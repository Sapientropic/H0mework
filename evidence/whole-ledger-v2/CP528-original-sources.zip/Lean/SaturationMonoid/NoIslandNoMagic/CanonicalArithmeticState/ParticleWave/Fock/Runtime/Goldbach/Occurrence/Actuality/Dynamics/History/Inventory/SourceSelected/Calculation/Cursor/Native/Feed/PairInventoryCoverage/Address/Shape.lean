import SaturationMonoid.NoIslandNoMagic.CanonicalArithmeticState.ParticleWave.Fock.Runtime.Goldbach.Occurrence.Actuality.Dynamics.History.Inventory.SourceSelected.Calculation.Cursor.Native.Feed.PairInventoryCoverage
import SaturationMonoid.GenericFoundation.Operations.Execution.Relations.History.Feed.Occurrence.Cut

set_option autoImplicit false
set_option Elab.async false
noncomputable section

namespace SaturationMonoid.ResponsibilityLifecycle.LivingLawEvolution.ConstructiveRoot
namespace NoIslandNoMagic.CanonicalArithmeticState.GoldbachUnitSelectedActor.Calculation.Cursor.Native.Feed.PairInventoryCoverage
open CofinalHistorySettlement SourceOperationExecution SourceOperationEffects
open SourceOperationScalarInventoryLift SourceOperationScalarRelations

namespace W
export SourceInventoryExecutionFeed.WordReceipt (RelationOccurrence)
end W
namespace P
export SourceOperationPaidRelations (words stepOccurrence exposure ReadStep readStep AtStep paidCut paidCut_word)
end P
namespace R
export Cursor.Native.Feed.PairHistory (birthReceipt)
end R

structure PartAt {G : Type} (parts whole : Nat → List G) (n position : Nat) where
  block : Fin n
  localIndex : Fin (parts block.val).length
  offset_eq : position = (whole block.val).length + localIndex.val
  read : (whole n)[position]? = (parts block.val)[localIndex.val]?

def locatePart {G : Type} (parts whole : Nat → List G)
    (empty : whole 0 = []) (advance : ∀ n, whole (n+1) = whole n ++ parts n) :
    (n position : Nat) → position < (whole n).length → PartAt parts whole n position
  | 0, position, inside => by
    rw [empty, List.length_nil] at inside
    exact False.elim (Nat.not_lt_zero position inside)
  | n+1, position, inside => by
    by_cases earlier : position < (whole n).length
    · let found := locatePart parts whole empty advance n position earlier
      refine ⟨found.block.castSucc, found.localIndex, found.offset_eq, ?_⟩
      rw [advance, List.getElem?_append_left earlier]
      exact found.read
    · have later : (whole n).length ≤ position := Nat.le_of_not_gt earlier
      let localIndex := position - (whole n).length
      have valid : localIndex < (parts n).length := by
        rw [advance, List.length_append] at inside
        dsimp only [localIndex]
        omega
      refine ⟨Fin.last n, ⟨localIndex, valid⟩, ?_, ?_⟩
      · change position = (whole n).length + localIndex
        dsimp only [localIndex]
        omega
      · simp only [advance, List.getElem?_append_right later, Fin.val_last, localIndex]

export Cursor.Native.Feed.Source (Values Vars)

set_option backward.isDefEq.respectTransparency false in
def originalTrace (depth count birth : Nat) :
    Trace (Value := PairValue (Values depth count)) (Var := Vars) (sort := true)
      (R.birthReceipt depth count birth).1.environment
      (R.birthReceipt depth count birth).1.expression
      (R.birthReceipt depth count birth).2.1.1 :=
  (R.birthReceipt depth count birth).2.1.2

abbrev PairWord (depth count : Nat) := Formal ℤ (PairValue (Values depth count)) Vars true

abbrev PairRelationAt {depth count : Nat} (stock : H.PairStock depth count) :=
  W.RelationOccurrence (V := PairValue (Values depth count)) (X := Vars) (s := true) stock

structure PositionRead {Word : Type} (read : Nat → Nat → Word → Type)
    (prefixSize : Nat → Nat) (n position : Nat) (word : Word) where
  birth : Fin n
  localIndex : Nat
  selected : read birth.val localIndex word
  offset_eq : position = n - 1 + prefixSize birth.val + localIndex

/-- The absolute stock address retains the born address of the same paid Step. -/
abbrev AddressedStep (depth count stage position : Nat) (word : PairWord depth count) :=
  PositionRead
    (fun (birth slot : Nat) (actual : PairWord depth count) =>
      P.ReadStep (originalTrace depth count birth) slot actual)
    (fun birth => (birthTraces depth count birth).length) (A.writtenCount depth count stage) position word


end NoIslandNoMagic.CanonicalArithmeticState.GoldbachUnitSelectedActor.Calculation.Cursor.Native.Feed.PairInventoryCoverage
end SaturationMonoid.ResponsibilityLifecycle.LivingLawEvolution.ConstructiveRoot
end
