import SaturationMonoid.NoIslandNoMagic.CanonicalArithmeticState.ParticleWave.Fock.Runtime.Goldbach.Occurrence.Actuality.Dynamics.History.Inventory.SourceSelected.Calculation.Cursor.Native.Feed.PairInventoryCoverage.Address.Shape

set_option autoImplicit false
set_option Elab.async false
noncomputable section

namespace SaturationMonoid.ResponsibilityLifecycle.LivingLawEvolution.ConstructiveRoot
namespace NoIslandNoMagic.CanonicalArithmeticState.GoldbachUnitSelectedActor.Calculation.Cursor.Native.Feed.PairInventoryCoverage
open CofinalHistorySettlement SourceOperationExecution SourceOperationEffects
open SourceOperationScalarInventoryLift SourceOperationScalarRelations

abbrev OriginalStepAt {depth count stage : Nat} (retained : H.PairExposure depth count stage)
    (event : PairRelationAt (depth := depth) (count := count) retained.stored) :=
  AddressedStep depth count stage event.before.length event.word

private theorem read_occurrence {depth count : Nat} {stock : H.PairStock depth count}
    (event : PairRelationAt (depth := depth) (count := count) stock) :
    stock.trace[event.before.length]? = some (.relation event.word) := by
  simp only [event.trace_eq, List.getElem?_append_right (Nat.le_refl _), Nat.sub_self, List.getElem?_cons_zero]

set_option cleanup.letToHave false in
/-- Eliminate an actual relation slot by its address in the original complete inventory. -/
def originalStepAt {depth count stage : Nat} (retained : H.PairExposure depth count stage)
    (event : PairRelationAt (depth := depth) (count := count) retained.stored) : OriginalStepAt retained event := by
  let n := A.writtenCount depth count stage
  let root := anchor depth count
  let spine := List.replicate (n-1) root
  let blocks := birthTraces depth count
  let parts (ordinal : Nat) := (H.birthWrite depth count ordinal).trace
  let position := event.before.length
  have full : retained.stored.trace = spine ++ blocks n := (actual_full_trace retained).2.2
  have read : retained.stored.trace[position]? = some (.relation event.word) := read_occurrence event
  have afterSpine : n-1 ≤ position := by
    by_contra! inside
    have inSpine : position < spine.length := by simpa only [spine, List.length_replicate] using inside
    have raw := (List.getElem?_append_left (l₂ := blocks n) inSpine).symm
    have isRoot : spine[position]? = some root := List.getElem?_replicate_of_lt inside
    have same : root = .relation event.word := Option.some.inj
      (isRoot.symm.trans (raw.trans (by rwa [full] at read)))
    change PresentedRelationEventAt.generator _ = .relation _ at same
    cases same
  let relative := position - (n-1)
  have inStock : position < retained.stored.trace.length :=
    (List.getElem?_eq_some_iff.mp read).elim (fun bound _ => bound)
  have inBlocks : relative < (blocks n).length := by
    rw [full, List.length_append] at inStock
    have spineLength : spine.length = n-1 := List.length_replicate
    rw [spineLength] at inStock
    dsimp only [relative]
    omega
  have subread : (blocks n)[relative]? = some (.relation event.word) := by
    have above : spine.length ≤ position := by simpa only [spine, List.length_replicate] using afterSpine
    rw [full, List.getElem?_append_right above] at read
    simpa only [relative, spine, List.length_replicate] using read
  let found := locatePart parts blocks rfl (fun _ => rfl) n relative inBlocks
  have partRead : (parts found.block.val)[found.localIndex.val]? = some (.relation event.word) :=
    found.read.symm.trans subread
  let original := originalTrace depth count found.block.val
  let step := P.readStep original found.localIndex.val event.word partRead
  refine ⟨found.block, found.localIndex.val, step, ?_⟩
  have place := found.offset_eq
  change relative = (blocks found.block.val).length + found.localIndex.val at place
  change position = n-1 + (blocks found.block.val).length + found.localIndex.val
  dsimp only [relative] at place
  omega

def OriginalStepAt.cut {depth count stage : Nat} {retained : H.PairExposure depth count stage}
    {event : PairRelationAt (depth := depth) (count := count) retained.stored} (selected : OriginalStepAt retained event) :
    P.AtStep (originalTrace depth count selected.birth.val) selected.selected.index.val :=
  P.paidCut _ selected.selected.index

end NoIslandNoMagic.CanonicalArithmeticState.GoldbachUnitSelectedActor.Calculation.Cursor.Native.Feed.PairInventoryCoverage
end SaturationMonoid.ResponsibilityLifecycle.LivingLawEvolution.ConstructiveRoot
end
