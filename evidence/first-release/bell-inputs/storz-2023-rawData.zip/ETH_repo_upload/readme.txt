# Loophole-free Bell inequality violation with superconducting circuits
#
# Raw datasets, experimental data presented in the main text of the article
#
# Authors
# Simon Storz (simon.storz@phys.ethz.ch), Josua Schär, Anatoly Kulikov, Paul Magnard, Philipp Kurpiers, Janis Lütolf, Theo Walter, Adrian Copetudo, Kevin Reuer, Abdulkadir Akin, Jean-Claude Besse, Mihai Gabureac, Graham J. Norris, Andrés Rosario, Ferran Martin, José Martinez, Waldimar Amaya, Morgan W. Mitchell, Carlos Abellan, Jean-Daniel Bancal, Nicolas Sangouard, Baptiste Royer, Alexandre Blais & Andreas Wallraff

Department of Physics, ETH Zurich, CH-8093 Zurich, Switzerland

Abstract:
Superposition, entanglement and non-locality constitute fundamental features of quantum physics. 
The fact that quantum physics does not follow the principle of local causality can be experimentally demonstrated in Bell tests performed on pairs of spatially separated, entangled quantum systems. 
Although Bell tests, which are widely regarded as a litmus test of quantum physics, have been explored using a broad range of quantum systems over the past 50 years, 
only relatively recently have experiments free of so-called loopholes succeeded. 
Such experiments have been performed with spins in nitrogen–vacancy centres, optical photons and neutral atoms. 
Here we demonstrate a loophole-free violation of Bell’s inequality with superconducting circuits, which are a prime contender for realizing quantum computing technology. 
To evaluate a Clauser–Horne–Shimony–Holt-type Bell inequality, we deterministically entangle a pair of qubits and perform fast and high-fidelity measurements along randomly chosen bases on the qubits 
connected through a cryogenic link spanning a distance of 30 metres. Evaluating more than 1 million experimental trials, we find an average S value of 2.0747 ± 0.0033, 
violating Bell’s inequality with a P value smaller than 10^−108. Our work demonstrates that non-locality is a viable new resource in quantum information technology realized with superconducting circuits 
with potential applications in quantum communication, quantum computing and fundamental physics.

- The datasets are named after the corresponding figure used for displaying. 

- More data available upon reasonable request.

Simon Storz