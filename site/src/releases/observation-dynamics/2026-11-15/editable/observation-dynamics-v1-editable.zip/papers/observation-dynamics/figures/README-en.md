# Observation dynamics figures

The six editable English SVGs share the geometry, curves, numerical inputs, and color conventions of the Chinese figures. Dark blue marks the generated objects and main curves. Gold marks reference curves or a second fibre. Vermilion identifies a split, decisive equation, new participant, risk increment, or threshold.

| Figure | English asset | What it shows |
| --- | --- | --- |
| 1 | [Observation fibres](01-observation-fibres-en.svg) | A source action splits a fibre with current readout $o=0$. A unit signal at position 2 has spatial samples $(0,0)\to(0,1)$ and full responses $(7,13)\to(9,18)\to(11,21)$. See §1 and Examples 2.1 and 3.2. |
| 2 | [Minimum window](02-minimum-window-en.svg) | The third frame supplies the last independent equation at copy scale $a=2$. Eliminating $h_1$ recovers all four spatial coordinates and the independent mass and clock. See §§3.2–3.3 and Theorems 3.3–3.4. |
| 3 | [Merge and update](03-merge-update-en.svg) | The same new participant enters before or after a merge. Both paths give the full counted moment $C'_z r'_z=C_z r_z+b$. See §5.2 and Theorem 5.3. |
| 4 | [Exact risk](04-exact-risk-en.svg) | Weighted $L^2$ splits the coarse residual into the fine residual and the difference of conditional means. In the five-participant example, spatial risk rises from $3/5$ to $4/5$. Clock risk is $8$ under both readouts and mass risk is zero. The full risk rises from $43/5$ to $44/5$. See §6.1 and Example 6.2. |
| 5 | [Parity and forgetting](05-parity-forgetting-en.svg) | The old and new multipliers $(d+2,d+3)\bmod 2$ reverse which code fares better. The worse code has risk at least $(d+1)/(d+2)$. A Gamma mixture gives the shifted power law $(1+t/r)^{-\alpha}$. See §§6.3–6.5 and Theorems 6.6 and 6.9. |
| 6 | [Reset-free circuit](06-no-reset-circuit-en.svg) | Ten drive lines yield 1024 digital images through the RLC circuit and 60-word ADC. A shared 11-output AIG implements the 128-bit arithmetic. The right panel gives the time-distortion bound for one $B$-bit packet. See §§7.1–7.4 and Theorems 7.1–7.6. |

In Figure 4, the triangle depicts orthogonality. Its side lengths are schematic. The two fine clock means and the clock risk both happen to equal $8$ in this example.

In Figure 5, the right panel sets $\alpha=1$. The solid curve is $(1+t/r)^{-1}$. The gold dashed curve is the single exponential $e^{-\alpha t/r}$ at the mean rate, and the pale dashed curves are representative exponential components.

In Figure 6, the voltage curves are schematic. The marked handoff occurs at the next ADC snapshot, after the RLC circuit has switched in response to feedback. The right panel shows $\mathrm{Risk}/\tau^2\ge\max(0,[(n/M)^2-1]/12)$, with $M=2^B$. The lower bound equals the tolerance at the vermilion point and exceeds it to the right.

Generate the SVGs from the repository root with Python and fontTools. The shared figure renderer uses STIX Two Text and STIX Two Math. The reading PDF build converts the SVGs to vector PDF with headless Chrome.

```sh
python3 papers/observation-dynamics/figures/make_figures.py --language en --svg-only
```
