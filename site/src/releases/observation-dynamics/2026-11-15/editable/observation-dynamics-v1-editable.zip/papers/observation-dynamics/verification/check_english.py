"""Verify that the English edition retains the published mathematics and source links."""

from collections import Counter
from pathlib import Path
import re

PAPER = Path(__file__).resolve().parents[1]
CHINESE = PAPER / "manuscript.md"
ENGLISH = PAPER / "manuscript-en.md"
# Text labels inside otherwise identical formulae.
MATH_LABELS = {
    "且": "and",
    "其他情形。": "otherwise.",
    "原粗观察的内在条件方差": "intrinsic coarse conditional variance",
    "取遍值群": "ranges over the value group",
    "为等距嵌入且": "is isometric and",
}
INLINE = re.compile(r"\\\((.*?)\\\)", re.S)
DISPLAY = re.compile(r"(?ms)^[ \t]*\\\[(.*?)^[ \t]*\\\]")
CITATION = re.compile(r"(?<![\w.])@([A-Za-z][A-Za-z0-9]+)")
HEADING = re.compile(r"(?m)^#{2,3} +(?:附录\s*|Appendix )?(\d+(?:\.\d+)?|[A-C])(?=[. 　])")
RESULT = re.compile(
    r"(?m)^\*\*(?:附录定理|主定理|定理|命题|引理|推论|例|定义|构造|"
    r"Appendix Theorem|Main Theorem|Theorem|Proposition|Lemma|Corollary|Example|Definition|Construction)"
    r"\s+([A-Z0-9]+\.\d+)\s*[(（]"
)
FIGURE = re.compile(r"(?m)^!\[[^\n]*\]\((figures/[^)]+\.svg)\)$")
PUBLIC_URL = re.compile(r"\]\((https://(?:github\.com/Sapientropic/H0mework/|doi\.org/)[^\s)]+)\)")
PRIVATE_PATH = re.compile(r"file:/|(?<![\w./])/(?:Users|Volumes|home|private/var|var/folders|tmp|opt/homebrew)/")
CJK = re.compile(r"[\u2e80-\u2fff\u3000-\u30ff\u3400-\u9fff\uf900-\ufaff\uff00-\uffef]")


def math_label(match):
    label = match[1].strip()
    return r"\text{" + MATH_LABELS.get(label, label) + "}"


def normalize_math(latex):
    latex = re.sub(r"\\text\{([^{}]*)\}", math_label, latex)
    return " ".join(latex.split())


def abstract(text, heading):
    body = text.split(heading + "\n\n", 1)[1]
    return body.split("\n\n**Keywords:", 1)[0]


def check():
    zh, en = CHINESE.read_text(), ENGLISH.read_text()
    assert not CJK.search(en), "Untranslated prose or punctuation"
    assert not PRIVATE_PATH.search(en), "Private path"
    assert en.splitlines()[0] == "# " + zh.splitlines()[2].removeprefix("## "), "English title"
    assert abstract(zh, "### Abstract") == abstract(en, "## Abstract"), "Published English abstract"
    assert HEADING.findall(zh) == HEADING.findall(en), "Chapters, subsections, and appendices"
    assert RESULT.findall(zh) == RESULT.findall(en), "Numbered results"
    assert CITATION.findall(zh) == CITATION.findall(en), "Citations"
    assert PUBLIC_URL.findall(zh) == PUBLIC_URL.findall(en), "DOI and fixed proof links"
    assert zh.count("∎") == en.count("∎"), "Proof endings"

    # Preserve display order and all inline formulae. English sentence order
    # can change the order of inline formulae.
    display_zh = list(map(normalize_math, DISPLAY.findall(zh)))
    display_en = list(map(normalize_math, DISPLAY.findall(en)))
    assert display_zh == display_en, "Displayed formulae or equation labels"
    inline_zh = list(map(normalize_math, INLINE.findall(zh[zh.index("### Abstract"):])))
    inline_en = list(map(normalize_math, INLINE.findall(en[en.index("## Abstract"):])))
    assert Counter(inline_zh) == Counter(inline_en), "Inline formulae"
    figures = FIGURE.findall(en)
    assert figures == [path.removesuffix(".svg") + "-en.svg" for path in FIGURE.findall(zh)]
    assert len(set(figures)) == 6 and all((PAPER / path).is_file() for path in figures)
    print(f"Bilingual parity passed: {len(RESULT.findall(en))} numbered results, "
          f"{len(display_en)} display blocks, {len(inline_en)} inline formulae, "
          f"{len(set(CITATION.findall(en)))} references, {len(figures)} localized figures")


if __name__ == "__main__":
    check()
