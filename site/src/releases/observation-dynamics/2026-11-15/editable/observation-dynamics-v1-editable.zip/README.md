# Autonomous Observation Dynamics

This archive contains both complete manuscripts, the shared bibliography, and the original vector figures in both languages.

From the extracted root, check formula and citation parity and independently recompute the paper's rational and combinatorial examples.

    python3 papers/observation-dynamics/verification/check_english.py
    python3 papers/observation-dynamics/verification/recheck.py

To rebuild the PDFs, use Python 3, Pandoc, XeLaTeX with xeCJK, Noto Serif/Sans CJK SC fonts, and Chrome for SVG conversion.

    python3 shared/scripts/build_pdf.py papers/observation-dynamics/manuscript.md papers/observation-dynamics/manuscript-en.md

The [proof and reproduction guide](https://github.com/Sapientropic/H0mework/blob/5e115b4637d39f52e8064759abdfe8237597934a/docs/observation-dynamics-reproduction.md) binds the Lean 4 proofs to their original evidence and archival inputs.

The manuscripts and original figures are licensed under CC BY 4.0. Lean source follows the H0mework Apache-2.0 license.
