# Ontological Rigidity and Universal Single-Mother Formation · editable v2

The bilingual v2 manuscripts (each with Appendices A-E), eight editable v2 vector
figures, PNG previews, the v2 figure generator, bibliography, metadata, and the
OB1-OB13 selection preserve the directory layout required by the shared builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome, and Noto Serif/Sans CJK SC. Build both PDFs:

    python3 shared/scripts/build_pdf.py papers/one-bit/manuscript.md papers/one-bit/manuscript-en.md --output-dir papers/one-bit/build/zenodo-20261111-v2

With fontTools, Google Chrome, and pdftoppm installed, regenerate the v2 figures:

    python3 papers/one-bit/figures/render_v2.py
    python3 papers/one-bit/figures/render_v2.py --english

The second-edition proof map and reproduction guide are available at H0mework
commit ffa5eeb70130b17db3873407d0cd10a218e45896. The selection records their paths,
the original CP483 and CP485 certifications, and the accepted OB2, OB12 and
OB13 build, dependency audit and declaration types. The accepted OB1-OB11
proofs are located through H0mework commit 6bff9d4046b3f89004678244482b1c403837150c.
The first-edition preprint has DOI 10.5281/zenodo.23437456.
Paper text and original figures use CC BY 4.0. Code uses Apache-2.0.
