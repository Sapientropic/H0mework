# 原文比较：古典问题源流与四大现代技术坐标（v2）

核查日期：2026-10-14（古典源流 `[1]`–`[5]`）与 2026-11-11（第二版现代技术坐标 `[9]`–`[20]`）。严格区分原文实际核读范围与本稿自身承担的数学责任，绝不由二手转述替代文本。第一版冻结书目保留于 [第一版 DOI](https://doi.org/10.5281/zenodo.23437456)，第二版完整书目见 [references-v2.bib](references-v2.bib)，本稿精确主张见 [第二版选集](release-selection-v2.json)。

## 一、四大古典问题源流与旧版题名致意（`[1]`–`[5]`）

| 原始来源 | 实际读取范围 | 本篇的具体接缝与边界 |
| --- | --- | --- |
| **Leibniz (1714)，*Monadology*，§§31–38**，Robert Latta 英译，[原著译文](https://en.wikisource.org/wiki/Monadology_(Leibniz,_tr._Latta)) | 直接读取 §§31–38，含矛盾律、充分理由、必然／偶然真理和最终理由的论证。 | 共同问题是偶然差异何以如此而非别样；本稿在零公理内核中将结构根据兑现为单构造子发生树、登记发生 $\mathsf{occ}(w)$ 与活当前单射 $\iota(s)$，不引入序列之外的神学实体，亦不把结构根据窄化为时间前因。 |
| **Wheeler (1989)，*Information, Physics, Quantum: The Search for Links***，[作者论文重印](https://cqi.inf.usi.ch/qic/wheeler.pdf) | 读取摘要及 §19.1–19.2（设备介导的 yes/no 问答与 “it from bit”），核对重印首页脚注原载信息（Tokyo, 1989, pp. 354–368）。 | 二值追问与物理实在资格有明确前史。本稿的二值问句判别“账外差异能否准入”而非单次测量比特；观察者与仪器同由母源 $S_\star$ 形成，局部不可见不消灭已登记发生（定理 3.3）。 |
| **Shannon (1948)，*A Mathematical Theory of Communication***，[原文修订重印](https://people.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf) | 读取 Introduction 二进制单位及 §6 熵定义、二值情形与确定结果的零熵性质。 | 严格区分**二值准入判准**、**节点语法计费**与**统计香农熵**：恒取“否”的确定性判准其统计熵为 $0$，而零数值效应请求（$\epsilon=0$）仍须支付正整数语法归约步（§5.3）。 |
| **Necula & Lee (1996)，*Safe Kernel Extensions Without Run-Time Checking***，[USENIX 原文](https://www.usenix.org/legacy/publications/library/proceedings/osdi96/full_papers/necula/html/osdi.html) | 读取摘要、PCC 机制与验证证明章节：接收方重建安全谓词并核验附带证明；核对 DOI `10.1145/238721.238781`。 | 共享“准入资格由机器可检证明现场支付”；本稿将其从单次代码安全谓词扩展为全生命周期源生合同（根发生、全事件库存、同债扣款、已付语法树余链续行与破产首写承接）。 |
| **Vaswani 等 (2017)，*Attention Is All You Need***，[arXiv:1706.03762](https://arxiv.org/abs/1706.03762) | 读取题录、摘要与版本记录。 | 仅记录第一版预印本题名致意；正文不对神经网络架构或统计标度律作任何外推。 |

## 二、四大现代技术前沿坐标（`[9]`–`[20]`）

| 柱位 | 原始来源 | 实际读取范围 | 本篇的正向推进与严格区分 |
| --- | --- | --- | --- |
| **系统引文** | **de Moura & Ullrich (2021)，*The Lean 4 Theorem Prover and Programming Language***，CADE-28, pp. 625–635，[原文 PDF](https://lean-lang.org/papers/lean4.pdf) | 读取 §1（CIC 基础）与 §5（p. 9，可信小内核及外部参考检查器导出）。 | 作为形式化验证工具链的系统引文；本稿 T0（`#print axioms = []`）与 T1（标准三公理）的公理依赖闭包由本稿自身的内核审计回执与 `check_release.py` 支持。 |
| **柱 I · 依赖类型与相等** | **Martin-Löf (1984)，*Intuitionistic Type Theory***，Bibliopolis，[原文重排 PDF](https://archive-pml.github.io/martin-lof/pdfs/Bibliopolis-Book-retypeset-1984.pdf) | 读取集合族不交并 $\Sigma(A,B)$ 与第一／第二投影规则 `p(c), q(c)`（pp. 20–26, 33）及命题相等 $I(A,a,b)$（pp. 31–34，其中 p. 32 采用相等反射规则）。 | 作为依赖对 $\Sigma$ 投影的经典来源；注意该 1984 讲义采用外延相等反射，而本文在 Lean 4 内涵内核中将合法状态定义为源生可达访问，由一步 $\Sigma$ 第一投影恢复世界状态。 |
| **柱 I · 宇宙单值性** | **Univalent Foundations Program (2013)，*Homotopy Type Theory***，IAS，[arXiv:1308.0729](https://arxiv.org/pdf/1308.0729) | 直接读取 §2.7（$\Sigma$ 类型）与 §2.10（引理 2.10.1 $\mathsf{idtoeqv}$ 及公理 2.10.3 单值公理 `Univalence`）。 | 单值公理刻画同一类型宇宙内的**类型等价与类型相等** $(A=_{\mathcal U} B)\simeq(A\simeq B)$；本文处理另一层问题——固定权威根或活过程内部的状态与发生身份，不引入单值公理，而以单构造子展开树与登记发生单射 $\mathsf{occ}(w)$ 判定同一性。 |
| **柱 I/III · 资源逻辑** | **Girard (1987)，*Linear Logic***，*TCS* 50(1):1–101；**Atkey (2011)，*Amortised Resource Analysis with Separation Logic***，*LMCS* 7(2:17)，[原文 PDF](https://bentnib.org/amortised-sep-logic-journal.pdf) | 核对 Girard 指数算子（`!/?`）对带标记公式复制与舍弃的控制；读取 Atkey §§1, 3.3–3.6, 5（堆与可消耗信用分离断言、§5 线性规划自动推断信用注解，以及 §3.6 向环境动态请求资源的可失败 `acquire` 指令）。 | 共享资源显式计账精神；区别在于线性逻辑以模态控制结构规则、Atkey 以规范信用注解（可经线性规划推断）及可失败环境 `acquire` 刻画程序资源，而本文语法预算 $Q=c(r_m)$ 由未付残差语法树内生决定，并在不相交和类型上强制同债扣减且不对原债行增补预算（新生请求另入右支）。 |
| **柱 II · 操作概率量子重构** | **Chiribella, D'Ariano & Perinotti (2011)，*Informational derivation of quantum theory***，*PRA* 84:012311 (`arXiv:1011.6451`) | 直接读取原稿 §§II–III：一般操作概率框架（制备、转换与测量结果概率规则）、五条信息公理及纯化公设（Postulate 1 `Purification`）。 | 该工作采用一般操作概率框架，由五条信息公理加纯化公设导出有限维量子理论；本文不以操作概率测试为原语，而在 T1 由单一确定性二态母源 $S_\star$ 的有限程序一致完备化普遍形成世界、询问与宏过程（定理 4.2），并在同一发生上恢复连续九场与 $4\sqrt2$ 配对（定理 4.4）。 |
| **柱 II · 构造子理论** | **Deutsch & Marletto (2015)，*Constructor theory of information***，*Proc. R. Soc. A* 471:20140540 (`arXiv:1405.5563`) | 直接读取原文 §§1–2（任务可能 $A^\checkmark$ 与不可能 $A^{\boldsymbol{\times}}$ 表述）、§6（原理 III 互操作性原理、原理 IV 可区分性原理）与 §§7–8（超信息媒质）。 | 构造子理论以底物上任务的可能／不可能及互操作性原理（原理 III）表述信息定律；本文 T0 内核不设“不可能”原语而从因果准入正向导出 `noMagicBit`，并在 T1 由固定母源 $S_\star$ 给出跨任意网络与词汇的普遍形成证明。 |
| **柱 II/I · 精化映射与辅助变量** | **Abadi & Lamport (1991)，*The Existence of Refinement Mappings***，*TCS* 82(2):253–284，DOI `10.1016/0304-3975(91)90224-P`，[作者原文](https://lamport.azurewebsites.net/pubs/abadi-existence.pdf) | 直接读取摘要与正文：在机器闭合、内部连续与有限不可见非确定性条件下，通过向低层规范增补辅助变量（历史变量与依赖未来的预言变量，投影回原变量保持相同可见行为）构造状态精化映射。 | 两条精确对比：① 精化证明中的预言变量是保持可见行为的规范层辅助扩充，而本文 §3.3 指出合法当前世界态本身不存储依赖未执行未来的数据；② 定理 4.2 无需增补目标规范以构造两层间精化映射，而在 `Type 0` 不交并内部自建分离地址，由同一母源 $S_\star$ 完备化直接给出左逆恢复。 |
| **柱 III · 溯源半环与增量微分** | **Green, Karvounarakis & Tannen (2007)，*Provenance Semirings***，PODS '07, pp. 31–40，[原文 PDF](https://web.cs.ucdavis.edu/~green/papers/pods07.pdf)；**Cai 等 (2014)**，PLDI '14 (`arXiv:1312.0658`)；**Budiu 等 (2023)，*DBSP***，*PVLDB* 16(7):1601–1614，[PVLDB 原文](https://www.vldb.org/pvldb/vol16/p1601-budiu.pdf) | 读取 Green 等 §§3–6（多项式半环 $\mathbb N[X]$ 同态分解，命题 3.5、4.2，定理 4.3）；Cai 等 §2–§3（变化结构与定理 3.11 `Derive` 正确性）；Budiu 等 §3（定理 3.3–3.4 双线性增量公式）与 §4.1（$\mathbb Z$-集定义）。 | 共享式 (10) 的交换群精确有限差分与双线性展开及代数求值分解思想；本文进一步将字面残差语法树转化为带正语法预算的下一原生请求（$\epsilon=0$ 仍执行两步扣款），经双负号恢复已付 AST 持续执行同态方法（`OB12`），并由九构造子原语回放同步生成库存边界与余链微分 $d^{0,1}$（`OB13`）。 |
| **柱 IV · 理论收缩与信念修订** | **Alchourrón, Gärdenfors & Makinson (1985)，*On the Logic of Theory Change: Partial Meet Contraction and Revision Functions***，*J. Symb. Logic* 50(2):510–530，DOI `10.2307/2274239` | 核对部分交收缩 $K \dot{-} p = \bigcap \gamma(K \bot p)$（利用选择函数 $\gamma$ 在极大不蕴含子集族中去掉对指定命题 $p$ 的蕴含，满足包含律 $K \dot{-} p \subseteq K$）以及有冲突输入时经 Levi 恒等式 $K*p=\mathrm{Cn}((K\dot{-}\neg p)\cup\{p\})$ 先收缩 $\neg p$ 再并入 $p$ 的修订构造。 | AGM 在**固定命题语言**内通过选择函数 $\gamma$ 去掉指定蕴含（并在冲突修订中借 Levi 恒等式先收缩 $\neg p$ 以保持一致）；本文 §6（`OB9`）处理的是旧语言表达与合法实现**双空破产**，在**零公理（免选择函数）**下生成范畴初始余面 $L_+\sqcup\{\star_\eta\}$ 扩张坐标维度（定理 6.2），同时令迁入旧债行与新方向行共用非终账首写而不收缩历史未清责任（定理 6.5）。 |

## 三、同系列专篇分工（`[6]`–`[8]`）

本篇与过程核心 v2（`[6]`）、物理旗舰 v3（`[7]`）及整账法 v1（`[8]`）的精确责任边界按 [第二版选集](release-selection-v2.json) 的 `OB1–OB13` 对应陈述：共享形式定理具名复用，跨四柱的总纲统摄、现代学术坐标定位与自足证明在本文完整展开。
