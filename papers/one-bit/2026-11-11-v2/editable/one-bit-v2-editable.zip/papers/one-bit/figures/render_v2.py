#!/usr/bin/env python3
"""Generate the One Bit v2 editable SVG plates and PNG previews.

Preserves v1 plates (`*.svg`/`*.png`) untouched by writing `*-v2.svg`/`*-v2.png`
and `*-v2-en.svg`/`*-v2-en.png`. Uses `shared/figure-style` with 1440 px canvas
width, minimum 24 px type size, and strict bounding-box / non-overlap assertions.
"""
import argparse
import subprocess
import sys
import tempfile
from html import escape
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH  # noqa: E402
import svg_text  # noqa: E402
from svg_text import line, text_width  # noqa: E402

svg_text.OPS.update('⋆⊔≡⇏∅∀∃→↦≠≤≥×√′−∧∂')
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'

W = 1440
MIN_SIZE = W / 60  # 24.0 px body floor
SUB_MIN = 18.5     # true mathematical sub/superscript size
LANG = ['zh']
parts, boxes = [], []


def L(zh, en):
    return zh if LANG[0] == 'zh' else en


def start(height, title, description):
    parts.clear()
    boxes.clear()
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
        f'viewBox="0 0 {W} {height}" role="img">'
    )
    parts.extend([f'<title>{escape(title)}</title>', f'<desc>{escape(description)}</desc>'])
    parts.append(
        '<defs>'
        + ''.join(
            f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" '
            f'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>'
            for n, c in [('ink', SLATE), ('acc', VERMILION), ('deep', DEEP)]
        )
        + '</defs>'
    )
    parts.append(f'<rect width="{W}" height="{height}" fill="#FFFFFF"/>')
    return height


def txt(x, y, text, size=25, color=INK, weight=400, anchor='start'):
    assert size >= MIN_SIZE - 1e-9, (text, size)
    width = text_width(text, size, SUB_MIN)
    x0 = x - {'start': 0, 'middle': width / 2, 'end': width}[anchor]
    boxes.append((x0, y - 0.80 * size, x0 + width, y + 0.22 * size, text))
    parts.append(line(x, y, text, size, color, weight, anchor, min_size=SUB_MIN))


def rect(x, y, w, h, fill='none', stroke=HAIR, width=1.6, radius=6, dashed=False):
    dash = ' stroke-dasharray="10 7"' if dashed else ''
    parts.append(
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" '
        f'stroke="{stroke}" stroke-width="{width}"{dash}/>'
    )


def path(d, color=SLATE, width=2.2, marker='ink', dashed=False):
    dash = ' stroke-dasharray="9 6"' if dashed else ''
    end = f' marker-end="url(#arrow-{marker})"' if marker else ''
    parts.append(
        f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{dash}{end}/>'
    )


def arrow(x1, y1, x2, y2, color=SLATE, marker='ink', width=2.2, dashed=False):
    path(f'M {x1} {y1} L {x2} {y2}', color, width, marker, dashed)


def card(x, y, w, h, title, rows, stroke=HAIR, fill='none', gap=36, title_color=INK, dashed=False, badge=None):
    rect(x, y, w, h, fill, stroke, 2.4 if stroke in (VERMILION, DEEP) else 1.6, dashed=dashed)
    txt(x + 20, y + 40, title, 26, title_color, 600)
    if badge:
        txt(x + w - 18, y + 40, badge, 24, DEEP if stroke != VERMILION else VERMILION, 500, 'end')
    for i, row in enumerate(rows):
        txt(x + 20, y + 80 + i * gap, row, 24, SLATE)
    check_count = len(rows) + (2 if badge else 1)
    for (x0, _, x1, _, t) in boxes[-check_count:]:
        assert x1 <= x + w - 12, ('card overflow', LANG[0], t, x1, x + w)


def save(name, height):
    for i, a in enumerate(boxes):
        assert a[0] >= 8 and a[2] <= W - 8 and a[1] >= 4 and a[3] <= height - 4, ('outside canvas', LANG[0], a)
        for b in boxes[i + 1:]:
            if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                raise AssertionError(('text overlap', LANG[0], a[4], b[4]))
    svg = '\n'.join(parts + ['</svg>'])
    stem = f'{name}-v2' if LANG[0] == 'zh' else f'{name}-v2-en'
    svg_path = OUT / f'{stem}.svg'
    png_path = OUT / f'{stem}.png'
    svg_path.write_text(svg, encoding='utf-8')
    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        html_path = tmp_dir / f'{stem}.html'
        pdf_path = tmp_dir / f'{stem}.pdf'
        html_path.write_text(
            '<!doctype html><html><head><style>'
            f'@page{{size:{W}px {height}px;margin:0}}html,body{{margin:0;padding:0}}'
            f'img{{display:block;width:{W}px;height:{height}px}}</style></head>'
            f'<body><img src="{svg_path.as_uri()}"></body></html>',
            encoding='utf-8',
        )
        subprocess.run(
            [
                CHROME, '--headless=new', '--disable-gpu', '--no-pdf-header-footer',
                '--allow-file-access-from-files', f'--print-to-pdf={pdf_path}', html_path.as_uri(),
            ],
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ['pdftoppm', '-png', '-r', '144', '-singlefile', str(pdf_path), str(png_path.with_suffix(''))],
            check=True,
            capture_output=True,
        )


def forest():
    """Figure 1: Single-root occurrence and the four-pillar universal formation forest."""
    H = start(
        1040,
        L('单根发生与四柱普遍形成森林', 'Single-root occurrence and the four-pillar formation forest'),
        L(
            '零公理内核 RootRead(o)=o 与固定母源 S_⋆ 支撑全实在性、三域普遍形成、同债微分续行与初始余面修订四柱。',
            'The T0 kernel RootRead(o)=o and fixed mother S_⋆ support total reality, three-domain formation, '
            'paid differential continuation, and initial-coface revision.',
        ),
    )
    # Left entry gate
    parts.append(f'<ellipse cx="92" cy="440" rx="46" ry="60" fill="none" stroke="{VERMILION}" stroke-width="11"/>')
    txt(92, 544, L('二值问句', 'Binary gate'), 25, VERMILION, 600, 'middle')
    txt(92, 580, L('账外差异', 'unaccounted'), 24, SLATE, anchor='middle')
    txt(92, 612, L('能否准入？', 'standing?'), 24, SLATE, anchor='middle')
    arrow(148, 440, 188, 440, VERMILION, 'acc', 2.6)

    # Root card (T0 + S_star)
    card(
        196,
        266,
        352,
        348,
        L('根内核与母源', 'Root kernel · S{sub:⋆}'),
        [
            L('单构造子 occur(r, bs)', 'constructor occur(r, bs)'),
            'RootRead(o) = o',
            L('访问 w · 发生 occ(w)', 'visit w · occ(w)'),
            L('单根编译防火墙 (T0)', 'authority firewall (T0)'),
            L('母源 S{sub:⋆} (SpinPair)', 'mother S{sub:⋆} (SpinPair)'),
            L('整账写回 · 规范后继', 'ledger write · next'),
        ],
        DEEP,
        WASH,
        gap=40,
        title_color=DEEP,
    )

    # Four pillars
    bx, bw = 602, 542
    pillars = [
        (
            34,
            L('I · 零公理整现实', 'I · T0 total reality'),
            [
                L('正向 locate ⇒ 无补写 ∧ 无魔法', 'locate ⇒ no supplement ∧ no magic'),
                L('occ(w)≠occ(w′) · 活过程 ι(s)≠ι(s′)', 'occ(w)≠occ(w′) · process ι(s)≠ι(s′)'),
            ],
            'OB1–OB5 · []',
        ),
        (
            252,
            L('II · 三域普遍形成', 'II · Universal formation'),
            [
                L('S{sub:⋆} 有限程序完备化覆盖 ∀N,V,R', 'completed S{sub:⋆} programmes ∀N,V,R'),
                L('世界 · 询问 · 宏过程左逆恢复', 'worlds · inquiries · processes'),
            ],
            'OB6 · T1',
        ),
        (
            470,
            L('III · 同债与微分续行', 'III · Paid & cochain'),
            [
                L('全未来残差 → 严格扣款 → 完成回答', 'residual → strict debit → answer'),
                L('已付 AST 方法 f · 逐步回放 d{sup:0,1}', 'paid AST method f · replay d{sup:0,1}'),
            ],
            'OB8,12,13 · T0/T1',
        ),
        (
            688,
            L('IV · 初始余面修订', 'IV · Initial coface'),
            [
                L('双空破产 → 初始余面 L{sub:+}⊔{⋆{sub:η}} (T0)', 'double empty → L{sub:+}⊔{⋆{sub:η}} (T0)'),
                L('唯一单射分解 · 旧债与新行同首写', 'unique F · shared first write'),
            ],
            'OB9 · []',
        ),
    ]
    for y, title, rows, badge in pillars:
        card(bx, y, bw, 172, title, rows, gap=40, badge=badge)
        cy = y + 86
        path(f'M 548 440 C 574 440, 576 {cy}, {bx - 8} {cy}', DEEP, 2.4, 'deep')

    # Right column: downstream domain verifications
    ix, iw = 1180, 224
    txt(ix + iw / 2, 226, L('领域核验链', 'Domain checks'), 24, MUTE, 600, 'middle')
    card(
        ix,
        246,
        iw,
        186,
        L('统一场实现', 'Unified field'),
        [
            L('4√2 配对 · 九场', '4√2 pair · 9 fields'),
            L('16→17 · 任意深度', '16→17 · all depths'),
            'OB7',
        ],
        gap=36,
    )
    card(
        ix,
        466,
        iw,
        186,
        L('长窗口接力', 'Long window'),
        [
            L('四份旧迹迁移', 'four prior traces'),
            L('逆残差纠正续算', 'residual fuel'),
            'OB10',
        ],
        gap=36,
    )
    arrow(1150, 338, 1172, 338, MUTE, 'ink', 2.0)
    arrow(1150, 556, 1172, 556, MUTE, 'ink', 2.0)

    rect(36, 914, 1368, 86, WASH, VERMILION, 2.4)
    txt(
        720,
        966,
        L(
            '无魔法不是预置字段：T0 内核正向导出发生刚性，母源 S{sub:⋆} 无第二基源普遍形成三域',
            'No-magic is derived, not assumed: T0 proves rigidity and S{sub:⋆} universally forms three domains',
        ),
        25,
        VERMILION,
        600,
        'middle',
    )
    save('one-bit-forest', H)


def ghost():
    """Figure 2: Ghost-bit interception, injective occurrence admission, and single-root firewall."""
    H = start(
        730,
        L('幽灵比特拦截与单根权威防火墙', 'Ghost-bit interception and single-root firewall'),
        L(
            '裸二元组不等经唯一准入投影落回同一登记发生；真实差异必改变根访问，单根防火墙在编译期拦截八类越权路径。',
            'Unequal raw pairs project to one registered occurrence; real differences require distinct visits, '
            'and the compile-time firewall blocks bypass paths.',
        ),
    )
    card(
        36,
        36,
        372,
        244,
        L('裸载体二元组', 'Raw pair carrier'),
        [
            'g{sub:0} = (w{sub:1}, false)',
            'g{sub:1} = (w{sub:1}, true)',
            L('g{sub:0} ≠ g{sub:1}（第二分量不同）', 'g{sub:0} ≠ g{sub:1} (distinct Bool)'),
            L('未登记的附加布尔位', 'unregistered extra bit'),
        ],
        gap=38,
    )
    card(
        504,
        36,
        420,
        244,
        L('合法准入 · pr{sub:1}', 'Lawful admission · pr{sub:1}'),
        [
            'g{sub:0}.1 = g{sub:1}.1 = w{sub:1}',
            'RootRead(o) = o',
            'occ(g{sub:0}.1) = occ(g{sub:1}.1)',
            'auth(g{sub:0}.1) = auth(g{sub:1}.1)',
        ],
        DEEP,
        WASH,
        gap=38,
        title_color=DEEP,
    )
    card(
        972,
        36,
        432,
        244,
        L('真实因果差异', 'Genuine causal step'),
        [
            'w{sub:1} = finite(v{sub:1})',
            'w{sub:2} = finite(v{sub:1}.next)',
            'w{sub:1} ≠ w{sub:2} ⇒ occ(w{sub:1}) ≠ occ(w{sub:2})',
            L('由正向发生单射支付', 'paid by injective admission'),
        ],
        gap=38,
    )
    arrow(416, 158, 496, 158, DEEP, 'deep', 2.6)
    txt(456, 134, 'pr{sub:1}', 25, DEEP, 600, 'middle')

    # Blocked overreach arrow
    path('M 222 288 C 222 358, 480 358, 566 358', VERMILION, 2.6, None, dashed=True)
    txt(596, 368, '⇏', 38, VERMILION, 600, 'middle')
    txt(632, 366, L('越权升格为“两个合法世界”', 'illegal promotion to two worlds'), 25, VERMILION, 600)

    # Single-root compile-time firewall card
    card(
        36,
        416,
        1368,
        170,
        L('单根权威编译期防火墙（fail_if_success 与 #guard_msgs）', 'Single-root compile-time firewall (fail_if_success & #guard_msgs)'),
        [
            L('拦截 1–4：构造子带 Bool 幽灵参 · 未准入裸根 · 裁剪事件库存伪造终账 · 借旁路账行权威',
              'Blocks 1–4: ghost Bool arg · unadmitted raw root · pruning inventory · sibling authority'),
            L('拦截 5–8：未来神谕升格当前原子 · 绕根执行询问/修订 · 平行挑选神谕 · 未安装切面或旧根微后继冒充与预装表',
              'Blocks 5–8: completed oracle as atom · off-root inquiry/revision · parallel oracles · uninstalled face or micro-for-macro/preload'),
        ],
        SLATE,
        dashed=True,
        gap=40,
        badge='T0 · []',
    )

    rect(36, 612, 1368, 82, WASH, VERMILION, 2.4)
    txt(
        720,
        663,
        L(
            '多一位裸数据 ⇏ 多一个合法现实；唯有改变已登记发生，差异才取得结构身份',
            'One more raw bit ⇏ one more lawful world; only a distinct registered occurrence earns identity',
        ),
        25,
        VERMILION,
        600,
        'middle',
    )
    save('ghost-identity', H)


def continuation():
    """Figure 3: Residual request, same-debt payment, paid-AST continuation, and cochain replay."""
    H = start(
        900,
        L('残差请求、同债付款与已付语法树微分续行闭环', 'Residual request, same-debt payment, and paid-AST differential continuation'),
        L(
            '全未来残差内生生成下一请求并执行同债严格扣款；已付 AST 经双负号恢复持续执行同态方法 f，逐原语回放同步更新边界与上同调微分。',
            'The all-future residual generates the next request and strict same-debt payment; the recovered paid AST '
            'executes homomorphic method f while primitive replay updates boundary and cochain differentials.',
        ),
    )
    xs, width = [36, 388, 740, 1092], 312
    top_cards = [
        (
            L('1 · 全未来残差', '1 · Future residual'),
            [
                'r{sub:m} = a + (−id)(p)',
                '[r{sub:m}] − ([a]−[p]) ∈ Z',
                L('全作用词·全站位等价', 'all words & sites'),
            ],
            HAIR,
        ),
        (
            L('2 · 请求出生', '2 · Request birth'),
            [
                'Q = c(r{sub:m}) ≥ 2',
                L('出生首步已执行', 'birth step paid'),
                L('剩余 Q − 1 > 0', 'remaining Q − 1 > 0'),
            ],
            HAIR,
        ),
        (
            L('3 · 同债扣款', '3 · Strict debit'),
            [
                L('严格扣减 · 零回填', 'strict debit · no refill'),
                L('锁定同一债务谱系', 'same debt lineage'),
                L('ε = 0 仍付语法费', 'ε = 0 still pays'),
            ],
            VERMILION,
        ),
        (
            L('4 · 后缀交付', '4 · Completion'),
            [
                L('Q−1 步达完成值 ε', 'Q−1 steps reach ε'),
                L('回答 · 回执 · 整账', 'answer · receipt · ledger'),
                L('规范后继当前态', 'canonical next'),
            ],
            DEEP,
        ),
    ]
    for i, (x, (title, rows, stroke)) in enumerate(zip(xs, top_cards)):
        tcol = VERMILION if stroke == VERMILION else (DEEP if stroke == DEEP else INK)
        card(x, 36, width, 214, title, rows, stroke, WASH if stroke == DEEP else 'none', gap=38, title_color=tcol)
        if i < 3:
            c = VERMILION if i == 1 else SLATE
            m = 'acc' if i == 1 else 'ink'
            arrow(x + width + 6, 143, xs[i + 1] - 8, 143, c, m, 2.4)

    # Connector from Completion down to Row 2 (OB12 & OB13)
    path('M 1248 256 L 1248 314 L 356 314 L 356 354', DEEP, 2.4, 'deep')
    path('M 1030 314 L 1030 354', DEEP, 2.4, 'deep')

    # Row 2 left: OB12 Paid-AST continuation
    card(
        36,
        362,
        652,
        228,
        L('5 · 已付 AST 恢复与方法 f', '5 · Paid-AST recovery & method f'),
        [
            L('retainedCode 经 −(−p{sub:⋆}) 取回已付 AST', 'retainedCode extracts paid AST via −(−p{sub:⋆})'),
            L('下一共尾包执行 actionAt f → (f{sup:(n+1)}(v), 0)', 'next packet runs actionAt f → (f{sup:(n+1)}(v), 0)'),
            L('完整查询迹入出生库存 · 统一四面与关系余链', 'query trace in stock · 4+2 unified faces'),
            L('驱动封闭询问场跨任意有限步更新', 'drives inquiry field across finite steps'),
        ],
        DEEP,
        gap=38,
        title_color=DEEP,
        badge='OB12',
    )

    # Row 2 right: OB13 Primitive replay & cochain differential
    card(
        736,
        362,
        668,
        228,
        L('6 · 逐原语回放与余链微分', '6 · Step replay & cochain d{sup:0,1}'),
        [
            L('WordExecution 逐步回放源词原语并精确计费', 'WordExecution replays each step with cost'),
            L('已付迹与回放暴露并入出生库存与下一查询', 'paid trace & exposure enter born stock'),
            L('源关系 μ ↦ ∂ = relMap(τ{sub:1}(μ)) = d{sup:0,1}(∂)', 'relation μ ↦ ∂ = relMap(τ{sub:1}(μ)) = d{sup:0,1}(∂)'),
            L('余像微分与物理读回 · 擦除恢复原展开树', 'coimage diff & physical readback · unfolding'),
        ],
        DEEP,
        WASH,
        gap=38,
        title_color=DEEP,
        badge='OB13',
    )
    arrow(696, 476, 728, 476, DEEP, 'deep', 2.4)

    # Row 3: Whole-ledger conservation bar
    card(
        36,
        636,
        1368,
        122,
        L('同一次整账写入与债务谱系隔离', 'Single whole-ledger write and lineage isolation'),
        [
            L('旧责任行与出生行在同一写入各归其位；新请求自付首步单独立账，绝不替旧债回填预算（OB8, OB12–OB13）',
              'Old and born rows settle in one write; new requests pay their own first step without refilling prior debt (OB8, OB12–OB13)'),
        ],
        HAIR,
        gap=38,
    )

    rect(36, 784, 1368, 82, WASH, VERMILION, 2.4)
    txt(
        720,
        835,
        L(
            '账本不止于事后记账：残差亲自生出请求并付清同债，已付 AST 与逐步回放继续驱动微分演化',
            'Beyond ex-post bookkeeping: residuals generate and pay requests while paid ASTs drive cochain steps',
        ),
        25,
        VERMILION,
        600,
        'middle',
    )
    save('paid-continuation', H)


def revision():
    """Figure 4: Zero-axiom initial-coface extension and shared first-write debt succession."""
    H = start(
        1020,
        L('零公理初始余面升维与双行同首写承接', 'Zero-axiom initial-coface extension and shared first-write succession'),
        L(
            '根植双空破产在零公理下生成范畴初始余面与唯一单射分解；经发射与结构锚定的有类型修订将旧债行与新方向行送入同一次首写。',
            'A rooted doubly-empty failure generates a zero-axiom initial coface with unique factorization; '
            'an emitted anchored revision sends old and new rows through one shared first write.',
        ),
    )
    card(
        36,
        38,
        382,
        248,
        L('根植双空破产 η', 'Rooted bankruptcy η'),
        [
            L('表达纤维 = ∅ ∧ 实现纤维 = ∅', 'expression = ∅ ∧ realization = ∅'),
            L('事件 = 障碍演算规范发射', 'event = canonical emit'),
            L('旧根开放需求行 e · 处置交换', 'demand row e · commuting'),
            L('携带 e 的准确因果后继', 'carries successor of e'),
        ],
        gap=38,
    )
    card(
        532,
        38,
        388,
        248,
        L('范畴初始余面', 'Initial coface'),
        [
            'C{sub:η} = L{sub:+} ⊔ {⋆{sub:η}}',
            L('旧账左注入回缩 · 预算不变', 'old rows retract · same budget'),
            L('⋆{sub:η} 预算 0 · 无旧原像', '⋆{sub:η}: budget 0 · no preimage'),
            L('旧表达定理在旧面完整存续', 'old theorems survive intact'),
        ],
        DEEP,
        WASH,
        gap=38,
        title_color=DEEP,
        badge='T0 · []',
    )
    card(
        1022,
        38,
        382,
        248,
        L('任意容许修订', 'Admissible revision'),
        [
            L('旧账·关联·主张构造回缩', 'retracts on old coordinates'),
            L('新元无旧原像 · 零初始预算', 'new generator · budget 0'),
            L('继承行预算单调不增', 'budgets nonincreasing'),
            L('唯一忠实单射态射 F', 'unique faithful injection F'),
        ],
        gap=38,
    )
    arrow(428, 162, 522, 162, DEEP, 'deep', 2.6)
    txt(474, 136, L('生成', 'generate'), 24, DEEP, 600, 'middle')
    arrow(930, 162, 1012, 162, DEEP, 'deep', 2.4)
    txt(971, 136, '∃! F', 25, DEEP, 600, 'middle')

    # Middle anchored typed revision
    card(
        260,
        336,
        920,
        176,
        L('有类型修订 Ξ（由固定询问程序在准确发生处发射）', 'Typed revision Ξ (emitted at the exact occurrence by the inquiry)'),
        [
            L('非保守网络翻译 · 新词汇与新活根 · 旧后继发生与新初访发生双向保发射对应',
              'non-conservative translation · new root · emission-preserving correspondence'),
            L('结构锚定：精确极小锚定（逐字段认回 C{sub:η}）或带严格降预算拆分的忠实锚定',
              'structural anchoring: exact minimal recognition of C{sub:η}, or split-faithful anchoring'),
        ],
        SLATE,
        dashed=True,
        gap=40,
    )
    arrow(726, 292, 726, 328, DEEP, 'deep', 2.2)
    txt(742, 318, L('唯一分解', 'factorizes'), 24, DEEP)

    # Bottom: two rows -> single shared first write -> separate dispositions at revised root
    card(
        36,
        568,
        408,
        176,
        L('迁入旧故障行 inl(e)', 'Migrated old row inl(e)'),
        [
            L('精确等于旧根需求行 e', 'equals exact demand row e'),
            L('由自身初访补片成员获权威', 'authority from initial patch'),
            L('恢复层无事后重认入口', 'no post-hoc row submission'),
        ],
        gap=36,
    )
    card(
        36,
        786,
        408,
        176,
        L('新增方向行 ⋆{sub:η}', 'New direction row ⋆{sub:η}'),
        [
            L('唯一分解 F 送入之新生成元', 'image of generator under F'),
            L('携带以 η 为索引的语义变化', 'carries η semantic change'),
            L('由自身初访补片成员获权威', 'authority from initial patch'),
        ],
        gap=36,
    )
    path('M 260 424 L 18 424 L 18 874 L 28 874', SLATE, 2.0, 'ink')
    path('M 18 656 L 28 656', SLATE, 2.0, 'ink')

    rect(536, 676, 292, 152, WASH, VERMILION, 2.6)
    txt(682, 736, L('同一次首写', 'Shared first write'), 27, VERMILION, 600, 'middle')
    txt(682, 774, L('同一非终账后继等式', 'one nonterminal next'), 24, SLATE, anchor='middle')
    txt(682, 808, L('零休眠旁路行', 'zero dormant rows'), 24, SLATE, anchor='middle')
    path('M 452 656 C 494 656, 500 720, 528 728', VERMILION, 2.6, 'acc')
    path('M 452 874 C 494 874, 500 786, 528 776', VERMILION, 2.6, 'acc')

    card(
        904,
        580,
        500,
        368,
        L('新根分类器分别处置', 'Revised root classifier'),
        [
            L('旧行：独立取得目标回答与后继', 'old row: own target answer & next'),
            L('新行：独立取得目标回答与后继', 'new row: own target answer & next'),
            L('生成初始行共享同一规范下一当前', 'all rows share one next current'),
            L('登记异常（升维） ≠ 结清旧债', 'registering anomaly ≠ settlement'),
            L('两笔账并列推进，绝不互相冲抵', 'two accounts advance side by side'),
        ],
        DEEP,
        gap=46,
        title_color=DEEP,
        badge='OB9',
    )
    arrow(836, 752, 896, 752, DEEP, 'deep', 2.6)
    save('revision-ledger', H)


def render_all():
    forest()
    ghost()
    continuation()
    revision()


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--english', action='store_true')
    args = ap.parse_args()
    LANG[0] = 'en' if args.english else 'zh'
    render_all()
    print('Rendered four v2 ' + ('English' if args.english else 'Chinese') + ' plates.')
