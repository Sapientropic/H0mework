# 一比特稿图件（v2 与冻结 v1）

当前第二版（v2）四幅主图与[中文正文](../manuscript.md)及[英文正文](../manuscript-en.md)的图 1–4 一一对应（`*-v2.svg`／`*-v2-en.svg` 及同名 `.png` 预览）。第一版已发表图件（`*.svg`／`*-en.svg`、同名 `.png` 与 `render.py`）按[第一版成品清单](../release-artifacts.json)保留原字节不变。

| 图 | v2 中文／英文矢量源 | 读者应看出的核心结构与对照关系 | 正文与证明 |
| --- | --- | --- | --- |
| **图 1｜单根发生与四柱普遍形成森林** | [中文 SVG](one-bit-forest-v2.svg)／[英文 SVG](one-bit-forest-v2-en.svg) | 二值问句仅为准入门禁；真正的承重根是单构造子发生树 `RootRead(o)=o`、单根编译期防火墙与固定母源 $S_\star$，由此分立零公理整现实、三域普遍形成、同债微分续行与零公理初始余面修订四柱，右侧统一场与长窗口仅作下游核验消费。 | 主定理 1.1；[OB1–OB13](../claims.md) |
| **图 2｜幽灵比特拦截与单根权威防火墙** | [中文 SVG](ghost-identity-v2.svg)／[英文 SVG](ghost-identity-v2-en.svg) | 裸二元组 `g₀ ≠ g₁` 经唯一合法准入投影 `pr₁` 落回同一状态、`RootRead(o)=o` 与同一登记发生；真实差异必由不同根访问产生，虚框标出 `fail_if_success` 与 `#guard_msgs` 编译期防火墙拦截的八类越权路径。 | 引理 2.2、命题 2.3；[OB2](../claims.md#ob2) |
| **图 3｜残差请求、同债付款与已付语法树微分续行闭环** | [中文 SVG](paid-continuation-v2.svg)／[英文 SVG](paid-continuation-v2-en.svg) | 上层展示全未来残差生成请求、同债严格扣款与后缀完成交付（OB8）；中层展示 `retainedCode` 双负号取回已付 AST 执行同态方法 $f$（OB12）与 `WordExecution` 逐步回放同步更新库存边界、$\tau_1$ 及上同调微分 $d^{0,1}$（OB13）；下层标明同次整账写入与债务谱系隔离。 | 定理 5.1–5.5；[OB8, OB12–OB13](../claims.md#ob8) |
| **图 4｜零公理初始余面升维与双行同首写承接** | [中文 SVG](revision-ledger-v2.svg)／[英文 SVG](revision-ledger-v2-en.svg) | 根植双空破产在零公理下生成范畴初始余面 $C_\eta = L_+ \sqcup \{\star_\eta\}$ 与唯一单射分解 $\exists! F$；经固定询问发射并结构锚定的有类型修订将迁入旧债行与新增方向行送入同一次非终账首写，由新根分类器分别处置并共享同一规范下一当前。 | 定理 6.2–6.5；[OB9](../claims.md#ob9) |

## 编辑与再生成

在 publish 根目录运行 v2 图件生成器：

```sh
python3 papers/one-bit/figures/render_v2.py
python3 papers/one-bit/figures/render_v2.py --english
```

生成器使用 `shared/figure-style` 测量字宽与上下标边界，在写出前严格断言全部文字框不越出画布、不溢出卡片且互不重叠（画布宽 `1440px`，按 6 英寸版心排印，最小字号 `24px`），并经无头 Chrome 矢量打印与 `pdftoppm` 导出预览图，确保数学算符与上下标无缺字方框。墨灰表示既有结构与门禁，深蓝表示源内生成对象，朱红仅标每幅图的核心裁决点或严格扣款／首写汇合处。
