#!/usr/bin/env python3
"""Check the One Bit paper's written locations, source bindings, and bilingual parity.

Run from the publish root. Defaults to v2 (`release-selection-v2.json`); pass
`--selection papers/one-bit/release-selection.json` to inspect frozen v1 records.
Fixed research sources are read with `git show` from Homework; nothing is built.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys

PAPER = Path(__file__).resolve().parents[1]
TEXTS = {'zh': PAPER / 'manuscript.md', 'en': PAPER / 'manuscript-en.md'}
META = re.compile(r'写作时|本轮|提示词|子代理|工作窗口|新窗口|agent|prompt|this draft|not rebuilt', re.I)
FULLWIDTH_EN = re.compile(r'[｜：；，。（）　]')
DECL = r'\b(?:theorem|def|lemma|abbrev|structure|inductive|instance|class)\s+(?:[\w.]*\.)?{}\b'
ENV_ZH = re.compile(r'(?m)^\*\*(主定理|定理|命题|引理|推论|定义|例)\s+(\d+(?:\.\d+|[A-Z]\.\d+)|[A-Z]\.\d+)')
ENV_EN = re.compile(r'(?m)^\*\*(Main Theorem|Theorem|Proposition|Lemma|Corollary|Definition|Example)\s+(\d+(?:\.\d+|[A-Z]\.\d+)|[A-Z]\.\d+)')


def anchors(text):
    return set(re.findall(r'<a id="([^"]+)"></a>', text))


def body(text):
    """Prose between the first section and the code-availability block."""
    start = text.index('## 1')
    return text[start:text.index('<!-- code-availability:begin -->')]


def blob(repo, commit, path):
    return subprocess.run(
        ['git', '-C', str(repo), 'show', f'{commit}:{path}'],
        check=True,
        capture_output=True,
    ).stdout


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--homework', type=Path, default=PAPER.parents[2] / 'Homework' if (PAPER.parents[2] / 'Homework').exists() else PAPER.parents[3] / 'Homework')
    ap.add_argument('--h0', type=Path, default=PAPER.parents[2] / 'H0mework' if (PAPER.parents[2] / 'H0mework').exists() else PAPER.parents[3] / 'H0mework')
    ap.add_argument('--selection', type=Path, default=PAPER / 'release-selection-v2.json')
    args = ap.parse_args()
    texts = {k: p.read_text() for k, p in TEXTS.items()}
    errors, report = [], {}

    # 1. Bilingual parity of anchors, equation tags, figures, citations, and display blocks
    for name, rx in [
        ('anchors', r'<a id="([^"]+)"></a>'),
        ('tags', r'\\tag\{([^}]+)\}'),
        ('figures', r'\]\((figures/[^)]+?)(?:-en)?\.svg\)'),
        ('citations', r'\[\[(\d+)\]\]\(#ref-\d+\)'),
    ]:
        sets = {k: sorted(set(re.findall(rx, t))) for k, t in texts.items()}
        report[name] = len(sets['zh'])
        if sets['zh'] != sets['en']:
            errors.append(f'{name} differ: zh-only {set(sets["zh"]) - set(sets["en"])}, en-only {set(sets["en"]) - set(sets["zh"])}')

    zh_envs = [(m.group(1), m.group(2)) for m in ENV_ZH.finditer(texts['zh'])]
    en_envs = [(m.group(1), m.group(2)) for m in ENV_EN.finditer(texts['en'])]
    report['numbered_environments'] = len(zh_envs)
    if [n for _, n in zh_envs] != [n for _, n in en_envs]:
        errors.append(f'environment numbers differ: zh {[n for _, n in zh_envs]} vs en {[n for _, n in en_envs]}')

    zh_disp = len(re.findall(r'\$\$', texts['zh']))
    en_disp = len(re.findall(r'\$\$', texts['en']))
    report['display_delimiters'] = {'zh': zh_disp, 'en': en_disp}
    if zh_disp % 2 != 0 or en_disp % 2 != 0 or zh_disp != en_disp:
        errors.append(f'display $$ delimiters mismatch: zh={zh_disp}, en={en_disp}')

    # 2. Figure existence, citation completeness, meta-wording & English punctuation hygiene
    for lang, t in texts.items():
        for fig in re.findall(r'\]\((figures/[^)]+\.svg)\)', t):
            if not (PAPER / fig).exists():
                errors.append(f'{lang}: missing figure {fig}')
            if (lang == 'en') != fig.endswith('-en.svg'):
                errors.append(f'{lang}: figure language mismatch {fig}')
        cited = set(re.findall(r'#ref-(\d+)', t))
        listed = set(re.findall(r'<a id="ref-(\d+)"></a>', t))
        if cited != listed:
            errors.append(f'{lang}: cited {sorted(cited)} vs listed {sorted(listed)}')
        for m in META.finditer(body(t)):
            errors.append(f'{lang}: meta wording "{m.group(0)}"')
        for m in re.finditer(r'`([^`]+)`', t):
            bad = sorted({c for c in m.group(1) if ord(c) > 127})
            if bad:
                errors.append(f'{lang}: non-ASCII inline code {m.group(0)!r}: {bad}')

    en_non_byline = '\n'.join(l for l in texts['en'].splitlines() if not l.startswith('**Author:'))
    fw = FULLWIDTH_EN.findall(en_non_byline)
    if fw:
        errors.append(f'en: full-width punctuation found: {sorted(set(fw))}')

    # 3. Written locations and source declarations of every claim
    selection = json.loads(args.selection.read_text())
    binding = selection['h0_binding']
    checked_sources = 0
    checked_h0_targets = 0
    for claim in selection['claims']:
        for lang, locs in claim['written'].items():
            for loc in locs:
                file, _, anchor = loc.partition('#')
                if anchor not in anchors((PAPER / file).read_text()):
                    errors.append(f'{claim["id"]}: missing anchor {loc}')
        for src in claim['sources']:
            data = blob(args.homework, src['commit'], src['path'])
            digest = hashlib.sha256(data).hexdigest()
            if 'sha256' in src and src['sha256'] != digest:
                errors.append(f'{claim["id"]}: sha mismatch {src["path"]}')
            text = data.decode()
            for decl in src['declarations']:
                if not re.search(DECL.format(re.escape(decl.split('.')[-1])), text):
                    errors.append(f'{claim["id"]}: declaration {decl} not declared in {src["path"]}')
            if args.h0.exists():
                for tgt in src.get('h0_exact_targets', []):
                    mod_path = 'Lean/' + tgt['module'].replace('.', '/') + '.lean'
                    h0_data = blob(args.h0, tgt.get('commit', binding['one_bit_commit']), mod_path)
                    if hashlib.sha256(h0_data).hexdigest() != tgt['sha256']:
                        errors.append(f'{claim["id"]}: H0 target sha mismatch {mod_path}')
                    checked_h0_targets += 1
            checked_sources += 1

    if args.h0.exists():
        for rec in binding['one_bit_records']:
            data = blob(args.h0, binding['one_bit_commit'], rec['path'])
            if hashlib.sha256(data).hexdigest() != rec['sha256']:
                errors.append(f'H0 record mismatch {rec["path"]}')
        report['h0_records_checked'] = len(binding['one_bit_records'])
        if v2 := binding.get('one_bit_v2'):
            fixed_map = json.loads(blob(args.h0, v2['commit'], v2['map']['path']))
            acceptance = fixed_map['acceptance']
            if (acceptance['status'] != 'passed'
                    or acceptance['declarations'] != v2['verified_declarations']
                    or acceptance['selection_sha256'] != v2['selection']['sha256']
                    or any(ref != acceptance.get(kind) for kind, ref in v2['acceptance'].items())):
                errors.append('H0 second-edition acceptance differs from the fixed proof map')
            refs = [v2[k] for k in ('map', 'selection', 'reproduction')]
            refs.extend(v2['acceptance'].values())
            for claim in selection['claims']:
                refs.extend(claim.get('original_certification', []))
            for ref in refs:
                if hashlib.sha256(blob(args.h0, v2['commit'], ref['path'])).hexdigest() != ref['sha256']:
                    errors.append(f'H0 v2 record mismatch {ref["path"]}')
            report['h0_v2_records_checked'] = len(refs)
    report['selection'] = args.selection.name
    report['claims'] = len(selection['claims'])
    report['source_files_checked'] = checked_sources
    report['h0_exact_targets_checked'] = checked_h0_targets
    report['errors'] = errors
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(1 if errors else 0)


if __name__ == '__main__':
    main()
