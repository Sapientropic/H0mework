#!/usr/bin/env python3
"""Package the One Bit paper's v2 editable inputs in the shared builder's layout."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
OUTPUT = PAPER / 'build' / 'reading-review-v2'
TEXTS = ('manuscript.md', 'manuscript-en.md')
SHARED = (
    'shared/scripts/build_pdf.py', 'shared/scripts/byline.py',
    'shared/styles/article-header.tex', 'shared/styles/article-header-en.tex',
    'shared/styles/article-filter.lua', 'shared/figure-style/house_style.py',
    'shared/figure-style/svg_text.py',
)
PRIVATE_PATH = re.compile(rb"(?<![\w/])/(?:Users|Volumes|home|(?:private/)?tmp|var/folders)/|file:[/]{2}|[A-Za-z]:\\(?:Users|Documents)\\", re.I)


def package(output_dir: Path | None = None):
    target_dir = output_dir.resolve() if output_dir else OUTPUT
    build_path = target_dir.relative_to(ROOT).as_posix()
    inputs = {ROOT / p for p in SHARED}
    inputs.update(PAPER / p for p in (
        *TEXTS, 'references-v2.bib', 'literature.md', 'reproduction.md',
        'release-selection-v2.json', 'metadata-v2.json',
    ))
    inputs.update((PAPER / 'scripts').glob('*.py'))
    for pattern in ('*-v2*.svg', '*-v2*.png', 'render_v2.py', 'README.md'):
        inputs.update((PAPER / 'figures').glob(pattern))
    payload, records = {}, []
    for path in sorted(inputs):
        data = path.read_bytes()
        if path.suffix != '.png' and PRIVATE_PATH.search(data):
            raise ValueError(f'Personal path in publication input: {path.name}')
        rel = path.relative_to(ROOT).as_posix()
        payload[rel] = data
        records.append({'path': rel, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    selection = json.loads((PAPER / 'release-selection-v2.json').read_text())
    binding = selection['h0_binding']
    metadata = json.loads((PAPER / 'metadata-v2.json').read_text())
    guide = f"""# Ontological Rigidity and Universal Single-Mother Formation · editable v2

The bilingual v2 manuscripts (each with Appendices A-E), eight editable v2 vector
figures, PNG previews, the v2 figure generator, bibliography, metadata, and the
OB1-OB13 selection preserve the directory layout required by the shared builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome, and Noto Serif/Sans CJK SC. Build both PDFs:

    python3 shared/scripts/build_pdf.py papers/one-bit/manuscript.md papers/one-bit/manuscript-en.md --output-dir {build_path}

With fontTools, Google Chrome, and pdftoppm installed, regenerate the v2 figures:

    python3 papers/one-bit/figures/render_v2.py
    python3 papers/one-bit/figures/render_v2.py --english

The second-edition proof map and reproduction guide are available at H0mework
commit {binding['one_bit_v2']['commit']}. The selection records their paths,
the original CP483 and CP485 certifications, and the accepted OB2, OB12 and
OB13 build, dependency audit and declaration types. The accepted OB1-OB11
proofs are located through H0mework commit {binding['one_bit_commit']}.
The first-edition preprint has DOI {metadata['previous_doi']}.
Paper text and original figures use CC BY 4.0. Code uses Apache-2.0.
"""
    payload['README-editable.md'] = guide.encode()
    payload['editable-inputs.json'] = (json.dumps({
        'schema': 'one-bit-editable-inputs/v2', 'paper': 'one-bit', 'version': selection['version'],
        'files': records, 'private_prompts_or_research_repositories_included': False,
    }, ensure_ascii=False, indent=2) + '\n').encode()
    target_dir.mkdir(parents=True, exist_ok=True)
    archive = target_dir / 'one-bit-v2-editable.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path, data in sorted(payload.items()):
            info = zipfile.ZipInfo(path, date_time=(*map(int, selection['date'].split('-')), 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(archive) as z:
        if set(z.namelist()) != set(payload) or z.testzip() is not None:
            raise ValueError('Archive contents or integrity mismatch')
        if any(z.read(path) != data for path, data in payload.items()):
            raise ValueError('Archive payload byte mismatch')
    return {
        'archive': archive.relative_to(ROOT).as_posix(),
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'bytes': archive.stat().st_size,
        'file_count': len(payload),
        'payload_bytes_match': True,
        'zip_integrity': 'pass',
        'input_files': records,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, help='Directory for the packaged artifact')
    result = package(parser.parse_args().output_dir)
    print(json.dumps({k: v for k, v in result.items() if k != 'input_files'}, ensure_ascii=False))
