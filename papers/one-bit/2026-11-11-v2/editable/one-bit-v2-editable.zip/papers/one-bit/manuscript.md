# 现实刚性与单母源普遍形成：无账外差异的零公理构造、因果准入与统一演化

*Ontological Rigidity and Universal Single-Mother Formation: Axiom-Free Exclusion of Unaccounted Differences, Causal Admission, and Unified Evolution*

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**形式验证与版本说明。** 本文的形式证明在 Lean 4 定理证明器[[9]](#ref-9)（具可信小内核与可导出参考检查器，见其 §5）中完成核验；本稿自身的审计回执与自动检查脚本确立了严格分离的两层公理闭包：管辖单构造子发生展开、根读恒等、合法世界准入、正向全实在性、观察商安全与范畴初始余面修订的通用权威层为**零公理构造性内核**（T0，`#print axioms = []`，不调用排中律、选择公理或商健全性）；承载固定物理母源 $S_\star$ 逐点一致完备化、连续—量子统一场消费及长窗口分析续行的实例层，其完整依赖闭包严格限于标准三公理（T1：命题外延性 `propext`、经典选择 `Classical.choice` 与商健全性 `Quot.sound`），不反向污染 T0 内核，全程无未完成证明占位（`sorry`）或非安全声明。正向核验链与编译期越权拦截反控（`fail_if_success`、`#guard_msgs`）均按预登记合同通过。本文为第一版预印本（原发表题名 *1 Bit Is All You Need*，DOI: [10.5281/zenodo.23437456](https://doi.org/10.5281/zenodo.23437456)；旧题名向 Vaswani 等[[5]](#ref-5)致意，正文不对神经网络架构或统计标度律作任何外推）的第二版（v2）重构定稿，完整纳入根读恒等母律、跨修订活过程全实在性、单根权威编译期防火墙及已付语法树同态与余链微分续行（OB12–OB13）。

## 摘要

一笔改变可观测后果或世界身份的真实差异，能否不交代任何结构来历就取得现实资格？本文在零公理构造性内核（T0，`#print axioms = []`）与标准三公理完备化层（T1）中给出否定证明，并将该二值准入判准兑现为四项相互咬合的基础定理。第一，在仅含弱差异五谓词、不预设任何“无魔法”禁令字段的 T0 内核中，单构造子发生树确立根读恒等 $\mathsf{RootRead}(o)=o$；任意源生权威根上的不同合法世界状态，以及任意跨局部终账与理论修订交接的完整活过程状态，均由单射登记的发生或完整活当前取得正向结构身份，由此无循环地纯构造导出外部补写与魔法比特恒空，并由单根权威编译期防火墙封死八类旁路神谕与越权激活。第二，在 T1 层，由原始事件结构内生生成的同一固定二态自旋对母源 $S_\star$，经有限程序求值像的逐点一致完备化，在不向准入接口添加任何可表示性前提下，普遍形成最低类型宇宙（`Type 0`）接口上跨**全体**关系网络、词汇与权威根的每一个合法世界状态、每一个完整询问与每一个询问引擎宏过程，经左逆限制逐项恢复发生、整账、编译、激活法则与任意有限深度运行历史（故在该接口上无需独立第二基源），并由 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 连续—量子统一场在同一发生上直接核验。

第三，在每个自然数共尾准入停点上，全未来模型中的字面残差在全部有限允许作用词与全部站位上同已付边界等价，内生转化为下一原生请求，并以自身语法信用对同一债务谱系执行严格扣款与零回填结算，在后缀完成时一并交付效应值、带回执回答、整账去向与规范后继；进而，双负号提取算子从残差语法完整恢复已付语法树（paid AST），在后续共尾输入上持续执行预定加法同态方法并将完整查询迹写入出生库存，而整词逐原语步进回放则将每步发生转化为库存中的显式整系数代数关系，同步更新链复形态射、余链微分 $d^{0,1}$ 与余像微分，并在条件解析长窗口计算中保持四份历史执行迹的跨帧纠正续行。第四，当既有法则在某根植发生处遭遇表达与合法实现双空破产时，阻滞自身在零公理下生成范畴初始余面 $L_+\sqcup\{\star_\eta\}$ 及唯一忠实单射分解，使迁入旧债行与新增零预算方向行经同一次非终账首写并列受领处置。全文最终将一切质疑收束到结构恢复、同债续行与领域解释三层可机械检验的等式门禁上。

**关键词：** 现实刚性；无账外差异；零公理内核；根读恒等；单母源普遍形成；同债语法付款；已付语法树微分续行；范畴初始余面

## Abstract

Can a real difference that alters world identity or observable outcomes acquire actual standing without any registered structural provenance? Working across a zero-axiom constructive kernel (T0, `#print axioms = []`) and a standard three-axiom analytic completion layer (T1), we prove the answer is no and cash out this binary admissibility criterion in four interlocking foundational theorems. First, inside a T0 kernel whose weak five-predicate difference vocabulary contains no preset “no-magic” axiom field, a single-constructor occurrence tree establishes the root-read identity $\mathsf{RootRead}(o)=o$; distinct lawful world states of any source-native authoritative root, as well as distinct states of any complete living process crossing local terminals and theory revisions, acquire positive structural identity from injective registered occurrences or complete living currents, constructively excluding external supplements and magic bits without circularity while a compile-time single-root firewall blocks eight classes of bypass oracles. Second, at layer T1, pointwise uniform completion of the finite-programme evaluation image of one primitive-event-generated spin-pair mother source $S_\star$ universally forms—with zero added representability premises—every lawful world state across all relation networks, vocabularies, and authority roots, every complete inquiry, and every macro-process on the `Type 0` interface, recovering occurrences, whole-ledger writes, compilations, and arbitrary-depth histories by left-inverse restriction (eliminating any independent second base source on that interface) and directly instantiating the $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ continuous–quantum unified field.

Third, at every natural-number cofinal admission stop, the literal syntactic residual equals the paid boundary across all finite allowed action words and sites, generates the next endogenous request, and executes strict Noetherian syntax debit without budget refill along the unique debt lineage before delivering the effect value, receipted answer, whole-ledger destinations, and canonical successor; moreover, double-negation extraction recovers the complete paid abstract syntax tree (paid AST) to execute any pre-fixed additive homomorphism across subsequent cofinal stops with full query traces recorded in born stock, while primitive-by-primitive word replay turns each evaluation step into explicit integral stock relations driving chain morphisms, the cochain differential $d^{0,1}$, and coimage differentials in lockstep (and carrying four prior execution traces across conditional long analytic windows). Fourth, whenever an existing law suffers rooted double emptiness of expression and realization fibres, the obstruction itself generates in zero axioms a categorical initial coface $L_+\sqcup\{\star_\eta\}$ with unique faithful injective factorization, routing migrated prior debts and the new zero-budget direction through one shared nonterminal first write. Every claim ultimately terminates in three layers of mechanically checkable equalities governing structural recovery, paid continuation, and domain interpretation.

**Keywords:** ontological rigidity; no unaccounted difference; zero-axiom kernel; root-read identity; universal single-mother formation; same-debt syntax payment; paid-AST homological continuation; categorical initial coface

---

## 1　引言：无账外差异的本体论刚性与单母源总纲

任何企图闭合自身基础的科学或形式理论，迟早都要面对同一道悬崖：**若允许一枚真实差异不交代任何内部发生来历就进入世界，理论还有什么资格拒绝下一次任意补写？** 在基础物理中，这种未登记的补写表现为事后迎合实验拨动的自由耦合旋钮、外置嫁接的坍缩开关，或为安放新现象临时另开的底层源[[7]](#ref-7)；在计算与账本系统中，它表现为绕过执行历史直接覆盖状态的神谕赋值，或借修改语言名目一笔勾销未清旧债[[6]](#ref-6)[[8]](#ref-8)。反过来，倘若人们只是在公理表顶端外加一条“禁止账外差异（无魔法）”的禁令，这一原则又极易沦为同义反复或事后免责口号：凡解释得了的便称内部生成，解释不了的便临时宣布“那也算某种原语”。

近四十年的现代形式科学分别从四条路线触及这一问题的不同侧面：(i) 在类型论与资源逻辑中，Martin-Löf 直觉主义类型论[[10]](#ref-10)给出了携带见证的 $\Sigma$ 依赖对投影（其 1984 讲义第 32 页采用相等反射规则），同伦类型论的单值公理[[11]](#ref-11)（公理 2.10.3）刻画同一宇宙内的类型等价与类型相等 $(A=_{\mathcal U} B)\simeq(A\simeq B)$，线性逻辑[[12]](#ref-12)以指数算子控制带标记公式的复制与舍弃，摊销资源分离逻辑[[13]](#ref-13)则以可经线性规划推断的信用断言与可失败的环境资源请求指令 `acquire`（§3.6）验证程序消耗；(ii) 在物理基础与规格精化中，量子论的信息重构[[14]](#ref-14)采用一般操作概率框架并由五条信息公理加纯化公设导出量子力学，信息构造子理论[[15]](#ref-15)以底物上任务的可能／不可能与互操作性原理（原理 III）表述定律，而状态精化映射完备性定理[[16]](#ref-16)在满足条件时通过向低层规范增补历史变量与预言变量（投影回原变量保持相同可见行为）来构造精化映射；(iii) 在数据溯源与增量计算中，溯源半环[[17]](#ref-17)通过多项式半环同态分解正关系查询求值，高阶语言静态微分[[18]](#ref-18)（定理 3.11）与 DBSP 流演算[[19]](#ref-19)（§4.1 $\mathbb Z$-集、定理 3.4 双线性公式）建立了精确的有限差分增量更新，但未将未付残差直接化为自付语法费的原生请求与逐步余链微分；(iv) 在理论变化逻辑中，经典的 AGM 框架[[20]](#ref-20)在固定语言内以部分交收缩 $K\dot{-}p=\bigcap\gamma(K\bot p)$ 去掉对指定命题的蕴含，并在面对冲突输入修订时经 Levi 恒等式先收缩 $\neg p$ 再并入 $p$ 以恢复一致，尚未处理旧语言表达与实现双空破产时的零公理升维与历史未清责任保全。

本文正面贯通这四道接缝。核心突破在于：**不把“无魔法”预设为任何公理、模态原语或结构体字段，而是在零公理构造性内核（T0）中仅凭合法状态的发生准入与弱差异正向分类，非循环地证出外部补写与魔法比特恒空；继而在标准分析层（T1）证明，由原始事件内生生成的单一固定母源 $S_\star$ 无需向目标接口增补表示性前提或规范辅助变量，即普遍形成原准入接口上的全部合法世界、完整询问与演化宏过程，并让残差请求、同债付款、已付语法树微分续行与零公理破产升维修订全部落回可机械检验的精确等式。**

<a id="sec-1-1"></a>
### 1.1　二值准入问句、反魔法非循环导出与四柱主定理

第一版题署中的“一比特（1 bit）”在本体系中有且仅有一项精确技术含义（**OB1**）：它指代一个二值资格问句——**一笔改变世界身份或下游可观测读数的实际差异，能否在不具备任何已登记结构来历的前提下取得合法现实资格？** 本文对所列全部源生结构证明该问句的取值为“否”（即命题层结构 $\mathsf{MagicBitAt}$ 恒为空类型）。这一二值印记既不表示把宇宙状态压缩编码进一个二进制位（恒取定值的确定性变量其 Shannon 信息熵严格为零[[3]](#ref-3)），也不声称在任意外部裸类型上存在停机布尔判定器；它的全部数学锋利度来自以下四根正向构造主梁。

<a id="thm-1-1"></a>
**主定理 1.1（现实刚性与单母源普遍形成四柱总定理）。**

1. **零公理正向整现实、根读恒等与发生身份（T0，`#print axioms = []`；§2–§3，OB1–OB5）。** 单构造子发生树确立根读恒等母律 $\mathsf{RootRead}(o)=o$：已登记发生的先前补片迹、当前补片与整账写回即该发生自身的结构形状。对任意关系网络 $N$、词汇 $V$ 与源生权威根 $R$，$R$ 上任意两个不等合法世界状态（含有限访问、共尾落点访问与共尾后继）必具不等的登记发生 $\mathsf{occ}(w)\neq\mathsf{occ}(w')$；对任意完整活源过程 $\mathcal P$，任意两个不等过程状态（含跨局部忠实终账与理论修订交接边界）必具不等的完整活当前 $\iota(s)\neq\iota(s')$。两者无需任何 `NoMagic` 输入字段即正向实现全实在性 $\mathsf{Total}(\mathcal R)$，纯构造推出外部补写与魔法比特恒空（定理 2.5、2.6、2.8），同时严格区分“过去与当前发生刚性”（定理 3.1）、“局部观察不可见核”（定理 3.3）与“按需生成而未预存的未来”。
2. **固定二态母源 $S_\star$ 的三域普遍形成与无第二基源完备性（T1；§4，OB6–OB7）。** 固定由原始事件结构内生生成的物理自旋对母源 $S_\star$。在最低类型宇宙（`Type 0`）原准入接口上，不附加任何可表示性或地址覆盖假设，$S_\star$ 有限程序求值像的逐点一致完备化同时普遍形成：(i) **任意** $N,V,R$ 上的**任意**合法世界状态 $w\in\mathsf{Law}(R)$；(ii) **任意** $N,V$ 上的**任意**完整询问 $q$；(iii) **任意**原生询问引擎宏过程 $P$；并由同一见证经左逆限制逐项恢复发生、整账写回、查询编译、激活法则及任意自然数深度 $n\in\mathbb N$ 的运行历史（定理 4.2）。由于权威根 $R$ 被全称量化，原接口上不存在独立于 $S_\star$ 的第二份底层基源。连续—量子统一场直接调用该形成总定理，在同一 `SpinPair` 发生上实现九场经典解、$4\sqrt2$ 有限 $\hbar$ 精确配对与宏步后继（推论 4.3、定理 4.4）。
3. **内生残差请求、同债良基付款与已付程序微分续行（§5、§7，OB8、OB10、OB12–OB13）。** 对任意源配置族 $\mathcal F$、初始帧 $I$ 与程序 $\mathsf{cfg}$，在运行自产的每个自然数共尾准入停点上，字面残差 $r_m=a+(-\mathrm{id})(p)$ 与已付边界 $[a]-[p]$ 在全部有限允许作用词与全部站位上属于同一全未来等价类，并内生转化为下一原生请求；其语法信用 $Q=c(r_m)\ge2$ 对同一债务谱系执行严格扣款且绝不回填预算，经 $Q-1$ 步后缀结算一并交付效应值 $\epsilon=D_a(\Gamma,\delta)$、带回执回答、旧／出生行整账去向与规范后继（定理 5.1–5.3）。进而，双负号提取从残差语法完整恢复已付语法树，在后续共尾包持续执行任意预定加法同态 $f$ 并把完整查询迹写入出生库存、安装代数、组合、拓扑与逻辑统一四面（并同源携带关系与余链切面，定理 5.4）；整词逐原语步进回放将每步求值转化为库存整系数关系，同步更新链态射 $\tau_1$、余链微分 $d^{0,1}$、余像微分与同停点物理读回（定理 5.5），并在条件解析长窗口中跨帧保全四份执行迹（§7，定理 E.1）。
4. **阻滞生成的零公理范畴初始余面与双行同首写带债修订（T0，`#print axioms = []`；§6，OB9）。** 当既有法则 $\Theta$ 在某根植发生处遭遇表达纤维与合法实现纤维双空破产时，该失败 $\eta$ 在零公理下自动生成坐标扩充 $C_\eta=L_+\sqcup\{\star_\eta\}$，完整保留旧面定理并对全体容许修订满足严格范畴初始性与唯一忠实单射分解（定理 6.2）；任意由固定询问发射且经结构锚定的有类型修订 $\Xi$，同样在零公理内核中将迁入旧故障行与新增零预算方向行送入同一次非终账首写，由新根分类器分别交付回答与后继并共享同一规范下一当前（定理 6.4–6.5）。

表 1 汇总四根主梁的公理层级、核心正向能力以及各自配对的正反控制门禁；图 1 展示它们如何从同一单构造子根内核与母源 $S_\star$ 分立生长并在下游汇合。

**表 1　两层公理地基与四柱正向定理—反向控制配对总览。**

| 承重主梁 | 公理层 | 核心正向定理与生成能力 | 配对反例／编译期负控门禁 | 正文与证明 |
| --- | --- | --- | --- | --- |
| **I. 整现实与根身份** | T0 `[]` | $\mathsf{RootRead}(o)=o$；单根与跨修订活过程全实在性正向导出无魔法比特；观察商安全判据 | 裸二元组幽灵位反例；8 类越权路径 `#guard_msgs` 防火墙；整算术挠类有限复观察全盲反例 | §2–§3；附录 A |
| **II. 单母源三域形成** | T1 标准三公理 | 单一母源 $S_\star$ 完备化对 $\forall N,V,R$ 普遍形成世界、询问与宏过程并左逆恢复全历史 | 5 项核验链禁绕低层引理审计；省去旋量翻转 $S$ 致暗时刻电流由 $+1/2$ 跌至 $-1/2$ 反例 | §4；附录 B |
| **III. 同债与微分续行** | T0/T1 | 全未来残差生出请求并严格扣款；双负号恢复已付 AST 续行同态 $f$；逐原语回放更新 $d^{0,1}$ | 零数值效应 $\epsilon=0$ 仍须支付 2 步语法费；端点同值不可冒充逐步回放迹相等 | §5、§7；附录 C、E |
| **IV. 初始余面修订** | T0 `[]` | 根植双空破产生成范畴初始余面 $L_+\sqcup\{\star_\eta\}$ 与唯一单射分解；旧债与新行共用首写 | 恢复接口封死“事后补交故障行”；错误等式无障碍事件，禁止改名逃入修订通道 | §6、§8；附录 C.5 |

![图 1｜单根发生与四柱普遍形成森林](figures/one-bit-forest-v2.svg)

**图 1｜单根发生与四柱普遍形成森林。** 左端朱红椭圆仅标示入口处的二值资格问句（账外差异能否获准进入合法世界）。真正承担构造重量的是深蓝色的单构造子发生内核（$\mathsf{RootRead}(o)=o$、时序访问发生 $\mathsf{occ}(w)$ 与 T0 单根编译期防火墙）及内生自旋对母源 $S_\star$。四条主支分别由各自的正向构造独立支付：零公理正向分类导出单根与活过程全实在性（OB1–OB5）；$S_\star$ 有限程序像完备化普遍形成世界、询问与宏过程三域（OB6）；全未来残差驱动同债严格扣款、已付 AST 同态方法 $f$ 与逐原语余链微分 $d^{0,1}$ 更新（OB8, OB12–OB13）；根植双空破产在零公理下生成初始余面并令旧债与新行共用首写（OB9）。右列连续—量子统一场（OB7）与长窗口接力（OB10）作为下游核验链直接调用对应主支，不反向充当其前提。

<a id="sec-1-2"></a>
### 1.2　三分钟纸笔锚点：幽灵位投影、非零平方账与两拍带债升维

在展开一般依赖类型构造之前，读者只需用纸笔花三分钟核对以下三个极小算例。它们不含任何黑箱记号，却分别浓缩了全文第 2、5、6 节的精确机制。

<a id="ex-1-2"></a>
**例 1.2（三分钟手算验核）。**

**(a) 多一位裸布尔值，为何不能免费多造一个合法世界（§2.2）。** 设权威根 $R_\circ$ 的初始访问给出合法世界态 $w_1=\mathrm{finite}(v_1)$，沿编译器后继推进一步给出 $w_2=\mathrm{finite}(v_2)$。在裸乘积载体 $G=\mathsf{Law}(R_\circ)\times\mathrm{Bool}$ 上取 $g_0=(w_1,\mathrm{false})$ 与 $g_1=(w_1,\mathrm{true})$。取第二投影立见 $g_0\neq g_1$；但合法世界准入只接收第一投影 $\mathrm{pr}_1:G\to\mathsf{Law}(R_\circ)$，故
$$\mathrm{pr}_1(g_0)=w_1=\mathrm{pr}_1(g_1),\qquad \mathsf{occ}(\mathrm{pr}_1(g_0))=\langle w_1,\varepsilon_{R_\circ}(w_1)\rangle=\mathsf{occ}(\mathrm{pr}_1(g_1)).$$
反之，$w_1$ 与 $w_2$ 的可达历史分别由初始构造子与一步推进构造子生成，故 $w_1\neq w_2$，对依赖对 $\mathsf{occ}(w)=\langle w,\varepsilon(w)\rangle$ 取第一投影立得 $\mathsf{occ}(w_1)\neq\mathsf{occ}(w_2)$。裸数据不等与准入后世界同一两件事同时为真；被拦截的是把未登记布尔位直接升格为新世界的那一步越权。

**(b) 一笔非零平方账如何付清旧债，并把已付结果送入下一步方法（§5.1–§5.4）。** 在实数或整环载体上取非线性表达式 $a=x\cdot x$，旧环境 $\Gamma(x)=2$，环境增量 $\delta(x)=2$（新环境 $x=4$）。旧运行已付至常量端点 $p=\mathrm{const}\,4$。下一原生请求定义为字面残差 $r=a+(-\mathrm{id})(p)$：
$$\mathrm{ev}_{\Gamma+\delta}(r)=4^2-4=12,\qquad D_a(\Gamma,\delta)=2\cdot2\cdot2+2^2=12.$$
按节点计语法费用（变量 1、常量 0、一元负号 $+1$、双加法 $+1$）：$c(a)=1+1+1=3$，$c(p)=0$，故请求总预算为 $Q=c(r)=3+0+2=5$。出生首步耗费 1 拍后剩余预算 $Q-1=4>0$，迫使下一步必走严格扣减的已付分支（$4\to3$），再经后缀推进抵达预算 $0$ 交付效应值 $12$。更进一步，在结算后的两层残差语法中，提取算子 `retainedCode` 对已付常量端点取双负号 $-(-\mathrm{const}\,12)$，在零环境增量下精确读回已付值 $12$，随即在下一共尾停点交由任意预定加法同态（如 $f(u)=3u$）算出 $(36,0)$，同时把 $x\cdot x$ 的三步原语求值链 $[x\cdot x]\to[4\cdot x]\to[4\cdot 4]\to[16]$ 写为库存关系边界 $[x\cdot x]-[16]$。

**(c) 旧语言破产时，两拍修订如何扩充维度而不抹销旧债（§6.2）。** 设旧世界支撑集为 $\{\mathrm{false},\mathrm{true}\}$，每点各背负一笔预算为 $2$ 的开放责任，而旧理论在 $\mathrm{true}$ 处表达与实现双空。首拍触发修订：最小余面零公理并入无旧原像的新点 $\star_\eta$（初始预算设为 $0$），账面成为“迁入旧行预算 $2$、新方向行预算 $0$”。新根以自然数为当前态、$n\mapsto n+1$ 为原生写入：首写 $0\to1$ 在同一动作中将两行（$2\to2$ 与 $0\to0$ 保预算转移）一并送达首写目标访问 $1$，新根编译器在该目标访问处分别裁决两行并按 $n\mapsto n+1$ 给出共同下一当前 $2$；第二拍在当前态 $2$ 直接给出单点回答并推进至 $3$。理论语言成功升维，而预算为 $2$ 的历史旧债分毫无损地越过接缝。

<a id="sec-1-3"></a>
### 1.3　按学科背景的 15 分钟快速验证通道与基础记号

本文连接数理逻辑与类型论、基础物理统一、程序语义与同调代数以及科学哲学四个方向。完成例 1.2 的三分钟验算后，不同领域的读者可按各自关切直接切入对应自足通道：

- **数理逻辑、依赖类型论与形式化验证方向**：直接读 **§2、§3.1、§6.1 与附录 A**，核验 T0 零公理内核（`#print axioms = []`）如何用单构造子归纳树建立 $\mathsf{RootRead}(o)=o$、在不引入排中律或 `NoMagic` 公理字段的前提下纯构造推出 `noMagicBit`、以 `#guard_msgs` 编译期防火墙封锁八类越权入口，并在零公理下证出根植破产最小余面的范畴初始性与唯一态射分解。
- **理论物理与连续—量子统一基础方向**：直接读 **§4、§3.2 与附录 B**，核验原始事件内生生成的固定 `SpinPair` 母源 $S_\star$ 如何经逐点一致完备化在 `Type 0` 接口上对 $\forall N,V,R$ 普遍形成全部合法世界、询问与宏过程（从而排除独立第二基源），以及统一场实现如何在同一发生上恢复九场经典解、$4\sqrt2$ 配对等式与暗时刻旋量翻转负控。
- **编程语言语义、增量计算与同调代数方向**：直接读 **§5、§7 与附录 C、E**，核验全环境零子模 $Z$ 在配对提升下的不变性、Noether 严格语法扣款与零回填律、`retainedCode` 双负号恢复已付 AST 驱动跨共尾同态方法持续作用（OB12），以及 `WordExecution` 逐原语步进回放同步驱动库存边界、$\tau_1$ 与余链微分 $d^{0,1}$（OB13）。
- **科学哲学、形而上学与方法论方向**：直接读 **§1.1、§2.3–§2.5、§3 与 §8**，核验“差异必有已登记发生来历”如何在无神学预设下构造性兑现充分理由关切，“昨天刚性、局部不可见不等于未发生、明天是待生成责任而非预存库存”如何切开决定论迷思，以及三层失败责任定位律如何使体系具备精确到等号的机械可反驳性。

自 §2.4 与 §4 起，正文反复使用三项标准依赖类型操作，在此一次性固定记号：**类型运输（transport）**指沿一条类型等式 $A=B$ 将 $A$ 中元素正则搬运至 $B$；**异质相等（heterogeneous equality，记作 $x\doteq y$）**指分处不同依赖纤维的 $x\in A$ 与 $y\in B$ 满足 $A=B$ 且经该等式运输后相等；**依赖直和（dependent direct sum / $\Sigma$ 类型与有限支集直和）**指每个站位 $j$ 各自携带载体 $M_j$ 并合成为整体，其中典范嵌入记作 $\iota_j$，依赖对记作 $\langle u, e\rangle$，第一投影记作 $\mathrm{pr}_1$（或后缀 `.1`）。

---

## 2　零公理整现实内核、根读恒等与单根权威防火墙

本节全部构造与证明均在**零公理内核（T0，`#print axioms = []`）**中完成。论证顺序严格遵循“准入先行，导出在后”：我们先展示单构造子发生树与根读恒等母律 $\mathsf{RootRead}(o)=o$，将合法世界状态定义为源生权威根的时序可达访问，使“从登记发生恢复世界状态”化为一步第一投影；随后给出裸二元组幽灵位反例与编译期单根权威防火墙；最后在不提及任何“无魔法”字样的弱差异词表中，纯构造地证出单根与跨修订活过程的全实在性。

### 2.1　单构造子发生展开、根读恒等与合法世界状态准入

为什么许多形式系统不得不靠外挂“审计证书”来事后追认状态合法性？根源在于它们把“状态演化”与“历史记账”拆成了两套平行数据结构。在本文的 T0 底层（`LivingLawRootedAccountedUnfoldingKernel`）中，一次实际发生被归约为**唯一构造子**生成的有限根植展开树：
$$\mathsf{RootedAccountedUnfolding}(\mathcal X)\;::=\;\mathsf{occur}\bigl(r:\mathcal X,\ \mathit{bs}:\mathsf{AccountedBranches}(\mathcal X)\bigr).\tag{1}$$
并行分叉（`parallelAt`）、依赖分叉（`jointAt`）、未决前沿（`frontier`，满足零公理非空律 $\mathsf{frontier}(o)\neq[\,]$ 以禁止未决叶静默蒸发）、完整溯源迹（`trace`）、满足结合扁平化律的一步展开推进（`advance_assoc`）、不存储未来完成表的按需有限观察（`observe`），以及万有求值折叠（`fold`）全部是由这一单构造子派生的零公理运算；并且任意与 $\mathsf{occur}$ 交换的候选求值器必唯一分解经过 `fold`（`fold_unique`）。没有第二种发生构造子，也没有独立于展开树之外的原始回执格式。

在这一底层之上，给定关系网络 $N$ 与词汇 $V$，一个**源生权威根** $R$ 由三部分组成：(i) 权威源（含重构账源、全事件库存准入、法则面与投影法则），其中**全事件库存准入**要求抽象呈现与具体源的当前态及每个当前态处的完整事件族之间具备正反复合皆为恒等的双向构造性对应[[8]](#ref-8)；(ii) 在每个当前态 $c$ 发出原始事件的发射器；(iii) 编译结果与发射器严格交换的证明。整个结构不含任何关于“魔法”或“外部补写”的字段。

<a id="def-2-1"></a>
**定义 2.1（时序可达见证与合法世界状态）。** 源生权威根 $R$ 上当前态 $c$ 的**时序可达见证**（`SourceNativeTemporalReachableAt`）仅有两类归纳构造子：

1. **有限可达（`finite`）**：从 $R$ 的初始访问出发，每一步沿原编译器给出的后继等式 $\mathsf{next}_R(c_i)=\mathrm{some}\,c_{i+1}$ 推进有限步抵达 $c$；
2. **共尾后可达（`postCofinal`）**：从一枚源内生成的共尾落点访问出发，其后沿同一后继等式推进有限步抵达 $c$。

$R$ 的**合法世界状态**定义为依赖对 $w=(c,h)$，其中 $h$ 为 $c$ 的时序可达见证；其全体记作 $\mathsf{Law}(R)$。状态 $w$ 的**登记发生**（`registeredOccurrence`）定义为依赖对
$$\mathsf{occ}(w)=\bigl\langle w,\ \varepsilon_R(w)\bigr\rangle\in\sum_{u:\mathsf{Law}(R)}E_R(u),\tag{2}$$
其中 $\varepsilon_R(w)$ 是根在访问 $w$ 处生成的准确时序因果事件（唯一规范构造子 `.canonical`）。同一访问同步读出权威时序演化 $\mathsf{auth}(w)$，以及由同一编译像穷尽给出的五种原语正向处置之一：原生写入、关系写入、续接运输、Borromean 重定向（多行耦合约束重定向[[6]](#ref-6)）或本地忠实终账。

定义 2.1 的准入面就是 $\mathsf{Law}(R)$ 本身：不存在第二份外部登记表，也不接受调用方自行拼装的世界记录。由于共尾后可达只能以源生成的共尾落点起头，有限访问绝不能冒充共尾访问；同时有限嵌入为单射，故即便两次访问抵达同一当前态标签 $c$，只要因果历史 $h\neq h'$，它们在 $\mathsf{Law}(R)$ 中仍是两个不同的合法世界状态。

<a id="lem-2-2"></a>
**引理 2.2（根读恒等母律与合法世界态的发生单射准入）。** 在零公理内核（`#print axioms = []`）中，对任意源生权威根 $R$ 与任意合法世界状态 $w,w'\in\mathsf{Law}(R)$：

1. **根读恒等（$\mathsf{RootRead}(o)=o$）**：完整时序因果根发生上的根余面读出映射 $\mathsf{rootCofaceRead}(o)=o$ 为字面恒等映射，对**任意**下游消费者映射均满足观察安全且隐藏差异见证恒空（`rootCofaceRead_consumerSafe`、`no_hiddenNull_at_rootCofaceRead`，与 §3.2 定理 3.3 精确对偶）；在准确时序访问 $w$ 处，规范生成演化令牌 $\mathsf{generatedAt}(w)$ 的事件、先前补片流、当前有限补片与整账写回均定义性地等于根编译器在 $w$ 处的直接生成像（`occurrence_eq`、`priorPatches_eq`、`currentPatch_eq`、`wholeLedgerWriteBack_eq`），且任意已安装语义切面 $\phi$ 的根读 $\mathsf{rootRead}(\phi)$ 均是该同一根发生的直接坐标限制，不存在独立于 $o$ 的第二枚根级结果对象。
2. **发生单射准入**：若 $\mathsf{occ}(w)=\mathsf{occ}(w')$，则 $w=w'$；等价地，$w\neq w'$ 蕴含 $\mathsf{occ}(w)\neq\mathsf{occ}(w')$。

**证明。** (1) `rootCofaceRead` 在完整时序根事件上按定义返回 `o` 本身，对等式作用 `congrArg consumer` 即证任意消费者安全；规范时序演化类型 `SourceNativeTemporalVisitGeneratedEvolutionAt` 在固定 $(R,w)$ 上仅有唯一构造子 `.canonical`，故先前补片迹、当前补片与整账写回展开即与根编译器输出逐项相等（`rfl`／`HEq.rfl`），而 `SourceNativeRootSemanticFaceAt.rootRead` 直接在 `emitted(w.current)` 上求值。(2) 对式 (2) 的 $\Sigma$ 类型等式取第一投影 $\mathrm{pr}_1$ 立得 $w=w'$；逆否方向直接对相等发生调回前一步即得矛盾。$\square$

引理 2.2(2) 的证明之所以只需一行投影，是因为全部结构代价已在定义 2.1 的准入门前付清：合法状态类型内部只装得下源生成的时序访问，没有任何未经登记的暗格可供账外参数藏身。

### 2.2　幽灵比特反例与单根权威编译期防火墙

现在用一对严格的正反控制检验这道准入门（**OB2**）。取固定验证源码包（附录 D 源 Y）中的具体询问世界根 $R_\circ$，令 $v_1$ 为初始访问，$v_2$ 为 $v_1$ 沿原后继推进一步所得访问，记 $w_i=\mathrm{finite}(v_i)$（$i=1,2$）。

<a id="prop-2-3"></a>
**命题 2.3（裸数据多一位不产生新现实与单根权威防火墙）。** 在零公理内核（`#print axioms = []`）中，以下四项结论同时成立：

1. **真实因果步进具有发生身份**：$v_1\neq v_2$，从而 $w_1\neq w_2$ 且 $\mathsf{occ}(w_1)\neq\mathsf{occ}(w_2)$。
2. **未登记幽灵位在准入处坍缩**：在裸乘积载体 $G=\mathsf{Law}(R_\circ)\times\mathrm{Bool}$ 上定义 $g_0=(w_1,\mathrm{false})$ 与 $g_1=(w_1,\mathrm{true})$。作为裸数据二元组有 $g_0\neq g_1$；但二者经唯一合法世界准入投影（第一分量 `.1`）后满足
$$g_0.1=g_1.1=w_1,\qquad \mathsf{occ}(g_0.1)=\mathsf{occ}(g_1.1),\qquad \mathsf{auth}(g_0.1)=\mathsf{auth}(g_1.1).\tag{3}$$
3. **构造子拒绝幽灵参数与未准入裸根**：合法世界状态的两类构造子仅接收根的有限访问或共尾后历史，向状态构造子额外传入 `Bool` 参数，或将未经全事件库存准入的混合终账／写入裸根当作合法世界根，均在类型检查期直接失败（`fail_if_success`）。
4. **单根权威编译期防火墙**：公开权威门面（`LivingLawSingleRootAuthorityFacadeRegression`）以编译期 `#guard_msgs` 守卫封死八类改变已准入世界的越权入口——(i) 裁剪完整实际事件库存，(ii) 向兄弟字段或旁路账行借用权威，(iii) 将完成态未来神谕提升为当前原子发生，(iv) 脱离固定根发生执行询问或修订载荷，(v) 重建平行生命周期或外部修订挑选神谕（如 `U8RevisionCalculus`、`GeneratedRevisionFamilyAt`、`RevisionSelectionCalculus`），(vi) 激活任意未安装公共切面，(vii) 以旧根微后继冒充询问宏后继，以及 (viii) 预装未来查询激活完成表。

**证明。** (1) $v_1$ 与 $v_2$ 的可达历史分别以初始构造子与后继推进构造子收尾，归纳构造子不相交给出 $v_1\neq v_2$；由 `finite` 单射得 $w_1\neq w_2$，再由引理 2.2(2) 得 $\mathsf{occ}(w_1)\neq\mathsf{occ}(w_2)$。(2) 若 $g_0=g_1$，取第二投影得 $\mathrm{false}=\mathrm{true}$，矛盾；式 (3) 三条等式由 $g_0.1\equiv w_1\equiv g_1.1$ 按定义自反成立（`rfl`）。(3) 与 (4) 分别由定义 2.1 构造子类型签名、全事件库存准入双射字段及公开门面的作用域隔离强制保证，并经内核 `fail_if_success` 与 `#guard_msgs` 逐条机器核验。$\square$

命题 2.3 把最易混淆的两件事彻底剥离（图 2）：在环境数学中定义乘积类型 $G$ 并证明 $g_0\neq g_1$ 完全合法；但在 $R_\circ$ 管辖的世界里，$g_0$ 与 $g_1$ 对应同一个合法状态与同一次发生，同样千真万确。那枚额外的布尔值若想成为真实世界差异，只有一条正道：进入源或根的发生机制，改变某次访问或触发后续残差／修订登记——一旦如此，它便如同第 (1) 条中的 $w_2$，堂堂正正带着新的 $\mathsf{occ}$ 进门；倘若它在一切源生演化与读出中永远不留痕迹，它就只是同一现实的冗余外衣。

![图 2｜幽灵比特拦截与单根权威防火墙](figures/ghost-identity-v2.svg)

**图 2｜幽灵比特拦截与单根权威防火墙。** 上排左：裸二元组 $g_0=(w_1,\mathrm{false})$ 与 $g_1=(w_1,\mathrm{true})$ 在第二分量上确实不等。上排中：唯一合法准入投影 $\mathrm{pr}_1$ 将二者映至同一状态 $w_1$，服从 $\mathsf{RootRead}(o)=o$ 且登记发生与权威演化逐项全等。上排右：真实差异 $w_1\neq w_2$ 源于两次不同的根访问，由正向发生单射赋予不同身份。中部朱红虚线标出被阻断的越权推论，下方虚框汇总 T0 内核由 `fail_if_success` 与 `#guard_msgs` 在编译期直接拦截的八项越权入口。

### 2.3　弱差异词表与反魔法的零公理正向导出

有了准入单射，我们现在证明：**无需在定义里埋入任何“禁止魔法”的公理字段，仅凭正向差异分类即可零公理排除外部补写与魔法比特（OB1、OB3）。**

<a id="def-2-4"></a>
**定义 2.4（弱差异语义、正向内部决定、外部补写与魔法比特）。** 一个**弱差异语义** $\mathcal R$ 由差异载体类型 $D$ 及其上五个独立命题谓词组成：实际性 $\mathsf{Act}$、稳定指称 $\mathsf{Ref}$、真实差异 $\mathsf{Real}$、冗余呈现 $\mathsf{Red}$ 与正向结构身份 $\mathsf{Id}$。对任意 $d\in D$，定义：

- **实际差异** $\mathsf{AD}(d)\;:\Longleftrightarrow\;\mathsf{Act}(d)\wedge\mathsf{Ref}(d)\wedge\mathsf{Real}(d)$；
- **内部决定** $\mathsf{ID}(d)\;:\Longleftrightarrow\;\mathsf{AD}(d)\wedge\mathsf{Id}(d)$（携带实际差异及其正向结构身份见证）；
- **外部补写** $\mathsf{ES}(d)\;:\Longleftrightarrow\;\mathsf{AD}(d)\wedge\neg\mathsf{Red}(d)\wedge\neg\mathsf{ID}(d)$；
- **魔法比特** $\mathsf{MB}(d)\;:\Longleftrightarrow\;\mathsf{AD}(d)\wedge\neg\mathsf{Red}(d)\wedge\neg\mathsf{ID}(d)$。

称语义 $\mathcal R$ 满足**正向全实在性**（`TotalRealityAt`），记作 $\mathsf{Total}(\mathcal R)$，若存在正向分类映射 `locate` 使得
$$\forall d\in D,\qquad \mathsf{AD}(d)\;\Longrightarrow\;\mathsf{Red}(d)\,\vee\,\mathsf{Id}(d).\tag{4}$$

定义 2.4 有两处关键设计杜绝了循环论证。第一，$\mathsf{ID}(d)$ 绝非 $\neg\mathsf{MagicBitAt}$ 的否定改写，而是要求显式交出正向结构身份 $\mathsf{Id}(d)$；式 (4) 的 $\mathsf{Total}(\mathcal R)$ 同样只规定实际差异的正向落点，不含任何否定公理字段。第二，$\mathsf{MB}(d)$ 与 $\mathsf{ES}(d)$ 拥有相同字段并非重复定义，而是揭示了一条即时逻辑后果（`MagicBitAt.toExternalSupplement`）：**凡声称某项差异既实际发生、又非表示冗余、却拒绝一切内部结构身份者，当场就在逻辑上背负了“必须从理论外部硬塞补丁”的义务。**

<a id="thm-2-5"></a>
**定理 2.5（正向全实在性无循环排除外部补写与魔法比特）。** 在零公理内核（`#print axioms = []`）中，若弱差异语义 $\mathcal R$ 满足 $\mathsf{Total}(\mathcal R)$，则对任意 $d\in D$，$\mathsf{ES}(d)$ 与 $\mathsf{MB}(d)$ 均为空（即蕴含 $\mathsf{False}$）。

**证明。** 任取外部补写见证 $e:\mathsf{ES}(d)$，将其实际差异分量 $e.\mathsf{actualDifference}:\mathsf{AD}(d)$ 输入式 (4) 的正向分类器 `locate`：若落在左支 $\mathsf{Red}(d)$，直接与 $e.\mathsf{nonredundant}:\mathsf{Red}(d)\to\mathsf{False}$ 矛盾；若落在右支 $\mathsf{Id}(d)$，将其与 $e.\mathsf{actualDifference}$ 配对即构造出内部决定见证 $\langle e.\mathsf{actualDifference},\,\mathrm{id}\rangle:\mathsf{ID}(d)$，直接与 $e.\mathsf{notInternallyDetermined}:\mathsf{ID}(d)\to\mathsf{False}$ 矛盾。故 $\mathsf{ES}(d)\to\mathsf{False}$。对任意魔法比特见证 $m:\mathsf{MB}(d)$，先经逐字段恒等映射 `toExternalSupplement` 化为 $\mathsf{ES}(d)$，再调用前一步即得矛盾。全程仅使用构造性合取与析取消去，不调用排中律、选择公理或商公理。$\square$

定理 2.5 本身只是一台纯逻辑引擎：倘若有人把 $\mathsf{Total}(\mathcal R)$ 当成外部假设传进来，它仍只是条件推演。接下来的定理 2.6 与 2.8 证明，任意源生权威根与任意完整活源过程均**由自身准入结构无条件生成 $\mathsf{Total}$**。

### 2.4　单根全实在性与跨终账／跨修订活过程全实在性

<a id="thm-2-6"></a>
**定理 2.6（任意源生权威根的全实在性，`RootTotalReality`）。** 在零公理内核（`#print axioms = []`）中，对任意关系网络 $N$、任意词汇 $V$ 及任意源生权威根 $R$，定义根级差异语义 $\mathcal R_R$ 如下：
$$
\begin{aligned}
D&=\mathsf{Law}(R)\times\mathsf{Law}(R),\\
\mathsf{Act}(w,w')&:\ \text{两侧演化 }\mathsf{auth}(w),\mathsf{auth}(w')\text{ 均具根时序访问编译器的规范回执},\\
\mathsf{Ref}(w,w')&:\ \text{两侧均存在等于 }\mathsf{occ}(w),\mathsf{occ}(w')\text{ 的准确时序根事件},\\
\mathsf{Real}(w,w')&:\ w\neq w',\qquad
\mathsf{Red}(w,w'):\ \mathsf{occ}(w)=\mathsf{occ}(w'),\qquad
\mathsf{Id}(w,w'):\ \mathsf{occ}(w)\neq\mathsf{occ}(w').
\end{aligned}\tag{5}
$$
则：(a) 任意一对不等合法状态 $w\neq w'$ 均由根编译器自身生成完整的实际差异见证 $\mathsf{AD}(w,w')$；(b) $\mathsf{Total}(\mathcal R_R)$ 恒成立；(c) 对任意 $d\in D$，外部补写 $\mathsf{ES}(d)$ 与魔法比特 $\mathsf{MB}(d)$ 均为空。

**证明。** (a) 对每个合法状态 $u\in\mathsf{Law}(R)$，根闭包自带其生成演化属于时序访问权威编译器规范像的证明，左右各取一份即得 $\mathsf{Act}(w,w')$；取 $\langle\mathsf{occ}(w),\mathsf{rfl}\rangle$ 与 $\langle\mathsf{occ}(w'),\mathsf{rfl}\rangle$ 即得 $\mathsf{Ref}(w,w')$；合上 $w\neq w'$ 即构成 $\mathsf{AD}(w,w')$。(b) 对任意实际差异，将其真实差异分量 $w\neq w'$ 代入引理 2.2(2)，直接构造出右支 $\mathsf{occ}(w)\neq\mathsf{occ}(w')$，故 `locate` 恒成立。(c) 将 (b) 代入定理 2.5 即得。$\square$

定理 2.6 覆盖单个固定权威根内的全部有限、共尾与共尾后访问，且由命题 2.3(1) 知其作用域非空（绝非空真）。然而，一个真实的演化过程未必永远停留在一张局部词汇表上：它可以在**本地忠实终账**处结清当前局部账面并交接给新根，也可以在**理论修订**边界处切换到扩充后的新法则面。为证明跨越根交接边界后依然不存在账外魔法缝隙，我们将同一构造提升至完整活过程层（`RootProcessTotalReality`）。

<a id="def-2-7"></a>
**定义 2.7（完整活源过程）。** 关系网络 $N$ 上的**完整活当前**（living current，全体记作 $\mathrm{Cur}(N)$）是三元依赖包 $(V,\rho,v)$，包含词汇 $V$、携带源定终账交接律的活根闭包 $\rho$ 以及 $\rho$ 的一次时序访问 $v$。一个**完整活源过程** $\mathcal P=(S,\iota,s_0,\sigma)$ 由任意状态类型 $S$、**单射登记映射** $\iota:S\hookrightarrow\mathrm{Cur}(N)$、初始态 $s_0\in S$ 与一步推进映射 $\sigma:S\to S$ 组成，并附带生成后继证明：对任意 $s\in S$，$\iota(\sigma s)$ 擦除交接律后精确等于 $\iota(s)$ 所在根于该访问处生成的下一当前；在非终账分支上活根自身保持异质相等，而在本地忠实终账分支上则严格落入源固定的终账交接目标[[6]](#ref-6)。

<a id="thm-2-8"></a>
**定理 2.8（跨局部终账与修订交接边界的活过程全实在性，`RootProcessTotalReality`）。** 在零公理内核（`#print axioms = []`）中，对任意关系网络 $N$ 与任意完整活源过程 $\mathcal P=(S,\iota,s_0,\sigma)$，定义过程差异语义 $\mathcal R_{\mathcal P}$：以 $S\times S$ 为差异载体，两侧均具过程规范因果“回答与后继”为 $\mathsf{Act}$，两侧均具过程索引因果发生为 $\mathsf{Ref}$，$s\neq s'$ 为 $\mathsf{Real}$，$\iota(s)=\iota(s')$ 为 $\mathsf{Red}$，$\iota(s)\neq\iota(s')$ 为 $\mathsf{Id}$。则任意不等状态对均由 $\mathcal P$ 自身生成实际差异见证，$\mathsf{Total}(\mathcal R_{\mathcal P})$ 恒成立，故跨任意根纪元交接边界的外部补写与魔法比特均为空。

**证明。** 过程 $\mathcal P$ 在每个状态 $s$ 处原生给出规范因果回答与后继及发射事件，从而生成 $\mathsf{Act}$ 与 $\mathsf{Ref}$。当 $s\neq s'$ 时，倘若 $\iota(s)=\iota(s')$，由登记单射性 $\iota$ 立得 $s=s'$，矛盾；故必有 $\iota(s)\neq\iota(s')$，正向落入 $\mathsf{Id}$。调用定理 2.5 即排除一切跨纪元外部补写与魔法比特。$\square$

<a id="ex-2-9"></a>
**例 2.9（局部终账交接并非全局停机位）。** 固定验证源码包（附录 D 源 Y）给出一条显式跨根活过程（`local_terminal_handoff_has_structural_identity`）：取状态载体 $S=\mathrm{Option}\,\mathbb N$，令 $\iota(\mathrm{none})$ 为某本地忠实终账根的终账访问，$\iota(\mathrm{some}\,n)$ 为另一原生写入根深度为 $n$ 的有限访问（初访 $n=0$），一步推进定为 $\mathrm{none}\mapsto\mathrm{some}\,0$、$\mathrm{some}\,n\mapsto\mathrm{some}\,(n+1)$。终账根词汇含忠实终账纤维而写入根词汇不含，且写入访问的有限深度恰为 $n$，故 $\iota$ 严格单射。跨越终账接缝的状态对 $(\mathrm{none},\mathrm{some}\,0)$ 并非靠一枚外置布尔位“世界停机了没有”来区分，而是直接由两份异质却完整的活当前 $\iota(\mathrm{none})\neq\iota(\mathrm{some}\,0)$ 取得正向结构身份。

### 2.5　举证责任的彻底倒置

至此，T0 内核完成了对“账外差异”的去循环化裁决：“无魔法”从未充当前提，前提只是**合法状态与过程登记必须交代源发生来历**。这也明确了本文在类型论坐标中的位置：我们沿用依赖类型论[[10]](#ref-10)的 $\Sigma$ 第一投影从登记发生恢复合法状态，但工作在保持内涵命题相等的 CIC 内核中（不采纳[[10]](#ref-10)第 32 页的外延相等反射），亦不引入处理宇宙内类型等价与类型相等的单值公理[[11]](#ref-11)；在固定权威根或活过程内部，状态同一性严格由单构造子展开树与已登记访问 $\mathsf{occ}(w)$、$\iota(s)$ 判定。一旦准入确立，任何被宣称为“属于现实的新比特”只剩两条合法出路：要么改变某个源或根的发生（或进入后续残差与修订登记），从而携带可核查的新 $\mathsf{occ}$ 或新 $\iota(s)$ 取得正向结构身份；要么不改变任何登记发生，从而在操作上归入同一现实的冗余呈现。至于第三条幻想之路——“真实改变世界，却永远不在任何发生账上留痕”——在零公理内核中已被严格证明为空类型。

---

## 3　发生刚性、观察商盲区与未预存的未来

确立已发生差异的结构刚性后，最容易滋生两类反向误读：一类误以为“既然完整当前唯一决定下一步，那么局部观察总能倒推全部历史”；另一类误以为“既然演化无魔法，那么无穷未来的全部具体事件早已像静态库存一样预存在今天”。本节用两条精确结果（**OB4、OB5**）将**过去与当前的发生刚性**、**观察商的信息损失**以及**未来的按需生成责任**严格拆开。

### 3.1　当前态反射与按需有限历史：封死“条件前提冒充既成事实”

<a id="thm-3-1"></a>
**定理 3.1（当前态反射、法则面保持与按需有限历史）。** 在零公理内核（`#print axioms = []`）中，固定任意完整活源过程 $\mathcal P=(S,\iota,s_0,\sigma)$：

1. **同当前同后继**：若 $\iota(s)=\iota(s')$，则 $s$ 与 $s'$ 处的规范因果“回答与后继”异质相等（`HEq`），特别地 $\iota(\sigma s)=\iota(\sigma s')$；
2. **后继差异必反射回当前**：若 $\iota(\sigma s)\neq\iota(\sigma s')$，则必有 $\iota(s)\neq\iota(s')$；
3. **固定过程保持法则面**：$\iota(\sigma s)$ 擦除交接律后等于 $\iota(s)$ 所在根生成的下一当前，且前后两活根拥有完全相同的法则面（`successor_lawSurface_eq`）；
4. **按需有限历史生成**：对任意读取预算 $n\in\mathbb N$ 与任意起点状态 $s\in S$，一步后继 $\sigma$ 递归生成长度为 $n$ 的有限历史 $\mathsf{hist}(n,s)$：$\mathsf{hist}(0,s)=\mathsf{exhausted}(s)$，$\mathsf{hist}(n+1,s)=\mathsf{step}(\mathsf{hist}(n,\sigma s))$。

**证明。** (1) 由 $\iota$ 单射及 $\iota(s)=\iota(s')$ 得 $s=s'$，消去等式后两侧规范回答与后继为同一项。(2) 为 (1) 的逆否命题。(3) 第一半取自生成后继证明的首分量；对其两侧取活根法则面映射，并复合单步生成保持法则面引理即得第二半。(4) 对自然数 $n$ 作原始递归。$\square$

定理 3.1(1)–(2) 精准封死了一条在形式建模中极其隐蔽的偷渡通道：**先在定理假设栏里写上一条能左右结果的前提 $H$，再把“在假设 $H$ 下可证某结果”偷换为“该结果已在本世界实际发生”。** 在固定过程 $\mathcal P$ 内，条件推理完全合法，但它产出的只是条件蕴含命题；一枚前提若想真正改动本世界的规范回答或下一状态 $\sigma(s)$，按第 (2) 条它就必须先改变当前已登记的完整活当前 $\iota(s)$（或显式切换到另一条源过程），绝无可能在同一 $\iota(s)$ 下暗改明天。同时，第 (3) 条表明固定法则过程即便跨越本地终账（如例 2.9 从 $\mathrm{none}$ 经 $n=2$ 步推进至 $\mathrm{some}\,1$）也无法偷换底层法则面——真正的法则升维必须走 §6 的独立修订合同；第 (4) 条中的构造子 $\mathsf{exhausted}$ 仅代表本次有限观察预算 $n$ 耗尽，历史归纳类型中根本不存在“世界全局停机”构造子。

### 3.2　局部观察不可见不等于本体未发生：观察商反例与整算术挠盲区

完整活当前的刚性属于本体登记层；而任何具体的仪器、界面或数学投影通常只是从完整状态空间 $A$ 到粗粒化读数空间 $O$ 的观察映射 $q:A\to O$。把不同的完整发生压进同一观察纤维，是观察商的常态，绝不构成抹杀原发生或免除未清责任的理由（**OB5**）。

<a id="def-3-2"></a>
**定义 3.2（相对于下游读出的观察安全与隐藏差异见证）。** 设 $q:A\to O$ 为观察映射，$c:A\to K$ 为下游读出算子（形式声明称消费者映射）。称观察 $q$ **对 $c$ 安全**（`ConsumerSafe`），若 $\forall x,y\in A,\ q(x)=q(y)\Rightarrow c(x)=c(y)$。称四元组 $(x,y,p_{\mathrm{obs}},p_{\mathrm{diff}})$ 为 $q$ 相对于 $c$ 的**隐藏差异见证**（`HiddenNullWitness`），若 $q(x)=q(y)$ 而 $c(x)\neq c(y)$。

<a id="thm-3-3"></a>
**定理 3.3（隐藏差异否决安全认证、全迹重定向与有限复观察核消亡）。**

1. **安全认证否决与不可挽救性**：一旦存在隐藏差异见证，$\mathsf{ConsumerSafe}(q,c)$ 即为空类型；且对任意后处理压缩映射 $h:O\to O'$，复合观察 $h\circ q$ 被同一对状态 $(x,y)$ 继续反驳。
2. **隐藏责任准入的全迹重定向**：在原生责任过程中，若一次实际承诺准入事件的作用域对某局部范围观察者不可见，则准入前后该局部观察者读出完全相同的责任清单，而完整当前责任观察者读出长度严格加一的清单；该准入事件连同局部不可见等式与完整清单不等式，直接构造出完整保留原准入事件的全迹重定向记录（`FullTraceRedirect`）。
3. **全局整算术挠类的有限复观察全盲反例**：在共同算术源生成的整体相容整数余核 $G=\{(g_n)\in\prod_n C_n:\rho_n(g_{n+1})=g_n\}$ 中，存在非零挠类 $z\in G$，使得首阶整算术读出算子满足 $J(z)\neq J(0)$，而**全体**有限阶段复标量化观察族 $F(g)=(1\otimes_{\mathbb Z}\pi_n(g))_{n\in\mathbb N}$ 满足 $F(z)=F(0)$[[8]](#ref-8)。因此，不存在**任何**函数（无论线性或非线性解码器）$h$ 使得 $J=h\circ F$。

**证明。** (1) 将 $q(x)=q(y)$ 代入安全定义得 $c(x)=c(y)$，与 $c(x)\neq c(y)$ 矛盾；对 $q(x)=q(y)$ 两侧作用 $h$ 得 $(h\circ q)(x)=(h\circ q)(y)$，同一矛盾照旧成立。(2) 局部范围观察者按可见谓词过滤开放责任，不可见新准入项被滤除故列表不变；完整观察者逐槽映射全部开放或空置槽位，新准入使槽位数加一，从而列表长度不等；将原事件与这两条证明打包即得 `FullTraceRedirect`。(3) 由整账法[[8]](#ref-8)定理 13.1–13.3（详见附录 A.5）：端点相容性给出 $z\in G$，单位算术根保证首阶投影 $J(z)=z_1\neq0$，而逐阶段整挠与复数域张量积直接消去 $1\otimes_{\mathbb Z} z_n=0$（无需交换逆极限与张量积），故 $F(z)=0=F(0)$；若存在 $h$ 使 $J=h\circ F$，则 $J(z)=h(F(z))=h(F(0))=J(0)=0$，矛盾。$\square$

定理 3.3 给科学实践划出了一条极锋利的方法论分界：面对“某套观测通道或复化投影读出为零”，合法结论只有三种截然不同的状态——已证对目标读出算子安全、已被隐藏差异见证推翻、或尚未完成分类；绝不允许把“局部通道看不见”静默改写为“本体未发生”。

### 3.3　明天不是静态库存，而是待生成的责任

把定理 3.1 与定理 3.3 合观，决定论的常见迷雾便一扫而空。当前现实真正持有的数据只是**当前状态连同一步生成法则** $(s_t,\sigma)$，而非无穷序列 $(s_t,s_{t+1},s_{t+2},\dots)$。定理 3.1(4) 赋予的是对任意有限步数 $n$ 按需展开前缀的构造能力，内核中从未存放一张写满未来事件的完成表；下文 §5 的全未来模型同样是用全称作用词等价关系约束下一步请求，具体未来发生仍须由每一次真实运行逐步支付成本后长出。在状态机精化理论[[16]](#ref-16)中，依赖未来的“预言变量”是扩充低层规范以构造精化映射的证明辅助变量（投影回原变量仍保持相同的可见行为）；而在本文的本体状态准入中，合法当前世界态自身绝不存储依赖未执行未来的数据——倘若把尚未运行的明天直接预装为当前原子状态，便构成了未经演化的旁路神谕（命题 2.3(4) 第 (iii)、(viii) 项在编译期直接拦截）。简言之：**过去与当前因登记而刚性，未来因未付而开放——不许赖账的原则不替世界预言明天，它只规定明天不能白拿。**

---

## 4　固定二态母源 $S_\star$ 的三域普遍形成总定理

第 2–3 节对每一个给定的源生权威根 $R$ 与活过程 $\mathcal P$ 确立了内部无魔法刚性。此时，任何敏锐的读者都会追问最深一层的本体论问题：**这些五花八门的权威根、询问与过程本身又从哪里来？** 倘若每换一类物理系统、每建一套查询语言都不得不从外部另挑一份底层源，那么“究竟挑了哪一份源”本身就会退化为凌驾于体系之上的账外自由度。

本节在标准三公理分析完备化层（T1）证明**单母源三域普遍形成总定理**（**OB6–OB7**）：无需逐对象另选底层源，由原始事件结构内生生成的**同一固定物理自旋对母源 $S_\star$**，经“有限程序观测逼近 $\to$ 逐点一致完备化 $\to$ 规范实现与左逆恢复”三步构造，无附加前提地普遍形成最低类型宇宙（`Type 0`）原准入接口上的全部合法世界、全部完整询问与全部宏过程。

### 4.1　内生母源 $S_\star$、有限程序求值与逐点一致完备化

固定物理母源 $S_\star$，即连续—量子统一场旗舰[[7]](#ref-7)中二态自旋对（`SpinPair`）活根的权威账本根。有必要在第一时间指明：**固定 $S_\star$ 绝非人为特殊点挑选或参数调优。** 物理旗舰[[7]](#ref-7)定理 9.3（第二版定理 8.3）已证，原始事件结构无需候选池比较即内生生成唯一规范根，其第 $n$ 次访问对一切 $n\in\mathbb N$ 逐拍复现原母史第 $n$ 次访问的当前态。本节正是要证明，这同一枚极小物理母源足以生长出整个 `Type 0` 准入森林。

设实数序列流空间为 $\mathbb S=\mathbb R^{\mathbb N}$。在材料阶 $r$ 上，记输入载体为 $X_r$，分离输入点的观测地址族为 $\mathcal A_r$。阶 $r$ 上的一个**有限母源程序**由一张有限观测地址表 $(a_0,\dots,a_{n-1})\in\mathcal A_r^{\,n}$ 与 $S_\star$ 的一次合法访问 $\nu\in\mathsf{Visit}(S_\star)$ 组成；其求值映射先将 $n$ 个实观测读数补零延拓为无穷实流，再交由 $S_\star$ 的有限求值律给出输出流：
$$
\begin{aligned}
\mathsf{Prog}_r&=\coprod_{n\in\mathbb N}\mathcal A_r^{\,n}\times\mathsf{Visit}(S_\star),\\
L_r\bigl((a_0,\dots,a_{n-1};\nu),\,x\bigr)&=\mathsf{finiteLaw}_{S_\star}\!\bigl(\nu,\ \mathrm{pad}_n(\mathrm{obs}_r(a_i,x))_{i<n}\bigr),\\
\mathcal R_r=\operatorname{im}L_r&\subseteq(X_r\to\mathbb S),\qquad \mathcal M_r=\widehat{\mathcal R_r}.
\end{aligned}\tag{6}
$$
此处完备化 $\mathcal M_r=\widehat{\mathcal R_r}$ 赋予函数空间 $X_r\to\mathbb S$ 逐输入点、逐有限输出前缀坐标的乘积一致结构（uniform structure），并记稠密一致嵌入为 $j_r:\mathcal R_r\hookrightarrow\mathcal M_r$。低阶材料与高阶材料统一按式 (6) 构造，其中高阶材料的输入载体 $X_r$ 可直接取已形成的低阶完备材料空间。

<a id="def-4-1"></a>
**定义 4.1（由母源 $S_\star$ 形成）。** 称材料 $m\in\mathcal M_r$ **由母源 $S_\star$ 形成**，若 $m$ 属于有限程序求值像 $\{j_r(L_r(p)):p\in\mathsf{Prog}_r\}$ 在完备空间 $\mathcal M_r$ 中的拓扑闭包。

注意定义 4.1 的逻辑地位：**“由 $S_\star$ 形成”是一项在证明内部无条件兑现的定理性质，而非加在目标对象头上的准入筛选条件。** 因为有限程序像等于原始像 $\mathcal R_r$，而 $\mathcal R_r$ 在自身一致完备化 $\mathcal M_r$ 中稠密，故 $\mathcal M_r$ 中的每一个完备材料自动满足定义 4.1。真正的数学硬仗在于：对任意给定的目标世界、询问或宏过程，在不向其原类型添加任何可表示性假设的前提下，从内部构造出分离地址与材料阶，使规范实现映射从该完备材料精确重构原对象并左逆恢复其全部操作。

### 4.2　三域普遍形成总定理与“无独立第二基源”推论

<a id="thm-4-2"></a>
**定理 4.2（固定母源 $S_\star$ 在原 `Type 0` 接口上的三域普遍形成总定理[[7]](#ref-7)）。** 固定母源 $S_\star$。在原准入接口（对象位于最低类型宇宙 `Type 0`）上，无需调用方补充任何地址分离或覆盖假设，以下三项全称命题同时成立：

1. **任意合法准入世界（$\forall N,V,R,w$）。** 对任意关系网络 $N$、任意词汇 $V$、任意源生权威根 $R$ 及任意合法世界状态 $w\in\mathsf{Law}(R)$，存在内生构造的材料阶 $r$ 与由 $S_\star$ 形成的完备材料 $m\in\mathcal M_r$，使规范状态构造映射从 $m$ 输出 $\mathrm{some}(V,R,w)$，读出完整世界 $(N,V,R,w)$，原编码嵌入具显式左逆，且恢复出的登记发生、权威演化、正向处置、先前补片迹、当前补片、整账写回、下一当前及步进推进均与原对象异质相等，所读出之根自动携带全实在性 $\mathsf{Total}(\mathcal R_R)$。
2. **任意完整询问（$\forall N,V,q$）。** 对任意 $N,V$ 及任意完整询问状态 $q$，存在由 $S_\star$ 形成的高阶完备材料，使其读出询问世界精确等于 $(N,V,\mathrm{create}(q))$，恢复出的程序子句等于 $q$ 的原始回答、行动与修订子句，对 $q$ 的每条查询及该访问处每个准确因果事件的编译结果均与原查询编译异质相等，且全部双亲底层材料空间均由左逆限制完整恢复。
3. **任意询问引擎宏过程（$\forall P$）。** 对任意原生询问引擎宏过程 $P$，存在由 $S_\star$ 形成的高阶完备材料 $m$ 及所形成过程 $P_m$，满足
$$\mathsf{form}(m)=\mathrm{some}(P_m),\qquad \mathsf{restrict}(P_m)=P,\tag{7}$$
经左逆限制完整保留全部双亲底层材料空间（`ParentsRetained`），状态载体、逐状态查询节点、初始态与一步后继全部精确恢复，且每个状态处每条查询的编译沿同一表示严格交换；对任意既有引擎、激活与完整激活法则，其完整询问结果、下一引擎与整条法则逐项恢复；对任意原执行轨迹 $\mathcal T$ 与任意深度 $n\in\mathbb N$，沿式 (7) 诱导的类型运输 $T_m$ 满足
$$\widetilde{\mathcal T}.\mathsf{stateAt}(n)=T_m\bigl(\mathcal T.\mathsf{stateAt}(n)\bigr),\quad
\widetilde{\mathcal T}.\mathsf{tickAt}(n)\doteq\mathcal T.\mathsf{tickAt}(n),\quad
\widetilde{\mathcal T}.\mathsf{tickAt}(n).\mathsf{next}=T_m\bigl(\mathcal T.\mathsf{tickAt}(n).\mathsf{next}\bigr).\tag{8}$$

**证明的承重结构。** 核心障碍在于有限与无穷的跨越：单个有限程序 $(a_0,\dots,a_{n-1};\nu)$ 只能探测有限个输入坐标，而目标世界或宏过程的状态与查询转换却是定义在完整载体上的函数 $f:X_r\to\mathbb S$。破局分三步闭合（完整细节见附录 B.1–B.3）：
第一步（**稠密逼近与完备双射**）：给定任意有限输入子集 $F\subset X_r$、有限输出前缀长度 $b\in\mathbb N$ 与精度 $\varepsilon>0$，对 $F$ 中每对相异点选取一枚区分地址，拼成在 $F$ 上单射的有限地址表；调用 $S_\star$ 有限求值器的稠密逼近定理（形式证明中取母史第 $10+c$ 次访问），即可在 $F\times\{0,\dots,b-1\}$ 上以误差 $<\varepsilon$ 逼近 $f$。因逐点一致拓扑的基本邻域恰由 $(F,b,\varepsilon)$ 刻画，$\mathcal R_r$ 在 $X_r\to\mathbb S$ 中稠密；完备延拓读出 $\mathsf{read}_r:\mathcal M_r\to(X_r\to\mathbb S)$ 作为像闭且含稠密子集的一致嵌入，必为双射。
第二步（**统一见证组装与双亲左逆**）：对宏过程 $P$，将其全部状态与逐状态依赖查询并入不交并 $\mathcal U_P=\mathrm{State}(P)\sqcup\coprod_s\mathrm{Query}(P.\mathsf{stateAt}(s))$，在证明内部自动定出材料阶与点分离地址；将状态域、查询节点族、事件地址与后继图经固定实流配对并入同一联合材料 $m$，配对投影提供双亲材料空间的严格左逆限制。
第三步（**规范重构与运行轨迹运输**）：规范实现映射读取 $m$ 的恢复分量生成重标过程 $P_m$，沿状态等价限制即得式 (7) 的完整记录等式 $\mathsf{restrict}(P_m)=P$；由此直接运输既有激活法则与任意深度 $n$ 的离散演化步，一次导出式 (8)，全程未对不同深度换用第二份材料。$\square$

定理 4.2 在本体论与方法论上同时立起三道硬边界：

- **原准入接口上无需独立第二基源**：第 (1) 款对源生权威根 $R$ 作了无条件全称量化（$\forall R$）。因此，在 `Type 0` 原准入接口上，任何被提议充当“另一份独立底层源”的权威根 $R'$ 及其全部合法世界状态，均已作为 $S_\star$ 有限程序完备化材料的读出被精确形成并恢复。
- **无需操作概率原语、模态任务公设或扩充规范辅助变量**：不同于采用一般操作概率框架并加纯化公设导出量子理论的重构路线[[14]](#ref-14)、以任务可能／不可能及互操作性原理（原理 III）表述信息定律的构造子理论[[15]](#ref-15)，亦不同于在满足条件时通过增补历史与预言变量扩充低层规范以构造精化映射的方法[[16]](#ref-16)，定理 4.2 在证明内部从 `Type 0` 不交并载体自建分离地址，由单一确定性物理母源 $S_\star$ 一次性给出普遍形成与严格左逆恢复。
- **完备形成材料不是预装运行库存**：式 (6) 的一致完备化 $\mathcal M_r$ 是由泛性质唯一固定的静态形成材料；定理 4.2(3) 恢复的是**后继生成函数**与任意有限深度 $n$ 的演化等式 (8)，下一步真实发生依然在运行中由该后继动态产出（与 §3.3 完全一致）。

### 4.3　连续—量子统一场对普遍形成的直接调用与旋量翻转反控

一条全称形成定理唯有在最复杂的真实物理对象上跑通，才算彻底排除空转嫌疑（**OB7**）。

<a id="cor-4-3"></a>
**推论 4.3（五条无旁路下游核验链[[7]](#ref-7)）。** 以下五项核验结果全部直接调用定理 4.2 的同一主声明 `root_admission_fixed_mother_complete_realization`，且经内核声明依赖审计确认**不直接旁路引用任何低层逐域覆盖引理或低层恢复引理**（完整依赖闭包仅含标准三公理）：(1) 任意合法世界 $(N,V,R,w)$ 的形成、整账写回与下一当前恢复；(2) 任意完整询问 $(N,V,q)$ 的双亲保留、子句恢复与逐事件编译交换；(3) 任意宏过程 $P$ 的式 (7) 左逆恢复；(4) 物理统一场询问过程在第 16 演化状态处的封印回答、下一引擎及整条激活法则异质相等恢复；(5) 对**任意**深度 $n\in\mathbb N$，同一母源材料同时恢复第 $16\to17$ 步演化与第 $n$ 步完整状态及后继，认回母史第 10 次物理访问与同发生激活（`SameOccurrenceActivation`）。

<a id="thm-4-4"></a>
**定理 4.4（同一 `SpinPair` 活根上的连续九场、$4\sqrt2$ 量子配对与宏步后继[[7]](#ref-7)）。** 从 `SpinPair` 活根内生生成忠实实现 $\mathcal Q$，使得：(i) 任意两次访问构成内部决定差异当且仅当其在 $\mathcal Q$ 中的表示访问不等；(ii) 对任意另一忠实实现存在唯一交换呈现；(iii) 每个事件完整恢复原投影、原写入器与整账写回；(iv) 在物理访问的每个事件上，读出构型通过四维 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 经典九场世界准入与 252 复维手征物质恢复，量子读出精确等于步进回答 $a$，且对全时空每一点 $x$ 与母物质载体上**任意**复线性自同态 $A\in\operatorname{End}_{\mathbb C}(\mathbb C^{252})$，成立有限 $\hbar$ 精确配对恒等式
$$\chi_x\bigl(A\,\psi_x\bigr)=4k\,\bigl\langle a_x,\ R(A)\,a_x\bigr\rangle,\qquad k=\sqrt2,\quad R(A)=S P A E,\tag{9}$$
同时该步下一节点擦除后精确等于该事件编译产出的下一当前。

式 (9) 将第 2 节的内部决定性、第 4 节的同源形成与真实物理统一场锁死在同一事件上：比例常数 $4\sqrt2$ 来自经典解幅度 $\psi=2Ev$ 与独立线性对偶幅度 $2\sqrt2$ 的无参乘积，而非经验拟合；压缩响应映射 $R(A)=SPAE$ 中的 $E$ 为八维占据等距嵌入，$P=E^*$ 为正交投影，$S$ 为独立对偶诱导的 Dirac 上下二旋量翻转。物理旗舰[[7]](#ref-7)（例 6.6）同时给出了配对的结构反例：若人为省去翻转算符 $S$，初时刻 $\theta=0$ 的同轴规范电流读数虽侥幸停在 $+1/2$，但在暗时刻 $\theta=\pi/2$ 会从真实的 $+1/2$ 跌落至 $-1/2$（偏差整整 $1$）。九场方程与多体算符代数由物理旗舰各自的正向构造支付；这里展示的是同一固定母源 $S_\star$ 如何毫无损耗地承载并恢复整座物理大厦。

---

## 5　内生残差请求、同债良基付款与已付程序微分续行

前四节解决了“状态身份从何而来”与“异质对象由谁形成”。但一个停留在静态归属层面的账本仍可能面临质疑：它是不是只在计算结束后跑出来盖章记账？**一本真正的源生账本，必须能从自身尚未付清的语义残差中内生生出下一步计算请求，用自己的语法预算付清同一笔债，并在第二版新增的持续演化闭环（OB12–OB13）中，让已付语法树继续驱动后续同态方法与余链微分。**

### 5.1　非线性源表达式、节点语法计费与残差请求构造

令 $S$ 为任意分拣类型（sorts），每个 $s\in S$ 配备交换群载体 $V_s$ 与变量集 $X_s$；环境 $\Gamma$ 为每个变量指派群元素。源表达式语法树（AST）由五类节点归纳生成：变量、常量、加法、交换群同态的一元线性作用以及双加法（bilinear）作用。记表达式 $a$ 在环境 $\Gamma$ 下的求值为 $\mathrm{ev}_\Gamma(a)$，源内递归定义的环境更新增量（effect）为 $D_a(\Gamma,\delta)$，二者满足精确差分恒等式[[8]](#ref-8)：
$$\mathrm{ev}_{\Gamma+\delta}(a)=\mathrm{ev}_\Gamma(a)+D_a(\Gamma,\delta).\tag{10}$$
对于双加法节点 $B(u,v)$，$D_{B(u,v)}(\Gamma,\delta)$ 完整保留左增量、右增量与非线性交叉项 $B(du,dv)$，绝不将非线性更新错误简化为在 $\delta$ 上单独求值（该交换群有限差分恒等式与高阶语言静态微分[[18]](#ref-18)定理 3.11 及 DBSP 流演算[[19]](#ref-19) §4.1 $\mathbb Z$-集上的双线性公式定理 3.4 一脉相承；下文在此基础上进一步将其接入节点语法扣款、已付语法树恢复与余链微分）。

每个语法树 $a$ 携带自然数**语法费用** $c(a)\in\mathbb N$：变量计 $1$，常量计 $0$，一元作用计子式费用加 $1$，加法与双加法计左右子式费用之和加 $1$。每一步合法原语归约 $a\rightsquigarrow a'$ 保持求值不变且严格消耗一个计费节点 $c(a)=c(a')+1$；完整执行状态 $\sigma=(p,\tau)$ 由当前归约式 $p$ 与自 $a$ 起算的有序已付步进迹 $\tau$ 组成，满足守恒式 $|\tau|+c(p)=c(a)$。

固定一次已准入根发生 $o$，其整账为 $L(o)$，整账写入器 $E_o$ 为每条旧责任行 $e\in L(o)$ 指派目标去向且同债预算单调不增。发生 $o$ 处的**原残差材料**为五元组 $m=(\Gamma,\delta,a,\sigma=(p,\tau),e)$，由此直接定义**字面残差语法树** $r_m$ 与**下一原生请求** $Q_m$：
$$r_m=a+(-\mathrm{id})(p),\qquad Q_m=(\Gamma+\delta,\ r_m,\ e),\qquad c(r_m)=c(a)+c(p)+2.\tag{11}$$
正如例 1.2(b) 手算所示，对平方算例 $a=x\cdot x$、$\Gamma(x)=2$、$\delta(x)=2$ 与已付常量端点 $p=\mathrm{const}\,4$，式 (10)–(11) 给出数值残差 $\mathrm{ev}_{\Gamma+\delta}(r_m)=12=D_a(\Gamma,\delta)$ 与语法预算 $c(r_m)=3+0+2=5$。

### 5.2　全未来模型中的残差等价与内生请求出生（OB8）

<a id="thm-5-1"></a>
**定理 5.1（全未来残差等价与下一原生请求生成[[8]](#ref-8)）。** 固定任意源配置族 $\mathcal F$、完整初始帧 $I$、程序配置 $\mathsf{cfg}$ 及语言同一性 $\mathsf{cfg.LowVar}=X$。源运行内生生成一列严格递增且在离散演化步上共尾的准入停点（按 $n\in\mathbb N$ 编号）。对每个停点 $n$，记 $q_n$ 为第 $n+1$ 个完整准入包从根当前态生成的原生请求，$b_n$ 为同次已付边界词 $[a]-[p]$ 在整系数自由模中的准确运输。则对**任意**有限允许作用词 $h$ 与**任意**原站位 $j\in\mathbb N$，成立全未来读出恒等式：
$$\mathrm{Obs}_j\bigl(A_h(\iota_{n+1}[q_n.\mathrm{AST}])\bigr)=\mathrm{Obs}_j\bigl(A_h(\iota_{n+1}b_n)\bigr),\tag{12}$$
其中 $\iota_{n+1}$ 为站位依赖直和嵌入，$A_h$ 为允许源作用词的逐字迭代，$\mathrm{Obs}_j$ 读取站位 $j$ 处的完整“旧值—增量效应”对。同时，实际下一准入当前态精确等于出生程序的规范后继，$q_n$ 由沿该当前态等式运输的整份残差材料直接生成，旧责任行与新生行的去向均取自同一次整账写入。

**证明的承重步骤。** 在整系数形式表达式自由模中定义**全环境零子模** $Z=\{w:\forall\Theta,\ \mathrm{ev}_\Theta(w)=0\}$。由求值线性延拓，对任意残差材料恒有
$$[r_m]-\bigl([a]-[p]\bigr)\in Z.\tag{13}$$
注意落入 $Z$ 的是“字面残差语法树与形式差词的差”，而非 $r_m$ 本身（如 $a=x,p=0$ 在 $x=1$ 处求值为 $1\neq0$）。对任意 $w\in Z$，由式 (10) 知其在任意 $(\Gamma,\delta)$ 下的旧值与新值皆为 $0$，故增量效应亦为 $0$，配对求值库存恒为 $(0,0)$。由于字面配对提升 `liftExpr` 在配对环境 $\mathrm{pairEnv}(\Gamma,\delta)$ 下的求值恰为 $(\mathrm{ev}_\Gamma,D(\Gamma,\delta))$，且任意配对环境均可分解为两坐标构成的 $\mathrm{pairEnv}$，故配对提升保持子模 $Z$；语言等式运输与完整包运输同样保持 $Z$。因此每一步站位源作用均将第 $k$ 站位的 $Z$ 送入第 $k+1$ 站位的 $Z$。对有限作用词 $h$ 的长度归纳，立得一切允许作用词与站位上的 $\mathrm{Obs}_j$ 对式 (13) 之差恒不可见，即式 (12) 成立；再复合出生包注册语法树恒等式 $q_n.\mathrm{AST}\equiv r_{m_n}$ 即完成认回（详见附录 C.1）。$\square$

### 5.3　同债严格扣款、零回填结算与后缀完成交付（OB8）

将完整“旧值／增量效应”配对读口源内安装至 $\mathcal F$ 的计算读口（保持原读口、写入器、库存回调与源种子不变），记所得派生配置族为 $\widehat{\mathcal F}$[[8]](#ref-8)。

<a id="thm-5-2"></a>
**定理 5.2（源生效应求值与同债严格扣款）。** 在 $\widehat{\mathcal F}$ 任一准入停点由原残差材料读出的同一当前态上，设 $\epsilon=D_a(\Gamma,\delta)$、$Q=c(r_m)$，$b$ 为该停止帧生成的出生对象。则 $b$ 的注册输入精确等于 $Q_m$，下一规范请求求值等于 $\epsilon$；$b$ 已付出生首步，剩余语法预算满足 $Q-1>0$；其实际动作必落入已付归约分支，生成同债付款见证 $\pi_b$——目标行唯一锁定原数学债务谱系、预算严格扣减（$Q-1\to Q-2$）、无任何预算回填，并异质相等于整账后继中原责任行的准确去向。

**证明。** 停止回执保证已付端点为常量 $p=\mathrm{const}\,v$，由已付迹可靠性 $v=\mathrm{ev}_\Gamma(a)$ 及式 (10)–(11) 立得
$$\mathrm{ev}_{\Gamma+\delta}(r_m)=\mathrm{ev}_\Gamma(a)+D_a(\Gamma,\delta)-v=\epsilon.\tag{14}$$
由式 (11)，$Q=c(a)+c(p)+2\ge2$；出生帧在源运行一步后读取，首步已消耗 1 个节点，故注册时钟给出剩余费用 $Q-1\ge1>0$。倘若此时实际动作落入数学结算分支，结算前提要求剩余费用为 $0$，矛盾！故分支消元必交出真实已付步，使剩余预算严格减一且不增补。因扩展账主张采用不相交和类型（原数学债居左支，继承旁支居右支），同债目标唯一；对有限访问步数归纳即认回整账写入去向（详见附录 C.2）。$\square$

<a id="thm-5-3"></a>
**定理 5.3（后缀完成结算、带回执回答与规范后继交付）。** 沿定理 5.2 记号，从 $b$ 的当前态继续推进 $Q-1$ 步剩余历史，精确抵达剩余费用为 $0$ 的源完成态，完成值等于 $\epsilon$。此时实际动作唯一落入数学结算分支，整账目标编译器对该完成事件生成债务准入动作 $G$，在同一次交付中给出：带原回执的回答、规范因果“回答与后继”、旧责任行与出生行在同一次整账写入中的各自去向，以及后继合法性证明；下游核验器在同一消元动作中直接读取完成值等于已付状态求值及已付迹效应的全部恒等式。

**零数值效应照付语法费，新生责任绝不替旧债续杯。** 取常量表达式 $a=\mathrm{const}\,v$ 与已付端点 $p=\mathrm{const}\,v$：任意环境变化下数值增量皆为 $\epsilon=0$，但式 (11) 生成的下一请求仍为 $r=\mathrm{const}\,v+(-\mathrm{id})(\mathrm{const}\,v)$，语法预算 $Q=2$——出生首步消去负号留预算 $1$，下一拍实际付款执行加法节点严格扣减 $1\to0$ 产出 $\mathrm{const}\,0$。数值效应为零绝不抹掉这两步真实归约及其付款谱系；若同一发生随后再发起新请求，新请求进入和类型右支自付首步，旧债零预算行绝不被暗中续杯。这与以指数算子控制带标记公式复制与舍弃的线性逻辑[[12]](#ref-12)、以可经线性规划推断的信用断言及可失败环境请求 `acquire`（§3.6）验证堆程序的摊销分离逻辑[[13]](#ref-13)，以及利用多项式半环同态分解正关系查询求值的溯源半环[[17]](#ref-17)形成了清晰的职责区分。

### 5.4　已付语法树持续方法作用与整词逐原语余链微分续行（OB12–OB13）

第一版至此停在单轮请求的完成交付上。第二版合入两项关键推进（**OB12、OB13**）：**刚付清的语法树不是作废收据，而是下一轮代数方法作用与同调微分演化的直接活性输入。**

为什么已付结果能跨共尾停点无损取回？观察停止帧出生的两层残差构造：首次残差具有形状 $a+(-\mathrm{id})(p)$，经 $Q$ 步归约付清后，其完成端点 $p_\star=\mathrm{const}\,\epsilon$ 在下一出生帧被再次包裹为形如 $\bigl(a+(-\mathrm{id})(p)\bigr)+(-\mathrm{id})(p_\star)$ 的残差表达式。定义语法提取算子 $\mathsf{retainedCode}$：匹配外层加法右支的已付子式 $p_\star$ 并外施一次负同态，得到 $(-\mathrm{id})((-\mathrm{id})(p_\star))$。由于交换群上双负号求值恒等（$-(-u)=u$），无需任何外部缓存表即可从残差语法自身完整恢复已付语法树！

<a id="thm-5-4"></a>
**定理 5.4（已付语法树恢复、跨共尾同态方法持续执行与统一四面安装，OB12）。** 设 $f:W_s\to W_s$ 为任意**预先固定**的交换群加法同态，记阶 $n$ 上的配对递归提升同态为 $f^{(0)}=f$、$f^{(n+1)}=f^{(n)}\times f^{(n)}$：

1. **单次出生转移的全称无损恢复与统一四面安装**：对**任意**分拣交换群族 $W$、**任意**源配置族 $\mathcal F$ 及派生方法运行中的任意准入包 $\mathsf{pkt}_k$，提取算子 $\mathsf{retainedCode}$ 在下一出生包上异质相等于前一包已付端点语法树的双负号像（`after_native_retained`），其求值精确恢复前一包完成结果 $v_k$（`after_native_value`）；下一准入包在零增量配对环境 $\mathrm{pairEnv}(\Gamma,0)$ 下实际执行线性方法节点，输出满足精确递推
$$v_{k+1}\;\doteq\;\bigl(f^{(n_k+1)}(v_k),\ 0\bigr)\qquad(\texttt{after\_native\_whole\_action},\ \texttt{actual\_method\_step}),\tag{15}$$
同时当次完整查询写入迹（`completeQueryWritten`）的每一个事件均经该包自身的库存回调写入出生库存 `writtenStock`（`actual_complete_query_written`），并在发射器前安装**代数、组合、拓扑与逻辑**统一四面（`UnifiedFourFace`，同源携带**关系**与**余链**切面），其切面根读满足 $\mathsf{face.rootRead}=\mathsf{packet}$。
2. **前瞻源运行上的跨全体共尾停点持续闭合**：固定完备复内积空间（Hilbert 空间）$\mathcal H$、活根闭包、时序访问、识别结构（将根发生映入 $\mathcal H$ 读数空间的识别数据）及障碍演化演算诱导的前瞻配置族与源运行 `sourceRuntime`，在每一个共尾准入停点 $k\in\mathbb N$ 及任意有限更新视界 $U\in\mathbb N$ 上，上述式 (15) 同态步进、查询迹回调与统一四面安装在封闭询问场上精确迭代推进 $1+d_k$ 步连接相邻准入停点（`cofinal_paid_method_faces`、`finite_paid_method_faces`）。

定理 5.4 处理的是跨周期的值与语法树传递；定理 5.5 则进一步打开单次整词执行内部的**每一步中间原语归约**，证明代数关系与余链微分同样由这条真实执行链亲自生成（**OB13**）。

<a id="thm-5-5"></a>
**定理 5.5（整词逐原语步进回放与库存边界—余链微分同源更新，OB13）。**

1. **全称上下文逐原语回放与精确计费**：对**任意**关系网络 $N$、**任意**完整活源过程 $\mathcal P$、分拣交换群载体、环境读映射及非线性源表达式，上下文词执行器 `WordExecution` 将每一个原语归约步 `Step` 结构递归嵌入上下文环境生成完整回放迹，其迹长精确等于代入绑定后的剩余语法预算（`forward_charge`）。在封闭算术—Fock 源运行 `sourceRuntime` 的任意起始步 `start` 与完成回执确定的停点 $\mathrm{stop}=\mathrm{start}+\mathrm{receipt}.1$ 上，原已付迹与本次回放暴露（`exposure`）双双经出生回调写入当次 `birthStock` 并进入下一完整查询（`native_replay_written`、`native_replay_next_query`）。
2. **关系边界、链态射、余链微分与物理读回同停点闭合**：在停点 $\mathrm{stop}$ 上，记源回放生成的整系数关系词为 $\mu_{\mathrm{stop}}=\mathsf{sourceRelations}(\mathrm{stop})$，当次库存直接构造的闭包边界元为 $\partial_{\mathrm{act}}=\mathsf{actualBoundary}(\mathrm{stop})$，自然数历史生成的余链复形为 $\mathcal C^\bullet=\mathsf{actualCochain}(\mathrm{stop})$，代换链复形态射为 $\tau_1$，当前配对环境为 $E_{\mathrm{stop}}$，代换源环境为 $E_{\mathrm{src}}=E_{\mathrm{stop}+1}$。则成立同源四重恒等式：
$$\bigl(d_{\mathcal C}^{0,1}(\partial_{\mathrm{act}})\bigr).\mathrm{val}\;=\;\partial_{\mathrm{act}}.\mathrm{val}\;=\;\mathsf{relMap}_{E_{\mathrm{stop}}}\bigl(\tau_1(\mu_{\mathrm{stop}})\bigr)\;=\;\mathsf{subst}_{\mathrm{pair}}\bigl(\mathsf{relMap}_{E_{\mathrm{src}}}(\mu_{\mathrm{stop}})\bigr),\tag{16}$$
且完备化投影精确湮灭该微分元 $\Pi_{\mathrm{comp}}(d_{\mathcal C}^{0,1}(\partial_{\mathrm{act}}))=0$；统一四面求值的规范余像算子将源关系词的标准余像类映为 $\partial_{\mathrm{act}}$ 的余像类并与对偶求值兼容交换（`actual_coimage_boundary`、`actual_coimage_differential`），发生树擦除投影完整恢复原展开树且根第二分量精确读回 $\mathsf{face.rootRead}$（`source_occurrence_erasure`、`source_occurrence_readback`）；同时在同一停点指标 $\mathrm{stop}$ 处完成物理运行下一拍源态与强迫迹读回（`physicalReadback`），并交付保持生成活法的同停点整账后继及 $\mathrm{receipt}.1+1$ 步封闭询问运行段（`actual_relation_cochain_method`）。

**证明思路（完整推导见附录 C.3–C.4）。** 定理 5.4 利用前缀已付步保持注册输入表达式不变（`paid_prefix_expression`），在结算出生处拆出双负号语法树，再由 $\mathrm{eff}(\text{expr},\Gamma,0)=0$ 导出式 (15)，并沿库存并行保留引理 `birth_keeps_callback` 将查询迹并入出生库存。定理 5.5 对全部九类原语归约步（变量绑定、常量加法／线性／双线性及递归子树归约）作结构归纳构造回放迹，绝不用“首尾求值相等”冒充中间步迹相等；随后利用任意执行迹首尾伸缩边界律、代换交换方块 `boundary_square` 与自然数余链首阶微分恒等式 `natComplex_d_zero_one` 串起式 (16)，最后由单构造子展开树的函子律 `map_map`、`map_id` 恢复原发生展开并完成同停点物理读回与整账后继拼接。$\square$

<a id="ex-5-6"></a>
**例 5.6（贯穿平方算例上的同态续行与三步余链边界验算）。** 将例 1.2(b) 的平方算例代入定理 5.4 与 5.5，高阶机制立即可用纸笔算穿：

- **同态方法续行（OB12）**：第一轮残差请求 $r_m=x\cdot x+(-\mathrm{id})(\mathrm{const}\,4)$ 在新环境 $x=4$ 下经 $4$ 步后缀结算为已付端点 $p_\star=\mathrm{const}\,12$（配对层为 $(12,0)$）。下一出生帧注册输入形如 $r_m+(-\mathrm{id})(\mathrm{const}\,(12,0))$，$\mathsf{retainedCode}$ 提取出 $(-\mathrm{id})((-\mathrm{id})(\mathrm{const}\,(12,0)))$，在零增量配对环境下读回 $(12,0)$。取预定同态 $f(u)=3u$，式 (15) 在下一共尾停点直接执行线性节点交出 $((3\times12,3\times0),\,0_{W^2})=((36,0),\,0_{W^2})$（其中 $0_{W^2}=(0,0)$ 为配对群零元），并把本次查询迹悉数记入出生库存。
- **逐步回放与余链边界（OB13）**：在环境 $x=4$ 下求值 $x\cdot x$，原语步进回放依次经历三步：绑定左变量 $[x\cdot x]\to[4\cdot x]$，绑定右变量 $[4\cdot x]\to[4\cdot 4]$，常量双加法归约 $[4\cdot 4]\to[16]$。三步暴露全部写入库存，其在整系数自由模中的有号关系和伸缩相消后给出显式边界 $\partial_{\mathrm{act}}=([x\cdot x]-[4\cdot x])+([4\cdot x]-[4\cdot 4])+([4\cdot 4]-[16])=[x\cdot x]-[16]$，经求值同态映为 $4^2-16=0$（即余像微分与完备化投影湮灭判据），而保留在库存中的三步链条本身正是区分“真实执行过 $x\cdot x$”与“直接偷填答案 $16$”的不可伪造代数凭证（图 3）。

![图 3｜残差请求、同债付款与已付语法树微分续行闭环](figures/paid-continuation-v2.svg)

**图 3｜残差请求、同债付款与已付语法树微分续行闭环。** 上排（OB8）：全未来残差生成原生请求，正语法预算强制执行同债严格扣款与零回填结算，后缀完成一并交付效应值 $\epsilon$、带回执回答、整账去向与规范后继。中排左（OB12）：`retainedCode` 经双负号 $-( -p_\star)$ 从残差语法恢复完整已付 AST，在后续共尾停点持续执行同态提升 $f^{(n+1)}$ 并将完整查询迹写入出生库存、安装统一四面与关系余链切面。中排右（OB13）：`WordExecution` 逐原语回放源词并精确计费，使源关系 $\mu$ 同步更新库存边界 $\partial$、$\mathsf{relMap}(\tau_1\mu)$、余链微分 $d^{0,1}(\partial)$ 及物理读回。下排标示同次整账写入与新旧债务谱系的严格隔离。

---

## 6　根植表达破产、零公理初始余面升维与双行同首写修订

当一套既有理论语言在某个真实问题面前捉襟见肘时，科学演化要求扩充语言。然而，理论修订历来是最容易混入账外特权的灰色地带：**一次“修宪”会不会只是给旧反例换个新名词，顺手把尚未清偿的历史旧债一笔抹销？** 本节的全部最小余面与有类型同首写恢复构造均在**零公理构造性内核（T0，`#print axioms = []`）**中闭合，把“破产生成什么”“容许修订如何分解”以及“旧债与新责任由谁处置”拆成三条严格可检的定理（**OB9**）。

### 6.1　根植双空破产与零公理范畴初始余面

并非随便一句“我想换套理论”都叫合法修订触发器；只有当既有法则在某次真实根发生处遭遇**表达与合法实现双空**，修订通道才依法开启。

<a id="def-6-1"></a>
**定义 6.1（根植表达与实现双空破产）。** 固定旧源生权威根 $R_{\mathrm{old}}$、一次时序访问 $v$、旧理论状态 $\Theta$ 及支撑 $s$ 上的障碍 $o$。称 $\Theta$ 在 $o$ 处发生**实际表达破产**，若 $\Theta$ 对该障碍需求的表达纤维与合法实现纤维同时为空（双空证明）。称该破产在访问 $v$ 处**根植**（`RootedActualExpressibilityFailureAt`，记作 $\eta$），若它同时携带以下同源对齐证明：$\Theta$ 恰为 $R_{\mathrm{old}}$ 当前源纪元所拥有的法则面；破产载荷等于根在 $v$ 处已安装投影切面的激活读数及规范令牌；源拥有的障碍演算在 $o$ 上发出规范事件且其支撑等于访问 $v$ 的支撑；旧根开放账中存在唯一对应的需求责任行 $e$，其理论审计处置与整账编译处置严格交换，并携带 $e$ 在 $v$ 处的因果权威及因果后继[[6]](#ref-6)。该类型的构造子对外部调用方封闭，只能由根投影面内生铸造。

<a id="thm-6-2"></a>
**定理 6.2（阻滞生成的零公理最小余面、范畴初始性与唯一态射分解）。** 在零公理内核（`#print axioms = []`）中，每个根植双空破产 $\eta$ 无需任何外部选择公理，直接生成最小余面扩充（`root_obstruction_generates_minimal_coface`）：

1. **坐标扩充与旧面定理存续**：在旧后继支撑的完整开放账 $L_+$ 上生成不交并载体与初始预算函数
$$C_\eta=L_+\sqcup\{\star_\eta\},\qquad \beta(\mathrm{inl}\,e)=\beta(e),\quad \beta(\mathrm{inr}\,\star_\eta)=0.\tag{17}$$
旧开放账经左注入 $\mathrm{inl}$ 嵌入 $C_\eta$，构造性回缩映射将新点 $\star_\eta$ 送回 $\eta$ 自带的目标需求行，故旧行先嵌入再回缩恒等恢复（`backward_forward`），而新点 $\star_\eta$ 无任何旧原像；关联（incidence）与主张（claim）坐标同样各并入唯一无旧原像的新生成元，新主张在新支撑上成立并携带以 $\eta$ 为索引的唯一语义变化，同时每条旧表达定理在嵌入旧面上原样存续。
2. **范畴初始性与唯一忠实单射分解**：对**任意**容许余面修订 $\mathcal A$（即对旧开放账、旧关联与旧主张提供构造性回缩，并给出无旧原像、预算为零的新生成元且继承行预算单调不增的任意扩充），存在规范忠实余面态射 $F:\mathcal C_\eta\to\mathcal A$（`minimal_coface_initial`）——其账行、关联与主张三个坐标映射全部**单射**，严格保持旧面嵌入与新生成元且不增加任何行预算；进而在全体忠实余面态射类中，$F$ **逐点唯一**（`minimal_coface_factorization_unique`）。

**证明。** 不交并左右构造子互斥直接排除 $\star_\eta$ 的旧原像；回缩在 $\star_\eta$ 处的取值直接读取 $\eta$ 已携带的需求目标行，无需调用选择公理另挑旧行。对任意容许修订 $\mathcal A$（设其旧行嵌入为 $j$、新生成元为 $a$），定义 $F(\mathrm{inl}\,e)=j(e)$、$F(\mathrm{inr}\,\star_\eta)=a$（关联与主张映射同式）。单射性分三形核验：左—左相等经 $\mathcal A$ 的构造性回缩还原为原旧行相等；左—右或右—左相等直接触发 $\mathcal A$ 中“$a$ 无旧原像”的矛盾；右—右仅含单点 $\star_\eta$。唯一性：任何保持旧嵌入与新生成元的候选态射在 $\mathrm{inl}$ 与 $\mathrm{inr}$ 两支上的取值已被定义完全锁死，模式匹配一步自反成立（`rfl`）。$\square$

定理 6.2 给出了理论升维的最小几何法则：最小余面 $\mathcal C_\eta$ 并不替未来科学钦定唯一的新动力学方程，但它确立了**一切合法扩充都无法绕开的范畴初始必经门**——新理论可以比 $\mathcal C_\eta$ 更丰富，但必须以唯一忠实单射方式完整包含它。这与经典的 AGM 理论变化框架[[20]](#ref-20)处理不同层面的问题：AGM 在**固定命题语言**内以部分交收缩 $K\dot{-}p=\bigcap\gamma(K\bot p)\subseteq K$（通过选择函数 $\gamma$ 选取极大不蕴含子集）去掉对指定命题 $p$ 的蕴含，并在面对冲突输入 $p$ 的修订语境中经 Levi 恒等式 $K*p=\mathrm{Cn}((K\dot{-}\neg p)\cup\{p\})$ 先收缩 $\neg p$ 再加入 $p$ 以恢复一致性；而定理 6.2 面对的是**旧语言本身表达与实现双空破产**，完全不调用选择公理或外部选择函数，直接在零公理下扩张坐标载体并保证全部旧表达定理与历史开放账无损迁入。

### 6.2　结构锚定修订与双行同首写承接：修宪绝不销账

<a id="def-6-3"></a>
**定义 6.3（有类型语义修订与结构锚定）。** 针对根植破产 $\eta$，一份**有类型语义修订** $\Xi$ 给出：新旧世界关系网络之间的非保守翻译（旧身份与旧开放账经构造性回缩存续，新增坐标允许无旧原像）；新词汇与携带终账交接律的新活根；回缩到旧根后继支撑的新初始支撑；保翻译主张且预算不增的旧目标开放账嵌入；保持规范发射的旧后继发生与新初访发生双向对应；编译为**非终账首次写入**（`CanonicalFirstRootWriteAt`）的新根初访整账演化；以及一条初始预算为 $0$、无旧原像且携带语义变化的新方向行，使得**每一条继承旧行与该新方向行共同构成首写的全部生成初始行**。

称 $\Xi$ 具备**结构锚定**（形式声明称 `FieldGrounded`），若满足以下两类锚定之一：(i) **精确极小锚定**，即新网络、法则面、翻译、初始支撑、旧账嵌入、新行与语义变化逐字段认回定理 6.2 的最小余面 $\mathcal C_\eta$；或 (ii) **带拆分的丰富忠实锚定**，即新法则面为新网络的根语义，新根首写编译器**实际选中**一次严格拆分（由同一迁入旧责任行拆出两条相异子行，子预算均严格低于父行），且初始账除迁入旧账与新方向行外不含任何休眠旁路行。

<a id="thm-6-4"></a>
**定理 6.4（初始方向唯一分解与首写汇合[[6]](#ref-6)）。** 每份有类型语义修订 $\Xi$ 自然诱导一个容许余面修订及其唯一忠实单射分解 $F_\Xi$；$F_\Xi$ 将最小余面新点 $\star_\eta$ 精确映至 $\Xi$ 的新方向行，且该行恰由 $\Xi$ 的非终账首写直接消费。

<a id="thm-6-5"></a>
**定理 6.5（迁入旧故障行与新增方向行的同首写权威承接与分别处置）。** 设针对根植破产 $\eta$ 的有类型修订 $\Xi$ 具备结构锚定。则：

1. **各自独立取得初始权威**：迁入的旧故障行 $\mathrm{inl}(e)$ 与新增方向行 $\star_\eta$ 分别由各自在新初访生成补片中的成员资格取得初始因果行权威；
2. **穿越同一枚首写后继**：两行经过**同一次**由新根编译器生成的非终账首写后继等式，各自取得首写目标访问处的因果权威；
3. **分别受领处置并共享下一当前**：新根自身的因果“回答与后继”编译器在首写目标访问处分别产出旧故障行与新方向行的回答与后继（更一般地，首写中的每一条生成初始行均获得各自的回答与后继），且它们的规范下一当前**完全相同**；
4. **封死事后调包故障行**：迁入旧行定义性等于旧根该次发生上的需求行 $e$ 及源障碍演算规范事件的需求行；恢复层接口不设任何“事后补交或改认故障行”的参数槽。

若 $\Xi$ 同时由固定询问程序在该准确发生处实际发射，上述联合令牌即直接构成该次询问的权威修订处置。

**证明。** 对每条初始生成行，由其在新根初访生成补片中的位置直接构造初始因果权威（构造函数私有，杜绝外部伪造）；取出新根非终账首写的唯一后继等式（`CanonicalFirstRootWriteAt` 为单元素子集类型 `Subsingleton`），对旧行与新行的初始权威施加同一整账行续接映射，即得目标访问处的两份行权威；再分别调用新根的因果回答与后继编译器。由于所有行的下一当前均由同一修订根在同一首写目标访问处读出，故定义性全等。第 (4) 款直接复合定义 6.1 的需求行对齐等式与规范发射等式（详见附录 C.5）。$\square$

定理 6.5 从制度与逻辑根部切开了两件经常被混为一谈的操作（图 4）：**登记异常（升维）**只是把最小新方向连同全部未清旧账一起写上新根的第一页，它授予的是继续表达的资格，绝非结清旧债的免死金牌；**实际清偿（恢复）**则必须由新根自己的分类器在首写之后逐行裁决——旧故障行究竟在新语言中被实质解决还是继续挂账追索，与新语义方向如何继续演化，是并列推进、绝不允许互相冲抵的两笔账。

<a id="ex-6-6"></a>
**例 6.6（二元支撑上的两步带债修订[[6]](#ref-6)）。** 正如例 1.2(c) 所预演：旧世界支撑集为 $\{\mathrm{false},\mathrm{true}\}$，各有一笔预算为 $2$ 的开放责任，旧理论在 $\mathrm{true}$ 处双空破产。首拍运行发射精确极小锚定修订 $\Xi$：最小余面并入新支撑 $\star_\eta$，初始账含“迁入旧行（预算 $2$）”与“新方向行（预算 $0$）”；新根以 $\mathbb N$ 为当前态、$n\mapsto n+1$ 为原生写入。首写 $0\to1$ 在同一动作中将两行（执行 $2\to2$ 与 $0\to0$ 保预算转移）送达首写目标访问 $1$，新根编译器在该目标访问处裁决两行并按 $n\mapsto n+1$ 给出共同下一当前 $2$；第二拍在同一新根访问 $2$ 处直接回答单点值并推进至 $3$。语言维度成功扩张，而预算为 $2$ 的历史责任跨越修订边界毫发无损。

![图 4｜零公理初始余面升维与双行同首写承接](figures/revision-ledger-v2.svg)

**图 4｜零公理初始余面升维与双行同首写承接。** 上排：根植双空破产 $\eta$（表达与实现纤维皆空、规范发射事件与需求行 $e$ 对齐）在零公理内核下自动生成范畴初始余面 $C_\eta=L_+\sqcup\{\star_\eta\}$，任意容许修订均经唯一忠实单射态射 $F$ 接收分解。中排虚框：由固定询问程序在准确发生处实际发射并经结构锚定的有类型修订 $\Xi$。下排：迁入旧故障行 $\mathrm{inl}(e)$ 与新增方向行 $\star_\eta$ 各自从初访补片取得初始权威，汇入朱红标示的**同一次非终账首写**，再由新根分类器分别交付回答与后继并共享同一规范下一当前；图中不存在任何“异常被改名吸收”的旁路箭头。

---

## 7　长计算窗口与逆残差纠正的全账接力

第 5 节的同债付款与微分续行不仅适用于短表达式，同样无损扩展至多阶段算子分析计算（**OB10**）。在整账法[[8]](#ref-8)（定理 14.1–14.2）与 Riesz 源微积分共用的有限窗口解析链上，首轮窗口执行在解码前将**前向库存、逆残差、二次均值与余链**四份完整执行迹安装入账；下一纠正帧直接从上一轮真实写入中读出逆残差 $\eta$，在完整保留上述四份历史旧迹的同时，令 $s=\iota(\nu)$、$r=\iota(\eta)$（其中 $\nu$ 为首轮带限资格源元，$\iota$ 为式 (18) 的四分量典范嵌入），将字面纠正项 $\kappa=\mathrm{const}\,s+(-\mathrm{id})(\mathrm{const}\,r)$（计费节点 $2$）代入完整窗口程序，生成新库存迹、纠正迹、同债付款与规范后继，并在全部允许未来作用词与全部站位上继续保持请求与已付边界等价。

该构造对列明的原条件输入类型**全称成立**——该输入类型包含一枚携带源 zeta 实现零点条件 $\zeta_{\rm src}(z)=0$、非平凡性 $\forall n\in\mathbb N,\ z\neq-2(n+1)$ 及右半平面条件 $\operatorname{Re}z>1/2$ 的观察回执（若 Riemann 猜想成立，该输入类型无居民，对应定理空真成立；本文将其严格作为对该输入类型的全称接线合同使用，不对输入类型是否非空作经验断言）。完整解析载体、语法费用 $4k+3$ 与两次发生的嵌套消元定理在附录 E（定理 E.1）中自足给出。

---

<a id="sec-8"></a>
## 8　三层可机械核查的失败责任与学术坐标

一项真正锋利的基础原则，绝不靠“永远立于不败之地”的话术自保，而是把每一条结论精准绑定到一枚可下锤检验的等式或类型签名上（**OB11**）。本节明确列出推翻或修正本体系各部分所需的精确反例形状，并将全文置于四大经典思想与计算传统的清晰坐标中。

### 8.1　三层失败责任定位律

面对任何理论质疑或经验偏差，核查严格按以下三道独立门禁分层定位：

1. **第一层：结构身份、根读恒等与普遍形成恢复门禁。** 检验靶标为引理 2.2 的 $\mathsf{RootRead}(o)=o$ 与发生单射、定理 2.8 的完整活当前单射、定理 4.2 的左逆恢复等式 (7)–(8) 以及定理 4.4 的有限 $\hbar$ 配对等式 (9)。由于上述形式定理均已通过 Lean 4 内核无占位审查（T0 为零公理 `[]`，T1 为标准三公理），对第一层的实质攻击只有两种有效形态：要么指出本文自然语言陈述与附录 D 所列形式声明之间存在翻译偏差（命中则直接修正对应自然语言命题及其下游表述，形式定理保持不变）；要么指出某具体研究对象违反了定义 2.1 的全事件库存准入前提（注意定理 4.2 已对 `Type 0` 原准入接口上的**全体**源生权威根 $\forall R$ 全称闭合）。
2. **第二层：同债付款、已付语法树微分续行与同首写修订门禁。** 检验靶标为全未来等价式 (12)、源效应等式 (14) 与严格扣款、定理 5.4 的双负号已付 AST 同态递推式 (15)、定理 5.5 的库存边界—余链微分四重等式 (16)，以及定理 6.5 中旧故障行与新方向行共用的那一次首写。这一层审查的核心是**同一性（sameness）**：扣款是否确实落在原债务谱系而非另开新户？同态方法与余链微分是否确实读取当次已付语法树与逐原语回放迹，而非靠端点值相等蒙混过关？新旧两行是否确实穿越同一次首写？凡在原输入类型内构造出一例使消费者读出旁路对象的情形，即精准击穿该条主张。
3. **第三层：领域解释映射与经验检验合同门禁。** 将形式源对象解释为具体时空场、手征费米子、分子能谱、临床神经信号或社会制度规则的映射，连同其定量实验盲测，各归属同系列对应专篇的领域合同。一旦某项物理或经验读数被实验反驳，必须直接修正该领域的解释映射或模型预测——它既不能靠第 2 节的零公理反魔法定理强行免责，也不会反向推翻第 5 节的同债语法付款定理。

### 8.2　禁止给失败换名字逃入修订通道

三层定位律附带一条硬性方法论禁令：**绝不允许把一条被证伪的具体等式改名为“表达破产”，从而混进第 6 节的理论修订通道洗白自己。** 原因完全是形式化的：开启定理 6.2 与 6.5 的修订通道必须先交出定义 6.1 的全部根植字段——双空纤维证明、源障碍演算的规范发射事件、对齐的开放需求行以及交换的整账处置；而一条算错的数值等式或被实验推翻的预测根本不具备规范障碍发射与交换处置字段，只能按受反驳层级的原事实直接认错修正。反过来，依据定理 3.3，尚未完成安全核验的压缩观察通道也绝不允许默认签发安全认证。

### 8.3　古典问题源流与四大现代技术前沿的精确接缝

为把本文每根承重柱的贡献边界交代清楚，我们将相关工作核读拆成两层（原始文献的精确读取章节与定理范围记录于 `literature.md`）：表 2 对照提出“充足理由、二值物理追问、通信比特与携带证明准入”的四大古典源头；表 3 则逐柱对照近四十年在**依赖／单值类型论与资源逻辑、量子信息重构与构造子理论、溯源半环与有限差分增量计算、以及 AGM 理论收缩与修订**四条现代技术路线上的代表性框架。

**表 2　四大古典问题源流与本文构造性兑现的精确比较。**

| 经典文献与核心命题 | 原文关注的问题域 | 本文共享的接缝 | 本文新增的正向构造与严格区分 |
| --- | --- | --- | --- |
| **Leibniz**《单子论》§§31–38[[1]](#ref-1)：充足理由律 | 为何任何事实如此而非别样；偶然真理序列的终极根据 | 拒绝“无来由的裸差异”直接取得实在地位 | 不诉诸偶然序列之外的神学终极实体；在零公理内核中将结构根据兑现为可投射的登记发生 $\mathsf{occ}(w)$ 与活当前单射 $\iota(s)$（同时关系或全局约束均可充当结构身份，无需更早时间前因） |
| **Wheeler** (1989)[[2]](#ref-2)：“It from Bit” | 物理存在意义经由仪器介导的是／否二值问答生成 | 二值问句与物理实在资格的深层关联 | 本文二值问句判别“账外差异能否准入”而非单次测量比特；观察者与测量仪器自身同在母源 $S_\star$ 中生成，不靠外部问答赋予世界存在，且局部观察不可见不消灭已登记发生（定理 3.3） |
| **Shannon** (1948)[[3]](#ref-3)：通信数学理论 | 随机变量不确定性的对数熵度量与信道编码容量 | 二进制位（bit）作为最简二值区分单位 | 严格区分**二值资格判准**、**节点语法计费**与**统计香农熵**：恒取“否”的确定性判准其统计熵为 $0$，而零数值效应请求（$\epsilon=0$）仍须支付正整数语法归约预算（§5.3） |
| **Necula & Lee** (1996)[[4]](#ref-4)：携带证明代码（PCC） | 接收方从收到代码重建安全谓词并核验附带证明以决定执行资格 | 准入资格由机器可检的形式证明现场支付，而非信任外部签名 | 从单次代码安全谓词升级为全生命周期源生合同：将根发生、全事件库存、同债严格扣款、已付语法树余链续行与破产首写承接锁入同一条依赖链 |

**表 3　四柱主定理与四大现代形式、物理、计算及修订框架的逐柱技术对比。**

| 承重柱与现代框架 | 代表性原文献与核心机制 | 原文献关注域与前提结构 | 本文的正向推进与严格区分 |
| --- | --- | --- | --- |
| **柱 I · 类型身份与资源纪律** | **Martin-Löf** (1984)[[10]](#ref-10) $\Sigma$ 投影；**HoTT** (2013)[[11]](#ref-11) 单值公理；**Girard** (1987)[[12]](#ref-12) 线性逻辑；**Atkey** (2011)[[13]](#ref-13) 摊销分离逻辑；系统工具 **Lean 4**[[9]](#ref-9) | [[10]](#ref-10) 第 32 页采用相等反射；单值公理处理同一宇宙内的类型等价与类型相等 $(A=_{\mathcal U} B)\simeq(A\simeq B)$；[[12]](#ref-12) 以指数算子控制带标记公式的复制与舍弃；[[13]](#ref-13) 以可经线性规划推断的信用注解与可失败环境请求 `acquire`（§3.6）刻画资源 | 在内涵内核上经本稿审计回执锁定 T0 空公理闭包 `[]`；状态身份由单构造子展开树与登记发生 $\mathsf{occ}(w)$ 判定；语法预算由残差语法树内生决定，在和类型上强制同债扣减且不对原债增补预算，并以 8 项 `#guard_msgs` 防火墙拦截旁路激活 |
| **柱 II · 物理重构与系统精化** | **Chiribella 等** (2011)[[14]](#ref-14) 五公理加纯化公设；**Deutsch & Marletto** (2015)[[15]](#ref-15) 构造子理论；**Abadi & Lamport** (1991)[[16]](#ref-16) 精化映射 | [[14]](#ref-14) 采用一般操作概率框架加纯化导出量子论；[[15]](#ref-15) 以任务可能／不可能与互操作性原理（原理 III）表述信息定律；[[16]](#ref-16) 在满足条件时扩充低层规范（增补保持可见行为的历史与预言变量）以构造精化映射 | T0 不设“不可能”原语而正向导出 `noMagicBit`；T1 无需操作概率原语、互操作公设或扩充目标规范，由同一确定性 `SpinPair` 母源 $S_\star$ 在 `Type 0` 不交并内自建分离地址，普遍形成三域并左逆恢复全历史（定理 4.2） |
| **柱 III · 溯源半环与差分增量** | **Green 等** (2007)[[17]](#ref-17) 溯源半环 $\mathbb N[X]$；**Cai 等** (2014)[[18]](#ref-18) 静态微分定理 3.11；**Budiu 等** (2023)[[19]](#ref-19) DBSP §4.1 $\mathbb Z$-集与定理 3.4 | [[17]](#ref-17) 以多项式半环同态分解正关系查询求值；[[18]](#ref-18) 与 [[19]](#ref-19) 分别给出一般变化结构上的静态微分与交换群值流的增量演算。交换群是前者的特例 | 保留式 (10) 的精确有限差分结构，进而将字面残差转化为带正语法预算的下一请求（$\epsilon=0$ 仍付 2 拍），经双负号无缓存恢复已付 AST 持续执行同态方法 $f$（OB12），并由九构造子原语回放同步生成库存边界与余链微分 $d^{0,1}$（OB13） |
| **柱 IV · 理论收缩与信念修订** | **Alchourrón, Gärdenfors & Makinson** (1985)[[20]](#ref-20)：部分交收缩 $K\dot{-}p=\bigcap\gamma(K\bot p)$ 与 Levi 恒等式 | 在**固定命题语言**内，部分交收缩经选择函数 $\gamma$ 去掉对指定命题 $p$ 的蕴含（$K\dot{-}p\subseteq K$）；冲突输入的修订经 Levi 恒等式先收缩 $\neg p$ 再加入 $p$ 以恢复一致性 | 面对旧语言表达与合法实现**双空破产**，在**零公理（免选择函数）**下生成范畴初始余面 $L_+\sqcup\{\star_\eta\}$ 扩张坐标维度（定理 6.2），同时令迁入旧债行与新方向行共用非终账首写而不收缩未清旧债（定理 6.5） |

---

## 9　结论：现实刚性的四次兑现与同系列精确接口

回到开篇的根本追问：一笔真实差异能否不交代任何结构来历就混入现实？本文用一套零循环、可编译、可逐项反查的数学构造给出了完整回答。

在零公理内核（T0）中，合法准入与单构造子发生树确立了根读恒等 $\mathsf{RootRead}(o)=o$，使任意源生权威根与任意跨终账／跨修订活过程中的每一项真实差异都由单射登记发生取得正向结构身份，纯构造地将外部补写与魔法比特彻底清零，并以编译期防火墙拦截八类旁路神谕。在标准三公理完备化层（T1）中，原始事件内生生成的单一二态自旋对母源 $S_\star$ 普遍形成 `Type 0` 原准入接口上的全部合法世界、完整询问与演化宏过程，消除了引入独立第二基源的必要，并在四维 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 连续—量子统一场上直接兑现九场经典构型与 $4\sqrt2$ 有限 $\hbar$ 精确配对。在动态续行与语言升维层中，全未来残差亲自生成下一请求并严格扣减同一笔语法债，双负号提取使已付语法树跨共尾停点持续执行同态方法，逐原语步进回放同步驱动库存边界与余链微分 $d^{0,1}$，而根植双空破产则在零公理下生成范畴初始余面 $L_+\sqcup\{\star_\eta\}$，迫使任何合法理论修订在同一非终账首写中全额承接历史旧债。

作为全系列的本体论与方法论前门，本文精确止步于上述普遍刚性与四柱总合同，并将下游专精责任清晰交予相邻专篇：四层过程代数、自由模正合求值核与执行步至请求双向可逆切片由《源生过程代数》[[6]](#ref-6)完整展开；责任生命周期守恒三律、容量短缺正阻滞与常量关系证书反演由《溯源守恒演算（整账法）》[[8]](#ref-8)完整承担；十阶连续—量子统一场闭合与零旋钮低能唯象演绎则由物理旗舰第三版[[7]](#ref-7)及其唯象系列专篇逐项兑现。留在账面上的每一项开放责任（具体领域的解释映射、定量实验盲测以及尚未由真实运行付清的明天）各自有名有姓，既未被夸口宣称已付，也绝无可能逃出这本账。

---

<a id="appendix-a"></a>
## 附录 A　零公理整现实、根读恒等与观察安全证明

本附录给出 §2–§3 全部命题与定理的自足证明细节，记号与正文一致。除定理 3.3(3) 的复张量算术实例外，全部声明位于固定源码包（附录 D 源 Y）的零公理内核（`#print axioms = []`）。

### A.1　单构造子发生展开与根读恒等母律

在 `LivingLawRootedAccountedUnfoldingKernel.lean` 中，互归纳类型 `RootedAccountedUnfolding` 与分支列表 `AccountedBranches` 仅含唯一发生构造子 `.occur root branches`（及分支的 `.nil`、`.cons`）。函子重标 `map` 对树作结构递归，由归纳立得恒等律 `map_id`（$o.\mathrm{map}(\mathrm{id})=o$）与复合律 `map_map`（$(o.\mathrm{map}\,f).\mathrm{map}\,g=o.\mathrm{map}(g\circ f)$）。未决前沿 `frontier` 在叶节点 `.occur r .nil` 返回单元素表 `[r]`，在非空分支上拼接各子树前沿；由非空左列表拼接保持非空引理 `append_ne_nil_of_left_ne_nil` 对树作互归纳，零公理证出 `frontier_ne_nil`（$o.\mathrm{frontier}\neq[\,]$）。一步展开 `advance next` 在每个开放叶 `r` 处挂接单分支 `.singleton (next r)`，由 `flatMap_append` 与局部列表结合律零公理导出 `frontier_advance` 与结合扁平化律 `advance_assoc`。万有求值折叠 `fold atOccurrence` 对树作唯一结构递归；若候选求值器 `cand` 满足与 `.occur` 的交换等式，互归纳立得 `fold_unique : cand o = o.fold atOccurrence`。

在 `LivingLawRootCoreRepresentationKernel.lean`、`LivingLawRootTemporalAnswerNextKernel.lean` 与 `LivingLawRootInquiryFoundationKernel.lean` 中，完整时序因果根发生上的根余面读出 `rootCofaceRead (o : ExactTemporalCausalRootEvent root) := o` 为字面恒等映射，零公理给出任意下游消费者的观察安全定理 `rootCofaceRead_consumerSafe` 与零隐藏差异定理 `no_hiddenNull_at_rootCofaceRead`；给定账本根闭包与时序访问 `visit`，规范生成演化令牌 `SourceNativeTemporalVisitGeneratedEvolutionAt root visit` 仅含单个构造子 `.canonical`，故任意令牌与 `generatedAtTemporalVisit` 定义性同一，其 `occurrence_eq`、`priorPatches_eq`、`currentPatch_eq` 与 `wholeLedgerWriteBack_eq` 全部由 `rfl`／`HEq.rfl` 给出。语义切面 `SourceNativeRootSemanticFaceAt` 携带投影坐标、激活见证与分类器等式 `classify = .inl active`，其根读函数 `rootRead` 直接返回 `project projection (root.emitted visit.current) active`；独立回答核验器 `SourceNativeInquiryAnswerConsumerAt` 通过异质等式 `project_heq` 将核验令牌绑定至 `(query, event, entry, answerFace.rootRead)`，从而在机器层面完整闭合引理 2.2(1) 的 $\mathsf{RootRead}(o)=o$。

### A.2　时序可达归纳结构与单根权威编译期防火墙

给定根 $R$，**共尾后可达** `SourceNativePostCofinalReachableAt` 由两枚构造子归纳定义：`.cofinal(u)` 接收源内生成的共尾访问 $u$ 并抵达其当前态；`.step(h, eq)` 接收抵达 $c$ 的共尾后历史 $h$ 与后继等式 $\mathsf{next}_R(c)=\mathrm{some}\,c'$ 并抵达 $c'$。**时序可达** `SourceNativeTemporalReachableAt` 仅含 `.finite(h)` 与 `.postCofinal(h)` 两枚构造子。因共尾后历史只能由 `.cofinal` 起始，有限历史无法混入共尾后分支；同时若 `.finite(v) = .finite(v')`，对记录逐字段解构即得当前态与有限历史分别相等，故 `finite_injective` 成立。命题 2.3(1) 中 $v_1$ 为初始构造子、$v_2$ 为一步后继构造子，对 $v_1=v_2$ 作构造子消去即得矛盾。

命题 2.3(3)–(4) 的编译期门禁分两层核验：第一层在 `LivingLawZeroLawRootAdmissionRegression.lean`（公开包 `H0mework.Checks.OneBit.ZeroLawRootAdmissionRegression`）中以 `fail_if_success` 验证向 `finite` 传入多余 `Bool` 参数或将未经全事件库存准入的 `mixedTerminalRoot` 强转为合法世界状态均无法通过类型检查，且 6 条 `#print axioms` 审查确认公理列表为空；第二层在 `Tracks/LivingLawSingleRootAuthorityFacadeRegression.lean` 中导入全部 20 个语义回归套件，并以 8 条 `#guard_msgs` 编译断言验证 `U8RevisionCalculus`、`GeneratedRevisionFamilyAt`、`RevisionSelectionCalculus`、`U7ObstructionLifecycle.demandEvolutionRun`、`TheoryRevisionLifecycleRegression.settled`、`SourceNativeGeneratedU8RevisionAuthority`、`SourceNativeGeneratedU8SettlementAuthority` 与 `SourceNativeOperationalSearchRecognitionAt.exhaustive` 在公共权威门面中严格不可见。

### A.3　单根全实在性与跨交接活过程全实在性

定理 2.6 的根语义式 (5) 中，实际性两侧分别取 `generatedAtTemporalVisit_isCanonical` 证明，稳定指称取依赖对 $\langle\mathsf{occ}(w),\,\mathsf{rfl}\rangle$，真实差异为 $w\neq w'$；全实在性映射 `RootTotalReality.isTotal` 对任意实际差异直接调用 `Or.inr (registeredOccurrence_ne_of_ne actual.realDifference)`，再串联定理 2.5 的 `noExternalSupplement` 与 `noMagicBit`。定理 2.8 的活过程语义（`RootProcessTotalReality`）比较完整三元活当前 `process.stateAt s`（包含词汇、内嵌终账交接律的活根闭包与时序访问），由 `stateAt_injective` 导出 `registeredCurrent_ne_of_ne`，同样返回右支并零公理排除跨局部终账与跨理论修订边界的外部补写与魔法比特。整套文件不接收调用方提供的 `NoMagic`、差异分类器或外部闭包令牌。

### A.4　当前态反射与法则面保持

定义 2.7 中的生成后继关系是单一合取依赖命题（而非两枚可拆散使用的独立令牌）：擦除交接律后的目标当前等于源生成的下一当前，且在非终账分支上活根异质相等。定理 3.1(1) 中由 $\iota(s)=\iota(s')$ 及单射性得 $s=s'$，模式匹配消去该等式后，两侧 `canonicalCausalAnswerAndNext` 为同一项（且其载体仅含唯一构造子 `.canonical`）；定理 3.1(3) 对后继等式作用投影 $\rho\mapsto\rho.\mathrm{lawSurface}$，再复合单步后继保持法则面引理即得法则面不变。

### A.5　观察商安全否决与整算术挠类复观察消亡

定理 3.3(2) 中，局部范围观察者对每条开放责任按作用域可见谓词过滤，不可见新准入责任被滤去故输出列表不变；完整当前责任观察者将全部槽位映为开放责任或空位，新准入追加一槽故列表长度加一，`FullTraceRedirect` 直接封装该准入事件与两条证明。定理 3.3(3) 中，$G=\{(g_n)\in\prod_n C_n:\rho_n(g_{n+1})=g_n\}$ 为相容整数挠余核，$F(g)=(1\otimes_{\mathbb Z}\pi_n(g))_n$，$J(g)=\pi_1(g)$。整账法[[8]](#ref-8)（定理 13.1–13.3）证明：端点相容构造给出 $z\in G$，单位算术根保证 $J(z)=z_1\neq0$，而有限阶整挠元在张量复数域 $\mathbb C$ 时逐阶满足 $1\otimes_{\mathbb Z} z_n=0$（完全无需交换逆极限与张量积），从而 $F(z)=0=F(0)$，排除了包括任意非线性映射在内的一切恢复函数 $h$。

---

<a id="appendix-b"></a>
## 附录 B　固定母源 $S_\star$ 三域普遍形成总定理证明

### B.1　从有限观测逼近到逐点一致完备双射

设材料阶 $r$ 上的观测地址族 $\mathcal A_r$ 分离输入载体 $X_r$ 的点。任取有限子集 $F\subset X_r$，对 $F$ 中每对不同元素选取一枚区分地址，排成有限地址表 $(a_0,\dots,a_{n-1})$，则有限观测向量 $x\mapsto(\mathrm{obs}_r(a_i,x))_{i<n}$ 在 $F$ 上单射，补零成实流 `pad_n` 保持单射。因此，对任意目标函数 $f:X_r\to\mathbb S$，可在 $F$ 的有限观测像上精确指定目标流值并延拓至全流空间。调用母源 $S_\star$ 有限求值器的稠密逼近定理[[7]](#ref-7)（附录 C.9）：对任意前缀长度 $b\in\mathbb N$ 与任意 $\varepsilon>0$，存在母史第 $10+c$ 次合法访问（$c$ 为有限程序编码序号）及上述有限地址表构成的程序 $p\in\mathsf{Prog}_r$，使得
$$\bigl\lvert L_r(p,x)(j)-f(x)(j)\bigr\rvert<\varepsilon\qquad(\forall x\in F,\ 0\le j<b).\tag{B.1}$$
由于函数空间 $X_r\to\mathbb S$ 上逐输入点、逐输出坐标乘积一致结构的全体基本邻域恰由 $(F,b,\varepsilon)$ 给出，式 (B.1) 直接证明有限程序像 $\mathcal R_r$ 在 $X_r\to\mathbb S$ 中稠密。原始包含映射的一致完备延拓读出 $\mathsf{read}_r:\mathcal M_r\to(X_r\to\mathbb S)$ 是一致嵌入，其像作为完备一致空间的等距像在 Hausdorff 完备空间 $X_r\to\mathbb S$ 中闭，又包含稠密子集 $\mathcal R_r$，故 $\mathsf{read}_r$ 必为满射，从而是双射。由此，每个完备材料 $m\in\mathcal M_r$ 自动位于有限程序像闭包内（定义 4.1 恒成立）。

### B.2　三域统一不交并见证与双亲左逆限制

对任意原生询问引擎宏过程 $P$，将其状态集与逐状态依赖查询族装入单一不交并载体
$$\mathcal U_P=\mathrm{State}(P)\ \sqcup\ \coprod_{s\in\mathrm{State}(P)}\mathrm{Query}\bigl(P.\mathsf{stateAt}(s)\bigr).\tag{B.2}$$
由于 $P$ 位于 `Type 0` 原接口，$\mathcal U_P$ 同样位于 `Type 0`，累积材料构造在证明内部直接从 $\mathcal U_P$ 定出充足材料阶与点分离观测地址（已回答、未访问以及局部读数相同但身份不同的状态在式 (B.2) 中各自保有独立坐标）。对每个状态 $s$ 分别形成完整查询节点，并同步形成状态域与一步后继图；询问分支同理编码查询类型与原查询编译的全部五个分支（含回答、行动、修订三族子句及路由选择）；世界分支将权威根材料与时序访问材料配对。联合构造将各族材料嵌入同一共同阶并以固定双射实流交织配对合并；因流解配对投影逐分量精确还原两路完整实流，双亲限制映射在整个联合材料空间上构成合并映射的严格左逆。

### B.3　规范实现重构与任意深度运行轨迹运输

宏过程规范实现映射从联合材料 $m$ 中读出状态域、完整节点族、事件地址与后继图；利用 B.2 的左逆恢复等式，成功输出原过程的状态重标同构本 $P_m$，再沿内部生成的状态等价作限制即得式 (7) 的完整记录等式 $\mathsf{restrict}(P_m)=P$。该记录等式一次性驱动全部下游恢复：逐状态节点相等保证每条查询经类型运输后编译结果异质相等；完整过程相等使任意既有引擎、激活与整条激活法则经运输逐项复原；对任意原执行轨迹 $\mathcal T$ 与任意自然数深度 $n\in\mathbb N$，逐步运输给出式 (8) 的状态、步进与下一态三联等式。世界分支的全实在性证明则直接由原点记录恢复出的权威根调用定理 2.6 内生生成。

### B.4　五条无旁路下游核验链与公理闭包审计

推论 4.3（`MotherFixedSourceRealizationConsumer.lean`）中的五个定理声明 `original_world`、`original_inquiry`、`original_process`、`original_physical_seal_and_whole_law` 与 `original_physical_tick_and_history` 均在证明项中直接调用定理 4.2 的唯一主声明 `root_admission_fixed_mother_complete_realization`：前三条验证三域通用左逆恢复，第四条在物理询问过程第 16 状态处核验封印回答与整条激活法则恢复，第五条同时核验第 $16\to17$ 步演化、任意深度 $n$ 历史恢复、母史第 10 次物理访问认回及 `SameOccurrenceActivation`。独立审计脚本逐一检查五项证明项语法树：确认它们均直接引用主声明，且零次直接引用三条低层逐域覆盖引理与四条低层恢复引理；完整依赖闭包仅含 `propext`、`Classical.choice` 与 `Quot.sound` 三条标准公理，无任何非安全或部分递归声明。

---

<a id="appendix-c"></a>
## 附录 C　同债付款、已付方法微分续行与零公理初始余面证明

### C.1　全环境零子模 $Z$ 在配对提升与站位作用下的保持（OB8）

记整系数形式表达式自由模为 $\mathrm{Fm}(V,X;s)$，环境 $\Theta$ 下的线性延拓求值为 $\mathrm{ev}_\Theta$。子集 $Z=\{w:\forall\Theta,\ \mathrm{ev}_\Theta(w)=0\}$ 对加法与整标量乘法封闭，构成子模。由求值差分律 (10) 知 $\mathrm{ev}_{\Gamma+\delta}=\mathrm{ev}_\Gamma+\mathrm{eff}_{\Gamma,\delta}$，故 $w\in Z$ 蕴含对一切 $(\Gamma,\delta)$ 有 $\mathrm{eff}_{\Gamma,\delta}(w)=0$，从而完整配对求值 $(\mathrm{ev}_\Gamma(w),\mathrm{eff}_{\Gamma,\delta}(w))=(0,0)$。字面配对提升 `liftExpr` 将常量 $v$ 映为 $(v,0)$，保持变量与加法，将一元同态 $g$ 映为 $(u,du)\mapsto(g(u),g(du))$，将双加法算符 $B$ 映为 $((u,du),(v,dv))\mapsto(B(u,v),\,B(u,dv)+B(du,v)+B(du,dv))$；结构归纳表明其在 $\mathrm{pairEnv}(\Gamma,\delta)$ 中的求值恰为 $(\mathrm{ev}_\Gamma,D(\Gamma,\delta))$。因任意配对环境 $\tilde\Theta$ 均等于由其两投影重构的 $\mathrm{pairEnv}$，故 `liftExpr` 将 $Z$ 送入配对语言的零子模；再复合保持 $Z$ 的语言等式运输与完整包运输，单步站位源作用将第 $k$ 站位的 $Z$ 送入第 $k+1$ 站位的 $Z$。由交换群基本恒等式知 $[r_m]-([a]-[p])\in Z$，对有限允许作用词归纳即得定理 5.1 的式 (12)。

### C.2　正语法时钟、严格同债扣款与唯一去向认回（OB8）

出生对象 $b$ 的注册时钟由源步进归纳给出 $c(\mathrm{state}(b))=c(b.\mathrm{AST})-(b.\mathrm{depth}+1)=Q-1$。由式 (11)，$Q=c(a)+c(p)+2\ge2$，故 $Q-1\ge1>0$。若出生处的实际动作落入数学结算分支，结算前提强制剩余费用等于 $0$，与 $Q-1>0$ 矛盾；因此对实际动作和类型消元必取得真实已付归约步，使预算严格减一。同债目标唯一性由扩展账主张的不相交和类型保证：原数学债务居左支，迁入继承行居右支，右支行不可能携带左支主张，故满足同债条件的去向行唯一；最后消去支撑等式与账演化同一性，对有限步数归纳即证付款演化异质相等于整账后继去向（定理 5.2–5.3）。

### C.3　双负号已付语法树恢复、同态步进与出生库存回调证明（OB12）

本节给出定理 5.4（附录 D 源 MV5，`PaidMethod/{Source,Recovery,Admissions}.lean`）的完整推导：

1. **前缀输入不变性与双负号提取（`after_native_retained`）**：设当前准入包为 $\mathsf{pkt}=(n,(\mathrm{source},\mathrm{seed}),\mathsf{cfg},\langle\mathsf{rfl}\rangle)$，其原生接收帧 `native` 的注册输入表达式为首次残差 $e_0=N.\mathrm{expression}(\mathrm{actualMaterial}(\mathrm{source},\mathsf{cfg}))$。记局部完成回执给出的归约步数距离为 $d=(\mathrm{receipt}(\mathsf{stockCfg},\mathrm{native},0)).1$。对 $0\le m\le d$ 作归纳：当 $m<d$ 时，`receipt_paid_prefix` 证明第 $m$ 帧动作必为已付步 `.paid`，故下一帧走 `mathNext`，注册输入表达式保持不变（`paid_prefix_expression`），从而终点选中帧 `selected` 仍满足 $\mathrm{selected.registered.input.expression}=e_0$。在终点处结算触发 `nextBorn`，其注册输入表达式按定义变为 `Expr.add e0 (Expr.linear (-id) selected.event.state.1)`（其中 `e0` 记 $e_0$）。将提取函数 `retainedCode` 作用于该两层加法树，模式匹配命中右支已付状态并外施 `-id`，直接给出异质等式
$$\mathsf{retainedCode}(\mathrm{next})\;\doteq\;(-\mathrm{id})\bigl((-\mathrm{id})(\mathrm{actualMaterial}(\mathrm{source},\mathsf{cfg}).\mathrm{state}.1)\bigr).$$
2. **求值还原与同态递推（`after_native_value`、`after_native_whole_action`）**：由所有者自由安装定理 `paid_expression`，上述已付状态语法树等于常量节点 `.const v_k`（其中 $v_k$ 为当前包动作结果值）；在任意环境 $\Gamma'$ 下，交换群对合律 `-(-x)=x`（`negate_paid`）给出 $\mathrm{ev}_{\Gamma'}(\mathsf{retainedCode}(\mathrm{next}))=v_k$。下一包计算读口 `raw f (n+1) frame` 在零增量配对环境 $\mathrm{pairEnv}(\Gamma',0)$ 下构造表达式 `.linear (pairAction (actionAt f (n+1))) (liftExpr (retainedCode (n+1) frame))`。因任意表达式在零增量下的效应恒为零 `effect_zero : expr.effect env 0 = 0`，配对提升求值 `pair_zero` 给出 `(retainedVal, 0)`；再作用分量同态 `pairAction` 并利用同态保零 `map_zero`，即得输出 `(actionAt f (n+1) v_k, 0)`，证毕式 (15)。
3. **查询迹回调入账与统一四面安装（`actual_complete_query_written`、`cofinal_paid_method_faces`）**：派生配置族 `factory baseFactory f` 将 `nextPairInventory` 设为 `some (Stock.preserve prior completeQueryWritten)`。出生帧配对库存按定义等于 `Stock.preserve frame.pairInventory (Stock.preserve callback generatedPairStock)`；对可选树分支消元并调用单构造子展开树的左右并行迹保持引理 `parallel_left`／`parallel_right`，即证 `completeQueryWritten` 的每一条事件均属于 `writtenStock.trace`。同时在库存读口发射前经七步余面合成 `componentCoface.trans inheritedCoface ...` 安装语义切面 `actualFace`，令 `packet := actualFace.rootRead`，立得 `source_readback : HEq face.rootRead packet := HEq.rfl`，并同步生成 `UnifiedFourFace` 的代数、组合、拓扑、逻辑统一四面（及关系、余链切面）与对偶读回；在 `Admissions.lean` 的复 Hilbert 空间与障碍演算诱导运行上，沿严格递增共尾停点指标 `D.index` 与封闭询问场迭代引理 `field_segment` 即得任意有限步历史闭合 `finite_paid_method_faces`。

### C.4　整词逐原语步进回放与边界—余链—余像四重微分证明（OB13）

本节给出定理 5.5（附录 D 源 MV5，`WordExecution.lean` 与 `RelationCochain/{Source,Consumer}.lean`）的完整推导：

1. **上下文原语嵌入与精确计费（`WordExecution`）**：对任意完整活源过程词载体 $w\in\mathrm{Carrier}(\mathcal P)$ 与环境读映射 `readEnv`，归纳验证嵌入求值交换律 `embed_eval : (embed readEnv expr).eval (Context.env w) = expr.eval (observerEnv readEnv w)` 及绑定推进律 `binding_word`。随后对原语归约步 `Step (observerEnv readEnv w) before after` 的九个构造子作结构递归定义 `embeddedStep`：变量绑定步 `.bind name` 调用上下文实际求值迹并用 `embed_eval` 改写终点；三类常量运算步（`addConst`、`linearConst`、`bilinearConst`）映射为单步迹 `Trace.single`；五类子树归约步（`addLeft`、`addRight`、`linear`、`bilinearLeft`、`bilinearRight`）递归提升子迹。拼接整条迹得 `embeddedTrace`，经绑定代换 `substitutedTrace` 与零增量提升 `liftTraceZero` 得到 `pairedForward`。由到常量端点的归约步数守恒律 `length_to_const` 直接证出精确计费等式 `forward_charge : (forward readEnv w expr).length = remaining ((embed readEnv expr).subst binding)`。
2. **出生库存与下一查询双包含（`native_replay_written`、`native_replay_next_query`）**：在封闭算术—Fock 运行第 $11+\mathrm{count}$ 步处，由归纳不变量 `actual_grounded` 证出活动环境恒等式 `environment_actual` 与已付环境恒等式 `paid_current`，从而当前回放暴露 `exposure(nativeReplayAt)` 精确等于回调写入的 `replayStock`（注意此处仅沿内部已证环境等式作类型运输，绝不用首尾求值相等混同不同执行迹）。再由 C.3 的 `birth_keeps_callback` 与联合完整写入保留引理 `complete_written_preserves`，证出回放暴露连同原已付迹同时包含于 `birthStock.trace` 与下一出生帧的 `completeQueryWritten.trace`。
3. **四重微分合一、发生树擦除与同停点物理读回（式 (16) 与 `actual_relation_cochain_method`）**：任意执行迹 $\tau:e_{\mathrm{in}}\Rightarrow^* e_{\mathrm{out}}$ 的整系数关系词在关系映射下满足伸缩边界公式 $\mathsf{relMap}_E(\tau.\mathrm{relationWords})=[e_{\mathrm{in}}]-[e_{\mathrm{out}}]$。将此公式同时施于当前帧配对环境 $E_{\mathrm{stop}}$ 下的回放迹 `nativeReplayAt` 与代换源环境 $E_{\mathrm{src}}=E_{\mathrm{stop}+1}$ 下的下一帧源迹 `nativeSourceAt`，结合绑定提升恒等式 `SubstitutionLift.expression`，即证 `actual_boundary_from_source`：$\partial_{\mathrm{act}}.\mathrm{val}=\mathsf{subst}_{\mathrm{pair}}(\mathsf{relMap}_{E_{\mathrm{src}}}(\mu_{\mathrm{stop}}))$。再调用代换链复形的边界交换方块 `SourceSubstitution.boundary_square`，立得 `actual_complex_boundary`：$\mathsf{relMap}_{E_{\mathrm{stop}}}(\tau_1(\mu_{\mathrm{stop}}))=\partial_{\mathrm{act}}.\mathrm{val}$。进而，自然数历史生成的余链复形满足首阶微分恒等式 `natComplex_d_zero_one`，给出 `generated_differential`：$(d_{\mathcal C}^{0,1}(\partial_{\mathrm{act}})).\mathrm{val}=\partial_{\mathrm{act}}.\mathrm{val}$，串联即得式 (16)，并由 `completion_kills_generated_differential` 证出完备化投影为零。进一步由配对绑定环境推进等式 `paired_binding_square` 构造统一四面求值态射 `faceAction`，调用 `generated_action` 与 `generated_equation` 导出余像边界与余像微分恒等式 `actual_coimage_boundary`、`actual_coimage_differential`。最后，对带根读标签的发生树 `sourceOccurrence = sourceUnfolding.map (fun ev => (ev, face.rootRead))` 应用 A.1 的 `map_map`、`map_id` 与 `root_map`，一步证出擦除恢复 `(sourceOccurrence.map Prod.fst) = sourceUnfolding` 与根读还原 `sourceOccurrence.root.2 = face.rootRead`，并联合 `physicalReadback`（读回下一拍 `((sourceState, forcedTrace), 0)`）及同停点回执编译与 `runFrom` 段拼接完成 `actual_relation_cochain_method`。

### C.5　零公理初始余面泛性质与双行同首写权威链（OB9）

定理 6.2 在 `LivingLawObstructionGeneratedMinimalCofaceKernel.lean` 中零公理实现：构造性回缩记录 `ConstructiveRetract A B` 仅要求单侧恒等 `backward (forward a) = a`，从而允许新载体 $B$ 合法容纳无旧原像的新坐标。忠实余面态射类型 `FaithfulCofaceMorphism` 仅含单个构造子 `.canonical`，故任意态射 `morphism` 经 `cases morphism; rfl` 一步证出与 `minimal_coface_initial` 相等（`minimal_coface_factorization_unique`）。

定理 6.5 的恢复权威链（`LivingLawTypedSemanticWorldNetworkU8RecoveryKernel.lean`）严格沿以下单向依赖推进：
$$\text{首写初访生成补片成员}\ \longmapsto\ \text{初始因果行权威}\ \longmapsto\ \text{同一次非终账首写目标权威}\ \longmapsto\ \text{新根因果回答与后继}.$$
其中第二步对迁入旧故障行与新增方向行共用同一枚 `CanonicalFirstRootWriteAt` 后继证明，第三步统一调用新根编译器而不接受外供结算令牌；因此两行（乃至首写全部生成初始行）产出的下一当前定义性全等。当修订采用带拆分的丰富忠实锚定时，编译器选中的拆分覆盖确保同一迁入父行生成的两条子行相异且各自 `progressBudget` 严格小于父行；若目标账至多一行或拆分覆盖为空，该双子行动作类型自动为空。

---

<a id="appendix-d"></a>
## 附录 D　机器核验索引与固定源对应表（OB1–OB13）

下表列出本文全部稳定主张 **OB1–OB13** 在中英文正文与附录中的精确位置、固定研究源声明以及公开复现入口。

| 编号 | 正文与附录位置 | 固定研究源核心模块与声明 | 公开核验包与独立认证 |
| --- | --- | --- | --- |
| **OB1** 二值语义约定 | §1.1，定义 2.4 | Y：`LivingLawTotalRealityKernel`（`MagicBitAt`）；Shannon (1948) | 源定义全文与原始文献核读 |
| **OB2** 幽灵反例与防火墙 | 例 1.2(a)，引理 2.2，命题 2.3，A.1–A.2 | Y：`LivingLawRootedAccountedUnfoldingKernel`（`occur`, `frontier_ne_nil`, `fold_unique`）；`LivingLawRootCoreRepresentationKernel`（`rootCofaceRead`）；`LivingLawRootTemporalAnswerNextKernel`（`occurrence_eq`, `wholeLedgerWriteBack_eq`）；`LivingLawRootInquiryFoundationKernel`（`rootRead`）；`LivingLawZeroLawRootAdmission{Kernel,Regression}`（`ghostFalse`, `no_ghost_argument_in_world_state_producer`）；`Tracks/LivingLawSingleRootAuthorityFacadeRegression`（8 条 `#guard_msgs`） | H0 `H0mework.Foundation.{Source.AccountedUnfolding,Cofinal.TemporalAnswer,Inquiry.Protocol}`；`H0mework.Checks.OneBit`（`make check-one-bit-full`，零公理 `[]`）。[公开防火墙](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/Lean/H0mework/Versions/Rb81a4438/ReleaseMaterials/SaturationMonoid/Tracks/LivingLawSingleRootAuthorityFacadeRegression.lean)核对八条断言 |
| **OB3** 零公理全实在性 | 主定理 1.1(1)，定义 2.4，定理 2.5–2.8，例 2.9，A.3 | Y：`LivingLawTotalRealityKernel`（`toExternalSupplement`, `noExternalSupplement`, `noMagicBit`）；`LivingLawZeroLawRootAdmissionKernel`（`registeredOccurrence_ne_of_ne`）；`LivingLawRootTotalRealityAdapter`（`RootTotalReality.isTotal`, `RootProcessTotalReality.isTotal`）及回归套件 | H0 整账包 `WA1`（`H0mework.Foundation.{Authority.ZeroLawAdmission,Semantics.RootReality}`，零公理 `[]`） |
| **OB4** 发生刚性与按需历史 | 定理 3.1，A.4 | Y：`LivingLawRootCoreRepresentationKernel`（`canonicalAnswerAndNext_heq_of_current_eq`）；`LivingLawRootAnswerNextHistoryKernel`（`successor_difference_reflects_current`, `successor_lawSurface_eq`, `generateHistory`） | H0 过程核心 `C3` 与整账包（零公理 `[]`） |
| **OB5** 观察商安全与挠盲区 | 定义 3.2，定理 3.3，A.5 | Y：`ResponsibilityObserverKernel`（`ConsumerSafe`, `HiddenNullWitness`, `FullTraceRedirect`）；`NativeReceiptGlobalCompression`、`NativeReceiptIntegralConsumerSeparation` | H0 整账包 `WA6`、`WA11` |
| **OB6** 单母源三域普遍形成 | 主定理 1.1(2)，定义 4.1，定理 4.2，B.1–B.3 | F：`Formation`、`CompleteRealization`（`root_admission_fixed_mother_complete_realization`, `low_formation`, `high_formation`） | H0 首发物理包 `phys.P22`（标准三公理） |
| **OB7** 统一场消费与反控 | 推论 4.3，定理 4.4，B.4 | F：`MotherFixedSourceRealizationConsumer`（5 条无旁路核验声明）；H：`PhysicsCore/Stage10/Realization`（`source_realization_consumed`） | H0 首发物理包 `phys.P6`、`phys.P22` 及物理旗舰 v3 `a5e774a4` |
| **OB8** 残差请求与同债付款 | 主定理 1.1(3)，例 1.2(b)，定理 5.1–5.3，C.1–C.2 | MV4：`RootConsumer/{Semantics,Source,Consumer}`（`actual_root_future`, `actual_root_eliminate`）；`RootedEffect/{Source,Consumer}`（`consume_rooted`）；`Completion/{Source,Consumer}`（`consume_rooted_completed_answer`） | H0 整账包 `WA38`、`WA39`（`Versions.Rba7e274b`） |
| **OB9** 零公理初始余面与修订 | 主定理 1.1(4)，例 1.2(c)，定义 6.1、6.3，定理 6.2、6.4–6.5，例 6.6，C.5 | Y：`LivingLawObstructionGeneratedMinimalCofaceKernel`（`root_obstruction_generates_minimal_coface`, `minimal_coface_initial`, `minimal_coface_factorization_unique`）；`LivingLawTypedSemanticWorldNetworkU8{,Lifecycle,Recovery}Kernel` 及回归（全部零公理 `[]`） | H0 整账包 `WA9`（`H0mework.Foundation.Inquiry.{SemanticRevision,RevisionRecovery}`，零公理 `[]`） |
| **OB10** 长窗口全账接力 | §7，附录 E 定理 E.1 | MV4：`ClozelOriginalKFinitePaWindowOperatorSourceAction/{Consumer,Complete}`；`ClozelOriginalKWindowInverseResidualSourceAction/{Received,Consumer}` | H0 整账包 `WA40`（独立声明闭包核验通过） |
| **OB11** 三层失败责任定位 | §8.1–§8.3，表 2–3 | OB2–OB10、OB12–OB13 的输入类型、输出等式与正反控制合成 | 本文综合方法论论证与 `check_release.py` |
| **OB12** 已付 AST 持续同态方法 | 主定理 1.1(3)，定理 5.4，例 5.6，C.3 | MV5：`PaidMethod/Source`（`retainedCode`, `factory`, `templateFourFaces`）→ `Recovery`（`after_native_retained`, `after_native_whole_action`, `actual_complete_query_written`）→ `Admissions`（`cofinal_paid_method_faces`, `finite_paid_method_faces`） | [第二版逐主张映射](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/docs/one-bit-v2-map.json)，[CP483](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/evidence/one-bit-v2/original/Rdf421ff6/Verification/framework/source-policy/original-certification/CP483/publication-certificate.json) |
| **OB13** 逐原语回放与余链微分 | 主定理 1.1(3)，定理 5.5，例 5.6，C.4 | MV5：`Context/WordExecution`（`embeddedStep`, `embeddedTrace`, `forward_charge`）→ `RelationCochain/Source`（`replayStock`, `replay_written`, `replay_next_query`）→ `Consumer`（`actual_complex_boundary`, `actual_complex_differential`, `actual_coimage_differential`, `physicalReadback`, `actual_relation_cochain_method`） | [第二版逐主张映射](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/docs/one-bit-v2-map.json)，[CP485](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/evidence/one-bit-v2/original/Rdf421ff6/Verification/framework/source-policy/original-certification/CP485/publication-certificate.json) |

固定研究源提交身份：Homework **Y** = `b81a443863f4d7135ebaca92c5bb7d208ccc18ca`，**H** = `e60a86058abcb74b7f2225f2383c182be8343785`，**F** = `cde4b910929d9bc57554aa56f6ade116bc3b8675`，**MV4** = `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`，**MV5** = `df421ff600085cbc290a7ae946193961bed7c83b`。逐文件 SHA-256 与声明定义核对由 `release-selection-v2.json` 及 `scripts/check_release.py` 自动检验。

---

<a id="appendix-e"></a>
## 附录 E　长计算窗口与逆残差纠正的完整条件接线合同

本附录完整给出 §7 概述的多阶段窗口分析接线合同（**OB10**，整账法[[8]](#ref-8)定理 14.1–14.2）。其中底层泛函分析算子——复 Hilbert 载体、缺陷算子、Fourier 算子、Pa 资格投影、居中 Möbius 有限截断及两条均值恒等式——由 Riesz 源微积分的同源构造提供；本附录专门核定其程序语法计费、四份历史迹跨帧迁移、同债付款与全未来读出保持。

### E.1　四分量解析载体与条件输入域

设 $\mathcal H$ 为原复 Hilbert 空间，$D$ 为缺陷算子，$\mathcal F$ 为 Fourier 算子，定义四分量乘积载体与带左逆 $\pi$ 的典范嵌入：
$$\mathcal B=(\mathcal H\times\mathcal H)\times(\mathcal H\times\mathcal H),\qquad \iota(f)=\bigl((f,Df),\,(\mathcal Ff,\mathcal FDf)\bigr),\qquad \pi\circ\iota=\mathrm{id}_{\mathcal H}.\tag{18}$$
取带限源元 $\nu=M\mathcal E\pi(S)$，其中 $\mathcal E$ 为 Paley–Wiener 带限资格投影[[8]](#ref-8)，$M$ 为资格乘子，$S\in\mathcal B$ 为源链输入；另记 $Z_a$ 为截断半径零延拓算子，$P$ 为首轮逆作用算子，$R_a$ 为区间读出限制算子。有限截断窗口算子定义为
$$W_a(f)=\sum_{m\in L_a}\frac1m\,A_{a,m}f-\frac12\,\ell(Jf)\,c_a,\tag{19}$$
其中 $L_a$ 为居中 Möbius 截断有限列表，$A_{a,m}$ 为尺度拉回，$\ell$ 为源窗口积分泛函，$J$ 为 Tate 倒数对合，$c_a$ 为常数区间场。该源链的原输入类型由以下数据组成：原解析发生上的零点观察回执 $z$（携带源 zeta 实现零点条件 $\zeta_{\rm src}(z)=0$、非平凡性 $\forall n\in\mathbb N,\ z\neq-2(n+1)$ 及右半平面条件 $\operatorname{Re}z>1/2$），以及任意深度、序数与实参数 $h,H,N,a$。当 $|L_a|=k$ 时，求和、倒数权重与 Tate 极点项全部保留为显式语法节点，窗口程序语法预算精确为 $4k+3$。下述定理对该条件输入类型全称成立（若 Riemann 猜想为真，该输入类型为空，定理空真成立）。

### E.2　跨帧四迹迁移、逆残差燃料与统一消元

<a id="thm-e-1"></a>
**定理 E.1（四份历史执行迹进入逆残差纠正、同债付款与全未来保持[[8]](#ref-8)）。** 对 E.1 所述条件输入类型中的每一组原输入：

1. **首帧执行与逆残差读出**：首次实际写入差分满足 $\Delta_F=\iota Z_a W_a(\nu)$；前向库存、逆残差、二次均值与余链四份执行库存在出生前完成安装；直接从该次写入读出
$$\eta=\nu-M P\pi(\Delta_F),\qquad s=\iota(\nu),\qquad r=\iota(\eta),\tag{20}$$
其中 $\eta$ 精确等于首轮逆程序生成的完整残差；该出生包的完成回执同步给出写入器、同债严格扣款与准确整账去向。
2. **字面纠正执行与窗口差恒等**：下一源帧执行字面纠正语法树 $\kappa=\mathrm{const}\,s+(-\mathrm{id})(\mathrm{const}\,r)$（含 2 个计费节点），将其代入原完整窗口程序生成纠正准入包、完成回执与整账写入，满足精确差分关系
$$\Delta_C=\iota Z_a W_a(\nu-\eta),\qquad R_a\pi(\Delta_C)-W_a(\nu)=-W_a(\eta).\tag{21}$$
3. **新旧六迹汇合消元**：首帧的四份历史执行迹经原库存迁移完整进入纠正包，纠正帧同时新生成自身的四类窗口执行迹以及新增库存迹与纠正迹；旧写入证明、新写入证明、新整账同债付款、原环境／语法树身份及真实执行迹在同一核验消费者中完成嵌套消元，任何库存维护开销均不混充原债预算。
4. **真实源种子锁定与全未来保持**：出生根与当前态精确认回完整包的根与当前态，续行严格从该包真实源种子出发（辅助种子无法替换），且在后续一切允许有限作用词、一切共尾准入序数与一切站位上保持请求与已付边界读出恒等。

定理 E.1 表明，即便在大型多阶段解析程序中，未消尽的残差 $\eta$ 也不允许被静默丢弃或手工归零，而必须原封不动化作下一帧真实计算的燃料。

---

<!-- code-availability:begin -->
## 代码与数据可得性

OB2 的单根编译期防火墙及 OB12–OB13 的证明、直接消费者和认证回执均可在 H0mework 固定提交 `ffa5eeb70130b17db3873407d0cd10a218e45896` 中查阅。[第二版逐主张映射](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/docs/one-bit-v2-map.json)登记实际 Lean 声明、类型与原始纪元，[复现指南](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/docs/one-bit-v2-reproduction.md)给出源码恢复、构建和公理依赖核验命令。`python3 tools/one_bit_v2.py entry` 核对已验收范围。[CP483](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/evidence/one-bit-v2/original/Rdf421ff6/Verification/framework/source-policy/original-certification/CP483/publication-certificate.json) 与 [CP485](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/evidence/one-bit-v2/original/Rdf421ff6/Verification/framework/source-policy/original-certification/CP485/publication-certificate.json) 保留原独立认证。OB1–OB11 已有证明沿用[首版映射](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-map.json)。

OB3、OB5、OB8–OB10 的完整重建入口为 `make check-whole-ledger-full`，OB6–OB7 为 `make check-first-release-full`。工具链固定为 Lean 4.33.0 与 Mathlib v4.33.0。

同系列共享过程结果引用过程核心第二版 DOI [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175)，物理统一场与普遍形成引用物理旗舰第三版 DOI [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339)（第二版 DOI [10.5281/zenodo.23297179](https://doi.org/10.5281/zenodo.23297179)），整账与付款引用整账法第一版 DOI [10.5281/zenodo.23437454](https://doi.org/10.5281/zenodo.23437454)；本篇第一版记录见 DOI [10.5281/zenodo.23437456](https://doi.org/10.5281/zenodo.23437456)。原创代码采用 Apache-2.0 许可；论文正文与原创矢量图件采用 CC BY 4.0 许可。
<!-- code-availability:end -->

## 参考文献

<a id="ref-1"></a>
[1] Gottfried Wilhelm Leibniz. *The Monadology* (1714). Robert Latta 英译，§§31–38. [Wikisource 译本](https://en.wikisource.org/wiki/Monadology_(Leibniz,_tr._Latta)).

<a id="ref-2"></a>
[2] John Archibald Wheeler. *Information, Physics, Quantum: The Search for Links*. Proceedings of the 3rd International Symposium on Foundations of Quantum Mechanics, Tokyo, 1989, 354–368. [作者论文重印](https://cqi.inf.usi.ch/qic/wheeler.pdf).

<a id="ref-3"></a>
[3] Claude E. Shannon. *A Mathematical Theory of Communication*. The Bell System Technical Journal, 27, 379–423, 623–656, 1948. [修订重印](https://people.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf).

<a id="ref-4"></a>
[4] George C. Necula and Peter Lee. *Safe Kernel Extensions Without Run-Time Checking*. Proceedings of the Second Symposium on Operating Systems Design and Implementation (OSDI), 229–243, 1996. DOI: `10.1145/238721.238781`. [USENIX 原文](https://www.usenix.org/legacy/publications/library/proceedings/osdi96/full_papers/necula/html/osdi.html).

<a id="ref-5"></a>
[5] Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Łukasz Kaiser, and Illia Polosukhin. *Attention Is All You Need*. arXiv:1706.03762, 2017. [arXiv](https://arxiv.org/abs/1706.03762).

<a id="ref-6"></a>
[6] 高健（Jian Gao）. 《状态不是历史，源才是：过程同一性、责任承接与最小修订》／*The State Is Not the History, the Source Is: Identity, Responsibility, and Minimal Revision in Processes*. 第二版，2026. DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175).

<a id="ref-7"></a>
[7] 高健（Jian Gao）. 《从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成》／*From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*. 第三版，2026. DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339)（第二版 DOI: [10.5281/zenodo.23297179](https://doi.org/10.5281/zenodo.23297179)）.

<a id="ref-8"></a>
[8] 高健（Jian Gao）. 《平账魔法别想逃：源生整账与真实续行》／*Book-Balancing Magic Has Nowhere to Hide: Source-Native Accounting and Actual Continuation*. 预印本 v1，2026. DOI: [10.5281/zenodo.23437454](https://doi.org/10.5281/zenodo.23437454)；完整形式化证明包 H0mework `4301fa8c5bb19bb1e8c3824d7c69be406264ed12`。

<a id="ref-9"></a>
[9] Leonardo de Moura and Sebastian Ullrich. *The Lean 4 Theorem Prover and Programming Language*. Automated Deduction – CADE 28, Lecture Notes in Computer Science, 12699, 625–635, 2021. DOI: `10.1007/978-3-030-79876-5_37`（核读 §1 与 §5 可信小内核及参考检查器）. [原文 PDF](https://lean-lang.org/papers/lean4.pdf).

<a id="ref-10"></a>
[10] Per Martin-Löf. *Intuitionistic Type Theory* (Notes by Giovanni Sambin). Bibliopolis, Naples, 1984（核读 $\Sigma$ 类型投影 pp. 20–26, 33 及命题相等与相等反射 pp. 31–34，尤其 p. 32）. [原文重排本](https://archive-pml.github.io/martin-lof/pdfs/Bibliopolis-Book-retypeset-1984.pdf).

<a id="ref-11"></a>
[11] The Univalent Foundations Program. *Homotopy Type Theory: Univalent Foundations of Mathematics*. Institute for Advanced Study, Princeton, 2013（核读 §2.7 $\Sigma$ 类型及 §2.10 引理 2.10.1 与公理 2.10.3 单值公理）. [原书主页](https://homotopytypetheory.org/book/).

<a id="ref-12"></a>
[12] Jean-Yves Girard. *Linear Logic*. Theoretical Computer Science, 50(1), 1–101, 1987. DOI: `10.1016/0304-3975(87)90045-4`.

<a id="ref-13"></a>
[13] Robert Atkey. *Amortised Resource Analysis with Separation Logic*. Logical Methods in Computer Science, 7(2:17), 1–33, 2011. DOI: `10.2168/LMCS-7(2:17)2011`（核读 §§1, 3.3–3.6, 5）. [作者原文](https://bentnib.org/amortised-sep-logic-journal.pdf).

<a id="ref-14"></a>
[14] Giulio Chiribella, Giacomo Mauro D'Ariano, and Paolo Perinotti. *Informational Derivation of Quantum Theory*. Physical Review A, 84(1), 012311, 2011. DOI: `10.1103/PhysRevA.84.012311`. arXiv:1011.6451（核读 §§II–III 一般操作概率框架、五公理与纯化公设）.

<a id="ref-15"></a>
[15] David Deutsch and Chiara Marletto. *Constructor Theory of Information*. Proceedings of the Royal Society A, 471(2174), 20140540, 2015. DOI: `10.1098/rspa.2014.0540`. arXiv:1405.5563（核读 §§1–2，§6 原理 III 互操作性与原理 IV 可区分性，及 §§7–8）.

<a id="ref-16"></a>
[16] Martín Abadi and Leslie Lamport. *The Existence of Refinement Mappings*. Theoretical Computer Science, 82(2), 253–284, 1991. DOI: `10.1016/0304-3975(91)90224-P`. [作者原文](https://lamport.azurewebsites.net/pubs/abadi-existence.pdf).

<a id="ref-17"></a>
[17] Todd J. Green, Grigoris Karvounarakis, and Val Tannen. *Provenance Semirings*. Proceedings of the 26th ACM SIGMOD-SIGACT-SIGART Symposium on Principles of Database Systems (PODS '07), 31–40, 2007. DOI: `10.1145/1265530.1265535`（核读 §§3–6，命题 3.5、4.2 与定理 4.3）. [作者原文](https://web.cs.ucdavis.edu/~green/papers/pods07.pdf).

<a id="ref-18"></a>
[18] Yufei Cai, Paolo G. Giarrusso, Tillmann Rendel, and Klaus Ostermann. *A Theory of Changes for Higher-Order Languages: Incrementalizing $\lambda$-Calculi by Static Differentiation*. Proceedings of the 35th ACM SIGPLAN Conference on Programming Language Design and Implementation (PLDI '14), 145–155, 2014. DOI: `10.1145/2594291.2594304`. arXiv:1312.0658（核读 §2 定义 2.1, 2.4 与 §3 定理 3.11）.

<a id="ref-19"></a>
[19] Mihai Budiu, Tej Chajed, Frank McSherry, Leonid Ryzhyk, and Val Tannen. *DBSP: Automatic Incremental View Maintenance for Rich Query Languages*. Proceedings of the VLDB Endowment, 16(7), 1601–1614, 2023. DOI: `10.14778/3587136.3587137`. arXiv:2203.16684（核读 §3 定理 3.3–3.4 与 §4.1 $\mathbb Z$-集定义）. [PVLDB 原文](https://www.vldb.org/pvldb/vol16/p1601-budiu.pdf).

<a id="ref-20"></a>
[20] Carlos E. Alchourrón, Peter Gärdenfors, and David Makinson. *On the Logic of Theory Change: Partial Meet Contraction and Revision Functions*. The Journal of Symbolic Logic, 50(2), 510–530, 1985. DOI: `10.2307/2274239`.
