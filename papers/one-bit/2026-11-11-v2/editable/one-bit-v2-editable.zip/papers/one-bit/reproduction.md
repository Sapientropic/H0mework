# One Bit 第二版复现

## 第二版（v2）阅读与可编辑材料

第二版包括中英文正文 PDF，各含附录 A–E，以及可编辑源码包。第二版书目与核读范围见[参考文献](references-v2.bib)和[文献比较](literature.md)。首版成品见[首版记录](https://doi.org/10.5281/zenodo.23437456)。

从 publish 根目录复现第二版 PDF、图件与可编辑包：

```sh
python3 papers/one-bit/figures/render_v2.py
python3 papers/one-bit/figures/render_v2.py --english
python3 shared/scripts/build_pdf.py \
  papers/one-bit/manuscript.md \
  papers/one-bit/manuscript-en.md \
  --output-dir papers/one-bit/build/zenodo-20261111-v2
python3 papers/one-bit/scripts/package_release.py \
  --output-dir papers/one-bit/build/zenodo-20261111-v2
```

需要 Python 3、Pandoc 3、XeLaTeX、xeCJK／unicode-math、Google Chrome、Noto Serif/Sans CJK SC、`fontTools` 与 `pdftoppm`。

核对双语锚点、公式标签、编号环境、跨语种标点卫生、行内代码 ASCII 纯净性以及 OB1–OB13 全部固定源文件 SHA-256 与声明签名：

```sh
python3 papers/one-bit/scripts/check_release.py --homework /path/to/Homework --h0 /path/to/H0mework
```

## 固定研究来源（OB1–OB13）

OB1–OB13 的逐项书面锚点、原声明与公开目标见[第二版选集](release-selection-v2.json)。以下提交给出 Homework 的固定研究源。

- **Y** = `b81a443863f4d7135ebaca92c5bb7d208ccc18ca`（零公理整现实、单构造子展开、根读恒等、单根编译期防火墙、观察安全与零公理初始余面修订）；
- **H** = `e60a86058abcb74b7f2225f2383c182be8343785`（`SpinPair` 连续—量子统一场实现）；
- **F** = `cde4b910929d9bc57554aa56f6ade116bc3b8675`（固定母源 $S_\star$ 原 `Type 0` 三域普遍形成与五条无旁路核验链）；
- **MV4** = `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`（全未来残差请求、同债严格扣款、后缀结算与长计算窗口）；
- **MV5** = `df421ff600085cbc290a7ae946193961bed7c83b`（OB12 已付语法树双负号恢复与跨共尾同态方法续行、OB13 整词逐原语回放与余链微分更新）。

从本地源仓副本直接读取任一固定文件：

```sh
git -C /path/to/Homework show SOURCE_COMMIT:SOURCE_PATH
```

## H0mework 公开证明包

OB2 的单根防火墙和 OB12–OB13 的完整证明选集固定在 `ffa5eeb70130b17db3873407d0cd10a218e45896`。[第二版逐主张映射](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/docs/one-bit-v2-map.json)登记原声明、类型、直接消费者以及 CP483、CP485 原认证。[第二版复现指南](https://github.com/Sapientropic/H0mework/blob/ffa5eeb70130b17db3873407d0cd10a218e45896/docs/one-bit-v2-reproduction.md)给出精确原字节恢复命令。

```sh
python3 tools/one_bit_v2.py entry
python3 tools/one_bit_v2.py build --output .local/one-bit-v2-build
python3 tools/one_bit_v2.py trust --output .local/one-bit-v2-trust
python3 tools/one_bit_v2.py types --output .local/one-bit-v2-types
```

OB1–OB11 的公开证明材料由 H0mework `6bff9d4046b3f89004678244482b1c403837150c`（材料提交 `c40ef754ccbbea96f8c1417f12348e840da5eb82`）统一定位，见固定提交下的[一比特映射](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-map.json)、[准备状态](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-readiness.md)与[复现入口](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-reproduction.md)：

```sh
make check-one-bit-entry
make bootstrap
make check-one-bit-full
```

其中 `H0mework.Checks.OneBit.ZeroLawRootAdmissionRegression` 执行最小闭包构建、`--trust=0` 元数据信任与完整类型核验（公理依赖为空 `[]`）；单构造子发生展开、时序访问生成演化与切面根读分别对应同一公开提交中的 `H0mework.Foundation.Source.AccountedUnfolding`、`H0mework.Foundation.Cofinal.TemporalAnswer` 与 `H0mework.Foundation.Inquiry.Protocol`。复用原包可用 `make check-whole-ledger-full`（OB3、OB5、OB8–OB10）与 `make check-first-release-full`（OB6–OB7）独立完整重建；物理旗舰第三版公开选集见 H0mework `a5e774a4cdef1c5bedc7426efedab7ba20a417ac`。工具链固定为 Lean 4.33.0／Mathlib v4.33.0。
