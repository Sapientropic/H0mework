# 全系列图件视觉语言

所有稿件的图件共用这套规则。matplotlib 管线直接 `import house_style`；手写 SVG 管线从中取色值与字体栈常量，并用 `svg_text.py` 排混合文字（cairosvg 不逐字回退，它按字形把一行拆成中文、拉丁、数学运算符三段并实测定位）。

## 规则

1. **一个强调色。** 朱红 `VERMILION` 只标出每张图要读者看见的那一处对象；其余用墨色 `INK`、灰阶 `SLATE/MUTE/HAIR`，生成对象用深蓝 `DEEP`，次要序列用 `GOLD`，少量填充用 `WASH`。
2. **图内不放大标题。** 标题和阅读说明交给正文图注；图内只留面板小标题、对象标签和必要读数。
3. **按印刷尺寸设计。** 版心约 6 英寸宽。matplotlib 画布乘 `PRINT_SCALE`（结构图用 0.85）；SVG 画布宽度 W 像素时，最小字号不低于 W/60。
4. **字体与正文一致。** matplotlib 的拉丁文用 Latin Modern，公式用 Computer Modern，中文用 Noto Serif CJK SC；中文图以 CJK 字体为首，保证与公式混排不缺字。SVG 的拉丁文与公式用 STIX Two Text，中文用 Noto Serif CJK SC。
5. **编码有定义。** 底色、宽度、亮度若承载数量，图注必须写明；示意图的箭头说明是映射、依赖还是时间推进。
6. **不写工作台语言。** 图内不出现 producer/consumer、消费者、Stage、提交号、文件名。

## 物理旗舰样例

`papers/physics-common-source/figures/` 的五张图是这套规则的首个实现，可作参照：图 4 用底色明度编码读数，图 1 用小图画出反例。

## 字体登记

`~/Library/Fonts` 里的 Noto Serif CJK 若带 `com.apple.quarantine` 标记，macOS 字体服务不会登记它；Chrome 与 cairosvg 会回退到宋体或方框。2026-09-30 已清除标记并以用户范围永久登记。若换机器后图中中文变成宋体，先用 `xattr -l` 检查这些字体文件。

SVG 预览优先走 Chrome 打印 + Poppler 栅格化，与论文 PDF 同一渲染器；cairosvg 对连续 tspan 的排法与 Chrome 不同，数学片段会错位。
