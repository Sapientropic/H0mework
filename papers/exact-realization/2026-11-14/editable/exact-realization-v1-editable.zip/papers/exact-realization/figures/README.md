# 忠实表示与精确反演：主图来源与视觉规范

本目录保存 `papers/exact-realization` 的四套双语矢量主图（共 8 个 `.svg` 与 8 个同名矢量 `.pdf`），统一由 [`make_figures.py`](make_figures.py) 基于全系列共用样式 [`shared/figure-style`](../../../shared/figure-style/README.md) 生成，并经 Headless Chrome 导出矢量 PDF 供阅读版排版嵌入。

| 图号 | 中文文件 | 英文文件 | 呈现的核心结构与定量证物 |
| --- | --- | --- | --- |
| 图 1 | `fig1-architecture.svg` / `.pdf` | `fig1-architecture-en.svg` / `.pdf` | 余像分解、四部分表示与反演结果及数学应用 |
| 图 2 | `fig2-torsion-picard.svg` / `.pdf` | `fig2-torsion-picard-en.svg` / `.pdf` | 特征标分离挠元、平衡代表元跳跃、观察分类与 Picard 线。下栏由逐层 CRT 展开至逆极限、分裂路径复形的 $H^1$ 与秩一整源判据 |
| 图 3 | `fig3-sparse-hankel.svg` / `.pdf` | `fig3-sparse-hankel-en.svg` / `.pdf` | 六个有号幂矩、三阶 Hankel 首块与精确行列式，以及递推、节点筛选、Vandermonde 恢复 |
| 图 4 | `fig4-hilbert-cayley.svg` / `.pdf` | `fig4-hilbert-cayley-en.svg` / `.pdf` | Hilbert 采样前缀能量、$\delta=1$ 的 Jordan 幂曲线与每个 $\delta>0$ 的取等构造。下栏给出 Cayley 双边消项、绝对收敛与两项误差界 |

在 `publish` 根目录运行以下命令生成两种语言的图件。

```sh
python3 papers/exact-realization/figures/make_figures.py
```

可用 `CHROME` 指定 Chrome 或 Chromium 的可执行文件。发布包中的 `web/` 矢量图由图 2–4 的 PDF 经 `pdftocairo -svg` 生成，网页显示沿用阅读版的字形和位置。两种语言共用面板位置、曲线和字号。检查图时以阅读版实际栏宽的 PDF 为准，重点检查数学上下标、矩阵括号、箭头落点及图例与曲线间距。
