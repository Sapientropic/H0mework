#!/usr/bin/env python3
"""Generate the four bilingual vector plates (SVG + Chrome vector PDF) for exact-realization.

Run from the publish root:
    python3 papers/exact-realization/figures/make_figures.py

The plots and matrices use the examples in the manuscript. All coordinates
are in a 1000-unit canvas with a consistent type scale for print.
"""
from __future__ import annotations

from html import escape
from pathlib import Path
import argparse
import math
import os
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, HAIR, DEEP, VERMILION, GOLD, WASH  # noqa: E402
from svg_text import line as text_line, text_width  # noqa: E402

W = 1000
MIN_SIZE = 19
SCRIPT_SIZE = 14
FULLWIDTH_EN = re.compile(r'[｜：；，。（）　]')
CJK_RE = re.compile(r'[\u4e00-\u9fff]')
def chrome_executable() -> str:
    browser = os.environ.get('CHROME')
    if browser:
        return browser
    for name in ('google-chrome', 'chromium', 'chromium-browser'):
        if executable := shutil.which(name):
            return executable
    mac_chrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
    if Path(mac_chrome).is_file():
        return mac_chrome
    raise RuntimeError('Install Chrome or Chromium, or set CHROME to its executable')


def _balanced_lift(val: int, mod: int) -> int:
    return (val + mod // 2) % mod - mod // 2


def compute_e2_sequence(stages: int = 5) -> list[tuple[int, int, int]]:
    """Compute (stage, (stage+1)!, balanced representative of 2-adic idempotent e2).

    e2 satisfies e2 ≡ 1 (mod 2^k) and e2 ≡ 0 (mod odd_part((n+1)!)) via CRT.
    """
    out = []
    for n in range(stages):
        m = math.factorial(n + 1)
        p2 = 1
        odd = m
        while odd % 2 == 0:
            p2 *= 2
            odd //= 2
        rep = (odd * pow(odd, -1, p2)) % m
        out.append((n, m, _balanced_lift(rep, m)))
    return out


class Plate:
    def __init__(self, height: int, lang: str, title: tuple[str, str]):
        self.h = height
        self.lang = lang
        chosen = self.choose(title)
        self.items = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
            f'viewBox="0 0 {W} {height}" role="img" xml:lang="{lang}">',
            f'<title>{escape(chosen)}</title>',
            '<rect width="100%" height="100%" fill="white"/>',
        ]

    def choose(self, value):
        return value[0 if self.lang == 'zh' else 1] if isinstance(value, tuple) else value

    def text(self, x: float, y: float, value, size: float = MIN_SIZE,
             color: str = INK, weight: int = 400, anchor: str = 'start',
             max_width: float = 960):
        s = str(self.choose(value))
        assert size >= MIN_SIZE, (s, size)
        if self.lang == 'en':
            bad = FULLWIDTH_EN.findall(s)
            assert not bad, f'full-width char in EN figure text: {s!r} -> {bad}'
            cjk = CJK_RE.findall(s)
            assert not cjk, f'CJK char in EN figure text: {s!r} -> {cjk}'
        w = text_width(s, size, min_size=SCRIPT_SIZE)
        w *= 1.07 if self.lang == 'en' and weight >= 600 else 1.0
        assert w <= max_width, (self.lang, s, round(w, 1), max_width)
        self.items.append(text_line(x, y, s, size, color, weight, anchor, min_size=SCRIPT_SIZE))

    def card(self, x: float, y: float, w: float, h: float,
             fill: str = 'white', stroke: str = HAIR, accent: str | None = DEEP):
        self.items.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="1.2"/>'
        )
        if accent:
            self.items.append(
                f'<rect x="{x}" y="{y + 3}" width="4" height="{h - 6}" fill="{accent}"/>'
            )

    def rect(self, x: float, y: float, w: float, h: float,
             fill: str = WASH, stroke: str = 'none', sw: float = 0.0,
             opacity: float = 1.0, rx: float = 0.0):
        op = f' fill-opacity="{opacity:.3f}"' if opacity < 1.0 else ''
        rx_attr = f' rx="{rx}"' if rx > 0 else ''
        st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke != 'none' and sw > 0 else ''
        self.items.append(
            f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}"'
            f'{rx_attr} fill="{fill}"{op}{st}/>'
        )

    def box(self, x: float, y: float, w: float, h: float, title, lines,
            fill: str = 'white', accent: str = DEEP, line_step: float = 32):
        self.card(x, y, w, h, fill=fill, accent=accent)
        self.text(x + 16, y + 30, title, 21, weight=600, max_width=w - 28)
        for i, row in enumerate(lines):
            self.text(x + 16, y + 61 + line_step * i, row, max_width=w - 28)

    def line(self, x1: float, y1: float, x2: float, y2: float,
             stroke: str = SLATE, width: float = 1.6, arrow: bool = False,
             dash: str = ''):
        dash_attr = f' stroke-dasharray="{dash}"' if dash else ''
        if not arrow:
            self.items.append(
                f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                f'stroke="{stroke}" stroke-width="{width}"{dash_attr}/>'
            )
            return
        dx, dy = x2 - x1, y2 - y1
        ln = math.hypot(dx, dy)
        assert ln > 1e-6
        ux, uy = dx / ln, dy / ln
        px, py = -uy, ux
        ah, aw = 8.5, 4.3
        sx2 = x2 - ux * (ah * 0.7)
        sy2 = y2 - uy * (ah * 0.7)
        self.items.append(
            f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{sx2:.1f}" y2="{sy2:.1f}" '
            f'stroke="{stroke}" stroke-width="{width}"{dash_attr}/>'
        )
        p1x, p1y = x2 - ux * ah + px * aw, y2 - uy * ah + py * aw
        p2x, p2y = x2 - ux * ah - px * aw, y2 - uy * ah - py * aw
        self.items.append(
            f'<polygon points="{x2:.1f},{y2:.1f} {p1x:.1f},{p1y:.1f} {p2x:.1f},{p2y:.1f}" fill="{stroke}"/>'
        )

    def polyline(self, pts: list[tuple[float, float]], stroke: str = DEEP,
                 width: float = 2.4, dash: str = ''):
        dash_attr = f' stroke-dasharray="{dash}"' if dash else ''
        coords = ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)
        self.items.append(
            f'<polyline fill="none" stroke="{stroke}" stroke-width="{width}"{dash_attr} points="{coords}"/>'
        )

    def circle(self, cx: float, cy: float, r: float = 4.6,
               fill: str = DEEP, stroke: str = 'white', sw: float = 1.2):
        self.items.append(
            f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
        )

    def matrix(self, cx: float, cy: float, rows, color: str = INK):
        step = 29
        nrows, ncols = len(rows), len(rows[0])
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                x = cx + (j - (ncols - 1) / 2) * step
                y = cy + (i - (nrows - 1) / 2) * step + 6
                self.text(x, y, str(val).replace('-', '−'), color=color, anchor='middle', max_width=step)
        half_w, half_h = ncols * step / 2 + 1, nrows * step / 2 - 2
        for sign in (-1, 1):
            x = cx + sign * half_w
            tip = x - sign * 6
            self.polyline([(tip, cy - half_h), (x, cy - half_h), (x, cy + half_h), (tip, cy + half_h)],
                          stroke=color, width=1.5)

    def legend(self, x: float, y: float, value, color: str, dash: str = '', width: float = 214):
        self.line(x, y - 6, x + 23, y - 6, stroke=color, width=2.4, dash=dash)
        self.text(x + 31, y, value, color=SLATE if color == GOLD else color, max_width=width - 31)

    def save(self, stem: str) -> Path:
        suffix = '' if self.lang == 'zh' else '-en'
        out = HERE / f'{stem}{suffix}.svg'
        out.write_text('\n'.join(self.items + ['</svg>']) + '\n')
        return out


# ---------------------------------------------------------------------------
# Figure 1: Global four-pillar representation & exact inversion architecture
# ---------------------------------------------------------------------------
def draw_fig1(lang: str) -> Path:
    s = Plate(608, lang, (
        '忠实表示与精确反演的四柱总架构与下游接口',
        'Four-pillar architecture of faithful representations and exact inversion',
    ))

    # Coimage factorization feeds the four settings through a common spine.
    s.box(26, 18, 460, 115,
          ('源、读数与配对（§1–§2）', 'Sources, readouts and pairings (§1–§2)'),
          [
              ('环模、离散矩、Hilbert 流与 Banach 算子',
               'Modules, moments, Hilbert streams and operators'),
              ('求值 {i:e}: {i:A} → {i:D}，乘积配对 {i:B}({i:u},{i:v})={i:ev}({i:u}){i:ev}({i:v})',
               'Readout {i:e}: {i:A} → {i:D}, pairing {i:B}({i:u},{i:v})={i:ev}({i:u}){i:ev}({i:v})'),
          ],
          accent=SLATE)

    s.box(514, 18, 460, 115,
          ('余像分解（§2–§8）', 'Coimage factorization (§2–§8)'),
          [
              '{i:A}/ker {i:e} ≃ im {i:e} ⊆ {i:D}',
              ('关系商的零类 ⇔ 原元素在边界像中',
               'Zero relation class ⇔ element in boundary image'),
          ],
          accent=GOLD)

    s.box(26, 162, 460, 141,
          ('I · 特征标与完备化（§2）', 'I · Characters and completions (§2)'),
          [
              ('特征标双对偶的求值像 {i:P}{sub:χ}({i:A}) ≃ {i:A}',
               'Character bidual evaluation image {i:P}{sub:χ}({i:A}) ≃ {i:A}'),
              ('多观测的联合核 ker({i:f},{i:g}) = ker {i:f} ∩ ker {i:g}',
               'Joint kernel ker({i:f},{i:g}) = ker {i:f} ∩ ker {i:g}'),
              ('Kummer 挠塔、阶乘完备化与整源跳跃判据',
               'Kummer, factorial completion and integral descent'),
          ],
          accent=DEEP)

    s.box(514, 162, 460, 141,
          ('II · Picard 线与行列式（§3–§4）', 'II · Picard lines and determinants (§§3–4)'),
          [
              ('有限投射模的局部秩与顶外幂线',
               'Projective local ranks and top exterior lines'),
              ('{i:y}{sup:2}={i:x}{sup:3}−{i:x} 上 (1,0) 的非自由可逆理想',
               'Nonfree invertible ideal of (1,0) on {i:y}{sup:2}={i:x}{sup:3}−{i:x}'),
              ('双格配对、Smith 指数、复形整线与极限',
               'Lattice pairings, Smith index, integral lines and limits'),
          ],
          accent=DEEP)

    s.box(26, 331, 460, 141,
          ('III · 自由线性化与稀疏矩（§5–§6）', 'III · Free words and sparse moments (§§5–6)'),
          [
              ('自由词 ℤ[{i:S}] 与不变的不可观测核',
               'Free words ℤ[{i:S}] and the unobservable kernel'),
              ('自由常量表的净额与合冲分解',
               'Net value and relation decomposition of free tables'),
              ('有号 Hankel 首块最大非奇异阶 {i:r}',
               'Largest nonsingular leading Hankel block of order {i:r}'),
          ],
          accent=DEEP)

    s.box(514, 331, 460, 141,
          ('IV · 奇异 Gram 与算子逆（§7–§8）', 'IV · Singular Gram and inverses (§§7–8)'),
          [
              ('奇异 Gram 的核陪集与投影强极限',
               'Gram kernel cosets and strong projection limits'),
              ('Hilbert 流有原像 ⇔ 全前缀零残差且能量有界',
               'Hilbert preimage ⇔ zero residuals, bounded energy'),
              ('线性 Cayley 幂增长 ⇒ 显式逆与最优范数界',
               'Linear Cayley growth ⇒ inverse with sharp bound'),
          ],
          accent=VERMILION)

    s.box(26, 502, 948, 88,
          ('数学应用（§9.5）', 'Mathematical applications (§9.5)'),
          [
              ('挠类与离散脉冲矩恢复　·　闭算子图重构与差分预解逆　·　双格高度配对与四项复形整线',
               'Torsion and pulse moments   ·   Closed operator graphs and resolvents   ·   Lattice pairings and determinant lines'),
          ],
          fill=WASH, accent=GOLD)

    s.line(486, 82, 514, 82, stroke=SLATE, width=1.8, arrow=True)
    s.line(744, 133, 744, 145, stroke=DEEP, width=1.6)
    s.line(256, 145, 744, 145, stroke=DEEP, width=1.6)
    s.line(256, 145, 256, 162, stroke=DEEP, width=1.6, arrow=True)
    s.line(744, 145, 744, 162, stroke=DEEP, width=1.6, arrow=True)
    s.line(500, 145, 500, 317, stroke=DEEP, width=1.6)
    s.line(256, 317, 744, 317, stroke=DEEP, width=1.6)
    s.line(256, 317, 256, 331, stroke=DEEP, width=1.6, arrow=True)
    s.line(744, 317, 744, 331, stroke=DEEP, width=1.6, arrow=True)

    # Independent downstream feeds from all four pillars (sides for I & II, bottom for III & IV)
    s.line(26, 232, 10, 232, stroke=GOLD, width=1.6)
    s.line(10, 232, 10, 546, stroke=GOLD, width=1.6)
    s.line(10, 546, 26, 546, stroke=GOLD, width=1.6, arrow=True)
    s.line(974, 232, 989, 232, stroke=GOLD, width=1.6)
    s.line(989, 232, 989, 546, stroke=GOLD, width=1.6)
    s.line(989, 546, 974, 546, stroke=GOLD, width=1.6, arrow=True)
    s.line(256, 472, 256, 502, stroke=GOLD, width=1.8, arrow=True)
    s.line(744, 472, 744, 502, stroke=VERMILION, width=1.8, arrow=True)

    return s.save('fig1-architecture')


# ---------------------------------------------------------------------------
# Figure 2: Torsion survival, factorial jumps, 4-way disposition & Picard line
# ---------------------------------------------------------------------------
def draw_fig2(lang: str) -> Path:
    s = Plate(882, lang, (
        '特征标分离挠元、阶乘完备化与整源判据、Picard 非自由线',
        'Torsion separation, factorial completion, and a nonfree Picard line',
    ))
    s.card(20, 18, 468, 459, accent=DEEP)
    s.text(36, 48, ('特征标分离挠元（§2.1）', 'Characters separate torsion (§2.1)'),
           21, weight=600, max_width=436)
    s.text(36, 80, '{i:A} = (ℤ/2ℤ){sup:2},  {i:x} = (0, 1) ∈ {i:A},  2{i:x} = 0', max_width=436)
    s.text(36, 110, '∀ {i:ℓ} ∈ Hom({i:A}, ℤ), 2{i:ℓ}({i:x}) = 0 ⇒ {i:ℓ}({i:x}) = 0', color=SLATE)
    s.text(36, 140, '{i:χ}({i:a},{i:b}) = {i:b}/2 mod ℤ ⇒ {v:χ(x)=1/2+ℤ≠0}')
    s.line(36, 158, 472, 158, stroke=HAIR)

    s.text(36, 189, ('阶乘平衡代表元的相邻跳跃（§2.5）', 'Adjacent jumps of balanced lifts (§2.5)'),
           21, weight=600, max_width=436)
    s.rect(38, 208, 14, 14, fill=VERMILION, rx=2)
    s.text(60, 222, ('非整类 {i:e}{sub:2}', 'Nonintegral {i:e}{sub:2}'), color=VERMILION, max_width=169)
    s.rect(242, 208, 14, 14, fill=DEEP, rx=2)
    s.text(264, 222, ('整数 −2', 'Integer −2'), color=DEEP, max_width=193)
    s.text(36, 252, '|{i:b}{sub:n+1} − {i:b}{sub:n}|/{i:M}{sub:n}', max_width=151)
    s.legend(224, 252, ('阈值 1', 'Threshold 1'), GOLD, dash='6,4')

    # Pair the bars so equal jumps remain individually visible.
    sequence = compute_e2_sequence()
    moduli = [m for _, m, _ in sequence]
    balanced = [b for _, _, b in sequence]
    integral = [_balanced_lift(-2, m) for m in moduli]
    ax0, ax1, floor = 66, 465, 397
    scale = 54
    for tick in (0, 1, 2):
        y = floor - scale * tick
        stroke, dash = {0: (SLATE, ''), 1: (GOLD, '6,4'), 2: (HAIR, '4,4')}[tick]
        s.line(ax0, y, ax1, y, stroke=stroke, width=1.5, dash=dash)
        s.text(ax0 - 11, y + 6, str(tick), color=SLATE, anchor='end', max_width=28)
    s.line(ax0, floor, ax0, 277, stroke=SLATE)
    for i, m in enumerate(moduli[:-1]):
        x = 117 + 99 * i
        jumps = ((balanced, -14, VERMILION), (integral, 14, DEEP))
        for reps, offset, color in jumps:
            step = abs(reps[i + 1] - reps[i]) // m
            if step:
                s.rect(x + offset - 10, floor - scale * step, 20, scale * step, fill=color, rx=2)
            else:
                s.line(x + offset - 10, floor, x + offset + 10, floor, stroke=color, width=4)
        s.text(x, 426, f'{i}→{i + 1}', color=SLATE, anchor='middle', max_width=62)
    values = ', '.join(str(b).replace('-', '−') for b in balanced)
    s.text(36, 454, f'{{i:b}}{{sub:0…4}}({{i:e}}{{sub:2}}) = ({values})', color=SLATE, max_width=436)

    s.card(512, 18, 468, 459, accent=DEEP)
    s.text(528, 48, ('线性观察 {i:o} 的四支（§2.2）', 'Four cases of a linear readout {i:o} (§2.2)'),
           21, weight=600, max_width=436)
    for x, header in [(728, ('满射', 'Surjective')), (884, ('非满射', 'Not surjective'))]:
        s.text(x, 84, header, color=SLATE, anchor='middle', max_width=148)
    for y, header in [(140, ('单射', 'Injective')), (212, ('非单射', 'Not injective'))]:
        s.text(528, y, header, color=SLATE, max_width=120)
    for x, y, title, value, color in [
        (654, 101, ('双射', 'Bijective'), '{i:P} ≃ {i:O}', DEEP),
        (810, 101, ('覆盖不足', 'Coverage gap'), '{i:y} ∉ im {i:o}', SLATE),
        (654, 173, ('核损失', 'Kernel loss'), '0 ≠ {i:k} ∈ ker {i:o}', SLATE),
        (810, 173, ('两种损失', 'Both defects'), '{i:k} ≠ 0, {i:y} ∉ im {i:o}', SLATE),
    ]:
        s.card(x, y, 148, 64, fill=WASH if color == DEEP else 'white', accent=None)
        s.text(x + 74, y + 26, title, color=color, weight=600, anchor='middle', max_width=130)
        s.text(x + 74, y + 51, value, color=color, anchor='middle', max_width=130)

    s.line(528, 254, 964, 254, stroke=HAIR)
    s.text(528, 285, ('投射性、局部秩与 Picard 类（§3）', 'Projectivity, local rank and Picard class (§3)'),
           21, weight=600, max_width=436)
    for y, label in [
        (318, ('ℤ/4ℤ 上的 ℤ/2ℤ 有限但非投射', 'ℤ/2ℤ over ℤ/4ℤ is finite and nonprojective')),
        (348, ('ℚ×ℚ 上的 ℚ×0 在两处秩为 1 和 0', 'ℚ×0 over ℚ×ℚ has local ranks 1 and 0')),
        (378, ('投射模常秩 {i:n} 时，⋀{sup:n}{i:M} 为可逆线', 'Projective of constant rank {i:n} ⇒ ⋀{sup:n}{i:M} invertible')),
        (409, ('例　{i:y}{sup:2}={i:x}{sup:3}−{i:x} 上取点 {i:P}=(1,0)', 'Take {i:P}=(1,0) on {i:y}{sup:2}={i:x}{sup:3}−{i:x}')),
        (441, '{i:L}{sub:P} = ({i:x}−1,{i:y}), rank {i:L}{sub:P} = 1, [{i:L}{sub:P}] ≠ 1'),
    ]:
        s.text(528, y, label, color=VERMILION if y == 441 else INK, max_width=436)

    s.card(20, 495, 960, 369, accent=GOLD)
    s.text(36, 523, ('阶乘完备化与整源判据（定理 2.7）', 'Factorial completion and integral descent (Theorem 2.7)'),
           21, weight=600, max_width=650)
    s.text(964, 523, '{i:M}{sub:n}=({i:n}+1)!', color=SLATE, anchor='end', max_width=160)
    s.box(36, 545, 448, 116,
          ('有限层的中国剩余定理', 'Chinese remainder theorem at each stage'),
          ['{i:M}{sub:n} = ∏{sub:p∣Mₙ} {i:p}{sup:vₚ(Mₙ)}',
           '{i:L}/{i:M}{sub:n}{i:L} ≃ ∏{sub:p∣Mₙ} {i:L}/{i:p}{sup:vₚ(Mₙ)}{i:L}'],
          fill=WASH, accent=GOLD)
    s.box(516, 545, 448, 116,
          ('取相容的逆极限', 'Pass to the compatible inverse limits'),
          [('{i:p}{sup:j+1} ∣ {i:M}{sub:n}（{i:n} 充分大）',
            '{i:p}{sup:j+1} ∣ {i:M}{sub:n} for sufficiently large {i:n}'),
           '∏{sub:p} {i:L̂}{sub:p} ≃ {i:L̂}{sub:!}'],
          fill=WASH, accent=GOLD)
    s.box(36, 691, 448, 157,
          ('分裂路径复形 {i:C}', 'Split path complex {i:C}'),
          [('{i:H}{sup:1}({i:C}) = {i:Q}{sub:τ}，过渡映射逐度满射',
            '{i:H}{sup:1}({i:C}) = {i:Q}{sub:τ}, stage maps surject in each degree'),
           ('满射塔的 lim → holim 为拟同构', 'Here lim → holim is a quasi-isomorphism'),
           '{i:H}{sup:1}(holim{sub:n}({i:C}/{i:M}{sub:n}{i:C})) ≃ {i:Q̂}{sub:τ,!}'],
          accent=DEEP)
    s.box(516, 691, 448, 157,
          ('秩一格 {i:L} ≃ ℤ 的平衡代表元', 'Balanced lifts in a rank-one lattice {i:L} ≃ ℤ'),
          ['{i:b}{sub:n+1} − {i:b}{sub:n} = {i:M}{sub:n}{i:k}{sub:n},  {i:k}{sub:n} ∈ ℤ',
           '|{i:k}{sub:n}| < 1 ⇔ {i:k}{sub:n} = 0',
           ('最终稳定 ⇔ 来自唯一整数', 'Eventually constant ⇔ unique integer source')],
          accent=VERMILION)
    s.line(484, 601, 516, 601, stroke=GOLD, arrow=True)
    s.line(740, 661, 740, 675, stroke=GOLD)
    s.line(260, 675, 740, 675, stroke=GOLD)
    s.line(260, 675, 260, 691, stroke=DEEP, arrow=True)
    s.line(740, 675, 740, 691, stroke=VERMILION, arrow=True)
    return s.save('fig2-torsion-picard')


# ---------------------------------------------------------------------------
# Figure 3: Signed sparse moment cancellation trap & Hankel order lock (R49)
# ---------------------------------------------------------------------------
def draw_fig3(lang: str) -> Path:
    s = Plate(599, lang, (
        '用首 Hankel 块确定支撑大小，再筛选节点并恢复有号权重',
        'Hankel order selection, support detection, and signed weight recovery',
    ))
    nodes = (1, -1, 2)
    weights = (1, -1, 0)
    moments = [sum(a * t ** j for t, a in zip(nodes, weights)) for j in range(6)]
    s.card(20, 18, 960, 288, accent=DEEP)
    s.text(36, 48, ('六个有号幂矩确定支撑基数（定理 6.2）', 'Support size from six signed moments (Theorem 6.2)'),
           21, weight=600, max_width=655)
    s.text(964, 48, ('有理数域算例', 'Example over ℚ'), color=SLATE, anchor='end', max_width=156)
    vals = ', '.join(str(m) for m in moments)
    s.text(36, 79, f'({{i:M}}{{sub:0}}, …, {{i:M}}{{sub:5}}) = ({vals})', max_width=416)
    s.text(964, 79, '{i:H}{sub:w} = {i:V}{sub:w} diag({i:a}|{sub:S}) {i:V}{sub:w}{sup:T}',
           color=SLATE, anchor='end', max_width=398)

    for i, (w, det) in enumerate([(1, 0), (2, -4), (3, 0)]):
        x = 36 + i * 315
        cx = x + 149
        color = VERMILION if det else SLATE
        s.card(x, 98, 298, 155, fill=WASH if det else 'white', accent=None)
        s.text(cx, 128, f'{{i:H}}{{sub:{w}}}', 21, weight=600, color=color, anchor='middle', max_width=60)
        s.matrix(cx, 180, [[moments[p + q] for q in range(w)] for p in range(w)], color=color)
        val = str(det).replace('-', '−')
        s.text(cx, 240, f'det {{i:H}}{{sub:{w}}} = {val}', color=color,
               weight=600, anchor='middle', max_width=154)
    s.text(500, 284, 'max { {i:w} : det {i:H}{sub:w} ≠ 0 } = {v:r = 2}',
           weight=600, anchor='middle', max_width=540)

    s.box(20, 337, 300, 244, ('求解首一递推', 'Solve for the recurrence'),
          ['{i:H}{sub:2}{i:c} = −({i:M}{sub:2}, {i:M}{sub:3}){sup:T}',
           '{i:c} = (−1, 0){sup:T}'],
          accent=DEEP)
    s.line(36, 451, 304, 451, stroke=HAIR)
    s.text(36, 485, ('首一多项式', 'Monic polynomial'), color=SLATE, max_width=268)
    s.text(36, 530, '{i:P}({i:t}) = {i:t}{sup:2} + {i:c}{sub:1}{i:t} + {i:c}{sub:0} = {i:t}{sup:2} − 1',
           21, color=DEEP, weight=600, max_width=268)

    s.box(350, 337, 300, 244, ('在候选节点上求值', 'Evaluate at candidate nodes'),
          ['{i:t} ∈ {1, −1, 2}'],
          accent=DEEP)
    s.rect(430, 420, 130, 80, fill=WASH, rx=4)
    s.line(365, 461, 634, 461, stroke=HAIR)
    s.text(366, 447, '{i:t}', color=SLATE, max_width=54)
    s.text(366, 487, '{i:P}({i:t})', color=SLATE, max_width=54)
    for x, t in zip((463, 527, 601), nodes):
        val = t ** 2 - 1
        color = VERMILION if val == 0 else SLATE
        s.text(x, 447, str(t).replace('-', '−'), anchor='middle', max_width=46)
        s.text(x, 487, str(val), color=color, weight=600, anchor='middle', max_width=46)
    s.text(366, 544, ('支撑节点 {1, −1}', 'Support nodes {1, −1}'),
           21, color=VERMILION, weight=600, max_width=268)

    s.box(680, 337, 300, 244, ('恢复有号权重', 'Recover signed weights'),
          ['{i:V}{sub:2}{i:a}|{sub:S} = ({i:M}{sub:0}, {i:M}{sub:1}){sup:T}'],
          accent=VERMILION)
    s.matrix(741, 454, ((1, 1), (1, -1)))
    s.text(781, 460, '{i:a}|{sub:S}', max_width=44)
    s.text(829, 460, '=', max_width=22)
    s.matrix(866, 454, ((0,), (2,)))
    s.text(696, 528, '({i:a}(1), {i:a}(−1)) = (1, −1)', 21, weight=600, max_width=268)
    s.text(696, 558, '{i:a}(2) = 0', color=SLATE, max_width=268)

    s.line(500, 306, 500, 321, stroke=DEEP)
    s.line(170, 321, 500, 321, stroke=DEEP)
    s.line(170, 321, 170, 337, stroke=DEEP, arrow=True)
    s.line(320, 459, 350, 459, stroke=DEEP, arrow=True)
    s.line(650, 459, 680, 459, stroke=VERMILION, arrow=True)
    return s.save('fig3-sparse-hankel')


# ---------------------------------------------------------------------------
# Figure 4: Hilbert stream preimage (R50/R62) & Cayley power-growth inverse (R52/R61)
# ---------------------------------------------------------------------------
def draw_fig4(lang: str) -> Path:
    s = Plate(853, lang, (
        'Hilbert 前缀能量、Cayley 双边逆及两项截断误差',
        'Hilbert prefix energy, the two-sided Cayley inverse, and truncation errors',
    ))
    s.card(20, 18, 468, 416, accent=DEEP)
    s.text(36, 48, ('Hilbert 采样流的像（定理 8.1）', 'Hilbert stream preimages (Theorem 8.1)'),
           21, weight=600, max_width=436)
    s.text(36, 81, ('有原像 ⇔ ∀{i:n}, {i:r}{sub:n}=0 且 sup{sub:n} {i:E}{sub:n}<∞',
                    'Preimage ⇔ all {i:r}{sub:n}=0 and sup{sub:n} {i:E}{sub:n}<∞'),
           max_width=436)
    s.legend(36, 114, '{i:d}{sub:i}=1/{i:i}', VERMILION, width=183)
    s.legend(218, 114, '{i:d}{sub:i}={i:i}{sup:−1/2}', SLATE, dash='6,4')
    s.legend(218, 145, '{i:E}{sub:∞}=π{sup:2}/6', GOLD, dash='6,4')
    s.text(36, 145, '{i:E}{sub:n}', color=SLATE, max_width=51)

    floor = 318

    def energy_y(e: float) -> float:
        return floor - e * 44

    def prefix_x(n: int) -> float:
        return 95 + (n - 1) * 30

    for tick in (0, 1, 2, 3):
        y = energy_y(tick)
        s.line(76, y, 465, y, stroke=SLATE if tick == 0 else HAIR, dash='' if tick == 0 else '4,4')
        s.text(66, y + 6, str(tick), color=SLATE, anchor='end', max_width=26)
    s.line(76, floor, 76, 158, stroke=SLATE)
    limit_y = energy_y(math.pi ** 2 / 6)
    s.line(76, limit_y, 465, limit_y, stroke=GOLD, width=1.8, dash='6,4')
    for n in (1, 4, 8, 12):
        s.line(prefix_x(n), floor, prefix_x(n), floor + 5, stroke=SLATE)
        s.text(prefix_x(n), 347, str(n), color=SLATE, anchor='middle', max_width=34)
    s.text(465, 347, '{i:n}', color=SLATE, anchor='end', max_width=20)
    for exponent, color, dash in ((1, SLATE, '6,4'), (2, VERMILION, '')):
        acc = 0.0
        points = []
        for n in range(1, 13):
            acc += 1 / n ** exponent
            points.append((prefix_x(n), energy_y(acc)))
        s.polyline(points, stroke=color, width=2.6, dash=dash)
        for x, y in points:
            s.circle(x, y, r=3.8, fill=color)
    gap_x = prefix_x(4) - 10
    energy_four_y = energy_y(sum(1 / n ** 2 for n in range(1, 5)))
    s.line(gap_x, energy_four_y, prefix_x(4), energy_four_y, stroke=DEEP, width=1)
    s.line(gap_x, energy_four_y, gap_x, limit_y, stroke=DEEP, width=2)
    for y in (energy_four_y, limit_y):
        s.line(gap_x - 4, y, gap_x + 4, y, stroke=DEEP, width=1.5)
    s.text(36, 382, ('平方误差　‖{i:x}{sub:★}−{i:x}{sub:n}‖{sup:2} = {i:E}{sub:∞}−{i:E}{sub:n}',
                     'Squared error  ‖{i:x}{sub:★}−{i:x}{sub:n}‖{sup:2} = {i:E}{sub:∞}−{i:E}{sub:n}'),
           color=DEEP, max_width=436)
    s.text(36, 413, ('任一前缀 {i:r}{sub:n}≠0 时无原像', 'A nonzero prefix residual rules out a preimage'),
           color=SLATE, max_width=436)

    s.card(512, 18, 468, 416, accent=VERMILION)
    s.text(528, 48, ('Jordan 块的线性增长与阻尼', 'Jordan growth and damping'),
           21, weight=600, max_width=436)
    s.text(528, 81, ('绘图取 {i:δ}=1，{i:q}=1/2', 'Plot for {i:δ}=1 and {i:q}=1/2'), color=SLATE, max_width=436)
    s.legend(528, 114, '‖({i:I}+{i:J}){sup:n}‖{sub:1}={i:n}+1', SLATE, dash='6,4')
    s.legend(528, 145, '‖{i:K}{sup:n}‖{sub:1}=({i:n}+1)2{sup:−n}', VERMILION)

    def power_x(n: int) -> float:
        return 583 + n * 43

    def growth_y(v: float) -> float:
        return floor - v * 17

    for tick in (0, 3, 6, 9):
        y = growth_y(tick)
        s.line(567, y, 956, y, stroke=SLATE if tick == 0 else HAIR, dash='' if tick == 0 else '4,4')
        s.text(557, y + 6, str(tick), color=SLATE, anchor='end', max_width=26)
    s.line(567, floor, 567, 158, stroke=SLATE)
    for n in (0, 2, 4, 6, 8):
        s.line(power_x(n), floor, power_x(n), floor + 5, stroke=SLATE)
        s.text(power_x(n), 347, str(n), color=SLATE, anchor='middle', max_width=34)
    s.text(965, 347, '{i:n}', color=SLATE, anchor='end', max_width=20)
    for q, color, dash in ((1, SLATE, '6,4'), (0.5, VERMILION, '')):
        points = [(power_x(n), growth_y((n + 1) * q ** n)) for n in range(9)]
        s.polyline(points, stroke=color, width=2.6, dash=dash)
        for x, y in points:
            s.circle(x, y, r=3.8, fill=color)

    s.text(528, 379, '∀ {i:δ}>0,   {i:A}{sub:δ}={i:J}/{i:δ},   {i:B}=1', max_width=297)
    s.text(528, 413, '‖({i:A}{sub:δ}−{i:I}){sup:−1}‖{sub:1} = 1+{i:δ}{sup:−1} = {i:M}{sub:δ,1}',
           color=VERMILION, weight=600, max_width=294)
    s.text(850, 392, '{i:J} =', max_width=42)
    s.matrix(922, 386, ((0, 1), (0, 0)))

    s.card(20, 452, 960, 383, accent=DEEP)
    s.text(36, 483, ('从线性幂增长到双边逆与截断界（定理 8.4）',
                     'From linear power growth to inversion and truncation (Theorem 8.4)'),
           21, weight=600, max_width=696)
    s.text(964, 483, '{i:M}{sub:δ,B}=({i:1}+{i:δ}){i:B}/{i:δ}', color=SLATE, anchor='end', max_width=172)
    s.box(36, 504, 288, 147,
          ('阻尼代换', 'Damp the shifted powers'),
          ['{i:q} = (1+{i:δ}){sup:−1},  {i:K} = {i:q}(1+{i:δA})',
           '1−{i:K} = −{i:δq}({i:A}−1)',
           '‖{i:K}{sup:n}‖ ≤ {i:B}({i:n}+1){i:q}{sup:n}'],
          fill=WASH)
    s.box(356, 504, 288, 147,
          ('有限和两端消项', 'Telescope on both sides'),
          ['{i:S}{sub:m}=∑{sub:n<m}{i:K}{sup:n},  {i:F}{sub:m}=−{i:δqS}{sub:m}',
           '(1−{i:K}){i:S}{sub:m} = {i:S}{sub:m}(1−{i:K})',
           '                           = 1−{i:K}{sup:m}'])
    s.box(676, 504, 288, 147,
          ('绝对收敛与范数界', 'Convergence and bounds'),
          ['∑{sub:n≥0}({i:n}+1){i:q}{sup:n}=(1−{i:q}){sup:−2}',
           'ℐ = lim{sub:m→∞} {i:F}{sub:m} = ({i:A}−1){sup:−1}',
           '‖{i:F}{sub:m}‖, ‖ℐ‖ ≤ {i:M}{sub:δ,B}'],
          fill=WASH)

    s.line(324, 575, 356, 575, stroke=DEEP, arrow=True)
    s.line(644, 575, 676, 575, stroke=DEEP, arrow=True)
    s.text(500, 685, '{i:F}{sub:m}{i:ỹ} − ℐ{i:y} = {i:F}{sub:m}({i:ỹ}−{i:y}) − {i:K}{sup:m}ℐ{i:y}',
           23, weight=600, anchor='middle', max_width=660)
    s.line(500, 651, 500, 660, stroke=DEEP)

    s.box(36, 719, 448, 99,
          ('观测误差的放大界与 {i:m} 无关', 'Noise term bounded independently of {i:m}'),
          ['‖{i:F}{sub:m}({i:ỹ}−{i:y})‖ ≤ {i:M}{sub:δ,B}‖{i:ỹ}−{i:y}‖'],
          accent=DEEP)
    s.box(516, 719, 448, 99,
          ('剩余尾项随 {i:m} 增大趋于零', 'The truncation tail tends to zero'),
          ['‖{i:K}{sup:m}ℐ{i:y}‖ ≤ {i:B}({i:m}+1){i:q}{sup:m}{i:M}{sub:δ,B}‖{i:y}‖'],
          accent=VERMILION)
    s.line(500, 693, 500, 706, stroke=DEEP)
    s.line(260, 706, 740, 706, stroke=DEEP)
    s.line(260, 706, 260, 719, stroke=DEEP, arrow=True)
    s.line(740, 706, 740, 719, stroke=VERMILION, arrow=True)
    return s.save('fig4-hilbert-cayley')


def svg_to_pdf(svg: Path, pdf: Path) -> None:
    head = svg.read_text(errors='replace')[:4000]
    box = re.search(r'viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)', head)
    assert box is not None, f'SVG without viewBox: {svg}'
    w, h = box.group(1), box.group(2)
    html = pdf.with_suffix('.html')
    html.write_text(
        '<!doctype html><html><head><style>'
        f'@page{{size:{w}px {h}px;margin:0}}html,body{{margin:0;padding:0}}'
        f'img{{display:block;width:{w}px;height:{h}px}}</style></head>'
        f'<body><img src="{svg.as_uri()}"></body></html>'
    )
    try:
        res = subprocess.run(
            [chrome_executable(), '--headless=new', '--disable-gpu', '--no-pdf-header-footer',
             '--allow-file-access-from-files', f'--print-to-pdf={pdf}', html.as_uri()],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        if res.returncode != 0 or not pdf.exists():
            raise RuntimeError(f'Chrome failed printing {svg}: {res.stdout}')
    finally:
        html.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('zh', 'en', 'both'), default='both')
    args = parser.parse_args()
    langs = ('zh', 'en') if args.lang == 'both' else (args.lang,)
    e2 = compute_e2_sequence()
    assert [r[2] for r in e2] == [0, -1, -3, 9, -15], e2
    for lang in langs:
        for fn in (draw_fig1, draw_fig2, draw_fig3, draw_fig4):
            svg = fn(lang)
            pdf = svg.with_suffix('.pdf')
            svg_to_pdf(svg, pdf)
            print(f'generated {svg.name} + {pdf.name}')


if __name__ == '__main__':
    main()
