# 忠实表示与精确反演：从商、矩与流恢复源对象

*Faithful Representations and Exact Inversion from Quotients, Moments, and Streams*

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**形式验证说明。** 本文采用 Lean 4（`v4.33.0`）与 `mathlib` [@deMouraUllrich2021Lean4; @mathlib2020] 中的形式化声明。附录 B 给出固定来源、公开范围及代表性类型，正文另给出数学证明和纸笔算例。

## 摘要

本文研究从商、有限矩和读数流中恢复源对象。对阿贝尔群的单射，若环境群 $p$-可除，余核 $p$-幂挠塔到源 $p$-进完备化的 Kummer 连接极限满射。源的 $p$-幂挠有界时，环境挠塔的极限单射到余核挠塔的极限，像恰为连接映射的核。环境群唯一 $p$-可除时，连接极限为同构。秩一阶乘完备化中的相干元来自整数，当且仅当其平衡代表元最终恒定。

任意域上，已知互异地址的有限候选集和稀疏上界 $k$ 时，前 $2k$ 个幂矩唯一恢复支撑与权重，即使低阶首块相消，最大非奇异首 Hankel 块仍给出真实支撑基数。复 Hilbert 空间中，允许探针线性相关，读数流有原像当且仅当各前缀拟合残差全为零且最小平方范数有界。最小范数解的平方重构误差等于极限能量减去前缀能量。复 Banach 代数中，若 $\|(1+\delta A)^n\|\le(n+1)B$ 且 $\delta>0$，绝对收敛级数给出 $(A-1)^{-1}$。锐界 $(1+\delta)B/\delta$ 同时控制任意阶截断对观测噪声的放大。

**关键词：** 特征标双对偶像；Kummer 余核挠塔；阶乘平衡代表元；无基底行列式接口；有号稀疏 Hankel 恢复；Hilbert 流像判据；线性增长 Cayley 算子逆

## Abstract

We prove four recovery results. For an injection of abelian groups, the Kummer map from the cokernel’s $p$-power torsion limit to the source’s $p$-adic completion is surjective if the ambient group is $p$-divisible and an isomorphism if it is uniquely $p$-divisible. Bounded source $p$-power torsion makes the ambient torsion limit inject into the cokernel torsion limit with image the kernel of the Kummer map. In rank-one factorial completion, integer classes are exactly those with eventually constant balanced representatives.

Over any field, $2k$ power moments recover a source with at most $k$ active weights on a known finite set of distinct addresses. The largest nonsingular leading Hankel block gives the support size even when smaller blocks cancel. In a complex Hilbert space with possibly dependent probes, a stream has a preimage exactly when every prefix fits and the minimum squared norms are bounded. Squared reconstruction error equals the limiting energy minus the prefix energy. In a complex Banach algebra, $\|(1+\delta A)^n\|\le(n+1)B$ for $\delta>0$ gives an absolutely convergent inverse series for $A-1$. The sharp inverse bound $(1+\delta)B/\delta$ controls noise at every truncation order.

**Keywords:** character bidual image; Kummer cokernel torsion; factorial balanced representative; basis-free determinant interface; signed sparse Hankel recovery; Hilbert stream preimages; linear-growth Cayley inverse

---

<a id="sec-1"></a>

## 1 引言：问题设定、核心结果与统一主线

### 1.1 四类局部观察失真与问题设定

从局部读数、有限商或流式截断恢复源对象时，不同数学分支中常出现四类结构性障碍。第一类是**挠元湮灭**：用整数、实数或复数线性泛函观察含挠模时，有限阶挠元全部落入核中——对 $A=\mathbb{Z}/2\mathbb{Z}$，任意 $\ell\in\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Z})$ 满足 $2\ell(x)=\ell(2x)=0$，故 $\ell\equiv 0$。第二类是**局部自由但全局无基**：在仿射椭圆曲线 $y^2=x^3-x$ 的坐标环上，有理点 $(1,0)$ 对应的极大理想是常秩 $1$ 有限生成投射模，但不存在全局自由基，任何预设全局坐标基的行列式表示在入口处即告失效。第三类是**未知稀疏度下的低阶相消**：当幂矩 $M_j=\sum_{s\in S} a_s \tau(s)^j$ 允许带号权重或取自正特征有限域时，即使真实活跃基数 $r=|S|\le k$ 非零，低阶首 Hankel 子式 $H_w$（$w<r$）仍可能因求和抵消而退化为零，从而需要在未知 $r$ 时给出不依赖首主子式顺序非奇异的定阶方法。第四类是**无穷维能量发散与非压缩算子截断**：在 Hilbert 空间中，逐阶有限前缀相容（零残差）的数据流仍可能因最小范数能量发散而不存在 $\ell^2$ 原像；在完备复 Banach 代数中，当偏移算子 $C_\delta(A)=1+\delta A$ 仅满足一阶线性幂增长 $\|(1+\delta A)^n\|\le (n+1)B$ 时，虽然谱条件 $\sigma(A)\subseteq\overline{D}(-1/\delta,1/\delta)$ 已蕴含 $1\notin\sigma(A)$ 从而 $A-1$ 可逆，但若不经谱分解而直接求取显式级数表示、可达的算子范数常数 $(1+\delta)B/\delta$ 以及不随截断阶数恶化的含噪误差界，仍需专门的阻尼中心化分析。

本文在不附加“有限生成”“无挠”“全局自由基”“正定权重”或“算子范数压缩”假设的前提下处理上述四类问题：对恢复与逼近问题（§2.1, §2.5, §6, §7–§8）给出显式构造与定量恒等式；对一般模观察与投射秩分派（§2.2 命题 2.2(3)、§3.1 命题 3.1）则在经典逻辑下给出带显式核／余核或素理想见证的分类。

<a id="sec-1-2"></a>

### 1.2 五枚三分钟纸笔验算锚点

以下五个初等算例各只需数行手算，分别对应本文五项关键机制与反例边界。

<a id="ex-1-1"></a>

**例 1.1（五枚纸笔验算锚点）。**

**(a) 特征标双对偶像分离 2-挠元（§2.1）。**
在 $A=(\mathbb{Z}/2\mathbb{Z})\times(\mathbb{Z}/2\mathbb{Z})$ 中取非零挠元 $x=(0,1)$。任取 $\ell\in\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Z})$，由 $2x=(0,0)$ 得 $\ell(x)=0$。改取加法群特征标 $\chi\in\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Q}/\mathbb{Z})$，$\chi(a,b)=b/2\bmod\mathbb{Z}$，则双重求值给出 $\mathrm{ev}(x)(\chi)=\chi(0,1)=1/2+\mathbb{Z}\neq 0$，将 $x$ 单射映入求值像 $P_{\chi,\mathbb{Z}}(A)$。

**(b) 阶乘模平衡代表元的最终稳定与全模跳跃（§2.5）。**
在一维整格 $L=\mathbb{Z}$ 的阶乘完备化 $\widehat{\mathbb{Z}}_{!}=\varprojlim_n \mathbb{Z}/(n+1)!\mathbb{Z}$ 中，取半开区间 $[-\lfloor (n+1)!/2\rfloor,\,(n+1)!-\lfloor (n+1)!/2\rfloor)$ 内的唯一平衡代表元 $b_n$。对整数 $s=-2\in\mathbb{Z}$，前五阶模 $(n+1)!\in\{1,2,6,24,120\}$ 下的代表元为 $0,0,-2,-2,-2$，归一化跳跃 $|b_{n+1}(-2)-b_n(-2)|/(n+1)!$ 依次为 $0,1,0,0$，自 $n\ge 2$ 起恒为零。而对 2-进幂等元 $e_2\in\widehat{\mathbb{Z}}$（在各阶满足 $e_2\equiv 1\pmod{2^{v_2((n+1)!)}}$ 且对奇素数幂模为 $0$），中国剩余定理给出：
$$b_0(e_2)=0,\quad b_1(e_2)=-1,\quad b_2(e_2)=-3,\quad b_3(e_2)=9,\quad b_4(e_2)=-15.\tag{1.1}$$
前四步相邻差 $|b_{n+1}(e_2)-b_n(e_2)|$ 依次为 $1,2,12,24$，每步均为 $(n+1)!$ 的非零整数倍；若 $e_2$ 来自整数 $s$，则 $s$ 被每个 $3$ 的幂整除，因而 $s=0$，这与其 $2$-进坐标为 $1$ 矛盾。由定理 2.7，在任意晚阶之后仍有幅度至少为 $(n+1)!$ 的跳跃，尽管个别晚阶（如 $n=27,29$）的跳跃为零。

**(c) 椭圆曲线 $y^2=x^3-x$ 上的非自由秩 1 可逆理想（§3.2）。**
在光滑仿射曲线的坐标环 $R_E=\mathbb{Q}[x,y]/(y^2-x^3+x)$ 中，有理点 $P=(1,0)$ 对应极大理想 $L_P=(x-1,y)$。由 $y^2=(x-1)x(x+1)$ 与 $\gcd(x-1,x(x+1))=1$ 得 $L_P^2=(x-1)R_E$，故 $L_P$ 可逆，其分数理想逆为 $(x-1)^{-1}L_P$。若 $L_P=(g)$，写 $g=a(x)+b(x)y$，则 $g^2=u(x-1)$，其中 $u\in R_E^\times$。范数 $N(g)=g(x,y)g(x,-y)$ 取值于 $\mathbb{Q}[x]$ 且保持乘法，所以 $N(u)\in\mathbb{Q}[x]^\times=\mathbb{Q}^\times$。由 $N(g)^2=N(u)(x-1)^2$ 得 $N(g)=c(x-1)$，其中 $c\in\mathbb{Q}^\times$。然而 $N(g)=a(x)^2-b(x)^2(x^3-x)$ 在 $b=0$ 时次数为偶数，$b\ne 0$ 时第二项次数至少为 $3$，两项的非零最高次项奇偶相异，无法相消。因此 $N(g)$ 的次数不可能为 $1$。

**(d) 低阶相消下的有号稀疏 Hankel 定阶（§6.2）。**
设稀疏上界 $k=3$，候选地址集 $A=\{1,-1,2\}\subset\mathbb{Q}$，真实信号为支撑在 $\{1,-1\}$ 上的带号源 $a=(1,-1,0)$（活跃基数 $r=2$）。前 $2k=6$ 个幂矩 $M_j=\sum a_i \tau_i^j$ 为 $(0,2,0,2,0,2)$，前三阶首 Hankel 块为：
$$H_1=[0]\;(\det H_1=0),\qquad H_2=\begin{pmatrix}0&2\\2&0\end{pmatrix}\;(\det H_2=-4\neq 0),\qquad H_3=\begin{pmatrix}0&2&0\\2&0&2\\0&2&0\end{pmatrix}\;(\det H_3=0).\tag{1.2}$$
虽然 $H_1$ 因正负抵消退化为零，最大非奇异首块 $H_2$ 仍锁定 $r=2$。由此解得 $c=-H_2^{-1}(0,2)^{\mathsf T}=(-1,0)^{\mathsf T}$，首一多项式 $P(t)=t^2-1$ 在 $A$ 中的根集恰好为 $\{1,-1\}$，再由 Vandermonde 逆 $\bigl(\begin{smallmatrix}1&1\\1&-1\end{smallmatrix}\bigr)^{-1}\binom{0}{2}=\binom{1}{-1}$ 恢复权重。

**(e) Hilbert 采样流三情形与 Jordan 块可达范数常数（§§8.1, 8.3）。**
在 $H=\ell^2(\mathbb{N}_{\ge 1},\mathbb{C})$ 上取标准正交族 $u_i=e_i$（对应正文 $0$-始下标的前 $n$ 项前缀）：

1. 取 $d_i=1/i$，每阶残差 $r_n=0$，前缀能量 $E_n=\sum_{i=1}^n i^{-2}\uparrow E_\infty=\pi^2/6$，平方误差满足 $\|x_\star-x_n\|^2=E_\infty-E_n=\sum_{i=n+1}^\infty i^{-2}$；
2. 取 $d_i=i^{-1/2}$，每步有限前缀残差仍为 $r_n=0$，但 $E_n=\sum_{i=1}^n i^{-1}\to\infty$，不存在 $\ell^2$ 实现元；
3. 取线性相关探针 $u_1=e_1, u_2=e_1$ 与冲突读数 $d=(1,2,0,\dots)$，数据有界但第 $2$ 阶残差 $r_2\neq 0$，不存在实现元。

在 $(\mathbb{C}^2,\|\cdot\|_1)$ 上赋予矩阵诱导算子范数。对任意 $\delta>0$，取 $J=\bigl(\begin{smallmatrix}0&1\\0&0\end{smallmatrix}\bigr)$ 和 $A_\delta=J/\delta$。由 $J^2=0$ 得 $(I+\delta A_\delta)^n=I+nJ$，故其范数为 $n+1$，可取 $B=1$。又 $(A_\delta-I)^{-1}=-(I+J/\delta)$，因而
$$\|\mathcal{I}_\delta(A_\delta)\|_1=1+\frac{1}{\delta}=\frac{1+\delta}{\delta}B.\tag{1.3}$$
因此定理 8.4(1) 的一致范数界对每个 $\delta>0$ 都能取等。

<a id="sec-1-3"></a>

### 1.3 核心定理总览与正反控制表

为区分基础代数封装与核心数学推进，全文将主要实质结果集中于以下五条定理，其余同构封装、无基底接口与辅助性质按命题、引理与推论定级（架构见图 1；正反边界对照见表 1）。

<a id="thm-1-1"></a>

**定理 1.1（核心结果总览）。**

1. **Kummer 余核挠塔的极限（定理 2.5，R54）。** 对单射同态 $\iota:L\to_{\mathbb{Z}}M$、余核 $C=M/\operatorname{im}\iota$ 与素数 $p$，$M$ 的 $p$-可除性蕴含连接极限 $\delta_\infty:T_p(C)\to\widehat{L}_p$ 满射。$L$ 的 $p$-幂挠有界时，$\alpha_\infty:T_p(M)\to T_p(C)$ 单射，且 $\operatorname{im}\alpha_\infty=\ker\delta_\infty$。$M$ 唯一 $p$-可除时，$\delta_\infty$ 为同构。
2. **阶乘完备化与整源跳跃判据（定理 2.7，R57–R58）。** 全素数完备化 $\prod_p\widehat{L}_p$ 与阶乘完备化 $\widehat{L}_{!}=\varprojlim_n L/(n+1)!L$ 同构。当 $L\cong\mathbb{Z}$ 时，相干元 $v\in\widehat{L}_{!}$ 来自唯一整源 $s\in L$ 当且仅当其平衡代表元 $b_n(v)$ 最终恒定。等价地，在非退化的赋范线性读出 $E_{\mathrm{eff}}$ 下，充分晚的相邻跳跃严格小于 $(n+1)!\|u\|$。
3. **任意域上未知稀疏度有号矩恢复（定理 6.2；R49）**：设 $K$ 为任意域，$\tau:I\to K$ 单射，未知源 $a\in K^{(I)}$ 支撑于已知有限集 $A\subseteq I$ 且 $r:=|\operatorname{supp}(a)|\le k$。由前 $2k$ 个幂矩构成的首 Hankel 块满足带号求值 Gram 分解 $H_w=V_w\operatorname{diag}(a|_S)V_w^{\mathsf T}$，其最大非奇异首块阶数满足 $r=\max\{w\le k:\det H_w\neq 0\}$，并由 $H_r^{-1}$ 的首一递推多项式在 $A$ 中的根集与 $V_r^{-1}$ 唯一还原支撑与权重。
4. **奇异探针下的 Hilbert 流像与算子原像判据（定理 8.1, 推论 8.3；R50–R51）**：对复 Hilbert 空间 $H$ 中任意（允许线性相关的）可数探针族 $\{u_i\}_{i\in\mathbb{N}}$ 与数据流 $d:\mathbb{N}\to\mathbb{C}$，存在 $x\in H$ 使 $\forall i,\langle u_i,x\rangle_H=d_i$ 当且仅当逐前缀奇异 Gram 残差 $r_n(d)=0$（$\forall n$）且最小范数拟合能量满足 $\sup_n E_n(d)<\infty$；此时前缀投影强极限 $x_\star$ 给出唯一最小范数解并满足 $\|x_\star-x_n(d)\|_H^2=E_\infty-E_n(d)$。对有界算子 $A\in\mathcal{B}(H,F)$ 与分离探针 $\{v_i\}\subset F$，经伴随拉回 $A^*v_i$ 立即刻画作用流像并给出完整原像陪集 $x_\star+\ker A$。
5. **线性 Cayley 幂增长下的显式算子逆与步数无关截断界（定理 8.4；R52, R61）**：在完备复 Banach 代数中，若 $\|(1+\delta A)^n\|\le (n+1)B$（$\delta>0$），令 $q=(1+\delta)^{-1}$，则绝对收敛级数 $\mathcal{I}_\delta(A)=-\delta q\sum_{n=0}^\infty q^n(1+\delta A)^n$ 给出 $(A-1)^{-1}$ 且满足可达上界 $\|(A-1)^{-1}\|\le M_{\delta,B}=\frac{1+\delta}{\delta}B$；在复 Banach 空间上，第 $m$ 步截断算子满足一致界 $\|F_{\delta,m}(A)\|\le M_{\delta,B}$，含噪重构误差满足 $\|F_{\delta,m}(A)\tilde y-(A-1)^{-1}y\|\le M_{\delta,B}\|y-\tilde y\|+B(m+1)q^m M_{\delta,B}\|y\|$。

![图 1｜忠实表示与精确反演的证明结构](figures/fig1-architecture.svg)

**图 1｜忠实表示与精确反演的证明结构。** 余像分解贯穿四部分。底栏列出挠类与离散脉冲矩恢复、闭算子图重构与差分逆，以及双格配对与整行列式线。

**表 1　核心正向结论与配对反例／边界对照总表**

| 支柱与主题 | 核心正向结论 | 配对反例／边界控制 | 正文位置 |
| --- | --- | --- | --- |
| **I. 特征标与阶乘跳跃** | 任意模 $A\simeq_R P_{\chi,R}(A)$（R1）；Kummer 三层极限（R54）；$(n+1)!$ 平衡代表元整源判准（R58） | $(\mathbb{Z}/2\mathbb{Z})^2$ 上 $\operatorname{Hom}_{\mathbb{Z}}(-,\mathbb{Z})\equiv 0$；$\mathbb{Q}$ 中 $1$ 在全素数拓扑不可分（R11）；$e_2$ 在 $n=27,29$ 零跳但晚阶共尾再跳（R58） | §2.1–§2.5；例 1.1(a)–(b)；定理 2.5, 2.7 |
| **I. 配对与观察分类** | 观察四支见证分类（R4）；约化环乘积配对核等于求值核（R15） | $\mathbb{Z}/4\mathbb{Z}$ 中幂零元 $2\neq 0$ 使全部乘积配对为零（R15）；单一观察盲区非零核元（R12） | §2.2–§2.3；命题 2.2–2.3 |
| **II. Picard 与行列式接口** | 常秩顶外幂扭子（R5）与五组无基底行列式接口（§4） | $y^2=x^3-x$ 点 $(1,0)$ 非自由理想（R6）；$\mathbb{Z}/4\mathbb{Z}$ 上 $\mathbb{Z}/2\mathbb{Z}$ 非投射；变秩乘积环双素理想；$-\mathrm{id}$ 保持 $-1$ 符号 | §3–§4；命题 3.1–3.2, 4.1–4.5；例 1.1(c), 4.1 |
| **III. 语法与合冲呈示** | 展开树无求值语法左逆（R20）；自由常量表构造性合冲呈示（R43） | 常零算子 $\kappa\equiv 0$ 抹平语义值但保留语法树；净额为零的差表由合冲证书还原自由分录 | §5.2, §6.1；命题 5.2, 6.1；例 6.1 |
| **III. 稀疏 Hankel 恢复** | 任意域 $K$ 与有限候选集 $A$ 上最大非奇异首块定阶与 $2k$ 矩恢复（R49） | $\mathbb{Q}$ 上权重 $(1,-1)$ 与 $\mathbb{F}_7$ 上权重 $(3,4)$（模 $7$ 相消）均使 $H_1=[0]$ 奇异而由 $H_2$ 定阶 | §6.2；例 1.1(d), 6.2；定理 6.2 |
| **IV. 奇异与增量 Gram** | 奇异 Gram 解陪集与分离强收敛（R44, R46）；首枢轴选行（R47）与对偶列单秩更新（R59） | 含零向量或相关探针时 $\ker G\neq 0$，最小范数解落在 $(\ker G)^\perp$ 而全解集为仿射核陪集 | §7.1–§7.2；命题 7.1–7.3；例 7.1 |
| **IV. Hilbert 流像** | 逐前缀零残差 $\wedge$ 能量有界充要刻画流像（R50, R51）；投影子空间恢复收敛（R62） | 零残差但能量发散流 $d_i=i^{-1/2}$ 无原像；数据有界但相关探针冲突流在 $r_2\neq 0$ 被拒 | §8.1–§8.2；例 1.1(e)；定理 8.1, 推论 8.3 |
| **IV. Cayley 算子逆** | $\|(1+\delta A)^n\|\le (n+1)B$ 下显式双边逆、可达常数与一致截断预算（R52, R61） | 任意 $\delta>0$ 的缩放 Jordan 块 $A_\delta$ 的移位幂范数为 $n+1$，且 $\|(A_\delta-I)^{-1}\|_1=1+1/\delta$，达到 $B=1$ 时的上界 | §8.3；例 1.1(e), 8.1；定理 8.4 |

<a id="sec-1-4"></a>

### 1.4 按学科背景的阅读路线

读者在浏览例 1.1 与定理 1.1 后，可按专业兴趣选择独立阅读路线：

- **交换代数与同调代数**：阅读 **§2.1–§2.5 与附录 A**，重点关注 Kummer 余核挠塔三层前提结论（定理 2.5）、满射上链塔同伦极限拟同构（引理 2.6）与阶乘模平衡代表元跳跃判准（定理 2.7）。
- **代数几何与形式化接口设计**：阅读 **§3–§4 与 §9.2**，查看椭圆曲线 $y^2=x^3-x$ 非自由秩 $1$ 理想的初等与形式化双路证明（命题 3.2）以及五组推迟基底选择的行列式与逆极限映射锥接口（命题 4.1–4.5）。
- **符号计算、控制论与离散反问题**：阅读 **§5–§6 与附录 C.1**，查看环模不可观最大不变子模（命题 5.3(2)）、自由常量表合冲呈示（命题 6.1）以及任意域未知稀疏度 Hankel 恢复定理（定理 6.2）。
- **泛函分析与算子反问题**：阅读 **§7–§8、§9.4 与附录 C.2**，查看有限维奇异 Gram 部件（§7）、无穷维奇异探针流像充要判据与能量缺口（定理 8.1）以及线性 Cayley 幂增长下的显式算子逆与截断误差分析（定理 8.4）。

<a id="sec-1-5"></a>

### 1.5 统一主线、文献坐标与记号约定

**贯穿主线与求值 Gram 桥。** 全文各部分围绕线性观察映射 $e:X\to Y$ 的四个递进问题组织：(i) **核与余像**：何时 $\ker e=0$，有核时如何通过余像 $X/\ker e$ 或逆极限保留忠实坐标（§2）；(ii) **载体不变量**：当余像同构成立且模有限生成投射时，何时存在无基底顶外幂线，何处受阻于非平凡 Picard 类（§3–§4）；(iii) **带号离散恢复**：当和式求值发生抵消时，如何借合冲纤维坐标保留分录，或借求值双线性型恢复稀疏源（§5–§6）；(iv) **无穷维流像与算子逆**：当观测为可数内积流或非压缩算子差分时，何时存在原像并给出带显式常数的逼近（§7–§8）。值得注意的是，支柱 III 与支柱 IV 之间由同一矩阵结构相连：定理 6.2 中的首 Hankel 块分解
$$H_w = V_w\,\operatorname{diag}(a|_S)\,V_w^{\mathsf T}$$
正是单项式求值泛函 $1,t,\dots,t^{w-1}$ 在带权离散测度 $\sum_{s\in S} a_s\delta_{\tau(s)}$ 下的**带号（或任意域值）求值 Gram 矩阵**。当 $K=\mathbb{R}$ 且权重 $a_s>0$ 时，$H_w$ 即第 7–8 节研究的正半定 Gram 矩阵，低阶非退化自动保持；当实权重有正有负，或在正特征域中计算时，低阶首块 $H_w$（$w<r$）可发生各向同性相消，唯独在 $w=r$ 处因 $V_r$ 成为方阵而锁死 $\det H_r\neq 0$（注记 C.1）。

**文献坐标。** 本文在 **§9** 对照 41 篇核实原始文献：(1) 特征标对偶（Pontryagin [@Pontryagin1934]、Baer [@Baer1940]、Lambek [@Lambek1964]、Stacks `01D6` [@Stacks01D6]）与逆极限同调（Milnor [@Milnor1962]、Weibel [@Weibel1994]、Jannsen [@Jannsen1988]）；(2) 行列式函子与算术复形背景（Knudsen–Mumford [@KnudsenMumford1976]、Deligne [@Deligne1987]、Stacks `0FJ9` [@Stacks0FJ9]、Tate [@Tate1966]、Nekovář [@Nekovar2006]、Macias Castillo–Sano [@MaciasCastilloSano2026]）；(3) 张量积与增量微分／差群／不可观子空间（Stacks `00CX` [@Stacks00CX]、Green 等 [@Green2007Provenance]、Cai 等 [@Cai2014Changes]、DBSP [@Budiu2023DBSP]、Ellerman [@Ellerman2014Accounting]、Kálmán [@Kalman1963]）及稀疏 Prony–Hankel 恢复（Prony [@Prony1795]、Kronecker [@Kronecker1881]、Ben-Or–Tiwari [@BenOrTiwari1988]、Peter–Plonka [@PeterPlonka2013]、Candès–Fernandez-Granda [@CandesFernandezGranda2014]）；(4) 广义逆、矩问题与算子值域／增长界（Schur [@Schur1917]、Penrose [@Penrose1955]、F. Riesz [@Riesz1910]、Aronszajn [@Aronszajn1950]、Douglas [@Douglas1966]、Adcock–Hansen [@AdcockHansen2016]、von Neumann [@vonNeumann1930]、Kreiss [@Kreiss1962]、Katznelson–Tzafriri [@KatznelsonTzafriri1986]）；(5) Lean 4 形式化数学（de Moura–Ullrich [@deMouraUllrich2021Lean4]、mathlib [@mathlib2020]、Angdinata–Xu [@AngdinataXu2023]、Buzzard–Commelin–Massot [@BuzzardCommelinMassot2020]、Commelin–Topaz [@CommelinTopaz2024] 及上游基础篇 [@Gao2026OneBitV2; @Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2]）。

**记号约定。** 全文以 $\mathbb{N}=\{0,1,2,\dots\}$ 表示自然数，$R$ 表示含幺交换环。对集合 $I$ 与模 $M$，$M^{(I)}$（当 $M=\mathbb{Z}$ 时亦记 $\mathbb{Z}[I]$）表示有限支撑函数模，单点基元记作 $\delta_i$ 或 $[i]$。对阿贝尔群 $L$，记全素数完备化乘积为 $\widehat{L}_{\mathrm{all}}:=\prod_{p\in\mathbb{P}}\widehat{L}_p$。复 Hilbert 空间内积 $\langle u,v\rangle_H$ 对第一变元共轭线性、对第二变元线性；闭子空间 $S\le H$ 上的正交投影记为 $P_S$。有限族 $u:\iota\to H$ 的合成映射为 $\Phi_u(a):=\sum_{i\in\iota} a_i u_i$，内积读数映射为 $\mathrm{rhs}_u(x):=(\langle u_i,x\rangle_H)_{i\in\iota}$，Gram 矩阵为 $(G_u)_{ij}=\langle u_i,u_j\rangle_H$。

---

## 第一部：模特征标双对偶像、观察分类与共尾拓扑下降

<a id="sec-2"></a>

## 2 任意交换环模的特征标表示、观察分类与 Kummer—阶乘完备化

将 $R$-模 $A$ 映入其普通线性双对偶 $\operatorname{Hom}_R(\operatorname{Hom}_R(A,R),R)$ 时，一旦 $A$ 含挠元，求值映射便可能非单射。本节先以 $\mathbb{Q}/\mathbb{Z}$-特征标双对偶的求值像给出无有限性或无挠假设的忠实表示，再整理核商逆极限与四支分类，最后证明 Kummer 余核挠塔的三层极限结论与阶乘模平衡代表元的整源下降定理。

### 2.1 特征标双对偶像同构（R1）

<a id="def-2-1"></a>

**定义 2.1（$R$-模的 $\mathbb{Q}/\mathbb{Z}$-特征标双对偶与求值像）。** 设 $R$ 为交换环，$A$ 为 $R$-模。记加法群特征标模为 $A^\vee_{\chi}:=\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Q}/\mathbb{Z})$，赋予双对偶 $A^{\vee\vee}_{\chi}:=\operatorname{Hom}_{\mathbb{Z}}(A^\vee_{\chi},\mathbb{Q}/\mathbb{Z})$ 诱导 $R$-模结构 $(r\cdot \Lambda)(\chi):=\Lambda(a\mapsto \chi(r\cdot a))$。定义双重求值映射
$$\mathrm{ev}_{R,A}:A\longrightarrow A^{\vee\vee}_{\chi},\qquad \mathrm{ev}_{R,A}(a)(\chi):=\chi(a),\tag{2.1}$$
记其像子模为 $P_{\chi,R}(A):=\operatorname{im}(\mathrm{ev}_{R,A})\le A^{\vee\vee}_{\chi}$，余限制映射为 $\eta_{R,A}:A\to P_{\chi,R}(A)$。

<a id="prop-2-1"></a>

**命题 2.1（R1：特征标双对偶像同构与函子自然性）。** 对任意交换环 $R$ 与任意 $R$-模 $A$：

1. $\mathrm{ev}_{R,A}$ 是单射 $R$-线性映射，故余限制 $\eta_{R,A}$ 给出典范 $R$-线性同构 $\mathrm{equiv}_{R,A}:A\xrightarrow{\sim} P_{\chi,R}(A)$（因而任意 $R$-线性映射 $g:A\to B$ 唯一通过 $\eta_{R,A}$ 分解为 $\tilde g=g\circ\mathrm{equiv}_{R,A}^{-1}$）；
2. 对任意 $R$-线性映射 $f:A\to B$，双重对偶映射 $f^{\vee\vee}(\Lambda):=\Lambda\circ f^\vee$ 将 $P_{\chi,R}(A)$ 映入 $P_{\chi,R}(B)$，诱导协变函子 $P_{\chi,R}:\mathrm{Mod}_R\to\mathrm{Mod}_R$ 并满足自然交换等式 $P_{\chi,R}(f)\circ\eta_{R,A}=\eta_{R,B}\circ f$。

**证明。** 对 $r\in R$、$a\in A$ 与 $\chi\in A^\vee_{\chi}$，$\mathrm{ev}_{R,A}(r\cdot a)(\chi)=\chi(r\cdot a)=(r\cdot \mathrm{ev}_{R,A}(a))(\chi)$，故 $\mathrm{ev}_{R,A}$ 为 $R$-线性映射。若 $a\in A\setminus\{0\}$，在循环子群 $\mathbb{Z}a\le A$ 上构造同态 $h:\mathbb{Z}a\to\mathbb{Q}/\mathbb{Z}$：当 $a$ 无穷阶时取 $h(a)=\frac12+\mathbb{Z}$，当 $a$ 阶为 $m\ge 2$ 时取 $h(a)=\frac1m+\mathbb{Z}$，均有 $h(a)\neq 0$。因 $\mathbb{Q}/\mathbb{Z}$ 可除，由 Baer 内射判准 [@Baer1940; @Stacks01D6]，$h$ 延拓为全局特征标 $\chi\in A^\vee_{\chi}$ 满足 $\chi(a)\neq 0$，证得 $\ker(\mathrm{ev}_{R,A})=0$ 及 $\eta_{R,A}$ 为同构，唯一分解随之成立。对 $f:A\to B$，由 $(f^{\vee\vee}(\mathrm{ev}_{R,A}(a)))(\psi)=\psi(f(a))=\mathrm{ev}_{R,B}(f(a))(\psi)$ 即得像保持与自然性。$\square$

<a id="rem-2-1"></a>

**注记 2.1（求值像边界与整数泛函盲区）。** 命题 2.1 仅在求值像 $P_{\chi,R}(A)$ 上建立同构，不声称 $\mathrm{ev}_{R,A}:A\to A^{\vee\vee}_\chi$ 满射：即使对 $A=\mathbb{Z}$，纯代数双对偶 $\mathbb{Z}^{\vee\vee}_\chi\cong\widehat{\mathbb{Z}}$ 也真包含 $\mathbb{Z}$。相对地，若改用整数线性对偶 $\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Z})$，则如图 2 左上所示，$(\mathbb{Z}/2\mathbb{Z})^2$ 中的非零元 $(0,1)$ 在所有整数线性读出下均映为 $0$，而在 $P_{\chi,\mathbb{Z}}(A)$ 中保持非零并与模自同态相容。

![图 2｜特征标分离挠元、阶乘完备化整源判据与 Picard 非自由线](figures/fig2-torsion-picard.svg)

**图 2｜特征标分离挠元、阶乘完备化整源判据与 Picard 非自由线。** 左上以特征标分离 $(0,1)$，并比较 $e_2$ 与整数 $-2$ 的归一化阶乘跳跃。右上按单射与满射列出四种观察情形，并列举投射性、局部秩与非自由 Picard 线。下栏从逐层中国剩余定理取逆极限，得到分裂路径复形的 $H^1$ 完备化与秩一格的整源判据（定理 2.7）。

### 2.2 核商逆极限、两项关系复形与观察四支分类（R2–R4, R9–R10, R13）

当观察映射 $e$ 非单射时，以下命题归纳单步与逆系统核商、两项关系复形及带缺陷见证的四支分类。

<a id="prop-2-2"></a>

**命题 2.2（R2–R4, R9–R10, R13：核商逆极限、关系商复形与观察失真分类）。**

1. **相对核商与相容塔逆极限（R2–R3）**：对阿贝尔群同态 $e:C\to\operatorname{Hom}_{\mathbb{Z}}(D,\mathbb{Z})$，余像 $C/\ker e$ 单射嵌入目标，且线性映射 $f:C\to Q$ 通过 $C/\ker e$ 唯一分解当且仅当 $\ker e\le\ker f$。一般地，给定交换环 $R$ 上满足 $t_n\circ e_{n+1}=e_n$ 的阶段评价族 $e_n:G\to C_n$，包含链 $\ker e_{n+1}\le\ker e_n$ 诱导满射商塔 $G/\ker e_{n+1}\twoheadrightarrow G/\ker e_n$ 及其逆极限 $K_\infty:=\varprojlim_n(G/\ker e_n)$（锥映射 $\sigma:G\to K_\infty$）；对 $K_\infty$ 上任意线性评价 $e_\infty:K_\infty\to\operatorname{Hom}_R(D,R)$，有 $K_\infty/\ker e_\infty\xrightarrow{\sim}\operatorname{im}(e_\infty)$，此同构由 $[x]\mapsto e_\infty(x)$ 给出。令 $C_\infty=\varprojlim_n C_n$，并记 $j:K_\infty\hookrightarrow C_\infty$ 为逐阶嵌入 $[g]\mapsto e_n(g)$ 诱导的映射，则
   $$C_\infty/j(K_\infty)\hookrightarrow\varprojlim_n\bigl(C_n/\operatorname{im}(e_n)\bigr),\qquad [(c_n)_n]\longmapsto ([c_n])_n.$$
   若另一相容塔满足 $s_n e_n=e'_n a$ 与 $t'_n s_{n+1}=s_n t_n$，则 $[g]\mapsto[a(g)]$ 给出相容的阶段余像映射。
2. **两项关系复形与截断尾残差（R9–R10, R13）**：设 $G_{\mathrm{cl}}$ 为生成元自由 $\mathbb{Z}$-模，$R_{\mathrm{cl}}\le G_{\mathrm{cl}}$ 为关系子模，包含映射 $d:R_{\mathrm{cl}}\hookrightarrow G_{\mathrm{cl}}$ 构成集中于 $0,1$ 度的两项上链复形（$d^2=0$），其一阶上同调即关系商模 $Q_{\mathrm{rel}}:=G_{\mathrm{cl}}/R_{\mathrm{cl}}$，满足 $[w]=0\iff w\in\operatorname{im}(d)$。保持 $R_{\mathrm{cl}}$ 的移位自同态下降到 $Q_{\mathrm{rel}}$。在 R13 的相邻历史中，后拍 $H_{m+1}$ 的生成元闭包 $G_{m+1}$ 支撑于阶 $\ge m+1$。前拍 $H_m$ 的相位基元 $\delta_{(m,\mathrm{phase})}$ 属于 $G_m$，其在环境自由模除以 $G_{m+1}$ 的商中为非零类，给出 `GeneratorResidual`。
3. **线性观察的四支见证分类（R4）**：对任意交换环 $R$ 与 $R$-线性映射 $o:P\to O$，经典分类映射 `settle(o)` 将 $o$ 互斥且穷尽地归入四支：(a) **双射等价**（$P\simeq_R O$，当且仅当 $o$ 双射）；(b) **纯核损失**（$o$ 满射非单射，给出核见证 $k\in\ker o\setminus\{0\}$）；(c) **纯覆盖不足**（$o$ 单射非满射，给出值域外见证 $y\in O\setminus\operatorname{im} o$ 及其非零余核类）；(d) **双重损失**（既非单射亦非满射，同时保留核见证 $k\neq 0$ 与值域外代表 $y\notin\operatorname{im} o$）。

**证明。** (1) 两个余像同构由第一同构定理给出。若相干族 $(c_n)_n$ 的每个余核类为零，各 $c_n$ 在阶段余像 $G/\ker e_n$ 中有唯一原像。过渡相容性使这些原像组成 $K_\infty$ 的一个元素，故 $C_\infty$ 到余核逆极限的核正好是 $j(K_\infty)$。最后由 $s_n e_n=e'_n a$ 得 $a(\ker e_n)\subseteq\ker e'_n$。(2) 两项复形仅在度 $0\to 1$ 非零故 $d^2=0$，商为零即属于子模 $R_{\mathrm{cl}}$；在 R13 中，取 $(m,\mathrm{phase})$ 坐标的线性读出在 $G_{m+1}$ 上为零，在前拍相位基元上为 $1$，故该基元的尾商类非零。(3) 在经典排中律下按 `Injective o` 与 `Surjective o` 的四种真值情况分支：非单射时取 $o(x_1)=o(x_2)$（$x_1\neq x_2$）得 $k=x_1-x_2\neq 0$；非满射时取 $y\in O\setminus\operatorname{im} o$；双射时调用 `LinearEquiv.ofBijective`。$\square$

### 2.3 全素数一致拓扑、联合核商与约化环乘积配对（R11–R12, R14–R17）

<a id="prop-2-3"></a>

**命题 2.3（R11–R12, R14–R17：全素数一致拓扑核、联合核商与交换环配对纤维）。**

1. **全素数幂一致拓扑不可分核（R11）**：对阿贝尔群 $L$，赋予离散商乘积 $\prod_{p,n} L/p^{n+1}L$ 乘积一致结构并沿投影 $\pi_{\mathrm{st}}$ 拉回至 $L$。元素 $x\in L$ 与 $0$ 在该拉回拓扑中不可分当且仅当
   $$\forall p\in\mathbb{P},\;\forall n\in\mathbb{N},\;\exists y\in L,\quad p^{n+1}y=x\quad \bigl(\text{即 }x\in\ker\pi_{\mathrm{all}}=\bigcap_{p,n}p^{n+1}L\bigr),\tag{2.2}$$
   故商群 $L/\ker\pi_{\mathrm{all}}$ 单射嵌入 $\widehat{L}_{\mathrm{all}}$（在 $\mathbb{Z}$ 中 $1$ 与 $0$ 可分，而在可除群 $\mathbb{Q}$ 中 $1$ 与 $0$ 不可分）。
2. **单一观察盲区非零元的联合核商恢复（R12）**：设阿贝尔群同态 $f:C\to F$ 与 $g:C\to G_1$ 满足存在 $c\in\ker f\setminus\{0\}$ 使 $g(c)\neq 0$。则 $g$ 不能穿过 $C/\ker f$ 分解；而对联合同态 $j=(f,g)$，有 $\ker j=\ker f\cap\ker g\le\ker g$，$g$ 唯一线性穿过联合余像 $C/\ker j$，其中 $[c]\neq 0$ 且遗忘投影 $C/\ker j\twoheadrightarrow C/\ker f$ 非单射。
3. **交换环乘积配对核与约化环恢复（R14–R17）**：对交换环 $V$ 与求值同态 $\mathrm{ev}:\mathbb{Z}^{(G)}\to V$，令双线性配对为 $B(w_1,w_2):=\mathrm{ev}(w_1)\mathrm{ev}(w_2)$。一般地，$B(w_1,\cdot)=B(w_2,\cdot)\iff \mathrm{ev}(w_1)-\mathrm{ev}(w_2)\in\operatorname{Ann}_V(\operatorname{im}\mathrm{ev})$（例如 $V=\mathbb{Z}/4\mathbb{Z}$ 上取值 $2\neq 0$ 时 $2\cdot 2=0$ 使 $B\equiv 0$）。对关系子模 $R_{\mathrm{cl}}$，$B$ 在两变量上下降到关系商当且仅当 $\mathrm{ev}(R_{\mathrm{cl}})\subseteq\operatorname{Ann}_V(\operatorname{im}\mathrm{ev})$。若 $V$ 为**约化环**（无非零幂零元），则无须 $\operatorname{im}\mathrm{ev}$ 含单位元即有 $\ker B=\ker\mathrm{ev}$，柯里化配对像同构于 $\operatorname{im}(\mathrm{ev})$，配对跨关系商下降当且仅当 $\mathrm{ev}$ 在关系子模上为零，且 $V$-线性扩展恢复生成元张成的 $V$-子模。

**证明。** (1) 离散群乘积空间是 Hausdorff 空间，拉回拓扑中 $x$ 与 $0$ 不可分当且仅当 $\pi_{\mathrm{st}}(x)=0$，即对一切 $p,n$ 有 $x\in p^{n+1}L$。(2) 若 $g=\bar g\circ\pi_f$，则 $g(c)=\bar g(0)=0$，矛盾；对 $j=(f,g)$ 应用命题 2.2(1) 得唯一分解。(3) 双线性与对称性给出下降判据 $B(R_{\mathrm{cl}},\cdot)=0$，展开即为湮灭子条件。约化环中若 $\mathrm{ev}(w)\in\operatorname{Ann}_V(\operatorname{im}\mathrm{ev})$，取自配对得 $\mathrm{ev}(w)^2=0\implies \mathrm{ev}(w)=0$，故柯里化映射 $w\mapsto B(w,\cdot)$ 的核等于 $\ker\mathrm{ev}$，由第一同构定理即得像同构与商下降判据。$\square$

### 2.4 共尾拓扑提升、Kummer 余核挠塔与上链同伦极限（R53–R56）

逆极限函子并非右正合函子：无界 $p^\infty$-挠可能破坏逆极限的正合性（参见 Jannsen [@Jannsen1988]）。以下先整理全素数完备化上的函子提升引理，再给出 Kummer 余核挠塔在三层不同前提下的极限结论及满射上链塔拟同构引理。

<a id="lem-2-4"></a>

**引理 2.4（R53：共尾拓扑后继、分裂保持与双线性完备化提升）。** 设 $A:L\to_{\mathbb{Z}} M$ 为阿贝尔群同态，则：(1) $A$ 在商乘积 $\prod_{p,j} L/p^{j+1}L$ 上一致连续，并诱导完备化同态 $\widehat{A}_{\mathrm{all}}:\widehat{L}_{\mathrm{all}}\to\widehat{M}_{\mathrm{all}}$ 及余像同态，两源元 $x,y\in L$ 在目标商乘积中的像相等当且仅当 $A(x-y)\in\bigcap_{p,j}p^{j+1}M$；(2) 若 $A$ 具左逆 $B$（$B\circ A=\mathrm{id}_L$）或直和分裂 $A\circ B+\iota\circ C=\mathrm{id}_M$，该左逆与分裂在商乘积、$\widehat{L}_{\mathrm{all}}$ 与余像上同步保持；(3) 双线性映射 $\beta:L\times M\to N$ 逐阶下降为商双线性映射并诱导完备化双线性映射 $\widehat{\beta}:\widehat{L}_{\mathrm{all}}\times\widehat{M}_{\mathrm{all}}\to\widehat{N}_{\mathrm{all}}$。

**证明。** 由 $A(p^{j+1}L)\subseteq p^{j+1}M$ 及双线性映射满足 $\beta(p^{j+1}L,M)+\beta(L,p^{j+1}M)\subseteq p^{j+1}N$，各项等式在每一有限阶商上成立，取逆极限即得全部结论。$\square$

<a id="thm-2-5"></a>

**定理 2.5（R54：Kummer 余核挠塔在三层前提下的极限结论）。** 设 $\iota:L\to_{\mathbb{Z}} M$ 为单射阿贝尔群同态，记余核 $C:=M/\operatorname{im}(\iota)$，固定素数 $p$。记 $\widehat{L}_p:=\varprojlim_j L/p^{j+1}L$，余核挠逆极限 $T_p(C):=\varprojlim_j C[p^{j+1}]$（过渡映射为乘 $p$）。每阶由蛇形引理定义连接同态 $\delta_j:C[p^{j+1}]\to L/p^{j+1}L$（将 $[m]\in C[p^{j+1}]$ 映为满足 $\iota(x)=p^{j+1}m$ 的 $[x]$），诱导极限同态 $\delta_\infty:T_p(C)\to\widehat{L}_p$ 与环境挠极限同态 $\alpha_\infty:T_p(M)\to T_p(C)$。则：

1. **环境 $p$-可除蕴含连接极限满射**（`cokernel_connecting_limit_surjective`）：若 $M$ 上乘 $p$ 满射，则 $\delta_\infty:T_p(C)\twoheadrightarrow\widehat{L}_p$ 满射；
2. **源有界挠蕴含环境极限单射与核正合**（`ambient_to_cokernel_limit_injective_of_bounded`）：若存在 $d\in\mathbb{N}$ 使 $\forall j,\forall y\in L[p^{j+1}],\ p^d y=0$，则 $\alpha_\infty:T_p(M)\hookrightarrow T_p(C)$ 单射且满足 $\operatorname{im}(\alpha_\infty)=\ker(\delta_\infty)$；
3. **环境唯一 $p$-可除蕴含完备化同构**（`cokernelCompletionEquiv`）：若对一切 $j\in\mathbb{N}$，$M$ 上乘 $p^{j+1}$ 双射，则 $\delta_\infty$ 给出 $\mathbb{Z}$-线性同构
   $$\widehat{L}_p \;\simeq_{\mathbb{Z}}\; T_p\bigl(M/\operatorname{im}(\iota)\bigr).\tag{2.3}$$

**证明。** (1) 任取 $v=(v_j)_{j\ge 0}\in\widehat{L}_p$，设 $F_j=\{z\in C[p^{j+1}]:\delta_j(z)=v_j\}$。由 $M$ 的 $p$-可除性，选 $m_0$ 使 $pm_0=\iota(x_0)$，其中 $x_0$ 代表 $v_0$，故 $F_0$ 非空。给定 $[m_j]\in F_j$，令 $p^{j+1}m_j=\iota(x_j)$。取 $v_{j+1}$ 的代表元 $x_{j+1}$，写 $x_{j+1}=x_j+p^{j+1}\ell$。再选 $m_{j+1}$ 使 $pm_{j+1}=m_j+\iota(\ell)$，即有 $p^{j+2}m_{j+1}=\iota(x_{j+1})$ 与 $p[m_{j+1}]=[m_j]$。逐阶选取遂得 $z\in T_p(C)$，满足 $\delta_\infty(z)=v$。
(2) 若 $u=(u_j),u'=(u'_j)\in T_p(M)$ 满足 $\alpha_\infty(u)=\alpha_\infty(u')$，则在第 $j+d$ 阶存在 $y\in L$ 使 $\iota(y)=u_{j+d}-u'_{j+d}\in M[p^{j+d+1}]$。因 $\iota$ 单射，$y\in L[p^{j+d+1}]$，由有界挠条件（引理 A.1）得 $p^d y=0$，于是
$$u_j - u'_j = p^d(u_{j+d}-u'_{j+d}) = \iota(p^d y) = 0,$$
故 $\alpha_\infty$ 单射。再取 $w=(w_j)\in\ker(\delta_\infty)$，每阶代表 $m_j\in M$ 满足 $p^{j+1}m_j=\iota(x_j)$ 且 $x_j\in p^{j+1}L$；修正后可设 $m_j\in M[p^{j+1}]$ 且 $\pi_C(m_j)=w_j$。由 $\pi_C(pm_{j+d+1})=\pi_C(m_{j+d})$ 与引理 A.1，平移序列 $\tilde m_j:=p^d m_{j+d}\in M[p^{j+1}]$ 满足 $p\tilde m_{j+1}=\tilde m_j$ 与 $\pi_C(\tilde m_j)=p^d w_{j+d}=w_j$，证得 $w=\alpha_\infty(\tilde m)$。
(3) 当 $M$ 上乘 $p^{j+1}$ 双射时，$M[p^{j+1}]=0$ 且每阶 $\delta_j:C[p^{j+1}]\to L/p^{j+1}L$ 均为同构并与过渡交换，取逆极限得 (2.3)。$\square$

<a id="lem-2-6"></a>

**引理 2.6（R55–R56：分裂路径复形的延拓同伦等价与满射上链塔拟同构）。** 给定集合 $\mathcal{E}$ 上的有限有向路径 $\tau=(e_0\to e_1\to\dots\to e_m)$，在自由 $\mathbb{Z}$-模 $\mathbb{Z}[\mathcal{E}]$ 的访问顶点子模 $G_{\mathrm{cl}}(\tau)$ 中令步差子模为 $R_{\mathrm{cl}}(\tau):=\operatorname{span}_{\mathbb{Z}}\{[e_i]-[e_{i+1}] : 0\le i<m\}$，记两项上链复形 $C^\bullet_\tau=(0\to R_{\mathrm{cl}}(\tau)\xrightarrow{d}G_{\mathrm{cl}}(\tau)\to 0)$ 与增广同态 $\operatorname{aug}(\sum c_e[e]):=\sum c_e\in\mathbb{Z}$。则：

1. **终态直和分裂与延拓链同伦等价（R55）**：每个 $w\in G_{\mathrm{cl}}(\tau)$ 唯一分解为 $w = d(r_\tau(w)) + (\operatorname{aug} w)[e_m]$，诱导 $G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau)\xrightarrow{\sim}\mathbb{Z}$；对任意延拓路径 $\tau_{\mathrm{prior}}\prec\tau_{\mathrm{next}}$，包含态射 $C^\bullet_{\tau_{\mathrm{prior}}}\to C^\bullet_{\tau_{\mathrm{next}}}$ 为链同伦等价（其映射锥可缩），且因短正合列 $0\to R_{\mathrm{cl}}(\tau)\to G_{\mathrm{cl}}(\tau)\to G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau)\to 0$ 直和分裂，任意加性函子 $F:\mathrm{Ab}\to\mathrm{Mod}_{\mathbb{Z}}$ 满足 $H^1(F(C^\bullet_\tau))\cong F(G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau))$。
2. **满射素数幂上链塔拟同构（R56）**：对任意整上链复形 $K^\bullet$ 与素数 $p$，逐度过渡 $K^q/p^{j+2}K^q\twoheadrightarrow K^q/p^{j+1}K^q$ 满射，故逆极限复形 $\varprojlim_j(K^\bullet/p^{j+1}K^\bullet)$ 到顺序映射余锥同伦极限的典范态射为拟同构（`cochain_derived_limit_quasiIso`）。

**证明。** (1) 伸缩恒等式 $[e_k]-[e_m]=\sum_{j=k}^{m-1}([e_j]-[e_{j+1}])\in\operatorname{im}(d)$ 给出直和分解 $G_{\mathrm{cl}}(\tau)=\operatorname{im}(d)\oplus\mathbb{Z}[e_m]$，使 $C^\bullet_\tau$ 链同伦等价于集中在度 $1$ 的 $\mathbb{Z}$；延拓后旧终点与新终点之差属于 $\operatorname{im}(d_{\mathrm{next}})$，在同调上诱导恒等，从而自由两项复形间的拟同构提升为链同伦等价；加性函子保持直和分裂故保持余核。(2) 记过渡为 $t_j:K_{j+1}^\bullet\to K_j^\bullet$，其中 $K_j^\bullet=K^\bullet/p^{j+1}K^\bullet$。在乘积复形上令 $\Delta((x_j))=(x_j-t_jx_{j+1})_j$。其核是严格逆极限。给定各度的 $(y_j)_j$，从 $x_0=0$ 起逐步解 $t_jx_{j+1}=x_j-y_j$，故 $\Delta$ 逐度满射。由所得短正合列，$\ker\Delta\to\operatorname{Cone}(\Delta)[-1]$ 是拟同构 [@Milnor1962; @Weibel1994]。$\square$

### 2.5 阶乘完备化同构与平衡代表元整源下降判准（R57–R58）

全素数完备化 $\prod_{p\in\mathbb{P}}\widehat{L}_p$ 涉及可数多个素数坐标；改用阶乘模塔 $L/(n+1)!L$ 可将逆极限收束到单一阶段参数 $n$，并以半开区间代表元的相邻差判别相干类是否来自整数源。

<a id="thm-2-7"></a>

**定理 2.7（R57–R58：全素数—阶乘完备化同构与阶乘平衡代表元跳跃判准）。** 设 $L$ 为任意阿贝尔群，记阶乘模 $M_n:=(n+1)!$ 及阶乘完备化 $\widehat{L}_{!}:=\varprojlim_{n\in\mathbb{N}} L/M_n L$（典范映射 $\iota_{!}:L\to\widehat{L}_{!}$）。

1. **中国剩余定理完备化同构（R57）**：存在典范 $\mathbb{Z}$-线性同构 $\prod_{p\in\mathbb{P}}\widehat{L}_p \simeq_{\mathbb{Z}} \widehat{L}_{!}$（`factorialCompletionEquiv`）。对引理 2.6 的分裂路径复形 $C_\tau^\bullet$，记 $Q_\tau=G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau)$，则阶乘上链塔满足
   $$H^1\bigl(\operatorname{holim}_n(C_\tau^\bullet/M_n C_\tau^\bullet)\bigr)\cong\widehat{Q_\tau}_{!}.$$
2. **整格平衡代表元稳定与全模跳跃判准（R58）**：设 $L$ 具整坐标同构 $\phi:L\xrightarrow{\sim}\mathbb{Z}$，对 $v=(v_n)\in\widehat{L}_{!}$ 取第 $n$ 阶唯一半开平衡代表元 $b_n(v)\in L$，使其模 $M_n L$ 余类为 $v_n$ 且满足
   $$-\lfloor M_n/2\rfloor \le \phi(b_n(v)) < M_n - \lfloor M_n/2\rfloor.\tag{2.4}$$
   则：
   (a) 对任意逐阶匹配 $v_n$ 的提升序列 $s_n\in L$，存在唯一整数 $k_n\in\mathbb{Z}$ 使 $\phi(s_{n+1})-\phi(s_n)=(n+1)!\,k_n$；
   (b) **整源最终稳定充要条件**：相干元 $v\in\widehat{L}_{!}$ 来自唯一源元素 $s\in L$（$\iota_{!}(s)=v$）**当且仅当**平衡代表元序列最终不变，即 $\exists N\in\mathbb{N},\ \forall n\ge N,\ |\phi(b_{n+1}(v))-\phi(b_n(v))| < (n+1)!$（等价于 $b_{n+1}(v)=b_n(v)=s$）；反之，若 $v\notin\operatorname{im}(\iota_{!})$，则对任意 $N\in\mathbb{N}$，必存在 $n\ge N$ 使 $|\phi(b_{n+1}(v))-\phi(b_n(v))|\ge (n+1)!$；
   (c) **赋范线性读出推论**：对任意实赋范空间 $E$ 与满足 $u:=E_{\mathrm{eff}}(\phi^{-1}(1))\neq 0$ 的线性映射 $E_{\mathrm{eff}}:L\to_{\mathbb{Z}} E$，$v\in\operatorname{im}(\iota_{!})$ 当且仅当存在 $N\in\mathbb{N}$ 使对一切 $n\ge N$ 成立
   $$\bigl\|E_{\mathrm{eff}}(b_{n+1}(v))-E_{\mathrm{eff}}(b_n(v))\bigr\| < (n+1)!\,\|u\|.\tag{2.5}$$

**证明。** (1) 记 $M_n$ 的素因子分解为 $\prod_{p\le n+1} p^{v_p(M_n)}$。中国剩余定理给出 $L/M_n L \simeq \prod_{p\le n+1} L/p^{v_p(M_n)}L$；每个由不同素数幂组成的有限乘积都整除充分大的 $M_n$，而每个 $M_n$ 本身是这样的乘积。由这些相容的有限层同构取极限，得 $\prod_p\widehat{L}_p\simeq\widehat{L}_{!}$。阶乘塔的过渡逐度满射，由引理 2.6(2) 的同一论证，严格逆极限到同伦极限的映射为拟同构。再把加性阶乘完备化函子代入引理 2.6(1)，即得所示 $H^1$ 同构。
(2) 因 $s_{n+1}\equiv s_n\pmod{M_n L}$，整差 $\phi(s_{n+1})-\phi(s_n)$ 被 $M_n=(n+1)!$ 整除，得 (a)。对整数 $k_n$，条件 $|M_n k_n|<M_n$ 等价于 $k_n=0$，即 $b_{n+1}(v)=b_n(v)$。若 $\iota_{!}(s)=v$，由命题 A.2 取 $N=2|\phi(s)|+2$，当 $n\ge N$ 时 $s$ 本身满足区间条件 (2.4)，由代表元唯一性得 $b_n(v)=s$。反之，若对一切 $n\ge N$ 有 $b_n(v)=b_N(v)=:s$，则由过渡相容性知对全部 $n\in\mathbb{N}$ 均有 $s\bmod M_n L = v_n$，即 $\iota_{!}(s)=v$；由 $\bigcap_n (n+1)!\mathbb{Z}=\{0\}$ 知 $\iota_{!}$ 单射，故 $s$ 唯一，其逆否命题即非整类的共尾全模跳跃。最后，在赋范读出下由 $\mathbb{Z}$-线性性有 $\|E_{\mathrm{eff}}(b_{n+1}(v))-E_{\mathrm{eff}}(b_n(v))\|=(n+1)!|k_n|\|u\|$，因 $\|u\|>0$，(2.5) 与 $|k_n|<1$ 等价。$\square$

---

## 第二部：有限投射模 Picard 扭子与无基底行列式接口

<a id="sec-3"></a>

## 3 有限投射局部化外幂、Picard 扭子与椭圆曲线非自由理想

在双射精确分支（命题 2.2(3a)）内加上有限生成投射条件后，模的表示进一步细分为局部柄秩与 Picard 类障碍。

### 3.1 张量对偶、局部柄秩分派与 Picard 标架扭子（R5）

<a id="prop-3-1"></a>

**命题 3.1（R5：有限投射张量对偶、柄秩分派与 Picard 分类）。** 设 $M$ 为交换环 $R$ 上的有限生成投射模：

1. **张量对偶**：典范映射 $M^\vee\otimes_R M\to\operatorname{End}_R(M)$ 为 $R$-线性同构（相对地，有限非投射模如 $\mathbb{Z}/4\mathbb{Z}$-模 $\mathbb{Z}/2\mathbb{Z}$ 在进入本分支前已被投射性条件排除）。
2. **局部柄秩与 Picard 分派**：考察素谱柄秩函数 $\mathfrak{p}\mapsto\operatorname{rank}_{R_{\mathfrak{p}}}(M_{\mathfrak{p}})$（$\mathfrak{p}\in\operatorname{Spec} R$）：
   (a) **变秩分支**：若存在 $\mathfrak{p}_1,\mathfrak{p}_2\in\operatorname{Spec} R$ 使柄秩不等，分类器保留素理想对 $(\mathfrak{p}_1,\mathfrak{p}_2)$ 作为无法在所有柄同时取最高次外幂的见证（注记 3.1）；
   (b) **常秩分支**：若全体素理想处柄秩恒为 $n\in\mathbb{N}$（零环 $R\cong 0$ 因 $\operatorname{Spec} R=\varnothing$ 归入 $n=0$），则顶外幂 $L:=\bigwedge^n_R M$ 为秩 $1$ 可逆 $R$-模；当 Picard 类 $[L]=1\in\operatorname{Pic}(R)$ 时，$L$ 的全体单元素基构成 $R^\times$-标架扭子；当 $[L]\neq 1$ 时保留非自由见证。

**证明。** 有限生成投射模存在有限对偶基 $\{(f_i,m_i)\}_{i=1}^k$ 使 $\mathrm{id}_M=\sum_i f_i(\cdot)m_i$，直接给出 $M^\vee\otimes_R M\xrightarrow{\sim}\operatorname{End}_R(M)$。常秩 $n$ 时，外幂与局部化交换给出 $(\bigwedge^n_R M)_{\mathfrak{p}}\simeq\bigwedge^n_{R_{\mathfrak{p}}}(R_{\mathfrak{p}}^n)\simeq R_{\mathfrak{p}}$，故 $L$ 可逆；若 $L\cong R$，任一生成元乘以 $R^\times$ 遍历全部自由基，构成主齐性空间（torsor）。$\square$

<a id="rem-3-1"></a>

**注记 3.1（与 Stacks Project Tag 0FJ9 分块行列式的界定）。** 变秩模在代数几何中可按 $\operatorname{Spec} R$ 的开闭分解支拼合局部行列式线（Stacks Tag `0FJ9` [@Stacks0FJ9]）。例如 $\mathbb{Q}\times\mathbb{Q}$ 上的 $\mathbb{Q}\times 0$ 在两个素理想处的最高外幂次数分别为 $1$ 和 $0$，因此没有一个固定次数 $n$ 能在两个柄同时给出最高外幂。命题 3.1(2a) 保留这两个素理想作为见证。

### 3.2 仿射椭圆曲线上的非自由可逆理想实例（R6）

<a id="prop-3-2"></a>

**命题 3.2（R6：仿射椭圆曲线 $y^2=x^3-x$ 上有理点 $(1,0)$ 的非自由可逆理想）。** 设 $R_E:=\mathbb{Q}[x,y]/(y^2-x^3+x)$ 为光滑椭圆曲线 $E:y^2=x^3-x$ 的仿射坐标环，$P=(1,0)\in E(\mathbb{Q})$。对应于 $P$ 的极大理想 $L_P=(x-1,y)\triangleleft R_E$ 是常秩 $1$ 有限生成投射 $R_E$-模，满足 $[L_P]\neq 1\in\operatorname{Pic}(R_E)$ 且不是自由 $R_E$-模，落入命题 3.1(2b) 的常秩非自由分支。

**证明。** 初等自足证明已由例 1.1(c) 给出：由 $L_P^2=(x-1)R_E$ 得 $L_P$ 的分数理想逆，从而 $L_P$ 是秩 $1$ 投射模；而等式 $L_P^2=(x-1)R_E$ 结合多项式范数 $a(x)^2-b(x)^2(x^3-x)$ 次数奇偶比较排除 $L_P$ 为主理想，因秩 $1$ 投射理想自由当且仅当主生成，故 $L_P$ 非自由且 $[L_P]\neq 1$。在形式化实现 `ScalarNontrivialPicardLineRegression.lean` 中，证明调用 `mathlib` 已形式化的光滑仿射 Weierstrass 曲线点到理想类群单射定理（`WeierstrassCurve.Affine.Point.toClass_eq_zero`，由 Angdinata 与 Xu 建立 [@AngdinataXu2023; @mathlib2020]）及 Dedekind 整环 $\operatorname{Cl}(R_E)\simeq\operatorname{Pic}(R_E)$，对一般域上非零仿射点导出非自由性并实例化至 $P=(1,0)$。$\square$

---

<a id="sec-4"></a>

## 4 无基底行列式与范畴极限复形的五组代数接口

本节汇总的五组命题（接口 I–V）在纯数学层面均属线性代数与同调代数的基本构造；将它们集中形式化的目的在于建立**推迟基底选择的规格边界**（参见 Deligne [@Deligne1987] 与 Commelin–Topaz [@CommelinTopaz2024]）：上游模与复形构造不携带人为选定的矩阵基底，标量行列式坐标仅在终端读出阶段传入标架时才生成（对应源码路径见附录 B.2）。

<a id="prop-4-1"></a>

**命题 4.1（接口 I：双格对偶行列式接口，`DualLatticeDeterminantKernel`）。** 设 $K$ 为域，$L,R'$ 为有限自由 $\mathbb{Z}$-格，整双线性配对 $\langle\cdot,\cdot\rangle:L\times R'\to K$ 经标量扩充至 $L_K:=K\otimes_{\mathbb{Z}} L$ 与 $R'_K:=K\otimes_{\mathbb{Z}} R'$ 后非退化。则：

1. $\dim_K L_K=\dim_K R'_K=:r$，配对诱导同构 $L_K\xrightarrow{\sim}(R'_K)^\vee$ 与无基底顶外幂映射
   $$\det(L_K)\otimes_K\det(R'_K)\longrightarrow K;\tag{4.1}$$
2. 对任意双侧 $K$-基 $(e_L,e_R)$，配对矩阵 $(M_{\mathrm{dual}}(e_L,e_R))_{ij}:=\langle e_{L,i},e_{R,j}\rangle$ 的行列式在换基 $(P,Q)$ 下乘以 $\det(P)\det(Q)$；当标架取自 $\mathbb{Z}$-格整基时，不同整基读出之间仅相差单位符号 $u_L u_R\in\{\pm 1\}$；
3. 对同态 $\lambda:L\to_{\mathbb{Z}} R'$，自配对矩阵 $(M_{\mathrm{self}}(e_L))_{ij}:=\langle e_{L,i},\lambda(e_{L,j})\rangle$ 满足 $\det M_{\mathrm{self}}(e_L)=\det M_{\mathrm{dual}}(e_L,e_R)\cdot\det_{e_L,e_R}(\lambda_K)$。

**证明。** 有限维空间上非退化双线性配对给出单射 $L_K\hookrightarrow(R'_K)^\vee$ 与 $R'_K\hookrightarrow L_K^\vee$，故维数相等且均为同构，取 $r$ 次外幂得 (4.1)；矩阵关系 $M_{\mathrm{self}}(e_L)=M_{\mathrm{dual}}(e_L,e_R)[\lambda_K]_{e_L,e_R}$ 及 $\mathrm{GL}_r(\mathbb{Z})$ 行列式取值 $\{\pm 1\}$ 给出 (2)–(3)。$\square$

<a id="prop-4-2"></a>

**命题 4.2（接口 II：等秩整格有限余核指数与有限群同态基数平衡，`FiniteDefectDeterminantKernel`）。**

1. **等秩整格余核指数**：设 $f:S\to_{\mathbb{Z}} T$ 为等秩有限自由 $\mathbb{Z}$-格间的线性映射（$\operatorname{rank}_{\mathbb{Z}} S=\operatorname{rank}_{\mathbb{Z}} T$）。若余核 $\operatorname{coker} f = T/\operatorname{im}(f)$ 有限，则 $\ker f=0$，且在任意双侧整基下表示矩阵满足
   $$|\det f| = \#\operatorname{coker} f.\tag{4.2}$$
2. **有限阿贝尔群同态基数平衡**：对任意有限阿贝尔群同态 $g:H_1\to_{\mathbb{Z}} H_2$，成立 $\#H_2\cdot\#\ker g = \#H_1\cdot\#\operatorname{coker} g$，即有理基数比满足 $\#\operatorname{coker} g / \#\ker g = \#H_2 / \#H_1$。

**证明。** (1) 因 $T/\operatorname{im} f$ 有限，$\operatorname{rank}_{\mathbb{Z}}(\operatorname{im} f)=\operatorname{rank}_{\mathbb{Z}} T=\operatorname{rank}_{\mathbb{Z}} S$，自由阿贝尔群满秩满射无核给出 $\ker f=0$；由 Smith 标准型（或满秩子格指标定理）得 $|\det f|=\#(T/\operatorname{im} f)$。(2) 由 $|H_1|=|\ker g|\cdot|\operatorname{im} g|$ 与 $|H_2|=|\operatorname{im} g|\cdot|\operatorname{coker} g|$ 消去 $|\operatorname{im} g|$ 即得。$\square$

<a id="prop-4-3"></a>

**命题 4.3（接口 III：短正合列基底粘合与零余核外幂输运，`ExactDeterminantGluingKernel`）。**

1. **短正合列基底粘合**：设 $R$ 为非零交换环，$0\to X_1\to X_2\to X_3\to 0$ 为有限自由 $R$-模短正合列。给定两端基底 $b_1,b_3$ 后，分裂提升给出 $X_2$ 的粘合基底、顶外幂标架及秩可加性 $\operatorname{rank}_R X_2=\operatorname{rank}_R X_1+\operatorname{rank}_R X_3$。
2. **零余核无基底外幂输运**：在命题 4.2(1) 的等秩有限余核条件下，若 $\operatorname{coker} f = 0$，则 $f:S\xrightarrow{\sim} T$ 为线性同构，无需选定基底即诱导顶外幂整线同构 $\bigwedge^r_{\mathbb{Z}} S\xrightarrow{\sim}\bigwedge^r_{\mathbb{Z}} T$。

**证明。** (1) 因 $X_3$ 自由，右端满射分裂，$X_2\cong X_1\oplus X_3$；非零交换环满足不变基数性质（`StrongRankCondition`），故秩可加。(2) 由命题 4.2(1) 知 $\ker f=0$，结合 $\operatorname{coker} f=0$ 得 $f$ 双射，外幂函子保持同构。$\square$

<a id="prop-4-4"></a>

**命题 4.4（接口 IV：四项自由整复形交错行列式线与逐项同构输运，`PerfectComplexDeterminantProjectionKernel`）。** 给定四项有限自由整上链复形 $C^\bullet=(C_0\xrightarrow{d_0}C_1\xrightarrow{d_1}C_2\xrightarrow{d_2}C_3)$：

1. 无须预先选定各度基底，定义交错整行列式线
   $$\det\nolimits_{\mathbb{Z}}(C^\bullet):=\bigl(\det\nolimits_{\mathbb{Z}}(C_0)\otimes_{\mathbb{Z}}\det\nolimits_{\mathbb{Z}}(C_1)^\vee\bigr)\otimes_{\mathbb{Z}}\det\nolimits_{\mathbb{Z}}(C_2)\otimes_{\mathbb{Z}}\det\nolimits_{\mathbb{Z}}(C_3)^\vee,\tag{4.3}$$
   它是秩 $1$ 自由 $\mathbb{Z}$-模，具有总宇称 $(\sum_{i=0}^3\operatorname{rank} C_i)\bmod 2\in\mathbb{Z}/2\mathbb{Z}$ 与双元素整生成元集合（$\{\pm 1\}$-扭子）；
2. 任意逐项上链复形同构 $(e_0,e_1,e_2,e_3):C^\bullet\xrightarrow{\sim}D^\bullet$ 按偶度协变 $\bigwedge e_{2k}$、奇度逆变对偶 $(\bigwedge e_{2k+1}^{-1})^\vee$ 诱导整线同构 $\det_{\mathbb{Z}}(C^\bullet)\xrightarrow{\sim}\det_{\mathbb{Z}}(D^\bullet)$，并与复形同构的复合协变相容（注：本接口仅封装逐项同构输运，不涉及一般拟同构下的同调行列式比较）。

**证明。** 见附录命题 A.3。$\square$

<a id="prop-4-5"></a>

**命题 4.5（接口 V：上链复形图的范畴逆极限与映射锥收缩，`DependentDerivedGlobalStateKernel`）。** 设 $\mathcal{I}$ 为小指标范畴，$D:\mathcal{I}\to\operatorname{Ch}^\bullet(\mathbb{Z})$ 为整上链复形函子。由于 $\operatorname{Ch}^\bullet(\mathbb{Z})$ 完备：

1. 存在范畴逆极限复形 $\mathcal{G}:=\varprojlim_{i\in\mathcal{I}} D(i)$ 及满足对一切态射 $\alpha:i\to j$ 有 $D(\alpha)\circ\pi_i=\pi_j$ 的限制链态射族 $\pi_i:\mathcal{G}\to D(i)$；
2. 对固定指标 $i_0\in\mathcal{I}$ 上的任意复形态射 $\tau:D(i_0)\to E^\bullet$，记 $f=\tau\circ\pi_{i_0}$。由 $\operatorname{Cone}(f)^n=E^n\oplus\mathcal{G}^{n+1}$ 得逐度分裂的短正合列 $0\to E^\bullet\to\operatorname{Cone}(f)\to\mathcal{G}[1]\to 0$。若有界有限自由复形上的态射 $p:P^\bullet\to\mathcal{G}$ 的映射锥有收缩同伦 $h$，即 $d_{\mathrm{Cone}}h+hd_{\mathrm{Cone}}=\mathrm{id}$，则 $p$ 为链同伦等价。模型 $P^\bullet$ 给出行列式线 $\det_{\mathbb{Z}}(P^\bullet)$，其复合限制满足 $D(\alpha)\circ(\pi_i\circ p)=\pi_j\circ p$（$\alpha:i\to j$）。

**证明。** $\mathrm{Mod}_{\mathbb{Z}}$ 完备蕴含上链复形范畴逐度取极限完备，极限锥泛性质给出 (1)；映射锥构造及“映射锥可缩当且仅当原链态射为链同伦等价”的标准同调代数事实 [@Weibel1994] 给出 (2)。复合限制的等式由 (1) 右复合 $p$ 得到。$\square$

<a id="ex-4-1"></a>

**例 4.1（Smith 指数、负恒等符号与四项复形的初等核对）。** 对 $f=2\cdot\mathrm{id}:\mathbb{Z}\to\mathbb{Z}$，命题 4.2(1) 给出 $\ker f=0$ 与 $|\det f|=2=\#(\mathbb{Z}/2\mathbb{Z})$。对同构 $u=-\mathrm{id}:\mathbb{Z}\to\mathbb{Z}$，$\#\operatorname{coker} u=1$，而命题 4.3(2) 的无基底顶外幂输运保持符号 $-1$。对四项复形 $C^\bullet=(\mathbb{Z}\xrightarrow{\cdot 2}\mathbb{Z}\xrightarrow{0}\mathbb{Z}\xrightarrow{\cdot 3}\mathbb{Z})$，命题 4.4 给出秩一自由模 $\det_{\mathbb{Z}}(C^\bullet)\cong\mathbb{Z}$ 及其 $\{\pm 1\}$-扭子（作为命题 4.4 范围之外的经典 Euler–Poincaré 背景对照，该复形的有限上同调基数交错比亦等于 $\#H^1\cdot\#H^3/(\#H^0\cdot\#H^2)=2\cdot 3=6$）。

---

## 第三部：状态系统自由线性化、合冲呈示与有号稀疏 Hankel 恢复

<a id="sec-5"></a>

## 5 状态系统的自由线性化、不可观不变核与语法左逆

本节整理离散状态系统线性化及多步观测核的基础代数性质，供第 6 节的常量表合冲呈示与姊妹过程代数模块调用。

### 5.1 点观察塔自由线性化与交错差导子律（R7–R8）

<a id="prop-5-1"></a>

**命题 5.1（R7–R8：点观察塔同构、双线性增量与交错差导子律）。** 设 $S$ 为集合，$\sigma:S\to S$ 为自映射。令 $V=\mathbb{Z}^{(S)}$，$T:V\to V$ 为 $\sigma$ 的自由线性扩张。由相容前缀 $(v,Tv,\dots,T^nv)$ 取逆极限，得 $\mathcal{F}_\sigma=\{(T^nv)_{n\in\mathbb{N}}:v\in V\}\le\prod_n V$。

1. **双侧线性同构与三项增量（R7）**：生成映射 $\mathrm{sourceMap}:\mathbb{Z}[S]\to\mathcal{F}_\sigma$ 与零阶读回映射 $\mathrm{word}:\mathcal{F}_\sigma\to\mathbb{Z}[S]$ 互为 $\mathbb{Z}$-线性逆，将 $\mathcal{F}_\sigma$ 上的移位算子认同于 $\sigma$ 的自由线性扩张；任意二元运算 $\star:X\times Y\to Z$ 经双线性扩张 [@Stacks00CX] 满足三项差分展开 [@Budiu2023DBSP]：
   $$(x+\Delta x)\star(y+\Delta y)-x\star y = (\Delta x\star y)+(x\star\Delta y)+(\Delta x\star\Delta y).\tag{5.1}$$
2. **非等变映射的交错差导子律（R8）**：对步进系统 $(X,\sigma_X),(Y,\sigma_Y)$ 与任意集合映射 $f:X\to Y$，记诱导线性映射为 $\mathrm{map}(f):\mathcal{F}_X\to\mathcal{F}_Y$，步进线性算子为 $A_{\sigma_X},B_{\sigma_Y}$。定义交错差算子 $\Delta f:=B_{\sigma_Y}\circ\mathrm{map}(f)-\mathrm{map}(f)\circ A_{\sigma_X}$，则对任意可复合集合映射 $X\xrightarrow{f}Y\xrightarrow{g}Z$ 成立
   $$\Delta(g\circ f) = \Delta g\circ\mathrm{map}(f) + \mathrm{map}(g)\circ\Delta f,\tag{5.2}$$
   且 $\Delta f = 0$ 当且仅当对所有 $x\in X$ 有 $\sigma_Y(f(x))=f(\sigma_X(x))$。

**证明。** (1) $\mathrm{sourceMap}$ 单射且 $\mathcal{F}_\sigma$ 按定义等于其像，零阶坐标读回其逆；双线性分配律直接展开得 (5.1)。(2) 伸缩恒等式 $C_{\sigma_Z}\mathrm{map}(g)\mathrm{map}(f)-\mathrm{map}(g)\mathrm{map}(f)A_{\sigma_X}=(C_{\sigma_Z}\mathrm{map}(g)-\mathrm{map}(g)B_{\sigma_Y})\mathrm{map}(f)+\mathrm{map}(g)(B_{\sigma_Y}\mathrm{map}(f)-\mathrm{map}(f)A_{\sigma_X})$ 给出 (5.2)；在基元 $\delta_x$ 上检验 $\Delta f(\delta_x)=\delta_{\sigma_Y(f(x))}-\delta_{f(\sigma_X(x))}=0$ 即得等变充要性。$\square$

### 5.2 语法解析左逆、加性上下文链态射与不可观不变子模（R18–R42, R45, R60）

<a id="prop-5-2"></a>

**命题 5.2（R20, R60, R18, R21, R23：展开树语法左逆与加性上下文两项复形链态射）。**

1. **无求值语法解析左逆（R20，`Tree/Fold/Inverse.lean`）**：对归纳树类型 `occur(r, bs)`（根标号 $r\in R_0$，子树表 $bs$）及任意节点折叠函数 $\kappa:R_0\to\mathrm{List}(C_0)\to C_0$，语法编码映射 $\mathrm{program}_\kappa$ 与不调用 $\kappa$ 的结构递归解析器 `readTree` 满足 $\mathrm{readTree}(\mathrm{program}_\kappa(T))=\mathrm{some}\,T$；特别地，即使 $\kappa\equiv 0$ 使语义求值恒为零，$\mathrm{program}_\kappa$ 仍为单射。
2. **加性上下文两项复形链态射（R60，`LinearCochain.lean`）**：设 $\mathrm{op}$ 为加性算子，父轨迹在上下文 $\mathcal{L}_{\mathrm{op}}$ 中执行给定的子轨迹。子路径到父路径的映射在表达式基元上取 $[e]\mapsto[\mathcal{L}_{\mathrm{op}}(e)]$，诱导两项关系复形之间的链态射 `linearCochain`。在任意环境增量下，边界的增量求值满足
   $$\mathrm{eff}_\delta(\partial_{\mathrm{parent}}) = \mathrm{op}\bigl(\mathrm{eff}_\delta(\partial_{\mathrm{child}})\bigr).\tag{5.3}$$
3. **变量代换的轨迹长度与边界（R18, R21, R23）。** 设 $\sigma$ 为保类型的表达式代换，$\rho$ 为代换后变量的环境。原轨迹的环境把 $x$ 赋值为 $\sigma(x)$ 在 $\rho$ 中的求值。把原轨迹 $E\rightsquigarrow E'$ 的每个变量求值步替换为相应 $\sigma(x)$ 在 $\rho$ 中的求值轨迹，得到 $F_0\rightsquigarrow\cdots\rightsquigarrow F_m$，其中 $F_0=E^\sigma$、$F_m=(E')^\sigma$。在表达式生成的自由整模中，边界为
   $$\sum_{i=0}^{m-1}([F_i]-[F_{i+1}])=[E^\sigma]-[(E')^\sigma].$$
   若 $E'$ 为常量，则 $m=\mathrm{remaining}(E^\sigma)$。这里 $\mathrm{remaining}$ 计数变量出现与加法、一元线性和二元双线性节点，常量贡献零。

**证明。** (1) 对树与森林作互归纳：`readTree` 仅按语法分隔构造子还原 $(r,bs)$ 而不读取 $\kappa$。(2) 加性映射将基步差 $[e_i]-[e_{i+1}]$ 映为 $[\mathcal{L}_{\mathrm{op}}(e_i)]-[\mathcal{L}_{\mathrm{op}}(e_{i+1})]$，与包含微分 $d$ 交换并给出 (5.3)。(3) 各原步在代换后端点相接，连接所得子轨迹即为总轨迹。中间基向量在边界和中两两消去。代换后的每个原语步都使 $\mathrm{remaining}$ 减一，故终点为常量时，步数等于代换后起始式的计数。$\square$

<a id="prop-5-3"></a>

**命题 5.3（R19, R22, R24–R27, R36：商核同构、环模不可观子模与纤维约束原像判据）。**

1. **商核同构恢复（R19, R22，`Fibre/Recovery.lean`）**：设线性映射 $E,E_{\mathrm{next}}$ 与增量对映射 $J_0$ 满足 $\ker E=\ker J_0\cap\ker E_{\mathrm{next}}$，记包含 $\mathrm{kernelMap}:\ker E\hookrightarrow\ker E_{\mathrm{next}}$，则第一同构定理给出无须选取代表元的同构 $\ker E_{\mathrm{next}}/\operatorname{im}(\mathrm{kernelMap})\xrightarrow{\sim}\operatorname{im}(J_0|_{\ker E_{\mathrm{next}}})$。
2. **环模上的不可观最大不变子模（R24–R25, R27, R36，`Words/Kernel.lean`）**：设 $C$ 为交换环 $R$ 上的模，$e:C\to_R B$ 为线性输出映射，$\{A_\alpha:C\to_R C\}_{\alpha\in I}$ 为自同态族。定义自由幺半群词读出映射 $\mathcal{I}(c)(w):=e(A_w c)$（$w\in I^*$），则 $\ker\mathcal{I}$ 等于包含在 $\ker e$ 中的**唯一最大 $\{A_\alpha\}$-不变 $R$-子模**（即控制论中 Kálmán 不可观子空间 [@Kalman1963] 在任意交换环模与非交换自同态族上的代数形式）；当 $\ker\mathcal{I}=0$ 时，$\mathcal{I}$ 诱导线性同构 $C\xrightarrow{\sim}\operatorname{im}(\mathcal{I})$。
3. **纤维约束原像双残差判据（R26，`TargetDifference.lean`）**：设交换方块 $d_C=d_D\circ\mu$（其中 $\mu:C\to D$，$d_C:C\to H$，$d_D:D\to H$ 均为线性映射），给定 $c_0\in C$ 与 $y\in D$，记 $\delta:=y-\mu(c_0)$。则存在满足 $d_C(c)=d_C(c_0)$ 且 $\mu(c)=y$ 的原像 $c\in C$，当且仅当
   $$d_D(\delta)=0 \quad \wedge \quad [\delta]=0\in\operatorname{coker}(\mu).$$

**证明。** (1) 由 $\ker(J_0|_{\ker E_{\mathrm{next}}})=\ker E$ 直接得出。(2) 取空词 $w=[]$ 得 $\ker\mathcal{I}\le\ker e$；移位关系 $\mathcal{I}(A_\alpha c)(w)=\mathcal{I}(c)(\alpha::w)$ 表明 $\ker\mathcal{I}$ 为 $\{A_\alpha\}$-不变子模；对任意不变子模 $N\le\ker e$ 按词长归纳得 $A_w(N)\subseteq N\le\ker e$，即 $N\le\ker\mathcal{I}$。(3) 若 $c$ 存在，则 $\delta=\mu(c-c_0)$ 蕴含 $[\delta]=0$ 且 $d_D(\delta)=d_C(c-c_0)=0$；反之 $[\delta]=0$ 给出 $c\in C$ 使 $\mu(c-c_0)=\delta$，代入 $d_C=d_D\circ\mu$ 得 $d_C(c)-d_C(c_0)=d_D(\delta)=0$。$\square$

<a id="rem-5-1"></a>

**注记 5.1（跨步同余与两节点语法树核对）。** 有限词族对偶、零求值商同余及同根拼接性质（R28–R35, R38–R42, R45；索引见附录 B.1）为姊妹过程核 [@Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2] 提供基础代数引理。在最小两节点树 $\mathrm{occur}(r_0, [\mathrm{occur}(r_1, [])])$ 上，即便取 $\kappa\equiv 0$ 使求值恒为零，$\mathrm{program}_\kappa$ 仍保留根标号与子树分隔结构，由 `readTree` 还原原树。

---

<a id="sec-6"></a>

## 6 自由常量表的构造性合冲呈示与未知稀疏度有号 Hankel 恢复

### 6.1 自由常量表的构造性合冲呈示与净额—证书分解（R43）

在借贷差群（Ellerman [@Ellerman2014Accounting]）与流式计算 $\mathbb{Z}$-集（DBSP [@Budiu2023DBSP]）中，形式分录经群求值映射 $\mathrm{freeEval}:\mathbb{Z}^{(G)}\to G$ 后，正负抵消项（如 $[g]+[-g]-[0]$）落入求值核 $\ker(\mathrm{freeEval})$ 而在商群中归零。以下命题给出该核的显式二项生成关系呈示及构造性合冲（syzygy）分解：若通道同时传输群净额 $v=\mathrm{freeEval}(\Delta T)$ 与核内合冲证书 $\mathrm{cert}(\Delta T)$，即可无损重建原差表 $\Delta T$。

<a id="prop-6-1"></a>

**命题 6.1（R43：自由常量表的正合合冲呈示与净额—证书分解）。** 设 $G$ 为阿贝尔群，记自由 $\mathbb{Z}$-模 $\mathbb{Z}^{(G)}$ 及其求值同态 $\mathrm{freeEval}:\mathbb{Z}^{(G)}\to_{\mathbb{Z}} G$（$\delta_g\mapsto g$）。令关系指标集为 $\mathcal{R}_G:=(G\times G)\sqcup(\mathbb{Z}\times G)$，定义同态 $\mathrm{rel}_G:\mathbb{Z}^{(\mathcal{R}_G)}\to_{\mathbb{Z}}\mathbb{Z}^{(G)}$ 为
$$\mathrm{rel}_G\bigl(\delta_{\mathrm{inl}(a,b)}\bigr):=\delta_a+\delta_b-\delta_{a+b},\qquad \mathrm{rel}_G\bigl(\delta_{\mathrm{inr}(w,g)}\bigr):=\delta_{w\cdot g}-w\,\delta_g.$$
则：

1. **环境更新关系分解**：在环境增量下，后继自由常量表满足
   $$T_{\mathrm{after}} = T_{\mathrm{before}} + T_{\mathrm{effect}} - \mathrm{rel}_G(C_{\mathrm{add}}),\tag{6.1}$$
   其中 $C_{\mathrm{add}}\in\mathbb{Z}^{(\mathcal{R}_G)}$ 由各分录旧值与增量的配对显式给出。
2. **构造性合冲证书与正合呈示**：对任意差表 $\Delta T:=T_{\mathrm{after}}-T_{\mathrm{before}}\in\mathbb{Z}^{(G)}$，按其有限支撑列表归纳构造合冲元素 $\mathrm{cert}(\Delta T)\in\mathbb{Z}^{(\mathcal{R}_G)}$，满足
   $$\mathrm{rel}_G(\mathrm{cert}(\Delta T)) = \Delta T - \delta_{\mathrm{freeEval}(\Delta T)}.\tag{6.2}$$
   由此立得正合呈示等式 $\operatorname{im}(\mathrm{rel}_G)=\ker(\mathrm{freeEval})$，且由旧表 $T_{\mathrm{before}}$、净额 $v=\mathrm{freeEval}(\Delta T)$ 与合冲见证 $\mathrm{cert}(\Delta T)$ 通过 $T_{\mathrm{before}}+\delta_v+\mathrm{rel}_G(\mathrm{cert}(\Delta T))$ 恒等还原 $T_{\mathrm{after}}$。

**证明。** 设第 $i$ 个位置的旧值、增量和整数系数分别为 $a_i,b_i,w_i$。取 $T_{\mathrm{effect}}=\sum_i w_i\delta_{b_i}$ 和 $C_{\mathrm{add}}=\sum_i w_i\delta_{\mathrm{inl}(a_i,b_i)}$。逐项展开 $\mathrm{rel}_G(C_{\mathrm{add}})$，即得 (6.1)。为证明 (6.2)，将 $\Delta T$ 写为有限支撑表 $[(g_1,w_1),\dots,(g_m,w_m)]$ 并对长度 $m$ 归纳。当 $m=0$ 时，取 $\mathrm{cert}(0):=-\delta_{\mathrm{inr}(0,0)}$，有 $\mathrm{rel}_G(-\delta_{\mathrm{inr}(0,0)})=-(\delta_0-0\cdot\delta_0)=-\delta_0=0-\delta_{\mathrm{freeEval}(0)}$。归纳步在表首加入 $w\cdot\delta_g$ 时，令新证书在旧证书 $\mathrm{cert}(\mathrm{rest})$ 上加上 $-\delta_{\mathrm{inr}(w,g)}+\delta_{\mathrm{inl}(w\cdot g,\,\mathrm{val}(\mathrm{rest}))}$，展开 $\mathrm{rel}_G$ 消去 $\delta_{\mathrm{val}(\mathrm{rest})}$ 即得 (6.2)。显然 $\mathrm{freeEval}\circ\mathrm{rel}_G=0$；反之若 $\mathrm{freeEval}(\Delta T)=0$，由 (6.2) 与 $\delta_0=\mathrm{rel}_G(\delta_{\mathrm{inr}(0,0)})$ 得 $\Delta T=\mathrm{rel}_G(\mathrm{cert}(\Delta T)+\delta_{\mathrm{inr}(0,0)})\in\operatorname{im}(\mathrm{rel}_G)$。$\square$

式 (6.2) 与正合呈示同样成立于任意交换环 $R$ 及其模 $G$。将标量关系指标改为 $R\times G$，以 $w\cdot g$ 表示模作用，原有限支撑归纳逐项给出所需证书。

<a id="ex-6-1"></a>

**例 6.1（零净额差表的合冲分解算例）。** 在 $G=\mathbb{Z}$ 上取差表 $\Delta T = [5] + [-5] - [0]\in\mathbb{Z}^{(\mathbb{Z})}$，其净额为 $\mathrm{freeEval}(\Delta T)=5+(-5)-0=0$。命题 6.1(2) 将 $\Delta T$ 分解为净额项 $\delta_0=[0]$ 与核内合冲项 $\mathrm{rel}_{\mathbb{Z}}(\mathrm{cert}(\Delta T))=[5]+[-5]-2[0]$ 之和，完整保留正负抵消分录。

### 6.2 任意域上未知稀疏度有号源的 $2k$ 矩 Hankel 恢复（R49）

由有理生成函数理论（Kronecker [@Kronecker1881]）与稀疏插值算法（Prony [@Prony1795]；Ben-Or–Tiwari [@BenOrTiwari1988]），幂矩生成的 Hankel 矩阵秩刻画活跃指数项数。从本文主线看，首 Hankel 块 $H_w$ 恰是单项式族在带号离散测度下的求值 Gram 矩阵：当权重带正负号或域特征为正时，$w<r$ 的低阶首块可因相消而奇异，未知 $r$ 时不能假定首主子式从 $w=1$ 到 $r$ 依次非零。以下定理在任意域 $K$（含正特征有限域）与已知有限候选集上给出完整的最大非奇异首块定阶与恢复证明。

<a id="thm-6-2"></a>

**定理 6.2（R49：任意域上未知 $k$-稀疏有号支撑的 $2k$ 幂矩恢复，`SparseMoment.lean`）。** 设 $K$ 为任意域，$I$ 为指标集，$\tau:I\to K$ 为单射地址映射。设 $a\in K^{(I)}$ 的支撑 $S:=\operatorname{supp}(a)$ 包含于已知有限候选集 $A\subseteq I$，且满足基数上界 $r:=|S|\le k$（$r$ 未知，各活跃权重 $a(s)\in K^\times$ 任意）。定义幂矩 $M_j$ 如下，已知其前 $2k$ 项
$$M_j := \sum_{i\in I} a_i\,\tau(i)^j \in K\qquad (j\ge 0),\tag{6.3}$$
对各阶 $w\ge 0$ 定义首 Hankel 方阵 $(H_w)_{p,q}:=M_{p+q}$（$0\le p,q<w$，约定 $\det H_0=1$）。则：

1. **带号求值 Gram 分解**：记 $S=\{s_0,\dots,s_{r-1}\}$，令矩形 Vandermonde 矩阵 $V_w\in K^{w\times r}$ 为 $(V_w)_{p,\ell}=\tau(s_\ell)^p$，则对一切 $w\in\mathbb{N}$ 有
   $$H_w = V_w\,\operatorname{diag}\bigl(a(s_0),\dots,a(s_{r-1})\bigr)\,V_w^{\mathsf T};\tag{6.4}$$
2. **最大非奇异首块定阶**：即使部分低阶首块 $H_w$（$1\le w<r$）因抵消而满足 $\det H_w=0$，仍有 $\det H_r\neq 0$ 且对一切 $w>r$ 有 $\det H_w=0$；因此真实活跃基数由前 $2k$ 个矩确定为（参见注记 C.1）
   $$r = |S| = \max\{\,w\in\{0,\dots,k\} : \det H_w \neq 0\,\};\tag{6.5}$$
3. **首一递推支撑定位与权重恢复**：令 $c := -H_r^{-1}(M_r,\dots,M_{2r-1})^{\mathsf T}\in K^r$ 并置首一多项式
   $$P(t) := t^r + \sum_{j=0}^{r-1} c_j t^j \in K[t],\tag{6.6}$$
   则候选集内的零点集 $\{i\in A : P(\tau(i))=0\}$ 等于 $S$（`recover_support`），且方阵 $V_r\in K^{r\times r}$ 可逆，给出 $(a(s_0),\dots,a(s_{r-1}))^{\mathsf T} = V_r^{-1}(M_0,\dots,M_{r-1})^{\mathsf T}$（`recover_prefix`）。 当 $r=0$ 时，取 $P=1$，恢复空支撑和零表。

**证明。** (1) 展开矩阵乘积 $(V_w \operatorname{diag}(a|_S) V_w^{\mathsf T})_{p,q}=\sum_{\ell=0}^{r-1}\tau(s_\ell)^p a(s_\ell)\tau(s_\ell)^q=M_{p+q}=(H_w)_{p,q}$。
(2) 当 $w=r$ 时，$V_r$ 由互异域元 $\{\tau(s_\ell)\}_{\ell=0}^{r-1}$ 生成，$\det V_r=\prod_{0\le u<v<r}(\tau(s_v)-\tau(s_u))\neq 0$，且对所有 $s_\ell\in S$ 有 $a(s_\ell)\neq 0$，故 $\det H_r=(\det V_r)^2\prod_{\ell=0}^{r-1}a(s_\ell)\neq 0$。当 $w>r$ 时，$\operatorname{rank}(H_w)\le\operatorname{rank}(V_w)\le r<w$，故 $\det H_w=0$。因 $0\le r\le k$ 且 $H_0,\dots,H_k$ 仅依赖 $M_0,\dots,M_{2k-2}$，满足 $\det H_w\neq 0$ 的最大下标 $w\le k$ 必等于 $r$。
(3) 记 $z_\ell:=a(s_\ell)P(\tau(s_\ell))$。对每个 $0\le p<r$，由 (6.3) 与 $H_r c=-(M_r,\dots,M_{2r-1})^{\mathsf T}$ 得
$$(V_r z)_p = \sum_{\ell=0}^{r-1}\tau(s_\ell)^p a(s_\ell)\Bigl(\tau(s_\ell)^r+\sum_{q=0}^{r-1}c_q\tau(s_\ell)^q\Bigr) = M_{p+r}+\sum_{q=0}^{r-1}M_{p+q}c_q = 0.$$
由 $V_r$ 可逆知 $z=0$；因 $a(s_\ell)\neq 0$，所有 $s_\ell\in S$ 满足 $P(\tau(s_\ell))=0$，即 $S\subseteq R_{\mathrm{rec}}:=\{i\in A:P(\tau(i))=0\}$。又因非零 $r$ 次多项式 $P$ 在域 $K$ 中至多有 $r$ 个根且 $\tau$ 单射，$|R_{\mathrm{rec}}|=|\tau(R_{\mathrm{rec}})|\le r=|S|$，故 $R_{\mathrm{rec}}=S$。最后在前 $r$ 阶矩等式 $V_r a|_S=(M_0,\dots,M_{r-1})^{\mathsf T}$ 左乘 $V_r^{-1}$ 即得全部权重。$\square$

<a id="ex-6-2"></a>

**例 6.2（正特征有限域 $\mathbb{F}_7$ 上的模相消恢复）。** 取 $K=\mathbb{F}_7$、上界 $k=3$、候选集 $A=\{1,2,4\}\subset\mathbb{F}_7$ 及权重 $(3,4,0)$（真实支撑 $S=\{1,2\}$，$r=2$）。计算前 $6$ 个幂矩 $M_j=3\cdot 1^j + 4\cdot 2^j \bmod 7$ 得
$$M = (0,\, 4,\, 5,\, 0,\, 4,\, 5) \pmod 7.$$
首矩 $M_0\equiv 3+4\equiv 0\pmod 7$ 使 $H_1=[0]$ 退化；但二阶块 $H_2=\bigl(\begin{smallmatrix}0&4\\4&5\end{smallmatrix}\bigr)$ 满足 $\det H_2 = 0\cdot 5 - 4^2 = -16 \equiv 5 \not\equiv 0 \pmod 7$，而三阶块满足 $\det H_3 \equiv 0 \pmod 7$，故 (6.5) 给出 $r=2$。解 $H_2 c \equiv -(5,0)^{\mathsf T}\equiv (2,0)^{\mathsf T}\pmod 7$ 得 $c\equiv (2,4)^{\mathsf T}$，生成 $P(t)=t^2+4t+2\equiv (t-1)(t-2)\pmod 7$；在 $A$ 上求值有 $P(1)\equiv P(2)\equiv 0$ 而 $P(4)\equiv 6\not\equiv 0$，还原 $S=\{1,2\}$ 与权重 $(3,4)$。

![图 3｜有号 Hankel 定阶、候选节点筛选与权重恢复](figures/fig3-sparse-hankel.svg)

**图 3｜有号 Hankel 定阶、候选节点筛选与权重恢复。** 六个有号幂矩的首 Hankel 块行列式为 $0,-4,0$，最大非奇异阶为 $2$。从 $H_2$ 求出 $P(t)=t^2-1$，在候选节点中筛出 $1,-1$，再以 Vandermonde 系统恢复权重 $1,-1$（定理 6.2）。

---

## 第四部：奇异 Hermitian Gram、Hilbert 流像与线性增长 Cayley 算子逆

<a id="sec-7"></a>

## 7 有限维奇异 Hermitian Gram 解陪集与增量更新部件

转向正半定内积环境，当有限探针族 $\{u_i\}$ 线性相关甚至包含零向量时，Gram 矩阵 $G_u$ 为奇异半正定矩阵。本节整理奇异 Hermitian Gram 的全解陪集、分离有向网强收敛及 Schur 镶边与对偶列单秩更新公式，作为第 8 节无穷维流像判据的有限维基础部件。

### 7.1 奇异有限 Hermitian Gram 解陪集与有向网强收敛（R44, R46, R48）

<a id="prop-7-1"></a>

**命题 7.1（R44, R46, R48：奇异有限 Gram 解陪集、正交投影合成与分离强收敛）。**

1. **奇异 Hermitian 解陪集（R44，`FiniteGram.lean`）**：设 $G\in\mathbb{C}^{\iota\times\iota}$ 为有限 Hermitian 矩阵，$b\in(\ker G)^\perp$。商同构 $(\mathbb{C}^\iota/\ker G)\simeq(\ker G)^\perp\simeq\operatorname{im}(G)$ 给出唯一最小范数解 $c_\star\in(\ker G)^\perp$ 使 $Gc_\star=b$，全体解集为仿射核陪集
   $$Gx = b \iff x - c_\star\in\ker G.\tag{7.1}$$
2. **向量族相容性与正交投影合成（R44, R48）**：若 $G=G_u$ 由复内积空间 $H$ 的有限族 $u:\iota\to H$ 生成，则对任意 $x\in H$，读数向量 $b=\mathrm{rhs}_u(x)$ 自动属于 $(\ker G_u)^\perp$ 且 $\ker G_u\le\ker\Phi_u$；因此合成元在整条解陪集 (7.1) 上取常值 $\Phi_u(c_\star)=P_{\operatorname{span}(u)} x$，其余项 $(I-P_{\operatorname{span}(u)})x$ 给出正交创新算子 `innovationCLM`。在 R48 的实际双支演化中，完整坐标 $E$ 保留合场的位置系数、正交余项及原外侧分量，库存更新 $U$ 与源作用 $A$ 满足 $U(Ev)=E(Av)$（`actual_stock_source_step`）。
3. **分离测试族有向网强收敛（R46，`PrefixReadback.lean`, `DirectedReadback.lean`）**：若 $H$ 完备且 $\{u_i\}_{i\in\mathcal{J}}$ 在 $H$ 中分离点（$\forall i,\langle u_i,x\rangle_H=0\implies x=0$），则沿有限子集包含有向网 $\mathcal{F}\in\mathrm{Finset}(\mathcal{J})$（含自然数前缀 $n\to\infty$），对每个 $x\in H$ 有
   $$\lim_{\mathcal{F}} \Phi_{u|_{\mathcal{F}}}\bigl(c_\star(G_{u|_{\mathcal{F}}},\,\mathrm{rhs}_{\mathcal{F}}(x))\bigr) = x \quad \text{in }\|\cdot\|_H.\tag{7.2}$$

**证明。** (1) 由 $G=G^*$ 得 $\operatorname{im}(G)=(\ker G)^\perp$，$b\in(\ker G)^\perp$ 确定唯一原像 $c_\star\in(\ker G)^\perp$ 及陪集 (7.1)。(2) $G_u a=0\implies \|\Phi_u(a)\|_H^2=\langle a,G_u a\rangle=0\implies \Phi_u(a)=0$；由 $\langle u_i,x-\Phi_u(c_\star)\rangle_H=0$ 得 $\Phi_u(c_\star)=P_{\operatorname{span}(u)} x$。(3) 分离性蕴含 $\bigcup_{\mathcal{F}}\operatorname{span}(u|_{\mathcal{F}})$ 在完备空间 $H$ 中稠密，单调有向子空间族上的正交投影强收敛至恒等算子。$\square$

### 7.2 Schur 镶边逆、尾线性无关首枢轴选行与对偶列单秩更新（R47, R59）

<a id="prop-7-2"></a>

**命题 7.2（R47：交换环 Schur 镶边更新与尾线性无关族首枢轴解码，`MatrixBorder.lean`, `CofinalInsertion.lean`, `CofinalRecord.lean`）。**

1. **交换环 Schur 镶边公式**：设 $R$ 为交换环，$A\in R^{n\times n}$ 可逆，对镶边方阵 $B=\bigl(\begin{smallmatrix}A&r\\b^{\mathsf T}&d\end{smallmatrix}\bigr)$ 置 Schur 补标量 $s:=d-b^{\mathsf T}A^{-1}r\in R$ [@Schur1917]。则 $\det B=\det(A)\cdot s$，且当 $s\in R^\times$ 时，
   $$\det B=\det(A)\cdot s,\qquad B^{-1}=\begin{pmatrix}A^{-1}+A^{-1}r s^{-1}b^{\mathsf T}A^{-1} & -A^{-1}r s^{-1}\\ -s^{-1}b^{\mathsf T}A^{-1} & s^{-1}\end{pmatrix}.\tag{7.3}$$
2. **尾线性无关族的首非零枢轴选行**：设函数族 $\{f_j:\mathbb{N}\to\mathbb{C}\}_{j\in\mathbb{N}}$ 在每一截断尾 $\{t\ge\tau_{\mathrm{cut}}\}$ 上线性无关。若既有采样点 $\tau_0<\dots<\tau_{n-1}$ 使前 $n$ 个模式的求值限制单射，记新模式 $f_n$ 在旧点上的拟合系数为 $\hat p_n\in\mathbb{C}^n$ 并置残差函数 $\rho_n(t):=f_n(t)-\sum_{i<n}\hat p_{n,i}f_i(t)$，则必存在最小后续时刻 $\tau_n>\max(\{0\}\cup\{\tau_i:i<n\})$（`pivotTime`）使 $\rho_n(\tau_n)\neq 0$；追加 $\tau_n$ 保持前 $n+1$ 个模式采样单射，且对 $y=\sum_{i<n}a_i f_i + b f_n$，由旧求解值 $\tilde a:=\mathrm{solve}_{\tau_{<n}}(y|_{\tau_{<n}})$ 与单点读数 $y(\tau_n)$ 给出（`decode_insert_exact`）：
   $$b = \frac{y(\tau_n)-\sum_{i<n}\tilde a_i f_i(\tau_n)}{\rho_n(\tau_n)},\qquad a = \tilde a - b\,\hat p_n.$$

**证明。** (1) 分块高斯消元直接验证。(2) 若对一切 $t>\max(\{0\}\cup\{\tau_i:i<n\})$ 有 $\rho_n(t)=0$，则 $f_n-\sum_{i<n}\hat p_{n,i}f_i$ 在尾集上恒为零，违反尾线性无关假设，故最小非零时刻 $\tau_n$ 存在；由线性性 $\tilde a = a+b\hat p_n$，代入 $\tau_n$ 消去 $\tilde a$ 恢复 $b$ 与 $a$。$\square$

<a id="prop-7-3"></a>

**命题 7.3（R59：线性无关族追加列的对偶列单秩更新，`Projection/DualColumn/Insert.lean`）。** 设复内积空间 $H$ 中扩张有限族 $u^{\mathrm{snoc}}:=(u,u_{\mathrm{new}})$（$u:\operatorname{Fin} n\to H$）线性无关。记既有双正交基为 $w_i:=\Phi_u(G_u^{-1}e_i)\in\operatorname{span}(u)$（$\langle w_i,u_j\rangle_H=\delta_{ij}$），坐标泛函为 $c_i(x):=\langle w_i,x\rangle_H$，正交余项为 $r_n:=(I-P_{\operatorname{span}(u)})u_{\mathrm{new}}\neq 0$。则扩张族的双正交基与投影系数满足：

1. 末位对偶列向量为
   $$w^{\mathrm{new}}_n = \frac{1}{\|r_n\|_H^2}\,r_n;\tag{7.4}$$
2. 旧索引 $i<n$ 的对偶列向量作单秩更新：
   $$w^{\mathrm{new}}_i = w_i - \overline{\langle w_i, u_{\mathrm{new}}\rangle_H}\,w^{\mathrm{new}}_n;\tag{7.5}$$
3. 对任意 $x\in H$，新增系数 $c_n=\langle r_n,x\rangle_H/\|r_n\|_H^2$ 满足 $|c_n|\cdot\|r_n\|_H\le\|x\|_H$，且全系数满足
   $$c^{\mathrm{new}}_n = c_n,\qquad c^{\mathrm{new}}_i = c_i\bigl(x - c_n u_{\mathrm{new}}\bigr)\quad(\forall i<n).\tag{7.6}$$

**证明。** 由 $r_n\perp\operatorname{span}(u)$ 与 $\langle r_n,u_{\mathrm{new}}\rangle_H=\|r_n\|_H^2$ 直接检验双正交内积 $\langle w^{\mathrm{new}}_p, u^{\mathrm{snoc}}_q\rangle_H=\delta_{pq}$（$0\le p,q\le n$），结合 Cauchy–Schwarz 不等式得全部结论。$\square$

<a id="ex-7-1"></a>

**例 7.1（$\mathbb{C}^2$ 上的对偶列单秩追加算例）。** 设 $u_0=(1,0)^{\mathsf T}\in\mathbb{C}^2$，对偶基为 $w_0=(1,0)^{\mathsf T}$。追加 $u_{\mathrm{new}}=(1,1)^{\mathsf T}$ 时，$r_1=(0,1)^{\mathsf T}$（$\|r_1\|^2=1$）。由 (7.4)–(7.5) 得 $w_1^{\mathrm{new}}=(0,1)^{\mathsf T}$ 与 $w_0^{\mathrm{new}}=(1,0)^{\mathsf T}-1\cdot(0,1)^{\mathsf T}=(1,-1)^{\mathsf T}$，无须对扩展 Gram 矩阵 $\bigl(\begin{smallmatrix}1&1\\1&2\end{smallmatrix}\bigr)$ 求逆即满足 $\langle w^{\mathrm{new}}_i,u_j\rangle=\delta_{ij}$。

---

<a id="sec-8"></a>

## 8 无穷维 Hilbert 流像判据与线性增长 Cayley 算子逆

命题 7.1 处理的是已知源元 $x\in H$ 时的正交逼近；在实际反问题中，给定的往往只是一条无穷标量测量流 $d:\mathbb{N}\to\mathbb{C}$，需要判定是否存在原像 $x\in H$。本节建立允许奇异探针流的 Hilbert 读数流像充要定理（定理 8.1）、闭子空间投影恢复收敛命题（命题 8.2）、有界算子作用流像推论（推论 8.3），以及线性 Cayley 幂增长下的 Banach 差分算子逆与截断预算定理（定理 8.4）。

### 8.1 无穷维 Hilbert 读数流像充要判据与剩余能量恒等式（R50）

给定可数探针流 $\{u_i\}_{i\in\mathbb{N}}\subset H$ 与数据流 $d:\mathbb{N}\to\mathbb{C}$，对每个前缀阶 $n\in\mathbb{N}$ 记 $d|_n:=(d_0,\dots,d_{n-1})\in\mathbb{C}^n$，由命题 7.1 定义第 $n$ 阶奇异 Gram 近似元 $x_n(d):=\Phi_{u|_n}(c_\star(G_{u|_n},P_{(\ker G_{u|_n})^\perp}(d|_n)))$、前缀残差与前缀最小范数能量：
$$r_n(d):=\mathrm{rhs}_{u|_n}(x_n(d))-d|_n,\qquad E_n(d):=\|x_n(d)\|_H^2.\tag{8.1}$$

<a id="thm-8-1"></a>

**定理 8.1（R50：奇异探针下的 Hilbert 读数流像充要判据与剩余能量恒等式，`PrefixImage.lean`, `PrefixEnergy.lean`）。** 设 $H$ 为复 Hilbert 空间，$\{u_i\}_{i\in\mathbb{N}}\subset H$ 为任意探针流（不假定正交或线性无关），$d:\mathbb{N}\to\mathbb{C}$ 为数据流。

1. **流像充要判据（`admitted_iff_image`）**：存在 $x\in H$ 使对一切 $i\in\mathbb{N}$ 有 $\langle u_i,x\rangle_H=d_i$，**当且仅当**由各有限前缀决定的残差与能量序列满足（对照 F. Riesz [@Riesz1910] 与 Aronszajn [@Aronszajn1950] 的有界泛函判据）：
   $$(\forall n\in\mathbb{N},\ r_n(d)=0)\quad \wedge\quad \sup_{n\in\mathbb{N}} E_n(d) < \infty.\tag{8.2}$$
2. **强极限最小范数解与剩余能量等式（`error_squared`, `first_within`）**：当 (8.2) 成立时，对任意 $m\le n$ 有 $x_m(d)=P_{\operatorname{span}(u|_m)} x_n(d)$ 与毕达哥拉斯递推
   $$E_n(d)=E_m(d)+\|x_n(d)-x_m(d)\|_H^2;\tag{8.3}$$
   序列 $\{x_n(d)\}$ 在 $H$ 中强收敛至 $x_\star\in\overline{\operatorname{span}\{u_i\}}$，$x_\star$ 是全体实现纤维 $x_\star+\{u_i\}^\perp$ 中的唯一最小范数解（$\|x_\star\|_H^2=E_\infty:=\sup_n E_n(d)$），且第 $n$ 阶前缀近似的平方误差满足恒等式
   $$\|x_\star - x_n(d)\|_H^2 = E_\infty - E_n(d).\tag{8.4}$$
   对任意 $\varepsilon>0$，最小满足 $E_\infty-E_n(d)<\varepsilon^2$ 的下标给出达标前缀阶 $n_\varepsilon$（`firstWithin`），且任意有界算子 $L\in\mathcal{B}(H,V)$ 满足误差上界 $\|L(x_\star)-L(x_n(d))\|_V\le\|L\|\sqrt{E_\infty-E_n(d)}$。

**证明。** （必要性）若 $\langle u_i,x\rangle_H=d_i$（$\forall i$），命题 7.1(2) 给出 $x_n(d)=P_{\operatorname{span}(u|_n)}x$，故对 $i<n$ 有 $\langle u_i,x_n(d)\rangle_H=d_i$（即 $r_n(d)=0$），且 $E_n(d)=\|P_{\operatorname{span}(u|_n)}x\|_H^2\le\|x\|_H^2<\infty$。
（充分性）设 (8.2) 成立，记 $E_\infty:=\sup_n E_n(d)<\infty$。当 $m\le n$ 时，$r_n(d)=0$ 保证对 $i<m$ 有 $\langle u_i,x_n(d)\rangle_H=d_i$，再由命题 7.1(2) 得 $x_m(d)=P_{\operatorname{span}(u|_m)} x_n(d)$ 及正交分解 (8.3)。任给 $\varepsilon>0$，取 $N$ 使 $E_\infty-\varepsilon^2<E_N(d)$，则对 $n\ge N$ 有 $\|x_n(d)-x_N(d)\|_H^2=E_n(d)-E_N(d)\le E_\infty-E_N(d)<\varepsilon^2$，故 $\{x_n(d)\}$ 为 Cauchy 列，由 $H$ 完备性收敛至 $x_\star\in\overline{\operatorname{span}\{u_i\}}$。固定 $i$，当 $n>i$ 时 $\langle u_i,x_n(d)\rangle_H=d_i$，令 $n\to\infty$ 得 $\langle u_i,x_\star\rangle_H=d_i$。任意实现元 $x$ 满足 $x-x_\star\in\{u_i\}^\perp$，故 $x-x_\star\perp x_\star$，$\|x\|_H^2=\|x_\star\|_H^2+\|x-x_\star\|_H^2\ge\|x_\star\|_H^2$。最后由 $x_n(d)=P_{\operatorname{span}(u|_n)}x_\star\to x_\star$ 得 $E_n(d)\uparrow\|x_\star\|_H^2=E_\infty$，代入 $\|x_\star-x_n(d)\|_H^2=\|x_\star\|_H^2-\|x_n(d)\|_H^2$ 即得 (8.4) 及有界算子误差上界。$\square$

### 8.2 闭子空间投影恢复与有界算子作用流像（R62, R51）

<a id="prop-8-2"></a>

**命题 8.2（R62：闭子空间投影探针受限 Gram 恢复与细化强收敛，`ContactFibre.lean`）。** 设 $S\le H$ 为复内积空间 $H$ 的完备闭子空间，$u:\iota\to H$ 为有限外部探针族。置投影探针 $\tilde u_i:=P_S(u_i)\in S$，并在完备空间 $S$ 内定义 $\mathcal{R}_{S,u}:\mathbb{C}^\iota\to S$，先将数据投影到 $(\ker G_{\tilde u})^\perp$，再用命题 7.1 合成。则对任意 $x\in S$：

1. **外部测量相容与能量分解**：恢复元 $\hat x:=\mathcal{R}_{S,u}(\mathrm{rhs}_u(x))\in S$ 满足外部方程 $\langle u_i,\hat x\rangle_H=\langle u_i,x\rangle_H$（$\forall i\in\iota$）及正交能量分解 $\|x\|_H^2=\|\hat x\|_H^2+\|x-\hat x\|_H^2$；
2. **细化误差单调不增与强收敛**：若有限族 $v:\kappa\to H$ 经映射 $e:\iota\to\kappa$ 包含 $u$（$v_{e(i)}=u_i$），则重构误差单调不增 $\|x-\mathcal{R}_{S,v}(\mathrm{rhs}_v(x))\|_H\le\|x-\mathcal{R}_{S,u}(\mathrm{rhs}_u(x))\|_H$；若可数探针族 $\{u_i\}_{i\in\mathbb{N}}$ 分离 $H$，则沿保留第 $n$ 阶前缀的任意有限细化列 $\{v^{(n)}\}$，有 $\lim_{n\to\infty}\mathcal{R}_S(\mathrm{rhs}_{v^{(n)}}(x))=x$。

**证明。** 对 $z\in S$，$\langle \tilde u_i,z\rangle_H=\langle P_S u_i,z\rangle_H=\langle u_i,P_S z\rangle_H=\langle u_i,z\rangle_H$，故 $\mathrm{rhs}_u(x)=\mathrm{rhs}_{\tilde u}(x)$。在 $S$ 内调用命题 7.1(2) 得 $\hat x=P^S_{\operatorname{span}(\tilde u)}x$，从而 $\langle u_i,x-\hat x\rangle_H=\langle \tilde u_i,x-\hat x\rangle_H=0$ 及能量分解成立。包含关系给出 $\operatorname{span}(\tilde u)\le\operatorname{span}(\tilde v)\le S$，正交投影最佳逼近性保证误差单调不增；若 $\{u_i\}$ 分离 $H$，则 $\{\tilde u_i\}$ 分离 $S$，由命题 7.1(3) 与夹逼性得强收敛。$\square$

<a id="cor-8-3"></a>

**推论 8.3（R51：有界线性算子作用流像充要判据与核陪集原像纤维，`ActionImage.lean`）。** 设 $H,F$ 为复 Hilbert 空间，$A\in\mathcal{B}(H,F)$ 为有界线性算子（不假定单射、满射或闭值域），$\{v_i\}_{i\in\mathbb{N}}\subset F$ 为输出探针流，记伴随拉回探针流为 $u_i:=A^* v_i\in H$。

1. **作用流像判据（`admitted_iff_action_image`）**：存在 $x\in H$ 使 $\forall i\in\mathbb{N},\ \langle v_i,Ax\rangle_F=d_i$，**当且仅当**拉回探针流 $\{A^* v_i\}$ 对数据 $d$ 满足
   $$(\forall n\in\mathbb{N},\ r_n^{(A^*v)}(d)=0)\quad\wedge\quad \sup_{n\in\mathbb{N}} E_n^{(A^*v)}(d) < \infty;\tag{8.5}$$
2. **原像核陪集（`complete_fibre`）**：当 (8.5) 成立且 $\{v_i\}$ 分离 $F$ 时，记 $x_\star\in H$ 为定理 8.1 对 $\{A^*v_i\}$ 生成的最小范数解，则 $d$ 的全体原像构成仿射核陪集
   $$\{x\in H : \forall i\in\mathbb{N},\ \langle v_i, Ax\rangle_F = d_i\} = x_\star + \ker A.\tag{8.6}$$

**证明。** 由恒等式 $\langle A^* v_i, x\rangle_H = \langle v_i, Ax\rangle_F$ 直接应用定理 8.1 即得 (8.5) 与 $x_\star$；当 $\{v_i\}$ 分离 $F$ 时，$(\forall i,\langle v_i,Ax\rangle_F=d_i)\iff Ax=Ax_\star\iff x-x_\star\in\ker A$。$\square$

![图 4｜Hilbert 前缀能量、Cayley 双边逆及两项截断误差](figures/fig4-hilbert-cayley.svg)

**图 4｜Hilbert 前缀能量、Cayley 双边逆及两项截断误差。** 左上比较两条零残差 Hilbert 采样流，并标出收敛流的平方误差（定理 8.1）。右上绘制 $\delta=1$ 的 Jordan 例，并给出任意 $\delta>0$ 的取等构造。下栏依次用阻尼、有限和双边消项与取极限得到 Cayley 逆，最后分别给出观测噪声与截断尾项的误差界（定理 8.4）。

### 8.3 线性 Cayley 幂增长下的显式 Banach 算子逆与一致截断预算（R52, R61）

设 $A$ 为完备复 Banach 代数 $\mathcal{A}$ 中的元素。若仿射移位元 $C_\delta(A):=1+\delta A$（$\delta>0$）满足一阶线性幂增长界 $\|(1+\delta A)^n\|\le (n+1)B$，则 $C_\delta(A)$ 的谱半径不超过 $1$，从而 $\sigma(A)\subseteq\overline{D}(-1/\delta,1/\delta)$ 远离 $1$，$A-1$ 的可逆性由谱位置即得；但此时 $C_\delta(A)$ 未必满足范数压缩条件 $\|C_\delta(A)\|<1$ 甚至未必幂有界。以下定理的目的在于：不借助谱分解或预解围道积分，直接通过几何阻尼因子 $q=(1+\delta)^{-1}$ 给出 $(A-1)^{-1}$ 的绝对收敛幂级数、证明上界常数 $(1+\delta)B/\delta$ 可达，并导出噪声放大因子一致有界（不随截断阶数 $m$ 增长）的有限步误差预算。

<a id="thm-8-4"></a>

**定理 8.4（R52, R61：线性 Cayley 幂增长下 $A-1$ 的显式双边逆、可达范数界与一致截断预算，`CayleyEffectInverse`）。** 设 $\mathcal{A}$ 为含幺完备复 Banach 代数，$A\in\mathcal{A}$。若存在 $\delta>0$ 与 $B\ge 0$ 使 $C_\delta(A):=1+\delta A$ 满足
$$\forall n\in\mathbb{N},\qquad \bigl\|(1+\delta A)^n\bigr\|\le (n+1)B,\tag{8.7}$$
置阻尼因子 $q:=(1+\delta)^{-1}\in(0,1)$ 与缩放移位元 $K_\delta(A):=q\,C_\delta(A)\in\mathcal{A}$。则：

1. **显式双边有界逆与可达常数（R52）**：无穷级数
   $$\mathcal{I}_\delta(A) := -\delta q\sum_{n=0}^{\infty} K_\delta(A)^n = -\frac{\delta}{1+\delta}\sum_{n=0}^{\infty}(1+\delta)^{-n}(1+\delta A)^n\tag{8.8}$$
   在 $\mathcal{A}$ 中绝对收敛，给出 $A-1$ 的双边逆及下列范数界。例 1.1(e) 对每个 $\delta>0$ 在 $B=1$ 时取等。
   $$\mathcal{I}_\delta(A)(A-1) = (A-1)\mathcal{I}_\delta(A) = 1,\qquad \|\mathcal{I}_\delta(A)\| \le M_{\delta,B} := \frac{\delta q B}{(1-q)^2} = \frac{1+\delta}{\delta}B.\tag{8.9}$$
2. **等距情形的源范数控制（R61）**：当 $\mathcal{A}=\mathcal{B}(H)$（$H$ 为复 Banach 空间）且 $C_\delta(A)$ 为等距算子（$\|C_\delta(A)x\|=\|x\|,\ B=1$）时，对一切 $x\in H$ 有 $\|x\|\le\|(A-1)x\|$，且第 $m$ 步截断算子 $F_{\delta,m}(A):=-\delta q\sum_{k=0}^{m-1}K_\delta(A)^k$ 满足 $\|F_{\delta,m}(A)(A-1)x-x\|\le q^m\|(A-1)x\|$；
3. **线性增长下的步数无关含噪误差预算（R61）**：当 $\mathcal{A}=\mathcal{B}(H)$（$H$ 为完备复 Banach 空间）且满足 (8.7) 时，对任意 $m\in\mathbb{N}$、精确右端 $y\in H$ 与含噪观测 $\tilde y\in H$，截断算子满足尾恒等式 $F_{\delta,m}(A)y=\mathcal{I}_\delta(A)y-K_\delta(A)^m\mathcal{I}_\delta(A)y$ 与独立于步数 $m$ 的一致算子范数界 $\|F_{\delta,m}(A)\|\le M_{\delta,B}$（注记 C.2），从而满足含噪误差上界
   $$\bigl\|F_{\delta,m}(A)\tilde y - (A-1)^{-1}y\bigr\| \le M_{\delta,B}\|y-\tilde y\| + B(m+1)q^m M_{\delta,B}\|y\|,\tag{8.10}$$
   其中尾项系数 $(m+1)q^m\to 0$（$m\to\infty$），故当 $m\to\infty$ 且 $\|y-\tilde y\|\to 0$ 时 $F_{\delta,m}(A)\tilde y\to (A-1)^{-1}y$。

**证明。** (1) 由 $\delta q = \delta/(1+\delta) = 1-q$，展开得 $-\delta q(A-1) = (1-q)-q\delta A = 1-q(1+\delta A) = 1-K_\delta(A)$。由 (8.7)，$\|K_\delta(A)^n\| \le B(n+1)q^n$；因 $0<q<1$，$\sum_{n=0}^\infty (n+1)q^n=(1-q)^{-2}<\infty$，级数在完备代数 $\mathcal{A}$ 中绝对收敛于 $(1-K_\delta(A))^{-1}$。乘以 $-\delta q$ 并利用 $A-1$ 与 $K_\delta(A)$ 交换即证双边逆等式及范数界 $\delta q B/(1-q)^2 = (1+\delta)B/\delta$。
(2) 当 $C_\delta(A)$ 等距时，$-\delta q(A-1)x = x - K_\delta(A)x$ 给出 $\delta q\|(A-1)x\|\ge \|x\|-q\|x\|=\delta q\|x\|$，消去 $\delta q>0$ 得 $\|x\|\le\|(A-1)x\|$；伸缩和恒等式 $F_{\delta,m}(A)(A-1)=1-K_\delta(A)^m$ 给出误差上界 $q^m\|(A-1)x\|$。
(3) 将 $y=(A-1)\mathcal{I}_\delta(A)y$ 代入 $F_{\delta,m}(A)(A-1)=1-K_\delta(A)^m$ 得尾分解；由各项非负性有 $\|F_{\delta,m}(A)\|\le \delta q \sum_{k=0}^{m-1} B(k+1)q^k \le M_{\delta,B}$。用三角不等式拆分 $\|F_{\delta,m}(A)(\tilde y-y)\|+\|K_\delta(A)^m\mathcal{I}_\delta(A)y\|$ 即得 (8.10)。$\square$

<a id="ex-8-1"></a>

**例 8.1（$2\times 2$ Jordan 块上的有限步截断核对）。** 将例 1.1(e) 专门取为 $\delta=1$，故 $A_1=J$、$q=1/2$、$B=1$，有 $M_{1,1}=2$。第 $m$ 步截断矩阵 $F_{1,m}(A)=-\frac12\sum_{k=0}^{m-1}2^{-k}\bigl(\begin{smallmatrix}1&k\\0&1\end{smallmatrix}\bigr)$ 的 $\ell^1$ 算子范数为 $2-(m+2)2^{-m} < 2 = M_{1,1}$，与真逆 $\bigl(\begin{smallmatrix}-1&-1\\0&-1\end{smallmatrix}\bigr)$ 的算子范数误差为 $(m+2)2^{-m} \le 2(m+1)2^{-m} = B(m+1)q^m M_{1,1}$（$\forall m\ge 1$）。

---

<a id="sec-9"></a>

## 9 五轴文献对话与数学应用接缝

表 2 与以下五小节按研究轴对照 41 篇原始文献，区分古典结果、形式化封装与本文新增的显式判据及常数界。

**表 2　五条技术轴与原始文献定位总表**

| 技术轴 | 代表性原始文献 | 前作既有范围 | 本文定位与边界 |
| --- | --- | --- | --- |
| **轴一：特征标与逆极限** | Pontryagin [@Pontryagin1934]; Baer [@Baer1940]; Lambek [@Lambek1964]; Milnor [@Milnor1962]; Weibel [@Weibel1994]; Jannsen [@Jannsen1988] | 局部紧拓扑群双对偶；可除群内射性；$\varprojlim^1$ 与 Mittag-Leffler；连续上同调挠障碍 | 归功 Baer 内射性，在无拓扑假设下将同构限定于求值像 $P_{\chi,R}(A)$；给出 Kummer 余核挠塔三层前提结论与阶乘模 $(n+1)!$ 平衡代表元整源跳跃判准 |
| **轴二：Picard 线与行列式接口** | Knudsen–Mumford [@KnudsenMumford1976]; Deligne [@Deligne1987]; Stacks `0FJ9` [@Stacks0FJ9]; Tate [@Tate1966]; Nekovář [@Nekovar2006]; Macias Castillo–Sano [@MaciasCastilloSano2026] | 完美复形行列式函子；虚拟范畴；开闭分块拼合；Selmer 复形与高度配对 | 在 `mathlib` 椭圆曲线类群基础上连接 $(1,0)$ 非自由理想与常秩分派器，并将双格、Smith 指数、粘合、四项自由复形整线与极限映射锥封装为无基底接口 |
| **轴三：合冲呈示与有号稀疏矩** | Green 等 [@Green2007Provenance]; Cai 等 [@Cai2014Changes]; DBSP [@Budiu2023DBSP]; Ellerman [@Ellerman2014Accounting]; Kálmán [@Kalman1963]; Prony [@Prony1795]; Kronecker [@Kronecker1881]; Ben-Or–Tiwari [@BenOrTiwari1988]; Candès–Fernandez-Granda [@CandesFernandezGranda2014] | 半环溯源；$\mathbb{Z}$-集与差群；线性系统不可观子空间；稀疏插值与连续含噪最小间距超分辨 | 建立环模不可观最大不变子模与自由常量表构造性合冲呈示；在任意域（含正特征）与有限候选集上完成允许低阶相消奇异的 $2k$ 矩最大非奇异首块恢复与机检 |
| **轴四：流像判据与 Cayley 逆** | Schur [@Schur1917]; Penrose [@Penrose1955]; F. Riesz [@Riesz1910]; Aronszajn [@Aronszajn1950]; Douglas [@Douglas1966]; Adcock–Hansen [@AdcockHansen2016]; Kreiss [@Kreiss1962]; Katznelson–Tzafriri [@KatznelsonTzafriri1986] | 广义逆与 Schur 补；有界矩判据与再生核；算子值域包含；斜投影广义采样；预解与幂有界算子 | 在奇异探针流下给出构造性前缀投影强极限与能量缺口恒等式；区分投影探针正交恢复与斜投影采样；在线性 Cayley 增长下给出显式级数、可达常数 $(1+\delta)B/\delta$ 与步数无关误差预算 |
| **轴五：形式化数学与规格边界** | de Moura–Ullrich [@deMouraUllrich2021Lean4]; mathlib [@mathlib2020]; Angdinata–Xu [@AngdinataXu2023]; Buzzard 等 [@BuzzardCommelinMassot2020]; Commelin–Topaz [@CommelinTopaz2024] | Lean 4 内核与数学库；Weierstrass 曲线群律；完备化与抽象规格边界 | 在同一标准三公理类型边界内打通模论、同调极限、有限域稀疏代数与 Hilbert／Banach 算子分析，隔离无基底接口与下游坐标选择 |

### 9.1 轴一对话：从 Pontryagin／Baer／Jannsen 到求值像与阶乘跳跃

Pontryagin [@Pontryagin1934] 的局部紧交换群双对偶满射依赖连续特征标限制；在纯代数设定下，即使 $\mathbb{Z}$ 的代数双对偶 $\mathbb{Z}^{\vee\vee}_\chi\cong\widehat{\mathbb{Z}}$ 也严格更大。命题 2.1 基于 Baer 可除内射判准 [@Baer1940; @Stacks01D6] 与 Lambek 特征标模框架 [@Lambek1964]，明确把同构域限定于求值像 $P_{\chi,R}(A)$，用 $(\mathbb{Z}/2\mathbb{Z})^2$ 对照整数线性泛函的挠盲区。在逆极限侧，对照 Milnor [@Milnor1962]、Weibel [@Weibel1994]（第 3.5 节）以及 Jannsen [@Jannsen1988] 指出的无界 $p^\infty$-挠对逆极限正合性的阻碍，定理 2.5（R54）将环境 $p$-可除（连接极限满射）、源有界 $p^d$-挠（环境挠单射与核正合）和环境唯一 $p$-可除（$\widehat{L}_p\simeq T_p(M/L)$）三层充分前提分开陈述；定理 2.7（R57–R58）则利用阶乘模 $(n+1)!$ 半开平衡代表元的稳定与晚阶共尾跳跃，为判别极限相干元是否来自整数源提供了离散充要条件。

### 9.2 轴二对话：从 Knudsen–Mumford／Deligne 到无基底代数接口

Knudsen–Mumford [@KnudsenMumford1976] 与 Deligne [@Deligne1987] 建立了完美复形行列式函子及其拟同构不变性，Stacks Tag `0FJ9` [@Stacks0FJ9] 给出了变秩有限投射模按开闭分解拼合行列式的标准构造。本文 §3–§4 的范围比一般导出行列式函子更具体：命题 3.1–3.2 在 `mathlib` 椭圆曲线类群形式化 [@AngdinataXu2023; @mathlib2020] 基础上把 $(1,0)\in E(\mathbb{Q})$ 作为常秩非自由分支的显式实例（配套初等次数证明），而命题 4.1–4.5 则是面向算术高度与格指数背景 [@Tate1966; @Nekovar2006; @MaciasCastilloSano2026]、按照规格驱动原则 [@CommelinTopaz2024] 封装的无基底接口层（其中四项复形接口仅覆盖逐项同构输运，不重证一般完美复形的拟同构不变性）。

### 9.3 轴三对话：从不可观子空间／差群／Prony 到合冲呈示与任意域定阶

在动力系统与增量计算中，命题 5.3(2)（R24–R25）的词评价核 $\ker\mathcal{I}\le\ker e$ 是 Kálmán 线性系统不可观子空间 [@Kalman1963] 在一般交换环模与多自同态字作用下的代数形式；对照半环溯源 [@Green2007Provenance]、静态变化结构 [@Cai2014Changes]、DBSP $\mathbb{Z}$-集 [@Budiu2023DBSP] 与 Ellerman 差群 [@Ellerman2014Accounting]，命题 6.1（R43）用显式合冲映射 $\mathrm{cert}(\Delta T)$ 给出了短正合呈示 $\operatorname{im}(\mathrm{rel}_G)=\ker(\mathrm{freeEval})$ 的构造性分解。在稀疏恢复侧，Hankel 秩定阶源于 Prony [@Prony1795]、Kronecker [@Kronecker1881] 与 Ben-Or–Tiwari [@BenOrTiwari1988]（算子特征函数推广见 Peter–Plonka [@PeterPlonka2013]，连续含噪设定下以最小间距控制条件数的理论见 Candès–Fernandez-Granda [@CandesFernandezGranda2014]）。定理 6.2（R49）聚焦于已知有限候选集上的无噪离散代数恢复，贡献在于在**任意域 $K$（含正特征有限域）**与未知稀疏度 $r\le k$ 下，完整形式化了低阶相消奇异时的最大非奇异首块定阶与恢复链。

### 9.4 轴四对话：从 F. Riesz／再生核／广义采样到奇异流像与 Cayley 可达常数

无穷线性矩方程存在有界范数解的判据可追溯至 F. Riesz [@Riesz1910] 与再生核二次型有界性（Aronszajn [@Aronszajn1950]），有限维广义逆与分块补则源于 Penrose [@Penrose1955] 与 Schur [@Schur1917]。定理 8.1（R50）在允许探针流任意线性相关或含零向量的条件下，把这一存在性准则具体化为逐前缀奇异 Gram 投影构造，给出强极限最小范数解与精确能量缺口恒等式 $\|x_\star-x_n\|^2=E_\infty-E_n$，并经伴随拉回导出一般有界算子作用流像判据（推论 8.3，对照 Douglas 全算子值域包含定理 [@Douglas1966]）。对于子空间恢复，Adcock–Hansen [@AdcockHansen2016] 的广义采样预先给定重构空间，稳定采样率对限制在该空间的采样算子给出下界。命题 8.2（R62）从已知闭子空间 $S\le H$ 正交投影算子 $P_S$ 的情形，直接重构于投影探针张成空间 $\operatorname{span}(P_S u_i)\le S$ 内，按构造属于正交投影，故误差随探针细化单调不增。最后，对照自伴分式 Cayley 变换 [@vonNeumann1930]、Kreiss 矩阵预解条件 [@Kreiss1962] 与幂有界算子谱理论 [@KatznelsonTzafriri1986]，定理 8.4（R52, R61）在一阶线性幂增长 $\|(1+\delta A)^n\|\le (n+1)B$ 下给出了无需谱分解的显式阻尼级数、证明了算子范数常数 $(1+\delta)B/\delta$ 可在 Jordan 块上精确取到，并证明有限截断对观测误差的放大因子一致不超过 $M_{\delta,B}$（与截断步数 $m$ 无关）。

### 9.5 轴五对话：形式化架构与跨领域接口复用

本文在 Lean 4 [@deMouraUllrich2021Lean4] 与 `mathlib` [@mathlib2020; @AngdinataXu2023] 上采用单核心多分支组织方式（对照完备化与凝聚数学的形式化工程经验 [@BuzzardCommelinMassot2020; @CommelinTopaz2024] 及同系列基础篇 [@Gao2026OneBitV2; @Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2]）。由于各命题均以一般环模、任意域或抽象 Hilbert／Banach 空间参数化陈述，所得定理与无基底接口可作为独立数学模块复用于三类后续分析任务：(i) 利用联合核商（命题 2.3(2)）分离单一标量化读数盲区中的挠类，并以定理 6.2 反演离散脉冲矩；(ii) 利用有限奇异 Gram 强收敛（命题 7.1）、流像判据（定理 8.1）、闭子空间投影恢复（命题 8.2）与线性增长差分逆（定理 8.4）重构闭线性算子图与预解差分；(iii) 利用双格对偶、Smith 有限余核指数与四项自由整复形交错线接口（命题 4.1–4.5）在推迟选基的前提下组织高度配对与整上同调行列式计算。

---

## 附录 A　Kummer 挠塔、阶乘代表元与四项复形接口补充证明

<a id="app-a-1"></a>

**引理 A.1（有界源挠下的平移提升对齐）。** 设 $\iota:L\to_{\mathbb{Z}} M$ 单射，$C=M/\operatorname{im}\iota$，且存在 $d\in\mathbb{N}$ 使 $\forall j,\forall y\in L[p^{j+1}],\ p^d y=0$。若 $r_j,\tilde r_j\in M[p^{j+1}]$ 在 $C$ 中余类相同，则对一切 $j\in\mathbb{N}$ 有 $p^d r_{j+d} = p^d \tilde r_{j+d}$。

**证明。** 由 $\pi_C(r_{j+d}-\tilde r_{j+d})=0$ 知存在 $y\in L$ 使 $\iota(y)=r_{j+d}-\tilde r_{j+d}$。两边乘以 $p^{j+d+1}$ 得 $\iota(p^{j+d+1}y)=0$，由 $\iota$ 单射知 $y\in L[p^{j+d+1}]$，故 $p^d y=0$，两边作用 $\iota$ 即得 $p^d r_{j+d}=p^d\tilde r_{j+d}$。$\square$

<a id="app-a-2"></a>

**命题 A.2（阶乘平衡代表元唯一性与整源稳定阈值）。** 对同构 $\phi:L\xrightarrow{\sim}\mathbb{Z}$ 与 $M_n=(n+1)!$，半开区间 $[-\lfloor M_n/2\rfloor,\ M_n-\lfloor M_n/2\rfloor)$ 含 $M_n$ 个连续整数，故任意余类 $v_n\in L/M_n L$ 在该区间内有唯一代表元 $b_n(v)$。对固定 $s\in L$，取 $N:=2|\phi(s)|+2$，当 $n\ge N$ 时 $(n+1)!\ge n+1 > 2|\phi(s)|$，故 $s$ 落入该半开区间，必有 $b_n(\iota_!(s))=s$。

**证明。** 同余模 $M_n$ 且同落入宽度为 $M_n$ 的半开区间的两整数之差绝对值小于 $M_n$ 且被 $M_n$ 整除，必为零；第二部分由 $n+1\le (n+1)!$ 与 $\lfloor M_n/2\rfloor\ge (M_n-1)/2$ 直接核验。$\square$

<a id="app-a-3"></a>

**命题 A.3（四项自由整复形交错行列式线的秩一性与同构输运）。** 在命题 4.4 条件下，$\det_{\mathbb{Z}}(C^\bullet)$ 是秩 $1$ 自由 $\mathbb{Z}$-模，其两个整生成元构成 $\{\pm 1\}$-扭子，且偶协变、奇逆变对偶诱导映射与逐项复形同构的复合协变相容。

**证明。** 任取有限自由 $\mathbb{Z}$-模 $C_i$ 的一组辅助整基（仅用于验证存在性，不进入 $\det_{\mathbb{Z}}(C^\bullet)$ 的定义），则每个顶外幂 $\det_{\mathbb{Z}}(C_i)$ 及其 $\mathbb{Z}$-线性对偶均同构于 $\mathbb{Z}$，四重张量积同构于 $\mathbb{Z}^{\otimes 4}\cong\mathbb{Z}$，故秩一自由，且整自同构群为 $\mathbb{Z}^\times=\{\pm 1\}$。对可逆线性映射 $e:C_{2k+1}\xrightarrow{\sim} D_{2k+1}$ 与 $f:D_{2k+1}\xrightarrow{\sim} E_{2k+1}$，对偶反变性与求逆反变性抵消：$((f\circ e)^{-1})^\vee = (e^{-1}\circ f^{-1})^\vee = (f^{-1})^\vee \circ (e^{-1})^\vee$，故在张量积上保持协变函子复合律。$\square$

---

## 附录 B　R1–R62 与无基底行列式接口索引及 Lean 4 声明映射

### B.1 命题族 R1–R62 源码路径、提交纪元与正文位置对照表

研究源仓 `Homework` 的固定提交链按批次为：`e60a86058a`（`R1–R8`）、`eec031c489`（`R9–R13`）、`453de27572`（`R14–R17`）、`c19e94a5e0`（`R18–R19`）、`fde5c14df3`（`R20–R23`）、`aef0ad2a26`（`R24–R27`）、`26b91feb6b`（`R28–R31`）、`e055580972`（`R32–R33`）、`c62f3d25c4`（`R34–R35`）、`71e94e8261`（`R36–R37`）、`9c73a630ce`（`R38–R39`）、`ba7e274beb`（`R40–R42`）、`df421ff600`（`R43–R45` 及接口 I–V）、`7e4da746f3`（`R46–R48`）、`3a90cba5ac`（`R49–R50`）、`11a0142465`（`R51`）、`1abd7da932`（`R52`）及 `f94092efb4`（`R53–R62`）。

路径前缀简记：`GF/` = `Lean/SaturationMonoid/GenericFoundation/`；`SM/` = `Lean/SaturationMonoid/`；`W/` = `GF/Operations/Inquiry/Context/Faces/Execution/Activation/Receipt/Configured/Writeback/Successor/FourFace/Native/Source/Word/`；`PG/` = `SM/NoIslandNoMagic/CanonicalRiemann/GeneralizedDual/CoPoissonEnergy/Muntz/Cokernel/CenteredGram/JointAction/Runtime/`。公开模块及其构建范围见随稿的[公开模块表](https://github.com/Sapientropic/H0mework/blob/ccf469d177d0cff2cefbb162b4f5ab7891a83b25/docs/exact-realization-map.json)。

| 编号 | 数学内容与范围 | 源码入口与核心声明 | 正文位置 |
| --- | --- | --- | --- |
| **R1** | 交换环模特征标双对偶像同构与自然性；$(\mathbb{Z}/2\mathbb{Z})^2$ 挠元分离 | `GF/Scalar/Character/Exact.lean` (`equiv`, `factor_unique`); `GF/Operations/Runtime/Regression/Character.lean` | §2.1 命题 2.1；例 1.1(a)；图 2 |
| **R2** | 加法群相对评价余像 $C/\ker e$ 单射与 $\ker e\le\ker f$ 分解判据 | `GF/LivingLawRootGeneratedSourcePerfectificationKernel.lean` (`dualEmbedding_injective`, `canonicalMap_universal`) | §2.2 命题 2.2(1) |
| **R3** | 相容阶段评价塔核商逆极限、余核残差塔单射与自然态射 | `GF/Scalar/Cofinal/LivingLawRootGeneratedScalarCofinalExactEnvelopeKernel.lean` (`completion_universal_property`); `SM/LivingLawRootGeneratedCofinalCoverageResidualTowerKernel.lean` (`completionResidualToResidualLimit_injective`); `GF/LivingLawRootGeneratedDependentCofinalProfileNaturalityKernel.lean` | §2.2 命题 2.2(1) |
| **R4** | 线性观察的四支互斥见证分类（双射／纯核／纯覆盖／双重损失） | `GF/Scalar/Observation/LivingLawRootGeneratedScalarObservationDispositionKernel.lean` (`settle`, `settle_exact_iff_bijective`, `settle_eq_kernelAndCoverage_of_neither`) | §2.2 命题 2.2(3)；图 2 |
| **R5** | 有限投射张量对偶、柄秩分派、常秩顶外幂与标架扭子分类 | `GF/Scalar/Bounded/LivingLawRootGeneratedScalarBoundedObservationDispositionKernel.lean`; `GF/Scalar/Determinant/LivingLawRootGeneratedScalarProjectiveDeterminantDispositionKernel.lean` (`settle`, `settle_constant_of_constantRank`) | §3.1 命题 3.1；图 2 |
| **R6** | 仿射椭圆曲线 $y^2=x^3-x$ 上有理点 $(1,0)$ 的非自由秩 1 可逆理想 | `GF/Scalar/Determinant/LivingLawRootGeneratedScalarNontrivialPicardLineRegression.lean` (`rationalPointPic_not_free`, `rationalPicClass_ne_one`, `rationalPicLine_settles_projectiveNonfree`) | §3.2 命题 3.2；例 1.1(c) |
| **R7** | 点观察塔与自由模 $\mathbb{Z}[S]$ 双侧同构及二元运算三项增量展开 | `GF/Probability/Source/Full/Word.lean` (`equivalence`, `word_action`); `GF/Probability/Source/Full/Binary.lean` (`binary_mixed_update`, `pushJoint`) | §5.1 命题 5.1(1) |
| **R8** | 集合映射诱导自由线性映射、交错差导子复合律与等变判据 | `GF/Probability/Source/Full/Map.lean` (`map_comp`); `GF/Probability/Source/Full/Defect.lean` (`defect_comp`, `defect_zero_iff`) | §5.1 命题 5.1(2) |
| **R9** | 同根评价投影、单基自由读回与不同评价器分离反例 | `SM/LivingLawRootGeneratedCofinalHistorySettlementFaceKernel.lean`; `SM/LivingLawRootGeneratedCofinalFaithfulSettlementFaceKernel.lean`; `GF/LivingLawRootGeneratedCofinalDualityTransportKernel.lean` | §2.2, §5.2 |
| **R10** | 关系子模生成两项上链复形（$d^2=0$）与关系商零元刻画 | `GF/Cofinal/LivingLawRootGeneratedCofinalRelationComplexKernel.lean` (`completion_zero_iff_generated_boundary`, `ofHistoryCommonLaw`) | §2.2 命题 2.2(2) |
| **R11** | 全素数幂乘积拉回一致拓扑不可分核判据 $\bigcap_{p,n}p^{n+1}L$ | `GF/Cofinal/Topology/LivingLawRootGeneratedCofinalAllPrimeTopologyKernel.lean` (`allPrimeKernel_iff`, `source_inseparable_zero_iff_kernel`) | §2.3 命题 2.3(1) |
| **R12** | 单一观察族核内非零元由联合核商 $C/(\ker f\cap\ker g)$ 唯一恢复 | `SM/DomainConsumers/CanonicalArithmetic/Relation/NativeReceiptJointConsumerCoimage.lean` (`joint_kernel_exact`, `jointToIntegral_unique`, `original_class_joint_nonzero`) | §2.3 命题 2.3(2)；§9.5 |
| **R13** | 分级关系商上的移位输运与截断尾子模早阶生成元非零残差 | `PG/JointRelation/ClozelPairedOmegaJointRelationShiftAction.lean`; `PG/JointRelation/ClozelPairedOmegaJointRelationNativeNextTransition.lean`; `PG/JointRelation/ClozelPairedOmegaJointRelationNativeNextReverseReadback.lean` | §2.2 命题 2.2(2) |
| **R14** | 共尾展开四面关联及自由词求值跨关系商下降充要条件 | `GF/Occurrence/Realization/Raw/CofinalAction.lean`; `GF/Occurrence/Realization/Raw/CofinalActionCochain.lean` (`generated_differential_descent_iff`); `GF/Occurrence/Realization/Raw/CofinalActionFullFourFace.lean` | §2.3 命题 2.3(3) |
| **R15** | 交换环乘积配对核等于像湮灭子；约化环上配对核等于求值核 | `GF/Occurrence/Realization/Raw/CofinalActionValuePairing.lean` (`valuePairing_fibre_iff_annihilator`, `valuePairingRangeRecovery_actual`) | §2.3 命题 2.3(3) |
| **R16–R17** | 乘积配对跨关系商下降判据与约化环上生成子模线性恢复 | `GF/Occurrence/Realization/Raw/CofinalActionValuePairingDescent.lean` (`valuePairing_descent_iff_annihilator`, `valuePairing_descent_iff_evaluator_descent`); `GF/Occurrence/Realization/Raw/CofinalActionValueScalarCoimage.lean` (`valueWordCoimageRecovery`) | §2.3 命题 2.3(3) |
| **R18–R19** | 表达式替换关系迁移与无代表元商核同构恢复 | `GF/Operations/Native/Substitution/Source.lean`; `GF/Operations/Runtime/Fibre/Recovery.lean` (`residualEquiv`, `recover_injective`, `recover_balanced`) | §5.2 命题 5.2(3), 5.3(1) |
| **R20–R23** | 归纳树无求值语法解析左逆（$\kappa\equiv 0$ 单射）与替换步长归纳 | `GF/Operations/Native/Tree/Fold/Inverse.lean` (`read_program`, `program_injective`); `GF/Operations/Execution/Substitution/Source.lean` | §5.2 命题 5.2(1), 5.2(3) |
| **R24–R27** | 环模不可观最大不变子模、零核词同构与纤维约束双残差判据 | `GF/Operations/Observed/Words/Kernel.lean` (`common_invariant_is_retained`); `GF/Operations/Observed/Words/Model.lean`; `GF/Operations/Native/Tree/Fold/Dependent/Joint/TargetDifference.lean` (`fibre_preimage_exact`) | §5.2 命题 5.3(2)–(3) |
| **R28–R42, R45** | 有限词族对偶、线性差分、零求值商同余与同根拼接保持 | `GF/Operations/Inquiry/Context/Faces/Execution/Activation/Receipt/Inventory/Born/Vector/Fibre/Source.lean`; `GF/Operations/Native/CompleteWordDual.lean`; `GF/Operations/Inquiry/Cofinal/Native/Installed/Cofinal/Action/Common/RootConsumer/Semantics.lean`; `W/Reentry/Splice.lean` | §5.2 命题 5.3(2), 注记 5.1 |
| **R43** | 自由常量表的正合合冲呈示 $\operatorname{im}(\mathrm{rel}_G)=\ker(\mathrm{freeEval})$ 与证书分解 | `W/ConstantTransport.lean` (`constant_update`, `computed_after`); `W/ConstantInverse.lean` (`actualCertificate`, `restored_next_constants`); `GF/Scalar/Relations/FiniteTableCertificate.lean` (`finiteTableCertificate_read`, `relationRange_eq_kernel`)，补证纪元 `339ab2a4c2` | §6.1 命题 6.1；例 6.1 |
| **R44** | 奇异有限 Hermitian Gram 解陪集与正交投影合成 | `GF/Scalar/Feature/FiniteGram.lean` (`full_fibre`, `source_effect_of_equation`); `GF/Scalar/Feature/FiniteGram/Projection.lean` (`kernel_synthesis`, `predictable_readback`, `innovationCLM`) | §7.1 命题 7.1(1)–(2) |
| **R46** | 分离探针族奇异 Gram 投影沿前缀与有限子集有向网强收敛 | `GF/Scalar/Feature/FiniteGram/PrefixReadback.lean` (`inverse_tendsto`); `GF/Scalar/Feature/FiniteGram/DirectedReadback.lean` (`inverse_tendsto_finset`) | §7.1 命题 7.1(3)；§9.4 |
| **R47** | 交换环 Schur 镶边逆更新及尾线性无关族首非零枢轴解码 | `GF/Scalar/Feature/FiniteGram/MatrixBorder.lean` (`border_det`, `borderInverse`); `GF/Scalar/Feature/FiniteGram/CofinalInsertion.lean` (`decode_insert_exact`); `GF/Scalar/Feature/FiniteGram/CofinalRecord.lean` (`pivotTime`, `schedule_read_insert`) | §7.2 命题 7.2 |
| **R48** | 正交投影与正交余项双分量分解同下游演化交换 | `PG/Feedback/ClozelOriginalKFiniteOrderRelease/GammaSource/PositionGap/FullStock.lean` (`actual_stock_source_step`); `PG/Feedback/ClozelOriginalKFiniteOrderRelease/GammaSource/PositionGap/RelationInventory.lean` | §7.1 命题 7.1(2) |
| **R49** | 任意域与有限候选集上未知 $k$-稀疏有号源由 $2k$ 矩最大非奇异首块定阶与恢复 | `GF/Scalar/Feature/FiniteGram/SparseMoment.lean` (`hankel_factor`, `order_from_source`, `recover_support`, `recover_prefix`) | §6.2 定理 6.2；例 1.1(d), 6.2；图 3 |
| **R50** | 奇异探针下 Hilbert 流像充要判据与剩余能量恒等式 $\|x_\star-x_n\|^2=E_\infty-E_n$ | `GF/Scalar/Feature/FiniteGram/PrefixImage.lean` (`admitted_iff_image`, `realize_captured`); `GF/Scalar/Feature/FiniteGram/PrefixImage/PrefixEnergy.lean` (`error_squared`, `first_within`, `output_bound`) | §8.1 定理 8.1；例 1.1(e)；图 4 |
| **R51** | 有界算子伴随拉回 $A^*v_i$ 作用流像判据与核陪集 $x_\star+\ker A$ | `GF/Scalar/Feature/FiniteGram/PrefixImage/ActionImage.lean` (`admitted_iff_action_image`, `forward_equation`, `complete_fibre`, `inverse_capture`) | §8.2 推论 8.3 |
| **R52** | 复 Banach 代数线性 Cayley 幂增长下 $A-1$ 的显式双边逆与可达范数界 | `GF/Operations/Observed/Operator/CayleyEffectInverse.lean` (`inverse`, `inverse_effect`, `inverse_norm`); `GF/Operations/Observed/Operator/CayleyEffectInverse/Sharpness.lean` (`jordan_cayley_power_norm`, `jordan_inverse_attains`)，补证纪元 `ce917c1cf9` | §8.3 定理 8.4(1)；例 1.1(e)；图 4 |
| **R53** | 全阶商与全素数完备化上的同态、分裂左逆与双线性提升 | `GF/Cofinal/Topology/Successor.lean`; `GF/Cofinal/Topology/SplitAction.lean`; `GF/Cofinal/Topology/Bilinear/Completion.lean` | §2.4 引理 2.4 |
| **R54** | Kummer 余核挠塔在三层前提下的极限结论（满射／有界挠单射正合／同构） | `GF/Cofinal/Topology/CokernelTorsion/{CoherentLift,CoherentKernel,CoherentEquivalence}.lean` (`cokernel_connecting_limit_surjective`, `ambient_to_cokernel_limit_injective_of_bounded`, `cokernel_connecting_limit_kernel_of_bounded`, `cokernelCompletionEquiv`) | §2.4 定理 2.5；附录 A.1 |
| **R55** | 分裂路径复形的直和分解与延拓态射链同伦等价 | `GF/Operations/Execution/Relations/History/Payment/{Closure,Completion}.lean`; `GF/Cofinal/Topology/Operations/Closure/Continuation/Cochain/Derived.lean` (`continuation_derived_zero`) | §2.4 引理 2.6(1) |
| **R56** | 素数幂满射上链塔逆极限到映射余锥同伦极限的拟同构 | `GF/Cofinal/Topology/Cochain/{DerivedLimit,DerivedNaturality}.lean` (`cochain_derived_limit_quasiIso`); `GF/Cofinal/Topology/Operations/Closure/Continuation/Cochain/Cohomology.lean` (`paidObservedCohomologyIso`) | §2.4 引理 2.6(1)–(2) |
| **R57** | 全素数完备化与阶乘完备化的中国剩余定理同构 | `GF/Cofinal/Topology/FiniteModulus/{Factorization,Completion}.lean`; `GF/Cofinal/Topology/FiniteModulus/Factorial/Equivalence.lean` (`factorialCompletionEquiv`); `GF/Cofinal/Topology/FiniteModulus/Factorial/Cochain/Homology.lean` | §2.5 定理 2.7(1) |
| **R58** | 阶乘模 $(n+1)!$ 半开平衡代表元最终稳定与非整类晚阶共尾全模跳跃判准 | `GF/Cofinal/Topology/FiniteModulus/Factorial/Integral/{Bounded,Representative,EffectJump}.lean` (`factorial_integral_source_iff`, `factorial_small_effect_recovers_source`, `factorial_nonintegral_effect_jumps`) | §2.5 定理 2.7(2)；例 1.1(b)；图 2 |
| **R59** | 线性无关族追加列时的对偶基单秩更新与投影系数回读 | `GF/Scalar/Feature/FiniteGram/Projection/DualColumn/Insert.lean` (`dualColumn_snoc_last`, `dualColumn_snoc_castSucc`, `coefficients_snoc_read`) | §7.2 命题 7.3；例 7.1 |
| **R60** | 加性算子上下文诱导两项路径复形链态射与边界增量保持 | `GF/Operations/Execution/Relations/History/Payment/LinearCochain.lean` (`linearCochain`, `linear_differential`, `linear_boundary_effect`) | §5.2 命题 5.2(2) |
| **R61** | Cayley 差分逆 $m$ 步截断残差、等距源范数控制与步数无关含噪误差预算 | `GF/Operations/Observed/Operator/CayleyEffectInverse/{Finite,FiniteGrowth}.lean` (`source_norm_le_effect`, `finite_error`, `finite_tendsto`, `finite_growth_error`, `finite_noisy_error`, `linear_retention_tendsto`) | §8.3 定理 8.4(2)–(3)；例 8.1 |
| **R62** | 完备闭子空间投影探针受限奇异 Gram 恢复与细化强收敛 | `GF/Scalar/Feature/FiniteGram/PrefixImage/ContactFibre.lean` (`recover_equation`, `recover_energy`, `recover_error_le`, `recover_refined_tendsto`) | §8.2 命题 8.2；§9.4 |

### B.2 五组无基底行列式与极限复形接口对照表（均已归入 `H0mework`）

| 接口名称 | `Homework` 源路径 | `H0mework` 公开导出路径 | 正文命题与功能 |
| --- | --- | --- | --- |
| 接口 I：双格对偶行列式 | `SM/LivingLawRootGeneratedDualLatticeDeterminantKernel.lean` | `Lean/H0mework/Realization/Determinant/DualLattice.lean` | 命题 4.1；双格非退化配对外幂与整基符号控制 |
| 接口 II：有限余核 Smith 指数 | `SM/LivingLawRootGeneratedFiniteDefectDeterminantKernel.lean` | `Lean/H0mework/Foundation/Relations/FiniteDefectDeterminant.lean` | 命题 4.2；等秩格 $|\det f|=\#\operatorname{coker} f$ 与基数平衡 |
| 接口 III：短正合列粘合与输运 | `SM/LivingLawRootGeneratedExactDeterminantGluingKernel.lean` | `Lean/H0mework/Realization/Determinant/ExactGluing.lean` | 命题 4.3；两端基粘合与零余核无基底外幂同构 |
| 接口 IV：四项自由复形整线 | `SM/LivingLawRootGeneratedPerfectComplexDeterminantProjectionKernel.lean` | `Lean/H0mework/Realization/Determinant/FourTermProjection.lean` | 命题 4.4；交错顶外幂整线、$\{\pm 1\}$-扭子与逐项同构输运 |
| 接口 V：范畴逆极限映射锥 | `SM/LivingLawRootGeneratedDependentDerivedGlobalStateKernel.lean` | `Lean/H0mework/Realization/GlobalSections/DerivedState.lean` | 命题 4.5；复形图逆极限投影与可缩映射锥同伦等价 |

### B.3 核心定理的 Lean 4 声明类型签名摘录

以下列出代表性核心声明的 Lean 4 类型，补写文件内隐含参数（分别来自 `Exact.lean`、`SparseMoment.lean`、`PrefixImage.lean`、`CayleyEffectInverse.lean` 与 `EffectJump.lean`）：

```lean
def equiv (R : Type r) [CommRing R] (A : Type u) [AddCommGroup A] [Module R A] :
    A ≃ₗ[R] Carrier R A

theorem order_from_source {I K : Type*} [Field K] (clock : I → K)
    (distinct : Function.Injective clock) (source : I →₀ K) {bound : Nat}
    (within : source.support.card ≤ bound) :
    order (measure clock source bound) = source.support.card

theorem admitted_iff_image {H : Type*} [NormedAddCommGroup H]
    [InnerProductSpace ℂ H] [CompleteSpace H] (source : Nat → H) (data : Nat → ℂ) :
    ((∀ n, residual source data n = 0) ∧ BddAbove (range (energy source data))) ↔
      ∃ x : H, read source x = data

theorem inverse_effect {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [CompleteSpace A]
    (action : A) {d budget : ℝ} (positive : 0 < d)
    (growth : ∀ n : Nat, ‖(cayley action d)^n‖ ≤ ((n : ℝ)+1)*budget) :
    inverse action d * (action-1) = 1 ∧ (action-1) * inverse action d = 1

theorem factorial_small_effect_recovers_source {L E : Type*} [AddCommGroup L]
    [NormedAddCommGroup E] [NormedSpace ℝ E] (coordinate : L ≃ₗ[ℤ] ℤ)
    (effect : L →ₗ[ℤ] E) (live : effect (coordinate.symm 1) ≠ 0)
    (value : FactorialCompletion (L := L)) :
    (∃! source : L, factorialCanonicalMap source = value) ↔
      ∃ base : Nat, ∀ stage ≥ base,
        ‖effect (factorialBalancedLift coordinate value (stage+1)) -
          effect (factorialBalancedLift coordinate value stage)‖ <
          (factorialModulus stage : ℝ)*‖effect (coordinate.symm 1)‖
```

---

## 附录 C　带号 Hankel 行列式展开与有限截断误差说明

<a id="app-c-1"></a>

**注记 C.1（首 Hankel 行列式的 Cauchy–Binet 展开与定阶机制）。** 对任意域 $K$ 上的分解 $H_w = V_w \operatorname{diag}(a|_S) V_w^{\mathsf T}$（其中 $V_w\in K^{w\times r}$，$|S|=r$），应用 Cauchy–Binet 公式立即得到
$$\det H_w = \sum_{T\subseteq S,\;|T|=w}\Bigl(\prod_{s\in T} a(s)\Bigr)\bigl(\det V_{w,T}\bigr)^2,\tag{C.1}$$
其中 $V_{w,T}\in K^{w\times w}$ 为取自子集 $T$ 的方阵 Vandermonde 块。式 (C.1) 同时解释三种现象：(1) 当 $w>r$ 时求和指标集为空，$\det H_w=0$；(2) 当 $K=\mathbb{R}$ 且所有 $a(s)>0$ 时，对每个 $w\le r$，各项均为严格正实数故无法抵消，$\det H_w>0$；(3) 当 $a(s)$ 带正负号或 $\operatorname{char}(K)>0$ 时，$w<r$ 处的多项求和可能发生相消而使 $\det H_w=0$，唯独在 $w=r$ 处求和退化为单一非零项 $T=S$，故 $\det H_r = (\prod_{s\in S} a(s))(\det V_r)^2 \neq 0$ 在任意域上恒成立。

<a id="app-c-2"></a>

**注记 C.2（步数无关的噪声放大上界 $M_{\delta,B}$）。** 对每个 $m$，有 $\|F_{\delta,m}(A)\|\le\delta q\sum_{k=0}^{m-1}B(k+1)q^k\le M_{\delta,B}$。例 8.1 的实际放大因子随 $m$ 趋于 $M_{1,1}=2$，在 $m=1$ 时为 $1/2$。

---

## 附录 D　核心术语与符号双语对照表

| 中文术语 | English Term | 数学记号／定义 |
| --- | --- | --- |
| 特征标双对偶像 | Character bidual image | $P_{\chi,R}(A):=\operatorname{im}(\mathrm{ev}_{R,A})\le\operatorname{Hom}_{\mathbb{Z}}(A^\vee_\chi,\mathbb{Q}/\mathbb{Z})$ |
| 观察四支见证分类 | Four-way observation disposition | 双射等价／纯核损失／纯覆盖不足／双重损失（`settle`） |
| 全素数一致不可分核 | All-prime uniformity kernel | $\ker\pi_{\mathrm{all}}=\bigcap_{p,n}p^{n+1}L$ |
| Kummer 余核挠塔极限 | Kummer cokernel-torsion limit | $T_p(C)=\varprojlim_j (M/\operatorname{im}\iota)[p^{j+1}]$ |
| 阶乘模平衡代表元 | Factorial balanced representative | $b_n(v)\in L$，$-\lfloor M_n/2\rfloor\le\phi(b_n(v))<M_n-\lfloor M_n/2\rfloor$ |
| 四项复形交错整行列式线 | Alternating integral determinant line | $\det_{\mathbb{Z}}(C^\bullet)=(\det C_0\otimes\det C_1^\vee)\otimes\det C_2\otimes\det C_3^\vee$ |
| 交错差算子 | Intertwining defect operator | $\Delta f=B_{\sigma_Y}\circ\mathrm{map}(f)-\mathrm{map}(f)\circ A_{\sigma_X}$ |
| 环模不可观不变子模 | Unobservable invariant submodule | $\ker\mathcal{I}=\{c\in C:\forall w\in I^*,\,e(A_w c)=0\}\le\ker e$ |
| 带号求值 Gram / 首 Hankel 块 | Signed evaluation Gram / Hankel block | $H_w = V_w\operatorname{diag}(a|_S)V_w^{\mathsf T}$，$r=\max\{w\le k:\det H_w\neq 0\}$ |
| Hilbert 读数流像条件 | Stream preimage conditions | $\forall n,\,r_n(d)=0\ \wedge\ \sup_n E_n(d)<\infty$ |
| 线性增长 Cayley 阻尼逆 | Linear-growth damped Cayley inverse | $\mathcal{I}_\delta(A)=-\delta q\sum_{n\ge 0}q^n(1+\delta A)^n$，$M_{\delta,B}=\frac{1+\delta}{\delta}B$ |

---

<!-- code-availability:begin -->
## 代码与数据可得性

证明使用 Lean 4 `v4.33.0` 与 `mathlib` 提交 `db584cd6d46c92f209a44c0f1c829460d327499d`。[固定仓库](https://github.com/Sapientropic/H0mework/tree/ccf469d177d0cff2cefbb162b4f5ab7891a83b25) 给出 R1–R62 和五组接口的全部证明、直接消费者及原回执。原路径和公开 owner 见[逐项对应表](https://github.com/Sapientropic/H0mework/blob/ccf469d177d0cff2cefbb162b4f5ab7891a83b25/docs/exact-realization-map.json)。在仓库根目录运行 `lake -d Lean build ExactRealization`。源码恢复和完整验收命令见[复现指南](https://github.com/Sapientropic/H0mework/blob/ccf469d177d0cff2cefbb162b4f5ab7891a83b25/docs/exact-realization-reproduction.md)。

随稿运行 `python3 validation/verify_manuscript.py --math-only` 可复算阶乘代表元、有限域矩和 Jordan 块算例。
<!-- code-availability:end -->

## 参考文献

[Gao2026OneBitV2] 高健（Jian Gao）. *现实刚性与单母源普遍形成：无账外差异的零公理构造、因果准入与统一演化*（*Ontological Rigidity and Universal Single-Mother Formation*）. 第二版（v2），Zenodo，2026. DOI: [10.5281/zenodo.24135399](https://doi.org/10.5281/zenodo.24135399).

[Gao2026SourceProcessCoreV3] 高健（Jian Gao）. *源生过程代数与初始余面修订：四层同一性、正合求值核与可逆增量续行*（*Source-Native Process Algebra and Initial-Coface Revision*）. 第三版（v3），Zenodo，2026. DOI: [10.5281/zenodo.24147130](https://doi.org/10.5281/zenodo.24147130).

[Gao2026WholeLedgerV2] 高健（Jian Gao）. *溯源守恒演算与非免费连续性：全事件账本、观察安全与良基结清*（*Provenance-Preserving Conservation Calculus and Non-Free Continuity*）. 第二版（v2），Zenodo，2026. DOI: [10.5281/zenodo.24147183](https://doi.org/10.5281/zenodo.24147183).

[Pontryagin1934] Pontrjagin, L. The Theory of Topological Commutative Groups. *Annals of Mathematics*, Series 2, **35**(2) (1934), 361–388. DOI: [10.2307/1968438](https://doi.org/10.2307/1968438).

[Baer1940] Baer, R. Abelian Groups That Are Direct Summands of Every Containing Abelian Group. *Bulletin of the American Mathematical Society*, **46**(10) (1940), 800–806. DOI: [10.1090/S0002-9904-1940-07306-9](https://doi.org/10.1090/S0002-9904-1940-07306-9).

[Lambek1964] Lambek, J. A Module Is Flat If and Only If Its Character Module Is Injective. *Canadian Mathematical Bulletin*, **7**(2) (1964), 237–243. DOI: [10.4153/CMB-1964-021-9](https://doi.org/10.4153/CMB-1964-021-9).

[Stacks01D6] The Stacks Project Authors. *The Stacks Project, Tag 01D6: Injective Abelian Groups*. URL: [https://stacks.math.columbia.edu/tag/01D6](https://stacks.math.columbia.edu/tag/01D6).

[Milnor1962] Milnor, J. W. On Axiomatic Homology Theory. *Pacific Journal of Mathematics*, **12**(1) (1962), 337–341. DOI: [10.2140/pjm.1962.12.337](https://doi.org/10.2140/pjm.1962.12.337).

[Weibel1994] Weibel, C. A. *An Introduction to Homological Algebra*. Cambridge Studies in Advanced Mathematics, Vol. **38**, Cambridge University Press (1994). DOI: [10.1017/CBO9781139644136](https://doi.org/10.1017/CBO9781139644136).

[Jannsen1988] Jannsen, U. Continuous Étale Cohomology. *Mathematische Annalen*, **280**(2) (1988), 207–245. DOI: [10.1007/BF01456052](https://doi.org/10.1007/BF01456052).

[KnudsenMumford1976] Knudsen, F. F., and Mumford, D. The Projectivity of the Moduli Space of Stable Curves. I: Preliminaries on “det” and “Div”. *Mathematica Scandinavica*, **39**(1) (1976), 19–55. DOI: [10.7146/math.scand.a-11642](https://doi.org/10.7146/math.scand.a-11642).

[Deligne1987] Deligne, P. Le déterminant de la cohomologie. In *Current Trends in Arithmetical Algebraic Geometry*, Contemporary Mathematics **67**, American Mathematical Society (1987), 93–177. DOI: [10.1090/conm/067/902592](https://doi.org/10.1090/conm/067/902592).

[Stacks0FJ9] The Stacks Project Authors. *The Stacks Project, Tag 0FJ9: Determinants*. URL: [https://stacks.math.columbia.edu/tag/0FJ9](https://stacks.math.columbia.edu/tag/0FJ9).

[Tate1966] Tate, J. On the Conjectures of Birch and Swinnerton-Dyer and a Geometric Analog. *Séminaire Bourbaki*, Vol. **9**, Exposé 306 (1966), 415–440. NUMDAM: [https://www.numdam.org/item/SB_1964-1966__9__415_0/](https://www.numdam.org/item/SB_1964-1966__9__415_0/).

[Nekovar2006] Nekovář, J. *Selmer Complexes*. *Astérisque* **310**, Société Mathématique de France (2006), viii+559 pp. NUMDAM: [https://www.numdam.org/issues/AST_2006__310__R1_0/](https://www.numdam.org/issues/AST_2006__310__R1_0/).

[MaciasCastilloSano2026] Macias Castillo, D., and Sano, T. On Selmer Complexes, Stark Systems and Derived $p$-adic Heights. arXiv:[2603.23978](https://arxiv.org/abs/2603.23978) (2026).

[Stacks00CX] The Stacks Project Authors. *The Stacks Project, Tag 00CX: Tensor Products*. URL: [https://stacks.math.columbia.edu/tag/00CX](https://stacks.math.columbia.edu/tag/00CX).

[Green2007Provenance] Green, T. J., Karvounarakis, G., and Tannen, V. Provenance Semirings. In *Proceedings of the 26th ACM SIGMOD-SIGACT-SIGART Symposium on Principles of Database Systems (PODS ’07)*, ACM (2007), 31–40. DOI: [10.1145/1265530.1265535](https://doi.org/10.1145/1265530.1265535).

[Cai2014Changes] Cai, Y., Giarrusso, P. G., Rendel, T., and Ostermann, K. A Theory of Changes for Higher-Order Languages: Incrementalizing $\lambda$-Calculi by Static Differentiation. In *Proceedings of the 35th ACM SIGPLAN Conference on Programming Language Design and Implementation (PLDI ’14)*, ACM (2014), 145–155. DOI: [10.1145/2594291.2594304](https://doi.org/10.1145/2594291.2594304).

[Budiu2023DBSP] Budiu, M., Chajed, T., McSherry, F., Ryzhyk, L., and Tannen, V. DBSP: Automatic Incremental View Maintenance for Rich Query Languages. *Proceedings of the VLDB Endowment*, **16**(7) (2023), 1601–1614. DOI: [10.14778/3587136.3587137](https://doi.org/10.14778/3587136.3587137).

[Ellerman2014Accounting] Ellerman, D. P. On Double-Entry Bookkeeping: The Mathematical Treatment. *Accounting Education*, **23**(5) (2014), 483–501. DOI: [10.1080/09639284.2014.949803](https://doi.org/10.1080/09639284.2014.949803).

[Kalman1963] Kálmán, R. E. Mathematical Description of Linear Dynamical Systems. *Journal of the Society for Industrial and Applied Mathematics, Series A: Control*, **1**(2) (1963), 152–192. DOI: [10.1137/0301010](https://doi.org/10.1137/0301010).

[Prony1795] de Prony, G. Essai expérimental et analytique sur les lois de la dilatabilité de fluides élastiques et sur celles de la force expansive de la vapeur de l’eau et de la vapeur de l’alkool, à différentes températures. *Journal de l’École Polytechnique*, **1**(2) (1795), 24–76.

[Kronecker1881] Kronecker, L. Zur Theorie der Elimination einer Variabeln aus zwei algebraischen Gleichungen. *Monatsberichte der Königlich Preussischen Akademie der Wissenschaften zu Berlin* (1881), 535–600.

[BenOrTiwari1988] Ben-Or, M., and Tiwari, P. A Deterministic Algorithm for Sparse Multivariate Polynomial Interpolation. In *Proceedings of the 20th Annual ACM Symposium on Theory of Computing (STOC ’88)*, ACM (1988), 301–309. DOI: [10.1145/62212.62241](https://doi.org/10.1145/62212.62241).

[PeterPlonka2013] Peter, T., and Plonka, G. A Generalized Prony Method for Reconstruction of Sparse Sums of Eigenfunctions of Linear Operators. *Inverse Problems*, **29**(2) (2013), 025001. DOI: [10.1088/0266-5611/29/2/025001](https://doi.org/10.1088/0266-5611/29/2/025001).

[CandesFernandezGranda2014] Candès, E. J., and Fernandez-Granda, C. Towards a Mathematical Theory of Super-Resolution. *Communications on Pure and Applied Mathematics*, **67**(6) (2014), 906–956. DOI: [10.1002/cpa.21455](https://doi.org/10.1002/cpa.21455).

[Schur1917] Schur, I. Über Potenzreihen, die im Innern des Einheitskreises beschränkt sind. *Journal für die reine und angewandte Mathematik*, **147** (1917), 205–232. DOI: [10.1515/crll.1917.147.205](https://doi.org/10.1515/crll.1917.147.205).

[Penrose1955] Penrose, R. A Generalized Inverse for Matrices. *Mathematical Proceedings of the Cambridge Philosophical Society*, **51**(3) (1955), 406–413. DOI: [10.1017/S0305004100030401](https://doi.org/10.1017/S0305004100030401).

[Riesz1910] Riesz, F. Untersuchungen über Systeme integrierbarer Funktionen. *Mathematische Annalen*, **69**(4) (1910), 449–497. DOI: [10.1007/BF01457637](https://doi.org/10.1007/BF01457637).

[Aronszajn1950] Aronszajn, N. Theory of Reproducing Kernels. *Transactions of the American Mathematical Society*, **68**(3) (1950), 337–404. DOI: [10.1090/S0002-9947-1950-0051437-7](https://doi.org/10.1090/S0002-9947-1950-0051437-7).

[Douglas1966] Douglas, R. G. On Majorization, Factorization, and Range Inclusion of Operators on Hilbert Space. *Proceedings of the American Mathematical Society*, **17**(2) (1966), 413–415. DOI: [10.1090/S0002-9939-1966-0203464-1](https://doi.org/10.1090/S0002-9939-1966-0203464-1).

[AdcockHansen2016] Adcock, B., and Hansen, A. C. Generalized Sampling and Infinite-Dimensional Compressed Sensing. *Foundations of Computational Mathematics*, **16**(5) (2016), 1263–1323. DOI: [10.1007/s10208-015-9276-6](https://doi.org/10.1007/s10208-015-9276-6).

[vonNeumann1930] von Neumann, J. Allgemeine Eigenwerttheorie Hermitescher Funktionaloperatoren. *Mathematische Annalen*, **102** (1930), 49–131. DOI: [10.1007/BF01782338](https://doi.org/10.1007/BF01782338).

[Kreiss1962] Kreiss, H.-O. Über die Stabilitätsdefinition für Differenzengleichungen die partielle Differentialgleichungen approximieren. *BIT Numerical Mathematics*, **2**(3) (1962), 153–181. DOI: [10.1007/BF01957330](https://doi.org/10.1007/BF01957330).

[KatznelsonTzafriri1986] Katznelson, Y., and Tzafriri, L. On Power Bounded Operators. *Journal of Functional Analysis*, **68**(3) (1986), 313–328. DOI: [10.1016/0022-1236(86)90101-1](https://doi.org/10.1016/0022-1236(86)90101-1).

[deMouraUllrich2021Lean4] de Moura, L., and Ullrich, S. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, LNCS **12699**, Springer (2021), 625–635. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[mathlib2020] The mathlib Community. The Lean Mathematical Library. In *Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)*, ACM (2020), 367–381. DOI: [10.1145/3372885.3373824](https://doi.org/10.1145/3372885.3373824).

[AngdinataXu2023] Angdinata, D. K., and Xu, J. An Elementary Formal Proof of the Group Law on Weierstrass Elliptic Curves in Any Characteristic. In *14th International Conference on Interactive Theorem Proving (ITP 2023)*, LIPIcs **268**, Schloss Dagstuhl – Leibniz-Zentrum für Informatik (2023), 6:1–6:19. DOI: [10.4230/LIPIcs.ITP.2023.6](https://doi.org/10.4230/LIPIcs.ITP.2023.6).

[BuzzardCommelinMassot2020] Buzzard, K., Commelin, J., and Massot, P. Formalising Perfectoid Spaces. In *Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)*, ACM (2020), 299–312. DOI: [10.1145/3372885.3373830](https://doi.org/10.1145/3372885.3373830).

[CommelinTopaz2024] Commelin, J., and Topaz, A. Abstraction Boundaries and Spec Driven Development in Pure Mathematics. *Bulletin of the American Mathematical Society*, **61**(2) (2024), 241–255. DOI: [10.1090/bull/1831](https://doi.org/10.1090/bull/1831).
