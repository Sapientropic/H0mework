# Faithful Representations and Exact Inversion from Quotients, Moments, and Streams

**Author: Jian Gao**\
Independent Researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**Formal verification note.** The results draw on formal declarations in Lean 4 (`v4.33.0`) and `mathlib` [@deMouraUllrich2021Lean4; @mathlib2020]. Appendix B identifies their pinned sources, public availability, and representative types. The text gives mathematical proofs and worked examples.

## Abstract

We prove four recovery results. For an injection of abelian groups, the Kummer map from the cokernel’s $p$-power torsion limit to the source’s $p$-adic completion is surjective if the ambient group is $p$-divisible and an isomorphism if it is uniquely $p$-divisible. Bounded source $p$-power torsion makes the ambient torsion limit inject into the cokernel torsion limit with image the kernel of the Kummer map. In rank-one factorial completion, integer classes are exactly those with eventually constant balanced representatives.

Over any field, $2k$ power moments recover a source with at most $k$ active weights on a known finite set of distinct addresses. The largest nonsingular leading Hankel block gives the support size even when smaller blocks cancel. In a complex Hilbert space with possibly dependent probes, a stream has a preimage exactly when every prefix fits and the minimum squared norms are bounded. Squared reconstruction error equals the limiting energy minus the prefix energy. In a complex Banach algebra, $\|(1+\delta A)^n\|\le(n+1)B$ for $\delta>0$ gives an absolutely convergent inverse series for $A-1$. The sharp inverse bound $(1+\delta)B/\delta$ controls noise at every truncation order.

**Keywords:** character bidual image; Kummer cokernel torsion; factorial balanced representative; basis-free determinant interface; signed sparse Hankel recovery; Hilbert stream preimages; linear-growth Cayley inverse

---

<a id="sec-1"></a>

## 1 Introduction: Problem Setting, Main Results, and Unifying Thread

### 1.1 Four Structural Observation Distortions and Problem Setting

Recovering a source object from partial readouts, finite quotients, or streaming truncations encounters four recurrent structural obstructions across algebra and analysis. First is **torsion annihilation**: observing a module with torsion through integer, real, or complex linear functionals maps every finite-order element to zero — on $A=\mathbb{Z}/2\mathbb{Z}$, every $\ell\in\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Z})$ satisfies $2\ell(x)=\ell(2x)=0$ and hence $\ell\equiv 0$. Second is **local freeness without a global basis**: on the coordinate ring of the affine elliptic curve $y^2=x^3-x$, the maximal ideal attached to the rational point $(1,0)$ is finitely generated and projective of constant rank $1$ yet admits no global free basis, invalidating determinant formalisms that assume pre-chosen global coordinates. Third is **lower-order cancellation under unknown sparsity**: when power moments $M_j=\sum_{s\in S} a_s \tau(s)^j$ carry signed weights or lie in a field of positive characteristic, leading Hankel minors $H_w$ of order $w<r=|S|$ can vanish by cancellation even when $r\le k$ is nonzero, requiring an order-determination rule that does not assume sequential nonsingularity of leading minors. Fourth is **infinite-dimensional energy divergence and non-contractive operator truncation**: in a Hilbert space, a stream compatible with every finite prefix (zero prefix residual) may still fail to admit an $\ell^2$ preimage when minimal-norm energies diverge; in a complete complex Banach algebra, when the shifted element $C_\delta(A)=1+\delta A$ obeys linear power growth $\|(1+\delta A)^n\|\le(n+1)B$, the spectral inclusion $\sigma(A)\subseteq\overline{D}(-1/\delta,1/\delta)$ already implies $1\notin\sigma(A)$ and hence invertibility of $A-1$, yet obtaining an explicit series without spectral decomposition, the reachable norm constant $(1+\delta)B/\delta$, and truncation error bounds whose noise factor does not grow with the truncation order $m$ requires damped recentering.

This paper addresses all four problems without assuming finite generation, torsion-freeness, global free bases, positive weights, or norm contractivity: the reconstruction and approximation results (§2.1, §2.5, §6, §7–§8) provide explicit formulas and quantitative identities, while the general module-observation and stalk-rank classifiers (§2.2 Proposition 2.2(3), §3.1 Proposition 3.1) operate under classical logic while retaining explicit kernel, cokernel, or prime-ideal witnesses.

<a id="sec-1-2"></a>

### 1.2 Five Pen-and-Paper Verification Anchors

The five elementary examples below can each be checked in a few lines and illustrate the main mechanisms and counterexample boundaries of the paper.

<a id="ex-1-1"></a>

**Example 1.1 (Five pen-and-paper anchors).**

**(a) Character bidual image separating 2-torsion (§2.1).**
Take $x=(0,1)$ in $A=(\mathbb{Z}/2\mathbb{Z})\times(\mathbb{Z}/2\mathbb{Z})$. Every $\ell\in\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Z})$ satisfies $\ell(x)=0$ since $2x=(0,0)$. Using the additive character $\chi\in\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Q}/\mathbb{Z})$ given by $\chi(a,b)=b/2\bmod\mathbb{Z}$, double evaluation gives $\mathrm{ev}(x)(\chi)=\chi(0,1)=1/2+\mathbb{Z}\neq 0$, embedding $x$ injectively into the image $P_{\chi,\mathbb{Z}}(A)$.

**(b) Eventual stabilization versus modulus jumps of factorial balanced representatives (§2.5).**
In the factorial completion $\widehat{\mathbb{Z}}_{!}=\varprojlim_n \mathbb{Z}/(n+1)!\mathbb{Z}$ of $L=\mathbb{Z}$, let $b_n$ denote the unique representative in $[-\lfloor (n+1)!/2\rfloor,\,(n+1)!-\lfloor (n+1)!/2\rfloor)$. For the integer $s=-2\in\mathbb{Z}$, the representatives modulo $(n+1)!\in\{1,2,6,24,120\}$ are $0,0,-2,-2,-2$, with normalized jumps $|b_{n+1}(-2)-b_n(-2)|/(n+1)!$ equal to $0,1,0,0$ and vanishing identically for $n\ge 2$. By contrast, for the 2-adic idempotent $e_2\in\widehat{\mathbb{Z}}$ ($e_2\equiv 1\pmod{2^{v_2((n+1)!)}}$ and $0$ modulo odd prime powers), the Chinese remainder theorem yields
$$b_0(e_2)=0,\quad b_1(e_2)=-1,\quad b_2(e_2)=-3,\quad b_3(e_2)=9,\quad b_4(e_2)=-15.\tag{1.1}$$
The first four differences $|b_{n+1}(e_2)-b_n(e_2)|$ are $1,2,12,24$, each a nonzero multiple of $(n+1)!$. An integer representing $e_2$ would be divisible by every power of $3$, hence zero, contradicting its $2$-adic coordinate $1$. By Theorem 2.7, jumps of size at least $(n+1)!$ recur beyond every stage, although individual jumps vanish, for example at $n=27,29$.

**(c) Nonfree rank-one invertible ideal on $y^2=x^3-x$ (§3.2).**
In the coordinate ring $R_E=\mathbb{Q}[x,y]/(y^2-x^3+x)$ of the smooth affine curve, the rational point $P=(1,0)$ gives the maximal ideal $L_P=(x-1,y)$. The identities $y^2=(x-1)x(x+1)$ and $\gcd(x-1,x(x+1))=1$ give $L_P^2=(x-1)R_E$, so $L_P$ is invertible with fractional inverse $(x-1)^{-1}L_P$. If $L_P=(g)$ with $g=a(x)+b(x)y$, then $g^2=u(x-1)$ for a unit $u\in R_E^\times$. The norm $N(g)=g(x,y)g(x,-y)$ is multiplicative with values in $\mathbb{Q}[x]$, so $N(u)\in\mathbb{Q}[x]^\times=\mathbb{Q}^\times$. Hence $N(g)^2=N(u)(x-1)^2$ gives $N(g)=c(x-1)$ with $c\in\mathbb{Q}^\times$. Yet $N(g)=a(x)^2-b(x)^2(x^3-x)$ has even degree if $b=0$. If $b\ne 0$, the second term has degree at least $3$ and the two nonzero leading terms have opposite parity, so they cannot cancel. Thus $N(g)$ cannot have degree $1$.

**(d) Signed sparse Hankel order determination under lower-order cancellation (§6.2).**
Let $k=3$, candidate set $A=\{1,-1,2\}\subset\mathbb{Q}$, and true source $a=(1,-1,0)$ supported on $\{1,-1\}$ ($r=2$). The first $2k=6$ moments $M_j=\sum a_i \tau_i^j$ are $(0,2,0,2,0,2)$, giving leading Hankel blocks
$$H_1=[0]\;(\det H_1=0),\qquad H_2=\begin{pmatrix}0&2\\2&0\end{pmatrix}\;(\det H_2=-4\neq 0),\qquad H_3=\begin{pmatrix}0&2&0\\2&0&2\\0&2&0\end{pmatrix}\;(\det H_3=0).\tag{1.2}$$
Although $H_1$ vanishes by signed cancellation, the largest nonsingular leading block $H_2$ identifies $r=2$. Solving $c=-H_2^{-1}(0,2)^{\mathsf T}=(-1,0)^{\mathsf T}$ gives $P(t)=t^2-1$, whose root set in $A$ is $\{1,-1\}$, and Vandermonde inversion $\bigl(\begin{smallmatrix}1&1\\1&-1\end{smallmatrix}\bigr)^{-1}\binom{0}{2}=\binom{1}{-1}$ recovers the weights.

**(e) Three Hilbert stream regimes and reachable Jordan-block norm constant (§§8.1, 8.3).**
On $H=\ell^2(\mathbb{N}_{\ge 1},\mathbb{C})$ with standard basis probes $u_i=e_i$ (indexing the first $n$ terms by $1\le i\le n$, matching $0$-based prefixes in (8.1)):

1. For $d_i=1/i$, every prefix has $r_n=0$, $E_n=\sum_{i=1}^n i^{-2}\uparrow E_\infty=\pi^2/6$, and $\|x_\star-x_n\|^2=E_\infty-E_n=\sum_{i=n+1}^\infty i^{-2}$;
2. For $d_i=i^{-1/2}$, every finite prefix still satisfies $r_n=0$, yet $E_n=\sum_{i=1}^n i^{-1}\to\infty$, so no $\ell^2$ preimage exists;
3. For dependent probes $u_1=e_1, u_2=e_1$ and inconsistent data $d=(1,2,0,\dots)$, the stream is bounded but rejected at $n=2$ since $r_2\neq 0$.

Use the induced operator norm on $(\mathbb{C}^2,\|\cdot\|_1)$. For any $\delta>0$, set $J=\bigl(\begin{smallmatrix}0&1\\0&0\end{smallmatrix}\bigr)$ and $A_\delta=J/\delta$. Since $J^2=0$, $(I+\delta A_\delta)^n=I+nJ$ has norm $n+1$, so $B=1$. Also $(A_\delta-I)^{-1}=-(I+J/\delta)$, giving
$$\|\mathcal{I}_\delta(A_\delta)\|_1=1+\frac{1}{\delta}=\frac{1+\delta}{\delta}B.\tag{1.3}$$
Thus the uniform bound in Theorem 8.4(1) is attained for every $\delta>0$.

<a id="sec-1-3"></a>

### 1.3 Summary of Core Theorems and Falsifying Controls

To separate foundational algebraic interfaces from the main substantive results, we state five core theorems in the body and grade foundational equivalences, basis-free interfaces, and direct consequences as propositions, lemmas, and corollaries (architecture in Figure 1; paired positive and negative controls in Table 1).

<a id="thm-1-1"></a>

**Theorem 1.1 (Summary of core results).**

1. **Limits of Kummer cokernel-torsion towers (Theorem 2.5, R54).** For an injective homomorphism $\iota:L\to_{\mathbb{Z}}M$ with cokernel $C=M/\operatorname{im}\iota$ and prime $p$, $p$-divisibility of $M$ makes the connecting map $\delta_\infty:T_p(C)\to\widehat{L}_p$ surjective. Bounded $p$-power torsion of $L$ makes $\alpha_\infty:T_p(M)\to T_p(C)$ injective with $\operatorname{im}\alpha_\infty=\ker\delta_\infty$. If $M$ is uniquely $p$-divisible, $\delta_\infty$ is an isomorphism.
2. **Factorial completion and the integral descent criterion (Theorem 2.7, R57–R58).** There is an isomorphism $\prod_p\widehat{L}_p\simeq_{\mathbb{Z}}\widehat{L}_{!}=\varprojlim_n L/(n+1)!L$. When $L\cong\mathbb{Z}$, a coherent element $v\in\widehat{L}_{!}$ comes from a unique $s\in L$ exactly when its balanced representatives $b_n(v)$ eventually stabilize. Equivalently, for a nondegenerate normed linear readout $E_{\mathrm{eff}}$, the late adjacent jumps are strictly smaller than $(n+1)!\|u\|$.
3. **Unknown-sparsity signed moment recovery over arbitrary fields (Theorem 6.2; R49)**: Over any field $K$ with injective $\tau:I\to K$ and $a\in K^{(I)}$ supported inside a given finite set $A\subseteq I$ with $r:=|\operatorname{supp}(a)|\le k$, the leading Hankel blocks of the first $2k$ moments satisfy the signed evaluation Gram factorization $H_w=V_w\operatorname{diag}(a|_S)V_w^{\mathsf T}$, lock true sparsity via $r=\max\{w\le k:\det H_w\neq 0\}$, and recover $S$ and $a|_S$ from the roots of the $H_r^{-1}$ monic polynomial in $A$ and $V_r^{-1}$.
4. **Hilbert stream and operator preimages under singular probes (Theorem 8.1, Corollary 8.3; R50–R51)**: For any countable (possibly linearly dependent) family $\{u_i\}_{i\in\mathbb{N}}$ in a complex Hilbert space $H$ and $d:\mathbb{N}\to\mathbb{C}$, an element $x\in H$ satisfies $\langle u_i,x\rangle_H=d_i$ ($\forall i$) if and only if every prefix residual vanishes ($r_n(d)=0$) and minimal-norm energies satisfy $\sup_n E_n(d)<\infty$, in which case prefix projections converge strongly to the minimal-norm solution $x_\star$ with $\|x_\star-x_n(d)\|_H^2=E_\infty-E_n(d)$. For $A\in\mathcal{B}(H,F)$ and separating probes $\{v_i\}\subset F$, adjoint pullback $A^*v_i$ characterizes stream preimages and yields the coset $x_\star+\ker A$.
5. **Explicit Banach inverse and step-independent truncation bound under linear Cayley growth (Theorem 8.4; R52, R61)**: In a complete complex Banach algebra, if $\|(1+\delta A)^n\|\le(n+1)B$ ($\delta>0$) and $q=(1+\delta)^{-1}$, the absolutely convergent series $\mathcal{I}_\delta(A)=-\delta q\sum_{n=0}^\infty q^n(1+\delta A)^n$ equals $(A-1)^{-1}$ with reachable bound $\|(A-1)^{-1}\|\le M_{\delta,B}=\frac{1+\delta}{\delta}B$; on a complex Banach space, $m$-step truncations satisfy $\|F_{\delta,m}(A)\|\le M_{\delta,B}$ independently of $m$ and $\|F_{\delta,m}(A)\tilde y-(A-1)^{-1}y\|\le M_{\delta,B}\|y-\tilde y\|+B(m+1)q^m M_{\delta,B}\|y\|$.

![Figure 1 | Proof structure of faithful representations and exact inversion](figures/fig1-architecture-en.svg)

**Figure 1 | Proof structure of faithful representations and exact inversion.** Coimage factorization links the four parts. The bottom panel lists applications to torsion classes and pulse moments, closed operator graphs and resolvents, and lattice pairings and integral determinant lines.

**Table 1. Core positive results paired with counterexamples and boundary controls**

| Pillar & topic | Core positive result | Paired counterexample / boundary control | Location |
| --- | --- | --- | --- |
| **I. Characters & factorial jumps** | $A\simeq_R P_{\chi,R}(A)$ (R1); three-tier Kummer limits (R54); $(n+1)!$ balanced-lift criterion (R58) | $\operatorname{Hom}_{\mathbb{Z}}(-,\mathbb{Z})\equiv 0$ on $(\mathbb{Z}/2\mathbb{Z})^2$; $1\in\mathbb{Q}$ inseparable in all-prime topology (R11); $e_2$ has zero jumps at $n=27,29$ yet jumps cofinally (R58) | §§2.1–2.5; Ex. 1.1(a)–(b); Thms 2.5, 2.7 |
| **I. Pairings & dispositions** | 4-way witness disposition (R4); reduced-ring pairing kernel equals evaluation kernel (R15) | Nilpotent $2\neq 0$ in $\mathbb{Z}/4\mathbb{Z}$ annihilates all product pairings (R15); single-family blind kernel element (R12) | §§2.2–2.3; Props 2.2–2.3 |
| **II. Picard & det interfaces** | Constant-rank exterior torsors (R5) and five basis-free determinant interfaces (§4) | Nonfree ideal $(1,0)$ on $y^2=x^3-x$ (R6); nonprojective $\mathbb{Z}/2\mathbb{Z}$ over $\mathbb{Z}/4\mathbb{Z}$; rank-varying product ring; $-\mathrm{id}$ sign $-1$ | §§3–4; Props 3.1–3.2, 4.1–4.5; Ex. 1.1(c), 4.1 |
| **III. Syntax & syzygies** | Evaluation-free syntactic left inverse (R20); constructive constant-table syzygy presentation (R43) | Zero folding $\kappa\equiv 0$ collapses values yet preserves syntax tree; zero-net table decomposed via syzygy certificate | §5.2, §6.1; Props 5.2, 6.1; Ex. 6.1 |
| **III. Sparse Hankel** | Max nonsingular leading block order & $2k$-moment recovery over any field $K$ and finite set $A$ (R49) | Weights $(1,-1)$ over $\mathbb{Q}$ and $(3,4)$ over $\mathbb{F}_7$ (cancelling mod $7$) both make $H_1=[0]$ singular while $H_2$ locks $r=2$ | §6.2; Ex. 1.1(d), 6.2; Thm 6.2 |
| **IV. Singular & incremental Gram** | Singular Gram coset & strong limit (R44, R46); first-pivot selection (R47) & rank-one dual update (R59) | Dependent or zero probes yield $\ker G\neq 0$; minimal-norm solution lies in $(\ker G)^\perp$ while full solution set is a coset | §§7.1–7.2; Props 7.1–7.3; Ex. 7.1 |
| **IV. Hilbert streams** | Prefix zero residual $\wedge$ bounded energy characterizes stream image (R50, R51); projected subspace limit (R62) | Zero-residual stream $d_i=i^{-1/2}$ diverges in energy; bounded inconsistent dependent data fails at $r_2\neq 0$ | §§8.1–8.2; Ex. 1.1(e); Thm 8.1, Cor. 8.3 |
| **IV. Cayley inverse** | Explicit inverse, reachable constant & uniform truncation bound under $\|(1+\delta A)^n\|\le(n+1)B$ (R52, R61) | For every $\delta>0$, the scaled Jordan block $A_\delta$ has $\|C_\delta(A_\delta)^n\|_1=n+1$ and attains $\|(A_\delta-I)^{-1}\|_1=1+1/\delta$ with $B=1$ | §8.3; Ex. 1.1(e), 8.1; Thm 8.4 |

<a id="sec-1-4"></a>

### 1.4 Reading Routes by Discipline

After browsing Example 1.1 and Theorem 1.1, readers may follow self-contained routes by specialty:

- **Commutative and homological algebra**: Read **§§2.1–2.5 and Appendix A**, focusing on the three-tier Kummer cokernel-torsion theorem (Theorem 2.5), surjective cochain homotopy-limit quasi-isomorphism (Lemma 2.6), and the factorial balanced-representative jump criterion (Theorem 2.7).
- **Algebraic geometry and formal interface design**: Read **§§3–4 and §9.2** for the elementary and `mathlib`-based proofs of the nonfree ideal at $(1,0)$ on $y^2=x^3-x$ (Proposition 3.2) and the five basis-deferred determinant and limit-cone interfaces (Propositions 4.1–4.5).
- **Symbolic computation, control theory, and discrete inverse problems**: Read **§§5–6 and Appendix C.1** for the module-theoretic unobservable invariant submodule (Proposition 5.3(2)), constant-table syzygy presentation (Proposition 6.1), and arbitrary-field unknown-sparsity Hankel recovery (Theorem 6.2).
- **Functional analysis and operator inverse problems**: Read **§§7–8, §9.4, and Appendix C.2** for finite-dimensional singular Gram components (§7), singular-probe Hilbert stream preimages and energy gaps (Theorem 8.1), and explicit Banach inverses under linear Cayley growth (Theorem 8.4).

<a id="sec-1-5"></a>

### 1.5 Unifying Thread, Literature Coordinates, and Notation

**Unifying thread and the evaluation-Gram bridge.** All four parts address four progressive questions about a linear observation map $e:X\to Y$: (i) **Kernel and coimage**: when is $\ker e=0$, and how do quotients $X/\ker e$ and inverse limits preserve faithful coordinates when $\ker e\neq 0$ (§2); (ii) **Carrier invariants**: on bijective finitely generated projective branches, when do basis-free top exterior lines exist and where do nontrivial Picard classes obstruct global bases (§3–§4); (iii) **Signed discrete recovery**: when additive evaluations cancel, how do syzygy coordinates retain cancelling entries and how do evaluation bilinear forms recover sparse sources (§5–§6); (iv) **Infinite-dimensional streams and operator inverses**: when do countable inner-product streams or non-contractive operator differences admit preimages and explicit-constant approximations (§7–§8). Crucially, Pillars III and IV are linked by a single matrix object: the Hankel block factorization in Theorem 6.2,
$$H_w = V_w\,\operatorname{diag}(a|_S)\,V_w^{\mathsf T},$$
is the **signed (or field-valued) evaluation Gram matrix** of the monomial functionals $1,t,\dots,t^{w-1}$ against the weighted discrete measure $\sum_{s\in S} a_s\delta_{\tau(s)}$. Over $\mathbb{R}$ with positive weights $a_s>0$, $H_w$ reduces to the positive-semidefinite Gram matrices of §§7–8 and remains nonsingular for all $w\le r$; with signed weights or in positive characteristic, cancellation can make blocks $w<r$ singular, whereas at $w=r$ the square factor $V_r$ forces $\det H_r\neq 0$ (Remark C.1).

**Literature coordinates.** Section 9 positions our results against 41 verified primary sources across five axes: (1) character duality (Pontryagin [@Pontryagin1934], Baer [@Baer1940], Lambek [@Lambek1964], Stacks `01D6` [@Stacks01D6]) and inverse-limit homology (Milnor [@Milnor1962], Weibel [@Weibel1994], Jannsen [@Jannsen1988]); (2) determinant functors and arithmetic complexes (Knudsen–Mumford [@KnudsenMumford1976], Deligne [@Deligne1987], Stacks `0FJ9` [@Stacks0FJ9], Tate [@Tate1966], Nekovář [@Nekovar2006], Macias Castillo–Sano [@MaciasCastilloSano2026]); (3) tensor products, incremental differentiation, difference groups, and unobservable subspaces (Stacks `00CX` [@Stacks00CX], Green et al. [@Green2007Provenance], Cai et al. [@Cai2014Changes], DBSP [@Budiu2023DBSP], Ellerman [@Ellerman2014Accounting], Kálmán [@Kalman1963]) alongside Prony–Hankel sparse recovery (Prony [@Prony1795], Kronecker [@Kronecker1881], Ben-Or–Tiwari [@BenOrTiwari1988], Peter–Plonka [@PeterPlonka2013], Candès–Fernandez-Granda [@CandesFernandezGranda2014]); (4) generalized inverses, moment problems, and operator ranges/growth bounds (Schur [@Schur1917], Penrose [@Penrose1955], F. Riesz [@Riesz1910], Aronszajn [@Aronszajn1950], Douglas [@Douglas1966], Adcock–Hansen [@AdcockHansen2016], von Neumann [@vonNeumann1930], Kreiss [@Kreiss1962], Katznelson–Tzafriri [@KatznelsonTzafriri1986]); and (5) Lean 4 formalization (de Moura–Ullrich [@deMouraUllrich2021Lean4], mathlib [@mathlib2020], Angdinata–Xu [@AngdinataXu2023], Buzzard–Commelin–Massot [@BuzzardCommelinMassot2020], Commelin–Topaz [@CommelinTopaz2024], and upstream companion foundations [@Gao2026OneBitV2; @Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2]).

**Notation.** Throughout, $\mathbb{N}=\{0,1,2,\dots\}$ and $R$ denotes a commutative ring with unity. For a set $I$ and module $M$, $M^{(I)}$ (written $\mathbb{Z}[I]$ when $M=\mathbb{Z}$) denotes finitely supported functions with point basis elements $\delta_i$ or $[i]$. For an abelian group $L$, $\widehat{L}_{\mathrm{all}}:=\prod_{p\in\mathbb{P}}\widehat{L}_p$. Complex Hilbert inner products $\langle u,v\rangle_H$ are conjugate-linear in the first slot and linear in the second; $P_S$ denotes orthogonal projection onto a closed subspace $S\le H$. A finite family $u:\iota\to H$ defines synthesis $\Phi_u(a):=\sum_{i\in\iota} a_i u_i$, readout $\mathrm{rhs}_u(x):=(\langle u_i,x\rangle_H)_{i\in\iota}$, and Gram matrix $(G_u)_{ij}=\langle u_i,u_j\rangle_H$.

---

## Part I: Module Character Bidual Images, Observation Dispositions, and Cofinal Topological Descent

<a id="sec-2"></a>

## 2 Character Representations of Arbitrary Modules, Dispositions, and Kummer–Factorial Completions

Mapping an $R$-module $A$ into its naive linear bidual $\operatorname{Hom}_R(\operatorname{Hom}_R(A,R),R)$ fails to be injective whenever torsion is killed by $R$-valued functionals. We first establish a faithful representation onto the evaluation image inside the $\mathbb{Q}/\mathbb{Z}$-character bidual without finiteness or torsion-freeness hypotheses, summarize kernel-quotient limits and four-way dispositions, and then prove the three-tier Kummer cokernel-torsion theorem and the factorial balanced-representative descent criterion.

### 2.1 Character Bidual Image Isomorphism (R1)

<a id="def-2-1"></a>

**Definition 2.1 ($\mathbb{Q}/\mathbb{Z}$-character bidual and evaluation image).** For a commutative ring $R$ and an $R$-module $A$, let $A^\vee_{\chi}:=\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Q}/\mathbb{Z})$ and equip $A^{\vee\vee}_{\chi}:=\operatorname{Hom}_{\mathbb{Z}}(A^\vee_{\chi},\mathbb{Q}/\mathbb{Z})$ with the $R$-action $(r\cdot \Lambda)(\chi):=\Lambda(a\mapsto \chi(r\cdot a))$. Define double evaluation
$$\mathrm{ev}_{R,A}:A\longrightarrow A^{\vee\vee}_{\chi},\qquad \mathrm{ev}_{R,A}(a)(\chi):=\chi(a),\tag{2.1}$$
its image $P_{\chi,R}(A):=\operatorname{im}(\mathrm{ev}_{R,A})\le A^{\vee\vee}_{\chi}$, and the corestriction $\eta_{R,A}:A\to P_{\chi,R}(A)$.

<a id="prop-2-1"></a>

**Proposition 2.1 (R1: Character bidual image isomorphism and functoriality).** For every commutative ring $R$ and every $R$-module $A$:

1. $\mathrm{ev}_{R,A}$ is injective and $R$-linear, so $\eta_{R,A}$ defines an $R$-linear isomorphism $\mathrm{equiv}_{R,A}:A\xrightarrow{\sim} P_{\chi,R}(A)$ (consequently every $R$-linear map $g:A\to B$ factors uniquely through $\eta_{R,A}$ as $\tilde g=g\circ\mathrm{equiv}_{R,A}^{-1}$);
2. For every $R$-linear map $f:A\to B$, the bidual map $f^{\vee\vee}(\Lambda):=\Lambda\circ f^\vee$ carries $P_{\chi,R}(A)$ into $P_{\chi,R}(B)$, defining a covariant functor $P_{\chi,R}:\mathrm{Mod}_R\to\mathrm{Mod}_R$ satisfying $P_{\chi,R}(f)\circ\eta_{R,A}=\eta_{R,B}\circ f$.

**Proof.** Linearity follows from $\mathrm{ev}_{R,A}(r\cdot a)(\chi)=\chi(r\cdot a)=(r\cdot \mathrm{ev}_{R,A}(a))(\chi)$. For $a\in A\setminus\{0\}$, define $h:\mathbb{Z}a\to\mathbb{Q}/\mathbb{Z}$ on the cyclic subgroup $\mathbb{Z}a\le A$ by sending $a$ to $\frac12+\mathbb{Z}$ if $a$ has infinite order and to $\frac1m+\mathbb{Z}$ if $a$ has finite order $m\ge 2$. Since $\mathbb{Q}/\mathbb{Z}$ is divisible, Baer’s injectivity criterion [@Baer1940; @Stacks01D6] extends $h$ to $\chi\in A^\vee_{\chi}$ with $\chi(a)\neq 0$, proving $\ker(\mathrm{ev}_{R,A})=0$ and that $\eta_{R,A}$ is an isomorphism. For $f:A\to B$, $(f^{\vee\vee}(\mathrm{ev}_{R,A}(a)))(\psi)=\psi(f(a))=\mathrm{ev}_{R,B}(f(a))(\psi)$ gives image preservation and naturality. $\square$

<a id="rem-2-1"></a>

**Remark 2.1 (Evaluation-image boundary and integer-functional blindness).** Proposition 2.1 restricts the isomorphism to the evaluation image $P_{\chi,R}(A)$ and never claims surjectivity onto $A^{\vee\vee}_\chi$: even for $A=\mathbb{Z}$, the algebraic character bidual $\mathbb{Z}^{\vee\vee}_\chi\cong\widehat{\mathbb{Z}}$ strictly contains $\mathbb{Z}$. Conversely, under integer functionals $\operatorname{Hom}_{\mathbb{Z}}(A,\mathbb{Z})$ (Figure 2, top left), $(0,1)\in(\mathbb{Z}/2\mathbb{Z})^2$ is annihilated by every readout yet remains nonzero in $P_{\chi,\mathbb{Z}}(A)$.

![Figure 2 | Torsion separation, factorial completion and integral descent, and a nonfree Picard line](figures/fig2-torsion-picard-en.svg)

**Figure 2 | Torsion separation, factorial completion and integral descent, and a nonfree Picard line.** The upper left separates $(0,1)$ by a character and compares the normalized factorial jumps of $e_2$ and the integer $-2$. The upper right classifies readouts by injectivity and surjectivity and gives examples of projectivity, local rank, and a nonfree Picard line. The lower panel passes from finite Chinese remainder isomorphisms to completion, then shows the result for $H^1$ of split path complexes and the rank-one integral descent criterion (Theorem 2.7).

### 2.2 Kernel-Quotient Inverse Limits, Two-Term Relation Complexes, and Four-Way Dispositions (R2–R4, R9–R10, R13)

When an observation map $e$ is not injective, the proposition below summarizes single-step and inverse-system coimages, two-term relation complexes, and the witness-bearing four-way disposition.

<a id="prop-2-2"></a>

**Proposition 2.2 (R2–R4, R9–R10, R13: Kernel-quotient limits, relation quotients, and four-way observation classification).**

1. **Relative coimages and coherent stage towers (R2–R3)**: For an abelian-group homomorphism $e:C\to\operatorname{Hom}_{\mathbb{Z}}(D,\mathbb{Z})$, the coimage $C/\ker e$ embeds injectively into the codomain, and a linear map $f:C\to Q$ factors uniquely through $C/\ker e$ if and only if $\ker e\le\ker f$. Over any commutative ring $R$, given $R$-linear stage evaluations $e_n:G\to C_n$ with $t_n\circ e_{n+1}=e_n$, the inclusions $\ker e_{n+1}\le\ker e_n$ define a surjective quotient tower $G/\ker e_{n+1}\twoheadrightarrow G/\ker e_n$ with inverse limit $K_\infty:=\varprojlim_n(G/\ker e_n)$; for any $R$-linear evaluation $e_\infty:K_\infty\to\operatorname{Hom}_R(D,R)$, $K_\infty/\ker e_\infty\xrightarrow{\sim}\operatorname{im}(e_\infty)$, with $[x]\mapsto e_\infty(x)$. Let $C_\infty=\varprojlim_n C_n$ and let $j:K_\infty\hookrightarrow C_\infty$ be induced by the stage embeddings $[g]\mapsto e_n(g)$. Then
   $$C_\infty/j(K_\infty)\hookrightarrow\varprojlim_n\bigl(C_n/\operatorname{im}(e_n)\bigr),\qquad [(c_n)_n]\longmapsto ([c_n])_n.$$
   A map to another coherent tower with $s_n e_n=e'_n a$ and $t'_n s_{n+1}=s_n t_n$ induces compatible stage coimage maps $[g]\mapsto[a(g)]$.
2. **Two-term relation complexes and truncated tail residuals (R9–R10, R13)**: For a free $\mathbb{Z}$-module $G_{\mathrm{cl}}$ and relation submodule $R_{\mathrm{cl}}\le G_{\mathrm{cl}}$, the inclusion $d:R_{\mathrm{cl}}\hookrightarrow G_{\mathrm{cl}}$ in degrees $0,1$ satisfies $d^2=0$, with degree-$1$ cohomology equal to the relation quotient $Q_{\mathrm{rel}}:=G_{\mathrm{cl}}/R_{\mathrm{cl}}$ ($[w]=0\iff w\in\operatorname{im}(d)$). Shift endomorphisms preserving $R_{\mathrm{cl}}$ descend to $Q_{\mathrm{rel}}$. In the consecutive histories of R13, the later generator closure $G_{m+1}$ is supported in stages $\ge m+1$. The phase generator $\delta_{(m,\mathrm{phase})}$ belongs to $G_m$ and has nonzero class in the ambient free module modulo $G_{m+1}$, giving the witness `GeneratorResidual`.
3. **Four-way witness classification (R4)**: For any $R$-linear map $o:P\to O$, the classical classifier `settle(o)` partitions $o$ into four mutually exclusive cases: (a) **bijective equivalence** ($P\simeq_R O$, iff $o$ is bijective); (b) **pure kernel loss** ($o$ surjective, non-injective, supplying $k\in\ker o\setminus\{0\}$); (c) **pure coverage deficit** ($o$ injective, non-surjective, supplying $y\in O\setminus\operatorname{im} o$ with nonzero cokernel class); and (d) **double loss** (neither injective nor surjective, retaining both $k\neq 0$ and $y\notin\operatorname{im} o$).

**Proof.** (1) The first isomorphism theorem gives both coimage isomorphisms. If all the cokernel classes of a coherent family $(c_n)_n$ vanish, each $c_n$ has a unique preimage in $G/\ker e_n$. Compatibility of the transitions makes these preimages an element of $K_\infty$, so $j(K_\infty)$ is the kernel of the map to the cokernel limit. Finally, $s_n e_n=e'_n a$ gives $a(\ker e_n)\subseteq\ker e'_n$. (2) A two-term complex has $d^2=0$ for degree reasons, and the $(m,\mathrm{phase})$ coordinate vanishes on $G_{m+1}$ and takes value $1$ on the earlier phase generator. (3) By classical case analysis on `Injective o` and `Surjective o`, extracting $k=x_1-x_2\neq 0$ when non-injective, $y\in O\setminus\operatorname{im} o$ when non-surjective, and `LinearEquiv.ofBijective` when bijective. $\square$

### 2.3 All-Prime Uniformity, Joint Coimages, and Reduced-Ring Pairings (R11–R12, R14–R17)

<a id="prop-2-3"></a>

**Proposition 2.3 (R11–R12, R14–R17: All-prime uniformity kernel, joint coimages, and product-pairing fibres).**

1. **All-prime-power uniformity kernel (R11)**: Equipping an abelian group $L$ with the uniform structure pulled back along $\pi_{\mathrm{st}}:L\to\prod_{p,n} L/p^{n+1}L$ from discrete quotients, an element $x\in L$ is topologically inseparable from $0$ if and only if
   $$\forall p\in\mathbb{P},\;\forall n\in\mathbb{N},\;\exists y\in L,\quad p^{n+1}y=x\quad \bigl(\text{i.e., }x\in\ker\pi_{\mathrm{all}}=\bigcap_{p,n}p^{n+1}L\bigr),\tag{2.2}$$
   so $L/\ker\pi_{\mathrm{all}}$ embeds injectively into $\widehat{L}_{\mathrm{all}}$ ($1$ and $0$ are separated in $\mathbb{Z}$ but inseparable in $\mathbb{Q}$).
2. **Joint-coimage recovery of blind-spot elements (R12)**: Given group homomorphisms $f:C\to F$ and $g:C\to G_1$ with $c\in\ker f\setminus\{0\}$ satisfying $g(c)\neq 0$, $g$ cannot factor through $C/\ker f$; for $j=(f,g)$, $\ker j=\ker f\cap\ker g\le\ker g$, so $g$ factors uniquely through $C/\ker j$ with $[c]\neq 0$, while $C/\ker j\twoheadrightarrow C/\ker f$ is non-injective.
3. **Commutative-ring product pairings and reduced-ring recovery (R14–R17)**: For a commutative ring $V$ and evaluation $\mathrm{ev}:\mathbb{Z}^{(G)}\to V$, set $B(w_1,w_2):=\mathrm{ev}(w_1)\mathrm{ev}(w_2)$. In general, $B(w_1,\cdot)=B(w_2,\cdot)\iff \mathrm{ev}(w_1)-\mathrm{ev}(w_2)\in\operatorname{Ann}_V(\operatorname{im}\mathrm{ev})$ (e.g., $2\in\mathbb{Z}/4\mathbb{Z}$ gives $B\equiv 0$ since $2\cdot 2=0$). For a relation submodule $R_{\mathrm{cl}}$, the pairing descends through the relation quotient in both variables if and only if $\mathrm{ev}(R_{\mathrm{cl}})\subseteq\operatorname{Ann}_V(\operatorname{im}\mathrm{ev})$. When $V$ is **reduced**, $\ker B=\ker\mathrm{ev}$ without assuming $1\in\operatorname{im}\mathrm{ev}$. Thus the curried pairing image is isomorphic to $\operatorname{im}(\mathrm{ev})$, the descent condition is $\mathrm{ev}(R_{\mathrm{cl}})=0$, and the $V$-linear extension recovers the generated $V$-submodule.

**Proof.** (1) Products of discrete groups are Hausdorff, so inseparability from $0$ in the pullback topology is equivalent to $\pi_{\mathrm{st}}(x)=0$. (2) If $g=\bar g\circ\pi_f$, then $g(c)=\bar g(0)=0$, a contradiction; Proposition 2.2(1) gives unique factorization through $C/\ker j$. (3) By bilinearity and symmetry the pairing descends exactly when $B(R_{\mathrm{cl}},\cdot)=0$, which is the annihilator condition. In a reduced ring, $\mathrm{ev}(w)\in\operatorname{Ann}_V(\operatorname{im}\mathrm{ev})$ implies $\mathrm{ev}(w)^2=0$ and hence $\mathrm{ev}(w)=0$, so curried $B$ shares the kernel of $\mathrm{ev}$. $\square$

### 2.4 Cofinal Topological Lifts, Kummer Cokernel-Torsion Towers, and Cochain Homotopy Limits (R53–R56)

Because $\varprojlim$ is not right exact, unbounded $p^\infty$-torsion can obstruct exactness in the limit (cf. Jannsen [@Jannsen1988]). After recording functorial lifts on $\widehat{L}_{\mathrm{all}}$, we prove the three-tier Kummer cokernel-torsion theorem and the surjective cochain-tower quasi-isomorphism lemma.

<a id="lem-2-4"></a>

**Lemma 2.4 (R53: Cofinal topological successors, split retractions, and bilinear completion lifts).** For any abelian-group homomorphism $A:L\to_{\mathbb{Z}} M$: (1) $A$ is uniformly continuous on $\prod_{p,j}L/p^{j+1}L$ and induces $\widehat{A}_{\mathrm{all}}:\widehat{L}_{\mathrm{all}}\to\widehat{M}_{\mathrm{all}}$ and coimage maps, with equal target product images of $x,y\in L$ exactly when $A(x-y)\in\bigcap_{p,j}p^{j+1}M$; (2) any left inverse $B\circ A=\mathrm{id}_L$ or direct-sum splitting $A\circ B+\iota\circ C=\mathrm{id}_M$ lifts compatibly to $\widehat{L}_{\mathrm{all}}$ and coimages; (3) any bilinear map $\beta:L\times M\to N$ descends modulo $p^{j+1}$ and induces $\widehat{\beta}:\widehat{L}_{\mathrm{all}}\times\widehat{M}_{\mathrm{all}}\to\widehat{N}_{\mathrm{all}}$.

**Proof.** Since $A(p^{j+1}L)\subseteq p^{j+1}M$ and $\beta(p^{j+1}L,M)+\beta(L,p^{j+1}M)\subseteq p^{j+1}N$, all identities hold at each finite quotient stage and pass to the inverse limit. $\square$

<a id="thm-2-5"></a>

**Theorem 2.5 (R54: Limit properties of Kummer cokernel-torsion towers under three tier hypotheses).** Let $\iota:L\to_{\mathbb{Z}} M$ be an injective abelian-group homomorphism with cokernel $C:=M/\operatorname{im}(\iota)$, and fix a prime $p$. Write $\widehat{L}_p:=\varprojlim_j L/p^{j+1}L$ and $T_p(C):=\varprojlim_j C[p^{j+1}]$ (with multiplication-by-$p$ transitions). The snake-lemma connecting maps $\delta_j:C[p^{j+1}]\to L/p^{j+1}L$ sending $[m]$ to $[x]$ with $\iota(x)=p^{j+1}m$ assemble into $\delta_\infty:T_p(C)\to\widehat{L}_p$ alongside $\alpha_\infty:T_p(M)\to T_p(C)$. Then:

1. **Ambient $p$-divisibility implies limit surjection** (`cokernel_connecting_limit_surjective`): if multiplication by $p$ is surjective on $M$, then $\delta_\infty:T_p(C)\twoheadrightarrow\widehat{L}_p$ is surjective;
2. **Bounded source torsion implies ambient limit injection and kernel exactness** (`ambient_to_cokernel_limit_injective_of_bounded`): if there exists $d\in\mathbb{N}$ such that $\forall j,\forall y\in L[p^{j+1}],\ p^d y=0$, then $\alpha_\infty:T_p(M)\hookrightarrow T_p(C)$ is injective and $\operatorname{im}(\alpha_\infty)=\ker(\delta_\infty)$;
3. **Unique ambient $p$-divisibility implies completion isomorphism** (`cokernelCompletionEquiv`): if multiplication by $p^{j+1}$ is bijective on $M$ for every $j\in\mathbb{N}$, then $\delta_\infty$ defines a $\mathbb{Z}$-linear isomorphism
   $$\widehat{L}_p \;\simeq_{\mathbb{Z}}\; T_p\bigl(M/\operatorname{im}(\iota)\bigr).\tag{2.3}$$

**Proof.** (1) Given $v=(v_j)\in\widehat{L}_p$, put $F_j=\{z\in C[p^{j+1}]:\delta_j(z)=v_j\}$. For a representative $x_0$ of $v_0$, $p$-divisibility provides $m_0$ with $pm_0=\iota(x_0)$, so $F_0$ is nonempty. Given $[m_j]\in F_j$, let $p^{j+1}m_j=\iota(x_j)$. For a representative $x_{j+1}$ of $v_{j+1}$, write $x_{j+1}=x_j+p^{j+1}\ell$. Choose $m_{j+1}$ with $pm_{j+1}=m_j+\iota(\ell)$. Then $p^{j+2}m_{j+1}=\iota(x_{j+1})$ and $p[m_{j+1}]=[m_j]$. Iteration gives $z\in T_p(C)$ with $\delta_\infty(z)=v$.
(2) If $\alpha_\infty(u)=\alpha_\infty(u')$ for $u,u'\in T_p(M)$, then at stage $j+d$ there is $y\in L$ with $\iota(y)=u_{j+d}-u'_{j+d}\in M[p^{j+d+1}]$. Injectivity of $\iota$ forces $y\in L[p^{j+d+1}]$, so $p^d y=0$ (Lemma A.1) and
$$u_j - u'_j = p^d(u_{j+d}-u'_{j+d}) = \iota(p^d y) = 0,$$
proving injectivity of $\alpha_\infty$. For $w=(w_j)\in\ker(\delta_\infty)$, modifying stage lifts yields $m_j\in M[p^{j+1}]$ with $\pi_C(m_j)=w_j$; Lemma A.1 implies that $\tilde m_j:=p^d m_{j+d}\in M[p^{j+1}]$ satisfies $p\tilde m_{j+1}=\tilde m_j$ and $\pi_C(\tilde m_j)=w_j$, giving $w=\alpha_\infty(\tilde m)$.
(3) Bijectivity of $p^{j+1}$ on $M$ forces $M[p^{j+1}]=0$ and makes every $\delta_j$ an isomorphism commuting with transitions, yielding (2.3). $\square$

<a id="lem-2-6"></a>

**Lemma 2.6 (R55–R56: Continuation homotopy equivalence of split path complexes and surjective cochain-tower quasi-isomorphism).** For a finite directed path $\tau=(e_0\to e_1\to\dots\to e_m)$ on $\mathcal{E}$, let $R_{\mathrm{cl}}(\tau):=\operatorname{span}_{\mathbb{Z}}\{[e_i]-[e_{i+1}]:0\le i<m\}$ inside the visited-vertex module $G_{\mathrm{cl}}(\tau)\le\mathbb{Z}[\mathcal{E}]$, forming the two-term complex $C^\bullet_\tau=(0\to R_{\mathrm{cl}}(\tau)\xrightarrow{d}G_{\mathrm{cl}}(\tau)\to 0)$ with augmentation $\operatorname{aug}(\sum c_e[e]):=\sum c_e\in\mathbb{Z}$. Then:

1. **Terminal direct-sum splitting and continuation homotopy equivalence (R55)**: Every $w\in G_{\mathrm{cl}}(\tau)$ decomposes uniquely as $w=d(r_\tau(w))+(\operatorname{aug} w)[e_m]$, giving $G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau)\xrightarrow{\sim}\mathbb{Z}$; for any path continuation $\tau_{\mathrm{prior}}\prec\tau_{\mathrm{next}}$, the inclusion $C^\bullet_{\tau_{\mathrm{prior}}}\to C^\bullet_{\tau_{\mathrm{next}}}$ is a chain homotopy equivalence (its mapping cone is contractible), and because $0\to R_{\mathrm{cl}}(\tau)\to G_{\mathrm{cl}}(\tau)\to G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau)\to 0$ splits, every additive functor $F:\mathrm{Ab}\to\mathrm{Mod}_{\mathbb{Z}}$ satisfies $H^1(F(C^\bullet_\tau))\cong F(G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau))$.
2. **Surjective prime-power cochain towers (R56)**: For any integral cochain complex $K^\bullet$ and prime $p$, degreewise surjectivity of $K^q/p^{j+2}K^q\twoheadrightarrow K^q/p^{j+1}K^q$ ensures that the canonical map from $\varprojlim_j(K^\bullet/p^{j+1}K^\bullet)$ to the sequential mapping-cocone homotopy limit is a quasi-isomorphism (`cochain_derived_limit_quasiIso`).

**Proof.** (1) Telescoping $[e_k]-[e_m]=\sum_{j=k}^{m-1}([e_j]-[e_{j+1}])\in\operatorname{im}(d)$ yields $G_{\mathrm{cl}}(\tau)=\operatorname{im}(d)\oplus\mathbb{Z}[e_m]$, making $C^\bullet_\tau$ homotopy equivalent to $\mathbb{Z}$ in degree $1$; continuation identifies $[e_{m_1}]$ and $[e_{m_2}]$ modulo $\operatorname{im}(d_{\mathrm{next}})$, giving a homotopy equivalence of bounded free complexes, and additive functors preserve split short exact sequences. (2) Write $K_j^\bullet=K^\bullet/p^{j+1}K^\bullet$ with transition $t_j$, and define $\Delta((x_j))=(x_j-t_jx_{j+1})_j$ on the product complex. Its kernel is the strict inverse limit. In each degree, given $(y_j)_j$, start at $x_0=0$ and solve $t_jx_{j+1}=x_j-y_j$ recursively. Thus $\Delta$ is degreewise surjective. The resulting short exact sequence gives the quasi-isomorphism $\ker\Delta\to\operatorname{Cone}(\Delta)[-1]$ [@Milnor1962; @Weibel1994]. $\square$

### 2.5 Factorial Completion Isomorphism and Balanced-Representative Descent Criterion (R57–R58)

Replacing $\prod_{p\in\mathbb{P}}\widehat{L}_p$ by the single-parameter factorial tower $L/(n+1)!L$ allows integral descent to be tested via adjacent differences of half-open balanced representatives.

<a id="thm-2-7"></a>

**Theorem 2.7 (R57–R58: All-prime/factorial completion isomorphism and balanced-representative jump criterion).** Let $L$ be an abelian group, $M_n:=(n+1)!$, and $\widehat{L}_{!}:=\varprojlim_{n\in\mathbb{N}} L/M_n L$ with canonical map $\iota_{!}:L\to\widehat{L}_{!}$.

1. **Chinese-remainder completion isomorphism (R57)**: There is a canonical $\mathbb{Z}$-linear isomorphism $\prod_{p\in\mathbb{P}}\widehat{L}_p \simeq_{\mathbb{Z}} \widehat{L}_{!}$ (`factorialCompletionEquiv`). For the split path complex $C_\tau^\bullet$ of Lemma 2.6, put $Q_\tau=G_{\mathrm{cl}}(\tau)/R_{\mathrm{cl}}(\tau)$. The factorial cochain tower satisfies
   $$H^1\bigl(\operatorname{holim}_n(C_\tau^\bullet/M_n C_\tau^\bullet)\bigr)\cong\widehat{Q_\tau}_{!}.$$
2. **Balanced-representative stabilization and modulus-jump criterion (R58)**: Suppose $\phi:L\xrightarrow{\sim}\mathbb{Z}$, and for $v=(v_n)\in\widehat{L}_{!}$ let $b_n(v)\in L$ be the unique representative of $v_n\bmod M_n L$ satisfying
   $$-\lfloor M_n/2\rfloor \le \phi(b_n(v)) < M_n - \lfloor M_n/2\rfloor.\tag{2.4}$$
   Then:
   (a) Any stage-compatible lifts $s_n\in L$ satisfy $\phi(s_{n+1})-\phi(s_n)=(n+1)!\,k_n$ for a unique $k_n\in\mathbb{Z}$;
   (b) **Integral stabilization criterion**: $v\in\widehat{L}_{!}$ descends to a unique integral source $s\in L$ ($\iota_{!}(s)=v$) **if and only if** the balanced representatives stabilize eventually, i.e., $\exists N\in\mathbb{N},\ \forall n\ge N,\ |\phi(b_{n+1}(v))-\phi(b_n(v))| < (n+1)!$ (equivalently $b_{n+1}(v)=b_n(v)=s$); contrapositively, if $v\notin\operatorname{im}(\iota_{!})$, then for every $N\in\mathbb{N}$ there exists $n\ge N$ with $|\phi(b_{n+1}(v))-\phi(b_n(v))|\ge (n+1)!$;
   (c) **Normed linear readout consequence**: for any real normed space $E$ and $\mathbb{Z}$-linear map $E_{\mathrm{eff}}:L\to_{\mathbb{Z}} E$ with $u:=E_{\mathrm{eff}}(\phi^{-1}(1))\neq 0$, $v\in\operatorname{im}(\iota_{!})$ if and only if there exists $N\in\mathbb{N}$ such that for all $n\ge N$,
   $$\bigl\|E_{\mathrm{eff}}(b_{n+1}(v))-E_{\mathrm{eff}}(b_n(v))\bigr\| < (n+1)!\,\|u\|.\tag{2.5}$$

**Proof.** (1) For $M_n=\prod_{p\le n+1}p^{v_p(M_n)}$, CRT gives $L/M_n L\simeq\prod_{p\le n+1}L/p^{v_p(M_n)}L$. Every product of finitely many distinct prime powers divides all sufficiently large $M_n$, and every $M_n$ is such a product. Taking the limit of the compatible finite isomorphisms gives $\widehat{L}_{!}\simeq\prod_p\widehat{L}_p$. The factorial tower is degreewise surjective, so the argument of Lemma 2.6(2) gives a quasi-isomorphism from the strict limit to the homotopy limit. Applying Lemma 2.6(1) with the additive factorial completion functor identifies its $H^1$ with $\widehat{Q_\tau}_{!}$.
(2) Coherence modulo $M_n L$ implies $M_n\mid(\phi(s_{n+1})-\phi(s_n))$, giving (a). For $k_n\in\mathbb{Z}$, $|M_n k_n|<M_n$ holds iff $k_n=0$, i.e., $b_{n+1}(v)=b_n(v)$. If $\iota_{!}(s)=v$, Proposition A.2 shows $b_n(v)=s$ for all $n\ge 2|\phi(s)|+2$. Conversely, if $b_n(v)=b_N(v)=:s$ for all $n\ge N$, transition compatibility forces $s\bmod M_n L=v_n$ for all $n\in\mathbb{N}$, and $\bigcap_n(n+1)!\mathbb{Z}=\{0\}$ gives uniqueness of $s$. Finally, $\|E_{\mathrm{eff}}(b_{n+1}(v))-E_{\mathrm{eff}}(b_n(v))\|=(n+1)!|k_n|\|u\|$ with $\|u\|>0$ makes (2.5) equivalent to $|k_n|<1$. $\square$

---

## Part II: Projective Picard Torsors and Basis-Free Determinant Interfaces

<a id="sec-3"></a>

## 3 Finite Projective Localization, Picard Torsors, and Elliptic-Curve Nonfree Ideals

Adding finite generation and projectivity inside the bijective branch (Proposition 2.2(3a)) refines module representation into local stalk-rank dispatch and Picard classes.

### 3.1 Tensor Duality, Stalk-Rank Dispatch, and Picard Frame Torsors (R5)

<a id="prop-3-1"></a>

**Proposition 3.1 (R5: Finite projective tensor duality, stalk-rank dispatch, and Picard classification).** Let $M$ be a finitely generated projective $R$-module:

1. **Tensor duality**: The canonical map $M^\vee\otimes_R M\to\operatorname{End}_R(M)$ is an $R$-linear isomorphism (whereas finite nonprojective modules such as $\mathbb{Z}/2\mathbb{Z}$ over $\mathbb{Z}/4\mathbb{Z}$ are excluded prior to this branch).
2. **Stalk-rank and Picard dispatch**: Consider $\mathfrak{p}\mapsto\operatorname{rank}_{R_{\mathfrak{p}}}(M_{\mathfrak{p}})$ on $\operatorname{Spec} R$:
   (a) **Rank-varying branch**: if $\operatorname{rank}_{R_{\mathfrak{p}_1}}(M_{\mathfrak{p}_1})\neq\operatorname{rank}_{R_{\mathfrak{p}_2}}(M_{\mathfrak{p}_2})$, the classifier retains the pair $(\mathfrak{p}_1,\mathfrak{p}_2)$ as a witness that no one exterior degree is highest at every stalk (Remark 3.1);
   (b) **Constant-rank branch**: if the stalk rank is constant $n\in\mathbb{N}$ (including $R\cong 0$ at $n=0$ via $\operatorname{Spec} R=\varnothing$), then $L:=\bigwedge^n_R M$ is a rank-$1$ invertible $R$-module; when $[L]=1\in\operatorname{Pic}(R)$, its single-element bases form an $R^\times$-frame torsor, while $[L]\neq 1$ retains a nonfree witness.

**Proof.** Dual-basis coordinates $\{(f_i,m_i)\}_{i=1}^k$ with $\mathrm{id}_M=\sum_i f_i(\cdot)m_i$ yield $M^\vee\otimes_R M\xrightarrow{\sim}\operatorname{End}_R(M)$. Under constant stalk rank $n$, localization commutes with exterior powers to give $(\bigwedge^n_R M)_{\mathfrak{p}}\simeq R_{\mathfrak{p}}$, so $L$ is invertible; when $L\cong R$, $R^\times$ acts simply transitively on its generators. $\square$

<a id="rem-3-1"></a>

**Remark 3.1 (Scope relative to Stacks Project Tag 0FJ9).** Rank-varying finite projective modules admit patched determinant lines over clopen decompositions of $\operatorname{Spec} R$ (Stacks Tag `0FJ9` [@Stacks0FJ9]). Proposition 3.1(2a) simply records that there is no common highest exterior degree at all stalks for modules such as $\mathbb{Q}\times 0$ over $\mathbb{Q}\times\mathbb{Q}$ (stalk ranks $1$ and $0$).

### 3.2 Nonfree Invertible Ideal on an Affine Elliptic Curve (R6)

<a id="prop-3-2"></a>

**Proposition 3.2 (R6: Nonfree invertible ideal of $(1,0)$ on $y^2=x^3-x$).** Let $R_E:=\mathbb{Q}[x,y]/(y^2-x^3+x)$ be the affine coordinate ring of $E:y^2=x^3-x$, and let $P=(1,0)\in E(\mathbb{Q})$. The maximal ideal $L_P=(x-1,y)\triangleleft R_E$ is finitely generated and projective of constant rank $1$, satisfies $[L_P]\neq 1\in\operatorname{Pic}(R_E)$, is not a free $R_E$-module, and lands in the constant-rank nonfree branch of Proposition 3.1(2b).

**Proof.** An elementary self-contained proof is given in Example 1.1(c): the fractional ideal inverse makes $L_P$ projective of rank $1$, and $L_P^2=(x-1)R_E$ and parity of polynomial degrees in $a(x)^2-b(x)^2(x^3-x)$ rule out $L_P$ being principal (hence free). In the Lean formalization `ScalarNontrivialPicardLineRegression.lean`, the proof invokes `mathlib`’s injectivity of the affine Weierstrass point-to-class-group homomorphism (`WeierstrassCurve.Affine.Point.toClass_eq_zero`, formalized by Angdinata and Xu [@AngdinataXu2023; @mathlib2020]) together with $\operatorname{Cl}(R_E)\simeq\operatorname{Pic}(R_E)$ to deduce nonfreeness for any nonzero affine point over a field and instantiate $P=(1,0)$. $\square$

---

<a id="sec-4"></a>

## 4 Five Basis-Free Algebraic Interfaces for Determinants and Limit Complexes

Mathematically, the five propositions in this section (Interfaces I–V) encapsulate standard facts of linear and homological algebra; their role in our formalization is to enforce an **abstraction boundary that defers basis selection** (cf. Deligne [@Deligne1987] and Commelin–Topaz [@CommelinTopaz2024]): upstream module and cochain constructions store no chosen matrices or bases, producing scalar determinant coordinates only when frames are supplied at readout (see Appendix B.2).

<a id="prop-4-1"></a>

**Proposition 4.1 (Interface I: Dual-lattice determinant interface, `DualLatticeDeterminantKernel`).** Let $K$ be a field, $L,R'$ finite free $\mathbb{Z}$-lattices, and $\langle\cdot,\cdot\rangle:L\times R'\to K$ a $\mathbb{Z}$-bilinear pairing whose scalar extension to $L_K:=K\otimes_{\mathbb{Z}} L$ and $R'_K:=K\otimes_{\mathbb{Z}} R'$ is nondegenerate. Then:

1. $\dim_K L_K=\dim_K R'_K=:r$, and the pairing induces $L_K\xrightarrow{\sim}(R'_K)^\vee$ together with the basis-free top exterior pairing
   $$\det(L_K)\otimes_K\det(R'_K)\longrightarrow K;\tag{4.1}$$
2. Under changes of $K$-bases $(P,Q)$, $\det M_{\mathrm{dual}}(e_L,e_R)$ scales by $\det(P)\det(Q)$, so readouts on integral $\mathbb{Z}$-bases differ at most by a sign $u_L u_R\in\{\pm 1\}$;
3. For $\lambda:L\to_{\mathbb{Z}} R'$, $(M_{\mathrm{self}}(e_L))_{ij}:=\langle e_{L,i},\lambda(e_{L,j})\rangle$ satisfies $\det M_{\mathrm{self}}(e_L)=\det M_{\mathrm{dual}}(e_L,e_R)\cdot\det_{e_L,e_R}(\lambda_K)$.

**Proof.** Nondegeneracy on finite-dimensional spaces gives injections $L_K\hookrightarrow(R'_K)^\vee$ and $R'_K\hookrightarrow L_K^\vee$, forcing equal dimension, isomorphism, and (4.1); $M_{\mathrm{self}}(e_L)=M_{\mathrm{dual}}(e_L,e_R)[\lambda_K]_{e_L,e_R}$ and $\det(\mathrm{GL}_r(\mathbb{Z}))=\{\pm 1\}$ give (2)–(3). $\square$

<a id="prop-4-2"></a>

**Proposition 4.2 (Interface II: Equal-rank finite-cokernel Smith index and finite-group cardinality balance, `FiniteDefectDeterminantKernel`).**

1. **Equal-rank lattice index**: Let $f:S\to_{\mathbb{Z}} T$ be a linear map between finite free $\mathbb{Z}$-lattices with $\operatorname{rank}_{\mathbb{Z}} S=\operatorname{rank}_{\mathbb{Z}} T$. If $\operatorname{coker} f = T/\operatorname{im}(f)$ is finite, then $\ker f=0$ and in any pair of integral bases,
   $$|\det f| = \#\operatorname{coker} f.\tag{4.2}$$
2. **Finite abelian homomorphism balance**: Every homomorphism $g:H_1\to_{\mathbb{Z}} H_2$ of finite abelian groups satisfies $\#H_2\cdot\#\ker g = \#H_1\cdot\#\operatorname{coker} g$, i.e., $\#\operatorname{coker} g / \#\ker g = \#H_2 / \#H_1$.

**Proof.** (1) Finiteness of $T/\operatorname{im} f$ implies $\operatorname{rank}_{\mathbb{Z}}(\operatorname{im} f)=\operatorname{rank}_{\mathbb{Z}} T=\operatorname{rank}_{\mathbb{Z}} S$, forcing $\ker f=0$ on free $\mathbb{Z}$-modules, and Smith normal form gives $|\det f|=\#(T/\operatorname{im} f)$. (2) Eliminate $|\operatorname{im} g|$ between $|H_1|=|\ker g|\cdot|\operatorname{im} g|$ and $|H_2|=|\operatorname{im} g|\cdot|\operatorname{coker} g|$. $\square$

<a id="prop-4-3"></a>

**Proposition 4.3 (Interface III: Short-exact basis gluing and zero-cokernel exterior transport, `ExactDeterminantGluingKernel`).**

1. **Short-exact basis gluing**: Over any nonzero commutative ring $R$, given a short exact sequence $0\to X_1\to X_2\to X_3\to 0$ of finite free $R$-modules and bases $b_1,b_3$ on the endpoints, projective splitting constructs a glued basis on $X_2$, its top exterior frame, and $\operatorname{rank}_R X_2=\operatorname{rank}_R X_1+\operatorname{rank}_R X_3$.
2. **Zero-cokernel basis-free exterior transport**: Under the hypotheses of Proposition 4.2(1), if $\operatorname{coker} f=0$, then $f:S\xrightarrow{\sim} T$ is an isomorphism and induces $\bigwedge^r_{\mathbb{Z}} S\xrightarrow{\sim}\bigwedge^r_{\mathbb{Z}} T$ without choosing bases.

**Proof.** (1) Freeness of $X_3$ splits the sequence so $X_2\cong X_1\oplus X_3$, and every nonzero commutative ring satisfies invariant basis number (`StrongRankCondition`). (2) Proposition 4.2(1) gives $\ker f=0$, so $\operatorname{coker} f=0$ makes $f$ bijective. $\square$

<a id="prop-4-4"></a>

**Proposition 4.4 (Interface IV: Alternating integral determinant line of four-term free complexes, `PerfectComplexDeterminantProjectionKernel`).** For a four-term finite free integral cochain complex $C^\bullet=(C_0\xrightarrow{d_0}C_1\xrightarrow{d_1}C_2\xrightarrow{d_2}C_3)$:

1. Without choosing degreewise bases, the alternating integral determinant line
   $$\det\nolimits_{\mathbb{Z}}(C^\bullet):=\bigl(\det\nolimits_{\mathbb{Z}}(C_0)\otimes_{\mathbb{Z}}\det\nolimits_{\mathbb{Z}}(C_1)^\vee\bigr)\otimes_{\mathbb{Z}}\det\nolimits_{\mathbb{Z}}(C_2)\otimes_{\mathbb{Z}}\det\nolimits_{\mathbb{Z}}(C_3)^\vee\tag{4.3}$$
   is a free $\mathbb{Z}$-module of rank $1$ carrying parity $(\sum_{i=0}^3\operatorname{rank} C_i)\bmod 2\in\mathbb{Z}/2\mathbb{Z}$ and a two-element generator set ($\{\pm 1\}$-torsor);
2. Every termwise cochain isomorphism $(e_0,e_1,e_2,e_3):C^\bullet\xrightarrow{\sim}D^\bullet$ induces $\det_{\mathbb{Z}}(C^\bullet)\xrightarrow{\sim}\det_{\mathbb{Z}}(D^\bullet)$ via $\bigwedge e_{2k}$ in even degrees and $(\bigwedge e_{2k+1}^{-1})^\vee$ in odd degrees, covariantly compatible with composition (note: this interface encapsulates termwise isomorphism transport rather than general quasi-isomorphism invariance).

**Proof.** See Proposition A.3 in Appendix A. $\square$

<a id="prop-4-5"></a>

**Proposition 4.5 (Interface V: Categorical inverse limits of cochain diagrams and mapping-cone contractions, `DependentDerivedGlobalStateKernel`).** Let $\mathcal{I}$ be a small index category and $D:\mathcal{I}\to\operatorname{Ch}^\bullet(\mathbb{Z})$ a diagram of integral cochain complexes. Because $\operatorname{Ch}^\bullet(\mathbb{Z})$ is complete:

1. There exists an inverse-limit cochain complex $\mathcal{G}:=\varprojlim_{i\in\mathcal{I}} D(i)$ equipped with projection cochain maps $\pi_i:\mathcal{G}\to D(i)$ satisfying $D(\alpha)\circ\pi_i=\pi_j$ for every morphism $\alpha:i\to j$ in $\mathcal{I}$;
2. For a cochain map $\tau:D(i_0)\to E^\bullet$ at a fixed index $i_0$, put $f=\tau\circ\pi_{i_0}$. The cone $\operatorname{Cone}(f)^n=E^n\oplus\mathcal{G}^{n+1}$ gives the degreewise split exact sequence $0\to E^\bullet\to\operatorname{Cone}(f)\to\mathcal{G}[1]\to 0$. If a map $p:P^\bullet\to\mathcal{G}$ from a bounded finite free complex has a contracting homotopy $h$ on its cone, so that $d_{\mathrm{Cone}}h+hd_{\mathrm{Cone}}=\mathrm{id}$, then $p$ is a chain homotopy equivalence. The model $P^\bullet$ has determinant line $\det_{\mathbb{Z}}(P^\bullet)$ and its composite restrictions satisfy $D(\alpha)\circ(\pi_i\circ p)=\pi_j\circ p$ for $\alpha:i\to j$.

**Proof.** Degreewise limits in $\mathrm{Mod}_{\mathbb{Z}}$ give (1), while standard mapping-cone homological algebra (contractibility of $\operatorname{Cone}(p)$ is equivalent to $p$ being a chain homotopy equivalence [@Weibel1994]) gives (2). Composing the identity in (1) with $p$ gives the equality for the composite restrictions. $\square$

<a id="ex-4-1"></a>

**Example 4.1 (Elementary checks on Smith index, sign transport, and four-term complexes).** For $f=2\cdot\mathrm{id}:\mathbb{Z}\to\mathbb{Z}$, Proposition 4.2(1) gives $\ker f=0$ and $|\det f|=2=\#(\mathbb{Z}/2\mathbb{Z})$. For $u=-\mathrm{id}:\mathbb{Z}\to\mathbb{Z}$, $\#\operatorname{coker} u=1$ while Proposition 4.3(2) preserves the sign $-1$. On $C^\bullet=(\mathbb{Z}\xrightarrow{\cdot 2}\mathbb{Z}\xrightarrow{0}\mathbb{Z}\xrightarrow{\cdot 3}\mathbb{Z})$, Proposition 4.4 gives $\det_{\mathbb{Z}}(C^\bullet)\cong\mathbb{Z}$ with its $\{\pm 1\}$-torsor (as classical Euler–Poincaré background outside Proposition 4.4’s termwise scope, the alternating cohomology cardinality ratio is likewise $\#H^1\cdot\#H^3/(\#H^0\cdot\#H^2)=2\cdot 3=6$).

---

## Part III: Free Linearization of State Systems, Syzygy Presentations, and Signed Sparse Hankel Recovery

<a id="sec-5"></a>

## 5 Free Linearization of State Systems, Unobservable Submodules, and Syntactic Left Inverses

This section collects basic algebraic properties of linearized state-transition systems and multi-step observation kernels used in §6 and companion process-algebra modules.

### 5.1 Point-Observation Linearization and Intertwining Defect Derivation (R7–R8)

<a id="prop-5-1"></a>

**Proposition 5.1 (R7–R8: Point-observation tower isomorphism, bilinear increments, and defect derivation).** Let $S$ be a set with self-map $\sigma:S\to S$, put $V=\mathbb{Z}^{(S)}$, and let $T:V\to V$ be the free linear extension of $\sigma$. The inverse limit of compatible prefixes $(v,Tv,\dots,T^nv)$ is $\mathcal{F}_\sigma=\{(T^nv)_{n\in\mathbb{N}}:v\in V\}\le\prod_n V$.

1. **Two-sided linear isomorphism and three-term increment (R7)**: The generator map $\mathrm{sourceMap}:\mathbb{Z}[S]\to\mathcal{F}_\sigma$ and degree-zero readout $\mathrm{word}:\mathcal{F}_\sigma\to\mathbb{Z}[S]$ are mutually inverse $\mathbb{Z}$-linear isomorphisms intertwining the induced shift with the free linear extension of $\sigma$; any binary operation $\star:X\times Y\to Z$ lifts by bilinearity [@Stacks00CX] to satisfy the three-term difference expansion [@Budiu2023DBSP]:
   $$(x+\Delta x)\star(y+\Delta y)-x\star y = (\Delta x\star y)+(x\star\Delta y)+(\Delta x\star\Delta y).\tag{5.1}$$
2. **Intertwining defect derivation law (R8)**: Given step systems $(X,\sigma_X),(Y,\sigma_Y)$ and any map $f:X\to Y$ with induced linear map $\mathrm{map}(f):\mathcal{F}_X\to\mathcal{F}_Y$ and step operators $A_{\sigma_X},B_{\sigma_Y}$, the intertwining defect $\Delta f:=B_{\sigma_Y}\circ\mathrm{map}(f)-\mathrm{map}(f)\circ A_{\sigma_X}$ satisfies, for all composable maps $X\xrightarrow{f}Y\xrightarrow{g}Z$,
   $$\Delta(g\circ f) = \Delta g\circ\mathrm{map}(f) + \mathrm{map}(g)\circ\Delta f,\tag{5.2}$$
   with $\Delta f=0$ if and only if $\sigma_Y(f(x))=f(\sigma_X(x))$ for all $x\in X$.

**Proof.** (1) $\mathrm{sourceMap}$ is injective onto its image $\mathcal{F}_\sigma$ with left inverse $\mathrm{word}$, and distributivity gives (5.1). (2) Telescoping $C_{\sigma_Z}\mathrm{map}(g)\mathrm{map}(f)-\mathrm{map}(g)\mathrm{map}(f)A_{\sigma_X}$ gives (5.2), and evaluating $\Delta f$ on point generators $\delta_x$ yields equivariance. $\square$

### 5.2 Syntactic Left Inverses, Additive-Context Cochain Maps, and Unobservable Submodules (R18–R42, R45, R60)

<a id="prop-5-2"></a>

**Proposition 5.2 (R20, R60, R18, R21, R23: Syntactic tree left inverse and additive-context two-term cochain maps).**

1. **Evaluation-free syntactic left inverse (R20, `Tree/Fold/Inverse.lean`)**: For inductive trees `occur(r, bs)` ($r\in R_0$, child list $bs$) and any folding function $\kappa:R_0\to\mathrm{List}(C_0)\to C_0$, the syntactic encoding $\mathrm{program}_\kappa$ and structural parser `readTree` (which never invokes $\kappa$) satisfy $\mathrm{readTree}(\mathrm{program}_\kappa(T))=\mathrm{some}\,T$; in particular, $\mathrm{program}_\kappa$ remains injective even when $\kappa\equiv 0$.
2. **Additive-context two-term cochain map (R60, `LinearCochain.lean`)**: Let $\mathrm{op}$ be additive and let the parent trace execute the given child trace in the context $\mathcal{L}_{\mathrm{op}}$. The map $[e]\mapsto[\mathcal{L}_{\mathrm{op}}(e)]$ induces the chain map `linearCochain` between their two-term path complexes. For any environment increment, the incremental evaluation of the boundaries satisfies
   $$\mathrm{eff}_\delta(\partial_{\mathrm{parent}}) = \mathrm{op}\bigl(\mathrm{eff}_\delta(\partial_{\mathrm{child}})\bigr).\tag{5.3}$$
3. **Length and boundary of a substituted trace (R18, R21, R23).** Let $\sigma$ be a sort-preserving substitution by expressions and let $\rho$ be the environment for the new variables. The old environment assigns to $x$ the value of $\sigma(x)$ in $\rho$. Replacing each variable evaluation in a trace $E\rightsquigarrow E'$ by the evaluation trace of $\sigma(x)$ in $\rho$ gives $F_0\rightsquigarrow\cdots\rightsquigarrow F_m$, where $F_0=E^\sigma$ and $F_m=(E')^\sigma$. In the free integral module on expressions its boundary is
   $$\sum_{i=0}^{m-1}([F_i]-[F_{i+1}])=[E^\sigma]-[(E')^\sigma].$$
   If $E'$ is constant, then $m=\mathrm{remaining}(E^\sigma)$. Here $\mathrm{remaining}$ counts variable occurrences and the addition, unary linear, and binary bilinear nodes. A constant contributes zero.

**Proof.** (1) Mutual structural induction on trees and child lists shows `readTree` reconstructs $(r,bs)$ solely from constructor delimiters independently of $\kappa$. (2) Additivity maps $[e_i]-[e_{i+1}]$ to $[\mathcal{L}_{\mathrm{op}}(e_i)]-[\mathcal{L}_{\mathrm{op}}(e_{i+1})]$, commuting with $d$ and proving (5.3). (3) Substituted step traces have matching endpoints and concatenate. Their interior basis elements cancel in the boundary sum. Each primitive step reduces $\mathrm{remaining}$ by one, so a trace ending at a constant has length $\mathrm{remaining}(E^\sigma)$. $\square$

<a id="prop-5-3"></a>

**Proposition 5.3 (R19, R22, R24–R27, R36: Kernel-quotient isomorphism, module-theoretic unobservable submodule, and fiber-constrained preimages).**

1. **Representative-free kernel-quotient isomorphism (R19, R22, `Fibre/Recovery.lean`)**: Given linear maps $E,E_{\mathrm{next}}$ and $J_0$ satisfying $\ker E=\ker J_0\cap\ker E_{\mathrm{next}}$ with inclusion $\mathrm{kernelMap}:\ker E\hookrightarrow\ker E_{\mathrm{next}}$, the first isomorphism theorem yields $\ker E_{\mathrm{next}}/\operatorname{im}(\mathrm{kernelMap})\xrightarrow{\sim}\operatorname{im}(J_0|_{\ker E_{\mathrm{next}}})$ without selecting representatives.
2. **Unobservable maximal invariant submodule (R24–R25, R27, R36, `Words/Kernel.lean`)**: For an $R$-module $C$ over a commutative ring $R$, linear readout $e:C\to_R B$, and endomorphism family $\{A_\alpha:C\to_R C\}_{\alpha\in I}$, the free-monoid word readout $\mathcal{I}(c)(w):=e(A_w c)$ ($w\in I^*$) has kernel $\ker\mathcal{I}$ equal to the **unique largest $\{A_\alpha\}$-invariant $R$-submodule contained in $\ker e$** (the module-theoretic counterpart over arbitrary commutative rings of Kálmán’s unobservable subspace [@Kalman1963]); when $\ker\mathcal{I}=0$, $\mathcal{I}$ induces $C\xrightarrow{\sim}\operatorname{im}(\mathcal{I})$.
3. **Fiber-constrained preimage criterion (R26, `TargetDifference.lean`)**: Given commuting linear maps $d_C=d_D\circ\mu$ ($\mu:C\to D$, $d_C:C\to H$, $d_D:D\to H$), $c_0\in C$, and $y\in D$, set $\delta:=y-\mu(c_0)$. There exists $c\in C$ satisfying both $d_C(c)=d_C(c_0)$ and $\mu(c)=y$ if and only if
   $$d_D(\delta)=0 \quad \wedge \quad [\delta]=0\in\operatorname{coker}(\mu).$$

**Proof.** (1) Immediate from $\ker(J_0|_{\ker E_{\mathrm{next}}})=\ker E$. (2) Setting $w=[]$ gives $\ker\mathcal{I}\le\ker e$, shifting $\mathcal{I}(A_\alpha c)(w)=\mathcal{I}(c)(\alpha::w)$ gives invariance, and induction on word length places every $\{A_\alpha\}$-invariant $N\le\ker e$ inside $\ker\mathcal{I}$. (3) If $c$ exists, $\delta=\mu(c-c_0)$ yields $[\delta]=0$ and $d_D(\delta)=d_C(c-c_0)=0$; conversely, $[\delta]=0$ provides $c\in C$ with $\mu(c-c_0)=\delta$, whence $d_C(c)-d_C(c_0)=d_D(\delta)=0$. $\square$

<a id="rem-5-1"></a>

**Remark 5.1 (Cross-step congruences and two-node tree check).** Finite word duals, zero-evaluation congruences, and same-root splicing (`R28–R35, R38–R42, R45`; Appendix B.1) supply supporting lemmas for [@Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2]. On the two-node tree $\mathrm{occur}(r_0, [\mathrm{occur}(r_1, [])])$ with $\kappa\equiv 0$, $\mathrm{program}_\kappa$ evaluates semantically to zero yet preserves delimiters so `readTree` returns the input tree.

---

<a id="sec-6"></a>

## 6 Constructive Syzygy Presentations and Unknown-Sparsity Signed Hankel Recovery

### 6.1 Constructive Syzygy Presentation and Net–Certificate Decomposition of Free Constant Tables (R43)

In Pacioli difference groups (Ellerman [@Ellerman2014Accounting]) and streaming $\mathbb{Z}$-sets (DBSP [@Budiu2023DBSP]), cancelling formal entries such as $[g]+[-g]-[0]$ lie in $\ker(\mathrm{freeEval})$ under $\mathrm{freeEval}:\mathbb{Z}^{(G)}\to G$ and vanish in the group quotient. Proposition 6.1 constructs an explicit two-generator relation presentation and syzygy map $\mathrm{cert}(\Delta T)$: transmitting the net group value $v=\mathrm{freeEval}(\Delta T)$ together with the syzygy certificate $\mathrm{cert}(\Delta T)$ reconstructs $\Delta T$ identically.

<a id="prop-6-1"></a>

**Proposition 6.1 (R43: Exact syzygy presentation and net–certificate decomposition of free constant tables).** For an abelian group $G$, let $\mathrm{freeEval}:\mathbb{Z}^{(G)}\to_{\mathbb{Z}} G$ send $\delta_g\mapsto g$. Over $\mathcal{R}_G:=(G\times G)\sqcup(\mathbb{Z}\times G)$, define $\mathrm{rel}_G:\mathbb{Z}^{(\mathcal{R}_G)}\to_{\mathbb{Z}}\mathbb{Z}^{(G)}$ by
$$\mathrm{rel}_G\bigl(\delta_{\mathrm{inl}(a,b)}\bigr):=\delta_a+\delta_b-\delta_{a+b},\qquad \mathrm{rel}_G\bigl(\delta_{\mathrm{inr}(w,g)}\bigr):=\delta_{w\cdot g}-w\,\delta_g.$$
Then:

1. **Environment-increment decomposition**: Under an environment update, the updated constant table satisfies
   $$T_{\mathrm{after}} = T_{\mathrm{before}} + T_{\mathrm{effect}} - \mathrm{rel}_G(C_{\mathrm{add}}),\tag{6.1}$$
   with $C_{\mathrm{add}}\in\mathbb{Z}^{(\mathcal{R}_G)}$ constructed termwise from prior values and increments.
2. **Constructive syzygy certificate and exact presentation**: For every difference table $\Delta T:=T_{\mathrm{after}}-T_{\mathrm{before}}\in\mathbb{Z}^{(G)}$, structural recursion over its finite support constructs $\mathrm{cert}(\Delta T)\in\mathbb{Z}^{(\mathcal{R}_G)}$ satisfying
   $$\mathrm{rel}_G(\mathrm{cert}(\Delta T)) = \Delta T - \delta_{\mathrm{freeEval}(\Delta T)}.\tag{6.2}$$
   Consequently $\operatorname{im}(\mathrm{rel}_G)=\ker(\mathrm{freeEval})$ is exact, and $T_{\mathrm{before}}+\delta_v+\mathrm{rel}_G(\mathrm{cert}(\Delta T))$ ($v=\mathrm{freeEval}(\Delta T)$) equals $T_{\mathrm{after}}$.

**Proof.** At position $i$ let $a_i$ be the prior value, $b_i$ its increment, and $w_i$ its integer coefficient. Set $T_{\mathrm{effect}}=\sum_i w_i\delta_{b_i}$ and $C_{\mathrm{add}}=\sum_i w_i\delta_{\mathrm{inl}(a_i,b_i)}$. Expanding $\mathrm{rel}_G(C_{\mathrm{add}})$ gives (6.1). For (6.2), represent $\Delta T$ as $[(g_1,w_1),\dots,(g_m,w_m)]$ and induct on $m$. At $m=0$, $\mathrm{cert}(0):=-\delta_{\mathrm{inr}(0,0)}$ gives $\mathrm{rel}_G(-\delta_{\mathrm{inr}(0,0)})=-\delta_0$. Prepending $w\cdot\delta_g$ and adding $-\delta_{\mathrm{inr}(w,g)}+\delta_{\mathrm{inl}(w\cdot g,\,\mathrm{val}(\mathrm{rest}))}$ to $\mathrm{cert}(\mathrm{rest})$ cancels $\delta_{\mathrm{val}(\mathrm{rest})}$ under $\mathrm{rel}_G$, proving (6.2). Clearly $\mathrm{freeEval}\circ\mathrm{rel}_G=0$; conversely, if $\mathrm{freeEval}(\Delta T)=0$, (6.2) and $\delta_0=\mathrm{rel}_G(\delta_{\mathrm{inr}(0,0)})$ yield $\Delta T=\mathrm{rel}_G(\mathrm{cert}(\Delta T)+\delta_{\mathrm{inr}(0,0)})\in\operatorname{im}(\mathrm{rel}_G)$. $\square$

Equation (6.2) and the exact presentation hold for a module $G$ over any commutative ring $R$. With scalar relation indices in $R\times G$ and $w\cdot g$ the module action, the same finite-support induction gives the certificate.

<a id="ex-6-1"></a>

**Example 6.1 (Syzygy decomposition of a zero-net difference table).** On $G=\mathbb{Z}$, $\Delta T = [5]+[-5]-[0]\in\mathbb{Z}^{(\mathbb{Z})}$ has net evaluation $\mathrm{freeEval}(\Delta T)=0$. Proposition 6.1(2) decomposes $\Delta T$ into the net term $\delta_0=[0]$ plus the syzygy boundary $\mathrm{rel}_{\mathbb{Z}}(\mathrm{cert}(\Delta T))=[5]+[-5]-2[0]$, retaining all cancelling entries.

### 6.2 Unknown-Sparsity Signed Sparse Recovery from $2k$ Moments over Arbitrary Fields (R49)

Classical rational-interpolation and sparse-polynomial theory (Prony [@Prony1795]; Kronecker [@Kronecker1881]; Ben-Or–Tiwari [@BenOrTiwari1988]) relates Hankel rank to active sparsity. Along our unifying thread, the leading Hankel block $H_w$ is the evaluation Gram matrix of monomials against a signed discrete measure: when weights carry opposite signs or $K$ has positive characteristic, lower blocks $H_w$ ($w<r$) can vanish by cancellation, so unknown-order recovery cannot assume sequential nonsingularity from $w=1$ up to $r$. Theorem 6.2 proves and formalizes largest-nonsingular-block recovery over an arbitrary field $K$ within a known finite candidate set.

<a id="thm-6-2"></a>

**Theorem 6.2 (R49: Unknown-$k$-sparse signed recovery from $2k$ moments over an arbitrary field, `SparseMoment.lean`).** Let $K$ be any field, $I$ an index set, and $\tau:I\to K$ an injective address map. Suppose $a\in K^{(I)}$ has support $S:=\operatorname{supp}(a)$ contained in a known finite candidate set $A\subseteq I$ with $r:=|S|\le k$ ($r$ unknown, active weights $a(s)\in K^\times$ arbitrary). Define the power moments below, of which the first $2k$ are given.
$$M_j := \sum_{i\in I} a_i\,\tau(i)^j \in K\qquad (j\ge 0),\tag{6.3}$$
Define the leading Hankel matrix of each order $w\ge 0$ by $(H_w)_{p,q}:=M_{p+q}$ for $0\le p,q<w$, with $\det H_0=1$. Then:

1. **Signed evaluation-Gram factorization**: Writing $S=\{s_0,\dots,s_{r-1}\}$ and $(V_w)_{p,\ell}=\tau(s_\ell)^p$ ($V_w\in K^{w\times r}$), for every $w\in\mathbb{N}$,
   $$H_w = V_w\,\operatorname{diag}\bigl(a(s_0),\dots,a(s_{r-1})\bigr)\,V_w^{\mathsf T};\tag{6.4}$$
2. **Order determination via largest nonsingular leading block**: Even if $\det H_w=0$ for some $1\le w<r$ due to cancellation, $\det H_r\neq 0$ while $\det H_w=0$ for all $w>r$; hence (see Remark C.1)
   $$r = |S| = \max\{\,w\in\{0,\dots,k\} : \det H_w \neq 0\,\};\tag{6.5}$$
3. **Support localization and weight inversion**: Setting $c := -H_r^{-1}(M_r,\dots,M_{2r-1})^{\mathsf T}\in K^r$ and
   $$P(t) := t^r + \sum_{j=0}^{r-1} c_j t^j \in K[t],\tag{6.6}$$
   the root set $\{i\in A : P(\tau(i))=0\}$ equals $S$ (`recover_support`), and invertible $V_r\in K^{r\times r}$ recovers $(a(s_0),\dots,a(s_{r-1}))^{\mathsf T} = V_r^{-1}(M_0,\dots,M_{r-1})^{\mathsf T}$ (`recover_prefix`). When $r=0$, $P=1$ and the recovered table is zero with empty support.

**Proof.** (1) Direct expansion gives $(V_w \operatorname{diag}(a|_S) V_w^{\mathsf T})_{p,q}=\sum_{\ell=0}^{r-1}\tau(s_\ell)^p a(s_\ell)\tau(s_\ell)^q=M_{p+q}=(H_w)_{p,q}$.
(2) At $w=r$, distinctness of $\{\tau(s_\ell)\}$ gives $\det V_r\neq 0$, and $a(s_\ell)\neq 0$ on $S$ yields $\det H_r=(\det V_r)^2\prod_{\ell=0}^{r-1}a(s_\ell)\neq 0$. For $w>r$, $\operatorname{rank}(H_w)\le\operatorname{rank}(V_w)\le r<w$, so $\det H_w=0$. Since $0\le r\le k$ and $H_0,\dots,H_k$ depend only on $M_0,\dots,M_{2k-2}$, the largest $w\le k$ with $\det H_w\neq 0$ equals $r$.
(3) Put $z_\ell:=a(s_\ell)P(\tau(s_\ell))$. For $0\le p<r$, (6.3) and $H_r c=-(M_r,\dots,M_{2r-1})^{\mathsf T}$ give
$$(V_r z)_p = \sum_{\ell=0}^{r-1}\tau(s_\ell)^p a(s_\ell)\Bigl(\tau(s_\ell)^r+\sum_{q=0}^{r-1}c_q\tau(s_\ell)^q\Bigr) = M_{p+r}+\sum_{q=0}^{r-1}M_{p+q}c_q = 0.$$
Invertibility of $V_r$ forces $z=0$, so $a(s_\ell)\neq 0$ implies $S\subseteq R_{\mathrm{rec}}:=\{i\in A:P(\tau(i))=0\}$. Because $\deg P=r$ over the field $K$ and $\tau$ is injective, $|R_{\mathrm{rec}}|=|\tau(R_{\mathrm{rec}})|\le r=|S|$, forcing $R_{\mathrm{rec}}=S$, and multiplying $V_r a|_S=(M_0,\dots,M_{r-1})^{\mathsf T}$ by $V_r^{-1}$ recovers the weights. $\square$

<a id="ex-6-2"></a>

**Example 6.2 (Modular cancellation recovery over $\mathbb{F}_7$).** Take $K=\mathbb{F}_7$, $k=3$, candidate set $A=\{1,2,4\}\subset\mathbb{F}_7$, and weights $(3,4,0)$ ($S=\{1,2\}$, $r=2$). Computing $M_j=3\cdot 1^j + 4\cdot 2^j\bmod 7$ for $0\le j<6$ yields
$$M = (0,\, 4,\, 5,\, 0,\, 4,\, 5) \pmod 7.$$
Here $M_0\equiv 3+4\equiv 0\pmod 7$ makes $H_1=[0]$ singular; however, $H_2=\bigl(\begin{smallmatrix}0&4\\4&5\end{smallmatrix}\bigr)$ has $\det H_2 = 0\cdot 5 - 4^2 = -16 \equiv 5 \not\equiv 0 \pmod 7$ while $\det H_3 \equiv 0 \pmod 7$, so (6.5) identifies $r=2$. Solving $H_2 c \equiv -(5,0)^{\mathsf T}\equiv (2,0)^{\mathsf T}\pmod 7$ gives $c\equiv (2,4)^{\mathsf T}$ and $P(t)=t^2+4t+2\equiv (t-1)(t-2)\pmod 7$; evaluating on $A$ gives $P(1)\equiv P(2)\equiv 0$ and $P(4)\equiv 6\not\equiv 0$, recovering $S=\{1,2\}$ and weights $(3,4)$.

![Figure 3 | Signed Hankel order, support detection, and weight recovery](figures/fig3-sparse-hankel-en.svg)

**Figure 3 | Signed Hankel order, support detection, and weight recovery.** The leading Hankel determinants of the six signed moments are $0,-4,0$, so the largest nonsingular order is $2$. The recurrence from $H_2$ gives $P(t)=t^2-1$, which selects nodes $1,-1$ from the candidates. The Vandermonde system then recovers weights $1,-1$ (Theorem 6.2).

---

## Part IV: Singular Hermitian Gram Projections, Hilbert Stream Preimages, and Linear-Growth Cayley Operator Inverses

<a id="sec-7"></a>

## 7 Finite-Dimensional Singular Hermitian Gram Cosets and Incremental Updates

Turning to positive-semidefinite inner-product spaces, finite probe families $\{u_i\}$ may be linearly dependent or contain zero vectors, making $G_u$ singular. This section records the finite-dimensional solution cosets, separating directed-net strong convergence, Schur-border updates, and rank-one dual-column updates serving as building blocks for Section 8.

### 7.1 Singular Finite Hermitian Gram Cosets and Directed-Net Convergence (R44, R46, R48)

<a id="prop-7-1"></a>

**Proposition 7.1 (R44, R46, R48: Singular Gram solution cosets, orthogonal projection synthesis, and directed strong convergence).**

1. **Singular Hermitian solution coset (R44, `FiniteGram.lean`)**: For any finite Hermitian matrix $G\in\mathbb{C}^{\iota\times\iota}$ and $b\in(\ker G)^\perp$, $(\mathbb{C}^\iota/\ker G)\simeq(\ker G)^\perp\simeq\operatorname{im}(G)$ determines a unique minimal-norm solution $c_\star\in(\ker G)^\perp$ with $Gc_\star=b$, and the full solution set is the affine coset
   $$Gx = b \iff x - c_\star\in\ker G.\tag{7.1}$$
2. **Probe compatibility and orthogonal projection synthesis (R44, R48)**: When $G=G_u$ is generated by $u:\iota\to H$ in a complex inner-product space $H$, $b=\mathrm{rhs}_u(x)$ lies in $(\ker G_u)^\perp$ for every $x\in H$ and $\ker G_u\le\ker\Phi_u$; hence synthesis takes the constant value $\Phi_u(c_\star)=P_{\operatorname{span}(u)}x$ across the coset (7.1), its complement $(I-P_{\operatorname{span}(u)})x$ defines `innovationCLM`. In the original two-branch evolution of R48, the full coordinates $E$ retain position coefficients and the orthogonal remainder of the summed field, as well as the original outside component. The inventory update $U$ and source action $A$ satisfy $U(Ev)=E(Av)$ (`actual_stock_source_step`).
3. **Directed-net strong convergence for separating families (R46, `PrefixReadback.lean`, `DirectedReadback.lean`)**: If $H$ is complete and $\{u_i\}_{i\in\mathcal{J}}$ separates points of $H$ ($\forall i,\langle u_i,x\rangle_H=0\implies x=0$), then along the directed net of finite subsets $\mathcal{F}\in\mathrm{Finset}(\mathcal{J})$ (including natural-number prefixes), for every $x\in H$,
   $$\lim_{\mathcal{F}} \Phi_{u|_{\mathcal{F}}}\bigl(c_\star(G_{u|_{\mathcal{F}}},\,\mathrm{rhs}_{\mathcal{F}}(x))\bigr) = x \quad \text{in }\|\cdot\|_H.\tag{7.2}$$

**Proof.** (1) Hermiticity $G=G^*$ gives $\operatorname{im}(G)=(\ker G)^\perp$, yielding unique $c_\star\in(\ker G)^\perp$ and (7.1). (2) $G_u a=0\implies \|\Phi_u(a)\|_H^2=\langle a,G_u a\rangle=0\implies\Phi_u(a)=0$, and $\langle u_i,x-\Phi_u(c_\star)\rangle_H=0$ characterizes $P_{\operatorname{span}(u)}x$. (3) Separation implies density of $\bigcup_{\mathcal{F}}\operatorname{span}(u|_{\mathcal{F}})$ in complete $H$, so increasing orthogonal projections converge strongly to the identity. $\square$

### 7.2 Schur-Bordered Inverses, Tail-Independent First-Pivot Selection, and Rank-One Dual Updates (R47, R59)

<a id="prop-7-2"></a>

**Proposition 7.2 (R47: Commutative-ring Schur border update and tail-independent first-pivot decoding, `MatrixBorder.lean`, `CofinalInsertion.lean`, `CofinalRecord.lean`).**

1. **Schur border formula**: Over a commutative ring $R$, given invertible $A\in R^{n\times n}$ and bordered $B=\bigl(\begin{smallmatrix}A&r\\b^{\mathsf T}&d\end{smallmatrix}\bigr)$, set $s:=d-b^{\mathsf T}A^{-1}r\in R$ [@Schur1917]. Then $\det B=\det(A)\cdot s$, and whenever $s\in R^\times$,
   $$\det B=\det(A)\cdot s,\qquad B^{-1}=\begin{pmatrix}A^{-1}+A^{-1}r s^{-1}b^{\mathsf T}A^{-1} & -A^{-1}r s^{-1}\\ -s^{-1}b^{\mathsf T}A^{-1} & s^{-1}\end{pmatrix}.\tag{7.3}$$
2. **Tail-independent first-pivot selection**: Let $\{f_j:\mathbb{N}\to\mathbb{C}\}_{j\in\mathbb{N}}$ be linearly independent on every tail $\{t\ge\tau_{\mathrm{cut}}\}$. Given sample times $\tau_0<\dots<\tau_{n-1}$ on which evaluation of $f_0,\dots,f_{n-1}$ is injective, let $\hat p_n\in\mathbb{C}^n$ be the fit of $f_n$ on those times and set $\rho_n(t):=f_n(t)-\sum_{i<n}\hat p_{n,i}f_i(t)$. Then there exists a least $\tau_n>\max(\{0\}\cup\{\tau_i:i<n\})$ (`pivotTime`) with $\rho_n(\tau_n)\neq 0$; appending $\tau_n$ preserves injectivity on $f_0,\dots,f_n$, and for $y=\sum_{i<n}a_i f_i+bf_n$ with prior fit $\tilde a:=\mathrm{solve}_{\tau_{<n}}(y|_{\tau_{<n}})$, a single sample $y(\tau_n)$ yields (`decode_insert_exact`):
   $$b = \frac{y(\tau_n)-\sum_{i<n}\tilde a_i f_i(\tau_n)}{\rho_n(\tau_n)},\qquad a = \tilde a - b\,\hat p_n.$$

**Proof.** (1) Direct block Gaussian elimination. (2) Identical vanishing of $\rho_n(t)$ for $t>\max(\{0\}\cup\{\tau_i:i<n\})$ would contradict tail linear independence, giving minimal $\tau_n$; linearity gives $\tilde a=a+b\hat p_n$, and evaluating at $\tau_n$ isolates $b\rho_n(\tau_n)$. $\square$

<a id="prop-7-3"></a>

**Proposition 7.3 (R59: Rank-one dual-column update under linearly independent column insertion, `Projection/DualColumn/Insert.lean`).** Let $u^{\mathrm{snoc}}:=(u,u_{\mathrm{new}})$ ($u:\operatorname{Fin} n\to H$) be linearly independent in a complex inner-product space $H$. Write $w_i:=\Phi_u(G_u^{-1}e_i)\in\operatorname{span}(u)$ ($\langle w_i,u_j\rangle_H=\delta_{ij}$), $c_i(x):=\langle w_i,x\rangle_H$, and $r_n:=(I-P_{\operatorname{span}(u)})u_{\mathrm{new}}\neq 0$. Then:

1. The last biorthogonal vector is
   $$w^{\mathrm{new}}_n = \frac{1}{\|r_n\|_H^2}\,r_n;\tag{7.4}$$
2. Prior biorthogonal vectors ($i<n$) update by rank one:
   $$w^{\mathrm{new}}_i = w_i - \overline{\langle w_i, u_{\mathrm{new}}\rangle_H}\,w^{\mathrm{new}}_n;\tag{7.5}$$
3. For every $x\in H$, $c_n=\langle r_n,x\rangle_H/\|r_n\|_H^2$ obeys $|c_n|\cdot\|r_n\|_H\le\|x\|_H$, and all coefficients satisfy
   $$c^{\mathrm{new}}_n = c_n,\qquad c^{\mathrm{new}}_i = c_i\bigl(x - c_n u_{\mathrm{new}}\bigr)\quad(\forall i<n).\tag{7.6}$$

**Proof.** Using $r_n\perp\operatorname{span}(u)$ and $\langle r_n,u_{\mathrm{new}}\rangle_H=\|r_n\|_H^2$, direct inner-product evaluation verifies $\langle w^{\mathrm{new}}_p, u^{\mathrm{snoc}}_q\rangle_H=\delta_{pq}$ ($0\le p,q\le n$), and Cauchy–Schwarz gives the coefficient bound. $\square$

<a id="ex-7-1"></a>

**Example 7.1 (Rank-one dual-column insertion on $\mathbb{C}^2$).** For $u_0=(1,0)^{\mathsf T}\in\mathbb{C}^2$ with $w_0=(1,0)^{\mathsf T}$ and $u_{\mathrm{new}}=(1,1)^{\mathsf T}$, we have $r_1=(0,1)^{\mathsf T}$ ($\|r_1\|^2=1$). Formulas (7.4)–(7.5) give $w_1^{\mathrm{new}}=(0,1)^{\mathsf T}$ and $w_0^{\mathrm{new}}=(1,0)^{\mathsf T}-1\cdot(0,1)^{\mathsf T}=(1,-1)^{\mathsf T}$ without inverting the extended Gram matrix $\bigl(\begin{smallmatrix}1&1\\1&2\end{smallmatrix}\bigr)$.

---

<a id="sec-8"></a>

## 8 Infinite-Dimensional Hilbert Stream Preimages and Linear-Growth Cayley Operator Inverses

Whereas Proposition 7.1 approximates a given element $x\in H$, inverse problems present only a scalar stream $d:\mathbb{N}\to\mathbb{C}$ and ask whether a preimage $x\in H$ exists. We establish the singular-probe Hilbert stream preimage characterization (Theorem 8.1), closed-subspace projected-probe convergence (Proposition 8.2), bounded-operator stream preimage corollary (Corollary 8.3), and the explicit Banach inverse and truncation budget under linear Cayley growth (Theorem 8.4).

### 8.1 Hilbert Stream Preimage Criterion and Residual Energy Identity (R50)

Given probes $\{u_i\}_{i\in\mathbb{N}}\subset H$ and data $d:\mathbb{N}\to\mathbb{C}$, write $d|_n:=(d_0,\dots,d_{n-1})\in\mathbb{C}^n$ and define via Proposition 7.1 the $n$-th singular Gram approximation $x_n(d):=\Phi_{u|_n}(c_\star(G_{u|_n},P_{(\ker G_{u|_n})^\perp}(d|_n)))$, prefix residual, and minimal-norm prefix energy:
$$r_n(d):=\mathrm{rhs}_{u|_n}(x_n(d))-d|_n,\qquad E_n(d):=\|x_n(d)\|_H^2.\tag{8.1}$$

<a id="thm-8-1"></a>

**Theorem 8.1 (R50: Necessary-and-sufficient Hilbert stream preimage criterion and residual energy identity under singular probes, `PrefixImage.lean`, `PrefixEnergy.lean`).** Let $H$ be a complex Hilbert space, $\{u_i\}_{i\in\mathbb{N}}\subset H$ an arbitrary probe sequence (not assumed orthogonal or linearly independent), and $d:\mathbb{N}\to\mathbb{C}$ a data stream.

1. **Stream preimage criterion (`admitted_iff_image`)**: There exists $x\in H$ satisfying $\langle u_i,x\rangle_H=d_i$ for all $i\in\mathbb{N}$ **if and only if** the residuals and energies determined by the finite prefixes satisfy (cf. F. Riesz [@Riesz1910] and Aronszajn [@Aronszajn1950]):
   $$(\forall n\in\mathbb{N},\ r_n(d)=0)\quad \wedge\quad \sup_{n\in\mathbb{N}} E_n(d) < \infty.\tag{8.2}$$
2. **Minimal-norm strong limit and energy-gap identity (`error_squared`, `first_within`)**: When (8.2) holds, $x_m(d)=P_{\operatorname{span}(u|_m)} x_n(d)$ for all $m\le n$ with Pythagorean recursion
   $$E_n(d)=E_m(d)+\|x_n(d)-x_m(d)\|_H^2;\tag{8.3}$$
   $\{x_n(d)\}$ converges strongly to $x_\star\in\overline{\operatorname{span}\{u_i\}}$, the unique minimal-norm solution in the realization coset $x_\star+\{u_i\}^\perp$ ($\|x_\star\|_H^2=E_\infty:=\sup_n E_n(d)$), with squared approximation error
   $$\|x_\star - x_n(d)\|_H^2 = E_\infty - E_n(d).\tag{8.4}$$
   For any $\varepsilon>0$, the least index with $E_\infty-E_n(d)<\varepsilon^2$ defines the threshold stage $n_\varepsilon$ (`firstWithin`), and every $L\in\mathcal{B}(H,V)$ satisfies $\|L(x_\star)-L(x_n(d))\|_V\le\|L\|\sqrt{E_\infty-E_n(d)}$.

**Proof.** (Necessity) If $\langle u_i,x\rangle_H=d_i$ ($\forall i$), Proposition 7.1(2) gives $x_n(d)=P_{\operatorname{span}(u|_n)}x$, so $r_n(d)=0$ and $E_n(d)\le\|x\|_H^2<\infty$.
(Sufficiency) Assume (8.2) and set $E_\infty:=\sup_n E_n(d)<\infty$. For $m\le n$, $r_n(d)=0$ implies $\langle u_i,x_n(d)\rangle_H=d_i$ ($i<m$), so Proposition 7.1(2) gives $x_m(d)=P_{\operatorname{span}(u|_m)} x_n(d)$ and (8.3). Given $\varepsilon>0$, choose $N$ with $E_\infty-\varepsilon^2<E_N(d)$; then $\|x_n(d)-x_N(d)\|_H^2=E_n(d)-E_N(d)<\varepsilon^2$ for all $n\ge N$, so $\{x_n(d)\}$ is Cauchy and converges to $x_\star\in\overline{\operatorname{span}\{u_i\}}$. Taking $n\to\infty$ in $\langle u_i,x_n(d)\rangle_H=d_i$ ($n>i$) gives $\langle u_i,x_\star\rangle_H=d_i$. Any realization $x$ satisfies $x-x_\star\in\{u_i\}^\perp$, whence $\|x\|_H^2=\|x_\star\|_H^2+\|x-x_\star\|_H^2\ge\|x_\star\|_H^2$. Finally, $x_n(d)=P_{\operatorname{span}(u|_n)}x_\star\to x_\star$ yields $E_n(d)\uparrow\|x_\star\|_H^2=E_\infty$ and (8.4). $\square$

### 8.2 Closed-Subspace Projected Recovery and Bounded-Operator Stream Preimages (R62, R51)

<a id="prop-8-2"></a>

**Proposition 8.2 (R62: Closed-subspace projected-probe Gram recovery and refinement convergence, `ContactFibre.lean`).** Let $S\le H$ be a complete closed subspace of a complex inner-product space $H$ and $u:\iota\to H$ a finite ambient probe family. Set $\tilde u_i:=P_S(u_i)\in S$ and define $\mathcal{R}_{S,u}:\mathbb{C}^\iota\to S$ by projecting data to $(\ker G_{\tilde u})^\perp$ and then applying the synthesis in Proposition 7.1 inside $S$. Then for every $x\in S$:

1. **Ambient equation consistency and energy split**: $\hat x:=\mathcal{R}_{S,u}(\mathrm{rhs}_u(x))\in S$ satisfies $\langle u_i,\hat x\rangle_H=\langle u_i,x\rangle_H$ ($\forall i\in\iota$) and $\|x\|_H^2=\|\hat x\|_H^2+\|x-\hat x\|_H^2$;
2. **Non-increasing refinement error and strong convergence**: If $v:\kappa\to H$ contains $u$ via $e:\iota\to\kappa$ ($v_{e(i)}=u_i$), then $\|x-\mathcal{R}_{S,v}(\mathrm{rhs}_v(x))\|_H\le\|x-\mathcal{R}_{S,u}(\mathrm{rhs}_u(x))\|_H$; if $\{u_i\}_{i\in\mathbb{N}}$ separates $H$, then along any finite refinements $\{v^{(n)}\}$ retaining the $n$-th prefix, $\lim_{n\to\infty}\mathcal{R}_S(\mathrm{rhs}_{v^{(n)}}(x))=x$.

**Proof.** Self-adjointness of $P_S$ and $P_S x=x$ give $\langle \tilde u_i,x\rangle_H=\langle u_i,x\rangle_H$, so $\mathrm{rhs}_u(x)=\mathrm{rhs}_{\tilde u}(x)$. Applying Proposition 7.1(2) inside $S$ yields $\hat x=P^S_{\operatorname{span}(\tilde u)}x$, proving (1). Since $\operatorname{span}(\tilde u)\le\operatorname{span}(\tilde v)\le S$, orthogonal projection monotonicity gives non-increasing error, and separation of $H$ by $\{u_i\}$ implies separation of $S$ by $\{\tilde u_i\}$, giving strong convergence by Proposition 7.1(3). $\square$

<a id="cor-8-3"></a>

**Corollary 8.3 (R51: Bounded-operator stream preimage criterion and kernel-coset fibre, `ActionImage.lean`).** Let $H,F$ be complex Hilbert spaces, $A\in\mathcal{B}(H,F)$ a bounded linear operator (not assumed injective, surjective, or closed-range), and $\{v_i\}_{i\in\mathbb{N}}\subset F$ output probes with adjoint pullbacks $u_i:=A^* v_i\in H$.

1. **Action-stream criterion (`admitted_iff_action_image`)**: There exists $x\in H$ with $\langle v_i,Ax\rangle_F=d_i$ ($\forall i\in\mathbb{N}$) **if and only if** the pullback family $\{A^* v_i\}$ satisfies
   $$(\forall n\in\mathbb{N},\ r_n^{(A^*v)}(d)=0)\quad\wedge\quad \sup_{n\in\mathbb{N}} E_n^{(A^*v)}(d) < \infty;\tag{8.5}$$
2. **Preimage kernel coset (`complete_fibre`)**: When (8.5) holds and $\{v_i\}$ separates $F$, letting $x_\star\in H$ be the minimal-norm solution produced by Theorem 8.1 for $\{A^*v_i\}$, the full preimage set is
   $$\{x\in H : \forall i\in\mathbb{N},\ \langle v_i, Ax\rangle_F = d_i\} = x_\star + \ker A.\tag{8.6}$$

**Proof.** Apply Theorem 8.1 via $\langle A^* v_i, x\rangle_H = \langle v_i, Ax\rangle_F$; when $\{v_i\}$ separates $F$, $(\forall i,\langle v_i,Ax\rangle_F=d_i)\iff Ax=Ax_\star\iff x-x_\star\in\ker A$. $\square$

![Figure 4 | Hilbert prefix energy, the two-sided Cayley inverse, and truncation errors](figures/fig4-hilbert-cayley-en.svg)

**Figure 4 | Hilbert prefix energy, the two-sided Cayley inverse, and truncation errors.** The upper left compares two zero-residual Hilbert streams and marks the squared error for the convergent stream (Theorem 8.1). The upper right plots the Jordan example at $\delta=1$ and gives the equality construction for every $\delta>0$. The lower panel derives the Cayley inverse by damping, two-sided telescoping, and passage to the limit, then bounds observation noise and the truncation tail (Theorem 8.4).

### 8.3 Explicit Banach Operator Inverses and Uniform Truncation Budgets under Linear Cayley Growth (R52, R61)

Let $A$ belong to a unital complete complex Banach algebra $\mathcal{A}$. When $C_\delta(A):=1+\delta A$ ($\delta>0$) obeys the linear power-growth bound $\|(1+\delta A)^n\|\le(n+1)B$, $C_\delta(A)$ has spectral radius at most $1$, placing $\sigma(A)\subseteq\overline{D}(-1/\delta,1/\delta)$ away from $1$; invertibility of $A-1$ thus follows immediately from spectrum location, even though $C_\delta(A)$ need not satisfy $\|C_\delta(A)\|<1$ or power-boundedness. Theorem 8.4 constructs $(A-1)^{-1}$ directly as an absolutely convergent damped series without spectral decomposition, proves that the upper bound $(1+\delta)B/\delta$ is reachable, and establishes a truncation error budget whose noise amplification factor is bounded by $M_{\delta,B}$ independently of the truncation order $m$.

<a id="thm-8-4"></a>

**Theorem 8.4 (R52, R61: Explicit two-sided inverse of $A-1$, reachable norm bound, and step-independent truncation budget under linear Cayley growth, `CayleyEffectInverse`).** Let $\mathcal{A}$ be a unital complete complex Banach algebra and $A\in\mathcal{A}$. Suppose there exist $\delta>0$ and $B\ge 0$ such that $C_\delta(A):=1+\delta A$ satisfies
$$\forall n\in\mathbb{N},\qquad \bigl\|(1+\delta A)^n\bigr\|\le (n+1)B,\tag{8.7}$$
and set $q:=(1+\delta)^{-1}\in(0,1)$ and $K_\delta(A):=q\,C_\delta(A)\in\mathcal{A}$. Then:

1. **Explicit two-sided inverse and reachable norm bound (R52)**: The series
   $$\mathcal{I}_\delta(A) := -\delta q\sum_{n=0}^{\infty} K_\delta(A)^n = -\frac{\delta}{1+\delta}\sum_{n=0}^{\infty}(1+\delta)^{-n}(1+\delta A)^n\tag{8.8}$$
   converges absolutely in $\mathcal{A}$, gives the two-sided inverse of $A-1$, and obeys the reachable bound (attained for every $\delta>0$ at $B=1$ in Example 1.1(e)):
   $$\mathcal{I}_\delta(A)(A-1) = (A-1)\mathcal{I}_\delta(A) = 1,\qquad \|\mathcal{I}_\delta(A)\| \le M_{\delta,B} := \frac{\delta q B}{(1-q)^2} = \frac{1+\delta}{\delta}B;\tag{8.9}$$
2. **Isometric source control (R61)**: When $\mathcal{A}=\mathcal{B}(H)$ on a complex Banach space $H$ and $C_\delta(A)$ is isometric ($\|C_\delta(A)x\|=\|x\|,\ B=1$), $\|x\|\le\|(A-1)x\|$ for all $x\in H$, and $F_{\delta,m}(A):=-\delta q\sum_{k=0}^{m-1}K_\delta(A)^k$ satisfies $\|F_{\delta,m}(A)(A-1)x-x\|\le q^m\|(A-1)x\|$;
3. **Step-independent noisy truncation budget under linear growth (R61)**: When $\mathcal{A}=\mathcal{B}(H)$ on a complete complex Banach space $H$ satisfying (8.7), for every $m\in\mathbb{N}$, exact right-hand side $y\in H$, and noisy datum $\tilde y\in H$, $F_{\delta,m}(A)y=\mathcal{I}_\delta(A)y-K_\delta(A)^m\mathcal{I}_\delta(A)y$ and $\|F_{\delta,m}(A)\|\le M_{\delta,B}$ independently of $m$ (Remark C.2), yielding
   $$\bigl\|F_{\delta,m}(A)\tilde y - (A-1)^{-1}y\bigr\| \le M_{\delta,B}\|y-\tilde y\| + B(m+1)q^m M_{\delta,B}\|y\|,\tag{8.10}$$
   with $(m+1)q^m\to 0$ as $m\to\infty$, so $F_{\delta,m}(A)\tilde y\to (A-1)^{-1}y$ as $m\to\infty$ and $\|y-\tilde y\|\to 0$.

**Proof.** (1) Since $\delta q = 1-q$, $-\delta q(A-1) = (1-q)-q\delta A = 1-K_\delta(A)$. By (8.7), $\|K_\delta(A)^n\|\le B(n+1)q^n$, whose sum over $n\ge 0$ equals $B(1-q)^{-2}<\infty$ as $q\in(0,1)$. Completeness of $\mathcal{A}$ and commutativity of $A-1$ with $K_\delta(A)$ give two-sided inversion and $\delta q B/(1-q)^2=(1+\delta)B/\delta$.
(2) Under isometry, $-\delta q(A-1)x=x-K_\delta(A)x$ gives $\delta q\|(A-1)x\|\ge(1-q)\|x\|=\delta q\|x\|$, while $F_{\delta,m}(A)(A-1)=1-K_\delta(A)^m$ yields the geometric bound.
(3) Applying $F_{\delta,m}(A)(A-1)=1-K_\delta(A)^m$ to $\mathcal{I}_\delta(A)y$ gives the tail identity; nonnegativity of terms yields $\|F_{\delta,m}(A)\|\le \delta q\sum_{k=0}^{m-1}B(k+1)q^k\le M_{\delta,B}$, and the triangle inequality gives (8.10). $\square$

<a id="ex-8-1"></a>

**Example 8.1 (Finite truncation check on the $2\times 2$ Jordan block).** Specializing Example 1.1(e) to $\delta=1$ gives $A_1=J$, $q=1/2$, $B=1$, and $M_{1,1}=2$. The $m$-step truncation $F_{1,m}(A)=-\frac12\sum_{k=0}^{m-1}2^{-k}\bigl(\begin{smallmatrix}1&k\\0&1\end{smallmatrix}\bigr)$ has $\ell^1$ operator norm $2-(m+2)2^{-m} < 2 = M_{1,1}$ and exact error norm $(m+2)2^{-m} \le 2(m+1)2^{-m} = B(m+1)q^m M_{1,1}$ for all $m\ge 1$.

---

<a id="sec-9"></a>

## 9 Five-Axis Literature Dialogue and Cross-Domain Interfaces

Table 2 and the five subsections below position our results against 41 verified primary sources, separating classical foundations and formal interface wrappers from new explicit criteria and sharp constants.

**Table 2. Positioning across five primary-literature axes**

| Technical axis | Key primary references | Prior scope | Scope and contribution in this work |
| --- | --- | --- | --- |
| **Axis I: Characters & inverse limits** | Pontryagin [@Pontryagin1934]; Baer [@Baer1940]; Lambek [@Lambek1964]; Milnor [@Milnor1962]; Weibel [@Weibel1994]; Jannsen [@Jannsen1988] | Locally compact topological biduals; divisible injectivity; $\varprojlim^1$ & Mittag-Leffler; continuous cohomology torsion obstructions | Credits Baer injectivity and restricts isomorphism to the evaluation image $P_{\chi,R}(A)$ without topology; proves three-tier Kummer limit properties and the $(n+1)!$ balanced-lift jump criterion |
| **Axis II: Picard lines & det interfaces** | Knudsen–Mumford [@KnudsenMumford1976]; Deligne [@Deligne1987]; Stacks `0FJ9` [@Stacks0FJ9]; Tate [@Tate1966]; Nekovář [@Nekovar2006]; Macias Castillo–Sano [@MaciasCastilloSano2026] | Determinant functors on perfect complexes; virtual categories; clopen rank patching; Selmer complexes & heights | Links the nonfree ideal $(1,0)$ on $y^2=x^3-x$ (building on `mathlib`) to stalk-rank dispatch, and packages dual-lattice, Smith-index, gluing, four-term free, and limit-cone constructions as basis-free interfaces |
| **Axis III: Syzygies & signed sparse moments** | Green et al. [@Green2007Provenance]; Cai et al. [@Cai2014Changes]; DBSP [@Budiu2023DBSP]; Ellerman [@Ellerman2014Accounting]; Kálmán [@Kalman1963]; Prony [@Prony1795]; Kronecker [@Kronecker1881]; Ben-Or–Tiwari [@BenOrTiwari1988]; Candès–Fernandez-Granda [@CandesFernandezGranda2014] | Provenance semirings; $\mathbb{Z}$-sets & difference groups; linear unobservable subspaces; sparse interpolation & minimum-separation super-resolution | Formalizes module-theoretic unobservable submodules and constructive constant-table syzygy presentations; proves and machine-checks arbitrary-field (including $\operatorname{char} K>0$) $2k$-moment recovery on finite candidate sets under lower-order cancellation |
| **Axis IV: Stream preimages & Cayley inverses** | Schur [@Schur1917]; Penrose [@Penrose1955]; F. Riesz [@Riesz1910]; Aronszajn [@Aronszajn1950]; Douglas [@Douglas1966]; Adcock–Hansen [@AdcockHansen2016]; Kreiss [@Kreiss1962]; Katznelson–Tzafriri [@KatznelsonTzafriri1986] | Generalized inverses & Schur complements; bounded moment criteria & RKHS; operator range inclusion; oblique generalized sampling; Kreiss & power-bounded operators | Gives constructive singular-probe prefix limits and exact energy-gap identity; contrasts projected-probe orthogonal recovery with oblique sampling; establishes explicit series, reachable constant $(1+\delta)B/\delta$, and step-independent truncation bounds under linear Cayley growth |
| **Axis V: Formalized mathematics & specs** | de Moura–Ullrich [@deMouraUllrich2021Lean4]; mathlib [@mathlib2020]; Angdinata–Xu [@AngdinataXu2023]; Buzzard et al. [@BuzzardCommelinMassot2020]; Commelin–Topaz [@CommelinTopaz2024] | Lean 4 kernel & mathlib; Weierstrass curve group law; completions & spec-driven abstraction boundaries | Unifies module theory, inverse-limit homology, arbitrary-field sparse algebra, and Hilbert/Banach operator bounds within one three-axiom type boundary while isolating basis-free interfaces from coordinate choices |

### 9.1 Axis I: From Pontryagin, Baer, and Jannsen to Evaluation Images and Factorial Jumps

Pontryagin’s biduality [@Pontryagin1934] relies on restricting to continuous characters on locally compact groups; algebraically, even $\mathbb{Z}^{\vee\vee}_\chi\cong\widehat{\mathbb{Z}}$ strictly contains $\mathbb{Z}$. Building on Baer’s divisible injectivity [@Baer1940; @Stacks01D6] and Lambek’s character modules [@Lambek1964], Proposition 2.1 corestricts onto the evaluation image $P_{\chi,R}(A)$ and contrasts it with $\mathbb{Z}$-linear blindness on $(\mathbb{Z}/2\mathbb{Z})^2$. For inverse limits, against the backdrop of Milnor [@Milnor1962], Weibel [@Weibel1994] (Section 3.5), and Jannsen’s analysis of unbounded $p^\infty$-torsion [@Jannsen1988], Theorem 2.5 (R54) separates ambient $p$-divisibility (limit surjection), bounded $p^d$-torsion on $L$ (ambient injection and kernel exactness), and unique $p$-divisibility ($\widehat{L}_p\simeq T_p(M/L)$), while Theorem 2.7 (R57–R58) uses half-open balanced representatives modulo $(n+1)!$ to characterize integral descent via eventual stabilization versus cofinal modulus jumps.

### 9.2 Axis II: From Knudsen–Mumford and Deligne to Basis-Free Algebraic Interfaces

Knudsen–Mumford [@KnudsenMumford1976] and Deligne [@Deligne1987] established determinant functors and quasi-isomorphism invariance for perfect complexes, while Stacks Tag `0FJ9` [@Stacks0FJ9] constructs patched determinants across clopen rank decompositions. Sections 3–4 have a more specific scope: Propositions 3.1–3.2 connect the nonfree ideal at $(1,0)\in E(\mathbb{Q})$ (combining an elementary norm-degree proof with `mathlib`’s Weierstrass class-group formalization [@AngdinataXu2023; @mathlib2020]) to constant-rank dispatch, while Propositions 4.1–4.5 package dual-lattice pairings, Smith cokernel indices, short-exact gluing, four-term free alternating lines, and inverse-limit cones — motivated by arithmetic height and lattice-index formalisms [@Tate1966; @Nekovar2006; @MaciasCastilloSano2026] — as basis-deferred interfaces following spec-driven design [@CommelinTopaz2024] (covering termwise isomorphism transport on four-term complexes rather than general quasi-isomorphism invariance).

### 9.3 Axis III: From Unobservable Subspaces, Difference Groups, and Prony to Syzygies and Arbitrary-Field Order Locking

In dynamical systems and incremental computation, the word-readout kernel $\ker\mathcal{I}\le\ker e$ in Proposition 5.3(2) (R24–R25) generalizes Kálmán’s unobservable subspace [@Kalman1963] to modules over arbitrary commutative rings under families of endomorphisms; relative to provenance semirings [@Green2007Provenance], static change structures [@Cai2014Changes], DBSP $\mathbb{Z}$-sets [@Budiu2023DBSP], and Ellerman’s difference groups [@Ellerman2014Accounting], Proposition 6.1 (R43) gives a constructive syzygy decomposition for the exact presentation $\operatorname{im}(\mathrm{rel}_G)=\ker(\mathrm{freeEval})$. For sparse recovery, Hankel rank determination originates with Prony [@Prony1795], Kronecker [@Kronecker1881], and Ben-Or–Tiwari [@BenOrTiwari1988] (with operator extensions in Peter–Plonka [@PeterPlonka2013] and continuum noisy super-resolution under minimum separation in Candès–Fernandez-Granda [@CandesFernandezGranda2014]). Theorem 6.2 (R49) addresses exact discrete algebraic recovery on a given finite candidate set, providing an end-to-end formalized proof over **arbitrary fields $K$ (including positive characteristic)** when $r\le k$ is unknown and lower leading blocks vanish by cancellation.

### 9.4 Axis IV: From F. Riesz, RKHS, and Generalized Sampling to Singular Streams and Reachable Cayley Constants

Boundedness criteria for infinite linear moment systems go back to F. Riesz [@Riesz1910] and reproducing-kernel quadratic forms (Aronszajn [@Aronszajn1950]), alongside finite-dimensional generalized inverses and Schur complements [@Penrose1955; @Schur1917]. Theorem 8.1 (R50) instantiates this principle constructively for arbitrary linearly dependent probe streams via singular-Gram prefix projections, yielding strong convergence to the minimal-norm preimage, the exact energy-gap identity $\|x_\star-x_n\|^2=E_\infty-E_n$, and bounded-operator preimage cosets via adjoint pullback (Corollary 8.3, complementing Douglas’s operator range theorem [@Douglas1966]). In subspace recovery, Adcock–Hansen [@AdcockHansen2016] study prescribed reconstruction spaces and stable sampling rates that bound the restricted sampling operator from below. Proposition 8.2 (R62) starts from the orthogonal projector $P_S$ onto $S\le H$ and reconstructs directly inside $\operatorname{span}(P_S u_i)\le S$, which is an orthogonal projection by construction and hence monotonically non-increasing in error under probe refinement. Finally, alongside von Neumann’s fractional Cayley transform [@vonNeumann1930], Kreiss’s resolvent condition [@Kreiss1962], and power-bounded operator theory [@KatznelsonTzafriri1986], Theorem 8.4 (R52, R61) gives an explicit damped series under first-order linear growth $\|(1+\delta A)^n\|\le(n+1)B$ without spectral decomposition, proves reachability of the norm constant $(1+\delta)B/\delta$ on a $2\times 2$ Jordan block, and bounds the truncation noise amplification factor uniformly by $M_{\delta,B}$ independently of step $m$.

### 9.5 Axis V: Formal Architecture and Cross-Domain Interface Reuse

Built in Lean 4 [@deMouraUllrich2021Lean4] on `mathlib` [@mathlib2020; @AngdinataXu2023] (drawing on formalization patterns for completions and abstraction boundaries [@BuzzardCommelinMassot2020; @CommelinTopaz2024] and upstream foundations [@Gao2026OneBitV2; @Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2]), all results in this paper are parameterized over general commutative rings, arbitrary fields, or abstract Hilbert and Banach spaces. Consequently, they serve as reusable mathematical interfaces in companion studies across three settings: (i) using joint coimages (Proposition 2.3(2)) to retain torsion classes invisible to scalarized readouts and Theorem 6.2 to invert discrete pulse moments; (ii) using singular Gram convergence (Proposition 7.1), stream preimage criteria (Theorem 8.1), closed-subspace projected recovery (Proposition 8.2), and linear-growth difference inverses (Theorem 8.4) to reconstruct closed operator graphs and resolvent differences; and (iii) using the dual-lattice, Smith-index, and four-term alternating determinant-line interfaces (Propositions 4.1–4.5) to organize height pairings and integral cohomological determinants prior to basis selection.

---

## Appendix A Supplementary Proofs for Kummer Towers, Balanced Representatives, and Four-Term Complexes

<a id="app-a-1"></a>

**Lemma A.1 (Shifted lift alignment under bounded source torsion).** Let $\iota:L\to_{\mathbb{Z}} M$ be injective, $C=M/\operatorname{im}\iota$, and suppose $d\in\mathbb{N}$ satisfies $\forall j,\forall y\in L[p^{j+1}],\ p^d y=0$. If $r_j,\tilde r_j\in M[p^{j+1}]$ have equal classes in $C$, then $p^d r_{j+d}=p^d\tilde r_{j+d}$ for all $j\in\mathbb{N}$.

**Proof.** From $\pi_C(r_{j+d}-\tilde r_{j+d})=0$ there is $y\in L$ with $\iota(y)=r_{j+d}-\tilde r_{j+d}$. Multiplying by $p^{j+d+1}$ gives $\iota(p^{j+d+1}y)=0$, so injectivity of $\iota$ places $y\in L[p^{j+d+1}]$; hence $p^d y=0$, and applying $\iota$ yields $p^d r_{j+d}=p^d\tilde r_{j+d}$. $\square$

<a id="app-a-2"></a>

**Proposition A.2 (Uniqueness and stabilization threshold of factorial balanced representatives).** For $\phi:L\xrightarrow{\sim}\mathbb{Z}$ and $M_n=(n+1)!$, the half-open interval $[-\lfloor M_n/2\rfloor,\ M_n-\lfloor M_n/2\rfloor)$ contains $M_n$ consecutive integers, so each residue class $v_n\in L/M_n L$ has a unique representative $b_n(v)$ therein. For fixed $s\in L$ and $N:=2|\phi(s)|+2$, every $n\ge N$ satisfies $(n+1)!\ge n+1 > 2|\phi(s)|$, placing $s$ inside the interval and forcing $b_n(\iota_!(s))=s$.

**Proof.** Two integers congruent modulo $M_n$ in a half-open interval of length $M_n$ differ by less than $M_n$ in absolute value and hence coincide; the threshold follows from $n+1\le(n+1)!$ and $\lfloor M_n/2\rfloor\ge(M_n-1)/2$. $\square$

<a id="app-a-3"></a>

**Proposition A.3 (Rank-one freeness and isomorphism transport of four-term alternating determinant lines).** Under Proposition 4.4, $\det_{\mathbb{Z}}(C^\bullet)$ is a free $\mathbb{Z}$-module of rank $1$ whose two generators form a $\{\pm 1\}$-torsor, and the even-covariant, odd-contragredient rule commutes covariantly with composition of termwise cochain isomorphisms.

**Proof.** Choosing auxiliary integral bases on the finite free modules $C_i$ (solely to verify existence, not stored in $\det_{\mathbb{Z}}(C^\bullet)$) identifies each $\det_{\mathbb{Z}}(C_i)$ and its dual with $\mathbb{Z}$, so $\det_{\mathbb{Z}}(C^\bullet)\cong\mathbb{Z}^{\otimes 4}\cong\mathbb{Z}$ with unit group $\mathbb{Z}^\times=\{\pm 1\}$. On odd degrees, contragredient inversion satisfies $((f\circ e)^{-1})^\vee = (e^{-1}\circ f^{-1})^\vee = (f^{-1})^\vee\circ(e^{-1})^\vee$, preserving covariant composition. $\square$

---

## Appendix B Index of R1–R62, Determinant Interfaces, and Lean 4 Declarations

### B.1 Source Paths, Commit Epochs, and Text Locations for R1–R62

Pinned commits in the research repository `Homework` by batch are: `e60a86058a` (`R1–R8`), `eec031c489` (`R9–R13`), `453de27572` (`R14–R17`), `c19e94a5e0` (`R18–R19`), `fde5c14df3` (`R20–R23`), `aef0ad2a26` (`R24–R27`), `26b91feb6b` (`R28–R31`), `e055580972` (`R32–R33`), `c62f3d25c4` (`R34–R35`), `71e94e8261` (`R36–R37`), `9c73a630ce` (`R38–R39`), `ba7e274beb` (`R40–R42`), `df421ff600` (`R43–R45` and Interfaces I–V), `7e4da746f3` (`R46–R48`), `3a90cba5ac` (`R49–R50`), `11a0142465` (`R51`), `1abd7da932` (`R52`), and `f94092efb4` (`R53–R62`).

Path-prefix shorthand: `GF/` = `Lean/SaturationMonoid/GenericFoundation/`; `SM/` = `Lean/SaturationMonoid/`; `W/` = `GF/Operations/Inquiry/Context/Faces/Execution/Activation/Receipt/Configured/Writeback/Successor/FourFace/Native/Source/Word/`; `PG/` = `SM/NoIslandNoMagic/CanonicalRiemann/GeneralizedDual/CoPoissonEnergy/Muntz/Cokernel/CenteredGram/JointAction/Runtime/` (note: `PG/` retains historical research-directory names; the declarations used here depend solely on general module and inner-product definitions). The accompanying [public module index](https://github.com/Sapientropic/H0mework/blob/ccf469d177d0cff2cefbb162b4f5ab7891a83b25/docs/exact-realization-map.json) gives the public targets and their build scope.

| ID | Mathematical content & scope | Source entry & declarations | Section |
| --- | --- | --- | --- |
| **R1** | Character bidual image isomorphism & naturality; $(\mathbb{Z}/2\mathbb{Z})^2$ torsion separation | `GF/Scalar/Character/Exact.lean` (`equiv`, `factor_unique`); `GF/Operations/Runtime/Regression/Character.lean` | §2.1 Prop. 2.1; Ex. 1.1(a); Fig. 2 |
| **R2** | Abelian relative coimage $C/\ker e$ injection & $\ker e\le\ker f$ criterion | `GF/LivingLawRootGeneratedSourcePerfectificationKernel.lean` (`dualEmbedding_injective`, `canonicalMap_universal`) | §2.2 Prop. 2.2(1) |
| **R3** | Coherent stage-tower inverse limits, cokernel towers & naturality | `GF/Scalar/Cofinal/LivingLawRootGeneratedScalarCofinalExactEnvelopeKernel.lean` (`completion_universal_property`); `SM/LivingLawRootGeneratedCofinalCoverageResidualTowerKernel.lean` (`completionResidualToResidualLimit_injective`); `GF/LivingLawRootGeneratedDependentCofinalProfileNaturalityKernel.lean` | §2.2 Prop. 2.2(1) |
| **R4** | Four-way witness classification of linear maps (bijective / kernel / coverage / both) | `GF/Scalar/Observation/LivingLawRootGeneratedScalarObservationDispositionKernel.lean` (`settle`, `settle_exact_iff_bijective`, `settle_eq_kernelAndCoverage_of_neither`) | §2.2 Prop. 2.2(3); Fig. 2 |
| **R5** | Finite projective tensor duality, stalk-rank dispatch & Picard frame torsors | `GF/Scalar/Bounded/LivingLawRootGeneratedScalarBoundedObservationDispositionKernel.lean`; `GF/Scalar/Determinant/LivingLawRootGeneratedScalarProjectiveDeterminantDispositionKernel.lean` (`settle`, `settle_constant_of_constantRank`) | §3.1 Prop. 3.1; Fig. 2 |
| **R6** | Nonfree rank-1 invertible ideal of $(1,0)$ on $y^2=x^3-x$ | `GF/Scalar/Determinant/LivingLawRootGeneratedScalarNontrivialPicardLineRegression.lean` (`rationalPointPic_not_free`, `rationalPicClass_ne_one`, `rationalPicLine_settles_projectiveNonfree`) | §3.2 Prop. 3.2; Ex. 1.1(c) |
| **R7** | Point-observation tower $\simeq\mathbb{Z}[S]$ & three-term bilinear expansion | `GF/Probability/Source/Full/Word.lean` (`equivalence`, `word_action`); `GF/Probability/Source/Full/Binary.lean` (`binary_mixed_update`, `pushJoint`) | §5.1 Prop. 5.1(1) |
| **R8** | Free linearization of maps, defect derivation law & equivariance criterion | `GF/Probability/Source/Full/Map.lean` (`map_comp`); `GF/Probability/Source/Full/Defect.lean` (`defect_comp`, `defect_zero_iff`) | §5.1 Prop. 5.1(2) |
| **R9** | Same-root evaluation projections, single-basis readout & separator controls | `SM/LivingLawRootGeneratedCofinalHistorySettlementFaceKernel.lean`; `SM/LivingLawRootGeneratedCofinalFaithfulSettlementFaceKernel.lean`; `GF/LivingLawRootGeneratedCofinalDualityTransportKernel.lean` | §2.2, §5.2 |
| **R10** | Two-term relation complex ($d^2=0$) & relation-quotient zero criterion | `GF/Cofinal/LivingLawRootGeneratedCofinalRelationComplexKernel.lean` (`completion_zero_iff_generated_boundary`, `ofHistoryCommonLaw`) | §2.2 Prop. 2.2(2) |
| **R11** | All-prime-power pullback uniformity kernel $\bigcap_{p,n}p^{n+1}L$ | `GF/Cofinal/Topology/LivingLawRootGeneratedCofinalAllPrimeTopologyKernel.lean` (`allPrimeKernel_iff`, `source_inseparable_zero_iff_kernel`) | §2.3 Prop. 2.3(1) |
| **R12** | Unique joint-coimage $C/(\ker f\cap\ker g)$ recovery of single-family kernel elements | `SM/DomainConsumers/CanonicalArithmetic/Relation/NativeReceiptJointConsumerCoimage.lean` (`joint_kernel_exact`, `jointToIntegral_unique`, `original_class_joint_nonzero`) | §2.3 Prop. 2.3(2); §9.5 |
| **R13** | Graded relation-quotient shift transport & nonzero tail-truncation residuals | `PG/JointRelation/ClozelPairedOmegaJointRelationShiftAction.lean`; `PG/JointRelation/ClozelPairedOmegaJointRelationNativeNextTransition.lean`; `PG/JointRelation/ClozelPairedOmegaJointRelationNativeNextReverseReadback.lean` | §2.2 Prop. 2.2(2) |
| **R14** | Cofinal four-face unfolding & relation-quotient descent of word evaluations | `GF/Occurrence/Realization/Raw/CofinalAction.lean`; `GF/Occurrence/Realization/Raw/CofinalActionCochain.lean` (`generated_differential_descent_iff`); `GF/Occurrence/Realization/Raw/CofinalActionFullFourFace.lean` | §2.3 Prop. 2.3(3) |
| **R15** | Product-pairing kernel as image annihilator; equality with evaluation kernel on reduced rings | `GF/Occurrence/Realization/Raw/CofinalActionValuePairing.lean` (`valuePairing_fibre_iff_annihilator`, `valuePairingRangeRecovery_actual`) | §2.3 Prop. 2.3(3) |
| **R16–R17** | Quotient descent of product pairings & generated $V$-submodule recovery on reduced rings | `GF/Occurrence/Realization/Raw/CofinalActionValuePairingDescent.lean` (`valuePairing_descent_iff_annihilator`, `valuePairing_descent_iff_evaluator_descent`); `GF/Occurrence/Realization/Raw/CofinalActionValueScalarCoimage.lean` (`valueWordCoimageRecovery`) | §2.3 Prop. 2.3(3) |
| **R18–R19** | Substitution relation transport & representative-free kernel-quotient isomorphism | `GF/Operations/Native/Substitution/Source.lean`; `GF/Operations/Runtime/Fibre/Recovery.lean` (`residualEquiv`, `recover_injective`, `recover_balanced`) | §5.2 Props 5.2(3), 5.3(1) |
| **R20–R23** | Evaluation-free syntactic tree left inverse ($\kappa\equiv 0$ injective) & step-count induction | `GF/Operations/Native/Tree/Fold/Inverse.lean` (`read_program`, `program_injective`); `GF/Operations/Execution/Substitution/Source.lean` | §5.2 Props 5.2(1), 5.2(3) |
| **R24–R27** | Module-theoretic unobservable invariant submodule, zero-kernel isomorphism & fiber-constrained preimages | `GF/Operations/Observed/Words/Kernel.lean` (`common_invariant_is_retained`); `GF/Operations/Observed/Words/Model.lean`; `GF/Operations/Native/Tree/Fold/Dependent/Joint/TargetDifference.lean` (`fibre_preimage_exact`) | §5.2 Prop. 5.3(2)–(3) |
| **R28–R42, R45** | Finite word duals, linear differences, zero-evaluation congruences & splicing | `GF/Operations/Inquiry/Context/Faces/Execution/Activation/Receipt/Inventory/Born/Vector/Fibre/Source.lean`; `GF/Operations/Native/CompleteWordDual.lean`; `GF/Operations/Inquiry/Cofinal/Native/Installed/Cofinal/Action/Common/RootConsumer/Semantics.lean`; `W/Reentry/Splice.lean` | §5.2 Prop. 5.3(2), Rem. 5.1 |
| **R43** | Exact syzygy presentation $\operatorname{im}(\mathrm{rel}_G)=\ker(\mathrm{freeEval})$ & certificate split | `W/ConstantTransport.lean` (`constant_update`, `computed_after`); `W/ConstantInverse.lean` (`actualCertificate`, `restored_next_constants`); `GF/Scalar/Relations/FiniteTableCertificate.lean` (`finiteTableCertificate_read`, `relationRange_eq_kernel`), proof extension at `339ab2a4c2` | §6.1 Prop. 6.1; Ex. 6.1 |
| **R44** | Singular finite Hermitian Gram solution cosets & orthogonal projection synthesis | `GF/Scalar/Feature/FiniteGram.lean` (`full_fibre`, `source_effect_of_equation`); `GF/Scalar/Feature/FiniteGram/Projection.lean` (`kernel_synthesis`, `predictable_readback`, `innovationCLM`) | §7.1 Prop. 7.1(1)–(2) |
| **R46** | Directed-net & prefix strong convergence of singular Gram projections | `GF/Scalar/Feature/FiniteGram/PrefixReadback.lean` (`inverse_tendsto`); `GF/Scalar/Feature/FiniteGram/DirectedReadback.lean` (`inverse_tendsto_finset`) | §7.1 Prop. 7.1(3); §9.4 |
| **R47** | Commutative-ring Schur border update & tail-independent first-pivot decoding | `GF/Scalar/Feature/FiniteGram/MatrixBorder.lean` (`border_det`, `borderInverse`); `GF/Scalar/Feature/FiniteGram/CofinalInsertion.lean` (`decode_insert_exact`); `GF/Scalar/Feature/FiniteGram/CofinalRecord.lean` (`pivotTime`, `schedule_read_insert`) | §7.2 Prop. 7.2 |
| **R48** | Commutation of orthogonal projection/complement splitting with downstream maps | `PG/Feedback/ClozelOriginalKFiniteOrderRelease/GammaSource/PositionGap/FullStock.lean` (`actual_stock_source_step`); `PG/Feedback/ClozelOriginalKFiniteOrderRelease/GammaSource/PositionGap/RelationInventory.lean` | §7.1 Prop. 7.1(2) |
| **R49** | Arbitrary-field unknown-$k$-sparse $2k$-moment recovery on finite candidate sets via max nonsingular block | `GF/Scalar/Feature/FiniteGram/SparseMoment.lean` (`hankel_factor`, `order_from_source`, `recover_support`, `recover_prefix`) | §6.2 Thm 6.2; Ex. 1.1(d), 6.2; Fig. 3 |
| **R50** | Singular-probe Hilbert stream preimage criterion & energy-gap identity $\|x_\star-x_n\|^2=E_\infty-E_n$ | `GF/Scalar/Feature/FiniteGram/PrefixImage.lean` (`admitted_iff_image`, `realize_captured`); `GF/Scalar/Feature/FiniteGram/PrefixImage/PrefixEnergy.lean` (`error_squared`, `first_within`, `output_bound`) | §8.1 Thm 8.1; Ex. 1.1(e); Fig. 4 |
| **R51** | Bounded-operator adjoint-pullback $A^*v_i$ stream criterion & coset $x_\star+\ker A$ | `GF/Scalar/Feature/FiniteGram/PrefixImage/ActionImage.lean` (`admitted_iff_action_image`, `forward_equation`, `complete_fibre`, `inverse_capture`) | §8.2 Cor. 8.3 |
| **R52** | Explicit Banach two-sided inverse of $A-1$ & reachable constant under linear Cayley growth | `GF/Operations/Observed/Operator/CayleyEffectInverse.lean` (`inverse`, `inverse_effect`, `inverse_norm`); `GF/Operations/Observed/Operator/CayleyEffectInverse/Sharpness.lean` (`jordan_cayley_power_norm`, `jordan_inverse_attains`), proof extension at `ce917c1cf9` | §8.3 Thm 8.4(1); Ex. 1.1(e); Fig. 4 |
| **R53** | Uniform continuity, split retractions & bilinear lifts on all-prime completions | `GF/Cofinal/Topology/Successor.lean`; `GF/Cofinal/Topology/SplitAction.lean`; `GF/Cofinal/Topology/Bilinear/Completion.lean` | §2.4 Lem. 2.4 |
| **R54** | Three-tier Kummer cokernel-torsion limit properties (surjection / bounded-torsion exactness / isomorphism) | `GF/Cofinal/Topology/CokernelTorsion/{CoherentLift,CoherentKernel,CoherentEquivalence}.lean` (`cokernel_connecting_limit_surjective`, `ambient_to_cokernel_limit_injective_of_bounded`, `cokernel_connecting_limit_kernel_of_bounded`, `cokernelCompletionEquiv`) | §2.4 Thm 2.5; App. A.1 |
| **R55** | Direct-sum splitting & continuation homotopy equivalence of path complexes | `GF/Operations/Execution/Relations/History/Payment/{Closure,Completion}.lean`; `GF/Cofinal/Topology/Operations/Closure/Continuation/Cochain/Derived.lean` (`continuation_derived_zero`) | §2.4 Lem. 2.6(1) |
| **R56** | Quasi-isomorphism from prime-power cochain limits to mapping-cocone homotopy limits | `GF/Cofinal/Topology/Cochain/{DerivedLimit,DerivedNaturality}.lean` (`cochain_derived_limit_quasiIso`); `GF/Cofinal/Topology/Operations/Closure/Continuation/Cochain/Cohomology.lean` (`paidObservedCohomologyIso`) | §2.4 Lem. 2.6(1)–(2) |
| **R57** | Chinese-remainder isomorphism between all-prime and factorial completions | `GF/Cofinal/Topology/FiniteModulus/{Factorization,Completion}.lean`; `GF/Cofinal/Topology/FiniteModulus/Factorial/Equivalence.lean` (`factorialCompletionEquiv`); `GF/Cofinal/Topology/FiniteModulus/Factorial/Cochain/Homology.lean` | §2.5 Thm 2.7(1) |
| **R58** | Factorial modulus $(n+1)!$ balanced-representative stabilization & cofinal jump criterion | `GF/Cofinal/Topology/FiniteModulus/Factorial/Integral/{Bounded,Representative,EffectJump}.lean` (`factorial_integral_source_iff`, `factorial_small_effect_recovers_source`, `factorial_nonintegral_effect_jumps`) | §2.5 Thm 2.7(2); Ex. 1.1(b); Fig. 2 |
| **R59** | Rank-one biorthogonal dual-column update & coefficient readout under column insertion | `GF/Scalar/Feature/FiniteGram/Projection/DualColumn/Insert.lean` (`dualColumn_snoc_last`, `dualColumn_snoc_castSucc`, `coefficients_snoc_read`) | §7.2 Prop. 7.3; Ex. 7.1 |
| **R60** | Additive-context two-term path cochain map & incremental boundary preservation | `GF/Operations/Execution/Relations/History/Payment/LinearCochain.lean` (`linearCochain`, `linear_differential`, `linear_boundary_effect`) | §5.2 Prop. 5.2(2) |
| **R61** | $m$-step Cayley truncation residuals, isometric source bound & step-independent noise budget | `GF/Operations/Observed/Operator/CayleyEffectInverse/{Finite,FiniteGrowth}.lean` (`source_norm_le_effect`, `finite_error`, `finite_tendsto`, `finite_growth_error`, `finite_noisy_error`, `linear_retention_tendsto`) | §8.3 Thm 8.4(2)–(3); Ex. 8.1 |
| **R62** | Closed-subspace projected-probe singular Gram recovery & refinement convergence | `GF/Scalar/Feature/FiniteGram/PrefixImage/ContactFibre.lean` (`recover_equation`, `recover_energy`, `recover_error_le`, `recover_refined_tendsto`) | §8.2 Prop. 8.2; §9.4 |

### B.2 Five Basis-Free Determinant and Limit-Complex Interfaces (All Exported in `H0mework`)

| Interface | `Homework` source path | `H0mework` public path | Proposition & function |
| --- | --- | --- | --- |
| Interface I: Dual-lattice determinant | `SM/LivingLawRootGeneratedDualLatticeDeterminantKernel.lean` | `Lean/H0mework/Realization/Determinant/DualLattice.lean` | Prop. 4.1; nondegenerate dual-lattice exterior pairing & integral sign control |
| Interface II: Finite-cokernel Smith index | `SM/LivingLawRootGeneratedFiniteDefectDeterminantKernel.lean` | `Lean/H0mework/Foundation/Relations/FiniteDefectDeterminant.lean` | Prop. 4.2; equal-rank index $|\det f|=\#\operatorname{coker} f$ & group balance |
| Interface III: Short-exact gluing & transport | `SM/LivingLawRootGeneratedExactDeterminantGluingKernel.lean` | `Lean/H0mework/Realization/Determinant/ExactGluing.lean` | Prop. 4.3; endpoint basis gluing & zero-cokernel exterior isomorphism |
| Interface IV: Four-term free alternating line | `SM/LivingLawRootGeneratedPerfectComplexDeterminantProjectionKernel.lean` | `Lean/H0mework/Realization/Determinant/FourTermProjection.lean` | Prop. 4.4; alternating exterior line, $\{\pm 1\}$-torsor & termwise transport |
| Interface V: Inverse-limit mapping cones | `SM/LivingLawRootGeneratedDependentDerivedGlobalStateKernel.lean` | `Lean/H0mework/Realization/GlobalSections/DerivedState.lean` | Prop. 4.5; cochain diagram inverse limits & contractible mapping-cone equivalence |

### B.3 Representative Lean 4 Types

```lean
def equiv (R : Type r) [CommRing R] (A : Type u) [AddCommGroup A] [Module R A] :
    A ≃ₗ[R] Carrier R A

theorem order_from_source {I K : Type*} [Field K] (clock : I → K)
    (distinct : Function.Injective clock) (source : I →₀ K) {bound : Nat}
    (within : source.support.card ≤ bound) :
    order (measure clock source bound) = source.support.card

theorem admitted_iff_image {H : Type*} [NormedAddCommGroup H]
    [InnerProductSpace ℂ H] [CompleteSpace H] (source : Nat → H) (data : Nat → ℂ) :
    ((∀ n, residual source data n = 0) ∧ BddAbove (range (energy source data))) ↔
      ∃ x : H, read source x = data

theorem inverse_effect {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [CompleteSpace A]
    (action : A) {d budget : ℝ} (positive : 0 < d)
    (growth : ∀ n : Nat, ‖(cayley action d)^n‖ ≤ ((n : ℝ)+1)*budget) :
    inverse action d * (action-1) = 1 ∧ (action-1) * inverse action d = 1

theorem factorial_small_effect_recovers_source {L E : Type*} [AddCommGroup L]
    [NormedAddCommGroup E] [NormedSpace ℝ E] (coordinate : L ≃ₗ[ℤ] ℤ)
    (effect : L →ₗ[ℤ] E) (live : effect (coordinate.symm 1) ≠ 0)
    (value : FactorialCompletion (L := L)) :
    (∃! source : L, factorialCanonicalMap source = value) ↔
      ∃ base : Nat, ∀ stage ≥ base,
        ‖effect (factorialBalancedLift coordinate value (stage+1)) -
          effect (factorialBalancedLift coordinate value stage)‖ <
          (factorialModulus stage : ℝ)*‖effect (coordinate.symm 1)‖
```

---

## Appendix C Cauchy–Binet Expansion of Signed Hankel Blocks and Truncation Amplification

<a id="app-c-1"></a>

**Remark C.1 (Cauchy–Binet expansion of leading Hankel determinants).** Applying the Cauchy–Binet formula over an arbitrary field $K$ to the factorization $H_w = V_w \operatorname{diag}(a|_S) V_w^{\mathsf T}$ ($V_w\in K^{w\times r}$, $|S|=r$) gives
$$\det H_w = \sum_{T\subseteq S,\;|T|=w}\Bigl(\prod_{s\in T} a(s)\Bigr)\bigl(\det V_{w,T}\bigr)^2,\tag{C.1}$$
where $V_{w,T}\in K^{w\times w}$ denotes the square Vandermonde submatrix on $T$. Identity (C.1) accounts simultaneously for all three regimes: (1) for $w>r$ the sum is empty, so $\det H_w=0$; (2) over $K=\mathbb{R}$ with $a(s)>0$, every summand for $w\le r$ is strictly positive, preventing cancellation and giving $\det H_w>0$; (3) under signed weights or $\operatorname{char}(K)>0$, multiple summands at $w<r$ can cancel to give $\det H_w=0$, whereas at $w=r$ the sum reduces to the single nonzero term $T=S$, guaranteeing $\det H_r=(\prod_{s\in S}a(s))(\det V_r)^2\neq 0$ over every field.

<a id="app-c-2"></a>

**Remark C.2 (Step-independent upper bound $M_{\delta,B}$ on noise amplification).** For every $m$, $\|F_{\delta,m}(A)\|\le\delta q\sum_{k=0}^{m-1}B(k+1)q^k\le M_{\delta,B}$. The actual amplification factor in Example 8.1 starts at $1/2$ for $m=1$ and tends to $M_{1,1}=2$.

---

## Appendix D Glossary of Core Terms, Lean Identifiers, and Symbols

| Concept | Lean Identifier / Module | Mathematical Notation / Definition |
| --- | --- | --- |
| Character bidual image | `Carrier R A` (`Exact.lean`) | $P_{\chi,R}(A):=\operatorname{im}(\mathrm{ev}_{R,A})\le\operatorname{Hom}_{\mathbb{Z}}(A^\vee_\chi,\mathbb{Q}/\mathbb{Z})$ |
| Four-way observation disposition | `settle` (`ObservationDisposition`) | Bijective / pure kernel / pure coverage / double loss |
| All-prime uniformity kernel | `allPrimeKernel_iff` | $\ker\pi_{\mathrm{all}}=\bigcap_{p,n}p^{n+1}L$ |
| Kummer cokernel-torsion limit | `cokernelCompletionEquiv` | $T_p(C)=\varprojlim_j (M/\operatorname{im}\iota)[p^{j+1}]$ |
| Factorial balanced representative | `factorialBalancedLift` | $b_n(v)\in L$, $-\lfloor M_n/2\rfloor\le\phi(b_n(v))<M_n-\lfloor M_n/2\rfloor$ |
| Alternating integral determinant line | `FourTermProjection` | $\det_{\mathbb{Z}}(C^\bullet)=(\det C_0\otimes\det C_1^\vee)\otimes\det C_2\otimes\det C_3^\vee$ |
| Intertwining defect operator | `defect` (`Full/Defect.lean`) | $\Delta f=B_{\sigma_Y}\circ\mathrm{map}(f)-\mathrm{map}(f)\circ A_{\sigma_X}$ |
| Unobservable invariant submodule | `common_invariant_is_retained` | $\ker\mathcal{I}=\{c\in C:\forall w\in I^*,\,e(A_w c)=0\}\le\ker e$ |
| Signed evaluation Gram / Hankel block | `hankel_factor`, `order_from_source` | $H_w = V_w\operatorname{diag}(a|_S)V_w^{\mathsf T}$, $r=\max\{w\le k:\det H_w\neq 0\}$ |
| Stream preimage conditions | `admitted_iff_image` | $\forall n,\,r_n(d)=0\ \wedge\ \sup_n E_n(d)<\infty$ |
| Linear-growth damped Cayley inverse | `CayleyEffectInverse.inverse` | $\mathcal{I}_\delta(A)=-\delta q\sum_{n\ge 0}q^n(1+\delta A)^n$, $M_{\delta,B}=\frac{1+\delta}{\delta}B$ |

---

<!-- code-availability:begin -->
## Code and Data Availability

The proofs use Lean 4 `v4.33.0` and mathlib commit `db584cd6d46c92f209a44c0f1c829460d327499d`. The [pinned repository](https://github.com/Sapientropic/H0mework/tree/ccf469d177d0cff2cefbb162b4f5ab7891a83b25) provides the proofs, direct consumers, and original certificates for R1–R62 and the five interfaces. The [claim map](https://github.com/Sapientropic/H0mework/blob/ccf469d177d0cff2cefbb162b4f5ab7891a83b25/docs/exact-realization-map.json) records the original paths and their public module owners. Run `lake -d Lean build ExactRealization` from the repository root. The [reproduction guide](https://github.com/Sapientropic/H0mework/blob/ccf469d177d0cff2cefbb162b4f5ab7891a83b25/docs/exact-realization-reproduction.md) lists the source restoration and kernel checks.

The accompanying `python3 validation/verify_manuscript.py --math-only` recomputes the factorial, finite-field moment, and Jordan examples.
<!-- code-availability:end -->

## References

[Gao2026OneBitV2] Gao, J. *Ontological Rigidity and Universal Single-Mother Formation: Axiom-Free Exclusion of Unaccounted Differences, Causal Admission, and Unified Evolution*. Version 2, Zenodo, 2026. DOI: [10.5281/zenodo.24135399](https://doi.org/10.5281/zenodo.24135399).

[Gao2026SourceProcessCoreV3] Gao, J. *Source-Native Process Algebra and Initial-Coface Revision: Four-Tier Identity, Exact Evaluation Kernels, and Reversible Incremental Continuation*. Version 3, Zenodo, 2026. DOI: [10.5281/zenodo.24147130](https://doi.org/10.5281/zenodo.24147130).

[Gao2026WholeLedgerV2] Gao, J. *Provenance-Preserving Conservation Calculus and Non-Free Continuity: Whole-Event Ledgers, Observer Safety, and Well-Founded Settlement*. Version 2, Zenodo, 2026. DOI: [10.5281/zenodo.24147183](https://doi.org/10.5281/zenodo.24147183).

[Pontryagin1934] Pontrjagin, L. The Theory of Topological Commutative Groups. *Annals of Mathematics*, Series 2, **35**(2) (1934), 361–388. DOI: [10.2307/1968438](https://doi.org/10.2307/1968438).

[Baer1940] Baer, R. Abelian Groups That Are Direct Summands of Every Containing Abelian Group. *Bulletin of the American Mathematical Society*, **46**(10) (1940), 800–806. DOI: [10.1090/S0002-9904-1940-07306-9](https://doi.org/10.1090/S0002-9904-1940-07306-9).

[Lambek1964] Lambek, J. A Module Is Flat If and Only If Its Character Module Is Injective. *Canadian Mathematical Bulletin*, **7**(2) (1964), 237–243. DOI: [10.4153/CMB-1964-021-9](https://doi.org/10.4153/CMB-1964-021-9).

[Stacks01D6] The Stacks Project Authors. *The Stacks Project, Tag 01D6: Injective Abelian Groups*. URL: [https://stacks.math.columbia.edu/tag/01D6](https://stacks.math.columbia.edu/tag/01D6).

[Milnor1962] Milnor, J. W. On Axiomatic Homology Theory. *Pacific Journal of Mathematics*, **12**(1) (1962), 337–341. DOI: [10.2140/pjm.1962.12.337](https://doi.org/10.2140/pjm.1962.12.337).

[Weibel1994] Weibel, C. A. *An Introduction to Homological Algebra*. Cambridge Studies in Advanced Mathematics, Vol. **38**, Cambridge University Press (1994). DOI: [10.1017/CBO9781139644136](https://doi.org/10.1017/CBO9781139644136).

[Jannsen1988] Jannsen, U. Continuous Étale Cohomology. *Mathematische Annalen*, **280**(2) (1988), 207–245. DOI: [10.1007/BF01456052](https://doi.org/10.1007/BF01456052).

[KnudsenMumford1976] Knudsen, F. F., and Mumford, D. The Projectivity of the Moduli Space of Stable Curves. I: Preliminaries on “det” and “Div”. *Mathematica Scandinavica*, **39**(1) (1976), 19–55. DOI: [10.7146/math.scand.a-11642](https://doi.org/10.7146/math.scand.a-11642).

[Deligne1987] Deligne, P. Le déterminant de la cohomologie. In *Current Trends in Arithmetical Algebraic Geometry*, Contemporary Mathematics **67**, American Mathematical Society (1987), 93–177. DOI: [10.1090/conm/067/902592](https://doi.org/10.1090/conm/067/902592).

[Stacks0FJ9] The Stacks Project Authors. *The Stacks Project, Tag 0FJ9: Determinants*. URL: [https://stacks.math.columbia.edu/tag/0FJ9](https://stacks.math.columbia.edu/tag/0FJ9).

[Tate1966] Tate, J. On the Conjectures of Birch and Swinnerton-Dyer and a Geometric Analog. *Séminaire Bourbaki*, Vol. **9**, Exposé 306 (1966), 415–440. NUMDAM: [https://www.numdam.org/item/SB_1964-1966__9__415_0/](https://www.numdam.org/item/SB_1964-1966__9__415_0/).

[Nekovar2006] Nekovář, J. *Selmer Complexes*. *Astérisque* **310**, Société Mathématique de France (2006), viii+559 pp. NUMDAM: [https://www.numdam.org/issues/AST_2006__310__R1_0/](https://www.numdam.org/issues/AST_2006__310__R1_0/).

[MaciasCastilloSano2026] Macias Castillo, D., and Sano, T. On Selmer Complexes, Stark Systems and Derived $p$-adic Heights. arXiv:[2603.23978](https://arxiv.org/abs/2603.23978) (2026).

[Stacks00CX] The Stacks Project Authors. *The Stacks Project, Tag 00CX: Tensor Products*. URL: [https://stacks.math.columbia.edu/tag/00CX](https://stacks.math.columbia.edu/tag/00CX).

[Green2007Provenance] Green, T. J., Karvounarakis, G., and Tannen, V. Provenance Semirings. In *Proceedings of the 26th ACM SIGMOD-SIGACT-SIGART Symposium on Principles of Database Systems (PODS ’07)*, ACM (2007), 31–40. DOI: [10.1145/1265530.1265535](https://doi.org/10.1145/1265530.1265535).

[Cai2014Changes] Cai, Y., Giarrusso, P. G., Rendel, T., and Ostermann, K. A Theory of Changes for Higher-Order Languages: Incrementalizing $\lambda$-Calculi by Static Differentiation. In *Proceedings of the 35th ACM SIGPLAN Conference on Programming Language Design and Implementation (PLDI ’14)*, ACM (2014), 145–155. DOI: [10.1145/2594291.2594304](https://doi.org/10.1145/2594291.2594304).

[Budiu2023DBSP] Budiu, M., Chajed, T., McSherry, F., Ryzhyk, L., and Tannen, V. DBSP: Automatic Incremental View Maintenance for Rich Query Languages. *Proceedings of the VLDB Endowment*, **16**(7) (2023), 1601–1614. DOI: [10.14778/3587136.3587137](https://doi.org/10.14778/3587136.3587137).

[Ellerman2014Accounting] Ellerman, D. P. On Double-Entry Bookkeeping: The Mathematical Treatment. *Accounting Education*, **23**(5) (2014), 483–501. DOI: [10.1080/09639284.2014.949803](https://doi.org/10.1080/09639284.2014.949803).

[Kalman1963] Kálmán, R. E. Mathematical Description of Linear Dynamical Systems. *Journal of the Society for Industrial and Applied Mathematics, Series A: Control*, **1**(2) (1963), 152–192. DOI: [10.1137/0301010](https://doi.org/10.1137/0301010).

[Prony1795] de Prony, G. Essai expérimental et analytique sur les lois de la dilatabilité de fluides élastiques et sur celles de la force expansive de la vapeur de l’eau et de la vapeur de l’alkool, à différentes températures. *Journal de l’École Polytechnique*, **1**(2) (1795), 24–76.

[Kronecker1881] Kronecker, L. Zur Theorie der Elimination einer Variabeln aus zwei algebraischen Gleichungen. *Monatsberichte der Königlich Preussischen Akademie der Wissenschaften zu Berlin* (1881), 535–600.

[BenOrTiwari1988] Ben-Or, M., and Tiwari, P. A Deterministic Algorithm for Sparse Multivariate Polynomial Interpolation. In *Proceedings of the 20th Annual ACM Symposium on Theory of Computing (STOC ’88)*, ACM (1988), 301–309. DOI: [10.1145/62212.62241](https://doi.org/10.1145/62212.62241).

[PeterPlonka2013] Peter, T., and Plonka, G. A Generalized Prony Method for Reconstruction of Sparse Sums of Eigenfunctions of Linear Operators. *Inverse Problems*, **29**(2) (2013), 025001. DOI: [10.1088/0266-5611/29/2/025001](https://doi.org/10.1088/0266-5611/29/2/025001).

[CandesFernandezGranda2014] Candès, E. J., and Fernandez-Granda, C. Towards a Mathematical Theory of Super-Resolution. *Communications on Pure and Applied Mathematics*, **67**(6) (2014), 906–956. DOI: [10.1002/cpa.21455](https://doi.org/10.1002/cpa.21455).

[Schur1917] Schur, I. Über Potenzreihen, die im Innern des Einheitskreises beschränkt sind. *Journal für die reine und angewandte Mathematik*, **147** (1917), 205–232. DOI: [10.1515/crll.1917.147.205](https://doi.org/10.1515/crll.1917.147.205).

[Penrose1955] Penrose, R. A Generalized Inverse for Matrices. *Mathematical Proceedings of the Cambridge Philosophical Society*, **51**(3) (1955), 406–413. DOI: [10.1017/S0305004100030401](https://doi.org/10.1017/S0305004100030401).

[Riesz1910] Riesz, F. Untersuchungen über Systeme integrierbarer Funktionen. *Mathematische Annalen*, **69**(4) (1910), 449–497. DOI: [10.1007/BF01457637](https://doi.org/10.1007/BF01457637).

[Aronszajn1950] Aronszajn, N. Theory of Reproducing Kernels. *Transactions of the American Mathematical Society*, **68**(3) (1950), 337–404. DOI: [10.1090/S0002-9947-1950-0051437-7](https://doi.org/10.1090/S0002-9947-1950-0051437-7).

[Douglas1966] Douglas, R. G. On Majorization, Factorization, and Range Inclusion of Operators on Hilbert Space. *Proceedings of the American Mathematical Society*, **17**(2) (1966), 413–415. DOI: [10.1090/S0002-9939-1966-0203464-1](https://doi.org/10.1090/S0002-9939-1966-0203464-1).

[AdcockHansen2016] Adcock, B., and Hansen, A. C. Generalized Sampling and Infinite-Dimensional Compressed Sensing. *Foundations of Computational Mathematics*, **16**(5) (2016), 1263–1323. DOI: [10.1007/s10208-015-9276-6](https://doi.org/10.1007/s10208-015-9276-6).

[vonNeumann1930] von Neumann, J. Allgemeine Eigenwerttheorie Hermitescher Funktionaloperatoren. *Mathematische Annalen*, **102** (1930), 49–131. DOI: [10.1007/BF01782338](https://doi.org/10.1007/BF01782338).

[Kreiss1962] Kreiss, H.-O. Über die Stabilitätsdefinition für Differenzengleichungen die partielle Differentialgleichungen approximieren. *BIT Numerical Mathematics*, **2**(3) (1962), 153–181. DOI: [10.1007/BF01957330](https://doi.org/10.1007/BF01957330).

[KatznelsonTzafriri1986] Katznelson, Y., and Tzafriri, L. On Power Bounded Operators. *Journal of Functional Analysis*, **68**(3) (1986), 313–328. DOI: [10.1016/0022-1236(86)90101-1](https://doi.org/10.1016/0022-1236(86)90101-1).

[deMouraUllrich2021Lean4] de Moura, L., and Ullrich, S. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, LNCS **12699**, Springer (2021), 625–635. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[mathlib2020] The mathlib Community. The Lean Mathematical Library. In *Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)*, ACM (2020), 367–381. DOI: [10.1145/3372885.3373824](https://doi.org/10.1145/3372885.3373824).

[AngdinataXu2023] Angdinata, D. K., and Xu, J. An Elementary Formal Proof of the Group Law on Weierstrass Elliptic Curves in Any Characteristic. In *14th International Conference on Interactive Theorem Proving (ITP 2023)*, LIPIcs **268**, Schloss Dagstuhl – Leibniz-Zentrum für Informatik (2023), 6:1–6:19. DOI: [10.4230/LIPIcs.ITP.2023.6](https://doi.org/10.4230/LIPIcs.ITP.2023.6).

[BuzzardCommelinMassot2020] Buzzard, K., Commelin, J., and Massot, P. Formalising Perfectoid Spaces. In *Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)*, ACM (2020), 299–312. DOI: [10.1145/3372885.3373830](https://doi.org/10.1145/3372885.3373830).

[CommelinTopaz2024] Commelin, J., and Topaz, A. Abstraction Boundaries and Spec Driven Development in Pure Mathematics. *Bulletin of the American Mathematical Society*, **61**(2) (2024), 241–255. DOI: [10.1090/bull/1831](https://doi.org/10.1090/bull/1831).
