#!/usr/bin/env python3
"""Build both reading PDFs for `exact-realization` (`manuscript.md` and `manuscript-en.md`).

Run from the publish root:
    python3 papers/exact-realization/scripts/build_pdf.py --lang both
"""
from __future__ import annotations

import argparse
from functools import partial
import json
import os
import re
import shutil
import sys
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
sys.path.insert(0, str(ROOT / 'shared/scripts'))
import build_pdf as shared  # noqa: E402

ZH = 'papers/exact-realization/manuscript.md'
EN = 'papers/exact-realization/manuscript-en.md'
shared.RUNHEADS[ZH] = (
    'exact-realization',
    '忠实表示与精确反演',
    '从商、矩与流恢复源对象',
)
shared.RUNHEADS[EN] = (
    'exact-realization',
    'Faithful Representations and Exact Inversion',
    'Recovery from Quotients, Moments, and Streams',
)
shared.CONTINUOUS_APPENDICES.add(ZH)
shared.CONTINUOUS_APPENDICES.add(EN)

_latin_title = shared.latin_title


def _subtitle(line: str) -> str | None:
    stripped = line.strip()
    if stripped in ('# Abstract', '## Abstract') or stripped.startswith('**Formal verification'):
        return None
    return _latin_title(line)


shared.latin_title = _subtitle

_prepare = shared.prepare


def _prepare_paginated(source: str, toc: bool, profile: dict):
    title, subtitle, body = _prepare(source, toc, profile)
    body = re.sub(
        r'```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n'
        r'(#{1,2} (?:摘要|Abstract(?: \(English\))?)\s*)\n\n'
        r'```\{=latex\}\n(\\begingroup\\small[^\n]+)\n```'
        r'(.*?)'
        r'```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```',
        lambda m: (
            '```{=latex}\n\\Needspace{9\\baselineskip}\n```\n\n'
            + m.group(1)
            + '\n\n```{=latex}\n'
            + m.group(2)
            + '\n```'
            + m.group(3)
            + '```{=latex}\n\\endgroup\\par\n```'
        ),
        body,
        flags=re.S,
    )
    body = re.sub(
        r'```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n'
        r'(# (?:参考文献|References)\s*)\n\n'
        r'```\{=latex\}\n(\\begingroup\\footnotesize[^\n]+)\n```',
        lambda m: (
            '```{=latex}\n\\Needspace{8\\baselineskip}\n```\n\n'
            + m.group(1)
            + '\n\n```{=latex}\n'
            + m.group(2)
            + '\n```'
        ),
        body,
        count=1,
    )
    body = re.sub(
        r'```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```\s*\Z',
        lambda _: '```{=latex}\n\\endgroup\\par\n```\n',
        body,
        count=1,
    )
    return title, subtitle, body


shared.prepare = _prepare_paginated


def _smart_code_breaks(match: re.Match) -> str:
    inner = match.group(1)
    if re.fullmatch(r'[0-9a-f]{32,64}', inner):
        return match.group(0)
    s = inner
    for ch, repl in _LEAN_HIGHLIGHT_MAP.items():
        s = s.replace(ch, repl)
    s = s.replace('/', '/\\allowbreak{}')
    s = s.replace('-', '-\\allowbreak{}')
    s = s.replace(',', ',\\allowbreak{}')
    s = s.replace('::', '::\\allowbreak{}')
    s = s.replace('\\_', '\\_\\allowbreak{}')
    s = s.replace('\\{', '\\allowbreak\\{')
    s = s.replace('\\}', '\\}\\allowbreak{}')
    s = re.sub(r'\.(?!lean\b)', r'.\\allowbreak{}', s)
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1\\allowbreak{}\2', s)
    s = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1\\allowbreak{}\2', s)
    return '{\\sloppy ' + s + '}'


_compile_tex = shared.compile_tex

_LEAN_HIGHLIGHT_MAP = {
    'ℝ': r'\ensuremath{\mathbb{R}}',
    'ℤ': r'\ensuremath{\mathbb{Z}}',
    'ℚ': r'\ensuremath{\mathbb{Q}}',
    'ℂ': r'\ensuremath{\mathbb{C}}',
    'ℕ': r'\ensuremath{\mathbb{N}}',
    'κ': r'\ensuremath{\kappa}',
    '≡': r'\ensuremath{\equiv}',
    '∀': r'\ensuremath{\forall}',
    '∃': r'\ensuremath{\exists}',
    '∧': r'\ensuremath{\land}',
    '∨': r'\ensuremath{\lor}',
    '→': r'\ensuremath{\rightarrow}',
    '←': r'\ensuremath{\leftarrow}',
    '↔': r'\ensuremath{\leftrightarrow}',
    '≃': r'\ensuremath{\simeq}',
    '≅': r'\ensuremath{\cong}',
    '≤': r'\ensuremath{\leq}',
    '≥': r'\ensuremath{\geq}',
    '≠': r'\ensuremath{\neq}',
    '¬': r'\ensuremath{\lnot}',
    '∈': r'\ensuremath{\in}',
    '∉': r'\ensuremath{\notin}',
    '⊆': r'\ensuremath{\subseteq}',
    '⧸': r'\ensuremath{/}',
    '⊥': r'\ensuremath{\bot}',
    '•': r'\ensuremath{\cdot}',
    '‖': r'\ensuremath{\Vert}',
    '⟨': r'\ensuremath{\langle}',
    '⟩': r'\ensuremath{\rangle}',
    '₀': r'\ensuremath{{}_0}',
    '₁': r'\ensuremath{{}_1}',
    '₂': r'\ensuremath{{}_2}',
    '₃': r'\ensuremath{{}_3}',
    'ₓ': r'\ensuremath{{}_x}',
    'ᵥ': r'\ensuremath{{}_{\mathrm{v}}}',
    'ₗ': r'\ensuremath{{}_{\ell}}',
    '⁻¹': r'\ensuremath{{}^{-1}}',
}


def _replace_lean_unicode(match: re.Match) -> str:
    block = match.group(0)
    for ch, repl in _LEAN_HIGHLIGHT_MAP.items():
        block = block.replace(ch, repl)
    return block


def _compile_clean(tex: Path):
    params = tex.parent / 'paper-params.tex'
    if params.is_file():
        ptxt = params.read_text()
        hook = (
            '\\AtBeginDocument{'
            '\\pretocmd{\\section}{\\Needspace{10\\baselineskip}}{}{}'
            '\\pretocmd{\\subsection}{\\Needspace{8\\baselineskip}}{}{}'
            '}\n'
        )
        if '\\pretocmd{\\subsection}' not in ptxt:
            params.write_text(ptxt + hook)

    ts = tex.read_text()
    # Keep the bilingual keywords on the opening page with both abstracts.
    if tex.parent.name == 'pdf-work':
        ts = ts.replace(r'\begingroup\small\setstretch{1.16}', r'\begingroup\small\setstretch{1.10}')
    ts = re.sub(r'\\seqsplit\{((?:\\.|[^{}])+)\}', _smart_code_breaks, ts)
    ts = re.sub(
        r'\\begin\{Highlighting\}\[\].*?\\end\{Highlighting\}',
        _replace_lean_unicode,
        ts,
        flags=re.S,
    )

    thm_pat = re.compile(
        r'(?m)^(\\textbf\{(?:定理|命题|引理|推论|定义|例|注记|Theorem|Proposition|Lemma|Corollary|Definition|Example|Remark)\s+[0-9]+\.[0-9]+)'
    )
    out_lines = []
    for line in ts.split('\n'):
        if thm_pat.match(line):
            prev_nonempty = next((x for x in reversed(out_lines) if x.strip()), '')
            if '\\Needspace' not in prev_nonempty:
                out_lines.append('\\Needspace{7\\baselineskip}')
        out_lines.append(line)
    tex.write_text('\n'.join(out_lines))
    return _compile_tex(tex)


shared.compile_tex = _compile_clean
shared.fit_wide_displays = partial(shared.fit_wide_displays, tolerance=0.0)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('zh', 'en', 'both'), default='both')
    parser.add_argument('--no-toc', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=PAPER / 'build')
    args = parser.parse_args()

    out_dir = args.output_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    temp = out_dir / 'tmp'
    temp.mkdir(parents=True, exist_ok=True)
    os.environ['TMPDIR'] = str(temp)

    targets = [ZH, EN] if args.lang == 'both' else ([ZH] if args.lang == 'zh' else [EN])
    try:
        reports = []
        for rel in targets:
            rep = shared.build(rel, toc=not args.no_toc, output_dir=out_dir)
            reports.append(rep)
            print(json.dumps(rep, ensure_ascii=False))
    finally:
        shutil.rmtree(temp, ignore_errors=True)


if __name__ == '__main__':
    main()
