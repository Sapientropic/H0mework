# Proof Supplement: Propagation Catalogs, Spatial Evolution Interfaces, and Multi-Body Long-Range Proofs

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

## Abstract

This Proof Supplement provides in full the technical catalogs, operator-analytic interfaces, and step-by-step derivations invoked across Sections 3–14 of *Low-Energy Electromagnetic Emergence from a Zero-Knob Unified Source: Coupled Propagation, Unit Electron Charge, the Maxwell Cone, and $1/(4\pi r)$ Coulomb Return* (CourtyCourt · Case 1, second edition v2; mother action in [1], first-edition archive in [2]): Section S1 presents homogeneous coframe balances, rational propagation recovery, and the full four-momentum fourth-order soft-phase matrix (equations (S1.1)–(S1.5)); Section S2 presents original coordinates of the four free external legs, exact inverses of the two weak five-component sources, and static-response counts (equations (S2.1)–(S2.4)); Section S3 presents weak equations on the spatial Dirac domain, all-time window gluing, whole-word CAR mother-operator ordering, and first-order integrated current interfaces (equations (S3.1)–(S3.2)); Section S4 presents Riesz closed-form preparation points, direction-uniform five-dimensional static-inverse error bounds, and multi-layer equal-charge coframe commutator identities (equations (S4.1)–(S4.17)); Section S5 presents complete proofs for the 1650-term first-jet Hessian identity, pole-residue difference quotients, all-direction Schur infrared radii, three-dimensional Gaussian–Bochner regulator limits, two-particle created-source norm lower bounds, three-fermion four-grade Born overlap dressing, and the standard Maxwell light cone, $N=3$ pole unit-charge cancellation, and three-channel ordered far-field balance (equations (S5.1)–(S5.24)). Sections and equation tags correspond one-to-one with the single-volume first edition (v1) via S1 $\leftrightarrow$ v1 Appendix B, S2 $\leftrightarrow$ v1 Appendix C, S3 $\leftrightarrow$ v1 Appendix D, S4 $\leftrightarrow$ v1 Appendix F, and S5 $\leftrightarrow$ v1 Appendix G (while Appendices A and B of the main text carry the bare inventory/stabilizer proofs and the `L1-L29` fixed-evidence ledger). Unprefixed section and numeric equation citations such as `(3.1)`, `(11.17)`, and `(14.4)` refer to the main text.

<a id="supp-s1"></a>
## S1. Reduced operators, fourth-order phases, and recovery of original fields

### S1.1 Homogeneous coframe balance and radial feedback

Use $E_A,\mathcal D,c,q_v$ from (3.1). Substituting the same development and its actual jet into the original coframe variation reduces the temporal row to

$$\mathcal C_0=\mathcal D-\frac{3aE_A}{4\sigma n^2}=0,\tag{S1.1}$$

and the spatial trace row to

$$\mathcal C_s=2a\dot H+\frac{E_A}{4\sigma n}
-n\left[\frac{2s(c-\alpha)}{a^2}-q_va^2\left(f^2+\frac{w_s^2}{2}\right)
-3a^2-H^2+c^2\right]=0.\tag{S1.2}$$

The positive root of (S1.1) gives $n$ in (3.1), while (S1.2) gives $\dot H$ in (3.2). These two balances retain the coefficients of the matter, gauge, scalar kinetic, and potential terms. The corresponding traceless spatial rows and mixed rows vanish through the specific components of the original homogeneous fields. In the radial first-order direction, both $f,w_s$ start at zero; the scalar load in (S1.1)–(S1.2) begins at second order, in agreement with the complete coframe variation (3.12).

### S1.2 Propagation catalogs and recovery matrices

The accompanying data file `axial-propagation.json` records the field indices, row denominators, nonzero constants, and all factors and multiplicities of the ten blocks. The file `radial-propagation.json` records the 14 radial products and their correspondence with 22 axial factors. Both are extracted from exact outputs at the fixed source commit.

After field scaling, $G=S_f^{\mathsf T}K_{103}S_f/N$. The exact recovery of the original determinant is

$$\det K_{103}(\lambda,k)=
\frac{N^{103}}{\prod_i(S_f)_{ii}^2}
\det G\left(\frac{\lambda}{N\sqrt2},\frac{k}{\sqrt2}\right).\tag{S1.3}$$

The three original rounds of auxiliary recovery, the Ward-row inverse, the preparation embedding, and section readback give two sets of maps. The field map sends effective solutions back to original fields; the equation map sends effective residuals back to original Euler rows. They are different matrices. The $V_{289}$ and $J_{289}$ of §5 are their prepared-subclass versions, and $H_{289}V_{289}=J_{289}G$ holds for all four formal momentum variables.

Exceptional fiber dimensions, projections, and rotation maps for peripheral development are recorded in the canonical-peripheral sources listed in Appendix B of the main text. The difference between an instantaneous kernel and the maximal development space is that the latter requires the original vector field to remain in the constraint space. The computation therefore uses the constraints and their evolution closure together, rather than only the matrix kernel at one point.

The four-dimensional blocks in the 43-dimensional real scalar subspace use the original quaternionic structure. For three actual generator matrices satisfying $J_i^2=-I$ and $J_iJ_j=-J_jJ_i$, a matrix $M=aI+\sum_i b_iJ_i$ satisfies

$$M\left(aI-\sum_i b_iJ_i\right)=
\left(a^2+\sum_i b_i^2\right)I,\qquad
\det M=\left(a^2+\sum_i b_i^2\right)^2.\tag{S1.4}$$

The adapted basis and coefficients apply this identity block by block to 23 real singlets and five four-dimensional blocks. The complete 61-dimensional peripheral inverse uses all its projections in (6.8).

### S1.3 The fourth-order phase matrix at full four-momentum

Write $r=q_1^2+q_2^2+q_3^2$. With the original phase normalization of §5, the fourth-order term is

$$\begin{aligned}
(K_4)_{\varphi\varphi}={}&\frac{8000}{13467}\bigl[(q_2^2+q_3^2)^2-q_1^4\bigr]
-\frac{12033024}{67896125}q_1^2u^2\\
&+\frac{258700928}{203688375}(q_2^2+q_3^2)u^2
+\frac{320}{363}u^4,\\[2pt]
(K_4)_{\varphi\theta}=(K_4)_{\theta\varphi}={}&
\frac{2000}{603}q_1^2r+\frac{400}{99}q_1^2u^2
-\frac{148000i}{59697}q_3ur-\frac{34000i}{6633}q_3u^3,\\[2pt]
(K_4)_{\theta\theta}={}&\frac{2317625}{39366}r^2
-\frac{47494}{243}ru^2+\frac{45694}{375}u^4.
\end{aligned}\tag{S1.5}$$

Here $u,\mathbf q$ are the growth and spatial Fourier variables; transpose identities use the bilinear convention $p\mapsto-p$. An off-shell expression on a particular section can contain directional terms. The original four-momentum effective action and complete field recovery together determine their meaning.

Substituting $u^2=-55r/67+dr^2$ into the vector-phase row reduces (S1.5), on the second-order shell, to $12033024r^2/82709825$, independent of direction. For the axial-phase row, take $u^2=125r/162+dr^2$; its fourth-order term is $-381625r^2/19683$. Returning each to original time gives (5.10)–(5.11). The square of the fourth-order off-diagonal term enters the determinant at eighth order; after division by the other, noncoincident second-order branch, its influence begins at the sixth-order coefficient of $u^2$.

The accompanying `soft-phase.json` records the constant phase basis, the inverse of the 77-dimensional heavy block at the origin, graph maps at each order, original Noether densities, the embedding into the original 289 rows, and fifth- and sixth-order remainders. The $O(|\mathbf k|^6)$ in the main text denotes the order of the branch expansion. By contrast, $R_5,R_6$ are the exact homogeneous remainders obtained by substituting the finite field truncation into the original equations. They serve different purposes.


<a id="supp-s2"></a>

## S2. External legs, weak five-component sources, and static-response catalogs

### S2.1 Original coordinates of the four external legs

The original 252 coordinates are ordered first by Dirac component, then by exterior degree $\Lambda^6,\Lambda^2,\Lambda^4$. Each degree follows the original enumeration of increasing index sets. Let $e_j^{(252)}$ denote the zero-indexed unit column. The four coordinate-unit legs of (6.17) are

$$u_{4,\rm in}=e_{154},\qquad
u_{4,\rm out}=\frac{e_{154}+e_{217}}{\sqrt2},$$

$$u_{2,\rm in}=e_{196},\qquad
u_{2,\rm out}=\frac{e_{133}-e_{196}}{\sqrt2}.\tag{S2.1}$$

The subscripts $\mathrm{in}/\mathrm{out}$ distinguish incoming and outgoing legs. All four $u$ belong to the original matter carrier; the independent complex-linear dual field of an outgoing leg is $s u_{\rm out}^\dagger S$, and transfer sources are formed according to (6.4). Their field equations, momenta, frequencies, complete 97-component transfer sources, 79-dimensional dynamical solutions, and 289-dimensional positive Green fields are recorded in `onshell-exchange.json`. The action-normalized external legs are all multiplied by $2^{-1/4}$. Their two actually regenerated sources, 289-dimensional fields, and final exchange are recorded in `kinetic-residue.json`.

The complete merged frequency distribution at the origin is

$$\frac{E_{\rm orig}}{N\sqrt2}:
-\frac95[42],\ -\frac32[50],\ -\frac35[14],\quad
\frac35[15],\ \frac32[50],\ \frac95[45].\tag{S2.2}$$

The free spectral branches at nonzero momentum are given in §6.4. The zero-frequency spheres in original time are $|\mathbf k|^2=54/25,9/2,162/25$, with kernel dimensions $29,50,29$, respectively. The co-rotating zero-frequency spheres are instead $0,9/50,81/50,72/25$, with dimensions $31,5,45,28$. The two sets are related by $E_{\rm st}=E_{\rm orig}-\omega Q$ and retain their distinct identities.

### S2.2 Complete inverses for two original weak five-component sources

Each weak channel contains four connection components and one original scalar direction. For arbitrary three-momentum, write

$$r=|\mathbf k|^2,\qquad
T=\lambda^2+\frac r{N^2}-\frac12,\qquad
L=\lambda^2+N^2r-\frac12.$$

The actual four-vector Green matrix is

$$G_{00}=\frac{N(1-2\lambda^2)}{4L},\qquad
G_{0i}=G_{i0}=-\frac{iN\lambda k_i}{2L},$$

$$G_{ij}=-\frac{\delta_{ij}}{4NT}
+\frac{(2N^2\lambda^2+2r-N^{-2})k_ik_j}{4NTL}.\tag{S2.3}$$

It has no directional denominator, and at $\mathbf k=0$ directly gives $G_{00}=-N/2$. The original change of variables $A_\mu=B_\mu-\partial_\mu\eta$ turns the five-variable action into a constant scalar block $-4N$ and a four-vector block. For a gauge source $j_\mu$ and original scalar source $z$, the tree action is

$$-\frac12j(-p)^{\mathsf T}G(p)j(p)
+\frac1{8N}r_{\rm src}(-p)r_{\rm src}(p),\qquad
r_{\rm src}=z+\lambda j_0+i\mathbf k\cdot\mathbf j.\tag{S2.4}$$

The second term is the original scalar–divergence contact source. Both channels are recovered through the original six gauge auxiliaries and satisfy all 289 rows. Equation (S2.4) thus agrees with the corresponding block of (6.5).

### S2.3 Residues, sources, and static readings

All free spectral projections retain chirality and exterior degree. The sign of the kinetic residue is $\chi_c/s$, while the positive weight in the phase-charge pairing is $s\chi_cQ$. The counts are

| Original free directions | Dimension | Kinetic weight | Phase-charge weight |
|---|---:|---:|---:|
| Left-handed $\Lambda^2/\Lambda^4$ | 106 | $-s$ | $s$ |
| Right-handed $\Lambda^2/\Lambda^4$ | 96 | $s$ | $s$ |
| Right-handed $\Lambda^6$ | 14 | $s$ | $3s$ |

The accompanying `metric-response.json` retains ten independent metric sources and every $10\times10$ rational reading; `charge-response.json` retains twelve original charge sources, the $12\times12$ readings, and the soft residues of compatible sources. The minus signs of their complete induced fields follow the convention of a positive source term in the action. A finite extension of the reading to the origin does not make the complete original inverse invertible there.


<a id="supp-s3"></a>

## S3. Proof interfaces for spatial evolution and complete-word return

### S3.1 The strong equation on the original domain and the weak equation for general initial states

For $f\in\mathcal D(\mathsf H)$, (7.7) gives the strong derivative of $U(t)f$. For a general $u\in\mathscr H$, take a test vector $v$ in the domain. Equation (8.2) satisfies

$$\frac d{dt}\langle v,W_\epsilon(t,a)u\rangle
=-i\langle\mathsf Hv,W_\epsilon(t,a)u\rangle
-i\epsilon\langle v,R(t)W_\epsilon(t,a)u\rangle.\tag{S3.1}$$

The inner product is conjugate-linear on the left and linear on the right. In the first term of (S3.1), the unbounded generator acts on $v$ first, so the term is defined for every $L^2$ initial state. Returning through the original $S$ pairing and (7.8) gives the weak equation for the original independent dual. Schwartz tests then express the Fourier multiplier as actual spatial partial derivatives.

### S3.2 Gluing windows into evolution for all time

For a given starting time $a$ and ending time $t$, choose any open window containing both, for example one of radius $|a|+|t|+1$. The radial construction generates a solution on that window; the norm identity then makes it satisfy the original interaction equation. On overlap with another window, the two original solutions agree by their common initial value and uniqueness. Hence near any $t$, the global curve agrees locally with a curve from one fixed window. Its time derivative is inherited from that fixed curve, rather than obtained by differentiating a window radius that varies with $t$.

Linearity also follows from uniqueness: the sum of two solutions and the solution with the sum of their initial values satisfy the same original equation. Using a solution's value at an intermediate time as new initial data gives the two-time composition law, and reverse time gives a two-sided inverse. The argument needs no control norm bound supplied uniformly over all time.

### S3.3 The order of preparation, CAR words, and the original mother operator

Let $E$ contain the preparation vector and a given finite test family, let $J_E$ be the one-particle embedding, and let $I_{12}:\mathcal H_{12}\to\mathcal M$ be the original isometric exterior-power embedding. For a finite CAR word $W$, the mother operator of the unnormalized spatial preparation is

$$\widetilde A_W=I_{12}K_t^\dagger\,\iota_E
(J_E^\dagger WJ_E)\iota_E^\dagger K_tI_{12}^\dagger,
\qquad A_{\rm mother}=S\widetilde A_W.\tag{S3.2}$$

Here $\iota_E:E\to\mathscr H$ is the inclusion map. The final $S$ returns the coordinate inner product to the original independent dual, exactly as in (7.13a). For normalization, divide further by $\|K_tw\|^2$. A zero preparation retains the unnormalized zero functional; the unit-state conclusions apply to the nonzero preparations actually generated.

Equation (S3.2) uses one compression after $W$ has been formed in full. When the test family is enlarged, the exterior-algebra embedding intertwines each creation and annihilation operator, preserving every finite word, its adjoint, and $W^\dagger W$ simultaneously. For a multitime word, first apply the original $P(t_i+t_p)$ on each individual leg, then form the complete product. In general, phases at different times cannot be combined into an arbitrarily chosen single total phase.

### S3.4 The first-order remainder and integrated current

The common constant in (8.8) comes from $\sup\|R(t)\|$ on the time segment, rather than a derivative radius depending on a particular initial state. The strong integral is defined on each vector, and this uniform bound gives the boundedness of the integral operator. No operator-norm continuity of $R_H(t)$ is required. The local-current $L^1$ bound (7.18) then sends the two first-order state variations into an actual integrated current. In this order, (8.10) is the first-order reading of global finite evolution, beyond a formal commutator expression.


<a id="supp-s4"></a>

## S4. Written proofs for preparation, the static inverse, and equal-charge exchange

### S4.1 How the closed form generates the same preparation point

The original source remainder is the complete energy tail minus the composition term, $R=E_{\mathrm{tail}}-C_{\mathrm{src}}$. Both have their own two-sided Schur/source-coefficient bounds and self-adjointness, so $R$ is fixed, bounded, and self-adjoint. Augment the closed densely defined factor $A$ by

$$\widetilde A x=\left(Ax,(R+\|R\|I)^{1/2}x\right),\qquad
\|\widetilde Ax\|^2=\mathfrak q(x,x)+\|R\|\|x\|^2.
\tag{S4.1}$$

The square root is that of a bounded positive operator. If $x_n\to x$ and $\widetilde Ax_n\to(y,z)$, closedness of $A$ gives $x\in D(A)$ and $Ax=y$; boundedness of the square root gives $z=(R+\|R\|I)^{1/2}x$. The augmented graph is therefore closed, with the same dense domain. The Riesz solution for the graph inner product $\langle\widetilde Ax,\widetilde Ay\rangle+\langle x,y\rangle$ generates $\mathsf B$, satisfying

$$\mathfrak q(\mathsf Bf,y)+(1+\|R\|)\langle\mathsf Bf,y\rangle
=\langle f,y\rangle,\qquad y\in D(A).
\tag{S4.2}$$

Taking $y=\mathsf Bf$ shows positivity of $\mathsf B$. If $\mathsf Bf=0$, then $f$ is orthogonal to dense $D(A)$ and hence $f=0$. Exchanging the two sides and conjugating gives self-adjointness. Let $b=\|\mathsf B\|>0$. For a bounded positive operator the supremum of its quadratic readout on unit vectors is its norm. Choose unit $y_j$ with $\langle y_j,\mathsf By_j\rangle\to b$. Since $0\le\mathsf B^2\le b\mathsf B$,

$$\|(\mathsf B-bI)y_j\|^2
\le b\left(b-\langle y_j,\mathsf By_j\rangle\right)\longrightarrow0.
\tag{S4.3}$$

Thus $\|\mathsf By_j\|\to b$, while $x_j=\mathsf By_j/\|\mathsf By_j\|$ lies in the domain of $\mathcal T$ and

$$\|(\mathcal T-E_{\mathrm{src}})x_j\|
=\frac{\|y_j-b^{-1}\mathsf By_j\|}{\|\mathsf By_j\|}
\longrightarrow0.
\tag{S4.4}$$

Given $\varepsilon$, choose the same $x_j$ with residual below $\varepsilon$. Localized half-density and original number-raising CAR creation are isometric, so $v_\varepsilon$ remains unit. The original seed has native $Y$ eigenvalue $-1$. This identity holds first on smooth tests and extends by boundedness of the charge operator and density, giving (9.4). The original weak-form identity for the same $x_j$ is the inverse graph of (S4.2); the original localized-leg bound controls all eight completed legs. The closed Yukawa graph at this point gives the geometric cutoff bound following (9.4). Every preparation field therefore uses this generated point.

### S4.2 The static inverse in every direction, original-field reconstruction, and error bounds

The original five-dimensional static matrix and inverse are

$$\begin{gathered}
T_5=\sqrt{30}
\begin{pmatrix}
-25/54&0&0&0&0\\
0&-12/335&0&0&0\\
0&0&1/15&-1/3&0\\
0&0&-1/3&1/15&0\\
0&0&0&0&4/5
\end{pmatrix},\\
G_5=\sqrt{30}
\begin{pmatrix}
-9/125&0&0&0&0\\
0&-67/72&0&0&0\\
0&0&-1/48&-5/48&0\\
0&0&-5/48&-1/48&0\\
0&0&0&0&1/24
\end{pmatrix}.
\end{gathered}
\tag{S4.5}$$

Direct multiplication gives $T_5G_5=G_5T_5=I_5$, checking the actual scales in (9.14) and (10.13). Below, $T_{\mathrm{stat}},G_0$ denote the $289$-dimensional zero extensions of $T_5,G_5$; in particular, $G_0$ is the original static inverse matrix. The invertible padded matrices are separately denoted $\widetilde T_0=T_{\mathrm{stat}}+I-\Pi_5$ and $\widetilde G_0=G_0+I-\Pi_5$. The field-reconstruction matrices $F_0$ and $F_{\kappa,n}$ act in the original $289$ dimensions. The source reader takes values in $\Pi_5$, where the zero extension and padded inverse have the same action. At $p=(0,i\kappa n)$, the leading dictionary of the original Schur kernel $K_{\mathrm{eff}}(p)$ is exactly $-\kappa^2|n|^2T_{\mathrm{stat}}$: terms with nonzero temporal powers vanish, each spatial square gives $-\kappa^2n_j^2$, and the original canonical term table cancels cross-terms.

Let $\Pi_5$ be the five-direction projection and define

$$\mathsf K_{\kappa,n}
=(-\kappa^2)^{-1}K_{\mathrm{eff}}(0,i\kappa n)+(I-\Pi_5).
\tag{S4.6}$$

The original finite polynomial coefficients and complementary inverse give source-generated constants $B_{\mathrm{inv}}\ge1$, $C_{\mathrm{eff}}\ge0$, and a positive radius $r_0$ such that, for every $|n|=1$ and $0<\kappa\le r_0$, $\|\mathsf K_{\kappa,n}-\widetilde T_0\|\le C_{\mathrm{eff}}\kappa$ and $\|\widetilde G_0\|\le B_{\mathrm{inv}}$. These constants can be computed directly from absolute coefficient sums in the original term tables and the two-sided complementary-inverse bound on the controlled neighborhood. Reduce the radius to

$$r_{\mathrm{stat}}=\min\left\{r_0,
\frac1{4B_{\mathrm{inv}}(1+C_{\mathrm{eff}})}\right\}.
\tag{S4.7}$$

Then $\|\widetilde G_0(\mathsf K_{\kappa,n}-\widetilde T_0)\|\le1/4$. The Neumann series gives the actual two-sided inverse, and the inverse-difference identity gives

$$\|\mathsf K_{\kappa,n}^{-1}\|\le2B_{\mathrm{inv}},\qquad
\|\mathsf K_{\kappa,n}^{-1}-\widetilde G_0\|
\le2B_{\mathrm{inv}}^2C_{\mathrm{eff}}\kappa.
\tag{S4.8}$$

Retaining the original field map $F_{\kappa,n}$, source reader $R_{\kappa,n}$, contact, and complement, the complete original field is

$$\mathcal G_\kappa J=X_{\mathrm{contact}}(J)
+(-\kappa^2)^{-1}F_{\kappa,n}
\mathsf K_{\kappa,n}^{-1}R_{\kappa,n}J
+X_{\mathrm{complement}}(J).
\tag{S4.9}$$

These maps are continuous within the original source radius and converge to $F_0,F_0^{\mathsf T}$ and the original contact/complement at the origin. The complete field satisfies (9.2). Its finite-$\kappa$ pole-factor error therefore obeys

$$\begin{aligned}
&\left|J_D^{\mathsf T}
\left[-\kappa^2(\mathcal G_\kappa J_S-X_{\mathrm{reg}}(J_S))
-F_{\kappa,n}G_0R_{\kappa,n}J_S\right]\right|\\
&\quad\le
\left(\sum_i|J_{D,i}|\right)\|F_{\kappa,n}\|\,
2B_{\mathrm{inv}}^2C_{\mathrm{eff}}\kappa\,
\|R_{\kappa,n}J_S\|,
\qquad X_{\mathrm{reg}}=X_{\mathrm{contact}}+X_{\mathrm{complement}}.
\end{aligned}\tag{S4.10}$$

This first controls the actual factor at finite scale, then uses continuity to take the complete residue limit for fixed forcing. Both source maps remain, without discarding geometric projection or contact in advance.

### S4.3 Why equal-charge coframe exchange retains every correction

Let $Q$ be the original actual charge. In the positive triangular coframe coordinates $z_{\mathrm{cf}}=(z_0,\ldots,z_5)$, the three original cofactors are $m=(n_{\mathrm{cf}}z_2z_5,n_{\mathrm{cf}}z_1z_5,n_{\mathrm{cf}}z_0z_5)$. The original density-pairing matrix $D_{\mathrm{kin}}$ and gamma/color actions give the complete 252-dimensional matrix

$$M_{\mathrm{cf}}(z)=2\left[
m_0D_{\mathrm{kin}}\,i\gamma^1\rho(T_1)
+m_1D_{\mathrm{kin}}\,i\gamma^1\rho(T_0)
-m_2D_{\mathrm{kin}}\,i\gamma^2\rho(T_0)\right].$$

These three polynomial coefficients combine the volume and inverse-frame variations of the original coframe slot. For the unit- and zero-charge projections $\Pi_e,\Pi_n$, the actual matrix support gives $M_{\mathrm{cf}}=\Pi_eM_{\mathrm{cf}}\Pi_n+\Pi_nM_{\mathrm{cf}}\Pi_e$. The two original primal channels are these ordered products. The independent-dual branch exchanges their signs before taking the conjugate matrix of the original branch. Form the complete 504-dimensional matrix first, then apply full CAR one-body quantization. The identity $[d\Gamma(Q),d\Gamma(M)]=d\Gamma([Q,M])$ gives charge degrees $+1,-1$ on the smooth core; products of quantized projections are not substituted for the original matrix product.

Write $C_\pm^0$ for this core channel, $\mathcal I_F$ for test reconstruction, and $P_F$ for output-frame approximation. The finite reader is $C_\pm=P_F\,\operatorname{embed}\,C_\pm^0\mathcal I_F$. Its compression correction is generated directly from two original differences:

$$E_{\mathrm{cmp},\pm}y=
[Q,P_F]\operatorname{embed}C_\pm^0\mathcal I_Fy
+P_F\operatorname{embed}C_\pm^0
(Q_{\mathrm{core}}\mathcal I_Fy-\mathcal I_FQy).$$

Substitution of the core charge-degree identity gives

$$[Q,C_\pm]=\pm C_\pm+E_{\mathrm{cmp},\pm}.
\tag{S4.11}$$

The term $E_{\mathrm{cmp},\pm}$ is generated by the same test reconstruction and finite-frame projection relative to $Q$. The two-sided original Green identities give

$$[Q,G_z]=G_z[H,Q]G_z.
\tag{S4.12}$$

Set $b_{\mathrm{cf}}=-g_{\mathrm{scale}}/2$ and $B_\pm=G_z(b_{\mathrm{cf}}C_\pm)G_w$. The product rule gives, term by term,

$$[Q,B_\pm]=\pm B_\pm+
[Q,G_z](b_{\mathrm{cf}}C_\pm)G_w
+G_z(b_{\mathrm{cf}}E_{\mathrm{cmp},\pm})G_w
+G_z(b_{\mathrm{cf}}C_\pm)[Q,G_w].
\tag{S4.13}$$

Denote the last three terms by $E_{B,\pm}$. The original preparation projection $P$, equal-energy map $\mathcal E_F(A)=\sum_\nu C_\nu A E_\nu$, and resonance projection $P_{\mathrm{res}}(n)=\sum_{\nu:\Delta v_\nu(n)=0}P_\nu(n)$ are the actual original objects. Set $B_\pm^P=PB_\pm P$. Its exchange remainder is

$$E_{P,\pm}=[Q,P]B_\pm P+PE_{B,\pm}P+PB_\pm[Q,P].
\tag{S4.14}$$

The equal-energy map generates independent commutator terms at both ends:

$$E_{\mathcal E}(A)=
\sum_\nu\left([Q,C_\nu]AE_\nu+C_\nu A[Q,E_\nu]\right),
\quad
[Q,\mathcal E_F(A)]=\mathcal E_F([Q,A])+E_{\mathcal E}(A).
\tag{S4.15}$$

The resonance-projection commutator is the sum of the same $[Q,P_\nu(n)]$ over the original finite index set, without changing the zero-velocity surface. Taking $A_\pm=P_{\mathrm{res}}\mathcal E_F(B_\pm^P)$ gives

$$\mathcal X_\pm=[Q,P_{\mathrm{res}}]\mathcal E_F(B_\pm^P)
+P_{\mathrm{res}}\left(E_{\mathcal E}(B_\pm^P)
+\mathcal E_F(E_{P,\pm})\right).
\tag{S4.16}$$

Substitute (S4.13)–(S4.16) successively to obtain (10.10). The original actual prepared dual and primal have endpoint charges $q_L,q_R$, hence

$$\bigl(q_L-q_R\mp1\bigr)\mathcal Q_S(A_\pm)
=\mathcal Q_S(\mathcal X_\pm).
\tag{S4.17}$$

For equal edge, $q_L=q_R$; adding the two channels gives (10.11). The proof uses actual two-sided inverses, original charge action, and product rules for finite sums. All matter torques, compression terms, endpoint Green factors, and spectral-window corrections therefore remain. Summing all 64 weights and then normalizing both actual ends by (10.5) gives exactly (10.12)–(10.14).


<a id="supp-s5"></a>

## S5. Complete derivations of the same-action identity, spatial integral, Born dressing, Maxwell cone, and far-field balance

### S5.1 The actual first-jet Hessian and Fourier dictionary

The first jet has $5\times289=1445$ real slots. Write $x_{d,i}$ for its original value or derivative coordinates. In the original nine-group lift, the coframe, two connections, auxiliaries, multiplier, and scalar use their actual insertions; matter uses $P\delta\psi$, and the independent dual uses $\delta\chi\circ P$. At the anchor, the time derivative of the co-rotating field retains $P'(a)\delta\psi$, while the spatial derivatives retain the actual $x_i$. These determine the original time coefficients.

Put $X=\bar e^{-1}\delta e$. The local second-order expansion is recoverable term by term:

$$\begin{aligned}
e(t)^{-1}&=(I-tX+t^2X^2)\bar e^{-1}+O(t^3),\\
\nu_{e(t)}&=\nu_{\bar e}\left[1+t\operatorname{tr}X+
\frac{t^2}{2}\bigl((\operatorname{tr}X)^2-\operatorname{tr}X^2\bigr)\right]+O(t^3),\\
F(\bar A+ta)&=\bar F+tD_{\bar A}a+t^2a\wedge a,\\
D_{\bar A+ta}(\bar\Phi+t\varphi)&=
D_{\bar A}\bar\Phi+t(D_{\bar A}\varphi+\rho(a)\bar\Phi)+t^2\rho(a)\varphi.
\end{aligned}
\tag{S5.1}$$

The Lorentz curvature expands in the same way, and $\Sigma_e$ expands by wedging two coframe columns. The independent-dual matter term uses the original bilinear product $\chi(i\Gamma D\psi+Y_R\psi)$, with the original one-way Yukawa. Substitute (S5.1) into the four-sector density. In each product, select two first-order factors or one second-order factor. The result is the actual second-order homogeneous density

$$\mathcal Q(j)=\sum_{\ell=1}^{1650}
c_\ell x_{d_\ell,i_\ell}x_{e_\ell,j_\ell},
\qquad
\mathcal B(v,w)=\mathcal Q(v+w)-\mathcal Q(v)-\mathcal Q(w).
\tag{S5.2}$$

The sectors contain 234, 406, 220, and 790 terms, respectively. Gravity includes the actual BF, BB, and linear multiplier terms. Since $\mathcal Q=\frac12\mathcal B(j,j)$, the factor $1/2$ in the second-order density is not inserted again into the Fourier Hessian. The expansion uses 637 real first-jet slots; unused slots remain in the complete carrier.

A term $c x_{d,i}x_{e,j}$ polarizes in (S5.2) to $c(v_{d,i}w_{e,j}+v_{e,j}w_{d,i})$. Its Fourier value is therefore exactly

$$c\,\sigma_d(-p)\sigma_e(p)E_{ij}
+c\,\sigma_e(-p)\sigma_d(p)E_{ji}.
\tag{S5.3}$$

Value slots have zero momentum power, and derivative slots have the corresponding four-dimensional unit power. The left derivative slot contributes one factor $-1$; the right slot keeps its sign. The two powers add. Equation (S5.3) thus agrees with the original Euler rule, “value derivative minus divergence.” Adding contributions term by term preserves the matrix; exchanging two terms preserves their sum; merging a common $(i,j,\text{four-momentum power})$ adds coefficients and also preserves the matrix. Canonicalizing the two finite tables by these three algebraic rules gives identical nonzero terms and $\mathbb Q(\sqrt2,\sqrt{15})$ coefficients. This proves the complete identity between the original 3071-term matrix and (11.2), with no Hessian identity supplied as an input.

### S5.2 Difference-quotient proof of residue flux

Fix $b,n$ and $\varepsilon$ in the generated simple-pole range. Abbreviate $s_0=s_b$, $K(s)=K(p_\varepsilon(s,n))$, and $G(s)=G(p_\varepsilon(s,n))$. The original recovery matrices give the two-sided equations

$$K(s)G(s)=I-Q_s(s),\qquad
G(s)K(s)=I-Q_f(s),
\qquad RQ_s(s_0)=0.
\tag{S5.4}$$

Here $Q_s,Q_f$ are the complete original null-source and null-field readers. They are generated by the original polynomial recovery matrices and are continuous at the pole. We have $(s-s_0)G(s)\to R$, and $K$ is the differentiable original polynomial matrix. Multiply the first two equations by $s-s_0$ and take the limit to obtain $K(s_0)R=RK(s_0)=0$. For $s\ne s_0$, this gives

$$R\frac{K(s)-K(s_0)}{s-s_0}\bigl[(s-s_0)G(s)\bigr]
=R(I-Q_s(s)).
\tag{S5.5}$$

The left side tends to $RK'(s_0)R$. The right retains the actual varying $Q_s(s)$ and tends to $R(I-Q_s(s_0))=R$. This proves (11.6) while retaining the constraint source in the difference quotient.

From $R K'R=R$, we obtain $(RK')^2=RK'$. The simple-pole cofactor factorization of the original left reader gives $R=v_b\ell_b$. Its nonzero polarization lies in the original active field image, so the null-field reading vanishes. Hence $RJ=v_b\ell_b(J)$, with nonzero equivalence following from $v_b\ne0$. The chain transformations of physical frequency and positive clock then give (11.9)–(11.11) directly.

### S5.3 How the complete Schur formula generates a radius for every direction

Write $F(p)$ for the original complete field frame, $A(p)$ for its regular/contact part, and $F(-p)^{\mathsf T}$ for the reflected frame. They are continuous at zero momentum, with $F(0)=F_0$. Denote the padded inverse of the complete static five-direction kernel by $B(r,n)^{-1}$. The original Schur formula is

$$r^2G(0,irn)=r^2A(0,irn)
-F(0,irn)B(r,n)^{-1}F(0,-irn)^{\mathsf T}.
\tag{S5.6}$$

The original static domain generates constants $M_G,M_E$ such that, for every unit $n$,

$$\|B(r,n)^{-1}-\widetilde G_0\|\leq2M_G^2M_Er,
\qquad \widetilde G_0=G_0+I-\Pi_5.
\tag{S5.7}$$

This is the original error bound for the finite kernel: $\|B(r,n)-B(0,n)\|\leq M_Er$ and $\|B(0,n)^{-1}\|\leq M_G$. On the original domain, $M_GM_Er\leq1/2$. The Neumann series gives $\|B(r,n)^{-1}\|\leq2M_G$, and the inverse-difference identity gives (S5.7). The term coefficients and $|n_i|\leq1$ produce the same $M_E$. Since $F(p)\Pi_5=F(p)$, the complementary part $I-\Pi_5$ contributes zero to the limiting contraction in (S5.6).

The bound $\|(0,irn)\|\leq r$ lets the continuity of $F,A$, and the reflected frame at the origin provide radii common to every direction. Finite matrix multiplication and subtraction are continuous. Taking the minimum of these radii and the one from (S5.7) gives (12.2). More explicitly, first select an input error $\delta>0$ for the Schur reading, then choose

$$r_* =\min\left(\delta,r_F,r_A,r_{F^-},
\frac{\delta}{1+2M_G^2M_E}\right)>0.
\tag{S5.8}$$

This controls all five actual inputs $(r,A,F,B^{-1},F^-)$ near their zero-momentum values simultaneously. Taking output error 1, the triangle inequality gives $\|r^2G\|\leq1+\|S_0\|$, the source budget in (12.3).

### S5.4 Newton convolution and two actual regulator limits

For Schwartz $\phi$, use $\sup|\phi|$ near the origin: the radial measure $r^2dr$ controls the singularity $r^{-2}$. At infinity, use $|\phi(\xi)|\leq C_m(1+|\xi|)^{-m}$ with $m>3$. Thus

$$\int\frac{|\phi(\xi)|}{|2\pi\xi|^2}\,d\xi<\infty,
\qquad
\int\frac{|f_\phi(x-y)|}{|y|}\,dy<\infty.
\tag{S5.9}$$

For the second integral, inverse Fourier transformation preserves Schwartz functions, as do translation and reflection; $r^{-1}$ is also locally integrable at the origin. The finite matrix integral may be defined entry by entry. Equation (S5.9) and the uniform matrix-norm bound simultaneously establish its Bochner integrability.

For $d>0$, use the same positive Gaussian representation

$$\frac1{|k|^2+d^2}=\int_0^\infty e^{-t(|k|^2+d^2)}\,dt,
\qquad
\mathcal F^{-1}\bigl(e^{-t|2\pi\xi|^2}\bigr)(y)
=(4\pi t)^{-3/2}e^{-|y|^2/(4t)}.
\tag{S5.10}$$

On both sides, $d>0$, the Gaussian integral, and the Schwartz $L^1$ bounds justify the Fubini interchanges. The regulated Fourier integral therefore equals $g_d*f_\phi$, where

$$g_d(y)=\int_0^\infty e^{-d^2t}(4\pi t)^{-3/2}
e^{-|y|^2/(4t)}\,dt
=\frac{e^{-d|y|}}{4\pi|y|}\quad(y\ne0).
\tag{S5.11}$$

The final equality can also be evaluated directly. Set $a=d|y|/2$ and substitute $u=|y|/(2\sqrt t)$. The remaining integral is $I(a)=\int_0^\infty e^{-u^2-a^2/u^2}du$. Differentiate for $a>0$ and substitute $v=a/u$ to get $I'(a)=-2I(a)$. Gaussian domination at zero gives $I(0)=\sqrt\pi/2$, hence $I(a)=(\sqrt\pi/2)e^{-2a}$. These give the constant in (S5.11).

As $d\downarrow0$, the frequency side is dominated by the first integral in (S5.9). The spatial side is dominated by its second integral and $|g_d(y)|\leq(4\pi|y|)^{-1}$. The two sides tend separately to the original massless Fourier integral and (12.5), proving equality. The coordinate $k=2\pi\xi$ and original three-dimensional volume are retained together, so the Fourier calculation supplies exactly this one $4\pi$.

### S5.5 The created source, joint return, and moving domination

On the source closed box of the original norm-one background $b$, the scalar coefficient $c_{12}$ near its vacuum value 1 obeys $|c_{12}|\geq1/2$. An unused color mode satisfies $a_{02}b=0$. The original CAR therefore gives

$$a_{02}a^\dagger_{10}(\Phi)b=\overline{c_{12}}\,b,
\qquad
\|b\|^2\leq4\|a^\dagger_{10}(\Phi)b\|^2.
\tag{S5.12}$$

The norms use the original physical half-density. Integrate first over configuration, then extend the bound from the dense smooth core to the original closed preparation carrier by continuity. The annihilator bound $\|a_{02}\|\leq1$ and the coefficient lower bound give the second inequality. Actual dressed creation also multiplies by the original nonzero character $i/2$, so the created vector is nonzero, and its own norm gives the unique positive real normalization factor. The same CAR increment and unit norms give native hypercharge readings $-2,-1$ for the complete $N=2$ state and unchanged background.

At a fixed event's nonreal energy, the finite full-Yukawa resolvent inverse and original field vertex are continuous in transfer momentum, and the original test approximation is continuous linear. Every term of (12.9) is therefore continuous, and the endpoint contraction $L(k,M)$ is jointly continuous. Given output error $\eta$, first control $L$ in a common neighborhood of $(0,S_0)$. Equation (12.2) then controls the matrix, and $\|rn\|\leq r$ controls transfer. This gives $L(rn,r^2G)\to L(0,S_0)$ uniformly in direction. Error 1 generates $B_{DS}$ and a positive radius. The dominated convergence in (12.11) then uses this actual source-generated budget throughout.

If $Q_{\rm joint}u=\frac12u+v$ is the input return of the same original joint charge, write $V_i(k)$ for the two-leg current vertex in (12.9). The input cross terms of the original joint current are

$$I_e(k)_i=\langle v,V_i(k)u\rangle+\langle u,V_i(k)v\rangle,
\quad
\Xi_e=I_e+J_e^{\rm bg}-J_e^{\rm bg,Q}.
\tag{S5.13}$$

Here $J^{\rm bg,Q}_i=\langle Q_{\rm joint}b,V_i b\rangle+\langle b,V_iQ_{\rm joint}b\rangle$. Substitute $Q_{\rm joint}u$ into the two-sided expectation: $1/2+1/2$ gives the actual excited current. Subtracting the original charged background gives exactly $J^{\rm joint}=J+\Xi$. Bilinearly expanding the two complete original returns yields (12.12), retaining both cross terms and the return–return term.

### S5.6 Complete three-fermion ($N=3$) response, gauge projection, and coefficient

The original named modes obey the mother CAR $\{a_i,a_j^\dagger\}=\delta_{ij}$. Let $\Omega_d$ be the branch vacuum and let $\pi$ range over the permutations of three colors. The original triple products are

$$\begin{aligned}
\epsilon_d(s_0,s_1,s_2)&=\sum_\pi\operatorname{sgn}(\pi)
a^\dagger_{d,(s_0,\pi_0,0)}
a^\dagger_{d,(s_1,\pi_1,0)}
a^\dagger_{d,(s_2,\pi_2,1)}\Omega_d,\\
q_d^{(3)}&=\tfrac13\bigl[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)\bigr].
\end{aligned}
\tag{S5.14}$$

Eliminate the three creation operators from right to left using CAR. The inner product of two triple products is the determinant of their $3\times3$ Kronecker Gram matrix. The first term has six orthogonal unit occupation words and norm squared 6. In the second, the first two spins repeat: exchanging their two colors combines the two summands into one occupation word with coefficient 2. Three such groups give norm squared 12. The spin occupations of the two terms differ, so their cross inner product is zero. Consequently $\|q_d^{(3)}\|^2=(6+12)/9=2$. The actual source profile is 1 at $z_*$, so $q_\ell\ne0$ in the original positive configuration measure.

The operator $R_{0,F}$ preserves each sector $(N,j)$. The operator $Y$ preserves $N$ and increases $j$ by one. Since sector $(3,4)$ of the original $N=3$ carrier is empty, $T_F^4b=0$. The finite geometric sum gives

$$\begin{aligned}
(C_F+Y-\zeta)\sum_{j=0}^{3}T_F^jb
&=q+R_{0,F}^{-1}(-T_F^4b)=q,\\
P_{3,0}\sum_{j=0}^{3}T_F^jb&=b,
\qquad
\left\|\sum_{j=0}^{3}T_F^jb\right\|^2
=\sum_{j=0}^{3}\|T_F^jb\|^2.
\end{aligned}
\tag{S5.15}$$

The independent grade-preserving reference branch ($\sharp=1$) has vanishing raising action on the bottom sector, so its response is $b$. The actual two-sided inverses give $b\ne0,r\ne0$, while the original $H_0-C_F=d_F$ gives (13.2). From the same source equation, the complete response return of literal electromagnetic charge $Q_{\rm E}$ is

$$Q_{\rm E}r=q_d^{\rm EM}r+
\mathfrak R_F[(\mathfrak B_FQ_{\rm E}-Q_{\rm E}\mathfrak B_F)r],
\quad q_d^{\rm EM}=(-1)^d,
\quad \mathfrak B_F=C_F+Y^{(\sharp)}-\zeta.
\tag{S5.16}$$

This retains charge mixing from compression and Yukawa. Multiplication by $\|r\|^{-1}$ preserves the same return on the unit state.

Write $\Gamma_{\mu a}(p)$ for the original quantum action of the pure-gauge form. It preserves grade, hence $P\Gamma_{\mu a}=\Gamma_{\mu a}P$, where $P=P_{3,0}$. The projection $P$ is self-adjoint in the original configuration pairing, giving

$$\mathcal V_{\mu a}(p;Pv,w)=\mathcal V_{\mu a}(p;v,Pw).
\tag{S5.17}$$

If one endpoint lies on the grade-preserving reference branch, it equals its own bottom response $b$; (S5.17) projects the opposite endpoint to the bottom sector. This proves that the complete numerator equals the numerator in (13.5). The original pure-gauge form is conjugate-linear on the left and linear on the right. Normalization by positive real norms gives $w^{\rm actual}=w^{\rm base}/(\|r_L\|\|r_R\|)$. Substituting $z=\|b\|/\|r\|$ proves (13.6).

The constant of the complete field contraction also matters. The zero action of original unsupported field slots and every row of $F_0$ together give

$$F_0^{\mathsf T}J=(e_0+e_1)w^{\rm actual},
\qquad
G_0(e_0+e_1)=\sqrt{30}
\left(-\frac9{125}e_0-\frac{67}{72}e_1\right).
\tag{S5.18}$$

Therefore $-(e_0+e_1)^{\mathsf T}G_0(e_0+e_1)=\sqrt{30}(9/125+67/72)=K_*$. The actual $N=3$ detector contains a single $(hc_b)^{-1}$, so its complete $S_0$ coefficient is $K_*w_D^{\rm actual}w_S^{\rm actual}/(hc_b)$. Applying (13.6) to each pair proves (13.8). Finally, the continuous matrix reading commutes with the actual Bochner integral, and Theorem 12.1 gives (13.9). The full field is retained throughout the Fourier return. ∎

### S5.7 Proofs for the standard Maxwell cone, $N=3$ pole unit-charge cancellation, and three-channel far-field balance

This subsection provides self-contained proofs of Theorem 11.4 (§11.4), Theorem 12.4 (§12.4), and Theorem 14.1 (§14.1).

**(i) Polynomial standard-branch criteria and the transverse Maxwell cone (Theorem 11.4).** Assume the leading zero-clock denominator polynomial is nonzero, $D_{\mathrm{lead}}(e)\ne 0$. At every regular real momentum $\mathbf n\in\mathbb R^3\setminus\{0\}$ ($D_{\mathrm{lead}}(e)(\mathbf n)\ne 0$), putting the adjugate-quotient formula $T_{\mathrm{stat}}(e,\mathbf n)_{\mu\nu}=N_{\mathrm{stat}}(e)_{\mu\nu}(\mathbf n)/D_{\mathrm{lead}}(e)(\mathbf n)$ over a common denominator with (11.12) yields the exact entrywise identity

$$T_{\mathrm{stat}}(e,\mathbf n)_{\mu\nu}
-T^{\mathrm{std}}\bigl(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\bigr)(\mathbf n)_{\mu\nu}
=\frac{\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}(\mathbf n)}{D_{\mathrm{lead}}(e)(\mathbf n)\,|\mathbf n|^4}.
\tag{S5.19}$$

If $\mathcal R_{\mathrm{stat}}(e)=0$, the right-hand side vanishes at every regular $\mathbf n\ne 0$, proving the forward implication of (11.13). Conversely, suppose $\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}\ne 0$ for some $(\mu,\nu)$. Because $D_{\mathrm{lead}}(e)\ne 0$ and $|\mathbf X|^2\ne 0$ in the integral domain $\mathbb C[X_1,X_2,X_3]$, the product of three nonzero polynomials $P=D_{\mathrm{lead}}(e)\cdot|\mathbf X|^2\cdot\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}$ is nonzero; since $\mathbb R\subset\mathbb C$ is infinite, a nonzero polynomial in three variables cannot vanish identically on $\mathbb R^3$, so there exists $\mathbf n_\star\in\mathbb R^3$ with $P(\mathbf n_\star)\ne 0$, hence $|\mathbf n_\star|^2\ne 0$, $D_{\mathrm{lead}}(e)(\mathbf n_\star)\ne 0$, and $\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}(\mathbf n_\star)\ne 0$, giving $T_{\mathrm{stat}}(e,\mathbf n_\star)_{\mu\nu}\ne T^{\mathrm{std}}(\mathbf n_\star)_{\mu\nu}$ by (S5.19). On a whole-sphere regular chart $\eta$, setting $\mathbf n=\mathbf k/|\mathbf k|$ for $\mathbf k\in\mathbb R^3\setminus\{0\}$ substitutes $T^{\mathrm{std}}_{00}(\mathbf n)=c_{\mathrm{temp}}(e)$ into the temporal symbol to yield $c_{\mathrm{temp}}(e)/|\mathbf k|^2$ without angular averaging, returning $C_{\mathrm{EM}}^{\mathrm{gen}}(e)/|\mathbf x-\mathbf y|$ by Section S5.4.

For the dynamic branch, suppose $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)=0$, which clears denominators in the polynomial matrix ring as

$$\bigl(|\mathbf k_\varepsilon|^2 M_{\mathrm{Max}}(X)\,\mathcal E^{\mathsf T}\bigr)V_{289}(X)
=\frac34\,D_0(X)\,P_{\mathrm{curr}}(X).
\tag{S5.20}$$

Evaluating at $s\in\mathbb R$ with $D_0(s)\ne 0$ and multiplying by $D_0(s)^{-1}$ yields (11.15) via $T_{\mathrm{EM}}(e,\varepsilon,s,\mathbf n)=D_0(s)^{-1}\mathcal E^{\mathsf T}V_{289}(s)$ (the entrywise $\sigma\downarrow 0$ limit of $T_{\mathrm{EM}}^{\mathrm{corr}}$); expanding $j=j^{\mathrm{proj}}+j^{\mathrm{Ward}}$ bilinearly gives (11.16). At a real visible pole $a$ ($\operatorname{Im}a=0$) and visible electromagnetic channel $c=(c_1,c_2)$, left-multiplying column $c_2$ of (S5.20) by the constant embedding $\mathcal E$ lifts it to the 289-vector polynomial equation $H_{\mathrm{Max}}(X)V_{c_2}(X)=D_0(X)F_{\cdot,c_2}(X)$, where $H_{\mathrm{Max}}(X)=|\mathbf k_\varepsilon|^2\mathcal E M_{\mathrm{Max}}(X)\mathcal E^{\mathsf T}$. Let $d\ge 1$ be the root multiplicity of $D_0(X)$ at $X=a$ and $r$ the common $(X-a)$ root multiplicity across all 289 components of $V_{c_2}(X)$, writing $D_0(X)=(X-a)^d\widetilde D_0(X)$ and $V_{c_2}(X)=(X-a)^r\widetilde V_{c_2}(X)$ (so the zero-clock pole mode is $v_{a,c}=\widetilde V_{c_2}(a)\ne 0$). Because $a$ is a visible pole surviving greatest-common-divisor reduction of $(\mathcal E_{c_1}^{\mathsf T}V_{c_2}(X))/D_0(X)$, one strictly has $0\le r<d$ (otherwise $(X-a)^d$ would divide the numerator and cancel the pole). Canceling $(X-a)^r$ in the torsion-free module $\mathbb C[X]^{289}$ and evaluating at $X=a$ kills the right-hand side via $(a-a)^{d-r}=0$ ($d-r\ge 1$), giving $H_{\mathrm{Max}}(a)v_{a,c}=0$; left-multiplying by $\mathcal E^{\mathsf T}$ and using $\mathcal E^{\mathsf T}\mathcal E=\frac34 I_4$ and $|\mathbf k_\varepsilon|^2\ne 0$ establishes $M_{\mathrm{Max}}(a)(\mathcal E^{\mathsf T}v_{a,c})=0$ (whose spatial curl and divergence yield the homogeneous Faraday and magnetic Gauss laws).

For any $v\in\mathbb C^4$, applying the transverse projector $(\Pi_\perp(\mathbf k)v)_i=v_i-k_i(\mathbf k\cdot\mathbf v)/|\mathbf k|^2$ ($i=1,2,3$) to the spatial block of $M_{\mathrm{Max}}(a)v$ annihilates longitudinal $k_{\varepsilon,i}$ terms and leaves the pure scalar identity

$$\Pi_\perp(\mathbf k_\varepsilon)\bigl(M_{\mathrm{Max}}(a)v\bigr)
=\bigl(\varepsilon_{\mathrm{eff}}(e)\,\omega_{\mathrm{phys}}^2-\mu_{\mathrm{eff}}(e)^{-1}|\mathbf k_\varepsilon|^2\bigr)\,\Pi_\perp(\mathbf k_\varepsilon)v.
$$

Taking $v=\mathcal E^{\mathsf T}v_{a,c}$ makes the left-hand side vanish; since $\Pi_\perp(\mathbf k_\varepsilon)(\mathcal E^{\mathsf T}v_{a,c})\ne 0$, the scalar factor must vanish. Dividing by $\varepsilon_{\mathrm{eff}}|\mathbf k_\varepsilon|^2\ne 0$ ($\eta_{\mathrm{pair}}\ne 0$) and substituting (11.14) proves (11.17). Even prior to assuming $\mathcal R_{\mathrm{dyn}}=0$, at any visible real root $s$ satisfying pencil clock balance, electromagnetic-column clock finiteness, and nonvanishing clearing polynomial $d_{\mathrm{clear}}(s)\ne 0$—writing $N=\sqrt{54/125}$ for the background temporal coframe lapse of (1.1) (so the tree-level native gauge speed squared is $v_{\mathrm{nat}}^2=N^{-2}=125/54$, distinct from particle number), $\mathcal E_{\mathrm{rest}}$ for the 217-slot non-gauge-auxiliary field insertion, and $\mathcal C_{\mathrm{comp}}(p,Q_0,v_{\mathrm{mode}})$ for the full 289-slot polarization-and-background feedback vector—projecting the native principal forced balance onto any nonzero transverse slot $i$ prices the exact phase-speed feedback shift:

$$v_{\mathrm{phase}}^2(\varepsilon,s,\mathbf n)
=v_{\mathrm{nat}}^2
+\frac{\bigl[\Pi_\perp(\mathbf k_\varepsilon)\bigl(\mathcal E_{\mathrm{rest}}^{\mathsf T}\mathcal C_{\mathrm{comp}}(p,Q_0,v_{\mathrm{mode}})\bigr)\bigr]_i}
{2N\,|\mathbf k_\varepsilon|^2\,\bigl[\Pi_\perp(\mathbf k_\varepsilon)(\mathcal E^{\mathsf T}v_{\mathrm{mode}})\bigr]_i}.
\tag{S5.21}$$

**(ii) Three-fermion ($N=3$) pole Coulomb packet and $|Q_e|^2=1$ cancellation (Theorem 12.4).** By definition, $\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)=Q_{DS}^{\mathrm{pole}}\cdot\eta_{\mathrm{pair}}^2\mathcal P_{\mathrm{sec}}(e_F,00,\eta,\phi,\mathbf x)$. Under $D_{\mathrm{lead}}(e_F)\ne 0$ and $\mathcal R_{\mathrm{stat}}(e_F)=0$, pulling the constant $Q_{DS}^{\mathrm{pole}}$ inside the whole-sphere standard Lebesgue convolution established in (i) (with wavepacket inverse Fourier kernel $f_\phi=\mathcal F^{-1}\phi$ of (12.4)) proves (12.15), with $\lambda\downarrow 0$ convergence inherited directly. When $c_{\mathrm{phys}}(e_F)>0$, $h_{\mathrm{src}}>0$ makes $n_F=h_{\mathrm{src}}c_{\mathrm{phys}}(e_F)>0$ invertible; since Proposition 9.1 gives $q_{e,\mathrm{Noether}}(0)=q_e=1$ and $1^2=1$, we obtain

$$\alpha_{\mathrm{pole}}(e_F)
=\frac{1^2\cdot C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{n_F}
=\frac{C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)}.
\tag{S5.22}$$

Multiplying both sides of (12.15) by $n_F^{-1}$, pulling $n_F^{-1}$ inside the integral, and substituting (S5.22) establishes (12.16).

**(iii) Three-channel static decomposition and two-step far-field balance (Theorem 14.1, `L29`).** For every $(\kappa,\sigma,\mathbf n)$ with $\sigma>0$ and nonzero corrected determinant, the forced corrected static field splits identically into native, $G\cdot Q_{\mathrm{freq}}$ feedback, and nine-dimensional null-lift components:

$$X_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)
=X_{\mathrm{nat}}(\kappa,\mathbf n)
+G(p_{\kappa,\mathbf n})\,Q_{\mathrm{freq}}(\kappa,\sigma,\mathbf n)\,Y_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)
+L_{\mathrm{null}}(p_{\kappa,\mathbf n})\,c_{\mathrm{null}}(\kappa,\sigma,\mathbf n).
\tag{S5.23}$$

Left-multiplying by $J_{\mathrm{comp},D}^{\mathsf T}$ gives (14.1). Combining the bounded linear functional norm $|\mathcal M_{DS}(\kappa^2G)|\le\|\mathcal M_{DS}\|\cdot\|\kappa^2G\|$ with the sphere-uniform bound $\|\kappa^2G(p_{\kappa,\mathbf n})\|\le B_{\mathrm{whole}}$ ($0<\kappa<r_{\mathrm{nat}}$, $|\mathbf n|=1$) from Section S5.3 yields (14.2).

On the finite long-range return branch ($D_{\mathrm{IR}}(e,\mathbf n)\ne 0$, static clock divisibility, and pole order $\le 4$ across all 17 fractions), the ordered static chart theorem guarantees $\mathcal R_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)\to\mathcal R_{\mathrm{probe}}^{(0)}(\sqrt\kappa,\mathbf n)$ as $\sigma\downarrow 0$ for small $\kappa\in\mathcal D_{\mathrm{stat}}$; because $\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)$ is independent of $\sigma$, subtracting it in (14.1) proves the first limit in (14.3). Sending $\kappa\downarrow 0$ next, the ordered Coulomb return gives $-\kappa^2\mathcal R_{\mathrm{probe}}^{(0)}(\sqrt\kappa,\mathbf n)\to C_{\mathrm{ord}}(e,\mathbf n)$; subtracting $-\kappa^2\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)\to C_{\mathrm{nat}}$ yields

$$\lim_{\kappa\downarrow 0}\bigl[-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)\bigr]
=C_{\mathrm{ord}}(e,\mathbf n)-C_{\mathrm{nat}}
=:C_{\mathrm{fb+null}}(e,\mathbf n),
\tag{S5.24}$$

yielding the domination bound $|-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)|\le 1+|C_{\mathrm{ord}}(e,\mathbf n)-C_{\mathrm{nat}}|$ on the unit-tolerance neighborhood and rearranging directly to $C_{\mathrm{ord}}(e,\mathbf n)=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}(e,\mathbf n)$ in (14.4). ∎

The [public proof map](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-map.json) and [reproduction guide](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-reproduction.md) cover the main paper and this supplement at the same fixed public revision.

## References

[1] Gao, J. *From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*. CourtyCourt · Case 0, Zenodo, v3 (2026), DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339) (v1 DOI: [10.5281/zenodo.23210292](https://doi.org/10.5281/zenodo.23210292)).

[2] Gao, J. *Low-Energy Electromagnetic Emergence from a Zero-Knob Unified Source: Coupled Propagation, Unit Electron Charge, the Maxwell Cone, and $1/(4\pi r)$ Coulomb Return* (main text; v1 published archive *The Current Takes the Stand: From Coupled Propagation to Actual Electrons, Coulomb Response, and Born Dressing*, DOI: [10.5281/zenodo.23299174](https://doi.org/10.5281/zenodo.23299174)). CourtyCourt · Case 1 (2026).
