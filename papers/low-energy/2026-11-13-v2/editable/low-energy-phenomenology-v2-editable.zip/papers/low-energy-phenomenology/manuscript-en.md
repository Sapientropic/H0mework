# Low-Energy Electromagnetic Emergence from a Zero-Knob Unified Source: Coupled Propagation, Unit Electron Charge, the Maxwell Cone, and $1/(4\pi r)$ Coulomb Return

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**Formal verification and evidence hierarchy.** This paper (CourtyCourt · Case 1, second edition v2; the published first edition is archived at `10.5281/zenodo.23299174`) builds directly on the parameter-free unified mother action of the third-edition physics flagship [1], uniting all claims `L1-L29` with self-contained written proofs. Machine-checked theorems are verified in the Lean 4 (`v4.33.0`) kernel [32]: the complete axiom footprint of the spatial-evolution, Bochner–Fourier, spectral-resolvent, and pole-residue layers is strictly restricted to the three standard axioms `[propext, Classical.choice, Quot.sound]`, with zero `sorry`, zero `unsafe/partial` declarations, and zero custom physical axioms or imported experimental fine-structure inputs; high-dimensional rational propagation catalogs and fourth-order phase expansions are paired with independent exact rational verification receipts. Fixed source commits, exported theorem declarations, and reproduction commands are listed in Appendix B and “Code and data availability,” while multi-page propagation catalogs, operator interfaces, and step-by-step long-range proofs appear in the companion Proof Supplement (Sections S1–S5).

## Abstract

Within a parameter-free (zero-knob) unified field theory introducing no external electromagnetic coupling constant, hand-set charge unit, or postulated speed of light, we derive deductively from the nine-field coupled dynamics of the fixed $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ mother action [1] three-dimensional strongly continuous matter propagation, all-time causal Kubo response, the absolute unit electron charge $|Q_e|=1$, the transverse Maxwell dispersion cone, the real-space $1/(4\pi|\mathbf x-\mathbf y|)$ Coulomb potential, four-leg Born overlap dressing for three-fermion ($N=3$) composites, and three-channel far-field feedback balance. At the level of constrained propagation and real-space quantum evolution, we establish a uniform local Lipschitz nine-field solution family with Fréchet–Jacobi initial-data derivatives, reduce the 289-component real first-jet quadratic action without momentum denominators via three auxiliary eliminations, nine scalar-torque Ward constraints, and nine gauge–Lorentz symmetry directions onto a faithful 103-dimensional propagation section ($79$ canonical prepared modes $\oplus\ 24$ independent-dual complement modes) with exact 289-row field reconstruction, compute parameter-free fourth-order rational dispersions and exact fifth/sixth-order polynomial remainders for the vector and axial soft phases, and obtain from all 158 matter vertices an exact 42-digit action-normalized on-shell tree exchange incorporating the Einstein–Cartan axial contact $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$, the Hodge constitutive ratio $N^2=54/125$, and the absence of a single-point one-loop inverse-coupling intersection. On $L^2(\mathbb R^3,\mathbb C^{12})$, we characterize the exact self-adjoint domain of the occupied Dirac generator, construct all-real-time and all-real-amplitude ($\epsilon\in\mathbb R$) unitary evolution under locally bounded norm-continuous self-adjoint gauge controls, prove a uniform unit-ball remainder bound $\epsilon^2M^2|t|^2$ yielding the operator-norm Fréchet derivative at $\epsilon=0$, and recover positivity across all finite CAR words together with the causal Kubo commutator response.

At the level of emergent electrodynamics and long-range spatial return, the unbroken electromagnetic generator $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ assigns dressed joint characters $\pm 1/2$ to scalar–matter pairs while unconditionally locking the physical rest electron leg on the charged fermionic channel ($e=0$) to unit electromagnetic charge $|Q_e|=1$ and native temporal current $-1$; retaining all 64 rest-spinor weights, oriented age windows, and three finite-parameter leg-amputation residuals yields the static Coulomb seed $K_*=\frac{9023}{9000}\sqrt{30}$ and the on-shell photon pole response. We prove that the mixed electromagnetic carrier across all 289 field directions equals the exact 1650-monomial first-jet Fréchet Hessian of the mother action and preserves its residue–Jacobi flux identity under every positive clock rescaling $t'=ct$. Without angular averaging, sixteen-entry polynomial remainder criteria under a nonvanishing leading denominator characterize the whole-sphere standard electromagnetic branch—producing a regular real obstruction direction whenever violated—and lock every real visible transverse pole mode onto the **Maxwell light cone** $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$. For Schwartz wavepacket inputs, uniform all-direction Schur infrared domination and three-dimensional matrix Bochner–Fourier integration across opposite momentum transfers return the **single-$4\pi$ real-space Coulomb kernel $1/(4\pi|\mathbf x-\mathbf y|)$** for rest electrons, moving two-particle ($N=2$) connected currents, and Maxwell-conserved three-fermion ($N=3$) energy-pole packets, where $|Q_e|^2=1$ cancels automatically to leave the rescaling-invariant pole coupling quotient $C_{\mathrm{EM}}^{\mathrm{gen}}/(h_{\mathrm{src}}c_{\mathrm{phys}})$. Unit normalization of four-grade $N=3$ composite responses endogenously generates ground-sector Born overlaps $z_\ell\in(0,1]$ whose four-leg product $Z$ satisfies $C_{\mathrm{full}}=ZC_{\mathrm{base}}$ whenever each endpoint pair contains at least one grade-preserving reference leg; finally, the complete static current circuit splits identically into native Green, quantum-feedback, and nine-constraint null channels that maintain $O(\kappa^{-2})$ coefficient balance under the ordered far-field limit ($\sigma\downarrow 0$ followed by $\kappa\downarrow 0$).

**Keywords:** zero-knob unified field theory; emergent electrodynamics; unit electron charge; transverse Maxwell cone; real-space Coulomb potential; Born overlap dressing; constrained field propagation; operator-norm Kubo response.

<a id="sec-1"></a>

## 1 Introduction: Three Testimonies of One Current and Zero-Knob Electromagnetic Emergence

Making a large matrix smaller by elimination is easy; the stringent question is whether the reduced effective operator still reports the exact reading that the original unified action assigns to the original matter. In a parameter-free (zero-knob) unified field theory [1] that forbids introducing an external electromagnetic coupling constant $e$, hand-tuned hypercharge ratios, or an externally postulated speed of light $c$, every qualitative law and quantitative coefficient of low-energy electrodynamics must pass the same examination: every auxiliary elimination, subspace compression, physical-clock rescaling, and three-dimensional Fourier integral must retain an explicit inverse map back to the original 289-component field equations and independent spinor-dual pairing.

Before entering the 289-dimensional constrained field space and 504-mode many-body carrier, we call to the stand a four-dimensional invariant-subspace current that can be verified with pen and paper in three minutes. It testifies three times—as the exact expectation under finite nonlinear control evolution, as the two-leg derivative of the evolved state with respect to the control amplitude, and as an oriented Heisenberg commutator integral—followed immediately by a two-line arithmetic verification of the unit electron charge and static Coulomb rational seed. Every initial state, driving force, action current, and charge weight is locked uniquely by the same mother action.

### 1.1 Three-minute pen-and-paper anchor (I): A four-dimensional window from the twelve-dimensional occupied space

Take the mother-action fixed constants

$$s=\sqrt2,\qquad N^2=\frac{54}{125},\qquad
\alpha_0=\frac{3\sqrt2}{5},\qquad
\omega=\frac{3N}{2}(s-\alpha_0)=\frac{18\sqrt{15}}{125}>0.\tag{1.1}$$

Here $t$ is the original time coordinate, $N$ is the temporal lapse coefficient of the background coframe, $s$ is the axial spin-connection amplitude, and $\alpha_0$ is the spatial gauge-potential amplitude (written $(s,\alpha_0)$ here for the spin and gauge amplitudes denoted $(k,a)$ in [1], so as not to collide with spatial momentum $\mathbf k$ and scale factor $a$ below). We emphasize from the outset that **the four numbers in (1.1) are not hand-selected parameters**: the companion physics flagship [1, Definition 2.1, Propositions 2.2–2.4, Theorem 4.4] proves from a parameter-free positive smooth source occurrence that the constitutive ratio is $\sigma=1/2$ and that the nine-field classical world solution admitting lawful historical recovery is unique, locking every constant in (1.1) through the stationary cubic balance $\alpha_0^3=2\sigma N^2s=N^2s$ and ratio $\alpha_0/s=3/5$ (Section 2.3 gives the full nine-field configuration, and Section 3.1 establishes nonlinear evolution from arbitrary admissible initial data in a neighborhood). Tensoring the four-component Dirac spinor over the three-color exterior slice spanning the background color doublet and third color direction (embedding the eight-dimensional chiral core of [1] into its natural three-color completion) gives the twelve-dimensional occupied matter space

$$\mathcal H_{12}=\mathbb C^4\otimes\operatorname{span}\{e_{05},e_{15},e_{25}\}.$$

With spin indices ordered first and color indices second, the unit occupied vector is

$$w=\frac12(0,1,0,-1,0,0,0,1,0,-1,0,0)^{\mathsf T}.
\tag{1.2}$$

The original field amplitude at time zero is $\psi_0=2w$. Write the chirality matrix $Q=\operatorname{diag}(-1,-1,1,1)\otimes I_3$ and choose the original color generator

$$\rho_{01}=\begin{pmatrix}0&1&0\\-1&0&0\\0&0&0\end{pmatrix}.$$

Through the temporal gauge connection, it generates the Hamiltonian driving force $T$ and the mother-action variational current $B$:

$$T=-iI_4\otimes\rho_{01},\qquad B=-sQT.\tag{1.3}$$

Both are Hermitian, yet they are distinct operators: $T$ governs how the quantum state is driven in time, whereas $B$ reads the first-order gauge-variational current paired with the independent complex-linear dual $\chi$ in the mother action; the factor $-sQ$ carries the exact independent-dual spin flip and temporal kinetic weight.

Let $r=Tw$, $q=Qr$, and $p=Qw$. The four columns $F=(w,r,q,p)$ are orthonormal and span a common invariant subspace of the stationary Hamiltonian $h_0$, $T$, and $B$. In this orthonormal basis generated from the original state,

$$F^\dagger h_0F=
\begin{pmatrix}0&0&0&0\\0&0&2\omega&0\\0&2\omega&0&0\\0&0&0&0\end{pmatrix},
\qquad
F^\dagger TF=
\begin{pmatrix}0&1&0&0\\1&0&0&0\\0&0&0&1\\0&0&1&0\end{pmatrix}.
\tag{1.4}$$

Forming the positive and negative $Q$ eigencombinations $(w+p,r+q,w-p,r-q)/\sqrt2$ block-diagonalizes the system into two orthogonal $2\times2$ blocks:

$$h_{0,+}=\begin{pmatrix}0&0\\0&2\omega\end{pmatrix},\quad
h_{0,-}=\begin{pmatrix}0&0\\0&-2\omega\end{pmatrix},\quad
T_\pm=\sigma_x,\quad B_\pm=\mp s\sigma_x.
\tag{1.5}$$

The initial state in each block is $2^{-1/2}(1,0)^{\mathsf T}$. This four-dimensional window is an exact simultaneous invariant subspace of the twelve-dimensional occupied operators, not an externally adjoined two-level toy model.

### 1.2 Three-minute pen-and-paper anchor (II): Finite control before linear response, unit electron charge, and the Coulomb rational seed

**The first testimony comes from exact finite-amplitude evolution.** Applying an arbitrary real control amplitude $\epsilon\in\mathbb R$ to the temporal gauge connection gives the block Hamiltonians

$$h_{\epsilon,\pm}=\pm\omega I+\epsilon\sigma_x\mp\omega\sigma_z.
\tag{1.6}$$

Since the traceless part satisfies $(\epsilon\sigma_x\mp\omega\sigma_z)^2=(\omega^2+\epsilon^2)I$, setting $r_\epsilon=\sqrt{\omega^2+\epsilon^2}$ yields the exact matrix exponential immediately:

$$U_{\epsilon,\pm}(t)=e^{\mp i\omega t}
\left[\cos(r_\epsilon t)I-i\frac{\sin(r_\epsilon t)}{r_\epsilon}
(\epsilon\sigma_x\mp\omega\sigma_z)\right].\tag{1.7}$$

For every real $\epsilon,t\in\mathbb R$, (1.7) solves the initial-value problem under finite control. Acting on the two block initial states and summing $B_\pm=\mp s\sigma_x$ from (1.5) gives the exact finite-control current

$$\boxed{J_\epsilon(t)=
\frac{s\epsilon\omega}{\omega^2+\epsilon^2}
\left[1-\cos\!\left(2t\sqrt{\omega^2+\epsilon^2}\right)\right].}
\tag{1.8}$$

Differentiating with respect to $\epsilon$ at zero control yields the genuine parameter derivative of the finite solution family:

$$\boxed{\left.\partial_\epsilon J_\epsilon(t)\right|_0
=\frac{s}{\omega}(1-\cos 2\omega t).}\tag{1.9}$$

Note the order of operations: **solve the finite-amplitude problem for all real times first, then differentiate at $\epsilon=0$**; the nonlinear Rabi frequency shift $r_\epsilon=\sqrt{\omega^2+\epsilon^2}$ is already accounted for inside (1.8). Here $J_\epsilon$ is evaluated on the unit occupied state (1.2); the bilinear current of the background amplitude $\psi_0=2w$ is four times as large.

**The second testimony comes from two-leg state differentiation and two immediate negative controls.** In the basis $(w,r,q,p)$, the zero-control state remains $w$, and the first-order state variation is

$$\delta u(t):=\left.\partial_\epsilon U_\epsilon(t)w\right|_0
=-i\frac{\sin2\omega t}{2\omega}r
+\frac{\cos2\omega t-1}{2\omega}q.\tag{1.10}$$

Because $Bw=-sq$, the two legs of the current expectation together give

$$\delta u(t)^\dagger Bw+w^\dagger B\delta u(t)
=\frac{s}{\omega}(1-\cos2\omega t).\tag{1.11}$$

Two structural counterexamples expose any shortcut on the spot: differentiating only one state leg halves the amplitude, whereas replacing the mother-action current $B=-sQT$ with the Hamiltonian driving force $T$ causes the positive- and negative-chirality blocks to cancel identically to $0$. Computing the unitary matrix exponential correctly does not by itself guarantee reading the correct physical current.

**The third testimony comes from the oriented Heisenberg commutator integral.** With $U(t)=e^{-ith_0}$, set $T_H(\tau)=U(-\tau)TU(\tau)$ and $B_H(t)=U(-t)BU(t)$. Equation (1.4) gives

$$\operatorname{Re}\,i\langle w,[T_H(\tau),B_H(t)]w\rangle
=2s\sin\bigl(2\omega(t-\tau)\bigr).$$

Integrating over $\tau\in[0,t]$ yields

$$\operatorname{Re}\,i\int_0^t
\langle w,[T_H(\tau),B_H(t)]w\rangle\,d\tau
=\frac{s}{\omega}(1-\cos2\omega t),\tag{1.12}$$

matching (1.9) and (1.11) identically, including at negative times $t<0$ via the oriented integral. Section 8 establishes this same identity on the infinite-dimensional space $L^2(\mathbb R^3,\mathbb C^{12})$ via a uniform unit-ball operator-norm quadratic remainder bound $\epsilon^2M^2|t|^2$.

**Extending the pen-and-paper check to emergent electrodynamics (Sections 9–12).** Two lines of arithmetic likewise preview charge quantization and the static Coulomb seed in the second half of the paper. On the seven-dimensional fundamental basis $(c_0,c_1,c_2,w_0,w_1,h_+,h_-)$, the unbroken electromagnetic generator $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ has diagonal weights $\bigl(-\frac12,+\frac12,0,0,0,-\frac12,+\frac12\bigr)$ (Section 9.3, (9.7)). Pairing a four-index scalar $\Phi\in\Lambda^4\mathbb C^7$ with a two-index spinor $\psi\in\Lambda^2\mathbb C^7$ yields weight sums $\frac12+(-1)=-\frac12,+\frac12-\frac12=-\frac12$ across all three color channels (dressed joint characters $\pm 1/2$), whereas on the physical rest leg of the charged fermionic channel ($e=0$), the independent-dual Noether charge and temporal pairing obey $a_{\mathrm{src}}h_{\mathrm{src}}=1$, unconditionally locking the **unit electron charge $|Q_e|=1$** alongside native temporal current $-1$ (Section 9.3 Proposition 9.1, Section 10.1 Proposition 10.1). Meanwhile, summing the inverse eigenvalues of the two surviving spatial gauge slots in the five-dimensional 289-field static kernel gives

$$\frac{9}{125}+\frac{67}{72}=\frac{648+8375}{9000}=\frac{9023}{9000},$$

which upon multiplication by $\sqrt{30}$ produces the exact static Coulomb seed $K_*=\frac{9023}{9000}\sqrt{30}$ governing both endpoint Coulomb readouts and the $1/(4\pi|\mathbf x-\mathbf y|)$ real-space return (Theorems 9.2, 10.3, and 12.1).

### 1.3 Central question, four pillars, and paired falsifiability gates

The central question of this paper is: **starting from the single $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ mother action [1] with all tunable physical knobs eliminated, can constrained nine-field coupled propagation deductively generate—without empirical inputs—three-dimensional strongly continuous matter evolution, all-time operator-norm causal Kubo response, the absolute unit electron charge $|Q_e|=1$, the transverse Maxwell dispersion cone, the real-space $1/(4\pi|\mathbf x-\mathbf y|)$ Coulomb potential, and many-body Born overlap and far-field feedback closure?**

Every theorem below obeys one compositional principle: **the original field equations generate constrained propagation, the original external legs generate conserved sources, and the mother action generates both the independent-dual current and its second-variation Hessian; on spatial preparations and composite external states, the operator-norm derivative of finite quantum evolution, pole residues, and three-dimensional matrix Bochner integrals return to the electrodynamic observables of that same action.** Table 1 summarizes the inputs, core constructions, and outputs of the four pillars (`L1-L29`); Figure 1 depicts how the first three pillars meet at the $\epsilon=0$ current response.

**Table 1. Inputs, core constructions, and deductive outputs across the four pillars (`L1-L29`).**

| Pillar and sections | Exact inputs | Core constructions and invariants | Deductive outputs and claims |
|---|---|---|---|
| **Pillar I (Sections 2–6, Appendix A, Supplement S1–S2)**: Constrained propagation, fourth-order soft phases, and tree exchange | Seven homogeneous real initial values in $\mathcal A$; 289 real first-jet perturbations and $p\in\mathbb C^4$; 158 matter vertices and 216 free external legs | Nine scalar-torque Ward inverses plus denominator-free 9-symmetry polynomial section $289\to 103=79\oplus 24$; 77-mode fourth-order recursion; Lorentz-connection inverse yielding ECSK axial contact $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ | Joint local nine-field family and derivative $\exp(tJ_0)$; absence of a single-point running crossing; vector/axial fourth-order rational dispersions; 42-digit rational on-shell tree exchange; Hodge ratio $N^2=54/125$ (`L1-L11`) |
| **Pillar II (Sections 7–8, Supplement S3)**: $L^2(\mathbb R^3,\mathbb C^{12})$ all-time unitary evolution and operator-norm Kubo derivative | $L^2$ initial states and arbitrary finite test families; locally bounded norm-continuous self-adjoint gauge controls $R(t)$ and $\epsilon\in\mathbb R$ | Bidirectional Fourier-multiplier domain characterization; globally bounded radial Picard map $b(v)=v/(1+\|v\|)$ and norm-conserving window gluing; uniform unit-ball bound $\epsilon^2M^2\lvert t\rvert^2$ | Two-time unitary propagator $W_\epsilon(t,a)$ for all $t,a,\epsilon\in\mathbb R$; whole-word CAR positivity and single-$S$ mother readback; operator-norm Fréchet derivative at $\epsilon=0$ and causal Kubo formula (`L12-L17`) |
| **Pillar III (Sections 9–11, Supplement S4, S5.1–S5.2, S5.7)**: Unit electron charge $\lvert Q_e\rvert=1$, mother Hessian identity, and transverse Maxwell cone | Configuration half-density preparations; charged channel ($e=0$) rest electron leg, 64-weight oriented age windows, and nonreal resolvents; 1445-slot real first jet | Separation of dressed joint characters $\pm 1/2$ from rest-electron unit charge; identity of 1650-term second variation with 3071-term $H_{289}(p)$; $R_cK'_c$ clock invariance; 16-entry polynomial Maxwell gates | Calibration-free proof of $\lvert Q_e\rvert=1$, temporal current $-1$, and static seed $K_*=\frac{9023}{9000}\sqrt{30}$; positive-clock flux invariance; angle-average-free locking of the transverse **Maxwell cone** $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$ (`L18-L26` and standard extension) |
| **Pillar IV (Sections 12–14, Supplement S5.3–S5.7)**: Real-space single-$4\pi$ Coulomb return, $N=3$ Born overlap dressing, and 3-channel far-field balance | Schwartz wavepackets $\phi$; rest electrons, moving $N=2$ connected currents, $N=3$ energy-pole sections, and 4-grade composite legs | Uniform all-direction Schur IR radius; opposite-transfer 3D matrix Bochner integral and Gaussian regulator removal; $(3,0)$ bottom-sector projection; 3-channel circuit under $\sigma\downarrow 0$ then $\kappa\downarrow 0$ | Unique single-$4\pi$ real-space Coulomb kernel $1/(4\pi\lvert\mathbf x-\mathbf y\rvert)$; automatic $\lvert Q_e\rvert^2=1$ cancellation and pole quotient $\alpha_{\mathrm{pole}}$; four-leg Born dressing $C_{\mathrm{full}}=ZC_{\mathrm{base}}$; $O(\kappa^{-2})$ native–feedback–null far-field balance (`L27-L29` and $N=3$ pole extension) |

Trust in a zero-parameter theory is built not by defensive disclaimers, but by **paired positive universal theorems and structural counterexamples / falsifiability gates**: omitting any algebraic link required by the mother action triggers an immediate, computable quantitative failure. Table 2 collects six paired positive/negative controls established across the text.

**Table 2. Six paired positive theorems and structural counterexamples / falsifiability gates.**

| Structural link | Positive zero-knob theorem (full structure retained) | Structural counterexample or distortion upon omitting one link | Location |
|---|---|---|---|
| **Action current vs driving force** | Two-leg variation on the independent-dual current $B=-sQT$ yields $\frac{s}{\omega}(1-\cos 2\omega t)$, matching the finite-control derivative and Kubo integral | Differentiating one leg halves the amplitude; replacing $B$ by the driving force $T$ causes the chiral blocks to **cancel identically to $0$** | Section 1.2 (1.9)–(1.12), Section 8.3 |
| **True gauge–Lorentz section vs naive diffeomorphisms** | Three color-$\mathrm{SU}(2)$ and six Lorentz tangents annihilate $H_{112}(p)$ identically, and the denominator-free section $K_{103}$ reconstructs all 289 field rows | Four naive coordinate-variation candidates leave **128 nonzero residual entries**; coframe Hodge temporal scaling differs from ordinary 2-form pullback by $-2/N\ne 0$ | Section 2.4 (2.16)–(2.17), Section 4.2 Proposition 4.1 |
| **Whole-word CAR evaluation vs premature compression** | Forming the 4-point CAR word $a^\dagger(u_p)a(u_p)a^\dagger(u_p)a(u_p)$ in $\Lambda E$ before pulling back via a single $S$ returns **$1$** | Compressing each creation/annihilation operator to the 1-particle sector before multiplying loses the vacuum-sector return and **collapses the reading to $0$** | Section 3.4 Proposition 3.4, Section 7.4 Proposition 7.3 and (7.16a) |
| **Bare temporal gauge charges vs dressed electron current** | Source-prepared configuration covectors and the rest electron leg activate the difference of spatial gauge slots 21 and 34 ($A_1^{\,0}-A_2^{\,1}$), yielding $\lvert Q_e\rvert=1$ and $K_*=\frac{9023}{9000}\sqrt{30}$ | Solving the coupled static system with the 12 bare temporal gauge charges gives **zero $1/\lvert\mathbf k\rvert^2$ Coulomb residue in every direction** across all 144 entries | Section 6.7 Proposition 6.3 vs Section 9.4 Theorem 9.2, Section 10.4 Theorem 10.3 |
| **Whole-sphere standard EM branch vs anisotropic obstruction** | Under a nonzero leading denominator $D_{\mathrm{lead}}(e)\ne 0$, vanishing of the 16-entry polynomial remainder $\mathcal R_{\mathrm{stat}}=0$ is equivalent without angular averaging to the standard tensor across all regular real directions, and $\mathcal R_{\mathrm{dyn}}=0$ locks $v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2$ | Whenever $\mathcal R_{\mathrm{stat}}\ne 0$ (with $D_{\mathrm{lead}}(e)\ne 0$), there is a **regular real obstruction direction** $\mathbf n\in\mathbb R^3\setminus\{0\}$ falsifying the standard tensor | Section 11.4 Theorem 11.4, Supplement S5.7 |
| **Three-channel far-field circuit vs truncating feedback/null** | Retaining native Green, quantum feedback, and 9 null modes under $\sigma\downarrow 0$ then $\kappa\downarrow 0$ satisfies $C_{\mathrm{ord}}=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}$ | The combined correction is $O(\kappa^{-2})$. When $C_{\mathrm{fb+null}}\ne0$, omitting it loses that part of the far-field coefficient | Section 14.1 Theorem 14.1, Figure 7, Supplement S5.7 |

![The original action, propagation, and the same current](figures/main-01-common-current-en.svg)

**Figure 1. The origin and return of the same current.** The left and middle columns generate homogeneous nine-field nonlinear development and 289-dimensional constrained propagation from the mother action; the right column generates $L^2(\mathbb R^3,\mathbb C^{12})$ spatial preparation and finite-amplitude unitary evolution from the matter action. The vermilion panel at the bottom is where the three paths meet: the independent-dual action current, two-sided state variation, and causal Kubo integral yield the identical response at $\epsilon=0$. Arrows carry explicit field, equation, or source reconstruction maps without conflating the three domains.

### 1.4 Carrier and sign-convention quick guide, 15-minute verification pathways, and literature coordinates

To reduce working-memory overhead across sections, Table 3 summarizes the five carriers, their dimensions, and the time/resolvent sign conventions used throughout the paper. Two distinctions prevent common misreadings at first sight: (i) propagation algebra uses the growth variable $p=(\lambda,i\mathbf k)$ (so $\lambda^2<0$ represents real-frequency oscillation $\lambda=-iE$), Section 7 uses the one-body resolvent $(E-h(\mathbf k))^{-1}$, and Sections 9–13 uniformly use $(H-zI)^{-1}$; (ii) fractional hypercharge weights on single exterior basis modes, half-unit dressed joint characters $\pm 1/2$ on scalar–matter pairs (Section 9.3), the unit charge $|Q_e|=1$ on the physical rest electron leg (Section 10.1), and integer charges $\pm 1$ on color-singlet three-fermion ($N=3$) composites (Sections 12.4 and 13) act on distinct composition levels and are mutually consistent.

**Table 3. Quick guide to core carriers, dimensions, and time/resolvent conventions.**

| Carrier or symbol | Mathematical space and dimension | Physical role and section location |
|---|---|---|
| Mother matter carrier $\mathcal M$ and independent dual $\chi$ | $\mathbb C^4\otimes(\Lambda^6\oplus\Lambda^2\oplus\Lambda^4)\mathbb C^7$ (252 complex dims), $\chi\in\mathcal M^*$ | Single-generation chiral exterior spinors and independent complex-linear dual; prepared sector satisfies $\chi=s\psi^\dagger S$, $S=\gamma^0\gamma^5$ (Sections 2.1–2.2, 4.4) |
| Active first jet and faithful propagation quotient | $\mathbb R^{289}\to\mathbb R^{103}=\mathbb R^{79}\oplus\mathbb R^{24}$; first jet $5\times 289=1445$ real slots | Coupled gravity–gauge–scalar–matter quadratic action $H_{289}(p)$; denominator-free section splits into 79 prepared modes and 24 dual-complement modes (Sections 4.1–4.4, 11.1) |
| Free on-shell external-leg subspace | $\mathbb C^{216}\hookrightarrow\mathcal M$ (fifty $2\times2$ blocks + twenty-nine $4\times4$ blocks) | Full-momentum Hermitian spectrum on $\ker Y_R(v)$ with kinetic-residue scale $u_{\mathrm{action}}=2^{-1/4}u_{\mathrm{coord}}$ (Sections 6.4–6.6) |
| Spatial occupied Hilbert carrier $\mathscr H$ | $L^2(\mathbb R^3,\mathbb C^{12})$ and antisymmetric Fock spaces $\Lambda E$ over finite test spans | Self-adjoint Dirac generator $\mathsf H$ over $\mathcal H_{12}$, all-time controlled unitary propagator $W_\epsilon(t,a)$, and whole-word CAR readback (Sections 7–8) |
| Many-body configuration–Fock carrier | 100-dim configuration half-densities $\times$ 504-mode CAR (sectors $N=k$) | Configuration preparation $v_\varepsilon$, $N=2$ connected currents, $N=3$ energy-pole packets, and 4-grade $(3,j)$ Born overlap responses (Sections 9.2, 12.3–13) |
| Time, momentum, and resolvent dictionary | Original time $t$, proper time $\tau=Nt$; $p=(\lambda,i\mathbf k)$, $\mathbf k=2\pi\xi$; $h_{\mathrm{src}}a_{\mathrm{src}}=1$ | $\lambda=-i\omega$ ($\lambda^2<0$ oscillatory); Section 7 resolvent $(E-h)^{-1}$, Sections 9–13 resolvent $(H-zI)^{-1}$; nondimensionalizing divisor $h_{\mathrm{src}}c_{\mathrm{src}}$ (Sections 2.5, 9.3) |

**15-minute fast verification pathways by specialty.** Because the paper spans effective field theory, constrained gauge–gravity reduction, functional-analytic evolution groups, and infrared quantum electrodynamics, specialists who have checked the three-minute anchor in Sections 1.1–1.2 may jump directly to any of four self-contained verification tracks:

- **Effective field theory, grand-unified running, and spin–torsion gravity**: Read **Sections 2.1, 2.4, 4–6, Appendix A, and Supplement S1–S2 (Propositions 2.1, 4.1, 5.1, Theorem 6.1, and Propositions 6.2–6.3)** to verify why the single-generation chiral–scalar inventory strictly forbids a single-point running crossing (contrasting with Georgi–Glashow [7] and Georgi–Quinn–Weinberg [8]), how 289 constrained fields reduce without momentum denominators to $103=79\oplus 24$ with exact 289-row reconstruction (contrasting with Dirac [13], DeWitt [14], and Abbott [2]), how eliminating 77 heavy modes fixes fourth-order soft-phase coefficients with zero free low-energy constants (contrasting with Weinberg [15] and Appelquist–Carazzone [16]), and how the ghost-free 18 curved gauge–Lorentz identities (contrasting with Slavnov–Taylor [36]) and Lorentz-connection elimination produce the parameter-free ECSK axial contact $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ and 42-digit rational on-shell amplitude (contrasting with Kibble [10], Sciama [11], and Hehl et al. [12]).
- **Rigorous functional analysis, nonautonomous quantum evolution, and linear response**: Jump from Sections 1.1–1.2 to **Sections 7–8 and Supplement S3 (Proposition 7.1, Theorem 7.2, Proposition 7.3, Theorems 8.1–8.2, and Corollary 8.3)** to verify the bidirectional domain characterization of the unbounded Dirac generator on $L^2(\mathbb R^3,\mathbb C^{12})$ (contrasting with Stone [17] and Thaller [18]), global unitary gluing via the bounded radial Picard map without uniform whole-line norm bounds or $C^1$ domain hypotheses (contrasting with Dyson [19] and Kato [5]), whole-word CAR positivity on arbitrary linearly dependent test families (contrasting with Araki [20] and Tasaki [4]), and the uniform unit-ball operator-norm Kubo Fréchet derivative without equilibrium $[\rho,\mathsf H]=0$ assumptions (contrasting with Kubo [6] and Bratteli–Robinson [21]).
- **Emergent electrodynamics, charge quantization, and constitutive light cones**: Read **Sections 6.7, 9–11, and Supplement S4, S5.1–S5.2, S5.7 (Proposition 9.1, Theorem 9.2, Remark 9.3, Proposition 10.1, Lemma 10.2, Theorems 10.3–10.4, Theorem 11.1, Proposition 11.2, and Theorems 11.3–11.4)** to verify how $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ simultaneously supports half-unit dressed characters and the rest-electron unit charge $|Q_e|=1$ (contrasting with Pati–Salam [9]), how the 1650-monomial mother second variation reproduces $H_{289}(p)$ term by term while preserving positive-clock flux invariance, and how 16-entry polynomial remainder gates collapse high-degree constitutive dispersion onto the non-birefringent transverse Maxwell cone $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$ without angular averaging while retaining generalized Ward residuals [22, 23, 36] and pre-metric constitutive structure [24].
- **Infrared QFT, dressed charged states, and many-body scattering**: Read **Sections 12–14.1 and Supplement S5.3–S5.7 (Theorem 12.1, Corollary 12.2, Theorems 12.3–12.4, Theorem 13.1, and Theorem 14.1)** to verify how uniform all-direction Schur domination and three-dimensional matrix Bochner integration separate contact polynomials to return the single-$4\pi$ Coulomb kernel $1/(4\pi|\mathbf x-\mathbf y|)$ (contrasting with Donoghue [30]), how $N=3$ composite pole packets (contrasting with Haag [34]) obey full-field Maxwell continuity with automatic $|Q_e|^2=1$ cancellation, how four-grade composite responses yield UV-cutoff-free $(0,1]$ valence-core Born overlap dressing $C_{\mathrm{full}}=ZC_{\mathrm{base}}$ (contrasting with Källén [33], Lehmann [25], LSZ [26], and Weinberg [35]), and how the three-channel static circuit preserves same-order native, quantum-feedback, and nine-null-mode balance in the ordered far-field limit (contrasting with Dirac [27], Kulish–Faddeev [28], and Buchholz [29]). Section 14.2 provides a systematic comparison table (Table 4) across all five traditions and 36 primary works.

<a id="sec-2"></a>

## 2 The zero-knob mother action, nine-field background, and non-crossing criterion

### 2.1 The field source and carrier

We use the same positive smooth unified source and unique classical world configuration as [1]. The mother group is $\mathrm{Spin}^{+}(1,3)\times\mathrm{SU}(7)$; in [1, Theorem 2.2], commutation with the source-generated adjoint spectral order parameter together with block trace equations bijectively selects the Standard Model gauge subalgebra in which the actual connection takes values:

$$\mathfrak h=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1),
\qquad (C,W,y)\longmapsto\operatorname{diag}(C,W,y,-y).\tag{2.1}$$

Below we refer to (2.1) simply as the Standard Model gauge-block embedding. The seven-dimensional basis $(c_0,c_1,c_2,w_0,w_1,h_+,h_-)$ is indexed by $0,\ldots,6$. Three exterior-power layers form the single-generation chiral matter carrier

$$\mathcal M=\mathbb C^4\otimes
\left(\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7\right),
\qquad \dim_{\mathbb C}\mathcal M=4(7+21+35)=252.\tag{2.2}$$

Here $e_I$ denotes the unit exterior basis vector whose index set is sorted in increasing order. The specified scalar vacuum is

$$v=e_{0126}+e_{0124}+e_{0156}+e_{0145},\qquad \|v\|^2=4.\tag{2.3}$$

To prevent misreadings when encountering single-mode exterior quantum numbers or one-loop coefficients, two structural facts should be noted upfront. First, the raw hypercharge weights on single-fermion exterior basis modes in (2.2) are pre-composite basis coordinates: in Sections 9.3 and 10.1, the unbroken electromagnetic generator $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ produces relative characters $\pm 1/2$ on scalar–matter dressed pairs while unconditionally assigning the exact integer unit charge $|Q_e|=1$ to the physical rest electron leg, and integer charges $\pm 1$ to color-singlet three-fermion ($N=3$) composites in Sections 12.4–13 (compare Pati–Salam [9], which derives integer lepton charges from non-Abelian color–weak combinations, though here within a single simple $\mathrm{SU}(7)$ factor). Second, in contrast to Georgi–Glashow $\mathrm{SU}(5)$ unification [7] with hand-selected reducible representations $\bar{\mathbf 5}\oplus\mathbf{10}$ and Georgi–Quinn–Weinberg [8] assuming a single-point one-loop inverse-coupling crossing across a threshold-free desert, the fixed inventory satisfies the following exact criterion (full arithmetic and group-theoretic proofs are given in Appendices A.1–A.3):

**Proposition 2.1 (Absence of a single-point one-loop crossing and bare vacuum stabilizer, `L1-L2`).** Substituting the single-generation chiral exterior carrier (2.2) plus one complex $\Lambda^4\mathbb C^7$ scalar into the standard one-loop algebraic formula yields, in the order $(\mathrm{SU}(7),\mathrm{SU}(3),\mathrm{SU}(2),\mathrm U(1))$, the coefficients $b_0=(56/3,4,1/3,-28)$; under the native constitutive parameter $\sigma=1/2$ and affine running coordinate $\ell=\ln(\mu/\mu^*)/(8\pi^2)$, because restricting the mother $\mathrm{SU}(7)$ trace to the two-entry hypercharge embedding $(y,-y)$ in (2.1) equals twice the native pairing $\kappa(y,z)=-\operatorname{Re}(yz)$ (so $I_1(0)=\sigma=1/2$ at the reference scale $\ell=0$, whereas $I_3(0)=I_2(0)=1$ on the special-unitary blocks), the three inverse-coupling lines $I_3=1+4\ell$, $I_2=1+\ell/3$, and $I_1=\frac12-7\ell$ are simultaneously positive on $-1/4<\ell<1/14$ and **have no common single-point intersection** anywhere ($I_3=I_2$ forces $\ell=0$, where $I_1=1/2\ne 1$). Simultaneously, the $7\times 21$ exterior-wedge Yukawa matrix of the vacuum $v$ satisfies $YY^\dagger=\operatorname{diag}(2,2,2,4,2,0,0)$ (rank $5$, kernel dimension $16$), the bare gauge–scalar quadratic block has rank $9$ (nonzero eigenvalues $1\,[6]$ and the three real roots of $6x^3-26x^2+27x-8=0$), and the compact stabilizer in $\mathrm{SU}(7)$ is isomorphic to $(\mathrm{SU}(2)\times\mathrm{USp}(4)\times\mathrm U(1))/\mathbb Z_2$, intersecting the subgroup (2.1) in the unbroken color $\mathrm{SU}(2)$ on the first two colors.

Proposition 2.1 shows from the outset that under the zero-knob mother action, low-energy couplings connect to experimental scales not through naive desert line-crossing, but through genuine heavy-field propagation inverses and finite threshold decoupling (tree-level elimination in Sections 4–5; 108-channel threshold decoupling in Case 3).

The nine independent fields are the coframe $e$, spin connection $\varpi$ (in the first-order independent frame–connection geometric tradition of Kibble [10] and Sciama [11], coupled further to simplicity two-forms and chiral exterior matter), gravitational two-form $\mathcal B$, simplicity multiplier $\Lambda$, gauge connection $A$, gauge two-form $B_A$, scalar $\Phi\in\Lambda^4\mathbb C^7$, matter $\psi\in\mathcal M$, and independent complex-linear dual field $\chi\in\mathcal M^*$. The fields $\chi$ and $\psi$ have independent variations. The relation $\chi=s\psi^\dagger S$ used below belongs to actual solutions and the specified prepared sector; it does not define the original field space.

Curvatures are calculated from these fields: $F_\varpi=d\varpi+\varpi\wedge\varpi$ and $F_A=dA+A\wedge A$. Likewise, covariant derivatives are calculated from the actual first derivatives of the fields, rather than supplied as additional independent data. We write the formulas on coordinate chart zero of the source; the other charts are transported by the same mother representation and its dual.

### 2.2 An action with its normalization intact

Set $\eta=\operatorname{diag}(-1,1,1,1)$, $g=e^{\mathsf T}\eta e$, and $\nu_e=|\det e|$. Spacetime two-forms and internal bivectors are both ordered as $(01,02,03,23,31,12)$, while their two types of indices remain distinct. Write

$$J=\begin{pmatrix}0&I_3\\-I_3&0\end{pmatrix},\qquad
(\Sigma_e)_{Ip}=e^{a_I}_{\mu_p}e^{b_I}_{\nu_p}-e^{a_I}_{\nu_p}e^{b_I}_{\mu_p}.$$

Here $J$ is internal bivector duality, and $\star_e$ is the Hodge operator on spacetime two-forms. Define $p^c=(3,4,5,0,1,2)$, $\epsilon_I=(-1,-1,-1,1,1,1)_I$, and

$$W_\kappa(X,Y)=\sum_p\kappa(X_p,Y_{p^c}),\qquad
W_{\rm top}(X,Y)=\sum_{I,p}\epsilon_I X_{Ip}Y_{I,p^c}.\tag{2.4}$$

On the two special-unitary blocks, $\kappa(X,Y)=-\operatorname{Re}\operatorname{tr}(XY)$; on the original hypercharge coordinate, $\kappa(y,z)=-\operatorname{Re}(yz)$. The latter is not doubled by the two diagonal entries of the mother embedding. Write $\widehat F_{\varpi,Ip}=\epsilon_I F^{\rm raw}_{\varpi,Ip}$, where “raw” denotes the original curvature coordinates with both internal indices lowered.

We use the Dirac matrices and chirality operator

$$\gamma^0=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\quad
\gamma^i=\begin{pmatrix}0&\sigma_i\\\sigma_i&0\end{pmatrix},\quad
\gamma^5=\operatorname{diag}(-I_2,I_2),\quad S=\gamma^0\gamma^5.\tag{2.5}$$

On $\mathcal M$, each is tensored with the identity on the exterior-power layers. The operator $S$ satisfies $S^\dagger=S$ and $S^2=I$; it exchanges the chiral blocks and connects the specified dual to the coordinate inner product. Set

$$\Gamma_e^\mu=(e^{-1})^\mu{}_a\gamma^a,\quad
\Omega_\mu=\frac14\varpi_{\mu ab}\gamma^a\gamma^b,\quad
D_\mu\psi=\partial_\mu\psi+(\Omega_\mu+\rho(A_\mu))\psi,
$$

$$D_\mu\Phi=\partial_\mu\Phi+\rho_4(A_\mu)\Phi,\qquad
Y_R(\Phi)=T_\Phi P_R,\quad P_R=\operatorname{diag}(0,0,1,1),$$

$$T_\Phi(w_6,w_2,w_4)=(w_2\wedge\Phi,0,0),\qquad
V(\Phi)=\|\Phi-v\|^2.\tag{2.6}$$

The right-handed Yukawa action maps $\Lambda^2$ to $\Lambda^6$. Its direction is part of the original action; the independent dual then evaluates the resulting vector.

The common local density is

$$\begin{aligned}
\mathcal L={}&W_{\rm top}(\mathcal B,\widehat F_\varpi)
-\frac12W_{\rm top}(\mathcal B,J\mathcal B)
+W_{\rm top}(\Lambda,\mathcal B-J\Sigma_e)\\
&+\sum_{j=3,2,1}\left[W_j(B_{A,j},F_{A,j})
-\frac12W_j(B_{A,j},g_j^2\star_e B_{A,j})\right]\\
&+\nu_e\left[\frac12g^{\mu\nu}\operatorname{Re}\langle D_\mu\Phi,D_\nu\Phi\rangle
-V(\Phi)+\operatorname{Re}\chi\bigl(i\Gamma_e^\mu D_\mu\psi+Y_R(\Phi)\psi\bigr)\right],
\qquad g_j^2=\sigma=\frac12.
\end{aligned}\tag{2.7}$$

This formula fixes the normalization of every quadratic form and vertex used below. The BF terms are already coefficients of four-forms; only the last line is additionally multiplied by the volume density. It is $g_j^2$, rather than $g_j$, that equals $1/2$. The independent dual of $\psi$ already supplies the left pairing, so the Yukawa term contains neither an inserted $\gamma^0$ nor an additional reverse adjoint term.

### 2.3 The nine fields of the specified background

Using $q_0=e_{05},q_1=e_{15}\in\Lambda^2\mathbb C^7$, define

$$C(u,v)=\begin{pmatrix}0&u\\-u&0\\0&v\\-v&0\end{pmatrix},\qquad
\Psi[u,v]_r=\sum_{a=0}^1C(u,v)_{ra}q_a,
\quad \Xi[p,q](z)=\sum_{r,a}C(p,q)_{ra}q_a^*(z_r).\tag{2.8}$$

There is no complex conjugation in the expression for $\Xi$. On the first two colors, the three color-doublet generators are

$$\tau_0=\frac12\begin{pmatrix}0&i\\i&0\end{pmatrix},\quad
\tau_1=\frac12\begin{pmatrix}0&1\\-1&0\end{pmatrix},\quad
\tau_2=\frac12\begin{pmatrix}i&0\\0&-i\end{pmatrix},\qquad
\kappa(\tau_i,\tau_j)=\frac12\delta_{ij}.\tag{2.9}$$

They vanish on all remaining coordinates. The specified configuration is

$$\begin{gathered}
e_0=\operatorname{diag}(N,1,1,1),\quad
A^{(0)}=(0,\alpha_0\tau_0,\alpha_0\tau_1,\alpha_0\tau_2),\quad
\Phi_0=v,\\
\psi_0(t)=\Psi[e^{i\omega t},e^{-i\omega t}],\quad
\chi_0(t)=\Xi[se^{i\omega t},se^{-i\omega t}].
\end{gathered}\tag{2.10}$$

The only nonzero components of the spin connection with lowered internal indices are

$$\varpi_{1,23}=\varpi_{2,31}=\varpi_{3,12}=s.\tag{2.11}$$

In the bivector and two-form order specified above, the remaining three fields are

$$\mathcal B_0=\begin{pmatrix}0&I_3\\-NI_3&0\end{pmatrix},\qquad
\Lambda_0=\operatorname{diag}(-N,-N,-N,s^2-1,s^2-1,s^2-1),$$

$$B_{A,0}=\frac{\alpha_0^2}{\sigma N}(\tau_0,\tau_1,\tau_2,0,0,0).\tag{2.12}$$

The actual curvatures are

$$\widehat F_{\varpi,0}=\operatorname{diag}(0,0,0,-s^2,-s^2,-s^2),\quad
F_{A,0}=(0,0,0,-\alpha_0^2\tau_0,-\alpha_0^2\tau_1,-\alpha_0^2\tau_2).\tag{2.13}$$

Thus, although the background coframe is constant, its spin and gauge curvatures are nonzero. These terms arise from connection self-products and subsequently enter propagation mixing and external-leg frequencies.

### 2.4 Auxiliary elimination and recovery of the fields

Start with an elimination that can be carried out entirely on paper. Variation of (2.7) with respect to $B_A$ gives $F_A-K_eB_A=0$, where $K_e=\sigma\star_e$. Since $\star_e^2=-I$ on Lorentzian two-forms,

$$B_A^*=-\sigma^{-1}\star_e F_A,\qquad
\mathcal L(B_A)=\mathcal L(B_A^*)-\frac12W(B_A-B_A^*,K_e(B_A-B_A^*)).
\tag{2.14}$$

This is completion of the square with the signs of the original wedge pairing. On the background $e_0$,

$$\star_{e_0}(f_0,\ldots,f_5)
=(f_3/N,f_4/N,f_5/N,-Nf_0,-Nf_1,-Nf_2).\tag{2.15}$$

Substituting (2.13) immediately reconstructs $B_{A,0}$ in (2.12): the three magnetic curvature components become three electric-type auxiliary components. The eliminated field is still determined by the retained fields.

For an arbitrary first-order perturbation, the reconstruction formula becomes

$$\boxed{\delta B_A=K_0^{-1}
\left(\delta F_A-(\delta K_e)B_{A,0}\right).}\tag{2.16}$$

The second term is essential: changing the coframe also changes the Hodge operator. For example, if only the temporal coefficient $N\mapsto N+\delta n$ and the magnetic amplitude $\alpha_0\mapsto\alpha_0+\delta\alpha$ are perturbed, then

$$\delta(B_A)_{0i}
=\left(\frac{2\alpha_0}{\sigma N}\delta\alpha
-\frac{\alpha_0^2}{\sigma N^2}\delta n\right)\tau_{i-1}.
\tag{2.17}$$

Omitting the coframe term would drop a genuine gravity–gauge cross-response rather than merely altering gauge notation—illustrating at first variation how spacetime geometry directly couples to electromagnetic excitation through the Hodge constitutive map in pre-metric electrodynamics [24]. The two gravitational fields are likewise reconstructed as

$$\delta\mathcal B=J\,\delta\Sigma_e,\qquad
\delta\Lambda=J\,\delta\mathcal B-\delta\widehat F_\varpi.\tag{2.18}$$

The larger matrix elimination in §4 performs the same operation step by step, preserving both field reconstruction and equation reconstruction at each stage. Tree-level elimination of invertible heavy directions follows the general strategy of Henning–Lu–Murayama [3, §2.1.1]; here we enforce the stronger requirement that every effective-field solution, when embedded back via explicit polynomial maps, satisfies all retained original field equations identically.

### 2.5 Original time, the co-rotating representation, and pairing

The periodic matter background can be made stationary using the same source phase. On the full 252-dimensional carrier, let $P_6$ project onto the $\Lambda^6$ layer and define

$$Q=\gamma^5+2P_6,\qquad P(t)=e^{-i\omega tQ},\qquad
\psi_{\rm orig}=P(t)\psi_{\rm st},\quad
\chi_{\rm orig}=\chi_{\rm st}\,S P(t)^\dagger S.\tag{2.19}$$

Restricted to the original occupied space, $Q$ is the $\gamma^5$ of §1. The complete original Dirac operator acquires $+\omega\Gamma_e^0Q$ in the stationary representation, and the corresponding Hamiltonian satisfies

$$H_{\rm st}(\mathbf k)=H_{\rm orig}(\mathbf k)-\omega Q.
\tag{2.20}$$

The co-rotating transformation changes the field representation while keeping the same time coordinate $t$. Equation (2.20) restores the original frequency with the specified phase. When nonzero vertices preserve the $Q$ charge, the original and stationary frequency transfers coincide.

Throughout the paper, we use the following time and momentum dictionary: original time $t=x^0$; background proper time $\tau=Nt$; the Fourier–Jacobi growth symbol $p=(\lambda,i\mathbf k)$; and the rationalized variables

$$u=\frac{\lambda}{N\sqrt2},\qquad \mathbf q=\frac{\mathbf k}{\sqrt2};
\qquad \widehat f(\xi)=\int e^{-2\pi i\mathbf x\cdot\xi}f(\mathbf x)\,d^3x,
\quad \mathbf k=2\pi\xi.\tag{2.21}$$

In the propagation formulas, $\lambda$ is a growth rate. Quantum frequency formulas use $e^{-iEt}$, so $\lambda=-iE$. Thus $\lambda^2<0$ corresponds to oscillation, and $\lambda^2>0$ to real growth. The following sections retain this sign distinction rather than erasing it under the name “mass squared.”

<a id="sec-3"></a>

## 3 Joint nine-field development and its actual tangent

### 3.1 How seven initial values generate nine fields

Spatial homogeneity removes spatial derivatives but does not split gravity, gauge fields, and matter into uncoupled equations. An initial scalar velocity changes the stress; the temporal coframe then changes, along with the gauge acceleration and matter phase. We now express this feedback as an explicit seven-dimensional system.

Write the state as $x=(a,H,\alpha,b,f,w_s,\theta)$, representing, in order, the spatial scale, frame velocity, gauge amplitude, gauge momentum, radial scalar displacement, scalar velocity in the frame, and matter phase. Here $w_s$ is a real velocity, distinct from the occupied vector $w$ in §1. Define

$$c=\frac{s}{a^2},\quad E_A=b^2+\alpha^4,\quad q_v=\|v\|^2=4,$$

$$\mathcal D(x)=\frac{6s(c-\alpha)}a
+q_v a^3\left(f^2-\frac{w_s^2}{2}\right)
+3a^3+3aH^2-3ac^2,\qquad
n(x)=\sqrt{\frac{3aE_A}{4\sigma\mathcal D(x)}}.\tag{3.1}$$

The admissible domain is the open set $\mathcal A=\{a>0,E_A>0,\mathcal D>0\}$. Its $n$ is determined by the temporal coframe equation, rather than prescribed as an external clock function. The vector field $G$ generated by the original equations is

$$\begin{aligned}
\dot a&=nH,\\
\dot H&=\frac{1}{2a}\left[-\frac{E_A}{4\sigma n}
+n\left(\frac{2s(c-\alpha)}{a^2}
-q_v a^2\left(f^2+\frac{w_s^2}{2}\right)-3a^2-H^2+c^2\right)\right],\\
\dot\alpha&=\frac{ab}{n},\qquad
\dot b=\frac{4\sigma ns}{a}-\frac{2a\alpha^3}{n},\\
\dot f&=nw_s,\qquad \dot w_s=n\left(2f-\frac{3Hw_s}{a}\right),\\
\dot\theta&=\frac{3n(c-\alpha)}{2a}.
\end{aligned}\tag{3.2}$$

Along any admissible solution $x(t)$, set

$$e=\operatorname{diag}(n,a,a,a),\quad A_i=\alpha\tau_{i-1},\ A_0=0,
\quad \Phi=(1+f)v,$$

$$\psi=a^{-3/2}\Psi[e^{i\theta},e^{-i\theta}],\qquad
\chi=sa^{-3/2}\Xi[e^{i\theta},e^{-i\theta}].\tag{3.3}$$

The spin connection is the sum of two parts. The nonzero mixed components of its Levi–Civita part are $\varpi_i{}^0{}_i=\varpi_i{}^i{}_0=H$; the lowered components of its axial-torsion part are $\varpi_{1,23}=\varpi_{2,31}=\varpi_{3,12}=c$. The remaining fields are reconstructed by

$$\mathcal B=J\Sigma_e,\qquad \Lambda=J\mathcal B-\widehat F_\varpi,
\qquad B_A=-\sigma^{-1}\star_e F_A\tag{3.4}$$

Thus the seven state variables specify all nine fields and their actual first derivatives. In particular, $\dot n=Dn(x)G(x)$ cannot be set to zero when calculating curvature.

**Theorem 3.1 (Joint local development).** For every $x_*\in\mathcal A$, there exist $r,T>0$ and $C\geq0$ such that each initial state $x$ in the closed ball $\overline B(x_*,r)$ generates a smooth solution $X(x,t)$ on the same time interval $|t|<T$. The solution remains in $\mathcal A$, satisfies $X(x,0)=x$ and $\partial_tX=G(X)$, and obeys

$$\|X(x,t)-X(y,t)\|\leq C\|x-y\|.\tag{3.5}$$

For the nine fields generated by (3.3)–(3.4), all nine original Euler residuals vanish together on this interval. Developments with the same initial data agree on their common interval of definition.

**Proof.** The difficulty lies in the second step: solving the seven-dimensional ODE does not by itself make all nine fields answer their own equations. First, strict positivity of $a,E_A,\mathcal D$ makes $G$ smooth on the admissible domain; a local Picard construction gives a common initial-data ball and time interval, and joint continuity keeps the entire product neighborhood inside $\mathcal A$. Substituting the actual derivatives of the solution into the original fields, the Cartan equation gives $c=s/a^2$, the gauge equations give $\dot\alpha,\dot b$, the scalar equations give $\dot f,\dot w_s$, the two matter equations give the dilution rate and $\dot\theta$, and the two coframe balances give $n$ and $\dot H$ (Supplement S1.1). Because this uses the original field variations, the result is a joint nine-field solution rather than merely a solution of the seven-dimensional ODE. ∎

### 3.2 The initial-data derivative along phase drift

The original state is

$$x_0=(1,0,\alpha_0,0,0,0,0),\qquad
X(x_0,t)=x_0+t\omega e_7.\tag{3.6}$$

It is not a fixed point in the seven-dimensional coordinates: the seventh coordinate keeps moving. Since $G$ does not depend on $\theta$, subtracting this actual drift gives the centered vector field

$$G_c(z)=G(x_0+z)-\omega e_7,\qquad G_c(0)=0,\qquad
J_0=DG(x_0),\quad G_c(z)=J_0z+o(\|z\|).\tag{3.7}$$

**Theorem 3.2 (Actual initial-data derivative).** For the joint development of Theorem 3.1 at $x_0$, and every $|t|<T$,

$$D_xX(x_0,t)=e^{tJ_0}.\tag{3.8}$$

**Proof.** This is the Fréchet derivative of the actual nonlinear solution family along the moving phase-drift orbit. Comparing $X(x_0+h,t)-X(x_0,t)$ with $e^{tJ_0}h$, the local Lipschitz bound first controls the full nonlinear displacement by $C\|h\|$, making the remainder in (3.7) $o(\|h\|)$ throughout the time interval. Applying Grönwall's estimate to the difference equation and treating positive and negative times separately proves (3.8) while retaining the drift in (3.6). ∎

The characteristic polynomial of the original $J_0$ is

$$\det(XI-J_0)=X\left(X^2+\frac{648}{125}\right)
\left(X^2-\frac{50}{3}\right)
\left(X^2-\frac{108}{125}\right).\tag{3.9}$$

The zero root, oscillatory roots, and two pairs of real growth/decay roots each have their own place. The radial scalar pair gives $108/125=2N^2$. The polynomial of the remaining five states is the product of the first three factors; §4 accepts the same tangent through all 289 original rows.

### 3.3 Radial Jacobi solutions on full space

Now give the scalar a spatial profile while retaining all other fields of the original background. Set $\Phi_\epsilon=(1+\epsilon f(t,\mathbf x))v$. The original scalar kinetic term and potential directly reduce the radial equation to

$$\mathcal R f:=\frac1{N^2}\partial_t^2f-\Delta f-2f=0.\tag{3.10}$$

Fix any real spatial momentum $\mathbf k$. With $f(0,\mathbf x)=0$ and $\partial_tf(0,\mathbf x)=\cos(\mathbf k\cdot\mathbf x)$, the solution is

$$f_{\mathbf k}(t,\mathbf x)=\cos(\mathbf k\cdot\mathbf x)
\begin{cases}
\sinh(\gamma t)/\gamma,&|\mathbf k|^2<2,\quad\gamma=N\sqrt{2-|\mathbf k|^2},\\
t,&|\mathbf k|^2=2,\\
\sin(\nu t)/\nu,&|\mathbf k|^2>2,\quad\nu=N\sqrt{|\mathbf k|^2-2}.
\end{cases}\tag{3.11}$$

The critical expression $t$ is the common zero-frequency limit of the other two expressions. Each time factor has initial derivative 1, so the full field always has initial velocity $\cos(\mathbf k\cdot\mathbf x)$.

**Theorem 3.3 (Complete radial first variation).** Suppose the profile $f$ is differentiable, each first coordinate partial derivative is differentiable at the point under consideration, and (3.10) holds there. Then eight of the nine original field residuals vanish exactly for every real $\epsilon$. The only remaining residual is the coframe residual, equal to $\epsilon^2$ times an explicit original coframe covector. Thus the derivatives of all nine residuals with respect to $\epsilon$ vanish at zero. In particular, all three momentum regimes in (3.11) give Jacobi solutions of the original nine-field system.

**Proof.** Substituting $\Phi_\epsilon=(1+\epsilon f)v$ into the nine Euler variations reduces the scalar row to $\mathcal R f=0$ while the gauge, spin-connection, gravitational-auxiliary, multiplier, and two matter rows vanish identically from the background balance of $v$. The second-order backreaction is read directly from the radial perturbation density

$$\Delta\mathcal L_\Phi
=\epsilon^2q_v\nu_e\left(\frac12g^{\mu\nu}\partial_\mu f\,\partial_\nu f-f^2\right).
\tag{3.12}$$

Varying with respect to $e$ before setting $e=e_0$ produces a coframe load starting strictly at $\epsilon^2$, so all nine first derivatives at $\epsilon=0$ vanish identically. ∎

Equation (3.12) explains both why the first-order Jacobi solution closes on the fixed background and why finite radial amplitude requires the joint coframe feedback of §3.1. The single cosine wave here is a full-space mode; §7 treats normalizable spatial fields separately through $L^2$ preparation.

### 3.4 Comoving matter dilution and subspace compression return

The $a^{-3/2}$ spinor amplitude of the nonlinear solution and the ordering of subsequent operator compressions obey the following exact identities:

**Proposition 3.4 (Comoving matter-dilution conservation and subspace compression return, `L4`).** Along any admissible nine-field development of Section 3.1, setting $\widehat\psi_\theta=\Psi[e^{i\theta},e^{-i\theta}]/2$ gives, for every mother operator $A\in\operatorname{End}(\mathcal M)$,

$$\chi(A\psi)=4s\,a^{-3}\langle\widehat\psi_\theta,SA\widehat\psi_\theta\rangle.
\tag{3.13}$$

In particular, $A=S$ yields the physical matter density and comoving conservation law

$$\rho=\operatorname{Re}\chi(S\psi)=4s\,a^{-3},\qquad a^3\rho=4s.\tag{3.14}$$

Furthermore, for any isometric subspace embedding $I$ into $\mathcal M$ ($I^\dagger I=I_{\mathrm{sub}}$) with compression $C(A)=I^\dagger AI$, every operator product satisfies the exact complementary-return decomposition

$$C(AB)=C(A)C(B)+I^\dagger A(I-II^\dagger)BI.\tag{3.15}$$

**Proof.** Substituting $\psi,\chi$ from (3.3) into (2.8) and evaluating the chiral inner product with $S=\gamma^0\gamma^5$ gives (3.13); setting $A=S$ with $S^2=I$ and $\|\widehat\psi_\theta\|^2=1$ gives (3.14). Inserting $I_{\mathcal M}=II^\dagger+(I-II^\dagger)$ inside $I^\dagger ABI$ proves (3.15). ∎

Equation (3.14) unites spatial volume, matter dilution, and the independent-dual pairing, while the second term of (3.15) records departure into and return from the complementary subspace—the exact algebraic reason why both tree exchange in §6 and CAR words in §7.4 (Table 2, row 3) must form complete products prior to compression.

<a id="sec-4"></a>

## 4 Full coupled propagation and reconstruction of the original fields

### 4.1 Why constraints come first

On a nonzero matter background, a gauge perturbation changes matter, matter changes the current in return, and the coframe and spin connection enter both. Diagonalizing one bare mass block does not solve this coupled propagation problem. We take the second variation directly from the independent field first jets in (2.7).

The active real carrier coupled to the original occupied state contains 16 coframe coordinates, 24 Lorentz-connection coordinates, 36 gravitational auxiliary coordinates, 36 multiplier coordinates, 48 gauge-connection coordinates, 72 gauge-auxiliary coordinates, 9 real scalar orbit coordinates, and 24 real coordinates each for the primal and independent dual in the original occupied space: 289 in total. The remaining scalar and matter directions retain their own blocks and return relations in §§4.5 and 6.

Denote the quadratic Euler symbol by $H_{289}(p)$ and use the signed transpose for real fields, $M^\sharp(p)=M(-p)^{\mathsf T}$. The original quadratic action has the form $\frac12z^\sharp H_{289}z$. Retaining $-p$ is essential for a simple reason: integration by parts changes the sign when a differential operator moves to the other leg.

The first step consists of three actual algebraic eliminations:

$$289\longrightarrow217\longrightarrow145\longrightarrow121.
\tag{4.1}$$

The eliminated dimensions are $72,72,24$, respectively (namely the 72 gauge two-form auxiliary components $B_A$, the 72 gravitational two-form and simplicity-multiplier components $(\mathcal B,\Lambda)$, and the 24 real spin-connection components $\varpi$). Each step uses a two-sided inverse of an actual nonzero algebraic block and retains field reconstruction at all momenta. To make the meaning explicit, split the fields at one step into $(y,z)$ and write the quadratic action with a positive-sign source as

$$\frac12\begin{pmatrix}y\\z\end{pmatrix}^{\sharp}
\begin{pmatrix}A&B\\B^\sharp&D\end{pmatrix}
\begin{pmatrix}y\\z\end{pmatrix}+j_y^\sharp y+j_z^\sharp z.
$$

Whenever $A$ is invertible, the original $y$ equation gives

$$y=-A^{-1}(Bz+j_y),\quad
Kz=-j_z+B^\sharp A^{-1}j_y,\quad
K=D-B^\sharp A^{-1}B.\tag{4.2}$$

Substitution into the action also leaves the local term $-\frac12j_y^\sharp A^{-1}j_y$. The propagation kernel, external-source transformation, eliminated fields, and contact term therefore arise together from one elimination step. The tree exchange in §6 uses all four.

### 4.2 A faithful section from the original Ward rows

The next object is not another zero block that can simply be discarded. The responses of all 12 gauge tangents to the original scalar potential form a torque of rank 9. For an original real scalar deviation $\phi$, it takes the form

$$\mathcal T_X(\phi)=-2\nu_e\langle\rho(X)v,\phi\rangle_{\mathbb R}.
\tag{4.3}$$

Row operations with an explicit polynomial inverse turn the 9 scalar rows into invertible constant constraints. Eliminating the corresponding variables gives 112 equivalent equations. The original scalar rows can be reconstructed by the inverse transformation, so the nonzero potential response is retained as a constraint.

The 112-dimensional system has 9 genuine symmetry tangents: three original color-SU(2) tangents and six Lorentz tangents. Let their matrix be $T_{\mathrm{sym}}(p)$. At axial momentum $p=(\lambda,0,0,ik)$, it has an invertible $9\times9$ minor independent of $\lambda,k$. This minor generates a 103-dimensional section $C$ and polynomial readback $Q_{\mathrm{sec}}(p)$ satisfying

$$Q_{\mathrm{sec}}(p)C=I_{103},\qquad
H_{112}(p)=Q_{\mathrm{sec}}^\sharp(p)K_{103}(p)Q_{\mathrm{sec}}(p).
\tag{4.4}$$

The section introduces no denominators in $\lambda$ or $k$—in contrast to conventional covariant background-field gauge fixings using nonlocal projectors $k_\mu k_\nu/k^2$ [2, 14] or singular Dirac-bracket inversions [13], this denominator-free polynomial section ensures that neither zero momentum nor exceptional momentum spheres acquire artificial singularities or lose kernel directions. For sources satisfying

$$T_{\mathrm{sym}}^\sharp(p)j=0\tag{4.5}$$

and wherever $K_{103}$ is invertible, the positive Green response $x_G=CK_{103}^{-1}C^{\mathsf T}j$ satisfies $H_{112}x_G=j$. With the positive-sign action source $+j^{\mathsf T}x$ of (4.2), the stationary equation is $H_{112}x+j=0$, hence the induced field is $x_{\rm ind}=-x_G$. Equation (4.2) and the inverse Ward transformation then reconstruct all 289 rows. Here “positive Green” refers to the sign of the source equation, not positive definiteness of the operator.

The rank is 103 at a generic axial point and 98 at the origin. The additional five-dimensional kernel at the origin is spanned by five constant original matter and independent-dual directions: real vector rescaling, vector phase, real axial rescaling, homogeneous $\theta$ phase, and purely imaginary independent-dual rescaling. At nonzero momentum these generally cease to be kernel directions. In contrast, four naive coordinate-diffeomorphism candidates leave 128 nonzero residual entries in the original symbol (Table 2, row 2); this reduction uses the nine gauge–Lorentz tangents that annihilate it identically. The difference between temporal rescaling of the original Hodge operator and ordinary pullback of a two-form also has the explicit nonzero derivative $-2/N$.

**Proposition 4.1 (Full propagation and reconstruction).** The algebraic eliminations, Ward constraints, and faithful section above give equivalent constrained propagation for the full active quadratic action. The nonradial five-state Jacobi solution of the original seven-dimensional development satisfies all 289 rows under the actual rank-5 field embedding, and its characteristic polynomial

$$X\left(X^2+\frac{648}{125}\right)\left(X^2-\frac{50}{3}\right)
\tag{4.6}$$

appears in full on the time axis of the original propagation.

**Proof.** Combining the block elimination identity (4.2), polynomial inverse row operations, and the denominator-free section (4.4) establishes exact full-momentum reconstruction; sending the actual five-state tangent of §3 through the field embedding into $H_{289}$ annihilates all 289 rows identically. Nonlinear development and linear propagation therefore share an actual tangent rather than merely matching eigenvalues. ∎

### 4.3 Complete factors and low-momentum branches

Decomposing $K_{103}$ by its actual nonzero support gives ten blocks of dimensions

$$1,1,1,1,2,2,16,16,30,33.\tag{4.7}$$

Read in the original variables of (2.21), the complete determinant has 22 distinct rational factors. Simultaneous rotation of spatial, spin, and original color directions organizes them into 14 radial product factors; the total degree of the corresponding time polynomial is 126. These rotations transport all nonzero real spatial momenta, while the matrix at the origin retains zero momentum independently. Supplement S1 and the accompanying exact catalog give the full factors, multiplicities, and nonzero scaling constants.

At the origin, the multiplicities of the temporal factors are $(1,1,2,2,2)$ and those of the static spatial factors are $(2,2,2,2,2)$. The leading terms of four low-momentum characteristic branches are

$$\lambda^2=-\frac{18}{25}|\mathbf k|^2,\quad
\lambda^2=-\frac3{20}|\mathbf k|^4,\quad
\lambda^2=-\frac{594}{1675}|\mathbf k|^2,\quad
\lambda^2=\frac13|\mathbf k|^2.\tag{4.8}$$

The first pair and the second pair differ in their lowest momentum orders and original field content. Section 5 derives the latter pair again from the phase-coordinate effective action and also obtains the fourth-order coefficients. The factor count here concerns characteristic divisors of the original operator. Whether a particular external state reads a pole is determined by the numerators and sources.

A smaller original weak block illustrates this distinction. Associated with the weak-doublet basis pair $(3,4)$ (namely $(w_0,w_1)$), the four-vector gauge block $A_{34}$ and symmetric weak block $S_{34}$ are each isolated in both directions from the remaining 99 quotient coordinates. Their transverse and longitudinal propagation denominators are, respectively,

$$\lambda^2+\frac{125}{54}k^2-\frac12,\qquad
\lambda^2+\frac{54}{125}k^2-\frac12.\tag{4.9}$$

Yet the response of the homogeneous temporal component is the constant $-N/2$. Reconstruction of the original fields also shows that a four-vector source $j_\mu$ generates $-\lambda j_0-ikj_3$ in the original scalar-orbit row. A four-vector readout in the quotient therefore includes an actual scalar-source condition, beyond forcing a single $A$ component.

### 4.4 The prepared sector in the original independent-dual theory

Now select the real preparation relation already present in the original theory,

$$\chi=s\psi^\dagger S.\tag{4.10}$$

Its linear tangent gives an 88-dimensional embedding $C_{\mathrm{prep}}$ and an actual equation-return matrix $R_{\mathrm{prep}}$:

$$K_{88}=C_{\mathrm{prep}}^{\mathsf T}H_{112}C_{\mathrm{prep}},\qquad
H_{112}C_{\mathrm{prep}}=R_{\mathrm{prep}}K_{88},\qquad
C_{\mathrm{prep}}^{\mathsf T}R_{\mathrm{prep}}=I_{88}.\tag{4.11}$$

The last two equalities go beyond substituting the preparation relation into the action: they guarantee that a reduced solution again satisfies the original independent equations. Removing the same nine genuine symmetry directions gives $K_{79}$, and the original 103-dimensional propagation splits into these 79 directions and a 24-dimensional complementary block. The real sources generated by actual prepared matter vanish identically on that block. This is a source selection rule, not a reason to remove original propagation branches.

### 4.5 Retaining all peripheral matter and scalar directions

The remaining directions of the complete carrier (comprising the 1078 linearized coupled field equations of the peripheral chiral spinors, independent complex-linear duals, and 61 peripheral scalar components outside the active 289-dimensional sector) also have definite dynamical roles. Maximal development of the prepared peripheral constraints gives a real fiber of dimension 522 at generic momentum, 524 at the origin, and 530 on the sphere $|\mathbf k|^2=5929/1800$; its development reconstructs all 1078 original equations. The instantaneous compatibility kernel has complex dimension 266, which describes a different object from the real dimension of the developable fiber. With scalar and connection held fixed, there is also a 232-dimensional complex invariant subspace for matter propagation.

The scalar has two decompositions whose definitions must both be retained. Among all 70 real scalar directions, the space satisfying both the Yukawa-kernel condition and orthogonality to the real gauge orbit has dimension 43: 23 real singlets and five four-dimensional blocks. The entire 61-dimensional scalar complement of the active 9-dimensional orbit consists instead of 25 real singlets and nine four-dimensional blocks; §6.3 gives its complete propagation inverse. The first decomposition selects directions satisfying two conditions, while the second reconstructs every peripheral scalar. The two sets of dimensions therefore cannot replace one another by subtraction.

<a id="sec-5"></a>

## 5 Eliminating seventy-seven heavy modes and parameter-free fourth-order soft-phase dispersion

### 5.1 Original phases rather than an arbitrary kernel basis

In the two-dimensional kernel of the prepared propagation $K_{79}(0)$, choose the two actual phases of the original matter. The vector phase $\varphi$ has tangent

$$\delta\psi=i\psi_0\,\delta\varphi,\qquad
\delta\chi=-i\chi_0\,\delta\varphi;$$

The axial phase $\theta$ has tangent

$$\delta\psi=-i\gamma^5\psi_0\,\delta\theta,\qquad
\delta\chi=-i\chi_0\gamma^5\,\delta\theta.\tag{5.1}$$

The vector phase rotates the matter and independent-dual legs in opposite directions; the axial phase acts on both legs with the same sign of $-i\gamma^5$. This distinction fixes the phase amplitudes and permits a term-by-term comparison of the effective action with the original Noether densities.

First apply the fixed diagonal rationalizing field-rescaling matrix $S_f$ (which brings coframe, connection, and matter amplitudes to a common rational-coefficient basis; see Supplement (S1.3)) to write $G=S_f^{\mathsf T}K_{79}S_f/N$. Let $P_{\rm src}(p)$ be the two original phase columns after actual section readback, and take the constant columns $P=P_{\rm src}(0)$. The difference $P_{\rm src}(p)-P$ lies in the remaining 77 directions. Choose a constant column matrix $E$ for these directions. Then $T_0=[P,E]$ is invertible, and

$$D(p)=E^{\mathsf T}G(p)E=D_0+D_1+D_2,\qquad D_0\text{ invertible}.\tag{5.2}$$

Here “heavy directions” means the 77 directions invertible at the origin. Their elimination applies to the derivative expansion near that point and is determined by the actual matrix in (5.2), rather than an externally imposed mass cutoff.

### 5.2 Recursive elimination and full field reconstruction

Write $B(p)=E^{\mathsf T}G(p)P=\sum B_n$, with each subscript denoting total momentum degree. The original equations generate the heavy-direction corrections order by order:

$$W_0=0,\qquad
D_0W_n=-B_n-D_1W_{n-1}-D_2W_{n-2},\quad 1\leq n\leq4,
\tag{5.3}$$

Subscripts outside the range are taken to be zero. The effective phase field is then $F=P+E\sum_{n=1}^4W_n$, and it satisfies

$$GF=T_0^{-\mathsf T}\big|_{\rm light}(K_2+K_4)+R_5+R_6.\tag{5.4}$$

Within the fourth-order truncation, the first- and third-order effective operators vanish. The formula contains two exact remainder matrices $R_5,R_6$, which are homogeneous polynomials, rather than numerical fitting errors. If $V_{289}$ and $J_{289}$ are the actual field and equation embeddings of §4, then

$$H_{289}V_{289}=J_{289}G,\quad V_{289}^{\sharp}J_{289}=NI_{79},$$

$$H_{289}V_{289}F
=J_{289}T_0^{-\mathsf T}\big|_{\rm light}(K_2+K_4)
+J_{289}(R_5+R_6).\tag{5.5}$$

The effective phases and their truncation error thus have a definite location in all 289 original rows. The same reconstruction formula states both the retained order and the first order at which the original equations acquire an error.

### 5.3 The effective action and one complete expansion

The calculation gives

$$K_2=\begin{pmatrix}
\frac{32}{11}u^2+\frac{160}{67}|\mathbf q|^2&0\\
0&-40u^2+\frac{2500}{81}|\mathbf q|^2
\end{pmatrix}.\tag{5.6}$$

Returning to the original time and spatial coordinates, the second-derivative density is

$$\boxed{\mathcal L_2=
-\frac8{11N}(\partial_t\varphi)^2+\frac{40N}{67}|\nabla\varphi|^2
+\frac{10}{N}(\partial_t\theta)^2+\frac{625N}{81}|\nabla\theta|^2.}
\tag{5.7}$$

Supplement S1.3 gives the complete four-momentum polynomial $K_4$. To calculate one branch explicitly, take the vector-phase entry along $q_3=q,q_1=q_2=0$:

$$(K_4)_{\varphi\varphi}
=\frac{8000}{13467}q^4
+\frac{258700928}{203688375}q^2u^2
+\frac{320}{363}u^4.\tag{5.8}$$

Set $u^2=cq^2+dq^4+O(q^6)$. The second-order term of (5.6) gives $c=-55/67$. Substituting this $c$ into (5.8) gives the fourth-order term $12033024q^4/82709825$, hence

$$\frac{32}{11}d+\frac{12033024}{82709825}=0,
\qquad d=-\frac{376032}{7519075}.\tag{5.9}$$

Finally, using $\lambda^2=2N^2u^2$ and $q^2=k^2/2$, we summarize this recursive elimination and on-shell substitution as an exact parameter-free proposition:

**Proposition 5.1 (Fourth-order rational dispersions of the two soft phases with zero free low-energy constants, `L8`).** Eliminating the 77 origin-invertible heavy directions of $K_{79}(0)$ yields, along every real spatial momentum direction $\mathbf k\in\mathbb R^3$, the exact rational fourth-order low-momentum branches

$$\boxed{\lambda_\varphi^2
=-\frac{594}{1675}|\mathbf k|^2
-\frac{10152864}{939884375}|\mathbf k|^4+O(|\mathbf k|^6),}
\tag{5.10}$$

$$\boxed{\lambda_\theta^2
=\frac13|\mathbf k|^2-\frac{3053}{29160}|\mathbf k|^4
+O(|\mathbf k|^6),}\tag{5.11}$$

and substituting the fourth-order effective field $F=P+E\sum_{n=1}^4W_n$ back into all 289 original field equations via (5.5) leaves only the exact fifth- and sixth-order homogeneous polynomial remainders $(R_5,R_6)$.

**Proof.** Solving the recursion (5.3) for $W_1,\ldots,W_4$ establishes (5.4)–(5.5); substituting the quadratic shell relations from (5.6) into the vector and axial diagonal entries of (S1.5) in Supplement S1.3 (since the square of the fourth-order off-diagonal entry enters the determinant only at $O(|\mathbf k|^8)$, i.e., $O(|\mathbf k|^6)$ on each branch) and returning to original time and momentum coordinates yields (5.10)–(5.11). ∎

This result contrasts sharply with Weinberg's derivative expansion of phenomenological Lagrangians [15] and Appelquist–Carazzone decoupling [16]: whereas fourth-order derivative operators in chiral effective field theories ordinarily carry undetermined low-energy constants (LECs) fitted to experiment or external UV completions, here the 77-dimensional origin inverse of the fixed mother action locks both the quadratic and fourth-order coefficients in $\mathbb Q$. In this fixed phase section, the off-shell $K_4$ need not be manifestly rotationally scalar entry by entry; substituting the second-order shell relation into its diagonal entries makes the fourth-order coefficients radial invariants. Physically, one must also distinguish two objects: $\lambda_\theta^2>0$ in (5.11) measures the hyperbolic saddle curvature of uncontrolled classical linearized Jacobi variations around the phase-precessing orbit $X(x_0,t)=x_0+t\omega e_7$ (sharing the same origin as the real root pairs in (3.9)), rather than any quantum blow-up—homogeneous nonlinear trajectories are controlled on finite strips by Theorem 3.1, occupied states on $L^2(\mathbb R^3,\mathbb C^{12})$ evolve by norm-preserving unitary propagators generated by the Hermitian Dirac operator (Theorems 7.2 and 8.1), and many-body electromagnetic readouts are anchored to localized ground-sector configuration preparations of the lower-bounded quadratic form $\mathcal T$ (Section 9.2, (9.3)–(9.4)).

![Low-momentum characteristic branches of the two phases](figures/main-02-soft-phases-en.svg)

**Figure 2. Two soft branches in original time.** Solid curves are the fourth-order truncations in (5.10)–(5.11) near $\mathbf k=0$, and dashed curves are their second-order leading terms. The horizontal axis shows $0\leq|\mathbf k|\leq0.5$; the asymptotic remainder is $O(|\mathbf k|^6)$. The vertical axis is the original-time growth variable $\lambda^2$. Below zero lies the oscillatory $\varphi$ branch (deep blue); above zero lies the hyperbolic saddle $\theta$ branch (vermilion), whose fourth-order term visibly separates it from its quadratic leading term over the displayed range.

### 5.4 Noether densities fix the phase scales

The derivatives of the original action with respect to the two phases give

$$J_\varphi^\mu=-\nu_e\operatorname{Re}\chi\Gamma_e^\mu\psi,
\qquad J_\theta^\mu=\nu_e\operatorname{Re}\chi\Gamma_e^\mu Q\psi.\tag{5.12}$$

On the original background, the vector density is zero and the axial density is $4s$. Their first variations must include both matter legs and the coframe. The coframe enters through

$$\delta\operatorname{adj}(e)=\det e\left[
\operatorname{tr}(e^{-1}\delta e)e^{-1}-e^{-1}(\delta e)e^{-1}\right]
\tag{5.13}$$

and cannot be discarded before normalizing the phases. Substituting the heavy-direction solution (5.3) into the original densities gives, at lowest order,

$$\delta J_\varphi^0=-\frac{16}{11N}\partial_t\varphi+O(\partial^3),\qquad
\delta J_\theta^0=\frac{20}{N}\partial_t\theta+O(\partial^3).\tag{5.14}$$

These are exactly the derivatives of (5.7) with respect to the two phase velocities. The full four-momentum Ward identities connect the divergences of the original currents to the phase rows of $H_{289}$. Thus the coefficients in (5.7) face two examinations: they first give the correct branches, and the charge densities of the original action then fix the phase scales.

<a id="sec-6"></a>

## 6 Eighteen curved gauge–Lorentz identities, ECSK axial contact, and 42-digit rational tree exchange

The propagation matrix answers how a field is forced; phenomenology also asks what matter exerted the force. The complete matter vertices of the original action first connect to the propagation of §4. Actual free external legs then take the stand and supply a nonzero four-leg coefficient. Its normalization is finally read from the original temporal kinetic term, rather than guessed from coordinate-vector lengths.

### 6.1 Complete vertices and original source conditions

Varying the original density once with respect to every bosonic field gives 158 vertices acting on the complete $\mathcal M$. We use

$$\mathcal L_3=\sum_b\delta b\,\operatorname{Re}\bigl[\zeta V_b(p)\xi\bigr],\tag{6.1}$$

where $p$ acts on the primal leg $\xi$, and $\zeta$ is the independent dual leg. The four vertex classes are

| Field | Real directions | Vertex read from the original action |
|---|---:|---|
| Gauge connection $A_\mu^T$ | 48 | $Ni\Gamma_{e_0}^\mu\rho(T)$ |
| Lorentz connection $\varpi_{\mu ab}$ with lowered indices | 24 | $Ni\Gamma_{e_0}^\mu\gamma^a\gamma^b/2$, counted over the six oriented bivectors |
| Coframe $e^a{}_{\mu}$ | 16 | Actual derivatives of $\operatorname{adj}(e)$, the complete stationary kinetic term, and $\det(e)Y_R$ |
| Scalar $\Phi$ | 70 | $NY_R(\sigma_b)$, where $\sigma_b$ runs over the real and imaginary directions of the 35 complex basis vectors |

The coframe vertices include the $+\omega\Gamma_e^0Q$ generated by (2.19). Both the volume derivative and inverse-coframe derivative contribute, so these vertices also check consistency of the time and field normalizations.

Let $D(p)$ be the complete original stationary Dirac symbol. The 18 identities generated by the actual local gauge and Lorentz actions have the common form

$$\delta D(p,r)+ND(p+r)T-NTD(p)=0.\tag{6.2}$$

Here $\delta D$ includes background-connection commutators, scalar vertices, and coframe variations together. Applying the actual source transformation of §4 expresses each of the nine symmetry-source compatibility conditions and nine scalar contact sources as

$$\operatorname{SourceMap}(r)V(p)
=N\bigl[TD(p)-D(p-r)T\bigr].\tag{6.3}$$

For two external legs satisfying $D(p_{\rm in})u_{\rm in}=0$ and $\zeta_{\rm out}D(p_{\rm out})=0$, take $r=p_{\rm in}-p_{\rm out}$. The two original field equations annihilate the right-hand side. In contrast to perturbative non-Abelian Slavnov–Taylor identities [36] requiring covariant gauge fixing and Faddeev–Popov ghost fields, (6.2)–(6.3) introduce no ghosts on the nonstationary spin-torsion and scalar-condensate background, directly extending the classical Abelian Ward–Takahashi identities [22, 23] into 18 exact relations encompassing both non-Abelian gauge and local Lorentz bivector generators while retaining background-connection commutators, scalar torques, and coframe derivatives, so that source compatibility is paid directly by the on-shell external-leg equations.

For the preparation relation (4.10), the actual real transfer source is

$$j_b=\frac{s}{2}u_{\rm out}^\dagger
\left[SV_b(p_{\rm in})+V_b(p_{\rm out})^\dagger S\right]u_{\rm in}.
\tag{6.4}$$

The two terms respectively use one external-leg equation. All $SV_b$ also preserve the original $Q$ charge. Nonzero transfers connect external states of equal $Q$ charge, so energy transfers agree in the co-rotating and original representations.

### 6.2 Dynamical exchange, contact terms, and fermionic exchange

Sending the 97 active bosonic sources through the original 289-dimensional polynomial decomposition yields auxiliary sources, nine scalar contact sources, $f_{79}$, $f_{24}$, and nine compatibility rows:

**Theorem 6.1 (Curved gauge–Lorentz source compatibility, active tree action, and parameter-free ECSK axial contact, `L9`).** On-shell external-leg equations annihilate all nine symmetry compatibility rows via the 18 identities (6.2)–(6.3); wherever the dynamical blocks are invertible, the exact active tree action is

$$\mathcal L_{\rm tree,act}=-\frac12\left[
 j^\sharp C_{\rm contact}j
+f_{79}^\sharp A_{79}^{-1}f_{79}
+f_{24}^\sharp B_{24}^{-1}f_{24}\right],\tag{6.5}$$

where all 24 complementary-block vertices $f_{24}$ vanish identically for real prepared sources (6.4) across the full 252-dimensional carrier, and the algebraic inverse of the 24 real Lorentz spin-connection directions reduces all spin sources to four axial bilinears:

$$\mathcal A^a=s\xi^\dagger S\gamma^a\gamma^5\xi,
\qquad
\boxed{\mathcal L_{\rm spin}=\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b.}
\tag{6.6}$$

**Proof.** On-shell equations annihilate the right-hand side of (6.3), establishing source compatibility; successive completion of the square via (4.2) gives (6.5) and reconstructs all 289 rows. Substituting the 24 bivector vertices of §6.1 into the $24\times 24$ spin-connection inverse of §4.1 and contracting temporal and spatial indices produces the Lorentzian signature $\eta_{ab}$ and prefactor $\frac{3N}{16}$ in (6.6); columnwise evaluation on (6.4) gives $f_{24}=0$. ∎

Viewed against gravitational spin–torsion theory, (6.6) is precisely the Einstein–Cartan–Sciama–Kibble (ECSK) axial four-fermion contact interaction established by Kibble [10], Sciama [11], and Hehl–von der Heyde–Kerlick–Nester [12], except that no independent gravitational or Immirzi-like coupling constant remains free—both $\frac{3N}{16}$ and $s=\sqrt2$ are uniquely locked by the mother action.

Multiparticle readouts use the same finite CAR representation. For one-body operators $A,B$, normal ordering splits $d\Gamma(A)d\Gamma(B)$ into the one-body term $d\Gamma(AB)$ and a four-operator term. On two occupied vectors, the matrix element of the latter contains two pairings, the second with a minus sign. That sign follows from anticommutation of the original creation and annihilation operators; it is not added by hand at the end of the four-leg calculation. The double-occupation vector of the two original chiral components has squared norm 4. The normal-ordered readout of the same color current is $216/125$, or $54/125$ after division by this squared norm. The complete action and pairing are read only after forming the four-operator product.

### 6.3 All 61 peripheral scalars and nonzero matter return

Let $J$ be the column matrix of the original nine-dimensional real scalar orbit,

$$P_\perp=I-J(J^{\mathsf T}J)^{-1}J^{\mathsf T}.
$$

The original color-SU(2) action on this space generates two orthogonal projections,

$$P_d=-\frac43\sum_i\rho_i^2P_\perp,\qquad P_s=P_\perp-P_d,
\qquad\operatorname{rank}P_s=25,\quad\operatorname{rank}P_d=36.\tag{6.7}$$

Write $r=|\mathbf k|^2$, $\Delta_s=\lambda^2/N^2+r-2$, $\Delta_d=\Delta_s+27/50$, and $\rho(\mathbf k)=\sum_i k_i\rho_i$. The complete projected inverse is

$$\boxed{G_\perp=\frac1N\left[
\frac{P_s}{\Delta_s}+\frac{\Delta_dP_d+2i\alpha_0\rho(\mathbf k)P_\perp}{\Delta_d^2-\alpha_0^2r}
\right],\qquad\alpha_0^2=\frac{18}{25}.}\tag{6.8}$$

Multiplication by the original scalar operator on either side gives $P_\perp$, and there are no angular or $|\mathbf k|$ denominators. For the positive-sign source $z_\perp=P_\perp z$, the induced scalar $\eta=-G_\perp z_\perp$ must also be sent through the original Yukawa mixing $M$, giving

$$\xi=D_6^{-1}MG_\perp z_\perp,\qquad\zeta=0.\tag{6.9}$$

The output of $M$ lies in $\Lambda^6$ and is generally nonzero, even though $Y_R$ vanishes on $\Lambda^6$ inputs. Equation (6.9) is precisely the matter return that cannot be omitted from scalar propagation. Together with (6.8), it reconstructs all 1078 original peripheral rows with their corresponding sources.

The complete scalar source enters the two parts through $z_J=J^{\mathsf T}z$ and $z_\perp$, with projections summing to $I_{70}$. Adding

$$-\frac12z_\perp^\sharp G_\perp z_\perp\tag{6.10}$$

to (6.5) gives the tree response of all original bosonic directions to these matter-bilinear sources. At the origin, the peripheral local term is $z^{\mathsf T}P_sz/(4N)+25z^{\mathsf T}P_dz/(73N)$. Supplement S2.2 gives the two complete weak five-source blocks and their scalar–divergence contact terms.

### 6.4 The original 216-dimensional free external-leg space

The complete original matter operator generates an isometric embedding $F_{\rm free}:\mathbb C^{216}\to\mathcal M$ satisfying

$$F_{\rm free}^\dagger F_{\rm free}=I,\qquad
F_{\rm free}F_{\rm free}^\dagger=P_{\rm free},\qquad
Y_R(v)F_{\rm free}=0.\tag{6.11}$$

The original $H$ splits there into 50 $2\times2$ blocks and 29 $4\times4$ blocks. Let $\chi_c=\pm1$ denote chirality and $\mathbf q=\mathbf k/\sqrt2$. After dividing the original Hamiltonian by $N\sqrt2$, the two block types are

$$h_{\chi_c,s}=\chi_c\left(\frac32I+\mathbf q\cdot\boldsymbol\sigma\right),$$

$$h_{\chi_c,d}=\chi_c\left(\frac32I+\mathbf q\cdot\boldsymbol\sigma\otimes I
+\frac3{10}\sum_i\sigma_i\otimes\sigma_i\right).\tag{6.12}$$

Color singlets and doublets here refer to the color SU(2) preserved by the original background. The two singlet spectral projections are $(I\pm\widehat{\mathbf q}\cdot\boldsymbol\sigma)/2$. The parallel-spin projections of a doublet give $\chi_c(9/5\pm|\mathbf q|)$. On the mixed-spin subspace, factoring out the chirality sign $\chi_c$ and subtracting $6I/5$ leaves an operator whose square is $(|\mathbf q|^2+9/25)I$, giving the remaining branches $\chi_c(6/5\pm\sqrt{|\mathbf q|^2+9/25})$. Every projection returns to the original 252 coordinates through $F_{\rm free}$. At zero momentum, combined projections are defined directly, without relying on a direction that does not exist.

These projections give the original-frequency resolvent and propagator,

$$G_H(E,\mathbf k)=\sum_b\frac{\Pi_b(\mathbf k)}{E-E_b(\mathbf k)},\qquad
U_{\rm free}(t,\mathbf k)=\sum_b e^{-iE_b(\mathbf k)t}\Pi_b(\mathbf k).
\tag{6.13}$$

They satisfy a two-sided inverse identity on the projected space and the time-group law. The external legs actually satisfy the original primal, independent-dual, and scalar equations. All 70 real scalar vertices vanish between two free external legs, so the projections themselves generate the scalar-exchange selection rule for this family.

### 6.5 Residues determine the external-leg scale

A unit coordinate vector is not yet an action-normalized external leg. Taking the original temporal jet of the actual field $\psi(x)=u+x^0v$, (2.7) gives

$$\mathcal L(u,\epsilon v)-\mathcal L(u,0)
=\epsilon s\operatorname{Re}\bigl(i\langle u,\gamma^5v\rangle\bigr).
\tag{6.14}$$

Here the original volume factor $N$ cancels the inverse-coframe factor $N^{-1}$, leaving the temporal kinetic pairing $G=s\gamma^5$. The original-frequency kernel and its inverse are therefore

$$K(E,\mathbf k)=s\gamma^5(E-H_{\rm orig}(\mathbf k)),\qquad
G_K(E,\mathbf k)=\sum_b\frac{(\chi_{c,b}/s)\Pi_b(\mathbf k)}{E-E_b(\mathbf k)}.
\tag{6.15}$$

The free space contains 106 negative-kinetic and 110 positive-kinetic directions (reflecting the standard chiral particle–hole kinetic sign split of classical c-number spinors prior to anticommuting CAR normal ordering, which takes over in §§6.2 and 7.4). A different, positive pairing read from the same phase rate is $s\gamma^5Q$, with weight $s$ on 202 directions and $3s$ on 14 right-handed $\Lambda^6$ directions. These pairings come from the time derivative and phase charge, respectively. Positivity of the latter does not change the signs of the former.

For right-handed external legs, the original residue fixes the exact scale

$$u_{\rm action}=s^{-1/2}u_{\rm coordinate}=2^{-1/4}u_{\rm coordinate}.
\tag{6.16}$$

Each bilinear source is therefore divided by $s$, and the four-leg tree coefficient by $s^2=2$. This scaling applies to both dynamical and contact terms.

### 6.6 A nonzero, on-shell, conserving exchange

Take the first right-handed $\Lambda^4$ color singlet and the first right-handed $\Lambda^2$ color singlet in (6.12), generating external legs with their actual positive-helicity projections. Their momenta are

$$\Lambda^4:\quad(0,0,1/\sqrt2)\longrightarrow(1/\sqrt2,0,0),$$

$$\Lambda^2:\quad(0,0,-1/\sqrt2)\longrightarrow(-1/\sqrt2,0,0).
\tag{6.17}$$

All four legs have original frequency $2N\sqrt2$, $Q$ charge 1, and stationary frequency $2N\sqrt2-\omega$. Total original energy and total spatial momentum are therefore conserved. Their complete 252-dimensional coordinate columns and transfer sources are stored in the data accompanying Supplement S2.

Substitution of the four legs into (6.4) gives two nonzero 97-component sources, while the original nine compatibility rows, nine scalar contact sources, and 24 complementary-block sources all vanish. The cross-vertices between the two exterior-power layers also vanish, so the species-exchange term in this channel is indeed zero. The remaining direct coefficient still has two parts: the full $79\times79$ dynamical inverse and the actual spin contact term.

Write

$$d=\frac{460567872925762140980306550635427551740791}
{457772441257406774332263414159620301790297}.
$$

The original coordinate-unit legs give

$$D_{\rm dyn}=\sqrt{30}\,d,\qquad
C_{\rm loc}=-\frac{9\sqrt{30}}{50},\qquad
\mathcal K_{\rm coordinate}=-D_{\rm dyn}-C_{\rm loc}
=-\sqrt{30}\left(d-\frac9{50}\right).\tag{6.18}$$

The two source orderings in $-D-C$ arise from the $-\frac12$ quadratic form of (6.5). The dynamical solution and contact fields jointly reconstruct all 289 original rows. Finally, regenerating the four external legs, two sources, and complete induced field with (6.16) gives

**Proposition 6.2 (Action-normalized 42-digit rational on-shell tree exchange, `L9-L10`).** On the four energy-, momentum-, and $Q$-charge-conserving right-handed free external legs of (6.17), rescaling via the kinetic-residue factor $u_{\mathrm{action}}=2^{-1/4}u_{\mathrm{coordinate}}$ in (6.16) to regenerate the two 97-component sources and full 289-component induced field yields, from the 79-dimensional dynamical inverse plus the ECSK axial spin contact (6.6), the nonzero on-shell tree amplitude

$$\boxed{\mathcal K_{\rm action}
=-\frac{\sqrt{30}}2\left(d-\frac9{50}\right)
\simeq-2.2623860895,}\tag{6.19}$$

whose induced field satisfies all 289 forced field equations identically.

**Proof.** Substituting the four coordinate-unit legs in Supplement (S2.1) into (6.4) generates two 97-component sources whose exact rational $79\times 79$ inverse gives $D_{\mathrm{dyn}}=\sqrt{30}\,d$ alongside the spin contact $C_{\rm loc}=-9\sqrt{30}/50$ in (6.18); rescaling each leg by $2^{-1/4}$ divides the four-leg amplitude by $s^2=2$, and polynomial reconstruction verifies zero residual across all 289 rows. This 42-digit rational number $d$ serves as an approximation-free benchmark for downstream scattering identification. ∎

### 6.7 Original electric and magnetic principal terms and static readouts

The highest-derivative density read from the same gauge-auxiliary elimination is

$$\mathcal L_{\rm prin}=\frac{N}{2\sigma}\kappa(E,E)
-\frac1{2\sigma N}\kappa(B,B).\tag{6.20}$$

Changing to proper time $\tau=Nt$, while also transforming the connection one-form $A_\tau=A_t/N$ and integration density $dt=d\tau/N$, gives

$$\mathcal L_{\rm prin,\tau}=\frac{N^2}{2\sigma}\kappa(E_\tau,E_\tau)
-\frac1{2\sigma N^2}\kappa(B,B).\tag{6.21}$$

Together with static source evaluation, this establishes the tree-level constitutive speed ratio and the zero-residue gate for bare temporal gauge charges:

**Proposition 6.3 (Native Hodge constitutive speed ratio and zero-Coulomb-residue gate for bare temporal gauge charges, `L11`).** Under proper time $\tau=Nt$ and native parameters $\sigma=1/2,N^2=54/125$, the electric and magnetic inverse principal coefficients are $108/125$ and $125/27$; the characteristic coordinate speeds of matter/scalars and transverse gauge waves are $N$ and $1/N$, giving in a common clock the tree-level constitutive speed ratio

$$\frac{c_{\rm gauge}}{c_{\rm matter}}=\frac1{N^2}=\frac{125}{54}.\tag{6.22}$$

Simultaneously, solving the full 289-dimensional coupled static system for all 12 bare temporal gauge charges yields a $12\times 12$ static response whose 144 entries extend finitely to zero momentum with **identically zero $1/|\mathbf k|^2$ Coulomb residue in every spatial direction**; its sole soft-phase pole coefficient factors as

$$\operatorname{Res}_{q^{-2}}G_{\rm source}
=C_{\rm null}(0)^{\mathsf T}C_{\rm constraint}C_{\rm null}(0),\qquad
(C_{\rm constraint})_{22}=\frac{9023}{5000N},\tag{6.23}$$

with all other entries vanishing (0-indexed), hence vanishing identically on every compatible source obeying $C_{\rm null}j=0$.

**Proof.** Substituting $\sigma=1/2$ and $N^2=54/125$ into (6.20)–(6.21) gives the inverse stiffnesses and speed ratio (6.22); sending the 12 unit temporal gauge sources through the denominator-free section inverse of §4 as $q\to 0$ verifies zero $1/|\mathbf k|^2$ residue on the compatible subspace across all 144 entries together with (6.23) (Supplement S2.3). ∎

In the pre-metric electrodynamics framework synthesized by Hehl and Obukhov [24], topological conservation laws precede the metric while the light cone emerges from the electric-to-magnetic stiffness ratio of the spacetime constitutive tensor; (6.20)–(6.22) exhibit this mechanism at tree level, while Theorem 11.4 in Section 11.4 derives the physical transverse Maxwell light cone $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$ for the full 289-field quantum-dressed response. Meanwhile, the zero-residue gate of Proposition 6.3 (Table 2, row 4) echoes Dirac's classic insight [27] that bare spinor sources do not automatically carry physical Coulomb fields; Sections 9–10 prove that activating the difference of spatial gauge slots 21 and 34 ($A_1^{\,0}-A_2^{\,1}$) through full configuration insertion and the physical rest electron leg generates the nonzero Coulomb seed $K_*=\frac{9023}{9000}\sqrt{30}$.

For the ten original metric sources, set $\delta g=e_0^{\mathsf T}\eta\delta e+\delta e^{\mathsf T}\eta e_0$. With the positive-sign source convention, the response $R_g$ satisfies $\delta g=-R_gJ$. One complete static axial readout at $k=\sqrt2q$ is

$$R_{00,00}(q)=N^3\frac{625q^6+7800q^4+15984q^2-31104}
{625q^8+2550q^6+7704q^4+23328q^2-93312}.\tag{6.24}$$

Its value at the origin is $N^3/3$, while $\lim_{|k|\to\infty}|k|^2R_{00,00}=2N^3$. Every entry of the ten-by-ten metric readout is finite at the origin. The eight $1/q$ terms of the full field in the $J_{03}$ channel remain, but cancel under the metric map. The actual numerators distinguish clearly the information retained by the source, complete field, and final observable.

<a id="sec-7"></a>

## 7 Spatial Dirac self-adjoint domain, localized gauge preparation, and whole-word CAR positivity

### 7.1 The same twelve-dimensional symbol

We return to the original occupied space of §1. This time all 48 gauge perturbation directions appear; the examination is no longer restricted to a single $T$. The stationary Hamiltonian read from the actual connection is

$$h(\mathbf k)=h_0+\sum_iH_i k_i,\qquad
h_0=\left(\frac{3Ns}{2}-\omega\right)\gamma^5
+iN\alpha_0\sum_i\gamma^0\gamma^i\rho_i,\qquad
H_i=-N\gamma^0\gamma^i.\tag{7.1}$$

All matrices are restricted to $\mathcal H_{12}$, and $\rho_i$ are the three original color generators. For every real momentum, $h(\mathbf k)$ is Hermitian and commutes with $Q$. The Hamiltonian in original time is $H_{\rm orig}=h+\omega Q$. The $h_0$ of §1 is precisely the zero-momentum part above.

For an original gauge direction $A_\mu^a$, the Hamiltonian force and current are

$$T_{0a}=-i\rho_a,\qquad T_{ia}=iN\gamma^0\gamma^i\rho_a,\qquad
B_{\mu a}=-sQT_{\mu a}.\tag{7.2}$$

Both families preserve $\mathcal H_{12}$ and are Hermitian. Let the columns of $T_*$ and $B_*$ be $T_a\psi_0$ and $B_a\psi_0$, respectively, retaining the original background amplitude $\psi_0=2w$:

**Proposition 7.1 (Forty-eight-direction occupied current response and uniform upper-half-plane bound, `L12`).** The ordered resolvents of the two matter legs define the complete $48\times 48$ occupied current response

$$\Pi(E,\mathbf k)=B_*^\dagger(E-h(\mathbf k))^{-1}T_*
-B_*^{\mathsf T}(E+h(-\mathbf k))^{-\mathsf T}\overline{T_*},
\tag{7.3}$$

which agrees entry by entry with Schur elimination of the occupied matter and independent dual from the 289-dimensional system and evaluates in the zero-momentum temporal slot to

$$\Pi_{00}(z\omega,0)=-\frac{200\sqrt{30}}{27(z^2-4)}.\tag{7.4}$$

For every $E\in\mathbb R$, $\eta>0$, and $\mathbf k\in\mathbb R^3$, the imaginary part of the Hermitian inner product gives

$$\eta\|v\|\leq\|[(E+i\eta)I-h(\mathbf k)]v\|,
$$

ensuring invertibility in the upper half-plane and the momentum-uniform operator-norm bound

$$\boxed{\|\Pi(E+i\eta,\mathbf k)\|\leq\frac{1512\sqrt2}{125\eta}.}
\tag{7.5}$$

**Proof.** Eliminating the 48 real occupied primal and independent-dual rows of $H_{289}$ via (4.2) while retaining momentum reversal, transpose, and conjugation yields (7.3) and (7.4). Hermiticity of $h(\mathbf k)$ gives $\operatorname{Im}\langle v,[(E+i\eta)I-h(\mathbf k)]v\rangle=\eta\|v\|^2$, bounding the resolvent norm by $\eta^{-1}$ and yielding (7.5) from the fixed column norms of $T_*,B_*$; at zero momentum, positively damped Laplace integration of the retarded forced ODE reproduces the identical rational response. ∎

### 7.2 The spatial carrier and the complete domain of the unbounded generator

Finite matrices tell us how each momentum evolves. A normalizable spatial state also requires a complete Hilbert space. Set

$$\mathscr H=L^2(\mathbb R^3,\mathbb C^{12}),\qquad
U(t)=\mathcal F^{-1}\,e^{-it h(2\pi\xi)}\,\mathcal F.\tag{7.6}$$

The exponential is unitary in every fiber, so it preserves the $L^2$ norm and has the explicit inverse $U(-t)$. As $t\to0$, the squared pointwise difference is bounded by $4\|\widehat f(\xi)\|^2$; dominated convergence gives strong continuity. No bound on $h(\mathbf k)$ over all momenta is required.

**Theorem 7.2 (Spatial unitary group and bidirectional self-adjoint domain characterization, `L13`).** Equation (7.6) defines a strongly continuous unitary group on $\mathscr H$. The complete domain and action of its self-adjoint Hamiltonian $\mathsf H$ are

$$\boxed{\mathcal D(\mathsf H)=
\{f\in\mathscr H:h(2\pi\xi)\widehat f(\xi)\in L^2\},\qquad
\mathsf Hf=\mathcal F^{-1}\bigl(h(2\pi\xi)\widehat f(\xi)\bigr).}
\tag{7.7}$$

For every vector in this domain, $\partial_tU(t)f=-i\mathsf HU(t)f$ holds at every real time. Schwartz fields belong to the domain, and Fourier differentiation gives the original position-space Dirac equation. General $L^2$ initial states satisfy the corresponding weak equation and its weak return to the independent dual.

**Proof.** Forward inclusion follows from Plancherel unitarity and dominated convergence; the decisive step is the reverse inclusion: without it, one knows only that vectors with a square-integrable energy multiplier lie in the domain, without verifying that the maximal self-adjoint generator supplied by Stone's theorem [17] has no strictly larger domain (compare Thaller's standard Fourier-multiplier domain analysis for free Dirac operators [18], extended here to non-Abelian background connections and axial spin torsion $h_0$). Indeed, if $U(t)f$ has an $L^2$ strong derivative at zero, a subsequence of its difference quotients converges almost everywhere; in every finite-dimensional momentum fiber, the derivative of the matrix exponential equals $-ih(2\pi\xi)\widehat f(\xi)$. Agreement of the two limits almost everywhere forces this energy multiplier to belong to $L^2$. Hence (7.7) is the exact self-adjoint domain. ∎

Propagation in original time is

$$U_{\rm orig}(t)=P(t)U(t),\qquad P(t)=e^{-i\omega tQ}.\tag{7.8}$$

The internal phase commutes with the vector-valued Fourier transform, so this identity holds for every $L^2$ vector. The spatially constant background remains the original field that generates the coefficients. Preparations, perturbations, and forced fields are the objects placed in $L^2$.

### 7.3 Original gauge controls generate spatial preparations

For a continuous $L^2$ source $f(t)$, define the actual strong integral

$$u(t)=\int_0^tU(t-\tau)f(\tau)\,d\tau.\tag{7.9}$$

It is continuous, has zero initial value, and satisfies

$$\frac d{dt}\bigl[U(-t)u(t)\bigr]=U(-t)f(t),\qquad
\|u(t)\|\leq\int_0^t\|f(\tau)\|\,d\tau\quad(t\geq0).
\tag{7.10}$$

If the source vanishes in the past, so does the past field. Subtracting (7.9) from another solution leaves a curve with zero derivative in the interaction picture; thus mild solutions with the same initial value are unique.

Let an original finite-dimensional gauge force act pointwise on an $L^2$ spatial profile. This gives an actual history of source operators $F(t)$ from $\mathcal H_{12}$ to $\mathscr H$, and a bounded linear preparation map

$$K_tu=\int_0^tU(t-\tau)F(\tau)u\,d\tau,\qquad
\|K_t\|\leq\left|\int_0^t\|F(\tau)\|\,d\tau\right|,\qquad t\in\mathbb R.\tag{7.11}$$

This control is an actual field source; the preparation direction still comes from the original occupied vector $w$. The source construction supplies a nonzero causal history and a positive preparation time $t_p$ for which $K_{t_p}w\ne0$. Consequently,

$$u_p=\frac{K_{t_p}w}{\|K_{t_p}w\|},\qquad
\rho_p=|u_p\rangle\langle u_p|\tag{7.12}$$

is a normalized spatial pure state. The unnormalized $K_t|w\rangle\langle w|K_t^\dagger$ also retains the preparation strength. For every bounded spatial operator $A$,

$$\langle K_tw,AK_tw\rangle=\langle w,K_t^\dagger AK_tw\rangle.\tag{7.13}$$

Let $I_{12}:\mathcal H_{12}\to\mathcal M$ be the original isometric embedding, and lift the operator on the right to $\widetilde A_t=I_{12}K_t^\dagger AK_tI_{12}^\dagger$. One spin exchange $S$ is still needed before evaluation by the independent dual. From $\chi_0=s\psi_0^\dagger S$, $S^2=I$, and $\psi_0(0)=2I_{12}w$, we obtain

$$\chi_0(0)\bigl(S\widetilde A_t\psi_0(0)\bigr)
=4s\,\langle w,K_t^\dagger AK_tw\rangle
=4s\,\langle K_tw,AK_tw\rangle.\tag{7.13a}$$

The quantum evaluation by the original source reads (7.13a) divided by $4s$, exactly recovering (7.13). The spin exchange acts once, after the complete operator has been formed; it is not inserted into intermediate products. Spatial preparation and the original independent dual therefore evaluate the same object throughout.

### 7.4 Every finite CAR word

A spatial preparation must support more than a single one-body expectation. Given any finite test family $f_1,\ldots,f_m\in\mathscr H$, allow repetitions, linear dependence, and nonorthogonality, and include $u_p$ in its finite-dimensional span $E$. On $\Lambda E$, define creation and annihilation operators satisfying

$$\{a(f),a(g)\}=0,\qquad
\{a(f),a^\dagger(g)\}=\langle f,g\rangle I.\tag{7.14}$$

**Proposition 7.3 (Whole-word CAR positivity and mother-pairing order across arbitrary finite test families, `L15`).** For any (possibly repeated, linearly dependent, and nonorthogonal) finite test family $f_1,\ldots,f_m\in\mathscr H$ together with the unit spatial preparation $u_p$, set $E=\operatorname{span}\{u_p,f_1,\ldots,f_m\}$. On the antisymmetric tensor carrier $\Lambda E$, every finite creation/annihilation word $W$ admits the extension-consistent vector-state evaluation

$$\omega_p(W)=\langle u_p,Wu_p\rangle_{\Lambda E}.\tag{7.15}$$

Here $u_p$ lies in the one-particle sector while $W$ may traverse arbitrary intermediate particle-number sectors. Enlarging $E$ intertwines every creation and annihilation operator isometrically, so $\omega_p(W)$ is independent of adjoined test directions and satisfies linearity, adjoint compatibility, and positivity $\omega_p(W^\dagger W)\ge 0$ across all finite words.

**Proof.** Any isometric subspace inclusion $E\hookrightarrow E'$ induces an isometric exterior-algebra embedding $\Lambda E\hookrightarrow\Lambda E'$ preserving wedge products and Hilbert adjoints, thereby intertwining every $a^\dagger(f)$ and $a(f)$ ($f\in E$) and leaving (7.15) invariant; positivity is immediate from $\langle Wu_p,Wu_p\rangle_{\Lambda E}=\|Wu_p\|^2\ge 0$ (Supplement S3.3). ∎

Proposition 7.3 supplies a constructive finite-subalgebra bridge between one-body second quantization [4] and general quasifree CAR algebras [20] that couples directly to the 252-dimensional independent-dual mother pairing without pre-orthogonalization. If $J_E:E\to\Lambda E$ is the one-particle embedding, the actual operator returned to the one-body input is $J_E^\dagger WJ_E$. Form the complete word first, then pull it back via (7.13) and the single terminal spin flip $S$. In particular,

$$J_E^\dagger ABJ_E\ne
(J_E^\dagger AJ_E)(J_E^\dagger BJ_E)
\tag{7.16}$$

whenever an intermediate particle-number sector contributes on return; the discrepancy is the complementary-subspace return term of (3.15). A four-point word turns this noncommutativity into an immediate counterexample (Table 2, row 3): for any four not necessarily orthogonal spatial test vectors $f,g,h,k$, a unit one-particle preparation $u_p$ gives

$$\langle u_p,a^\dagger(f)a(g)a^\dagger(h)a(k)u_p\rangle
=\langle u_p,f\rangle\langle g,h\rangle\langle k,u_p\rangle.\tag{7.16a}$$

Acting from right to left, the state traverses the one-particle, vacuum, one-particle, vacuum, and one-particle sectors; the three inner products are the exact amplitudes of those transitions. Setting all four test vectors equal to $u_p$ returns $1$ for the whole word, whereas compressing each creation or annihilation operator to the one-particle sector $J_E^\dagger(\cdot)J_E$ before multiplying collapses the reading to $0$. Return through intermediate particle-number sectors is essential physical content of the complete product.

### 7.5 Local currents become integrable readings

Let $g\in L^\infty(\mathbb R^3)$ be a real control profile, and let $T$ be an original gauge force from (7.2). The local Hamiltonian is the bounded self-adjoint operator

$$R_gf(\mathbf x)=g(\mathbf x)Tf(\mathbf x).
\tag{7.17}$$

The corresponding original current matrix remains $B=-sQT$. For $f,h\in L^2$, the local current density $g f^\dagger Bh$ belongs to $L^1$, with

$$\|g f^\dagger Bh\|_{L^1}
\leq\|g\|_\infty\|B\|\|f\|_2\|h\|_2.\tag{7.18}$$

This gives the integrated current an actual meaning in function space. The next section applies the same controls at finite amplitude, before assuming a linear response.

<a id="sec-8"></a>

## 8 Nonperturbative all-time unitary evolution and the operator-norm causal Kubo derivative

### 8.1 Generating evolution for all time from original controls

Suppose $R:\mathbb R\to\mathcal B(\mathscr H)$ is continuous in operator norm and every $R(t)$ is self-adjoint. Original local gauge histories $R(t)=R_{g_t}$ give an actual class of inputs: $t\mapsto g_t$ is continuous in the $L^\infty$ norm, the profiles are real, and the gauge matrices are generated by (7.2). A bound $M$ exists on each compact time interval; no common bound over the entire time axis is required.

For any real amplitude $\epsilon$, any real initial time $a$, and any $u\in\mathscr H$, solve in the interaction picture

$$y'(t)=-i\epsilon R_H(t)y(t),\qquad y(a)=u,\qquad
R_H(t)=U(-t)R(t)U(t).\tag{8.1}$$

Only strong continuity of $U$ is needed. Continuity of $R_H(t)$ on each vector, together with a locally uniform norm bound, makes the vector field in (8.1) jointly continuous. The group of the unbounded free Hamiltonian need not be continuous in operator norm.

**Theorem 8.1 (Unitary evolution generated by the source for all time, `L17`).** For every $R$ as above and every $\epsilon,a,u$, equation (8.1) has a unique strong solution on all of $\mathbb R$. The physical propagator it generates,

$$W_\epsilon(t,a)u
=U(t)y_{\epsilon,a,U(-a)u}(t)\tag{8.2}$$

is an actual two-time unitary operator on $\mathscr H$, satisfying

$$W_\epsilon(a,a)=I,\quad
W_\epsilon(t,b)W_\epsilon(b,a)=W_\epsilon(t,a),\quad
W_\epsilon(t,a)^{-1}=W_\epsilon(a,t),\quad
\|W_\epsilon(t,a)u\|=\|u\|.\tag{8.3}$$

The physical field satisfies the original controlled weak equation against every test vector in the generator domain.

**Proof.** The difficulty is extending a solution through all time: the state space is unbounded, and an ordinary Picard construction initially gives only a local window near the initial value. First replace the unbounded state variable by the globally bounded radial map

$$b(v)=\frac{v}{1+\|v\|},\qquad \|b(v)\|\leq1,\qquad
\|b(v)-b(w)\|\leq2\|v-w\|.\tag{8.4}$$

On any prescribed finite window, use the vector field

$$F(t,v)=-i\epsilon R_H(t)(1+\|u\|)b(v)\tag{8.5}$$

in the Picard construction. It is bounded and uniformly Lipschitz over the whole state space, so the window length is no longer restricted by a small neighborhood of the initial value. Along the resulting trajectory, self-adjointness gives

$$\frac d{dt}\|v(t)\|^2
=2\operatorname{Re}\langle v(t),-i\epsilon R_H(t)v(t)\rangle
\frac{1+\|u\|}{1+\|v(t)\|}=0.\tag{8.6}$$

Therefore $\|v(t)\|=\|u\|$, and the radial factor in (8.5) is exactly 1 along the whole trajectory. The constructed solution returns to (8.1) without changing physical time. The difference between two original solutions on overlapping windows also preserves its norm and has zero initial value, so the two solutions agree. Arbitrary finite windows thus glue to a solution for all time. Uniqueness then proves additivity, complex homogeneity, the composition law, and backward evolution, giving (8.3). ∎

The argument has two steps: a globally bounded radial vector field supplies fixed points on arbitrarily large finite windows, and self-adjoint norm conservation restores the auxiliary radial factor to $1$ identically. Compared with time-ordered Dyson series [19] and Kato's theorem on nonautonomous Banach-space hyperbolic evolution equations [5, Conditions C1–C4, Theorems 1–5], Theorem 8.1 requires neither time-independent generator domains with strong $C^1$ regularity nor a uniform norm bound on $R(t)$ across the entire real line $\mathbb R$ (histories growing unboundedly like $\max(t,0)$ in Section 8.4 close identically), generating a two-time unitary group for every real amplitude $\epsilon\in\mathbb R$.

### 8.2 An operator-norm derivative of the same solution family

Fix any real $t$ and take the initial time to be 0. On the time segment joining $0$ and $t$, choose $M\geq\sup\|R(\tau)\|$ and define

$$D(t)u=-i\int_0^tU(t-\tau)R(\tau)U(\tau)u\,d\tau.
\tag{8.7}$$

For every $u$, the integral converges strongly in $\mathscr H$. Since $\|D(t)\|\leq M|t|$, it defines a bounded operator.

**Theorem 8.2 (Operator-norm amplitude derivative, `L17`).** The propagator $\epsilon\mapsto W_\epsilon(t,0)$, defined for every real amplitude, has the operator-norm derivative $D(t)$ at $\epsilon=0$. The same actual evolution satisfies the uniform remainder bound

$$\boxed{\|W_\epsilon(t,0)-U(t)-\epsilon D(t)\|
\leq\epsilon^2M^2|t|^2\qquad(|\epsilon|\leq1).}\tag{8.8}$$

As $t$ is arbitrary, the conclusion holds at every real time.

**Proof.** The decisive step is making the remainder bound uniform over the entire unit ball. Starting from the original integral equation, the difference between the interaction state and its initial value first obeys

$$\|y_\epsilon(\tau)-u\|\leq|\epsilon|M|\tau|\|u\|.
$$

Substituting this difference back into the integral once bounds the first-order remainder by $\epsilon^2M^2|t|^2\|u\|$. Because the same $M$ works across the entire unit ball, taking the supremum gives (8.8), promoting the strong derivative on each state to an operator-norm Fréchet derivative of the global family constructed in Theorem 8.1. ∎

### 8.3 The two-sided current, Kubo integral, and original source

For a bounded self-adjoint current operator $B$ and arbitrary initial state $u\in\mathscr H$, define the finite-control current expectation

$$J_\epsilon(t)=\operatorname{Re}\langle W_\epsilon(t,0)u,
B W_\epsilon(t,0)u\rangle.
$$

Applying the uniform unit-ball operator-norm remainder bound (8.8) of Theorem 8.2 to both state legs gives

$$\left.\partial_\epsilon J_\epsilon(t)\right|_0
=\operatorname{Re}\bigl[
\langle D(t)u,BU(t)u\rangle+
\langle U(t)u,BD(t)u\rangle\bigr].\tag{8.9}$$

Setting $B_H(t)=U(-t)BU(t)$ and substituting (8.7) establishes the all-time causal linear-response identity:

**Corollary 8.3 (Two-sided variation and all-time causal Kubo commutator response, `L16-L17`).** For every $u\in\mathscr H$, every real time $t\in\mathbb R$, and every gauge-control history $R$ of Section 8.1, the finite-amplitude current family $\epsilon\mapsto J_\epsilon(t)$ is differentiable at $\epsilon=0$, and its genuine derivative equals the oriented commutator integral

$$\boxed{\left.\partial_\epsilon J_\epsilon(t)\right|_0
=\operatorname{Re}\,i\int_0^t
\langle u,[R_H(\tau),B_H(t)]u\rangle\,d\tau.}\tag{8.10}$$

**Proof.** Expanding $W_\epsilon(t,0)=U(t)+\epsilon D(t)+O_{\mathcal B(\mathscr H)}(\epsilon^2)$ by Theorem 8.2 against bounded self-adjoint $B$ gives (8.9); substituting the strong integral (8.7) and using unitarity of $U(t)$ combines the two inner products into $[R_H(\tau),B_H(t)]$, yielding (8.10). ∎

Compared with Kubo [6, §2]—which assumes an initial equilibrium density matrix commuting with the unperturbed Hamiltonian ($[\rho,H]=0$, switched on adiabatically with a formal first-order truncation of the quantum Liouville equation)—and operator-algebraic KMS perturbation theory [21], Theorems 8.1–8.2 and Corollary 8.3 sharpen three boundaries: first, $u$ need not be an eigenstate of $\mathsf H$ or a thermal state (in particular, $u$ may be the nonstationary spatially localized preparation $u_p$ driven over $[0,t_p]$ in Section 7.3); second, the nonperturbative unitary family is constructed for all $\epsilon\in\mathbb R$ first and differentiated via the uniform unit-ball bound $\epsilon^2M^2|t|^2$ in operator norm; third, the Hamiltonian driving force $T$ is kept distinct from the independent-dual action current $B=-sQT$ (omitting $-sQ$ triggers the exact cancellation counterexample of Section 1.2).

For $u=u_p$, first define the complete response operator

$$A_{\rm resp}(t)=i\int_0^t[R_H(\tau),B_H(t)]\,d\tau
\tag{8.11}$$

by a strong integral on each vector, then apply the normalized pullback $K_{t_p}^\dagger A_{\rm resp}K_{t_p}$. Evaluation by the complete original mother operator equals (8.10) exactly. If the current is represented by second quantization, the commutator becomes the finite CAR four-point word of §7.4; evaluation of the complete word by the original source remains the same reading. Five witnesses now sign the same equality: finite evolution, differentiation of both legs, the Duhamel integral, the Kubo commutator, and original source evaluation.

Original local gauge forces commute with $Q$. By uniqueness, the actual evolution also commutes with $P(r)$. The original phase at preparation time $t_p$ therefore gives the actual field

$$\psi_{\epsilon,\rm orig}(t)=P(t+t_p)W_\epsilon(t,0)u_p.\tag{8.12}$$

Its actual interaction equation in original time is

$$\frac d{dt}\bigl[U_{\rm orig}(-t)\psi_{\epsilon,\rm orig}(t)\bigr]
=U_{\rm orig}(-t)(-i\epsilon R(t)\psi_{\epsilon,\rm orig}(t)).\tag{8.13}$$

The original current is compatible with this phase, so (8.10) is preserved in original time with the full preparation phase. The current matrix $B=-sQT$ already contains the dual weight $s$: doubling the prepared field amplitude multiplies the current and its derivative by four, as in §1. The independent-dual evaluation of the mother operator uses $4s$ according to (7.13a); the current, which already carries the weight, is not multiplied by $s$ again. If the control vanishes in the past, the past physical field is exactly the original free evolution.

### 8.4 Two tests: the finite window and the actual spatial carrier

The opening current returns to court. The temporal color-gauge control $T=-iI_4\otimes\rho_{01}$ of §1 gives a finite solution with noncommuting coefficients. After division by $\epsilon$, (1.8) tends to (1.9) as $\epsilon\to0$. Write $x=\omega t$ and $\beta=\epsilon/\omega$. The full comparison becomes

$$\frac{\omega J_\epsilon(t)}{s\epsilon}
=\frac{1-\cos(2x\sqrt{1+\beta^2})}{1+\beta^2}
\longrightarrow1-\cos2x.
\tag{8.14}$$

![The current under finite original control and its actual derivative](figures/main-03-finite-current-en.svg)

**Figure 3. How the finite current approaches its actual derivative.** The solid curves use (8.14) with $\epsilon/\omega=1,1/2,1/4$ (gold, gray, and dark blue). The vermilion dashed curve is the normalized derivative $1-\cos2\omega t$, with $\omega=18\sqrt{15}/125$. The horizontal coordinate $\omega t$ uses original time, not proper time. The vertical coordinate is $\omega J_\epsilon/(s\epsilon)$ for a unit occupied state; the current of the field with its original amplitude is four times as large. Finite amplitude changes both amplitude and oscillation frequency.

This four-dimensional invariant window of the original system tests the noncommuting coefficients; actual $L^2$ examples test the spatial and temporal quantifiers. Original temporal hypercharge generates $T=I$ on the occupied space. For a nonzero spherical $L^2$ profile $f$, the actual propagator for every real $\epsilon,a,t$ is

$$W_\epsilon(t,a)f=e^{-i\epsilon(t-a)}U(t-a)f.\tag{8.15}$$

For example, at $\epsilon=3,a=100,t=-200$, the actual solution is $e^{900i}U(-300)f$. Its norm is nonzero, with no restriction to the original local time window or a small-amplitude range. Another real local control history vanishes in the past and grows as $\max(t,0)$ in the future. It needs no uniform norm bound on the whole time axis; at $\epsilon=-7,t=-1000$, the evolution returns exactly to $U(-1000)f$.

The original nonzero causal preparation also supplies some $t_p>0$ such that its normalized field in original time has norm 1 for every real $\epsilon,t$ and admits the original source derivative (8.10). The finite invariant window and the examples on the full spatial carrier each use their actual carrier, together testing the coefficients and the construction for all time.

<a id="sec-9"></a>

## 9 Source-generated electromagnetic preparation, unit electron charge, and the static Coulomb scalar

Section 8 connected the mother-action current to all-time unitary development in three-dimensional real space. Spatial and configuration preparations now enter gauge exchange directly: the mother action first generates a many-body configuration state, then unites the unbroken electromagnetic generator, the complete 289-field static Green inverse, and the physical rest electron within one parameter-free calculus. Neither the charge unit nor the static coupling is supplied by an external fit; the phase action, endpoint preparations, and every normalization trace directly back to the original action.

### 9.1 The independent-dual mother density reproduces the same propagation operator

Along the same positive smooth unified source of [1] and its actual nine-field configuration, take the real first jet $j=(x,x_\mu)\in\mathbb R^{289}\times(\mathbb R^{289})^4$. Inserting the anchored affine signal $x+\sum_\mu(y^\mu-y_0^\mu)x_\mu$ into the nine original field groups yields the local mother density $\mathcal L_{\mathrm{nat}}(j)$ with its independent complex-linear dual pairing. The matter leg is inserted with the co-rotating matrix; the independent dual is right-composed with that same matrix without complex conjugation of its coefficients. Set $\mathcal B=D^2\mathcal L_{\mathrm{nat}}(0)$, $\sigma_\emptyset(p)=1$, and $\sigma_\mu(p)=p_\mu$. The Fourier dictionary of this real second-variation Hessian is

$$K_{ab}(p)=\sum_{d,e\in\{\emptyset,0,1,2,3\}}
\mathcal B(e_{d,a},e_{e,b})\sigma_d(-p)\sigma_e(p)
=H_{289,ab}(p),\qquad p\in\mathbb C^4.
\tag{9.1}$$

Theorem 11.1 proves this identity in full: every coefficient arises from an actual second partial derivative of the local mother density and lies in $\mathbb Q(\sqrt2,\sqrt{15})$. The Green operator consumed by the many-body configuration preparations below is therefore the identical constrained propagation operator of §§4–6, joined by an exact action identity across all $289$ real field directions.

For arbitrary external forcing $J$, field reconstruction retains the nine-dimensional compatibility cosource:

$$K(p)X(p;J)=J-L_{\mathrm{null}}(p)\,
P_{\mathrm{null}}R_b(p)J,\qquad
R_b(p)L_{\mathrm{null}}(p)=I.
\tag{9.2}$$

The right-hand side simplifies to $J$ if and only if that nine-dimensional cosource vanishes. Every static and far-field limit below retains (9.2) intact rather than mistaking the existence of a pole for source compatibility.

### 9.2 Configuration-space preparation and complete two-leg currents

Whereas §§7–8 evolved a 12-component spatial spinor on a fixed classical background, from this section onward we work on the full many-body configuration–Fock carrier constructed in [1, §6.3]: the bosonic sector consists of UV-cutoff-free square-integrable half-densities on the 100-dimensional local configuration manifold (so configuration diffeomorphisms act natively as norm-preserving isometries), tensored with the 504-real-mode canonical anticommutation (CAR) Fock space of the full 252-dimensional chiral spinor and its independent dual. The common many-body Hamiltonian is bigraded by particle-number sector $N=k$ (also abbreviated N$k$) and finite exterior raising degree; because the exterior and finite-frame dimensions are bounded, the pure raising Yukawa operator is strictly nilpotent—every 57-fold pure raising product vanishes identically, closing full-Yukawa resolvents as exact finite geometric sums without perturbative resummation.

Within this configuration-manifold measure and half-density representation, $A$ is the minimal closed graph of the first-order factor of the coframe Weyl principal part, while $R$ is the complete Fourier energy tail minus the composition term; closedness of the action domain and two-sided Schur bounds ensure that $A$ is densely defined and $R$ is bounded self-adjoint. Together they define the closed quadratic form $\mathfrak q(x,y)=\langle Ax,Ay\rangle+\langle x,Ry\rangle$ and hence the unique self-adjoint source operator $\mathcal T$, whose strictly positive injective resolvent and ground energy scale are

$$\mathsf B=(\mathcal T+1+\|R\|)^{-1},\qquad
E_{\mathrm{src}}=\|\mathsf B\|^{-1}-(1+\|R\|).
\tag{9.3}$$

For every precision $\varepsilon>0$, Supplement S4.1 constructs from $\mathsf B$ a unit vector $x_\varepsilon$ in the domain of $\mathcal T$ satisfying $\|\mathcal T x_\varepsilon-E_{\mathrm{src}}x_\varepsilon\|<\varepsilon$. Smooth localization in the source chart together with CAR creation produces a spatial profile $u_\varepsilon$ and configuration state $v_\varepsilon$. Writing $\mathcal Z_\phi$ for zero-point localization cut off by a smooth localizer $\phi$, $\Pi_{\mathrm{prep}}$ for the preparation map, $\mathcal D_{1/2}$ for the configuration half-density isometry on the zero-particle sector, and $\mathcal C_{\mathrm{src}}$ for CAR source creation, we have

$$\begin{gathered}
u_\varepsilon=\mathcal Z_{\phi_{\mathrm{src}}}x_\varepsilon,\qquad
v_\varepsilon=\Pi_{\mathrm{prep}}u_\varepsilon
=\mathcal C_{\mathrm{src}}\mathcal D_{1/2}x_\varepsilon,\\
\|v_\varepsilon\|=1,\qquad
\langle v_\varepsilon,Q_Yv_\varepsilon\rangle=-1.
\end{gathered}\tag{9.4}$$

The localizer $\phi_{\mathrm{src}}$ equals $1$ at the source basepoint, ensuring a nontrivial localized subspace. The operators and energy $\mathcal T,R,E_{\mathrm{src}}$ are independent of $\varepsilon$. The full Yukawa domain and operator value are preserved with the geometric truncation bound $\|Y_{\mathrm{closed}}v_\varepsilon-Y_n v_\varepsilon\|\le(915/916)^{n+1}\,916\,b_Y$, without requiring norm convergence of the state sequence as $\varepsilon\downarrow 0$. Here $v_\varepsilon$ is the single-particle configuration background preparation; below, $N=k$ (abbreviated N$k$) denotes the $k$-particle sector of the full 504-mode CAR Fock space. The two-particle (N2) unit created state in §12.3 applies the specified charged CAR creation operator to this background first and divides by the generated nonzero vector's actual norm rather than substituting $\|v_\varepsilon\|=1$.

Write $L^{\pm}_{a,s}u_\varepsilon$ for the completed creation/annihilation legs retaining both inverse square-root and square-root coframe volume factors and the full configuration measure. For any finite configuration test frame $F$, fully retained resolvent $G_{F,n}(p,z)$, and test reconstruction map $\mathcal I_F$, let $\mathcal F_i$ denote the configuration field form of the mother action along the $i$-th real field direction $e_i$ (decomposed in (9.13)). For independent legs $\ell,r$, define

$$a=\mathcal I_F\!\left(G_{F,n}(p+k,z)^\dagger\ell\right),\qquad
b=\mathcal I_F\!\left(G_{F,n}(p,w)r\right),\qquad
J_i=D\mathcal F_i(0)[a,b].
\tag{9.5}$$

This is the complete $289$-component prepared current. Here $C_F(p)$ is the grade-preserving part of the common Hamiltonian compressed to the finite frame, and $Y_n$ is the retained Yukawa truncation, with explicit resolvent convention

$$\begin{aligned}
&R_F(p,z)=(C_F(p)-zI)^{-1},\qquad
H_{F,n}(p)=C_F(p)+Y_n,\\
&G_{F,n}(p,z)=(H_{F,n}(p)-zI)^{-1}
=\sum_{j=0}^{56}(-R_F(p,z)Y_n)^jR_F(p,z).
\end{aligned}$$

Because finite grade support annihilates every 57-fold pure raising product, the finite sum is an exact two-sided inverse. The uncut matter resolvent below uses the same $H-zI$ convention while §7 retains its $E-h$ sign. With $f_{F,\alpha}$ and $v_{F,\alpha}$ denoting the frame test functions and their configuration images, define the explicit computable constants

$$b_n(z)=\frac1{|\operatorname{Im}z|}
\sum_{j=0}^{56}\left(\frac{\|Y_n\|}{|\operatorname{Im}z|}\right)^j,\qquad
c_i(p,F)=\sum_{\alpha,\beta}
\left|D\mathcal F_i(0)
[f_{F,\alpha},f_{F,\beta}]\right|
\|v_{F,\alpha}\|\|v_{F,\beta}\|.$$

For $\operatorname{Im}z,\operatorname{Im}w\ne0$, each current component obeys the explicit a priori bound

$$|J_i|\le \|\ell\|\,b_n(z)\,c_i(p,F)\,b_n(w)\,\|r\|.
\tag{9.6}$$

Both resolvents, the retained Yukawa interaction, and the two endpoint preparations remain completely independent across source and detector.

### 9.3 Half-unit dressed joint characters versus the absolute integer unit electron charge

The unbroken electromagnetic generator is locked by the mother color–hypercharge algebra to $\mathsf E=-T^{\mathrm{color}}_2-Y/2$. In the seven-dimensional basis order $(c_0,c_1,c_2,w_0,w_1,h_+,h_-)$, its anti-Hermitian diagonal weights are

$$\mathsf E=i\,\operatorname{diag}\!\left(-\tfrac12,\tfrac12,0,0,0,-\tfrac12,\tfrac12\right),
\qquad
\mathsf E\,e_I=i\!\left(\sum_{j\in I}q_j\right)e_I.
\tag{9.7}$$

Pairing the four-index scalar subset $\{c_0,c_1,c_2\}\setminus\{c\}$ joined with $\{w_0,w_1\}$ or $\{h_+,h_-\}$ against the two-index matter subset $\{c,h_+\}$ gives scalar weights $(1/2,-1/2,0)$ and matter weights $(-1,0,-1/2)$, whose sum equals $-1/2$ in every color channel. For $a,s\in\{0,1\}$, let $I(a,c)$ denote that scalar index set and define the signed exterior contractions

$$\phi_{a,c}=(-1)^{[c=1]}\Phi_{I(a,c)},\qquad
\psi_{s,c}=\psi_{s,\{c,h_+\}},\qquad
r_{a,s}=\sum_c\phi_{a,c}\psi_{s,c},\qquad
r^\vee_{a,s}=\sum_c\overline{\phi_{a,c}}\,
\chi(e_{s,\{c,h_+\}}).$$

Here $\chi$ remains an arbitrary independent complex-linear dual. The termwise Leibniz rule yields

$$r_{a,s}(\mathsf E\Phi,\psi)+r_{a,s}(\Phi,\mathsf E\psi)
=-\frac i2r_{a,s}(\Phi,\psi),\qquad
r^\vee_{a,s}(\mathsf E\Phi,\chi)+
r^\vee_{a,s}(\Phi,-\chi\circ\mathsf E)
=\frac i2r^\vee_{a,s}(\Phi,\chi).
\tag{9.8}$$

Right composition $-\chi\circ\mathsf E$ together with conjugation of the scalar coefficient in the dual contraction flips the sign without replacing $\chi$ by a Hilbert adjoint.

Combining the CAR identities $[d\Gamma(M),a^\dagger_j]=\sum_iM_{ij}a_i^\dagger$ and $[d\Gamma(M),a_j]=-\sum_iM_{ji}a_i$ with (9.7) establishes the dressed creation and annihilation characters $c_+=i/2$ and $c_-=-i/2$ on smooth tests and extends them by boundedness to completed profiles. Consequently,

$$J_i^{\mathrm{dress}}=(\overline{c_\ell}+c_r)J_i.
\tag{9.9}$$

In the full 504-mode mother action, the gauge generator $G_T=iQ_{\mathrm{first}}$ of the first-charge matrix $Q_{\mathrm{first}}$ carries character $-(10/11)c_\pm$ and scales the prepared current by the same factor $-10/11$. Meanwhile, acting with the full charge operator on a completed leg retains the scalar–configuration input remainder (equal on the smooth core to $L^\pm(Q_{\mathsf E}f)+i\,\operatorname{embed}(L^\pm_{\delta\Phi}f)$ for seed section $f$ and $\delta\Phi=\mathsf E\Phi$, with bounded extension $L_{\mathrm{in}}^\pm$):

$$Q_{\mathsf E}L^\pm u=\delta_\pm L^\pm u+L_{\mathrm{in}}^\pm u,\quad
\delta_\pm=\pm\tfrac12,\qquad
J_Q=(\delta_\ell+\delta_r)J+J_{\mathrm{in}}.
\tag{9.10}$$

Thus the photon pole left reader $\beta(J_Q)$ evaluates both $(\delta_\ell+\delta_r)\beta(J)$ and $\beta(J_{\mathrm{in}})$: the half-unit $\pm 1/2$ is a relative increment of the scalar–matter composite letter rather than the absolute charge of an isolated electron leg.

The absolute charge unit of the physical electron arises unconditionally from the charged fermionic channel with zero empirical charge calibration. Inside the mother-matter core, the color-singlet fermionic doublet splits by discrete channel index $e\in\{0,1\}$ into the charged channel ($e=0$) and neutral channel ($e=1$) (which together with spin $s\in\{0,1\}$ and chirality span the eight-state zero-momentum rest basis $\mathscr R$ of §10.3):

**Proposition 9.1 (Half-unit dressed characters and the absolute integer unit electron charge, `L18, L20, L21`).** The fermionic channel charge function $q_{\mathrm{edge}}(e)$ takes the value $1$ on the charged channel $e=0$ and $0$ on the neutral channel $e=1$; on the rest preparation, the independent-dual Noether electromagnetic charge readout unconditionally yields the **unit electron charge**

$$q_e=1,\qquad
\chi_0\!\left(C_{\mathrm{dual}}(P_{s,0})\,
Q_{\mathrm{Noether}}P_{s,0}\psi_0\right)
=h_{\mathrm{src}}q_e,\qquad
h_{\mathrm{src}}>0,
\tag{9.11}$$

where $h_{\mathrm{src}}>0$ is the source-generated phase momentum (the native action unit). Writing $c_{\mathrm{src}}(b)>0$ for the source propagation speed of branch $b$, the product $h_{\mathrm{src}}c_{\mathrm{src}}(b)$ (abbreviated $h_{\mathrm{src}}c_{\mathrm{src}}$ when branch-independent) forms the sole nondimensionalizing denominator below.

**Proof.** Restricting the unbroken electromagnetic generator $\mathsf E$ in (9.7) to the rest projection $P_{s,0}\psi_0$ and dual pairing $C_{\mathrm{dual}}(P_{s,0})$ evaluates on the charged channel $e=0$ to $h_{\mathrm{src}}>0$ times $q_e=1$ in (9.11). Rescaling primal and dual representations by any common nonzero factor and dividing out preserves $q_e=1$ identically, while filtered spatial states retain the commutator correction $h_{\mathrm{src}}\langle f_L,\Delta_Qf_R\rangle$. ∎

Proposition 10.1 in Section 10.1 verifies native temporal current $-1$ alongside electromagnetic charge $+1$ on the same physical rest electron leg.

### 9.4 Complete static projection and the Coulomb seed $K_*$

Prepared currents arise from configuration-slice insertion. In the 289-coordinate ordering, matter, independent-dual, and auxiliary indices $i\ge73$ have zero direct insertion in this configuration slice, so $J_i=0$ (this zero-column property pertains specifically to the configuration-slice variation of $\mathcal F_i$; the 64-weight oriented age window of §10.3 evaluates the raw slot operator recovered through the full configuration reader plus its compensation). Contraction with the origin reconstruction matrix $F_0$ simplifies to

$$F_0^{\mathsf T}J=(e_0+e_1)w_J,\qquad
w_J=\frac{3\sqrt2}{10}(J_{21}-J_{34}).
\tag{9.12}$$

The surviving direction $g=e_{21}-e_{34}$ is precisely the difference of spatial gauge slots 21 and 34 ($A_1^{\,0}-A_2^{\,1}$)—whose activation overcomes the zero-residue obstruction of bare temporal gauge charges in Proposition 6.3 (§6.7). Its six-part configuration integral is

$$\begin{aligned}
w_J=\frac{3\sqrt2}{10}\Bigl[{}&D\mathcal F_{\mathrm{native},g}
+D\mathcal F_{\mathrm{coframe},g}
-D\mathcal F_{\mathrm{retained},g}\\
&+\int\!\left(j_{\mathrm{density},g}
+\langle a,\widehat{M_g}b\rangle_z
-\langle a,\widehat{M_{\perp,g}}b\rangle_z\right)d\mu(z)\Bigr].
\end{aligned}\tag{9.13}$$

This retains native gauge, coframe, volume-density, full matter, complementary scalar/gauge, and retained Yukawa contributions under the two-resolvent bound (9.6).

Supplement S4.2 exhibits the five-dimensional static reduction matrix $T_5$ and its two-sided inverse $G_5$. For every unit spatial direction $n$ and purely spatial four-momentum $p_\kappa=(0,i\kappa n)$, the leading 289-field Schur tensor is $-\kappa^2 T_{\mathrm{stat}}$, while contact, complement, and full-field reconstruction remain intact. Writing $\mathcal G_\kappa J$ for the full 289-field static Green response gives, as $\kappa\downarrow 0$,

$$-\kappa^2\mathcal G_\kappa J\longrightarrow
F_0G_0F_0^{\mathsf T}J,\qquad
G_0(e_0+e_1)=\sqrt{30}\left(-\frac9{125}e_0-\frac{67}{72}e_1\right).
\tag{9.14}$$

**Theorem 9.2 (Static Coulomb scalar of two complete preparations, `L18-L19`).** Fix any independent source ($S$) and detector ($D$) preparations (including their positive precisions, momenta, finite configuration frames, cutoffs, nonreal resolvent parameters, and discrete leg indices). For every real unit direction $n$, as $\kappa\downarrow 0$ within the source-generated static radius,

$$\begin{aligned}
C_{\mathrm{comp}}&=K_*w_Dw_S,\qquad
K_*=\frac{9023}{9000}\sqrt{30},\\
J_D^{\mathsf T}F_0G_0F_0^{\mathsf T}J_S&=-C_{\mathrm{comp}},\\
\kappa^2J_D^{\mathsf T}\mathcal G_\kappa J_S&\longrightarrow C_{\mathrm{comp}}.
\end{aligned}\tag{9.15}$$

**Proof.** Apply (9.12) at both ends and invert via (9.14): $9/125+67/72=9023/9000$. Bilinear transpose contraction requires no extra conjugation. The direction-uniform $O(\kappa)$ bound in Supplement S4.2 controls the pole-factor remainder, while continuous bounded contact and complement terms vanish upon multiplication by $\kappa^2$. Both $w_D,w_S$ are supplied endogenously by (9.13). ∎

Inserting the unit electron charges $q_e^D=q_e^S=1$ from Proposition 9.1 gives $q_e^Dq_e^SC_T=C_T$, with any nonzero representation scales canceling at each end. Sign conventions are fixed transparently: the Thomson static constant uses the $-\kappa^2$ residue $C_T=-C_{\mathrm{comp}}$, whereas the positive scalar $C_{\mathrm{comp}}$ in (9.15) corresponds to $+\kappa^2$; dividing once by $h_{\mathrm{src}}c_{\mathrm{src}}$ yields the respective dimensionless static ratios.

### 9.5 On-shell photon pole amplitude and the zero-transfer Thomson matching interface

Let $P_\omega$ denote the full $289$-dimensional residue at the physical-frequency pole, $\mathcal P_\omega$ its frequency-normalized polarization vector, and $\beta$ the source-generated linear left reader. For each unit spatial direction $n$ and source branch $b$, at sufficiently small scale $e>0$ on the pole sheet, the full residue factors with rank one:

$$P_\omega(e,b,n)J=\beta_{e,b,n}(J)\,
\mathcal P_\omega(e,b,n).
\tag{9.16}$$

Here the physical ray is $p=(-ie^2s_b(e,n),ie^2n)$ with physical frequency $\omega_e=e^2s_b(e,n)$ (independent of the static scale $\kappa$ and without assuming $\beta=1$). Defining the photon polarization amplitude $\mathcal A_\gamma=J^{\mathsf T}\mathcal P_\omega$ and dimensionless amplitude $\widehat{\mathcal A}_\gamma=\mathcal A_\gamma/(h_{\mathrm{src}}c_{\mathrm{src}})$ for the current (9.5) gives, at nonzero scale and nonreal resolvent parameters,

$$h_{\mathrm{src}}c_{\mathrm{src}}\widehat{\mathcal A}_\gamma
=\mathcal A_\gamma,\qquad
|\mathcal A_\gamma|\le\sum_i|\mathcal P_{\omega,i}|\,
\|\ell\|b_n(z)c_i(p,F)b_n(w)\|r\|.
\tag{9.17}$$

Together with (9.4), this packages the unit state, native $Y$ charge $-1$, raw and normalized photon amplitudes, and explicit bound into the on-shell photon input (`L22`).

**Remark 9.3 (Thomson zero-transfer matching interface in original action units, `L21, L23`).** Connection to the downstream zero-knob matching paper (Case 3) is governed by an exact raw-unit matching contract (compare the separation of heavy-threshold contact terms in Appelquist–Carazzone [16] and Henning–Lu–Murayama [3]): whenever the matching layer supplies in original action units the full on-shell response $\mathcal O=\beta_{e,b,n}(J)\,\mathcal A_\gamma=J^{\mathsf T}P_\omega J$, the light-field loop response $\mathcal L$, and the local contact response $\mathcal C$ satisfying

$$\mathcal O-\mathcal L=C_T+\mathcal C,
\tag{9.18}$$

dividing once by $h_{\mathrm{src}}c_{\mathrm{src}}>0$ reads out unambiguously

$$\frac{\mathcal O-\mathcal L-\mathcal C}
{h_{\mathrm{src}}c_{\mathrm{src}}}
=\frac{C_T}{h_{\mathrm{src}}c_{\mathrm{src}}}.
\tag{9.19}$$

Binding $\mathcal O$ explicitly to the two-sided raw-unit residue reading $\beta_{e,b,n}(J)\,\mathcal A_\gamma=J^{\mathsf T}P_\omega J$ (fixed source in Appendix B.1) guarantees that $\mathcal O,\mathcal L,\mathcal C,C_T$ share identical original action units with a single normalization $(h_{\mathrm{src}}c_{\mathrm{src}})^{-1}$, while the 17-companion Riesz light/heavy/contact separation and numerical interval tightening of $\alpha(0)$ belong to Case 3.

<a id="sec-10"></a>

## 10 Two-end readouts of the physical rest electron: once-Coulomb scalar and on-shell photon response

Half-unit dressed characters $\pm 1/2$ and the unit rest electron $|Q_e|=1$ now take their exact places within one many-body readout calculus, retaining independent oriented age windows, all 64 zero-momentum spinor-channel weights, and finite-parameter leg-amputation residuals.

### 10.1 Dual-operator verification on the same physical rest electron leg

**Proposition 10.1 (Simultaneous dual-operator verification on the physical rest electron leg, `L21, L24`).** For spin index $s\in\{0,1\}$, the rest coordinate of the charged fermionic channel ($e=0$) is $(s,1)$. Letting $u_{\mathrm{src}}^0$ denote the mother-matter unit occupied state at time zero, set

$$u_{e,s}=P_{(s,1)}u_{\mathrm{src}}^0
=\iota\bigl(u^{\mathrm{ch}}_{s,0}\bigr),
\tag{10.1}$$

where $u^{\mathrm{ch}}_{s,0}$ is the rest restriction to spin $s$ and charged channel $e=0$, and $\iota$ is its isometric natural-coordinate embedding; then on this identical external state $u_{e,s}$, the native temporal current operator and physical electromagnetic charge operator simultaneously yield

$$\langle u_{e,s},B_{\mathrm{native},0}u_{e,s}\rangle=-1,
\qquad Q_{\mathrm{EM}}u_{e,s}=u_{e,s},
\qquad a_{\mathrm{src}}h_{\mathrm{src}}=1.
\tag{10.2}$$

**Proof.** Coordinate identities of the preparation operator yield (10.1). The native temporal reader equals the Noether temporal bilinear multiplied by the action scale $a_{\mathrm{src}}$; the charged channel $e=0$ has unscaled temporal reading $-h_{\mathrm{src}}$, which $a_{\mathrm{src}}h_{\mathrm{src}}=1$ reduces to $-1$. On the same rest coordinate, $Q_{\mathrm{EM}}$ acts on the $e=0$ block with eigenvalue $+1$, without changing the leg or conflating the two operators. ∎

Under spatial filtering $F$, charge matrix elements retain both the commutator correction and the full-carrier defect:

$$h_{\mathrm{src}}\langle f_L,Q_{\mathrm{EM}}f_R\rangle
=h_{\mathrm{src}}\langle f_L,f_R\rangle
+h_{\mathrm{src}}\langle f_L,\Delta_Qf_R\rangle
-h_{\mathrm{src}}\langle f_L,D_{\mathrm{EM}}f_R\rangle,
\tag{10.3}$$

where $\Delta_Q=[Q_{\mathrm{actual}},F]$ acts on the unfiltered leg and $D_{\mathrm{EM}}$ vanishes on the source embedding while remaining nonzero on the full 504-mode carrier (compare Buchholz [29] on electromagnetic corrections accompanying localized charged states under Gauss's law).

### 10.2 Exact two-leg amputation normalization and the three finite-parameter residuals

In Lehmann–Symanzik–Zimmermann (LSZ) reduction [26], external legs are amputated by inverse propagators while non-pole remainders are dropped in the asymptotic mass-shell limit. Working at finite nonreal complex resolvent parameters $(z,w)$ and finite configuration frame $F$, we drop nothing:

**Lemma 10.2 (Finite-parameter two-leg amputation normalization and three-term residual identity, `L24`).** With $G_z$ denoting the zero-momentum full matter resolvent, $u$ and $d$ the nonzero prepared primal and independent-dual legs, and $r,\ell$ their column and dual residuals relative to the rest reference energies $(E_R,E_L)$, for any nonreal complex parameters ($\operatorname{Im}z,\operatorname{Im}w\ne 0$), two-sided inversion produces strictly nonzero amputated legs

$$u^{\mathrm{amp}}=u-G_wr=(E_R-w)G_wu,\qquad
d^{\mathrm{amp}}=d-\ell G_z=(E_L-z)dG_z.
\tag{10.4}$$

Defining $N_q=\|d^{\mathrm{amp}}\|^{-1}\|u^{\mathrm{amp}}\|^{-1}$, the amputated observation functional of every linear operator $A$ satisfies identically, with $|\mathcal U_q(A)|\le\|A\|$,

$$N_q=\|d^{\mathrm{amp}}\|^{-1}\|u^{\mathrm{amp}}\|^{-1},\qquad
\mathcal U_q(A)=N_q\bigl[d(Au)+\mathfrak c_q(A)\bigr],
\tag{10.5}$$

$$\mathfrak c_q(A)=
-\ell\!\left(G_zAu\right)-d\!\left(AG_wr\right)
+\ell\!\left(G_zAG_wr\right).
\tag{10.6}$$

**Proof.** Nonreal $z,w$ keep $E_R-w$ and $E_L-z$ nonzero, so injectivity of the resolvent and $u,d\ne 0$ ensure $u^{\mathrm{amp}},d^{\mathrm{amp}}\ne 0$. Expanding $(d-\ell G_z)A(u-G_wr)$ produces $d(Au)$ plus all three terms in (10.6); multiplying by $N_q$ yields (10.5) and $|\mathcal U_q(A)|\le\|A\|$. ∎

The third term in (10.6) is the two-end cross residual, retained alongside both single-end residuals in every electron readout below.

### 10.3 All 64 rest weights and oriented age windows

The rest spinor-channel index set $\mathscr R$ (spanned by spin $s\in\{0,1\}$, fermionic channel $e\in\{0,1\}$, and chirality) has eight zero-momentum basis states. For the expansion coefficients $c^{s,e}_a(p)$ of a moving charged preparation, define the $8\times 8=64$ endpoint weights

$$W^{s_L,e_L;s_R,e_R}_{ab}(p_L,p_R)
=\overline{c^{s_L,e_L}_a(p_L)}
c^{s_R,e_R}_b(p_R),\qquad a,b\in\mathscr R.
\tag{10.7}$$

Both prepared currents and detectors retain all $64$ weights of the zero-momentum basis expansion before inserting the actual momenta $(p_L,p_R)$ into the time-evolution and resolvent kernels.

Writing $U_p(t)$ for physical time evolution, $G_p(z)=(H_F(p)-zI)^{-1}$ for the full matter resolvent, and $C_g=M_g+C_{\mathrm{comp},g}$ for the decomposition of the configuration current restriction (9.13) into raw slot reader $M_g$ plus compensation $C_{\mathrm{comp},g}$, the three time kernels are

$$\mathscr K_{A}(t)=U_{p_L}(-t)G_{p_L}(z)\,
A\,G_{p_R}(w)U_{p_R}(t),\qquad
\mathscr K_{\mathrm{mode}}
=\mathscr K_{C_g}-\mathscr K_{C_{\mathrm{comp},g}}.
\tag{10.8}$$

For each rest pair $(a,b)\in\mathscr R^2$, the origin weight over the oriented age window $(0,T)$ (along the difference of spatial gauge slots 21 and 34, $A_1^{\,0}-A_2^{\,1}$) splits into full configuration minus compensation integrals:

$$\begin{aligned}
d_{ab}(\lambda,T)={}&
-\frac{3\sqrt2}{10}\int_0^T e^{-\lambda t}
\langle u_a(p_L),\mathscr K_{C_g}(t)u_b(p_R)\rangle\,dt\\
&+\frac{3\sqrt2}{10}\int_0^T e^{-\lambda t}
\langle u_a(p_L),\mathscr K_{C_{\mathrm{comp},g}}(t)u_b(p_R)\rangle\,dt.
\end{aligned}\tag{10.9}$$

Continuity on finite intervals ensures integrability for every real $T\in\mathbb R$ (including $T<0$) and complex $\lambda\in\mathbb C$, vanishing identically at $T=0$ and preserving the pairwise identity upon summing over all $64$ weights $W_{ab}$.

### 10.4 Equal-charge torque exchange and the once-Coulomb scalar theorem

Splitting the static coframe source into positive and negative charge-transfer channels $A_+,A_-$ across the full matter resolvents, preparation projection, equal-energy projection, and zero-velocity resonance projection yields the commutator law with remainder (proved layer by layer in Supplement S4.3):

$$[Q_{\mathrm{actual}},A_\pm]=\pm A_\pm+\mathcal X_\pm.
\tag{10.10}$$

Here $\mathcal X_\pm$ collects matter charge torques and all resolvent and projection commutators. Between source endpoints of equal fermionic channel (zero charge difference), the left-hand side vanishes in expectation, forcing $\mathcal Q(A_+)=-\mathcal Q(\mathcal X_+)$ and $\mathcal Q(A_-)=\mathcal Q(\mathcal X_-)$. Because the static coframe operator is $A_++A_-$, the source coframe weight reduces to the pure torque difference

$$W_{\mathrm{cf}}
=\mathcal Q_S(A_++A_-)
=\mathcal Q_S(\mathcal X_--\mathcal X_+),
\qquad \mathcal Q_S(A)=d_S(Au_S),
\tag{10.11}$$

summing all 64 source weights, while the detector static age readout is $D_{\mathrm{act}}=\sum_{a,b}W^D_{ab}(0,0)d_{ab}(0,T)$.

**Theorem 10.3 (Once-Coulomb scalar readout of the physical electron, `L24`).** Take independent response points $q_D,q_S$ (each with nonreal $z,w$), arbitrary branch indices for two physical electrons, real age $T$, and real spatial momentum direction $n$. Letting $V_S^{\mathrm C}$ denote the three-channel static Coulomb field driven by the source's prepared static coframe operator, the normalized once-Coulomb observation at the detector equals identically

$$\boxed{C_{\mathrm{raw}}
=N_D\left[K_*D_{\mathrm{act}}W_{\mathrm{cf}}
-\mathfrak c_D\!\left(\mathscr A_D(V_S^{\mathrm C};0,T)\right)\right],
\qquad K_*=\frac{9023}{9000}\sqrt{30}.}
\tag{10.12}$$

Here $\mathscr A_D(V;\lambda,T)=\int_0^T e^{-\lambda t}\sum_iV_i\,\mathscr K_i^D(t)\,dt$ is the full-field age kernel and $V_S^{\mathrm C}$ already incorporates the static Coulomb inverse once. The action-Euler minus sign fixes the passage from two-leg readouts to field readouts:

$$\begin{aligned}
\mathcal D_D^{\lambda,T}(V)
&=-d_D\!\left(\mathscr A_D(V;\lambda,T)u_D\right),\\
\mathcal U_D^{\mathrm{field}}(V)
&=-\mathcal U_D\!\left(\mathscr A_D(V;\lambda,T)\right)
=N_D\left[\mathcal D_D^{\lambda,T}(V)
-\mathfrak c_D\!\left(\mathscr A_D(V;\lambda,T)\right)\right].
\end{aligned}$$

Substituting (10.5) produces the minus sign in front of $\mathfrak c_D$ in (10.12) and (10.16) directly.

**Proof.** Each source pair projects at the static origin to $(e_0+e_1)\langle u_a,S_{\mathrm{cf}}u_b\rangle$, read by the three origin columns as $d_{ab}(0,T),d_{ab}(0,T),0$. Inverting and summing the two spatial stiffnesses $a_0=25\sqrt{30}/54$ and $a_1=12\sqrt{30}/335$ gives

$$a_0^{-1}+a_1^{-1}
=\sqrt{30}\left(\frac9{125}+\frac{67}{72}\right)=K_*.
\tag{10.13}$$

Summing over all 64 detector pairs and 64 source pairs factors the contraction into $K_*D_{\mathrm{act}}W_{\mathrm{cf}}$ without requiring shared windows or frames; applying the negative field-read identity, (10.6), (10.11), and (10.9) yields (10.12). ∎

Normalizing the source legs by $N_S$ via (10.5) gives the symmetric two-end expansion

$$N_SC_{\mathrm{raw}}
=N_D\left[
K_*D_{\mathrm{act}}\bigl(\mathcal U_S(\mathcal X_--\mathcal X_+)
-N_S\mathfrak c_S(\mathcal X_--\mathcal X_+)\bigr)
-N_S\mathfrak c_D(\mathscr A_D(V_S^{\mathrm C};0,T))\right],
\tag{10.14}$$

followed by a single division by $h_{\mathrm{src}}c_{\mathrm{src}}$ for the dimensionless static readout.

### 10.5 On-shell photon pole response retaining the source amplitude

Assigning independent oriented age windows $(\lambda,T)$ to the detector and $(\mu,S)$ to the source, let $J_S^{\mu,S}$ be the 64-weight source window current and $\mathcal D_D^{\lambda,T}$ the 64-weight detector linear reader. On source branch $b$, unit direction $n$, and pole-sheet scale $e$, set

$$V_\gamma(e)=P_\omega(e,b,n)J_S^{\mu,S}
=\beta_S(e)\mathcal P_\omega(e,b,n),\qquad
\beta_S(e)=\beta_{e,b,n}(J_S^{\mu,S}).
\tag{10.15}$$

**Theorem 10.4 (Full-parameter on-shell photon pole readout of the physical electron, `L25`).** For arbitrary $q_D,q_S$, four branch indices, complex $\lambda,\mu\in\mathbb C$, real $T,S\in\mathbb R$, and real unit direction $n$, whenever the detector's two Green parameters are nonreal, there exists $e_0>0$ such that every $0<e<e_0$ in the scale domain satisfies on the pole sheet of (9.16)

$$\boxed{\mathcal O_e
=\frac{N_D}{h_{\mathrm{src}}c_{\mathrm{src}}(b)}
\left[
\beta_S(e)\,
\mathcal D_D^{\lambda,T}\!\left(\mathcal P_\omega(e,b,n)\right)
-\mathfrak c_D\!\left(\mathscr A_D(V_\gamma(e);\lambda,T)\right)
\right].}
\tag{10.16}$$

**Proof.** Rank-one residue factorization (9.16) commutes with the source's 64-term sum to extract $\beta_S(e)$; applying the negative field-read functional of §10.4 to (10.5) and dividing once by $h_{\mathrm{src}}c_{\mathrm{src}}(b)$ proves (10.16) on $(0,e_0)$. ∎

Here the visible source amplitude $\beta_S(e)$ is evaluated directly on the physical electron current without dividing it out, feeding directly into the mother-action Hessian, Maxwell light cone, and real-space Coulomb integrals below.

<a id="sec-11"></a>

## 11 Mother-action second variation, clock rescaling, and the transverse Maxwell light cone

### 11.1 First-jet second variation of the nine field groups rather than an external quadratic ansatz

Write $\mathcal L_{\rm nat}$ for the restriction of the independent-dual local mother density of §9.1 to the nine-group field lift over the full real first jet

$$j=(x,x_0,x_1,x_2,x_3)\in\mathbb R^{289}\times(\mathbb R^{289})^4,
\qquad \mathcal B=D^2\mathcal L_{\rm nat}(0).
\tag{11.1}$$

Evaluating $\mathcal B$ at the zero jet in the nondegenerate coframe neighborhood, the affine signal $x+\sum_\mu(y^\mu-a^\mu)x_\mu$ at anchor $a$ carries exact value $x$ and derivatives $x_\mu$, with co-rotating perturbations $P(y)\delta\psi$ and $\delta\chi\circ P(y)$ keeping $\chi$ independent of the Hermitian adjoint of $\psi$. Letting $d,e\in\{\varnothing,0,1,2,3\}$ index the value and four derivative slots with $\sigma_\varnothing(p)=1$ and $\sigma_\mu(p)=p_\mu$, the Fourier matrix of the Fréchet Hessian is

$$K_{ij}(p)=\sum_{d,e}
\mathcal B(e_{d,i},e_{e,j})\sigma_d(-p)\sigma_e(p),
\qquad p\in\mathbb C^4.
\tag{11.2}$$

**Theorem 11.1 (Exact identity of the mother-action Hessian and the $289\times 289$ Jacobi matrix, `L26`).** Equation (11.2) equals the $289\times289$ coupled Jacobi matrix $H_{289}(p)$ of §§4–6 entry by entry across $\mathbb C^4$; its constrained Green function, local contact terms, and nine cosource constraints are generated by that identical second variation.

**Proof.** Expanding the second variation across gravity, gauge, scalar, and independent-dual Dirac sectors yields $234,406,220,790$ quadratic monomials ($1650$ in total). Polarizing each monomial $c j_{d,i}j_{e,j}$ produces two ordered terms, with $p\mapsto-p$ on the left derivative slot from integration by parts; merging the $3300$ signed contributions by row, column, and four-momentum power reproduces all $3071$ entries of $H_{289}(p)$ over $\mathbb Q(\sqrt2,\sqrt{15})$ (Supplement S5.1). ∎

Theorem 11.1 realizes covariant background-field second variation (compare DeWitt [14] and Abbott [2]) without approximation around a time-precessing spinor–coframe–gauge background with independent linear dual, anchoring both L1–L17 and the many-body electromagnetic readouts to one operator.

### 11.2 Retaining all 289 mixed outputs along the literal electromagnetic direction

Inserting $\mathrm E=-C_2-Y/2$ into the four spacetime gauge slots defines $\mathcal E:\mathbb C^4\to\mathbb C^{289}$. Because the spatial gauge background is nonzero, the commutator

$$[\bar A_\mu,\mathrm E]
=(0,-\alpha_0 C_1,\alpha_0 C_0,0)_\mu
\tag{11.3}$$

excites two color directions inside the coupled equations. Retaining the full 289-component Green output prior to electromagnetic contraction gives

$$G_{\rm E}=\mathcal E^{\mathsf T}G\mathcal E,
\qquad V_{\rm E}=R\mathcal E,
\qquad T_{\rm E}=\mathcal E^{\mathsf T}R\mathcal E.
\tag{11.4}$$

For each unit spatial direction $n$ and source branch $b\in\{0,1\}$, the five-direction characteristic construction yields a simple pole $s_b(\varepsilon,n)$:

**Proposition 11.2 (Full 289-component pole residue projector and rest-source visibility equivalence, `L26`).** At sufficiently small $\varepsilon>0$ along the physical ray

$$p_\varepsilon(s,n)=(-i\varepsilon^2s,i\varepsilon^2n),
\qquad \omega=\varepsilon^2s,
\qquad R=\lim_{s\to s_b}(s-s_b)G(p_\varepsilon(s,n)),
\tag{11.5}$$

the full 289-dimensional residue satisfies the homogeneous equations and difference-quotient projector identity

$$K(p_\varepsilon(s_b,n))R=RK(p_\varepsilon(s_b,n))=0,
\qquad R K'_s R=R,
\tag{11.6}$$

so $V_{\rm E}=R\mathcal E$ solves all 289 homogeneous rows together with the nine null-field constraints and obeys the flux normalization

$$\mathcal E^{\mathsf T}R K'_sV_{\rm E}=T_{\rm E};
\tag{11.7}$$

meanwhile, for the rest-electron action source $J$, the linear left reader $\ell_b$ and nonzero full-field polarization $v_b$ give the exact visibility equivalence

$$v_J=\ell_b(J)v_b,
\qquad v_J\ne0\iff\ell_b(J)\ne0.
\tag{11.8}$$

**Proof.** Retaining the varying nine-dimensional null-source and null-field projectors $Q_s(s),Q_f(s)$ in the two-sided Green identities, multiplying by $s-s_b$, and applying the difference quotient of $K(s)$ with $RQ_s(s_b)=0$ yields (11.6) (Supplement S5.2), from which right multiplication by $\mathcal E$ or $J$ and rank-one simple-pole factorization yield (11.7)–(11.8). ∎

### 11.3 Physical frequency and arbitrary positive clock rescalings

In the physical frequency variable $\omega=\varepsilon^2s$, the residue and Jacobi frequency derivative satisfy

$$R_\omega=\varepsilon^2R,
\qquad K'_\omega=\varepsilon^{-2}K'_s,
\qquad R_\omega K'_\omega R_\omega=R_\omega.
\tag{11.9}$$

Under any positive clock rescaling $t'=ct$ and $\omega'=\omega/c$ ($c>0$), the Green argument, pole, residue, and derivative transform together as

$$G_c(\omega')=G(p_\varepsilon(c\omega'/\varepsilon^2,n)),
\quad \omega'_b=\omega_b/c,
\quad R_c=R_\omega/c,
\quad K'_c=cK'_\omega.
\tag{11.10}$$

**Theorem 11.3 (Flux-normalization invariance under arbitrary positive clock rescalings, `L26`).** For every $c>0$, the punctured-pole residue $R_c$ and chain-rule Hessian derivative $K'_c$ preserve the projector and electromagnetic flux identities:

$$R_cK'_c=R_\omega K'_\omega,
\qquad R_cK'_cR_c=R_c,
\qquad
\mathcal E^{\mathsf T}R_cK'_cR_c\mathcal E
=\mathcal E^{\mathsf T}R_c\mathcal E.
\tag{11.11}$$

**Proof.** Since $\omega'-\omega'_b=(\omega-\omega_b)/c$, the punctured limit gives $R_c=R_\omega/c$ while the chain rule gives $K'_c=cK'_\omega$; substituting into (11.9) leaves one net factor $1/c$ on both sides, establishing (11.11). ∎

![Positive clock rescaling and residue-flux invariance of one mother action](figures/main-04-action-clock-v2-en.svg)

**Figure 4. Positive clock rescaling and residue-flux invariance of one mother action.** Fixing a source branch, unit spatial direction, and simple-pole range, a positive clock rescaling $t'=ct$ ($c>0$) transforms the pole residue $R_c=R_\omega/c$ (deep-blue hyperbola) and chain-rule Jacobi derivative $K'_c=cK'_\omega$ (gold dashed line) reciprocally, keeping their product projector $R_cK'_c=P$ (vermilion horizontal line, pivot $c=1$) strictly scale-invariant. Embedding $\mathrm E=-T^{\mathrm{color}}_2-\frac12 Y$ via $\mathcal E$ across all 289 field slots retains mixed color–gravity outputs and preserves (11.9)–(11.11) for all $c>0$.

### 11.4 Angle-average-free standard electromagnetic branch criteria and the transverse Maxwell light cone

For a dressed event $e$ incorporating full quantum polarization and background mixing, when does the 289-field constrained response exhibit the exact isotropic Coulomb–Biot–Savart static tensor and non-birefringent transverse Maxwell light cone—without angular averaging over directions and without assuming external current conservation a priori?

In the three-variable spatial momentum polynomial ring $\mathbb C[X_1,X_2,X_3]$, write $|\mathbf X|^2=X_1^2+X_2^2+X_3^2$ and let $D_{\mathrm{lead}}(e)$ be the 289-field zero-clock adjugate leading denominator polynomial. Because the electromagnetic slot embedding obeys $\mathcal E^{\mathsf T}\mathcal E=\frac34 I_4$, the endpoint pairing scale is fixed uniquely to $\eta_{\mathrm{pair}}=\frac43 h_{\mathrm{src}}>0$ (inverting the $\frac34$ Gram factor back to the phase momentum $h_{\mathrm{src}}$); let $N_{\mathrm{stat}}(e)_{\mu\nu}$ be the static Noether numerator polynomial extracted after zero-damping and spatial divisibility (including $\eta_{\mathrm{pair}}^2$). Reading the static temporal and spatial scalar coefficients $(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e))$ directly from nonzero monomial support ratios without directional sampling or spherical $S^2$ averaging, form the standard static numerator $N^{\mathrm{std}}_{\mu\nu}(c_{\mathrm{temp}},c_{\mathrm{sp}})$ (equal to $c_{\mathrm{temp}}|\mathbf X|^2$ at $(0,0)$, $0$ on mixed temporal–spatial entries, and $c_{\mathrm{sp}}(|\mathbf X|^2\delta_{ij}-X_iX_j)$ on spatial entries $(i,j)$), and define the 16-entry polynomial static remainder

$$\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}
=|\mathbf X|^4 N_{\mathrm{stat}}(e)_{\mu\nu}
-D_{\mathrm{lead}}(e)\,N^{\mathrm{std}}_{\mu\nu}\bigl(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\bigr)
\in\mathbb C[X_1,X_2,X_3].
\tag{11.12}$$

When the leading zero-clock denominator polynomial is nonzero ($D_{\mathrm{lead}}(e)\ne 0$, excluding the singular denominator disposition), at every regular real spatial momentum $\mathbf n\in\mathbb R^3\setminus\{0\}$ ($D_{\mathrm{lead}}(e)(\mathbf n)\ne 0$), the difference between the dressed static Noether tensor $T_{\mathrm{stat}}(e,\mathbf n)$ and the standard Coulomb–Biot–Savart tensor $T^{\mathrm{std}}(c_{\mathrm{temp}},c_{\mathrm{sp}})(\mathbf n)=N^{\mathrm{std}}(\mathbf n)/|\mathbf n|^4$ equals $\mathcal R_{\mathrm{stat}}(e)(\mathbf n)/[D_{\mathrm{lead}}(e)(\mathbf n)|\mathbf n|^4]$, establishing the angle-average-free equivalence

$$\begin{aligned}
\bigl(D_{\mathrm{lead}}(e)\ne 0\bigr)\qquad
\mathcal R_{\mathrm{stat}}(e)=0
\Longleftrightarrow{}&\forall\,\mathbf n\in\mathbb R^3\setminus\{0\}\ \Bigl(D_{\mathrm{lead}}(e)(\mathbf n)\ne 0\\
&\implies T_{\mathrm{stat}}(e,\mathbf n)=T^{\mathrm{std}}\bigl(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\bigr)(\mathbf n)\Bigr).
\end{aligned}
\tag{11.13}$$

Refusing spherical averaging carries sharp physical falsifiability: a quadrupolar anisotropy contamination such as $X_1^2-X_2^2$ integrates identically to zero over $S^2$ and would be hidden by angular averaging, whereas in (11.12)–(11.13) it forces $\mathcal R_{\mathrm{stat}}(e)\ne 0$ and exposes the tensor discrepancy along an explicit real ray (such as $\mathbf n_\star=(1,0,0)$). Alongside the $(0,0)$ temporal entry, the complete static current-scattering coefficient retains both endpoint charge-calibration remainders, the remaining 15 spatiotemporal/spatial electromagnetic entries, and all three non-pure response contributions.

Turning to dynamic frequency response, write $T_{\mathrm{EM}}^{\mathrm{corr}}(e,\varepsilon,s,\sigma,\mathbf n)=\mathcal E^{\mathsf T}G_{\mathrm{corr}}(e,\varepsilon,s,\sigma,\mathbf n)\mathcal E$ for the $4\times 4$ electromagnetic contraction of the positively damped ($\sigma>0$) 289-field corrected constrained Green operator. When $c_{\mathrm{temp}}(e)\ne 0$ and $c_{\mathrm{sp}}(e)\ne 0$, the same static coefficients endogenously define the effective electric and magnetic constitutive stiffnesses

$$\varepsilon_{\mathrm{eff}}(e)=-\frac{3\,\eta_{\mathrm{pair}}^2}{4\,c_{\mathrm{temp}}(e)},
\qquad
\mu_{\mathrm{eff}}(e)^{-1}=\frac{3\,\eta_{\mathrm{pair}}^2}{4\,c_{\mathrm{sp}}(e)},
\qquad
\frac{\mu_{\mathrm{eff}}(e)^{-1}}{\varepsilon_{\mathrm{eff}}(e)}
=-\frac{c_{\mathrm{temp}}(e)}{c_{\mathrm{sp}}(e)}.
\tag{11.14}$$

For scale $\varepsilon\in\mathbb R\setminus\{0\}$ and physical spatial momentum $\mathbf k_\varepsilon=\varepsilon^2\mathbf n\ne 0$, form in frequency indeterminate $\omega_X=\varepsilon^2 X$ the $4\times 4$ polynomial Maxwell matrix $M_{\mathrm{Max}}(e,\varepsilon,\mathbf n)(X)$ (entry $\varepsilon_{\mathrm{eff}}|\mathbf k_\varepsilon|^2$ at $(0,0)$, $\varepsilon_{\mathrm{eff}}\omega_X k_{\varepsilon,j}$ on mixed entries, and $(\varepsilon_{\mathrm{eff}}\omega_X^2-\mu_{\mathrm{eff}}^{-1}|\mathbf k_\varepsilon|^2)\delta_{ij}+\mu_{\mathrm{eff}}^{-1}k_{\varepsilon,i}k_{\varepsilon,j}$ on spatial blocks) together with the conserved-current output projector $P_{\mathrm{curr}}(\varepsilon,\mathbf n)(X)$, acting on all 289 zero-clock adjugate columns $V_{289}(e,\varepsilon,\mathbf n)(X)$ to define the 16-entry dynamic polynomial remainder $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)\in M_4(\mathbb C[X])$.

**Theorem 11.4 (Angle-average-free standard-branch equivalence, dynamic Maxwell scattering law, and the transverse Maxwell light cone, `L26` standard extension).** For a dressed event $e$, the following three statements hold:

1. **Whole-sphere standard static equivalence and constructive real obstruction**: Whenever the leading zero-clock denominator satisfies $D_{\mathrm{lead}}(e)\ne 0$, the equivalence (11.13) holds; if $\mathcal R_{\mathrm{stat}}(e)\ne 0$, there constructively exists an explicit regular real momentum $\mathbf n_\star\in\mathbb R^3\setminus\{0\}$ ($D_{\mathrm{lead}}(e)(\mathbf n_\star)\ne 0$) at which $T_{\mathrm{stat}}(e,\mathbf n_\star)\ne T^{\mathrm{std}}(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e))(\mathbf n_\star)$ (Table 2, row 5). Conversely, when $\mathcal R_{\mathrm{stat}}(e)=0$ on a whole-sphere regular chart $\eta$, the temporal symbol equals $c_{\mathrm{temp}}(e)/|\mathbf k|^2$ across all $\mathbf k\in\mathbb R^3\setminus\{0\}$, returning on every Schwartz wavepacket $\phi$ the single-$4\pi$ Coulomb kernel $C_{\mathrm{EM}}^{\mathrm{gen}}(e)/|\mathbf x-\mathbf y|$ with $C_{\mathrm{EM}}^{\mathrm{gen}}(e)=c_{\mathrm{temp}}(e)/(4\pi)$.
2. **Ward-projected dynamic Maxwell response and four-part scattering split**: Under electromagnetic-column clock finiteness and $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)=0$ at $\varepsilon\ne 0$ and $\mathbf k_\varepsilon=\varepsilon^2\mathbf n\ne 0$, at every regular real frequency parameter $s\in\mathbb R$ ($D_0(e,\varepsilon,\mathbf n)(s)\ne 0$), the positive-damping limit ($\sigma\downarrow 0$) of the full 16-entry electromagnetic tensor $T_{\mathrm{EM}}(e,\varepsilon,s,\mathbf n)$ obeys identically

   $$|\mathbf k_\varepsilon|^2\,M_{\mathrm{Max}}(e,\varepsilon,\mathbf n)(s)\,T_{\mathrm{EM}}(e,\varepsilon,s,\mathbf n)
   =\frac34\,P_{\mathrm{curr}}(\varepsilon,\mathbf n)(s),
   \tag{11.15}$$

   and for arbitrary (not necessarily conserved) external Noether currents $j_D,j_S\in\mathbb C^4$, writing $j^{\mathrm{proj}}=|\mathbf k_\varepsilon|^{-2}P_{\mathrm{curr}}(s)j$ and $j^{\mathrm{Ward}}=j-j^{\mathrm{proj}}$, the full scattering readout splits identically into four terms:

   $$j_D^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S
   =(j_D^{\mathrm{proj}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{proj}}
   +(j_D^{\mathrm{Ward}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{proj}}
   +(j_D^{\mathrm{proj}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{Ward}}
   +(j_D^{\mathrm{Ward}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{Ward}},
   \tag{11.16}$$

   where $\widetilde T_{\mathrm{EM}}=\eta_{\mathrm{pair}}^2 T_{\mathrm{EM}}^{\mathrm{corr}}$, never substituting projected currents for actual external charged states.
3. **Locking of the transverse Maxwell dispersion cone and homogeneous field laws**: Under $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)=0$ and $\mathbf k_\varepsilon\ne 0$, for every real visible pole $a$ ($\operatorname{Im}a=0$, $\omega_{\mathrm{phys}}=\varepsilon^2\operatorname{Re}a$) and visible channel $c$, the electromagnetic four-potential $\mathcal A=(\mathcal A_0,\vec{\mathcal A}):=\mathcal E^{\mathsf T}v_{a,c}$ of the full 289-component pole mode $v_{a,c}$ satisfies $M_{\mathrm{Max}}(a)\mathcal A=0$, and its induced electric field $\vec{\mathcal E}=i(\omega_{\mathrm{phys}}\vec{\mathcal A}-\mathcal A_0\mathbf k_\varepsilon)$ and magnetic field $\mathbf B=i\mathbf k_\varepsilon\times\vec{\mathcal A}$ satisfy the homogeneous Faraday law $\mathbf k_\varepsilon\times\vec{\mathcal E}-\omega_{\mathrm{phys}}\mathbf B=0$ and magnetic Gauss law $\mathbf k_\varepsilon\cdot\mathbf B=0$ (with $\mathbf B\ne 0$ implying $\Pi_\perp(\mathbf k_\varepsilon)\mathcal A\ne 0$). Whenever $\Pi_\perp(\mathbf k_\varepsilon)(\mathcal E^{\mathsf T}v_{a,c})\ne 0$, $c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\ne 0$, and $-c_{\mathrm{temp}}(e)/c_{\mathrm{sp}}(e)$ is strictly positive real, setting $c_{\mathrm{phys}}(e)=\sqrt{-c_{\mathrm{temp}}(e)/c_{\mathrm{sp}}(e)}>0$ locks the transverse mode onto the single non-birefringent **Maxwell light cone**:

   $$\boxed{\varepsilon_{\mathrm{eff}}(e)\,\omega_{\mathrm{phys}}^2
   -\mu_{\mathrm{eff}}(e)^{-1}|\mathbf k_\varepsilon|^2=0,
   \qquad
   v_{\mathrm{phase}}^2(\varepsilon,\operatorname{Re}a,\mathbf n)
   :=\frac{\omega_{\mathrm{phys}}^2}{|\mathbf k_\varepsilon|^2}
   =-\frac{c_{\mathrm{temp}}(e)}{c_{\mathrm{sp}}(e)}
   =c_{\mathrm{phys}}(e)^2.}
   \tag{11.17}$$

Supplement S5.7 proves Theorem 11.4 in full. Across arbitrary inputs $(e,\varepsilon,\mathbf n)$, an endogenous classifier partitions the physical return without prior assumptions into 11 mutually exclusive and exhaustive dispositions (zero scale, zero momentum, unmet angular regularity, exceptional singular direction, nonstandard static disposition, vanishing electric stiffness, vanishing magnetic stiffness, nonreal constitutive ratio, nonpositive constitutive ratio, nonzero dynamic feedback remainder, and the standard branch realizing both the Maxwell cone (11.17) and single-$4\pi$ Coulomb convolution). Moreover, even prior to imposing $\mathcal R_{\mathrm{dyn}}=0$, all-multiplicity Schur residue-flux balance, four-channel (pure gauge, coframe–matter, retained Yukawa, and compensation) full-root coupling balance, and the exact phase-speed feedback shift $v_{\mathrm{phase}}^2-v_{\mathrm{nat}}^2$ in Supplement (S5.21) hold at every visible real root—reducing identically to the tree-level Hodge speed squared $v_{\mathrm{nat}}^2=N^{-2}=125/54$ of Proposition 6.3 when quantum polarization and background feedback vanish. Viewed against pre-metric constitutive electrodynamics [24]—where generic linear constitutive media obey the quartic Tamm–Rubilar birefringent wave surface $\mathcal G^{\mu\nu\rho\sigma}k_\mu k_\nu k_\rho k_\sigma=0$—and generalized Ward–Takahashi identities [22, 23, 36], Theorem 11.4 shows how the 16-entry polynomial gates collapse the high-degree adjugate dispersion of the 289-field spin–torsion–polarization medium onto a single quadratic Maxwell light cone (Figure 7, left column), with $c_{\mathrm{phys}}(e)$ emerging purely from the dressed electric-to-magnetic stiffness ratio.

<a id="sec-12"></a>

## 12 Full-field constrained Green operator and three-dimensional single-$4\pi$ Coulomb return

### 12.1 All-direction static Schur estimates generate an infrared integrable window

Retaining the origin reconstruction matrix $F_0$ of (9.12) and the static inverse $G_0$ of (9.14), define the full 289-dimensional static limit tensor

$$S_0=-F_0G_0F_0^{\mathsf T}.
\tag{12.1}$$

Schur elimination, local contact terms, and field/source recovery maps establish a sphere-uniform operator-norm limit: for every $\eta>0$, there exists $r_\eta>0$ such that every unit spatial direction $n$ and every $0<r<r_\eta$ in the static regular domain satisfy

$$\|r^2G(0,irn)-S_0\|\leq\eta.
\tag{12.2}$$

Supplement S5.3 proves this uniformity from the five-dimensional static inverse error and continuity of the recovery maps. Taking $\eta=1$ generates an endogenous infrared radius $\rho>0$ inside the static regular domain and operator-norm budget $B_0=1+\|S_0\|$. For scale parameter $a>0$, define the windowed kernel

$$\mathcal W_a(k)=
\begin{cases}
a^2G(0,iak),&0<a|k|<\rho,\\
0,&\text{otherwise}.
\end{cases}
\qquad
\|\mathcal W_a(k)\|\leq\frac{B_0}{|k|^2}.
\tag{12.3}$$

Setting the single origin point to zero leaves the three-dimensional Lebesgue integral unchanged; as $a\downarrow 0$, the interior retains the full $289\times 289$ constrained Green matrix without scalar truncation.

For any Schwartz wavepacket test $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$, using the Fourier momentum dictionary $k=2\pi\xi$, write

$$f_\phi(x)=\int e^{2\pi i\xi\cdot x}\phi(\xi)\,d\xi,
\qquad
\mathcal P_a[\phi](x)=\int e^{2\pi i\xi\cdot x}\phi(\xi)
\mathcal W_a(2\pi\xi)\,d\xi.
\tag{12.4}$$

**Theorem 12.1 (Full 289-field matrix Bochner–Fourier and single-$4\pi$ Coulomb–Newton return, `L27`).** Equation (12.4) is a convergent finite-dimensional matrix-valued Bochner integral, and for every $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$ and $x\in\mathbb R^3$,

$$\lim_{a\downarrow0}\mathcal P_a[\phi](x)
=\mathcal N_\phi(x)S_0,
\qquad
\mathcal N_\phi(x)=\int\frac{f_\phi(x-y)}{4\pi|y|}\,dy.
\tag{12.5}$$

**Proof.** In three momentum dimensions, $|\xi|^{-2}$ is locally integrable at the origin (the radial volume factor $r^2dr$ cancels the singularity) while Schwartz decay controls infinity, so $B_0|\phi(\xi)|/|2\pi\xi|^2$ provides a common $L^1$ dominating function for the entire matrix family. For every $\xi\ne0$, (12.2) gives pointwise convergence $\mathcal W_a(2\pi\xi)\to S_0/|2\pi\xi|^2$, and dominated convergence yields the Bochner limit. Supplement S5.4 applies the common positive Gaussian regulator $e^{-t(|k|^2+d^2)}$ on both sides and sends $d\downarrow 0$ under established $L^1$ bounds to derive the unique factor $1/(4\pi|y|)$. ∎

This separation echoes Donoghue's distinction [30] in gravitational effective field theory between nonanalytic $|\mathbf q|^{-2}$ long-range terms and polynomial contact terms, except that here it closes directly via a perturbation-free Bochner dominated limit on the full 289-dimensional constrained matrix without soft-photon infrared resummation [28]. Momentum dilation $\phi_a(\xi)=\phi(\xi/a)$ simultaneously gives the exact three-dimensional homogeneity law

$$\mathcal P_a[\phi](x)=a^{-1}\mathcal P_1[\phi_a](x/a),
\tag{12.6}$$

combining the Green prefactor $a^2$ and three-dimensional Jacobian $a^{-3}$ into degree $-1$ without introducing any external Coulomb length scale.

### 12.2 Real-space return of the two-unit physical electron readout across independent windows

Applying the physical electron source current and detector linear reader of §10 to the matrix packet (12.4) with a single detector normalization $hc_b=h_{\mathrm{src}}c_{\mathrm{src}}(b)$ immediately yields the real-space electron corollary:

**Corollary 12.2 (Real-space return of the two-unit physical electron readout across independent windows, `L27`).** For arbitrary independent response points $(q_D,q_S)$, external-leg indices, and oriented age windows $(\lambda,T)$ and $(\mu,S)$, the real-space electron packet retaining all 64 rest weights, compensations, and two-end leg-amputation residuals satisfies

$$\lim_{a\downarrow0}\mathcal P_a^{\rm el}[\phi](x)
=\mathcal N_\phi(x)\,
\frac{K_*w_D^{\rm el}(q_D;\lambda,T)
w_S^{\rm el}(q_S;\mu,S)}{h c_b},
\qquad K_*=\frac{9023}{9000}\sqrt{30}.
\tag{12.7}$$

**Proof.** Bounded linearity of the two-end electron functional on $M_{289}(\mathbb C)$ commutes with the Bochner integral (12.4) to consume (12.5); substituting $G_0$ produces $K_*w_D^{\rm el}w_S^{\rm el}/(hc_b)$. ∎

### 12.3 Opposite-momentum real-space return for connected currents of two-particle ($N=2$) created states

Consider a two-particle creation event in the CAR Fock space,

$$e=(\epsilon_e,p_e,F_e,n_e,z_e),
\qquad \epsilon_e>0,\quad \operatorname{Im}z_e\ne0.
\tag{12.8}$$

Its unit $N=2$ state $u_e$ is generated by applying charged CAR creation to the source profile and dividing by its strictly positive norm, alongside the unit $N=1$ background state $b_e$ (Supplement S5.5 proves the positive norm lower bound); their native $Y$-charges are $-2$ and $-1$, giving connected increment $-1$.

Letting $R_e(p)=(C_{F_e}(p)+Y_{n_e}-z_e)^{-1}$ denote the finite-frame full-Yukawa resolvent inverse, $\mathcal A_{F_e}$ the frame test reconstruction, and $\mathcal J_i(p;v,w)$ the mother-action first-order bilinear source along field direction $i$, the full 289-component connected current is

$$\begin{aligned}
J_e(k)_i={}&\mathcal J_i\bigl(p_e;
\mathcal A_{F_e}R_e(p_e-k)^\dagger u_e,
\mathcal A_{F_e}R_e(p_e)u_e\bigr)\\
&-\mathcal J_i\bigl(p_e;
\mathcal A_{F_e}R_e(p_e-k)^\dagger b_e,
\mathcal A_{F_e}R_e(p_e)b_e\bigr).
\end{aligned}
\tag{12.9}$$

Because $\operatorname{Im}z_e\ne 0$ makes the resolvent inverse continuous in momentum transfer $k$, evaluating detector and source at opposite transfers $J_D(-ak)$ and $J_S(ak)$ makes $L(k,M)=J_D(-k)^{\mathsf T}M J_S(k)$ jointly continuous, generating together with (12.2) a positive radius $\rho_{DS}>0$ and uniform bound

$$B_{DS}=1+|L(0,S_0)|,
\qquad
|L(rn,r^2G(0,irn))|\leq B_{DS}\quad(0<r<\rho_{DS},\ |n|=1).
\tag{12.10}$$

Setting $m_a(k)=L(ak,\mathcal W_a(k))$ inside $\min(\rho,\rho_{DS})$ and zero outside establishes the moving two-end return:

**Theorem 12.3 (Real-space Coulomb–Newton observation of moving connected endpoints, `L27`).** For any two independent creation events $(e_D,e_S)$ and every $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$, $x\in\mathbb R^3$,

$$\mathcal P_a^{\rm conn}[\phi](x)
=\int e^{2\pi i\xi\cdot x}\phi(\xi)m_a(2\pi\xi)\,d\xi
\longrightarrow
-\mathcal N_\phi(x)
(F_0^{\mathsf T}J_D(0))^{\mathsf T}G_0(F_0^{\mathsf T}J_S(0)).
\tag{12.11}$$

**Proof.** Joint continuity and sphere-uniform convergence (12.2) send $L(rn,r^2G)\to L(0,S_0)$ uniformly over $|n|=1$, giving $|m_a(k)|\leq B_{DS}/|k|^2$ and pointwise limit $L(0,S_0)/|k|^2$ for $k\ne 0$; Schwartz domination as in Theorem 12.1 and $S_0=-F_0G_0F_0^{\mathsf T}$ yield (12.11). ∎

Equation (12.9) already incorporates the connected normalization without an extra $hc_b$ divisor. Retaining the unsubtracted joint-charge current $J_e^{\rm joint}=J_e+\Xi_e$ (where $\Xi_e$ collects scalar-input and background-charge returns, Supplement S5.5 (S5.13)) expands identically on any field matrix $M$ into four terms:

$$\begin{aligned}
(J_D^{\rm joint})^{\mathsf T}MJ_S^{\rm joint}
={}&J_D^{\mathsf T}MJ_S
+J_D^{\mathsf T}M\Xi_S
+\Xi_D^{\mathsf T}MJ_S
+\Xi_D^{\mathsf T}M\Xi_S,
\end{aligned}
\tag{12.12}$$

preserving both cross returns and the return–return term at $M=S_0$ without assuming the propagated state is a charge eigenstate.

![Opposite-transfer N=2 connected currents and 3D single-4pi Coulomb return](figures/main-05-newton-return-v2-en.svg)

**Figure 5. Opposite-transfer $N=2$ connected currents and three-dimensional single-$4\pi$ Coulomb return.** Detector and source two-particle ($N=2$) connected currents take opposite momentum transfers $J_D(-a\mathbf k)$ and $J_S(+a\mathbf k)$ with independent creation events, nonreal energies, and oriented age windows. In the geometric panel, the punctured momentum ball $0<a|\mathbf k|<\min(\rho,\rho_{DS})$ supplies the $L^1$ domination $|m_a(\mathbf k)|\le B_{DS}/|\mathbf k|^2$ (left), which converges under three-dimensional Bochner–Fourier inversion $\mathcal F^{-1}$ as $a\downarrow 0$ to the single-$4\pi$ real-space Coulomb kernel $1/(4\pi|\mathbf y|)$ convolved with the Schwartz wavepacket $f_\phi(\mathbf x-\mathbf y)$ (right; Theorem 12.3, (12.11)–(12.12)).

### 12.4 Three-fermion ($N=3$) physical energy-pole packet, full-field Maxwell continuity, and $|Q_e|^2=1$ unit-charge cancellation

Joining the whole-sphere standard electromagnetic branch of §11.4 to three-fermion ($N=3$) composite energy-pole sections (compare Haag [34] on composite bound-particle poles and asymptotic scattering in local field theory) completes the parameter-free normalization closure of the real-space Coulomb kernel at the composite fermion pole level.

For a dressed event $e$, composite leg $\ell$, and energy-pole section $\varpi$, the pole current $J_{\mathrm{pole}}(e,\ell,\varpi)\in\mathbb C^{289}$, its four-dimensional electromagnetic contraction, and its second-order contact derivative reproduce slot by slot all 289 mother-action Noether field forms, all 16 electromagnetic readouts, and the finite Riesz contact operator (obeying the explicit bound $\|J_{\mathrm{pole},i}\|\le 2P_{\mathrm{pole},i}$). At every scale $\varepsilon$, frequency parameter $s$, positive damping $\sigma>0$ (nonzero corrected determinant), and four-momentum ray $p=p_\varepsilon(s,\mathbf n)$, writing $X_{\mathrm{corr}}$ for the full 289-component forced corrected field and $Q_{\mathrm{freq}}$ for the frequency quantum polarization matrix, the pole source satisfies **the full-field inhomogeneous Maxwell equation with induced quantum current and exact total current continuity** (compare Buchholz [29] on composite charged states obeying local Gauss–Maxwell laws):

$$\operatorname{div}_p\!\bigl(\mathcal H_p(X_{\mathrm{corr}})\bigr)
=J_{\mathrm{ext},p}(J_{\mathrm{pole}})+J_{\mathrm{ind},p}(Q_{\mathrm{freq}},X_{\mathrm{corr}}),
\qquad
\operatorname{cont}_p\!\bigl(J_{\mathrm{ext},p}(J_{\mathrm{pole}})+J_{\mathrm{ind},p}(Q_{\mathrm{freq}},X_{\mathrm{corr}})\bigr)=0.
\tag{12.13}$$

Simultaneously, the temporal (charge) component of the pole Noether current decomposes in the history limit $m\to\infty$ into the electron sign $s_e(\ell)\in\{\pm 1\}$, pole and calibration corrections, and background subtraction,

$$J_{\mathrm{Noether}}^{\mathrm{pole}}(e,\ell,\varpi)_0
=s_e(\ell)
+\bigl\langle u_{\mathrm{pole}},\,\delta u_{\mathrm{pole}}+\delta u_{\mathrm{cal}}\bigr\rangle
-\bigl\langle b_{\mathrm{Noether}},\,\mathcal R_{\mathrm{EM}}(b_{\mathrm{Noether}})\bigr\rangle,
\tag{12.14}$$

locked to the raw electromagnetic pole charge $\mathcal Q_{\mathrm{pole}}(e,\ell,\varpi)$ via $(J_{\mathrm{EM}}(J_{\mathrm{pole}}))_0=h_{\mathrm{src}}\mathcal Q_{\mathrm{pole}}(e,\ell,\varpi)$. Write $Q_{DS}^{\mathrm{pole}}=\mathcal Q_{\mathrm{pole}}(e_D,\ell_D,\varpi_D)\mathcal Q_{\mathrm{pole}}(e_S,\ell_S,\varpi_S)$ for the product of independent detector and source pole charges, and retain the wavepacket inverse Fourier kernel $f_\phi=\mathcal F^{-1}\phi$ of (12.4).

**Theorem 12.4 (Three-fermion $N=3$ energy-pole single-$4\pi$ Coulomb packet and $|Q_e|^2=1$ unit-charge cancellation, `L27` pole extension).** Suppose the field-dressing event $e_F$ carries a whole-sphere regular chart $\eta$ satisfying the standard static gates $D_{\mathrm{lead}}(e_F)\ne 0$ and $\mathcal R_{\mathrm{stat}}(e_F)=0$ of Section 11.4. For arbitrary independent detector/source events $(e_D,e_S)$, composite legs $(\ell_D,\ell_S)$, $N=3$ energy-pole sections $(\varpi_D,\varpi_S)$, Schwartz wavepacket $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$, and spatial point $\mathbf x\in\mathbb R^3$:

1. **Positive-scale convergence to the single-$4\pi$ Coulomb convolution**: As $\lambda\downarrow 0$, the temporal-sector Fourier packet converges to the spatial integral $\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)$ given by

   $$\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)
   =\int_{\mathbb R^3}\frac{Q_{DS}^{\mathrm{pole}}\,C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{|\mathbf y|}\,f_\phi(\mathbf x-\mathbf y)\,d^3y,
   \qquad
   C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)=\frac{c_{\mathrm{temp}}(e_F)}{4\pi}.
   \tag{12.15}$$

2. **Automatic cancellation of $|Q_e|^2=1$ and the zero-knob pole coupling quotient**: Whenever the emergent light speed $c_{\mathrm{phys}}(e_F)>0$, the nondimensionalizing denominator $h_{\mathrm{src}}c_{\mathrm{phys}}(e_F)>0$ is invertible, and because the source-generated electron Noether unit charge of Proposition 9.1 satisfies $q_{e,\mathrm{Noether}}(0)=q_e=1$ and hence $1^2=1$, the pole coupling expression simplifies identically and normalizes the real-space Coulomb readout:

   $$\boxed{\begin{aligned}
   \alpha_{\mathrm{pole}}(e_F)
   &:=\frac{q_{e,\mathrm{Noether}}(0)^2\,C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)}
   =\frac{C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)},\\
   \frac{\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)}
   &=\int_{\mathbb R^3}\frac{Q_{DS}^{\mathrm{pole}}\,\alpha_{\mathrm{pole}}(e_F)}{|\mathbf y|}\,f_\phi(\mathbf x-\mathbf y)\,d^3y.
   \end{aligned}}
   \tag{12.16}$$

Supplement S5.7 proves Theorem 12.4 in full (paired with a transitive dependency-closure audit verifying all 289 slot identifications, 16 electromagnetic contractions, Riesz contact identities, and zero imported empirical coupling constants; see Appendix B.1). Equation (12.16) exhibits the structural sharpness of a zero-knob unified field: the $1/(4\pi r)$ kernel, emergent transverse speed of light $c_{\mathrm{phys}}(e_F)$, unit electron charge $q_e=1$, and pole coupling quotient $\alpha_{\mathrm{pole}}(e_F)$ meet in a single identity.

<a id="sec-13"></a>

## 13 Bottom-sector Born overlaps and exact four-end Coulomb dressing of three-fermion composite states

### 13.1 Four-grade full $N=3$ responses generate normalized unit states

We next examine multi-grade Yukawa dressing on three-fermion ($N=3$) composite sources in the full 504-mode CAR Fock space. Set $q_\ell=f_{d_\ell}\,q_{d_\ell}^{(3)}$, where $d_\ell\in\{0,1\}$ labels the two independent charge branches and $f_d$ is a smooth compactly supported profile generated by the source with $f_d(z_*)=1$. Antisymmetrized triple CAR creation products give $\|q_d^{(3)}\|^2=2$ (Supplement S5.6 (S5.14)), placing the input in the bottom sector $(3,0)$ of particle number $3$ and raising grade $0$.

Each external leg $\ell=(d_\ell,F_\ell,\sharp_\ell,\zeta_\ell)$ carries its own nonreal complex energy $\zeta_\ell$. Setting $R_{0,F}(\zeta)=(C_F-\zeta)^{-1}$ and $T_F(\zeta)=-R_{0,F}(\zeta)Y$, because $Y$ preserves particle number $N=3$ while incrementing the auxiliary grade $j$ by $1$ and sector $(3,4)$ is empty, the fourth raising product vanishes identically ($T_F^4b_\ell=0$):

$$b_\ell=R_{0,F_\ell}(\zeta_\ell)q_\ell,
\qquad
r_\ell=
\begin{cases}
\sum_{j=0}^{3}T_{F_\ell}(\zeta_\ell)^j b_\ell,&\sharp_\ell=0,\\
b_\ell,&\sharp_\ell=1.
\end{cases}
\tag{13.1}$$

Here $\sharp_\ell=0$ retains all four orthogonal grades $(3,0)\oplus(3,1)\oplus(3,2)\oplus(3,3)$ of the full Yukawa coupling, whereas $\sharp_\ell=1$ denotes the independent grade-preserving reference branch restricted to $(3,0)$. Returning to the uncut Hamiltonian retains the finite-frame compression defect $d_{F_\ell}=H_0-C_{F_\ell}$:

$$\begin{aligned}
(H_0+Y-\zeta_\ell)r_\ell&=q_\ell+d_{F_\ell}r_\ell &&(\sharp_\ell=0),\\
(H_0+Y^\sharp-\zeta_\ell)r_\ell&=q_\ell+d_{F_\ell}r_\ell &&(\sharp_\ell=1).
\end{aligned}
\tag{13.2}$$

Two-sided invertibility ensures $r_\ell\ne0$, and orthogonality of the four sectors $(3,j)$ yields the normalized unit state

$$u_\ell=\frac{r_\ell}{\|r_\ell\|},
\qquad \|u_\ell\|=1,
\qquad P_{3,0}r_\ell=b_\ell,
\qquad \|r_\ell\|^2=\sum_{j=0}^{3}\|T_{F_\ell}^jb_\ell\|^2
\quad(\sharp_\ell=0).
\tag{13.3}$$

### 13.2 Cutoff-free bottom-sector Born overlap amplitudes $z_\ell\in(0,1]$

From the orthogonal decomposition (13.3), define each leg's bottom-sector overlap amplitude $z_\ell$ and Born probability weight $\mathfrak b_\ell$:

$$z_\ell=\frac{\|b_\ell\|}{\|r_\ell\|},
\qquad \mathfrak b_\ell=z_\ell^2=\|P_{3,0}u_\ell\|^2,
\qquad 0<z_\ell\leq1.
\tag{13.4}$$

This orthogonal decomposition carries a transparent composite-particle interpretation: the bottom sector $(3,0)$ is the antisymmetrized **three-fermion valence core**, whereas the higher sectors $(3,1)$, $(3,2)$, and $(3,3)$ represent first-, second-, and third-order scalar–spinor Yukawa dressing clouds whose fourth excitation $(3,4)$ vanishes identically by finite exterior Pauli exclusion ($T_{F_\ell}^4b_\ell=0$). Comparing (13.4) with Källén–Lehmann spectral positivity [25, 33] ($0\le Z\le 1$) and Weinberg's composite-particle bare-core overlap criterion [35] highlights a key contrast: whereas bare-to-dressed overlaps in perturbative field theory typically require infinite ultraviolet counterterms, finite-grade Pauli nilpotency and the configuration half-density Hilbert norm make $z_\ell$ a strictly positive finite number in $(0,1]$ with **zero UV cutoff**, and $\mathfrak b_\ell=\|P_{3,0}u_\ell\|^2$ is literally the Born probability of finding the normalized composite state $u_\ell$ in its $(3,0)$ valence core (with $z_\ell=\mathfrak b_\ell=1$ when $\sharp_\ell=1$).

Furthermore, on the full-Yukawa branch ($\sharp_\ell=0$), dividing numerator and denominator in (13.3)–(13.4) by $\|b_\ell\|>0$ yields the cutoff-free norm-ratio formula

$$z_\ell=\left(1+\sum_{j=1}^{3}\frac{\|T_{F_\ell}(\zeta_\ell)^j b_\ell\|^2}{\|b_\ell\|^2}\right)^{-1/2},
\qquad
\mathfrak b_\ell=\frac{\|b_\ell\|^2}{\|b_\ell\|^2+\sum_{j=1}^{3}\|T_{F_\ell}(\zeta_\ell)^j b_\ell\|^2}
\quad(\sharp_\ell=0).
\tag{13.4a}$$

Crucially, the higher-grade dressing cloud in (13.4a) is genuinely nonzero rather than vacuous in the unified source: for the $(3,0)$ three-fermion valence-core candidate $q_d^{(3)}$ ($\|q_d^{(3)}\|^2=2$, Supplement S5.6 (S5.14)), pairing the quantized joint-vacuum Yukawa operator $\widehat Y(v)$ against the unit-norm $(3,1)$ CAR witness triple $w_{\mathrm{Yuk},d}=|(0,0,0),(0,1,0),\mathrm{out}_A\rangle_d$ isolates a single nonzero exterior matrix element with exact rational squared modulus

$$\bigl|\langle w_{\mathrm{Yuk},d},\,\widehat Y(v)\,q_d^{(3)}\rangle\bigr|^2
=\left(\frac{2}{3}\right)^2 N^2\,|\eta_{\mathrm{Yuk}}|^2
=\frac{4}{9}\cdot\frac{54}{125}
=\frac{24}{125}>0
\qquad(d\in\{0,1\}),
\tag{13.4b}$$

Here $N=\sqrt{54/125}$ is the temporal coframe lapse of (1.1), and $\eta_{\mathrm{Yuk}}\in\{\pm 1\}$ is the disjoint-support permutation sign. The normalization $f_d(z_*)=1$ gives a nonzero bounded normalized-$Y$ read of the actual input. Fix a finite frame and a nonreal causal line $\zeta=\omega+i\eta$, $\eta\ne 0$. The scaled base resolvent satisfies $\zeta R_{0,F}(\zeta)\to-I$ in operator norm as $\omega\to+\infty$, so the normalized-$Y$ read of the base response is nonzero at all sufficiently large $\omega$. The full-source equation would force this read to vanish if the full response equalled its bottom projection. Orthogonality in (13.4a) therefore gives $0<z_\ell<1$ throughout that frequency range, for either causal orientation and every fixed positive damping. This is the actual composite-leg theorem `composite_bottom_overlap_eventually_lt_one`.

**Four-grade norm benchmark (pen-and-paper check).** To see by direct hand arithmetic how fourth-step Pauli truncation converts orthogonal cloud norms into Coulomb dressing without ultraviolet counterterms (matching the right bar chart of Figure 6), take on a finite frame $F_\ell$ ($\sharp_\ell=0$, $T_{F_\ell}^4b_\ell=0$) a $(3,0)$ valence-core response of squared norm $\|b_\ell\|^2=4$ and first-, second-, and third-order dressing clouds of squared norms $(\|T_{F_\ell}b_\ell\|^2,\|T_{F_\ell}^2b_\ell\|^2,\|T_{F_\ell}^3b_\ell\|^2)=(3,\frac32,\frac12)$ (summing to $5$), paired with a grade-preserving reference leg ($\sharp=1$, $r_{\mathrm{ref}}=b_{\mathrm{ref}}$, $z_{\mathrm{ref}}=1$). If both the detector pair $(dL,dR)$ and source pair $(sL,sR)$ carry one such dressed leg and one reference leg, substituting into (13.4a) and (13.7)–(13.8) gives in one line:

$$\|r_\ell\|^2=4+3+\frac{3}{2}+\frac{1}{2}=9
\implies
z_\ell=\frac{2}{3},\quad
\mathfrak b_\ell=\frac{4}{9},\quad
Z=\left(\frac{2}{3}\cdot 1\right)^2=\frac{4}{9},\quad
|C_{\mathrm{full}}-C_{\mathrm{base}}|=\frac{5}{9}\,|C_{\mathrm{base}}|.
\tag{13.4c}$$

Here $\frac49$ of the unit-state Born probability remains in the $(3,0)$ valence core while $\frac59$ resides in the three-grade scalar–spinor cloud, rescaling the real-space Coulomb coefficient to $C_{\mathrm{full}}=\frac49 C_{\mathrm{base}}$ with zero UV divergences or ad hoc counterterms.

Because pure-gauge first-variation vertices preserve grade ($P_{3,0}\Gamma_{\mu a}=\Gamma_{\mu a}P_{3,0}$), whenever at least one leg in a pair $(L,R)$ lies on the grade-preserving reference branch ($\sharp_L=1$ or $\sharp_R=1$), the full gauge numerator projects cleanly onto $(3,0)$. Writing $\mathcal V_{\mu a}(p;v,w)$ for the pure-gauge sesquilinear form along the difference of spatial gauge slots 21 and 34 ($A_1^{\,0}-A_2^{\,1}$), define

$$\begin{aligned}
w_{LR}^{\rm base}(p)&=\frac{3\sqrt2}{10}
\bigl[-\mathcal V_{10}(p;b_L,b_R)+\mathcal V_{21}(p;b_L,b_R)\bigr],\\
\widehat w_{LR}^{\rm base}(p)&=
\frac{w_{LR}^{\rm base}(p)}{\|b_L\|\|b_R\|}.
\end{aligned}
\tag{13.5}$$

Consequently, the normalized full-response static weight obeys the multiplicative law

$$w_{LR}^{\rm actual}(p)
=z_Lz_R\widehat w_{LR}^{\rm base}(p),
\qquad \sharp_L=1\ \text{or}\ \sharp_R=1.
\tag{13.6}$$

The condition $\sharp_L=1$ or $\sharp_R=1$ is essential: if $\sharp_L=\sharp_R=0$, diagonal matrix elements in higher grades $(3,j)$ ($j\ge 1$) also enter the full numerator.

### 13.3 Exact four-end Born Coulomb dressing and modulus-defect identity

Requiring at least one grade-preserving reference leg in both the detector pair $(dL,dR)$ and source pair $(sL,sR)$, set

$$Z=z_{dL}z_{dR}z_{sL}z_{sR},
\qquad 0<Z\leq1,
\qquad
C_{\rm base}=\frac{K_*\widehat w_{dL,dR}^{\rm base}(p_D)
\widehat w_{sL,sR}^{\rm base}(p_S)}{hc_b}.
\tag{13.7}$$

**Theorem 13.1 (Source-generated four-end Born overlap Coulomb dressing, `L28`).** Under the reference-leg condition in each pair, the full four-grade $N=3$ Coulomb coefficient $C_{\rm full}$ and bottom-sector reference coefficient $C_{\rm base}$ satisfy

$$\boxed{C_{\rm full}=ZC_{\rm base},
\qquad |C_{\rm full}-C_{\rm base}|=(1-Z)|C_{\rm base}|,}
\tag{13.8}$$

and the full $N=3$ current returns through the single $hc_b$ detector normalization and 289-field matrix Bochner integral (12.4) the real-space Coulomb convolution

$$\lim_{a\downarrow0}\mathcal P_a^{(3)}[\phi](x)
=\mathcal N_\phi(x)\,ZC_{\rm base}.
\tag{13.9}$$

**Proof.** Grade preservation of pure-gauge vertices projects each pair's numerator onto $(3,0)$ while unit normalization retains the full four-grade norms $\|r_\ell\|$, giving (13.6). Multiplying detector and source pairs and contracting with $G_0$ (Supplement S5.6 (S5.18)) yields $C_{\rm full}=ZC_{\rm base}$; $0<Z\le 1$ gives $|Z-1|=1-Z$, and commuting the bounded matrix functional with Theorem 12.1 yields (13.9). ∎

The four overlaps come from their own four-grade response norms. Fix the other three legs and take the full left detector leg sufficiently far up a fixed causal line. Then `composite_coulomb_overlap_eventually_lt_one` gives $Z<1$. Under the two reference-leg conditions, the defect in (13.8) is strictly positive if $C_{\rm base}\ne0$.

![Four-grade Pauli truncation, valence-core Born overlaps, and four-end Coulomb dressing](figures/main-06-born-dressing-v2-en.svg)

**Figure 6. Four-grade Pauli truncation, valence-core Born overlaps, and four-end Coulomb dressing.** Top row: the four independent composite legs $(dL,dR)$ and $(sL,sR)$. Middle panel: on the left, the Yukawa raising operator $T_F=-R_{0,F}Y$ populates the orthogonal four-grade ladder $(3,0)\to(3,1)\to(3,2)\to(3,3)$ before truncating identically at the empty sector $(3,4)=\varnothing$ ($T_F^4b_\ell=0$); on the right, orthogonal norm shares compare a full-Yukawa leg ($\sharp_\ell=0$, Section 13.2 benchmark $\mathfrak b_\ell=4/9,\ z_\ell=2/3$) with a grade-preserving reference leg ($\sharp_\ell=1$, $z_{\mathrm{ref}}=1$). Their product $Z=z_{dL}z_{dR}z_{sL}z_{sR}$ governs Theorem 13.1 and equations (13.8)–(13.9).

<a id="sec-14"></a>

## 14 Three-channel far-field balance, five-axis literature synthesis, and series interfaces

### 14.1 Three-channel static current decomposition and two-step far-field balance (`L29`)

Having established the static Coulomb residue, the transverse Maxwell light cone, and the real-space $1/(4\pi r)$ convolution, one structural question remains: **when quantum polarization feedback and the nine gauge–Lorentz constraint null lifts are retained simultaneously inside the full static current circuit, are they subleading short-range corrections, or do they contribute at the identical $O(\kappa^{-2})$ Coulomb order as native Green propagation in the far field?**

Fix a dressed event $e$, real unit spatial direction $\mathbf n$ ($|\mathbf n|^2=1$), static regular scale $\kappa\in\mathcal D_{\mathrm{stat}}$, positive damping $\sigma>0$ (with $\det_{\mathrm{corr}}(e,\sqrt\kappa,0,\sigma,\mathbf n)\ne 0$), and independent detector/source momenta $(p_D,p_S)$ and composite legs $(d_L,d_R,s_L,s_R)$. Writing $J_{\mathrm{comp}}(p_D;d_L,d_R)$ and $J_{\mathrm{comp}}(p_S;s_L,s_R)$ for the full composite currents, the corrected static probe reading $\mathcal R_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)$ decomposes identically into **native Green propagation, quantum polarization feedback, and nine-constraint null-lift** channels:

$$\mathcal R_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)
=\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)
+\mathcal R_{\mathrm{fb}}(\kappa,\sigma,\mathbf n)
+\mathcal R_{\mathrm{null}}(\kappa,\sigma,\mathbf n),
\tag{14.1}$$

where $\mathcal R_{\mathrm{nat}}$ contracts the native 289-field static Green operator directly, $\mathcal R_{\mathrm{fb}}$ routes the frequency quantum polarization matrix $Q_{\mathrm{freq}}$ and full corrected response through the native Green operator, and $\mathcal R_{\mathrm{null}}$ reads the nine null coordinates through $L_{\mathrm{null}}$.

Prior to any directional restriction, the native channel inherits an all-direction static domination bound: there exist a direction-independent radius $r_{\mathrm{nat}}>0$ and explicit budget $P_{\mathrm{nat}}=\|\mathcal M_{DS}\|\cdot B_{\mathrm{whole}}$ such that

$$\forall\,\kappa\in\mathcal D_{\mathrm{stat}}\ (\kappa<r_{\mathrm{nat}}),\ \forall\,|\mathbf n|=1:\quad
\kappa^2\bigl|\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)\bigr|\le P_{\mathrm{nat}},
\qquad
\lim_{\kappa\downarrow 0}\bigl(-\kappa^2\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)\bigr)=C_{\mathrm{nat}},
\tag{14.2}$$

where $C_{\mathrm{nat}}=J_{\mathrm{comp},D}^{\mathsf T}S_{\mathrm{res}}J_{\mathrm{comp},S}$ is direction-independent (and at every nonzero static scale $\kappa\in\mathcal D_{\mathrm{stat}}$, the composite currents vanish identically on all nine symmetry-constraint cokernel projections). Meanwhile, an endogenous classifier partitions every unit spatial direction without external scalar inputs into four mutually exclusive and exhaustive static regimes: singular leading determinant, clock principal pole, higher spatial pole, and **finite long-range return**—characterized by a nonzero infrared clock determinant $D_{\mathrm{IR}}(e,\mathbf n)\ne 0$, static spatial-numerator clock-order divisibility (distinct from the dynamic frequency-ray EM-column clock finiteness of §11.4), and origin spatial pole order at most $4$ across all 16 zero-clock electromagnetic fractions and 1 static probe fraction (17 rational fractions in total).

**Theorem 14.1 (Three-channel static current decomposition and two-step ordered far-field balance, `L29`).** In the static current circuit (14.1), whenever a unit direction $\mathbf n$ ($|\mathbf n|=1$) lies in the source-determined finite long-range return regime, write $\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)=\mathcal R_{\mathrm{probe}}^{(0)}(\sqrt\kappa,\mathbf n)-\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)$ for the zero-damping combined feedback-plus-null reading. Then:

1. **Existence, uniform boundedness, and equal order of the two-step ordered far-field limit**: For sufficiently small positive $\kappa$, sending positive damping $\sigma\downarrow 0$ first converges the sum of feedback and nine-constraint null channels to $\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)$; subsequently sending $\kappa\downarrow 0$, $-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)$ obeys the infrared domination bound $|-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)|\le 1+|C_{\mathrm{ord}}(e,\mathbf n)-C_{\mathrm{nat}}|$ inside an endogenous radius and converges to a finite $O(\kappa^{-2})$ coefficient $C_{\mathrm{fb+null}}(e,\mathbf n)$:

   $$\lim_{\sigma\downarrow 0}\bigl[\mathcal R_{\mathrm{fb}}(\kappa,\sigma,\mathbf n)+\mathcal R_{\mathrm{null}}(\kappa,\sigma,\mathbf n)\bigr]
   =\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n),
   \qquad
   \lim_{\kappa\downarrow 0}\bigl[-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)\bigr]
   =C_{\mathrm{fb+null}}(e,\mathbf n).
   \tag{14.3}$$

2. **Far-field $O(\kappa^{-2})$ equal-order conservation law**: The full ordered probe far-field coefficient $C_{\mathrm{ord}}(e,\mathbf n)$ equals the exact sum of the native and feedback-plus-null coefficients:

   $$\boxed{C_{\mathrm{ord}}(e,\mathbf n)
   =C_{\mathrm{nat}}+C_{\mathrm{fb+null}}(e,\mathbf n).}
   \tag{14.4}$$

Theorem 14.1 and Supplement S5.7 retain the complete coefficient of the $\kappa^{-2}$ term. If $C_{\mathrm{fb+null}}(e,\mathbf n)\ne0$, convergence in (14.3) eventually bounds the modulus of the scaled correction below by half the modulus of that coefficient. The correction is then of exact order $\kappa^{-2}$. A zero coefficient gives $o(\kappa^{-2})$. In the ordered limit, damping vanishes at fixed nonzero $\kappa$ to select the zero-clock response, which is then read at long spatial range.

![Standard Maxwell cone, N=3 unit-charge cancellation, and three-channel far-field balance](figures/main-07-maxwell-farfield-v2-en.svg)

**Figure 7. Standard Maxwell light cone, $N=3$ unit-charge cancellation, and three-channel far-field balance.** Top banner: the single 289-field mother-action Hessian $K(p)$, electromagnetic generator $\mathrm E=-T^{\mathrm{color}}_2-\frac12 Y$, and unit electron charge $|Q_e|=1$. Left column (§11.4, §12.4): under $D_{\mathrm{lead}}(e)\ne 0$, the 16-entry polynomial gates $\mathcal R_{\mathrm{stat}}=0$ and $\mathcal R_{\mathrm{dyn}}=0$ shift real transverse poles from the tree reference cone $v_{\mathrm{nat}}$ onto the single quadratic Maxwell light cone $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$ without angular averaging (constructing an explicit real obstruction ray $\mathbf n_\star$ on $S^2$ whenever $\mathcal R_{\mathrm{stat}}\ne 0$), while $q_{e,\mathrm{Noether}}(0)^2=1^2=1$ cancels the charge unit in the $N=3$ pole packet to return the single-$4\pi$ Coulomb kernel. Right column (§14.1, `L29`): the general static circuit splits into native, quantum-feedback, and nine-constraint null channels, achieving $O(\kappa^{-2})$ balance $C_{\mathrm{ord}}=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}$ along the ordered L-shaped limit path ($\sigma\downarrow 0$ followed by $\kappa\downarrow 0$) in the $(\kappa,\sigma)$ plane.

### 14.2 Theorem-by-theorem synthesis across five foundational physics traditions

Deriving low-energy electrodynamics from the zero-knob mother action [1] places our theorems in sharp, verifiable dialogue with 36 primary works across five foundational traditions in theoretical and mathematical physics (documented item by item in `literature-v2.md`):

1. **Unified gauge groups, running intersection tests, unit charge emergence, and torsion contact terms ([1, 7–12])**. Simple-group grand unification (Georgi–Glashow $\mathrm{SU}(5)$ [7]) selects reducible chiral multiplets $\bar{\mathbf 5}\oplus\mathbf{10}$ and multi-scale Higgs potentials by hand, Georgi–Quinn–Weinberg [8] infer a desert unification scale from single-point intersection of one-loop inverse-coupling lines, and semisimple Pati–Salam unification [9] obtains integer lepton charges from a fourth color group. Within the single $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ mother action [1], the exterior inventory $\Lambda^6\oplus\Lambda^2\oplus\Lambda^4$ plus complex $\Lambda^4$ scalar at $\sigma=1/2$ obeys the **exact non-intersection theorem** (Proposition 2.1: $I_3=I_2=1\ne I_1=1/2$ at $\ell=0$), algebraically refuting naive desert single-point intersection and necessitating finite heavy-threshold matching; the unbroken generator $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ yields relative dressed characters $\pm 1/2$ alongside the exact unit electron charge $|Q_e|=1$ on the charged channel ($e=0$) without hypercharge tuning (Propositions 9.1 and 10.1); and within first-order frame–connection gravity (Kibble [10], Sciama [11], Hehl et al. [12]), eliminating the 24 real Lorentz connections yields the parameter-free ECSK axial four-fermion contact $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ in (6.6) (Theorem 6.1), combining with the 79-dimensional dynamical inverse into an exact 42-digit rational on-shell tree amplitude (Proposition 6.2).
2. **Degenerate constraint elimination, covariant background-field Hessians, and parameter-free effective actions ([2, 3, 13–16])**. Dirac's constrained Hamiltonian formalism [13], DeWitt's curved-background second variation [14], and Abbott's background-field method [2] organize gauge–gravity fluctuations, while Weinberg's phenomenological Lagrangians [15], Appelquist–Carazzone decoupling [16], and the Henning–Lu–Murayama covariant derivative expansion [3] integrate out heavy fields at the cost of fitted higher-derivative low-energy constants (LECs) and $1/k^2$ nonlocal projectors. Around a time-precessing nine-field background, Theorem 11.1 proves exact entrywise equality between the 1650-term real first-jet Fréchet Hessian and the 3071-term matrix $H_{289}(p)$, Proposition 4.1 reduces $289\to 103=79\oplus 24$ via momentum-denominator-free polynomial sections reconstructing all 289 rows, and Proposition 5.1 computes the fourth-order rational soft-phase dispersion coefficients and exact fifth/sixth-order polynomial remainders with zero fitted LECs.
3. **Unbounded Dirac groups, nonautonomous global unitarity, full-word CAR states, and operator-norm Kubo derivatives ([4–6, 17–21])**. Stone's theorem [17] and Dirac operator theory [18] govern constant-coefficient generators, Dyson series [19] and Kato's hyperbolic evolution theorem [5] treat time-dependent perturbations under constant-domain and $C^1$ hypotheses, Kubo linear response [6] and KMS perturbation theory [21] assume initial equilibrium $[\rho,H]=0$ with first-order truncation, and Fock second quantization [4] and quasifree CAR algebras [20] formulate many-fermion kinematics. Proposition 7.1, Theorems 7.2–8.2, and Corollary 8.3 characterize $\mathcal D(\mathsf H)$ in both directions on a non-Abelian spin–torsion background, glue global unitary propagators $W_\epsilon(t,a)$ across all real times and amplitudes via bounded radial Picard maps without uniform all-time bounds or $C^1$ regularity, establish orthonormalization-free full-word CAR positivity and single-flip $S$ mother-pairing readback (Propositions 3.4 and 7.3), and prove the operator-norm Kubo derivative at $\epsilon=0$ on arbitrary nonstationary spatial preparations via the uniform unit-ball bound $\epsilon^2M^2|t|^2$.
4. **Generalized Ward–Slavnov–Taylor identities, pre-metric constitutive electrodynamics, and the emergent Maxwell cone ([22–24, 36])**. Extending flat-space Abelian Ward–Takahashi identities [22, 23], ghost-dependent non-Abelian Slavnov–Taylor identities [36], and pre-metric constitutive electrodynamics [24] (where generic linear constitutive media exhibit quartic Tamm–Rubilar birefringence), Theorem 6.1 unifies non-Abelian gauge and local Lorentz invariance without ghosts into 18 exact background-curved identities, Proposition 11.2 and Theorem 11.3 preserve normalized residue-flux projectors under every positive clock rescaling $t'=ct$, and Theorem 11.4 characterizes standard electromagnetic branches under $D_{\mathrm{lead}}\ne 0$ via 16-entry polynomial remainders without angular averaging, retains all four Ward scattering terms for unconserved external currents in (11.16), and collapses the 289-field dispersion onto a single non-birefringent quadratic Maxwell light cone $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$.
5. **Real-space $1/(4\pi r)$ kernels, cutoff-free valence-core Born dressing $Z$, dressed charged states, and three-channel far-field balance ([25–35])**. Realizing the structural insights of Dirac's gauge-invariant dressed electron [27], Kulish–Faddeev asymptotic states [28], Buchholz's Gauss-law infraparticle analysis [29], Källén–Lehmann positivity [25, 33], LSZ reduction [26], Haag's composite-particle formalism [34], Weinberg's weak-binding compositeness criterion [35], and Donoghue's long-range Fourier separation [30] without UV/IR divergences: while bare 12-component temporal gauge charges carry identically zero Coulomb residue (Proposition 6.3), preparations activating the difference of spatial gauge slots 21 and 34 ($A_1^{\,0}-A_2^{\,1}$), moving $N=2$ connected currents, and full-field Maxwell-conserving $N=3$ composite pole packets return the single-$4\pi$ Coulomb kernel $1/(4\pi|\mathbf x-\mathbf y|)$ via sphere-uniform Schur bounds and 3D matrix Bochner integrals with automatic $|Q_e|^2=1$ cancellation (Theorem 12.1, Corollary 12.2, Theorems 12.3–12.4); finite-energy leg amputation retains all three residuals $\mathfrak c_q$ in (10.6) (Lemma 10.2); four-grade Pauli nilpotency makes $z_\ell=\|b_\ell\|/\|r_\ell\|\in(0,1]$ a UV-cutoff-free $(3,0)$ valence-core Born amplitude yielding $C_{\mathrm{full}}=ZC_{\mathrm{base}}$ (Theorem 13.1); and Theorem 14.1 proves $O(\kappa^{-2})$ balance among native, quantum-feedback, and nine-null channels, formally verified in the Lean 4 kernel [32].

**Table 4. Five-axis comparison between classical physics benchmarks and the exact advances of Case 1 v2 (`L1-L29`).**

| Disciplinary axis & primary works | Classical premises or methodological limits | Exact advance & retained conditions in Case 1 v2 (`L1-L29`) |
|---|---|---|
| **I. Unified groups, running & torsion** [1, 7–12] | Hand-picked multiplets & multi-Higgs potentials; desert single-point crossing; free ECSK gravitational/torsion constants | Fixed exterior inventory strictly forbids single-point crossing (Prop. 2.1); $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ yields both dressed $\pm 1/2$ and rest-electron $\lvert Q_e\rvert=1$ (Props. 9.1, 10.1); parameter-free $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ & 42-digit rational on-shell exchange (Thm. 6.1, Prop. 6.2) |
| **II. Constrained reduction & EFT** [2, 3, 13–16] | Nonlocal $1/k^2$ transverse projectors; fitted fourth-order low-energy constants (LECs) | Denominator-free polynomial section $289\to 103=79\oplus 24$ reconstructing all 289 rows (Prop. 4.1); 1650-term 1-jet Hessian equals $H_{289}(p)$ (Thm. 11.1); zero-LEC fourth-order rational dispersion & exact 5th/6th-order remainders (Prop. 5.1) |
| **III. Nonautonomous Dirac & Kubo** [4–6, 17–21] | Constant domain & $C^1$ hypotheses in Kato's theorem; initial equilibrium $[\rho,H]=0$ & formal first-order truncation in Kubo | Two-way characterization of $\mathcal D(\mathsf H)$ (Thm. 7.2); global all-time/all-amplitude unitary propagator via radial Picard gluing without global bounds or $C^1$ (Thm. 8.1); full-word CAR positivity (Props. 3.4, 7.3); uniform $\epsilon^2M^2\lvert t\rvert^2$ Kubo derivative on arbitrary preparations (Thm. 8.2, Cor. 8.3) |
| **IV. Gauge–Lorentz laws & light cone** [22–24, 36] | Flat Abelian or ghost-dependent non-Abelian Ward identities; quartic birefringent cones in generic linear media | Ghost-free 18 curved gauge–Lorentz identities (Thm. 6.1); clock-invariant flux projectors under $t'=ct$ (Prop. 11.2, Thm. 11.3); under $D_{\mathrm{lead}}\ne 0$, angle-average-free 16-entry polynomial gates, four-part unconserved-current split & non-birefringent **Maxwell light cone** $v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2$ (Thm. 11.4) |
| **V. Real-space Coulomb, core $Z$ & far field** [25–35] | UV renormalization for $Z$, asymptotic dropping of off-pole LSZ remainders, IR soft-photon resummation | Sphere-uniform Schur bounds & 3D matrix Bochner integrals yield $1/(4\pi\lvert\mathbf x-\mathbf y\rvert)$ with full-field continuity and $\lvert Q_e\rvert^2=1$ cancellation on $N=3$ poles (Thm. 12.1, Cor. 12.2, Thms. 12.3–12.4); finite-energy 3-term amputation $\mathfrak c_q$ (Lem. 10.2); UV-finite four-grade valence-core Born dressing $C_{\mathrm{full}}=ZC_{\mathrm{base}}$ (Thm. 13.1); two-step ($\sigma\downarrow 0$, $\kappa\downarrow 0$) $O(\kappa^{-2})$ 3-channel balance (Thm. 14.1) |

### 14.3 Exact interfaces to downstream CourtyCourt cases (Cases 2–6)

The objects and identities closed here provide non-circular, type-exact inputs to the downstream phenomenological papers of the CourtyCourt series:

- **Cutoff-free ordered closed traces and whole-ball polarization curvature (Case 2 [31])**: Consumes the $L^2(\mathbb R^3,\mathbb C^{12})$ spatial dynamics and full-word CAR readouts of §§7–8 together with the mother-action Hessian identification $H_{289}$ of §11.1 to lock the $(2-,1+)$ inertia indices of whole-ball wavepacket polarization curvature and nonlinear constant-field Noether–Sylvester responses without UV cutoffs.
- **Zero-knob effective matching, heavy decoupling, and the endogenous Thomson formula for $\alpha(0)$ (Case 3)**: Consumes the raw-unit Thomson matching bridge of Remark 9.3 (`L21-L23`), unit electron charge $|Q_e|=1$ (Proposition 9.1), emergent speed of light $c_{\mathrm{phys}}$ (Theorem 11.4), and pole coupling quotient (Theorem 12.4) to execute two-scale four-operator parameter-free left-inverse matching at $\mu_0=1+4\pi^2$, 108-channel $O(h^3)/O(h)$ heavy-minus-light threshold decoupling, and the rescaling-invariant closed operator quotient $\alpha_{\mathrm{src}}(0)$.
- **Twelve-charge superselection, noncommutative flavor commutant, and composite baryon positivity (Case 4) plus constrained operator Euler equations and retarded backreaction (Cases 5A–5B)**: Consumes all 158 matter vertices and 216-dimensional free external-leg spectra of §6 together with the $N=3$ composite currents and three-channel feedback structure of §§12–14 to establish 12 conserved charge superselection sectors, the 14-dimensional flavor commutant $\mathbb C^{10}\oplus M_2(\mathbb C)$, pre-state-selection 350-direction differential CAR operator Euler equations, and moving-frame retarded positive-energy inequalities, culminating in composite bound spectra and rigorous proton-lifetime intervals in Case 6.

### 14.4 Closing synthesis

The four-dimensional invariant-window current that opened this paper testified three times—as the expectation value of finite nonlinear evolution, as a two-leg state-variation derivative, and as an oriented Heisenberg commutator integral. Across fourteen sections, the same zero-knob mother action has delivered far more than a current identity: it has endogenously locked the absolute integer unit charge $|Q_e|=1$ of the physical rest electron, erected the transverse Maxwell light cone $v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2$ via angle-average-free polynomial gates, recovered the single-$4\pi$ real-space Coulomb kernel $1/(4\pi|\mathbf x-\mathbf y|)$ through three-dimensional matrix Bochner–Fourier integration, derived cutoff-free four-grade Born composite dressing $C_{\mathrm{full}}=ZC_{\mathrm{base}}$, and preserved $O(\kappa^{-2})$ far-field balance across native propagation, quantum polarization feedback, and the nine gauge–Lorentz constraint null lifts. Every dimensional reduction, leg normalization, and clock rescaling retains its exact inverse path back to the unified action.

<a id="app-a"></a>

## Appendix A. Original inventory, bare quadratic structure, and stabilizer

### A.1 One-loop algebra for the specified inventory

The original single-copy Weyl inventory is $\Lambda^6\oplus\Lambda^2\oplus\Lambda^4$, together with one complex $\Lambda^4$ scalar. Substitution into the specified one-loop algebraic formula gives, in the order $\mathrm{SU}(7),\mathrm{SU}(3),\mathrm{SU}(2),\mathrm U(1)$,

$$b_0=\left(\frac{56}{3},4,\frac13,-28\right).\tag{A.1}$$

The three original constitutive parameters are all $1/2$. Restricting the mother SU(7) trace to the hypercharge direction gives twice the native pairing. In the specified affine coordinate $\ell$, the three inverse-coupling readings are

$$I_3=1+4\ell,\qquad I_2=1+\frac\ell3,\qquad I_1=\frac12-7\ell.
\tag{A.2}$$

They are simultaneously positive on $-1/4<\ell<1/14$. The equality $I_3=I_2$ forces $\ell=0$, where $I_1=1/2\ne1$, so they have no common intersection. Here $\ell$ is the affine running coordinate of the inventory, distinct from physical time $t$ in the main text. Equation (A.1) is the substitution of the specified inventory into an existing formula; the physical coefficients of the complete original quantum loops are to be determined using the inputs of §9.3.

![Affine readings for the specified inventory](figures/fig1-fixed-inventory-running-en.svg)

**Figure A1. Three affine readings for the specified inventory.** The horizontal axis is the inventory running coordinate $\ln(\mu/\mu^*)$, distinct from original time. With $\ell=\ln(\mu/\mu^*)/(8\pi^2)$, the three lines are (A.2), using native $\sigma=1/2$ with no thresholds, experimental fit, or GeV calibration. The vermilion vertical segment marks the gap at $\ell=0$: $I_3=I_2=1$, while $I_1=1/2$.

### A.2 Complete Yukawa coordinates of the joint vacuum

For the vacuum in (2.3), the oriented exterior product gives every matrix element of the wedge map $Y:\Lambda^2\mathbb C^7\to\Lambda^6\mathbb C^7$. If $I$ is a six-index set and $J$ a two-index set,

$$Y_{I,J}=\sum_{K\in\{0126,0124,0156,0145\}}
\mathbf1_{J\cap K=\varnothing}\mathbf1_{J\cup K=I}
\operatorname{sgn}(J,K),\tag{A.3}$$

where the sign is that of the permutation arranging the sequence $J$ followed by $K$ into an increasing six-index sequence. In the original output-basis order,

$$YY^\dagger=\operatorname{diag}(2,2,2,4,2,0,0),\qquad
\operatorname{rank}Y=5,\qquad\dim\ker Y=16.\tag{A.4}$$

Equation (A.3) specifies the complete $7\times21$ matrix without printing 147 coordinates as a dense array. The original right-handed Yukawa map remains the ordered $Y_R$; the singular-value reading from $YY^\dagger$ does not replace it by $Y_R+Y_R^\dagger$.

![Yukawa singular values of the joint vacuum](figures/fig3-joint-yukawa-spectrum-en.svg)

**Figure A2. Nonzero singular values and kernel of the joint vacuum.** The left column gives the eigenvalues of $YY^\dagger$ (squared singular values), and the right column their multiplicities. The vermilion zero eigenvalue, of multiplicity 2, gives $\operatorname{rank}Y=5$. The Gram matrix comes from the complete $7\times21$ wedge map. These bare singular values have a different identity from the original frequency spectrum of §6.

### A.3 The bare gauge Gram matrix and complete stabilizer

Acting on $v$ with the original gauge directions and taking the Gram matrix in the original real scalar pairing gives the bare quadratic block of the gauge-block embedding (2.1). It has rank 9 and spectrum

$$0\ [3],\qquad1\ [6],\qquad
\text{the three roots of }6x^3-26x^2+27x-8=0.\tag{A.5}$$

The scalar stabilizer in the complete mother group is

$$\operatorname{Stab}_{\mathrm{SU}(7)}(v)
\simeq\frac{\mathrm{SU}(2)\times\mathrm{USp}(4)\times\mathrm U(1)}{\mathbb Z_2},
\tag{A.6}$$

Its intersection with the Standard Model gauge subgroup of (2.1) is the specified color SU(2). This group isomorphism follows directly from the four-term vacuum. Write

$$v=e_{01}\wedge\Omega_v,\qquad
\Omega_v=(e_2-e_5)\wedge e_4+(e_2+e_5)\wedge e_6,$$

and define $W_v(x)=x\wedge v$. Taking the exterior products term by term gives

$$W_v^\dagger W_v=\operatorname{diag}(0,0,2,4,2,2,2).$$

If $g\in\mathrm{SU}(7)$ preserves $v$, then $W_vg=(\Lambda^5g)W_v$. Unitarity of the exterior-power action forces $g$ to preserve the three eigenspaces of this Gram matrix: $A=\operatorname{span}(e_0,e_1)$, $B=\operatorname{span}(e_2,e_4,e_5,e_6)$, and $C=\operatorname{span}(e_3)$. This excludes both mixing between blocks and additional discrete branches. With $u_\pm=(e_2\pm e_5)/\sqrt2$, we have $\Omega_v=\sqrt2(u_-\wedge e_4+u_+\wedge e_6)$. Its stabilizer in $U(B)$ is $\mathrm{USp}(4)$, and $\Omega_v\wedge\Omega_v\ne0$ forces its determinant to be 1.

A block-diagonal element preserves $v$ precisely when $\det(g_A)\Lambda^2g_B(\Omega_v)=\Omega_v$. Choose $z\in U(1)$ such that $z^2=\det(g_A)^{-1}$, set $A_0=zg_A$ and $S_B=z^{-1}g_B$, and use the unit determinant of the mother-group element to obtain $g_C=z^{-2}$. Thus, in block order $A\oplus B\oplus C$, the surjection

$$(A_0,S_B,z)\longmapsto\operatorname{diag}(z^{-1}A_0,zS_B,z^{-2})$$

covers the complete stabilizer. Its kernel consists exactly of $(I_2,I_4,1)$ and $(-I_2,-I_4,-1)$, giving the $\mathbb Z_2$ in (A.6).

Within the gauge subgroup of (2.1), preservation of $A,B,C$ forces the color block to be $(A_c,c)$, the weak block to be $\operatorname{diag}(w,w^{-1})$, and the hypercharge block to be $\operatorname{diag}(h,h^{-1})$, with $\det A_c=c^{-1}$. The four terms $e_{0126},e_{0124},e_{0156},e_{0145}$ acquire the phases $h^{-1},w^{-1},c^{-1},c^{-1}w^{-1}h$, respectively. The terms are linearly independent and all have coefficient 1, forcing $h=w=c=1$. Exactly the specified color $\mathrm{SU}(2)$ embedding remains. This is the complete group-level analytic proof for the bare scalar. The finite Gram check and fixed source are given in row L2 of Appendix B. ∎

![Bare scalar–gauge quadratic spectrum of the embedding (2.1)](figures/fig2-bare-scalar-gauge-spectrum-v2-en.svg)

**Figure A3. The bare scalar–gauge quadratic block of the gauge-block embedding (2.1).** The left column gives the eigenvalues of $R=B^{-1}K$, with $B$ the native real scalar pairing; the right column gives multiplicities. Of the 12 directions, 3 are zero (vermilion) and 9 are positive. The three nonrational eigenvalues are the roots of the cubic in (A.5), shown as decimals from rational isolating intervals. The kernel corresponds to the stabilizer tangent space; complete coupled propagation is treated separately in §4.

<a id="app-b"></a>
## Appendix B. Fixed evidence, claim locations, and proof-supplement guide

### B.1 Versions, supplement guide, and evidence identities

L1–L17 retain source commit S; L18–L22, L23–L25, and L26–L28 retain e055, c62, and 71e respectively, while the second-edition (v2) additions—L29 together with the standard long-range Maxwell cone and $N=3$ pole Coulomb packet—use the fixed source epochs listed in the second-edition claim map, and L23 uses the matching bridge repaired in c62 to original action units with the source left reading. The original action baseline H = `e60a86058abcb74b7f2225f2383c182be8343785` is an ancestor of S, with identical action root, background parameters, actual background, and Clifford definitions.

In the tables below, **F** denotes a formal Lean theorem, **E** an exact computational result with independent check, and **A** an analytic argument. The prefix `L/` means `Lean/SaturationMonoid/PhysicsCore/LowEnergy/`, and `V/` means `Verification/physics/low-energy-phenomenology/`.

| Claim | Evidence | Main text / Supplement | Fixed-source entry |
|------|--|-----|-----------|
| L1 Inventory and affine expressions | F | A.1 | `L/ScalarInventory.lean`, `L/Running.lean` |
| L2 Joint vacuum and bare stabilizer | F/E/A | §2, A.2–A.3 | `L/JointMassCoordinates.lean`, `V/stabilizer-derivation.md` |
| L3 Joint nine-field development and actual initial-data derivatives | F | §§3.1–3.2, Supp. S1.1 | `L/Evolution/Uniform.lean`, `VariationDerivative.lean` |
| L4 Complete matter composition and density | F | §3.4, Supp. S3.3 | `L/Quantum/{Compression,Density}.lean` |
| L5 Radial Jacobi propagation at every momentum | F | §3.3 | `L/Spacetime/{Propagation,Cauchy,Jacobi}.lean` |
| L6 Complete coupled propagation | F/E | §§4.1–4.3, Supp. S1.2 | `V/active-gauge/`, `rotation/` |
| L7 Phases, preparations, and peripheral development | F/E | §2.5, §§4.4–4.5, Supp. S1.2 | `L/FullPhase/`, `V/canonical-active/`, `canonical-peripheral/` |
| L8 Two-phase effective action | E | §5, Supp. S1.3, Figure 2 | `V/soft-phase/compute.py`, `receipt.json` |
| L9 Complete vertices and source exchange | F/E | §§6.1–6.3, Supp. S2.2 | `V/matter-vertices/`, `scalar-exchange/`, `L/Fermion/Consumer.lean` |
| L10 Original free external legs and residues | F/E | §§6.4–6.6, Supp. S2.1/S2.3 | `V/matter-modes/`, `onshell-sources/`, `kinetic-residue/` |
| L11 Principal parts and static source response | E | §6.7, Supp. S2.3 | `V/principal-normalization/`, `charge-response/`, `metric-response/` |
| L12 Occupied response in every gauge direction | E | §7.1 | `V/occupied-response/`, `causal/` |
| L13 Group on the full spatial carrier and complete domain | F/E | §§7.2–7.3, Supp. S3.1 | `L/MatterSpace/{Spatial,GeneratorDomain,PrimalSymbol}.lean` |
| L14 Actual gauge preparation | F | §7.3, Supp. S3.3 | `L/MatterSpace/Preparation{Gauge,State,Native}.lean` |
| L15 Every finite CAR word | F | §7.4, Supp. S3.3 | `L/MatterSpace/SpatialCAR{Words,State,Native}.lean` |
| L16 Local current and original phase | F | §7.5, §8.3, Supp. S3.4 | `L/MatterSpace/SpatialResponse{Kubo,Source,Phase}.lean` |
| L17 All-time, all-amplitude evolution and actual derivatives | F/E | §1, §8, Supp. S3.2/S3.4, Figure 3 | `L/MatterSpace/Global{Glue,Flow,Response,Original}.lean` |

New source paths use `Verification/physics/low-energy-phenomenology/` as their root. The continuation below lists L18–L29 together with the second-edition (v2) standard long-range and $N=3$ pole extensions (full hashes for `e055`, `c62`, `71e`, `ba7e`, and `df4` appear in “Code and data availability”).

| Claim | Type | Main text / Supplement | Fixed source entry |
|---|---|---|---|
| L18 Joint charge and complete static projection | F | §9.1–9.4, Supp. S4.2 | `alpha-source/SourceJoint{PhaseAction,PreparedCoupling}.lean`, `SourceStaticComposite{Projection,Current}.lean` |
| L19 Complete static Coulomb scalar | F | §9.4, Supp. S4.2 | `em-identification/PhysicalEMCompleteStaticScalar.lean` |
| L20 Dressed joint character and prepared read | F | §9.3 | `em-identification/PhysicalEMDressed{Character,PreparedRead}.lean` |
| L21 Electron unit charge and Thomson interface | F | §9.3/9.5, §10.1 | `SourceElectronChargeUnit.lean`, `SourceThomson{StaticResponse,MatchingConsumer}.lean` |
| L22 Source photon amplitude and on-shell input | F | §9.2/9.5, Supp. S4.1 | `SourcePrepared{PhotonAmplitude,ThomsonInput}.lean` |
| L23 Raw-unit Thomson matching bridge | F | §9.5 | `SourcePreparedThomsonMatchingBridge.lean` |
| L24 Physical electron equal-charge exchange and once-Coulomb | F | §10.1–10.4, Supp. S4.3 | `em-identification/PhysicalEMActualElectronCoulomb.lean` |
| L25 Full-parameter on-shell photon return | F | §10.5 | `em-identification/PhysicalEMActualElectronOrdinary.lean` |
| L26 Mother-action Hessian and clock flux invariance | F | §11.1–11.3, Supp. S5.1–S5.2, Figure 4 | `em-identification/ActualEM{Carrier,Action,Clock}.lean` |
| L26 Standard branch gates and transverse Maxwell cone | F | §11.4, Supp. S5.7, Figure 7 | `em-identification/ActualDressedEM{StandardLongRange,CorrectedRootFluxConsumer}.lean` |
| L27 Whole-289 and moving two-end single-$4\pi$ return | F | §12.1–12.3, Supp. S5.3–S5.5, Figure 5 | `em-identification/Actual{WholeCoulombPacket,DressedMovingCoulomb}.lean` |
| L27 $N=3$ pole packet and $\lvert Q_e\rvert^2=1$ cancellation | F | §12.4, Supp. S5.7, Figure 7 | `em-identification/PhysicalN3Pole{CoulombPacket,CurrentAudit}.lean` |
| L28 Three-fermion four-end Born overlap dressing | F | §13, Supp. S5.6, Figure 6 | `em-identification/ActualCompositeCoulombDressing.lean` |
| L29 Three-channel static circuit and two-step far-field balance | F | §14.1, Supp. S5.7, Figure 7 | `em-identification/ActualDressedStatic{CurrentCircuit,LongrangeReturn}.lean` |

### B.2 Restoring source files

The original exact data files are extracted from commit S; mechanism plates are generated from their fixed declarations. Build steps, checks, and the public status of each source family appear in “Code and data availability.” In the public repository H0mework, fixed source files can be restored by their original paths with

```bash
python3 tools/source_view.py --output DIR --at base --path ORIGINAL_REPOSITORY_PATH
```

Notation in the text corresponds to fixed source declarations as follows, for search by name:

| Notation | Source declaration |
|---|---|
| $h_{\mathrm{src}}$, $c_{\mathrm{src}}(b)$ | `phaseMomentum`, `sourceSpeed` |
| $\mathcal Z_\phi$, $\Pi_{\mathrm{prep}}$, $\mathcal D_{1/2}$, $\mathcal C_{\mathrm{src}}$ | `zeroLocalizedProfile`, `prepared`, `halfDensityEquiv 0`, `sourceCreated` |
| $\mathcal F_i$ | `fieldForm` |
| $G_T$ | the GT generator of `SourceDressedGTCharacter` |
| $u^{\mathrm{ch}}_{s,0}$, $\iota$ | `sourceChargedRestriction s 0`, `naturalCoordinates` |
| $F_0$, $G_0$ | `fullNativeOrigin`, `staticInverse` |
| Source pole branch and $e_0$ | `sourceSheet`, `scaleApproach` |
| $U_p(t)$, $G_p(z)$ | `physicalTime`, `jointResolvent` |
| $\mathcal R_{\mathrm{stat}}$, $\mathcal R_{\mathrm{dyn}}$, $c_{\mathrm{phys}}$ | `sourceStandardStaticRemainder`, `sourceDynamicStandardRemainder`, `sourceGeneratedPhysicalC` |
| $C_{\mathrm{EM}}^{\mathrm{gen}}$, $\alpha_{\mathrm{pole}}$ | `sourceGeneratedScalarCEM`, `physicalN3PoleEMCouplingExpression` |
| $w_{\mathrm{Yuk},d}$, $q_d^{(3)}$ | `yukawaWitness`, `actual_candidate_Y_entry` |
| $\mathcal R_{\mathrm{nat}}$, $\mathcal R_{\mathrm{fb}}$, $\mathcal R_{\mathrm{null}}$ | `nativeCurrentRead`, `feedbackCurrentRead`, `nullCurrentRead` |


<!-- code-availability:begin -->
## Code and data availability

The second-edition [public claim map](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-map.json) and [reproduction guide](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-reproduction.md) for L1–L29 are pinned to H0mework commit `d916604d403ae97e19779ff6fcd789e0184a468d` (Apache-2.0). Each entry gives the original source epoch, public declaration, downstream verification, resources, historical certification and public kernel acceptance. The [fixed first-edition map](https://github.com/Sapientropic/H0mework/blob/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/low-energy-release-map.json) supplies the original proofs and exact scientific evidence.

Use a fresh output directory for each check. These commands verify the fixed map and original certifications, then build and audit the second-edition scope L26–L29. The guide also links the inherited proofs and exact resources.

```sh
git checkout d916604d403ae97e19779ff6fcd789e0184a468d
python3 tools/low_energy_v2.py entry --paper low-energy-phenomenology
for check in build trust types; do
  LEAN_NUM_THREADS=2 python3 tools/low_energy_v2.py "$check"     --paper low-energy-phenomenology --output ".local/low-energy-v2-$check"
done
```
<!-- code-availability:end -->

## References

[1] Gao, J. *From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*. CourtyCourt · Case 0, Zenodo, v3 (2026), DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339) (v1 DOI: [10.5281/zenodo.23210292](https://doi.org/10.5281/zenodo.23210292); v2 DOI: [10.5281/zenodo.23297179](https://doi.org/10.5281/zenodo.23297179)).

[2] Abbott, L. F. Introduction to the Background Field Method. *Acta Physica Polonica B*, **13** (1982), 33–50. [Original journal text](https://www.actaphys.uj.edu.pl/R/13/1/33/pdf).

[3] Henning, B., Lu, X., and Murayama, H. How to use the Standard Model effective field theory. *Journal of High Energy Physics*, **2016**(01) (2016), 023. DOI: [10.1007/JHEP01(2016)023](https://doi.org/10.1007/JHEP01(2016)023). [Authors' manuscript arXiv:1412.1837v2](https://arxiv.org/abs/1412.1837v2), §2.1, equations (2.1)–(2.8).

[4] Tasaki, H. Introduction to the “second quantization” formalism for non-relativistic quantum mechanics: A possible substitution for Sections 6.7 and 6.8 of Feynman's “Statistical Mechanics”. [arXiv:1812.10732v5](https://arxiv.org/abs/1812.10732v5) (2018; v5 revised 2023), §3, equations (3.22)–(3.29).

[5] Kato, T. Integration of the equation of evolution in a Banach space. *Journal of the Mathematical Society of Japan*, **5**(2) (1953), 208–234. DOI: [10.2969/jmsj/00520208](https://doi.org/10.2969/jmsj/00520208).

[6] Kubo, R. Statistical-Mechanical Theory of Irreversible Processes. I. General Theory and Simple Applications to Magnetic and Conduction Problems. *Journal of the Physical Society of Japan*, **12**(6) (1957), 570–586. DOI: [10.1143/JPSJ.12.570](https://doi.org/10.1143/JPSJ.12.570).

[7] Georgi, H., and Glashow, S. L. Unity of All Elementary-Particle Forces. *Physical Review Letters*, **32**(8) (1974), 438–441. DOI: [10.1103/PhysRevLett.32.438](https://doi.org/10.1103/PhysRevLett.32.438).

[8] Georgi, H., Quinn, H. R., and Weinberg, S. Hierarchy of Interactions in Unified Gauge Theories. *Physical Review Letters*, **33**(7) (1974), 451–454. DOI: [10.1103/PhysRevLett.33.451](https://doi.org/10.1103/PhysRevLett.33.451).

[9] Pati, J. C., and Salam, A. Lepton number as the fourth “color”. *Physical Review D*, **10**(1) (1974), 275–289. DOI: [10.1103/PhysRevD.10.275](https://doi.org/10.1103/PhysRevD.10.275).

[10] Kibble, T. W. B. Lorentz Invariance and the Gravitational Field. *Journal of Mathematical Physics*, **2**(2) (1961), 212–221. DOI: [10.1063/1.1703702](https://doi.org/10.1063/1.1703702).

[11] Sciama, D. W. The Physical Structure of General Relativity. *Reviews of Modern Physics*, **36**(1) (1964), 463–469 (Erratum: **36**, 1103). DOI: [10.1103/RevModPhys.36.463](https://doi.org/10.1103/RevModPhys.36.463).

[12] Hehl, F. W., von der Heyde, P., Kerlick, G. D., and Nester, J. M. General relativity with spin and torsion: Foundations and prospects. *Reviews of Modern Physics*, **48**(3) (1976), 393–416. DOI: [10.1103/RevModPhys.48.393](https://doi.org/10.1103/RevModPhys.48.393).

[13] Dirac, P. A. M. Generalized Hamiltonian Dynamics. *Canadian Journal of Mathematics*, **2** (1950), 129–148. DOI: [10.4153/CJM-1950-012-1](https://doi.org/10.4153/CJM-1950-012-1).

[14] DeWitt, B. S. Quantum Theory of Gravity. II. The Manifestly Covariant Theory. *Physical Review*, **162**(5) (1967), 1195–1239. DOI: [10.1103/PhysRev.162.1195](https://doi.org/10.1103/PhysRev.162.1195).

[15] Weinberg, S. Phenomenological Lagrangians. *Physica A: Statistical Mechanics and its Applications*, **96**(1–2) (1979), 327–340. DOI: [10.1016/0378-4371(79)90223-1](https://doi.org/10.1016/0378-4371(79)90223-1).

[16] Appelquist, T., and Carazzone, J. Infrared singularities and massive fields. *Physical Review D*, **11**(10) (1975), 2856–2861. DOI: [10.1103/PhysRevD.11.2856](https://doi.org/10.1103/PhysRevD.11.2856).

[17] Stone, M. H. On One-Parameter Unitary Groups in Hilbert Space. *Annals of Mathematics* (2), **33**(3) (1932), 643–648. DOI: [10.2307/1968538](https://doi.org/10.2307/1968538).

[18] Thaller, B. *The Dirac Equation*. Texts and Monographs in Physics, Springer-Verlag, Berlin, Heidelberg (1992). DOI: [10.1007/978-3-662-02753-0](https://doi.org/10.1007/978-3-662-02753-0).

[19] Dyson, F. J. The Radiation Theories of Tomonaga, Schwinger, and Feynman. *Physical Review*, **75**(3) (1949), 486–502. DOI: [10.1103/PhysRev.75.486](https://doi.org/10.1103/PhysRev.75.486).

[20] Araki, H. On Quasifree States of CAR and Bogoliubov Automorphisms. *Publications of the Research Institute for Mathematical Sciences*, **6**(3) (1970), 385–442. DOI: [10.2977/prims/1195193913](https://doi.org/10.2977/prims/1195193913).

[21] Bratteli, O., and Robinson, D. W. *Operator Algebras and Quantum Statistical Mechanics 2: Equilibrium States. Models in Quantum Statistical Mechanics*, 2nd ed. Springer-Verlag, Berlin, Heidelberg (1997). DOI: [10.1007/978-3-662-03444-6](https://doi.org/10.1007/978-3-662-03444-6).

[22] Ward, J. C. An Identity in Quantum Electrodynamics. *Physical Review*, **78**(2) (1950), 182. DOI: [10.1103/PhysRev.78.182](https://doi.org/10.1103/PhysRev.78.182).

[23] Takahashi, Y. On the generalized Ward identity. *Il Nuovo Cimento*, **6**(2) (1957), 371–375. DOI: [10.1007/BF02832514](https://doi.org/10.1007/BF02832514).

[24] Hehl, F. W., and Obukhov, Y. N. *Foundations of Classical Electrodynamics: Charge, Flux, and Metric*. Progress in Mathematical Physics, Vol. 33, Birkhäuser, Boston (2003). DOI: [10.1007/978-1-4612-0051-2](https://doi.org/10.1007/978-1-4612-0051-2).

[25] Lehmann, H. Über Eigenschaften von Ausbreitungsfunktionen und Renormierungskonstanten quantisierter Felder. *Il Nuovo Cimento*, **11**(4) (1954), 342–357. DOI: [10.1007/BF02783624](https://doi.org/10.1007/BF02783624).

[26] Lehmann, H., Symanzik, K., and Zimmermann, W. Zur Formulierung quantisierter Feldtheorien. *Il Nuovo Cimento*, **1**(1) (1955), 205–225. DOI: [10.1007/BF02731765](https://doi.org/10.1007/BF02731765).

[27] Dirac, P. A. M. Gauge-Invariant Formulation of Quantum Electrodynamics. *Canadian Journal of Physics*, **33**(11) (1955), 650–660. DOI: [10.1139/p55-081](https://doi.org/10.1139/p55-081).

[28] Kulish, P. P., and Faddeev, L. D. Asymptotic conditions and infrared divergences in quantum electrodynamics. *Theoretical and Mathematical Physics*, **4**(2) (1970), 745–757 (*Teoret. Mat. Fiz.* **4**(2), 153–170). DOI: [10.1007/BF01066485](https://doi.org/10.1007/BF01066485).

[29] Buchholz, D. Gauss' law and the infraparticle problem. *Physics Letters B*, **174**(3) (1986), 331–334. DOI: [10.1016/0370-2693(86)91110-X](https://doi.org/10.1016/0370-2693(86)91110-X).

[30] Donoghue, J. F. General relativity as an effective field theory: The leading quantum corrections. *Physical Review D*, **50**(6) (1994), 3874–3888. DOI: [10.1103/PhysRevD.50.3874](https://doi.org/10.1103/PhysRevD.50.3874). [arXiv:gr-qc/9405057](https://arxiv.org/abs/gr-qc/9405057).

[31] Gao, J. *Two Negatives and One Positive, the Bare Trace Under Oath: Ordered Closed Traces and Whole-Ball Response Curvature*. CourtyCourt · Case 2, Zenodo, v1 (2026). DOI: [10.5281/zenodo.23299177](https://doi.org/10.5281/zenodo.23299177).

[32] de Moura, L., and Ullrich, S. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, Lecture Notes in Computer Science, Vol. 12699, Springer (2021), 625–635. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[33] Källén, G. On the definition of the renormalization constants in quantum electrodynamics. *Helvetica Physica Acta*, **25**(4) (1952), 417–434. DOI: [10.5169/seals-112316](https://doi.org/10.5169/seals-112316).

[34] Haag, R. Quantum Field Theories with Composite Particles and Asymptotic Conditions. *Physical Review*, **112**(2) (1958), 669–673. DOI: [10.1103/PhysRev.112.669](https://doi.org/10.1103/PhysRev.112.669).

[35] Weinberg, S. Evidence That the Deuteron Is Not an Elementary Particle. *Physical Review*, **137**(3B) (1965), B672–B678. DOI: [10.1103/PhysRev.137.B672](https://doi.org/10.1103/PhysRev.137.B672).

[36] Taylor, J. C. Ward identities and charge renormalization of the Yang–Mills field. *Nuclear Physics B*, **33**(2) (1971), 436–444. DOI: [10.1016/0550-3213(71)90297-5](https://doi.org/10.1016/0550-3213(71)90297-5).
