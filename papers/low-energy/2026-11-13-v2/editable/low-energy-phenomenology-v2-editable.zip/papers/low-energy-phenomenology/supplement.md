# 补充材料：传播目录、空间演化接口与多体长程完整证明

# Proof Supplement: Propagation Catalogs, Spatial Evolution Interfaces, and Multi-Body Long-Range Proofs

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

## 摘要

本补充材料完整给出《零旋钮统一场的低能电磁涌现：耦合传播、电子单位电荷、Maxwell 光速锥与 $1/(4\pi r)$ 库仑返回》（CourtyCourt · Case 1，第二版 v2；母作用见物理旗舰第三版 [1]，第一版归档见 [2]）正文 §§3–14 所调用的技术目录、算子分析接口与逐步骤完整推导：S1 给出齐次余标架平衡、有理传播恢复与全四动量四阶软相位矩阵（式 (S1.1)–(S1.5)）；S2 给出四条自由外腿原坐标、两个弱五源精确逆与静态响应计数（式 (S2.1)–(S2.4)）；S3 给出空间 Dirac 群弱方程、全时间窗口拼接、全词 CAR 母作用次序与一阶电流积分接口（式 (S3.1)–(S3.2)）；S4 给出闭形式 Riesz 准备点、五维静态逆误差界与同荷余标架多层交换恒等式（式 (S4.1)–(S4.17)）；S5 给出 1650 项一阶射流二阶变分、极点留数差商、全方向 Schur 红外半径、三维 Gaussian–Bochner 去规极限、二粒子创建源正范数下界、三费米子四分级 Born 重叠修饰，以及标准 Maxwell 光速锥、$N=3$ 极点单位荷消去与三通道远场同阶平衡的完整书面证明（式 (S5.1)–(S5.24)）。与第一版（v1）单册附录的节号与公式号一一对应关系为：S1 $\leftrightarrow$ v1 附录 B，S2 $\leftrightarrow$ v1 附录 C，S3 $\leftrightarrow$ v1 附录 D，S4 $\leftrightarrow$ v1 附录 F，S5 $\leftrightarrow$ v1 附录 G（正文附录 A 与附录 B 分别承载裸库存稳定子与 `L1-L29` 固定证据总表）。文中所引无前缀节号与双栏数字公式号（如 `(3.1)`、`(11.17)`、`(14.4)`）均指主文对应章节与公式。

<a id="supp-s1"></a>
## S1　约化算子、四阶相位与原场返回

### S1.1 齐次余标架平衡与径向反馈

记 (3.1) 的 $E_A,\mathcal D,c,q_v$。将同一发展及实际 jet 代入原余标架变分，时间行化为

$$\mathcal C_0=\mathcal D-\frac{3aE_A}{4\sigma n^2}=0,\tag{S1.1}$$

空间迹行化为

$$\mathcal C_s=2a\dot H+\frac{E_A}{4\sigma n}
-n\left[\frac{2s(c-\alpha)}{a^2}-q_va^2\left(f^2+\frac{w_s^2}{2}\right)
-3a^2-H^2+c^2\right]=0.\tag{S1.2}$$

(S1.1) 的正根给出 (3.1) 的 $n$，(S1.2) 给出 (3.2) 的 $\dot H$。物质项、规范项、标量动能与势项的系数都在这两个平衡中保留。相应非迹空间行及混合行由原齐次场的具体分量消去。径向一阶方向中 $f,w_s$ 都从零开始，(S1.1)–(S1.2) 的标量负载从二阶出现，与 (3.12) 的完整余标架变分一致。

### S1.2 传播目录与恢复矩阵

随稿数据 `axial-propagation.json` 保存十个块的字段索引、行分母、非零常数、全部因子及重数；`radial-propagation.json` 保存 14 个径向乘积及其与 22 个轴向因子的对应。二者摘自固定源提交的精确输出。

字段缩放后 $G=S_f^{\mathsf T}K_{103}S_f/N$，原行列式的准确恢复是

$$\det K_{103}(\lambda,k)=
\frac{N^{103}}{\prod_i(S_f)_{ii}^2}
\det G\left(\frac{\lambda}{N\sqrt2},\frac{k}{\sqrt2}\right).\tag{S1.3}$$

原三轮辅助恢复、Ward 行逆、制备嵌入和截面读回构成两组映射：场映射把有效解送回原字段，方程映射把有效残差送回原 Euler 行。它们不是同一个矩阵。§5 的 $V_{289}$ 与 $J_{289}$ 是其制备子类版本，恒等式 $H_{289}V_{289}=J_{289}G$ 在全部四个形式动量下成立。

外围发展的例外纤维维数、投影和旋转映射分别保存在正文附录 B 所列的 canonical-peripheral 来源。瞬时核与最大发展空间的区别在于，后者要求原向量场继续留在约束空间；因此计算同时使用约束及其发展闭包，而不只取某一点的矩阵核。

43 维实标量子空间的四维块使用原四元数结构：对三个满足 $J_i^2=-I$、$J_iJ_j=-J_jJ_i$ 的实际生成矩阵，若 $M=aI+\sum_i b_iJ_i$，则

$$M\left(aI-\sum_i b_iJ_i\right)=
\left(a^2+\sum_i b_i^2\right)I,\qquad
\det M=\left(a^2+\sum_i b_i^2\right)^2.\tag{S1.4}$$

适配基及系数把这个恒等式逐块应用到 23 个实单态和五个四维块。完整 61 维外围逆另由 (6.8) 使用其全部投影。

### S1.3 全四动量的四阶相位矩阵

记 $r=q_1^2+q_2^2+q_3^2$。在 §5 的原相位归一中，四阶项为

$$\begin{aligned}
(K_4)_{\varphi\varphi}={}&\frac{8000}{13467}\bigl[(q_2^2+q_3^2)^2-q_1^4\bigr]
-\frac{12033024}{67896125}q_1^2u^2\\
&+\frac{258700928}{203688375}(q_2^2+q_3^2)u^2
+\frac{320}{363}u^4,\\[2pt]
(K_4)_{\varphi\theta}=(K_4)_{\theta\varphi}={}&
\frac{2000}{603}q_1^2r+\frac{400}{99}q_1^2u^2
-\frac{148000i}{59697}q_3ur-\frac{34000i}{6633}q_3u^3,\\[2pt]
(K_4)_{\theta\theta}={}&\frac{2317625}{39366}r^2
-\frac{47494}{243}ru^2+\frac{45694}{375}u^4.
\end{aligned}\tag{S1.5}$$

这里 $u,\mathbf q$ 是增长／空间 Fourier 变量，转置恒等式采用 $p\mapsto-p$ 的双线性约定。具体截面的离壳表达式可以含有定向项；原四动量有效作用与完整字段回写共同决定其意义。

把 $u^2=-55r/67+dr^2$ 代入向量相位行，(S1.5) 在二阶壳上化为 $12033024r^2/82709825$，与方向无关。轴向相位行取 $u^2=125r/162+dr^2$，四阶项为 $-381625r^2/19683$。两种原时间读回分别给出 (5.10)–(5.11)。四阶非对角项的平方在行列式中从八阶开始，除以另一条非重合二阶支后，从 $u^2$ 的六阶系数开始产生影响。

随稿数据 `soft-phase.json` 保存常数相位基、77 维重方向原点逆、各阶图映射、原 Noether 密度、原 289 行嵌入以及五／六阶余项。正文的 $O(|\mathbf k|^6)$ 是分支展开的阶数；其中的 $R_5,R_6$ 是有限场截断代入原方程后确切的齐次余项，二者用途不同。


<a id="supp-s2"></a>

## S2　外腿、弱五源与静态响应目录

### S2.1 四条外腿的原坐标

原 252 坐标按 Dirac 分量优先、外幂层次依次为 $\Lambda^6,\Lambda^2,\Lambda^4$，每层按递增指标集合的原枚举排序。令 $e_j^{(252)}$ 表示从 0 开始编号的单位列，(6.17) 的四条坐标单位腿为

$$u_{4,\rm in}=e_{154},\qquad
u_{4,\rm out}=\frac{e_{154}+e_{217}}{\sqrt2},$$

$$u_{2,\rm in}=e_{196},\qquad
u_{2,\rm out}=\frac{e_{133}-e_{196}}{\sqrt2}.\tag{S2.1}$$

下标 $\mathrm{in}/\mathrm{out}$ 区分入、出腿，四个 $u$ 均属于原物质载体；出腿的独立对偶为 $s u_{\rm out}^\dagger S$，转移源按 (6.4) 形成。它们的场方程、动量、频率、全部 97 分量转移源、79 维动态解与 289 维正 Green 字段保存在随稿数据 `onshell-exchange.json`。作用归一腿统一乘 $2^{-1/4}$；其实际重新生成的两条源、289维场和最终交换见 `kinetic-residue.json`。

原点频率的完整合并分布为

$$\frac{E_{\rm orig}}{N\sqrt2}:
-\frac95[42],\ -\frac32[50],\ -\frac35[14],\quad
\frac35[15],\ \frac32[50],\ \frac95[45].\tag{S2.2}$$

非零动量的自由谱分支在 §6.4 给出；原时间零频率球为 $|\mathbf k|^2=54/25,9/2,162/25$，相应核维数为 $29,50,29$。共转零频率球另为 $0,9/50,81/50,72/25$，维数为 $31,5,45,28$。两组由 $E_{\rm st}=E_{\rm orig}-\omega Q$ 连接，不互相改名。

### S2.2 两个原弱五源的完整逆

每个弱通道含四个连接分量与一个原标量方向。对任意三动量，记

$$r=|\mathbf k|^2,\qquad
T=\lambda^2+\frac r{N^2}-\frac12,\qquad
L=\lambda^2+N^2r-\frac12.$$

实际四向量 Green 矩阵为

$$G_{00}=\frac{N(1-2\lambda^2)}{4L},\qquad
G_{0i}=G_{i0}=-\frac{iN\lambda k_i}{2L},$$

$$G_{ij}=-\frac{\delta_{ij}}{4NT}
+\frac{(2N^2\lambda^2+2r-N^{-2})k_ik_j}{4NTL}.\tag{S2.3}$$

它没有方向分母，$\mathbf k=0$ 时直接得到 $G_{00}=-N/2$。原变量变换 $A_\mu=B_\mu-\partial_\mu\eta$ 将五变量作用化成标量常数块 $-4N$ 与四向量块。对规范源 $j_\mu$ 和原标量源 $z$，树作用为

$$-\frac12j(-p)^{\mathsf T}G(p)j(p)
+\frac1{8N}r_{\rm src}(-p)r_{\rm src}(p),\qquad
r_{\rm src}=z+\lambda j_0+i\mathbf k\cdot\mathbf j.\tag{S2.4}$$

第二项是原标量—散度接触源。两通道均由原六个规范辅助场恢复并满足全部 289 行；式 (S2.4) 因而与 (6.5) 的对应块相同。

### S2.3 留数、源与静态读数

全部自由谱投影保留手征和外幂级。动能留数的符号为 $\chi_c/s$；相位荷配对的正权重则为 $s\chi_cQ$。其计数为

| 原自由方向 | 维数 | 动能权重 | 相位荷权重 |
|---|---:|---:|---:|
| 左手 $\Lambda^2/\Lambda^4$ | 106 | $-s$ | $s$ |
| 右手 $\Lambda^2/\Lambda^4$ | 96 | $s$ | $s$ |
| 右手 $\Lambda^6$ | 14 | $s$ | $3s$ |

随稿数据 `metric-response.json` 保留十个独立度规源及全部 $10\times10$ 有理读数；`charge-response.json` 保留十二个原电荷源、$12\times12$ 读数及相容源软留数。它们的完整诱导场负号均按正号作用源约定。读数在原点有限延拓，并不意味着原完整逆在原点可逆。


<a id="supp-s3"></a>

## S3　空间发展与全词读回的证明接口

### S3.1 原域上的强式与一般初态的弱式

对 $f\in\mathcal D(\mathsf H)$，(7.7) 给出 $U(t)f$ 的强导数。对一般 $u\in\mathscr H$，取域中测试向量 $v$，(8.2) 满足

$$\frac d{dt}\langle v,W_\epsilon(t,a)u\rangle
=-i\langle\mathsf Hv,W_\epsilon(t,a)u\rangle
-i\epsilon\langle v,R(t)W_\epsilon(t,a)u\rangle.\tag{S3.1}$$

内积采用左共轭、右线性约定。(S3.1) 的第一项先把无界生成元作用于 $v$，所以对全部 $L^2$ 初态都有定义。用原 $S$ 配对及 (7.8) 读回后得到原独立 dual 弱方程；Schwartz 测试再把 Fourier 乘子写成实际空间偏导。

### S3.2 全时间窗口的拼接

给定起点 $a$、终点 $t$，选择任何包含二者的开窗口，例如半径 $|a|+|t|+1$。窗口内的径向构造先生成解，范数恒等式再使其满足原交互方程。与另一个窗口重叠时，两条原解由相同初值与唯一性相等。因此在任意 $t$ 邻域内，全局曲线与某条固定窗口曲线最终相等；其时间导数从这条固定曲线继承，而不是对随 $t$ 改变的窗口半径求导。

线性同样由唯一性得出：两解之和与和初值的解满足同一原方程。把一个解在中间时刻的值用作新初值，便得双时刻复合律；反向时间给出双侧逆。这个论证不需要对全体时间预先供应一个统一的控制范数。

### S3.3 准备、CAR 词与原母作用的次序

令 $E$ 包含准备向量及给定有限测试族，$J_E$ 为一粒子层嵌入，$I_{12}:\mathcal H_{12}\to\mathcal M$ 为原外幂等距嵌入。对有限 CAR 词 $W$，未归一空间准备的母作用为

$$\widetilde A_W=I_{12}K_t^\dagger\,\iota_E
(J_E^\dagger WJ_E)\iota_E^\dagger K_tI_{12}^\dagger,
\qquad A_{\rm mother}=S\widetilde A_W.\tag{S3.2}$$

其中 $\iota_E:E\to\mathscr H$ 为包含映射；最后一次 $S$ 将坐标内积接回原独立对偶，正是 (7.13a) 的配对。规范化时再除以 $\|K_tw\|^2$。若准备为零，则保留未归一的零泛函；单位态结论只用于已生成的非零准备。

(S3.2) 在 $W$ 已完整形成之后使用一次压缩。测试族扩大时，外代数嵌入交织每一个产生／湮灭算子，故全部有限词、其伴随及 $W^\dagger W$ 同时保持。多时词先在各自腿上使用原 $P(t_i+t_p)$，再形成完整乘积；一般不把多条不同时刻的相位合成一个任意选取的总相位。

### S3.4 一阶余项与电流积分

式 (8.8) 的共同常数来自时间段上的 $\sup\|R(t)\|$，而非某个初态依赖的导数半径。由于强积分逐向量定义，积分算子的有界性由该统一界给出；无须把 $R_H(t)$ 提升为算子范数连续。局域电流的 $L^1$ 界 (7.18) 随后把两条一阶态变分送入真实积分电流。此顺序保证 (8.10) 是全局有限发展的一阶读数，不只是一个形式对易子。


<a id="supp-s4"></a>

## S4　准备、静态逆与同荷交换的书面证明

### S4.1 闭形式怎样生成同一个准备点

原源余项是完整能量尾与组成项之差 $R=E_{\mathrm{tail}}-C_{\mathrm{src}}$。两者各有双侧 Schur／源系数界与自伴性；所以 $R$ 固定、有界、自伴。闭稠密因子 $A$ 的增广图取

$$\widetilde A x=\left(Ax,(R+\|R\|I)^{1/2}x\right),\qquad
\|\widetilde Ax\|^2=\mathfrak q(x,x)+\|R\|\|x\|^2.
\tag{S4.1}$$

平方根是有界正算子的平方根。若 $x_n\to x$、$\widetilde Ax_n\to(y,z)$，$A$ 闭使 $x\in D(A)$、$Ax=y$；有界平方根使 $z=(R+\|R\|I)^{1/2}x$。因此增广图闭，域仍稠密。图内积
$\langle\widetilde Ax,\widetilde Ay\rangle+\langle x,y\rangle$
的 Riesz 解生成 $\mathsf B$，满足

$$\mathfrak q(\mathsf Bf,y)+(1+\|R\|)\langle\mathsf Bf,y\rangle
=\langle f,y\rangle,\qquad y\in D(A).
\tag{S4.2}$$

取 $y=\mathsf Bf$，得 $\mathsf B$ 正；若 $\mathsf Bf=0$，则 $f$ 与稠密 $D(A)$ 正交，故 $f=0$。两侧交换并取共轭给自伴性。令 $b=\|\mathsf B\|>0$。对正有界算子，单位向量的二次读数上确界等于范数；取单位 $y_j$ 使 $\langle y_j,\mathsf By_j\rangle\to b$。由
$0\le\mathsf B^2\le b\mathsf B$，

$$\|(\mathsf B-bI)y_j\|^2
\le b\left(b-\langle y_j,\mathsf By_j\rangle\right)\longrightarrow0.
\tag{S4.3}$$

于是 $\|\mathsf By_j\|\to b$，$x_j=\mathsf By_j/\|\mathsf By_j\|$ 在 $\mathcal T$ 的定义域中，且

$$\|(\mathcal T-E_{\mathrm{src}})x_j\|
=\frac{\|y_j-b^{-1}\mathsf By_j\|}{\|\mathsf By_j\|}
\longrightarrow0.
\tag{S4.4}$$

给定 $\varepsilon$，选其残差小于 $\varepsilon$ 的同一 $x_j$。局域化半密度映射与原升粒子数 CAR 产生算子均为等距映射，所以 $v_\varepsilon$ 仍保持单位范数。原种子态的原生超荷 $Y$ 特征值为 $-1$；这一等式先在光滑测试核上成立，再由有界荷算子和稠密性延拓，即得 (9.4)。同一 $x_j$ 的原弱形式就是 (S4.2) 的逆图，八条完备腿由原局域化腿界控制。闭 Yukawa 图在该点给出 (9.4) 后的几何截断界；因而准备中每个分量都直接消费同一内生生成点。

### S4.2 全方向静态逆、原场恢复及误差价格

原五维静态矩阵及其逆是

$$\begin{gathered}
T_5=\sqrt{30}
\begin{pmatrix}
-25/54&0&0&0&0\\
0&-12/335&0&0&0\\
0&0&1/15&-1/3&0\\
0&0&-1/3&1/15&0\\
0&0&0&0&4/5
\end{pmatrix},\\
G_5=\sqrt{30}
\begin{pmatrix}
-9/125&0&0&0&0\\
0&-67/72&0&0&0\\
0&0&-1/48&-5/48&0\\
0&0&-5/48&-1/48&0\\
0&0&0&0&1/24
\end{pmatrix}.
\end{gathered}
\tag{S4.5}$$

直接乘法给 $T_5G_5=G_5T_5=I_5$。这同时核对 (9.14) 与 (10.13) 的实际尺度。以下 $T_{\mathrm{stat}},G_0$ 表示 $T_5,G_5$ 的 $289$ 维零扩展；尤其 $G_0$ 就是原静态逆矩阵。可逆补齐矩阵则另记为 $\widetilde T_0=T_{\mathrm{stat}}+I-\Pi_5$、$\widetilde G_0=G_0+I-\Pi_5$。下文 $F_0$ 和 $F_{\kappa,n}$ 是原 $289$ 维场恢复矩阵，源读口的值落在 $\Pi_5$ 内，故零扩展与补齐逆在该值上的作用完全相同。原 Schur 核 $K_{\mathrm{eff}}(p)$ 的首项字典在 $p=(0,i\kappa n)$ 上逐项等于
$-\kappa^2|n|^2T_{\mathrm{stat}}$：时间幂非零的单项式消去，三个空间平方各给 $-\kappa^2n_j^2$，交叉项在原典范项表中相消。

令 $\Pi_5$ 为五方向投影，定义

$$\mathsf K_{\kappa,n}
=(-\kappa^2)^{-1}K_{\mathrm{eff}}(0,i\kappa n)+(I-\Pi_5).
\tag{S4.6}$$

原有限多项式系数及互补逆给出源内常数
$B_{\mathrm{inv}}\ge1$、$C_{\mathrm{eff}}\ge0$ 和正半径 $r_0$，对所有 $|n|=1$、$0<\kappa\le r_0$ 满足
$\|\mathsf K_{\kappa,n}-\widetilde T_0\|\le C_{\mathrm{eff}}\kappa$、
$\|\widetilde G_0\|\le B_{\mathrm{inv}}$。常数可由原项表的绝对系数和及互补块在控制邻域的双侧逆界直接计算。再缩半径到

$$r_{\mathrm{stat}}=\min\left\{r_0,
\frac1{4B_{\mathrm{inv}}(1+C_{\mathrm{eff}})}\right\}.
\tag{S4.7}$$

此时 $\|\widetilde G_0(\mathsf K_{\kappa,n}-\widetilde T_0)\|\le1/4$。Neumann 级数给实际双侧逆，逆差恒等式给

$$\|\mathsf K_{\kappa,n}^{-1}\|\le2B_{\mathrm{inv}},\qquad
\|\mathsf K_{\kappa,n}^{-1}-\widetilde G_0\|
\le2B_{\mathrm{inv}}^2C_{\mathrm{eff}}\kappa.
\tag{S4.8}$$

完整保留原场恢复映射 $F_{\kappa,n}$、源读口 $R_{\kappa,n}$、局部接触项与补空间项，完整原场为

$$\mathcal G_\kappa J=X_{\mathrm{contact}}(J)
+(-\kappa^2)^{-1}F_{\kappa,n}
\mathsf K_{\kappa,n}^{-1}R_{\kappa,n}J
+X_{\mathrm{complement}}(J).
\tag{S4.9}$$

这些映射在原源半径内连续，分别趋于 $F_0,F_0^{\mathsf T}$ 与原点的接触项／补空间项；全场满足 (9.2)。原极点因子的有限 $\kappa$ 误差，因此有

$$\begin{aligned}
&\left|J_D^{\mathsf T}
\left[-\kappa^2(\mathcal G_\kappa J_S-X_{\mathrm{reg}}(J_S))
-F_{\kappa,n}G_0R_{\kappa,n}J_S\right]\right|\\
&\quad\le
\left(\sum_i|J_{D,i}|\right)\|F_{\kappa,n}\|\,
2B_{\mathrm{inv}}^2C_{\mathrm{eff}}\kappa\,
\|R_{\kappa,n}J_S\|,
\qquad X_{\mathrm{reg}}=X_{\mathrm{contact}}+X_{\mathrm{complement}}.
\end{aligned}\tag{S4.10}$$

这先控制有限尺度的实际因子，再由连续性取固定受迫源的完整留数极限。它完整保留两侧源映射，未把几何投影或局部接触项提前丢弃。

### S4.3 同荷余标架交换为何保全部修正

设 $Q$ 为原实际荷。原正三角余标架坐标 $z_{\mathrm{cf}}=(z_0,\ldots,z_5)$ 的三个余子式是
$m=(n_{\mathrm{cf}}z_2z_5,n_{\mathrm{cf}}z_1z_5,n_{\mathrm{cf}}z_0z_5)$。原密度配对矩阵 $D_{\mathrm{kin}}$ 和原 $\gamma$／色作用给出完整 252 维矩阵

$$M_{\mathrm{cf}}(z)=2\left[
m_0D_{\mathrm{kin}}\,i\gamma^1\rho(T_1)
+m_1D_{\mathrm{kin}}\,i\gamma^1\rho(T_0)
-m_2D_{\mathrm{kin}}\,i\gamma^2\rho(T_0)\right].$$

这是原余标架槽变分中体积与逆标架合成的三个多项式系数。按原绝对荷的单位、零权投影 $\Pi_e,\Pi_n$，该矩阵的实际支撑给
$M_{\mathrm{cf}}=\Pi_eM_{\mathrm{cf}}\Pi_n+\Pi_nM_{\mathrm{cf}}\Pi_e$。
因此原始物质支的两条通道正是这两个有序乘积；独立对偶支交换正负通道后取原分支的共轭矩阵。先形成完整 504 维矩阵，再应用完整 CAR 一体量子化，可由
$[d\Gamma(Q),d\Gamma(M)]=d\Gamma([Q,M])$
得到光滑测试核上的荷次 $+1,-1$；不把量子化投影的乘积替代原矩阵乘积。

记该核心通道为 $C_\pm^0$，测试恢复为 $\mathcal I_F$、输出框架近似为 $P_F$。有限读口算子是
$C_\pm=P_F\,\operatorname{embed}\,C_\pm^0\mathcal I_F$。
其压缩交换项由两个原差直接生成：

$$E_{\mathrm{cmp},\pm}y=
[Q,P_F]\operatorname{embed}C_\pm^0\mathcal I_Fy
+P_F\operatorname{embed}C_\pm^0
(Q_{\mathrm{core}}\mathcal I_Fy-\mathcal I_FQy).$$

将核心荷次恒等式代入即得

$$[Q,C_\pm]=\pm C_\pm+E_{\mathrm{cmp},\pm}.
\tag{S4.11}$$

$E_{\mathrm{cmp},\pm}$ 由同一测试恢复和有限框架投影与 $Q$ 的差生成。原 Green 两侧逆给出

$$[Q,G_z]=G_z[H,Q]G_z.
\tag{S4.12}$$

令 $b_{\mathrm{cf}}=-g_{\mathrm{scale}}/2$、$B_\pm=G_z(b_{\mathrm{cf}}C_\pm)G_w$。乘积法则逐项给

$$[Q,B_\pm]=\pm B_\pm+
[Q,G_z](b_{\mathrm{cf}}C_\pm)G_w
+G_z(b_{\mathrm{cf}}E_{\mathrm{cmp},\pm})G_w
+G_z(b_{\mathrm{cf}}C_\pm)[Q,G_w].
\tag{S4.13}$$

记右侧后三项为 $E_{B,\pm}$。原准备投影 $P$、等能映射
$\mathcal E_F(A)=\sum_\nu C_\nu A E_\nu$、共振投影
$P_{\mathrm{res}}(n)=\sum_{\nu:\Delta v_\nu(n)=0}P_\nu(n)$
是实际原对象。定义 $B_\pm^P=PB_\pm P$，其交换余项为

$$E_{P,\pm}=[Q,P]B_\pm P+PE_{B,\pm}P+PB_\pm[Q,P].
\tag{S4.14}$$

等能映射产生独立两侧交换项

$$E_{\mathcal E}(A)=
\sum_\nu\left([Q,C_\nu]AE_\nu+C_\nu A[Q,E_\nu]\right),
\quad
[Q,\mathcal E_F(A)]=\mathcal E_F([Q,A])+E_{\mathcal E}(A).
\tag{S4.15}$$

共振投影的对易子是同一个原有限求和中各 $[Q,P_\nu(n)]$ 的和，不更换零速度面。取
$A_\pm=P_{\mathrm{res}}\mathcal E_F(B_\pm^P)$，则

$$\mathcal X_\pm=[Q,P_{\mathrm{res}}]\mathcal E_F(B_\pm^P)
+P_{\mathrm{res}}\left(E_{\mathcal E}(B_\pm^P)
+\mathcal E_F(E_{P,\pm})\right).
\tag{S4.16}$$

将 (S4.13)–(S4.16) 逐层代入，得到 (10.10)。原实际制备对偶腿与物质腿在两端分别给出荷 $q_L,q_R$，因此

$$\bigl(q_L-q_R\mp1\bigr)\mathcal Q_S(A_\pm)
=\mathcal Q_S(\mathcal X_\pm).
\tag{S4.17}$$

对相同费米通道，$q_L=q_R$；相加两条通道便得 (10.11)。证明只用了真实双侧逆、原荷作用和有限和乘积法则，故所有物质电荷扭矩、压缩项、两端 Green 因子与谱窗修正悉数保留。最后对完整 64 项权重求和，并按 (10.5) 再作实际双端归一，正是 (10.12)–(10.14)。


<a id="supp-s5"></a>

## S5　同作用、空间积分、Born 修饰、Maxwell 光速锥与远场平衡的完整推导

### S5.1 真实一阶射流的 Hessian 与 Fourier 字典

一阶射流共有 $5\times289=1445$ 个实槽。定义 $x_{d,i}$ 为场值或导数的原坐标。在原九组场提升中，余标架、两套联络、辅助场、乘子和标量使用其实际插入，物质使用 $P\delta\psi$，独立对偶使用 $\delta\chi\circ P$。在锚点处，共转场的时间导数保留 $P'(a)\delta\psi$；空间导数保留实际 $x_i$。这唯一决定原时间系数。

令 $X=\bar e^{-1}\delta e$。局部第二阶展开可以逐项恢复：

$$\begin{aligned}
e(t)^{-1}&=(I-tX+t^2X^2)\bar e^{-1}+O(t^3),\\
\nu_{e(t)}&=\nu_{\bar e}\left[1+t\operatorname{tr}X+
\frac{t^2}{2}\bigl((\operatorname{tr}X)^2-\operatorname{tr}X^2\bigr)\right]+O(t^3),\\
F(\bar A+ta)&=\bar F+tD_{\bar A}a+t^2a\wedge a,\\
D_{\bar A+ta}(\bar\Phi+t\varphi)&=
D_{\bar A}\bar\Phi+t(D_{\bar A}\varphi+\rho(a)\bar\Phi)+t^2\rho(a)\varphi.
\end{aligned}
\tag{S5.1}$$

Lorentz 曲率同样展开；$\Sigma_e$ 用两列余标架的楔积展开。独立对偶的物质项使用原双线性积 $\chi(i\Gamma D\psi+Y_R\psi)$，不增加反向 Yukawa。将 (S5.1) 代入原四部门密度，对每个积取两个一次项或一个二次项，便得到实际二阶齐次密度

$$\mathcal Q(j)=\sum_{\ell=1}^{1650}
c_\ell x_{d_\ell,i_\ell}x_{e_\ell,j_\ell},
\qquad
\mathcal B(v,w)=\mathcal Q(v+w)-\mathcal Q(v)-\mathcal Q(w).
\tag{S5.2}$$

四部门分别有 234、406、220、790 项；引力包含真实 BF、BB 和线性乘子项。$\mathcal Q=\frac12\mathcal B(j,j)$；二阶密度的这个 $1/2$ 不再重复插入 Fourier Hessian。有效使用的实一阶射流槽有 637 个，未出现的槽仍留在完整载体内。

对一项 $c x_{d,i}x_{e,j}$，(S5.2) 的极化是 $c(v_{d,i}w_{e,j}+v_{e,j}w_{d,i})$，故其 Fourier 值准确为

$$c\,\sigma_d(-p)\sigma_e(p)E_{ij}
+c\,\sigma_e(-p)\sigma_d(p)E_{ji}.
\tag{S5.3}$$

值槽的幂为零、导数槽的幂为对应四元单位幂。左导数槽的系数乘 $-1$，右槽不变；两幂相加。因此 (S5.3) 与原 Euler 的“值偏导减散度”规则相同。逐项相加保持矩阵，交换两个项的次序保持和；合并同一 $(i,j,\text{四元幂})$ 只把系数相加，也保持矩阵。用这三条代数规则典范化两个有限项表后，全部非零项及 $\mathbb Q(\sqrt2,\sqrt{15})$ 系数相同。这给出原 3071 项矩阵和 (11.2) 的完整恒等式，而不是把目标 Hessian 当作输入。

### S5.2 留数通量的差商证明

固定 $b,n$ 和已生成简单极点范围内的 $\varepsilon$，简记 $s_0=s_b$、$K(s)=K(p_\varepsilon(s,n))$、$G(s)=G(p_\varepsilon(s,n))$。原恢复矩阵给两侧方程

$$K(s)G(s)=I-Q_s(s),\qquad
G(s)K(s)=I-Q_f(s),
\qquad RQ_s(s_0)=0.
\tag{S5.4}$$

$Q_s,Q_f$ 分别是完整原零模源投影与零模场投影，由原多项式恢复矩阵生成，在极点处连续。$(s-s_0)G(s)\to R$，而 $K$ 是可微的原多项式矩阵。将前两式乘以 $s-s_0$ 并取极限，得 $K(s_0)R=RK(s_0)=0$。于是对 $s\ne s_0$，

$$R\frac{K(s)-K(s_0)}{s-s_0}\bigl[(s-s_0)G(s)\bigr]
=R(I-Q_s(s)).
\tag{S5.5}$$

左侧趋于 $RK'(s_0)R$；右侧保留实际变化的 $Q_s(s)$ 后趋于 $R(I-Q_s(s_0))=R$。这证明 (11.6)，且未在差商中删除约束源。

由 $R K'R=R$，$(RK')^2=RK'$。原左读口的简单极点余子式分解给 $R=v_b\ell_b$，其非零极化位于原活跃场像空间内，故零模场读数为零。于是 $RJ=v_b\ell_b(J)$，非零等价性由 $v_b\ne0$ 得到。物理频率及正时钟的链式变换再直接给 (11.9)–(11.11)。

### S5.3 完整 Schur 式怎样产生全方向半径

把原全场恢复矩阵记为 $F(p)$，原正则／接触部分记为 $A(p)$，反射恢复矩阵记为 $F(-p)^{\mathsf T}$；它们在零动量连续，$F(0)=F_0$。完整静态五方向核的补齐逆记为 $B(r,n)^{-1}$。原 Schur 式是

$$r^2G(0,irn)=r^2A(0,irn)
-F(0,irn)B(r,n)^{-1}F(0,-irn)^{\mathsf T}.
\tag{S5.6}$$

原静态域生成常数 $M_G,M_E$，使所有单位 $n$ 上

$$\|B(r,n)^{-1}-\widetilde G_0\|\leq2M_G^2M_Er,
\qquad \widetilde G_0=G_0+I-\Pi_5.
\tag{S5.7}$$

这是有限核的原误差界：$\|B(r,n)-B(0,n)\|\leq M_Er$、$\|B(0,n)^{-1}\|\leq M_G$；在原域内 $M_GM_Er\leq1/2$，Neumann 级数给 $\|B(r,n)^{-1}\|\leq2M_G$，逆差恒等式给 (S5.7)。各项系数及 $|n_i|\leq1$ 生成同一个 $M_E$。$F(p)\Pi_5=F(p)$，所以补空间 $I-\Pi_5$ 在 (S5.6) 的极限收缩中为零。

由于 $\|(0,irn)\|\leq r$，$F,A$ 及反射恢复矩阵在原点的连续性分别给所有方向共用的半径。乘法与相减在有限矩阵范数中连续，将这些半径与 (S5.7) 的半径取最小，得到 (12.2)。具体可先给 Schur 读口选择输入误差 $\delta>0$，再取

$$r_* =\min\left(\delta,r_F,r_A,r_{F^-},
\frac{\delta}{1+2M_G^2M_E}\right)>0.
\tag{S5.8}$$

这控制五个实际输入 $(r,A,F,B^{-1},F^-)$ 同时靠近其零动量值。取输出误差 1 后，三角不等式给 $\|r^2G\|\leq1+\|S_0\|$，即 (12.3) 的源预算。

### S5.4 Newton 卷积与两个真实去规极限

若 $\phi$ 为 Schwartz 波包，近原点用 $\sup|\phi|$，球坐标中的 $r^2dr$ 支付 $r^{-2}$；远处用 $|\phi(\xi)|\leq C_m(1+|\xi|)^{-m}$，取 $m>3$。因此

$$\int\frac{|\phi(\xi)|}{|2\pi\xi|^2}\,d\xi<\infty,
\qquad
\int\frac{|f_\phi(x-y)|}{|y|}\,dy<\infty.
\tag{S5.9}$$

第二式利用逆 Fourier 变换仍保持 Schwartz 类，平移及反射亦保持该类，原点的 $r^{-1}$ 局部可积。有限矩阵值积分可逐项定义；(S5.9) 与统一矩阵范数界同时给出其 Bochner 可积性。

取 $d>0$，用同一个正 Gaussian 表示

$$\frac1{|k|^2+d^2}=\int_0^\infty e^{-t(|k|^2+d^2)}\,dt,
\qquad
\mathcal F^{-1}\bigl(e^{-t|2\pi\xi|^2}\bigr)(y)
=(4\pi t)^{-3/2}e^{-|y|^2/(4t)}.
\tag{S5.10}$$

两侧的 Fubini 交换由 $d>0$、Gaussian 积分与 Schwartz 的 $L^1$ 性支付。因此规整 Fourier 积分等于 $g_d*f_\phi$，其中

$$g_d(y)=\int_0^\infty e^{-d^2t}(4\pi t)^{-3/2}
e^{-|y|^2/(4t)}\,dt
=\frac{e^{-d|y|}}{4\pi|y|}\quad(y\ne0).
\tag{S5.11}$$

最后一个等号也可直接算出：设 $a=d|y|/2$，代换 $u=|y|/(2\sqrt t)$ 后只需 $I(a)=\int_0^\infty e^{-u^2-a^2/u^2}du$。对 $a>0$ 求导，再作 $v=a/u$，得到 $I'(a)=-2I(a)$；在零处的 Gaussian 支配给 $I(0)=\sqrt\pi/2$，故 $I(a)=(\sqrt\pi/2)e^{-2a}$。这正是 (S5.11) 的常数。

当 $d\downarrow0$，频率侧由 (S5.9) 第一式支配，空间侧由第二式及 $|g_d(y)|\leq(4\pi|y|)^{-1}$ 支配。两侧分别趋于原无质量 Fourier 积分与 (12.5)，从而相等。$k=2\pi\xi$ 与原三维体积始终一起使用，所以 Fourier 只带来这一次 $4\pi$。

### S5.5 二粒子创建源、联合返回及移动支配

原单位范数背景态 $b$ 的源闭盒内，标量系数 $c_{12}$ 在真空值 1 附近满足 $|c_{12}|\geq1/2$。未占据色模式满足 $a_{02}b=0$。原 CAR 因而给

$$a_{02}a^\dagger_{10}(\Phi)b=\overline{c_{12}}\,b,
\qquad
\|b\|^2\leq4\|a^\dagger_{10}(\Phi)b\|^2.
\tag{S5.12}$$

这里的范数使用原物理配置半密度；先逐配置积分，再由稠密光滑核的连续性把下界扩到原闭准备载体。$\|a_{02}\|\leq1$ 与系数下界给第二式。实际修饰创建算子还乘以原非零字符 $i/2$，所以创建态严格非零，其自身范数给出唯一正实归一因子。完整 $N=2$ 态与不变背景态的原生超荷读数 $-2,-1$ 由同一 CAR 增量与单位范数直接读出。

在固定事件的非实能量上，有限全保留 Yukawa 预解逆及原场顶点对转移动量连续，原测试近似也是连续线性映射。因此 (12.9) 每一项连续，并且两端收缩 $L(k,M)$ 联合连续。给定输出误差 $\eta$，先在 $(0,S_0)$ 的一个共同邻域中控制 $L$，再由 (12.2) 控制矩阵并用 $\|rn\|\leq r$ 控制转移，便得到全方向的 $L(rn,r^2G)\to L(0,S_0)$。误差取 1 生成 $B_{DS}$ 和正半径；随后 (12.11) 的支配收敛完全使用这项实际源生成预算。

若 $Q_{\rm joint}u=\frac12u+v$ 为同一原联合荷的输入返回，记 $V_i(k)$ 为 (12.9) 的双腿电流顶点，则原联合电流的输入交叉项为

$$I_e(k)_i=\langle v,V_i(k)u\rangle+\langle u,V_i(k)v\rangle,
\quad
\Xi_e=I_e+J_e^{\rm bg}-J_e^{\rm bg,Q}.
\tag{S5.13}$$

$J^{\rm bg,Q}_i=\langle Q_{\rm joint}b,V_i b\rangle+\langle b,V_iQ_{\rm joint}b\rangle$。将 $Q_{\rm joint}u$ 代入两侧期望，$1/2+1/2$ 给出实际激发态电流，再减去原带电背景电流，恰得 $J^{\rm joint}=J+\Xi$。对这两个完整原返回作双线性展开就是 (12.12)，同时保留两条交叉返回项与余项自乘项。

### S5.6 三费米子（$N=3$）的完整响应、规范投影及系数

原命名模式满足母 CAR 的 $\{a_i,a_j^\dagger\}=\delta_{ij}$。令 $\Omega_d$ 为分支真空，$\pi$ 遍历三个颜色的排列，原三重积为

$$\begin{aligned}
\epsilon_d(s_0,s_1,s_2)&=\sum_\pi\operatorname{sgn}(\pi)
a^\dagger_{d,(s_0,\pi_0,0)}
a^\dagger_{d,(s_1,\pi_1,0)}
a^\dagger_{d,(s_2,\pi_2,1)}\Omega_d,\\
q_d^{(3)}&=\tfrac13\bigl[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)\bigr].
\end{aligned}
\tag{S5.14}$$

从右向左用 CAR 消去三次产生算子，两个三重积的内积就是 $3\times3$ 的 Kronecker Gram 行列式。第一项有六个正交单位占据词，范数平方 6；第二项的前两自旋重复，交换两色的两项合成同一个带系数 2 的占据词，三组给范数平方 12。两项自旋占据不同，交叉内积为零。于是 $\|q_d^{(3)}\|^2=(6+12)/9=2$。实际源剖面在 $z_*$ 为 1，故在原正配置测度中 $q_\ell\ne0$。

$R_{0,F}$ 保持每个 $(N,j)$ 层；$Y$ 保持粒子数 $N$ 并将分级指标 $j$ 加一。原 $N=3$ 载体的 $(3,4)$ 层为空，因此 $T_F^4b=0$。有限几何和给

$$\begin{aligned}
(C_F+Y-\zeta)\sum_{j=0}^{3}T_F^jb
&=q+R_{0,F}^{-1}(-T_F^4b)=q,\\
P_{3,0}\sum_{j=0}^{3}T_F^jb&=b,
\qquad
\left\|\sum_{j=0}^{3}T_F^jb\right\|^2
=\sum_{j=0}^{3}\|T_F^jb\|^2.
\end{aligned}
\tag{S5.15}$$

独立保分级基准支（$\sharp=1$）的升阶项在底扇区消失，所以其响应恰为 $b$。实际双侧逆同时给 $b\ne0,r\ne0$，原 $H_0-C_F=d_F$ 给 (13.2)。由同一源方程，字面电磁荷 $Q_{\rm E}$ 的完整响应返回为

$$Q_{\rm E}r=q_d^{\rm EM}r+
\mathfrak R_F[(\mathfrak B_FQ_{\rm E}-Q_{\rm E}\mathfrak B_F)r],
\quad q_d^{\rm EM}=(-1)^d,
\quad \mathfrak B_F=C_F+Y^{(\sharp)}-\zeta.
\tag{S5.16}$$

这精确保留有限框架压缩及 Yukawa 耦合产生的电荷混合。乘以 $\|r\|^{-1}$ 后同一返回仍在单位态上成立。

记纯规范型的原量子作用为 $\Gamma_{\mu a}(p)$。它严格保分级，故 $P\Gamma_{\mu a}=\Gamma_{\mu a}P$，$P=P_{3,0}$。$P$ 在原配置配对中自伴，给出

$$\mathcal V_{\mu a}(p;Pv,w)=\mathcal V_{\mu a}(p;v,Pw).
\tag{S5.17}$$

若一端取保分级基准支，则该端等于自身的底层响应 $b$；(S5.17) 把另一端投影到底扇区。这证明完整分子等于 (13.5) 的分子。纯规范原双线性型左共轭、右线性；正实范数归一给 $w^{\rm actual}=w^{\rm base}/(\|r_L\|\|r_R\|)$。代入 $z=\|b\|/\|r\|$ 即得 (13.6)。

还须看住完整场收缩的常数。原无直接插入场槽的零作用与全部 $F_0$ 行共同给

$$F_0^{\mathsf T}J=(e_0+e_1)w^{\rm actual},
\qquad
G_0(e_0+e_1)=\sqrt{30}
\left(-\frac9{125}e_0-\frac{67}{72}e_1\right).
\tag{S5.18}$$

因此 $-(e_0+e_1)^{\mathsf T}G_0(e_0+e_1)=\sqrt{30}(9/125+67/72)=K_*$。实际 $N=3$ 探测器读口只含一次 $(hc_b)^{-1}$，所以其完整 $S_0$ 系数是 $K_*w_D^{\rm actual}w_S^{\rm actual}/(hc_b)$。两对分别消费 (13.6) 给 (13.8)。最后，连续矩阵读口与真 Bochner 积分交换，定理 12.1 给 (13.9)；全场没有在 Fourier 返回前被简化为单一标量传播子。∎

### S5.7 标准 Maxwell 光速锥、$N=3$ 极点单位荷消去与三通道远场平衡证明

本小节给出 §11.4 定理 11.4、§12.4 定理 12.4 与 §14.1 定理 14.1 的完整自足书面证明。

**（一）多项式标准分支判据与横波 Maxwell 光速锥（定理 11.4）。** 设零钟主分母多项式非零 $D_{\mathrm{lead}}(e)\ne 0$。对任意正则实动量 $\mathbf n\in\mathbb R^3\setminus\{0\}$（满足 $D_{\mathrm{lead}}(e)(\mathbf n)\ne 0$），由修饰静态 Noether 张量的伴随商表示 $T_{\mathrm{stat}}(e,\mathbf n)_{\mu\nu}=N_{\mathrm{stat}}(e)_{\mu\nu}(\mathbf n)/D_{\mathrm{lead}}(e)(\mathbf n)$ 与式 (11.12) 通分相减，直接得到逐方向精确差商恒等式

$$T_{\mathrm{stat}}(e,\mathbf n)_{\mu\nu}
-T^{\mathrm{std}}\bigl(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\bigr)(\mathbf n)_{\mu\nu}
=\frac{\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}(\mathbf n)}{D_{\mathrm{lead}}(e)(\mathbf n)\,|\mathbf n|^4}.
\tag{S5.19}$$

若 $\mathcal R_{\mathrm{stat}}(e)=0$，式 (S5.19) 右端对全部正则 $\mathbf n\ne 0$ 为零，给出式 (11.13) 正向蕴涵。反之，设某分量 $\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}\ne 0$；因 $D_{\mathrm{lead}}(e)\ne 0$ 且 $|\mathbf X|^2\ne 0$，整环 $\mathbb C[X_1,X_2,X_3]$ 中三个非零多项式的乘积 $P=D_{\mathrm{lead}}(e)\cdot|\mathbf X|^2\cdot\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}\ne 0$，且实数嵌入像 $\mathbb R\subset\mathbb C$ 为无限集，多元多项式在无限积集 $\mathbb R^3$ 上恒为零蕴涵形式零多项式，故必存在实向量 $\mathbf n_\star\in\mathbb R^3$ 使 $P(\mathbf n_\star)\ne 0$，即同时满足 $|\mathbf n_\star|^2\ne 0$、$D_{\mathrm{lead}}(e)(\mathbf n_\star)\ne 0$ 与 $\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}(\mathbf n_\star)\ne 0$，代入 (S5.19) 即给出 $T_{\mathrm{stat}}(e,\mathbf n_\star)_{\mu\nu}\ne T^{\mathrm{std}}(\mathbf n_\star)_{\mu\nu}$。这证毕式 (11.13) 及其构造性实阻碍方向。在整球正则图 $\eta$ 上，对任意 $\mathbf k\in\mathbb R^3\setminus\{0\}$ 取单位方向 $\mathbf n=\mathbf k/|\mathbf k|$，将 $(0,0)$ 分量 $T^{\mathrm{std}}_{00}(\mathbf n)=c_{\mathrm{temp}}(e)$ 代入扇区符号定义即得无角度平均乘子 $c_{\mathrm{temp}}(e)/|\mathbf k|^2$，接续 S5.4 的三维无质量 Newton 卷积与正标度支配极限即返回 $C_{\mathrm{EM}}^{\mathrm{gen}}(e)/|\mathbf x-\mathbf y|$。

转入动态分支：设 $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)=0$。在矩阵多项式环上，清除分母后的等式为

$$\bigl(|\mathbf k_\varepsilon|^2 M_{\mathrm{Max}}(X)\,\mathcal E^{\mathsf T}\bigr)V_{289}(X)
=\frac34\,D_0(X)\,P_{\mathrm{curr}}(X).
\tag{S5.20}$$

在 $D_0(s)\ne 0$ 的实点 $s$ 求值并乘以 $D_0(s)^{-1}$，因零钟电磁读出满足 $T_{\mathrm{EM}}(e,\varepsilon,s,\mathbf n)=D_0(s)^{-1}\mathcal E^{\mathsf T}V_{289}(s)$（由正阻尼极限 $\sigma\downarrow 0$ 逐分量收敛自 $T_{\mathrm{EM}}^{\mathrm{corr}}$），立得式 (11.15)；式 (11.16) 则由双线性展开 $j=j^{\mathrm{proj}}+j^{\mathrm{Ward}}$ 直接合并同类项得出。再设 $a$ 为实可见极点（$\operatorname{Im}a=0$）、$c=(c_1,c_2)$ 为其可见电磁通道，左乘常值嵌入 $\mathcal E$ 将 (S5.20) 第 $c_2$ 列提升为 289 维多项式向量方程 $H_{\mathrm{Max}}(X)V_{c_2}(X)=D_0(X)F_{\cdot,c_2}(X)$，其中 $H_{\mathrm{Max}}(X)=|\mathbf k_\varepsilon|^2\mathcal E M_{\mathrm{Max}}(X)\mathcal E^{\mathsf T}$。设 $D_0(X)$ 在 $X=a$ 处的根重数为 $d\ge 1$，289 维列多项式向量 $V_{c_2}(X)$ 各分量的公共 $(X-a)$ 因子重数为 $r$，写出 $D_0(X)=(X-a)^d\widetilde D_0(X)$ 与 $V_{c_2}(X)=(X-a)^r\widetilde V_{c_2}(X)$（故零钟极点模恰为 $v_{a,c}=\widetilde V_{c_2}(a)\ne 0$）；因 $a$ 是约化分式 $(\mathcal E_{c_1}^{\mathsf T}V_{c_2}(X))/D_0(X)$ 消去最大公因式后留存的可见极点，必有严格不等式 $0\le r<d$（否则 $(X-a)^d$ 整除分子使极点在约化分式中消去）。在 $\mathbb C[X]^{289}$ 无零因子模中约去 $(X-a)^r$ 并在 $X=a$ 求值，右端因 $d-r\ge 1$ 留下因子 $(a-a)^{d-r}=0$，得 $H_{\mathrm{Max}}(a)v_{a,c}=0$；再左乘 $\mathcal E^{\mathsf T}$ 并利用电磁槽 Gram 恒等式 $\mathcal E^{\mathsf T}\mathcal E=\frac34 I_4$ 与 $|\mathbf k_\varepsilon|^2\ne 0$，即证得四维齐次核方程 $M_{\mathrm{Max}}(a)(\mathcal E^{\mathsf T}v_{a,c})=0$（其空间旋度与散度直接给出齐次 Faraday 定律与磁 Gauss 定律）。

对任意四维向量 $v\in\mathbb C^4$，令横向投影为 $(\Pi_\perp(\mathbf k)v)_i=v_i-k_i(\mathbf k\cdot\mathbf v)/|\mathbf k|^2$（$i=1,2,3$）。直接展开 $M_{\mathrm{Max}}(a)v$ 的空间块，纵向项 $k_{\varepsilon,i}(\cdots)$ 被 $\Pi_\perp(\mathbf k_\varepsilon)$ 精确消去，留下纯标量倍乘恒等式

$$\Pi_\perp(\mathbf k_\varepsilon)\bigl(M_{\mathrm{Max}}(a)v\bigr)
=\bigl(\varepsilon_{\mathrm{eff}}(e)\,\omega_{\mathrm{phys}}^2-\mu_{\mathrm{eff}}(e)^{-1}|\mathbf k_\varepsilon|^2\bigr)\,\Pi_\perp(\mathbf k_\varepsilon)v.
$$

取 $v=\mathcal E^{\mathsf T}v_{a,c}$，左端因 $M_{\mathrm{Max}}(a)v=0$ 而为零；由横波传播非零条件 $\Pi_\perp(\mathbf k_\varepsilon)(\mathcal E^{\mathsf T}v_{a,c})\ne 0$，标量括号必为零。代入式 (11.14) 的刚度商 $\mu_{\mathrm{eff}}^{-1}/\varepsilon_{\mathrm{eff}}=-c_{\mathrm{temp}}/c_{\mathrm{sp}}$（因配对尺度 $\eta_{\mathrm{pair}}\ne 0$ 故 $\varepsilon_{\mathrm{eff}}\ne 0$），两边同除以 $\varepsilon_{\mathrm{eff}}|\mathbf k_\varepsilon|^2$ 即证得式 (11.17) 横波 Maxwell 光速锥恒等式。而在尚未假定 $\mathcal R_{\mathrm{dyn}}=0$ 的一般可见实根 $s$ 上，只要满足铅笔钟平衡性、电磁列钟有限性及可见根处清分母多项式非零 $d_{\mathrm{clear}}(s)\ne 0$，记 $N=\sqrt{54/125}$ 为式 (1.1) 背景时间余标架流逝系数（故树级原生规范波速平方为 $v_{\mathrm{nat}}^2=N^{-2}=125/54$，区别于粒子数指标）、$\mathcal E_{\mathrm{rest}}$ 为非规范二形式辅助场的 217 槽嵌入、$\mathcal C_{\mathrm{comp}}(p,Q_0,v_{\mathrm{mode}})$ 为完整 289 维量子极化与背景混合反馈向量，将横向投影作用于原生主部受迫平衡方程即在任意非零横向分量 $i$ 上给出精确反馈速度定价公式：

$$v_{\mathrm{phase}}^2(\varepsilon,s,\mathbf n)
=v_{\mathrm{nat}}^2
+\frac{\bigl[\Pi_\perp(\mathbf k_\varepsilon)\bigl(\mathcal E_{\mathrm{rest}}^{\mathsf T}\mathcal C_{\mathrm{comp}}(p,Q_0,v_{\mathrm{mode}})\bigr)\bigr]_i}
{2N\,|\mathbf k_\varepsilon|^2\,\bigl[\Pi_\perp(\mathbf k_\varepsilon)(\mathcal E^{\mathsf T}v_{\mathrm{mode}})\bigr]_i}.
\tag{S5.21}$$

**（二）三费米子（$N=3$）极点库仑包与 $|Q_e|^2=1$ 消去（定理 12.4）。** 极点时间库仑包定义为 $\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)=Q_{DS}^{\mathrm{pole}}\cdot\eta_{\mathrm{pair}}^2\mathcal P_{\mathrm{sec}}(e_F,00,\eta,\phi,\mathbf x)$。在 $D_{\mathrm{lead}}(e_F)\ne 0$ 与 $\mathcal R_{\mathrm{stat}}(e_F)=0$ 下，由（一）已证整球标准卷积等式提取常数因子 $Q_{DS}^{\mathrm{pole}}$ 进入三维 Lebesgue 积分（其中波包逆 Fourier 核即式 (12.4) 的 $f_\phi=\mathcal F^{-1}\phi$），立得式 (12.15)，正标度收敛由扇区 Fourier 返回乘以常数 $Q_{DS}^{\mathrm{pole}}\eta_{\mathrm{pair}}^2$ 直接继承。当 $c_{\mathrm{phys}}(e_F)>0$ 时，因 $h_{\mathrm{src}}>0$，分母 $n_F=h_{\mathrm{src}}c_{\mathrm{phys}}(e_F)>0$ 可逆。由命题 9.1 源内已证的电子 Noether 单位荷 $q_{e,\mathrm{Noether}}(0)=q_e=1$，有 $q_{e,\mathrm{Noether}}(0)^2=1^2=1$，故

$$\alpha_{\mathrm{pole}}(e_F)
=\frac{1^2\cdot C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{n_F}
=\frac{C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)}.
\tag{S5.22}$$

将式 (12.15) 两端同乘 $n_F^{-1}$，把常数 $n_F^{-1}$ 移入积分号并应用代数结合律 $(Q_{DS}^{\mathrm{pole}}C_{\mathrm{EM}}^{\mathrm{gen}}/|\mathbf y|\cdot f_\phi)n_F^{-1}=Q_{DS}^{\mathrm{pole}}(C_{\mathrm{EM}}^{\mathrm{gen}}/n_F)/|\mathbf y|\cdot f_\phi$，代入 (S5.22) 即证得式 (12.16)。

**（三）静态电流三通道分解与两步远场同阶平衡（定理 14.1，`L29`）。** 对任意满足 $\sigma>0$ 且修正行列式非零的 $(\kappa,\sigma,\mathbf n)$，完整修正静态场精确分解为原生场、$G\cdot Q_{\mathrm{freq}}$ 反馈场与九维零模提升场三项之和：

$$X_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)
=X_{\mathrm{nat}}(\kappa,\mathbf n)
+G(p_{\kappa,\mathbf n})\,Q_{\mathrm{freq}}(\kappa,\sigma,\mathbf n)\,Y_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)
+L_{\mathrm{null}}(p_{\kappa,\mathbf n})\,c_{\mathrm{null}}(\kappa,\sigma,\mathbf n).
\tag{S5.23}$$

左乘探测器复合流 $J_{\mathrm{comp},D}^{\mathsf T}$ 即得式 (14.1) 三通道恒等式。对原生通道，双线性矩阵读口 $\mathcal M_{DS}(M)=J_{\mathrm{comp},D}^{\mathsf T}MJ_{\mathrm{comp},S}$ 为有限维矩阵空间上的连续线性算子；将其算子范数不等式 $|\mathcal M_{DS}(\kappa^2G)|\le\|\mathcal M_{DS}\|\cdot\|\kappa^2G\|$ 与 S5.3 建立的全方向一致支配界 $\|\kappa^2G(p_{\kappa,\mathbf n})\|\le B_{\mathrm{whole}}$（$0<\kappa<r_{\mathrm{nat}}$，$|\mathbf n|=1$）相乘，立得方向无关预算界 (14.2) 第一式，而连续性复合静态留数极限给出 $-\kappa^2\mathcal R_{\mathrm{nat}}\to C_{\mathrm{nat}}$。

在有限长程返回支（$D_{\mathrm{IR}}(e,\mathbf n)\ne 0$、静态钟阶可除性及全部 17 个分式原点极点阶 $\le 4$）上，有序静态图定理保证对充分小的 $\kappa\in\mathcal D_{\mathrm{stat}}$，完整探针在 $\sigma\downarrow 0$ 时满足 $\mathcal R_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)\to\mathcal R_{\mathrm{probe}}^{(0)}(\sqrt\kappa,\mathbf n)$；因 $\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)$ 与 $\sigma$ 无关，由式 (14.1) 移项取 $\sigma\downarrow 0$ 极限即证得式 (14.3) 第一式 $\mathcal R_{\mathrm{fb}}+\mathcal R_{\mathrm{null}}\to\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)$。接着在 $\kappa\downarrow 0$ 时，有序库仑返回定理给出 $-\kappa^2\mathcal R_{\mathrm{probe}}^{(0)}(\sqrt\kappa,\mathbf n)\to C_{\mathrm{ord}}(e,\mathbf n)$；与已证原生极限 $-\kappa^2\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)\to C_{\mathrm{nat}}$ 相减，即证得

$$\lim_{\kappa\downarrow 0}\bigl[-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)\bigr]
=C_{\mathrm{ord}}(e,\mathbf n)-C_{\mathrm{nat}}
=:C_{\mathrm{fb+null}}(e,\mathbf n),
\tag{S5.24}$$

取输出误差 $\eta=1$ 的邻域即得一致支配界 $|-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)|\le 1+|C_{\mathrm{ord}}(e,\mathbf n)-C_{\mathrm{nat}}|$，移项即得同阶远场系数守恒律 $C_{\mathrm{ord}}(e,\mathbf n)=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}(e,\mathbf n)$（式 (14.4)）。∎

正文与本卷的 [公开证明映射](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-map.json) 和 [复现说明](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-reproduction.md) 固定在同一个公开版本。

## 参考文献

[1] Gao, J. *From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*（《从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成》）. CourtyCourt · Case 0, Zenodo, v3 (2026), DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339)（第一版 v1 DOI: [10.5281/zenodo.23210292](https://doi.org/10.5281/zenodo.23210292)）.

[2] Gao, J. *Low-Energy Electromagnetic Emergence from a Zero-Knob Unified Source: Coupled Propagation, Unit Electron Charge, the Maxwell Cone, and $1/(4\pi r)$ Coulomb Return*（《零旋钮统一场的低能电磁涌现：耦合传播、电子单位电荷、Maxwell 光速锥与 $1/(4\pi r)$ 库仑返回》，主文；第一版已发表记录 DOI: [10.5281/zenodo.23299174](https://doi.org/10.5281/zenodo.23299174)）. CourtyCourt · Case 1 (2026).
