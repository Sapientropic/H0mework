# 零旋钮统一场的低能电磁涌现：耦合传播、电子单位电荷、Maxwell 光速锥与 $1/(4\pi r)$ 库仑返回

# Low-Energy Electromagnetic Emergence from a Zero-Knob Unified Source: Coupled Propagation, Unit Electron Charge, the Maxwell Cone, and $1/(4\pi r)$ Coulomb Return

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**形式验证与证据层级。** 本文（CourtyCourt · Case 1，第二版 v2；第一版已发表记录见 `10.5281/zenodo.23299174`）承接同系列物理旗舰第三版 [1] 的零可调旋钮统一场母作用，统合 `L1-L29` 全部命题与自足书面证明。正式机器证明在 Lean 4（`v4.33.0`）[32] 内核中完成：实空间演化、Bochner–Fourier 积分、谱预解与极点留数层的完整公理闭包严格限于命题外延性、经典选择与商健全性三条标准公理（`[propext, Classical.choice, Quot.sound]`），全程无 `sorry`、无 `unsafe/partial` 项、无任何自定义物理公理或外部精细结构常数输入；大维有理多项式传播目录与四阶相位展开配套独立精确有理数核验回执。逐项固定来源、声明入口与复现命令见附录 B 与“代码与数据可得性”；多页传播目录、算子接口与逐步骤长程推导见随附《补充材料》（S1–S5）。

## 摘要

在不引入外设电磁耦合常数、手调电荷单位或先验光速标尺的零可调旋钮（zero-knob）统一场论中，本文从固定 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 母作用 [1] 的九场耦合动力学出发，纯演绎地导出三维强连续物质传播、全时间因果 Kubo 响应、电子绝对单位电荷 $|Q_e|=1$、横波 Maxwell 光速锥、三维实空间 $1/(4\pi|\mathbf x-\mathbf y|)$ 库仑势、三费米子（$N=3$）四端 Born 重叠修饰及三通道远场反馈平衡。在受约束传播与实空间量子演化层，我们证明空间齐次九场非线性系统在允许域上具有共同局部 Lipschitz 解族与初值 Fréchet–Jacobi 导数；将 289 维实一阶射流二次作用经三次辅助消元、9 条标量力矩 Ward 约束与 9 个规范—Lorentz 对称方向无分母归约为 103 维忠实传播截面（分解为 79 维正则制备商与 24 维独立对偶补空间）并逐行恢复原 289 条场方程，零自由低能常数算出向量与轴向两相位的四阶有理色散及五／六阶精确多项式余项，由全部 158 个物质耦合顶点导出含 Einstein–Cartan 轴矢接触项 $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ 的 42 位有理数在壳树交换、Hodge 本构比 $N^2=54/125$ 及单世代一圈逆耦合无公共单点交点判据；进而在固定背景 $L^2(\mathbb R^3,\mathbb C^{12})$ 上双向锁定占据态 Dirac 算子的自伴定义域，证明任意紧区间有界范数连续自伴规范控制历史生成全实时间、全实幅度 $\epsilon\in\mathbb R$ 幺正演化群，由单位球一致二阶余项界 $\epsilon^2M^2|t|^2$ 在 $\epsilon=0$ 处取出算子范数 Fréchet 导数，同时恢复全部有限反对易（CAR）词矩正性与全时间因果 Kubo 响应。

在低能电磁涌现与实空间长程返回层，未破缺电磁生成元 $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ 在标量—物质外代数上给出相对修饰联合字符 $\pm 1/2$，而在实际带电费米通道（$e=0$）的物理静止电子态上无条件证出绝对单位电荷 $|Q_e|=1$ 与原生时间流 $-1$，保留全部 64 项零动量自旋—边权重、有向年龄窗与三项有限能量截腿残差导出一次库仑标量种子 $K_*=\frac{9023}{9000}\sqrt{30}$ 及在壳光子极点响应。我们证明全部 289 场方向上的混合电磁载体精确等于母作用 1650 项一阶射流二阶 Fréchet 变分 Hessian，且在任意正时钟尺度重标 $t'=ct$ 下保持极点留数与 Jacobi 导数的通量乘积恒等式；无需角度平均，非奇异主分母下的 16 项多项式余项判据充要刻画整球标准电磁分支（违背时存在正则实动量阻碍方向），并将每个实可见横波传播极点模严格锁定在 **Maxwell 光速锥** $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$ 上。对 Schwartz 空间波包输入，全方向 Schur 算子范数红外半径与相反动量转移下的三维矩阵 Bochner–Fourier 积分对静止电子、移动二粒子（$N=2$）连通流及整球标准静态分支中满足全场连续性方程的三费米子（$N=3$）物理能量极点包一致返回**单 $4\pi$ 因子实空间库仑核 $1/(4\pi|\mathbf x-\mathbf y|)$**，其中 $|Q_e|^2=1$ 自动消去并给出重标不变的极点耦合算子商 $C_{\mathrm{EM}}^{\mathrm{gen}}/(h_{\mathrm{src}}c_{\mathrm{phys}})$。三费米子四分级完整响应自产位于 $(0,1]$ 的底层 Born 重叠振幅 $z_\ell$，当探测器对与源对各自至少含一端保分级基准腿时精确给出 $C_{\mathrm{full}}=ZC_{\mathrm{base}}$；完整静态电流回路进一步恒等分解为原生 Green、量子反馈与九约束零模三通道，并在先阻尼 $\sigma\downarrow 0$ 后动量尺度 $\kappa\downarrow 0$ 的两步有序远场极限下严格保持$O(\kappa^{-2})$ 系数平衡。

**关键词：** 零旋钮统一场；低能电磁涌现；电子单位电荷；横波 Maxwell 光速锥；实空间库仑势；Born 重叠修饰；受约束场传播；算子范数 Kubo 响应。

## Abstract

Within a parameter-free (zero-knob) unified field theory introducing no external electromagnetic coupling constant, hand-set charge unit, or postulated speed of light, we derive deductively from the nine-field coupled dynamics of the fixed $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ mother action [1] three-dimensional strongly continuous matter propagation, all-time causal Kubo response, the absolute unit electron charge $|Q_e|=1$, the transverse Maxwell dispersion cone, the real-space $1/(4\pi|\mathbf x-\mathbf y|)$ Coulomb potential, four-leg Born overlap dressing for three-fermion ($N=3$) composites, and three-channel far-field feedback balance. At the level of constrained propagation and real-space quantum evolution, we establish a uniform local Lipschitz nine-field solution family with Fréchet–Jacobi initial-data derivatives, reduce the 289-component real first-jet quadratic action without momentum denominators via three auxiliary eliminations, nine scalar-torque Ward constraints, and nine gauge–Lorentz symmetry directions onto a faithful 103-dimensional propagation section ($79$ canonical prepared modes $\oplus\ 24$ independent-dual complement modes) with exact 289-row field reconstruction, compute parameter-free fourth-order rational dispersions and exact fifth/sixth-order polynomial remainders for the vector and axial soft phases, and obtain from all 158 matter vertices an exact 42-digit action-normalized on-shell tree exchange incorporating the Einstein–Cartan axial contact $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$, the Hodge constitutive ratio $N^2=54/125$, and the absence of a single-point one-loop inverse-coupling intersection. On $L^2(\mathbb R^3,\mathbb C^{12})$, we characterize the exact self-adjoint domain of the occupied Dirac generator, construct all-real-time and all-real-amplitude ($\epsilon\in\mathbb R$) unitary evolution under locally bounded norm-continuous self-adjoint gauge controls, prove a uniform unit-ball remainder bound $\epsilon^2M^2|t|^2$ yielding the operator-norm Fréchet derivative at $\epsilon=0$, and recover positivity across all finite CAR words together with the causal Kubo commutator response.

At the level of emergent electrodynamics and long-range spatial return, the unbroken electromagnetic generator $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ assigns dressed joint characters $\pm 1/2$ to scalar–matter pairs while unconditionally locking the physical rest electron leg on the charged fermionic channel ($e=0$) to unit electromagnetic charge $|Q_e|=1$ and native temporal current $-1$; retaining all 64 rest-spinor weights, oriented age windows, and three finite-parameter leg-amputation residuals yields the static Coulomb seed $K_*=\frac{9023}{9000}\sqrt{30}$ and the on-shell photon pole response. We prove that the mixed electromagnetic carrier across all 289 field directions equals the exact 1650-monomial first-jet Fréchet Hessian of the mother action and preserves its residue–Jacobi flux identity under every positive clock rescaling $t'=ct$. Without angular averaging, sixteen-entry polynomial remainder criteria under a nonvanishing leading denominator characterize the whole-sphere standard electromagnetic branch—producing a regular real obstruction direction whenever violated—and lock every real visible transverse pole mode onto the **Maxwell light cone** $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$. For Schwartz wavepacket inputs, uniform all-direction Schur infrared domination and three-dimensional matrix Bochner–Fourier integration across opposite momentum transfers return the **single-$4\pi$ real-space Coulomb kernel $1/(4\pi|\mathbf x-\mathbf y|)$** for rest electrons, moving two-particle ($N=2$) connected currents, and Maxwell-conserved three-fermion ($N=3$) energy-pole packets, where $|Q_e|^2=1$ cancels automatically to leave the rescaling-invariant pole coupling quotient $C_{\mathrm{EM}}^{\mathrm{gen}}/(h_{\mathrm{src}}c_{\mathrm{phys}})$. Unit normalization of four-grade $N=3$ composite responses endogenously generates ground-sector Born overlaps $z_\ell\in(0,1]$ whose four-leg product $Z$ satisfies $C_{\mathrm{full}}=ZC_{\mathrm{base}}$ whenever each endpoint pair contains at least one grade-preserving reference leg; finally, the complete static current circuit splits identically into native Green, quantum-feedback, and nine-constraint null channels that maintain $O(\kappa^{-2})$ coefficient balance under the ordered far-field limit ($\sigma\downarrow 0$ followed by $\kappa\downarrow 0$).

**Keywords:** zero-knob unified field theory; emergent electrodynamics; unit electron charge; transverse Maxwell cone; real-space Coulomb potential; Born overlap dressing; constrained field propagation; operator-norm Kubo response.

<a id="sec-1"></a>

## 1 引言：一条电流的三重证词与零旋钮电磁涌现

把大矩阵消元变小并不难；真正严苛的问题在于：降维后的有效算子报出的读数，是否仍是原始统一作用量对原始物质所作的精确读数？在不允许引入外设电磁耦合常数 $e$、手调超荷比例或人为指定光速常数 $c$ 的零可调旋钮统一场论 [1] 中，低能电动力学的全部定性结构与定量系数都必须经受同一场测试——每一次消去辅助场、压缩子空间、切换物理时钟或执行三维 Fourier 积分，都必须保留精确返回原始 289 维场方程与独立旋量对偶配对的逆映射。

在展开 289 维受约束场与 504 模多体空间之前，本文先传唤一个三分钟即可在纸上算完的四维不变窗口电流。它将当庭作证三次：一次作为有限非线性控制幅度演化的精确期望值，一次作为真实演化态对控制幅度的双腿导数，一次作为未扰动海森堡对易子的有向时间积分；紧接着再核验一组两行即可算清的电磁电荷与静态库仑有理数恒等式。所有初态、推动力、作用电流与电荷权均由同一原始母作用唯一锁定。

### 1.1 三分钟纸笔锚点（一）：从十二维占据态取出四维不变窗口

取母作用固定常数

$$s=\sqrt2,\qquad N^2=\frac{54}{125},\qquad
\alpha_0=\frac{3\sqrt2}{5},\qquad
\omega=\frac{3N}{2}(s-\alpha_0)=\frac{18\sqrt{15}}{125}>0.\tag{1.1}$$

这里 $t$ 是原始时间坐标，$N$ 是背景余标架的时间流逝系数（lapse），$s$ 是轴向自旋联络幅度，$\alpha_0$ 是空间规范势幅度（对应 [1] 中的自旋—规范幅度记号 $(k,a)\mapsto(s,\alpha_0)$，避免下文与空间动量 $\mathbf k$ 及尺度因子 $a$ 重名）。需要在一开始就指明：**式 (1.1) 中的四个数绝非人为挑选的自由参数**；同系列物理旗舰 [1，定义 2.1、命题 2.2–2.4、定理 4.4] 已从零拟合正光滑发生源出发，证出本构比 $\sigma=1/2$ 及满足经典世界准入与历史弱恢复的九场解唯一，其驻定立方平衡 $\alpha_0^3=2\sigma N^2s=N^2s$ 与比例 $\alpha_0/s=3/5$ 直接锁死式 (1.1) 的全部数值（完整九场构型见 §2.3，空间齐次邻域内任意允许初值的非线性演化见 §3.1）。将四分量 Dirac 旋量张量以包含背景前两色二重态与第三色完备方向的三色外幂切片（从而把 [1] 的八维手征占据核自然嵌入完备三色空间），得到十二维原始物质占据空间

$$\mathcal H_{12}=\mathbb C^4\otimes\operatorname{span}\{e_{05},e_{15},e_{25}\}.$$

按自旋优先、颜色次之的坐标序，单位占据向量为

$$w=\frac12(0,1,0,-1,0,0,0,1,0,-1,0,0)^{\mathsf T}.
\tag{1.2}$$

原场在零时刻的幅度是 $\psi_0=2w$。记手征矩阵 $Q=\operatorname{diag}(-1,-1,1,1)\otimes I_3$，选择原色生成元

$$\rho_{01}=\begin{pmatrix}0&1&0\\-1&0&0\\0&0&0\end{pmatrix}.$$

它在时间规范联络中产生的哈密顿推动力算子 $T$ 与母作用变分电流算子 $B$ 分别为

$$T=-iI_4\otimes\rho_{01},\qquad B=-sQT.\tag{1.3}$$

两者都是厄米算子，却绝不是同一个算子：$T$ 决定量子态如何随时间受控演化，$B$ 则读取母作用中独立复线性对偶 $\chi$ 对规范变分的一阶电流；因子 $-sQ$ 精确承载了独立对偶翻转配对与原始时间动能权重。

令 $r=Tw$、$q=Qr$、$p=Qw$。四列 $F=(w,r,q,p)$ 标准正交，并同时构成定常哈密顿量 $h_0$、$T$ 与 $B$ 的公共不变子空间。在这个由原态生成的正交归一基中，

$$F^\dagger h_0F=
\begin{pmatrix}0&0&0&0\\0&0&2\omega&0\\0&2\omega&0&0\\0&0&0&0\end{pmatrix},
\qquad
F^\dagger TF=
\begin{pmatrix}0&1&0&0\\1&0&0&0\\0&0&0&1\\0&0&1&0\end{pmatrix}.
\tag{1.4}$$

再取 $Q$ 的正、负本征组合 $(w+p,r+q,w-p,r-q)/\sqrt2$，系统化为两个正交的 $2\times 2$ 块：

$$h_{0,+}=\begin{pmatrix}0&0\\0&2\omega\end{pmatrix},\quad
h_{0,-}=\begin{pmatrix}0&0\\0&-2\omega\end{pmatrix},\quad
T_\pm=\sigma_x,\quad B_\pm=\mp s\sigma_x.
\tag{1.5}$$

初态在两块中各为 $2^{-1/2}(1,0)^{\mathsf T}$。这个四维窗口不是外置嫁接的二能级玩具模型，而是十二维占据态算子的精确同时不变子空间。

### 1.2 三分钟纸笔锚点（二）：有限控制先于线性响应，以及单位电子荷与库仑有理数种子

**第一份证词来自有限幅度精确演化。** 给时间规范联络施加任意实控制幅度 $\epsilon\in\mathbb R$，两块的完整哈密顿量为

$$h_{\epsilon,\pm}=\pm\omega I+\epsilon\sigma_x\mp\omega\sigma_z.
\tag{1.6}$$

由于无迹部分满足 $(\epsilon\sigma_x\mp\omega\sigma_z)^2=(\omega^2+\epsilon^2)I$，令 $r_\epsilon=\sqrt{\omega^2+\epsilon^2}$，即可直接写出精确矩阵指数：

$$U_{\epsilon,\pm}(t)=e^{\mp i\omega t}
\left[\cos(r_\epsilon t)I-i\frac{\sin(r_\epsilon t)}{r_\epsilon}
(\epsilon\sigma_x\mp\omega\sigma_z)\right].\tag{1.7}$$

对任意实数 $\epsilon,t\in\mathbb R$，式 (1.7) 精确满足初值条件与有限控制微分方程。将其作用于两块初态并按式 (1.5) 的 $B_\pm=\mp s\sigma_x$ 求和，立得有限控制电流

$$\boxed{J_\epsilon(t)=
\frac{s\epsilon\omega}{\omega^2+\epsilon^2}
\left[1-\cos\!\left(2t\sqrt{\omega^2+\epsilon^2}\right)\right].}
\tag{1.8}$$

对 $\epsilon$ 在零控制点求导，得到有限演化解族的真实参数导数：

$$\boxed{\left.\partial_\epsilon J_\epsilon(t)\right|_0
=\frac{s}{\omega}(1-\cos 2\omega t).}\tag{1.9}$$

注意这里的逻辑次序：**先构造全实轴有限幅度解，再在 $\epsilon=0$ 处求真导数**；非线性拉比频率 $r_\epsilon=\sqrt{\omega^2+\epsilon^2}$ 随控制幅度的偏移已完整包含在式 (1.8) 中。此处 $J_\epsilon$ 采用单位占据态 (1.2)；原场幅度 $\psi_0=2w$ 的双线性电流恰为其 4 倍。

**第二份证词来自态矢双腿变分与两处当场露馅的反控。** 在原基 $(w,r,q,p)$ 中，零控制态保持为 $w$，态矢一阶变分为

$$\delta u(t):=\left.\partial_\epsilon U_\epsilon(t)w\right|_0
=-i\frac{\sin2\omega t}{2\omega}r
+\frac{\cos2\omega t-1}{2\omega}q.\tag{1.10}$$

因 $Bw=-sq$，电流期望值的左右两条腿共同给出

$$\delta u(t)^\dagger Bw+w^\dagger B\delta u(t)
=\frac{s}{\omega}(1-\cos2\omega t).\tag{1.11}$$

这里立即出现两道结构反控：若只对单侧态腿求导，系数当场折半；若把母作用电流算子 $B=-sQT$ 误换作推动态演化的力算子 $T$，正负手征两块的响应便精确反号抵消为 $0$。算对幺正演化指数，远不足以保证读对母作用电流。

**第三份证词来自海森堡对易子有向积分。** 用未扰动群 $U(t)=e^{-ith_0}$ 记 $T_H(\tau)=U(-\tau)TU(\tau)$、$B_H(t)=U(-t)BU(t)$，由式 (1.4) 算得

$$\operatorname{Re}\,i\langle w,[T_H(\tau),B_H(t)]w\rangle
=2s\sin\bigl(2\omega(t-\tau)\bigr).$$

对 $\tau\in[0,t]$ 积分，得到

$$\operatorname{Re}\,i\int_0^t
\langle w,[T_H(\tau),B_H(t)]w\rangle\,d\tau
=\frac{s}{\omega}(1-\cos2\omega t),\tag{1.12}$$

与式 (1.9)、(1.11) 分毫不差，且有向积分对负时间 $t<0$ 同样成立。§8 将在无穷维空间 $L^2(\mathbb R^3,\mathbb C^{12})$ 上证明同一等式，并给出整个单位球共用的算子范数二阶余项界 $\epsilon^2M^2|t|^2$。

**纸笔锚点延伸至电磁涌现层（§9–§12）。** 读者同样只需两行算术即可预验本文后半部的电荷量子化与库仑种子常数：在七维母表示 $(c_0,c_1,c_2,w_0,w_1,h_+,h_-)$ 上，未破缺电磁生成元 $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ 的本征权为 $\bigl(-\frac12,+\frac12,0,0,0,-\frac12,+\frac12\bigr)$（§9.3 式 (9.7)）。当四指标标量 $\Phi\in\Lambda^4\mathbb C^7$ 与二指标物质 $\psi\in\Lambda^2\mathbb C^7$ 组成修饰对时，三色通道权和恒为 $\frac12+(-1)=-\frac12,+\frac12-\frac12=-\frac12$（相对修饰字符 $\pm 1/2$）；而在带电费米通道（$e=0$）的物理静止腿上，独立对偶 Noether 荷读数与时间配对满足 $a_{\mathrm{src}}h_{\mathrm{src}}=1$，无条件锁死**电子绝对单位电荷 $|Q_e|=1$** 与原生时间流 $-1$（§9.3 命题 9.1、§10.1 命题 10.1）。与此同时，289 场静态五维约化核在两条存活空间规范槽上的有理特征值逆之和给出

$$\frac{9}{125}+\frac{67}{72}=\frac{648+8375}{9000}=\frac{9023}{9000},$$

乘以 $\sqrt{30}$ 即得全文贯穿静态库仑交换与 $1/(4\pi|\mathbf x-\mathbf y|)$ 实空间返回的核心种子常数 $K_*=\frac{9023}{9000}\sqrt{30}$（定理 9.2、10.3、12.1）。

### 1.3 中心问题、四大支柱与正反可证伪门禁

本文聚焦的核心科学问题是：**在完全清除可调物理旋钮的单一 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 母作用 [1] 下，受约束九场耦合传播能否不借任何外部经验输入，纯演绎地闭合并打通三维强连续物质演化、全时间算子范数因果 Kubo 响应、电子绝对单位电荷 $|Q_e|=1$、横波 Maxwell 色散光速锥、三维实空间 $1/(4\pi|\mathbf x-\mathbf y|)$ 库仑势及多体 Born 重叠与远场反馈回路？**

全文定理链遵循一条严格的对象相接准则：**原场方程生成受约束传播，原外腿生成守恒源，原母作用生成独立对偶电流與二阶 Hessian；在真实空间准备与复合外态上，有限量子发展的算子范数导数、极点留数与三维矩阵 Bochner 积分精确返回同一母作用的电动力学读数。** 表 1 列出四大支柱（`L1-L29`）各自的输入、核心构造与可核查输出；图 1 展示前三支柱在 $\epsilon=0$ 电流响应处的精确交汇。

**表 1　全文四大支柱的输入、核心构造与演绎输出（`L1-L29`）。**

| 支柱与章节 | 严格输入 | 核心构造与关键不变量 | 演绎输出与命题范围 |
|---|---|---|---|
| **第一支柱（§2–§6，附录 A，补充材料 S1–S2）**：低能受约束传播、四阶软相位与树级物质交换 | 允许域内七个空间齐次实初值；289 维实一阶射流扰动与四动量 $p$；158 个物质耦合顶点与 216 维自由外腿 | 9 条标量力矩 Ward 行逆＋9 对称方向无分母多项式截面 $289\to 103=79\oplus 24$；77 重方向四阶递归消元；Lorentz 联络代数逆导出 ECSK 轴矢接触项 $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ | 共同局部九场解族与初值导数 $\exp(tJ_0)$；单世代跑动无公共单点交点；向量／轴向相位四阶有理色散；42 位有理数在壳树交换；Hodge 本构比 $N^2=54/125$（`L1-L11`） |
| **第二支柱（§7–§8，补充材料 S3）**：空间 $L^2(\mathbb R^3,\mathbb C^{12})$ 全时间幺正演化与算子范数 Kubo 导数 | $L^2$ 初态与任意有限测试族；紧区间有界范数连续自伴规范控制历史 $R(t)$ 与任意实幅度 $\epsilon\in\mathbb R$ | Fourier 乘子双向定义域刻画；全局有界径向 Picard 映射 $b(v)=v/(1+\|v\|)$ 与范数守恒窗口拼接；单位球一致二阶余项界 $\epsilon^2M^2\lvert t\rvert^2$ | 全实时间双时刻幺正群 $W_\epsilon(t,a)$；全有限 CAR 词矩正性与单次 $S$ 母配对读回；$\epsilon=0$ 算子范数 Fréchet 导数与全时间因果 Kubo 公式（`L12-L17`） |
| **第三支柱（§9–§11，补充材料 S4、S5.1–S5.2、S5.7）**：电子绝对单位荷 $\lvert Q_e\rvert=1$、母作用 Hessian 认回与横波 Maxwell 光速锥 | 源生配置半密度准备；带电费米通道（$e=0$）静止电子腿、64 权有向年龄窗与非实预解参数；1445 槽实一阶射流 | 修饰联合字符 $\pm 1/2$ 与静止电子整单位荷分立；1650 项二阶变分与 3071 项 $H_{289}(p)$ 全等；时钟重标 $R_cK'_c$ 不变；16 项多项式标准分支判据 | 无外部标定证出 $\lvert Q_e\rvert=1$、时间流 $-1$ 与静态种子 $K_*=\frac{9023}{9000}\sqrt{30}$；正时钟通量恒等式；无角度平均锁定横波 **Maxwell 光速锥** $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$（`L18-L26` 及标准长程扩展） |
| **第四支柱（§12–§14，补充材料 S5.3–S5.7）**：实空间单 $4\pi$ 库仑返回、$N=3$ 四端 Born 重叠修饰与三通道远场平衡 | Schwartz 波包 $\phi$；静止电子、移动 $N=2$ 连通流、$N=3$ 能量极点截面与四分级复合腿 | 全方向 Schur 红外支配半径；相反动量转移三维矩阵 Bochner 积分与正 Gaussian 去规；$(3,0)$ 底扇区正交投影；三通道回路先 $\sigma\downarrow 0$ 后 $\kappa\downarrow 0$ | 唯一单 $4\pi$ 实空间库仑卷积 $1/(4\pi\lvert\mathbf x-\mathbf y\rvert)$；$\lvert Q_e\rvert^2=1$ 自动消去与极点耦合商 $\alpha_{\mathrm{pole}}$；四端 Born 修饰 $C_{\mathrm{full}}=ZC_{\mathrm{base}}$；原生—反馈—九零模$O(\kappa^{-2})$ 远场系数平衡（`L27-L29` 及 $N=3$ 极点扩展） |

零自由度理论的可信度不靠谦辞免责建立，而靠**成对的正向全称定理与结构反例／失真门禁**建立：省去母作用要求的任何一个代数环节，定量读数都会立即发生可计算的崩塌。表 2 汇总贯穿全文的六组正反可证伪对照。

**表 2　六组成对正向定理与结构反例／失真报警门禁。**

| 检验环节 | 正向零旋钮定理（完整结构保留） | 结构反例或近似失真后果（省去单一环节） | 正文定位 |
|---|---|---|---|
| **作用电流 vs 推动力** | 双腿变分作用于独立对偶电流 $B=-sQT$ 精确给出 $\frac{s}{\omega}(1-\cos 2\omega t)$，与有限控制真导数及 Kubo 积分三路合一 | 只对单腿求导使振幅折半；把观测量 $B$ 换作哈密顿推动力 $T$ 使正负手征块响应**精确抵消为 $0$** | §1.2 式 (1.9)–(1.12)、§8.3 |
| **真规范—Lorentz 截面 vs 朴素坐标变换** | 3 个色 $\mathrm{SU}(2)$ 与 6 个 Lorentz 对称切向精确湮灭 $H_{112}(p)$，无分母多项式截面 $K_{103}$ 完整恢复 289 行场方程 | 4 个朴素坐标微分同胚候选在原符号中留下 **128 项非零残差**；余标架 Hodge 时间伸缩与普通二形式拉回相差 $-2/N\ne 0$ | §2.4 式 (2.16)–(2.17)、§4.2 命题 4.1 |
| **全词 CAR 评价 vs 过早单粒子压缩** | 四点词 $a^\dagger(u_p)a(u_p)a^\dagger(u_p)a(u_p)$ 先在反对称 Fock 空间完整乘积再经单次 $S$ 拉回母配对，精确返回 **$1$** | 若先将每个产生／湮灭算子压缩到单粒子层再相乘，中间真空层返回项丢失，读数**坍缩为 $0$** | §3.4 命题 3.4、§7.4 命题 7.3 与式 (7.16a) |
| **裸时间规范荷 vs 修饰静止电子流** | 源生完整配置协向量与静止电子腿激活空间规范槽 21 与 34 之差（$A_1^{\,0}-A_2^{\,1}$），给出 $\lvert Q_e\rvert=1$ 与非零库仑种子 $K_*=\frac{9023}{9000}\sqrt{30}$ | 仅用 12 个裸时间规范电荷源直接求解耦合静态系统，144 个条目在零动量全方向**库仑极点留数恒为 $0$** | §6.7 命题 6.3 对照 §9.4 定理 9.2、§10.4 定理 10.3 |
| **整球标准电磁分支 vs 各向异性阻碍** | 在非奇异主分母 $D_{\mathrm{lead}}(e)\ne 0$ 下，16 项多项式静态余项 $\mathcal R_{\mathrm{stat}}=0$ 无需角度平均即等价于全正则实方向标准库仑—Biot–Savart 张量，动态余项为零锁死 $v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2$ | 一旦 $\mathcal R_{\mathrm{stat}}\ne 0$（且 $D_{\mathrm{lead}}(e)\ne 0$），定理给出**正则实动量阻碍方向** $\mathbf n\in\mathbb R^3\setminus\{0\}$ 当场证伪标准张量（拒绝角度平均掩盖各向异性） | §11.4 定理 11.4、补充材料 S5.7 |
| **三通道远场回路 vs 截除反馈／零模** | 静态探针保留原生 Green、量子极化反馈与九约束零模三通道，先 $\sigma\downarrow 0$ 后 $\kappa\downarrow 0$ 严格满足 $C_{\mathrm{ord}}=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}$ | 合并修正有 $O(\kappa^{-2})$ 上界。$C_{\mathrm{fb+null}}\ne 0$ 时，省去合并项会损失这部分远场系数 | §14.1 定理 14.1、图 7、补充材料 S5.7 |

![原作用、传播与同一电流之间的关系](figures/main-01-common-current.svg)

**图 1　同一电流的来路与返回。** 左、中两列从原母作用生成空间齐次九场非线性发展和 289 维受约束耦合传播，右列从原物质作用生成 $L^2(\mathbb R^3,\mathbb C^{12})$ 空间准备与全实幅度幺正演化。朱红底框是三条路径的汇合处：母作用独立对偶电流、双侧态变分及因果 Kubo 积分在 $\epsilon=0$ 处给出同一响应。箭头携带显式的场恢复、方程恢复或源映射，不混同三个定义域。

### 1.4 载体与符号速查、分学科十五分钟验证通道及文献坐标

为降低跨章节阅读的记忆负担，表 3 集中列出全文五类核心载体的维数、物理角色及时间—频率符号约定。首次阅读时只需留意两处关键区分：（i）传播代数使用增长变量 $p=(\lambda,i\mathbf k)$（故 $\lambda^2<0$ 对应实频振荡 $\lambda=-iE$），第 7 节单粒子算子使用 $E-h(\mathbf k)$，第 9–13 节多体配置预解统一使用 $(H-zI)^{-1}$；（ii）单模外幂基的分数超荷权、标量—物质修饰对的半整数相对字符 $\pm 1/2$（§9.3）、物理静止电子腿的整单位电荷 $|Q_e|=1$（§10.1）与三费米子（$N=3$）色单态复合态的电荷 $\pm 1$（§12.4、§13）分属不同复合层级，彼此严格相容。

**表 3　核心载体、维数与预解／时间符号速查表。**

| 载体或符号 | 数学空间与维数 | 物理含义与正文位置 |
|---|---|---|
| 母物质载体 $\mathcal M$ 与独立对偶 $\chi$ | $\mathbb C^4\otimes(\Lambda^6\oplus\Lambda^2\oplus\Lambda^4)\mathbb C^7$（252 复维），$\chi\in\mathcal M^*$ | 单世代手征旋量外幂与独立复线性对偶；制备子类满足 $\chi=s\psi^\dagger S$，$S=\gamma^0\gamma^5$（§2.1–§2.2、§4.4） |
| 活跃一阶射流与忠实传播商 | $\mathbb R^{289}\to\mathbb R^{103}=\mathbb R^{79}\oplus\mathbb R^{24}$；一阶射流 $5\times 289=1445$ 实槽 | 引力—规范—标量—占据物质耦合二次作用 $H_{289}(p)$；无分母截面分解为 79 维制备动态商与 24 维对偶补块（§4.1–§4.4、§11.1） |
| 自由在壳外腿子空间 | $\mathbb C^{216}\hookrightarrow\mathcal M$（50 个二阶块＋29 个四阶块） | $Y_R(v)$ 核空间上的全动量厄米谱与留数尺度 $u_{\mathrm{action}}=2^{-1/4}u_{\mathrm{coord}}$（§6.4–§6.6） |
| 空间占据态 Hilbert 载体 $\mathscr H$ | $L^2(\mathbb R^3,\mathbb C^{12})$ 及任意有限测试族反对称张量空间 $\Lambda E$ | 背景占据子空间 $\mathcal H_{12}$ 上的自伴 Dirac 生成元 $\mathsf H$、全时间受控幺正群 $W_\epsilon(t,a)$ 与全词 CAR 读回（§7–§8） |
| 多体配置—Fock 载体 | 100 维配置流形半密度 $\times$ 504 模实／双支 CAR（扇区 $N=k$） | 源生配置准备 $v_\varepsilon$、$N=2$ 连通流、$N=3$ 极点包与四分级 $(3,j)$ Born 重叠响应（§9.2、§12.3–§13） |
| 时间、动量与预解字典 | 原时间 $t$，固有时 $\tau=Nt$；$p=(\lambda,i\mathbf k)$，$\mathbf k=2\pi\xi$；$h_{\mathrm{src}}a_{\mathrm{src}}=1$ | $\lambda=-i\omega$（$\lambda^2<0$ 为实频传播）；§7 预解 $(E-h)^{-1}$，§§9–13 预解 $(H-zI)^{-1}$；无量纲化分母 $h_{\mathrm{src}}c_{\mathrm{src}}$（§2.5、§9.3） |

**按专业背景的 15 分钟快速验证通道。** 鉴于全文横跨有效场论、受约束引力—规范约化、泛函分析算子群与红外量子电动力学，不同领域读者在验算 §1.1–§1.2 的纸笔锚点后，可按各自方向直接切入以下四条自足通道：

- **有效场论、大统一跑动与自旋—挠率引力方向**：直接读 **§2.1、§2.4、§4–§6、附录 A 及补充材料 S1–S2（命题 2.1、命题 4.1、命题 5.1、定理 6.1、命题 6.2–6.3）**，核验单世代手征—标量库存为何严格无单点跑动交汇（对照 Georgi–Glashow [7] 与 Georgi–Quinn–Weinberg [8]）、289 维受约束场如何无动量分母地约化为 $103=79\oplus 24$ 并完整回写原方程（对照 Dirac [13]、DeWitt [14]、Abbott [2]）、77 重方向消元如何零自由常数锁定四阶软相位系数（对照 Weinberg [15]、Appelquist–Carazzone [16]），以及无幽灵场 18 条弯曲规范—Lorentz 恒等式（对照 Slavnov–Taylor [36]）与 Lorentz 联络消元如何零参数导出 $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ 轴矢接触项与 42 位有理数在壳散射振幅（对照 Kibble [10]、Sciama [11]、Hehl 等 [12]）。
- **严格泛函分析、非自治量子演化与线性响应方向**：由 §1.1–§1.2 直接跳读 **§7–§8 及补充材料 S3（命题 7.1、定理 7.2、命题 7.3、定理 8.1–8.2、推论 8.3）**，核验 $L^2(\mathbb R^3,\mathbb C^{12})$ 上无界 Dirac 生成元定义域的双向刻画（对照 Stone [17]、Thaller [18]）、无需全轴统一范数界或定义域 $C^1$ 假设的径向 Picard 全时间幺正拼接（对照 Dyson [19]、Kato [5]）、任意相关测试族上的全词 CAR 正性（对照 Araki [20]、Tasaki [4]），以及不假定平衡态 $[\rho,\mathsf H]=0$ 的单位球一致算子范数 Kubo Fréchet 导数（对照 Kubo [6]、Bratteli–Robinson [21]）。
- **涌现电动力学、电荷量子化与本构光速锥方向**：直接读 **§6.7、§9–§11 及补充材料 S4、S5.1–S5.2、S5.7（命题 9.1、定理 9.2、注记 9.3、命题 10.1、引理 10.2、定理 10.3–10.4、定理 11.1、命题 11.2、定理 11.3–11.4）**，核验 $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ 如何同时承载修饰半单位字符与静止电子整单位电荷 $|Q_e|=1$（对照 Pati–Salam [9]）、母作用 1650 项二阶变分如何逐项认回 $H_{289}(p)$ 并保持任意正时钟通量恒等式，以及 16 项多项式余项判据如何在保留广义 Ward 余项 [22, 23, 36] 与前度规本构结构 [24] 的同时无角度平均地将高阶色散坍缩为无双折射横波 Maxwell 光速锥 $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$。
- **红外量子场论、修饰带电态与多体散射方向**：直接读 **§12–§14.1 及补充材料 S5.3–S5.7（定理 12.1、推论 12.2、定理 12.3–12.4、定理 13.1、定理 14.1）**，核验全方向 Schur 红外半径与三维矩阵 Bochner 积分如何分离接触项并精确返回单 $4\pi$ 实空间库仑核 $1/(4\pi|\mathbf x-\mathbf y|)$（对照 Donoghue [30]）、$N=3$ 复合极点包（对照 Haag [34]）如何满足全场连续性并自动消去 $|Q_e|^2=1$、四分级复合响应如何无需紫外重整化直接给出 $(0,1]$ 价态核重叠修饰 $C_{\mathrm{full}}=ZC_{\mathrm{base}}$（对照 Källén [33]、Lehmann [25]、LSZ [26]、Weinberg [35]），以及三通道静态回路如何在两步远场极限下保持原生、量子反馈与九约束零模同阶平衡（对照 Dirac [27]、Kulish–Faddeev [28]、Buchholz [29]）。§14.2 给出与上述五大传统共 36 篇原始文献的系统比较总表（表 4）。

<a id="sec-2"></a>

## 2 零旋钮母作用、九场背景与无单点交点判据

### 2.1 场的来源与载体

本文沿用 [1] 中的同一正光滑统一源及其唯一经典世界构型。母群为 $\mathrm{Spin}^{+}(1,3)\times\mathrm{SU}(7)$；在 [1，定理 2.2] 中，正源伴随谱序参量对易关系加分块迹方程双向唯一选出实际规范连接所在的标准模型子代数

$$\mathfrak h=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1),
\qquad (C,W,y)\longmapsto\operatorname{diag}(C,W,y,-y).\tag{2.1}$$

下文简称式 (2.1) 为标准模型规范块嵌入。七维基按 $(c_0,c_1,c_2,w_0,w_1,h_+,h_-)$ 编为 $0,\ldots,6$。三个外幂层组成单世代手征物质载体

$$\mathcal M=\mathbb C^4\otimes
\left(\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7\right),
\qquad \dim_{\mathbb C}\mathcal M=4(7+21+35)=252.\tag{2.2}$$

$e_I$ 表示指标集合递增排序的单位外幂基。标量的指定真空是

$$v=e_{0126}+e_{0124}+e_{0156}+e_{0145},\qquad \|v\|^2=4.\tag{2.3}$$

为避免专业读者在初见单模外幂量子数或一圈系数时产生误判，此处预先标明两项结构事实：第一，式 (2.2) 中单费米子外幂基上的原始超荷权属于复合前基底坐标，进入 §9.3 与 §10.1 后，未破缺电磁方向 $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ 在标量—物质修饰对上给出相对字符 $\pm 1/2$，而在带电静止电子腿上无条件给出绝对整单位电荷 $|Q_e|=1$，并在 §12.4–§13 的三费米子（$N=3$）色单态复合态上给出整数电荷 $\pm 1$（可对照 Pati–Salam [9] 以非阿贝尔色—弱组合生成整数轻子荷的路线，但此处无需并列半单群）；第二，不同于 Georgi–Glashow $\mathrm{SU}(5)$ 模型 [7] 手选可约表示 $\bar{\mathbf 5}\oplus\mathbf{10}$ 及 Georgi–Quinn–Weinberg [8] 假定无阈值荒漠下一圈逆耦合单点交汇，本源固定库存满足如下精确判据（完整算术与群论证明见附录 A.1–A.3）：

**命题 2.1（单世代库存无单点跑动交点与裸真空稳定子，`L1-L2`）。** 将式 (2.2) 单世代手征外幂加一个复 $\Lambda^4\mathbb C^7$ 标量代入标准一圈代数公式，按 $(\mathrm{SU}(7),\mathrm{SU}(3),\mathrm{SU}(2),\mathrm U(1))$ 顺序得系数 $b_0=(56/3,4,1/3,-28)$；在原生本构参数 $\sigma=1/2$ 与仿射跑动坐标 $\ell=\ln(\mu/\mu^*)/(8\pi^2)$ 下，由于母 $\mathrm{SU}(7)$ 迹限制到式 (2.1) 双对角元 $(y,-y)$ 超荷方向恰为原生配对 $\kappa(y,z)=-\operatorname{Re}(yz)$ 的 2 倍（故基准点 $\ell=0$ 处 $I_1(0)=\sigma=1/2$，而特殊酉块为 $I_3(0)=I_2(0)=1$），三条逆耦合直线 $I_3=1+4\ell$、$I_2=1+\ell/3$、$I_1=\frac12-7\ell$ 同时为正的区间为 $-1/4<\ell<1/14$，且在该区间及全实轴上**不存在公共单点交点**（$I_3=I_2$ 唯一解 $\ell=0$ 处 $I_1=1/2\ne 1$）。同时，真空 $v$ 的 $7\times 21$ 外积 Yukawa 矩阵满足 $YY^\dagger=\operatorname{diag}(2,2,2,4,2,0,0)$（秩 $5$、核维数 $16$），规范—标量裸二次块秩为 $9$（非零谱为 $1\,[6]$ 及 $6x^3-26x^2+27x-8=0$ 三实根），母群紧稳定子同构于 $(\mathrm{SU}(2)\times\mathrm{USp}(4)\times\mathrm U(1))/\mathbb Z_2$，与式 (2.1) 子群相交恰为前两色构成的未破缺色 $\mathrm{SU}(2)$。

命题 2.1 从源头表明：在零旋钮母作用下，低能耦合与实验标度的衔接不能靠朴素荒漠直线单点交汇，而必须通过真实重场传播逆与有限阈值解耦完成（树级消元见 §4–§5，108 通道阈值解耦归同系列第三案）。

九个独立场分别为余标架 $e$、自旋联络 $\varpi$（沿 Kibble [10] 与 Sciama [11] 的一阶独立标架—联络几何传统，但进一步耦合简单性二形式与手征外幂）、引力二形式 $\mathcal B$、简单性乘子 $\Lambda$、规范连接 $A$、规范二形式 $B_A$、标量 $\Phi\in\Lambda^4\mathbb C^7$、物质 $\psi\in\mathcal M$ 和独立复线性对偶 $\chi\in\mathcal M^*$。$\chi$ 与 $\psi$ 各有自己的变分；后文的关系 $\chi=s\psi^\dagger S$ 是实际解与指定制备子类的关系，不是原场空间的定义。

曲率由这些场计算：$F_\varpi=d\varpi+\varpi\wedge\varpi$、$F_A=dA+A\wedge A$。同样，协变导数由实际场的一阶导数计算，而非作为可以独立指定的附加数据。以下在源的零号坐标片写公式，其他坐标片按同一母表示及其对偶输运。

### 2.2 一个保留归一化的作用式

令 $\eta=\operatorname{diag}(-1,1,1,1)$、$g=e^{\mathsf T}\eta e$、$\nu_e=|\det e|$。时空二形式与内部双矢均按 $(01,02,03,23,31,12)$ 排序，但保留两类指标的区别。写

$$J=\begin{pmatrix}0&I_3\\-I_3&0\end{pmatrix},\qquad
(\Sigma_e)_{Ip}=e^{a_I}_{\mu_p}e^{b_I}_{\nu_p}-e^{a_I}_{\nu_p}e^{b_I}_{\mu_p}.$$

$J$ 是内部双矢对偶；$\star_e$ 是时空二形式的 Hodge 算子。定义 $p^c=(3,4,5,0,1,2)$、$\epsilon_I=(-1,-1,-1,1,1,1)_I$，以及

$$W_\kappa(X,Y)=\sum_p\kappa(X_p,Y_{p^c}),\qquad
W_{\rm top}(X,Y)=\sum_{I,p}\epsilon_I X_{Ip}Y_{I,p^c}.\tag{2.4}$$

在两个特殊酉块上 $\kappa(X,Y)=-\operatorname{Re}\operatorname{tr}(XY)$；在原超荷坐标上 $\kappa(y,z)=-\operatorname{Re}(yz)$。后者没有因母嵌入出现两个对角元而乘二。记 $\widehat F_{\varpi,Ip}=\epsilon_I F^{\rm raw}_{\varpi,Ip}$，其中 raw 表示降低两个内部指标的原曲率坐标。

Dirac 矩阵与手征算子采用

$$\gamma^0=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\quad
\gamma^i=\begin{pmatrix}0&\sigma_i\\\sigma_i&0\end{pmatrix},\quad
\gamma^5=\operatorname{diag}(-I_2,I_2),\quad S=\gamma^0\gamma^5.\tag{2.5}$$

在 $\mathcal M$ 上均张量以外幂层的恒等作用。$S^\dagger=S$、$S^2=I$；它交换手征块，负责把指定对偶接回坐标内积。令

$$\Gamma_e^\mu=(e^{-1})^\mu{}_a\gamma^a,\quad
\Omega_\mu=\frac14\varpi_{\mu ab}\gamma^a\gamma^b,\quad
D_\mu\psi=\partial_\mu\psi+(\Omega_\mu+\rho(A_\mu))\psi,
$$

$$D_\mu\Phi=\partial_\mu\Phi+\rho_4(A_\mu)\Phi,\qquad
Y_R(\Phi)=T_\Phi P_R,\quad P_R=\operatorname{diag}(0,0,1,1),$$

$$T_\Phi(w_6,w_2,w_4)=(w_2\wedge\Phi,0,0),\qquad
V(\Phi)=\|\Phi-v\|^2.\tag{2.6}$$

右手 Yukawa 作用从 $\Lambda^2$ 指向 $\Lambda^6$。其方向性是原作用的一部分；独立对偶随后评价这个向量。

共同局部密度为

$$\begin{aligned}
\mathcal L={}&W_{\rm top}(\mathcal B,\widehat F_\varpi)
-\frac12W_{\rm top}(\mathcal B,J\mathcal B)
+W_{\rm top}(\Lambda,\mathcal B-J\Sigma_e)\\
&+\sum_{j=3,2,1}\left[W_j(B_{A,j},F_{A,j})
-\frac12W_j(B_{A,j},g_j^2\star_e B_{A,j})\right]\\
&+\nu_e\left[\frac12g^{\mu\nu}\operatorname{Re}\langle D_\mu\Phi,D_\nu\Phi\rangle
-V(\Phi)+\operatorname{Re}\chi\bigl(i\Gamma_e^\mu D_\mu\psi+Y_R(\Phi)\psi\bigr)\right],
\qquad g_j^2=\sigma=\frac12.
\end{aligned}\tag{2.7}$$

上式固定了全文所有二次型和顶点的归一化。BF 项本身已是四形式系数；仅最后一行另乘体积密度。$g_j^2$ 而非 $g_j$ 等于 $1/2$。相对于 $\psi$ 的独立对偶已承担左配对，Yukawa 中不再插入 $\gamma^0$ 或额外的反向伴随项。

### 2.3 指定背景的九个字段

用 $q_0=e_{05},q_1=e_{15}\in\Lambda^2\mathbb C^7$ 定义

$$C(u,v)=\begin{pmatrix}0&u\\-u&0\\0&v\\-v&0\end{pmatrix},\qquad
\Psi[u,v]_r=\sum_{a=0}^1C(u,v)_{ra}q_a,
\quad \Xi[p,q](z)=\sum_{r,a}C(p,q)_{ra}q_a^*(z_r).\tag{2.8}$$

$\Xi$ 的表达式中没有复共轭。三个色二重态生成元在前两色上为

$$\tau_0=\frac12\begin{pmatrix}0&i\\i&0\end{pmatrix},\quad
\tau_1=\frac12\begin{pmatrix}0&1\\-1&0\end{pmatrix},\quad
\tau_2=\frac12\begin{pmatrix}i&0\\0&-i\end{pmatrix},\qquad
\kappa(\tau_i,\tau_j)=\frac12\delta_{ij}.\tag{2.9}$$

它们在其余坐标上为零。指定构型是

$$\begin{gathered}
e_0=\operatorname{diag}(N,1,1,1),\quad
A^{(0)}=(0,\alpha_0\tau_0,\alpha_0\tau_1,\alpha_0\tau_2),\quad
\Phi_0=v,\\
\psi_0(t)=\Psi[e^{i\omega t},e^{-i\omega t}],\quad
\chi_0(t)=\Xi[se^{i\omega t},se^{-i\omega t}].
\end{gathered}\tag{2.10}$$

降低内部指标的自旋连接，其唯一非零分量是

$$\varpi_{1,23}=\varpi_{2,31}=\varpi_{3,12}=s.\tag{2.11}$$

在前述双矢与二形式顺序中，其余三个字段为

$$\mathcal B_0=\begin{pmatrix}0&I_3\\-NI_3&0\end{pmatrix},\qquad
\Lambda_0=\operatorname{diag}(-N,-N,-N,s^2-1,s^2-1,s^2-1),$$

$$B_{A,0}=\frac{\alpha_0^2}{\sigma N}(\tau_0,\tau_1,\tau_2,0,0,0).\tag{2.12}$$

实际曲率是

$$\widehat F_{\varpi,0}=\operatorname{diag}(0,0,0,-s^2,-s^2,-s^2),\quad
F_{A,0}=(0,0,0,-\alpha_0^2\tau_0,-\alpha_0^2\tau_1,-\alpha_0^2\tau_2).\tag{2.13}$$

因此背景余标架虽然常数，自旋曲率与规范曲率仍非零。由联络自乘产生的这些项，后面会进入传播混合和外腿频率。

### 2.4 辅助消元以及如何把场找回来

先看一组可以完全手算的消元。由 (2.7) 对 $B_A$ 变分得 $F_A-K_eB_A=0$，其中 $K_e=\sigma\star_e$。洛伦兹二形式上 $\star_e^2=-I$，故

$$B_A^*=-\sigma^{-1}\star_e F_A,\qquad
\mathcal L(B_A)=\mathcal L(B_A^*)-\frac12W(B_A-B_A^*,K_e(B_A-B_A^*)).
\tag{2.14}$$

这是原楔配对下带符号的配方。对背景 $e_0$，

$$\star_{e_0}(f_0,\ldots,f_5)
=(f_3/N,f_4/N,f_5/N,-Nf_0,-Nf_1,-Nf_2).\tag{2.15}$$

把 (2.13) 代入，立即恢复 (2.12) 的 $B_{A,0}$：三个磁曲率分量变成三个电型辅助分量。消去的场没有消失，它的值已由保留场确定。

对任意一阶扰动，恢复公式继续为

$$\boxed{\delta B_A=K_0^{-1}
\left(\delta F_A-(\delta K_e)B_{A,0}\right).}\tag{2.16}$$

第二项尤其重要：余标架改变，Hodge 算子也改变。例如仅扰动时间系数 $N\mapsto N+\delta n$ 并扰动磁幅度 $\alpha_0\mapsto\alpha_0+\delta\alpha$，则

$$\delta(B_A)_{0i}
=\left(\frac{2\alpha_0}{\sigma N}\delta\alpha
-\frac{\alpha_0^2}{\sigma N^2}\delta n\right)\tau_{i-1}.
\tag{2.17}$$

忽略余标架项会漏掉一个真实引力—规范交叉响应，而不是只改变规范写法（这也从一阶变分侧面印证前度规本构电动力学 [24] 中时空几何通过 Hodge 本构直接耦合电磁激发）。引力两项同样恢复为

$$\delta\mathcal B=J\,\delta\Sigma_e,\qquad
\delta\Lambda=J\,\delta\mathcal B-\delta\widehat F_\varpi.\tag{2.18}$$

§4 的大矩阵消元逐步实现同一件事，并保存每一步的场恢复与方程恢复。通过经典驻值方程树级消去可逆重方向的组织思路与 Henning–Lu–Murayama [3, §2.1.1] 一致；本文在此之上多施加一条刚性要求：低能有效解经显式多项式逆嵌入回写后，必须逐行重新满足原系统保留的全部场方程。

### 2.5 原时间、共转表示与配对

物质的周期背景可用同一源相位化为定常形式。在完整 252 维载体上，令 $P_6$ 为 $\Lambda^6$ 层投影，定义

$$Q=\gamma^5+2P_6,\qquad P(t)=e^{-i\omega tQ},\qquad
\psi_{\rm orig}=P(t)\psi_{\rm st},\quad
\chi_{\rm orig}=\chi_{\rm st}\,S P(t)^\dagger S.\tag{2.19}$$

$Q$ 限制到原占据空间即为 §1 的 $\gamma^5$。完整原 Dirac 算子在定常表示中增加 $+\omega\Gamma_e^0Q$，相应 Hamiltonian 满足

$$H_{\rm st}(\mathbf k)=H_{\rm orig}(\mathbf k)-\omega Q.
\tag{2.20}$$

共转变换改变的是场表示，时间坐标仍为同一个 $t$；(2.20) 按确定的相位恢复原频率。非零顶点保留 $Q$ 荷时，原频率与定常频率的转移量相同。

全文采用下列时间与动量字典：原时间 $t=x^0$；背景固有时 $\tau=Nt$；Fourier–Jacobi 增长符号 $p=(\lambda,i\mathbf k)$；有理化变量

$$u=\frac{\lambda}{N\sqrt2},\qquad \mathbf q=\frac{\mathbf k}{\sqrt2};
\qquad \widehat f(\xi)=\int e^{-2\pi i\mathbf x\cdot\xi}f(\mathbf x)\,d^3x,
\quad \mathbf k=2\pi\xi.\tag{2.21}$$

在传播式中 $\lambda$ 是增长率；在量子频率式中使用 $e^{-iEt}$，即 $\lambda=-iE$。所以 $\lambda^2<0$ 对应振荡，$\lambda^2>0$ 对应实增长。以下各节保持这个符号，不用“质量平方”的命名抹平二者。

<a id="sec-3"></a>

## 3 九场共同发展及其真实切向

### 3.1 七个初值怎样生成九个场

空间齐次条件使空间导数消失，但并未把引力、规范和物质拆成互不影响的方程。一个标量初始速度会改变应力；时间余标架因而改变，规范加速度与物质相位也随之改变。下面把这种反馈写成一个明确的七维系统。

记状态为 $x=(a,H,\alpha,b,f,w_s,\theta)$，依次表示空间尺度、标架速度、规范幅度、规范动量、径向标量位移、标架中的标量速度和物质相位。此处 $w_s$ 是实速度，区别于 §1 的占据向量 $w$。定义

$$c=\frac{s}{a^2},\quad E_A=b^2+\alpha^4,\quad q_v=\|v\|^2=4,$$

$$\mathcal D(x)=\frac{6s(c-\alpha)}a
+q_v a^3\left(f^2-\frac{w_s^2}{2}\right)
+3a^3+3aH^2-3ac^2,\qquad
n(x)=\sqrt{\frac{3aE_A}{4\sigma\mathcal D(x)}}.\tag{3.1}$$

允许域是开集 $\mathcal A=\{a>0,E_A>0,\mathcal D>0\}$。其中的 $n$ 由时间余标架方程确定，不是另给的时钟函数。原方程生成的向量场 $G$ 为

$$\begin{aligned}
\dot a&=nH,\\
\dot H&=\frac{1}{2a}\left[-\frac{E_A}{4\sigma n}
+n\left(\frac{2s(c-\alpha)}{a^2}
-q_v a^2\left(f^2+\frac{w_s^2}{2}\right)-3a^2-H^2+c^2\right)\right],\\
\dot\alpha&=\frac{ab}{n},\qquad
\dot b=\frac{4\sigma ns}{a}-\frac{2a\alpha^3}{n},\\
\dot f&=nw_s,\qquad \dot w_s=n\left(2f-\frac{3Hw_s}{a}\right),\\
\dot\theta&=\frac{3n(c-\alpha)}{2a}.
\end{aligned}\tag{3.2}$$

沿任一允许解 $x(t)$ 写出

$$e=\operatorname{diag}(n,a,a,a),\quad A_i=\alpha\tau_{i-1},\ A_0=0,
\quad \Phi=(1+f)v,$$

$$\psi=a^{-3/2}\Psi[e^{i\theta},e^{-i\theta}],\qquad
\chi=sa^{-3/2}\Xi[e^{i\theta},e^{-i\theta}].\tag{3.3}$$

自旋连接由两部分相加：Levi–Civita 部分的非零混合分量为 $\varpi_i{}^0{}_i=\varpi_i{}^i{}_0=H$；轴向挠率部分的降低分量为 $\varpi_{1,23}=\varpi_{2,31}=\varpi_{3,12}=c$。其余字段由

$$\mathcal B=J\Sigma_e,\qquad \Lambda=J\mathcal B-\widehat F_\varpi,
\qquad B_A=-\sigma^{-1}\star_e F_A\tag{3.4}$$

恢复。因而七个状态既写出九个场，也写出各场实际的一阶导数。特别是 $\dot n=Dn(x)G(x)$，不能在求曲率时当作零。

**定理 3.1（共同局部发展）。** 对每个 $x_*\in\mathcal A$，存在 $r,T>0$ 和 $C\geq0$，使闭球 $\overline B(x_*,r)$ 中每个初值 $x$ 都生成同一时间条带 $|t|<T$ 上的光滑解 $X(x,t)$。它保持在 $\mathcal A$ 中，满足 $X(x,0)=x$、$\partial_tX=G(X)$，并有

$$\|X(x,t)-X(y,t)\|\leq C\|x-y\|.\tag{3.5}$$

由 (3.3)–(3.4) 生成的九场，其原九类 Euler 残差在条带内共同为零。同初值的发展在共同定义区间上相同。

**证明。** 难处在第二步：七维 ODE 有解，不等于九个场都回答了各自的方程。证明要点是两个实际相接的步骤。先由 $a,E_A,\mathcal D$ 的严格正性，得到 $G$ 在允许域内光滑；局部 Picard 构造给出共同初值球和共同时间区间，再利用联合连续性把整个乘积邻域留在允许域。随后将该解的实际导数代入原场：Cartan 方程给出 $c=s/a^2$，规范方程给出 $\dot\alpha,\dot b$，标量方程给出 $\dot f,\dot w_s$，两条物质方程给出稀释率与 $\dot\theta$，余标架两类平衡给出 $n$ 和 $\dot H$（补充材料 S1.1）。这一步使用的是原场变分，故结论是九场共同解，而不止七维 ODE 的一个解。∎

### 3.2 相位漂移中的初值导数

原状态为

$$x_0=(1,0,\alpha_0,0,0,0,0),\qquad
X(x_0,t)=x_0+t\omega e_7.\tag{3.6}$$

它不是七维坐标中的静止点：第七坐标一直走。由于 $G$ 不依赖 $\theta$，减去这一实际漂移后，得到中心向量场

$$G_c(z)=G(x_0+z)-\omega e_7,\qquad G_c(0)=0,\qquad
J_0=DG(x_0),\quad G_c(z)=J_0z+o(\|z\|).\tag{3.7}$$

**定理 3.2（真初值导数）。** 对定理 3.1 在 $x_0$ 处的共同发展及每个 $|t|<T$，

$$D_xX(x_0,t)=e^{tJ_0}.\tag{3.8}$$

**证明。** 这是实际非线性解族的 Fréchet 导数。容易算错的是背景本身在走：相位一直漂移，偏离必须从漂移中的轨道量起。将 $X(x_0+h,t)-X(x_0,t)$ 与 $e^{tJ_0}h$ 相减，局部 Lipschitz 界先把全部非线性位移控制为 $C\|h\|$；(3.7) 的余项因而在整段时间上为 $o(\|h\|)$。对差方程应用 Grönwall 估计，再分别处理正、负时间，即得 (3.8)。相位漂移保留在 (3.6) 中，而没有被误算为偏离背景的扰动。∎

原 $J_0$ 的特征多项式为

$$\det(XI-J_0)=X\left(X^2+\frac{648}{125}\right)
\left(X^2-\frac{50}{3}\right)
\left(X^2-\frac{108}{125}\right).\tag{3.9}$$

零根、振荡根和两对实增长／衰减根各有自己的位置。径向标量对给出 $108/125=2N^2$；其余五态的多项式是前三个因子的乘积，并将在 §4 通过原 289 行接受同一个切向。

### 3.3 全空间径向 Jacobi 解

现在允许标量有空间轮廓，仍保留原背景的其余场。令 $\Phi_\epsilon=(1+\epsilon f(t,\mathbf x))v$。径向方程从原标量动能和势直接化为

$$\mathcal R f:=\frac1{N^2}\partial_t^2f-\Delta f-2f=0.\tag{3.10}$$

固定任意实三动量 $\mathbf k$，取 $f(0,\mathbf x)=0$、$\partial_tf(0,\mathbf x)=\cos(\mathbf k\cdot\mathbf x)$，得到

$$f_{\mathbf k}(t,\mathbf x)=\cos(\mathbf k\cdot\mathbf x)
\begin{cases}
\sinh(\gamma t)/\gamma,&|\mathbf k|^2<2,\quad\gamma=N\sqrt{2-|\mathbf k|^2},\\
t,&|\mathbf k|^2=2,\\
\sin(\nu t)/\nu,&|\mathbf k|^2>2,\quad\nu=N\sqrt{|\mathbf k|^2-2}.
\end{cases}\tag{3.11}$$

临界式 $t$ 是左右两种表达式在零频率处的同一极限；三个时间因子的初始导数均为 1，完整场的初始速度始终为 $\cos(\mathbf k\cdot\mathbf x)$。

**定理 3.3（完整径向第一变分）。** 设轮廓 $f$ 可微，各一阶坐标偏导在所考察点可微，且在该点满足 (3.10)。则原九场残差中八类在任意实 $\epsilon$ 下恰为零，唯一留下的余标架残差为 $\epsilon^2$ 乘一个明确的原余标架余向量。因此九类残差对 $\epsilon$ 在零处的导数全部为零。特别地，(3.11) 的三种动量区域均给出原九场的 Jacobi 解。

**证明。** 将 $\Phi_\epsilon=(1+\epsilon f)v$ 代入原九类 Euler 变分，线性阶上标量行恰化为 $\mathcal R f=0$，而规范、自旋联络、引力辅助、乘子与两条物质行均由 $v$ 的背景平衡逐项消去；二阶反作用从径向扰动密度

$$\Delta\mathcal L_\Phi
=\epsilon^2q_v\nu_e\left(\frac12g^{\mu\nu}\partial_\mu f\,\partial_\nu f-f^2\right).
\tag{3.12}$$

对 $e$ 变分后置 $e=e_0$，所得余标架负载严格从 $\epsilon^2$ 开始，故在 $\epsilon=0$ 处九类一阶变分导数同为零。∎

式 (3.12) 同时解释了一阶 Jacobi 解为何在固定背景上闭合，以及有限径向振幅为何要求 §3.1 的共同余标架反馈。这里的单个余弦波是全空间模态；§7 的 $L^2$ 准备将另外处理可归一的空间场。

### 3.4 同一发展的物质稀释守恒与子空间压缩返回

非线性解中 $a^{-3/2}$ 的振幅与后续多算子乘积的压缩次序满足如下精确代数定律：

**命题 3.4（共动体积物质稀释守恒与子空间压缩返回恒等式，`L4`）。** 沿 §3.1 的任一允许九场解，令 $\widehat\psi_\theta=\Psi[e^{i\theta},e^{-i\theta}]/2$，则对任意完整母算子 $A\in\operatorname{End}(\mathcal M)$ 有

$$\chi(A\psi)=4s\,a^{-3}\langle\widehat\psi_\theta,SA\widehat\psi_\theta\rangle.
\tag{3.13}$$

特别取 $A=S$ 得原场物质密度与共动体积守恒律

$$\rho=\operatorname{Re}\chi(S\psi)=4s\,a^{-3},\qquad a^3\rho=4s.\tag{3.14}$$

同时，对任意选定物质子空间等距嵌入 $I$（$I^\dagger I=I_{\mathrm{sub}}$）及其压缩映射 $C(A)=I^\dagger AI$，任意两算子乘积满足精确补空间返回分解

$$C(AB)=C(A)C(B)+I^\dagger A(I-II^\dagger)BI.\tag{3.15}$$

**证明。** 将式 (3.3) 的 $\psi,\chi$ 代入式 (2.8) 定义并用 $S=\gamma^0\gamma^5$ 核对两手征块内积，立得 (3.13)；取 $A=S$ 并用 $S^2=I,\|\widehat\psi_\theta\|^2=1$ 得 (3.14)。在 $I^\dagger ABI$ 中间插入恒等分解 $I_{\mathcal M}=II^\dagger+(I-II^\dagger)$ 即得 (3.15)。∎

式 (3.14) 将空间体积、物质稀释与独立对偶配对接在同一条等式上；式 (3.15) 第二项则精确记录“先离开子空间、再返回子空间”的中间跃迁——§6 的树交换与 §7.4 的全词 CAR 评价（表 2 第 3 项）之所以必须先完成完整乘积再作压缩，代数根源正在于此。

<a id="sec-4"></a>

## 4 完整耦合传播与原场恢复

### 4.1 为什么先处理约束

在非零物质背景上，规范扰动改变物质，物质反过来改变电流，余标架与自旋连接又同时进入二者。把某一个裸质量块对角化，尚未完成这组联立传播问题。本节直接从 (2.7) 的独立字段一阶 jet 取二次变分。

与原占据态相耦合的活跃实载体包含：16 个余标架坐标、24 个 Lorentz 连接坐标、36 个引力辅助坐标、36 个乘子坐标、48 个规范连接坐标、72 个规范辅助坐标、9 个标量实轨道坐标，以及原占据空间中 primal 与独立 dual 的各 24 个实坐标，总计 289。其余标量与物质方向在 §4.5 和 §6 保留各自的分块与返回关系。

记二次 Euler 符号为 $H_{289}(p)$，采用实字段的带符号转置 $M^\sharp(p)=M(-p)^{\mathsf T}$。原二次作用的形式为 $\frac12z^\sharp H_{289}z$。准确保留 $-p$ 的原因很简单：分部积分把微分算子送到另一条腿时会改变符号。

第一步是三次真实代数消元：

$$289\longrightarrow217\longrightarrow145\longrightarrow121.
\tag{4.1}$$

相应消去维数依次为 $72,72,24$（即 72 个规范二形式辅助分量 $B_A$、72 个引力二形式与简单性乘子分量 $(\mathcal B,\Lambda)$，以及 24 个实自旋联络分量 $\varpi$）。每步从实际非零代数块求双侧逆，保留了全动量场恢复。为了看清其含义，设某一步的场分为 $(y,z)$，二次作用连同正号源为

$$\frac12\begin{pmatrix}y\\z\end{pmatrix}^{\sharp}
\begin{pmatrix}A&B\\B^\sharp&D\end{pmatrix}
\begin{pmatrix}y\\z\end{pmatrix}+j_y^\sharp y+j_z^\sharp z.
$$

只要 $A$ 可逆，原 $y$ 方程给出

$$y=-A^{-1}(Bz+j_y),\quad
Kz=-j_z+B^\sharp A^{-1}j_y,\quad
K=D-B^\sharp A^{-1}B.\tag{4.2}$$

代回作用后还留下局部项 $-\frac12j_y^\sharp A^{-1}j_y$。于是传播核、外源变换、被消去场和接触项从同一个消元步骤同时产生。§6 的树交换会把这四样一并用上。

### 4.2 从原 Ward 行得到忠实截面

接下来遇到的不是另一个可以随意舍弃的零块。全部 12 个规范切向对原标量势的响应恰给出秩 9 的 torque。对原实标量偏差 $\phi$，它的形状是

$$\mathcal T_X(\phi)=-2\nu_e\langle\rho(X)v,\phi\rangle_{\mathbb R}.
\tag{4.3}$$

通过具有显式多项式逆的行操作，9 个标量行成为可逆常数约束，消去相应变量后得到 112 个等价方程。原标量行可以反向恢复，非零势响应因此作为约束保留。

112 系统的真正对称切向有 9 个：三个原色 SU(2) 切向和六个 Lorentz 切向。记其矩阵为 $T_{\mathrm{sym}}(p)$。在轴向 $p=(\lambda,0,0,ik)$，它具有一个与 $\lambda,k$ 无关的可逆 $9\times9$ 子式，由此生成 103 维截面 $C$ 与多项式读回 $Q_{\mathrm{sec}}(p)$，满足

$$Q_{\mathrm{sec}}(p)C=I_{103},\qquad
H_{112}(p)=Q_{\mathrm{sec}}^\sharp(p)K_{103}(p)Q_{\mathrm{sec}}(p).
\tag{4.4}$$

截面构造完全不引入 $\lambda$ 或 $k$ 的分母——与依赖横向投影算子 $k_\mu k_\nu/k^2$ 或规范固定幽灵场的传统协变背景场约化 [2, 14] 及一般退化约束括号消元 [13] 相比，这一无分母多项式截面保证了零动量原点与特殊动量球面均不会因选择截面而产生人工奇点或丢失核空间。对满足

$$T_{\mathrm{sym}}^\sharp(p)j=0\tag{4.5}$$

的源，在 $K_{103}$ 可逆处，正 Green 响应 $x_G=CK_{103}^{-1}C^{\mathsf T}j$ 满足 $H_{112}x_G=j$。沿用 (4.2) 的正号作用源 $+j^{\mathsf T}x$ 时，驻值方程为 $H_{112}x+j=0$，故诱导场是 $x_{\rm ind}=-x_G$；再用 (4.2) 和 Ward 逆变换恢复全部 289 行。这里“正 Green”指源方程的符号，不指算子的正定性。

一般轴向点的秩为 103，原点为 98。原点额外五维核由原物质与独立对偶的五种常方向张成：向量实缩放、向量相位、轴向实缩放、齐次 $\theta$ 相位及纯虚独立对偶缩放。它们在非零动量一般不再成核。另一方面，四个朴素坐标微分同胚候选在原符号中留下 128 项非零残差（表 2 第 2 项）；本约化使用的是实际精确湮灭符号的九个规范—Lorentz 切向。原 Hodge 算子的时间伸缩与普通二形式拉回之差，也具有明确的非零导数 $-2/N$。

**命题 4.1（完整传播与回写）。** 上述代数消元、Ward 约束与忠实截面给出完整活跃二次作用的等价受约束传播。原七维发展中的非径向五态 Jacobi 解，经秩 5 的实际场嵌入满足全部 289 行，且其特征多项式

$$X\left(X^2+\frac{648}{125}\right)\left(X^2-\frac{50}{3}\right)
\tag{4.6}$$

完整进入原传播的时间轴。

**证明。** 前三步是精确代数恒等式，判决落在最后一次对质：由块消元恒等式 (4.2)、多项式行逆和无分母截面 (4.4) 合成全动量回写，再把 §3 的实际五态导数经原字段映射送入 $H_{289}$，所得全部 289 行恒等于零。因而非线性发展与线性传播共享真实切向，而不只是共享相似的特征值。∎

### 4.3 完整因子与低动量支

对 $K_{103}$ 按实际非零支撑分解，得到十个块，维数依次为

$$1,1,1,1,2,2,16,16,30,33.\tag{4.7}$$

在 (2.21) 的原变量读回下，完整行列式有 22 个不同的有理因子。同步旋转空间、自旋和原色方向后，可将其组合为 14 个径向乘积因子；相应时间多项式总次数为 126。所有非零实空间动量均由该旋转输运，零动量由原点矩阵独立保留。完整因子、重数与非零缩放常数见补充材料 S1 及随稿精确目录。

原点处的时间部分重数是 $(1,1,2,2,2)$，静态空间部分重数是 $(2,2,2,2,2)$。四条低动量特征支的首项为

$$\lambda^2=-\frac{18}{25}|\mathbf k|^2,\quad
\lambda^2=-\frac3{20}|\mathbf k|^4,\quad
\lambda^2=-\frac{594}{1675}|\mathbf k|^2,\quad
\lambda^2=\frac13|\mathbf k|^2.\tag{4.8}$$

前两条与后两条有不同的最低动量阶和原场组成。后两条将在 §5 由相位坐标的有效作用重新求得，并进一步给出四阶系数。这里的因子数统计的是原算子的特征除子；具体外态是否读到某个极点，还要由分子和源来决定。

一个较小的原弱块展示了这种区别。七维基弱双重态指标对 $(3,4)$（即 $(w_0,w_1)$）对应的原生规范四向量块 $A_{34}$ 与对称弱块 $S_{34}$，各与商中其余 99 个坐标双向隔离，其横、纵传播分母分别为

$$\lambda^2+\frac{125}{54}k^2-\frac12,\qquad
\lambda^2+\frac{54}{125}k^2-\frac12.\tag{4.9}$$

齐次时间分量的响应却为常数 $-N/2$。原字段回写还表明：四向量源 $j_\mu$ 在原标量轨道行同时生成 $-\lambda j_0-ikj_3$。因此，一个商中的四向量读数包含真实的标量源条件，而不是单独强迫某个 $A$ 分量。

### 4.4 原独立对偶中的制备子类

现在选取原理论已有的实制备关系

$$\chi=s\psi^\dagger S.\tag{4.10}$$

其线性切向给出 88 维嵌入 $C_{\mathrm{prep}}$，以及实际方程返回矩阵 $R_{\mathrm{prep}}$：

$$K_{88}=C_{\mathrm{prep}}^{\mathsf T}H_{112}C_{\mathrm{prep}},\qquad
H_{112}C_{\mathrm{prep}}=R_{\mathrm{prep}}K_{88},\qquad
C_{\mathrm{prep}}^{\mathsf T}R_{\mathrm{prep}}=I_{88}.\tag{4.11}$$

最后两个等式比“把制备关系代入作用”更强：它们保证约化解重新满足原独立方程。除去同样的九个真实对称方向后得到 $K_{79}$，且原 103 维传播分解为这 79 个方向与一个 24 维补块。实际制备物质产生的实源在该补块上恒等为零；这是一项源选择律，而不是删除原传播分支的理由。

### 4.5 外围物质与标量的完整保留

完整载体的其余方向（即活跃 289 维子系统之外、由其余外围手征旋量、独立复线性对偶与 61 维外围标量共同组成的 1078 条原耦合线性化场方程）同样有明确的动力学位置。对制备类外围约束作最大发展，实纤维维数在一般动量为 522，在原点为 524，在球面 $|\mathbf k|^2=5929/1800$ 为 530；其发展完整恢复原来的 1078 行方程。瞬时相容核的复维数为 266，与可发展纤维的实维数描述不同对象。固定标量与连接时，另有 232 维复物质传播不变子空间。

标量也有两种必须保留定义的分解。全部 70 个实标量方向中，同时满足 Yukawa 核条件与实规范轨道正交条件的空间维数是 43，可写为 23 个实单态和五个四维块。与活跃 9 维轨道互补的整个 61 维标量空间，则由 25 个实单态和九个四维块组成；它的完整传播逆在 §6.3 给出。前一分解挑选同时满足两种条件的方向，后一分解负责恢复所有外围标量，因此两组数并不相减替代。

<a id="sec-5"></a>

## 5 七十七重方向消元与零自由常数四阶软相位色散

### 5.1 用原相位，而不是任意核基

在制备传播 $K_{79}(0)$ 的二维核中，选择原物质的两种实际相位。向量相位 $\varphi$ 的切向为

$$\delta\psi=i\psi_0\,\delta\varphi,\qquad
\delta\chi=-i\chi_0\,\delta\varphi;$$

轴向相位 $\theta$ 的切向为

$$\delta\psi=-i\gamma^5\psi_0\,\delta\theta,\qquad
\delta\chi=-i\chi_0\gamma^5\,\delta\theta.\tag{5.1}$$

向量相位使物质与独立对偶两腿反向转动；轴向相位则在两腿上以同号的 $-i\gamma^5$ 作用。这一区别固定了相位幅度，并使有效作用能够与原 Noether 密度逐项比较。

先用固定对角有理化场缩放矩阵 $S_f$（将余标架、联络与物质振幅规整至有理系数基，见补充材料式 (S1.3)）写 $G=S_f^{\mathsf T}K_{79}S_f/N$，令 $P_{\rm src}(p)$ 为原相位经实际截面读回后的两列，并取常数列 $P=P_{\rm src}(0)$。$P_{\rm src}(p)-P$ 位于剩余 77 个方向中。选取这些方向的常数列矩阵 $E$，则 $T_0=[P,E]$ 可逆，而

$$D(p)=E^{\mathsf T}G(p)E=D_0+D_1+D_2,\qquad D_0\text{ 可逆}.\tag{5.2}$$

“重方向”在这里指原点处可逆的 77 个方向。其消去适用于原点附近的导数展开，由 (5.2) 的实际矩阵而不是一个外加质量分界决定。

### 5.2 递归消去与完整场回写

设 $B(p)=E^{\mathsf T}G(p)P=\sum B_n$，各下标表示总动量次数。原方程逐阶生成重方向修正

$$W_0=0,\qquad
D_0W_n=-B_n-D_1W_{n-1}-D_2W_{n-2},\quad 1\leq n\leq4,
\tag{5.3}$$

越界下标取零。于是相位的有效场为 $F=P+E\sum_{n=1}^4W_n$，满足

$$GF=T_0^{-\mathsf T}\big|_{\rm light}(K_2+K_4)+R_5+R_6.\tag{5.4}$$

在四阶截断内，一阶和三阶有效算子消失。上式含两个确切余项矩阵 $R_5,R_6$，它们是齐次多项式，而非数值拟合误差。若 $V_{289}$ 与 $J_{289}$ 为 §4 的实际场与方程嵌入，则

$$H_{289}V_{289}=J_{289}G,\quad V_{289}^{\sharp}J_{289}=NI_{79},$$

$$H_{289}V_{289}F
=J_{289}T_0^{-\mathsf T}\big|_{\rm light}(K_2+K_4)
+J_{289}(R_5+R_6).\tag{5.5}$$

有效相位及其截断误差由此在原 289 行中有了确定位置：保留到几阶、原方程的误差从哪一阶开始，同一个回写式当场给出。

### 5.3 有效作用及一条完整展开

计算得到

$$K_2=\begin{pmatrix}
\frac{32}{11}u^2+\frac{160}{67}|\mathbf q|^2&0\\
0&-40u^2+\frac{2500}{81}|\mathbf q|^2
\end{pmatrix}.\tag{5.6}$$

回到原时间和空间坐标，二阶导数密度为

$$\boxed{\mathcal L_2=
-\frac8{11N}(\partial_t\varphi)^2+\frac{40N}{67}|\nabla\varphi|^2
+\frac{10}{N}(\partial_t\theta)^2+\frac{625N}{81}|\nabla\theta|^2.}
\tag{5.7}$$

完整 $K_4$ 的四动量多项式见补充材料 S1.3。为了实际算出一条支，先沿 $q_3=q,q_1=q_2=0$ 取向量相位项：

$$(K_4)_{\varphi\varphi}
=\frac{8000}{13467}q^4
+\frac{258700928}{203688375}q^2u^2
+\frac{320}{363}u^4.\tag{5.8}$$

令 $u^2=cq^2+dq^4+O(q^6)$。由 (5.6) 的二阶项，$c=-55/67$。把这个 $c$ 代入 (5.8)，四阶项变为 $12033024q^4/82709825$；因而

$$\frac{32}{11}d+\frac{12033024}{82709825}=0,
\qquad d=-\frac{376032}{7519075}.\tag{5.9}$$

最后使用 $\lambda^2=2N^2u^2$、$q^2=k^2/2$，我们将上述递归消元与在壳回代总结为如下零自由常数命题：

**命题 5.1（两相位四阶有理色散与零待定低能常数展开，`L8`）。** 消去 $K_{79}(0)$ 中原点可逆的 77 个重方向后，向量相位 $\varphi$ 与轴向相位 $\theta$ 的低动量特征支在任意实三动量方向 $\mathbf k\in\mathbb R^3$ 上具有精确有理四阶展开

$$\boxed{\lambda_\varphi^2
=-\frac{594}{1675}|\mathbf k|^2
-\frac{10152864}{939884375}|\mathbf k|^4+O(|\mathbf k|^6),}
\tag{5.10}$$

$$\boxed{\lambda_\theta^2
=\frac13|\mathbf k|^2-\frac{3053}{29160}|\mathbf k|^4
+O(|\mathbf k|^6),}\tag{5.11}$$

且四阶有效场 $F=P+E\sum_{n=1}^4 W_n$ 经式 (5.5) 回写原 289 维场方程时仅留下精确的五阶与六阶齐次多项式余项 $(R_5,R_6)$。

**证明。** 由递归式 (5.3) 解出 $W_1,\ldots,W_4$ 得 (5.4)–(5.5)；将式 (5.6) 二阶壳关系分别代入补充材料 S1.3 式 (S1.5) 的向量与轴向对角项（四阶非对角项平方在行列式中严格从 $O(|\mathbf k|^8)$、即分支 $O(|\mathbf k|^6)$ 才进入），换回原时间与空间动量变量即证得式 (5.10)–(5.11)。∎

这一结果与 Weinberg 唯象拉氏量导数展开 [15] 及 Appelquist–Carazzone 低动量重场解耦 [16] 形成清晰对照：在一般手征有效场论中，四阶导数算符的系数通常作为待由实验拟合或紫外补全另行输入的自由低能常数（LECs）；此处同一固定母作用的 77 维原点逆直接将二阶与四阶系数全部锁定在 $\mathbb Q$ 中。所用离壳 $K_4$ 在固定相位截面中不必逐项写成显然的旋转标量；将二阶壳关系代入其对角项后，四阶系数精确化为径向不变量。同时应在物理上区分两类对象：式 (5.11) 中 $\lambda_\theta^2>0$ 刻画的是齐次相位进动轨道 $X(x_0,t)=x_0+t\omega e_7$ 邻域内无外控经典线性化 Jacobi 切向的双曲鞍点曲率（与式 (3.9) 的实特征根对同源），绝非实空间量子演化的失稳发散——在齐次非线性层由定理 3.1 的有限时间条带严格控制，在三维占据态空间 $L^2(\mathbb R^3,\mathbb C^{12})$ 上厄米 Dirac 生成元给出全实时间保范幺正群（定理 7.2、8.1），而在多体电磁层则锚定于正定下有界二次型算子 $\mathcal T$ 的局域化基态配置准备（§9.2 式 (9.3)–(9.4)）。

![两相位的低动量特征支](figures/main-02-soft-phases.svg)

**图 2　原时间中的两条软支。** 实线为 (5.10)–(5.11) 在 $\mathbf k=0$ 附近的四阶截断，虚线为二阶首项，横轴展示 $0\leq|\mathbf k|\leq0.5$，渐近余项为 $O(|\mathbf k|^6)$。纵轴为原时间增长变量 $\lambda^2$：零线以下是振荡支 $\varphi$（深蓝），以上是双曲鞍点支 $\theta$（朱红）；后者的四阶项在所示范围内已与二阶首项清晰分离。

### 5.4 Noether 密度固定相位的尺度

原作用对两种相位的导数读数为

$$J_\varphi^\mu=-\nu_e\operatorname{Re}\chi\Gamma_e^\mu\psi,
\qquad J_\theta^\mu=\nu_e\operatorname{Re}\chi\Gamma_e^\mu Q\psi.\tag{5.12}$$

原背景上的向量密度为零，轴向密度为 $4s$。第一变分必须同时计入物质两腿以及余标架。后者通过

$$\delta\operatorname{adj}(e)=\det e\left[
\operatorname{tr}(e^{-1}\delta e)e^{-1}-e^{-1}(\delta e)e^{-1}\right]
\tag{5.13}$$

进入，不能在归一化相位之前丢弃。将 (5.3) 的重方向解代回原密度，最低阶为

$$\delta J_\varphi^0=-\frac{16}{11N}\partial_t\varphi+O(\partial^3),\qquad
\delta J_\theta^0=\frac{20}{N}\partial_t\theta+O(\partial^3).\tag{5.14}$$

它们恰为 (5.7) 对两条相位速度的导数。完整四动量 Ward 恒等式则把原流的散度与 $H_{289}$ 的相位行相接。于是 (5.7) 的系数经受了两次询问：先解出正确的支，再由原作用的电荷密度固定相位尺度。

<a id="sec-6"></a>

## 6 十八条弯曲规范—Lorentz 恒等式、ECSK 轴矢接触项与 42 位有理树交换

传播矩阵回答场怎样受迫；唯象还要追问：是什么样的物质施了这个力？原作用的完整物质顶点先接上 §4 的传播，实际自由外腿随后出庭，交出一个非零四腿系数。归一化最后从原时间动能读取，不从坐标向量的长度猜测。

### 6.1 完整顶点与原源条件

对原密度的全部玻色字段求一次变分，得到 158 个作用在完整 $\mathcal M$ 上的顶点。采用

$$\mathcal L_3=\sum_b\delta b\,\operatorname{Re}\bigl[\zeta V_b(p)\xi\bigr],\tag{6.1}$$

其中 $p$ 作用于 primal 腿 $\xi$，独立 dual 腿为 $\zeta$。四类顶点为

| 字段 | 实方向数 | 从原作用读取的顶点 |
|---|---:|---|
| 规范连接 $A_\mu^T$ | 48 | $Ni\Gamma_{e_0}^\mu\rho(T)$ |
| 降低指标的 Lorentz 连接 $\varpi_{\mu ab}$ | 24 | $Ni\Gamma_{e_0}^\mu\gamma^a\gamma^b/2$，按六个定向双矢计数 |
| 余标架 $e^a{}_{\mu}$ | 16 | 对 $\operatorname{adj}(e)$、完整定常动能及 $\det(e)Y_R$ 的真实导数 |
| 标量 $\Phi$ | 70 | $NY_R(\sigma_b)$，$\sigma_b$ 为 35 个复基的实部与虚部方向 |

余标架顶点包括 (2.19) 产生的 $+\omega\Gamma_e^0Q$。它的体积导数和逆余标架导数共同参与，故可以用来检查时间与场归一化是否一致。

令 $D(p)$ 为原完整定常 Dirac 符号。由实际局域规范与 Lorentz 作用生成的 18 条恒等式具有共同形式

$$\delta D(p,r)+ND(p+r)T-NTD(p)=0.\tag{6.2}$$

这里 $\delta D$ 同时包含背景连接交换子、标量顶点及余标架变化。再代入 §4 的真实源变换，可将九条对称源相容条件和九条标量接触源各写为

$$\operatorname{SourceMap}(r)V(p)
=N\bigl[TD(p)-D(p-r)T\bigr].\tag{6.3}$$

对两条外腿 $D(p_{\rm in})u_{\rm in}=0$、$\zeta_{\rm out}D(p_{\rm out})=0$，取 $r=p_{\rm in}-p_{\rm out}$，右侧被原两条场方程消去。区别于依赖协变规范固定与 Faddeev–Popov 幽灵场的微扰非阿贝尔 Slavnov–Taylor 恒等式 [36]，式 (6.2)–(6.3) 在非定常自旋挠率—标量凝聚背景上无需引入任何幽灵场，直接将经典阿贝尔电动力学 Ward–Takahashi 恒等式 [22, 23] 精确推广为同时涵盖非阿贝尔规范切向与局域 Lorentz 双矢切向的 18 条恒等式，并将背景联络对易子、标量扭矩与余标架导数一并纳入，使源相容条件直接由在壳外腿方程支付，无需在散射计算之外附加人为流守恒假设。

对制备关系 (4.10)，实际实转移源为

$$j_b=\frac{s}{2}u_{\rm out}^\dagger
\left[SV_b(p_{\rm in})+V_b(p_{\rm out})^\dagger S\right]u_{\rm in}.
\tag{6.4}$$

两项分别接受一条外腿方程。全部 $SV_b$ 还保持原 $Q$ 荷；非零转移连接相同 $Q$ 荷的外态，于是共转表示与原表示的能量转移相同。

### 6.2 动态交换、接触项与费米交换

将 97 个活跃玻色源送入原 289 维多项式分解，得到辅助源、九个标量接触源、$f_{79}$、$f_{24}$ 及九行相容条件：

**定理 6.1（弯曲规范—Lorentz 源相容律、活跃树作用与无参 ECSK 轴矢接触项，`L9`）。** 在壳外腿方程经 18 条恒等式 (6.2)–(6.3) 自动消去全部九行对称源相容余项；在相应动态块可逆处，原活跃玻色方向的精确树作用为

$$\mathcal L_{\rm tree,act}=-\frac12\left[
 j^\sharp C_{\rm contact}j
+f_{79}^\sharp A_{79}^{-1}f_{79}
+f_{24}^\sharp B_{24}^{-1}f_{24}\right],\tag{6.5}$$

其中对式 (6.4) 制备实源，完整 252 维载体上的 24 个对偶补块顶点 $f_{24}$ 恒等于零；而 24 个实 Lorentz 自旋联络方向的代数消元逆将全部自旋源精确压缩为四条轴矢双线性接触相互作用

$$\mathcal A^a=s\xi^\dagger S\gamma^a\gamma^5\xi,
\qquad
\boxed{\mathcal L_{\rm spin}=\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b.}
\tag{6.6}$$

**证明。** 将在壳条件代入式 (6.3) 得九行相容条件为零；对保留与消去块逐级应用配方恒等式 (4.2) 即得式 (6.5) 及原 289 行辅助场恢复。将表 6.1 第 2 行的 24 个双矢顶点代入 §4.1 第三步 $24\times 24$ 自旋联络块代数逆并按时间与空间指标收缩，直接给出式 (6.6) 的洛伦兹号差 $\eta_{ab}$ 与系数 $\frac{3N}{16}$；对式 (6.4) 的实制备配对逐列核验知 $f_{24}=0$。∎

式 (6.6) 是 (6.5) 中的实际局部四费米接触项。从引力理论史审视，它正是 Kibble [10]、Sciama [11] 与 Hehl–von der Heyde–Kerlick–Nester [12] 所确立的 Einstein–Cartan–Sciama–Kibble（ECSK）无传播挠率轴矢四费米子接触相互作用，但此处不再含有独立可调的引力常数或 Immirzi 类参数——系数 $\frac{3N}{16}$ 与轴矢双线性权重 $s=\sqrt2$ 完全由同一母作用锁定。

多粒子读数由同一有限 CAR 表示完成。对一体算子 $A,B$，正规序将 $d\Gamma(A)d\Gamma(B)$ 分成一体项 $d\Gamma(AB)$ 和四算子项。后者在两个占据向量上的矩阵元含有两种配对，第二种带负号；这个负号来自原产生、湮灭算子的反交换，而不是在四腿结果末端手工添加。原两个手征分量的双占据向量范数平方为 4；同一颜色电流的正规读数为 $216/125$，除以此范数后为 $54/125$。完整作用与配对都在形成四算子乘积后再读取。

### 6.3 外围 61 个标量及非零物质返回

设 $J$ 为原九维实标量轨道的列矩阵，

$$P_\perp=I-J(J^{\mathsf T}J)^{-1}J^{\mathsf T}.
$$

原色 SU(2) 在该空间的作用生成两个正交投影

$$P_d=-\frac43\sum_i\rho_i^2P_\perp,\qquad P_s=P_\perp-P_d,
\qquad\operatorname{rank}P_s=25,\quad\operatorname{rank}P_d=36.\tag{6.7}$$

记 $r=|\mathbf k|^2$、$\Delta_s=\lambda^2/N^2+r-2$、$\Delta_d=\Delta_s+27/50$、$\rho(\mathbf k)=\sum_i k_i\rho_i$。完整投影逆为

$$\boxed{G_\perp=\frac1N\left[
\frac{P_s}{\Delta_s}+\frac{\Delta_dP_d+2i\alpha_0\rho(\mathbf k)P_\perp}{\Delta_d^2-\alpha_0^2r}
\right],\qquad\alpha_0^2=\frac{18}{25}.}\tag{6.8}$$

它与原标量算子左右相乘均为 $P_\perp$，且不含角度或 $|\mathbf k|$ 分母。对正号源 $z_\perp=P_\perp z$，诱导标量 $\eta=-G_\perp z_\perp$ 还须送入原 Yukawa 混合 $M$，得到

$$\xi=D_6^{-1}MG_\perp z_\perp,\qquad\zeta=0.\tag{6.9}$$

$M$ 的输出位于 $\Lambda^6$；它一般非零，虽然 $Y_R$ 在 $\Lambda^6$ 输入上为零。式 (6.9) 正是标量传播之外不可省去的物质返回。连同 (6.8)，全部原外围 1078 行恢复为相应源。

完整标量源通过 $z_J=J^{\mathsf T}z$ 与 $z_\perp$ 接到两部分，投影和为 $I_{70}$。将

$$-\frac12z_\perp^\sharp G_\perp z_\perp\tag{6.10}$$

与 (6.5) 相加，得到全部原玻色方向对这些物质双线性源的树响应。原点的外围局部项为 $z^{\mathsf T}P_sz/(4N)+25z^{\mathsf T}P_dz/(73N)$。两个完整弱五源块及其标量—散度接触项在补充材料 S2.2 给出。

### 6.4 原 216 维自由外腿

原完整物质算子生成等距嵌入 $F_{\rm free}:\mathbb C^{216}\to\mathcal M$，满足

$$F_{\rm free}^\dagger F_{\rm free}=I,\qquad
F_{\rm free}F_{\rm free}^\dagger=P_{\rm free},\qquad
Y_R(v)F_{\rm free}=0.\tag{6.11}$$

原 $H$ 在其中分为 50 个二阶块和 29 个四阶块。以 $\chi_c=\pm1$ 表示手征、$\mathbf q=\mathbf k/\sqrt2$，将原 Hamiltonian 除以 $N\sqrt2$ 后，两类块为

$$h_{\chi_c,s}=\chi_c\left(\frac32I+\mathbf q\cdot\boldsymbol\sigma\right),$$

$$h_{\chi_c,d}=\chi_c\left(\frac32I+\mathbf q\cdot\boldsymbol\sigma\otimes I
+\frac3{10}\sum_i\sigma_i\otimes\sigma_i\right).\tag{6.12}$$

色单态、双态均指原背景保持的色 SU(2)。单态的两个谱投影为 $(I\pm\widehat{\mathbf q}\cdot\boldsymbol\sigma)/2$。双态的平行自旋投影给出 $\chi_c(9/5\pm|\mathbf q|)$；在混合自旋子空间上，先提出手征符号 $\chi_c$，再减去 $6I/5$，所得算子的平方为 $(|\mathbf q|^2+9/25)I$，给出其余两支 $\chi_c(6/5\pm\sqrt{|\mathbf q|^2+9/25})$。所有投影经 $F_{\rm free}$ 返回原 252 坐标。零动量用合并投影直接定义，避免依赖一个不存在的方向。

由这些投影，原频率 resolvent 与传播分别为

$$G_H(E,\mathbf k)=\sum_b\frac{\Pi_b(\mathbf k)}{E-E_b(\mathbf k)},\qquad
U_{\rm free}(t,\mathbf k)=\sum_b e^{-iE_b(\mathbf k)t}\Pi_b(\mathbf k).
\tag{6.13}$$

它们满足投影空间上的双侧逆和时间群律，且外腿实际满足原 primal、独立 dual 与标量方程。全部 70 个实标量顶点在两个自由外腿之间消去，故本族的标量交换选择律由原投影产生。

### 6.5 留数决定外腿的尺度

单位坐标向量尚不是单位作用外腿。对真实场 $\psi(x)=u+x^0v$ 取原时间 jet，由 (2.7) 读取

$$\mathcal L(u,\epsilon v)-\mathcal L(u,0)
=\epsilon s\operatorname{Re}\bigl(i\langle u,\gamma^5v\rangle\bigr).
\tag{6.14}$$

原体积 $N$ 与逆余标架 $N^{-1}$ 在此相消，时间动能配对为 $G=s\gamma^5$。于是原频率核与其逆为

$$K(E,\mathbf k)=s\gamma^5(E-H_{\rm orig}(\mathbf k)),\qquad
G_K(E,\mathbf k)=\sum_b\frac{(\chi_{c,b}/s)\Pi_b(\mathbf k)}{E-E_b(\mathbf k)}.
\tag{6.15}$$

自由空间中有 106 个负动能方向、110 个正动能方向（这一手征正负号差正是经典 c 数旋量场在进行费米反对易正规序量子化之前的标准粒子—空穴动能读数，进入 §6.2 与 §7.4 的有限 CAR 表示后由产生—湮灭正规序自然接管）。另一个由同一相位速率读取的正配对为 $s\gamma^5Q$，在 202 个方向上权重为 $s$，在 14 个右手 $\Lambda^6$ 方向上为 $3s$。这两个配对分别来自时间导数和相位荷，不因后一项为正就改写前一项的符号。

对右手外腿，原留数给出准确尺度

$$u_{\rm action}=s^{-1/2}u_{\rm coordinate}=2^{-1/4}u_{\rm coordinate}.
\tag{6.16}$$

因此每条双线性源除以 $s$，四腿树系数除以 $s^2=2$。这个尺度同时作用于动态项与接触项。

### 6.6 一个非零、在壳且守恒的交换

取 (6.12) 中第一个右手 $\Lambda^4$ 色单态及第一个右手 $\Lambda^2$ 色单态，以各自真实正 helicity 投影产生外腿。其动量为

$$\Lambda^4:\quad(0,0,1/\sqrt2)\longrightarrow(1/\sqrt2,0,0),$$

$$\Lambda^2:\quad(0,0,-1/\sqrt2)\longrightarrow(-1/\sqrt2,0,0).
\tag{6.17}$$

四条腿的原频率均为 $2N\sqrt2$，$Q$ 荷均为 1，定常频率为 $2N\sqrt2-\omega$。因此总原能量和总三动量守恒。它们的完整 252 维坐标列及转移源保存在补充材料 S2 的伴随数据中。

将四条腿代入 (6.4)，两条 97 分量源非零，原九行相容式、九个标量接触源以及 24 补块源均为零。两种外幂级之间的交叉顶点也为零，所以本通道的物种交换项确实消失。剩下的直接系数仍有两个组成：完整 $79\times79$ 动态逆，以及实际自旋接触。

写

$$d=\frac{460567872925762140980306550635427551740791}
{457772441257406774332263414159620301790297}.
$$

原坐标单位腿给出

$$D_{\rm dyn}=\sqrt{30}\,d,\qquad
C_{\rm loc}=-\frac{9\sqrt{30}}{50},\qquad
\mathcal K_{\rm coordinate}=-D_{\rm dyn}-C_{\rm loc}
=-\sqrt{30}\left(d-\frac9{50}\right).\tag{6.18}$$

$-D-C$ 的两个源排列来自 (6.5) 的 $-\frac12$ 二次式。动态解与接触场共同恢复原 289 行。最后以 (6.16) 重新生成四条外腿、两条源和完整诱导场，得到

**命题 6.2（原作用留数归一的 42 位有理数在壳守恒树交换，`L9-L10`）。** 在式 (6.17) 能量—三动量与 $Q$ 荷同时守恒的四条右手自由在壳外腿上，经式 (6.16) 动能留数尺度 $u_{\mathrm{action}}=2^{-1/4}u_{\mathrm{coordinate}}$ 重新生成两条 97 分量源与完整 289 维诱导场后，79 维动态传播逆与式 (6.6) ECSK 自旋接触项共同给出非零在壳树交换振幅

$$\boxed{\mathcal K_{\rm action}
=-\frac{\sqrt{30}}2\left(d-\frac9{50}\right)
\simeq-2.2623860895,}\tag{6.19}$$

且所得诱导场逐行满足原 289 维受迫场方程。

**证明。** 将补充材料 S2.1 式 (S2.1) 的四条单位坐标腿代入 (6.4) 生成两条 97 分量源，精确有理数消元解出 $79\times 79$ 动态逆读数 $D_{\mathrm{dyn}}=\sqrt{30}\,d$ 与式 (6.6) 自旋接触读数 $C_{\mathrm{loc}}=-9\sqrt{30}/50$（式 (6.18)）；按式 (6.16) 将四条腿同步乘以 $2^{-1/4}$（四腿振幅除以 $s^2=2$）并经多项式逆嵌入回写原 289 行，残差逐行恒为零。分子分母各四十二位的精确有理数 $d$ 直接作为后续散射识别的无近似基准。∎

### 6.7 原电、磁主部与静态读数

从同一规范辅助消元读出的最高导数密度为

$$\mathcal L_{\rm prin}=\frac{N}{2\sigma}\kappa(E,E)
-\frac1{2\sigma N}\kappa(B,B).\tag{6.20}$$

换到固有时 $\tau=Nt$ 时，同时变换连接一形式 $A_\tau=A_t/N$ 和积分密度 $dt=d\tau/N$，得到

$$\mathcal L_{\rm prin,\tau}=\frac{N^2}{2\sigma}\kappa(E_\tau,E_\tau)
-\frac1{2\sigma N^2}\kappa(B,B).\tag{6.21}$$

由此连同静态源响应，我们确立树级本构速度比与裸时间规范荷的零库仑留数门禁：

**命题 6.3（原生 Hodge 本构速度比与裸时间规范荷零库仑留数禁令，`L11`）。** 在固有时 $\tau=Nt$ 与原生配对 $\sigma=1/2,N^2=54/125$ 下，电、磁主部逆系数分别为 $108/125$ 与 $125/27$；完整物质与标量的原坐标特征速度为 $N$，横向规范波特征速度为 $1/N$，二者在同一时钟下的树级本构速度比为

$$\frac{c_{\rm gauge}}{c_{\rm matter}}=\frac1{N^2}=\frac{125}{54}.\tag{6.22}$$

与此同时，对全部 12 个裸时间规范电荷源求解完整 289 维耦合静态系统后，$12\times 12$ 静态响应矩阵的全部 144 个条目在零动量处均具有有限方向延拓，**在任意空间方向上的 $1/|\mathbf k|^2$ 库仑极点留数恒等于零**；其唯一的软相位极点系数因式分解为

$$\operatorname{Res}_{q^{-2}}G_{\rm source}
=C_{\rm null}(0)^{\mathsf T}C_{\rm constraint}C_{\rm null}(0),\qquad
(C_{\rm constraint})_{22}=\frac{9023}{5000N},\tag{6.23}$$

其余条目全为零（下标从 0 计），故对满足原相容条件 $C_{\rm null}j=0$ 的正则源该留数亦恒为零。

**证明。** 由式 (6.20)–(6.21) 代入 $\sigma=1/2,N^2=54/125$ 直接读出逆刚度与速度比 (6.22)；将 12 个时间规范单位源送入 §4 的无分母多项式截面逆并展开至 $q\to 0$，精确有理约化给出全部 144 个条目在相容子空间上零极点留数及式 (6.23) 分解（随稿数据见补充材料 S2.3）。∎

按照 Hehl 与 Obukhov [24] 总结的前度规电动力学观点，电磁场的拓扑守恒律独立于度规，而传播光锥完全由时空本构张量的电—磁刚度之比涌现生成；式 (6.20)–(6.22) 在树级原生配对中首次展示了这一机制，而 §11.4 定理 11.4 将进一步在包含完整量子极化与背景混合的 289 场修饰响应上导出物理横波 Maxwell 光速锥 $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$。同时，命题 6.3 的零留数禁令（表 2 第 4 项）恰与 Dirac [27] 关于裸旋量源不自动携带物理库仑场的经典洞察相呼应：§§9–10 将证明，唯有含完整配置插入的源生修饰态与静止电子腿激活空间规范槽 21 与 34 之差（$A_1^{\,0}-A_2^{\,1}$），才产生非零库仑种子 $K_*=\frac{9023}{9000}\sqrt{30}$。

对原十个度规源，令 $\delta g=e_0^{\mathsf T}\eta\delta e+\delta e^{\mathsf T}\eta e_0$，响应 $R_g$ 按正号源约定满足 $\delta g=-R_gJ$。静态轴向 $k=\sqrt2q$ 的一个完整读数是

$$R_{00,00}(q)=N^3\frac{625q^6+7800q^4+15984q^2-31104}
{625q^8+2550q^6+7704q^4+23328q^2-93312}.\tag{6.24}$$

它在原点为 $N^3/3$，而 $\lim_{|k|\to\infty}|k|^2R_{00,00}=2N^3$。十乘十度规读数均在原点有限；完整场在 $J_{03}$ 通道中的八个 $1/q$ 项却仍存在，只是在度规映射下消去。源、完整场和最终观测量各自保留的信息，由这些实际分子清楚地区分。

<a id="sec-7"></a>

## 7 三维空间 Dirac 自伴定义域、局域规范准备与全词 CAR 正性

### 7.1 同一个十二维符号

回到 §1 的原占据空间。这一次 48 个规范扰动方向全部到场，不再只传唤一个 $T$。从实际连接读取的定常 Hamiltonian 为

$$h(\mathbf k)=h_0+\sum_iH_i k_i,\qquad
h_0=\left(\frac{3Ns}{2}-\omega\right)\gamma^5
+iN\alpha_0\sum_i\gamma^0\gamma^i\rho_i,\qquad
H_i=-N\gamma^0\gamma^i.\tag{7.1}$$

所有矩阵限制在 $\mathcal H_{12}$，$\rho_i$ 是三个原色生成元。$h(\mathbf k)$ 对每个实动量 Hermitian，且与 $Q$ 对易。原 Hamiltonian 为 $H_{\rm orig}=h+\omega Q$。§1 的 $h_0$ 即上式的零动量部分。

对原规范方向 $A_\mu^a$，Hamiltonian 力为

$$T_{0a}=-i\rho_a,\qquad T_{ia}=iN\gamma^0\gamma^i\rho_a,\qquad
B_{\mu a}=-sQT_{\mu a}.\tag{7.2}$$

两种算子都保持 $\mathcal H_{12}$，且都 Hermitian。令 $T_*$、$B_*$ 的列分别为 $T_a\psi_0$、$B_a\psi_0$，即保留原背景幅度 $\psi_0=2w$：

**命题 7.1（四十八方向占据态电流响应与全动量上半平面一致界，`L12`）。** 两条物质腿的有序预解给出全部 $48\times 48$ 占据态电流响应

$$\Pi(E,\mathbf k)=B_*^\dagger(E-h(\mathbf k))^{-1}T_*
-B_*^{\mathsf T}(E+h(-\mathbf k))^{-\mathsf T}\overline{T_*},
\tag{7.3}$$

它与原 289 维系统中消去占据物质与独立对偶所得 Schur 响应逐项相同，且在零动量时间方向给出

$$\Pi_{00}(z\omega,0)=-\frac{200\sqrt{30}}{27(z^2-4)}.\tag{7.4}$$

对任意 $E\in\mathbb R$、$\eta>0$ 及任意 $\mathbf k\in\mathbb R^3$，厄米内积虚部给出下界

$$\eta\|v\|\leq\|[(E+i\eta)I-h(\mathbf k)]v\|,
$$

从而上半平面预解处处存在，且满足动量无关的一致算子范数界

$$\boxed{\|\Pi(E+i\eta,\mathbf k)\|\leq\frac{1512\sqrt2}{125\eta}.}
\tag{7.5}$$

**证明。** 将原 289 维系统的 48 行占据旋量与独立对偶块按式 (4.2) 求逆并保留反向动量转置与共轭，即得 (7.3) 与零动量有理读数 (7.4)。因 $h(\mathbf k)$ 厄米，$\operatorname{Im}\langle v,[(E+i\eta)I-h(\mathbf k)]v\rangle=\eta\|v\|^2$，由 Cauchy–Schwarz 不等式得预解范数界 $\eta^{-1}$，乘以固定矩阵列范数上界即证得全动量一致界 (7.5)；零动量处同一频率式亦由受迫常微分方程延迟核的正阻尼 Laplace 积分精确恢复。∎

### 7.2 空间载体及无界生成元的真实定义域

有限矩阵告诉我们每一个动量怎样演化；可归一的空间状态还需要一个完整 Hilbert 空间。取

$$\mathscr H=L^2(\mathbb R^3,\mathbb C^{12}),\qquad
U(t)=\mathcal F^{-1}\,e^{-it h(2\pi\xi)}\,\mathcal F.\tag{7.6}$$

每个纤维的指数幺正，故它保持 $L^2$ 范数，并具有显式逆 $U(-t)$。当 $t\to0$，逐点差的平方被 $4\|\widehat f(\xi)\|^2$ 控制，支配收敛给出强连续性。这里不需要 $h(\mathbf k)$ 在全部动量上有界。

**定理 7.2（原空间传播与自伴定义域双向刻画，`L13`）。** 式 (7.6) 生成 $\mathscr H$ 上的强连续幺正群。其自伴 Hamiltonian $\mathsf H$ 的完整定义域及作用为

$$\boxed{\mathcal D(\mathsf H)=
\{f\in\mathscr H:h(2\pi\xi)\widehat f(\xi)\in L^2\},\qquad
\mathsf Hf=\mathcal F^{-1}\bigl(h(2\pi\xi)\widehat f(\xi)\bigr).}
\tag{7.7}$$

对域中每个向量，$\partial_tU(t)f=-i\mathsf HU(t)f$ 在所有实时间成立。Schwartz 场属于该域，且由 Fourier 微分得到原位置空间 Dirac 方程；一般 $L^2$ 初态则满足相应弱方程与独立 dual 的弱读回。

**证明。** 正向包含由 Fourier 酉性与支配收敛直接给出；容易漏掉的是反向包含：若不做双向证明，便只知道能量乘子平方可积的向量落在定义域内，而无法确认 Stone 定理 [17] 所对应的真实最大自伴生成元没有更大定义域（可对照 Thaller [18] 关于一阶自由 Dirac 算子 Fourier 乘子域的标准刻画，此处含非阿贝尔背景联络与自旋挠率偏移 $h_0$）。事实上，若 $U(t)f$ 在零处具有 $L^2$ 强导数，则差商的一个子列几乎处处收敛；每个有限维动量纤维的矩阵指数导数又已知为 $-ih(2\pi\xi)\widehat f(\xi)$。两种极限几乎处处相等，迫使该能量乘子属于 $L^2$。因此 (7.7) 正是完整自伴定义域。∎

原时间传播为

$$U_{\rm orig}(t)=P(t)U(t),\qquad P(t)=e^{-i\omega tQ}.\tag{7.8}$$

内部相位与向量值 Fourier 变换交换，故这个等式对全部 $L^2$ 向量成立。空间常量背景依然是产生系数的原场；进入 $L^2$ 的是准备、扰动和受迫场。

### 7.3 原规范控制生成空间准备

对连续 $L^2$ 源 $f(t)$，定义真实强积分

$$u(t)=\int_0^tU(t-\tau)f(\tau)\,d\tau.\tag{7.9}$$

它连续、零初值，满足

$$\frac d{dt}\bigl[U(-t)u(t)\bigr]=U(-t)f(t),\qquad
\|u(t)\|\leq\int_0^t\|f(\tau)\|\,d\tau\quad(t\geq0).
\tag{7.10}$$

过去源为零时，过去场也为零。将另一个解与 (7.9) 相减，交互表象中的导数为零，故相同初值的 mild 解唯一。

让原有限维规范力点态作用于一个 $L^2$ 空间剖面，便得到从 $\mathcal H_{12}$ 到 $\mathscr H$ 的实际源算子历史 $F(t)$。它生成有界线性准备映射

$$K_tu=\int_0^tU(t-\tau)F(\tau)u\,d\tau,\qquad
\|K_t\|\leq\left|\int_0^t\|F(\tau)\|\,d\tau\right|,\qquad t\in\mathbb R.\tag{7.11}$$

这个控制是真实场源，准备的方向仍来自原占据向量 $w$。源构造提供非零因果历史和正准备时刻 $t_p$，使 $K_{t_p}w\ne0$。于是

$$u_p=\frac{K_{t_p}w}{\|K_{t_p}w\|},\qquad
\rho_p=|u_p\rangle\langle u_p|\tag{7.12}$$

是规范化的空间纯态；未归一的 $K_t|w\rangle\langle w|K_t^\dagger$ 同时保留准备强度。对任意有界空间算子 $A$，

$$\langle K_tw,AK_tw\rangle=\langle w,K_t^\dagger AK_tw\rangle.\tag{7.13}$$

记 $I_{12}:\mathcal H_{12}\to\mathcal M$ 为原等距嵌入，将右侧算子提升为 $\widetilde A_t=I_{12}K_t^\dagger AK_tI_{12}^\dagger$。独立对偶评价前还须作一次自旋交换 $S$；由 $\chi_0=s\psi_0^\dagger S$、$S^2=I$ 及 $\psi_0(0)=2I_{12}w$，得到

$$\chi_0(0)\bigl(S\widetilde A_t\psi_0(0)\bigr)
=4s\,\langle w,K_t^\dagger AK_tw\rangle
=4s\,\langle K_tw,AK_tw\rangle.\tag{7.13a}$$

原源量子评价读出 (7.13a) 除以 $4s$ 的值，恰为 (7.13)。自旋交换只在完整算子形成后作用一次，不插入中间乘积；这样，空间准备与原独立对偶始终评价同一个对象。

### 7.4 全部有限 CAR 词

空间准备不能只验证一个一体期望值。给定任意有限测试族 $f_1,\ldots,f_m\in\mathscr H$，允许重复、线性相关和非正交，并把 $u_p$ 一起加入其有限维张成空间 $E$。在 $\Lambda E$ 上定义产生、湮灭算子，满足

$$\{a(f),a(g)\}=0,\qquad
\{a(f),a^\dagger(g)\}=\langle f,g\rangle I.\tag{7.14}$$

**命题 7.3（任意有限测试族的全词 CAR 正性与母配对次序，`L15`）。** 对任意（允许重复、线性相关且非正交的）有限测试族 $f_1,\ldots,f_m\in\mathscr H$ 及单位空间准备态 $u_p$，令 $E=\operatorname{span}\{u_p,f_1,\ldots,f_m\}$，在反对称张量空间 $\Lambda E$ 上每个有限产生／湮灭词 $W$ 均具有扩张一致的向量态评价

$$\omega_p(W)=\langle u_p,Wu_p\rangle_{\Lambda E}.\tag{7.15}$$

这里 $u_p$ 位于一粒子层，而 $W$ 本身可穿越任意中间粒子数层。将 $E$ 扩大时，外代数等距嵌入与全部原产生、湮灭算子精确交织，故 $\omega_p(W)$ 不依赖额外添入的测试方向，且对全部有限词满足线性、伴随相容与正性 $\omega_p(W^\dagger W)\ge 0$。

**证明。** 子空间等距包含 $E\hookrightarrow E'$ 诱导的反对称张量等距嵌入 $\Lambda E\hookrightarrow\Lambda E'$ 保持外积与内积伴随，故逐个交织 $a^\dagger(f)$ 与 $a(f)$（$f\in E$），从而保持任意有限词 $W$ 在一粒子态 $u_p$ 上的内积 (7.15)；正性直接来自 Hilbert 内积 $\langle Wu_p,Wu_p\rangle_{\Lambda E}=\|Wu_p\|^2\ge 0$（补充材料 S3.3）。∎

命题 7.3 在一体二次量子化 [4] 与一般准自由 CAR 态代数 [20] 之间给出了无需正交化预处理、直接与 252 维独立对偶母配对相接的构造性有限子代数载体。若 $J_E:E\to\Lambda E$ 是一粒子嵌入，返回一体输入的实际算子是 $J_E^\dagger WJ_E$。先形成整个词，再用 (7.13) 与单次末端翻转 $S$ 拉回母作用。特别地，

$$J_E^\dagger ABJ_E\ne
(J_E^\dagger AJ_E)(J_E^\dagger BJ_E)
\tag{7.16}$$

在有中间粒子数返回时完全可能；差值正是 (3.15) 所刻画的补空间返回项。一个四点词将该非交换次序变成当场可见的反例（表 2 第 3 项）：对任意四个不必正交的空间测试向量 $f,g,h,k$，在单位一粒子准备 $u_p$ 上有

$$\langle u_p,a^\dagger(f)a(g)a^\dagger(h)a(k)u_p\rangle
=\langle u_p,f\rangle\langle g,h\rangle\langle k,u_p\rangle.\tag{7.16a}$$

从右向左作用时，量子态依次经过一粒子、真空、一粒子、真空、一粒子层；三个内积正是这三次穿越的精确幅。令四个测试向量全取 $u_p$，完整词读数精确等于 $1$；反之，若过早将每个产生或湮灭算子压缩到单粒子层 $J_E^\dagger(\cdot)J_E$ 后再相乘，读数当场坍缩为 $0$。中间粒子数层的返回，正是完整词乘积不可省去的物理内容。

### 7.5 局域电流成为可积读数

令 $g\in L^\infty(\mathbb R^3)$ 为实控制剖面，$T$ 为 (7.2) 的原规范力。局域 Hamiltonian 是有界自伴算子

$$R_gf(\mathbf x)=g(\mathbf x)Tf(\mathbf x).
\tag{7.17}$$

相应原电流矩阵仍为 $B=-sQT$。对 $f,h\in L^2$，局域电流密度 $g f^\dagger Bh$ 属于 $L^1$，且

$$\|g f^\dagger Bh\|_{L^1}
\leq\|g\|_\infty\|B\|\|f\|_2\|h\|_2.\tag{7.18}$$

这给电流积分一个真实的函数空间意义。下一节将让同样的控制以有限幅度作用，而不先假定响应已经线性。

<a id="sec-8"></a>

## 8 全实时间非微扰幺正发展与算子范数因果 Kubo 导数

### 8.1 从原控制生成全时间发展

设 $R:\mathbb R\to\mathcal B(\mathscr H)$ 在算子范数中连续，且每个 $R(t)$ 自伴。原局域规范历史 $R(t)=R_{g_t}$ 是实际的一类输入：$t\mapsto g_t$ 在 $L^\infty$ 范数中连续、剖面实值，规范矩阵由 (7.2) 生成。每段紧时间区间上存在界 $M$；整条时间轴不要求共用一个界。

给定任意实幅度 $\epsilon$、任意实初始时刻 $a$ 和任意 $u\in\mathscr H$，在交互表象中求

$$y'(t)=-i\epsilon R_H(t)y(t),\qquad y(a)=u,\qquad
R_H(t)=U(-t)R(t)U(t).\tag{8.1}$$

$U$ 只需强连续。$R_H(t)$ 的逐向量连续性和局部统一范数界足以使 (8.1) 的向量场联合连续；无界自由 Hamiltonian 的群本身不必算子范数连续。

**定理 8.1（全时间源生幺正发展，`L17`）。** 对上述每个 $R$、每个 $\epsilon,a,u$，式 (8.1) 有定义在全部 $\mathbb R$ 上的唯一强解。由它生成的物理传播

$$W_\epsilon(t,a)u
=U(t)y_{\epsilon,a,U(-a)u}(t)\tag{8.2}$$

是 $\mathscr H$ 上真正的双时刻幺正算子，满足

$$W_\epsilon(a,a)=I,\quad
W_\epsilon(t,b)W_\epsilon(b,a)=W_\epsilon(t,a),\quad
W_\epsilon(t,a)^{-1}=W_\epsilon(a,t),\quad
\|W_\epsilon(t,a)u\|=\|u\|.\tag{8.3}$$

物理场对每个生成元域中的测试向量满足原受控弱方程。

**证明。** 难处在于把解一路延到全时间：状态空间无界，普通 Picard 构造只在初值附近给出局部窗口。先把无界的状态变量变成全局有界的径向函数

$$b(v)=\frac{v}{1+\|v\|},\qquad \|b(v)\|\leq1,\qquad
\|b(v)-b(w)\|\leq2\|v-w\|.\tag{8.4}$$

在任意给定有限窗口内，用向量场

$$F(t,v)=-i\epsilon R_H(t)(1+\|u\|)b(v)\tag{8.5}$$

作 Picard 构造。它在全部状态空间有界且统一 Lipschitz，因此窗口长度不再被小初值邻域限制。沿所得轨道，自伴性给出

$$\frac d{dt}\|v(t)\|^2
=2\operatorname{Re}\langle v(t),-i\epsilon R_H(t)v(t)\rangle
\frac{1+\|u\|}{1+\|v(t)\|}=0.\tag{8.6}$$

于是 $\|v(t)\|=\|u\|$，(8.5) 的径向因子沿整条轨道恰为 1；构造实际解回 (8.1)，没有改变物理时间。重叠窗口内的两个原解之差也保范数，且初值为零，所以完全相同。任意有限窗口据此拼成全时间解。再由唯一性证明加法、复数倍数、复合律与反向发展，即得 (8.3)。∎

整条路线只有两步：先用全局有界径向向量场换来任意大有限窗口上的不动点，再用自伴演化范数守恒把辅助径向因子精确还原为 $1$。与 Dyson 时间序级数展开 [19] 及 Kato 关于 Banach 空间非自治双曲演化方程的经典定理 [5，条件 C1–C4、定理 1–5] 相比，定理 8.1 无需假设含时生成元定义域恒定与强 $C^1$ 可微性，亦无需控制算子在整条实时间轴 $\mathbb R$ 上具有统一上界（如 §8.4 中沿 $\max(t,0)$ 无界增长的控制历史同样精确闭合），即可对任意实幅度 $\epsilon\in\mathbb R$ 生成双时刻幺正群。

### 8.2 同一个解族的算子范数导数

现在固定任意实 $t$，初始时刻取 0。在连接 $0$ 与 $t$ 的时间段上取 $M\geq\sup\|R(\tau)\|$，定义

$$D(t)u=-i\int_0^tU(t-\tau)R(\tau)U(\tau)u\,d\tau.
\tag{8.7}$$

积分对每个 $u$ 在 $\mathscr H$ 中强收敛，且 $\|D(t)\|\leq M|t|$，所以它定义一个有界算子。

**定理 8.2（真实幅度算子范数导数，`L17`）。** 全实幅度传播 $\epsilon\mapsto W_\epsilon(t,0)$ 在 $\epsilon=0$ 具有算子范数导数 $D(t)$；同一实际发展满足统一余项界

$$\boxed{\|W_\epsilon(t,0)-U(t)-\epsilon D(t)\|
\leq\epsilon^2M^2|t|^2\qquad(|\epsilon|\leq1).}\tag{8.8}$$

因 $t$ 任意，结论适用于全部实时间。

**证明。** 决定性的一步是让余项界对整个单位球统一。从原积分方程开始，交互态与初态的差先满足

$$\|y_\epsilon(\tau)-u\|\leq|\epsilon|M|\tau|\|u\|.
$$

将这个差代回积分一次，所得一阶剩余量至多为 $\epsilon^2M^2|t|^2\|u\|$。常数 $M$ 对整个单位球相同，取上确界便得到 (8.8)。这一单位球上的统一性，把每个态的强导数提升为算子范数导数。全局传播本身对所有实 $\epsilon$ 已由定理 8.1 定义；求导使用的是这个真实解族。∎

### 8.3 双侧电流、Kubo 积分与原源

取有界自伴电流算子 $B$、任意初态 $u\in\mathscr H$，定义有限控制下的电流期望

$$J_\epsilon(t)=\operatorname{Re}\langle W_\epsilon(t,0)u,
B W_\epsilon(t,0)u\rangle.
$$

将定理 8.2 的单位球一致算子范数余项界 (8.8) 同时作用于左右两条态腿，立得

$$\left.\partial_\epsilon J_\epsilon(t)\right|_0
=\operatorname{Re}\bigl[
\langle D(t)u,BU(t)u\rangle+
\langle U(t)u,BD(t)u\rangle\bigr].\tag{8.9}$$

令 $B_H(t)=U(-t)BU(t)$ 并将 (8.7) 代入，即证得全时间因果线性响应恒等式：

**推论 8.3（双侧变分与全时间因果 Kubo 对易子响应，`L16-L17`）。** 对任意 $u\in\mathscr H$、任意实时刻 $t\in\mathbb R$ 及 §8.1 的任意规范控制历史 $R$，有限幅度电流族 $\epsilon\mapsto J_\epsilon(t)$ 在 $\epsilon=0$ 处可微，且其真导数严格等于有向对易子积分

$$\boxed{\left.\partial_\epsilon J_\epsilon(t)\right|_0
=\operatorname{Re}\,i\int_0^t
\langle u,[R_H(\tau),B_H(t)]u\rangle\,d\tau.}\tag{8.10}$$

**证明。** 由定理 8.2 的算子范数展开 $W_\epsilon(t,0)=U(t)+\epsilon D(t)+O_{\mathcal B(\mathscr H)}(\epsilon^2)$ 与 $B$ 的有界自伴性立得式 (8.9)；代入式 (8.7) 的强收敛积分并利用 $U(t)$ 酉性将两侧内积合并为对易子 $[R_H(\tau),B_H(t)]$，即证得式 (8.10)。∎

与 Kubo [6, §2] 假设初态密度矩阵与未扰动哈密顿量对易（$[\rho,H]=0$，平衡态绝热开启并对量子 Liouville 方程作形式一阶截断）及算子代数 KMS 平衡微扰理论 [21] 相比，定理 8.1–8.2 与推论 8.3 在三方面推进了严格边界：第一，初态 $u$ 无需为 $\mathsf H$ 的本征态或热平衡态（尤其可直接取 §7.3 由有限时段受迫演化生成的非驻定空间局域准备态 $u_p$）；第二，先建立全部实幅度 $\epsilon\in\mathbb R$ 的非微扰幺正解族，再由单位球一致余项 $\epsilon^2M^2|t|^2$ 证出算子范数 Fréchet 导数；第三，显式区分推动态演化的哈密顿力 $T$ 与承载独立对偶配对的母作用电流 $B=-sQT$（省去 $-sQ$ 即触发 §1.2 的零化反例）。

对 $u=u_p$，先将整个响应算子

$$A_{\rm resp}(t)=i\int_0^t[R_H(\tau),B_H(t)]\,d\tau
\tag{8.11}$$

按逐向量强积分定义，再作规范化的 $K_{t_p}^\dagger A_{\rm resp}K_{t_p}$ 拉回。原完整母算子读出准确等于 (8.10)。若用二次量子化表示电流，对易子成为 §7.4 的有限 CAR 四点词；完整词的原源评价仍是同一读数。五位证人于是在同一个等式上签名：有限发展、双侧求导、Duhamel 积分、Kubo 对易子和原源评价。

原局域规范力与 $Q$ 对易，实际发展因唯一性也与 $P(r)$ 对易。准备时刻 $t_p$ 的原相位因此在真实字段上成为

$$\psi_{\epsilon,\rm orig}(t)=P(t+t_p)W_\epsilon(t,0)u_p.\tag{8.12}$$

其真实原交互方程为

$$\frac d{dt}\bigl[U_{\rm orig}(-t)\psi_{\epsilon,\rm orig}(t)\bigr]
=U_{\rm orig}(-t)(-i\epsilon R(t)\psi_{\epsilon,\rm orig}(t)).\tag{8.13}$$

原电流亦与该相位相容，所以 (8.10) 在原时间和准备总相位下保持。电流矩阵 $B=-sQT$ 已含对偶权重 $s$：准备场的幅度乘二时，电流及其导数乘四，与 §1 相同。母算子的独立对偶读回则按 (7.13a) 使用 $4s$，不再给已含权重的电流重复乘 $s$。若控制在过去为零，过去的物理场就是原自由发展。

### 8.4 有限窗口与真实空间的两个检验

开场那个电流再次出庭。§1 的原色时间规范控制 $T=-iI_4\otimes\rho_{01}$ 给出非交换的有限解。(1.8) 除以 $\epsilon$ 后，在 $\epsilon\to0$ 时趋向 (1.9)。令 $x=\omega t$、$\beta=\epsilon/\omega$，可以把整个比较写成

$$\frac{\omega J_\epsilon(t)}{s\epsilon}
=\frac{1-\cos(2x\sqrt{1+\beta^2})}{1+\beta^2}
\longrightarrow1-\cos2x.
\tag{8.14}$$

![有限原控制的电流与真导数](figures/main-03-finite-current.svg)

**图 3　有限电流如何趋向真导数。** 实曲线采用 (8.14) 的 $\epsilon/\omega=1,1/2,1/4$（金、灰、深蓝），朱红虚线为归一化真导数 $1-\cos2\omega t$，$\omega=18\sqrt{15}/125$。横轴 $\omega t$ 使用原时间，不是固有时。纵轴为单位占据态的 $\omega J_\epsilon/(s\epsilon)$；原有幅度场的电流乘四。有限幅度既改变振幅，也改变振荡频率。

这个四维原不变窗口验证非交换系数；真实 $L^2$ 例子则检验空间与时间的量词。原时间超荷在占据空间生成 $T=I$。对一个非零球形 $L^2$ 剖面 $f$，任意实 $\epsilon,a,t$ 的真实传播为

$$W_\epsilon(t,a)f=e^{-i\epsilon(t-a)}U(t-a)f.\tag{8.15}$$

例如 $\epsilon=3,a=100,t=-200$ 时，实际解是 $e^{900i}U(-300)f$；其范数非零，且不受原局部时间窗口或小幅度范围限制。另一个实局域控制历史在过去为零、未来按 $\max(t,0)$ 增长，它无需整条时间轴上的统一范数界；在 $\epsilon=-7,t=-1000$ 时，发展精确返回 $U(-1000)f$。

原非零因果准备还给出某个 $t_p>0$，其规范化原字段对全部实 $\epsilon,t$ 的范数恒为 1，并接受 (8.10) 的原源导数。有限不变窗口与全空间例子各自使用真实的载体，共同检查系数和全时间构造。

<a id="sec-9"></a>

## 9 源生电磁准备、电子绝对单位荷与静态库仑标量

§8 已将母作用电流接到三维实空间全时间幺正发展。现在让空间与配置准备本身进入规范场交换：先由同一母作用内生生成多体配置态，再将未破缺电磁生成元、289 场完整静态 Green 逆与物理静止电子接在同一套无自由参数公式中。这里的电荷单位与静态耦合均不由外部拟合补入；相位作用、双端准备及每一次归一化均可逐项追回原始作用定义。

### 9.1 含独立对偶的母作用局部密度认回同一传播算子

沿 [1] 的同一正光滑统一源及其实际九场构型，取实一阶射流（1-jet）
$j=(x,x_\mu)\in\mathbb R^{289}\times(\mathbb R^{289})^4$。将锚定仿射信号
$x+\sum_\mu(y^\mu-y_0^\mu)x_\mu$ 插入九组原场，得到含独立复线性对偶配对的局部母密度 $\mathcal L_{\mathrm{nat}}(j)$。物质腿按原共转矩阵插入；独立对偶按同一共转矩阵右复合，其系数不取复共轭。令 $\mathcal B=D^2\mathcal L_{\mathrm{nat}}(0)$，$\sigma_\emptyset(p)=1$、$\sigma_\mu(p)=p_\mu$。同一实二阶变分 Hessian 的 Fourier 字典为

$$K_{ab}(p)=\sum_{d,e\in\{\emptyset,0,1,2,3\}}
\mathcal B(e_{d,a},e_{e,b})\sigma_d(-p)\sigma_e(p)
=H_{289,ab}(p),\qquad p\in\mathbb C^4.
\tag{9.1}$$

定理 11.1 给出这一恒等式的完整证明：每个系数都来自原母密度的真实二阶偏导数，且全部落在代数数域 $\mathbb Q(\sqrt2,\sqrt{15})$ 中。因而下文多体配置准备所使用的 Green 算子，正是 §§4–6 的同一受约束传播算子；二者通过全部 $289$ 个实场方向上的精确作用恒等式直接相接。

对任意外源强迫项 $J$，原场恢复严格保留九维对称相容余源：

$$K(p)X(p;J)=J-L_{\mathrm{null}}(p)\,
P_{\mathrm{null}}R_b(p)J,\qquad
R_b(p)L_{\mathrm{null}}(p)=I.
\tag{9.2}$$

当且仅当该九维余源为零时，右端才简化为 $J$。下文的全部静态与远场极限均完整保留式 (9.2) 的恢复结构，不以极点存在替代源相容判据。

### 9.2 一次生成的配置准备与完整双腿电流

与 §§7–8 在固定经典背景上考察 12 维占据态空间场不同，本节起进入 [1，§6.3] 建立的完整多体配置—Fock 载体：玻色侧在 100 维局部配置流形上取无紫外截断的平方可积半密度（half-density，使配置坐标变换天然作用为保范等距算子），费米侧则张量以完整 252 维复手征旋量与独立对偶展开的 504 实模正则反对易（CAR）Fock 空间。共同多体哈密顿量按粒子数扇区 $N=k$（下文亦简记 N$k$）与有限外幂升阶指标联合分级；因外幂与有限配置框架维数有界，纯升阶 Yukawa 算子具有精确有限幂零性——任意第 57 次连续纯升阶乘积恒等于零，使全保留多体预解逆无需微扰重求和即可闭合为精确有限几何和。

在这一配置流形测度与半密度表示中，$A$ 是原余标架 Weyl 主部一阶因子的最小闭图算子，$R$ 是完整 Fourier 能量尾减去组成项所得余项；母作用的闭域与双侧 Schur 界保证 $A$ 定义域稠密且 $R$ 有界自伴。二者生成闭二次型
$\mathfrak q(x,y)=\langle Ax,Ay\rangle+\langle x,Ry\rangle$，从而唯一定出源算子 $\mathcal T$，其严格正单射预解式与源能量底为

$$\mathsf B=(\mathcal T+1+\|R\|)^{-1},\qquad
E_{\mathrm{src}}=\|\mathsf B\|^{-1}-(1+\|R\|).
\tag{9.3}$$

对任意精度 $\varepsilon>0$，补充材料 S4.1 由 $\mathsf B$ 构造 $\mathcal T$ 定义域中的单位态 $x_\varepsilon$，满足
$\|\mathcal T x_\varepsilon-E_{\mathrm{src}}x_\varepsilon\|<\varepsilon$。源坐标片中的光滑局域化与原 CAR 创建算子给出空间轮廓 $u_\varepsilon$ 及同一配置态 $v_\varepsilon$。记 $\mathcal Z_\phi$ 为光滑局域子 $\phi$ 截断的零点局域化，$\Pi_{\mathrm{prep}}$ 为原准备映射，$\mathcal D_{1/2}$ 为零粒子层的配置半密度等距映射，$\mathcal C_{\mathrm{src}}$ 为原 CAR 源创建算子，则

$$\begin{gathered}
u_\varepsilon=\mathcal Z_{\phi_{\mathrm{src}}}x_\varepsilon,\qquad
v_\varepsilon=\Pi_{\mathrm{prep}}u_\varepsilon
=\mathcal C_{\mathrm{src}}\mathcal D_{1/2}x_\varepsilon,\\
\|v_\varepsilon\|=1,\qquad
\langle v_\varepsilon,Q_Yv_\varepsilon\rangle=-1.
\end{gathered}\tag{9.4}$$

局域子 $\phi_{\mathrm{src}}$ 在源基点处取值为 $1$，确保局域化子空间非零。算子与能量 $\mathcal T,R,E_{\mathrm{src}}$ 均不依赖 $\varepsilon$。完整 Yukawa 定义域与算子值保持不变，且满足几何指数收敛界
$\|Y_{\mathrm{closed}}v_\varepsilon-Y_n v_\varepsilon\|
\le(915/916)^{n+1}\,916\,b_Y$。近谱残差与截断残差作用于同一准备态，无需额外假定态矢序列在 $\varepsilon\downarrow 0$ 时强收敛。此处 $v_\varepsilon$ 为单粒子配置背景准备；下文记完整 504 模 CAR Fock 空间中粒子数为 $k$ 的扇区为 $N=k$（简记 N$k$）。第 12.3 节二粒子（N2）创建单位态先在同一背景上施加指定带电 CAR 创建算子，再除以所生成非零态矢的真实范数完成归一，不以 $\|v_\varepsilon\|=1$ 替代。

用 $L^{\pm}_{a,s}u_\varepsilon$ 表示原完备创建／湮灭腿，其同时保留余标架体积的逆平方根与平方根及完整配置测度。任取有限配置测试框架 $F$、全保留预解式 $G_{F,n}(p,z)$ 与测试恢复映射 $\mathcal I_F$；记 $\mathcal F_i$ 为母作用沿第 $i$ 个实场方向 $e_i$ 的配置场形式（其部门分解见式 (9.13)）。对独立双腿 $\ell,r$ 定义

$$a=\mathcal I_F\!\left(G_{F,n}(p+k,z)^\dagger\ell\right),\qquad
b=\mathcal I_F\!\left(G_{F,n}(p,w)r\right),\qquad
J_i=D\mathcal F_i(0)[a,b].
\tag{9.5}$$

这就是完整 $289$ 分量的准备态电流。这里 $C_F(p)$ 是共同哈密顿量保分级（grade-preserving）部分在有限框架上的压缩，$Y_n$ 是保留 Yukawa 截断，具体预解式约定为

$$\begin{aligned}
&R_F(p,z)=(C_F(p)-zI)^{-1},\qquad
H_{F,n}(p)=C_F(p)+Y_n,\\
&G_{F,n}(p,z)=(H_{F,n}(p)-zI)^{-1}
=\sum_{j=0}^{56}(-R_F(p,z)Y_n)^jR_F(p,z).
\end{aligned}$$

因有限分级支撑使第 57 次纯升阶乘积恒等于零，右端有限和给出精确双侧逆。下文未截断原物质预解式沿用同一 $H-zI$ 约定，与 §7 的 $E-h$ 字典各自保持确定符号。记 $f_{F,\alpha}$ 与 $v_{F,\alpha}$ 为框架测试函数及其配置像，定义两项显式有界常数

$$b_n(z)=\frac1{|\operatorname{Im}z|}
\sum_{j=0}^{56}\left(\frac{\|Y_n\|}{|\operatorname{Im}z|}\right)^j,\qquad
c_i(p,F)=\sum_{\alpha,\beta}
\left|D\mathcal F_i(0)
[f_{F,\alpha},f_{F,\beta}]\right|
\|v_{F,\alpha}\|\|v_{F,\beta}\|.$$

前者控制有限预解几何和，后者由同一双线性表的秩一 Riesz 算子与三角不等式直接给出。当 $\operatorname{Im}z,\operatorname{Im}w\ne0$ 时，电流各分量满足显式先验界

$$|J_i|\le \|\ell\|\,b_n(z)\,c_i(p,F)\,b_n(w)\,\|r\|.
\tag{9.6}$$

两份预解式、完整保留 Yukawa 与双端准备始终显式分离；下文源端与探测器端可完全独立地选取上述全部读出参数。

### 9.3 修饰联合荷的半单位字符与物理电子的绝对整单位电荷

未破缺电磁生成元由母代数色—超荷组合唯一锁定为 $\mathsf E=-T^{\mathrm{color}}_2-Y/2$。在七维基序 $(c_0,c_1,c_2,w_0,w_1,h_+,h_-)$ 上，其反厄米对角本征权为

$$\mathsf E=i\,\operatorname{diag}\!\left(-\tfrac12,\tfrac12,0,0,0,-\tfrac12,\tfrac12\right),
\qquad
\mathsf E\,e_I=i\!\left(\sum_{j\in I}q_j\right)e_I.
\tag{9.7}$$

取四指标标量子集 $\{c_0,c_1,c_2\}\setminus\{c\}$ 并上 $\{w_0,w_1\}$ 或 $\{h_+,h_-\}$，配对二指标物质子集 $\{c,h_+\}$：三色标量权依次为 $(1/2,-1/2,0)$，物质权依次为 $(-1,0,-1/2)$，逐色相加恒等于 $-1/2$。对 $a,s\in\{0,1\}$，令 $I(a,c)$ 为上述标量指标集，定义带符号外代数收缩

$$\phi_{a,c}=(-1)^{[c=1]}\Phi_{I(a,c)},\qquad
\psi_{s,c}=\psi_{s,\{c,h_+\}},\qquad
r_{a,s}=\sum_c\phi_{a,c}\psi_{s,c},\qquad
r^\vee_{a,s}=\sum_c\overline{\phi_{a,c}}\,
\chi(e_{s,\{c,h_+\}}).$$

其中 $\chi$ 仍为任意独立复线性对偶。逐项莱布尼茨乘积法则给出

$$r_{a,s}(\mathsf E\Phi,\psi)+r_{a,s}(\Phi,\mathsf E\psi)
=-\frac i2r_{a,s}(\Phi,\psi),\qquad
r^\vee_{a,s}(\mathsf E\Phi,\chi)+
r^\vee_{a,s}(\Phi,-\chi\circ\mathsf E)
=\frac i2r^\vee_{a,s}(\Phi,\chi).
\tag{9.8}$$

独立对偶变分采用右逆复合 $-\chi\circ\mathsf E$；对偶收缩中标量系数的复共轭自动翻转符号，无需将 $\chi$ 强行替换为物质态的厄米伴随。

结合 CAR 对易恒等式 $[d\Gamma(M),a^\dagger_j]=\sum_iM_{ij}a_i^\dagger$、$[d\Gamma(M),a_j]=-\sum_iM_{ji}a_i$ 与式 (9.7) 标量变分，先在光滑测试核上证得修饰创建、湮灭算子的联合字符为 $c_+=i/2$、$c_-=-i/2$，再沿稠密核经完备腿有界性延拓至完整空间轮廓。双腿修饰电流因此满足

$$J_i^{\mathrm{dress}}=(\overline{c_\ell}+c_r)J_i.
\tag{9.9}$$

在完整 504 模母作用中，源首荷矩阵 $Q_{\mathrm{first}}$ 对应的规范生成元 $G_T=iQ_{\mathrm{first}}$ 在同一准备上的字符为 $-(10/11)c_\pm$，完整 $G_T$ 准备电流亦同步乘以 $-10/11$。与此同时，真实荷算子作用于完备腿时还完整保留输入端的标量—配置余项（光滑核上为 $L^\pm(Q_{\mathsf E}f)+i\,\operatorname{embed}(L^\pm_{\delta\Phi}f)$，$f$ 为种子截面，$\delta\Phi=\mathsf E\Phi$，其有界延拓记作 $L_{\mathrm{in}}^\pm$）：

$$Q_{\mathsf E}L^\pm u=\delta_\pm L^\pm u+L_{\mathrm{in}}^\pm u,\quad
\delta_\pm=\pm\tfrac12,\qquad
J_Q=(\delta_\ell+\delta_r)J+J_{\mathrm{in}}.
\tag{9.10}$$

故光子极点左读数 $\beta(J_Q)$ 同时读取相对增量 $(\delta_\ell+\delta_r)\beta(J)$ 与输入余项 $\beta(J_{\mathrm{in}})$。半单位 $\pm 1/2$ 是标量—物质复合字母的相对修饰字符，绝不冒充孤立电子外腿的绝对电荷。

物理电子的绝对电荷单位由实际带电费米通道直接生成，无需任何经验电荷标定。在母物质占据核内，色单态费米二重态按离散通道指标 $e\in\{0,1\}$ 分为带电费米通道（$e=0$）与中性费米通道（$e=1$）（连同自旋指标 $s\in\{0,1\}$ 及正负手征对，共张成 §10.3 的 8 维零动量静止基 $\mathscr R$）：

**命题 9.1（修饰半单位字符与物理电子绝对整单位电荷，`L18, L20, L21`）。** 原费米通道电荷函数 $q_{\mathrm{edge}}(e)$ 在带电通道 $e=0$ 取值 $1$、中性通道 $e=1$ 取值 $0$；在同一静止准备态上，独立复线性对偶的母作用 Noether 电磁荷读数无条件给出**电子绝对单位电荷**

$$q_e=1,\qquad
\chi_0\!\left(C_{\mathrm{dual}}(P_{s,0})\,
Q_{\mathrm{Noether}}P_{s,0}\psi_0\right)
=h_{\mathrm{src}}q_e,\qquad
h_{\mathrm{src}}>0,
\tag{9.11}$$

其中 $h_{\mathrm{src}}>0$ 为源生相位动量（母作用自身的作用量单位）。对任意源支 $b$，记 $c_{\mathrm{src}}(b)>0$ 为该支源生传播速率，乘积 $h_{\mathrm{src}}c_{\mathrm{src}}(b)$（不特指分支时简记为 $h_{\mathrm{src}}c_{\mathrm{src}}$）构成下文各电磁读数唯一的无量纲化分母。

**证明。** 将式 (9.7) 未破缺电磁生成元 $\mathsf E$ 限制于静止投影 $P_{s,0}\psi_0$ 与独立对偶配对 $C_{\mathrm{dual}}(P_{s,0})$，带电通道 $e=0$ 的外幂收缩精确读出源生相位动量 $h_{\mathrm{src}}>0$ 乘以整系数 $q_e=1$（式 (9.11)）。将原始与对偶表示同时乘以任意非零尺度再除以同一尺度，$q_e=1$ 严格保持不变；在空间滤波态上则显式保留对易修正 $h_{\mathrm{src}}\langle f_L,\Delta_Qf_R\rangle$。∎

§10.1 命题 10.1 将在同一实际静止电子腿上并列核对原生时间流 $-1$ 与电磁荷 $+1$。

### 9.4 完整静态投影与库仑标量常数 $K_*$

准备电流来自实际配置切片插入。按原 289 实场坐标序，指标 $i\ge73$ 的物质、独立对偶与辅助方向在该配置切片上无直接插入，故 $J_i=0$（该零列性质专指配置切片形式 $\mathcal F_i$ 的一阶变分；§10.3 的 64 权有向年龄窗使用原始槽位算子并经完整配置读口及其补偿精确认回，不将固定 $w_J$ 混同于年龄窗读数）。原点场恢复矩阵 $F_0$ 的非零收缩简化为

$$F_0^{\mathsf T}J=(e_0+e_1)w_J,\qquad
w_J=\frac{3\sqrt2}{10}(J_{21}-J_{34}).
\tag{9.12}$$

唯一存活的组合 $g=e_{21}-e_{34}$ 恰为原空间规范联络槽 21 与 34 之差（$A_1^{\,0}-A_2^{\,1}$；正是这一空间规范槽位的激活跨越了 §6.7 命题 6.3 裸时间电荷源零库仑留数的禁令），其标量与余标架直插分量为零，而标量轨道补偿完整保留。$w_J$ 的六项完整配置积分内容为

$$\begin{aligned}
w_J=\frac{3\sqrt2}{10}\Bigl[{}&D\mathcal F_{\mathrm{native},g}
+D\mathcal F_{\mathrm{coframe},g}
-D\mathcal F_{\mathrm{retained},g}\\
&+\int\!\left(j_{\mathrm{density},g}
+\langle a,\widehat{M_g}b\rangle_z
-\langle a,\widehat{M_{\perp,g}}b\rangle_z\right)d\mu(z)\Bigr].
\end{aligned}\tag{9.13}$$

全部一阶形式均在同一零场基点与同一对 $(a,b)$ 上求值；$M_g$ 为原规范密度两列之差，$M_{\perp,g}$ 为同一插入的正交补空间恢复，同时保留原生规范、余标架、体积密度、完整物质、互补标量／规范与保留 Yukawa 六部分，并服从式 (9.6) 双预解界。

补充材料 S4.2 给出完整五维静态约化矩阵 $T_5$ 及其双侧逆 $G_5$。对任意单位实空间方向 $n$ 与纯空间四动量 $p_\kappa=(0,i\kappa n)$，289 场 Schur 核的首项张量为 $-\kappa^2 T_{\mathrm{stat}}$，同时保留局部接触项、补空间项与全场恢复。记原完整 289 场静态 Green 响应为 $\mathcal G_\kappa J$，则当 $\kappa\downarrow 0$ 时

$$-\kappa^2\mathcal G_\kappa J\longrightarrow
F_0G_0F_0^{\mathsf T}J,\qquad
G_0(e_0+e_1)=\sqrt{30}\left(-\frac9{125}e_0-\frac{67}{72}e_1\right).
\tag{9.14}$$

**定理 9.2（双端完整准备的静态库仑标量，`L18-L19`）。** 固定任意两份独立的源端（$S$）与探测器端（$D$）准备（含各自的正准备精度、动量、有限配置框架、截断阶、非实预解参数及离散腿指标）。对任意单位实空间方向 $n$，在源生静态收敛半径内令 $\kappa\downarrow 0$，有

$$\begin{aligned}
C_{\mathrm{comp}}&=K_*w_Dw_S,\qquad
K_*=\frac{9023}{9000}\sqrt{30},\\
J_D^{\mathsf T}F_0G_0F_0^{\mathsf T}J_S&=-C_{\mathrm{comp}},\\
\kappa^2J_D^{\mathsf T}\mathcal G_\kappa J_S&\longrightarrow C_{\mathrm{comp}}.
\end{aligned}\tag{9.15}$$

**证明。** 将式 (9.12) 分别代入源与探测器两端，并用式 (9.14) 精确求逆：
$9/125+67/72=9023/9000$。双端收缩采用复双线性转置而不额外插入复共轭。补充材料 S4.2 建立的方向一致 $O(\kappa)$ 误差界控制极点因子余项；局部接触项与补空间项在原点连续有界，乘以 $\kappa^2$ 后一致趋于零。两端权重 $w_D,w_S$ 均由式 (9.13) 完整配置积分内生给出，无需外供固定电流值。∎

将命题 9.1 已归一的两个电子绝对单位荷 $q_e^D=q_e^S=1$ 代入静态留数，立得 $q_e^Dq_e^SC_T=C_T$，两端任意非零表示尺度精确对消。此处符号约定完全透明：Thomson 静态常数采用 $-\kappa^2$ 留数约定 $C_T=-C_{\mathrm{comp}}$，而式 (9.15) 的正标量 $C_{\mathrm{comp}}$ 对应 $+\kappa^2$ 极限；二者各自除以一次 $h_{\mathrm{src}}c_{\mathrm{src}}$ 即得无量纲静态比值。

### 9.5 在壳光子极点振幅与零动量转移 Thomson 匹配接口

令 $P_\omega$ 为物理频率极点处的完整 $289$ 维留数矩阵，$\mathcal P_\omega$ 为其频率归一极化向量，$\beta$ 为源生线性左读口。对每个单位空间方向 $n$ 与源支 $b$，在原极点支充分小的正尺度 $e>0$ 上，完整留数呈精确秩一分解：

$$P_\omega(e,b,n)J=\beta_{e,b,n}(J)\,
\mathcal P_\omega(e,b,n).
\tag{9.16}$$

物理四动量射线取 $p=(-ie^2s_b(e,n),ie^2n)$，物理频率为 $\omega_e=e^2s_b(e,n)$（射线参数 $e$ 与 §9.4 静态参数 $\kappa$ 各自独立，且不假定 $\beta=1$）。对同一电流 (9.5) 定义光子极化振幅 $\mathcal A_\gamma=J^{\mathsf T}\mathcal P_\omega$ 及其无量纲化振幅 $\widehat{\mathcal A}_\gamma=\mathcal A_\gamma/(h_{\mathrm{src}}c_{\mathrm{src}})$，在非零尺度与非实双预解参数下满足

$$h_{\mathrm{src}}c_{\mathrm{src}}\widehat{\mathcal A}_\gamma
=\mathcal A_\gamma,\qquad
|\mathcal A_\gamma|\le\sum_i|\mathcal P_{\omega,i}|\,
\|\ell\|b_n(z)c_i(p,F)b_n(w)\|r\|.
\tag{9.17}$$

式 (9.4) 与 (9.17) 生成的单位态、原生超荷 $-1$、未归一与已归一光子振幅及显式上界共同组成原作用单位下的在壳光子极点输入包（`L22`）。

**注记 9.3（原作用单位下的 Thomson 零转移匹配接口，`L21, L23`）。** 本篇与下游零旋钮匹配篇（Case 3）通过如下原作用单位合同精确衔接（可对照 Appelquist–Carazzone [16] 与 Henning–Lu–Murayama [3] 中重场积分消去后有限阈值接触项的分离）：当下游匹配层在原作用单位下交付在壳完整响应 $\mathcal O=\beta_{e,b,n}(J)\,\mathcal A_\gamma=J^{\mathsf T}P_\omega J$、轻场圈响应 $\mathcal L$ 与局部接触响应 $\mathcal C$ 并证出分解等式

$$\mathcal O-\mathcal L=C_T+\mathcal C,
\tag{9.18}$$

同一比值即无歧义且仅归一化一次地读出

$$\frac{\mathcal O-\mathcal L-\mathcal C}
{h_{\mathrm{src}}c_{\mathrm{src}}}
=\frac{C_T}{h_{\mathrm{src}}c_{\mathrm{src}}}.
\tag{9.19}$$

将 $\mathcal O$ 显式绑定为携带源端左读数 $\beta_{e,b,n}(J)$ 的原单位双侧留数读出 $J^{\mathsf T}P_\omega J$（固定来源见附录 B.1），保证了 $\mathcal O,\mathcal L,\mathcal C,C_T$ 四项共享完全相同的原作用量纲，绝不发生单端已归一振幅与未归一静态留数混用单位的错位；17 伴随 Riesz 轻／重／接触分解与最终 $\alpha(0)$ 算子商数值收窄按分工由 Case 3 独立完成。

<a id="sec-10"></a>

## 10 物理静止电子的双端读回：一次库仑标量与在壳光子响应

半单位修饰字符 $\pm 1/2$ 与整单位物理电子 $|Q_e|=1$ 至此在同一套多体读出中各归其位。决定散射与静电力系数的不是抽象量子数标签，而是保留独立有向年龄窗、全部 64 项零动量自旋—边权重及有限能量截腿残差的完整双端电流。

### 10.1 同一物理静止电子腿上的双算子验证

**命题 10.1（物理静止电子腿的双算子同时核验，`L21, L24`）。** 对自旋指标 $s\in\{0,1\}$，带电费米通道（$e=0$）的物理静止坐标为 $(s,1)$。以 $u_{\mathrm{src}}^0$ 记母物质在零时刻的单位占据态，取静止电子外态

$$u_{e,s}=P_{(s,1)}u_{\mathrm{src}}^0
=\iota\bigl(u^{\mathrm{ch}}_{s,0}\bigr),
\tag{10.1}$$

其中 $u^{\mathrm{ch}}_{s,0}$ 是源在自旋 $s$、带电通道 $e=0$ 上的真实静止限制，$\iota$ 为其在自然坐标中的等距嵌入；则母作用的原生时间流算子与物理电磁荷算子在同一态矢 $u_{e,s}$ 上同时给出

$$\langle u_{e,s},B_{\mathrm{native},0}u_{e,s}\rangle=-1,
\qquad Q_{\mathrm{EM}}u_{e,s}=u_{e,s},
\qquad a_{\mathrm{src}}h_{\mathrm{src}}=1.
\tag{10.2}$$

**证明。** 准备算子的坐标恒等式直接给出 (10.1)。原生时间读口由母作用 Noether 时间双线性乘以作用尺度 $a_{\mathrm{src}}$ 构成；带电通道 $e=0$ 的未缩放时间读数为 $-h_{\mathrm{src}}$，代入 $a_{\mathrm{src}}h_{\mathrm{src}}=1$ 即化为 $-1$。同一静止外坐标在电磁荷算子 $Q_{\mathrm{EM}}$ 的带电通道 $e=0$ 块上精确取本征值 $+1$。全过程不切换外腿，亦不把时间流算子与电磁荷算子混同为同一算子。∎

当外态经过空间滤波算子 $F$ 时，电荷矩阵元精确保留对易子修正与全载体缺陷项：

$$h_{\mathrm{src}}\langle f_L,Q_{\mathrm{EM}}f_R\rangle
=h_{\mathrm{src}}\langle f_L,f_R\rangle
+h_{\mathrm{src}}\langle f_L,\Delta_Qf_R\rangle
-h_{\mathrm{src}}\langle f_L,D_{\mathrm{EM}}f_R\rangle,
\tag{10.3}$$

其中 $\Delta_Q=[Q_{\mathrm{actual}},F]$ 作用于未滤波原腿；全载体缺陷 $D_{\mathrm{EM}}$ 在源嵌入子空间上恒为零，但在完整 504 模载体上非零并被如实保留（可对照 Buchholz [29] 关于 Gauss 定律下局域滤波态必带电磁修正的结构洞察）。

### 10.2 双腿精确截腿归一与三项有限参数残差

在 Lehmann–Symanzik–Zimmermann（LSZ）渐近约化 [26] 中，外腿通过逆传播子截腿（amputation）并在在壳极限 $p^2\to m^2$ 下舍弃非极点余项。本文工作在有限非实复能量参数 $(z,w)$ 与有限配置框架 $F$ 上，不做任何渐近丢项：

**引理 10.2（有限参数双腿截腿归一与三项残差恒等式，`L24`）。** 令 $G_z$ 为零动量完整物质预解式，$u$ 与 $d$ 为实际准备的非零原始腿与独立对偶腿，$r$ 与 $\ell$ 为二者相对于静止参考能量 $(E_R,E_L)$ 的列残差与对偶残差。对任意满足 $\operatorname{Im}z,\operatorname{Im}w\ne 0$ 的复预解参数，双侧预解逆给出严格非零的截腿向量

$$u^{\mathrm{amp}}=u-G_wr=(E_R-w)G_wu,\qquad
d^{\mathrm{amp}}=d-\ell G_z=(E_L-z)dG_z.
\tag{10.4}$$

以 $N_q=\|d^{\mathrm{amp}}\|^{-1}\|u^{\mathrm{amp}}\|^{-1}$ 定义双腿归一因子，则任意线性算子 $A$ 的完整截腿观测泛函满足精确恒等式与算子范数界 $|\mathcal U_q(A)|\le\|A\|$：

$$N_q=\|d^{\mathrm{amp}}\|^{-1}\|u^{\mathrm{amp}}\|^{-1},\qquad
\mathcal U_q(A)=N_q\bigl[d(Au)+\mathfrak c_q(A)\bigr],
\tag{10.5}$$

$$\mathfrak c_q(A)=
-\ell\!\left(G_zAu\right)-d\!\left(AG_wr\right)
+\ell\!\left(G_zAG_wr\right).
\tag{10.6}$$

**证明。** 因 $\operatorname{Im}z,\operatorname{Im}w\ne 0$，实参考能量与复参数之差 $E_R-w,E_L-z$ 均非零，由预解单射性与 $u,d\ne 0$ 知 $u^{\mathrm{amp}},d^{\mathrm{amp}}\ne 0$。直接展开 $(d-\ell G_z)A(u-G_wr)$ 即得主双线性项 $d(Au)$ 与式 (10.6) 的三项修正；乘以 $N_q$ 得 (10.5)，且左右单位截腿向量直接给出 $|\mathcal U_q(A)|\le\|A\|$。∎

式 (10.6) 第三项为双端残差交叉项，与两项单端残差共同构成有限参数截腿的精确账单，下文全部电子库仑与光子读数均完整携带 $\mathfrak c_q$。

### 10.3 全部 64 项静止权重与有向年龄窗

原静止自旋—通道索引集 $\mathscr R$（由自旋 $s\in\{0,1\}$、费米通道 $e\in\{0,1\}$ 及正负手征对张成）共含 $8$ 个零动量基态。对运动带电准备态的展开系数 $c^{s,e}_a(p)$，定义 $8\times 8=64$ 项双端权重矩阵

$$W^{s_L,e_L;s_R,e_R}_{ab}(p_L,p_R)
=\overline{c^{s_L,e_L}_a(p_L)}
c^{s_R,e_R}_b(p_R),\qquad a,b\in\mathscr R.
\tag{10.7}$$

完整准备电流与探测器先保留零动量基展开的全部 $64$ 项权重，再将真实动量 $(p_L,p_R)$ 送入时间演化与预解核，绝不人为截取单一静止分量。

记物理时间演化为 $U_p(t)$、完整物质预解式为 $G_p(z)=(H_F(p)-zI)^{-1}$，$C_g$ 为式 (9.13) 的完整配置电流限制。原始槽位算子 $M_g$ 与其配置补偿 $C_{\mathrm{comp},g}$ 满足 $C_g=M_g+C_{\mathrm{comp},g}$，对应三类时间核

$$\mathscr K_{A}(t)=U_{p_L}(-t)G_{p_L}(z)\,
A\,G_{p_R}(w)U_{p_R}(t),\qquad
\mathscr K_{\mathrm{mode}}
=\mathscr K_{C_g}-\mathscr K_{C_{\mathrm{comp},g}}.
\tag{10.8}$$

对每一对静止基指标 $(a,b)\in\mathscr R^2$，有向年龄窗 $(0,T)$ 上的原点权重积分精确拆分为完整配置读口与补偿读口之差：

$$\begin{aligned}
d_{ab}(\lambda,T)={}&
-\frac{3\sqrt2}{10}\int_0^T e^{-\lambda t}
\langle u_a(p_L),\mathscr K_{C_g}(t)u_b(p_R)\rangle\,dt\\
&+\frac{3\sqrt2}{10}\int_0^T e^{-\lambda t}
\langle u_a(p_L),\mathscr K_{C_{\mathrm{comp},g}}(t)u_b(p_R)\rangle\,dt.
\end{aligned}\tag{10.9}$$

式 (10.9) 是原 Euler 空间规范槽 21 与 34 之差（$A_1^{\,0}-A_2^{\,1}$）的真实时间积分：被积核在任意有限区间连续，对任意实窗长 $T\in\mathbb R$（含 $T<0$ 有向积分）及任意复阻尼率 $\lambda\in\mathbb C$ 绝对可积，且在 $T=0$ 处两项同步归零。乘以全部 $64$ 项 $W_{ab}$ 求和后逐对恒等式严格保持。

### 10.4 同荷外态力矩交换与一次库仑标量定理

静态余标架源拆分为正负两条电荷转移通道 $A_+,A_-$。经过完整物质预解、准备投影、等能投影与零速度共振投影后，二者满足带余项荷交换关系（完整多层对易推导见补充材料 S4.3）：

$$[Q_{\mathrm{actual}},A_\pm]=\pm A_\pm+\mathcal X_\pm.
\tag{10.10}$$

余项 $\mathcal X_\pm$ 完整收集物质电荷扭矩、两份预解对易子及全部投影对易子。当源端左右外态取相同费米通道（同荷外态，电荷差为零）时，对易子左端消去，直接给出 $\mathcal Q(A_+)=-\mathcal Q(\mathcal X_+)$ 与 $\mathcal Q(A_-)=\mathcal Q(\mathcal X_-)$。因静态余标架准备算子恰为两通道之和，源端静态余标架权重化为纯力矩差读数

$$W_{\mathrm{cf}}
=\mathcal Q_S(A_++A_-)
=\mathcal Q_S(\mathcal X_--\mathcal X_+),
\qquad \mathcal Q_S(A)=d_S(Au_S),
\tag{10.11}$$

同时涵盖源端全部 64 项权重。探测器端静态年龄窗读数为 $D_{\mathrm{act}}=\sum_{a,b}W^D_{ab}(0,0)d_{ab}(0,T)$。

**定理 10.3（物理电子的一次库仑标量读出，`L24`）。** 任取两份独立响应点 $q_D,q_S$（各自复参数 $z,w$ 虚部非零）、两个实际电子的分支指标、实年龄窗长 $T$ 及实空间动量方向 $n$。令 $V_S^{\mathrm C}$ 为以同一源端静态余标架算子为输入的三个空间通道一次库仑场，则探测器端归一化一次库仑读数严格等于

$$\boxed{C_{\mathrm{raw}}
=N_D\left[K_*D_{\mathrm{act}}W_{\mathrm{cf}}
-\mathfrak c_D\!\left(\mathscr A_D(V_S^{\mathrm C};0,T)\right)\right],
\qquad K_*=\frac{9023}{9000}\sqrt{30}.}
\tag{10.12}$$

这里 $\mathscr A_D(V;\lambda,T)=\int_0^T e^{-\lambda t}\sum_iV_i\,\mathscr K_i^D(t)\,dt$ 为全字段年龄窗积分核；$V_S^{\mathrm C}$ 已消费一次静态库仑逆，不再重复施加静态留数。母作用 Euler 变分的负号唯一锁定了场读数与双腿读数的符号衔接：

$$\begin{aligned}
\mathcal D_D^{\lambda,T}(V)
&=-d_D\!\left(\mathscr A_D(V;\lambda,T)u_D\right),\\
\mathcal U_D^{\mathrm{field}}(V)
&=-\mathcal U_D\!\left(\mathscr A_D(V;\lambda,T)\right)
=N_D\left[\mathcal D_D^{\lambda,T}(V)
-\mathfrak c_D\!\left(\mathscr A_D(V;\lambda,T)\right)\right].
\end{aligned}$$

将式 (10.5) 的加号截腿修正代入上述负号场读数，直接导出式 (10.12) 与下文式 (10.16) 中的减号修正项 $-\mathfrak c_D$，无需在归一化末端人为调整正负号。

**证明。** 对每一对源基指标，静态简单强迫项在原点投影为 $(e_0+e_1)\langle u_a,S_{\mathrm{cf}}u_b\rangle$；探测器在三条原点恢复列上的读数依次为 $d_{ab}(0,T),d_{ab}(0,T),0$。两条存活空间通道的原刚度系数为 $a_0=25\sqrt{30}/54$ 与 $a_1=12\sqrt{30}/335$，求逆相加即得

$$a_0^{-1}+a_1^{-1}
=\sqrt{30}\left(\frac9{125}+\frac{67}{72}\right)=K_*.
\tag{10.13}$$

依次对探测器端 64 对指标与源端 64 对指标求和，完整收缩精确因式分解为 $K_*D_{\mathrm{act}}W_{\mathrm{cf}}$，且无需两端共用同一窗口或框架。代入负号场读数定义、式 (10.6) 截腿修正、同荷恒等式 (10.11) 与年龄分解 (10.9)，即证得 (10.12)。∎

若进一步对源端双腿施加其自身截腿范数 $N_S$，展开式 (10.5) 给出完全对称的双端精确恒等式：

$$N_SC_{\mathrm{raw}}
=N_D\left[
K_*D_{\mathrm{act}}\bigl(\mathcal U_S(\mathcal X_--\mathcal X_+)
-N_S\mathfrak c_S(\mathcal X_--\mathcal X_+)\bigr)
-N_S\mathfrak c_D(\mathscr A_D(V_S^{\mathrm C};0,T))\right],
\tag{10.14}$$

两端单侧截腿残差与交叉残差悉数保留，再除以一次 $h_{\mathrm{src}}c_{\mathrm{src}}$ 即得无量纲一次库仑读数。

### 10.5 在壳光子极点响应完整保留源端振幅

进一步赋予探测器与源端各自独立的有向年龄窗 $(\lambda,T)$ 与 $(\mu,S)$。令 $J_S^{\mu,S}$ 为源端全 64 权窗口电流，$\mathcal D_D^{\lambda,T}$ 为探测器全 64 权线性读口。在源支 $b$、单位空间方向 $n$ 与极点支尺度 $e$ 上，极点场与源端振幅为

$$V_\gamma(e)=P_\omega(e,b,n)J_S^{\mu,S}
=\beta_S(e)\mathcal P_\omega(e,b,n),\qquad
\beta_S(e)=\beta_{e,b,n}(J_S^{\mu,S}).
\tag{10.15}$$

**定理 10.4（物理电子在壳光子极点响应的全参数返回，`L25`）。** 对任意响应点 $q_D,q_S$、四个离散分支指标、复阻尼率 $\lambda,\mu\in\mathbb C$、实窗长 $T,S\in\mathbb R$ 及单位实空间方向 $n$，只要探测器两份复预解参数虚部非零，即存在正常数 $e_0>0$，使原尺度域内所有 $0<e<e_0$ 在式 (9.16) 源极点支上满足

$$\boxed{\mathcal O_e
=\frac{N_D}{h_{\mathrm{src}}c_{\mathrm{src}}(b)}
\left[
\beta_S(e)\,
\mathcal D_D^{\lambda,T}\!\left(\mathcal P_\omega(e,b,n)\right)
-\mathfrak c_D\!\left(\mathscr A_D(V_\gamma(e);\lambda,T)\right)
\right].}
\tag{10.16}$$

**证明。** 频率留数秩一分解 (9.16) 对任意源电流成立；源端 64 项有限加权和与线性左读口交换，给出系数 $\beta_S(e)$。将 §10.4 负号场读数定义作用于式 (10.5) 双腿泛函，提取线性主项中的 $\beta_S(e)$ 并除以一次 $h_{\mathrm{src}}c_{\mathrm{src}}(b)$，即得 (10.16)。上界 $e_0$ 由极点分解邻域内生定出，不外推为任意有限大动量恒等式。∎

在式 (10.16) 中，源端可见振幅 $\beta_S(e)$ 已由实际物理电子电流内生算出而不再是抽象占位符（若某特殊源构型被左读口湮灭，公式亦如实返回零主项），且不人为约去 $\beta_S(e)$。下文母作用 Hessian 认回、横波 Maxwell 光速锥与三维实空间库仑积分将直接消费此处建立的双端精确接口。

<a id="sec-11"></a>

## 11 母作用二阶变分、物理时钟重标与横波 Maxwell 光速锥

### 11.1 同一九组场的一阶射流二阶变分，而非外置二次模型

记 §9.1 含独立对偶的母作用局部密度在九组场提升上的限制为 $\mathcal L_{\rm nat}$。其自变量为完整实一阶射流

$$j=(x,x_0,x_1,x_2,x_3)\in\mathbb R^{289}\times(\mathbb R^{289})^4,
\qquad \mathcal B=D^2\mathcal L_{\rm nat}(0).
\tag{11.1}$$

二阶 Fréchet 导数 $\mathcal B$ 在非退化余标架邻域的零射流点取值。在任意时空锚点 $a$ 处，仿射信号 $x+\sum_\mu(y^\mu-a^\mu)x_\mu$ 的场值与一阶偏导数恰为 $(x,x_\mu)$；代入九组原场即给出局部作用量密度。物质与独立复线性对偶同步采用共转表示：扰动物质为 $P(y)\delta\psi$，扰动对偶为 $\delta\chi\circ P(y)$（始终独立于物质的厄米伴随）。零扰动精确返回原背景构型，余标架、标量及引力／规范两套辅助场均保持原插入方式。

令 $d,e\in\{\varnothing,0,1,2,3\}$ 标记场值槽与四个时空导数槽，$e_{d,i}$ 为对应一阶射流单位基向量，$\sigma_\varnothing(p)=1$、$\sigma_\mu(p)=p_\mu$。真实二阶变分 Hessian 的 Fourier 符号矩阵为

$$K_{ij}(p)=\sum_{d,e}
\mathcal B(e_{d,i},e_{e,j})\sigma_d(-p)\sigma_e(p),
\qquad p\in\mathbb C^4.
\tag{11.2}$$

**定理 11.1（母作用二阶变分与 $289\times 289$ Jacobi 矩阵全等，`L26`）。** 式 (11.2) 在 $\mathbb C^4$ 上逐项精确等于 §§4–6 的原 $289\times289$ 耦合 Jacobi 矩阵 $H_{289}(p)$；其受约束 Green 函数、局部接触项与九维相容余源约束均由同一母作用二阶变分生成。

**证明。** 局部密度的二阶变分按引力、规范、标量与独立对偶 Dirac 四部门分解（依次含 $234,406,220,790$ 个二次单项，总计 $1650$ 项）。每个二次单项 $c j_{d,i}j_{e,j}$ 极化产生两个有序二阶导数项；式 (11.2) 对左导数槽赋予一次分部积分反号 $p\mapsto-p$，右导数槽保留 $p$。四部门的 $3300$ 个有符号贡献按场行、场列及四动量幂次合并后，与原 $3071$ 项传播字典逐系数全等，且全部系数落在 $\mathbb Q(\sqrt2,\sqrt{15})$ 中（完整一阶射流展开与归并规则见补充材料 S5.1）。∎

定理 11.1 在含时间进动旋量—余标架背景与独立线性对偶的一阶引力—规范系统上实现了协变背景场二阶变分（对照 DeWitt [14] 与 Abbott [2]）的无近似闭合，使 L1–L17 的受约束传播与新增多体电磁读出锚定在同一母作用算子上。

### 11.2 字面电磁方向保留全部 289 维混合输出

将未破缺电磁生成元 $\mathrm E=-C_2-Y/2$ 插入四个时空规范联络槽，得到实嵌入矩阵 $\mathcal E:\mathbb C^4\to\mathbb C^{289}$。由于空间规范背景非零，对易导数

$$[\bar A_\mu,\mathrm E]
=(0,-\alpha_0 C_1,\alpha_0 C_0,0)_\mu
\tag{11.3}$$

激活两条非零色方向并进入全场耦合方程。因此必须先求解完整 289 维受约束 Green 响应，再收缩回四维电磁读口：

$$G_{\rm E}=\mathcal E^{\mathsf T}G\mathcal E,
\qquad V_{\rm E}=R\mathcal E,
\qquad T_{\rm E}=\mathcal E^{\mathsf T}R\mathcal E.
\tag{11.4}$$

左右两侧采用原有序 Fourier 配对（反向动量已内置于恢复读口，不将独立双端混同为同一厄米向量）。

对每个固定单位空间方向 $n$ 与源支 $b\in\{0,1\}$，五维特征构造生成简单极点 $s_b(\varepsilon,n)$：

**命题 11.2（完整 289 维极点留数投影与静止源可见性充要判据，`L26`）。** 在充分小的正射线参数 $\varepsilon>0$ 上，沿物理射线

$$p_\varepsilon(s,n)=(-i\varepsilon^2s,i\varepsilon^2n),
\qquad \omega=\varepsilon^2s,
\qquad R=\lim_{s\to s_b}(s-s_b)G(p_\varepsilon(s,n)),
\tag{11.5}$$

完整 289 维极点留数满足齐次场方程与差商投影恒等式

$$K(p_\varepsilon(s_b,n))R=RK(p_\varepsilon(s_b,n))=0,
\qquad R K'_s R=R,
\tag{11.6}$$

故混合电磁载体 $V_{\rm E}=R\mathcal E$ 同时解出全部 289 条齐次行及九维零模场约束，并满足通量归一

$$\mathcal E^{\mathsf T}R K'_sV_{\rm E}=T_{\rm E};
\tag{11.7}$$

对静止电子的完整作用源 $J$，记 $v_J=RJ$，线性左读口 $\ell_b$ 与非零全场极化向量 $v_b$ 给出精确可见性充要判据

$$v_J=\ell_b(J)v_b,
\qquad v_J\ne0\iff\ell_b(J)\ne0.
\tag{11.8}$$

**证明。** 双侧受约束 Green 方程保留随 $s$ 连续变化的九维零模源／场投影 $Q_s(s),Q_f(s)$。乘以 $s-s_b$ 取极限得式 (11.6) 前两式；再将左齐次式作用于 $K(s)$ 的差商并利用 $RQ_s(s_b)=0$，即得 $RK'_sR=R$（详证见补充材料 S5.2）。右乘 $\mathcal E$ 或 $J$ 并代入简单极点秩一分解即得式 (11.7)–(11.8)。∎

### 11.3 物理频率与任意正时钟尺度重表达

换用物理频率变量 $\omega=\varepsilon^2s$，真实频率留数与 Jacobi 频率导数为

$$R_\omega=\varepsilon^2R,
\qquad K'_\omega=\varepsilon^{-2}K'_s,
\qquad R_\omega K'_\omega R_\omega=R_\omega.
\tag{11.9}$$

对任意正时钟重标因子 $c>0$，作时间—频率重表达 $t'=ct$、$\omega'=\omega/c$，Green 函数自变量、极点位置、留数与导数同步变换为

$$G_c(\omega')=G(p_\varepsilon(c\omega'/\varepsilon^2,n)),
\quad \omega'_b=\omega_b/c,
\quad R_c=R_\omega/c,
\quad K'_c=cK'_\omega.
\tag{11.10}$$

**定理 11.3（任意正时钟重标下的通量归一守恒律，`L26`）。** 对任意 $c>0$，重表达后的穿孔极点留数 $R_c$ 与同一母作用 Hessian 的链式导数 $K'_c$ 严格保持归一投影与电磁通量恒等式：

$$R_cK'_c=R_\omega K'_\omega,
\qquad R_cK'_cR_c=R_c,
\qquad
\mathcal E^{\mathsf T}R_cK'_cR_c\mathcal E
=\mathcal E^{\mathsf T}R_c\mathcal E.
\tag{11.11}$$

**证明。** 由 $\omega'-\omega'_b=(\omega-\omega_b)/c$ 知穿孔极限留数为 $R_c=R_\omega/c$，链式求导给 $K'_c=cK'_\omega$；代入 (11.9) 后两份留数与一份导数共留单因子 $1/c$，立得 (11.11)。∎

![同一母作用下的正时钟重表达与留数通量守恒](figures/main-04-action-clock-v2.svg)

**图 4　同一母作用下的正时钟重表达与留数通量守恒。** 固定源支、单位空间方向及简单极点范围，正时钟变换 $t'=ct$（$c>0$）使极点留数 $R_c=R_\omega/c$（深蓝双曲线）与链式 Jacobi 导数 $K'_c=cK'_\omega$（金色虚线）互逆缩放，二者乘积 $R_cK'_c=P$（朱红水平实线，枢轴 $c=1$）严格保持尺度不变。$\mathcal E$ 将字面电磁方向 $\mathrm E=-T^{\mathrm{color}}_2-\frac12 Y$ 嵌入全部 289 维场空间并完整保留混合色—引力输出，使通量恒等式式 (11.9)–(11.11) 在一切 $c>0$ 下成立。

### 11.4 无角度平均标准电磁分支判据与横波 Maxwell 光速锥

在包含完整量子极化修正与背景混合的修饰事件 $e$ 上，一个根本物理问题是：289 场受约束响应在何时严格呈现各向同性标准库仑—Biot–Savart 静态张量与无双折射横波 Maxwell 光速锥？能否在不作球面角度平均、亦不预先假定外部电流守恒的前提下给出充要代数判据？

记三元形式空间动量多项式环 $\mathbb C[X_1,X_2,X_3]$ 中的径向平方元为 $|\mathbf X|^2=X_1^2+X_2^2+X_3^2$，$D_{\mathrm{lead}}(e)$ 为全 289 场零钟伴随主分母多项式。因电磁规范槽嵌入满足正交归一关系 $\mathcal E^{\mathsf T}\mathcal E=\frac34 I_4$，母作用双端配对尺度唯一固定为 $\eta_{\mathrm{pair}}=\frac43 h_{\mathrm{src}}>0$（恰抵消 $\frac34$ 因子并恢复源生相位动量 $h_{\mathrm{src}}$）；令 $N_{\mathrm{stat}}(e)_{\mu\nu}$ 为零阻尼与空间可除消因子后提取的静态 Noether 分子多项式（已计入 $\eta_{\mathrm{pair}}^2$）。无需对任何物理方向采样或作球面 $S^2$ 平均，直接从非零支撑单项式比值定出静态电、磁标量系数 $(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e))$，构造标准静态分子多项式 $N^{\mathrm{std}}_{\mu\nu}(c_{\mathrm{temp}},c_{\mathrm{sp}})$（在 $(0,0)$ 分量为 $c_{\mathrm{temp}}|\mathbf X|^2$，时空混合分量为 $0$，空间块 $(i,j)$ 为 $c_{\mathrm{sp}}(|\mathbf X|^2\delta_{ij}-X_iX_j)$），并定义 16 项精确多项式静态余项

$$\mathcal R_{\mathrm{stat}}(e)_{\mu\nu}
=|\mathbf X|^4 N_{\mathrm{stat}}(e)_{\mu\nu}
-D_{\mathrm{lead}}(e)\,N^{\mathrm{std}}_{\mu\nu}\bigl(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\bigr)
\in\mathbb C[X_1,X_2,X_3].
\tag{11.12}$$

当零钟主分母多项式非零（$D_{\mathrm{lead}}(e)\ne 0$，即排除奇异主分母分支）时，在任意正则实三动量 $\mathbf n\in\mathbb R^3\setminus\{0\}$（满足 $D_{\mathrm{lead}}(e)(\mathbf n)\ne 0$）上，修饰静态 Noether 电磁张量 $T_{\mathrm{stat}}(e,\mathbf n)$ 与标准库仑—Biot–Savart 张量 $T^{\mathrm{std}}(c_{\mathrm{temp}},c_{\mathrm{sp}})(\mathbf n)=N^{\mathrm{std}}(\mathbf n)/|\mathbf n|^4$ 之差精确等于 $\mathcal R_{\mathrm{stat}}(e)(\mathbf n)/[D_{\mathrm{lead}}(e)(\mathbf n)|\mathbf n|^4]$，由此无需角度平均即导出双向充要判据：

$$\begin{aligned}
\bigl(D_{\mathrm{lead}}(e)\ne 0\bigr)\qquad
\mathcal R_{\mathrm{stat}}(e)=0
\Longleftrightarrow{}&\forall\,\mathbf n\in\mathbb R^3\setminus\{0\}\ \Bigl(D_{\mathrm{lead}}(e)(\mathbf n)\ne 0\\
&\implies T_{\mathrm{stat}}(e,\mathbf n)=T^{\mathrm{std}}\bigl(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\bigr)(\mathbf n)\Bigr).
\end{aligned}
\tag{11.13}$$

拒绝角度平均在这里具有直接的物理证伪意义：例如四极各向异性污染项 $X_1^2-X_2^2$ 在单位球面 $S^2$ 上积分恒为零，球面平均会将其彻底掩盖，而在式 (11.12)–(11.13) 中该项使 $\mathcal R_{\mathrm{stat}}(e)\ne 0$，并在实方向（如 $\mathbf n_\star=(1,0,0)$）当场暴露张量偏离。同时，除主对角时间项外，完整静态电流散射系数还精确保留双端电荷标定余项、其余 15 个时空／空间电磁分量及三项非纯响应贡献。

进一步转入动态频率响应：记正阻尼 $\sigma>0$ 下完整 289 场修正受约束 Green 算子的四维电磁读出为 $T_{\mathrm{EM}}^{\mathrm{corr}}(e,\varepsilon,s,\sigma,\mathbf n)=\mathcal E^{\mathsf T}G_{\mathrm{corr}}(e,\varepsilon,s,\sigma,\mathbf n)\mathcal E$。当 $c_{\mathrm{temp}}(e)\ne 0$ 且 $c_{\mathrm{sp}}(e)\ne 0$ 时，由同一静态系数内生定义电、磁有效本构刚度

$$\varepsilon_{\mathrm{eff}}(e)=-\frac{3\,\eta_{\mathrm{pair}}^2}{4\,c_{\mathrm{temp}}(e)},
\qquad
\mu_{\mathrm{eff}}(e)^{-1}=\frac{3\,\eta_{\mathrm{pair}}^2}{4\,c_{\mathrm{sp}}(e)},
\qquad
\frac{\mu_{\mathrm{eff}}(e)^{-1}}{\varepsilon_{\mathrm{eff}}(e)}
=-\frac{c_{\mathrm{temp}}(e)}{c_{\mathrm{sp}}(e)}.
\tag{11.14}$$

对尺度 $\varepsilon\in\mathbb R\setminus\{0\}$ 与物理空间动量 $\mathbf k_\varepsilon=\varepsilon^2\mathbf n\ne 0$，以频率变量 $\omega_X=\varepsilon^2 X$ 构造 $4\times 4$ 多项式 Maxwell 矩阵 $M_{\mathrm{Max}}(e,\varepsilon,\mathbf n)(X)$（$(0,0)$ 元为 $\varepsilon_{\mathrm{eff}}|\mathbf k_\varepsilon|^2$，$(0,j)$ 与 $(i,0)$ 元为 $\varepsilon_{\mathrm{eff}}\omega_X k_{\varepsilon,j}$，空间块为 $(\varepsilon_{\mathrm{eff}}\omega_X^2-\mu_{\mathrm{eff}}^{-1}|\mathbf k_\varepsilon|^2)\delta_{ij}+\mu_{\mathrm{eff}}^{-1}k_{\varepsilon,i}k_{\varepsilon,j}$）及守恒流输出投影 $P_{\mathrm{curr}}(\varepsilon,\mathbf n)(X)$，作用于全部 289 行零钟伴随列矩阵 $V_{289}(e,\varepsilon,\mathbf n)(X)$ 定义 16 项动态多项式余项 $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)\in M_4(\mathbb C[X])$。

**定理 11.4（无角度平均标准分支充要判据、动态 Maxwell 散射律与横波 Maxwell 光速锥，`L26` 标准长程扩展）。** 对修饰事件 $e$，成立如下三项精确结论：

1. **整球标准静态分支充要判据与构造性实阻碍**：若零钟主分母多项式 $D_{\mathrm{lead}}(e)\ne 0$，则式 (11.13) 双向充要成立；一旦 $\mathcal R_{\mathrm{stat}}(e)\ne 0$，必构造性存在显式正则实动量方向 $\mathbf n_\star\in\mathbb R^3\setminus\{0\}$（满足 $D_{\mathrm{lead}}(e)(\mathbf n_\star)\ne 0$）使 $T_{\mathrm{stat}}(e,\mathbf n_\star)\ne T^{\mathrm{std}}(c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e))(\mathbf n_\star)$（表 2 第 5 项）。反之，当 $\mathcal R_{\mathrm{stat}}(e)=0$ 且具备整球正则方向图 $\eta$ 时，时间分量符号在全体 $\mathbf k\in\mathbb R^3\setminus\{0\}$ 上恒等于 $c_{\mathrm{temp}}(e)/|\mathbf k|^2$，对任意 Schwartz 波包 $\phi$ 无需角度平均即返回单 $4\pi$ 库仑卷积核 $C_{\mathrm{EM}}^{\mathrm{gen}}(e)/|\mathbf x-\mathbf y|$，其中 $C_{\mathrm{EM}}^{\mathrm{gen}}(e)=c_{\mathrm{temp}}(e)/(4\pi)$。
2. **带广义 Ward 投影的动态 Maxwell 响应与四项散射分解**：若事件 $e$ 满足电磁列钟有限条件，且在尺度 $\varepsilon\ne 0$、方向 $\mathbf n$（$\mathbf k_\varepsilon=\varepsilon^2\mathbf n\ne 0$）上 $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)=0$，则对任意正则实频率参数 $s\in\mathbb R$（零钟频率分母 $D_0(e,\varepsilon,\mathbf n)(s)\ne 0$），正阻尼极限 $\sigma\downarrow 0$ 后的完整 16 分量电磁响应张量 $T_{\mathrm{EM}}(e,\varepsilon,s,\mathbf n)$ 满足精确矩阵方程

   $$|\mathbf k_\varepsilon|^2\,M_{\mathrm{Max}}(e,\varepsilon,\mathbf n)(s)\,T_{\mathrm{EM}}(e,\varepsilon,s,\mathbf n)
   =\frac34\,P_{\mathrm{curr}}(\varepsilon,\mathbf n)(s),
   \tag{11.15}$$

   且对任意（不必预先横截守恒的）双端外部 Noether 流 $j_D,j_S\in\mathbb C^4$，记守恒流投影为 $j^{\mathrm{proj}}=|\mathbf k_\varepsilon|^{-2}P_{\mathrm{curr}}(s)j$、Ward 纵向余项为 $j^{\mathrm{Ward}}=j-j^{\mathrm{proj}}$，完整散射读数恒等分解为四项之和：

   $$j_D^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S
   =(j_D^{\mathrm{proj}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{proj}}
   +(j_D^{\mathrm{Ward}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{proj}}
   +(j_D^{\mathrm{proj}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{Ward}}
   +(j_D^{\mathrm{Ward}})^{\mathsf T}\widetilde T_{\mathrm{EM}}j_S^{\mathrm{Ward}},
   \tag{11.16}$$

   其中 $\widetilde T_{\mathrm{EM}}=\eta_{\mathrm{pair}}^2 T_{\mathrm{EM}}^{\mathrm{corr}}$，绝不以投影流暗中替换真实带电外态。
3. **横波 Maxwell 色散光速锥锁定与齐次场方程**：在 $\mathcal R_{\mathrm{dyn}}(e,\varepsilon,\mathbf n)=0$ 与 $\mathbf k_\varepsilon\ne 0$ 下，对任意实可见极点 $a$（$\operatorname{Im}a=0$，物理频率 $\omega_{\mathrm{phys}}=\varepsilon^2\operatorname{Re}a$）及其可见通道 $c$，完整 289 维极点模 $v_{a,c}$ 的四维电磁投影 $\mathcal A=(\mathcal A_0,\vec{\mathcal A}):=\mathcal E^{\mathsf T}v_{a,c}$ 自动满足 $M_{\mathrm{Max}}(a)\mathcal A=0$，其诱导电场 $\vec{\mathcal E}=i(\omega_{\mathrm{phys}}\vec{\mathcal A}-\mathcal A_0\mathbf k_\varepsilon)$ 与磁场 $\mathbf B=i\mathbf k_\varepsilon\times\vec{\mathcal A}$ 精确满足齐次 Faraday 定律 $\mathbf k_\varepsilon\times\vec{\mathcal E}-\omega_{\mathrm{phys}}\mathbf B=0$ 与磁 Gauss 定律 $\mathbf k_\varepsilon\cdot\mathbf B=0$（且一旦磁感应非零 $\mathbf B\ne 0$ 即自动蕴涵横向投影 $\Pi_\perp(\mathbf k_\varepsilon)\mathcal A\ne 0$）。若 $\Pi_\perp(\mathbf k_\varepsilon)(\mathcal E^{\mathsf T}v_{a,c})\ne 0$，$c_{\mathrm{temp}}(e),c_{\mathrm{sp}}(e)\ne 0$ 且比值 $-c_{\mathrm{temp}}(e)/c_{\mathrm{sp}}(e)$ 为严格正实数，定义源生光速 $c_{\mathrm{phys}}(e)=\sqrt{-c_{\mathrm{temp}}(e)/c_{\mathrm{sp}}(e)}>0$，则该横波极点模严格落在单一无双折射 **Maxwell 光速锥**上：

   $$\boxed{\varepsilon_{\mathrm{eff}}(e)\,\omega_{\mathrm{phys}}^2
   -\mu_{\mathrm{eff}}(e)^{-1}|\mathbf k_\varepsilon|^2=0,
   \qquad
   v_{\mathrm{phase}}^2(\varepsilon,\operatorname{Re}a,\mathbf n)
   :=\frac{\omega_{\mathrm{phys}}^2}{|\mathbf k_\varepsilon|^2}
   =-\frac{c_{\mathrm{temp}}(e)}{c_{\mathrm{sp}}(e)}
   =c_{\mathrm{phys}}(e)^2.}
   \tag{11.17}$$

定理 11.4 的完整证明见补充材料 S5.7。在任意输入参数 $(e,\varepsilon,\mathbf n)$ 上，源内部分类器无需先验假设即将物理返回互斥完备地划分为 11 个分支（零尺度、零动量、角度条件不满足、例外奇异方向、静态非标准处置、电刚度为零、磁刚度为零、本构比非实、本构比非正、动态非标准反馈余项，以及同时实现式 (11.17) 横波光速锥与单 $4\pi$ 库仑卷积的标准电磁分支）；同时，即便在尚未施加 $\mathcal R_{\mathrm{dyn}}=0$ 的一般修饰可见根上，任意重数极点的 Schur 留数通量平衡、四通道（纯规范、余标架—物质、保留 Yukawa 与补偿）全根耦合平衡及相对树级原生速率平方 $v_{\mathrm{nat}}^2=N^{-2}=125/54$ 的精确相速度偏移公式 $v_{\mathrm{phase}}^2-v_{\mathrm{nat}}^2$（补充材料 S5.7 式 (S5.21)）均恒等成立——当量子极化与背景反馈置零时，式 (S5.21) 分子消去，$v_{\mathrm{phase}}^2$ 精确退回 §6.7 命题 6.3 的树级 Hodge 速度平方 $125/54$。对照 Hehl 与 Obukhov [24] 总结的前度规本构电动力学（其中一般线性本构介质满足可容许双折射的四次 Tamm–Rubilar 波面方程 $\mathcal G^{\mu\nu\rho\sigma}k_\mu k_\nu k_\rho k_\sigma=0$）以及广义 Ward–Takahashi 恒等式 [22, 23, 36]，定理 11.4 表明：16 项多项式判据将 289 维自旋—挠率—极化耦合系统的高阶伴随色散精确坍缩为单一二次 Maxwell 光速锥（图 7 左列），物理光速 $c_{\mathrm{phys}}(e)$ 纯粹作为修饰电—磁刚度比涌现。

<a id="sec-12"></a>

## 12 全场受约束 Green 算子与三维实空间单 $4\pi$ 库仑返回

### 12.1 全方向静态 Schur 估计生成红外可积窗口

沿用 (9.12) 的原点恢复矩阵 $F_0$ 与 (9.14) 的静态逆 $G_0$，定义完整 289 维静态极限张量

$$S_0=-F_0G_0F_0^{\mathsf T}.
\tag{12.1}$$

完整 Schur 消元式、局部接触项与场／源恢复映射共同给出球面一致的算子范数极限：对任意 $\eta>0$，存在正半径 $r_\eta>0$，使全部单位空间方向 $n$ 与原静态正则域内的 $0<r<r_\eta$ 一致满足

$$\|r^2G(0,irn)-S_0\|\leq\eta.
\tag{12.2}$$

补充材料 S5.3 从五维静态逆误差与恢复映射连续性严格证出这一球面一致性。取 $\eta=1$，源自身内生定出共同红外半径 $\rho>0$ 与算子范数预算 $B_0=1+\|S_0\|$（且 $\rho$ 严格落在静态正则域内）。对标度参数 $a>0$ 定义截断窗口核

$$\mathcal W_a(k)=
\begin{cases}
a^2G(0,iak),&0<a|k|<\rho,\\
0,&\text{otherwise}.
\end{cases}
\qquad
\|\mathcal W_a(k)\|\leq\frac{B_0}{|k|^2}.
\tag{12.3}$$

原点单点置零不改变三维 Lebesgue 积分；当 $a\downarrow 0$ 时，窗口内部始终保持未经标量化截断的完整 $289\times 289$ 受约束 Green 矩阵。

对任意 Schwartz 波包测试函数 $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$，沿用 Fourier 动量字典 $k=2\pi\xi$，记

$$f_\phi(x)=\int e^{2\pi i\xi\cdot x}\phi(\xi)\,d\xi,
\qquad
\mathcal P_a[\phi](x)=\int e^{2\pi i\xi\cdot x}\phi(\xi)
\mathcal W_a(2\pi\xi)\,d\xi.
\tag{12.4}$$

**定理 12.1（完整 289 场三维矩阵 Bochner–Fourier 与单 $4\pi$ 库仑—Newton 返回，`L27`）。** 式 (12.4) 为收敛的有限维矩阵值 Bochner 积分；对任意 $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$ 与任意空间点 $x\in\mathbb R^3$，有

$$\lim_{a\downarrow0}\mathcal P_a[\phi](x)
=\mathcal N_\phi(x)S_0,
\qquad
\mathcal N_\phi(x)=\int\frac{f_\phi(x-y)}{4\pi|y|}\,dy.
\tag{12.5}$$

**证明。** 在三维动量空间中，$|\xi|^{-2}$ 在原点可积（球坐标体积元 $r^2dr$ 抵消奇异性），Schwartz 速降控制无穷远，故 $B_0|\phi(\xi)|/|2\pi\xi|^2$ 构成整族矩阵被积函数的共同 $L^1$ 支配函数。对任意 $\xi\ne0$，式 (12.2) 给出点态收敛 $\mathcal W_a(2\pi\xi)\to S_0/|2\pi\xi|^2$，Lebesgue 支配收敛定理给出 Bochner 极限。补充材料 S5.4 对动量侧与空间侧同步引入正 Gaussian 正则因子 $e^{-t(|k|^2+d^2)}$ 并在已证 $L^1$ 支配下令 $d\downarrow 0$，严格导出唯一单因子 $1/(4\pi|y|)$。∎

这一机制与 Donoghue [30] 在引力有效场论中区分动量空间 $|\mathbf q|^{-2}$ 奇异长程项与多项式短程接触项的思想遥相呼应，但此处是在完整 289 维受约束矩阵上以无微扰红外发散的 Bochner 支配极限直接闭合（无需如微扰散射态 [28] 那样外接软光子重求和）。同一动量伸缩 $\phi_a(\xi)=\phi(\xi/a)$ 同时给出精确三维齐次标度律

$$\mathcal P_a[\phi](x)=a^{-1}\mathcal P_1[\phi_a](x/a),
\tag{12.6}$$

其中 Green 前因子 $a^2$ 与三维体积雅可比 $a^{-3}$ 乘出 $-1$ 次幂，全程未引入任何外设库仑长度标尺。

### 12.2 物理电子双单位读口在独立年龄窗下的实空间返回

将 §10 物理电子的完整源端电流与探测器线性读口作用于矩阵包 (12.4)，经探测器端单次作用—速率分母 $hc_b=h_{\mathrm{src}}c_{\mathrm{src}}(b)$ 归一化，立即得到如下实空间推论：

**推论 12.2（物理电子双单位读口在独立年龄窗下的实空间返回，`L27`）。** 对任意两份独立的响应点 $(q_D,q_S)$、左右外腿指标及有向年龄窗 $(\lambda,T)$、$(\mu,S)$，保留全部 64 项静止权重、补偿读口与双端截腿修正的电子实空间包满足

$$\lim_{a\downarrow0}\mathcal P_a^{\rm el}[\phi](x)
=\mathcal N_\phi(x)\,
\frac{K_*w_D^{\rm el}(q_D;\lambda,T)
w_S^{\rm el}(q_S;\mu,S)}{h c_b},
\qquad K_*=\frac{9023}{9000}\sqrt{30}.
\tag{12.7}$$

**证明。** 双端电子读口为 $M_{289}(\mathbb C)$ 上的有界线性泛函，故直接穿过式 (12.4) Bochner 积分并消费定理 12.1 极限 (12.5)；代入同一五维逆 $G_0$ 即得系数 $K_*w_D^{\rm el}w_S^{\rm el}/(hc_b)$。∎

### 12.3 二粒子创建态（$N=2$）连通流在相反动量转移下的实空间返回

考察多体 Fock 空间中的二粒子创建事件

$$e=(\epsilon_e,p_e,F_e,n_e,z_e),
\qquad \epsilon_e>0,\quad \operatorname{Im}z_e\ne0.
\tag{12.8}$$

其单位范数二粒子态 $u_e$（$N=2$ 扇区）由同一源剖面施加带电 CAR 创建算子并除以其真实正范数生成，$b_e$ 为同剖面的单位范数单粒子背景态（$N=1$ 扇区；补充材料 S5.5 证出创建态范数严格有正下界）。二者原生超荷读数分别为 $-2$ 与 $-1$，连通增量为 $-1$。

令 $R_e(p)=(C_{F_e}(p)+Y_{n_e}-z_e)^{-1}$ 为保留全部 Yukawa 项的有限框架预解逆，$\mathcal A_{F_e}$ 为框架测试恢复映射，$\mathcal J_i(p;v,w)$ 为母作用沿第 $i$ 场方向的一阶双线性源，则完整 289 分量连通流为

$$\begin{aligned}
J_e(k)_i={}&\mathcal J_i\bigl(p_e;
\mathcal A_{F_e}R_e(p_e-k)^\dagger u_e,
\mathcal A_{F_e}R_e(p_e)u_e\bigr)\\
&-\mathcal J_i\bigl(p_e;
\mathcal A_{F_e}R_e(p_e-k)^\dagger b_e,
\mathcal A_{F_e}R_e(p_e)b_e\bigr).
\end{aligned}
\tag{12.9}$$

因 $\operatorname{Im}z_e\ne 0$ 保证预解逆关于动量转移 $k$ 连续，在共同 Fourier 动量 $ak$ 下令探测器与源端取相反动量转移 $J_D(-ak)$ 与 $J_S(ak)$，双线性收缩 $L(k,M)=J_D(-k)^{\mathsf T}M J_S(k)$ 联合连续，从而与式 (12.2) 共同内生生成正半径 $\rho_{DS}>0$ 与一致界

$$B_{DS}=1+|L(0,S_0)|,
\qquad
|L(rn,r^2G(0,irn))|\leq B_{DS}\quad(0<r<\rho_{DS},\ |n|=1).
\tag{12.10}$$

取共同窗口半径 $\min(\rho,\rho_{DS})$，窗内置 $m_a(k)=L(ak,\mathcal W_a(k))$、窗外置零，即得运动双端实空间返回定理：

**定理 12.3（运动双端连通流的实空间库仑—Newton 观测，`L27`）。** 对任意两份独立二粒子创建事件 $(e_D,e_S)$ 及任意 $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$、$x\in\mathbb R^3$，有

$$\mathcal P_a^{\rm conn}[\phi](x)
=\int e^{2\pi i\xi\cdot x}\phi(\xi)m_a(2\pi\xi)\,d\xi
\longrightarrow
-\mathcal N_\phi(x)
(F_0^{\mathsf T}J_D(0))^{\mathsf T}G_0(F_0^{\mathsf T}J_S(0)).
\tag{12.11}$$

**证明。** 联合连续性与球面一致极限 (12.2) 给出 $L(rn,r^2G)\to L(0,S_0)$，导出一致界 $|m_a(k)|\leq B_{DS}/|k|^2$ 及非零点逐点极限 $L(0,S_0)/|k|^2$；应用与定理 12.1 相同的 Schwartz 可积支配并代入 $S_0=-F_0G_0F_0^{\mathsf T}$ 即得 (12.11)。∎

式 (12.9) 已内置连通流自身归一化，无需额外除以 $hc_b$。若进一步考察未扣除输入余项的完整联合荷电流 $J_e^{\rm joint}=J_e+\Xi_e$（$\Xi_e$ 收集标量输入余项与背景荷偏移，见补充材料 S5.5 式 (S5.13)），同一全场矩阵 $M$ 上的双端收缩恒等展开为四项之和：

$$\begin{aligned}
(J_D^{\rm joint})^{\mathsf T}MJ_S^{\rm joint}
={}&J_D^{\mathsf T}MJ_S
+J_D^{\mathsf T}M\Xi_S
+\Xi_D^{\mathsf T}MJ_S
+\Xi_D^{\mathsf T}M\Xi_S,
\end{aligned}
\tag{12.12}$$

两条交叉返回项与余项自乘项均在零转移极限 $M=S_0$ 下精确保持，无需将传播后多体态强行假定为输入荷算子的本征态。

![相反动量转移下的二粒子连通流与三维实空间单 4π 库仑返回](figures/main-05-newton-return-v2.svg)

**图 5　相反动量转移下的二粒子连通流与三维实空间单 $4\pi$ 库仑返回。** 探测器与源端二粒子（$N=2$）连通流分别取相反动量转移 $J_D(-a\mathbf k)$ 与 $J_S(+a\mathbf k)$，各自保留独立创建事件、非实能量与有向年龄窗。中段几何面板左示内生穿孔红外球 $0<a|\mathbf k|<\min(\rho,\rho_{DS})$ 内的 $L^1$ 支配收缩 $|m_a(\mathbf k)|\le B_{DS}/|\mathbf k|^2$，右示 $a\downarrow 0$ 时三维 Bochner–Fourier 逆变换 $\mathcal F^{-1}$ 返回的唯一单 $4\pi$ 实空间库仑核 $1/(4\pi|\mathbf y|)$ 与 Schwartz 波包 $f_\phi(\mathbf x-\mathbf y)$ 卷积（定理 12.3，式 (12.11)–(12.12)）。

### 12.4 三费米子（$N=3$）物理能量极点包、全场 Maxwell 连续性与 $|Q_e|^2=1$ 单位荷消去

将 §11.4 的整球标准电磁分支与多体三费米子（$N=3$）复合态能量极点截面（可对照 Haag [34] 关于局域场论复合束缚粒子极点与渐近散射的奠基框架）相接，实空间库仑返回在复合带电费米子极点层完成最后一步无旋钮归一化闭合。

对修饰事件 $e$、复合外腿指标 $\ell$ 及能量极点截面 $\varpi$，极点电流 $J_{\mathrm{pole}}(e,\ell,\varpi)\in\mathbb C^{289}$、其四维电磁收缩及二阶接触导数逐槽认回母作用全部 289 个原始 Noether 场形式、16 项电磁读口与有限 Riesz 接触型（满足显式范数上界 $\|J_{\mathrm{pole},i}\|\le 2P_{\mathrm{pole},i}$）。在任意尺度 $\varepsilon$、频率参数 $s$、正阻尼 $\sigma>0$（修正行列式非零）与四动量射线 $p=p_\varepsilon(s,\mathbf n)$ 上，令 $X_{\mathrm{corr}}$ 为完整 289 维受迫修正场、$Q_{\mathrm{freq}}$ 为频率量子极化修正矩阵，该极点源精确满足**含诱导量子流的全场非齐次 Maxwell 方程与总电流守恒律**（对照 Buchholz [29] 关于复合带电态精确服从局域 Gauss—Maxwell 约束的要求）：

$$\operatorname{div}_p\!\bigl(\mathcal H_p(X_{\mathrm{corr}})\bigr)
=J_{\mathrm{ext},p}(J_{\mathrm{pole}})+J_{\mathrm{ind},p}(Q_{\mathrm{freq}},X_{\mathrm{corr}}),
\qquad
\operatorname{cont}_p\!\bigl(J_{\mathrm{ext},p}(J_{\mathrm{pole}})+J_{\mathrm{ind},p}(Q_{\mathrm{freq}},X_{\mathrm{corr}})\bigr)=0.
\tag{12.13}$$

同时，极点 Noether 流的时间（电荷）分量在历史序列极限 $m\to\infty$ 下精确分解为电子电荷符号 $s_e(\ell)\in\{\pm 1\}$、极点态与电磁标定态修正及背景扣除：

$$J_{\mathrm{Noether}}^{\mathrm{pole}}(e,\ell,\varpi)_0
=s_e(\ell)
+\bigl\langle u_{\mathrm{pole}},\,\delta u_{\mathrm{pole}}+\delta u_{\mathrm{cal}}\bigr\rangle
-\bigl\langle b_{\mathrm{Noether}},\,\mathcal R_{\mathrm{EM}}(b_{\mathrm{Noether}})\bigr\rangle,
\tag{12.14}$$

且与原始电磁荷读口 $\mathcal Q_{\mathrm{pole}}(e,\ell,\varpi)$ 通过 $(J_{\mathrm{EM}}(J_{\mathrm{pole}}))_0=h_{\mathrm{src}}\mathcal Q_{\mathrm{pole}}(e,\ell,\varpi)$ 严格绑定。记探测器与源端独立极点截面的电荷乘积为 $Q_{DS}^{\mathrm{pole}}=\mathcal Q_{\mathrm{pole}}(e_D,\ell_D,\varpi_D)\mathcal Q_{\mathrm{pole}}(e_S,\ell_S,\varpi_S)$，并沿用式 (12.4) 的波包逆 Fourier 核 $f_\phi=\mathcal F^{-1}\phi$。

**定理 12.4（三费米子 $N=3$ 能量极点单 $4\pi$ 库仑包与 $|Q_e|^2=1$ 单位荷消去，`L27` 极点扩展）。** 设场修饰事件 $e_F$ 具备整球正则方向图 $\eta$，且满足 §11.4 标准静态条件 $D_{\mathrm{lead}}(e_F)\ne 0$ 与 $\mathcal R_{\mathrm{stat}}(e_F)=0$。对任意独立的探测器／源端事件 $(e_D,e_S)$、复合腿 $(\ell_D,\ell_S)$、$N=3$ 能量极点截面 $(\varpi_D,\varpi_S)$、Schwartz 波包 $\phi\in\mathcal S(\mathbb R^3,\mathbb C)$ 及空间点 $\mathbf x\in\mathbb R^3$：

1. **正标度极限返回单 $4\pi$ 实空间库仑卷积**：时间通道扇区 Fourier 包在正标度 $\lambda\downarrow 0$ 时收敛至精确空间积分 $\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)$，且满足

   $$\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)
   =\int_{\mathbb R^3}\frac{Q_{DS}^{\mathrm{pole}}\,C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{|\mathbf y|}\,f_\phi(\mathbf x-\mathbf y)\,d^3y,
   \qquad
   C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)=\frac{c_{\mathrm{temp}}(e_F)}{4\pi}.
   \tag{12.15}$$

2. **电子单位电荷 $|Q_e|^2=1$ 自动消去与零旋钮极点耦合商**：若源生光速 $c_{\mathrm{phys}}(e_F)>0$，则无量纲化分母 $h_{\mathrm{src}}c_{\mathrm{phys}}(e_F)>0$；由命题 9.1 源内已证的电子 Noether 单位荷 $q_{e,\mathrm{Noether}}(0)=q_e=1$ 满足 $1^2=1$，极点电磁耦合表达式恒等简化并给出归一化实空间库仑读出：

   $$\boxed{\begin{aligned}
   \alpha_{\mathrm{pole}}(e_F)
   &:=\frac{q_{e,\mathrm{Noether}}(0)^2\,C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)}
   =\frac{C_{\mathrm{EM}}^{\mathrm{gen}}(e_F)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)},\\
   \frac{\mathcal P_{\mathrm{pole}}^{(3)}[\phi](\mathbf x)}{h_{\mathrm{src}}\,c_{\mathrm{phys}}(e_F)}
   &=\int_{\mathbb R^3}\frac{Q_{DS}^{\mathrm{pole}}\,\alpha_{\mathrm{pole}}(e_F)}{|\mathbf y|}\,f_\phi(\mathbf x-\mathbf y)\,d^3y.
   \end{aligned}}
   \tag{12.16}$$

定理 12.4 的完整证明见补充材料 S5.7（配套传递依赖闭包审计同时核验全部 289 槽电流认回、16 项电磁收缩、Riesz 接触恒等式及外部经验耦合常数零输入，见附录 B.1）。式 (12.16) 清晰展示了零旋钮理论的锋利之处：实空间 $1/(4\pi r)$ 几何核、物理横波光速 $c_{\mathrm{phys}}(e_F)$、电子整单位电荷 $q_e=1$ 与极点耦合商 $\alpha_{\mathrm{pole}}(e_F)$ 在同一个积分等式中严丝合缝地汇合。

<a id="sec-13"></a>

## 13 三费米子复合态的底扇区 Born 重叠与四端精确库仑修饰

### 13.1 四分级完整 $N=3$ 响应内生生成单位态

现在进一步考察完整 504 模 CAR 空间中三费米子（$N=3$）复合源的多分级 Yukawa 修饰效应。令输入源为 $q_\ell=f_{d_\ell}\,q_{d_\ell}^{(3)}$，其中 $d_\ell\in\{0,1\}$ 标记两条独立电荷分支，$f_d$ 为源生光滑紧支剖面且在基点满足 $f_d(z_*)=1$。反对称三重产生算子乘积给出精确 Gram 范数 $\|q_d^{(3)}\|^2=2$（补充材料 S5.6 式 (S5.14)），输入严格位于粒子数 $3$、升阶数 $0$ 的底扇区 $(3,0)$。

每条外腿 $\ell=(d_\ell,F_\ell,\sharp_\ell,\zeta_\ell)$ 携带独立的非实复能量 $\zeta_\ell$。令保分级预解为 $R_{0,F}(\zeta)=(C_F-\zeta)^{-1}$、单步升阶转移算子为 $T_F(\zeta)=-R_{0,F}(\zeta)Y$。由于 $Y$ 保持粒子数 $N=3$ 并使辅助升阶指标 $j$ 严格加 $1$，而 $N=3$ 载体的 $(3,4)$ 层为空集，第四次升阶恒等为零（$T_F^4b_\ell=0$）：

$$b_\ell=R_{0,F_\ell}(\zeta_\ell)q_\ell,
\qquad
r_\ell=
\begin{cases}
\sum_{j=0}^{3}T_{F_\ell}(\zeta_\ell)^j b_\ell,&\sharp_\ell=0,\\
b_\ell,&\sharp_\ell=1.
\end{cases}
\tag{13.1}$$

此处 $\sharp_\ell=0$ 表示保留全部四层正交扇区 $(3,0)\oplus(3,1)\oplus(3,2)\oplus(3,3)$ 的完整 Yukawa 耦合支，而 $\sharp_\ell=1$ 表示限制在底扇区 $(3,0)$ 的独立保分级基准支。回写完整原作用时，二者均精确保留有限框架压缩缺陷 $d_{F_\ell}=H_0-C_{F_\ell}$：

$$\begin{aligned}
(H_0+Y-\zeta_\ell)r_\ell&=q_\ell+d_{F_\ell}r_\ell &&(\sharp_\ell=0),\\
(H_0+Y^\sharp-\zeta_\ell)r_\ell&=q_\ell+d_{F_\ell}r_\ell &&(\sharp_\ell=1).
\end{aligned}
\tag{13.2}$$

因双侧逆保证 $r_\ell\ne 0$ 且四个分级分量两两正交，完整响应自身范数唯一生成单位态 $u_\ell$：

$$u_\ell=\frac{r_\ell}{\|r_\ell\|},
\qquad \|u_\ell\|=1,
\qquad P_{3,0}r_\ell=b_\ell,
\qquad \|r_\ell\|^2=\sum_{j=0}^{3}\|T_{F_\ell}^jb_\ell\|^2
\quad(\sharp_\ell=0).
\tag{13.3}$$

### 13.2 无紫外截断的底扇区 Born 重叠振幅 $z_\ell\in(0,1]$

由式 (13.3) 正交分解，定义每条外腿的底扇区重叠振幅 $z_\ell$ 与 Born 概率权重 $\mathfrak b_\ell$：

$$z_\ell=\frac{\|b_\ell\|}{\|r_\ell\|},
\qquad \mathfrak b_\ell=z_\ell^2=\|P_{3,0}u_\ell\|^2,
\qquad 0<z_\ell\leq1.
\tag{13.4}$$

这一正交分解具有直观而清晰的复合粒子物理图像：底扇区 $(3,0)$ 是反对称三重产生算子生成的**三费米子价态核**（valence core），而高分级扇区 $(3,1)$、$(3,2)$ 与 $(3,3)$ 则是 Yukawa 外积耦合依次激发的一阶、二阶与三阶标量—旋量修饰云；由于有限外幂层的泡利不相容原理使第四阶 $(3,4)$ 严格为空集，修饰云在第 4 步精确截断（$T_{F_\ell}^4b_\ell=0$）。将其与 Källén–Lehmann 谱表示 [25, 33] 的波函数重整化常数 $0\le Z\le 1$ 以及 Weinberg 复合粒子裸核重叠判据 [35] 对照，对比尤为鲜明：传统微扰场论中裸态与物理态的重叠常因无穷维圈积分紫外发散而退化为依赖截断的形式重整化常数；而在式 (13.3)–(13.4) 中，有限分级泡利幂零性与真实配置半密度 Hilbert 内积使 $z_\ell$ 在**零紫外截断**下天然是严格位于 $(0,1]$ 的有限正实数，其平方 $\mathfrak b_\ell=\|P_{3,0}u_\ell\|^2$ 字面上就是单位复合态 $u_\ell$ 停留在 $(3,0)$ 价态三费米核中的精确 Born 概率（当取保分级基准支 $\sharp_\ell=1$ 时恰有 $z_\ell=\mathfrak b_\ell=1$）。

更进一步，在完整 Yukawa 支（$\sharp_\ell=0$）上，由式 (13.3)–(13.4) 同除以 $\|b_\ell\|>0$ 即得无截断闭式范数比公式

$$z_\ell=\left(1+\sum_{j=1}^{3}\frac{\|T_{F_\ell}(\zeta_\ell)^j b_\ell\|^2}{\|b_\ell\|^2}\right)^{-1/2},
\qquad
\mathfrak b_\ell=\frac{\|b_\ell\|^2}{\|b_\ell\|^2+\sum_{j=1}^{3}\|T_{F_\ell}(\zeta_\ell)^j b_\ell\|^2}
\quad(\sharp_\ell=0).
\tag{13.4a}$$

式 (13.4a) 中的高分级修饰云在统一源中绝非形式空项：对 $(3,0)$ 价态三费米核候选态 $q_d^{(3)}$（$\|q_d^{(3)}\|^2=2$，补充材料 S5.6 式 (S5.14)），取 $(3,1)$ 层单位范数正交见证三重态 $w_{\mathrm{Yuk},d}=|(0,0,0),(0,1,0),\mathrm{out}_A\rangle_d$，联合真空量化 Yukawa 算子 $\widehat Y(v)$ 在其上的矩阵元由单一非零外积项精确隔离，模平方严格等于有理数

$$\bigl|\langle w_{\mathrm{Yuk},d},\,\widehat Y(v)\,q_d^{(3)}\rangle\bigr|^2
=\left(\frac{2}{3}\right)^2 N^2\,|\eta_{\mathrm{Yuk}}|^2
=\frac{4}{9}\cdot\frac{54}{125}
=\frac{24}{125}>0
\qquad(d\in\{0,1\}),
\tag{13.4b}$$

其中 $N=\sqrt{54/125}$ 为式 (1.1) 的时间余标架系数，$\eta_{\mathrm{Yuk}}\in\{\pm 1\}$ 为不相交指标并集的置换符号。基点归一化 $f_d(z_*)=1$ 使实际输入的有界归一化 $Y$ 读数非零。固定有限框架与非实因果线 $\zeta=\omega+i\eta$、$\eta\ne0$，当 $\omega\to+\infty$ 时有算子范数极限 $\zeta R_{0,F}(\zeta)\to-I$，故底扇区响应的归一化 $Y$ 读数在充分大的 $\omega$ 上非零。完整源方程表明，若完整响应等于其底扇区投影，该读数必为零。于是由式 (13.4a) 的正交分解得到 $0<z_\ell<1$，适用于任一因果方向及任一固定正阻尼。这正是实际复合腿定理 `composite_bottom_overlap_eventually_lt_one`。

**四分级范数算例（纸笔验算）。** 为直观检验泡利四阶截断如何把正交修饰云范数转化为精确库仑拉低系数（对应图 6 中段右侧条形图），在有限框架 $F_\ell$（$\sharp_\ell=0$，$T_{F_\ell}^4b_\ell=0$）上取 $(3,0)$ 价态核响应范数平方 $\|b_\ell\|^2=4$，并设一、二、三阶修饰云范数平方依次为 $(\|T_{F_\ell}b_\ell\|^2,\|T_{F_\ell}^2b_\ell\|^2,\|T_{F_\ell}^3b_\ell\|^2)=(3,\frac32,\frac12)$（三层修饰云合计为 $5$），其配对的保分级基准腿（$\sharp=1$）满足 $r_{\mathrm{ref}}=b_{\mathrm{ref}}$（$z_{\mathrm{ref}}=1$）。若探测器对 $(dL,dR)$ 与源对 $(sL,sR)$ 各含一条上述完整修饰腿与一条基准腿，代入式 (13.4a) 及下文式 (13.7)–(13.8) 立即可手算出：

$$\|r_\ell\|^2=4+3+\frac{3}{2}+\frac{1}{2}=9
\implies
z_\ell=\frac{2}{3},\quad
\mathfrak b_\ell=\frac{4}{9},\quad
Z=\left(\frac{2}{3}\cdot 1\right)^2=\frac{4}{9},\quad
|C_{\mathrm{full}}-C_{\mathrm{base}}|=\frac{5}{9}\,|C_{\mathrm{base}}|.
\tag{13.4c}$$

价态核保留了 $\frac49$ 的单位态 Born 概率，其余 $\frac59$ 进入三层有限标量—旋量修饰云，使实空间库仑系数精确重标为 $C_{\mathrm{full}}=\frac49 C_{\mathrm{base}}$，全程无任何紫外发散或人为重整化抵消项。

由于母作用纯规范一阶顶点严格保分级（$P_{3,0}\Gamma_{\mu a}=\Gamma_{\mu a}P_{3,0}$），只要左右外腿对 $(L,R)$ 中至少有一端取保分级基准支（$\sharp_L=1$ 或 $\sharp_R=1$），完整规范双线性分子便精确退回底扇区分子。记纯规范左共轭、右线性配对为 $\mathcal V_{\mu a}(p;v,w)$，按原空间规范槽 21 与 34 之差（$A_1^{\,0}-A_2^{\,1}$）定义底扇区权重

$$\begin{aligned}
w_{LR}^{\rm base}(p)&=\frac{3\sqrt2}{10}
\bigl[-\mathcal V_{10}(p;b_L,b_R)+\mathcal V_{21}(p;b_L,b_R)\bigr],\\
\widehat w_{LR}^{\rm base}(p)&=
\frac{w_{LR}^{\rm base}(p)}{\|b_L\|\|b_R\|}.
\end{aligned}
\tag{13.5}$$

于是完整单位态响应的实际静态权重满足精确乘积律

$$w_{LR}^{\rm actual}(p)
=z_Lz_R\widehat w_{LR}^{\rm base}(p),
\qquad \sharp_L=1\ \text{或}\ \sharp_R=1.
\tag{13.6}$$

式 (13.6) 的配对前提不可省略：若左右两端同时取完整 Yukawa 支 $\sharp_L=\sharp_R=0$，高分级 $(3,j)$（$j\ge 1$）同层对角矩阵元也进入完整分子。

### 13.3 四端 Born 重叠乘积的精确库仑修饰与差模恒等式

对探测器外腿对 $(dL,dR)$ 与源外腿对 $(sL,sR)$，设每对各自至少含一端保分级基准支。定义四端重叠乘积与底扇区基准库仑系数：

$$Z=z_{dL}z_{dR}z_{sL}z_{sR},
\qquad 0<Z\leq1,
\qquad
C_{\rm base}=\frac{K_*\widehat w_{dL,dR}^{\rm base}(p_D)
\widehat w_{sL,sR}^{\rm base}(p_S)}{hc_b}.
\tag{13.7}$$

**定理 13.1（三费米子四端源生 Born 重叠库仑修饰，`L28`）。** 在探测器对与源对各自至少含一端保分级基准支（$\sharp=1$）的条件下，完整四分级 $N=3$ 库仑系数 $C_{\rm full}$ 与底扇区基准系数 $C_{\rm base}$ 满足精确乘积修饰与差模公式

$$\boxed{C_{\rm full}=ZC_{\rm base},
\qquad |C_{\rm full}-C_{\rm base}|=(1-Z)|C_{\rm base}|,}
\tag{13.8}$$

且同一完整 $N=3$ 电流经单次 $hc_b$ 探测器归一与完整 289 场矩阵 Bochner 积分 (12.4) 返回实空间库仑卷积：

$$\lim_{a\downarrow0}\mathcal P_a^{(3)}[\phi](x)
=\mathcal N_\phi(x)\,ZC_{\rm base}.
\tag{13.9}$$

**证明。** 纯规范顶点保分级性使含基准支的外腿对分子精确投影至底扇区，而分母保留完整四分级范数 $\|r_\ell\|$，给出 (13.6)。将探测器对与源对相乘并代入五维静态逆 $G_0$ 收缩（补充材料 S5.6 式 (S5.18)）即得 $C_{\rm full}=ZC_{\rm base}$；因 $0<Z\le 1$，有 $|Z-1|=1-Z$，立得差模等式。最后由有界矩阵读口与定理 12.1 Bochner 极限交换得 (13.9)。∎

四个重叠因子由各自的四分级响应范数给出。固定另外三条腿，令探测器的完整左腿沿固定因果线取充分高频，则由 `composite_coulomb_overlap_eventually_lt_one` 得 $Z<1$。两对基准腿条件下，若 $C_{\rm base}\ne0$，式 (13.8) 的差严格为正。

![三费米子四分级泡利截断、底扇区 Born 重叠与四端库仑修饰](figures/main-06-born-dressing-v2.svg)

**图 6　三费米子四分级泡利截断、底扇区 Born 重叠与四端库仑修饰。** 顶列为探测器对 $(dL,dR)$ 与源对 $(sL,sR)$ 四条独立复合外腿。中段左示 Yukawa 升阶算子 $T_F=-R_{0,F}Y$ 激发的四分级正交阶梯 $(3,0)\to(3,1)\to(3,2)\to(3,3)$ 及其在空集 $(3,4)=\varnothing$ 处的泡利精确截断（$T_F^4 b_\ell=0$）；右示完整耦合支（$\sharp_\ell=0$，§13.2 算例 $\mathfrak b_\ell=4/9,\ z_\ell=2/3$）与保分级基准支（$\sharp_\ell=1$，$z_{\mathrm{ref}}=1$）的正交范数分解。四端乘积 $Z=z_{dL}z_{dR}z_{sL}z_{sR}$ 直接给出定理 13.1 式 (13.8)–(13.9) 的修饰系数与差模。

<a id="sec-14"></a>

## 14 远场三通道电流平衡、五轴文献对话与系列接口

### 14.1 完整静态电流三通道分解与两步远场同阶平衡（`L29`）

在前三节建立单次静态留数、横波 Maxwell 光速锥与实空间 $1/(4\pi r)$ 卷积之后，我们还需回答最后一道严苛的结构追问：**当完整静态电流回路中同时保留量子极化反馈与九条规范—Lorentz 约束零模提升时，这两项在远场极限下究竟是高阶消失的短程修正，还是与原生 Green 传播处于同一 $O(\kappa^{-2})$ 长程阶的实质贡献？**

固定修饰事件 $e$、单位实空间方向 $\mathbf n$（$|\mathbf n|^2=1$）、静态正则尺度 $\kappa\in\mathcal D_{\mathrm{stat}}$、正阻尼 $\sigma>0$（使修正行列式 $\det_{\mathrm{corr}}(e,\sqrt\kappa,0,\sigma,\mathbf n)\ne 0$），以及独立探测器／源端动量 $(p_D,p_S)$ 与复合外腿 $(d_L,d_R,s_L,s_R)$。记双端完整复合电流为 $J_{\mathrm{comp}}(p_D;d_L,d_R)$ 与 $J_{\mathrm{comp}}(p_S;s_L,s_R)$，则完整修正探针读数 $\mathcal R_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)$ 恒等分解为**原生 Green 通道、量子极化反馈通道与九约束零模提升通道**三项之和：

$$\mathcal R_{\mathrm{corr}}(\kappa,\sigma,\mathbf n)
=\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)
+\mathcal R_{\mathrm{fb}}(\kappa,\sigma,\mathbf n)
+\mathcal R_{\mathrm{null}}(\kappa,\sigma,\mathbf n),
\tag{14.1}$$

其中 $\mathcal R_{\mathrm{nat}}$ 直接收缩原生 289 场静态 Green 算子，$\mathcal R_{\mathrm{fb}}$ 经原生 Green 算子作用频率量子修正矩阵 $Q_{\mathrm{freq}}$ 与完整修正响应，$\mathcal R_{\mathrm{null}}$ 则经九维零模提升映射 $L_{\mathrm{null}}$ 读取同一修正响应的零模坐标。

原生通道先于任何方向选择继承全方向静态支配界：存在方向无关的正半径 $r_{\mathrm{nat}}>0$ 与显式预算常数 $P_{\mathrm{nat}}=\|\mathcal M_{DS}\|\cdot B_{\mathrm{whole}}$，使得

$$\forall\,\kappa\in\mathcal D_{\mathrm{stat}}\ (\kappa<r_{\mathrm{nat}}),\ \forall\,|\mathbf n|=1:\quad
\kappa^2\bigl|\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)\bigr|\le P_{\mathrm{nat}},
\qquad
\lim_{\kappa\downarrow 0}\bigl(-\kappa^2\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)\bigr)=C_{\mathrm{nat}},
\tag{14.2}$$

其中 $C_{\mathrm{nat}}=J_{\mathrm{comp},D}^{\mathsf T}S_{\mathrm{res}}J_{\mathrm{comp},S}$ 为方向无关的原生静态留数系数（且对任意非零静态尺度 $\kappa\in\mathcal D_{\mathrm{stat}}$，完整复合电流在九维对称约束余核投影上自动归零）。与此同时，源内部分类器在无需外部输入标量响应的前提下，将任意单位方向严格划分为互斥完备的四类静态长程情形：奇异主行列式支、时钟主部极点支、高阶空间极点支与**有限长程返回支**——后者满足红外钟行列式 $D_{\mathrm{IR}}(e,\mathbf n)\ne 0$、静态空间分子钟阶可除性（区别于 §11.4 针对频率射线电磁伴随列的动态钟有限条件），且全部 16 个零钟电磁分式与 1 个静态探针分式（共 17 个有理分式）在原点的空间极点阶均不超过 $4$。

**定理 14.1（静态电流三通道分解与两步有序远场同阶平衡，`L29`）。** 在式 (14.1) 的完整静态电流回路中，若方向 $\mathbf n$（$|\mathbf n|=1$）处于源内判定的有限长程返回支，记零阻尼反馈—零模合并读数为 $\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)=\mathcal R_{\mathrm{probe}}^{(0)}(\sqrt\kappa,\mathbf n)-\mathcal R_{\mathrm{nat}}(\kappa,\mathbf n)$，则：

1. **两步有序远场极限及统一上界**：对充分小的正静态尺度 $\kappa$，先令正阻尼 $\sigma\downarrow 0$，反馈与九约束零模之和收敛至零钟合并读数；随后令空间动量尺度 $\kappa\downarrow 0$，$-\kappa^2$ 倍该合并读数在源生红外半径内满足一致控制界 $|-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)|\le 1+|C_{\mathrm{ord}}(e,\mathbf n)-C_{\mathrm{nat}}|$ 并收敛至有限同阶长程系数 $C_{\mathrm{fb+null}}(e,\mathbf n)$：

   $$\lim_{\sigma\downarrow 0}\bigl[\mathcal R_{\mathrm{fb}}(\kappa,\sigma,\mathbf n)+\mathcal R_{\mathrm{null}}(\kappa,\sigma,\mathbf n)\bigr]
   =\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n),
   \qquad
   \lim_{\kappa\downarrow 0}\bigl[-\kappa^2\mathcal R_{\mathrm{fb+null}}^{(0)}(\kappa,\mathbf n)\bigr]
   =C_{\mathrm{fb+null}}(e,\mathbf n).
   \tag{14.3}$$

2. **远场 $O(\kappa^{-2})$ 同阶系数守恒律**：完整有序探针远场系数 $C_{\mathrm{ord}}(e,\mathbf n)$ 精确等于原生通道系数与反馈—九零模通道系数之和：

   $$\boxed{C_{\mathrm{ord}}(e,\mathbf n)
   =C_{\mathrm{nat}}+C_{\mathrm{fb+null}}(e,\mathbf n).}
   \tag{14.4}$$

定理 14.1 与补充材料 S5.7 保留了 $\kappa^{-2}$ 项的完整系数。若 $C_{\mathrm{fb+null}}(e,\mathbf n)\ne0$，由式 (14.3) 的收敛性，充分小的 $\kappa$ 使缩放后修正项的模至少为该系数模的一半，因而修正项恰为 $\kappa^{-2}$ 阶。系数为零时则为 $o(\kappa^{-2})$。有序极限在固定非零 $\kappa$ 时先去阻尼取得零钟响应，再读取空间远场。

![标准 Maxwell 光速锥、N=3 单位荷消去与三通道远场平衡](figures/main-07-maxwell-farfield-v2.svg)

**图 7　标准 Maxwell 光速锥、$N=3$ 单位荷消去与三通道远场平衡。** 顶框为同一 289 场母作用二阶变分 $K(p)$、电磁方向 $\mathrm E=-T^{\mathrm{color}}_2-\frac12 Y$ 与电子绝对单位荷 $|Q_e|=1$。左列展示 §11.4–§12.4 标准长程分支：在 $D_{\mathrm{lead}}(e)\ne 0$ 下，16 项多项式判据 $\mathcal R_{\mathrm{stat}}=0$ 与 $\mathcal R_{\mathrm{dyn}}=0$ 无角度平均地将实可见横波极点锁定于单一二次 Maxwell 光速锥 $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$（违背静态判据时给出正则实阻碍方向 $\mathbf n_\star$），并在 $N=3$ 极点包上以 $q_{e,\mathrm{Noether}}(0)^2=1^2=1$ 自动消去电荷单位，返回单 $4\pi$ 库仑核 $1/(4\pi|\mathbf x-\mathbf y|)$。右列展示 §14.1 一般静态回路（`L29`）：完整探针分解为原生、量子反馈与九约束零模三通道，沿 $(\kappa,\sigma)$ 平面先 $\sigma\downarrow 0$、后 $\kappa\downarrow 0$ 的两步有序路径达成$O(\kappa^{-2})$ 远场系数平衡 $C_{\mathrm{ord}}=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}$。

### 14.2 与五大基础物理传统的逐定理对话

本文将零旋钮母作用 [1] 的耦合动力学推演至低能电动力学的各个核心可观测量，沿途与二十世纪以来五大基础物理与严格数学物理传统共 36 篇代表文献形成了精确、可逐项核验的边界对话（完整文献核查深度见随稿 `literature-v2.md`）：

1. **统一规范群、跑动交汇判据、电荷整单位涌现与挠率接触项（[1, 7–12]）**。经典单群大统一（Georgi–Glashow $\mathrm{SU}(5)$ [7]）依靠手选可约手征表示 $\bar{\mathbf 5}\oplus\mathbf{10}$ 与多重 Higgs 势破缺，Georgi–Quinn–Weinberg [8] 则在无中间阈值荒漠假设下以三条一圈逆耦合直线交于一点定出统一能标；半单 Pati–Salam 模型 [9] 借第四色规范群组合出整数轻子电荷。本文在单一 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 母作用 [1] 下给出了截然不同的零旋钮图景：单世代外幂 $\Lambda^6\oplus\Lambda^2\oplus\Lambda^4$ 加复 $\Lambda^4$ 标量在原生本构 $\sigma=1/2$ 下严格满足**无公共单点交点定理**（命题 2.1，$\ell=0$ 处 $I_3=I_2=1\ne I_1=1/2$），从代数上否决朴素荒漠单点交汇并指向有限重场阈值匹配；未破缺生成元 $\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ 在修饰对上给出相对字符 $\pm 1/2$，而在带电费米通道（$e=0$）静止电子腿上无需超荷调参直接导出 $|Q_e|=1$（命题 9.1、命题 10.1）；同时，在一阶独立标架—自旋联络框架（Kibble [10]、Sciama [11]、Hehl 等 [12]）下，24 维实 Lorentz 联络代数消元零自由常数地产生 ECSK 轴矢四费米子接触项 $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$（定理 6.1），与 79 维动态块共同构成精确 42 位有理数在壳散射振幅（命题 6.2）。
2. **退化受约束消元、协变背景场 Hessian 与零待定常数有效作用（[2, 3, 13–16]）**。Dirac 受约束哈密顿方法 [13]、DeWitt 弯曲背景二阶变分 [14] 与 Abbott 背景场方法 [2] 奠定了规范—引力涨落展开的一般工具；Weinberg 唯象拉氏量 [15]、Appelquist–Carazzone 解耦定理 [16] 与 Henning–Lu–Murayama 协变导数展开 [3] 则建立了积分消去重场的低能有效理论框架，但高阶导数项通常带有待拟合低能常数（LECs），且动量投影往往引入 $1/k^2$ 奇点。本文在含时间相位进动的非平凡九场背景上证出 1650 项实一阶射流二阶 Fréchet 导数与 3071 项 $H_{289}(p)$ 逐项全等（定理 11.1），以无动量分母多项式截面 $289\to 103=79\oplus 24$ 完整回写全部 289 行场方程（命题 4.1），并由 77 维原点逆零待定常数地算出两相位四阶有理色散系数与五／六阶精确多项式余项（命题 5.1）。
3. **无界 Dirac 群、非自治全局幺正演化、全词 CAR 与算子范数 Kubo 导数（[4–6, 17–21]）**。Stone 定理 [17] 与自由 Dirac 算子理论 [18] 给出常系数一阶算子的酉群基础；Dyson 级数 [19] 与 Kato 双曲演化方程定理 [5] 处理含时微扰，但后者要求定义域恒定与强 $C^1$ 条件；Kubo 线性响应 [6] 与算子代数 KMS 微扰论 [21] 通常假定初态满足平衡条件 $[\rho,H]=0$ 并作一阶线性化截断；Fock 二次量子化 [4] 与准自由 CAR 代数 [20] 给出了多费米子代数语言。本文命题 7.1、定理 7.2–8.2 与推论 8.3 在非阿贝尔自旋—挠率背景上双向锁定 $\mathcal D(\mathsf H)$，用有界径向 Picard 映射在无全局统一控制上界与无 $C^1$ 假设下拼出全实轴、全实幅度幺正群 $W_\epsilon(t,a)$，对任意不必正交测试族证出全词 CAR 正性及单次末端翻转 $S$ 母配对读回（命题 7.3），并对任意非平衡空间准备态以单位球一致二阶界 $\epsilon^2M^2|t|^2$ 导出 $\epsilon=0$ 算子范数 Kubo 导数。
4. **广义 Ward–Slavnov–Taylor 恒等式、前度规本构电动力学与涌现 Maxwell 光速锥（[22–24, 36]）**。Ward [22] 与 Takahashi [23] 建立了平直空间阿贝尔流守恒与传播子关系，Taylor [36] 借助规范固定与 Faddeev–Popov 幽灵场建立非阿贝尔规范恒等式；Hehl 与 Obukhov [24] 阐明了无度规拓扑电动力学经时空本构闭合涌现光锥的几何原理（一般线性本构对应四次 Tamm–Rubilar 双折射波面）。本文无需任何幽灵场即将非阿贝尔规范与局域 Lorentz 对称统一为 18 条含背景曲率／标量扭矩的精确恒等式（定理 6.1），在极点差商中保留九维零模投影（命题 11.2、定理 11.3），并在定理 11.4 中以 $D_{\mathrm{lead}}\ne 0$ 下的 16 项多项式余项无角度平均地充要刻画标准电磁分支、保留外部未投影流全部四项 Ward 散射余项（式 (11.16)），最终将 289 场高阶色散坍缩为无双折射的单一二次横波 Maxwell 光速锥 $v_{\mathrm{phase}}^2=-c_{\mathrm{temp}}/c_{\mathrm{sp}}=c_{\mathrm{phys}}^2$。
5. **实空间 $1/(4\pi r)$ 势、无截断复合核 Born 重叠 $Z$、修饰带电态与远场三通道平衡（[25–35]）**。Dirac 规范不变修饰电子 [27]、Kulish–Faddeev 红外渐近态 [28] 与 Buchholz 超粒子 Gauss 定律分析 [29] 指出物理带电粒子不可简化为无电磁云的裸费米算子；Källén [33] 与 Lehmann [25] 的正谱表示、LSZ 截腿约化 [26]、Haag 复合粒子场论 [34] 刻画束缚态的谱权与渐近场。Weinberg [35] 在弱束缚极限下用裸基本粒子的概率刻画复合度。本文的 $z_\ell^2$ 是归一响应投影到整个 $(3,0)$ 扇区的概率；Donoghue [30] 分离了动量 $|\mathbf q|^{-2}$ 长程核与多项式接触项。本文正面兑现了这一整组物理洞见的无发散、零旋钮构造：裸 12 分量时间规范荷库仑留数恒零（命题 6.3），而激活空间规范槽 21 与 34 之差（$A_1^{\,0}-A_2^{\,1}$）的源生修饰态、移动 $N=2$ 连通流与满足全场连续性的 $N=3$ 复合能量极点包经全方向 Schur 支配与三维矩阵 Bochner 积分一致返回单 $4\pi$ 库仑核 $1/(4\pi|\mathbf x-\mathbf y|)$ 且自动消去 $|Q_e|^2=1$（定理 12.1、推论 12.2、定理 12.3–12.4）；有限能量双腿截腿完整保留三项残差 $\mathfrak c_q$（引理 10.2），四分级泡利幂零性使 $z_\ell=\|b_\ell\|/\|r_\ell\|\in(0,1]$ 成为无紫外截断的 $(3,0)$ 价态三费米核 Born 振幅并给出 $C_{\mathrm{full}}=ZC_{\rm base}$（定理 13.1）；定理 14.1 进一步证明量子极化反馈与九约束零模在两步有序远场极限下保留原生、反馈和零模的完整 $\kappa^{-2}$ 系数，整条推理链在 Lean 4 内核 [32] 中完成标准三公理形式化闭合。

**表 4　五条学科主轴上的经典基准与本文（`L1-L29`）推进边界对照总表。**

| 学科主轴与代表文献 | 经典框架的前提或方法边界 | 本文零旋钮统一场（Case 1 v2）的精确推进与保留条件 |
|---|---|---|
| **I. 统一群、跑动与挠率接触** [1, 7–12] | 手选多表示与多重 Higgs 势；荒漠假设单点交汇；ECSK 接触项含独立引力／挠率耦合常数 | 固定外幂库存严格无公共单点交点（命题 2.1）；$\mathsf E=-T^{\mathrm{color}}_2-\frac12 Y$ 同源给出修饰字符 $\pm 1/2$ 与静止电子 $\lvert Q_e\rvert=1$（命题 9.1、10.1）；零参数导出 $\frac{3N}{16}\eta_{ab}\mathcal A^a\mathcal A^b$ 与 42 位有理在壳交换（定理 6.1、命题 6.2） |
| **II. 受约束消元与低能有效作用** [2, 3, 13–16] | 横向投影常带 $1/k^2$ 奇点；四阶软模导数项含待拟合低能常数（LECs） | 无分母多项式截面 $289\to 103=79\oplus 24$ 保原点并完整回写 289 行（命题 4.1）；1650 项一阶射流 Hessian 全等于 $H_{289}(p)$（定理 11.1）；零待定常数算出四阶有理色散与五／六阶余项（命题 5.1） |
| **III. 非自治 Dirac 演化与 Kubo 响应** [4–6, 17–21] | Kato 非自治定理需定义域不变与 $C^1$ 正则；Kubo 公式常设平衡态 $[\rho,H]=0$ 并作形式一阶截断 | 双向刻画 $\mathcal D(\mathsf H)$（定理 7.2）；径向 Picard 映射免全局统一界与 $C^1$ 条件拼出全实轴全幅度幺正群（定理 8.1）；全词 CAR 保中间层返回（命题 3.4、7.3）；任意准备态上单位球一致 $\epsilon^2M^2\lvert t\rvert^2$ 算子范数 Kubo 导数（定理 8.2、推论 8.3） |
| **IV. 规范—Lorentz 恒等式与前度规光锥** [22–24, 36] | 阿贝尔平直 Ward 恒等式或依赖幽灵场的非阿贝尔恒等式；一般线性本构呈四次双折射锥面 | 无幽灵场 18 条弯曲规范—Lorentz 恒等式（定理 6.1）；正时钟 $t'=ct$ 保通量投影恒等式（命题 11.2、定理 11.3）；$D_{\mathrm{lead}}\ne 0$ 下 16 项多项式判据无角度平均充要刻画标准分支、保四项外流余项并锁死无双折射 **Maxwell 光速锥** $v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2$（定理 11.4） |
| **V. 实空间库仑势、复合核 $Z$ 与远场反馈** [25–35] | 微扰 $Z$ 需紫外重整化，LSZ 渐近丢弃非极点余项；微扰软光子需红外重求和 | 全方向 Schur 支配与三维矩阵 Bochner 积分直接返回单 $4\pi$ 库仑核 $1/(4\pi\lvert\mathbf x-\mathbf y\rvert)$，$N=3$ 复合极点包满足全场连续性且自动消去 $\lvert Q_e\rvert^2=1$（定理 12.1、推论 12.2、定理 12.3–12.4）；有限能量保三项截腿残差 $\mathfrak c_q$（引理 10.2）；无截断四分级价态核重叠给出 $C_{\mathrm{full}}=ZC_{\mathrm{base}}$（定理 13.1）；先 $\sigma\downarrow 0$ 后 $\kappa\downarrow 0$ 保原生—反馈—九零模$O(\kappa^{-2})$ 平衡（定理 14.1） |

### 14.3 同系列下游案卷（Case 2–6）的精确接口

本文确立的对象与恒等式为同系列后续唯象专篇提供了确定无误的输入接口，各篇边界清晰且无循环依赖：

- **无截断有序一圈闭迹与整球极化曲率（Case 2 [31]）**：直接消费本文 §7–§8 的空间 $L^2(\mathbb R^3,\mathbb C^{12})$ 演化、全词 CAR 读回与 §11.1 的母作用二阶变分认回 $H_{289}$，在零紫外截断下锁定空间波包整球极化曲率张量的 $(2-,1+)$ 惯性指数与常场非线性 Noether–Sylvester 响应。
- **零旋钮有效场匹配、重场解耦与精细结构常数源内 Thomson 公式（Case 3）**：沿本文 §9.5 注记 9.3 的原单位匹配桥（`L21-L23`）、命题 9.1 的电子绝对单位荷 $|Q_e|=1$、定理 11.4 的源生光速 $c_{\mathrm{phys}}$ 与定理 12.4 的极点耦合商表达式，完成源生标度 $\mu_0=1+4\pi^2$ 下两尺度四算符无参左逆匹配、108 通道重减轻 $O(h^3)/O(h)$ 红外阈值解耦及重标度不变的精细结构常数源内闭式算子商 $\alpha_{\mathrm{src}}(0)$。
- **十二荷超选择律、非交换味换位子与复合重子正谱（Case 4）及受约束算符场方程／迟滞反作用（Case 5A–5B）**：消费本文 §6 的全部 158 个物质耦合顶点、216 维自由外腿谱及 §§12–14 的 $N=3$ 复合电流与三通道反馈结构，建立 12 个守恒荷扇区、14 维味换位子代数 $\mathbb C^{10}\oplus M_2(\mathbb C)$、350 方向选态前微分 CAR 算符 Euler 方程及移动参考系迟滞正能量强制不等式，最终汇入 Case 6 的复合束缚谱与质子寿命严格区间演绎。

### 14.4 结语

开场那条四维窗口电流曾三次登台作证：作为有限非线性控制演化的期望值，作为双腿态变分的导数，作为海森堡对易子的有向积分。走完全文十四节的推演，同一零旋钮母作用交出的已不止是一条电流恒等式——它内生锁定了物理静止电子的绝对整单位电荷 $|Q_e|=1$，以无角度平均的多项式判据竖起了横波 Maxwell 光速锥 $v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2$，在三维矩阵 Bochner–Fourier 积分中带回了单 $4\pi$ 实空间库仑核 $1/(4\pi|\mathbf x-\mathbf y|)$，用无紫外截断的四分级 Born 概率振幅写出了复合态修饰律 $C_{\mathrm{full}}=ZC_{\mathrm{base}}$，并在远场完整保住了原生传播、量子极化反馈与九条规范—Lorentz 约束零模的同阶守恒。每一次消元降维、每一次截腿归一、每一次重标时钟，都完整保留了返回原始统一作用量的精确逆路。

<a id="app-a"></a>

## 附录 A　原库存、裸二次结构与稳定子

### A.1 指定库存的一圈代数

原单份 Weyl 库存为 $\Lambda^6\oplus\Lambda^2\oplus\Lambda^4$，另有一个复 $\Lambda^4$ 标量。代入指定一圈代数公式，按 $\mathrm{SU}(7),\mathrm{SU}(3),\mathrm{SU}(2),\mathrm U(1)$ 排序得到

$$b_0=\left(\frac{56}{3},4,\frac13,-28\right).\tag{A.1}$$

三个原本构参数均为 $1/2$；母 SU(7) 迹限制到超荷方向时为 native 配对的两倍。在指定仿射坐标 $\ell$ 中，三条逆耦合读数为

$$I_3=1+4\ell,\qquad I_2=1+\frac\ell3,\qquad I_1=\frac12-7\ell.
\tag{A.2}$$

它们同时为正的区间是 $-1/4<\ell<1/14$。由 $I_3=I_2$ 得 $\ell=0$，而此时 $I_1=1/2\ne1$，所以没有共同交点。这里 $\ell$ 是库存仿射跑动坐标，区别于正文物理时间 $t$；(A.1) 是指定库存对既有公式的代入，完整原量子圈的物理系数由 §9.3 的输入继续确定。

![指定库存的仿射读数](figures/fig1-fixed-inventory-running.svg)

**附图 A1　指定库存的三条仿射读数。** 横轴为库存跑动坐标 $\ln(\mu/\mu^*)$，不是原时间；$\ell=\ln(\mu/\mu^*)/(8\pi^2)$，三条线即 (A.2)，取原生 $\sigma=1/2$，未引入阈值、实验拟合或 GeV 标定。朱红竖段标出 $\ell=0$ 处 $I_3=I_2=1$ 而 $I_1=1/2$ 的缺口。

### A.2 联合真空的完整 Yukawa 坐标

按 (2.3) 的真空，楔映射 $Y:\Lambda^2\mathbb C^7\to\Lambda^6\mathbb C^7$ 的全部矩阵元由有向外积给出。若 $I$ 为六指标、$J$ 为二指标，

$$Y_{I,J}=\sum_{K\in\{0126,0124,0156,0145\}}
\mathbf1_{J\cap K=\varnothing}\mathbf1_{J\cup K=I}
\operatorname{sgn}(J,K),\tag{A.3}$$

其中符号是把先写 $J$、后写 $K$ 的序列排成递增六指标的置换符号。按原输出基排序，

$$YY^\dagger=\operatorname{diag}(2,2,2,4,2,0,0),\qquad
\operatorname{rank}Y=5,\qquad\dim\ker Y=16.\tag{A.4}$$

式 (A.3) 给出完整 $7\times21$ 矩阵，不必把 147 个坐标印成一个稠密方阵。原右手 Yukawa 仍是有序的 $Y_R$；$YY^\dagger$ 的奇异值读数不把它替换成 $Y_R+Y_R^\dagger$。

![联合真空的Yukawa奇异值](figures/fig3-joint-yukawa-spectrum.svg)

**附图 A2　联合真空的非零奇异值与核。** 左列为 $YY^\dagger$ 的本征值（奇异值平方），右列为重数；朱红的零本征值（重数 2）给出 $\operatorname{rank}Y=5$。来自完整 $7\times21$ 楔映射的 Gram 矩阵；图中裸奇异值的身份区别于 §6 的原频率谱。

### A.3 裸规范 Gram 与完整稳定子

把原规范方向作用于 $v$，并用原实标量配对取 Gram，得到式 (2.1) 原生规范块嵌入的裸二次块：秩为 9，谱为

$$0\ [3],\qquad1\ [6],\qquad
6x^3-26x^2+27x-8=0\ \text{的三根}.\tag{A.5}$$

完整母群中的标量稳定子为

$$\operatorname{Stab}_{\mathrm{SU}(7)}(v)
\simeq\frac{\mathrm{SU}(2)\times\mathrm{USp}(4)\times\mathrm U(1)}{\mathbb Z_2},
\tag{A.6}$$

其与 (2.1) 的标准模型规范子群相交为指定色 SU(2)。这个群同构可直接从四项真空求出。写

$$v=e_{01}\wedge\Omega_v,\qquad
\Omega_v=(e_2-e_5)\wedge e_4+(e_2+e_5)\wedge e_6,$$

并定义 $W_v(x)=x\wedge v$。逐项外积给出

$$W_v^\dagger W_v=\operatorname{diag}(0,0,2,4,2,2,2).$$

若 $g\in\mathrm{SU}(7)$ 保持 $v$，则 $W_vg=(\Lambda^5g)W_v$；外幂作用的幺正性迫使 $g$ 保持上述 Gram 的三个本征空间：$A=\operatorname{span}(e_0,e_1)$、$B=\operatorname{span}(e_2,e_4,e_5,e_6)$、$C=\operatorname{span}(e_3)$。这一步同时排除了混块与额外离散分支。令 $u_\pm=(e_2\pm e_5)/\sqrt2$，则 $\Omega_v=\sqrt2(u_-\wedge e_4+u_+\wedge e_6)$；保持它的 $U(B)$ 子群为 $\mathrm{USp}(4)$，并由 $\Omega_v\wedge\Omega_v\ne0$ 得到行列式为 1。

块对角元保持 $v$ 的条件是 $\det(g_A)\Lambda^2g_B(\Omega_v)=\Omega_v$。取 $z\in U(1)$ 满足 $z^2=\det(g_A)^{-1}$，令 $A_0=zg_A$、$S_B=z^{-1}g_B$，再用母行列式等于 1 得 $g_C=z^{-2}$。因而按 $A\oplus B\oplus C$ 块序的满射

$$(A_0,S_B,z)\longmapsto\operatorname{diag}(z^{-1}A_0,zS_B,z^{-2})$$

覆盖全部稳定子，其核恰为 $(I_2,I_4,1)$ 和 $(-I_2,-I_4,-1)$，即 (A.6) 的 $\mathbb Z_2$。

在式 (2.1) 规范子群内，保持 $A,B,C$ 迫使色块为 $(A_c,c)$、弱块为 $\operatorname{diag}(w,w^{-1})$、超荷块为 $\operatorname{diag}(h,h^{-1})$，其中 $\det A_c=c^{-1}$。四项 $e_{0126},e_{0124},e_{0156},e_{0145}$ 依次获得相位 $h^{-1},w^{-1},c^{-1},c^{-1}w^{-1}h$。四项线性独立且系数均为 1，故 $h=w=c=1$，留下恰为指定嵌入的色 $\mathrm{SU}(2)$。这是裸标量的完整群级解析证明；有限 Gram 校验与固定出处见附录 B 的 L2。∎

![式 (2.1) 规范块嵌入的标量—规范裸二次谱](figures/fig2-bare-scalar-gauge-spectrum-v2.svg)

**附图 A3　式 (2.1) 规范块嵌入的标量—规范裸二次谱。** 左列为 $R=B^{-1}K$ 的本征值，$B$ 为原生实标量配对，右列为重数；12 个方向中 3 个为零（朱红），9 个为正，三枚非有理本征值是 (A.5) 三次式的根，按有理隔离区间的小数显示。零空间与稳定子切向对应；完整耦合传播另外见 §4。

<a id="app-b"></a>
## 附录 B　固定证据、命题位置与证明补充导引

### B.1 版本、补充材料导引与证据身份

L1–L17 的固定来源为提交 S；L18–L22、L23–L25、L26–L28 分别采用 e055、c62、71e，第二版（v2）新增的 L29 及标准长程／$N=3$ 极点包采用第二版公开主张映射登记的固定源纪元；L23 采用 c62 中按原作用单位修复、并带源端左读数的匹配桥。本文继承的原作用基线 H = `e60a86058abcb74b7f2225f2383c182be8343785` 是 S 的祖先，原作用根、背景参数、实际背景与 Clifford 定义在两者之间相同。

下表中 **F** 表示正式 Lean 定理，**E** 表示精确程序结果及其独立检查，**A** 表示解析论证。路径前缀 `L/` 为 `Lean/SaturationMonoid/PhysicsCore/LowEnergy/`，`V/` 为 `Verification/physics/low-energy-phenomenology/`。

| 命题 | 身份 | 正文／补充材料 | 固定来源入口 |
|------|--|-----|-----------|
| L1 库存与仿射式 | F | A.1 | `L/ScalarInventory.lean`、`L/Running.lean` |
| L2 联合真空与裸稳定子 | F/E/A | §2、A.2–A.3 | `L/JointMassCoordinates.lean`、`V/stabilizer-derivation.md` |
| L3 共同九场与真初值导数 | F | §3.1–3.2、补充 S1.1 | `L/Evolution/Uniform.lean`、`VariationDerivative.lean` |
| L4 完整物质复合与密度 | F | §3.4、补充 S3.3 | `L/Quantum/{Compression,Density}.lean` |
| L5 全动量径向 Jacobi | F | §3.3 | `L/Spacetime/{Propagation,Cauchy,Jacobi}.lean` |
| L6 完整耦合传播 | F/E | §4.1–4.3、补充 S1.2 | `V/active-gauge/`、`rotation/` |
| L7 相位、制备与外围发展 | F/E | §2.5、§4.4–4.5、补充 S1.2 | `L/FullPhase/`、`V/canonical-active/`、`canonical-peripheral/` |
| L8 两相位有效作用 | E | §5、补充 S1.3、图2 | `V/soft-phase/compute.py`、`receipt.json` |
| L9 完整顶点与源交换 | F/E | §6.1–6.3、补充 S2.2 | `V/matter-vertices/`、`scalar-exchange/`、`L/Fermion/Consumer.lean` |
| L10 原自由外腿与留数 | F/E | §6.4–6.6、补充 S2.1/S2.3 | `V/matter-modes/`、`onshell-sources/`、`kinetic-residue/` |
| L11 主部与静态源响应 | E | §6.7、补充 S2.3 | `V/principal-normalization/`、`charge-response/`、`metric-response/` |
| L12 全规范占据响应 | E | §7.1 | `V/occupied-response/`、`causal/` |
| L13 全空间群与完整域 | F/E | §7.2–7.3、补充 S3.1 | `L/MatterSpace/{Spatial,GeneratorDomain,PrimalSymbol}.lean` |
| L14 真实规范准备 | F | §7.3、补充 S3.3 | `L/MatterSpace/Preparation{Gauge,State,Native}.lean` |
| L15 全部有限 CAR 词 | F | §7.4、补充 S3.3 | `L/MatterSpace/SpatialCAR{Words,State,Native}.lean` |
| L16 局域电流与原相位 | F | §7.5、§8.3、补充 S3.4 | `L/MatterSpace/SpatialResponse{Kubo,Source,Phase}.lean` |
| L17 全时间、全幅度与真导数 | F/E | §1、§8、补充 S3.2/S3.4、图3 | `L/MatterSpace/Global{Glue,Flow,Response,Original}.lean` |

新增源路径均以 `Verification/physics/low-energy-phenomenology/` 为根；下表续列 L18–L29 及第二版（v2）标准长程／极点扩展（固定提交别名 `e055`、`c62`、`71e`、`ba7e`、`df4` 完整哈希见“代码与数据可得性”）。

| 命题 | 身份 | 正文／补充材料 | 固定来源入口 |
|---|---|---|---|
| L18 联合荷与完整静态投影 | F | §9.1–9.4、补充 S4.2 | `alpha-source/SourceJoint{PhaseAction,PreparedCoupling}.lean`、`SourceStaticComposite{Projection,Current}.lean` |
| L19 完整静态库仑标量 | F | §9.4、补充 S4.2 | `em-identification/PhysicalEMCompleteStaticScalar.lean` |
| L20 修饰联合字符与准备读回 | F | §9.3 | `em-identification/PhysicalEMDressed{Character,PreparedRead}.lean` |
| L21 电子单位荷与 Thomson 接口 | F | §9.3/9.5、§10.1 | `SourceElectronChargeUnit.lean`、`SourceThomson{StaticResponse,MatchingConsumer}.lean` |
| L22 源生光子振幅与在壳输入包 | F | §9.2/9.5、补充 S4.1 | `SourcePrepared{PhotonAmplitude,ThomsonInput}.lean` |
| L23 原作用单位匹配桥 | F | §9.5 | `SourcePreparedThomsonMatchingBridge.lean` |
| L24 物理电子同荷交换与一次库仑 | F | §10.1–10.4、补充 S4.3 | `em-identification/PhysicalEMActualElectronCoulomb.lean` |
| L25 在壳光子极点全参数返回 | F | §10.5 | `em-identification/PhysicalEMActualElectronOrdinary.lean` |
| L26 母作用 Hessian 与时钟通量 | F | §11.1–11.3、补充 S5.1–S5.2、图4 | `em-identification/ActualEM{Carrier,Action,Clock}.lean` |
| L26 标准分支与横波 Maxwell 锥 | F | §11.4、补充 S5.7、图7 | `em-identification/ActualDressedEM{StandardLongRange,CorrectedRootFluxConsumer}.lean` |
| L27 全场／运动双端单 $4\pi$ 返回 | F | §12.1–12.3、补充 S5.3–S5.5、图5 | `em-identification/Actual{WholeCoulombPacket,DressedMovingCoulomb}.lean` |
| L27 $N=3$ 极点包与 $\lvert Q_e\rvert^2=1$ 消去 | F | §12.4、补充 S5.7、图7 | `em-identification/PhysicalN3Pole{CoulombPacket,CurrentAudit}.lean` |
| L28 三费米子四端 Born 重叠修饰 | F | §13、补充 S5.6、图6 | `em-identification/ActualCompositeCoulombDressing.lean` |
| L29 静态电流三通道与两步远场平衡 | F | §14.1、补充 S5.7、图7 | `em-identification/ActualDressedStatic{CurrentCircuit,LongrangeReturn}.lean` |

### B.2 源码还原

原精确数据文件摘自提交 S；机制图由各自固定声明生成。构建、检查和各来源的公开状态见“代码与数据可得性”一节。在公开仓 H0mework 中按原路径还原固定源码的命令为

```bash
python3 tools/source_view.py --output <目录> --at base --path <完整仓内路径>
```

正文记号与固定源码声明的对应如下，供按名称检索：

| 正文记号 | 源码声明 |
|---|---|
| $h_{\mathrm{src}}$，$c_{\mathrm{src}}(b)$ | `phaseMomentum`，`sourceSpeed` |
| $\mathcal Z_\phi$，$\Pi_{\mathrm{prep}}$，$\mathcal D_{1/2}$，$\mathcal C_{\mathrm{src}}$ | `zeroLocalizedProfile`，`prepared`，`halfDensityEquiv 0`，`sourceCreated` |
| $\mathcal F_i$ | `fieldForm` |
| $G_T$ | `SourceDressedGTCharacter` 中的 GT 生成元 |
| $u^{\mathrm{ch}}_{s,0}$，$\iota$ | `sourceChargedRestriction s 0`，`naturalCoordinates` |
| $F_0$，$G_0$ | `fullNativeOrigin`，`staticInverse` |
| 源极点支与 $e_0$ | `sourceSheet`，`scaleApproach` |
| $U_p(t)$，$G_p(z)$ | `physicalTime`，`jointResolvent` |
| $\mathcal R_{\mathrm{stat}}$，$\mathcal R_{\mathrm{dyn}}$，$c_{\mathrm{phys}}$ | `sourceStandardStaticRemainder`，`sourceDynamicStandardRemainder`，`sourceGeneratedPhysicalC` |
| $C_{\mathrm{EM}}^{\mathrm{gen}}$，$\alpha_{\mathrm{pole}}$ | `sourceGeneratedScalarCEM`，`physicalN3PoleEMCouplingExpression` |
| $w_{\mathrm{Yuk},d}$，$q_d^{(3)}$ | `yukawaWitness`，`actual_candidate_Y_entry` |
| $\mathcal R_{\mathrm{nat}}$，$\mathcal R_{\mathrm{fb}}$，$\mathcal R_{\mathrm{null}}$ | `nativeCurrentRead`，`feedbackCurrentRead`，`nullCurrentRead` |


<!-- code-availability:begin -->
## 代码与数据可得性

第二版 L1–L29 的[公开主张映射](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-map.json)和[复现说明](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-reproduction.md)固定于 H0mework 提交 `d916604d403ae97e19779ff6fcd789e0184a468d`（Apache-2.0）。映射逐项给出源纪元、公开声明、下游验证、资源、原认证及公开内核验收。第一版[固定映射](https://github.com/Sapientropic/H0mework/blob/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/low-energy-release-map.json)继续提供原范围的证明与精确科学证据。

各检查使用新的输出目录。以下命令核验固定映射及原认证，并构建、审查第二版新增范围 L26–L29。复现说明也给出继承证明和精确资源的入口。

```sh
git checkout d916604d403ae97e19779ff6fcd789e0184a468d
python3 tools/low_energy_v2.py entry --paper low-energy-phenomenology
for check in build trust types; do
  LEAN_NUM_THREADS=2 python3 tools/low_energy_v2.py "$check"     --paper low-energy-phenomenology --output ".local/low-energy-v2-$check"
done
```
<!-- code-availability:end -->

## 参考文献

[1] Gao, J. *From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*（《从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成》）. CourtyCourt · Case 0, Zenodo, v3 (2026), DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339)（第一版 v1 DOI: [10.5281/zenodo.23210292](https://doi.org/10.5281/zenodo.23210292)；第二版 v2 DOI: [10.5281/zenodo.23297179](https://doi.org/10.5281/zenodo.23297179)）.

[2] Abbott, L. F. Introduction to the Background Field Method. *Acta Physica Polonica B*, **13** (1982), 33–50. [原刊全文](https://www.actaphys.uj.edu.pl/R/13/1/33/pdf).

[3] Henning, B., Lu, X., and Murayama, H. How to use the Standard Model effective field theory. *Journal of High Energy Physics*, **2016**(01) (2016), 023. DOI: [10.1007/JHEP01(2016)023](https://doi.org/10.1007/JHEP01(2016)023). [作者原稿 arXiv:1412.1837v2](https://arxiv.org/abs/1412.1837v2), §2.1, 式 (2.1)–(2.8).

[4] Tasaki, H. Introduction to the “second quantization” formalism for non-relativistic quantum mechanics: A possible substitution for Sections 6.7 and 6.8 of Feynman's “Statistical Mechanics”. [arXiv:1812.10732v5](https://arxiv.org/abs/1812.10732v5) (2018; v5 revised 2023), §3, 式 (3.22)–(3.29).

[5] Kato, T. Integration of the equation of evolution in a Banach space. *Journal of the Mathematical Society of Japan*, **5**(2) (1953), 208–234. DOI: [10.2969/jmsj/00520208](https://doi.org/10.2969/jmsj/00520208).

[6] Kubo, R. Statistical-Mechanical Theory of Irreversible Processes. I. General Theory and Simple Applications to Magnetic and Conduction Problems. *Journal of the Physical Society of Japan*, **12**(6) (1957), 570–586. DOI: [10.1143/JPSJ.12.570](https://doi.org/10.1143/JPSJ.12.570).

[7] Georgi, H., and Glashow, S. L. Unity of All Elementary-Particle Forces. *Physical Review Letters*, **32**(8) (1974), 438–441. DOI: [10.1103/PhysRevLett.32.438](https://doi.org/10.1103/PhysRevLett.32.438).

[8] Georgi, H., Quinn, H. R., and Weinberg, S. Hierarchy of Interactions in Unified Gauge Theories. *Physical Review Letters*, **33**(7) (1974), 451–454. DOI: [10.1103/PhysRevLett.33.451](https://doi.org/10.1103/PhysRevLett.33.451).

[9] Pati, J. C., and Salam, A. Lepton number as the fourth “color”. *Physical Review D*, **10**(1) (1974), 275–289. DOI: [10.1103/PhysRevD.10.275](https://doi.org/10.1103/PhysRevD.10.275).

[10] Kibble, T. W. B. Lorentz Invariance and the Gravitational Field. *Journal of Mathematical Physics*, **2**(2) (1961), 212–221. DOI: [10.1063/1.1703702](https://doi.org/10.1063/1.1703702).

[11] Sciama, D. W. The Physical Structure of General Relativity. *Reviews of Modern Physics*, **36**(1) (1964), 463–469 (Erratum: **36**, 1103). DOI: [10.1103/RevModPhys.36.463](https://doi.org/10.1103/RevModPhys.36.463).

[12] Hehl, F. W., von der Heyde, P., Kerlick, G. D., and Nester, J. M. General relativity with spin and torsion: Foundations and prospects. *Reviews of Modern Physics*, **48**(3) (1976), 393–416. DOI: [10.1103/RevModPhys.48.393](https://doi.org/10.1103/RevModPhys.48.393).

[13] Dirac, P. A. M. Generalized Hamiltonian Dynamics. *Canadian Journal of Mathematics*, **2** (1950), 129–148. DOI: [10.4153/CJM-1950-012-1](https://doi.org/10.4153/CJM-1950-012-1).

[14] DeWitt, B. S. Quantum Theory of Gravity. II. The Manifestly Covariant Theory. *Physical Review*, **162**(5) (1967), 1195–1239. DOI: [10.1103/PhysRev.162.1195](https://doi.org/10.1103/PhysRev.162.1195).

[15] Weinberg, S. Phenomenological Lagrangians. *Physica A: Statistical Mechanics and its Applications*, **96**(1–2) (1979), 327–340. DOI: [10.1016/0378-4371(79)90223-1](https://doi.org/10.1016/0378-4371(79)90223-1).

[16] Appelquist, T., and Carazzone, J. Infrared singularities and massive fields. *Physical Review D*, **11**(10) (1975), 2856–2861. DOI: [10.1103/PhysRevD.11.2856](https://doi.org/10.1103/PhysRevD.11.2856).

[17] Stone, M. H. On One-Parameter Unitary Groups in Hilbert Space. *Annals of Mathematics* (2), **33**(3) (1932), 643–648. DOI: [10.2307/1968538](https://doi.org/10.2307/1968538).

[18] Thaller, B. *The Dirac Equation*. Texts and Monographs in Physics, Springer-Verlag, Berlin, Heidelberg (1992). DOI: [10.1007/978-3-662-02753-0](https://doi.org/10.1007/978-3-662-02753-0).

[19] Dyson, F. J. The Radiation Theories of Tomonaga, Schwinger, and Feynman. *Physical Review*, **75**(3) (1949), 486–502. DOI: [10.1103/PhysRev.75.486](https://doi.org/10.1103/PhysRev.75.486).

[20] Araki, H. On Quasifree States of CAR and Bogoliubov Automorphisms. *Publications of the Research Institute for Mathematical Sciences*, **6**(3) (1970), 385–442. DOI: [10.2977/prims/1195193913](https://doi.org/10.2977/prims/1195193913).

[21] Bratteli, O., and Robinson, D. W. *Operator Algebras and Quantum Statistical Mechanics 2: Equilibrium States. Models in Quantum Statistical Mechanics*, 2nd ed. Springer-Verlag, Berlin, Heidelberg (1997). DOI: [10.1007/978-3-662-03444-6](https://doi.org/10.1007/978-3-662-03444-6).

[22] Ward, J. C. An Identity in Quantum Electrodynamics. *Physical Review*, **78**(2) (1950), 182. DOI: [10.1103/PhysRev.78.182](https://doi.org/10.1103/PhysRev.78.182).

[23] Takahashi, Y. On the generalized Ward identity. *Il Nuovo Cimento*, **6**(2) (1957), 371–375. DOI: [10.1007/BF02832514](https://doi.org/10.1007/BF02832514).

[24] Hehl, F. W., and Obukhov, Y. N. *Foundations of Classical Electrodynamics: Charge, Flux, and Metric*. Progress in Mathematical Physics, Vol. 33, Birkhäuser, Boston (2003). DOI: [10.1007/978-1-4612-0051-2](https://doi.org/10.1007/978-1-4612-0051-2).

[25] Lehmann, H. Über Eigenschaften von Ausbreitungsfunktionen und Renormierungskonstanten quantisierter Felder. *Il Nuovo Cimento*, **11**(4) (1954), 342–357. DOI: [10.1007/BF02783624](https://doi.org/10.1007/BF02783624).

[26] Lehmann, H., Symanzik, K., and Zimmermann, W. Zur Formulierung quantisierter Feldtheorien. *Il Nuovo Cimento*, **1**(1) (1955), 205–225. DOI: [10.1007/BF02731765](https://doi.org/10.1007/BF02731765).

[27] Dirac, P. A. M. Gauge-Invariant Formulation of Quantum Electrodynamics. *Canadian Journal of Physics*, **33**(11) (1955), 650–660. DOI: [10.1139/p55-081](https://doi.org/10.1139/p55-081).

[28] Kulish, P. P., and Faddeev, L. D. Asymptotic conditions and infrared divergences in quantum electrodynamics. *Theoretical and Mathematical Physics*, **4**(2) (1970), 745–757（俄文原刊 *Teoret. Mat. Fiz.* **4**(2), 153–170）. DOI: [10.1007/BF01066485](https://doi.org/10.1007/BF01066485).

[29] Buchholz, D. Gauss' law and the infraparticle problem. *Physics Letters B*, **174**(3) (1986), 331–334. DOI: [10.1016/0370-2693(86)91110-X](https://doi.org/10.1016/0370-2693(86)91110-X).

[30] Donoghue, J. F. General relativity as an effective field theory: The leading quantum corrections. *Physical Review D*, **50**(6) (1994), 3874–3888. DOI: [10.1103/PhysRevD.50.3874](https://doi.org/10.1103/PhysRevD.50.3874). [arXiv:gr-qc/9405057](https://arxiv.org/abs/gr-qc/9405057).

[31] Gao, J. *Two Negatives and One Positive, the Bare Trace Under Oath: Ordered Closed Traces and Whole-Ball Response Curvature*（《两负一正，裸迹宣誓：有序闭迹与整球响应曲率》）. CourtyCourt · Case 2, Zenodo, v1 (2026). DOI: [10.5281/zenodo.23299177](https://doi.org/10.5281/zenodo.23299177).

[32] de Moura, L., and Ullrich, S. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, Lecture Notes in Computer Science, Vol. 12699, Springer (2021), 625–635. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[33] Källén, G. On the definition of the renormalization constants in quantum electrodynamics. *Helvetica Physica Acta*, **25**(4) (1952), 417–434. DOI: [10.5169/seals-112316](https://doi.org/10.5169/seals-112316).

[34] Haag, R. Quantum Field Theories with Composite Particles and Asymptotic Conditions. *Physical Review*, **112**(2) (1958), 669–673. DOI: [10.1103/PhysRev.112.669](https://doi.org/10.1103/PhysRev.112.669).

[35] Weinberg, S. Evidence That the Deuteron Is Not an Elementary Particle. *Physical Review*, **137**(3B) (1965), B672–B678. DOI: [10.1103/PhysRev.137.B672](https://doi.org/10.1103/PhysRev.137.B672).

[36] Taylor, J. C. Ward identities and charge renormalization of the Yang–Mills field. *Nuclear Physics B*, **33**(2) (1971), 436–444. DOI: [10.1016/0550-3213(71)90297-5](https://doi.org/10.1016/0550-3213(71)90297-5).
