#!/usr/bin/env python3
"""Draw upgraded v2 vector plates (Figures 4, 5, 6, 7, and A3) without touching frozen v1 art."""
from __future__ import annotations

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path

from svg_plate import (
    SVGPlate,
    SVG_FONT_ZH,
    SVG_FONT_EN,
    INK,
    SLATE,
    MUTE,
    HAIR,
    DEEP,
    VERMILION,
    GOLD,
    WASH,
)

BASE = Path(__file__).resolve().parents[1]
SOURCE_71E = '71e94e8261d67cf4849a05eb14ac95aa2f7dcbb9'
SOURCE_DF4 = 'df421ff600085cbc290a7ae946193961bed7c83b'
SOURCE_302 = '30218c1aea92640eae09b1d9204a09b01a2d0e47'


def make_plate(language: str, title: str, height: int, source_commit: str, records: list[dict]) -> SVGPlate:
    return SVGPlate(
        title,
        height,
        base=BASE,
        source_commit=source_commit,
        font=SVG_FONT_ZH if language == 'zh' else SVG_FONT_EN,
        suffix='' if language == 'zh' else '-en',
        manifest=records,
        creator='draw_v2_figures.py',
    )


def draw_main_04(language: str, records: list[dict]) -> None:
    t = lambda zh, en: zh if language == 'zh' else en
    g = make_plate(
        language,
        t('同一母作用下的正时钟重表达与留数通量守恒',
          'Positive clock rescaling and residue-flux invariance of one mother action'),
        648,
        SOURCE_71E,
        records,
    )

    # Top header box
    g.box(
        36, 16, 928, 86,
        t('同一母作用的 289 行二阶变分与字面电磁方向嵌入',
          '289-row second variation and literal EM embedding of one mother action'),
        [r'$K(p)=D^2\mathcal{L}_{\mathrm{nat}}(0)(p)=H_{289}(p),\qquad \mathrm{E}=-T^{\mathrm{color}}_2-\frac{1}{2}Y,\qquad \mathcal{E}:\mathbb{C}^4\to\mathbb{C}^{289}$'],
        edge=DEEP, title_fill=DEEP, lw=1.6,
    )

    g.line(300, 102, 255, 130, stroke=DEEP, arrow=True)
    g.line(700, 102, 745, 130, stroke=SLATE, arrow=True)

    # Left & Right boxes
    g.box(
        36, 134, 438, 138,
        t('原物理频率读出（$c=1$）', 'Original physical frequency ($c=1$)'),
        [
            r'$R_\omega=\lim_{\omega\to\omega_b}(\omega-\omega_b)G(\omega)$',
            r'$K^\prime_\omega=\partial_\omega K(\omega_b),\qquad P=R_\omega K^\prime_\omega$',
            r'$R_\omega K^\prime_\omega R_\omega=R_\omega$',
        ],
    )
    g.line(474, 203, 524, 203, stroke=DEEP, width=1.8, arrow=True)
    g.box(
        526, 134, 438, 138,
        t(r'任意正时钟重表达（$t^\prime=ct,\ c>0$）', r'Positive clock rescaling ($t^\prime=ct,\ c>0$)'),
        [
            r'$\omega^\prime=\omega/c,\qquad \omega^\prime_b=\omega_b/c$',
            r'$R_c=R_\omega/c,\qquad K^\prime_c=cK^\prime_\omega$',
            r'$R_cK^\prime_c=R_\omega K^\prime_\omega=P$',
        ],
    )

    # Geometric card: Inverse-hyperbola scaling vs invariant projector P
    g.items.append(f'<rect x="36" y="286" width="928" height="202" rx="6" fill="#FAFBFD" stroke="{HAIR}" stroke-width="1.1"/>')
    x0, x1, y0, y1 = 124, 584, 450, 308
    c_min, c_max, s_max = 0.40, 2.25, 2.35
    px = lambda c: x0 + (c - c_min) / (c_max - c_min) * (x1 - x0)
    py = lambda s: y0 - (s / s_max) * (y0 - y1)

    # Reference dashed guides at c=1 and scale=1
    g.line(px(1.0), y0, px(1.0), y1 + 8, stroke=HAIR, width=1.1, dash='4 4')
    g.line(x0 - 5, py(1.0), x0, py(1.0), stroke=SLATE, width=1.2)
    g.mathtext(x0 - 10, py(1.0) + 6, r'$1$', size=17, anchor='end', fill=SLATE)
    for c_tick, lbl in [(0.5, r'$0.5$'), (1.0, r'$1$'), (1.5, r'$1.5$'), (2.0, r'$2$')]:
        tx = px(c_tick)
        g.line(tx, y0, tx, y0 + 5, stroke=SLATE, width=1.2)
        g.mathtext(tx, y0 + 24, lbl, size=17, anchor='middle', fill=SLATE)

    g.line(x0, y0, x1 + 18, y0, stroke=SLATE, width=1.3, arrow=True)
    g.line(x0, y0, x0, y1 - 4, stroke=SLATE, width=1.3, arrow=True)
    g.mathtext(x1 + 16, y0 + 24, r'$c$', size=17, anchor='end', fill=INK)

    # Curves: 1/c (DEEP), c (GOLD dashed), and invariant product 1 (VERMILION)
    cs = [0.46 + i * (2.16 - 0.46) / 68 for i in range(69)]
    pts_inv = [(px(c), py(1.0 / c)) for c in cs]
    pts_lin = [(px(c), py(c)) for c in cs]
    g.path(pts_inv, stroke=DEEP, width=2.5)
    g.path(pts_lin, stroke=GOLD, width=2.2, dash='7 5')
    g.line(px(0.46), py(1.0), px(2.16), py(1.0), stroke=VERMILION, width=2.7)
    g.items.append(f'<circle cx="{px(1.0):.2f}" cy="{py(1.0):.2f}" r="5.5" fill="white" stroke="{VERMILION}" stroke-width="2.4"/>')

    g.mathtext(px(0.54) + 8, py(1.0 / 0.54) + 4, r'$R_c/R_\omega = 1/c$', size=17, anchor='start', fill=DEEP)
    g.mathtext(px(1.92) - 8, py(1.92) - 8, r'$K^\prime_c/K^\prime_\omega = c$', size=17, anchor='end', fill=GOLD)
    g.mathtext(px(1.78), py(1.0) - 10, r'$R_c K^\prime_c = P$', size=17, anchor='middle', fill=VERMILION)

    # Right legend inside geometric card
    g.line(626, 302, 626, 472, stroke=HAIR, width=1.0)
    g.text(794, 326, t('互逆缩放与不变量（定理 11.3）', 'Reciprocal scaling & invariant'),
           size=18, anchor='middle', weight='600', fill=INK)
    g.line(648, 360, 692, 360, stroke=DEEP, width=2.6)
    g.text(704, 366, t(r'极点留数 $R_c=R_\omega/c$', r'Residue $R_c=R_\omega/c$'), size=17, fill=DEEP)
    g.path([(648, 400), (692, 400)], stroke=GOLD, width=2.3, dash='7 5')
    g.text(704, 406, t(r'链式导数 $K^\prime_c=cK^\prime_\omega$', r'Derivative $K^\prime_c=cK^\prime_\omega$'), size=17, fill=GOLD)
    g.line(648, 440, 692, 440, stroke=VERMILION, width=2.7)
    g.text(704, 446, t(r'归一投影 $R_cK^\prime_c=P$ 恒定', r'Projector $R_cK^\prime_c=P$ fixed'), size=17, fill=VERMILION)

    # Bottom verdict
    g.line(500, 488, 500, 514, stroke=VERMILION, arrow=True)
    g.box(
        46, 518, 908, 114,
        t('通量归一恒等式与全 289 维留数投影随任意正时钟严格保持',
          'Flux normalization and 289-row residue projector hold across all $c>0$'),
        [
            r'$\mathcal{E}^{\mathsf{T}}R_cK^\prime_cR_c\mathcal{E}=\mathcal{E}^{\mathsf{T}}R_c\mathcal{E}=\frac{1}{c}\,\mathcal{E}^{\mathsf{T}}R_\omega\mathcal{E}$',
            t('完整保留混合色—引力输出；双侧留数同乘 1/c 而归一投影 P 不变',
              'Retains mixed color–gravity outputs; both sides scale by 1/c while P stays fixed'),
        ],
        fill=WASH, edge=VERMILION, title_fill=VERMILION, lw=2.0,
    )
    g.save('main-04-action-clock-v2')


def draw_main_05(language: str, records: list[dict]) -> None:
    t = lambda zh, en: zh if language == 'zh' else en
    g = make_plate(
        language,
        t('相反动量转移下的二粒子连通流与三维实空间单 4π 库仑返回',
          'Opposite-transfer N=2 connected currents and 3D single-4pi Coulomb return'),
        684,
        SOURCE_71E,
        records,
    )

    g.box(
        36, 16, 442, 114,
        t('探测器端：二粒子（$N=2$）连通流', 'Detector: two-particle ($N=2$) connected current'),
        [
            r'$J_D(-a\mathbf{k})\in\mathbb{C}^{289}$',
            t('独立创建事件、非实能量与有向年龄窗', 'Independent creation event, nonreal energy & window'),
        ],
    )
    g.box(
        522, 16, 442, 114,
        t('源端：二粒子（$N=2$）连通流', 'Source: two-particle ($N=2$) connected current'),
        [
            r'$J_S(+a\mathbf{k})\in\mathbb{C}^{289}$',
            t('独立创建事件、非实能量与有向年龄窗', 'Independent creation event, nonreal energy & window'),
        ],
    )

    g.line(257, 130, 360, 158, stroke=DEEP, arrow=True)
    g.line(743, 130, 640, 158, stroke=SLATE, arrow=True)

    g.box(
        64, 162, 872, 114,
        t('同一完整 289 场受约束 Green 算子与内生红外窗口',
          'Complete 289-field constrained Green operator & endogenous IR window'),
        [
            r'$0<a|\mathbf{k}|<r_*=\min(\rho,\rho_{DS}),\qquad \mathbf{k}=2\pi\xi$',
            r'$m_a(\mathbf{k})=J_D(-a\mathbf{k})^{\mathsf{T}}[a^2G(0,ia\mathbf{k})]J_S(a\mathbf{k}),\qquad |m_a(\mathbf{k})|\leq B_{DS}/|\mathbf{k}|^2$',
        ],
    )

    g.line(500, 276, 500, 300, stroke=DEEP, arrow=True)

    # Dual-domain geometric card: Momentum IR Ball -> Bochner F^{-1} -> Real-space 1/(4\pi r) & wavepacket
    g.items.append(f'<rect x="36" y="304" width="928" height="222" rx="6" fill="#FAFBFD" stroke="{HAIR}" stroke-width="1.1"/>')

    # Left subpanel: 3D punctured momentum ball
    g.text(242, 330, t('三维动量穿孔红外球（$L^1$ 支配）', '3D punctured momentum IR ball ($L^1$ bound)'),
           size=18, anchor='middle', weight='600', fill=INK)
    bx, by, br = 242, 420, 66
    g.items.append(f'<circle cx="{bx}" cy="{by}" r="{br}" fill="#EBF2F7" stroke="{DEEP}" stroke-width="1.6"/>')
    g.items.append(f'<ellipse cx="{bx}" cy="{by}" rx="{br}" ry="18" fill="none" stroke="{HAIR}" stroke-width="1.1"/>')
    # Opposite transfer vectors -ak and +ak cleanly inside the ball
    g.line(bx, by, bx - 44, by - 22, stroke=DEEP, width=2.2, arrow=True)
    g.line(bx, by, bx + 44, by + 22, stroke=VERMILION, width=2.2, arrow=True)
    # Punctured origin hollow dot
    g.items.append(f'<circle cx="{bx}" cy="{by}" r="4.5" fill="white" stroke="{VERMILION}" stroke-width="2.0"/>')
    g.mathtext(bx - 10, by - 26, r'$-a\mathbf{k}$', size=17, anchor='middle', fill=DEEP)
    g.mathtext(bx + 12, by + 39, r'$+a\mathbf{k}$', size=17, anchor='middle', fill=VERMILION)
    g.mathtext(bx, by + br + 24, r'$0<a|\mathbf{k}|<\min(\rho,\rho_{DS})$', size=17, anchor='middle', fill=SLATE)

    # Center bridge: Bochner-Fourier F^{-1}
    g.line(446, 422, 534, 422, stroke=DEEP, width=2.2, arrow=True)
    g.mathtext(490, 408, r'$a\downarrow 0$', size=17, anchor='middle', fill=DEEP)
    g.mathtext(490, 448, r'$\mathcal{F}^{-1}$', size=17, anchor='middle', fill=SLATE)

    # Right subpanel: Real-space 1/(4 pi |y|) potential + Schwartz wavepacket f_phi
    g.text(754, 330, t(r'实空间单 $4\pi$ 库仑核与 Schwartz 波包', r'Real-space $1/(4\pi r)$ kernel & wavepacket'),
           size=18, anchor='middle', weight='600', fill=INK)
    ox, oy = 586, 486
    g.line(ox, oy, 932, oy, stroke=SLATE, width=1.3, arrow=True)
    g.line(ox, oy, ox, 344, stroke=SLATE, width=1.3, arrow=True)
    g.mathtext(934, 510, r'$|\mathbf{y}|$', size=17, anchor='end', fill=INK)

    # Shaded Schwartz bell packet f_phi(x - y)
    pkt_pts = []
    for i in range(61):
        u = i / 60.0
        xx = ox + 36 + u * 260
        yy = oy - 68 * math.exp(-((u - 0.52) / 0.20) ** 2)
        pkt_pts.append((xx, yy))
    poly = ' '.join(f'{x:.2f},{y:.2f}' for x, y in [(pkt_pts[0][0], oy)] + pkt_pts + [(pkt_pts[-1][0], oy)])
    g.items.append(f'<polygon points="{poly}" fill="#DCE8F2" opacity="0.80"/>')
    g.path(pkt_pts, stroke=DEEP, width=1.9, dash='6 4')
    g.mathtext(766, 412, r'$f_\phi(\mathbf{x}-\mathbf{y})$', size=17, anchor='start', fill=DEEP)

    # Smooth 1/(4 pi |y|) radial curve
    coul_pts = []
    for i in range(65):
        r = 0.24 + i * (2.60 - 0.24) / 64.0
        xx = ox + 14 + (r / 2.65) * 300
        yy = oy - min(132.0, 31.5 / r)
        coul_pts.append((xx, yy))
    g.path(coul_pts, stroke=VERMILION, width=2.6)
    g.mathtext(644, 362, r'$\frac{1}{4\pi|\mathbf{y}|}$', size=18, anchor='start', fill=VERMILION)

    g.line(500, 526, 500, 550, stroke=VERMILION, arrow=True)

    g.box(
        46, 554, 908, 114,
        t(r'同一次相反转移返回三维实空间单 $4\pi$ 库仑—Newton 观测（定理 12.3）',
          r'One opposite transfer returns the 3D single-$4\pi$ Coulomb–Newton observation (Thm. 12.3)'),
        [
            r'$\mathcal{P}^{\mathrm{conn}}_a[\phi](\mathbf{x})\longrightarrow -(F_0^{\mathsf{T}}J_D(0))^{\mathsf{T}}G_0(F_0^{\mathsf{T}}J_S(0))\int\frac{f_\phi(\mathbf{x}-\mathbf{y})}{4\pi|\mathbf{y}|}\,d^3y$',
            t('无角度平均与软光子重求和；完整联合荷四项展开式 (12.12) 同步保持',
              'No angular averaging or soft resummation; four-term joint return (12.12) retained'),
        ],
        fill=WASH, edge=VERMILION, title_fill=VERMILION, lw=2.0,
    )
    g.save('main-05-newton-return-v2')


def draw_main_06(language: str, records: list[dict]) -> None:
    t = lambda zh, en: zh if language == 'zh' else en
    g = make_plate(
        language,
        t('三费米子四分级泡利截断、底扇区 Born 重叠与四端库仑修饰',
          'Four-grade Pauli truncation, valence-core Born overlaps, and four-end Coulomb dressing'),
        708,
        SOURCE_71E,
        records,
    )

    g.text(
        500, 28,
        t('探测器对与源对各含至少一端保分级基准支（$\\sharp=1$）；分母保留完整 $N=3$ 四分级范数',
          'At least one grade-preserving reference leg ($\\sharp=1$) per pair; full $N=3$ four-grade norms'),
        size=18, anchor='middle', weight='600', fill=INK,
    )

    legs = [
        (35, t('探测器左腿 $dL$', 'Detector left $dL$'), 'dL'),
        (273, t('探测器右腿 $dR$', 'Detector right $dR$'), 'dR'),
        (511, t('源端左腿 $sL$', 'Source left $sL$'), 'sL'),
        (749, t('源端右腿 $sR$', 'Source right $sR$'), 'sR'),
    ]
    for x, label, sym in legs:
        g.box(
            x, 46, 216, 114,
            label,
            [
                r'$z_{' + sym + r'}=\|b_{' + sym + r'}\|/\|r_{' + sym + r'}\|$',
                r'$0<z_{' + sym + r'}\leq 1$',
            ],
        )
        g.line(x + 108, 160, x + 108, 182, stroke=SLATE)

    g.line(143, 182, 857, 182, stroke=SLATE)
    g.line(500, 182, 500, 204, stroke=DEEP, arrow=True)

    # Geometric card: Left = 4-grade Pauli-truncated ladder; Right = Orthogonal norm-square bars
    g.items.append(f'<rect x="35" y="208" width="930" height="226" rx="6" fill="#FAFBFD" stroke="{HAIR}" stroke-width="1.1"/>')

    # Left subpanel: 4-grade ladder
    g.text(266, 234, t(r'四分级泡利截断阶梯（$T_F^4 b_\ell=0$）', r'Four-grade Pauli ladder ($T_F^4 b_\ell=0$)'),
           size=18, anchor='middle', weight='600', fill=INK)
    rungs = [
        (408, r'$(3,0)$', DEEP, False, t(r'价态核 $b_\ell$', r'Core $b_\ell$')),
        (372, r'$(3,1)$', SLATE, False, r'$T_F b_\ell$'),
        (336, r'$(3,2)$', SLATE, False, r'$T_F^2 b_\ell$'),
        (300, r'$(3,3)$', SLATE, False, r'$T_F^3 b_\ell$'),
        (264, r'$(3,4)=\varnothing$', VERMILION, True, r'$T_F^4 b_\ell=0$'),
    ]
    for ry, sector_lbl, col, is_empty, right_lbl in rungs:
        g.mathtext(158, ry + 6, sector_lbl, size=17, anchor='end', fill=col)
        if is_empty:
            g.path([(172, ry), (322, ry)], stroke=VERMILION, width=2.2, dash='6 5')
        else:
            g.line(172, ry, 322, ry, stroke=col, width=3.4 if ry == 408 else 2.6)
        g.text(336, ry + 6, right_lbl, size=17, anchor='start', fill=col)

    for y_low, y_high in [(408, 372), (372, 336), (336, 300)]:
        g.line(247, y_low - 4, 247, y_high + 5, stroke=GOLD, width=1.8, arrow=True)
    g.line(247, 300 - 4, 247, 264 + 6, stroke=VERMILION, width=1.6, dash='4 3', arrow=True)

    # Divider
    g.line(492, 224, 492, 418, stroke=HAIR, width=1.0)

    # Right subpanel: Orthogonal norm-square bar comparison
    g.text(726, 234, t('正交范数分解与 §13.2 算例', 'Norm shares & Sec. 13.2 benchmark'),
           size=18, anchor='middle', weight='600', fill=INK)

    # Bar 1: Full Yukawa branch (#=0): 4/9 valence + 5/9 cloud
    g.mathtext(516, 274, r'$\sharp_\ell=0:\ \|r_\ell\|^2=4+5=9\ \Rightarrow\ z_\ell=\frac{2}{3},\ \mathfrak{b}_\ell=\frac{4}{9}$',
               size=17, anchor='start', fill=INK)
    bx0, bw = 516, 414
    w_core = round(bw * 4 / 9)
    w_cloud = bw - w_core
    g.items.append(f'<rect x="{bx0}" y="288" width="{w_core}" height="28" rx="3" fill="{DEEP}"/>')
    g.items.append(f'<rect x="{bx0 + w_core}" y="288" width="{w_cloud}" height="28" rx="3" fill="#E3D4B4" stroke="{GOLD}" stroke-width="1.2"/>')
    g.mathtext(bx0 + w_core / 2, 308, r'$4/9$', size=17, anchor='middle', fill='white')
    g.text(bx0 + w_core + w_cloud / 2, 308, t('5/9（修饰云）', '5/9 (cloud)'), size=17, anchor='middle', fill=INK)

    # Bar 2: Grade-preserving reference leg (#=1): 100% valence core
    g.mathtext(516, 358, r'$\sharp_\ell=1:\ r_\ell=b_\ell\ \Rightarrow\ z_{\mathrm{ref}}=1,\ \mathfrak{b}_{\mathrm{ref}}=1$',
               size=17, anchor='start', fill=INK)
    g.items.append(f'<rect x="{bx0}" y="372" width="{bw}" height="28" rx="3" fill="{DEEP}"/>')
    g.text(bx0 + bw / 2, 392, t('1（价态核 (3,0)）', '1 (valence core (3,0))'), size=17, anchor='middle', fill='white')

    g.line(500, 434, 500, 458, stroke=DEEP, arrow=True)

    g.box(
        55, 462, 890, 88,
        t('无紫外截断底扇区 Born 重叠与四端乘积合账',
          'Cutoff-free valence-core Born overlaps and four-end product'),
        [
            r'$\mathfrak{b}_\ell=z_\ell^2=\|P_{3,0}u_\ell\|^2,\qquad z_{\sharp=1}=1,\qquad Z=z_{dL}z_{dR}z_{sL}z_{sR}\in(0,1]$',
        ],
    )

    g.line(500, 550, 500, 574, stroke=VERMILION, arrow=True)

    g.box(
        45, 578, 910, 114,
        t('三费米子四端库仑修饰与差模恒等式（定理 13.1）',
          'Four-end Born Coulomb dressing and modulus defect (Thm. 13.1)'),
        [
            r'$C_{\mathrm{full}}=ZC_{\mathrm{base}},\qquad |C_{\mathrm{full}}-C_{\mathrm{base}}|=(1-Z)|C_{\mathrm{base}}|$',
            r'$\lim_{a\downarrow 0}\mathcal{P}_a^{(3)}[\phi](\mathbf{x})=ZC_{\mathrm{base}}\int\frac{f_\phi(\mathbf{x}-\mathbf{y})}{4\pi|\mathbf{y}|}\,d^3y$',
        ],
        fill=WASH, edge=VERMILION, title_fill=VERMILION, lw=2.0,
    )
    g.save('main-06-born-dressing-v2')


def draw_main_07(language: str, records: list[dict]) -> None:
    t = lambda zh, en: zh if language == 'zh' else en
    g = make_plate(
        language,
        t('标准 Maxwell 光速锥、N=3 单位荷消去与三通道远场平衡',
          'Standard Maxwell cone, N=3 unit-charge cancellation, and three-channel far-field balance'),
        742,
        SOURCE_DF4,
        records,
    )

    g.box(
        32, 16, 936, 86,
        t('完整 289 场修饰电磁响应与独立源／探测器复合外腿',
          'Full 289-field dressed EM response and independent detector/source legs'),
        [r'$\mathrm{E}=-T^{\mathrm{color}}_2-\frac{1}{2}Y,\qquad |Q_e|=1,\qquad K(p)=D^2\mathcal{L}_{\mathrm{nat}}(0)(p)\in M_{289}(\mathbb{C})$'],
        edge=DEEP, title_fill=DEEP, lw=1.6,
    )

    g.line(290, 102, 256, 132, stroke=DEEP, arrow=True)
    g.line(710, 102, 744, 132, stroke=SLATE, arrow=True)

    g.box(
        32, 136, 448, 138,
        t('标准分支多项式判据与横波光速锥（§11.4）',
          'Standard branch gates & Maxwell cone (Sec. 11.4)'),
        [
            r'$D_{\mathrm{lead}}(e)\neq 0:\ \mathcal{R}_{\mathrm{stat}}=0 \Longleftrightarrow \forall\,\mathrm{reg.}\,\mathbf{n}\neq 0\ \mathrm{std.}$',
            r'$\mathcal{R}_{\mathrm{dyn}}=0 \Longrightarrow \varepsilon_{\mathrm{eff}}\omega_{\mathrm{phys}}^2-\mu_{\mathrm{eff}}^{-1}|\mathbf{k}_\varepsilon|^2=0$',
            r'$v_{\mathrm{phase}}^2=-\frac{c_{\mathrm{temp}}}{c_{\mathrm{sp}}}=c_{\mathrm{phys}}^2$',
        ],
    )

    g.items.append(f'<rect x="32" y="286" width="448" height="168" rx="6" fill="#FAFBFD" stroke="{HAIR}" stroke-width="1.1"/>')
    cx, cy = 158, 424
    g.line(66, cy, 250, cy, stroke=SLATE, width=1.2, arrow=True)
    g.line(cx, 440, cx, 304, stroke=SLATE, width=1.2, arrow=True)
    g.items.append(f'<polygon points="{cx},{cy} 96,334 220,334" fill="#EBF2F7" opacity="0.85"/>')
    g.items.append(f'<ellipse cx="{cx}" cy="334" rx="62" ry="11" fill="#DCE8F2" stroke="{DEEP}" stroke-width="1.5"/>')
    g.line(cx, cy, 96, 334, stroke=DEEP, width=2.1)
    g.line(cx, cy, 220, 334, stroke=DEEP, width=2.1)
    g.mathtext(170, 314, r'$\omega_{\mathrm{phys}}$', size=17, anchor='start', fill=DEEP)
    g.mathtext(246, 444, r'$|\mathbf{k}_\varepsilon|$', size=17, anchor='end', fill=INK)
    g.mathtext(92, 326, r'$c_{\mathrm{phys}}$', size=17, anchor='end', fill=DEEP)

    g.line(286, 300, 286, 440, stroke=HAIR, width=1.0)
    sx, sy, sr = 380, 366, 38
    g.items.append(f'<circle cx="{sx}" cy="{sy}" r="{sr}" fill="white" stroke="{DEEP}" stroke-width="1.5"/>')
    g.items.append(f'<ellipse cx="{sx}" cy="{sy}" rx="{sr}" ry="11" fill="none" stroke="{HAIR}" stroke-width="1.1"/>')
    g.line(sx, sy, sx + 29, sy - 25, stroke=VERMILION, width=2.0, arrow=True)
    g.mathtext(sx + 33, sy - 24, r'$\mathbf{n}_\star$', size=17, anchor='start', fill=VERMILION)
    g.text(sx, 434, t('非零余项给出实阻碍方向', 'Regular obstruction direction'), size=17, anchor='middle', fill=SLATE)

    g.line(256, 454, 256, 478, stroke=DEEP, arrow=True)
    g.box(
        32, 482, 448, 114,
        t('$N=3$ 极点包单 $4\\pi$ 库仑返回与荷消去（§12.4）',
          '$N=3$ pole Coulomb return & unit charge (Sec. 12.4)'),
        [
            r'$q_{e,\mathrm{Noether}}(0)^2=1^2=1,\qquad C_{\mathrm{EM}}^{\mathrm{gen}}=\frac{c_{\mathrm{temp}}}{4\pi}$',
            r'$\alpha_{\mathrm{pole}}=\frac{C_{\mathrm{EM}}^{\mathrm{gen}}}{h_{\mathrm{src}}c_{\mathrm{phys}}},\qquad \frac{1}{4\pi|\mathbf{x}-\mathbf{y}|}$',
        ],
    )

    g.box(
        520, 136, 448, 138,
        t('完整静态电流三通道分解（§14.1，L29）',
          'Three-channel static current circuit (Sec. 14.1)'),
        [
            r'$\mathcal{R}_{\mathrm{corr}}(\kappa,\sigma,\mathbf{n})=\mathcal{R}_{\mathrm{nat}}+\mathcal{R}_{\mathrm{fb}}+\mathcal{R}_{\mathrm{null}}$',
            r'$\kappa^2|\mathcal{R}_{\mathrm{nat}}(\kappa,\mathbf{n})|\leq P_{\mathrm{nat}}\quad (\forall\,|\mathbf{n}|=1)$',
            t('保留原生 Green、量子反馈与九约束零模', 'Native Green, quantum feedback, and 9 null modes'),
        ],
    )

    g.items.append(f'<rect x="520" y="286" width="448" height="168" rx="6" fill="#FAFBFD" stroke="{HAIR}" stroke-width="1.1"/>')
    ox, oy = 592, 418
    g.line(ox, oy, 926, oy, stroke=SLATE, width=1.3, arrow=True)
    g.line(ox, oy, ox, 306, stroke=SLATE, width=1.3, arrow=True)
    g.mathtext(944, 423, r'$\kappa$', size=17, anchor='end', fill=INK)
    g.mathtext(582, 316, r'$\sigma$', size=17, anchor='end', fill=INK)
    px_pt, py_pt = 816, 330
    g.line(px_pt, py_pt, ox + 12, oy - 6, stroke=MUTE, width=1.4, dash='4 5')
    g.items.append(f'<circle cx="{px_pt}" cy="{py_pt}" r="4.5" fill="{DEEP}"/>')
    g.line(px_pt, py_pt + 5, px_pt, oy - 3, stroke=DEEP, width=2.4, arrow=True)
    g.mathtext(px_pt + 12, 376, r'$1.\ \sigma\downarrow 0$', size=17, anchor='start', fill=DEEP)
    g.items.append(f'<circle cx="{px_pt}" cy="{oy}" r="4.5" fill="{DEEP}"/>')
    g.line(px_pt - 6, oy, ox + 8, oy, stroke=VERMILION, width=2.6, arrow=True)
    g.items.append(f'<circle cx="{ox}" cy="{oy}" r="5.5" fill="{VERMILION}"/>')
    g.mathtext(705, 442, r'$2.\ \kappa\downarrow 0\ \ (O(\kappa^{-2})\ \mathrm{balance})$', size=17, anchor='middle', fill=VERMILION)
    g.mathtext(ox + 10, 326, r'$C_{\mathrm{ord}}=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}$', size=17, anchor='start', fill=VERMILION)

    g.line(744, 454, 744, 478, stroke=SLATE, arrow=True)
    g.box(
        520, 482, 448, 114,
        t('有限分支两步有序远场极限（先 $\\sigma\\downarrow 0$，后 $\\kappa\\downarrow 0$）',
          'Two-step far-field limit (first $\\sigma\\downarrow 0$, then $\\kappa\\downarrow 0$)'),
        [
            r'$\sigma\downarrow 0:\ \mathcal{R}_{\mathrm{fb}}+\mathcal{R}_{\mathrm{null}}\longrightarrow \mathcal{R}^{(0)}_{\mathrm{fb+null}}(\kappa,\mathbf{n})$',
            r'$\kappa\downarrow 0:\ -\kappa^2\mathcal{R}^{(0)}_{\mathrm{fb+null}}\longrightarrow C_{\mathrm{fb+null}}(e,\mathbf{n})$',
        ],
    )

    g.line(256, 596, 256, 614, stroke=VERMILION)
    g.line(744, 596, 744, 614, stroke=VERMILION)
    g.line(256, 614, 744, 614, stroke=VERMILION)
    g.line(500, 614, 500, 632, stroke=VERMILION, arrow=True)

    g.box(
        45, 636, 910, 90,
        t('零旋钮远场闭合：光速锥与 $O(\\kappa^{-2})$ 反馈—零模系数守恒',
          'Zero-knob far-field closure: Maxwell cone and $O(\\kappa^{-2})$ balance'),
        [
            r'$v_{\mathrm{phase}}^2=c_{\mathrm{phys}}^2,\qquad C_{\mathrm{ord}}(e,\mathbf{n})=C_{\mathrm{nat}}+C_{\mathrm{fb+null}}(e,\mathbf{n})$',
        ],
        fill=WASH, edge=VERMILION, title_fill=VERMILION, lw=2.0,
    )

    g.save('main-07-maxwell-farfield-v2')


def draw_fig2_v2(language: str, data: dict, records: list[dict]) -> None:
    t = lambda zh, en: zh if language == 'zh' else en
    native = data['native_P286_scalar_gauge_block']
    entries = [(float(Fraction(f['root'])), f['root'], f['multiplicity']) for f in native['linear_factors']]
    entries += [(r['approximation'], f"{r['approximation']:.6f}", 1) for r in native['positive_root_intervals']]
    entries.sort()
    assert sum(e[2] for e in entries) == 12 and native['rank'] == 9

    row = 62
    h = 166 + row * (len(entries) - 1)
    g = make_plate(
        language,
        t('式 (2.1) 规范块嵌入的标量—规范裸二次谱',
          'Bare scalar–gauge quadratic spectrum of the embedding (2.1)'),
        h,
        SOURCE_302,
        records,
    )

    left, right, top = 200, 800, 60
    bottom = top + row * (len(entries) - 1)
    maximum = 3.2
    px = lambda x: left + x / maximum * (right - left)

    g.text(170, 28, t('本征值', 'Eigenvalue'), size=18, anchor='end', fill=SLATE)
    g.text(900, 28, t('重数', 'Multiplicity'), size=18, anchor='middle', fill=SLATE)

    for tick in range(math.floor(maximum) + 1):
        tx = px(tick)
        g.path([(tx, top - 18), (tx, bottom + 18)], stroke=HAIR, width=0.9, dash='3 6')
        g.text(tx, bottom + 46, str(tick), size=18, anchor='middle', fill=SLATE)

    for i, (val, label, count) in enumerate(entries):
        y = top + i * row
        col = VERMILION if val == 0 else DEEP
        g.text(170, y + 7, label, size=20, anchor='end', fill=col)
        if val > 0:
            g.line(left, y, px(val), y, stroke=col, width=3.5)
        g.items.append(
            f'<circle cx="{px(val):.2f}" cy="{y:.2f}" r="6.5" fill="white" stroke="{col}" stroke-width="2.5"/>'
        )
        g.text(900, y + 7, str(count), size=20, anchor='middle', fill=col)

    g.line(left, top - 18, left, bottom + 18, stroke=SLATE, width=1.2)
    g.text(
        right + 110, bottom + 88,
        t('$R=B^{-1}K$ 的本征值（三次根满足 $6x^3-26x^2+27x-8=0$）',
          'Eigenvalues of $R=B^{-1}K$ (cubic roots of $6x^3-26x^2+27x-8=0$)'),
        size=18, anchor='end', fill=INK,
    )

    g.save('fig2-bare-scalar-gauge-spectrum-v2')


def draw_all(language: str, data: dict) -> list[dict]:
    records: list[dict] = []
    draw_main_04(language, records)
    draw_main_05(language, records)
    draw_main_06(language, records)
    draw_main_07(language, records)
    draw_fig2_v2(language, data, records)
    return records


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--language', choices=['zh', 'en', 'both'], default='both')
    args = ap.parse_args()
    data = json.loads((BASE / 'data/exact-readout.json').read_text())
    langs = ['zh', 'en'] if args.language == 'both' else [args.language]
    all_records: list[dict] = []
    for lang in langs:
        all_records.extend(draw_all(lang, data))
    (BASE / 'v2-figure-manifest.json').write_text(
        json.dumps(all_records, indent=2, ensure_ascii=False) + '\n'
    )
    print(json.dumps({'generated_v2_plates': len(all_records), 'languages': langs}))


if __name__ == '__main__':
    main()
