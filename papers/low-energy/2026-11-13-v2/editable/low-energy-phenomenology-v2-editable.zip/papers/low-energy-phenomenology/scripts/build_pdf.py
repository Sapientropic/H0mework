#!/usr/bin/env python3
"""Build the reading editions (main manuscript + proof supplement) through the shared typography pipeline."""
import argparse
from functools import partial
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'shared/scripts'))
import build_pdf as common

_latin_title = common.latin_title
_prepare = common.prepare
_compile_tex = common.compile_tex

SUPP_FIRST_SECTION = r'^# +S1(?:[\s.．　]|$)[^\n]*$'


def subtitle(line):
    # A single-language title is followed by a section, not a second title.
    if line.strip() in {'# Abstract', '## Abstract'}:
        return None
    return _latin_title(line)


def prepare_multipage_refs(source, toc, profile):
    title, sub, body = _prepare(source, toc, profile)
    # Insert Table of Contents for Proof Supplement (whose first section opens with '# S1').
    if toc and '\\tableofcontents' not in body and re.search('(?m)' + SUPP_FIRST_SECTION, body):
        body = re.sub(
            '(?m)' + SUPP_FIRST_SECTION,
            lambda m: '```{=latex}\n\\clearpage\n{\\small\\tableofcontents}\n\\clearpage\n```\n\n' + m[0],
            body,
            count=1,
        )
    # Allow multi-page bibliographies to paginate cleanly across pages
    # instead of enclosing >1 page of entries inside an unbreakable minipage.
    ref_open = (
        "```{=latex}\n\\noindent\\begin{minipage}{\\linewidth}\n```\n\n"
    )
    idx = body.rfind(ref_open)
    if idx != -1 and body.endswith("```{=latex}\n\\endgroup\\end{minipage}\\par\n```\n"):
        body = (
            body[:idx]
            + "```{=latex}\n\\Needspace{12\\baselineskip}\n```\n\n"
            + body[idx + len(ref_open):-len("```{=latex}\n\\endgroup\\end{minipage}\\par\n```\n")]
            + "```{=latex}\n\\endgroup\\par\n```\n"
        )
    return title, sub, body


def _smart_code_breaks(match: re.Match) -> str:
    inner = match.group(1)
    # Keep character-level \seqsplit for long hexadecimal git commit hashes.
    if re.fullmatch(r'[0-9a-f]{32,64}', inner):
        return match.group(0)
    # Break paths and Lean identifiers cleanly at '/', '-', ',', '\{', '\}', '.', and CamelCase boundaries.
    s = inner
    s = s.replace('/', '/\\allowbreak{}')
    s = s.replace('-', '-\\allowbreak{}')
    s = s.replace(',', ',\\allowbreak{}')
    s = s.replace('\\{', '\\allowbreak\\{')
    s = s.replace('\\}', '\\}\\allowbreak{}')
    s = re.sub(r'\.(?!lean\b)', r'.\\allowbreak{}', s)
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1\\allowbreak{}\2', s)
    s = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1\\allowbreak{}\2', s)
    return '{\\sloppy ' + s + '}'


def compile_tex_with_title_math(tex):
    # 1. Prevent orphaned section and subsection headings at page bottoms.
    params_file = tex.parent / 'paper-params.tex'
    if params_file.is_file():
        ptxt = params_file.read_text()
        hook = (
            '\\AtBeginDocument{\\pretocmd{\\section}{\\Needspace{10\\baselineskip}}{}{}'
            '\\pretocmd{\\subsection}{\\Needspace{8\\baselineskip}}{}{}}\n'
        )
        if '\\pretocmd{\\subsection}' not in ptxt:
            params_file.write_text(ptxt + hook)

    # 2. Restore math mode '$1/(4\pi r)$' in \title/\papersubtitle and clean Unicode in pdftitle.
    escaped_pat = re.compile(r'\\\$1/\(4\\textbackslash(?:\{\}|\s*)pi r\)\\\$')
    sub_file = tex.parent / 'subtitle.tex'
    if sub_file.is_file():
        sub_file.write_text(escaped_pat.sub(r'$1/(4\\pi r)$', sub_file.read_text()))

    ts = escaped_pat.sub(r'$1/(4\\pi r)$', tex.read_text())
    ts = re.sub(r'^  pdftitle=.*$', lambda m: m[0].replace(r'$1/(4\pi r)$', '1/(4πr)'), ts, flags=re.M)

    # 3. Replace mid-syllable \seqsplit breaks on file/Lean paths with semantic CamelCase/path breaks.
    ts = re.sub(r'\\seqsplit\{((?:\\.|[^{}])+)\}', _smart_code_breaks, ts)

    # 4. Prevent orphaned Theorem / Proposition / Lemma / Corollary / Remark headers at page bottoms.
    thm_pat = re.compile(
        r'(?m)^(\\textbf\{(?:定理|命题|引理|推论|注记|Theorem|Proposition|Lemma|Corollary|Remark)\s+[0-9]+\.[0-9]+)'
    )
    lines = ts.split('\n')
    out_lines = []
    for line in lines:
        if thm_pat.match(line):
            prev_nonempty = next((x for x in reversed(out_lines) if x.strip()), '')
            if '\\Needspace' not in prev_nonempty:
                out_lines.append('\\Needspace{7\\baselineskip}')
        out_lines.append(line)
    tex.write_text('\n'.join(out_lines))
    return _compile_tex(tex)


common.latin_title = subtitle
common.prepare = prepare_multipage_refs
common.compile_tex = compile_tex_with_title_math
common.fit_wide_displays = partial(common.fit_wide_displays, tolerance=0.0)

PAPER = 'papers/low-energy-phenomenology/'
DEFAULT_V2_OUT = ROOT / PAPER / 'build/reading-review-v2'
common.RUNHEADS[PAPER + 'manuscript.md'] = (
    'low-energy-phenomenology', 'CourtyCourt · Case 1', '零旋钮统一场的低能电磁涌现')
common.RUNHEADS[PAPER + 'manuscript-en.md'] = (
    'low-energy-phenomenology', 'CourtyCourt · Case 1', 'Low-Energy Electromagnetic Emergence')
common.RUNHEADS[PAPER + 'supplement.md'] = (
    'low-energy-phenomenology-supplement', 'CourtyCourt · Case 1 · 补充材料', '传播目录、空间演化接口与多体长程证明')
common.RUNHEADS[PAPER + 'supplement-en.md'] = (
    'low-energy-phenomenology-supplement', 'CourtyCourt · Case 1 · Supplement', 'Catalogs, Evolution Interfaces, and Long-Range Proofs')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--language', choices=['zh', 'en', 'both'], default='both')
    parser.add_argument('--target', choices=['manuscript', 'supplement', 'all'], default='all')
    parser.add_argument('--no-toc', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=DEFAULT_V2_OUT,
                        help='Output directory (defaults to build/reading-review-v2 to protect frozen v1 PDFs)')
    args = parser.parse_args()
    targets = ['manuscript', 'supplement'] if args.target == 'all' else [args.target]
    langs = ['zh', 'en'] if args.language == 'both' else [args.language]
    for tgt in targets:
        for language in langs:
            name = f'{tgt}-en.md' if language == 'en' else f'{tgt}.md'
            print(json.dumps(common.build(PAPER + name, not args.no_toc, args.output_dir), ensure_ascii=False))
