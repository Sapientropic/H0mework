# Low-Energy Electromagnetic Emergence from a Zero-Knob Unified Source: Coupled Propagation, Unit Electron Charge, the Maxwell Cone, and 1/(4πr) Coulomb Return

This package contains both manuscripts, bibliography, editable vector figures and the public proof binding.
The registered source map and the original and new acceptance receipts are linked in the manuscripts.

From this extracted directory, verify the files and rebuild the PDFs using Python 3, Pandoc,
XeLaTeX, and the Noto Serif/Sans CJK SC fonts.

```sh
python3 verify-inputs.py
python3 papers/low-energy-phenomenology/scripts/build_pdf.py --language both --target all
```

The vector figures are supplied in SVG and PDF. The figure generation scripts are in `papers/low-energy-phenomenology/figures/`.
