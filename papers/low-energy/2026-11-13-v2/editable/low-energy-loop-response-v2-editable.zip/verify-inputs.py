#!/usr/bin/env python3
"""Verify an extracted editable package before building; no Git is required."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys

def verify(root):
    manifest = json.loads((root / "editable-inputs.json").read_bytes())
    if manifest.get("schema") != "publish/society-economic-editable-inputs@1":
        raise ValueError("Unknown editable input manifest")
    expected = {"editable-inputs.json"}
    for entry in manifest["files"]:
        name = entry["path"]
        rel = PurePosixPath(name)
        if (not name or str(rel) != name or rel.is_absolute()
                or ".." in rel.parts or "\\" in name or name in expected):
            raise ValueError("Unsafe or repeated manifest member")
        expected.add(name)
        path = root.joinpath(*rel.parts)
        if any(p.is_symlink() for p in (path, *path.parents) if p != root.parent):
            raise ValueError("Symlink in extracted input: " + name)
        raw = path.read_bytes()
        if len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise ValueError("Input hash/size mismatch: " + name)
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    if actual != expected:
        raise ValueError("Missing or unregistered files in extracted package")
    return {"status": "passed", "verified_files": len(expected), "git_required": False}

if __name__ == "__main__":
    try:
        if len(sys.argv) > 2:
            raise ValueError("Usage: python3 verify-inputs.py [extracted-root]")
        root = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent
        print(json.dumps(verify(root), sort_keys=True))
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
