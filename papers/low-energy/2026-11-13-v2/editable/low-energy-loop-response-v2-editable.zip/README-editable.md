# Cutoff-Free Noncommutative Polarization Curvature, Second-Variation Action Identification, and the (2,1) Inertia Law of Whole-Ball Response

This package contains both manuscripts, bibliography, editable vector figures and the public proof binding.
The registered source map and the original and new acceptance receipts are linked in the manuscripts.

From this extracted directory, verify the files and rebuild the PDFs using Python 3, Pandoc,
XeLaTeX, and the Noto Serif/Sans CJK SC fonts.

```sh
python3 verify-inputs.py
python3 papers/low-energy-loop-response/scripts/build_pdf.py --lang both
```

The vector figures are supplied in SVG and PDF. The figure generation scripts are in `papers/low-energy-loop-response/figures/`.
