# 无截断非交换极化曲率、母作用二阶变分认回与整球响应张量的 (2,1) 惯性律

**Cutoff-Free Noncommutative Polarization Curvature, Second-Variation Action Identification, and the (2,1) Inertia Law of Whole-Ball Response**

**COURTYCOURT · THE THEORY TAKES THE STAND · Case 2（第二版）**

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**形式验证、严格区间与双轨核验声明。** 本文覆盖 Q1–Q7 完整证据链（第一版 Q1–Q6 预印本见 [[3]](#ref-3)）。其中非交换有序闭迹简化（Q1）、二次量子化 Fock 整词读回（Q2）、费米子 Schur 补与五维轻核代数（Q3）、全四复动量母作用二阶 Fréchet 变分认回与原点核重构（Q5）、实场与非线性历史因果 Noether 极化（Q6）以及传播极小多项式商逆、有限 Sylvester 矩阵坍缩与精确 Yukawa 截断消除（Q7）均经 Lean 4（`v4.33.0`）内核严格类型检查通过 [[30]](#ref-30)，依赖闭包仅含标准三公理（`propext`、`Classical.choice`、`Quot.sound`），零 `sorry` 占位且零额外物理公设；双球空间波包五通道极化曲率张量的 $(2,1,0)$ 惯性律（Q4）由精确有理源矩阵、球面全角解析 Beta 积分、11,760 个复围道系数有理矩形包络（256/512-bit 向外二进有理舍入）与四阶位置矩解析余项共同闭合，并经多实现隔离审计重放核验 [[3]](#ref-3), [[25]](#ref-25), [[26]](#ref-26)。

## 摘要

在耦合引力、非阿贝尔规范场与手征费米子的统一场论中，能否在不引入人为紫外动量截断（cutoff-free）、不手加局部抵消项（zero counterterms）且不拨动任何自由拟合参数的前提下，精确归约非交换一圈有序闭迹并求值固定五通道空间波包极化曲率张量，锁定其全方向实对称惯性指数，并将低能有效玻色算子逐项认回原始母作用的二阶 Fréchet 变分？本文在固定 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 统一母作用及其唯一零参数经典解 [[1]](#ref-1) 上给出肯定证明。首先，在含独立线性变分对偶 $\chi$ 的 252 复维手征外幂物质载体上，利用 $P_6$ 手征分级与单向楔积幂零性（$N_a B N_b=0$），证明任意有限长合法有序规范传播词的闭迹严格等于其块对角自由分级词闭迹 $\operatorname{tr}W=\operatorname{tr}W_0$，单次单向标量插入闭迹及同向双插入开放算子恒为零（Q1）；在二次量子化 Fock 空间 $\mathcal F_-(\mathcal M)$ 上确立先合成整词再作单粒子压缩的实时读回规则，严格分离单位矩阵的全载体裸迹（$252$）、单位制备态期望（$1$）、显式开放标量返回（$-1$）与中途插入秩一投影 $P_w$ 造成的伪零抹除（$0$）（Q2）。其次，在共同块可逆域内将 289 维实场线性化系统经辅助场、Ward 与源对称无损消元至 103 维，并对 48 个实物质方向执行一次精确 Schur 补消元，得到有理玻色算子 $S_{55}=K_{bb}-K_{bm}M^{-1}K_{mb}$、全 289 行场—外源逐符号回写 $H_{289}F=J_{\mathrm{src}}S_{55}$ 以及同时承载线性与二次动量时间尺度的五维原点轻核（Q3）。针对 $dx^1S_{01}$ 外源、同向变分读出算符、零输出动量、双 Laplace 参数 $z=w=6c(1-i)$ 与等半径 $B$ 入射／观察双球空间波包窗口，合成两条量子源腿、变分接触项与两条玻色传播腿构成的完整五通道极化响应；在精确分离双球交集尖窗非解析一次项 $|d|$ 并保留球内体积分、两类球面边界通量与完整复交叉 Gram 后，经 11,760 项复系数有理矩形包络与连续缩放路径上的 Gershgorin 圆盘无过零分离，严格证明未中心化（raw）与连通（connected）二次曲率张量的 Sylvester 惯性指数同为 $(\text{负},\text{正},\text{零})=(2,1,0)$（其中 raw 坐标对角项的区间依次位于 $[-1.355200,-1.309214]$、$[2.140271,2.186257]$、$[-1.742600,-1.696614]\times 10^{-20}$，全部非对角元绝对值 $<2.30\times 10^{-22}$；均值项第二轴区间跨零并独立保留）（Q4）。

在全场变分认回与因果算子闭合侧，本文在全部四复动量 $p\in\mathbb C^4$ 上形式化证出：母作用密度关于全部 1,445 个实一阶射流槽的二阶 Fréchet 导数 Fourier–Euler 矩阵（1,650 项二次表合并为 3,071 项 Jacobi 字典）逐项严格等于低能传播矩阵 $H_{289}(p)$；由五列原点核 $N$ 与 $98=45+21+32$ 维直和坐标补空间构造全四复动量有理 Schur 核 $E(p)$、显式局部 Neumann 半径 $\rho$ 与整块三阶预解余项界，从清分母 Green 解 $\widetilde X=\widetilde G(P)J$ 逐项恢复接触项、活跃块及全部九个零模方向（Q5）。进而，对配置空间有序五因子核引入固定正则动量中央接触修正与四频点合账，在 $\operatorname{Re}\lambda>0$ 上建立实 289 场正半轴 Bochner 响应算子 $\mathcal J_\infty$；在单位创建态减同源背景差泛函 $\ell_d$ 下，沿 $C^1$ 实场非线性历史在共同正窗口 $0\le T<\tau(d,k,P,a)$ 内导出零幅度真导数生成的完整 $289\times 289$ 极化张量 $\Pi_{d,T}(P,\lambda)$、母 Euler 响应铅笔 $\int_0^T e^{-\lambda t}\partial_r E_d|_0\,dt=[W_T(P_0,\lambda)K_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$ 及完整电压 Cauchy 场更新（Q6）。最终，利用交换左右联合生成元的代数整性，先于任何读出与外力抽出 Sylvester 演化生成元 $\mathcal T_q$ 的有限阶首一极小多项式 $P_q(X)$，在商代数 $\mathbb C[X]/(P_q(X))$ 内无需外部可逆证书导出有限双逆权重向量 $w_q(\lambda)=M_q(\lambda)^{-1}e_0$，证明在 $\operatorname{Re}\lambda>0$ 上全部 $289^2$ 个静态钟 Noether 极化分量无截断坍缩为有限源词矩二次型 $\Pi^{\mathrm{st}}_d(k,\lambda)_{ij}=w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}w_q(\lambda)$，创建单位态 Hilbert 范数自动消去修饰相位接回制备光子振幅，且全 $Y$ 静态极化、物理三费米子（$N=3$）五腿因果窗与六阶红外极限对离散 Yukawa 截断标号严格不变，全体标号共享四阶红外解析延拓及六阶零极限（Q7）。

**关键词：** 无截断真空极化；独立 Dirac 对偶；有序闭迹简化；二次量子化整词评价；费米子 Schur 补；双球尖窗通量；Sylvester 惯性指数；极小多项式商预解逆。

## Abstract

In a unified theory coupling first-order gravity, non-Abelian gauge fields, and chiral fermions, can one reduce the ordered noncommutative one-loop traces and evaluate the fixed five-channel spatial wave-packet polarization curvature tensor without an artificial ultraviolet momentum cutoff, without hand-added local counterterms, and with zero tunable parameters, lock the exact eigenvalue inertia of the full real symmetric tensor, and identify the low-energy bosonic propagation matrix entry by entry with the second Fréchet variation of the underlying mother action? Working directly from the parameter-free $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ mother action and its unique six-sector classical solution [[1]](#ref-1), we establish an affirmative proof across seven interconnected results (Q1–Q7). First, on the 252-complex-dimensional chiral exterior-power carrier equipped with an independent linear variational dual $\chi$, the $P_6$ grading and one-way wedge nilpotency ($N_a B N_b=0$) reduce the closed trace of every finite admissible ordered gauge-propagation word to that of its block-diagonal part, $\operatorname{tr}W=\operatorname{tr}W_0$, while annihilating every single-scalar closed trace and co-directional double-scalar open chain (Q1); on the antisymmetric Fock space $\mathcal F_-(\mathcal M)$, multiplying the complete $d\Gamma$ word prior to one-particle compression strictly separates the full-carrier bare trace ($252$), the unit prepared-state expectation ($1$), the explicit open scalar return ($-1$), and the spurious zero ($0$) induced by inserting an intermediate rank-one projection $P_w$ (Q2). Second, lossless auxiliary, Ward, and symmetry reductions map the 289-real-field linearized system to 103 fields, where a single exact Schur complement over 48 real matter coordinates constructs the rational bosonic operator $S_{55}=K_{bb}-K_{bm}M^{-1}K_{mb}$, the full 289-row symbolic readback $H_{289}F=J_{\mathrm{src}}S_{55}$, and the five-dimensional origin light kernel governing both linear and quadratic momentum time scales (Q3). Under a $dx^1S_{01}$ external gauge probe, co-directional variational readout, zero output momentum, double Laplace parameters $z=w=6c(1-i)$, and equal-radius $B$ incoming/observing ball windows, we assemble all five polarization channels (two quantum source legs, readout contact, and two bosonic propagation legs); isolating the sharp-lens $|d|$ cusp while retaining the bulk integral, both spherical boundary fluxes, and the full complex cross-Gram across 11,760 outward-rounded rational contour rectangles, a continuous-path Gershgorin homotopy proves that both the uncentered (raw) and centered (connected) curvature tensors have exact Sylvester inertia $(\mathrm{neg},\mathrm{pos},\mathrm{zero})=(2,1,0)$, with raw coordinate-diagonal intervals in $[-1.355200,-1.309214]$, $[2.140271,2.186257]$, $[-1.742600,-1.696614]\times 10^{-20}$ and off-diagonal magnitudes below $2.30\times 10^{-22}$, whereas the mean sector's second-axis interval straddles zero and is recorded separately (Q4).

On the variational-return and causal-operator side, we prove formally across all complex four-momenta $p\in\mathbb C^4$ that the Fourier–Euler matrix of the second Fréchet derivative of the mother action density over all 1,445 real first-jet slots (1,650 quadratic terms merged into a 3,071-entry Jacobi dictionary) equals $H_{289}(p)$ entry by entry, and construct from five origin columns $N$ and a $98=45+21+32$ coordinate complement the exact four-momentum Schur kernel $E(p)$, explicit Neumann radius $\rho$, cubic resolvent bound, and denominator-cleared whole-field recovery retaining contact and all nine null directions (Q5). Incorporating the fixed-canonical-momentum central contact shift and four-frequency Fourier assembly into the ordered five-factor configuration kernel yields a bounded Bochner half-line operator $\mathcal J_\infty$ on $\operatorname{Re}\lambda>0$, while the normalized creation-minus-background functional $\ell_d$ acting along nonlinear $C^1$ field histories on a positive window $0\le T<\tau(d,k,P,a)$ generates the full $289\times 289$ causal polarization tensor $\Pi_{d,T}(P,\lambda)$, the exact mother-Euler amplitude-derivative pencil $[W_T(P_0,\lambda)K_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$, and the full voltage Cauchy field update (Q6). Finally, integrality of the commuting left and right joint generators extracts—prior to any readout or external force—the finite-degree monic minimal polynomial $P_q(X)$ of the Sylvester evolution generator $\mathcal T_q$, producing in the quotient algebra $\mathbb C[X]/(P_q(X))$ without external invertibility certificates a finite weight vector $w_q(\lambda)=M_q(\lambda)^{-1}e_0$ that collapses all $289^2$ entries of the static-clock Noether polarization on $\operatorname{Re}\lambda>0$ into the closed finite matrix quadratic form $\Pi^{\mathrm{st}}_d(k,\lambda)_{ij}=w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}w_q(\lambda)$, cancels the dressing phase via the created unit-state Hilbert norm to feed the prepared photon amplitude directly, and proves exact invariance of the full-$Y$ static polarization, physical three-fermion ($N=3$) five-leg window, across all discrete Yukawa cutoff indices, with a shared fourth-order analytic extension and a zero sixth-order infrared limit (Q7).

**Keywords:** cutoff-free vacuum polarization; independent Dirac dual; ordered closed-trace reduction; whole-word Fock evaluation; fermionic Schur complement; sharp two-ball boundary flux; Sylvester inertia; minimal-polynomial quotient resolvent.

## 1　问题定位、核心定理与跨学科验证入口

### 1.1　三座经典暗礁与“252 对 1 对 −1”的当庭对质

在传统量子场论与统一场有效作用计算中，一旦试图严格求值引力—规范—手征物质耦合体系的一圈真空极化与场反作用，推导往往立刻撞上三座暗礁。第一座暗礁是**紫外发散与减除自由度**：从 Schwinger 的固有时积分表示 [[4]](#ref-4) 到欧氏热核与谱作用量渐近展开 $\operatorname{Tr}\chi(D/\Lambda)$ [[8]](#ref-8)，动量空间无界圈积分需要外加紫外截断尺度 $\Lambda$ 或维数正规化；即便转入坐标空间采用 Epstein–Glaser 因果分布劈裂 [[5]](#ref-5)，非负奇异阶 $\omega\ge 0$ 在重合点仍留下 $\omega$ 次局部多项式待定抵消项。第二座暗礁是**泛函裸迹与实时制备态期望的混同**：背景场有效作用中的一圈 $\operatorname{Tr}\log$ [[7]](#ref-7), [[16]](#ref-16) 评价全载体的算符迹（对应渐近真空跃迁），而物理测量中的极化电流是在选定初始制备态下沿闭合时间路径（in-in）演化的实时双侧期望 [[11]](#ref-11), [[12]](#ref-12)，且当洛伦兹作用量保留独立线性对偶 $\chi$ 与单向手征楔积 $Y_R$ 时，算符不再自伴、矩阵乘法顺序与投影时机直接改变读数。第三座暗礁是**重场消元与有限空间波包窗口的账目遗失**：树级或一圈协变导数展开（CDE）[[14]](#ref-14), [[15]](#ref-15), [[16]](#ref-16) 将重自由度截断为局部渐近级数，不再逐行回写原始多场方程；而在空间有限波包或尖球窗口下求动量曲率时，窗口交集的非解析边界损失与球面通量极易被光滑动量微扰论遗漏 [[22]](#ref-22)。

这三重区分绝非形式修辞，在本文的 252 复维母物质载体 $\mathcal M$ 上，单凭单位算符 $I$ 的首轮对质便已一目了然：

\[
 \operatorname{tr}_{\mathcal M}I=252,
 \qquad \langle w,Iw\rangle=1,\qquad \|w\|=1. \tag{1.1}
\]

试图用第二个数字去“修正”第一个数字，或者把第一个数字当成第二个数字的高能近似，都是在偷换评价泛函：前者计算全载体的未投影裸矩阵迹，后者读取固定占据制备态 $w$ 对完整算符词的期望。一旦算符词由母作用动态生成，每一步操作顺序都受到严格约束：Dirac 传播逆从哪一侧相乘，独立对偶 $\chi$ 如何随时间右乘演化，单向标量顶点是否配有返回读出，以及单粒子制备态是在整串二次量子化乘积完成之后施加、还是被中途塞进两个因子之间。第 3 节将证明，同向单向标量插入的闭迹恒等于 $0$；然而第 4 节对同一物理开放输出施加显式返回算符却读出精确的 $-1$，倘若在乘积中途擅自插入秩一准备投影 $P_w=|w\rangle\langle w|$，该读数又立刻归零。开放跃迁客观发生了，只是错误的局部读出主动遮蔽了它。

同样的反转重现于三维空间波包极化响应。若只看零探针量子源腿（省去玻色场传播与窗口移动），未中心化（raw）外动量 Hessian 在全部三个空间方向上严格为负（约 $-0.014035$，§6.4）；但当同一零参数母作用内生生成的两条玻色场传播腿、变分接触项、双球尖窗边界通量以及球面全角积分全部归位后，完整的二次曲率张量却浮现出一个严格为正的特征方向。翻案不需要从理论外部传唤任何新参数，只需要把同一份母作用方程一字不漏地读完。

### 1.2　核心曲率定理与正反控制总览

全文沿用第 2 节由固定母源唯一锁定的源坐标与背景常数。记

\[
 c=\frac{6\sqrt{15}}{25},\quad
 \epsilon_B=\frac{5234375}{294988800512},\quad
 B=\sqrt2\epsilon_B,\quad z=w=6c(1-i). \tag{1.2}
\]

**结构出处说明（为何上述常数不是人为调参）。** 整部统一场论的可调物理参数严格为零 [[1]](#ref-1)。式 (1.2) 中的特征速率常数 $c=N\sqrt2$ 以及第 2 节的时间流逝尺度 $N=3\sqrt{30}/25$、规范背景振幅 $a=3\sqrt2/5$、本构耦合 $\sigma=1/2$、共转进动频率 $\omega_0=3N\sqrt2/5$、252 维外幂载体与占据态 $w$，均由物理旗舰篇 [[1]](#ref-1)（Stage 1–10 闭合，定义 2.1、定理 4.2–4.4、§6.1 与定理 9.3 零未登记物理权威封印）在单一无参母源上唯一解出，不含任何经验拟合自由度。本文显式指定的是**观测探针协议**：外加规范探测方向 $dx^1S_{01}$、零输出动量 $p_{\mathrm{out}}=0$、单位位置球滤波制备态、双 Laplace 复频率因子 $6(1-i)$（保证实部严格大于受扰传播核指数增长界，§7.3）以及等半径 $B=\sqrt2\epsilon_B$ 的入射／观察双球动量窗，其中 $\epsilon_B<\rho_*=1/8192$ 落在同一源生六次色散因子各分支根的共同解析认证圆盘内（§9.4 与附录 C.1）。因此，下表中的有理区间与式 (1.4) 的惯性指数，是零参数母理论在该固定探针协议下的纯演绎输出。

具体而言，令外加规范微扰为 $A_\varepsilon=A_0+\varepsilon\cos(d\cdot x)\,dx^1S_{01}$，变分读出算符取同一规范方向，观察输出动量取 $p_{\mathrm{out}}=0$。记 $\mathcal R_\alpha(d)$ 为第 7 节完整五通道极化响应的实读数，其中扇区下标 $\alpha=\mathrm{raw},\mathrm{mean},\mathrm{conn}$ 分别对应在全空间制备态秩一投影 $P=|\psi\rangle\langle\psi|$ 上取 $I$、$P$ 与 $I-P$。

<a id="def-1-1"></a>

**定义 1.1（双球尖窗响应曲率张量）。** 对任意实单位方向 $n\in S^2$，由同一母配对构造的正负外动量对称支路满足渐近展开

\[
 \mathcal R_\alpha(sn)=\mathcal R_\alpha(0)
 +a_\alpha(n)|s|+s^2n^T\mathsf K_\alpha n+o(s^2). \tag{1.3}
\]

其中 $a_\alpha(n)$ 是由双球交集球面边值唯一决定的偶方向函数（记录尖球窗裁切球冠产生的一次损失 [[22]](#ref-22)），$\mathsf K_\alpha\in\mathbb R^{3\times 3}$ 为实对称矩阵。本文称 $\mathsf K_\alpha$ 为整球响应曲率张量：它是物理外动量 $d=sn$ 的二次型系数矩阵，非对角交叉单项式约定为 $2K_{ij}d_id_j$。即便将非解析一次项 $a_\alpha(n)|s|$ 扣除后对剩余光滑部分求二阶导数，所得 Hessian 矩阵亦对应 $2\mathsf K_\alpha$ 而非 $\mathsf K_\alpha$；由于当 $a_\alpha(n)\ne 0$ 时 $\mathcal R_\alpha$ 在原点不可微，$\mathsf K_\alpha$ 不冒充完整尖窗响应函数在原点的光滑 Hessian。

<a id="thm-1-2"></a>

**定理 1.2（指定双球窗极化曲率张量的 $(2,1,0)$ 惯性律）。** 在上述固定外源、同向变分读出算符、空间滤波制备态、双 Laplace 时间参数及等半径 $B$ 入射／观察双球窗下，式 (1.3) 的实对称二次曲率张量严格满足 Sylvester 惯性定律 [[23]](#ref-23)：

\[
 \operatorname{Inertia}(\mathsf K_{\mathrm{raw}})
 =\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0), \tag{1.4}
\]

其中三元组依次记严格负、严格正与零特征值的重数。下表列出严格二进有理区间向外舍入后的十进制包络，单位为 $10^{-20}$（原作用自然单位，保留完整 $(2\pi)^{-3}$ Fourier 测度与 $B^3$ 窗口体积）：

| 主轴方向 | 未中心化（`raw`） | 均值项（`mean`） | 连通部分（`connected`） |
|---|---:|---:|---:|
| \(e_1\) | \([-1.355200,-1.309214]\) | \([-0.060120,-0.055272]\) | \([-1.297332,-1.251692]\) |
| \(e_2\) | \([2.140271,2.186257]\) | \([-0.001635,0.003212]\) | \([2.139655,2.185295]\) |
| \(e_3\) | \([-1.742600,-1.696614]\) | \([-0.043357,-0.038509]\) | \([-1.701494,-1.655854]\) |

对全部非对角指标 $i\ne j$，另有统一绝对上界

\[
 |K_{ij}^{\mathrm{raw}}|<2.299243\,10^{-22},\quad
 |K_{ij}^{\mathrm{mean}}|<2.423430\,10^{-23},\quad
 |K_{ij}^{\mathrm{conn}}|<2.281948\,10^{-22}. \tag{1.5}
\]

第 11.2 节结合对角区间与式 (1.5) 的非对角统一界，沿缩放非对角元的连续路径应用 Gershgorin 圆盘隔离定理 [[24]](#ref-24) 完成式 (1.4) 的证明；单独三个对角元符号本身并不足以推出三维矩阵惯性。均值项 `mean` 在 $e_2$ 轴上的区间包含 $0$，因此本文如实保留其区间而不对 `mean` 作惯性裁决；同样，当 $a_\alpha(n)\ne 0$ 时，小动量 $|s|\ll B$ 处的首阶斜率由 $|s|$ 尖项主导，正二次曲率不代表完整读数从原点起单调递增。

为使读者在进入分节推导前一眼把握全篇 Q1–Q7 四大支柱的可证伪刚性，表 1 将每项正向全称定理与源码内建的结构反例／反向控制配对列出：省去任何一个看似微小的非交换次序、Ward 补项或边界通量，定量结果立即发生可核查的跳变。

**表 1　四大支柱（Q1–Q7）的正向全称定理与成对结构反例／反向控制总览。**

| 支柱与命题 | 正向全称定理与精确输出 | 成对结构反例／反向控制（省去单步即破坏结论） | 正文位置 |
|---|---|---|---|
| **柱 I · 有序闭迹与 Fock 整词评价**（Q1–Q2） | 任意长合法有序规范传播词闭迹 $\operatorname{tr}W=\operatorname{tr}W_0$；单次单向标量插入闭迹为 $0$，同向双插入 $Y_a W Y_b=0$；完整 Fock 词单位制备读回 $1$，显式返回算子读出 $-1$ | 双规范顶点词给出 53 位非零有理闭迹 (3.9)；三顶点词闭迹为 $0$ 但开放差 $W-W_0\ne 0$；反向伴随给出 $\operatorname{tr}(N^\dagger N)=1296/125\ne 0$；全载体裸迹为 $252$；中途插入秩一投影 $P_w$ 将开放返回 $-1$ 抹成 $0$ 并篡改 $6/16$ 个规范整词 | §3–§4；附录 A |
| **柱 II · 费米子 Schur 补与双球 $(2,1,0)$ 惯性律**（Q3–Q4） | $289\to 103\to 55$ 一次物质 Schur 补 $S_{55}$ 满足全 289 行符号回写 $H_{289}F=J_{\mathrm{src}}S_{55}$；五维轻核兼备线性与二次时间尺度；五通道整球曲率 $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0)$ | 跳过 Lorentz 消元直逆自由物质块篡改 $128$ 个条目；删去 $32$ 个 Ward 标量源条目破坏 (5.4)；静态 $18N/125$ 与齐次 $33N/125$ 在原点不可交换；单看球内体项仅得三轴全负 $(-1.44,-0.19,-0.19)$；仿射场删去球面通量伪造负曲率；丢弃复交叉虚部将常场 $0$ 错算为 $-32$；`mean` 第二轴真实跨零 | §5–§11；图 1–4；附录 B–E |
| **柱 III · 全四复动量母 Hessian 认回与原点核重构**（Q5） | 母作用密度 1,445 射流槽二阶 Fréchet 导数在全部 $p\in\mathbb C^4$ 上逐项等于 $H_{289}(p)$（3,071 项字典）；$5\oplus(45+21+32)$ 直和补给出完整 Schur 核 $E(p)$、Neumann 半径 $\rho$、三阶余项界及清分母全 289 场（含接触与九零模）恢复 | 二阶截断 $T_{12}(p)$ 之外真实存在 48 项非零三四次表 $T_{34}(p)$ 及高阶预解项；五列原点核 $N$ 在 98 维补坐标上具有非零分量（非正交补）；删去九零模投影 $P_n$ 无法闭合完整原场 (12.20) | §12；图 5 |
| **柱 IV · 非线性因果 Noether 张量与极小多项式 Sylvester 坍缩**（Q6–Q7） | 实 289 场正半轴算子 $\mathcal J_\infty$；产生态减背景差 $\ell_d$ 在非线性正窗口 $[0,\tau)$ 上导出 $[W_T K_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$ 与电压 Cauchy 更新；首一极小多项式商逆将全部 $289^2$ 静态钟极化坍缩为 $w_q^{\mathsf T}D+w_q^{\mathsf T}Rw_q$、消相接回光子振幅，且全 $Y$ 静态／物理 $N=3$ 窗／六阶红外极限对 Yukawa 截断标号严格不变 | 省去中央 Noether 接触差 (13.2) 丢失运输斜率；异钟算例 $P=0,\lambda=T=1$ 给出 $W_T=1-e^{-1}\ne T$（禁止盲目除以 $T$）；极小多项式根矛盾锁死 $\operatorname{Re}\lambda\ne 0$ 上 $P_q(\lambda)\ne 0$；严守全 $Y$ 截断消除与定理 14.2 有限 Green 腿光子对的明确边界 | §13–§14；图 5–6；附录 E |

### 1.3　三分钟纸笔验算锚点

在进入 289 维场空间与复围道积分之前，读者仅需用纸笔花三分钟即可独立验算以下三个初等代数与微积分实例。它们不依赖任何计算机程序，却直接浓缩了本文三处最关键的结构转折。

<a id="ex-1-1"></a>

**例 1.1（三分钟纸笔验算锚点）。**

**(a) 手征外幂五逆序符号与“$252$ 对 $1$ 对 $-1$ 对 $0$”四重奏。** 在母物质载体 $\mathcal M=\mathbb C^4\otimes(\Lambda^6\oplus\Lambda^2\oplus\Lambda^4)\mathbb C^7$ 上，$\dim_{\mathbb C}\mathcal M=4\times(7+21+35)=252$，故 $\operatorname{tr}_{\mathcal M}I=252$。设 $P_6$ 为投向 $\mathbb C^4\otimes\Lambda^6\mathbb C^7$ 的投影，单向算符满足 $P_6N_a=N_a$ 与 $N_aP_6=0$，块对角算符满足 $[B,P_6]=0$。则仅凭矩阵乘法结合律与迹循环性立得

\[
 N_a B N_b = N_a B (P_6 N_b) = (N_a P_6) B N_b = 0,
\]

且 $\operatorname{tr}N_a=\operatorname{tr}(P_6N_a)=\operatorname{tr}(N_aP_6)=0$——这正是定理 3.2 任意长有序词闭迹简化的全部代数引擎。再看 §4.2 的单位准备态 $w\in\mathbb C^4\otimes\Lambda^2\mathbb C^7$：它在四个自旋—外幂槽 $(0;15),(1;05),(2;15),(3;05)$ 上依次取 $\frac12,-\frac12,\frac12,-\frac12$，故 $\|w\|^2=4\times\frac14=1$，$\langle w,Iw\rangle=1$。取标量微扰方向 $\delta\phi=e_{0234}\in\Lambda^4\mathbb C^7$，右旋投影 $P_R=\operatorname{diag}(0,0,1,1)$ 保留自旋指标 $2,3$；在 $2w$ 的自旋 $2$ 分量 $+e_{15}=e_1\wedge e_5$ 上，楔积给出

\[
 e_1\wedge e_5\wedge e_0\wedge e_2\wedge e_3\wedge e_4 = (-1)^5\,e_{012345} = -e_{012345},
\]

因为将排列 $(1,5,0,2,3,4)$ 排成升序 $(0,1,2,3,4,5)$ 恰含 $5$ 个逆序对：$(1,0),(5,0),(5,2),(5,3),(5,4)$。于是读取自旋 $2$ 中 $e_{012345}$ 分量的行泛函 $r$ 满足 $rY_{\delta\phi}(2w)=-1$；定义显式返回算符 $R=2wr$，便有 $RY_{\delta\phi}w=w\cdot rY_{\delta\phi}(2w)=-w$，从而 $\langle w,RY_{\delta\phi}w\rangle=-1$。反之，若在乘积中途插入秩一投影 $P_w=|w\rangle\langle w|$，由于 $Y_{\delta\phi}w\in P_6\mathcal M$ 而 $P_6w=0$，内积 $\langle w,Y_{\delta\phi}w\rangle=0$ 立即给出 $\langle w,RP_wY_{\delta\phi}w\rangle=0$。四个数字 $252,1,-1,0$ 各自忠实回答了四个不同的算符问题。

**(b) 双球透镜尖点与仿射场球面通量的精确零化。** 半径为 $B$ 的两个三维欧氏球中心相距 $|s|\in[0,2B]$ 时，每个球被对方裁去高为 $B-|s|/2$ 之外的球冠，初等旋转体积分给出交集体积 $\operatorname{Vol}(B_B\cap(B_B+sn))=\frac{4\pi}{3}B^3-\pi B^2|s|+\frac{\pi}{12}|s|^3$（式 (8.1)）：线性尖项 $-\pi B^2|s|$ 直接来自赤道投影圆面积 $\pi B^2=\frac12\int_{\partial B}|n\cdot\nu|\,dS$ [[22]](#ref-22)，二次项系数在此常量核上严格为 $0$。再检验式 (8.7) 的仿射测试场 $a(k)=[1+(2+i)k_3]b$（沿 $n=e_3$，其中 $b^{\mathsf T}Qb=4$）：$\partial_3 a=(2+i)b$，$\partial_3^2 a=0$，故左端直接积分给出 $K(e_3)=0$；而在分部积分后的右端（略去公共前置因子 $\frac1{4(2\pi)^3}$），球内梯度能项为 $-\int_B |(2+i)|^2(b^{\mathsf T}Qb)=-20\operatorname{Vol}(B_B)$，球面边界通量项为 $\int_{\partial B}\nu_3\operatorname{Re}\bigl([1+(2-i)k_3](2+i)\bigr)(b^{\mathsf T}Qb)=\int_{\partial B}\nu_3(8+20k_3)\,dS=\int_{\partial B}20\,\nu_3 k_3\,dS=+20\operatorname{Vol}(B_B)$（由奇对称消去 $\int_{\partial B}\nu_3\,dS=0$ 及散度定理 $\int_{\partial B}\nu_3 k_3\,dS=\int_B\partial_3 k_3=\operatorname{Vol}(B_B)$），两项非零且一正一负精确相消为 $0$。任何忽略移动窗口球面通量的近似都会把零曲率误判为负曲率。

**(c) 两行算术锁死 $(2,1,0)$ 惯性与零级数商预解逆。** 取 §1.2 表中 `raw` 的三个主轴区间，将每行向两侧各放宽 $2m_{\mathrm{raw}}<2\times 0.022993\times 10^{-20}=0.045986\times 10^{-20}$：第一行落入 $[-1.4012,-1.2632]\times 10^{-20}<0$，第二行落入 $[2.0942,2.2323]\times 10^{-20}>0$，第三行落入 $[-1.7886,-1.6506]\times 10^{-20}<0$。沿对称同伦 $M(t)=\operatorname{diag}(K_{11},K_{22},K_{33})+t(K-\operatorname{diag}K)$（$t\in[0,1]$），全部 Gershgorin 圆盘与 $0$ 严格不相交，特征值连续性立得 $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=(2,1,0)$。同理，在 §14 中，只要算符 $\mathcal T_q$ 被首一多项式 $P_q(X)$ 零化且 $P_q(\lambda)\ne 0$，单变元多项式带余除法 $P_q(X)=(X-\lambda)Q_{q,\lambda}(X)+P_q(\lambda)$ 代入 $X=\mathcal T_q$ 立即给出 $(\lambda I-\mathcal T_q)\bigl[P_q(\lambda)^{-1}Q_{q,\lambda}(\mathcal T_q)\bigr]=I$，无需展开任何无穷时间积分或 Neumann 级数即可精确求逆。

### 1.4　同源双支架构与分学科 15 分钟快速验证通道

本文在同系列中的依赖关系简洁透明：物理旗舰篇 Case 0 [[1]](#ref-1) 提供零参数共同母作用、独立线性对偶 $\chi$、唯一九场经典解、占据准备态 $w$ 及三载体返回配对；第一案 Case 1 [[2]](#ref-2) 提供 12 维占据态空间 $L^2(\mathbb R^3,\mathbb C^{12})$ 上的自伴 Dirac 生成元、全实时间幺正演化及算子范数因果导数（L1–L17）。本篇（Case 2）在完全相同的母作用与制备态上闭合四组核心命题：非交换有序词闭迹简化与 Fock 整词评价（§3–§4，Q1–Q2）；$289\to 103\to 55$ 费米子 Schur 补、五维原点轻核与双球五通道 $(2,1,0)$ 惯性律（§5–§11，Q3–Q4）；全四复动量母作用二阶 Fréchet 变分认回与 $5\oplus 98$ 原点核清分母全场恢复（§12，Q5）；以及配置空间有序五因子因果 Noether 极化张量、极小多项式商代数有限 Sylvester 坍缩与制备光子振幅连通馈入（§13–§14，Q6–Q7）。

如图 1 所示，有序闭迹支路（Q1–Q2）与空间波包极化支路（Q3–Q4，图 1–4）从同一母作用并行分出：前者刻画有限维纤维与 Fock 整词的非交换分级代数，后者将一次物质反馈玻色传播核与实时间量子复 Gram 配对积分；图 1 中不存在从“单向裸迹为零”推向“空间波包响应为零”的虚假箭头。第 12–14 节（Q5–Q7，图 5–6）进而把母作用二阶变分、四复动量原点核与非线性配置历史闭合为有限维源生 Sylvester 矩阵与精确无截断响应，其配置准备与时间收敛域条件与第 6–11 节的固定位置球双窗设置严格分列，绝不相互混借。

**按专业背景划分的 15 分钟快速验证通道。** 鉴于全文横跨非微扰量子场论、微局域／尖窗渐近与计算机辅助区间证明、受约束变分偏微分方程及算子代数响应理论，不同领域读者在读完例 1.1 后，可按各自方向直接切入以下四条自足核验路线：

- **量子场论、背景场有效作用与手征圈代数研究者**：直接阅读 **§3–§5 及附录 A–B（定理 3.2、推论 3.3、命题 4.1、定理 5.2–5.3、图 2）**，核验洛伦兹独立对偶下 $P_6$ 分级如何无需紫外截断或正规化即简化任意长有序规范闭迹，二次量子化整词评价如何严格区分裸迹 $252$、准备态期望 $1$ 与开放返回 $-1$，以及单次费米子 Schur 补 $S_{55}$ 如何实现全 289 行符号回写并在原点分离双时间尺度色散与非交换射线极限。
- **散射波包分析、积分几何与计算机辅助严格证明研究者**：直接阅读 **§1.2、§7.4–§11.2 及附录 D–E（定义 1.1、定理 1.2、命题 10.1、图 3–4）**，核验双球交集透镜如何产生 $|d|$ 集合协方差尖点与两类球面边界通量，§9.4 如何通过先递归求解外源响应系数消除区间算术包裹膨胀 [[26]](#ref-26)，以及 §10.2 球面通量如何将球内伪负曲率跨零逆转为 $(2,1,0)$ 惯性指数。
- **变分偏微分方程、受约束系统与多动量代数约化研究者**：直接阅读 **§12（命题 12.1、定理 12.2、图 5 上半部）**，核验九场母作用密度在 1,445 个实一阶射流槽上的二阶 Fréchet 导数如何在全部 $p\in\mathbb C^4$ 上逐项认回 3,071 项 $H_{289}(p)$，以及五列原点核与 $45+21+32$ 直和补坐标如何给出显式 Neumann 半径 $\rho$、三阶预解余项界与含九零模的清分母全场恢复。
- **算子代数、非平衡 Kubo 响应与 Sylvester 算子方程研究者**：直接跳读 **§13–§14（命题 13.1、定理 13.2、定理 14.1–14.3、例 14.1、图 5–6）与 §15**，核验产生态减背景差泛函 $\ell_d$ 如何沿非线性实场历史生成母 Euler 响应铅笔 $[W_T K_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$，交换左右生成元的代数整性如何在商代数 $\mathbb C[X]/(P_q(X))$ 内把无穷半轴积分精确坍缩为有限二次型 $w_q^{\mathsf T}D+w_q^{\mathsf T}Rw_q$，以及穿衣相位消去与离散 Yukawa 截断消除如何直通下游 Case 3 的精细结构常数源内 Thomson 公式。

![图1：同一零旋钮母作用的两条并行支路与双球五通道极化合成。](figures/fig01-two-branches-v2.svg)

**图 1　同一零旋钮母作用的两条并行支路与双球五通道极化合成。** 上支路（Q1–Q2）保留非交换词序、$P_6$ 手征分级与先乘整词后评价的 Fock 读回规则；下支路（Q3–Q4）将一次费米子 Schur 补玻色核、全 289 行符号回写与实时间占据态复 Gram 相接。两条量子源腿包含 Duhamel 幅度变分并使用固定入射球窗；变分读出接触项与两条玻色场传播腿使用随外动量 $d$ 移动的双球交集透镜；朱红标出的五条通道缺一不可。窗口标注对应本案 $p_{\mathrm{out}}=0$、两球等半径 $B$ 的探针协议（一般双窗分配见 §7.4）；箭头表示数学构造依赖而非数值相等。

## 2　同一母作用与四套不可混用的坐标与伴随纪律

要在一套包含一阶余标架引力、非阿贝尔规范场、外幂标量与手征旋量的 289 维耦合系统中做到零误差回代，首要前提是在出发点严格钉死母作用密度、时间换元相因子以及复纤维厄米伴随 $\dagger$ 与实化变分形式转置 $T$ 的各自职责。本节集中给出全篇共用的场变量、背景解常数与三种矩阵运算规则。

### 2.1　九组原场、252 维外幂载体与独立变分对偶

母作用量中的九组原场记为 $\Phi=(e,\omega,B_{\mathrm{gr}},\lambda,A,B_g,\phi,\psi,\chi)$：其中 $e$ 为四维余标架，$\omega$ 为 Lorentz 自旋联络，$B_{\mathrm{gr}},\lambda$ 为引力辅助二形式与简单性乘子，$A,B_g$ 为规范联络及其本构辅助二形式，$\phi$ 为四次外幂复标量场，$\psi$ 与 $\chi$ 则为相互独立的物质旋量场与线性变分对偶场 [[1]](#ref-1)。母物质载体取为

\[
 \mathcal M=\mathbb C^4\otimes
 (\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7),
 \qquad \dim\mathcal M=4(7+21+35)=252. \tag{2.1}
\]

内部 $\mathbb C^7$ 标准基记作 $e_0,\ldots,e_6$，其中颜色指标为 $0,1,2$，弱同位旋指标为 $3,4$，其余两个指标为 $5,6$。由母源谱序参量双向唯一选出的标准模型规范子代数为 $\mathfrak h=\{\operatorname{diag}(C,W,y,-y):C\in\mathfrak{su}(3),\ W\in\mathfrak{su}(2),\ y\in i\mathbb R\}$（实维数 $12$）[[1]](#ref-1)；全篇所有规范耦合顶点均由这一固定嵌入通过外幂导子律
$\rho(X)(v_1\wedge\cdots\wedge v_r)=\sum_jv_1\wedge\cdots\wedge Xv_j\wedge\cdots\wedge v_r$
生成，全部外积按升序基指标与置换奇偶符号精确求值。

取标准 Pauli 矩阵 $\sigma_j$，固定四维旋量矩阵表示为

\[
 \gamma^0=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\quad
 \gamma^j=\begin{pmatrix}0&\sigma_j\\\sigma_j&0\end{pmatrix},\quad
 \gamma_5=\begin{pmatrix}-I_2&0\\0&I_2\end{pmatrix},\quad
 S=\gamma^0\gamma_5. \tag{2.2}
\]

背景标量真空值及其诱导的单向外幂楔积 Yukawa 映射定义为

\[
 \begin{gathered}
 \phi_0=e_{0126}+e_{0124}+e_{0156}+e_{0145},\qquad
 T_\phi(w_6,w_2,w_4)=(w_2\wedge\phi,0,0),\\ Y_R=P_R T_\phi,\quad P_R=\operatorname{diag}(0,0,1,1).
 \end{gathered} \tag{2.3}
\]

与欧氏谱作用量中预设自伴有限 Dirac 矩阵 $D_F$ [[8]](#ref-8) 不同，本文在洛伦兹变分原理中**不将对偶场 $\chi$ 强行等同于 $\psi^\dagger$**。这一独立变分对偶使母作用密度中的物质双线性项及其导出的左、右两条 Euler–Lagrange 方程具备完全确定的非交换左右乘积次序。

以 $\mathcal W$ 表示时空二形式顶次楔积配对，以 $J$ 表示引力内部块交换映射，以 $*_e$ 表示依赖于动态余标架 $e$ 的 Hodge 星算子，母作用拉氏密度写为 [[1]](#ref-1)

\[
\begin{split}
\mathcal L={}&\mathcal W(B_{\mathrm{gr}},\widehat F_\omega)
-\tfrac12\mathcal W(B_{\mathrm{gr}},JB_{\mathrm{gr}})
+\mathcal W(\lambda,B_{\mathrm{gr}}-J\Sigma_e)\\
&+\mathcal W_g(B_g,F_A)-\tfrac\sigma2\mathcal W_g(B_g,*_eB_g)\\
&+\nu_e\left[\tfrac12g^{\mu\nu}\operatorname{Re}\langle D_\mu\phi,D_\nu\phi\rangle
-\|\phi-v\|^2+\operatorname{Re}\chi(i\Gamma_e^\mu D_\mu\psi+Y_R\psi)\right]. \tag{2.4}
\end{split}
\]

此处固定 $v=\phi_0$，闵氏内部度规取 $\eta=\operatorname{diag}(-1,1,1,1)$，诱导时空度规为 $g=e^T\eta e$，体积密度为 $\nu_e=|\det e|$。将自旋联络的 Lorentz 指标反对称延拓至全部 $a,b$，协变导数与标架缩并规定为

\[
 \begin{gathered}
 \Gamma_e^\mu=(e^{-1})^\mu{}_a\gamma^a,\qquad
 \Omega_\mu=\tfrac14\omega_{\mu ab}\gamma^a\gamma^b,\\
 D_\mu\psi=(\partial_\mu+\Omega_\mu+\rho(A_\mu))\psi,\quad
 D_\mu\phi=(\partial_\mu+\rho_4(A_\mu))\phi,
 \end{gathered}
\]

且余标架二次楔积为 $\Sigma_e^{ab}=e^a\wedge e^b$。规范曲率取 $F_{\mu\nu}=\partial_\mu A_\nu-\partial_\nu A_\mu+[A_\mu,A_\nu]$，Lorentz 曲率 $\widehat F_\omega$ 同式定义。时空与内部二形式指标统一按 $01,02,03,23,31,12$ 排序，顶次配对由 $\varepsilon^{0123}=1$ 定号（$J$ 与 $\mathcal W$ 的显式六维矩阵见附录 A.1）。规范李代数双线性配对在颜色 $\mathfrak{su}(3)$ 与弱 $\mathfrak{su}(2)$ 块上分别取 $-\operatorname{Re}\operatorname{tr}(XX^\prime)$，在母 $\mathfrak u(1)$ 原坐标上取 $-\operatorname{Re}(yz)$（不额外乘以二分量对角迹因子 $2$）。

### 2.2　唯一背景常数、物理时间与动量换算表

母作用在原历史弱恢复条件下的唯一非退化九场经典解锁定下列背景常数 [[1]](#ref-1)：

\[
 N=\frac{3\sqrt{30}}{25},\quad s_0=\sqrt2,\quad a=\frac{3\sqrt2}{5},\quad
 \omega_0=\frac{3N\sqrt2}{5},\quad \sigma=\frac12,\quad e=\operatorname{diag}(N,1,1,1). \tag{2.5}
\]

其空间自旋联络背景为 $\omega_{1,23}=\omega_{2,31}=\omega_{3,12}=\sqrt2$，规范势背景为 $A_0=0,A_j=a\tau_j$（其中 $\tau_j=i\sigma_j/2$ 嵌入颜色 $0,1$ 二维子块）。在 $t=0$ 处，经典解的物质场与独立对偶场取值为 $\psi_0=2w$ 与 $\chi_0=2\sqrt2\,w^\dagger S$（$w$ 的四个非零分量见式 (4.6)）。在下文共转表示中，$(\psi_0,\chi_0)$ 即为常值背景，物理时间表示下的振荡相位由酉旋转 $U_{\mathrm{rot}}(t)$ 精确还原；一切场变分仍对独立的 $(\psi,\chi)$ 执行。

全文始终以原物理时间 $t$ 为基准时间变量；局部代数运算中出现的 $\tau=Nt$ 或 $ct$ 仅为标度换元。各章节共用的时间、动量与窗口半径记号汇总如下：

| 记号 | 数学物理含义与精确换算关系 |
|---|---|
| \(\lambda\) | 物理时间 Laplace 指数变量；实振荡能量 \(E\) 对应 \(\lambda=-iE\) |
| \(u,q_{\mathrm{ax}}\) | 有理化轴向谱与动量坐标：\(\lambda=N\sqrt2\,u,\ k_3=\sqrt2\,q_{\mathrm{ax}}\) |
| \(p=2\pi\xi\) | 物质波包 Fourier 变换中的物理空间动量 |
| \(y,d\) | 玻色传播腿入射物理动量与外加探测场物理动量；负相位约定下出射动量为 \(y-d\) |
| \(c=N\sqrt2\) | 母解内生锁定的 Laplace 速率换元常数（\(6\sqrt{15}/25\)），非外置光速标尺 |
| \(B=\sqrt2\epsilon_B\) | 入射与观察三维动量球的共同半径，严格区别于半径为 \(1\) 的位置空间准备球 |

在 289 维实场线性化系统中，物质与对偶坐标采用消除背景时间相位进动的共转表示：令荷矩阵为 $Q=\gamma_5+2P_6$，共转变换为 $U_{\mathrm{rot}}(t)=e^{-i\omega_0tQ}$，共转生成元为 $H_{\mathrm{st}}=H_{\mathrm{orig}}-\omega_0Q$。物理时间本身并未改变，原时间背景满足

\[
 \psi_{\mathrm{orig}}(t)=U_{\mathrm{rot}}(t)\psi_0,\qquad
 \chi_{\mathrm{orig}}(t)=\chi_0S U_{\mathrm{rot}}(t)^\dagger S.
\]

需要注意两处坐标分工：第 6 节的实时间空间电流采用未减共转相位的原时间生成元 $H_{\mathrm{orig}}$，而第 5 节与第 12 节的 289 场代数消元采用常系数共转坐标；位置空间单位准备球的半径恒为 $1$，其经 Dirac 预解滤波后的归一化常数 $n$（式 (6.6)）亦完全固定，不随动量窗半径 $B$ 或外加微扰场重算。

### 2.3　两类矩阵转置与整词末端评价纪律

在有限维复纤维矩阵上，记号 $\dagger$ 专指复共轭转置（Hermitian 伴随）；而在包含独立对偶与实化一阶射流的 Euler–Jacobi 算符矩阵上，母作用二阶变分满足的形式对称律为 $H(-p)^T=H(p)$，其中 $T$ 为纯矩阵转置。全篇严格禁止将纯转置 $T$ 与厄米伴随 $\dagger$ 混同互换。称某一复参数集为正则可逆域（regular domain），均指当前步骤所使用的主部或分块子矩阵在该参数集上拥有真实双侧逆（具体定义域分别在 §3.2、§5.2、§9.4 与 §12.3 给出）。

固定单位占据态 $w$ 诱导的基础态评价泛函记作 $\Omega(A)=\langle w,Aw\rangle$；连续空间等距嵌入 $E$ 保持同一返回恒等式 $\Omega(E^\dagger AE)=\langle Ew,AEw\rangle$。用独立变分对偶背景 $(\psi_0,\chi_0)$ 表达时，同一读数精确写为 [[1]](#ref-1)

\[
 \Omega(A)=\frac{\chi_0(SA\psi_0)}{4\sqrt2}=\langle w,Aw\rangle. \tag{2.6}
\]

此处 $S^2=I$，且上下旋量翻转矩阵 $S=\gamma^0\gamma_5$ **仅在整串算符乘积 $A$ 完全形成之后在最左端作用一次**，绝不能拆插入相邻因子之间；同理，制备态评价 $\Omega$ 亦只作用于完整乘积末端，中途不插入秩一投影。第 4 节的二次量子化 Fock 整词与第 6 节的连续双时间复 Gram 均严格遵守这一末端评价律。为便于跨节查阅而避免把同名术语跨场景误植，表 2 汇总全篇四类量子载体、两套耦合消元链、两种“连通”泛函及三类预解式／动量相位约定。

**表 2　全篇四类量子载体、两套耦合消元链、两种“连通”泛函与三类预解／相位约定总表。**

| 概念维度 | 记号与数学对象 | 适用章节与命题 | 精确结构定义与不可混用红线 |
|---|---|---|---|
| **量子载体 I–II** | 有限手征纤维 $\mathcal M$（$\mathbb C^{252}$）与反对称 Fock 空间 $\mathcal F_-(\mathcal M)=\bigoplus_{r=0}^{252}\Lambda^r\mathcal M$ | §3–§4（Q1–Q2） | 固定各腿动量下的纯代数算符词；单粒子扇区 $d\Gamma(A_1)\cdots d\Gamma(A_m)J_1w=J_1(A_1\cdots A_mw)$ 须整词乘毕再投影，不涉连续空间积分 |
| **量子载体 III** | 12 维占据连续态空间 $L^2(\mathbb R^3,\mathcal H_{12})$（等距嵌入 $F_{12}:\mathcal H_{12}\to\mathcal M$） | §6–§11（Q4） | 自由生成元的双侧约化自伴不变子空间（$F_{12}^\dagger Y_RF_{12}=0$）；位置单位球经谱点 $i$ 处 Dirac 预解滤波得归一化波包 $\psi$ |
| **量子载体 IV** | 完整配置空间 Hilbert 空间 $\mathscr H_{\mathrm{cfg}}=\mathcal H$ 与有界算子代数 $\mathcal B(\mathcal H)$ | §13–§14（Q6–Q7） | 同时涵盖有限参考标架 $F_d$ 与外部多体未切 $Y$ 算子词；有序五因子核先完成乘积再外施连续线性观察泛函 |
| **耦合消元链 A–B** | 链 A：$289\to 103\to 55$ 物质 Schur 补 $S_{55}$（§5，Q3）；链 B：$5\oplus(45+21+32)$ 全四动量原点核 $E(p)$（§12，Q5） | §5、§7、§12 | 链 A 消去 48 个实物质坐标并经 $J_{\mathrm{src}}$（含 32 项 Ward 源）回写 289 行；链 B 在 $p\in\mathbb C^4$ 上用非正交直和坐标补恢复接触项、活跃块与 9 零模 |
| **“连通”定义 I–II** | 空间正交投影 $I-P$（其中 $P=\lvert\psi\rangle\langle\psi\rvert$）对产生态减背景差 $\ell_d(A)=-\langle u_\varepsilon,Au_\varepsilon\rangle+\langle v_\varepsilon,Av_\varepsilon\rangle$ | §6.3–§11 对 §13.2–§14.3 | 前者在固定单粒子空间波包内扣除复均值乘积（`raw = mean + conn`）；后者在多体配置空间扣除同源背景态期望并保持原 Euler 符号（$\|\ell_d\|\le 2$） |
| **预解与相位约定** | 纤维 Dirac 逆 $G_D(z)=i(z-H)^{-1}C_0^{-1}$（式 3.1）；12 维电流 Sylvester 核 $G_z(k)$（式 6.14）；商代数双侧预解 $\mathcal S_q(\lambda)=(\lambda I-\mathcal T_q)^{-1}$（式 14.4–14.6） | §3、§6、§13–§14 | 波包极化（§7–§10）采用负空间相位列 $e^{-ik\cdot x}$（出射动量 $y-d$）；配置空间（§13–§14）左／右腿动量固定为 $(p_d-k,p_d)$，绝不跨章混套符号 |

## 3　非交换有序闭迹简化：单向箭头与分级理想（Q1）

本节处理图 1 上支路的第一项核心问题：当洛伦兹 Dirac 传播生成元因独立对偶与手征外幂楔积 $Y_R$ 而非自伴时，一圈闭迹是否会因任意多次标量跃迁而失控？我们在不作动量积分、不引入紫外正规化且不交换任何不同顶点的前提下，证明 $P_6$ 手征分级将单向项严格关入二阶幂零理想，从而使任意长合法有序规范传播词的闭迹精确化归为自由块对角词闭迹。

### 3.1　独立对偶演化与精确 Dirac 预解逆

在固定空间动量纤维上，写一阶物质演化方程为 $D\psi=(C_0\partial_t+L)\psi=0$，其中时间主部矩阵 $C_0=i\gamma^0/N$ 处处可逆。Hamiltonian 生成元与谱参数 $z\in\mathbb C$ 处的 Dirac 预解逆之间满足精确代数关系

\[
 H=-iC_0^{-1}L,\quad D_z=-iC_0(z-H),\qquad
 G_D(z)=i(z-H)^{-1}C_0^{-1}. \tag{3.1}
\]

双侧直接相乘即验得 $D_zG_D(z)=G_D(z)D_z=I$；右端尾因子 $C_0^{-1}$ 与前因子 $i$ 均由原一阶拉氏密度锁定，不可省略。

令演化生成元为 $A=-C_0^{-1}L=-iH$，单参数群为 $U(t)=e^{tA}$。物质场与独立变分对偶场的配对演化律为

\[
 \psi(t)=U(t)\psi(0),\qquad
 \chi(t)=\chi(0)C_0U(-t)C_0^{-1}. \tag{3.2}
\]

对时间直接求导立得守恒配对 $\partial_t(\chi C_0\psi)=0$。注意式 (3.2) 全程未将 $\chi(t)$ 替换为 $\psi(t)^\dagger$，而 252 维生成元 $H$ 中的单向外幂楔积项在标准复内积下亦非自伴。

### 3.2　$P_6$ 手征分级理想与任意长有序规范词简化定理

在 $\mathcal M=\mathbb C^4\otimes(\Lambda^6\oplus\Lambda^2\oplus\Lambda^4)\mathbb C^7$ 上定义投向最高外幂扇区 $\mathbb C^4\otimes\Lambda^6\mathbb C^7$ 的正交投影：

\[
 P_6=I_4\otimes\operatorname{diag}(I_7,0_{21},0_{35}). \tag{3.3}
\]

称线性算符 $B\in\operatorname{End}(\mathcal M)$ 为**块对角算符**，若 $[B,P_6]=0$；称 $N_a\in\operatorname{End}(\mathcal M)$ 为**单向箭头**，若

\[
 P_6N_a=N_a,\qquad N_aP_6=0. \tag{3.4}
\]

式 (3.4) 表明 $N_a=P_6N_a(I-P_6)$ 只能将非六次外幂扇区单向送入 $\Lambda^6$ 扇区而无法折返。由此对任意块对角算符 $B$ 与任意单向箭头 $N_a,N_b$，立得三条基础理想恒等式：

\[
 N_aBN_b=0,\quad BN_a,\ N_aB\text{仍为箭头},\quad \operatorname{tr}N_a=0, \tag{3.5}
\]

其中末式由有限维矩阵迹循环性 $\operatorname{tr}(P_6N_a)=\operatorname{tr}(N_aP_6)=0$ 直接给出。

<a id="def-3-1"></a>

**定义 3.1（合法有序规范传播词）。** 对有限腿指标 $j=1,\ldots,m$，给定同一自由块对角纤维生成元 $H_{0,j}$、单向项 $N_j$、复谱参数 $z_j$ 与规范密度耦合顶点 $V_j$。若满足 $[H_{0,j},P_6]=[C_{0,j},P_6]=[V_j,P_6]=0$、单向条件 (3.4) 对每个 $N_j$ 成立，且 $C_{0,j}$ 与 $z_j-H_{0,j}$ 均双侧可逆，则由各腿完整 Dirac 传播逆 $G_{D,j}=i(z_j-H_{0,j}-N_j)^{-1}C_{0,j}^{-1}$ 与规范顶点 $V_j$ 按固定左右顺序相乘所得的任意有限乘积 $W$ 称为合法有序规范传播词（各腿动量与谱参数允许彼此独立）。

<a id="thm-3-2"></a>

**定理 3.2（任意有限合法有序规范词的闭迹简化定理）。** 设每条传播腿生成元分解为 $H_j=H_{0,j}+N_j$。则在定义 3.1 的可逆域上，完整预解逆精确截断为一阶线性式

\[
 (z_j-H_j)^{-1}=R_{0,j}+R_{0,j}N_jR_{0,j},
 \quad R_{0,j}=(z_j-H_{0,j})^{-1}. \tag{3.6}
\]

将有序词 $W$ 中的每条完整腿 $G_{D,j}$ 替换为其自由块对角传播腿 $iR_{0,j}C_{0,j}^{-1}$ 所得的自由分级词记为 $W_0$，则必有

\[
 W=W_0+N_W,\qquad P_6N_W=N_W,\quad N_WP_6=0,\qquad
 \operatorname{tr}W=\operatorname{tr}W_0. \tag{3.7}
\]

**证明。** 因 $R_{0,j}$ 与 $P_6$ 对易，式 (3.5) 给出 $N_jR_{0,j}N_j=0$；将 $(z_j-H_{0,j}-N_j)$ 从左、右两侧分别乘上 $R_{0,j}+R_{0,j}N_jR_{0,j}$，二次箭头项恒零，立得双侧精确逆 (3.6)。由于 $C_{0,j}^{-1}$ 与规范顶点 $V_j$ 均与 $P_6$ 对易，词中每个因子皆具“块对角算符＋单向箭头”形式（显式分块下三角乘法见附录 A.2 式 (A.4)）。保持原有乘法次序将整串有限乘积展开：凡含两枚及以上单向箭头的项，相邻两枚箭头之间只隔着块对角算符，由式 (3.5) 第一式恒等于零；恰含一枚单向箭头的全部项之和记为 $N_W$，由式 (3.5) 第二式仍为单向箭头；不含箭头的唯一项恰为 $W_0$。最后对 $W=W_0+N_W$ 取有限维矩阵迹，由 $\operatorname{tr}N_W=0$ 即得 $\operatorname{tr}W=\operatorname{tr}W_0$。□

手征反常的线性发散三角图中，动量路由与正规化决定 Ward 恒等式的表面项 [[9]](#ref-9), [[10]](#ref-10)。定理 3.2 在固定各腿动量和谱参数的 252 维有限纤维上计算矩阵迹，保留不同顶点的顺序并适用于任意有限词长。

<a id="cor-3-3"></a>

**推论 3.3（单向标量插入闭迹与双插入开放链归零）。** 对母作用全部 $70$ 个实标量微扰方向生成的单向耦合顶点 $Y_a$（$a=1,\ldots,70$）及任意合法有序规范词 $W,W_L,W_R$，恒有

\[
 \operatorname{tr}(W_LY_aW_R)=0,\qquad
 Y_a W Y_b=0\quad\text{作为开放算符恒等式}. \tag{3.8}
\]

**证明。** 每个原始标量微扰顶点 $Y_a$ 均满足式 (3.4) 的单向箭头条件。将定理 3.2 的分解 $W=W_0+N_W$ 代入 $Y_a W Y_b$，由 $Y_a W_0 Y_b=0$ 与 $Y_a N_W Y_b=0$（式 (3.5)）立得开放算符恒为零；同理 $W_L Y_a W_R$ 展开后含一枚箭头的项仍为单向箭头（迹为零），含两枚箭头的项本身为零，故闭迹恒为零。该结论一次覆盖全部 $70^2=4,900$ 对同向双标量插入，已在固定源 `T` 中经形式化证明与穷举核查双重签收。□

### 3.3　成对反向控制：非零规范闭迹、非零开放差与厄米折返

推论 3.3 的零化绝不意味着母作用的规范闭迹平庸，更不意味着开放算符本身没有单向跃迁。以下三项反向控制精确划定其边界：

1. **双规范顶点闭迹真实非零。** 在附录 A.1 的原顶点枚举中取第一枚规范顶点（$A_0$ 上的 $A_{01}$）作用两次，两条传播腿分别固定为
   \[
    (k_1,z_1)=(0,1+2i),\qquad
    (k_2,z_2)=((0,0,3\sqrt2/2),3+i).
   \]
   直接代入式 (3.1) 的完整 Dirac 逆作精确有理运算，其闭迹为五十三位分子分母的非零高斯有理数：
   \[
    \operatorname{tr}W=
    \frac{\begin{gathered}-95360266467327071496720412359528906607208738863660800\\
    -53185433068294844818992564133304778477617846100000000\,i\end{gathered}}
    {15868525877183800686561094790721538271497991716304161}\ne0. \tag{3.9}
   \]
2. **闭迹相等不蕴涵开放算符相等。** 在同一顶点库中构造另一枚含三个规范顶点的合法有序词，其闭迹虽因对称性相消为零，但开放单向余项 $N_W=W-W_0$ 作为 $252\times 252$ 算符严格非零。
3. **人为改用厄米伴随将打开反向通道。** 对背景单向时间项 $N$，取其复共轭转置 $N^\dagger$ 后直接计算迹可得
   \[
    \operatorname{tr}(N^\dagger N)=\frac{1296}{125},\qquad
    \operatorname{tr}(N+N^\dagger)^2=\frac{2592}{125}. \tag{3.10}
   \]
   原因在于 $N^\dagger=(I-P_6)N^\dagger P_6$ 从 $\Lambda^6$ 扇区反向折回低次外幂，不再满足单向条件 (3.4)。因此式 (3.10) 与式 (3.8) 评价的是两类完全不同的物理词：把独立对偶下的单向标量顶点替换成厄米对称化读出算符，等价于在物理上人为增设了一条反向返回跃迁。

## 4　二次量子化制备态整词评价：开放返回 $-1$ 与中途投影伪零（Q2）

在闭合时间路径（in-in）量子动力学 [[11]](#ref-11), [[12]](#ref-12) 中，实验探针读取的不是全空间算符迹 $\operatorname{tr}W$，而是系统处于特定初始制备态时整串二次量子化算符词的实时期望。本节在 252 模反对称 Fock 空间 $\mathcal F_-(\mathcal M)$ 上建立整词末端评价规则 [[13]](#ref-13)，并展示为何在乘积中途插入秩一态投影会抹杀真实的开放跃迁。

### 4.1　单位制备态、边界权矩阵 $K$ 与完整 Fock 词读回

背景解生成的单位占据制备态 $w\in\mathcal M$ 完全落在 $\Lambda^2\mathbb C^7$ 扇区内，满足 $P_6w=0$；于是对任意单向箭头 $N_a$，因 $N_aw=P_6N_aw$ 与 $w$ 正交，必有 $\langle w,N_aw\rangle=0$。一般余标架 $e$ 上的实时间边界权算符定义为

\[
 K_e=-i|\det e|\sqrt2\,S C_0(e),\qquad K=\sqrt2\gamma_5 \text{ 于本背景}. \tag{4.1}
\]

显然 $[K,P_6]=0$。结合定理 3.2 的式 (3.7)，任意合法有序规范词 $W$ 在单位制备态下的无权与 $K$-加权期望同时简化为自由块对角部分：

\[
 \langle w,Ww\rangle=\langle w,W_0w\rangle,\qquad
 \langle w,KWw\rangle=\langle w,KW_0w\rangle. \tag{4.2}
\]

令费米子反对称 Fock 空间为 $\mathcal F_-({\mathcal M})=\bigoplus_{r=0}^{252}\Lambda^r\mathcal M$，单粒子等距嵌入记作 $J_1:\mathcal M\to\mathcal F_-$。单粒子算符 $A$ 的二次量子化提升 $d\Gamma(A)$ 在每个 $r$-粒子扇区按导子律逐槽作用 [[13]](#ref-13)。对任意有限有序算符序列 $A_1,\ldots,A_m$，整词乘积满足

\[
 \mathbb W=d\Gamma(A_1)\cdots d\Gamma(A_m),\qquad
 \mathbb WJ_1v=J_1(A_1\cdots A_m)v. \tag{4.3}
\]

<a id="prop-4-1"></a>

**命题 4.1（二次量子化完整 Fock 词的单位制备态读回）。** 先在 $\mathcal F_-(\mathcal M)$ 上完成整词乘积 $\mathbb W$，再在两端施加单粒子制备态 $J_1w$，所得期望严格等于母独立对偶配对读数：

\[
 \langle J_1w,\mathbb WJ_1w\rangle
 =\Omega(J_1^\dagger\mathbb WJ_1)
 =\langle w,A_1\cdots A_mw\rangle. \tag{4.4}
\]

若在左端并入 $d\Gamma(K)$，则给出对应的 $K$-加权整词读数。

**证明。** 由单粒子扇区恒等式 $d\Gamma(A)J_1=J_1A$ 对词长 $m$ 作数学归纳立得式 (4.3) 第二式；再由 $J_1^\dagger J_1=I_{\mathcal M}$ 与式 (2.6) 的末端配对恒等式即得式 (4.4)。注意在多粒子扇区上 $\mathbb W$ 一般并不等于单一导子 $d\Gamma(A_1\cdots A_m)$；对于第 13–14 节包含显式产生与湮灭算符的完整配置空间词，必须先在完整多体 Fock 空间完成有序算符乘积，最后施加态评价泛函，绝不能对改变粒子数的中间因子套用式 (4.3)。□

以自旋翻转诱导的检验算符 $T_S=-iC_0^{-1}S$ 为例，直接代入式 (4.1) 可见边界权读数与裸迹的分立：

\[
 KT_S=-N\sqrt2 I,\qquad
 \langle w,KT_Sw\rangle=-N\sqrt2=-\frac{6\sqrt{15}}{25}, \tag{4.5}
\]

而同一算符的全载体裸迹却是 $-252N\sqrt2$。一般地，对母作用导出的耦合顶点 $V$，置推动生成元 $T=-iC_0^{-1}V$、流读出算符 $B_V=-KT$，则经典背景振幅 $\psi_0=2w$（振幅平方因子为 $4$）下的体积电流制备读数恰为 $4\langle w,B_Vw\rangle$；此处 252 维全空间权矩阵固定为 $\sqrt2\gamma_5$，不可提前替换为共转荷 $Q=\gamma_5+2P_6$。

### 4.2　开放标量返回读数 $-1$ 与中途秩一投影的伪零效应

如例 1.1(a) 已手算验证，单位制备态 $w$ 的四个非零分量按“自旋指标；$\Lambda^2$ 升序基”记为

\[
 w_{0;15}=\tfrac12,\quad w_{1;05}=-\tfrac12,\quad
 w_{2;15}=\tfrac12,\quad w_{3;05}=-\tfrac12. \tag{4.6}
\]

取原始标量方向 $\delta\phi=e_{0234}$，令行泛函 $r$ 读取自旋 $2$ 中 $\Lambda^6$ 基元 $e_{012345}$ 的坐标，记 $Y=Y_{\delta\phi}$。由式 (2.3) 楔积的五次逆序负号得 $rY(2w)=-1$。构造显式开放返回读出算符 $R=2wr$，即有

\[
 RYw=-w,\quad \langle w,RYw\rangle=-1,\qquad
 \langle w,R P_wYw\rangle=0,\quad P_w=|w\rangle\langle w|. \tag{4.7}
\]

式 (4.7) 清晰揭示了“期望为零”与“物理输出为零”的本质差别：$Y$ 将初态 $w$ 真实跃迁至正交扇区 $P_6\mathcal M$，因此单次期望 $\langle w,Yw\rangle=0$；显式返回读出算符 $R$ 捕捉到这一开放输出并报出 $-1$，但若在 $R$ 与 $Y$ 之间强行插入秩一投影 $P_w$，正交分量在返回前即被截断，读数瞬间塌缩为伪零 $0$。

对全部 $70$ 个实标量方向的系统清点进一步证实：其中恰有 $18$ 个方向满足开放输出 $Y_aw\ne 0$，尽管单向制备期望恒为零；当改用厄米对称化的实标量力读出算符时，双标量连通阵列出现 $36$ 个严格非零读数。同样，合法规范词也严禁中途插入秩一投影 $P_w$：在源认证生成的 $16$ 个基准双规范整词中，中途插入 $P_w$ 会直接篡改其中 $6$ 个词的精确数值。

### 4.3　推迟传播可逆域与连续空间滤波制备

在实空间连续动量纤维上，自由块对角生成元 $H_0(p)$ 自伴，故在上半复能量平面 $z=E+i\eta$（$\eta>0$）上恒具双侧有界预解逆；定理 3.2 的式 (3.6) 随即无条件将其提升为含单向项 $Y_R$ 的完整 Dirac 逆。在手征分块下，该双侧逆显式写为

\[
 D=\begin{pmatrix}0&A\\B&Y_R\end{pmatrix},\qquad
 D^{-1}=\begin{pmatrix}-B^{-1}Y_RA^{-1}&B^{-1}\\ A^{-1}&0\end{pmatrix}, \tag{4.8}
\]

左右直接相乘即验证式 (4.8) 并唯一锁定左下角单向交叉项 $-B^{-1}Y_RA^{-1}$ 的顺序。当把有限维占据态提升为三维实空间波包制备态时，源生 Dirac 滤波器 $R=G_D(i)$ 只在可观测算符 $A$ 的最外侧两端各作用一次：设空间球嵌入为 $e=Ew$，固定滤波范数 $n=\|Re\|>0$，则连续制备读数为

\[
 \Omega(E^\dagger R^\dagger A R E)/n^2
 =\langle\psi,A\psi\rangle,\qquad \psi=Re/n. \tag{4.9}
\]

此处归一化常数 $n$ 仅由固定初始球嵌入 $e$ 决定，不随内部被测算符 $A$ 或外加动量微扰重新归一，亦不在相邻算符因子之间重复插入滤波器。第 6 节的全部实时间连续复 Gram 矩阵均由式 (4.9) 统一生成。

## 5　费米子 Schur 补有效玻色算子、全场回写与五维原点轻核（Q3）

现在进入图 1 下支路的第一步：母作用围绕九场经典解展开共有 289 个实场方向，物质与玻色自由度深度耦合。若像传统有效场论协变导数展开（CDE）[[14]](#ref-14), [[15]](#ref-15), [[16]](#ref-16) 那样按重质量幂次作渐近局部截断，不仅会丢失有限动量极点，而且消元后的近似场无法代回原 289 行耦合场方程。本节在共同块可逆域内建立无损代数消元链 $289\to 103\to 55$，证明一次费米子 Schur 补 [[18]](#ref-18) 连同外源商—逆转置映射逐符号恢复全部 289 行母方程，并在原点奇异处分离出同时支配线性与二次时间尺度的五维轻核。

### 5.1　$289\to 103$ 受约束无损消元：消去冗余坐标，保留全部方程责任

在共转坐标下，九组原场的 289 个实活跃分量由 $16$ 个余标架、$24$ 个 Lorentz 自旋联络、$36+36$ 个引力辅助场 $(B_{\mathrm{gr}},\lambda)$、$48$ 个规范联络、$72$ 个规范辅助二形式 $B_g$、$9$ 个标量轨道方向以及各 $24$ 个活跃物质与独立对偶方向组成。记母作用密度 (2.4) 的实二次变分 Fourier–Euler 矩阵为 $H_{289}(p)$（第 12.1 节将在全部 $p\in\mathbb C^4$ 上形式化证出它与一阶射流二阶 Fréchet 导数的逐项全等）。

二阶变分中的纯代数辅助场方程 [[20]](#ref-20) 直接给出

\[
 B_g=-\sigma^{-1}*_eF_A,\quad
 \delta B_g=K_g^{-1}(\delta F_A-\delta K_g\,B_{g,0}),
 \quad\delta B_{\mathrm{gr}}=J\delta\Sigma_e,\quad
 \delta\lambda=J\delta B_{\mathrm{gr}}-\delta\widehat F_\omega. \tag{5.1}
\]

注意式 (5.1) 第二式中 $K_g$ 为原辅助场方程乘 $B_g$ 的本构线性算符：当余标架 $e$ 发生微扰时，Hodge 映射 $*_e$ 随之变化产生 $\delta K_g\,B_{g,0}$ 耦合项，绝不能将度规背景冻结。依次精确消去 $72+72$ 个引力与规范辅助坐标、$24$ 个 Lorentz 联络坐标、$9$ 个标量势力矩 Ward 轨道方向及 $9$ 个源对称规范方向（$3$ 个颜色 $\mathrm{SU}(2)$ 加 $6$ 个局域 Lorentz 生成元），维数链严格降为

\[
 289\longrightarrow217\longrightarrow145\longrightarrow121
 \longrightarrow112\longrightarrow103. \tag{5.2}
\]

每一步均同步保存场重构解图与外源协向量的逆转置回写映射。这里有一项关键反向控制：前两步辅助场消元不改变物质子块，但第三步消去 $24$ 个实 Lorentz 自旋联络方向时（对应一阶自旋—挠率代数接触项），精确改写了物质块中的 $128$ 个矩阵元；倘若跳过自旋联络消元而直接对裸自由物质块求逆，所得算子将偏离真实母作用动力学。

### 5.2　一次费米子反馈、有理玻色算子 $S_{55}$ 与全 289 行符号回写

将所得 $103$ 维系统按玻色坐标 $b\in\mathbb C^{55}$ 与活跃物质及独立对偶坐标 $m\in\mathbb C^{48}$ 分块，并取一次物质 Schur 补 [[18]](#ref-18)：

\[
 K_{103}=\begin{pmatrix}K_{bb}&K_{bm}\\K_{mb}&M\end{pmatrix},
 \qquad W=-M^{-1}K_{mb},\qquad
 S_{55}=K_{bb}-K_{bm}M^{-1}K_{mb}. \tag{5.3}
\]

<a id="def-5-1"></a>

**定义 5.1（两种消元次序的共同块可逆域）。** 记先消辅助场再消物质与先消物质再消辅助场的共同比较域为：总辅助块 $A_{\mathrm{aux}}$、原物质块 $D_{\mathrm{mat}}$ 以及两个 Schur 补块 $D_{\mathrm{mat}}-CA_{\mathrm{aux}}^{-1}B$ 与 $A_{\mathrm{aux}}-BD_{\mathrm{mat}}^{-1}C$ 同时双侧可逆的复动量参数集（式 (5.3) 本身仅需消元后 $48\times 48$ 块 $M$ 可逆）。该共同域非空：例如有理采样点 $u=\frac35(1-3i),q_{\mathrm{ax}}=\frac3{10}$ 处两套消元路径涉及的全部子块皆具精确双侧逆。

<a id="thm-5-2"></a>

**定理 5.2（一次物质 Schur 反馈算子 $S_{55}$ 与全 289 行场—外源逐符号回写）。** 在定义 5.1 的共同可逆域上，两种合法消元次序给出完全相同的有理玻色算子 $S_{55}$。且存在由各步场解图复合而成的重构矩阵 $F\in\mathbb C^{289\times55}$，以及由外源商映射与逆转置复合而成的源提升矩阵 $J_{\mathrm{src}}\in\mathbb C^{289\times55}$，使得多项式—有理矩阵恒等式

\[
 H_{289}F=J_{\mathrm{src}}S_{55} \tag{5.4}
\]

逐分量精确成立。特别地，凡在 $S_{55}R_{55}=I_{55}$ 处，令 $x=FR_{55}j$ 即精确满足全部 $289$ 行原始耦合线性化场方程 $H_{289}x=J_{\mathrm{src}}j$。

**证明。** 分块消元的核心难点不在于回写场向量 $F$，而在于不把 $H_{289}F$ 强行定义为源的前提下独立构造源提升 $J_{\mathrm{src}}$。对任意可逆左上块 $A$，分块高斯消元恒等式给出

\[
 \begin{pmatrix}A&B\\C&D\end{pmatrix}
 \begin{pmatrix}-A^{-1}B\\I\end{pmatrix}
 =\begin{pmatrix}0\\D-CA^{-1}B\end{pmatrix}. \tag{5.5}
\]

沿式 (5.2) 顺序复合各步解图（含 $m=Wb$ 与辅助场解图）即得 $F$；外源侧则从 $112\to 103$ 商投影 $Q$ 的伴随转置 $Q(-p)^T$ 出发，逆向逐步补回 Ward 标量轨道与辅助场行，独立生成 $J_{\mathrm{src}}$。对任意相邻两个可逆子块，一步总消元与分两步消元经 Banachiewicz–Woodbury 块逆恒等式给出完全一致的剩余 Schur 算子，归纳复合即证得式 (5.4)。□

在回写至 289 维的外源 $J_{\mathrm{src}}$ 中，包含 $32$ 个形如 $-T_{\mathrm{other}}(-p)^TJ_{112}$ 的非零 Ward 标量源补偿条目；人为删去这 32 个条目立即破坏式 (5.4)。同时须明确物理归属：母作用中经典背景物质与规范／引力场的线性化电流耦合已在 $K_{bm},K_{mb}$ 中精确在场，式 (5.3) 将这一线性化物质反馈不重不漏计入一次，它不是额外叠加的一圈真空泛函行列式 $\operatorname{Tr}\log$ [[16]](#ref-16)。

### 5.3　动量原点奇异性分解：42 个重物质方向与 6 个轻物质方向

在四动量原点 $p=0$ 处，物质块 $M_0=M(0,0)$ 退化不可逆，故有理式 (5.3) 不能直接代入原点。精确有理秩与主子式计算给出

\[
 \operatorname{rank}M_0=42,\qquad
 \det M_{hh,0}=
 -\frac{58990238851842729101108654352661116616704}
 {9094947017729282379150390625}\ne0. \tag{5.6}
\]

这一定量分解对应 Appelquist–Carazzone 低动量重场分离 [[17]](#ref-17) 的精确代数版本：以可逆 $42\times 42$ 重物质主块 $G_0=M_{hh,0}^{-1}$ 消去重方向后，原点处 $6$ 个轻物质零模的完整 48 维嵌入矩阵为

\[
 E_6=\begin{pmatrix}-G_0M_{h\ell,0}\\I_6\end{pmatrix},\qquad M_0E_6=0. \tag{5.7}
\]

注意 $6$ 个保留坐标轴本身并不直接落在 $M_0$ 零空间内，必须携带式 (5.7) 上半部的重场伴随修正 $-G_0M_{h\ell,0}$。记动量微扰为 $M_{hh}=M_{hh,0}+\Delta$，则在收敛域 $\|G_0\Delta\|<1$ 内有精确预解展开

\[
 M_{hh}^{-1}=G_0-G_0\Delta G_0+G_0\Delta G_0\Delta G_0
 -(G_0\Delta)^3M_{hh}^{-1}. \tag{5.8}
\]

将多项式按动量总次数截断至二阶，即得 $55$ 个玻色坐标与 $6$ 个轻物质坐标组成的 $61$ 维二阶有效系统，其截断余项范数严格受控于 $\|G_0\Delta\|^3\|G_0\|/(1-\|G_0\Delta\|)$；代回全 289 行母方程检验时，一、二阶残差恒为零，三阶残差真实非零（第 12 节将进一步给出不作截断的全四复动量精确 Schur 核与显式三阶系数界）。

### 5.4　五维原点轻核与线性—二次双时间尺度

<a id="thm-5-3"></a>

**定理 5.3（五维原点轻核与线性—二次双动量时间尺度）。** 上述 $61$ 维二阶有效系统的零动量常数矩阵秩恰为 $56$。进一步消去 $56$ 个玻色—轻物质混合重常项方向后，得到五维原点轻核；该二阶核与从 $103$ 维系统一次性消去对应 $98$ 个重方向所得结果逐项全等（保留坐标原编号为 $94,100,106,112,118$，各携完整重场恢复解图）。

沿背景 $(\psi_0,\chi_0)$ 的五条对称／对偶微扰路径——实振幅反向重标、总相位反向旋转、轴矢实重标、轴矢相位旋转与独立对偶纯虚变分（显式式见附录 B 式 (B.3)）——构造五维自然基（到保留坐标的基变换行列式为 $4$）。在该自然基下，五维轻核的一阶动量项仅有一对反对称时间耦合元非零（下标取 $1,\ldots,5$）：

\[
 (K_1)_{35}=-8u,\qquad (K_1)_{53}=8u, \tag{5.9}
\]

完整二阶矩阵 $K_2$ 列于附录 B 式 (B.1)–(B.2)；限制在一阶核的三维子空间上，二阶主部呈精确对角形：

\[
 \operatorname{diag}\left(
 \frac{16}{9}(5q_{\mathrm{ax}}^2+3u^2),
 \frac{32}{737}(55q_{\mathrm{ax}}^2+67u^2),
 \frac{20}{81}(125q_{\mathrm{ax}}^2-162u^2)\right). \tag{5.10}
\]

**证明与双尺度色散导出。** 常数矩阵秩 $56$ 由显式 $56\times 56$ 可逆主块及五列零空间解图直接认证；分步降维（$103\to 61\to 5$）与一步降维（$103\to 5$）在 $1,u,q_{\mathrm{ax}},u^2,uq_{\mathrm{ax}},q_{\mathrm{ax}}^2$ 六个系数矩阵上逐元相等。在双曲重标 $(u,q_{\mathrm{ax}})\mapsto(tu,tq_{\mathrm{ax}})$ 下直接展开五阶行列式，首项极限为

\[
 \lim_{t\to0}\frac{\det K(tu,tq_{\mathrm{ax}})}{t^8}
 =\frac{655360}{537273}u^2(5q_{\mathrm{ax}}^2+3u^2)
 (55q_{\mathrm{ax}}^2+67u^2)(125q_{\mathrm{ax}}^2-162u^2), \tag{5.11}
\]

（转回保留坐标仅乘基变换行列式平方 $16$）。式 (5.11) 的三个非退化二次因子给出三条线性声锥／传播前锋（换回物理变量 $\lambda=N\sqrt2\,u,k_3=\sqrt2\,q_{\mathrm{ax}}$）：

\[
 \frac{\lambda^2}{k^2}=-\frac{18}{25},\quad
 -\frac{594}{1675},\quad \frac13. \tag{5.12}
\]

而式 (5.11) 前端的二重根因子 $u^2$ 则隐藏着由一阶反对称项 (5.9) 驱动的**二次慢时间尺度**：令 $u=\varsigma q_{\mathrm{ax}}^2$，指标 $(3,5)$ 对应的二阶子块化为 $\left(\begin{smallmatrix}-40/3&-8\varsigma\\8\varsigma&-10/3\end{smallmatrix}\right)$，五维完整行列式的 $q_{\mathrm{ax}}^{10}$ 首项系数为

\[
 \frac{512000000}{439587}(36\varsigma^2+25), \tag{5.13}
\]

解得慢支路根 $\varsigma=\pm 5i/6$，对应低动量二次色散 $\lambda^2/k^4=-3/20$。同一五维原点轻核由此内生统一了线性传播锥与二次色散支路；有限非零动量处的精确极点则须回到未截断的完整六次因子（附录 B 式 (B.4) 与附录 C.1）。□

### 5.5　动态度规 $g_{00}$ 源注入与射线方向依赖的原点极限

考察时间度规分量微扰 $\delta g_{00}=-2N\,\delta e_{00}$。在作用量附加 $+J_{00}\delta g_{00}$ 的符号约定下，受迫响应场等于负逆作用于源；若改写为标准算子方程 $Hx=J$，则保持正号，场解图 $F$ 与源提升 $J_{\mathrm{src}}$ 自动对齐两种记法。

对动态 $g_{00}$ 外源注入，先解约化后的 $25$ 维耦合系统，再精确回写 $33$ 维独立对偶分量与全部 $289$ 场，得到精确有理格林响应。令频率沿固定射线 $u=rq_{\mathrm{ax}}$ 趋向原点，有理极限为

\[
 \lim_{q_{\mathrm{ax}}\to0}G_{00}(rq_{\mathrm{ax}},q_{\mathrm{ax}})
 =\frac{54\sqrt{30}(297r^2-125)}{3125(162r^2-125)},
 \quad r^2\ne\frac{125}{162}. \tag{5.14}
\]

其纯静态极限（$r=0$）为 $18N/125$，纯时间齐次极限（$r\to\infty$）则为 $33N/125$：二元原点 $(0,0)$ 处不存在与趋近方向无关的单一极限值。在式 (5.10) 的三维主核分解中，$g_{00}$ 读出行与注入列分别为 $(0,0,-36u/25)$ 与 $(0,0,+36u/25)$，所激发的轴向轻相位模态为

\[
 \theta=\frac{729u}{125(125q_{\mathrm{ax}}^2-162u^2)}. \tag{5.15}
\]

将接触常数 $18N/125$ 与动态极点项 $\frac{486Nu^2}{25(162u^2-125q_{\mathrm{ax}}^2)}$ 相加即得式 (5.14)，从而在 $g_{00}$ 读数中识别轴向极点。Luttinger 区分了时间度规势响应的空间齐次与静态极限 [[31]](#ref-31)。Weldon 展示了相对论等离子体的静态筛选和长波集体响应，其传播等离子模有频率阈值 [[32]](#ref-32)。本文零温余标架 $e=\operatorname{diag}(N,1,1,1)$ 与源内五维核给出无隙实轴增长支 $u^2=\frac{125}{162}q_{\mathrm{ax}}^2$（图 2）。

![图2：五维原点轻核的双时间尺度色散谱与动态度规射线极限。](figures/fig06-light-kernel-v2.svg)

**图 2　五维原点轻核的双时间尺度色散谱与动态度规射线极限。** 左：由附录 B 精确 $5\times 5$ 矩阵核式 (B.1)–(B.2) 导出的四条原点领先色散律（式 (5.11)–(5.13)）——包含两条振荡线性快锥 $|\operatorname{Im}u|=\sqrt{5/3}\,q_{\mathrm{ax}},\,\sqrt{55/67}\,q_{\mathrm{ax}}$、与动态度规直接耦合的实增长锥 $u=\sqrt{125/162}\,q_{\mathrm{ax}}$（朱红），以及由一阶反对称耦合 $K_1$ 驱动的二次慢支路 $|\operatorname{Im}u|=\frac56q_{\mathrm{ax}}^2$（金色）。右：动态度规响应 $G_{00}(rq_{\mathrm{ax}},q_{\mathrm{ax}})/N=\frac{18(297r^2-125)}{125(162r^2-125)}$ 随原点趋近射线斜率 $r=u/q_{\mathrm{ax}}$ 的精确双支函数曲线（式 (5.14)–(5.15)），清晰分离静态筛选极限 $18/125=0.144$（$r=0$）、无隙实轴极点 $r_*=\sqrt{125/162}\approx 0.878$ 与空间齐次渐近值 $33/125=0.264$（$r\to\infty$）。

## 6　12 维占据态实时间演化、Sylvester 电流预解核与复 Gram 分解

要把第 5 节的有效玻色传播算子接到真实的量子探针读数上，不能停留在 $t=0$ 的静态矩阵元，而必须追踪三维位置球滤波制备态 $\psi\in L^2(\mathbb R^3,\mathbb C^{12})$ 在全实时间幺正演化 [[2]](#ref-2) 下的电流算符双时间自关联与微扰响应 [[27]](#ref-27)。本节给出该 12 维约化子空间上的精确滤波核、外加规范余弦微扰下的算子 Sylvester 频域核 [[28]](#ref-28), [[29]](#ref-29) 以及固定制备态下的 `raw = mean + connected` 正交分解 [[7]](#ref-7)。

### 6.1　位置球 Dirac 滤波制备与全空间秩一投影 $P$

单位半径位置空间球嵌入及经谱点 $i$ 处 Dirac 预解滤波后的归一化制备态定义为

\[
 e(x)=\frac{\mathbf1_{|x|\le1}}{\sqrt{4\pi/3}}w,\qquad
 \widehat\psi(p)=\frac{f(p)b(|p|)}n,\quad
 f(p)=i(i-H(p))^{-1}C_0^{-1}w, \tag{6.1}
\]

其中球面 Fourier 变换核为 $b(r)=4\pi(\sin r-r\cos r)/(r^3\sqrt{4\pi/3})$，归一化平方为 $n^2=\int\|f(p)b(|p|)\|^2d^3p/(2\pi)^3$。由第一案 [[2]](#ref-2) 定理 7.1 已证，占据态所在的 $12$ 复维子空间 $\mathcal H_{12}=\mathbb C^4\otimes\operatorname{span}\{e_{05},e_{15},e_{25}\}$（等距嵌入记作 $F_{12}:\mathcal H_{12}\to\mathcal M$）是全 252 维自由生成元的双侧约化不变子空间：单向外幂楔积 $Y_R$ 在全空间虽非零，但其在 $\mathcal H_{12}$ 上的双侧压缩 $F_{12}^\dagger Y_R F_{12}$ 恒为零。在 $\mathcal H_{12}$ 上，动量纤维哈密顿量 $H(p)=H_0+\sum p_jH_j$ 严格自伴，与边界权 $K$ 对易 $[K,H(p)]=0$，且满足

\[
 \left(\sum p_jH_j\right)^2=N^2|p|^2I,\qquad K^2=2I. \tag{6.2}
\]

将颜色指标 $0,1$ 上的生成元 $\tau_j$ 补零扩为 $3\times 3$ 矩阵后，未减共转相位 $\omega_0Q$ 的原时间纤维矩阵显式为

\[
 H(p)=\frac{3N\sqrt2}{2}(\gamma_5\otimes I_3)
 +Na\sum_{j=1}^3 i\gamma^0\gamma^j\otimes\tau_j
 -N\sum_{j=1}^3p_j\gamma^0\gamma^j\otimes I_3.
\]

记手征算符 $Q=K/\sqrt2$ 及 $G_0=C_0^{-1}/(iN)$。对每个手征扇区 $\chi=\pm1$，种子向量 $s_\chi=(I+\chi Q)G_0w/2$ 与动量伴随向量 $t_\chi=(\chi H-\omega_0)s_\chi/N$ 满足闭二元不变关系：

\[
 \|s_\chi\|^2=\tfrac12,\quad
 \langle s_\chi,t_\chi\rangle=0,\quad
 \|t_\chi\|^2=|p|^2/2,\quad
 Hs_\chi=\chi(\omega_0s_\chi+Nt_\chi),\quad
 Ht_\chi=\chi(N|p|^2s_\chi+3\omega_0t_\chi). \tag{6.3}
\]

当 $r=|p|>0$ 时，$(\sqrt2s_\chi,\sqrt2t_\chi/r)$ 构成标准正交基，并在该基下把 $H(p)$ 化为 $2\times 2$ 实对称块 $\chi\left(\begin{smallmatrix}\omega_0&Nr\\Nr&3\omega_0\end{smallmatrix}\right)$；在 $p=0$ 处 $t_\chi=0$ 退化，但直接用未除 $r$ 的多项式向量写出的滤波核在全空间 $\mathbb R^3$ 上光滑正则：

\[
 f(p)=-N\sum_{\chi=\pm1}
 \frac{(i-3\chi\omega_0)s_\chi+\chi Nt_\chi}
 {(i-\chi\omega_0)(i-3\chi\omega_0)-N^2|p|^2}, \tag{6.4}
\]

其分母虚部恒为 $-4\chi\omega_0\ne 0$，故对一切实三维动量无奇点。

单位位置球指示函数自身卷积的径向重叠核为 $1-\frac34r+\frac1{16}r^3$（$0\le r\le2$）。定义初等指数矩函数

\[
 J(\kappa)=\int_0^2(r-3r^2/4+r^4/16)e^{-\kappa r}\,dr
 =\frac{2\kappa^3-3\kappa^2+3-3(\kappa+1)^2e^{-2\kappa}}{2\kappa^5}, \tag{6.5}
\]

置复衰减波数 $\kappa^2=(1-3\omega_0^2+4i\omega_0)/N^2$（取主支 $\operatorname{Re}\kappa>0$）与 $Z=(i-3\omega_0)J(\kappa)$。对式 (6.4) 完成球面全角积分与径向留数积分后，得到滤波归一化平方与零动量相位流均值：

\[
 n^2=\operatorname{Im}Z\simeq0.208904454900,\quad
 \mu_0=\frac{2\sqrt2}{N^2}\frac{\operatorname{Re}Z}{\operatorname{Im}Z}
 \simeq-0.701355479214, \tag{6.6}
\]

\[
 \|A_0\psi\|^2=\frac8{N^2n^2}-\frac8{N^4},\qquad
 \|(A_0-\mu_0)\psi\|^2\simeq45.287036020565, \tag{6.7}
\]

其中 $A_0=2KH/N^2$ 表示零空间动量转移处的原相位电流算符（下标 $0$ 指零动量探针而非规范势时间分量）。自此往后，$P=|\psi\rangle\langle\psi|$ 始终表示整个空间 Hilbert 空间 $L^2(\mathbb R^3,\mathcal H_{12})$ 上的全局秩一投影：既不逐动量切片重投影，也不对 12 维内部纤维作二次截断。

### 6.2　余弦外场 Duhamel 微扰与频域 Sylvester 电流预解核

记空间平面波乘子为 $M_k=e^{ik\cdot X}$。在共同定义域 $\operatorname{Dom}(H)$ 上，动量转移为 $k$ 的原相位电流算符及微扰海森堡演化写为

\[
 A_k=N^{-2}(KM_kH+H^\sharp M_kK),\qquad
 B_{\varepsilon,k}(t)=U_\varepsilon(t)^\dagger A_{\varepsilon,k}U_\varepsilon(t). \tag{6.8}
\]

在 12 维约化子空间上 $H^\sharp=H$；而在全 252 维共同定义域上，$H=H_{\mathrm{free}}+N_Y$ 对应伴随 $H^\sharp=H_{\mathrm{free}}+N_Y^\dagger$（其中 $N_Y=-iC_0^{-1}Y_R$，$N_Y^\dagger=iY_R^\dagger(C_0^{-1})^\dagger$ 保持因子反序）。余弦探针 $\cos(k\cdot X)=\frac12(e^{ik\cdot X}+e^{-ik\cdot X})$ 的每次动量平移各自携带一个半幅因子 $1/2$：

\[
 A_{\cos k}(p_{\mathrm{out}},p_{\mathrm{in}})
 =\frac{KH(p_{\mathrm{in}})+H(p_{\mathrm{out}})^\dagger K}{2N^2},
 \quad p_{\mathrm{out}}=p_{\mathrm{in}}\pm k, \tag{6.9}
\]

它在完整多体 Fock 空间上对应 $\frac2N\operatorname{Herm}[d\Gamma(K)d\Gamma(M_{\cos k}H/N)]$（厄米化作用于整词乘积之后）在单粒子扇区上的精确限制。

固定规范探测方向 $dx^1S_{01}$（采用附录 A.1 未除以 $2$ 的生成元 $S_{01}=2\tau_1$）。由含余标架体积因子的母作用密度顶点导出自伴扰动矩阵：

\[
 V_{252}=-iC_0^{-1}\frac{V_{\mathrm{density}}(1,S_{01})}{N},\qquad
 V=F_{12}^\dagger V_{252}F_{12},\quad V^\dagger=V,\quad [K,V]=0,\quad\|V\|=N. \tag{6.10}
\]

令空间调制扰动为 $W_d=\cos(d\cdot X)V$，受扰生成元为 $H_\varepsilon=H+\varepsilon W_d$。有界自伴扰动保持定义域 $\operatorname{Dom}(H_\varepsilon)=\operatorname{Dom}(H)$ 并生成强连续幺正群 $U_\varepsilon(t)=e^{-itH_\varepsilon}$，其在 $\varepsilon=0$ 处的算子范数 Fréchet 导数 [[2]](#ref-2) 由 Duhamel 积分给出：

\[
 D_d(t)=-i\int_0^tU(t-s)W_dU(s)\,ds. \tag{6.11}
\]

对正负动量支 $\sigma=\pm1$，分离出未乘余弦半幅的纤维核

\[
 d_\sigma(t,p)=-i\int_0^tE_{p+\sigma d}(t-s)V E_p(s)\,ds,\qquad E_p(t)=e^{-itH(p)}, \tag{6.12}
\]

则 $\widehat{D_df}(r)=\frac12\sum_{\sigma=\pm 1} d_\sigma(t,r-\sigma d)\widehat f(r-\sigma d)$，其正半轴 Laplace 变换核为 $-i(z+iH(p+\sigma d))^{-1}V(z+iH(p))^{-1}$ 再乘半幅 $1/2$。

对海森堡电流 (6.8) 求关于 $\varepsilon$ 在 $0$ 处的完整双侧变分，每个外动量转移支 $\sigma=\pm 1$ 包含接触直项与左、右两条演化变分项：

\[
\begin{split}
 C_{\sigma,k}(t,p)={}&E_{p+k+\sigma d}^\dagger\frac{KV}{N^2}E_p\\
 &+\tfrac12d_{-\sigma}(t,p+k+\sigma d)^\dagger A_k(p)E_p\\
 &+\tfrac12E_{p+k+\sigma d}^\dagger A_k(p+\sigma d)d_\sigma(t,p),
 \quad A_k(p)=\frac{K[H(p+k)+H(p)]}{N^2}, \tag{6.13}
\end{split}
\]

其中首项接触直项已计入外场余弦的一次 $1/2$ 因子。引入双动量算子换位子 $\mathcal L_{\ell,r}X=i[H(\ell)X-XH(r)]$：因 $H(\ell),H(r)$ 在 $\mathcal H_{12}$ 上自伴，$\mathcal L_{\ell,r}$ 在 Hilbert–Schmidt 空间上斜自伴，故对一切 $\operatorname{Re}z>0$，Sylvester 预解逆 [[28]](#ref-28), [[29]](#ref-29) $\mathcal R_{z;\ell,r}=(z-\mathcal L_{\ell,r})^{-1}$ 存在且满足 $\|\mathcal R_{z;\ell,r}\|\le 1/\operatorname{Re}z$。于是零阶与一阶电流的 Laplace 变换精确闭式化为

\[
 \widehat B_k(z,p)=\mathcal R_{z;p+k,p}(A_k(p)), \tag{6.14}
\]

\[
 \widehat C_{\sigma,k}(z,p)=\mathcal R_{z;p+k+\sigma d,p}
 \left[\frac{KV}{N^2}+\frac i2\{V\widehat B_k(z,p)-\widehat B_k(z,p+\sigma d)V\}\right]. \tag{6.15}
\]

注意式 (6.14)–(6.15) 是纠缠左右动量谱的算子 Sylvester 逆，绝不能误拆为两个独立单粒子预解逆的普通矩阵乘积。

### 6.3　固定制备态下 `raw`、`mean` 与 `connected` 的正交分解

记三类空间投影算符为 $\Pi_{\mathrm{raw}}=I,\Pi_{\mathrm{mean}}=P,\Pi_{\mathrm{conn}}=I-P$，令投影后电流态矢为 $j^\alpha_k(t)=\Pi_\alpha B_k(t)\psi$ 与 $\zeta^\alpha_{d,k}(t)=\Pi_\alpha C_{d,k}(t)\psi$。定义零阶与一阶双时间 Laplace–Gram 泛函：

\[
 \mathcal N_0^\alpha(k,l;z,w)
 =\int_0^\infty\!\!\int_0^\infty e^{-\bar zt-ws}
 \langle j_k^\alpha(t),j_l^\alpha(s)\rangle\,dt\,ds, \tag{6.16}
\]

\[
 \mathcal N_1^\alpha(d;k,l;z,w)
 =\iint e^{-\bar zt-ws}
 \left[\langle\zeta_{d,k}^\alpha(t),j_l^\alpha(s)\rangle
 +\langle j_k^\alpha(t),\zeta_{d,l}^\alpha(s)\rangle\right]dt\,ds. \tag{6.17}
\]

由 $I=P+(I-P)$ 及 $P(I-P)=0$，恒有精确勾股分解 $\mathcal N^{\mathrm{raw}}=\mathcal N^{\mathrm{mean}}+\mathcal N^{\mathrm{conn}}$。此处与 Abbott 背景场综述 [[7]](#ref-7) 中对真空生成泛函作 Legendre 变换得到的 1PI 有效作用有明确概念分界：这里的 `connected` 是在同一固定非真空空间波包制备态 $|\psi\rangle$ 下扣除量子期望乘积 $\mathcal N_0^{\mathrm{mean}}=\overline{\mu_B(k,z)}\mu_B(l,w)$ 后的量子涨落协方差；由于内积第一槽共轭线性，一般双动量 $(k,l)$ 处的 Gram 值为真复数，左时间指数权重必须取复共轭 $e^{-\bar zt}$。

<a id="prop-6-1"></a>

**命题 6.1（双时间 Laplace–Gram 强积分存在性与幅度导数可交换性）。** 对一切 $\operatorname{Re}z>0,\operatorname{Re}w>0$，由同一空间幺正演化生成的双时间强积分 (6.16)–(6.17) 绝对收敛，且外场幅度 $\varepsilon$ 在 $0$ 处的导数可与无穷双时间积分严格交换次序；在第 9 节使用的有限动量球与频率域上，直至四阶混合动量导数均受初始制备态位置矩的一致可积函数支配。

**证明。** 对 Duhamel 方程迭代两次立得算子范数估计 $\|U_\varepsilon(t)-U(t)\|\le|\varepsilon|N|t|$ 与 $\|U_\varepsilon(t)-U(t)-\varepsilon D_d(t)\|\le\varepsilon^2N^2t^2/2$。置 $\alpha_0=\sqrt2/N^2$、$h=\|H\psi\|$、$a_k=\alpha_0(2h+N|k|)$、$b_0=2\alpha_0N$，则完整电流态矢的一阶变分与二阶余项范数上界分别受控于时间多项式

\[
 z_k(t)=b_0+2Na_k|t|,\qquad
 d_k(t)=2Nb_0|t|+2N^2a_kt^2, \tag{6.18}
\]

双腿内积的 $\varepsilon^2$ 余项不超过 $\varepsilon^2[d_k(t)a_l+a_kd_l(s)+z_k(t)z_l(s)]$。由于对任意 $\eta=\min(\operatorname{Re}z,\operatorname{Re}w)>0$，每个多项式矩 $\int_0^\infty e^{-\eta t}t^m\,dt=m!/\eta^{m+1}$ 有限，控制收敛定理同时保证强积分存在、Fubini 次序交换以及 $\varepsilon=0$ 处幅度求导与积分交换。四阶动量导数的一致控制由附录 D.3 的位置权交换子递推给出（仅需 $\psi$ 与 $H\psi$ 的四阶位置矩，不要求尖球滤波态落在二阶能量域 $\operatorname{Dom}(H^2)$ 内）。□

### 6.4　反向控制：零探针量子源的负定各向同性与中心化变号

先检验最简特例——零动量转移探针 $k=0$。此时全时间恒等式 $B_{\varepsilon,0}(t)=2K(H+\varepsilon W_d)/N^2$ 消去了时间振荡，外动量二阶导数化为

\[
 C''_{ij}\widehat\psi(p)=\frac{2KV}{N^2n}\,
 \partial_{p_i}\partial_{p_j}[f(p)b(|p|)], \tag{6.19}
\]

双时间积分精确坍缩为标量因子 $1/|z|^2$。在固定频率模方 $|z|^2=7776/125$ 上代入式 (6.4)–(6.5) 完成全空间解析积分，得到下表中心值（严格向外有理区间见附录 D）：

| 外动量方向 | `raw` 量子源 Hessian | `mean` 量子源 Hessian | `connected` 量子源 Hessian |
|---|---:|---:|---:|
| \(e_1\) | \(-0.014034767643875352\) | \(-0.021154588614571218\) | \(+0.007119820970695866\) |
| \(e_2, e_3\) | \(-0.014034767643875352\) | \(-0.011031425013252896\) | \(-0.003003342630622456\) |

这张小表揭示了两件关键事实：第一，单看 `raw` 量子源腿，三个方向完全各向同性且严格为负（证实了 §1.1 的判断：不把两条玻色场传播腿加回来，`raw` 绝无可能出现正特征方向）；第二，扣除均值乘积二阶项 $\mu_0\mu''_{ij}$ 后，`connected` 的第一轴符号已从负翻正。而一旦进入非零探针 $k\ne 0$，真正的算子 Sylvester 导数 (6.15) 随时间演化并产生非零虚部（例如右腿二阶 `connected` 值约为 $-0.222877720447-0.018187219957i$），任何用 $t=0$ 静态导数除以 $|z|^2$ 的捷径都会彻底算错。

## 7　双球空间波包下的完整五通道极化组装与零抵消项瞬时核

本节把第 5 节的有效玻色传播与第 6 节的实时间量子电流合拢为完整的双球波包一次极化读数。这里有三道必须正面跨越的数学物理关卡：(i) 从轴向 $g_{00}$ 留数列无角度分母奇异地重构全三维动量传播列；(ii) 用三次顶点的双侧广义 Ward 恒等式 [[21]](#ref-21) 先解出九行补偿源再求扰动传播场；(iii) 在坐标空间卷积中精确分离受扰传播子的 $\delta'_0,\delta_0$ 瞬时分布项——与 Epstein–Glaser 因果分布劈裂中留有待定局部多项式常数 [[5]](#ref-5) 不同，这里的瞬时项系数由母方程高频恒等式与复围道积分唯一锁定，不含任何手加抵消项。

### 7.1　由动态 $g_{00}$ 轻支路无奇异重构全三维空间传播列

记三维动量模方半值为 $T=|k|^2/2$，母系统偶色散六次主因子记作 $\widehat F(U,T)$（全部大整数系数见附录 C.1 式 (C.1)）。置归一化常数与隐式轻根分支条件为

\[
 \begin{gathered}
 c_F=-100383300000000,\quad
 \widehat F(U(T),T)=0,\quad U(0)=0,\\
 U'(0)=\frac{125}{162},\quad
 D(U,T)=\widehat F_U(U,T)/c_F.
 \end{gathered} \tag{7.1}
\]

同一母方程内生生成三列 $289$ 维全三维动量多项式向量 $\mathcal A(k,U,T),\mathcal B(k,U,T),\mathcal Z(k,U,T)$（非零行数依次为 $87,114,56$），满足未取根前的精确代数恒等式

\[
 H_{289}(\lambda,-ik)(\lambda\mathcal A+\mathcal B)
 =(\lambda^2-c^2U)\mathcal Z-\frac{c^2}{c_F}\widehat F(U,T)j_{00}, \tag{7.2}
\]

其中 $j_{00}$ 为第 5.5 节的动态 $g_{00}$ 注入列（非零源分量为 $-2N$）。限制到隐式轻根曲面 $\widehat F(U(T),T)=0$ 上，定义全空间传播列与投影源列：

\[
 F_\lambda(k)=\frac{\lambda\mathcal A(k,U,T)+\mathcal B(k,U,T)}
 {D(U,T)(\lambda^2-c^2U)},\qquad I_0(k)=\frac{\mathcal Z(k,U,T)}{D(U,T)}, \tag{7.3}
\]

则式 (7.2) 右端第二项精确归零，给出全三维动量上的母方程解 $H_{289}(\lambda,-ik)F_\lambda(k)=I_0(k)$（注意 $I_0$ 是该轻极点生成的投影源，不等于原始单点注入 $j_{00}$）。

**构造与证明。** 如何从轴向留数列 $\mathcal V(u,q_{\mathrm{ax}})$ 严格恢复全三维动量而不引入球坐标极轴分母奇点？先按时间谱奇偶性拆出轴向多项式列：

\[
 \mathcal A_{\mathrm{ax}}=-\frac c{c_F}\frac{\mathcal V(u,q_{\mathrm{ax}})-\mathcal V(-u,q_{\mathrm{ax}})}{2u},
 \qquad
 \mathcal B_{\mathrm{ax}}=-\frac {c^2}{c_F}\frac{\mathcal V(u,q_{\mathrm{ax}})+\mathcal V(-u,q_{\mathrm{ax}})}{2}. \tag{7.4}
\]

利用母作用总空间旋转生成元同时运输场列、按逆转置运输源协向量列：由于总角动量 Casimir 算符在这些轴向列上仅含角量子数 $j=0,1,2$ 三个扇区，且各扇区径向依赖恰为 $q_{\mathrm{ax}}^j$ 乘 $(U,T)$ 的多项式，附录 C.2 式 (C.2) 的二次齐次笛卡尔球谐公式遂无任何角度分母地精确还原全三维空间多项式列 $\mathcal A,\mathcal B,\mathcal Z$。将其代回 289 行完整算符 $H_{289}$ 展开即得代数恒等式 (7.2)，代入隐式根并除以非零偏导 $D(U,T)\in[39/40,41/40]$ 立得式 (7.3)。

转换回物理时间域，对应的推迟因果传播核为

\[
 K_0(t,k)=\mathbf1_{t\ge0}
 \frac{\mathcal A\cosh(c\sqrt U\,t)+\mathcal B\sinh(c\sqrt U\,t)/(c\sqrt U)}D, \tag{7.5}
\]

（在 $U=0$ 处取解析延拓值 $\sinh(c\sqrt U\,t)/(c\sqrt U)=t$）。由时间分级系数恒等式 $H_2\mathcal A=H_2\mathcal B=0$、$H_1\mathcal A=\mathcal Z$ 与 $H_0\mathcal A+H_1\mathcal B=0$，立得分布意义下的零过去初值解 $H_{289}K_0=(\mathcal Z/D)\delta_0$，其在收敛半平面 $\operatorname{Re}\lambda>c\sqrt U$ 上的 Laplace 变换恰为式 (7.3)。

### 7.2　双侧三次顶点 Ward 恒等式与九行补偿源的先行求解

固定正相位外加规范平面波微扰 $a_\delta=e^{i\delta\cdot x}dx^1S_{01}$。由线性化曲率与余标架 Hodge 映射先确定规范辅助场的外伴随变分：

\[
 b_{g,1}=-\sigma^{-1}*_eD_A(p_e)a_\delta,\qquad p_e=(0,i\delta). \tag{7.6}
\]

记联合外场微扰列为 $b_1=(a_\delta,b_{g,1})$，先求背景残差 $E_1=H_{289}(p_e)b_1$，再由母作用的规范与局域 Lorentz 对称变换导出微扰对称生成列 $K_1$ 与源曲率修正项 $C_1$。此时母作用的三次相互作用顶点矩阵 $V_\delta$ 满足精确双侧广义 Ward–Takahashi 恒等式 [[21]](#ref-21)：

\[
 V_\delta K(p_{\mathrm{in}})+H(p_{\mathrm{out}})K_1+C_1=0,
 \quad
 K(-p_{\mathrm{out}})^TV_\delta+K_1^TH(p_{\mathrm{in}})+C_1^T=0. \tag{7.7}
\]

对出射动量标签 $K$ 与入射标签 $K+\delta$（置 $p_{\mathrm{out}}=(z,-iK)$），必须**先由右向 Ward 恒等式解出 Noether 补偿源 $I_{1,\delta}$，再求解受扰玻色传播列 $G_{z,\delta}(K)$**：

\[
 K(-p_{\mathrm{out}})^TI_{1,\delta}
 =-K_1^TI_0-C_1^TF_z(K+\delta),\qquad
 H(p_{\mathrm{out}})G_{z,\delta}(K)
 =I_{1,\delta}-V_\delta F_z(K+\delta). \tag{7.8}
\]

附录 C.2 式 (C.3) 证明被截面删去的九个对称方向子式 $\det K_{\mathrm{removed}}=\frac{3\sqrt2}{1000}(18-25k_x^2)$ 在整个动量轻球 $|k|\le B$ 上严格非零：故令其余 $280$ 行的补偿源为零，即可由该九行可逆子式唯一解出 $I_{1,\delta}$，随后在约化截面求解响应场并无损回写全部辅助分量（注意入射轻根 $U$、投影源 $I_0$ 与分母 $D$ 始终取在入射动量 $K+\delta$ 处；额外辅助特解仅在 $72$ 个规范辅助坐标上非零，其余 $96$ 个引力及乘子辅助特解精确为零）。

### 7.3　零抵消项瞬时分布项 $(\delta'_0,\delta_0)$ 的复围道锁定

对式 (7.8) 的完整有理受扰传播解 $G_{\lambda,\delta}(k)$ 作复频率无穷远渐近次数分析：103 维约化行列式的 $\lambda$ 次数恒为 $126$，稀疏耦合位置匹配与代数余子式次数上界共同证明全部九个外源方向回写至 289 维后至多呈 $O(\lambda)$ 线性增长。因此其时间域逆 Laplace 分布精确分解为

\[
 \mathcal G_{k,\delta}
 =P_1(k,\delta)\delta'_0+P_0(k,\delta)\delta_0
 +\mathbf1_{t\ge0}K_1(t;k,\delta). \tag{7.9}
\]

在入射闭球 $|k|\le B$、固定成对入射标架及外动量微扰盒 $\max_i|\delta_i|\le 1/200\,000$ 的共同域上，全部极点严格落在半径 $|\lambda|=\Gamma=5c$ 的圆盘内部，且圆周上行列式下界给出一致范数界 $\|G_\lambda\|_\infty\le C$。由同一个闭围道 $|\lambda|=5c$ 直接给出三项系数：

\[
 P_1=\frac1{2\pi i}\oint\frac{G_\lambda}{\lambda^2}\,d\lambda,\quad
 P_0=\frac1{2\pi i}\oint\frac{G_\lambda}{\lambda}\,d\lambda,\quad
 K_1(t)=\frac1{2\pi i}\oint e^{\lambda t}G_\lambda\,d\lambda, \tag{7.10}
\]

满足导数指数界 $\|\partial_t^mK_1(t)\|_\infty\le5^{m+1}Ce^{75t/16}$；由于探针参数 $\operatorname{Re}z=6c>5c>75/16$，一切正半轴积分绝对收敛。同时，母方程在 $|\lambda|\to\infty$ 处的逐阶系数自动锁定

\[
 H_2P_1=0,\quad H_2P_0+H_1P_1=0,\quad
 H_2K_1(0)+H_1P_0+H_0P_1=0, \tag{7.11}
\]

连同 $H_2K_1'(0)+H_1K_1(0)+H_0P_0=I_1(\infty)$ 精确抵消零过去分布方程中的全部奇异 $\delta$ 残差。与 Epstein–Glaser 局部微扰论在分布劈裂中遗留待定重整化多项式 [[5]](#ref-5) 相比，式 (7.10)–(7.11) 中的瞬时接触矩阵 $(P_1,P_0)$ 完全由母作用有理围道唯一决定，零自由抵消项。

将 $\mathcal G_{k,\delta}$ 与截断在正半轴的量子源电流 $j_+=\mathbf1_{t\ge 0}j$ 作分布卷积，得到

\[
 \mathcal G*j_+=P_1\delta_0j(0)
 +\mathbf1_+[P_1j'+P_0j+K_1*j]. \tag{7.12}
\]

在取 Laplace 变换时，$\widehat{j'}=z\widehat j-j(0)$ 产生的负初值项 $-P_1j(0)$ 恰与式 (7.12) 首项保留的边界脉冲 $+P_1\delta_0j(0)$ 精确抵消，从而完整还原频域乘积 $G_z\widehat j$。左右两条电流腿使用彼此独立的时间变量，变分读出算符按分布分部积分作用，全程不发生同点奇异分布硬乘；一致指数界、强动量导数界与紧动量球支撑共同保证时间积分与三维动量积分可合法交换次序。

### 7.4　完整五通道极化振幅的一般双窗公式

置三维 Fourier 测度为 $d\mu(k)=(2\pi)^{-3}d^3k$，入射球指示函数为 $w_B(k)=\mathbf1_{|k|\le B}$，输出观察球指示函数记作 $w_R$。玻色场与输出读出流统一采用负空间相位约定：在一般输出总动量 $p$ 下，两条玻色腿标签为 $k$ 与 $k-p$，而量子电流探针仍采用正相位乘子 $M_k$。记四动量符号为

\[
 L_z(k)=(\bar z,+ik),\quad R_w(l)=(w,-il),\quad
 r_b=(-\bar z-w,-ip). \tag{7.13}
\]

令 $Q_b(L,R)$ 表示由母作用二次涨落流导出、且已并入规范辅助场 $B_g$ 二阶本构回写的双线性读出矩阵，$Q'_{b,\delta}$ 表示该读出矩阵对外加规范场的一次变分（对 $\delta=\sigma d,l=k-p+\delta$ 满足四动量守恒 $L+R+(0,i\delta)+r_b=0$）。以 $\langle Fj,QGj'\rangle$ 表示 289 维场指标 $Q$-缩并与 12 维物质 Hilbert 空间内积的张量配对（第一槽共轭线性），代入第 6.3 节各扇区投影后的 Laplace 态矢 $j,\zeta$，五条极化通道的被积核依次为：

\[
\begin{aligned}
 \Phi_{R\sigma}(k)&=\langle F_z(k)j_z(k),
 Q_b(L_z(k),R_w(k-p))G_{w,\delta}(k-p)j_w(l)\rangle,\\
 \Phi_{L\sigma}(k)&=\langle G_{z,-\delta}(k+\delta)j_z(k),
 Q_b(L_z(k+\delta),R_w(l))F_w(l)j_w(l)\rangle,\\
 \Phi_{C\sigma}(k)&=\langle F_z(k)j_z(k),
 Q'_{b,\delta}(L_z(k),R_w(l))F_w(l)j_w(l)\rangle,\\
 \Phi_{NZ}(k)&=\langle F_z(k)\zeta_{z,d}(k),
 Q_b(L_z(k),R_w(k-p))F_w(k-p)j_w(k-p)\rangle,\\
 \Phi_{ZN}(k)&=\langle F_z(k)j_z(k),
 Q_b(L_z(k),R_w(k-p))F_w(k-p)\zeta_{w,d}(k-p)\rangle. \tag{7.14}
\end{aligned}
\]

每条通道各自携带由物理入射腿与观察腿决定的精确动量窗因子：

| 极化通道核 | 入射动量窗因子 | 输出观察窗因子 |
|---|---|---|
| \(\Phi_{R\sigma}\)（右玻色传播变分） | \(w_B(k)w_B(l)\) | \(w_R(k)w_R(k-p)\) |
| \(\Phi_{L\sigma}\)（左玻色传播变分） | \(w_B(k)w_B(l)\) | \(w_R(k+\delta)w_R(l)\) |
| \(\Phi_{C\sigma}\)（中央读出接触变分） | \(w_B(k)w_B(l)\) | \(w_R(k)w_R(l)\) |
| \(\Phi_{NZ},\Phi_{ZN}\)（左／右量子源变分） | \(w_B(k)w_B(k-p)\) | \(w_R(k)w_R(k-p)\) |

记 $T_\bullet$ 为式 (7.14) 各核乘上同行两个窗口指示函数后的完整被积函数，则一次外源插入的完整极化振幅为

\[
 \mathcal P_b(p,d;z,w)=\frac14\sum_{\sigma=\pm1}\int
 (T_{R\sigma}+T_{L\sigma}+T_{C\sigma})\,d\mu
 +\frac12\int(T_{NZ}+T_{ZN})\,d\mu. \tag{7.15}
\]

前置权重的来历完全透明：母作用二次涨落流自带因子 $1/2$；在场传播与读出接触三项中，外场余弦两支 $\sigma=\pm 1$ 再提供因子 $1/2$，合为 $1/4$；而在量子源两项 $\Phi_{NZ},\Phi_{ZN}$ 中，$\zeta$ 已在式 (6.13) 内并入了余弦半幅，故外侧仅保留二次涨落流的 $1/2$。在同参数点取式 (7.15) 的实部读数，即得定义 1.1 的 $\mathcal R_\alpha$。

**证明。** 对双线性观测流 $\frac12\langle F_\varepsilon j_\varepsilon,Q_\varepsilon F_\varepsilon j_\varepsilon\rangle$ 在 $\varepsilon=0$ 处应用五因子 Leibniz 乘积法则，依次变分左场腿、右场腿、中央双线性矩阵 $Q_\varepsilon$ 以及左、右两条量子电流腿；将式 (7.8) 的受扰玻色解与式 (6.13) 的受扰量子流代入，并对左传播变分作哑指标翻转 $\sigma\mapsto-\sigma$ 及积分动量平移，即逐项导出上表相异的窗口乘积与式 (7.15)。紧动量支集上的有理列一致有界，量子腿满足空间 $L^2$ Cauchy–Schwarz，结合式 (7.12) 与命题 6.1 即证频域重排与双时间实积分恒等。□

### 7.5　本案协议特化（$p=0,R=B$）：移动双球交集与固定量子窗的分工

自此固定本案探针参数 $p=0,R=B,z=w=6c(1-i)$。此时弱形式读出矩阵携带总时间衰减率 $-\bar z-z=-12c$，而静态空间余弦外场的显式时间导数为 $0$。

利用 $Q_{\mathrm{native}}$ 的厄米对称性与积分动量换元，左、右两条玻色传播腿合并为单一实部积分：

\[
 \mathscr R_\alpha(y,d)=F_z(y-d)^\dagger Q_{\mathrm{native}}(y-d)
 G_{z,d}(y-d;y)\,\mathcal N_0^\alpha(y-d,y;z,z), \tag{7.16}
\]

\[
 I_G^\alpha(d)=\frac12\sum_{\sigma=\pm1}\operatorname{Re}
 \int_{|y|\le B,\ |y-\sigma d|\le B}\mathscr R_\alpha(y,\sigma d)\,d\mu(y). \tag{7.17}
\]

注意在式 (7.16) 中，入射动量 $y$ 固定了入射轻根 $U(|y|^2/2)$、分母 $D$ 与投影源 $I_0(y)$：对物理外动量 $d$ 求导时只微分出射侧与受扰传播解 $G_{z,d}(y-d;y)$，绝不把入射根误换为输出根。

相反，两条量子源腿在 $p=0,R=B$ 下的窗口恒为固定单球 $|k|\le B$，不随 $d$ 移动。其背景场缩并权函数

\[
 C(k)=\frac12F_z(k)^\dagger Q_{\mathrm{native}}(k)F_z(k)
 =\frac{P_C(k,U,T)}{D(U,T)^2c^4(U^2+5184)} \tag{7.18}
\]

由含全部辅助回写的 $685$ 项实多项式 $P_C$ 精确给出，原点值为 $C(0)=\sqrt{15}/25000$。在整个闭轻球 $|k|\le B$ 上，严格区间包络给出极窄的正定常数带与窗口测度：

\[
 \begin{gathered}
 0.0001549193308186325975<C(k)<0.0001549193368779607818,\\
 \mu(B)=\frac{B^3}{6\pi^2}\in[2.6685289152662552116,2.6685289152662552117]10^{-16}.
 \end{gathered} \tag{7.19}
\]

由于在整球上量子源外动量二阶核满足 $H_n(k)\in[-0.015140743694,-0.012928791594]<0$，两条量子源腿合成的 `raw` 外动量 Hessian 沿任意单位方向 $n$ 严格落在负区间：

\[
 S_n^{\mathrm{raw}}\in[-6.25928534,-5.34484924]10^{-22}\quad(|n|=1). \tag{7.20}
\]

式 (7.20) 乘 $1/2$ 后作为二次系数进入总曲率张量 $\mathsf K$（约 $-3\times 10^{-22}$ 量级）；真正决定 $O(10^{-20})$ 主导量级并逆转第二轴符号的，正是式 (7.17) 随 $d$ 移动的双球交集场传播项。

## 8　双球尖窗几何渐近：集合协方差尖点 $|d|$ 与两类球面边界通量

在式 (7.17) 中，积分域 $B_B\cap(B_B+\sigma d)$ 具有硬球面截断边界。积分几何中的 Matheron–Galerne 集合协方差（covariogram）定理 [[22]](#ref-22) 指出，有界有限周长集指示函数自相关的平移展开在原点必然产生由方向边界面积决定的非解析 $|s|$ 尖项。本节给出一般光滑核在移动双球交集上的精确二阶弦切片展开，分离出一阶与零阶两类球面边界通量，并通过显式仿射场与复相位反向控制证明任何漏掉球面通量或复交叉虚部的近似都会直接改写曲率判词。

### 8.1　双球交集体积尖点与弦端点二阶展开公式

对半径为 $B$、球心间距为 $s\in[0,2B]$ 的两个三维球，旋转体切片积分直接给出精确交集体积：

\[
 \operatorname{Vol}(B_B\cap(B_B+sn))
 =\frac{4\pi B^3}{3}-\pi B^2s+\frac{\pi s^3}{12}. \tag{8.1}
\]

将 $s$ 延拓至全体实数即得 $-\pi B^2|s|$ 非解析尖点：即便被积核恒等于常数 $1$，尖球窗在原点亦不存在普通二阶导数。

一般地，将坐标原点平移至两极端球心的几何中点，设球心半距为 $h_0s$（$s\ge 0$），记光滑核沿平移与空间方向的联合射流为 $\Psi_j=(\partial_s+a\partial_n)^j\Phi|_{s=0}$（$a$ 为球心中点偏移系数）。则移动交集积分按 $s$ 展开的前三项精确系数为

\[
 I_0=\int_B\Psi_0,\quad
 I_1=\int_B\Psi_1-h_0\int_{\partial B}|n\cdot\nu|\Psi_0, \tag{8.2}
\]

\[
 I_2=\frac12\int_B\Psi_2
 +\frac{h_0^2}{2}\int_{\partial B}(n\cdot\nu)\partial_n\Psi_0
 -h_0\int_{\partial B}|n\cdot\nu|\Psi_1. \tag{8.3}
\]

**证明。** 将球 $B_B$ 沿单位方向 $n$ 分解为平行弦族：在正交截面 $y\perp n$（$|y|<B$）处，未移动半弦长为 $h(y)=\sqrt{B^2-|y|^2}$。当两球反向错开半距 $h_0s$ 时，满足 $h(y)\ge h_0s$ 的长弦保留区间缩为 $[-h(y)+h_0s,\,h(y)-h_0s]$：对该一维定积分同时按被积核的 $s$-Taylor 展开与上下限端点的 $h_0s$ 位移展开，再利用球面面积元关系 $dy_\perp=|n\cdot\nu|\,dS$，立即得到式 (8.2)–(8.3)。而靠近赤道边缘满足 $h(y)<h_0s$ 的短弦带，其正交投影圆环面积仅为 $\pi B^2-\pi(B^2-h_0^2s^2)=\pi h_0^2s^2$，最大弦长不超过 $2h_0s$，故整条边缘带体积不超过 $\frac{4\pi}{3}h_0^3s^3=O(s^3)$，对一次与二次系数贡献严格为零；闭球上二阶导数的连续模遂给出 $o(s^2)$ 余项。□

### 8.2　固定入射标架下的体积分、一阶球面通量与零阶球面通量

在式 (7.17) 中，两条传播腿固定采用入射射线方向 $\nu\in S^2$ 上的成对标架：置 $y=r\nu$、$d=sn$、方向余弦 $u=n\cdot\nu$。在该射线上，双球交集的精确径向上限为

\[
 r_{\max,\sigma}(s)=\min\{B,\ \sigma su+\sqrt{B^2-s^2(1-u^2)}\}. \tag{8.4}
\]

将一维径向积分 $\int_0^{r_{\max,\sigma}(s)}r^2\operatorname{Re}\mathscr R_\alpha(r\nu,\sigma sn)\,dr$ 对 $\sigma=\pm 1$ 求平均并按 $s$ 展开至 $s^2$ 阶（当 $\sigma u<0$ 时上限在 $s>0$ 处取右支 $\sigma su+\sqrt{B^2-s^2(1-u^2)}<B$，当 $\sigma u>0$ 时保持硬截断 $B$），传播腿二次曲率精确分解为球内体积分与两类球面通量之和（图 3）：

\[
\begin{split}
 K_G^\alpha(n)={}&\underbrace{\frac12\int_B\operatorname{Re}\mathscr R_{dd}}_{\text{球内体积分（body）}}
 +\underbrace{\frac12\int_{\partial B}u\operatorname{Re}\mathscr R_d}_{\text{一阶球面通量（first flux）}}\\
 &+\underbrace{\frac14\int_{\partial B}
 \left[u^2\partial_r\operatorname{Re}\mathscr R_0
 +\frac{3u^2-1}{B}\operatorname{Re}\mathscr R_0\right]}_{\text{零阶球面通量（zeroth flux）}}. \tag{8.5}
\end{split}
\]

此处体测度与球面面积元全程保留因子 $(2\pi)^{-3}$；下标 $d$ 专指固定入射动量 $y$ 下沿外动量方向 $n$ 的偏导数，而 $\partial_r$ 仅在固定射线角 $\nu$ 上沿径向求导——因此跨球面坐标拼接缝的入射标架只需 Borel 可测且一致有界，无需假定全局光滑球面标架场（毛球定理障碍由此自然规避）。

![图3：双球尖窗交集几何、一次球冠损失与两类球面通量对消。](figures/fig02-lens-flux-v2.svg)

**图 3　双球尖窗交集几何、一次球冠损失与两类球面通量对消。** 左：深色透镜区域为保留的双球交集积分域 $|y|\le B\cap |y-d|\le B$，其朱红球弧边界承载一阶与零阶两类球面通量；入射球中落在交集外被观察窗裁去的浅色球冠产生 $-\pi B^2|s|$ 型非解析一次损失，对应式 (1.3) 的 $|s|$ 尖项。右：固定入射标架下二次曲率分解为球内体积分、一阶球面通量与零阶球面通量，底部展示仿射测试场中球面通量与球内梯度能精确相消为零的反向控制（图形比例为几何示意，数值积分严格按式 (8.4) 上限与 $(2\pi)^{-3}$ 测度执行）。

### 8.3　反向控制一：弦端点相消不等于球面通量消失

为防止将两类截然不同的边界项混为一谈，考察具有厄米配对对称性的自相关泛函：

\[
 L(s)=\frac1{2(2\pi)^3}\int B_Q(a(k),a(k+sn))
 \mathbf1_{B_B}(k)\mathbf1_{B_B}(k+sn)\,d^3k,\qquad
 B_Q(a,b)=\operatorname{Re}(a^\dagger Qb). \tag{8.6}
\]

在一维弦切片上，对角量 $c(t)=B_Q(a,a)$ 与切向导数配对 $e(t)=B_Q(a,a')$ 满足恒等式 $c'=2e$，使移动上端点产生的二阶边值项 $+s^2c'(h)/2$ 与 $-s^2e(h)$ 彼此抵消，化简为

\[
 K(n)=\frac1{4(2\pi)^3}\int_BB_Q(a,\partial_n^2a)
 =\frac1{4(2\pi)^3}\left[
 \int_{\partial B}(n\cdot\nu)B_Q(a,\partial_na)-\int_BB_Q(\partial_na,\partial_na)\right]. \tag{8.7}
\]

注意式 (8.7) 第二个等号右端的球面通量 $\int_{\partial B}(n\cdot\nu)B_Q(a,\partial_n a)$ **并未消失**。在 289 维坐标中取实常向量 $b=e_9+e_{259}$（满足 $b^TQb=4$），将四组解析测试场直接代入式 (8.7) 沿 $n=e_3$ 求值：

| 三维测试场（\(n=e_3\)） | 精确二次系数 \(K(e_3)\) |
|---|---:|
| \(a=b\)（常值场） | \(0\) |
| \(a=[1+(2+i)k_3]b\)（复仿射场） | \(0\) |
| \(a=[1+(1+i)k_3+(2-i)k_3^2]b\)（二次场） | \(B^3(B^2+2)/(3\pi^2)\) |
| \(a=e^{i\kappa k_3}b\)（平面波场） | \(-\kappa^2B^3/(6\pi^2)\) |

如例 1.1(b) 所示，第二行复仿射场的零结果正是球面正通量与球内负梯度能当庭对消的产物：一旦漏写球面通量，仿射场就会被错判为严格负曲率。更进一步，完整五通道中的受扰传播核 (7.16) 因左、右两腿不对称而不再满足自相关恒等式 $c'=2e$（例如线性核 $\Phi=s$ 在移动交集上真实产生二阶球面项 $-2\pi B^2h_0$），故第 10 节必须完整保留式 (8.5) 的全部三项。

### 8.4　反向控制二：复交叉项少一个虚部即翻转判词

将场—态乘积写为张量积 $a=WJ$，其中 $W$ 为玻色场列、$J$ 为量子流态矢。记场缩并系数为 $\alpha=W^\dagger QW\in\mathbb R$、$\beta_n=W^\dagger QW_n$、$\delta_n=W^\dagger QW_{nn}$，量子复 Gram 系数为 $\nu=\langle J,J\rangle,\theta_n=\langle J,J_n\rangle,\eta_n=\langle J,J_{nn}\rangle$。二阶方向导数直接展开为

\[
 B_Q(a,a_{nn})=\operatorname{Re}\delta_n\,\nu
 +2\operatorname{Re}(\beta_n\theta_n)+\alpha\operatorname{Re}\eta_n, \tag{8.8}
\]

其中交叉项显式包含实部乘积与**虚部乘积之差**：$2\operatorname{Re}(\beta_n\theta_n)=2(\operatorname{Re}\beta_n\operatorname{Re}\theta_n-\operatorname{Im}\beta_n\operatorname{Im}\theta_n)$。取反向相位测试对 $W=e^{2ik_3}b,J=e^{-2ik_3}$：此时乘积 $a(k)=WJ\equiv b$ 为严格常值场，真实二阶项 $B_Q(a,a_{nn})$ 恒等于 $0$；但若提前丢弃复 Gram 的虚部而只保留 $\operatorname{Re}\beta_n\operatorname{Re}\theta_n$，式 (8.8) 右端便瞬间错算为 $-32$。这正是第 9–10 节必须先保留全部 58 个复两探针 Gram 权重、直至球面角积分末端才取实部的根本原因。

## 9　全空间隐式色散导数、复两探针 Gram 与抗包裹递归包络

要将式 (8.5) 从解析表达式变成零截断漏洞的严格有理区间，必须同时攻克四项分析任务：求隐式六次色散根 $U(T)$ 的精确高阶导数、解析算出连续位置球滤波态的 58 个复两探针 Gram 矩、界定变分接触项的消失阶数，以及在不触发区间算术包裹膨胀（wrapping effect）[[26]](#ref-26) 的前提下包围 11,760 个外源响应系数。

### 9.1　隐式六次色散根的一阶与二阶全空间导数

传播列 (7.3) 中的轻支路根 $U(T)$ 由六次多项式方程 $\widehat F(U(T),T)=0$ 隐式定义，而非简单取原点切线 $U'(0)T=\frac{125}{162}T$。记归一化多项式 $f=\widehat F/c_F$，一、二阶径向根导数 $S=U'(T)$ 与 $C=U''(T)$ 在闭轻球根域上满足隐函数微分恒等式：

\[
 S=-\frac{f_T}{f_U},\qquad
 C=-\frac{f_{TT}+2f_{UT}S+f_{UU}S^2}{f_U},\qquad
 S(0)=\frac{125}{162},\quad C(0)=-\frac{76325}{78732}. \tag{9.1}
\]

对任意显含 $(k,U,T)$ 的多项式分量 $g(k,U,T)$，引入全微分算子 $\mathcal D=S\partial_U+\partial_T$，则限制在真实隐式根流形上的空间动量一、二阶偏导数为

\[
 \partial_ag=g_a+k_a\mathcal Dg, \tag{9.2}
\]

\[
 \partial_a\partial_bg=g_{ab}+k_a\mathcal Dg_b+k_b\mathcal Dg_a
 +\delta_{ab}\mathcal Dg
 +k_ak_b(S^2g_{UU}+2Sg_{UT}+g_{TT}+Cg_U), \tag{9.3}
\]

（其中 $g_a,g_{ab}$ 仅对显式笛卡尔动量 $k_a$ 求偏导）。对分子列与分母 $D(U,T)$ 同步应用式 (9.2)–(9.3) 及商法则，即得 $F_z$ 与 $G_{z,d}$ 的精确全空间导数。

以初始留数种子列 $W(k)=-\sum_{\sigma=\pm1}\ell_\sigma(-k)$ 作独立代数校核：其 $87$ 个非零场行与背景读出矩阵 $Q$ 的 $188$ 个非零元缩并时恰激活 $56$ 个有效配对，在八维代数数基 $(1,\sqrt2,\sqrt{15},\sqrt{30},i,i\sqrt2,i\sqrt{15},i\sqrt{30})$ 上精确给出原点中心值

\[
 \alpha_0=\frac{1944\sqrt{15}}{390625},\quad
 \beta_a(0)=0,\quad
 \delta_{ab}(0)=\frac{144\sqrt{15}}{78125}\delta_{ab}. \tag{9.4}
\]

在根域矩形 $0\le T\le\epsilon_B^2$、$0\le U\le\frac{1331}{1620}\epsilon_B^2$ 上先代数消去 $-f_T-\frac{125}{162}D$ 的零阶常项再作向外有理区间包围，得到极紧的斜率漂移与曲率界：

\[
 |S-125/162|\le3.09374932\,10^{-10},\qquad |C|\le11.211290904, \tag{9.5}
\]

对应单位方向上的种子系数偏差界 $|\alpha-\alpha_0|\le2.54913989\,10^{-10}$、$|\beta_n|\le3.169153940416\,10^{-6}$ 与 $|\delta_n-144\sqrt{15}/78125|\le6.14562710075\,10^{-7}$（完整五通道计算仍直接调用式 (7.3) 与 (7.8) 的含频动态列）。在非零轴向点 $q_{\mathrm{ax}}=1/262144$ 处的商环与 Sturm 根隔离检验表明，倘若人为将根斜率 $S(0)$ 错置为 $1$，仅原点 $\delta_{11}(0)$ 一项便立即产生精确代数偏差

\[
 -\frac{10755974\sqrt{15}}{4150390625}\ne0. \tag{9.6}
\]

### 9.2　两探针量子复 Gram 的全部 58 个解析矩

在量子电流端，固定积分输出动量 $p$ 时入射动量为 $p-k$。记式 (6.14) 的 Sylvester 频域核为 $G(k,p)$，则其作用于空间滤波态 $\widehat\psi$ 的探针动量导数必须同时包含核导数与波包导数：

\[
 g_i=G_i\widehat\psi-G_0\partial_i\widehat\psi,\quad
 g_{ij}=G_{ij}\widehat\psi-G_i\partial_j\widehat\psi-G_j\partial_i\widehat\psi
 +G_0\partial_{ij}\widehat\psi; \tag{9.7}
\]

只微分预解核或只微分滤波态都会漏掉真实交叉项。

令 $p=\sqrt2v,x=v\cdot v\ge 0$，在每个手征不变块上，算子 Sylvester 方程精确消元后的径向有理分母分解为四个远离正实轴的复极点因子：

\[
 D_x=(x-18i)
 \left(x-\frac{83520+967032i}{48841}\right)
 \left(x+\frac9{25}-18i\right)
 \left(x+\frac{61920-530712i}{32761}\right). \tag{9.8}
\]

在 12 维占据载体上对两个手征块求和并完成动量球面角积分后，全部量子输入精确归结为 $1$ 个归一化权、$20$ 个复均值权与 $58$ 个两探针复 Gram 权（其中二阶数据含左腿 $6$ 个对称分量、右腿 $6$ 个对称分量及全部 $9$ 个左右混合分量）。与离散数值网格求积不同，这里的无穷三维动量积分**全程解析完成**：附录 D.1 通过球贝塞尔微分恒等式与分部积分将径向被积函数化为有理分式乘 $b(r)^2$，对全部 $11$ 个复极点（重数至多 $3$）作部分分式分解后代入闭式指数矩 (6.5) 及其 $\kappa$-导数，并以 $130$ 阶 Taylor 级数加显式阶乘尾界包裹至任意精度。

一项关键的对称性自检是令左、右两探针同步移动 $k=l$：此时二阶系数必须取完整组合 $L_{ij}+R_{ij}+2M_{ij}$。在 `connected` 扇区上，零阶电流同步二阶组合精确恢复空间各向同性

\[
 (L+R+2M)_{N_0}=0.1622411553760404839\,I_3, \tag{9.9}
\]

而外加 $dx^1S_{01}$ 微扰打破全旋转对称后的量子源一阶同步组合在三轴上依次为 $0.0255929216787139673$ 与两个相等横向值 $0.0120264349193238322$——单独读取右腿 Hessian 无法还原这一精确对称破缺模式。

### 9.3　变分读出接触项的 $O(B^5)$ 高阶压低与非零 $|d|$ 尖项

在中点动量坐标下，式 (7.14) 第三项变分读出接触核写为

\[
 \mathcal C(k,s)=\operatorname{Re}
 \langle A(k-sn/2),(Q_0+sQ_n)A(k+sn/2)\rangle,
 \quad Q_0^\dagger=Q_0,\quad Q_n^\dagger=-Q_n, \tag{9.10}
\]

其中 $A$ 为余标架传播列与量子流态矢的张量积（完整接触矩阵含 $97$ 个非零余标架条目；另有 $4$ 个标量接触条目因轻支路传播列的标量分量恒为零而在该列上作用归零）。对式 (9.10) 应用双球中点展开 (8.3) 并利用共轭反对称性化简球面项后，接触二次曲率化为纯体积分：

\[
 K_C(n)=\int_B\left[\frac14\operatorname{Re}\langle A,Q_0A_{nn}\rangle
 +\frac12\operatorname{Re}\langle A,Q_nA_n\rangle\right]d\mu. \tag{9.11}
\]

由于余标架传播列在原点消失 $F_e(0)=0$ 且首项为奇次线性动量项，偶对称球积分消去了全部 $O(B^3)$ 主项，使接触二次曲率从高阶 $O(B^5)$ 起算，全方向算子范数严格压低至

\[
 \|\mathsf K_C\|\le3.686515414428545\,10^{-26}, \tag{9.12}
\]

比主导传播腿曲率（$10^{-20}$）小五个数量级以上。然而接触项的尖窗一次系数 $a_C(n)|s|$ 并不为零：由原点线性导数矩阵

\[
 (DF_e(0))^\dagger Q_0DF_e(0)
 =-\tau\operatorname{diag}(2,1,1),\qquad
 \tau=\frac{32041\sqrt{30}}{31492800}, \tag{9.13}
\]

接触通道给出约 $+10^{-23}$ 量级的正一次尖项，与两条传播腿在 $[-7.470844,-7.370030]\times 10^{-18}$ 内的负一次尖项叠加后，完整五通道响应在原点仍保持真实非零的 $|d|$ 尖点。

### 9.4　消除区间包裹膨胀：先递归求解外源响应系数，后施读出范数

在计算机辅助严格证明中，区间算术的子分配律 $[a]\cdot([b]+[c])\subsetneq [a]\cdot[b]+[a]\cdot[c]$ 意味着若将矩阵逆、驱动源与读出算符分别粗估范数后再相乘，包裹膨胀效应（wrapping effect）[[25]](#ref-25), [[26]](#ref-26) 会把区间半宽放大数个数量级并彻底淹没特征值符号。本文直接针对线性方程组 $A(q,d)Y(q,d)=f(q,d)$（置原点逆 $P_0=A(0,0)^{-1}$），按径向幂次 $n$ 与外动量多指标 $\alpha$ 递归生成**同一个精确解**的幂级数系数：

\[
 Y_{n,\alpha}=P_0f_{n,\alpha}
 -\sum_{(j,\beta)\ne(0,0)}{\alpha\choose\beta}
 P_0A_{j,\beta}Y_{n-j,\alpha-\beta}. \tag{9.14}
\]

递归全程保留非交换矩阵乘法次序：逆矩阵级数保留 $40$ 阶，外源响应解 $Y$ 保留 $36$ 阶，全部 11,760 个复系数（其中 2,231 项非零）均以 $256$-bit 二进有理端点的向外舍入复矩形（附录 D.2 式 (D.4)）精确包裹。

为严格控制第 $36$ 阶之外的无穷解析尾项，取严格包住闭球半径 $\epsilon_B\approx 1.77\times 10^{-5}$ 的复径向圆周 $|q|=\rho_*=1/8192\approx 1.22\times 10^{-4}$。在此圆盘上，消去平凡零因子后的六次方程满足

\[
 \bar F(Tr,T)=T\left(r-\frac{125}{162}+TP(r,T)\right),\quad
 \rho_*^2\sup|P|<\frac1{20},\quad \rho_*^2\sup|P_r|<1. \tag{9.15}
\]

Banach 压缩映射原理由此保证以 $125/162$ 为中心的小圆盘内存在唯一全纯隐式根分支（实轴限制与 Sturm 隔离根 $U(T)$ 重合），同时 Neumann 条件保证 $A(q,d)$ 在整张多圆盘上全纯可逆。利用 $|q|=\rho_*$ 上的显式上界 $M$ 与 Cauchy 导数尾公式（附录 D.2 式 (D.5)），直接对已解出的响应列 $Y$（而非裸逆矩阵）取尾界：物理换元前 $0$ 至 $4$ 阶归一化轴向导数上界依次约为 $(0.001669,0.190606,0.074193,0.141750,0.357796)$，再与完整读出行 $F^\dagger QED$、规范辅助特解、九方向并矢展开 $\ell^1$ 界（因子 $3\times 3=9$）及物理坐标换算因子 $2^{-1/2}$ 合成，彻底消除了中间过程的区间膨胀。

## 10　成对标架球面全角解析积分与四阶位置矩余项闭合

### 10.1　空间旋转有限协变恒等式与成对北半球径向测度

母作用的三个空间总角动量生成元同步作用于 289 维场、独立对偶、空间动量及内部规范方向。背景双线性读出矩阵满足无穷小协变微分方程

\[
 J^TQ_a+Q_aJ+D_{(S^TL,S^TR)}Q_a+Q_{Ja}=0, \tag{10.1}
\]

规范辅助本构图亦满足 $DB_a+B_{Ja}=JB_a$；沿有限旋转圆周从单位元初值积分，即证完整三次电流在独立双四动量下的精确有限旋转协变性。

对入射单位方向，采用两步欧拉成对旋转标架：

\[
 L=L_z(t_z)L_y(t_y),\quad R=R_y(t_y)R_z(t_z),\quad
 L^{-1}(dx^1S_{01})=\sum_{ij}v_iv_jE_{ij},\quad v=Re_1,\quad m=Rn, \tag{10.2}
\]

其中 $E_{ij}$ 枚举九个空间规范基方向 $dx^i\otimes(g_1,g_0,g_6-g_7)_j$（未除二的 Cartan 元 $g_6-g_7$ 使三规范方向原配对 Gram 恰为 $2I_3$）。球积分采用正负径向 $r\in[-B,B]$ 共用同一北半球标架的成对径向测度（北半球积分乘 $2$）：置 $t=\cos\theta\in[0,1],s_\theta=\sqrt{1-t^2}$，显式旋转矩阵为

\[
 R=\begin{pmatrix}
 t\cos\varphi&t\sin\varphi&-s_\theta\\
 -\sin\varphi&\cos\varphi&0\\
 s_\theta\cos\varphi&s_\theta\sin\varphi&t
 \end{pmatrix}. \tag{10.3}
\]

原点单点 $\{r=0\}$ 勒贝格测度为零，故 $r>0$ 上的有界可测标架 (10.3) 精确承载全球积分而无极点歧义。

### 10.2　球内体积分与两类球面通量的 Beta 解析相消及 77 位整数主部

记式 (7.16) 的场端标量核为 $D(r,d)$，量子复 Gram 原点值为 $g=\mathcal N_0(0,0)$、左腿二阶复标量为 $\ell=\ell_R+i\ell_I$、左右混合标量为 $m_0$。九方向并矢张量共生成 $15$ 个二阶径向—外动量导数；其在秩一外源方向上的全部一阶射流恒为零，原点复常项精确为

\[
 C_*=(366033271/1585732915875000
 +15362367173\,i/19028794990500000)\sqrt{30}. \tag{10.4}
\]

沿 $u=n\cdot\nu$，完整乘积核的三组二阶导数为

\[
 \Phi_{dd}=D_{dd}g+C_*\ell|n|^2,\quad
 \Phi_{rd}=D_{rd}g-C_*(\ell+m_0)u,\quad
 \Phi_{rr}=D_{rr}g+C_*(2\ell_R+2m_0). \tag{10.5}
\]

代入式 (8.5) 的三项分解后，主导阶 $B^3$ 的三个球面角被积核依次为

\[
 \frac16\operatorname{Re}\Phi_{dd},\qquad
 \frac u2\operatorname{Re}\Phi_{rd},\qquad
 \frac{5u^2-|n|^2}{8}\operatorname{Re}\Phi_{rr}. \tag{10.6}
\]

用附录 E 式 (E.1)–(E.2) 的 Gamma／Beta 闭式公式（并经有限 Laurent–Fourier 三角词路线独立复核）对式 (10.3) 展开的每个角度单项式作精确符号积分，出现一处极具说服力的成对结构对消：左腿复二阶矩虚部 $\ell_I$ 在球内体积分与一阶球面通量之间**精确一正一负抵消为零**（零阶通量本身不含 $\ell_I$），混合矩 $m_0$ 在一阶球面通量与零阶球面通量之间**同样精确一负一正抵消为零**（球内体项本身不含 $m_0$），故唯独式 (8.5) 三项全部相加之后，$\ell_I$ 与 $m_0$ 的系数才在全方向上恒等于零，同时主导阶的非对角混合单项式亦精确相消。

最终主导阶对角张量由以下五个精确大整数完全锁定：

\[
 A=22167194028817237306747382536724582082089691131746230098538055829760,
\]
\[
 D_*=144049402099638285990225019962670247878188911404813573223075013222960000000,
\]
\[
\begin{aligned}
 b_1&=-2320339522879271170011217524973217861256927053064666079052657705109338,\\
 b_2&=3921375100572892251186223581547532771093087034683851044524183837417062,\\
 b_3&=-3012102837963769108469432161130193495577865811561102038217309537582938,
\end{aligned}
\]

即两条玻色传播腿的 $O(B^3)$ 领先曲率张量精确等于

\[
 \mathsf K_{G,0}^\alpha
 =\frac{B^3\sqrt{30}}{8\pi^2D_*}
 \operatorname{diag}(A\ell_R^\alpha+b_1g^\alpha,
 A\ell_R^\alpha+b_2g^\alpha,
 A\ell_R^\alpha+b_3g^\alpha). \tag{10.7}
\]

代入 `raw` 扇区的 $(g^{\mathrm{raw}},\ell_R^{\mathrm{raw}})\simeq(0.73590110,-0.22322738)$，各向同性项 $A\ell_R^{\mathrm{raw}}$ 因 $\ell_R^{\mathrm{raw}}<0$ 在三轴上一致贡献微小的负值 $-0.003766\times 10^{-20}$，而 $b_2g^{\mathrm{raw}}\simeq+2.196040\times 10^{-20}$ 单独奠定了 $e_2$ 轴的显著正曲率，使式 (10.7) 的三轴中心值（单位 $10^{-20}$）依次落在 $-1.3031969814$、$+2.1922740186$ 与 $-1.6905967190$。为直观揭示 $(2,1,0)$ 号差的几何与物理生成机制，下表将式 (8.5) 三个通道在主导 $g^{\mathrm{raw}}$ 项上的精确有理球面积分贡献拆解并列（单位 $10^{-20}$）：

| 式 (8.5) 曲率分解分项（`raw` 领先阶 $O(B^3)$） | \(e_1\) 轴 | \(e_2\) 轴 | \(e_3\) 轴 | 几何与对称性特征 |
|---|---:|---:|---:|---|
| 球内体积分（`body`，$g^{\mathrm{raw}}$ 部） | \(-1.436641\) | \(-0.184498\) | \(-0.184498\) | 三轴全负且 \(e_2=e_3\) 横向简并（伪 \((3,0,0)\)） |
| 一阶球面通量（`first flux`，$g^{\mathrm{raw}}$ 部） | \(-139.197532\) | \(-41.096041\) | \(-32.036010\) | 破缺 \(e_2\leftrightarrow e_3\) 简并，与 `body` 精确消去 \(\ell_I\) |
| 零阶球面通量（`zeroth flux`，$g^{\mathrm{raw}}$ 部） | \(+139.334741\) | \(+43.476580\) | \(+30.533677\) | 破缺 \(e_2\leftrightarrow e_3\) 简并，与一阶通量精确消去 \(m_0\) |
| **两类球面通量净和**（`first + zeroth`，$g^{\mathrm{raw}}$ 部） | \(\mathbf{+0.137209}\) | \(\mathbf{+2.380538}\) | \(\mathbf{-1.502333}\) | **在 \(e_2\) 注入 \(+2.38\) 跨零翻转，在 \(e_3\) 压低 \(-1.50\)** |
| 三通道 \(b_i g^{\mathrm{raw}}\) 合账 | \(-1.299431\) | \(+2.196040\) | \(-1.686831\) | 整球 \(g^{\mathrm{raw}}\) 主导号差已锁定为 \((-,+,-)\) |
| 各向同性项 \(A\ell_R^{\mathrm{raw}}\)（三通道合账） | \(-0.003766\) | \(-0.003766\) | \(-0.003766\) | \(\ell_R^{\mathrm{raw}}<0\) 带来一致微小负平移 |
| **传播腿领先阶总计 \(\mathsf K_{G,0}^{\mathrm{raw}}\)（式 10.7）** | \(\mathbf{-1.303197}\) | \(\mathbf{+2.192274}\) | \(\mathbf{-1.690597}\) | **两负一正，删去任一球面通量即彻底改写符号** |

这一拆解清楚回答了两个核心物理问题：第一，在 $r=0$ 处的纯外动量二阶射流 $D_{dd}$ 仅沿外源探测方向 $dx^1S_{01}$ 收缩，保持正交平面 $e_2\leftrightarrow e_3$ 对称且三轴全负，若按传统无界光滑动量微扰论忽略尖球窗边界通量，将直接误判为全负号差 $(3,0,0)$；第二，在球面 $\partial B$ 上，径向射流 $D_{rd},D_{rr}$ 同时感知非阿贝尔空间背景 $A_j=a\tau_j$（探测元 $S_{01}=2\tau_1$ 与 $\tau_2$ 的非零对易子 $[\tau_1,\tau_2]=i\tau_3$）、手征自旋联络扭率 $\omega_{j,\cdot}=\sqrt2$ 以及规范固定截面子式 $\det K_{\mathrm{removed}}=\frac{3\sqrt2}{1000}(18-25k_x^2)$（附录 C 式 (C.3)），经成对入射标架 (10.2)–(10.3) 积分后精确劈裂 $e_2$ 与 $e_3$，在一阶与零阶球面通量 $O(10^2)$ 量级的精细相消后留下 $e_2$ 轴 $+2.380538\times 10^{-20}$ 的净正通量并逆转整球曲率符号。连通扇区 `connected` 呈现完全相同的翻转机制（仅球内体项为 $(-1.4212,-0.1825,-0.1825)\times 10^{-20}$，两类球面通量净和在 $e_2$ 注入 $+2.3550\times 10^{-20}$，合成 $\mathsf K_{G,0}^{\mathrm{conn}}\simeq(-1.289229,+2.168683,-1.672466)\times 10^{-20}$）。

### 10.3　四阶位置矩控制下的 $O(B^5)$ 整球余项定理

对任意单位方向 $\nu\in S^2$，记空间位置幂矩为 $M_j(v)=\|X_\nu^jv\|_{L^2}$。位置球种子与正则滤波核 (6.4) 保证 $\psi$ 与 $H\psi$ 拥有直至四阶的有限位置矩。由算符对易子 $[H,X_\nu^j]=-ijh_\nu X_\nu^{j-1}$ 及 $\|h_\nu\|=N$，自由幺正演化满足多项式矩传播界：

\[
 \|X_\nu^mU(t)v\|\le P_m(t;v)
 :=\sum_{j=0}^m{m\choose j}(N|t|)^{m-j}M_j(v). \tag{10.8}
\]

多方向混合偏导数由同一方向幂矩经 Hölder 不等式一致控制。置 $\alpha_0=\sqrt2/N^2$，零阶电流的第 $m$ 阶动量探针导数与一阶量子源变分的第 $m$ 阶导数分别受控于

\[
 B_m(t,k)=\alpha_0[2P_m(t;H\psi)+N|k|P_m(t;\psi)
 +mN P_{m-1}(t;\psi)], \tag{10.9}
\]

\[
 C_m(t,k)=\alpha_0N[2P_m(t;\psi)+4tP_m(t;H\psi)
 +2N|k|tP_m(t;\psi)+2mNtP_{m-1}(t;\psi)]. \tag{10.10}
\]

完成正半轴指数权积分后，$B_0,\ldots,B_4$ 的一致上界依次严格小于 $1.255144$、$3.215825$、$5.536819$、$11.648259$ 与 $31.085903$。

沿入射路径 $(k,l)=(r\nu-dn,r\nu)$，两探针复 Gram 的混合径向—外动量导数满足 Leibniz 界

\[
 |\partial_r^a\partial_d^b\mathcal N_0|
 \le\sum_{j=0}^a{a\choose j}B_{b+j}B_{a-j},\qquad a+b\le4. \tag{10.11}
\]

将其与第 9.4 节已包围的受扰场解导数逐阶合成，得到完整核的四阶一致导数上界常数 $M_{22},M_{31},M_{40}$。由于成对径向测度 $r\in[-B,B]$ 自动将球内体积分的一次奇次径向项、一阶通量的二次奇次项与零阶通量的三次奇次项精确积分归零，全部剩余项整齐推迟至 $O(B^5)$。

<a id="prop-10-1"></a>

**命题 10.1（四阶位置矩控制的整球高阶余项统一上界）。** 在闭轻球 $|k|\le B$ 上，对一切实单位方向 $n\in S^2$，传播腿二次曲率与主导对角张量 (10.7) 之差满足统一谱范数界：

\[
 |K_G^\alpha(n)-n^T\mathsf K_{G,0}^\alpha n|
 \le\frac{B^5}{\pi^2}\left[
 \frac{M_{22}}{40}+\frac{M_{31}}{48}
 +\frac{1+1/\sqrt3}{144}M_{40}\right]. \tag{10.12}
\]

**证明。** 在成对径向参数 $r\in[-B,B]$ 上应用带积分余项的 Taylor 展开：球内体积分余项模长不超过 $r^2M_{22}/2$，一阶球面通量余项不超过 $|r|^3M_{31}/6$，零阶球面通量中的 $\partial_r\operatorname{Re}\mathscr R_0$ 与 $\operatorname{Re}\mathscr R_0$ 余项分别不超过 $|r|^3M_{40}/6$ 与 $r^4M_{40}/24$。代入式 (8.5)，结合精确球面绝对值积分 $\int_{S^2}|u|\,d\Omega=2\pi$、$\int_{S^2}u^2\,d\Omega=4\pi/3$、$\int_{S^2}|3u^2-1|\,d\Omega=16\pi/(3\sqrt3)$ 以及 $(2\pi)^{-3}$ 测度因子与各通道前置系数，直接积分 $r$ 即得式 (10.12)。□

代入向外有理区间算得的谱范数余项上界为：

| 扇区 | \(\|\mathsf K_G^\alpha-\mathsf K_{G,0}^\alpha\|_2\) 的全方向统一上界 |
|---|---:|
| `raw`（未中心化） | \(2.070266\times10^{-22}\) |
| `mean`（均值项） | \(1.336530\times10^{-24}\) |
| `connected`（连通部分） | \(2.052970\times10^{-22}\) |

由于实对称矩阵在单位球面上的二次型上确界恰等于其算子谱范数（从而控制每个对角与非对角矩阵元的误差），上表无需抽样拟合方向即可直接锁死全部非对角混合项。

## 11　整球极化曲率张量合成与连续同伦 $(2,1,0)$ 惯性锁定（Q4）

### 11.1　五通道总账合成与独立中心化区间纪律

记两条固定窗量子源腿的外动量 Hessian 矩阵为 $\mathsf S_N^\alpha$，变分读出接触项的二次系数矩阵为 $\mathsf K_C^\alpha$。五通道完整整球响应曲率张量为

\[
 \mathsf K_\alpha
 =\mathsf K_G^\alpha+\frac12\mathsf S_N^\alpha+\mathsf K_C^\alpha,\qquad
 \mathsf K_{\mathrm{raw}}=\mathsf K_{\mathrm{mean}}+\mathsf K_{\mathrm{conn}}, \tag{11.1}
\]

其中 $\frac12\mathsf S_N^\alpha$ 的因子 $1/2$ 是把二阶导数 Hessian 换算为 Taylor 二次型系数（式 (7.15) 的余弦与涨落流半幅此前均已计入）。

在 `raw` 扇区上，$\frac12\mathsf S_N^{\mathrm{raw}}+\mathsf K_C^{\mathrm{raw}}$ 沿任意单位方向的二次型值落在 $[-3.13001133,-2.67205597]\times 10^{-22}$ 内：它将式 (10.7) 的三个传播腿领先值一致向负侧平移约 $0.029\times 10^{-20}$，从而给出 §1.2 表中的最终严格区间，而丝毫无法动摇第二主轴 $+2.16\times 10^{-20}$ 的显著正值。遵循 §9.4 抗包裹膨胀原则 [[26]](#ref-26)，`mean` 与 `connected` 两个扇区各自独立使用自身的复均值与中心化复 Gram 完成区间合成，而非粗糙地用 `raw` 区间端点减去 `mean` 区间端点，故 `connected` 获得了与 `raw` 同样紧致的 $4.56\times 10^{-22}$ 区间宽度。

### 11.2　非对角元统一界与连续缩放路径 Gershgorin 惯性证明

记最终主轴对角区间的中点为 $d_i$、半宽为 $e_i$。由式 (10.7)、命题 10.1 的谱范数界、量子源各向异性包络及接触界 (9.12) 合成可得，完整实对称矩阵 $\mathsf K_\alpha$ 满足

\[
 K_{ii}\in[d_i-e_i,d_i+e_i],\quad |K_{ij}|\le m_\alpha\ (i\ne j), \tag{11.2}
\]

其中 $m_{\mathrm{raw}}<2.299243\times 10^{-22}$，$m_{\mathrm{conn}}<2.281948\times 10^{-22}$。按 Gershgorin 圆盘定理 [[24]](#ref-24)，三维矩阵第 $i$ 行的圆盘半径不超过两个非对角元绝对值之和 $2m_\alpha$。以 §1.2 向外放宽后的十进制区间计算，`raw` 三行扩张后的实圆盘依次包含于（单位 $10^{-20}$）

\[
 [-1.401185,-1.263229],\quad[2.094286,2.232242],\quad
 [-1.788585,-1.650629], \tag{11.3}
\]

而 `connected` 三行扩张后的实圆盘依次包含于（单位 $10^{-20}$）

\[
 [-1.342971,-1.206052],\quad[2.094015,2.230935],\quad
 [-1.747134,-1.610214]. \tag{11.4}
\]

**定理 1.2 的完整证明。** 构造实对称矩阵线性同伦族 $\mathsf K_\alpha(t)=\operatorname{diag}(K_{11}^\alpha,K_{22}^\alpha,K_{33}^\alpha)+t(\mathsf K_\alpha-\operatorname{diag}\mathsf K_\alpha)$，其中 $t\in[0,1]$。由于对一切 $t\in[0,1]$，非对角元模长 $|tK_{ij}^\alpha|\le |K_{ij}^\alpha|\le m_\alpha$ 单调受控于同一上界，$\mathsf K_\alpha(t)$ 的三个实特征值在整条连续路径 $t\in[0,1]$ 上始终被限制在式 (11.3)（对 `raw`）或式 (11.4)（对 `connected`）的三个并集区间内。因式 (11.3) 与 (11.4) 中所有区间均与原点 $0$ 保持大于 $1.20\times 10^{-20}$ 的严格正距离，由实对称矩阵特征值关于 $t$ 的连续性，整条路径上没有任何特征值能够穿过 $0$。在起点 $t=0$ 处，对角矩阵显然具有两个严格负特征值与一个严格正特征值；故在终点 $t=1$ 处，真实完整张量无条件保持同一 Sylvester 惯性指数 [[23]](#ref-23) $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0)$。□

![图4：对角有理区间、球面通量翻转、Gershgorin 包围与三窗口显微放大。](figures/fig03-inertia-v2.svg)

**图 4　对角有理区间、球面通量翻转、Gershgorin 包围与三窗口显微放大。** 单位统一为 $10^{-20}$。上层（A）展示全尺度 $[-2.05,+2.55]$ 上未中心化（`raw`，深蓝）与连通部分（`connected`，金色）的三主轴严格有理区间及 $\pm 2|K_{ij}|$ Gershgorin 行圆盘包络，并标出 `raw` 第二主轴从仅含球内体项的伪负值 $-0.19$ 经两类球面通量 $+2.38$ 跨过朱红零线逆转为 $+2.16$ 正峰的过程；全部六个圆盘包络与零线保持逾 $1.2\times 10^{-20}$ 的严格分离。下层（B）并列三个局部显微放大窗口：左窗（$\times 27$）与中窗（$\times 20$）清晰分辨 $0.046\times 10^{-20}$ 二进有理紧核与外层 Gershgorin 圆盘外晕，右窗展示均值项 `mean` 在 $e_2$ 轴真实跨零（$[-0.001635,+0.003212]\times 10^{-20}$），故在 §1.2 表中如实单列而不作惯性号差裁决。

需要准确界定这一张量定理的几何与物理含义：任意实单位方向 $n\in S^2$ 上的极化曲率读数由二次型 $n^T\mathsf K_\alpha n$ 给出；惯性指数 $(2,1,0)$ 锁定了实正交对角化后的两个负主曲率与一个正主曲率，但并不要求笛卡尔坐标轴 $(e_1,e_2,e_3)$ 本身就是精确特征向量（非零混合项 $K_{ij}$ 允许对特征标架作微小正交旋转）。同时，该惯性刻画的是本案固定探针协议下五通道一次诱导极化振幅的外动量曲率号差，而非未扰动背景场自身的动力学谱稳定性。

## 12　全四复动量母作用二阶 Fréchet 变分认回与五维核 Schur 重构（Q5）

第 5 节在轴向与共同块可逆域上导出了五维原点轻核的二阶展开。现在我们回答更深一层的变分基础问题 [[6]](#ref-6), [[19]](#ref-19)：前文使用的 $289\times 289$ 线性化传播矩阵 $H_{289}(p)$，在任意四维复动量 $p\in\mathbb C^4$ 上是否精确等于原始非线性母作用密度关于全部一阶射流变量的二阶 Fréchet 导数？原点五维核能否不作二阶截断，直接扩展为全四复动量上的精确有理 Schur 反馈核，并将实际量子电流驱动的清分母 Green 解无损还原回全部 289 个场方向？本节给出完整肯定证明。

### 12.1　母作用密度一阶射流二阶 Fréchet 导数逐项认回 $H_{289}(p)$

<a id="prop-12-1"></a>

**命题 12.1（全四复动量母作用一阶射流二阶 Fréchet 变分与 $H_{289}(p)$ 的逐项恒等）。** 在九场背景的实一阶射流空间 $j\in\mathbb R^{1445}$（含 289 个场值与 $289\times 4$ 个时空一阶梯度槽）上，将全部九组场及其偏导数提升为母作用全纯局部配置，定义拉氏密度射流映射

\[
\mathcal L_{\mathrm{nat}}(j)=\mathcal L_{\mathrm{mother}}(\mathrm{Lift}(j)), \tag{12.1}
\]

其中 $\mathrm{Lift}$ 完整保留余标架、自旋联络、引力与规范辅助二形式、外幂标量、物质场及独立变分对偶的值与四维梯度。记该光滑密度在背景原点处的二阶 Fréchet 导数双线性型为

\[
\mathcal H=D^2\mathcal L_{\mathrm{nat}}(0). \tag{12.2}
\]

则其对应的 Fourier–Euler 二阶变分算符矩阵 [[6]](#ref-6) 对**每一个四复动量 $p\in\mathbb C^4$** 严格满足逐项恒等：

\[
K_{\rm nat}(p)_{ij}
=\sum_{\alpha,\beta\in\{\varnothing,0,1,2,3\}}
 \mathcal H(e_{\alpha i},e_{\beta j})
 s_\alpha(-p)s_\beta(p)
=H_{289}(p)_{ij},\qquad
s_\varnothing(p)=1,\quad s_\mu(p)=p_\mu, \tag{12.3}
\]

其中 $e_{\alpha i}$ 为实一阶射流标准基（空指标 $\varnothing$ 表场值本身，$\mu=0,1,2,3$ 表对应偏导数槽）。

**证明。** 射流提升后的密度 $\mathcal L_{\mathrm{nat}}$ 与式 (2.4) 的局部作用密度逐点同一，其多项式—有理光滑性直接给出二阶 Fréchet 导数 $\mathcal H$ 及其对称双线性性。全部 $289\times 5=1,445$ 个实射流槽悉数保留（经母背景代数限制后共有 $637$ 个非零活跃射流槽）：引力、规范、外幂标量与独立对偶物质四个部门分别产生 $234$、$406$、$220$ 与 $790$ 个二次射流项，总计 $1,650$ 项。对每一二次项保留左、右分部积分 Euler 号，展开为 $3,300$ 个双腿 Fourier 单项式；在代数数域 $\mathbb Q(\sqrt2,\sqrt{15})$ 的四根基 $(1,\sqrt2,\sqrt{15},\sqrt{30})$ 上合并同动量多指标项后，精确生成包含 $3,071$ 条非零记录的原 Jacobi 字典，与前文 $H_{289}(p)$ 在全部四复动量多项式系数上逐字节全等。□

### 12.2　五列原点零模核与 98 维非正交直和坐标补空间

简记 $H(p)=H_{289}(p)$。母系数表生成可逆多项式场变换 $F(p)$ 及其双侧精确逆，令块约化矩阵为 $D(p)=F(-p)^TH(p)F(p)$。该矩阵自然分解为代数接触块、$103$ 个动力学活跃坐标与 $9$ 个规范／对称零模方向。记补零嵌入至 $289\times 289$ 的活跃块矩阵为 $K(p)$，对应坐标投影算符依次记作 $P_a$（活跃，秩 $103$）、$P_c$（接触）与 $P_n$（九零模），满足完备正交直和 $P_a+P_c+P_n=I_{289}$ 及形式转置律 $K(-p)^T=K(p)$。

以 $e_j$ 表示该变换后坐标下的标准单位列向量。活跃块在原点 $p=0$ 处的五维零空间由矩阵 $N=(n_0,\ldots,n_4)\in\mathbb C^{289\times5}$ 精确张成：

\[
 n_0=\frac{3\sqrt2}{10}(e_{21}-e_{34})+e_{79}+e_{83},\qquad
 n_1=\frac{3\sqrt2}{10}(e_{21}-e_{34})+e_{79}+e_{85}, \tag{12.4}
\]

\[
 n_2=e_{89}-e_{91},\qquad n_3=e_{95}-e_{97},\qquad
 n_4=e_{101}-e_{103}+e_{107}-e_{109}, \tag{12.5}
\]

其中前两列由正则占据制备态生成，后三列由独立变分对偶生成，满足 $K(0)N=0$。定义五维坐标读出映射 $C:\mathbb C^{289}\to\mathbb C^5$ 为 $Cx=(x_{83},x_{85},x_{89},x_{95},x_{101})$，直接代入验证得左逆关系 $CN=I_5$（故 $N$ 单射）。进而定义 $98$ 维坐标补投影：

\[
 P_h=P_a-\sum_{j\in\{83,85,89,95,101\}}e_je_j^T.
\]

对任意活跃场 $P_ax=x$，置五维核坐标为 $c_N=Cx\in\mathbb C^5$、剩余向量为 $y=x-Nc_N$，则 $Cy=Cx-CNc_N=0$，故必有 $P_hy=y$。与 Feshbach 正交子空间投影 [[19]](#ref-19) 不同，这里的 $\operatorname{Im}N\oplus\operatorname{Im}P_h$ 是**斜直和坐标补分解**：五列向量 $n_0,\ldots,n_4$ 本身在补坐标（如指标 $21,34,79,91,97,103,107,109$）上亦携带非零耦合分量，避免了无理正交化破坏有理系数结构。

### 12.3　$45+21+32$ 三分块原点双侧逆与非空四动量正则域

$98$ 维补空间投影 $P_h$ 按母作用稀疏耦合结构精确裂解为三个互不相交的不变坐标块，维数分别为 $45,21,32$，完整指标集为：

\[
\begin{aligned}
 I_{45}=\{&9,10,15,16,19,20,21,22,27,28,31,32,33,34,39,\\
 &40,43,44,45,46,51,52,55,56,57,58,59,60,61,62,\\
 &63,64,65,66,67,69,70,72,73,75,76,79,80,82,86\},\\
 I_{21}=\{&88,90,91,92,93,94,96,97,98,99,100,102,\\
 &103,104,105,106,107,108,109,110,111\},\\
 I_{32}=\{&11,12,13,14,17,18,23,24,25,26,29,30,35,36,37,38,\\
 &41,42,47,48,49,50,53,54,68,71,74,77,78,81,84,87\}.
\end{aligned}
\]

记三组块投影为 $P_i$，原点子矩阵为 $A_i=P_iK(0)P_i$。精确代数系数表直接构造出三枚块逆 $B_i$，满足 $B_iA_i=P_i$、$P_iB_i=B_i=B_iP_i$ 以及跨块正交 $B_iA_j=0$（$i\ne j$）。令原点总补逆为 $B=\sum_iB_i$，则

\[
 B(P_hK(0)P_h)=P_h,\qquad P_hB=B=BP_h. \tag{12.6}
\]

在补空间之外用恒等算符 $I-P_h$ 填满全 289 维方阵，定义全动量增广矩阵 $A(p)=P_hK(p)P_h+(I-P_h)$ 及原点逆 $A_0^{-1}=B+(I-P_h)$。式 (12.6) 给出 $A_0^{-1}A(0)=I_{289}$；有限维方阵左逆必为双侧逆，故 $A(0)A_0^{-1}=I_{289}$ 且 $\det A(0)\ne 0$。多项式行列式的连续性遂无需任何外加假设即内生保证四复动量开集 $\mathcal U=\{p\in\mathbb C^4:\det A(p)\ne0\}$ 非空且包含原点 $0$。在 $\mathcal U$ 上置补空间动态格林算符为 $G_c(p)=P_hA(p)^{-1}P_h$，双侧支撑消元立得

\[
 G_cKP_h=P_h,\quad P_hKG_c=P_h,\quad G_c(0)=B. \tag{12.7}
\]

### 12.4　全四复动量精确 Schur 核与活跃场恢复定理

<a id="thm-12-2"></a>

**定理 12.2（全四复动量 $5\oplus 98$ 原点核 Schur 重构与清分母全 289 场恢复）。** 在四复动量正则域 $\mathcal U$ 上，定义五维精确有效核 $E(p)\in\mathbb C^{5\times5}$、五维源压缩映射 $L_S(p)\in\mathbb C^{5\times289}$ 与五列动态修饰嵌入 $N_{\mathrm{eff}}(p)\in\mathbb C^{289\times5}$：

\[
 E(p)=N^TK(p)N-N^TK(p)G_c(p)K(p)N, \tag{12.8}
\]

\[
 L_S(p)=N^T-N^TK(p)G_c(p),\qquad N_{\rm eff}(p)=N-G_c(p)K(p)N. \tag{12.9}
\]

则对满足活跃场方程 $K(p)x=s$（$P_ax=x$）的任意场向量，令 $c_N=Cx\in\mathbb C^5$、$y=x-Nc_N$，其补空间分量、五维有效动力学方程及全活跃场重构恒等式精确为

\[
 y=G_c(s-KNc_N),\qquad E(p)c_N=L_S(p)s, \tag{12.10}
\]

\[
 x=N_{\rm eff}(p)c_N+G_c(p)s. \tag{12.11}
\]

**证明。** 将 $K(p)(Nc_N+y)=s$ 左乘 $P_h$ 后再左乘 $G_c(p)$，由式 (12.7) 的 $G_cKP_h=P_h$ 与 $P_hy=y$ 立即解出 $y=G_c(s-KNc_N)$。另一方面，由式 (12.9) 与 $P_hKG_c=P_h$ 可验 $L_S(p)K(p)P_h=N^TKP_h-N^TKG_cKP_h=0$：故用 $L_S(p)$ 左乘 $K(p)(Nc_N+y)=s$ 时，98 维补场 $y$ 被一步精确消去，留下 $L_S(p)K(p)Nc_N=E(p)c_N=L_S(p)s$。最后将 $y$ 的表达式代回 $x=Nc_N+y$ 即得式 (12.11)。特别在 $p=0,s=0$ 处，由 $K(0)N=0$ 得 $y=0$，证实 $N$ 的五列完整张成活跃块在原点的全部零空间。□

### 12.5　显式局部 Neumann 收敛半径 $\rho$ 与整块三阶预解余项界

记动量差分为 $\Delta K(p)=K(p)-K(0)$。将原点一次替换算符展开为动量多项式，可分离出 $36$ 项一、二次齐次表 $T_{12}(p)$ 与 $48$ 项三、四次齐次表 $T_{34}(p)$：

\[
 N^TKN-N^TKBKN=T_{12}+T_{34}. \tag{12.12}
\]

利用原点零模条件 $K(0)N=0$ 与对称律 $K(0)^T=K(0)$，精确有效核 (12.8) 具有无截断预解分解

\[
 E=T_{12}+T_{34}-N^T\Delta K\,(G_c-B)\Delta K\,N. \tag{12.13}
\]

在矩阵最大行和范数下，对 $\mathbb Q(\sqrt2,\sqrt{15})$ 代数系数引入有理向外权范数：

\[
 \operatorname{wt}(a+b\sqrt2+c\sqrt{15}+d\sqrt{30})
 =|a|+2|b|+4|c|+8|d|. \tag{12.14}
\]

对各字典逐单项式累加，由母系数直接算出四个显式有理上界常数：

\[
 I_B=1+\frac{3267130962160409}{14460684885900},\qquad
 V_B=1+\frac{1359392}{375},\qquad
 N_B=\frac{72}{5},\qquad H_B=\frac{4200156368}{32034375}, \tag{12.15}
\]

它们依次控制原点补逆 $A_0^{-1}$、动量差分 $\Delta K$、五列矩阵 $N$ 及其转置以及高次表 $T_{34}$。由此定义源生四复动量局部 Neumann 半径：

\[
 \rho=(4I_BV_B)^{-1}
 =\frac{1355689208053125}{4462200029129218450003}. \tag{12.16}
\]

凡在四复动量多圆盘 $0\le\max_\mu|p_\mu|\le r\le\rho$ 内，恒有 $\|A_0^{-1}[A(p)-A(0)]\|\le 1/4<1$，故 Neumann 级数绝对收敛并给出一致范数界 $\|G_c(p)\|\le 2I_B$。结合精确预解差分恒等式

\[
 G_c-B=-G_c\Delta K B \tag{12.17}
\]

与 $\|\Delta K\|\le V_Br$，立得 $\|G_c(p)-B\|\le 2I_B^2V_Br$；再并入 $\|N\|,\|N^T\|\le N_B$ 及 $\|T_{34}(p)\|\le H_Br^3$（$r\le 1$），代入式 (12.13) 逐因子相乘，即证整个 $5\times 5$ 有效核与二阶截断表 $T_{12}(p)$ 之间的严格三阶余项界：

\[
 \|E(p)-T_{12}(p)\|
 \le C_Er^3,\qquad
 C_E=H_B+2N_B^2I_B^2V_B^3. \tag{12.18}
\]

注意此处的 $\rho$ 专用于控制一般四复动量 $p\in\mathbb C^4$ 的局部补逆，而前文第 7–11 节三维实动量球 $|k|\le B$ 的解析根域仍由式 (9.15) 的 $\rho_*=1/8192$ 独立承保。

### 12.6　清分母受约束 Green 解的全 289 场（含接触与九零模）同时返回

取定准备响应点 $q$、独立左／右实动量 $p_L,p_R$、静止外态、读频 $\lambda$ 及有限年龄窗 $T$，记母作用生成的两部门量子电流窗口之和为 $J\in\mathbb C^{289}$；在四动量 $P=(\lambda,i(p_R-p_L))$ 下，其变换共源为 $\kappa=F(-P)^TJ$。

设原场有理格林矩阵的共同多项式分母为 $d(P)$，清分母后的整系数多项式伴随格林矩阵记作 $\widetilde G(P)$。由量子流驱动生成的清分母全场向量 $\widetilde X=\widetilde G(P)J$ 精确满足含九维零模相容投影的母方程：

\[
 \widetilde X=\widetilde G(P)J,\qquad
 H(P)\widetilde X=d(P)\{J-F(-P)^{-T}P_n\kappa\}. \tag{12.19}
\]

置活跃分量 $x=P_aF(P)^{-1}\widetilde X$ 与活跃源 $s=d(P)P_a\kappa$，用 $P_aF(-P)^T$ 左乘式 (12.19) 第二式并利用 $P_aP_n=0$，立得活跃块方程 $K(P)x=s$。于是定理 12.2 直接作用于该真实量子流响应场，而将接触投影 $P_c$、活跃块重构 (12.11) 与九零模投影 $P_n$ 三部分重新变换相加，即逐分量恢复完整的清分母 289 维原场：

\[
\begin{split}
 \widetilde X={}&F(P)P_cF(P)^{-1}\widetilde X\\
 &+F(P)\{N_{\rm eff}(P)c_N+G_c(P)s\}\\
 &+F(P)P_nF(P)^{-1}\widetilde X.
\end{split} \tag{12.20}
\]

在静止外态插入下，电流支撑结构进一步锁死原点五列原坐标读出矩阵 $N_{\mathrm{native}}(0)=F(0)N\in\mathbb C^{289\times 5}$ 的精确配对：

\[
 N_{\rm native}(0)^T J=(w_J,w_J,0,0,0),\qquad
 w_J=\frac{3\sqrt2}{10}(J_{21}-J_{34}),\quad N_{\rm native}(0)=F(0)N, \tag{12.21}
\]

且在多圆盘 $\max_\mu|P_\mu|\le r\le\rho$ 上，五维有效核坐标 $c_N$ 满足二阶近似残差界

\[
 \|T_{12}(P)c_N-L_S(P)s\|\le C_Er^3\|c_N\|. \tag{12.22}
\]

凡在非极点域 $d(P)\ne 0$ 读取未清分母物理场时，仅需将式 (12.20) 两端同除以标量分母 $d(P)$，接触项、五维轻核、98 维重补空间与九个零模相容方向无一遗漏。

## 13　配置空间有序历史、非线性有限窗 $289\times289$ 极化张量与 Cauchy 返回（Q6）

前文第 6–11 节考察了单粒子 12 维位置球滤波态在外加规范余弦微扰下的极化曲率。现在进入完整多体配置 Hilbert 空间 $\mathscr H_{\mathrm{cfg}}$（由 100 维配置流形半密度测度与 504 模整体 CAR Fock 载体张成 [[1]](#ref-1)）：当输入扩展为全部 289 个实场方向的非线性时间历史，且观测泛函取真实 CAR 创建单位态减去同源背景态时，量子极化如何反馈回母作用 Euler 方程？本节建立实场正半轴响应算子 $\mathcal J_\infty$、非线性共同正窗口 $[0,\tau)$ 上的完整 $289\times 289$ 极化张量 $\Pi_{d,T}(P,\lambda)$ 及含端点共源的电压 Cauchy 全场更新（注意这里的五因子时间—预解核、创建减背景泛函与时间窗口条件同第 7–11 节的双球窗设置各自独立）。

### 13.1　从配置空间有序五因子核到实 289 场正半轴算子 $\mathcal J_\infty$

在 $\mathscr H_{\mathrm{cfg}}$ 上固定配置准备响应点 $q$：正准备精度、物质动量 $p$、动量转移 $k$、有限标架 $F$、两条完整准备腿以及满足 $\operatorname{Im}z\ne 0,\operatorname{Im}w\ne 0$ 的独立物质复频率 $(z,w)$（外部观察波矢 $w_{\mathrm{obs}}\in\mathbb R^3$ 与场 Laplace 频率 $\lambda$ 与 $(z,w)$ 彼此独立）。对实场微扰 $h$，由左、右双向时间演化、左、右物质预解逆与中央原始变分流算符按固定顺序相乘，组成有序五因子算符核：

\[
\mathcal W(h,t)=U_+(h,-t)R_+(h,z)B_{\rm raw}(h)R_-(h,w)U_-(h,t). \tag{13.1}
\]

在半密度权重 $W$ 下，中央原始流算符是在完成独立对偶纤维乘积后执行一次完整 CAR 二次量子化所得的 $-4W\,DH$，对应二阶接触项为 $-4(DW\,DH+W\,D^2H)$。沿实方向 $h=rf$（$f\in\mathbb R^{289}$）在 $r=0$ 求导时，五因子乘积法则依次落在左时间、左预解逆、中央流算符、右预解逆与右时间上，最后才在整词外侧施加制备态内积。

从原始变分读出 $J_{\mathrm{raw}}$ 过渡到固定独立正则动量的 Noether 流读出 $J_N$ 时，零场背景处虽有 $J_N(0)=J_{\mathrm{raw}}(0)$，但沿场方向 $f$ 的一阶变分斜率携带非零的**中央运输接触差**：

\[
 S_q^N=S_q^{\mathrm{raw}}+
 \langle v_{L,q},(J_N'[f]-J_{\mathrm{raw}}'[f])v_{R,q}\rangle, \tag{13.2}
\]

其中 $v_{L,q},v_{R,q}$ 为已含零场时间演化与物质预解逆的左、右制备态矢（外侧四处因子导数保持原值，中央接触导数按式 (13.2) 精确补齐）。进而，实作用密度中的 $\operatorname{Re}(\pi\psi)$ 耦合同时激活正向、反向与左／右交叉共四条实路径：记补齐中央接触后的四路斜率依次为 $F,R,D_R,D_L$，则完整实作用密度在动量空间产生的四个转移频点组装为

\[
 -\frac12\left[
 \delta_{-k}(F+\overline R)+\delta_k(R+\overline F)
 +\delta_{2p+k}(D_R+\overline{D_L})
 +\delta_{-(2p+k)}(D_L+\overline{D_R})\right], \tag{13.3}
\]

其中 $\delta_v$ 表示有限支集动量谱在频点 $v$ 处的点质量——当特定 $(p,k)$ 使不同频点重合时，**必须先将重合频点的复幅值相加合并，再在指定观察波矢 $w_{\mathrm{obs}}$ 处求值**；外侧负号对应母 Euler 方程将源项移至右端的一次标准变号。

固定观察波矢 $w_{\mathrm{obs}}\in\mathbb R^3$，记融合了中央接触修正 (13.2) 与四频点合账 (13.3) 后的实 Noether–Euler 源导数算符为 $\mathcal D_q(t):\mathbb R^{289}\to\mathbb C^{289}$。共同场系数的 $C^2$ 光滑性与紧时间参数管上的局部一致可积支配保证有限窗口强迫积分满足精确 Fréchet 导数恒等式：

\[
D_h J_T(q,h;\lambda)|_{h=0}[f]
=\int_0^Te^{-\lambda t}\,\mathcal D_q(t)f\,dt. \tag{13.4}
\]

<a id="prop-13-1"></a>

**命题 13.1（完整实 289 场输入的正半轴 Noether–Bochner 响应算子与指数尾界）。** 对一切右半平面频率 $\operatorname{Re}\lambda>0$，母源参数内生给出有限正数 $C_q(\lambda)\ge 0$，使算子范数满足指数衰减支配

\[
\|e^{-\lambda t}\mathcal D_q(t)\|
\le C_q(\lambda)e^{-\Re\lambda\,t/2},\qquad t\ge0, \tag{13.5}
\]

从而正半轴算子值 Bochner 积分 $\mathcal J_\infty(q,\lambda)\in\mathcal L(\mathbb R^{289},\mathbb C^{289})$ 绝对收敛，且有限窗算子 $\mathcal J_T$ 以显式指数率在算子范数下收敛于 $\mathcal J_\infty$：

\[
\mathcal J_\infty(q,\lambda)
=\int_0^\infty e^{-\lambda t}\mathcal D_q(t)\,dt,
\qquad
\|\mathcal J_\infty-\mathcal J_T\|
\le\frac{2C_q(\lambda)}{\Re\lambda}
 e^{-\Re\lambda T/2}. \tag{13.6}
\]

**证明。** 共同时间生成元分解为保粒子数分级项 $C$ 与升分级项 $A$，线性常微分方程初值唯一性将部分演化截断为精确的 $57$ 项有限和，从而在全实轴 $t\ge 0$ 上只产生关于 $t$ 的有限阶多项式范数增长。结合 Duhamel 变分、五因子时间射流、中央接触差 (13.2) 与四频点组装 (13.3)，对固定 $(q,F,z,w)$ 取 $\eta=\operatorname{Re}\lambda/8>0$，利用初等界 $t^me^{-\eta t}\le m!/\eta^m$ 吸收全部时间多项式因子，再对 289 个标准输入基与输出分量求和即得式 (13.5)。连续性保证强可测，指数支配 (13.5) 给出 Bochner 可积性，对 $[T,\infty)$ 积分尾项立得式 (13.6)。□

**经母 Green 与曲率算符的全场回代。** 记母作用内生导出的普通二形式曲率线性读出矩阵为 $\mathcal R_{36}(P)\in\mathbb C^{36\times289}$，九零模相容源投影算符记为 $\mathcal C(P)=P_nF(-P)^T\in\mathbb C^{289\times289}$，逆转置源提升记为 $L_{\mathrm{src}}(P)=F(-P)^{-T}\in\mathbb C^{289\times289}$（区别于第 12.4 节的 $5\times 289$ 映射 $L_S$）。在取观察波矢 $w_{\mathrm{obs}}=k$ 使 $P_k=(\lambda,ik)$ 落入受约束 Green 矩阵 $\mathcal G(P_k)$ 的正则可逆域时，命题 12.1 的母 Hessian 恒等式直接给出半轴量子响应场的精确母方程：

\[
K_{\rm nat}(P_k)\mathcal G(P_k)\mathcal J_\infty f
=\mathcal J_\infty f-L_{\mathrm{src}}(P_k)\mathcal C(P_k)\mathcal J_\infty f; \tag{13.7}
\]

因场解图关于时间导数至多二阶，两次分部积分保留 $t=0$ 初始端点共源，而 $T\to\infty$ 终端项由同一指数衰减界压为零，使完整 289 场及 $\mathcal R_{36}$ 曲率读数同步取得算子范数半轴极限。

### 13.2　CAR 创建单位态减同源背景差泛函 $\ell_d$ 与非线性历史演化

现在固定实际修饰源事件参数组：

\[
d=(\epsilon>0,\ p\in\mathbb R^3,\ F,\ m\in\mathbb N,\ \zeta\in\mathbb C,\ \Im\zeta\ne0), \tag{13.8}
\]

其中 $\epsilon$ 为配置准备精度，$p$ 为物质动量，$F$ 为有限标架，$m$ 为截断阶指标，$\zeta$ 为左、右两条物质预解逆共用的非实复频率；另固定物理动量转移 $k\in\mathbb R^3$。

记配置准备映射 $\mathcal P$ 生成的归一化背景态矢为 $v_\epsilon=\mathcal Px_\epsilon$（$\|v_\epsilon\|=1$）。在 504 模整体 CAR 创建算符分支上取通道 $1$、自旋指标 $0$ 生成激发腿 $\mathcal A_{\mathrm{cr}}x_\epsilon$：由于源参数盒上标量系数恒不低于 $1/2$，利用未占用颜色通道的湮灭算符反提原准备态，半密度配对与 CAR 反对易范数恒等式给出严格正下界

\[
\|\mathcal P x\|^2
\le4\|\mathcal A_{\rm cr}x\|^2, \tag{13.9}
\]

故单位背景 $\|v_\epsilon\|=1$ 保证创建腿严格非零 $\|\mathcal A_{\mathrm{cr}}x_\epsilon\|\ge 1/2>0$。乘上非零电磁修饰特征标后记作 $g_\epsilon$，归一化即得单位创建态：

\[
u_\epsilon=g_\epsilon/\|g_\epsilon\|,
\qquad\|u_\epsilon\|=\|v_\epsilon\|=1. \tag{13.10}
\]

在整串非交换算符词完全乘毕之后，施加携带原母 Euler 负号的**产生态减同源背景差泛函**：

\[
\ell_d(A)=-\langle u_\epsilon,A u_\epsilon\rangle
+\langle v_\epsilon,A v_\epsilon\rangle,
\qquad\|\ell_d\|\le2, \tag{13.11}
\]

（两个单位态的内积各由 Cauchy–Schwarz 控制在 $\|A\|$ 以内，故算子对偶范数 $\|\ell_d\|\le 2$；注意 $\ell_d$ 比较的是多体创建态 $u_\epsilon$ 与背景态 $v_\epsilon$，与第 6.3 节固定单粒子态下的 $I-P$ 投影分解各司其职）。

置 $p_-=p,p_+=p-k$，记依赖于瞬时实场的共同时间生成元为 $G_\pm(h)$、物质预解逆为 $R_\pm(h)$、中央 Noether 变分读出算符为 $N_f(h)$。对任意在 $t=0$ 邻域具有 $C^1$ 时间正则性的实 289 场历史 $h(t)$，母源系数在闭幅度—时间矩形上给出一致 Lipschitz 界，由 Picard–Volterra 压缩不动点生成正幅度半径与正时间窗口上的真实非线性双侧演化算子：

\[
\begin{gathered}
\partial_tU_\rho(t)=A_{-,\rho}(t)U_\rho(t),
\qquad
\partial_tV_\rho(t)=-V_\rho(t)A_{+,\rho}(t),\\
A_{\pm,\rho}(t)=-iG_\pm(\rho h(t)),
\qquad U_\rho(0)=V_\rho(0)=I,
\end{gathered} \tag{13.12}
\]

其中左腿独立对偶演化 $V_\rho(t)$ 严格保持右乘微分次序。由 Gronwall 不等式与差商一致支配收敛，在零幅度 $\rho=0$ 处存在真正的参数导数（记零幅度自由演化为 $U_0,V_0$，生成元场导数为 $J_\pm(h)$）：

\[
\dot U(t)=U_0(t)\int_0^tU_0(-s)(-iJ_-(h(s)))U_0(s)\,ds, \tag{13.13}
\]

\[
\dot V(t)=-\left[\int_0^tV_0(s)(-iJ_+(h(s)))V_0(-s)\,ds\right]V_0(t),
\quad
\dot R_\pm=-R_\pm J_\pm(h(0))R_\pm,
\quad\dot N_f=N_f'[h(t)]. \tag{13.14}
\]

先在 $\mathscr H_{\mathrm{cfg}}$ 上合成非线性五因子有序算符核

\[
\mathcal K_{f,\rho}(t)
=V_\rho(t)R_+(\rho h(0))N_f(\rho h(t))R_-(\rho h(0))U_\rho(t), \tag{13.15}
\]

其在 $\rho=0$ 处的零幅度真导数精确展开为五项有序和：

\[
\begin{aligned}
\partial_\rho\mathcal K_{f,\rho}(t)|_0={}&
\dot V R_+N_fR_-U_0
+V_0\dot R_+N_fR_-U_0
+V_0R_+\dot N_fR_-U_0\\
&+V_0R_+N_f\dot R_-U_0
+V_0R_+N_fR_-\dot U,
\end{aligned} \tag{13.16}
\]

其中中央项 $\dot N_f$ 完整包含运输后的 Noether 接触导数；令中央场方向 $f$ 跑遍全部 $289$ 个标准基元并外施同一泛函 $\ell_d$，即得非线性配置准备的全部量子源导数。

### 13.3　正交双实历史与全 $289\times289$ 因果极化张量 $\Pi_{d,T}(P,\lambda)$

给定任意四复动量 $P=(P_0,P_1,P_2,P_3)\in\mathbb C^4$ 与任意复场振幅向量 $a\in\mathbb C^{289}$，构造一对正交相位实空间场信号：

\[
h_a(x)=\Re(e^{P\cdot x}a),\qquad
h_{-ia}(x)=\Re(e^{P\cdot x}(-ia)). \tag{13.17}
\]

取两份实信号各自 Picard 正存在窗口的最小值，得到源生共同正窗口 $\tau(d,k,P,a)>0$。记五项导数 (13.16) 经 $\ell_d$ 读出在全部 289 行上诱导的实线性映射为 $L_d(P,t):\mathbb C^{289}_{\mathbb R}\to\mathbb C^{289}$，通过正交双相位合成

\[
\mathscr D_d(P,t)a=L_d(P,t)a+iL_d(P,t)(-ia), \tag{13.18}
\]

实线性性直接蕴涵 $\mathscr D_d(P,t)(ia)=L_d(P,t)(ia)+iL_d(P,t)a=i\mathscr D_d(P,t)a$，故 $\mathscr D_d(P,t)$ 在 $\mathbb C^{289}$ 上严格复线性。按标准基列定义 $289\times 289$ 瞬时极化矩阵

\[
\Pi_d(P,t)_{ij}=\bigl(\mathscr D_d(P,t)e_j\bigr)_i, \tag{13.19}
\]

则对一切 $a\in\mathbb C^{289}$ 恒有 $\mathscr D_d(P,t)a=\Pi_d(P,t)a$（完整保留含九个标量轨道方向在内的全部 289 个输入与输出槽）。

记同一实幅度参数 $r$ 下，两份真实全纯提升母 Euler 残差的正交复组合减去非线性配置准备读数为总耦合残差 $E_d(r,t)$。将命题 12.1 的经典母 Euler 二阶变分身份与式 (13.16)–(13.19) 的量子准备零幅度导数逐行相减，在共同正窗口上精确得到

\[
\partial_rE_d(r,t)|_0
=K_{\rm nat}(P)e^{P_0t}a-\Pi_d(P,t)a,
\qquad0\le t<\tau(d,k,P,a). \tag{13.20}
\]

引入有限窗口指数时间权因子与频域有限窗极化张量：

\[
W_T(P_0,\lambda)=\int_0^Te^{-\lambda t}e^{P_0t}\,dt,
\qquad
\Pi_{d,T}(P,\lambda)=\int_0^Te^{-\lambda t}\Pi_d(P,t)\,dt. \tag{13.21}
\]

<a id="thm-13-2"></a>

**定理 13.2（非线性共同正窗口上的完整母 Euler 零幅度导数响应铅笔）。** 对任意复 Laplace 参数 $\lambda\in\mathbb C$、任意 $P\in\mathbb C^4,a\in\mathbb C^{289}$ 及共同正窗口内的任意截点 $0\le T<\tau(d,k,P,a)$，非线性母 Euler—量子耦合残差的零幅度导数有限积分严格等于矩阵铅笔作用：

\[
\boxed{\int_0^Te^{-\lambda t}\partial_rE_d(r,t)|_0\,dt
=\bigl[W_T(P_0,\lambda)K_{\rm nat}(P)-\Pi_{d,T}(P,\lambda)\bigr]a.} \tag{13.22}
\]

**证明。** 在 $[0,T]\subset[0,\tau)$ 上，式 (13.20) 两端关于 $t$ 连续，故有限维矩阵线性运算与定积分严格交换：经典母 Euler 项积分得 $W_T(P_0,\lambda)K_{\mathrm{nat}}(P)a$，量子准备导数项积分得 $\Pi_{d,T}(P,\lambda)a$，相减即证式 (13.22)。特别当观测时钟与输入信号时钟重合（$\lambda=P_0$）时，$e^{(P_0-\lambda)t}\equiv 1$ 给出 $W_T(P_0,P_0)=T$（此处保留积分原值而不人为除以 $T$）；而在异钟情形下（例如 $P=0,\lambda=1,T=1$），$W_1(0,1)=1-e^{-1}\ne 1$，式 (13.22) 原封不动保留精确指数时间权。□

与非线性有限窗口 $0\le T<\tau$ 并列，**线性化算子 $\mathscr D_d(P,t)$ 本身**在更宽的半平面上拥有无穷半轴 Bochner 极限：记输入信号增长率为 $\gamma(P)=\max(0,\operatorname{Re}P_0)$，只要频率满足正裕度 $\Delta=\operatorname{Re}\lambda-\gamma(P)>0$，双单位态范数、共同场 $C^2$ 界与多项式时间演化界即生成有限常数 $C_d=C_d(k,P,\lambda)\ge 0$，使得

\[
\|e^{-\lambda t}\mathscr D_d(P,t)\|
\le C_d e^{-\Delta t/2}\qquad(t\ge0), \tag{13.23}
\]

从而导出正半轴极限矩阵 $\Pi_\infty=\int_0^\infty e^{-\lambda t}\Pi_d(P,t)\,dt$ 及其显式算子范数指数尾界

\[
\|\Pi_\infty-\Pi_T\|
\le\frac{2C_d}{\Delta}e^{-\Delta T/2}\qquad(T\ge0). \tag{13.24}
\]

图 5 清晰并列了这三组不可混同的收敛域条件：实场半轴算子要求 $\operatorname{Re}\lambda>0$（命题 13.1），非线性历史真导数铅笔要求 $0\le T<\tau(d,k,P,a)$（定理 13.2），线性化极化半轴极限要求 $\operatorname{Re}\lambda>\gamma(P)$（式 (13.24)）。

### 13.4　时间射流端点共源与电压 Cauchy 全场更新闭合

由双实历史构造可知，量子强迫源向量满足 $\Pi_{d,T}(P,\lambda)a=j_T[h_a]+i\,j_T[h_{-ia}]$。在受约束母 Green 矩阵 $\mathcal G(P_k)$（$P_k=(\lambda,ik)$）的正则域上，将该量子强迫项 $j_T=\Pi_{d,T}(P,\lambda)a$ 代入母 Green，命题 12.1 的母 Hessian 身份立即给出全 289 场响应方程

\[
x_T=\mathcal G(P_k)j_T,
\quad
K_{\rm nat}(P_k)x_T=j_T-L_{\mathrm{src}}(P_k)\mathcal C(P_k)j_T, \tag{13.25}
\]

而对量子强迫项的零、一、二阶时间射流逐项执行两次分部积分，则精确分离出内部时间源与 $t=0,T$ 两个同源边界端点项：

\[
F(-P_k)^Tj_T
=\int_0^Te^{-\lambda t}j_{\rm time}(t)\,dt
-\bigl[B_\lambda(T)-B_\lambda(0)\bigr], \tag{13.26}
\]

其中 $j_{\mathrm{time}}=j_{\mathrm{time}}[h_a]+i\,j_{\mathrm{time}}[h_{-ia}]$ 与 $B_\lambda=B_\lambda[h_a]+i\,B_\lambda[h_{-ia}]$ 共用同一正交复相位组合。

**电压 Cauchy 更新实例。** 给定静态电压源诱导的线性时间 Cauchy 复历史 $h_{\mathrm v}(t)=u_{\mathrm v}(k)+t\,v_{\mathrm v}$（$u_{\mathrm v}(k)$ 为空间电压向量，$v_{\mathrm v}$ 为时间斜率向量），取其实部与虚部两路实 Cauchy 信号，记经典窗口积分场为 $X_{\mathrm{cl},T}=\int_0^Te^{-\lambda t}h_{\mathrm v}(t)\,dt$，两路信号经五项导数生成的量子强迫向量记作 $j_T^{\mathrm{Re}},j_T^{\mathrm{Im}}$。将经典窗口 Green 恒等式与两路量子强迫响应相加，得到完整电压 Cauchy 更新场：

\[
 X_{\mathrm{upd},T}=X_{\mathrm{cl},T}
 -F(P_k)P_nF(P_k)^{-1}X_{\mathrm{cl},T}
 +\mathcal G(P_k)j_T^{\mathrm{Re}}+i\mathcal G(P_k)j_T^{\mathrm{Im}}, \tag{13.27}
\]

其上 36 维普通曲率读出矩阵 $\mathcal R_{36}(P_k)$ 逐行作用并完整保留初末共源、九零模投影扣除与实虚两路量子反馈，同时为下游 72 维全纯规范曲率及物理频率极点匹配 [[2]](#ref-2), [[3]](#ref-3) 保全全部 289 个场分量。

![图5：母作用二阶 Fréchet 变分认回、四动量 Schur 重构与非线性 Noether 极化返回。](figures/fig04-full-return-v2.svg)

**图 5　母作用二阶 Fréchet 变分认回、四动量 Schur 重构与非线性 Noether 极化返回。** 顶栏：母作用密度在 1,445 个实一阶射流槽上的二阶 Fréchet 导数在全部 $p\in\mathbb C^4$ 上逐项认回 $H_{289}(p)$（命题 12.1）。上半部（Q5）：五列原点核与 $45+21+32$ 直和坐标补空间构造全四复动量 Schur 核 $E(p)$，从清分母 Green 解逐项恢复接触项、活跃块与全部九个零模方向（定理 12.2）。下半部（Q6）：配置空间有序五因子核先完成乘积再外施读出，中央项保留 raw 到 Noether 的接触修正并合并四个动量转移频点；左支路在 $\operatorname{Re}\lambda>0$ 上生成实场半轴算子 $\mathcal J_\infty$（命题 13.1），右支路以产生态减背景差泛函 $\ell_d$ 在非线性共同正窗口 $0\le T<\tau(d,k,P,a)$ 上生成完整 $289\times 289$ 极化张量与母 Euler 铅笔（定理 13.2，朱红聚焦），最终经同一母 Green 闭合 Cauchy 全场更新。

## 14　极小多项式 Sylvester 矩阵坍缩与穿衣光子连通源回馈（Q7）

### 14.1　交换代数整生成元与极小多项式商代数预解式

在静态输入时钟 $P_0=0$ 下，对任意 $\operatorname{Re}\lambda>0$，实际有限窗 Noether 矩阵 $\Pi_{d,T}((0,ik),\lambda)$ 收敛至 $\Pi_d^{\mathrm{st}}(k,\lambda)$。定理 `static_polarization_window_limit` 保持同一事件和动量转移，以独立 Laplace 频率 $\lambda$ 消费式 (13.24) 背后的源算子范数估计。经典 Sylvester 方程已有半群积分、级数和围道积分解法 [[28]](#ref-28), [[29]](#ref-29)。这里由母作用给出的全 $Y$ 左右生成元先于外力与读数生成共同多项式关系，商代数逆给出全部 $289^2$ 项共享的有限权重，并由实际创建态范数消去光子回馈中的准备相位。

固定穿衣事件 $d$ 与物理转移三动量 $k\in\mathbb R^3$，源内诱导的穿衣运动学点 $q=q(d,k)$ 将左、右双腿动量指派为 $(p_+,p_-)=(p_d-k,p_d)$（与 §13.2 一致），并保留有限参考标架 $F_d$ 与复预解频率 $z=w=\zeta_d$。在有界算子代数 $\mathcal B(\mathcal H)$ 上，记零谱频移与零背景场微扰下的完整空间演化算子为 $G(\cdot,F_d,0,0)$，定义左乘算子 $\mathcal L_q(X)=G(p_d-k,F_d,0,0)X$、右乘算子 $\mathcal R_q(X)=X\,G(p_d,F_d,0,0)$ 以及双侧联合 Sylvester 演化生成元：

\[
\mathcal T_q(X)=i\,\mathcal L_q(X)-i\,\mathcal R_q(X)
=i\,G(p_d-k,F_d,0,0)X-i\,X\,G(p_d,F_d,0,0),
\qquad X\in\mathcal B(\mathcal H). \tag{14.1}
\]

由算子结合律，左右乘法严格交换：$\mathcal L_q(\mathcal R_q(X))=G(p_d-k,F_d,0,0)X\,G(p_d,F_d,0,0)=\mathcal R_q(\mathcal L_q(X))$。在每个固定动量与标架处，完整空间演化算子 $G(\cdot,F_d,0,0)$（同时涵盖约化有限纤维与未切 $Y$ 外部词）均被源内构造的首一联合零化多项式零化，因而 $\mathcal L_q$ 与 $\mathcal R_q$ 均是复数域 $\mathbb C$ 上的代数整元素。交换环上代数整元素的标量倍数与和仍为代数整元素，故 $\mathcal T_q$ 在 $\operatorname{End}_{\mathbb C}(\mathcal B(\mathcal H))$ 中必为 $\mathbb C$ 上的代数整算子，从而唯一确定其首一极小多项式

\[
P_q(X)=\operatorname{minpoly}_{\mathbb C}(\mathcal T_q)\in\mathbb C[X],
\qquad N_q=\deg P_q<\infty,
\qquad P_q(\mathcal T_q)=0. \tag{14.2}
\]

尤为关键的是，$P_q(X)$ 完全由联合演化生成元 $\mathcal T_q$ 在选定任何场读出槽 $e_i$ 或外力槽 $e_j$ 之前内蕴生成。

当复频率偏离虚轴（$\operatorname{Re}\lambda\ne 0$）时，双侧演化铅笔 $\lambda I-\mathcal T_q$ 在 $\mathcal B(\mathcal H)$ 上拥有双侧连续逆 $\mathcal S_q(\lambda)=(\lambda I-\mathcal T_q)^{-1}$。将 $P_q(X)$ 对首一线性因子 $(X-\lambda)$ 作带余除法，得 $P_q(X)=(X-\lambda)Q_{q,\lambda}(X)+P_q(\lambda)$，其中商式次数满足 $\deg Q_{q,\lambda}=N_q-1<\deg P_q$。代入 $X=\mathcal T_q$ 并利用 $P_q(\mathcal T_q)=0$，得到 $(\mathcal T_q-\lambda I)Q_{q,\lambda}(\mathcal T_q)=-P_q(\lambda)I$。若 $P_q(\lambda)=0$，左乘双侧逆 $-\mathcal S_q(\lambda)$ 即推出 $Q_{q,\lambda}(\mathcal T_q)=0$，与 $P_q$ 的极小次数矛盾。由此无条件锁死谱避开性质：

\[
\operatorname{Re}\lambda\ne 0
\implies P_q(\lambda)\ne 0. \tag{14.3}
\]

现在转入 $N_q$ 维交换商代数 $\mathcal A_q=\mathbb C[X]/(P_q(X))$，记 $\bar X=X\bmod P_q$，其标准幂基为 $\{1,\bar X,\ldots,\bar X^{N_q-1}\}$。定义商铅笔元 $p_q(\lambda)=\lambda-\bar X\in\mathcal A_q$ 及商 Green 元：

\[
g_q(\lambda)=\frac{1}{P_q(\lambda)}\,\overline{P_q(X)/_{\mathrm m}(X-\lambda)}\in\mathcal A_q,
\qquad p_q(\lambda)\,g_q(\lambda)=1\quad(\operatorname{Re}\lambda>0), \tag{14.4}
\]

其中 $/_{\mathrm m}$ 表示对首一除子 $(X-\lambda)$ 的多项式商。事实上，在 $\mathcal A_q$ 中将 $P_q(X)=(X-\lambda)(P_q(X)/_{\mathrm m}(X-\lambda))+P_q(\lambda)$ 投射模去 $P_q(X)$，直接给出 $(\lambda-\bar X)\,\overline{P_q(X)/_{\mathrm m}(X-\lambda)}=P_q(\lambda)\cdot 1$；再乘以式 (14.3) 保证非零的标量 $P_q(\lambda)^{-1}$，即在不输入任何外部单位元证书的前提下证得 $p_q(\lambda)g_q(\lambda)=1$。

取商铅笔元 $p_q(\lambda)$ 在幂基 $\{1,\bar X,\ldots,\bar X^{N_q-1}\}$ 下的左乘表示矩阵 $M_q(\lambda)=\operatorname{LMat}_{\mathcal A_q}(p_q(\lambda))\in\mathbb C^{N_q\times N_q}$。由于左正则表示保持代数乘法与单位元，$M_q(\lambda)\operatorname{LMat}_{\mathcal A_q}(g_q(\lambda))=I_{N_q}$，故有限矩阵逆 $M_q(\lambda)^{-1}=\operatorname{LMat}_{\mathcal A_q}(g_q(\lambda))$ 恒存在。记幂基首单位坐标列向量为 $e_0=(1,0,\ldots,0)^{\mathsf T}\in\mathbb C^{N_q}$，定义 $N_q$ 维有理频率权重向量

\[
w_q(\lambda)=M_q(\lambda)^{-1}e_0\in\mathbb C^{N_q},
\qquad (e_0)_a=\delta_{a,0}\quad(0\le a<N_q), \tag{14.5}
\]

则 $w_q(\lambda)$ 恰为商 Green 元 $g_q(\lambda)$ 在幂基下的坐标展开：$g_q(\lambda)=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\bar X^a$。经由良定义的代数作用同态 $\Phi_q:\mathcal A_q\to\operatorname{End}_{\mathbb C}(\mathcal B(\mathcal H))$，$\bar X^a\mapsto\mathcal T_q^a$，商空间恒等式 $\Phi_q(g_q(\lambda))=\mathcal S_q(\lambda)$ 在右半平面 $\operatorname{Re}\lambda>0$ 上将无穷维双侧 Sylvester 预解式精确化为有限项生成元幂和：

\[
\mathcal S_q(\lambda)(A)=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\,\mathcal T_q^a(A),
\qquad \forall\,A\in\mathcal B(\mathcal H),\;\operatorname{Re}\lambda>0. \tag{14.6}
\]

### 14.2　两级受驱半逆与全 $289\times 289$ 静态 Noether 极化二次型

回到第 13 节的五因子有序核 (13.15)：在静态输入时钟 $P_0=0$ 下，对任意场读出槽 $e_i$ 与外力槽 $e_j$（$0\le i,j<289$），记原始初值顶点算子为 $I_q^{\mathrm{raw}}(e_i)$，合并斜率项与 raw-to-Noether 接触修正后的静态初值算子为 $I_q^{\mathrm{Noether}}(e_i,e_j)=I_q^{\mathrm{slope}}(e_i,e_j)+\Delta C_q^{\mathrm{Noether}}(e_i,e_j)$，并定义外力 $e_j$ 诱导的双侧电流驱动超算子

\[
\mathcal D_q(e_j)(B)=-J_L(q,e_j)\,B+B\,J_R(q,e_j),
\qquad B\in\mathcal B(\mathcal H), \tag{14.7}
\]

其中 $J_L(q,e_j)$ 与 $J_R(q,e_j)$ 分别为左、右双腿上的约化物质传播插入流算子。对 $\operatorname{Re}\lambda>0$ 执行内层与外层两段实时演化的 Laplace 预解归并，静态 Noether 半轴算子核满足精确两级 Sylvester 级联恒等式：

\[
\mathcal H_q^{\mathrm{Noether}}(e_i,e_j;\lambda)
=\mathcal S_q(\lambda)\Bigl(I_q^{\mathrm{Noether}}(e_i,e_j)
+\mathcal D_q(e_j)\bigl(\mathcal S_q(\lambda)(I_q^{\mathrm{raw}}(e_i))\bigr)\Bigr). \tag{14.8}
\]

式 (14.8) 从物理与代数两端揭示了极化频率结构的精确阶数：直接接触与斜率初值 $I_q^{\mathrm{Noether}}(e_i,e_j)$ 只经历一次外层双侧演化预解 $\mathcal S_q(\lambda)$，而原始流顶点 $I_q^{\mathrm{raw}}(e_i)$ 先经历内层预解 $\mathcal S_q(\lambda)$，在左右双腿同时受到外力流 $\mathcal D_q(e_j)$ 驱动后，再经历外层预解 $\mathcal S_q(\lambda)$。

将产生态减背景差线性观察泛函 $\ell_d$（式 (13.11)）作用于与频率 $\lambda$ 完全无关的有限长生成元幂词，定义 $N_q$ 维**直接矩向量** $D_{d,k}^{(ij)}\in\mathbb C^{N_q}$ 与 $N_q\times N_q$ **受驱矩矩阵** $R_{d,k}^{(ij)}\in\mathbb C^{N_q\times N_q}$：

\[
\begin{aligned}
D_{d,k;a}^{(ij)}&=\ell_d\!\Bigl(\mathcal T_q^a\bigl(I_q^{\mathrm{Noether}}(e_i,e_j)\bigr)\Bigr),\\
R_{d,k;ab}^{(ij)}&=\ell_d\!\Bigl(\mathcal T_q^a\Bigl(\mathcal D_q(e_j)\bigl(\mathcal T_q^b(I_q^{\mathrm{raw}}(e_i))\bigr)\Bigr)\Bigr),
\end{aligned}
\qquad 0\le a,b<N_q. \tag{14.9}
\]

这里的每一个分量都是真实源代数算子词在原始穿衣观察态 $\ell_d$ 下的直接读数，既非外供的唯象实现矩阵，亦未切换到替代静止系。

<a id="thm-14-1"></a>

**定理 14.1（全 $289\times 289$ 静态 Noether 极化张量的有限 Sylvester 矩阵坍缩）。** 对任意穿衣事件 $d$、任意物理转移三动量 $k\in\mathbb R^3$、任意满足 $\operatorname{Re}\lambda>0$ 的复频率 $\lambda\in\mathbb C$ 以及全部 $289\times 289$ 对场指标 $0\le i,j<289$，静态半轴 Noether 极化矩阵元 $\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}=\ell_d(\mathcal H_q^{\mathrm{Noether}}(e_i,e_j;\lambda))$ 无截断地严格等于有限维双线性二次型：

\[
\boxed{\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}
=w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}\,w_q(\lambda)
=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\,D_{d,k;a}^{(ij)}
+\sum_{a=0}^{N_q-1}\sum_{b=0}^{N_q-1}w_{q,a}(\lambda)\,w_{q,b}(\lambda)\,R_{d,k;ab}^{(ij)}.} \tag{14.10}
\]

**证明。** 取定 $\operatorname{Re}\lambda>0$。首先对内层算子 $I_q^{\mathrm{raw}}(e_i)$ 应用式 (14.6)，得 $\mathcal S_q(\lambda)(I_q^{\mathrm{raw}}(e_i))=\sum_{b=0}^{N_q-1}w_{q,b}(\lambda)\mathcal T_q^b(I_q^{\mathrm{raw}}(e_i))$。由于驱动超算子 $\mathcal D_q(e_j)$ 与演化幂 $\mathcal T_q^a$ 均为 $\mathcal B(\mathcal H)$ 上的复线性映射，将其代入式 (14.8) 并对外层两项分别再次应用式 (14.6)，有限和与线性算子严格交换：

\[
\mathcal H_q^{\mathrm{Noether}}(e_i,e_j;\lambda)
=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\,\mathcal T_q^a\bigl(I_q^{\mathrm{Noether}}(e_i,e_j)\bigr)
+\sum_{a=0}^{N_q-1}\sum_{b=0}^{N_q-1}w_{q,a}(\lambda)w_{q,b}(\lambda)\,
\mathcal T_q^a\!\Bigl(\mathcal D_q(e_j)\bigl(\mathcal T_q^b(I_q^{\mathrm{raw}}(e_i))\bigr)\Bigr).
\]

最后在两端施加连续复线性观察泛函 $\ell_d$，逐项代入式 (14.9) 的矩定义并按矩阵—向量点积重排，即得式 (14.10)。全部 $289^2$ 个场通道共用同一个 $N_q\times N_q$ 铅笔矩阵逆 $M_q(\lambda)^{-1}$ 生成的权重向量 $w_q(\lambda)$。□

同一静态矩阵还有显式多项式求值。两侧原联合多项式生成 Sylvester 生成元的首一湮灭式，次数为两侧次数之积。去掉所选 Laplace 频率处的因子后，得到全 Noether 矩阵的有限系数。源码 `ActualExplicitEvolutionPolynomial` 与 `explicit_full_noether_polarization` 给出原事件上全部场对的这一构造。

<a id="ex-14-1"></a>

**例 14.1（二次极小多项式 $N_q=2$ 伴随铅笔逆与两级权重展开的纸笔验算）。** 为直观检验式 (14.4)–(14.5) 与式 (14.10) 的代数运作，考察极小多项式在二能级不变子扇区取二次首一形式 $P_q(X)=X^2+c_1X+c_0$（$N_q=2$）的情形。在商代数 $\mathcal A_q=\mathbb C[X]/(P_q(X))$ 的幂基 $\{1,\bar X\}$ 下，$\bar X\cdot 1=\bar X$ 且 $\bar X\cdot\bar X=-c_0-c_1\bar X$，故左乘矩阵与铅笔矩阵分别为

\[
\operatorname{LMat}_{\mathcal A_q}(\bar X)=
\begin{pmatrix}0&-c_0\\1&-c_1\end{pmatrix},
\qquad
M_q(\lambda)=\lambda I_2-\operatorname{LMat}_{\mathcal A_q}(\bar X)=
\begin{pmatrix}\lambda&c_0\\-1&\lambda+c_1\end{pmatrix}.
\]

其行列式恰好还原极小多项式值 $\det M_q(\lambda)=\lambda(\lambda+c_1)+c_0=P_q(\lambda)$（在 $\operatorname{Re}\lambda>0$ 上由式 (14.3) 保证非零）。对 $2\times 2$ 矩阵直接求逆并取首列 $e_0=(1,0)^{\mathsf T}$，立即得到权重向量

\[
w_q(\lambda)=M_q(\lambda)^{-1}e_0
=\frac{1}{P_q(\lambda)}\begin{pmatrix}\lambda+c_1\\1\end{pmatrix},
\]

这与多项式带余除法 $(X^2+c_1X+c_0)/_{\mathrm m}(X-\lambda)=X+(\lambda+c_1)$ 在幂基 $\{1,\bar X\}$ 下的坐标 $(\lambda+c_1,\,1)^{\mathsf T}$ 逐字吻合。将其代入式 (14.10)，极化矩阵元显式展开为有理函数

\[
\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}
=\frac{(\lambda+c_1)D_{d,k;0}^{(ij)}+D_{d,k;1}^{(ij)}}{P_q(\lambda)}
+\frac{(\lambda+c_1)^2R_{d,k;00}^{(ij)}+(\lambda+c_1)\bigl(R_{d,k;01}^{(ij)}+R_{d,k;10}^{(ij)}\bigr)+R_{d,k;11}^{(ij)}}{P_q(\lambda)^2},
\]

单预解接触斜率极点 $P_q(\lambda)^{-1}$ 与双预解受驱级联极点 $P_q(\lambda)^{-2}$ 一目了然，全程无需对时间作任何无穷积分近似。

### 14.3　穿衣准备态相位消除与源生光子连通流回馈

定理 14.1 给出了静态极化张量的有限矩阵读出；Q7 的最后一步证明穿衣事件 $d$ 的连通电磁流在接入源生频率极化方向时，自动消去穿衣特征标相位并精确回馈到双腿准备光子振幅。

在穿衣事件 $d=(\epsilon_d>0,\ p_d\in\mathbb R^3,\ F_d,\ m_d\in\mathbb N,\ \zeta_d\in\mathbb C,\ \operatorname{Im}\zeta_d\ne 0)$（与式 (13.8) 一致，其中正条件 $\epsilon_d>0$ 为制备精度的正性证明项）中，记共享源剖面为 $\phi_d=\phi_{\epsilon_d}$，背景参考准备态为 $v_d=\psi_{\mathrm{prep}}(\phi_d)$，未归一完备单腿准备态为 $\ell_{\mathrm{leg}}(d)\in\mathcal H$，穿衣激发态为 $g_d$，电磁穿衣特征标在正产生分支上的取值为 $\chi_{\mathrm{EM}}^+\in\mathbb C$。源内构造的单位穿衣态 $u_d\in\mathcal H$（满足 $\|u_d\|_{\mathcal H}=1$）由复比例因子 $c_d=\|g_d\|_{\mathcal H}^{-1}\chi_{\mathrm{EM}}^+$ 与完备准备腿相乘生成：$u_d=c_d\,\ell_{\mathrm{leg}}(d)$。

在执行任何 Green 矩阵求逆或光子极化读出之前，Hilbert 单位范数条件 $\|c_d\,\ell_{\mathrm{leg}}(d)\|_{\mathcal H}=|c_d|\,\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}=1$ 直接迫使 $\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}>0$，并把复穿衣相位 $\chi_{\mathrm{EM}}^+/|\chi_{\mathrm{EM}}^+|$ 在模方乘积中彻底消去：

\[
\overline{c_d}\,c_d=|c_d|^2=\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}^{-2}>0. \tag{14.11}
\]

对全部 289 个场分量 $0\le i<289$，穿衣事件的连通流分量定义为产生态与同一源剖面背景态在完整电流顶点 $V_{\mathrm{curr}}(e_i;p_d,-k)$ 下的期望差：

\[
J_{d,k;i}^{\mathrm{conn}}
=\bigl\langle u_d,\,V_{\mathrm{curr}}(e_i;p_d,-k)u_d\bigr\rangle_{\mathcal H}
-\bigl\langle v_d,\,V_{\mathrm{curr}}(e_i;p_d,-k)v_d\bigr\rangle_{\mathcal H}.
\]

任取光子分支 $b\in\{0,1\}$、非零频率尺度参数 $\epsilon_{\mathrm{ph}}\in\mathbb R\setminus\{0\}$、实参数 $s\in\mathbb R$ 与空间传播方向 $n\in\mathbb R^3$，记源内生成的 289 维原生频率极化向量为 $e_{\mathrm{nat}}^{(b,\epsilon_{\mathrm{ph}},s,n)}\in\mathbb C^{289}$。

<a id="thm-14-2"></a>

**定理 14.2（穿衣准备相位消除与源生频率极化连通光子流恒等式）。** 对任意穿衣事件 $d$、物理转移三动量 $k\in\mathbb R^3$ 及满足 $\epsilon_{\mathrm{ph}}\ne 0$ 的任意原生频率极化参数 $(b,\epsilon_{\mathrm{ph}},s,n)$，连通流与原生频率极化向量的 289 槽完整收缩恒等于去相位的源生双腿准备光子振幅减去同剖面背景光子对：

\[
\boxed{\sum_{i=0}^{288}e_{\mathrm{nat},i}^{(b,\epsilon_{\mathrm{ph}},s,n)}\,J_{d,k;i}^{\mathrm{conn}}
=\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}^{-2}\,
\mathcal A_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;d)
-\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;v_d,v_d),} \tag{14.12}
\]

其中 $\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;x,y)$ 为左右两条完整有限 Green 腿在配置空间生成的整光子双线性对，而 $\mathcal A_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;d)=\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;\ell_{\mathrm{leg}}(d),\ell_{\mathrm{leg}}(d))$ 为未归一完备准备腿上的源生光子振幅。

**证明。** 当 $\epsilon_{\mathrm{ph}}\ne 0$ 时，对任意态向量 $x,y\in\mathcal H$，将两侧完整有限 Green 腿的伴随与正向作用送入配置一阶射流读出，对 $i=0,\ldots,288$ 求和恒将电流顶点收缩认回整光子对：$\sum_{i=0}^{288}e_{\mathrm{nat},i}^{(b,\epsilon_{\mathrm{ph}},s,n)}\langle x,V_{\mathrm{curr}}(e_i;p_d,-k)y\rangle_{\mathcal H}=\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;x,y)$。由于左内积共轭线性、右内积复线性，代入 $x=y=u_d=c_d\,\ell_{\mathrm{leg}}(d)$ 得

\[
\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;u_d,u_d)
=(\overline{c_d}\,c_d)\,\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}\bigl(p_d,-k;\ell_{\mathrm{leg}}(d),\ell_{\mathrm{leg}}(d)\bigr)
=\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}^{-2}\,\mathcal A_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;d),
\]

其中第二步应用了相位消除恒等式 (14.11)。再减去同剖面背景态 $x=y=v_d$ 上的同一收缩恒等式，并利用有限和关于减法的分配律，即得式 (14.12)。□

最后，穿衣事件元组 $d=(\epsilon_d>0,\ p_d,\ F_d,\ m_d\in\mathbb N,\ \zeta_d,\ \operatorname{Im}\zeta_d\ne 0)$ 仍携带离散 Volterra Yukawa 截断指标 $m_d\in\mathbb N$。为严格兑现标题“无截断（cutoff-free）”在配置空间响应侧的精确含义，对任意替换截断整数 $m'\in\mathbb N$，记仅替换该分量而保持其余源事件数据不变的事件为 $d[m']:=(\epsilon_d,\ p_d,\ F_d,\ m',\ \zeta_d)$。

<a id="thm-14-3"></a>

**定理 14.3（全 $Y$ 静态极化、物理三费米子五腿窗口与六阶红外返回的精确 Yukawa 截断消除）。** 对任意穿衣事件 $d$ 与任意离散截断整数 $m'\in\mathbb N$，成立以下三条精确截断不变恒等式：

1. **全 $289\times 289$ 静态极化截断不变性**：对一切转移三动量 $k\in\mathbb R^3$ 与复参数 $\lambda\in\mathbb C$，Lean 的 Bochner 定义满足下式。右半平面 $\operatorname{Re}\lambda>0$ 给出收敛的积分读数。

\[
\Pi_{d[m']}^{\mathrm{st}}(k,\lambda)=\Pi_d^{\mathrm{st}}(k,\lambda)\in\mathbb C^{289\times 289}. \tag{14.13}
\]

2. **物理三费米子（$N=3$）五腿因果窗口截断不变性**：记物理三费米子电子态 $\Psi_e^{N=3}(p_d,\zeta_d,\ell_{\mathrm{comp}})$ 减去同源 Noether 背景态在完整五腿变分算符下的有限时间因果响应窗口为 $\mathcal W_d^{N=3}(\ell_{\mathrm{comp}},k,\lambda,T;f_{\mathrm{read}},f_{\mathrm{force}})\in\mathbb C$，则对一切复合腿指标 $\ell_{\mathrm{comp}}$、$k\in\mathbb R^3$、$\lambda\in\mathbb C$、$T\in\mathbb R$ 及 $f_{\mathrm{read}},f_{\mathrm{force}}\in\mathbb R^{289}$，

\[
\mathcal W_{d[m']}^{N=3}(\ell_{\mathrm{comp}},k,\lambda,T;f_{\mathrm{read}},f_{\mathrm{force}})
=\mathcal W_d^{N=3}(\ell_{\mathrm{comp}},k,\lambda,T;f_{\mathrm{read}},f_{\mathrm{force}}). \tag{14.14}
\]

3. **全截断标号一致六阶红外返回**：同一矩阵函数 $G_d$ 在零点解析。对某个零点邻域内所有 $\operatorname{Re}z>0$ 和所有 $m'$，有 $z^4\Pi_{d[m']}^{\mathrm{st}}(0,z)=G_d(z)$。对**每一个** $m'\in\mathbb N$，沿右半平面去心邻域 $\{z\in\mathbb C:\operatorname{Re}z>0\}$ 均有

\[
\lim_{\substack{z\to 0\\\operatorname{Re}z>0}}z^6\,\Pi_{d[m']}^{\mathrm{st}}(0,z)=L_d=0. \tag{14.15}
\]

**证明与精确范围边界。** 全 $Y$ 穿衣运动学映射 $q(d[m'],k)=q(d,k)$ 与穿衣 Euler 观察泛函 $\ell_{d[m']}=\ell_d$ 直接建立在已消除有限 Volterra 截断的完整源对象上，定义层面不读取 $m'$，对矩阵指标 $0\le i,j<289$ 逐分量外延即得式 (14.13)。同理，完整五腿 Noether 变分算符、仅依赖 $(p_d,\zeta_d,\ell_{\mathrm{comp}})$ 的物理三费米子电子态及仅依赖精度剖面 $\epsilon_d$ 的同源背景态均对 $m'$ 定义不变，合并观察泛函与五腿积分立得式 (14.14)。最后，原矩阵的四阶解析延拓 `actual_fourth_ir_regularization` 给出 $G_d$。在同一邻域逐一代入式 (14.13)，得到全体标号共享的延拓。由解析性，$z^2G_d(z)	o0$，给出式 (14.15)。这里同样严守三项形式化边界：（i）定理 14.1 中的 $P_q(X)$ 为由代数整性唯一确定的抽象首一极小多项式（证明有限词坍缩而不在此求值具体次数）；（ii）定理 14.3 消除全 $Y$ 静态极化 (14.13)、物理 $N=3$ 五腿窗口 (14.14) 与六阶红外极限 (14.15) 的截断依赖，而定理 14.2 式 (14.12) 中的整光子双线性对 $\mathcal P_{\mathrm{ph}}$ 显式保留两侧有限 Green 腿（故不对式 (14.12) 声称截断不变性，亦不在 $\ell_d$ 与物理 $N=3$ 两种不同制备之间移植矩量）；（iii）原生频率极化 $e_{\mathrm{nat}}^{(b,\epsilon_{\mathrm{ph}},s,n)}$ 与修正物理光速锥及精细结构常数 $\alpha(0)$ 源内 Thomson 公式的接合由同系列第三案独立承担，各定理模块均在其专属上游导入链上通过零自定义公理内核审计。□

![图6：交换代数整演化、极小多项式商代数逆、全 289×289 Sylvester 坍缩与 Yukawa 截断消除。](figures/fig05-sylvester-collapse-v2.svg)

**图 6　交换代数整演化、极小多项式商代数逆、全 $289\times 289$ Sylvester 坍缩与 Yukawa 截断消除。** 顶栏三框（左至右）：交换左右乘法生成元 $\mathcal L_q,\mathcal R_q$ 的代数整性先于任何读出与外力抽出 $\mathcal T_q$ 的首一极小多项式 $P_q(X)$（涵盖未切 $Y$ 外词），并在商代数 $\mathcal A_q=\mathbb C[X]/(P_q(X))$ 中零外部证书给出商逆 $g_q(\lambda)$ 与 $N_q$ 维伴随铅笔权重 $w_q(\lambda)=M_q(\lambda)^{-1}e_0$。第二栏双通道：左框由接触与斜率初值生成一次预解直接矩向量 $D$，右框经双侧流驱动生成二次预解受驱矩矩阵 $R$。中部朱红聚焦框：全部 $289\times 289$ 静态极化分量严格坍缩为双线性二次型 $w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}w_q(\lambda)$（定理 14.1）。底栏三框：单位态 Hilbert 范数消去穿衣相位接回源生光子振幅（定理 14.2）、全 $Y$ 静态极化／物理 $N=3$ 窗／六阶红外极限对离散 Yukawa 截断标号严格不变（定理 14.3，金色边框），以及移交下游 Case 3 的零旋钮接口。

## 15　五轴文献综合对话与零旋钮结案移交

### 15.1　五轴文献综合对话：经典工具继承与本案结构推进

至此，从单向手征理想闭迹（Q1）到极小多项式 Sylvester 矩阵坍缩（Q7）的七项命题全部证毕。我们将全文结果置于五条经典数学物理脉络中作系统对照（完整核查深度与出版记录登记于随附书目档案），明确区分本文直接继承的经典方法与本文在零可调参数统一场架构下独立证出的结构推进。

1. **无紫外截断一圈极化、坐标空间零抵消项分布核与洛伦兹非自伴谱结构** [[4]](#ref-4), [[5]](#ref-5), [[6]](#ref-6), [[7]](#ref-7), [[8]](#ref-8)。Schwinger 的固有时积分 [[4]](#ref-4) 与 Chamseddine–Connes 欧氏谱作用量 $\operatorname{Tr}\chi(D/\Lambda)$ [[8]](#ref-8) 通过紫外截断尺度 $\Lambda$ 或渐近热核展开提取有效玻色耦合；Epstein–Glaser 因果微扰论 [[5]](#ref-5) 虽在坐标空间避免了动量截断，但在非负奇异阶 $\omega\ge 0$ 处仍留下 $\omega$ 次局部多项式自由重整化常数；DeWitt [[6]](#ref-6) 与 Abbott [[7]](#ref-7) 则奠定了协变背景场二阶变分、受约束背景 Green 函数以及连通生成泛函与 1PI 有效作用的严格区分。本文工作在洛伦兹物理时间下保留独立变分对偶 $\chi$（不设 $\chi=\psi^\dagger$）：一方面在有限维手征纤维上不借任何截断直接证出任意长有序规范词的精确闭迹简化（定理 3.2）；另一方面在受扰玻色传播核 $\mathcal G_{k,\delta}=P_1\delta'_0+P_0\delta_0+\mathbf 1_{t\ge 0}K_1$（式 (7.9)）中由 $|\lambda|=5c$ 围道积分与母方程高频恒等式唯一锁定 $P_1,P_0$（零自由抵消项），并在命题 12.1 中将 1,445 槽实一阶射流母作用二阶 Fréchet 导数逐项认回 $H_{289}(p)$。
2. **手征有限纤维闭迹、闭合时间路径（in-in）实时制备态与反对称 Fock 整词顺序** [[9]](#ref-9), [[10]](#ref-10), [[11]](#ref-11), [[12]](#ref-12), [[13]](#ref-13)。Adler [[9]](#ref-9) 与 Bell–Jackiw [[10]](#ref-10) 揭示了发散三角圈的动量路由、正规化与手征 Ward 表面项的关系；Schwinger [[11]](#ref-11) 与 Keldysh [[12]](#ref-12) 确立了给定初态下前向—后向闭合时间路径的实时期望框架；Tasaki [[13]](#ref-13) 系统给出了反对称 Fock 空间二次量子化一体算子在单粒子扇区的作用公式。本文将这三条线索交汇于含单向楔积 $Y_R$ 的母代数：定理 3.2 是在固定各腿动量与谱参数、绝不交换不同顶点的有限维分级理想精确恒等式；命题 4.1 严格证明单粒子 Fock 期望要求先完成整词乘积再作态投影，中途插入秩一投影 $P_w$ 会抹除 $-1$ 开放返回并篡改 16 个规范整词中的 6 个；第 6 节与第 13 节则以独立左右演化腿直接给出非平衡零温度制备态的实时极化读出。
3. **协变导数展开（CDE）、重场阈值解耦、保源全动量 Schur–Feshbach 恢复与集体模非交换原点极限** [[14]](#ref-14), [[15]](#ref-15), [[16]](#ref-16), [[17]](#ref-17), [[18]](#ref-18), [[19]](#ref-19), [[20]](#ref-20), [[21]](#ref-21), [[31]](#ref-31), [[32]](#ref-32)。Gaillard [[14]](#ref-14)、Cheyette [[15]](#ref-15) 与 Henning–Lu–Murayama [[16]](#ref-16) 用局部协变导数展开组织一圈泛函迹并严格区分内部迹 $\operatorname{tr}$ 与时空泛函迹 $\operatorname{Tr}\log$；Appelquist–Carazzone [[17]](#ref-17) 建立了重场低动量解耦定理；Schur [[18]](#ref-18)、Feshbach [[19]](#ref-19)、Dirac [[20]](#ref-20) 与 Takahashi [[21]](#ref-21) 分别奠定了分块消元、子空间有效哈密顿量、退化约束约化与有限动量转移广义 Ward 恒等式；Luttinger [[31]](#ref-31) 与 Weldon [[32]](#ref-32) 则阐明了时间度规势耦合与热浴中静态筛选与长波集体响应的区分。本文严守内部闭迹（第 3 节）、一次耦合场 Schur 反馈（第 5、12 节）与波包时间动量积分（第 7–11 节）的三层边界，不作 $1/M^2$ 渐近截断：定理 5.2 通过含 32 个非零 Ward 标量源条目的 $J_{\mathrm{src}}$ 实现 $H_{289}F=J_{\mathrm{src}}S_{55}$ 逐符号原方程恢复，定理 5.3 与 §5.5 在原点奇异处导出双时间尺度五维轻核及静态 $18N/125$ 对齐次 $33N/125$ 的非交换射线极限（图 2），定理 12.2 则以非正交直和坐标补从清分母 Green 解恢复接触项、五维有效核与全部九个零模方向。
4. **尖球窗集合协方差几何、Gershgorin 连续同伦惯性锁定与抗包裹严格区间证明** [[22]](#ref-22), [[23]](#ref-23), [[24]](#ref-24), [[25]](#ref-25), [[26]](#ref-26)。Galerne [[22]](#ref-22) 的集合协方差方向边界变分公式刻画了双球交集面积在原点产生非解析尖点 $|s|$ 的几何机制；Sylvester 惯性定律 [[23]](#ref-23) 与 Gershgorin 圆盘定理 [[24]](#ref-24) 提供了实对称二次型特征值符号隔离的代数拓扑工具；Tucker [[25]](#ref-25) 与 Gómez-Serrano [[26]](#ref-26) 确立了向外区间算术结合解析尾界的计算机辅助严格证明标准，并指明运算次序对抑制包裹膨胀（wrapping effect）的决定性作用。本文第 8–11 节完整保留尖球窗的球内体项与零阶／一阶两类球面通量（例 1.1b、§10.2 球面通量 $+2.38\times 10^{-20}$ 跨零翻转），在 11,760 个外源解多指标系数上直接递归合成读出并围绕中心化 Gram 直接包围 `connected` 通道，最终以 $4.6\times 10^{-22}$ 紧宽区间与路径同伦锁死 `raw` 与 `connected` 整球张量惯性 $(2,1,0)$（定理 1.2，图 4；均值项 `mean` 第二轴跨零并如实单列）。
5. **非平衡因果 Kubo 响应、算子 Sylvester 方程、极小多项式商代数坍缩与 Yukawa 截断消除** [[1]](#ref-1), [[2]](#ref-2), [[3]](#ref-3), [[27]](#ref-27), [[28]](#ref-28), [[29]](#ref-29), [[30]](#ref-30)。Kubo [[27]](#ref-27) 奠定了实时滞后线性响应积分；Rosenblum [[28]](#ref-28) 与 Bhatia–Rosenthal [[29]](#ref-29) 建立了算子 Sylvester 方程的谱条件与半群积分逆理论；de Moura–Ullrich [[30]](#ref-30) 提供了 Lean 4 极小可信内核验证架构。在物理旗舰 [[1]](#ref-1)、第一案 [[2]](#ref-2) 与本篇首版 [[3]](#ref-3) 的同源基础上，本文定理 13.2 给出非线性共同正窗口 $0\le T<\tau(d,k,P,a)$ 上保留精确指数时间权 $W_T(P_0,\lambda)$ 的完整母 Euler 响应铅笔，定理 14.1–14.3 进一步利用交换生成元代数整性在商代数 $\mathbb C[X]/(P_q(X))$ 中把 $\operatorname{Re}\lambda>0$ 上全部 $289^2$ 个静态极化分量精确坍缩为有限维二次型、消相接回光子振幅并消除离散 Yukawa 截断依赖，全部在 Lean `v4.33.0` 内核完成零自定义公理形式化闭合。

**表 3　五轴文献对话与本篇结构推进对照矩阵**

| 对话轴线 | 代表性经典文献 | 经典框架的标准处理与适用前提 | 本篇（Q1–Q7）的结构推进与严格边界 |
| --- | --- | --- | --- |
| **轴 I：无截断极化与零抵消项瞬时核** | Schwinger [[4]](#ref-4)；Epstein–Glaser [[5]](#ref-5)；DeWitt [[6]](#ref-6)；Abbott [[7]](#ref-7)；Chamseddine–Connes [[8]](#ref-8) | 紫外截断 $\Lambda$／热核渐近展开，或坐标空间奇异阶 $\omega\ge 0$ 局部自由抵消常数；欧氏自伴 Dirac 算符 | 洛伦兹独立对偶 $\chi$；零截断有限纤维精确闭迹（定理 3.2）；$|\lambda|=5c$ 围道与高频恒等式唯一锁定 $\delta'_0,\delta_0$ 系数 $P_1,P_0$（零自由抵消项）；1,445 槽母作用二阶变分逐项认回 $H_{289}(p)$（命题 12.1） |
| **轴 II：手征纤维迹、in-in 制备态与 Fock 词序** | Adler [[9]](#ref-9)；Bell–Jackiw [[10]](#ref-10)；Schwinger [[11]](#ref-11)；Keldysh [[12]](#ref-12)；Tasaki [[13]](#ref-13) | 连续发散圈正则化；非平衡实时双支格林函数；自伴一体算子二次量子化 | 固定腿动量有限维 $P_6$ 理想代数恒等式；单粒子 Fock 期望须整词乘毕再投影，中途投影抹除 $-1$ 开放返回并篡改 $6/16$ 规范词（命题 4.1） |
| **轴 III：CDE 展开、阈值解耦、全动量 Schur 与集体原点极限** | Gaillard [[14]](#ref-14)；Cheyette [[15]](#ref-15)；Henning 等 [[16]](#ref-16)；Appelquist–Carazzone [[17]](#ref-17)；Schur [[18]](#ref-18)；Feshbach [[19]](#ref-19)；Dirac [[20]](#ref-20)；Takahashi [[21]](#ref-21)；Luttinger [[31]](#ref-31)；Weldon [[32]](#ref-32) | $1/M^2$ 局部高维算符渐近截断；正交投影有效哈密顿量；热浴或等离子体介质中的快慢双极限 | 严分内部迹、耦合场 Schur 补与波包积分；$J_{\mathrm{src}}$（含 32 项 Ward 源）恢复 289 行母方程（定理 5.2）；零温背景五维轻核分离双时间尺度与 $18N/125$ 对 $33N/125$ 射线极限（定理 5.3，图 2）；全四动量九零模完整恢复（定理 12.2） |
| **轴 IV：尖窗几何、惯性锁定与严格区间证明** | Galerne [[22]](#ref-22)；Sylvester [[23]](#ref-23)；Gershgorin [[24]](#ref-24)；Tucker [[25]](#ref-25)；Gómez-Serrano [[26]](#ref-26) | 集合协方差边界导数；圆盘特征值隔离；向外区间算术与解析余项包围 | 完整保留双球尖窗非解析 $|d|$ 与零阶／一阶两类球面通量（在 $e_2$ 注入 $+2.38\times 10^{-20}$ 跨零翻转）；沿外源解递归抑制包裹膨胀，以 $4.6\times 10^{-22}$ 紧宽区间锁死 `raw` 与 `connected` 惯性 $(2,1,0)$（定理 1.2） |
| **轴 V：非平衡响应、Sylvester 预解、有限坍缩与截断消除** | 高健 [[1]](#ref-1)–[[3]](#ref-3)；Kubo [[27]](#ref-27)；Rosenblum [[28]](#ref-28)；Bhatia–Rosenthal [[29]](#ref-29)；de Moura–Ullrich [[30]](#ref-30) | 平衡态线性响应；半群无穷时间积分逆或外供谱分离证书 | 非线性共同正窗口 $0\le T<\tau$ 上不除 $T$ 的母 Euler 响应铅笔（定理 13.2）；商代数 $\mathbb C[X]/(P_q(X))$ 零外部证书将 $289^2$ 静态极化坍缩为有限二次型、消相接回光子振幅并消除离散 Yukawa 截断标号（定理 14.1–14.3） |

### 15.2　结案总合与面向下游低能匹配的零旋钮移交契约

回看引言提出的中心问题，本篇七项核心成果构成一条首尾咬合的零参数闭合链：

- **裸迹与制备态期望各居其位，词序与投影时机一丝不苟**：单位算子的全载体裸迹 $252$ 与概率准备态期望 $1$ 分属两种不同物理评价；单向手征理想在闭合规范迹中精确归零（定理 3.2），在开放态返回中贡献非零实标量 $-1$，而任何中途秩一投影都会篡改非交换整词（命题 4.1）。
- **消元不丢源，尖窗不漏通量，整球号差不由坐标轴代答**：$289\to 103\to 55$ 消元经 $H_{289}F=J_{\mathrm{src}}S_{55}$ 逐符号回写全部母方程并在原点抽出双时间尺度五维轻核与非交换度规射线极限（定理 5.2–5.3，图 2）；双球尖窗交集保留 $|d|$ 一次非解析项、球内体项、两类球面通量与完整复 Gram，经严格区间与 Gershgorin 连续同伦锁死未中心化（`raw`）与连通（`connected`）整球二次曲率张量的同一惯性 $(2,1,0)$（定理 1.2，图 4；均值项 `mean` 第二轴跨零并独立保留）。
- **从母作用二阶变分到非线性极化铅笔、有限 Sylvester 矩阵与无截断红外返回完全闭环**：母作用密度 1,445 槽实一阶射流二阶变分逐项认回 $H_{289}(p)$（命题 12.1），全四复动量 Schur 核从清分母 Green 解恢复接触项与九零模方向（定理 12.2），产生态减背景差泛函在共同正窗口上生成完整 $289\times 289$ 极化张量与母 Euler 铅笔（定理 13.2），并在右半平面经极小多项式商代数坍缩为有限矩阵二次型、去相位光子连通回馈及精确 Yukawa 截断不变响应（定理 14.1–14.3，图 6）。

本篇向同系列第三案（Case 3：源内重减轻阈值解耦、电磁消因子常数 $192/97$ 与单极点物理频率匹配）移交的全部对象均已锁定为零可调旋钮形式，具体契约汇总于表 4。

**表 4　本篇移交下游低能匹配（Case 3）的零旋钮输出对象契约**

| 移交对象 | 本篇精确定义与定理定位 | 固定参数／维度与不可删减结构 | 下游（Case 3）直接消费用途 |
| --- | --- | --- | --- |
| 源生五通道空间响应与固定窗口 | 式 (1.2)、式 (6.5)、式 (7.15)（§7.4） | $c=\frac{6\sqrt{15}}{25},\;B=\sqrt2\epsilon_B,\;z=w=6c(1-i)$，球重叠支集 $r\in[0,2]$ | 六个外源方向在完全相同测试窗与求值点下的跨通道比较 |
| 固定单粒子准备态复 Gram 与三扇区正交分解 | 式 (6.16)–(6.17)、式 (8.8)、附录 D.1 | $58$ 个两探针复 Gram 权与 $20$ 个复均值权；$\mathrm{raw}=\mathrm{mean}+\mathrm{conn}$ | 保持全积分固定同一量子准备，禁止按内动量 $k$ 重新制备 |
| 整球二次曲率张量与严格有理区间包络 | 定义 1.1、定理 1.2、式 (11.1)–(11.4) | $3\times 3$ 实对称张量，球内体项＋零阶／一阶两类球面通量，惯性 $(2,1,0)$ | 低能极化各向异性号差基准与有限波包边界通量核验 |
| 全四复动量母 Hessian 与清分母九零模恢复 | 命题 12.1、定理 12.2、式 (12.12)–(12.20) | $p\in\mathbb C^4$，五维原点核 $N$ 与 $45+21+32$ 直和补，保留全部 289 场与 9 零模 | 72 维全纯规范曲率读出与有限动量极点场恢复 |
| 有限窗母 Euler 铅笔、有限 Sylvester 矩阵、去相位光子流与截断消除 | 定理 13.2、定理 14.1–14.3、式 (13.22),(14.10),(14.12)–(14.15) | $289\times 289$ 极化二次型 $w_q^{\mathsf T}D+w_q^{\mathsf T}Rw_q$；去相位权 $\|\ell_{\mathrm{leg}}(d)\|^{-2}$；全 $Y$ 截断无关极限 $L_d$ | 源生光子连通振幅直接回馈、无截断六阶红外匹配与重减轻阈值解耦 |

## 附录 A　母作用线性化矩阵与分级箭头代数的显式重建

### A.1　物质与规范基序、背景辅助张量及一阶射流二次变分

252 维复物质基先按旋量指标 $0,1,2,3$，再按外幂扇区 $\Lambda^6,\Lambda^2,\Lambda^4$ 内部升序组合排列；因此偶外幂投影 $P_6$ 在每个 $63$ 维旋量块的前 $7$ 个对角位置取 $1$，其余 $56$ 个位置取 $0$。记标准矩阵元差与和为 $A_{ij}=E_{ij}-E_{ji}$、$S_{ij}=i(E_{ij}+E_{ji})$、$D_{i-j}=i(E_{ii}-E_{jj})$，12 个活跃 $\mathfrak{su}(7)$ 规范生成元按固定次序排列为

\[
(A_{01},S_{01},A_{02},S_{02},A_{12},S_{12},D_{0-2},D_{1-2},A_{34},S_{34},D_{3-4},Y), \tag{A.1}
\]

其中超荷对角生成元为 $Y=i\operatorname{diag}(0,0,0,0,0,1,-1)$。经典背景空间规范场所使用的三个 $\mathfrak{su}(2)$ 生成元准确为

\[
(\tau_1,\tau_2,\tau_3)=\tfrac12(S_{01},A_{01},D_{0-2}-D_{1-2}). \tag{A.2}
\]

它们位于颜色 $0,1,2$ 子块；本文第 6–11 节的外规范微扰插入取整枚生成元 $S_{01}=2\tau_1$。注意式 (3.9) 中顶点编号 $0$ 指代时间分量 $A_0$ 上的 $A_{01}$，并非此处空间一形式 $dx^1S_{01}$ 的别名。

对按 $(01,02,03,23,31,12)$ 排列的时空二形式基，经典度规背景上的 Hodge 星算子为

\[
*_e(f_1,f_2,f_3,f_4,f_5,f_6)
=(f_4/N,f_5/N,f_6/N,-Nf_1,-Nf_2,-Nf_3). \tag{A.3}
\]

对按同一双指标顺序 $(01,02,03,23,31,12)$ 排列的内部 Lorentz 二形式指标，楔积双线性型与背景辅助场取值为

\[
\begin{gathered}
J=\begin{pmatrix}0&I_3\\-I_3&0\end{pmatrix},\qquad
\mathcal W(X,Y)=\sum_{I,p}\epsilon_I X_{Ip}Y_{I,p^*},\\
\epsilon=(-1,-1,-1,1,1,1),\quad p^*=(3,4,5,0,1,2),
\end{gathered}
\]

其中 $p\in\{0,\ldots,5\}$，$p^*$ 表示互补二形式指标，内部指标 $I$ 的前三个负号来自 Lorentz 度规号差；规范楔积 $\mathcal W_g(X,Y)=\sum_p\langle X_p,Y_{p^*}\rangle_g$ 采用第 2 节固定的规范不变双线性型。在九场经典解背景上，引力辅助二形式、对称乘子与规范辅助二形式的背景值分别为

\[
\begin{gathered}
B_{\mathrm{gr},0}=\begin{pmatrix}0&I_3\\-NI_3&0\end{pmatrix},\qquad
\lambda_0=\operatorname{diag}(-N,-N,-N,s_0^2-1,s_0^2-1,s_0^2-1),\\
B_{g,0}=\frac{a^2}{\sigma N}(\tau_1,\tau_2,\tau_3,0,0,0),
\end{gathered}
\]

与式 (5.1) 代入 $A_j=a\tau_j$ 的代数消元值完全一致。以全部 289 个实场分量及其一阶时空导数（共 1,445 个实一阶射流坐标）为独立变量，提取母作用密度 (2.4) 围绕背景展开的 $\varepsilon^2$ 二次型并求 Hessian（Euler–Lagrange 符号约定为 $\partial_q\mathcal L-\partial_\mu\partial_{\partial_\mu q}\mathcal L$，动量坐标取 $p=(\lambda,ik)$，负相位列代入 $k\mapsto -k$），即逐项重建 $H_{289}(p)$（命题 12.1）。公开证据包完整保存全部 289 个场名、射流坐标、二次作用块、Fourier–Jacobi 稀疏非零条目、每步辅助与 Ward 消元矩阵、158 枚原密度顶点以及 252 维自由、单向与对偶时间矩阵。

### A.2　分块对角加单向箭头的显式下三角代数

在分解 $(I-P_6)\mathcal M\oplus P_6\mathcal M$（维数 $224\oplus 28$）下，任意容许算子 $A=A_0+N$（满足 $[A_0,P_6]=0$ 且 $N=P_6N(I-P_6)$）具有严格分块下三角矩阵形式，两个此类算子的乘积满足

\[
A=\begin{pmatrix}a&0\\n&b\end{pmatrix},\quad
A'=\begin{pmatrix}a'&0\\n'&b'\end{pmatrix},\quad
AA'=\begin{pmatrix}aa'&0\\na'+bn'&bb'\end{pmatrix}. \tag{A.4}
\]

第 3 节式 (3.7) 对任意长度词的分解正是式 (A.4) 的有限归纳。全部规范顶点均为严格分块对角（$n=0$）；而在母作用的 16 个余标架顶点中，4 个对角余标架变分携带由 $Y_R$ 或其递延因子 $N$ 倍数生成的非零左下角箭头块 $n\ne 0$，其余 12 个余标架顶点则为分块对角。因此当算子词包含余标架变分顶点时，必须按式 (A.4) 逐因子取其真实块对角部与单向箭头部，不可套用“非标量顶点必块对角”的简化口诀。

对角背景态的四个非零实准备分量由式 (4.6) 给出，物理背景振幅为 $2w$；完整母作用双线性密度使用独立对偶 $\chi$，代入背景准备后携带因子 $4\sqrt2$ 与自旋交换矩阵，而单粒子概率准备的单位范数读出则严格按式 (4.4) 与式 (4.9) 归一。

## 附录 B　五维轻核矩阵元、对称路径生成元与动态度规分母

记轴向空间波数为 $q=q_{\mathrm{ax}}$，增长频率为 $u$，令

\[
\begin{aligned}
r&=80q^2/9+16u^2/3,& v&=160q^2/67+32u^2/11,\\
a&=2500q^2/81-40u^2,& r_m&=80iqu/9+16u^2/3,\\
v_m&=-80q^2/67-32u^2/11,& a_m&=-20iqu/3,\\
p_1&=-40q^2/3+80iqu/3+88u^2/9,&
p_2&=-550q^2/201-2438u^2/561.
\end{aligned} \tag{B.1}
\]

第 5.4 节定理 5.3 在自然对称基下的完整二阶与一阶 $5\times 5$ 轻核系数矩阵显式为

\[
K_2=\begin{pmatrix}
r&0&r_m&0&0\\
0&v&0&0&v_m\\
r_m&0&p_1&0&0\\
0&0&0&a&a_m\\
0&v_m&0&a_m&p_2
\end{pmatrix},\qquad
K_1=\begin{pmatrix}0&0&0&0&0\\0&0&0&0&0\\0&0&0&0&-8u\\0&0&0&0&0\\0&0&8u&0&0\end{pmatrix}. \tag{B.2}
\]

矩阵核满足洛伦兹母作用的形式转置对称性 $K(-u,-q)^{\mathsf T}=K(u,q)$（故在实增长变量 $u$ 上不应强加欧氏自伴性）。该自然基由背景物质对 $(\psi_0,\chi_0)$ 沿五条对称变形路径在 $\varepsilon=0$ 处的一阶切向量生成：

\[
\begin{array}{ll}
\bigl((1+\varepsilon)\psi_0,\,\chi_0/(1+\varepsilon)\bigr),&
\bigl(e^{i\varepsilon}\psi_0,\,e^{-i\varepsilon}\chi_0\bigr),\\
\bigl(e^{-\varepsilon\gamma_5}\psi_0,\,\chi_0e^{-\varepsilon\gamma_5}\bigr),&
\bigl(e^{-i\varepsilon\gamma_5}\psi_0,\,\chi_0e^{-i\varepsilon\gamma_5}\bigr),\\
\bigl(\psi_0,\,(1+i\varepsilon)\chi_0\bigr),&
\end{array} \tag{B.3}
\]

与之配套的余标架、联络、辅助场及重物质分量由原点线性化零空间解图自动唯一恢复，而非人为置零。公开证据包完整收录 $289\times 5$ 原点零模矩阵、103 维坐标读回、基变换矩阵、式 (B.2) 的逐项源矩阵、式 (5.4) 的 $(F,J_{\mathrm{src}})$ 以及动态度规分量 $g_{00}$ 的完整有理分子、分母与 289 行回写检验。

需特别指出：轴向小动量领先特征锥虽为 $u^2=125q^2/162$（式 (5.12)），但完整动态分母在该领先锥上的精确代数值为

\[
\begin{aligned}
&\frac{781250q^4}{59049}
(790649734875q^8+2150126388440q^6-1399007363958q^4\\
&\qquad+2468324502972q^2-3677642578800),
\end{aligned} \tag{B.4}
\]

在 $q\ne 0$ 处并不恒为零。因此式 (5.12) 严格刻画长波低动量领先色散锥，而有限动量处的真实极点则必须采用附录 C 的完整六次因子根与全动态分母。

## 附录 C　完整六次传播根、无角分母全球重建与非轴向原方程检验

### C.1　六次特征多项式精确整系数

为便于独立复核第 7.1 节式 (7.3) 的六次因子 $\widehat F(U,T)=\sum_{j=0}^6 a_j(T)U^j$，列出其关于 $T=|k|^2/2$ 的全部精确多项式系数：

\[
\begin{aligned}
a_6={}&103312130400,\\
a_5={}&88042059000T-1326196135152,\\
a_4={}&-2812927273200T^2+7146135894492T-10666675605312,\\
a_3={}&-348356420550T^3-4054836616488T^2
+54877225175424T-29979885888000,\\
a_2={}&8566446093750T^4+14320336749875T^3
-13331559163500T^2\\&\quad-44274070098000T-232960429728000,\\
a_1={}&7105914843750T^5+20863513093750T^4
-54526414743750T^3\\&\quad+54793278225000T^2
+333108288000000T-100383300000000,\\
a_0={}&988769531250T^6+3515380859375T^5
+10071269531250T^4\\&\quad+30510703125000T^3
-166986562500000T^2+77456250000000T.
\end{aligned} \tag{C.1}
\]

在闭球域 $|k|\le B$（$T=|k|^2/2$）上，设 $U=T\,R(T)$，则比值根 $R(T)$ 在隔离区间 $[125/162-1/20,\,125/162+1/20]$ 内唯一，且偏导数模满足 $D=f_U\in[39/40,\,41/40]$。该单值解析根域覆盖原点及闭球邻域，且固定响应求值频率 $z=6c(1-i)$ 严格远离两处传播极点。

### C.2　无球坐标奇点的全球多项式重建与非轴向代回核验

对任一源响应列的 $j=0,1,2$ 角动量径向块 $W_0,W_1,W_2$，令 $C_2=(G_y^2W_2+3W_2)/2$、$E_2=G_zC_2$（$G_x,G_y,G_z$ 为共同表示生成元），则无需引入球极角分母 $\sqrt{k_x^2+k_y^2}$ 的全球三动量分子多项式显式为

\[
\begin{split}
\mathcal N_W={}&W_0-\frac{k_zW_1+k_xG_yW_1-k_yG_xW_1}{\sqrt2}
+\frac{2k_z^2-k_x^2-k_y^2}{4}W_2\\
&+\frac{k_xk_z}{2}G_yW_2-\frac{k_yk_z}{2}G_xW_2
+\frac{k_x^2-k_y^2}{2}C_2+\frac{k_xk_y}{2}E_2. \tag{C.2}
\end{split}
\]

场响应列采用生成元 $G$，源协向量列采用对偶生成元 $-G^{\mathsf T}$（线性项负号对应负空间相位的空间反射）。Casimir 投影、李代数对易关系、反射对称性及大圆常微分方程唯一性定理保证式 (C.2) 与球面有限旋转输运在全 $\mathbb R^3$ 上逐点相等。

固定规范截面消去了约化指标中的 9 行 $(21,27,39,58,59,60,63,64,68)$。虽然部分有理块 $\mathcal A$ 在这 9 行恒为零，但偶次耦合块 $\mathcal B$ 在其中 6 行携带非零交叉动量项 $k_xk_y,k_xk_z,k_yk_z$——这表明绝不能把单轴上恒零的行外推为全三维动量空间恒零。所删 9 行对应的对称子式行列式精确等于

\[
\det K_{\mathrm{removed}}=\frac{3\sqrt2}{1000}(18-25k_x^2), \tag{C.3}
\]

在整个轻球 $|k|\le B=\sqrt2\epsilon_B$ 上严格非零（因 $25k_x^2\le 50\epsilon_B^2\ll 18$），从而保证第 7.2 节式 (7.8) 的 Noether 补偿源 $I_{1,\delta}$ 全球唯一可解。

全空间响应列已通过两组独立精确有理代回核验：（1）取一般非轴向有理方向 $k=\sqrt2\rho(2,-3,6)/7$（$\rho=1/131072$）与复频率 $\lambda=c(7-2i)$，代回全部 289 行母方程（含 3 个一阶与 6 个二阶导数方程）残差恒零；（2）在 $q=1/262144$ 处核对全部 9 个外源方向、10 个二阶以内空间射流、289 行原方程与完整六次因子。正空间相位与负空间相位约定下的逆矩阵表满足 $P_+(q)=P_-(-q)$，一切奇阶径向导数相应翻转符号。

## 附录 D　复 Gram 矩阵的解析径向积分、矩形区间算术与强导数余项

### D.1　球对称径向权的解析分部积分与高阶极点递推

令 $x=r^2/2$，$t_b(r)=b'(r)/r$，$u_b(r)=(b''(r)-b'(r)/r)/r^2$。单位球特征准备态在原点给出有限极限 $b(0)=\sqrt{4\pi/3}$、$t_b(0)=-b(0)/5$、$u_b(0)=b(0)/35$。对复 Gram 矩阵中出现的径向二次型组合 $\alpha b^2+\beta b t_b+\delta_{bu}b u_b+\delta_{tt}t_b^2$，利用径向亥姆霍兹特征方程与两次分部积分可将其统一化归为无导数形式 $W(x)b(r)^2$，其中有理权函数由

\[
A=\alpha-\frac{\delta_{bu}}{2x}+\frac{\delta_{tt}}{2x},\quad
B_1=\beta-\frac{5\delta_{bu}}{2x}+\frac{2\delta_{tt}}x-\delta'_{tt},\quad
W=A-\frac{B_1}{4x}-\frac{B_1'}2 \tag{D.1}
\]

给出，且两个边界端点项 $rB_1b^2/2$ 与 $\delta_{tt}bb'$ 在全部实际有理权上均精确消失。对部分分式极点因子 $(r^2+\kappa^2)^{-m}$，首阶积分 $m=1$ 由第 6.1 节式 (6.5) 解析生成，高阶极点积分则由参数导数递推

\[
R_{m+1}(\kappa)=-\frac1{2m\kappa}\partial_\kappa R_m(\kappa) \tag{D.2}
\]

精确给出。球重叠多项式在 $r\in[0,2]$ 上的有理矩为

\[
M_j=\int_0^2r^j\bigl(r-3r^2/4+r^4/16\bigr)\,dr
=\frac{3\,2^{j+2}}{(j+2)(j+3)(j+5)}. \tag{D.3}
\]

将指数级数 $J(\kappa)=\sum_{j\ge 0}(-\kappa)^jM_j/j!$ 截断至 $130$ 阶：在全部满足 $|\kappa|<7$ 的实际复极点上，第 $j$ 阶导数的无穷级数余项严格受控于解析上界 $2^j(2/5)3^{14}14^{131}/131!$。复极点根、圆周率 $\pi$、有理权系数及上述截断尾界全程采用向外有理区间算术求值；证据包完整保存实部与虚部上下界，正文第 6.4 节与第 11.1 节仅展示十进制中心读数。

### D.2　复矩形向外乘法与 Cauchy 解析尾界合并

设两复数分别包含于二进有理复矩形 $z=(z_R\pm a)+i(z_I\pm a)$ 与 $w=(w_R\pm b)+i(w_I\pm b)$ 中，则其乘积中心取 $(z_Rw_R-z_Iw_I)+i(z_Rw_I+z_Iw_R)$，实虚两槽的向外半宽统一取为

\[
(|z_R|+|z_I|)b+a(|w_R|+|w_I|)+2ab, \tag{D.4}
\]

随后将端点向外舍入至固定精度二进有理网格；一切有序矩阵乘加均严守该包含规则。若外源响应解析解在复圆周 $|q|=\rho_*$ 上具有一致范数上界 $M$，幂级数保留至 $N$ 阶后，在收敛比 $t=\epsilon_B/\rho_*<1$ 上，第 $a$ 阶径向导数的无穷级数余项严格受控于

\[
\frac{M(N+1)^a a!}{\rho_*^a}
\frac{t^{N+1-a}}{(1-t)^{a+1}}, \tag{D.5}
\]

外层空间多指标导数的阶乘因子与 Cauchy 半径按相应多维全纯多圆盘一并计入。诚如第 9.4 节所述，式 (D.5) 直接作用于已收缩外源的响应解系数 (9.14)，从而避免了先对 $112\times 112$ 逆矩阵单独取范数再乘外源所导致的区间包裹膨胀 [[26]](#ref-26)。

### D.3　一阶能量域上的加权位置交换子与三扇区同态包围

第 6.1 节的单位球特征准备态 $\psi_0=G_D(i)e_{\mathrm{ball}}/\|G_D(i)e_{\mathrm{ball}}\|$ 属于一阶 Dirac 能量域 $\operatorname{Dom}(H_{\mathrm{free}})$；由于球特征函数在 $r=1$ 处间断，$H_{\mathrm{free}}^2\psi_0$ 并不属于 $L^2$，故证明绝对不假定二阶能量域正则性。式 (10.8) 所需的四阶动量探针强导数完全由位置乘子 $X_\nu^j\psi_0$、$X_\nu^jH_{\mathrm{free}}\psi_0$ 及有界一阶交换子 $[H_{\mathrm{free}},X_\nu]$ 归纳导出：先在紧支光滑核上建立四阶积分余项恒等式，再由算子闭性延拓至实际准备态 $\psi_0$，并借 Hölder 不等式给出全部混合方向的统一四阶位置矩上界。

对固定秩一投影 $P_0=|\psi_0\rangle\langle\psi_0|$，恒有算子压缩性质 $\|P_0v\|\le\|v\|$ 与 $\|(I-P_0)v\|\le\|v\|$。因此 `mean` 通道的高阶余项可由复均值直接收紧，而 `raw` 与 `connected` 通道各自保留精确零阶与一阶复 Gram，再用同一四阶位置矩向量界封闭四阶余项，确保三个通道在整个双球积分中严格共用同一个初始量子准备态。

## 附录 E　球面偶次单项式精确积分与形式化—区间双轨验收档案

### E.1　球面多项式精确 Gamma 积分与双路径交叉复核

对任意非负整数指数 $a,b,c,d$，北半球对称延拓下的球面方向单项式积分由方位角与极角 Euler–Beta 公式封闭给出：

\[
\int_0^{2\pi}\cos^c\varphi\sin^d\varphi\,d\varphi
=\begin{cases}
\displaystyle\frac{2\Gamma((c+1)/2)\Gamma((d+1)/2)}{\Gamma((c+d+2)/2)},&c,d\text{ 均为偶数},\\[8pt]
0,&\text{其余情形},
\end{cases} \tag{E.1}
\]

\[
\int_0^1 t^a(1-t^2)^{b/2}\,dt
=\frac{\Gamma((a+1)/2)\Gamma((b+2)/2)}{2\Gamma((a+b+3)/2)}, \tag{E.2}
\]

再乘以南北半球对称因子 $2$ 即得全球面积分。将第 10.1 节式 (10.3) 的精确系数张量代入，先完成 $9\times 9$ 外源方向代数收缩，再按式 (E.1)–(E.2) 精确积出球面角，即生成式 (10.7) 的整球二次系数张量。为排除任何代数实现偏差，独立复核程序将同一球面三角多项式展开为有限 Laurent–Fourier 词并在端点 $1,i$ 解析求值，所得球内体项、一阶球面通量、零阶球面通量及三者总和与 Gamma 公式逐有理数位完全一致。

### E.2　双轨验证证据清单与内核公理闭包审计

本篇全部定理按其数学属性接受两条严格互补轨道的机器核验：

1. **Lean 4 内核形式化证明轨道**（工具链固定为 Lean `v4.33.0` 与 mathlib `db584cd6d46c92f209a44c0f1c829460d327499d` [[30]](#ref-30)）：完整覆盖 Q1（$P_6$ 分级理想闭迹简化定理 3.2 与推论 3.3）、Q2（反对称 Fock 整词评价命题 4.1）、Q3（保源 Schur 恢复定理 5.2 与五维轻核抽象代数结构）、所消费的第一案 L1–L17 空间幺正演化与算子范数导数接口 [[2]](#ref-2)、Q5（1,445 槽母作用二阶变分认回命题 12.1 与全四复动量清分母九零模恢复定理 12.2）、Q6（实场半轴 Noether 算子命题 13.1、非线性共同正窗口母 Euler 零幅度导数铅笔定理 13.2 与电压 Cauchy 更新）以及第二版新增的 Q7（极小多项式商代数预解式、全 $289\times 289$ 静态极化有限矩阵坍缩定理 14.1、穿衣相位消除光子连通回馈定理 14.2 与精确 Yukawa 截断消除定理 14.3）。其中 Q7 的三个独立内核公理审计模块（`ActualSourceFullSylvesterMatrixFullAudit`、`ActualSourceEMEventFeedFullAudit` 与 `ActualSourceEventCutFullAudit`）逐项确认 `source_green_inverse`、`source_inverse_matrix_return`、`source_full_noether_polarization_matrix`、`actual_preparation_weight`、`actual_dressed_photon_connected_feed`、`actual_cut_free_static`、`actual_cut_free_physical_n3_window` 与 `actual_cut_free_sixth_ir_return` 仅依赖 Lean 标准三公理 `[propext, Classical.choice, Quot.sound]`，零 `sorry`、零自定义物理公理。
2. **精确有理代数与向外区间算术证明轨道** [[25]](#ref-25), [[26]](#ref-26)：完整覆盖 Q3 具体 $289\times 289$ 母矩阵消元与动态 $g_{00}$ 回写检验，以及 Q4（定理 1.2）的六次传播根隔离、256/512-bit 复 Gram 解析径向积分、11,760 个外源解系数与 Cauchy 尾界、球面精确有理积分及五通道相加后的 `raw`／`mean`／`connected` 对角紧区间、非对角统一界与全方向 Gershgorin 路径同伦判据。随附零外部依赖纯标准库核验脚本 `validation/verify_manuscript_formulas_v2.py` 可在 1 秒内独立复算全篇关键有理恒等式、$5\times 5$ 轻核多项式行列式、六次根隐函数导数、76 位球面通量相消与 Gershgorin 圆盘零分离；公开证据清单逐文件登记固定 Git 对象、SHA-256 校验和与字节长度。

<!-- code-availability:begin -->
## 代码与数据可得性

第二版 Q1–Q7 的[公开主张映射](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-map.json)和[复现说明](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-reproduction.md)固定于 H0mework 提交 `d916604d403ae97e19779ff6fcd789e0184a468d`（Apache-2.0）。映射逐项给出源纪元、公开声明、下游验证、资源、原认证及公开内核验收。第一版[固定映射](https://github.com/Sapientropic/H0mework/blob/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/low-energy-release-map.json)继续提供原范围的证明与精确科学证据。

各检查使用新的输出目录。以下命令核验固定映射及原认证，并构建、审查第二版新增范围 Q7。复现说明也给出继承证明和精确资源的入口。

```sh
git checkout d916604d403ae97e19779ff6fcd789e0184a468d
python3 tools/low_energy_v2.py entry --paper low-energy-loop-response
for check in build trust types; do
  LEAN_NUM_THREADS=2 python3 tools/low_energy_v2.py "$check"     --paper low-energy-loop-response --output ".local/low-energy-v2-$check"
done
```
<!-- code-availability:end -->

## 参考文献

<a id="ref-1"></a>
[1] 高健（Jian Gao）. *从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成*（*From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*）. CourtyCourt · Case 0，第三版（v3），Zenodo，2026. DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339)（第一版 v1 DOI: [10.5281/zenodo.23210292](https://doi.org/10.5281/zenodo.23210292)；第二版 v2 DOI: [10.5281/zenodo.23297179](https://doi.org/10.5281/zenodo.23297179)）.

<a id="ref-2"></a>
[2] 高健（Jian Gao）. *电流出庭：从耦合传播到实际电子、Coulomb 返回与 Born 修饰*（*The Current Takes the Stand: From Coupled Propagation to Actual Electrons, Coulomb Response, and Born Dressing*）. CourtyCourt · Case 1，第一版（v1），Zenodo，2026. DOI: [10.5281/zenodo.23299174](https://doi.org/10.5281/zenodo.23299174). 研究源 L1–L17 固定于 `Homework` `S = 30218c1aea92640eae09b1d9204a09b01a2d0e47`；[公开证明入口](https://github.com/Sapientropic/H0mework/blob/b9d66048342b1a5aeac3e112d920ed85401bb20a/Lean/H0mework/Papers/LowEnergyPhenomenology.lean).

<a id="ref-3"></a>
[3] 高健（Jian Gao）. *两负一正，裸迹宣誓：有序闭迹与整球响应曲率*（*Two Minuses, One Plus, and a Bare Trace Under Oath: Ordered Closed Traces and Whole-Ball Response Curvature*）. CourtyCourt · Case 2，第一版（v1），Zenodo，2026. DOI: [10.5281/zenodo.23299177](https://doi.org/10.5281/zenodo.23299177)；配套公开源码选集 `H0mework` 固定提交 [`b9d66048342b1a5aeac3e112d920ed85401bb20a`](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a).

<a id="ref-4"></a>
[4] Julian Schwinger. *On Gauge Invariance and Vacuum Polarization*. Physical Review, 82(5), 664–679, 1951. DOI: [10.1103/PhysRev.82.664](https://doi.org/10.1103/PhysRev.82.664).

<a id="ref-5"></a>
[5] Henri Epstein and Vladimir Glaser. *The Role of Locality in Perturbation Theory*. Annales de l'Institut Henri Poincaré, Section A ( Physique théorique ), 19(3), 211–295, 1973. [NUMDAM 原刊全文](http://www.numdam.org/item/AIHPA_1973__19_3_211_0/)（核读 §§1, 5.1–5.2, 6.1 坐标空间因果分布劈裂与奇异阶局部多项式自由度）.

<a id="ref-6"></a>
[6] Bryce S. DeWitt. *Quantum Theory of Gravity. II. The Manifestly Covariant Theory*. Physical Review, 162(5), 1195–1239, 1967. DOI: [10.1103/PhysRev.162.1195](https://doi.org/10.1103/PhysRev.162.1195).

<a id="ref-7"></a>
[7] Laurence F. Abbott. *Introduction to the Background Field Method*. Acta Physica Polonica B, 13(1–2), 33–50, 1982. [原刊全文 PDF](https://www.actaphys.uj.edu.pl/R/13/1/33/pdf)（核读 §2.2, pp. 39–42 连通生成泛函与 1PI 有效作用之区分）.

<a id="ref-8"></a>
[8] Ali H. Chamseddine and Alain Connes. *The Spectral Action Principle*. Communications in Mathematical Physics, 186(3), 731–750, 1997. DOI: [10.1007/s002200050126](https://doi.org/10.1007/s002200050126). arXiv:[hep-th/9606001](https://arxiv.org/abs/hep-th/9606001)（核读 §§1–2 欧氏自伴 Dirac 算符与带截断尺度 $\Lambda$ 的热核渐近展开）.

<a id="ref-9"></a>
[9] Stephen L. Adler. *Axial-Vector Vertex in Spinor Electrodynamics*. Physical Review, 177(5), 2426–2438, 1969. DOI: [10.1103/PhysRev.177.2426](https://doi.org/10.1103/PhysRev.177.2426).

<a id="ref-10"></a>
[10] John S. Bell and Roman Jackiw. *A PCAC puzzle: $\pi^0\to\gamma\gamma$ in the $\sigma$-model*. Il Nuovo Cimento A, 60(1), 47–61, 1969. DOI: [10.1007/BF02823296](https://doi.org/10.1007/BF02823296).

<a id="ref-11"></a>
[11] Julian Schwinger. *Brownian Motion of a Quantum Oscillator*. Journal of Mathematical Physics, 2(3), 407–432, 1961. DOI: [10.1063/1.1703727](https://doi.org/10.1063/1.1703727).

<a id="ref-12"></a>
[12] Leonid V. Keldysh. *Diagram Technique for Nonequilibrium Processes*. Zhurnal Eksperimental'noi i Teoreticheskoi Fiziki, 47, 1515–1527, 1964（英译刊：*Soviet Physics JETP*, 20(4), 1018–1026, 1965）.

<a id="ref-13"></a>
[13] Hal Tasaki. *Introduction to the “Second Quantization” Formalism for Non-Relativistic Quantum Mechanics: A Possible Substitution for Sections 6.7 and 6.8 of Feynman's “Statistical Mechanics”*. arXiv:[1812.10732v5](https://arxiv.org/abs/1812.10732), 2018（2023 修订第 5 版；核读 §3 式 (3.22)–(3.29) 费米子反对称 Fock 空间与一体算子二次量子化作用）.

<a id="ref-14"></a>
[14] Mary K. Gaillard. *The Effective One-Loop Lagrangian with Derivative Couplings*. Nuclear Physics B, 268(3–4), 669–692, 1986. DOI: [10.1016/0550-3213(86)90264-6](https://doi.org/10.1016/0550-3213(86)90264-6).

<a id="ref-15"></a>
[15] Oren Cheyette. *Effective Action for the Standard Model with Large Higgs Mass*. Nuclear Physics B, 297(1), 183–204, 1988. DOI: [10.1016/0550-3213(88)90205-2](https://doi.org/10.1016/0550-3213(88)90205-2).

<a id="ref-16"></a>
[16] Brian Henning, Xiaochuan Lu, and Hitoshi Murayama. *How to use the Standard Model effective field theory*. Journal of High Energy Physics, 2016(01), 023, 2016. DOI: [10.1007/JHEP01(2016)023](https://doi.org/10.1007/JHEP01(2016)023). arXiv:[1412.1837v2](https://arxiv.org/abs/1412.1837)（核读 §2.1 树级消元、内部指标迹 $\operatorname{tr}$ 与泛函迹 $\operatorname{Tr}\log$ 之区分）.

<a id="ref-17"></a>
[17] Thomas Appelquist and J. Carazzone. *Infrared Singularities and Massive Fields*. Physical Review D, 11(10), 2856–2861, 1975. DOI: [10.1103/PhysRevD.11.2856](https://doi.org/10.1103/PhysRevD.11.2856)（核读引言及 §§III–IV 重场低动量解耦定理）.

<a id="ref-18"></a>
[18] Issai Schur. *Über Potenzreihen, die im Innern des Einheitskreises beschränkt sind*. Journal für die reine und angewandte Mathematik, 147, 205–232, 1917. DOI: [10.1515/crll.1917.147.205](https://doi.org/10.1515/crll.1917.147.205).

<a id="ref-19"></a>
[19] Herman Feshbach. *Unified Theory of Nuclear Reactions*. Annals of Physics, 5(4), 357–390, 1958. DOI: [10.1016/0003-4916(58)90007-1](https://doi.org/10.1016/0003-4916(58)90007-1).

<a id="ref-20"></a>
[20] Paul A. M. Dirac. *Generalized Hamiltonian Dynamics*. Canadian Journal of Mathematics, 2, 129–148, 1950. DOI: [10.4153/CJM-1950-012-1](https://doi.org/10.4153/CJM-1950-012-1)（核读约束分类与辅助变量消元相容性传播）.

<a id="ref-21"></a>
[21] Yasushi Takahashi. *On the Generalized Ward Identity*. Il Nuovo Cimento, 6(2), 371–375, 1957. DOI: [10.1007/BF02832514](https://doi.org/10.1007/BF02832514).

<a id="ref-22"></a>
[22] Bruno Galerne. *Computation of the Perimeter of Measurable Sets via their Covariogram. Applications to Random Sets*. Image Analysis & Stereology, 30(1), 39–51, 2011. DOI: [10.5566/ias.v30.p39-51](https://doi.org/10.5566/ias.v30.p39-51).

<a id="ref-23"></a>
[23] James Joseph Sylvester. *A demonstration of the theorem that every homogeneous quadratic polynomial is reducible by real orthogonal substitutions to the form of a sum of positive and negative squares*. The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science, Series 4, 4(23), 138–142, 1852. DOI: [10.1080/14786445208647087](https://doi.org/10.1080/14786445208647087).

<a id="ref-24"></a>
[24] Semyon A. Gershgorin. *Über die Abgrenzung der Eigenwerte einer Matrix*. Bulletin de l'Académie des Sciences de l'URSS, Classe des sciences mathématiques et naturelles（*Izvestiya Akademii Nauk SSSR, Otdelenie Matematicheskikh i Estestvennykh Nauk*）, VII série, (6), 749–754, 1931.

<a id="ref-25"></a>
[25] Warwick Tucker. *A Rigorous ODE Solver and Smale's 14th Problem*. Foundations of Computational Mathematics, 2(1), 53–117, 2002. DOI: [10.1007/s102080010018](https://doi.org/10.1007/s102080010018).

<a id="ref-26"></a>
[26] Javier Gómez-Serrano. *Computer-Assisted Proofs in PDE: A Survey*. SeMA Journal, 76(3), 459–484, 2019. DOI: [10.1007/s40324-019-00186-x](https://doi.org/10.1007/s40324-019-00186-x). arXiv:[1810.00745](https://arxiv.org/abs/1810.00745)（核读 §§1–2 严格向外区间算术与例 2.1 包裹膨胀效应）.

<a id="ref-27"></a>
[27] Ryogo Kubo. *Statistical-Mechanical Theory of Irreversible Processes. I. General Theory and Simple Applications to Magnetic and Conduction Problems*. Journal of the Physical Society of Japan, 12(6), 570–586, 1957. DOI: [10.1143/JPSJ.12.570](https://doi.org/10.1143/JPSJ.12.570).

<a id="ref-28"></a>
[28] Marvin Rosenblum. *On the Operator Equation $BX - XA = Q$*. Duke Mathematical Journal, 23(2), 263–269, 1956. DOI: [10.1215/S0012-7094-56-02324-9](https://doi.org/10.1215/S0012-7094-56-02324-9).

<a id="ref-29"></a>
[29] Rajendra Bhatia and Peter Rosenthal. *How and Why to Solve the Operator Equation $AX - XB = Y$*. Bulletin of the London Mathematical Society, 29(1), 1–21, 1997. DOI: [10.1112/S0024609396001828](https://doi.org/10.1112/S0024609396001828).

<a id="ref-30"></a>
[30] Leonardo de Moura and Sebastian Ullrich. *The Lean 4 Theorem Prover and Programming Language*. Automated Deduction – CADE 28, Lecture Notes in Computer Science, 12699, 625–635, 2021. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37). [原文 PDF](https://lean-lang.org/papers/lean4.pdf)（核读 §§1, 5 极小可信内核与外部检查器架构）.

<a id="ref-31"></a>
[31] J. M. Luttinger. *Theory of Thermal Transport Coefficients*. Physical Review, 135(6A), A1505–A1514, 1964. DOI: [10.1103/PhysRev.135.A1505](https://doi.org/10.1103/PhysRev.135.A1505).

<a id="ref-32"></a>
[32] H. Arthur Weldon. *Covariant Calculations at Finite Temperature: The Relativistic Plasma*. Physical Review D, 26(6), 1394–1407, 1982. DOI: [10.1103/PhysRevD.26.1394](https://doi.org/10.1103/PhysRevD.26.1394).
