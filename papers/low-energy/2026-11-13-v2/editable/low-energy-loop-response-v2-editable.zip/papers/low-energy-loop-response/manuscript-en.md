# Cutoff-Free Noncommutative Polarization Curvature, Second-Variation Action Identification, and the (2,1) Inertia Law of Whole-Ball Response

**COURTYCOURT · THE THEORY TAKES THE STAND · Case 2 (Second Edition)**

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**Formal verification, rigorous interval enclosure, and dual-track audit note.** This second edition covers the complete proposition chain Q1–Q7 (the first-edition preprint covering Q1–Q6 is archived at [[3]](#ref-3)). Noncommutative ordered closed-trace reduction (Q1), second-quantized Fock whole-word readback (Q2), the fermionic Schur complement and five-dimensional origin light-kernel algebra (Q3), full four-complex-momentum mother-action second-Fréchet-variation identification and origin-kernel reconstruction (Q5), real-field and nonlinear-history causal Noether polarization (Q6), and minimal-polynomial quotient inversion, finite Sylvester matrix collapse, and exact Yukawa-cutoff elimination (Q7) are formally machine-checked in the Lean 4 (`v4.33.0`) kernel [[30]](#ref-30), with dependency closures restricted strictly to the three standard Lean axioms (`propext`, `Classical.choice`, `Quot.sound`), zero `sorry` placeholders, and zero unregistered physical axioms. The $(2,1,0)$ inertia law of the five-channel two-ball wave-packet polarization curvature tensor (Q4) is proved without floating-point approximation by combining exact rational source matrices, closed-form spherical Beta integrals, 11,760 outward-rounded dyadic rational contour rectangles (256/512-bit precision), and fourth-order position-moment analytic remainders, independently replayed across isolated implementations [[3]](#ref-3), [[25]](#ref-25), [[26]](#ref-26).

## Abstract

In a unified theory coupling first-order gravity, non-Abelian gauge fields, and chiral fermions, can one reduce the ordered noncommutative one-loop traces and evaluate the fixed five-channel spatial wave-packet polarization curvature tensor without an artificial ultraviolet momentum cutoff, without hand-added local counterterms, and with zero tunable parameters, lock the exact eigenvalue inertia of the full real symmetric tensor, and identify the low-energy bosonic propagation matrix entry by entry with the second Fréchet variation of the underlying mother action? Working directly from the parameter-free $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ mother action and its unique six-sector classical solution [[1]](#ref-1), we establish an affirmative proof across seven interconnected results (Q1–Q7). First, on the 252-complex-dimensional chiral exterior-power carrier equipped with an independent linear variational dual $\chi$, the $P_6$ grading and one-way wedge nilpotency ($N_a B N_b=0$) reduce the closed trace of every finite admissible ordered gauge-propagation word to that of its block-diagonal part, $\operatorname{tr}W=\operatorname{tr}W_0$, while annihilating every single-scalar closed trace and co-directional double-scalar open chain (Q1); on the antisymmetric Fock space $\mathcal F_-(\mathcal M)$, multiplying the complete $d\Gamma$ word prior to one-particle compression strictly separates the full-carrier bare trace ($252$), the unit prepared-state expectation ($1$), the explicit open scalar return ($-1$), and the spurious zero ($0$) induced by inserting an intermediate rank-one projection $P_w$ (Q2). Second, lossless auxiliary, Ward, and symmetry reductions map the 289-real-field linearized system to 103 fields, where a single exact Schur complement over 48 real matter coordinates constructs the rational bosonic operator $S_{55}=K_{bb}-K_{bm}M^{-1}K_{mb}$, the full 289-row symbolic readback $H_{289}F=J_{\mathrm{src}}S_{55}$, and the five-dimensional origin light kernel governing both linear and quadratic momentum time scales (Q3). Under a $dx^1S_{01}$ external gauge probe, co-directional variational readout, zero output momentum, double Laplace parameters $z=w=6c(1-i)$, and equal-radius $B$ incoming/observing ball windows, we assemble all five polarization channels (two quantum source legs, readout contact, and two bosonic propagation legs); isolating the sharp-lens $|d|$ cusp while retaining the bulk integral, both spherical boundary fluxes, and the full complex cross-Gram across 11,760 outward-rounded rational contour rectangles, a continuous-path Gershgorin homotopy proves that both the uncentered (raw) and centered (connected) curvature tensors have exact Sylvester inertia $(\mathrm{neg},\mathrm{pos},\mathrm{zero})=(2,1,0)$, with raw coordinate-diagonal intervals in $[-1.355200,-1.309214]$, $[2.140271,2.186257]$, $[-1.742600,-1.696614]\times 10^{-20}$ and off-diagonal magnitudes below $2.30\times 10^{-22}$, whereas the mean sector's second-axis interval straddles zero and is recorded separately (Q4).

On the variational-return and causal-operator side, we prove formally across all complex four-momenta $p\in\mathbb C^4$ that the Fourier–Euler matrix of the second Fréchet derivative of the mother action density over all 1,445 real first-jet slots (1,650 quadratic terms merged into a 3,071-entry Jacobi dictionary) equals $H_{289}(p)$ entry by entry, and construct from five origin columns $N$ and a $98=45+21+32$ coordinate complement the exact four-momentum Schur kernel $E(p)$, explicit Neumann radius $\rho$, cubic resolvent bound, and denominator-cleared whole-field recovery retaining contact and all nine null directions (Q5). Incorporating the fixed-canonical-momentum central contact shift and four-frequency Fourier assembly into the ordered five-factor configuration kernel yields a bounded Bochner half-line operator $\mathcal J_\infty$ on $\operatorname{Re}\lambda>0$, while the normalized creation-minus-background functional $\ell_d$ acting along nonlinear $C^1$ field histories on a positive window $0\le T<\tau(d,k,P,a)$ generates the full $289\times 289$ causal polarization tensor $\Pi_{d,T}(P,\lambda)$, the exact mother-Euler amplitude-derivative pencil $[W_T(P_0,\lambda)K_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$, and the full voltage Cauchy field update (Q6). Finally, integrality of the commuting left and right joint generators extracts—prior to any readout or external force—the finite-degree monic minimal polynomial $P_q(X)$ of the Sylvester evolution generator $\mathcal T_q$, producing in the quotient algebra $\mathbb C[X]/(P_q(X))$ without external invertibility certificates a finite weight vector $w_q(\lambda)=M_q(\lambda)^{-1}e_0$ that collapses all $289^2$ entries of the static-clock Noether polarization on $\operatorname{Re}\lambda>0$ into the closed finite matrix quadratic form $\Pi^{\mathrm{st}}_d(k,\lambda)_{ij}=w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}w_q(\lambda)$, cancels the dressing phase via the created unit-state Hilbert norm to feed the prepared photon amplitude directly, and proves exact invariance of the full-$Y$ static polarization, physical three-fermion ($N=3$) five-leg window, across all discrete Yukawa cutoff indices, with a shared fourth-order analytic extension and a zero sixth-order infrared limit (Q7).

**Keywords:** cutoff-free vacuum polarization; independent Dirac dual; ordered closed-trace reduction; whole-word Fock evaluation; fermionic Schur complement; sharp two-ball boundary flux; Sylvester inertia; minimal-polynomial quotient resolvent.

## 1 Problem Statement, Main Theorems, and Disciplinary Entry Routes

### 1.1 Three Classical Obstructions and the “252 vs. 1 vs. -1” Confrontation

Any attempt to evaluate one-loop vacuum polarization and field back-reaction rigorously in a theory coupling gravity, non-Abelian gauge fields, and chiral fermions immediately confronts three classical obstructions. The first obstruction is **ultraviolet divergence and subtraction ambiguity**: from Schwinger's proper-time integral representation [[4]](#ref-4) to Euclidean heat-kernel and spectral-action asymptotic expansions $\operatorname{Tr}\chi(D/\Lambda)$ [[8]](#ref-8), unbounded momentum-space loop integrals require an external ultraviolet scale $\Lambda$ or dimensional regularization; even when one works purely in position space via Epstein–Glaser causal distribution splitting [[5]](#ref-5), any singular order $\omega\ge 0$ leaves an undetermined degree-$\omega$ polynomial of local counterterms at coincidence. The second obstruction is **the conflation of functional bare traces with real-time prepared-state expectations**: the background-field one-loop $\operatorname{Tr}\log$ [[7]](#ref-7), [[16]](#ref-16) evaluates an operator trace over the entire carrier (appropriate to asymptotic in-out vacuum transitions), whereas physical polarization currents measure real-time two-sided expectations along a closed time path (in-in) in a definite initial state [[11]](#ref-11), [[12]](#ref-12); once a Lorentzian action retains an independent linear variational dual $\chi$ and a one-way chiral wedge coupling $Y_R$, operators cease to be self-adjoint and both multiplication order and projection timing alter the outcome. The third obstruction is **bookkeeping loss under heavy-field elimination and sharp wave-packet windows**: tree-level or one-loop covariant derivative expansions (CDE) [[14]](#ref-14), [[15]](#ref-15), [[16]](#ref-16) truncate heavy degrees of freedom into local asymptotic series that no longer satisfy the full coupled field equations row by row, while smooth momentum perturbation theory overlooks the non-analytic cusp loss and spherical boundary fluxes induced by finite spatial wave-packet or sharp-ball windows [[22]](#ref-22).

These distinctions are operational rather than semantic. On the 252-complex-dimensional matter carrier $\mathcal M$ of this paper, placing the identity operator $I$ on the stand already separates two distinct evaluations:

\[
 \operatorname{tr}_{\mathcal M}I=252,
 \qquad \langle w,Iw\rangle=1,\qquad \|w\|=1. \tag{1.1}
\]

Attempting to “correct” the second number from the first, or to treat the first as an ultraviolet limit of the second, confuses two inequivalent linear functionals: the unprojected bare matrix trace over the full carrier versus the expectation of a completed operator word in the fixed occupied state $w$. Once operator words are generated dynamically by the mother action, every algebraic step carries a strict order: on which side the Dirac resolvent acts, how the independent dual $\chi$ evolves on the right, whether a one-way scalar vertex is paired with a return readout, and whether one-particle state compression is applied after the entire second-quantized product is formed or inserted prematurely between factors. Section 3 proves that every closed trace with a co-directional one-way scalar insertion vanishes identically ($0$), yet Section 4 proves that applying the explicit return operator to that very same open transition yields $-1$, whereas inserting an intermediate rank-one projection $P_w=|w\rangle\langle w|$ collapses the reading back to $0$. The open transition is physically present; premature projection blinds the readout to it.

An analogous reversal governs three-dimensional wave-packet polarization. Taken in isolation, the zero-probe quantum source leg (omitting bosonic propagation and window shift) has a strictly negative uncentered external-momentum Hessian in all three spatial directions (approximately $-0.014035$, §6.4); once the two bosonic propagation legs, variational readout contact term, sharp two-ball boundary fluxes, and all-direction spherical integrals generated by the same parameter-free mother action are restored, the complete quadratic curvature tensor acquires one strictly positive principal direction. No external parameter is summoned to produce this sign reversal—only the complete reading of the same mother equations.

### 1.2 Main Curvature Theorem and Paired Positive/Negative Controls

Throughout the paper we work in the source coordinates and classical background constants uniquely locked in Section 2. Set

\[
 c=\frac{6\sqrt{15}}{25},\quad
 \epsilon_B=\frac{5234375}{294988800512},\quad
 B=\sqrt2\epsilon_B,\quad z=w=6c(1-i). \tag{1.2}
\]

**Provenance of constants (why none of the quantities above is a free parameter).** The unified theory contains zero adjustable physical parameters [[1]](#ref-1). The characteristic rate $c=N\sqrt2$, together with Section 2's lapse scale $N=3\sqrt{30}/25$, gauge background amplitude $a=3\sqrt2/5$, constitutive coupling $\sigma=1/2$, co-rotating precession frequency $\omega_0=3N\sqrt2/5$, the 252-dimensional exterior-power carrier, and the occupied state $w$, are all uniquely solved from a single parameter-free mother source in the flagship monograph [[1]](#ref-1) (Stages 1–10 closed; Definition 2.1, Theorems 4.2–4.4, §6.1, and Theorem 9.3 sealing zero unregistered physical authority). What the present paper specifies is the **observational probe protocol**: the external gauge direction $dx^1S_{01}$, zero output momentum $p_{\mathrm{out}}=0$, the unit position-ball filtered state, the double Laplace frequency factor $6(1-i)$ (chosen so its real part strictly dominates the exponential growth bound of the perturbed propagation kernel, §7.3), and the equal-radius $B=\sqrt2\epsilon_B$ incoming/observing momentum-ball windows, where $\epsilon_B<\rho_*=1/8192$ lies inside the certified analyticity disk common to all branch roots of the source-generated sextic dispersion (§9.4 and Appendix C.1). Consequently, the rational intervals tabulated below and the inertia law (1.4) are pure deductive outputs of a parameter-free theory under a fixed probe protocol.

Concretely, let the external gauge perturbation be $A_\varepsilon=A_0+\varepsilon\cos(d\cdot x)\,dx^1S_{01}$, with co-directional variational readout and zero observed output momentum $p_{\mathrm{out}}=0$. Denote by $\mathcal R_\alpha(d)$ the real reading of the complete five-channel polarization response assembled in Section 7, where $\alpha=\mathrm{raw},\mathrm{mean},\mathrm{conn}$ correspond respectively to inserting $I$, $P$, and $I-P$ for the rank-one spatial preparation projection $P=|\psi\rangle\langle\psi|$.

<a id="def-1-1"></a>

**Definition 1.1 (sharp two-ball response curvature tensor).** For every real unit vector $n\in S^2$, the symmetric positive and negative external-momentum branches constructed from the mother pairing admit the small-$s$ expansion

\[
 \mathcal R_\alpha(sn)=\mathcal R_\alpha(0)
 +a_\alpha(n)|s|+s^2n^T\mathsf K_\alpha n+o(s^2), \tag{1.3}
\]

where $a_\alpha(n)$ is an even directional function uniquely determined by boundary values on the sphere (recording the linear cusp loss from spherical cap clipping of the two-ball intersection [[22]](#ref-22)), and $\mathsf K_\alpha\in\mathbb R^{3\times 3}$ is a real symmetric matrix. We call $\mathsf K_\alpha$ the whole-ball response curvature tensor: it is the quadratic-form coefficient matrix in $d=sn$, with off-diagonal monomials $2K_{ij}d_id_j$. Even when subtracting $a_\alpha(n)|s|$ leaves a twice-differentiable remainder, its second derivative equals $2\mathsf K_\alpha$ rather than $\mathsf K_\alpha$; whenever $a_\alpha(n)\ne 0$, $\mathcal R_\alpha$ is non-differentiable at the origin and $\mathsf K_\alpha$ is never conflated with an origin Hessian of the full sharp-window response.

<a id="thm-1-2"></a>

**Theorem 1.2 (the $(2,1,0)$ inertia law for the specified two-ball window).** Under the fixed external probe, co-directional variational readout, spatial filtered state, double Laplace parameters, and equal-radius $B$ incoming/observing ball windows specified above, the real symmetric quadratic curvature tensors in (1.3) satisfy Sylvester's law of inertia [[23]](#ref-23) with

\[
 \operatorname{Inertia}(\mathsf K_{\mathrm{raw}})
 =\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0), \tag{1.4}
\]

where the triple counts strictly negative, strictly positive, and zero eigenvalues in order. Outward-rounded decimal enclosures of the certified dyadic rational intervals, in units of $10^{-20}$ (natural units of the mother action, retaining the full $(2\pi)^{-3}$ Fourier measure and $B^3$ window volume), are:

| Principal axis | Uncentered (`raw`) | Mean (`mean`) | Centered (`connected`) |
|---|---:|---:|---:|
| \(e_1\) | \([-1.355200,-1.309214]\) | \([-0.060120,-0.055272]\) | \([-1.297332,-1.251692]\) |
| \(e_2\) | \([2.140271,2.186257]\) | \([-0.001635,0.003212]\) | \([2.139655,2.185295]\) |
| \(e_3\) | \([-1.742600,-1.696614]\) | \([-0.043357,-0.038509]\) | \([-1.701494,-1.655854]\) |

Across all off-diagonal pairs $i\ne j$, the mixed entries obey the uniform absolute bounds

\[
 |K_{ij}^{\mathrm{raw}}|<2.299243\,10^{-22},\quad
 |K_{ij}^{\mathrm{mean}}|<2.423430\,10^{-23},\quad
 |K_{ij}^{\mathrm{conn}}|<2.281948\,10^{-22}. \tag{1.5}
\]

Section 11.2 combines the diagonal enclosures with the uniform off-diagonal bounds (1.5) via Gershgorin disk isolation [[24]](#ref-24) along a continuous off-diagonal scaling homotopy to prove (1.4)—three diagonal signs alone would not determine the inertia of a $3\times 3$ symmetric matrix. Because the `mean` enclosure along $e_2$ straddles $0$, its interval is reported verbatim without claiming an inertia sign; likewise, when $a_\alpha(n)\ne 0$, the leading slope for $|s|\ll B$ is governed by the $|s|$ cusp, so positive quadratic curvature does not imply monotonicity from the origin.

To display the falsifiable rigidity of all four load-bearing pillars (Q1–Q7) upfront, Table 1 pairs each universal positive theorem with its built-in structural counterexample or negative control: dropping any single noncommutative ordering rule, Ward compensation term, or spherical boundary flux triggers an immediate, verifiable breakdown.

**Table 1 Paired universal positive theorems and structural negative controls across the four pillars (Q1–Q7).**

| Pillar & propositions | Universal positive theorem & exact output | Paired structural counterexample / negative control | Location |
|---|---|---|---|
| **Pillar I · Ordered traces & Fock whole-word evaluation** (Q1–Q2) | Closed trace $\operatorname{tr}W=\operatorname{tr}W_0$ for all finite admissible ordered gauge words; single one-way scalar closed trace $=0$ and double insertion $Y_aWY_b=0$; Fock unit readback $=1$, explicit open scalar return $=-1$ | Two-gauge-vertex word yields 53-digit nonzero rational trace (3.9); three-vertex closed trace $=0$ yet open difference $W-W_0\ne 0$; Hermitian adjoint gives $\operatorname{tr}(N^\dagger N)=1296/125\ne 0$; bare carrier trace $=252$; intermediate $P_w$ erases $-1\mapsto 0$ and alters $6/16$ gauge words | §§3–4; App. A |
| **Pillar II · Fermionic Schur complement & $(2,1,0)$ inertia** (Q3–Q4) | $289\to 103\to 55$ single matter Schur complement $S_{55}$ satisfies symbolic 289-row write-back $H_{289}F=J_{\mathrm{src}}S_{55}$; 5D light kernel carries linear and quadratic scales; $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0)$ | Skipping Lorentz reduction corrupts $128$ matter entries; dropping $32$ Ward scalar source entries breaks (5.4); static $18N/125$ and homogeneous $33N/125$ fail to commute at $(0,0)$; bulk integral alone is all-negative $(-1.44,-0.19,-0.19)$; omitting sphere flux falsifies affine $0$; dropping cross-Gram imaginary part turns constant-field $0$ into $-32$; `mean` axis 2 straddles $0$ | §§5–11; Figs. 1–4; Apps. B–E |
| **Pillar III · Full four-momentum mother Hessian & origin-kernel recovery** (Q5) | 1,445-jet-slot second Fréchet derivative of mother density equals $H_{289}(p)$ across all $p\in\mathbb C^4$ (3,071-entry dictionary); $5\oplus(45+21+32)$ direct-sum complement yields exact $E(p)$, Neumann radius $\rho$, cubic remainder bound, and denominator-cleared 289-field + 9-null-mode recovery | Beyond quadratic $T_{12}(p)$ lie 48 nonzero cubic/quartic entries $T_{34}(p)$ and higher resolvent powers; 5 origin columns $N$ have nonzero components on the 98 complement coordinates (non-orthogonal); omitting null projection $P_n$ fails to close (12.20) | §12; Fig. 5 |
| **Pillar IV · Nonlinear causal Noether tensor & minimal-polynomial Sylvester collapse** (Q6–Q7) | Real 289-field half-line operator $\mathcal J_\infty$; creation-minus-background $\ell_d$ on $[0,\tau)$ yields $[W_TK_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$ and voltage Cauchy update; minimal-polynomial quotient inverse collapses all $289^2$ static entries to $w_q^{\mathsf T}D+w_q^{\mathsf T}Rw_q$, feeds photon amplitude phase-free, and proves exact Yukawa-cutoff invariance of static, $N=3$ window, and sixth-order IR limits | Omitting central Noether contact shift (13.2) loses transport slope; mismatched clocks $P=0,\lambda=T=1$ give $W_T=1-e^{-1}\ne T$ (forbidding division by $T$); a root of $P_q$ on $\operatorname{Re}\lambda\ne 0$ contradicts minimal degree; strict boundary kept between full-$Y$ cutoff elimination and finite-Green-leg photon pairs in (14.12) | §§13–14; Figs. 5–6; App. E |

### 1.3 Three-Minute Pen-and-Paper Verification Anchor

Before entering the 289-field algebra and contour enclosures, a reader can verify three elementary algebraic and calculus instances with pen and paper in three minutes. Requiring no computer code, they encapsulate the three central structural mechanisms of this paper.

<a id="ex-1-1"></a>

**Example 1.1 (three-minute pen-and-paper verification anchor).**

**(a) Five-inversion wedge sign and the “$252$ vs. $1$ vs. $-1$ vs. $0$” quartet.** On $\mathcal M=\mathbb C^4\otimes(\Lambda^6\oplus\Lambda^2\oplus\Lambda^4)\mathbb C^7$, $\dim_{\mathbb C}\mathcal M=4\times(7+21+35)=252$, so $\operatorname{tr}_{\mathcal M}I=252$. Let $P_6$ project onto $\mathbb C^4\otimes\Lambda^6\mathbb C^7$, let one-way operators satisfy $P_6N_a=N_a$ and $N_aP_6=0$, and let block-diagonal operators satisfy $[B,P_6]=0$. Associativity and trace cyclicity immediately yield

\[
 N_a B N_b = N_a B (P_6 N_b) = (N_a P_6) B N_b = 0,
\]

together with $\operatorname{tr}N_a=\operatorname{tr}(P_6N_a)=\operatorname{tr}(N_aP_6)=0$—the entire algebraic engine behind Theorem 3.2. Next inspect the unit prepared state $w\in\mathbb C^4\otimes\Lambda^2\mathbb C^7$ of §4.2, whose four nonzero spin-exterior slots $(0;15),(1;05),(2;15),(3;05)$ equal $\frac12,-\frac12,\frac12,-\frac12$, giving $\|w\|^2=4\times\frac14=1$ and $\langle w,Iw\rangle=1$. For the scalar perturbation $\delta\phi=e_{0234}\in\Lambda^4\mathbb C^7$, the right-handed projector $P_R=\operatorname{diag}(0,0,1,1)$ retains spin indices $2,3$; acting on the spin-$2$ component $+e_{15}=e_1\wedge e_5$ of $2w$, exterior multiplication gives

\[
 e_1\wedge e_5\wedge e_0\wedge e_2\wedge e_3\wedge e_4 = (-1)^5\,e_{012345} = -e_{012345},
\]

because sorting $(1,5,0,2,3,4)$ into $(0,1,2,3,4,5)$ requires exactly $5$ inversions: $(1,0),(5,0),(5,2),(5,3),(5,4)$. Hence the coordinate functional $r$ reading $e_{012345}$ in spin $2$ satisfies $rY_{\delta\phi}(2w)=-1$, and the explicit return operator $R=2wr$ gives $RY_{\delta\phi}w=w\cdot rY_{\delta\phi}(2w)=-w$, whence $\langle w,RY_{\delta\phi}w\rangle=-1$. Conversely, inserting $P_w=|w\rangle\langle w|$ between $R$ and $Y_{\delta\phi}$ forces $\langle w,Y_{\delta\phi}w\rangle=0$ (since $Y_{\delta\phi}w\in P_6\mathcal M$ and $P_6w=0$), collapsing $\langle w,RP_wY_{\delta\phi}w\rangle=0$. All four readings $252,1,-1,0$ truthfully answer four distinct operator questions.

**(b) Sharp two-ball lens cusp and exact cancellation of affine-field boundary flux.** When two Euclidean balls of radius $B$ in $\mathbb R^3$ have centers separated by $|s|\in[0,2B]$, elementary solid-of-revolution integration gives $\operatorname{Vol}(B_B\cap(B_B+sn))=\frac{4\pi}{3}B^3-\pi B^2|s|+\frac{\pi}{12}|s|^3$ (Eq. (8.1)): the linear cusp $-\pi B^2|s|$ equals minus the projected equatorial disk area $\pi B^2=\frac12\int_{\partial B}|n\cdot\nu|\,dS$ [[22]](#ref-22), and the quadratic $s^2$ coefficient vanishes identically on a constant integrand. Next test the affine field $a(k)=[1+(2+i)k_3]b$ along $n=e_3$ with $b^{\mathsf T}Qb=4$ in Eq. (8.7): since $\partial_3a=(2+i)b$ and $\partial_3^2a=0$, the left-hand integral gives $K(e_3)=0$ directly; on the integrated-by-parts right-hand side (omitting the common prefactor $\frac1{4(2\pi)^3}$), the bulk gradient term equals $-\int_B|(2+i)|^2(b^{\mathsf T}Qb)=-20\operatorname{Vol}(B_B)$, while the spherical boundary flux equals $\int_{\partial B}\nu_3\operatorname{Re}\bigl([1+(2-i)k_3](2+i)\bigr)(b^{\mathsf T}Qb)=\int_{\partial B}\nu_3(8+20k_3)\,dS=\int_{\partial B}20\,\nu_3k_3\,dS=+20\operatorname{Vol}(B_B)$ (since $\int_{\partial B}\nu_3\,dS=0$ by odd parity and $\int_{\partial B}\nu_3k_3\,dS=\int_B\partial_3k_3=\operatorname{Vol}(B_B)$ by the divergence theorem), canceling $-20\operatorname{Vol}(B_B)$ to exact $0$. Any approximation that drops the moving-window boundary flux manufactures a spurious negative curvature out of zero.

**(c) Two-line arithmetic locking $(2,1,0)$ inertia and series-free quotient inversion.** Widen each `raw` diagonal interval in §1.2 by $2m_{\mathrm{raw}}<2\times 0.022993\times 10^{-20}=0.045986\times 10^{-20}$: row 1 stays inside $[-1.4012,-1.2632]\times 10^{-20}<0$, row 2 inside $[2.0942,2.2323]\times 10^{-20}>0$, and row 3 inside $[-1.7886,-1.6506]\times 10^{-20}<0$. Along the symmetric homotopy $M(t)=\operatorname{diag}(K_{11},K_{22},K_{33})+t(K-\operatorname{diag}K)$ ($t\in[0,1]$), all Gershgorin disks remain strictly disjoint from $0$, so eigenvalue continuity locks $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=(2,1,0)$. Similarly, in §14, whenever $\mathcal T_q$ is annihilated by a monic polynomial $P_q(X)$ with $P_q(\lambda)\ne 0$, Euclidean division $P_q(X)=(X-\lambda)Q_{q,\lambda}(X)+P_q(\lambda)$ evaluated at $X=\mathcal T_q$ immediately yields $(\lambda I-\mathcal T_q)\bigl[P_q(\lambda)^{-1}Q_{q,\lambda}(\mathcal T_q)\bigr]=I$, inverting the resolvent algebraically with no infinite time integral or Neumann series.

### 1.4 Common-Source Dual-Branch Architecture and 15-Minute Disciplinary Verification Routes

The dependency footprint of this work within the series is explicit and minimal: the flagship monograph Case 0 [[1]](#ref-1) supplies the parameter-free mother action, the independent linear dual $\chi$, the unique nine-field classical solution, the occupied state $w$, and the three-carrier return pairing; Case 1 [[2]](#ref-2) supplies the self-adjoint Dirac generator on the 12-dimensional occupied subspace $L^2(\mathbb R^3,\mathbb C^{12})$, global real-time unitary evolution, and operator-norm causal Kubo derivatives (L1–L17). On that exact background and state, the present Case 2 closes four theorem groups: noncommutative ordered closed-trace reduction and Fock whole-word evaluation (§§3–4, Q1–Q2); the $289\to 103\to 55$ fermionic Schur complement, five-dimensional origin light kernel, and two-ball five-channel $(2,1,0)$ inertia law (§§5–11, Q3–Q4); full four-complex-momentum mother-action second-Fréchet-variation identification and $5\oplus 98$ denominator-cleared whole-field recovery (§12, Q5); and the configuration-space ordered five-factor causal Noether polarization tensor, minimal-polynomial quotient Sylvester collapse, and phase-free dressed photon connected feed (§§13–14, Q6–Q7).

As illustrated in Figure 1, the ordered closed-trace branch (Q1–Q2) and the spatial wave-packet polarization branch (Q3–Q4, Figures 1–4) bifurcate in parallel from the same mother action: the upper branch governs finite-fiber graded ideals and Fock whole-word order, whereas the lower branch couples the single-matter-feedback bosonic kernel to real-time occupied-state complex Gram integrals; no false implication leads from “vanishing one-way bare trace” to “vanishing spatial wave-packet response.” Sections 12–14 (Q5–Q7, Figures 5–6) then close the mother second variation, four-momentum origin kernel, and nonlinear configuration histories into a finite source-generated Sylvester matrix and cutoff-free response, keeping their configuration preparations and Laplace convergence domains strictly separated from the fixed two-ball protocol of §§6–11.

**15-minute disciplinary verification routes.** Because the paper bridges nonperturbative quantum field theory, sharp-window microlocal asymptotics and computer-assisted interval proofs, constrained variational PDEs, and operator-algebraic response theory, specialists may proceed directly from Example 1.1 along four self-contained verification tracks:

- **Quantum field theory, background-field effective actions, and chiral loop algebra**: read **§§3–5 and Appendices A–B (Theorem 3.2, Corollary 3.3, Proposition 4.1, Theorems 5.2–5.3, Figure 2)** to verify how the $P_6$ grading reduces arbitrary-length ordered gauge closed traces without ultraviolet cutoffs or regularization, how whole-word Fock evaluation separates $252$, $1$, and $-1$, and how the single fermionic Schur complement $S_{55}$ achieves symbolic 289-row write-back while isolating dual-scale dispersion and non-commuting origin limits.
- **Wave-packet scattering, integral geometry, and computer-assisted proofs**: read **§1.2, §§7.4–11.2, and Appendices D–E (Definition 1.1, Theorem 1.2, Proposition 10.1, Figures 3–4)** to verify how the two-ball intersection lens generates the $|d|$ covariogram cusp and two spherical boundary fluxes, how §9.4 eliminates interval wrapping inflation by solving source-contracted multi-index recursions prior to readout [[26]](#ref-26), and how §10.2's boundary fluxes flip the negative bulk curvature across zero into $(2,1,0)$ inertia.
- **Variational PDEs, constrained systems, and multi-momentum algebraic reduction**: read **§12 (Proposition 12.1, Theorem 12.2, Figure 5 upper half)** to verify how the second Fréchet derivative of the nine-field mother density across 1,445 real first-jet slots matches the 3,071-entry matrix $H_{289}(p)$ over all $p\in\mathbb C^4$, and how five origin columns plus a $45+21+32$ direct-sum complement yield an explicit Neumann radius $\rho$, cubic resolvent bound, and denominator-cleared recovery including all nine null modes.
- **Operator algebras, nonequilibrium Kubo response, and Sylvester equations**: read **§§13–14 (Proposition 13.1, Theorem 13.2, Theorems 14.1–14.3, Example 14.1, Figures 5–6) and §15** to verify how the creation-minus-background functional $\ell_d$ produces the mother-Euler pencil $[W_TK_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$ along nonlinear $C^1$ histories, how commuting integral generators collapse the half-line integral in $\mathbb C[X]/(P_q(X))$ to the finite quadratic form $w_q^{\mathsf T}D+w_q^{\mathsf T}Rw_q$, and how dressing-phase cancellation and discrete Yukawa-cutoff elimination feed directly into Case 3's source-native Thomson matching.

![Figure 1: Two parallel branches from the same zero-knob mother action and five-channel two-ball polarization assembly.](figures/fig01-two-branches-v2-en.svg)

**Figure 1. Two parallel branches from the same zero-knob mother action and five-channel two-ball polarization assembly.** The upper branch (Q1–Q2) preserves noncommutative word order, the $P_6$ chiral grading, and whole-word-first Fock evaluation; the lower branch (Q3–Q4) couples the single-matter-feedback bosonic Schur kernel and symbolic 289-row write-back to the real-time occupied-state complex Gram matrix. Both quantum source legs include Duhamel amplitude variation on the fixed incoming ball; the variational readout contact term and both bosonic propagation legs act on the $d$-shifted two-ball lens; all five vermilion-highlighted channels are indispensable. Window labels reflect the $p_{\mathrm{out}}=0$, equal-radius-$B$ protocol of Theorem 1.2 (general two-window assignments appear in §7.4); arrows denote mathematical construction dependencies rather than numerical equality.

## 2 One Mother Action and Four Non-Interchangeable Coordinate and Adjoint Conventions

Achieving zero-residual write-back across a 289-dimensional coupled system of first-order coframe gravity, non-Abelian gauge fields, exterior-power scalars, and chiral spinors requires fixing at the outset the exact mother Lagrangian density, time-rescaling factors, and strict separation between fiber Hermitian conjugation $\dagger$ and realified variational transpose $T$. This section records the shared field variables, background constants, and matrix conventions used throughout.

### 2.1 Nine Original Field Sectors, the 252-Dimensional Exterior-Power Carrier, and the Independent Dual

The nine original field sectors of the mother action are $\Phi=(e,\omega,B_{\mathrm{gr}},\lambda,A,B_g,\phi,\psi,\chi)$, comprising the four-dimensional coframe $e$, Lorentz spin connection $\omega$, gravitational auxiliary two-form $B_{\mathrm{gr}}$ and simplicity multiplier $\lambda$, gauge connection $A$ and constitutive auxiliary two-form $B_g$, degree-four exterior-power complex scalar $\phi$, and mutually independent matter spinor $\psi$ and linear variational dual $\chi$ [[1]](#ref-1). The matter carrier is

\[
 \mathcal M=\mathbb C^4\otimes
 (\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7),
 \qquad \dim\mathcal M=4(7+21+35)=252. \tag{2.1}
\]

Denote the standard basis of $\mathbb C^7$ by $e_0,\ldots,e_6$, with color indices $0,1,2$, weak-isospin indices $3,4$, and remaining indices $5,6$. The Standard Model gauge subalgebra bi-uniquely selected by the mother spectral order parameter is $\mathfrak h=\{\operatorname{diag}(C,W,y,-y):C\in\mathfrak{su}(3),\ W\in\mathfrak{su}(2),\ y\in i\mathbb R\}$ (real dimension $12$) [[1]](#ref-1); every gauge vertex in this paper arises from this fixed embedding via the exterior derivation law
$\rho(X)(v_1\wedge\cdots\wedge v_r)=\sum_jv_1\wedge\cdots\wedge Xv_j\wedge\cdots\wedge v_r$,
evaluated in ascending basis order with exact permutation parity signs.

With standard Pauli matrices $\sigma_j$, fix the four-dimensional Dirac representation

\[
 \gamma^0=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\quad
 \gamma^j=\begin{pmatrix}0&\sigma_j\\\sigma_j&0\end{pmatrix},\quad
 \gamma_5=\begin{pmatrix}-I_2&0\\0&I_2\end{pmatrix},\quad
 S=\gamma^0\gamma_5. \tag{2.2}
\]

The background scalar vacuum expectation and its induced one-way exterior-wedge Yukawa operator are

\[
 \begin{gathered}
 \phi_0=e_{0126}+e_{0124}+e_{0156}+e_{0145},\qquad
 T_\phi(w_6,w_2,w_4)=(w_2\wedge\phi,0,0),\\ Y_R=P_R T_\phi,\quad P_R=\operatorname{diag}(0,0,1,1).
 \end{gathered} \tag{2.3}
\]

Unlike Euclidean spectral actions built around a self-adjoint finite Dirac matrix $D_F$ [[8]](#ref-8), the Lorentzian variational principle here **never identifies the dual spinor $\chi$ with $\psi^\dagger$**. Retaining $\chi$ as an independent variational field endows both the bilinear matter density and its left/right Euler–Lagrange equations with an unambiguous noncommutative factor order.

Writing $\mathcal W$ for the top-form spacetime two-form wedge pairing, $J$ for the internal gravitational block-swap map, and $*_e$ for the Hodge star depending dynamically on the coframe $e$, the mother Lagrangian density reads [[1]](#ref-1)

\[
\begin{split}
\mathcal L={}&\mathcal W(B_{\mathrm{gr}},\widehat F_\omega)
-\tfrac12\mathcal W(B_{\mathrm{gr}},JB_{\mathrm{gr}})
+\mathcal W(\lambda,B_{\mathrm{gr}}-J\Sigma_e)\\
&+\mathcal W_g(B_g,F_A)-\tfrac\sigma2\mathcal W_g(B_g,*_eB_g)\\
&+\nu_e\left[\tfrac12g^{\mu\nu}\operatorname{Re}\langle D_\mu\phi,D_\nu\phi\rangle
-\|\phi-v\|^2+\operatorname{Re}\chi(i\Gamma_e^\mu D_\mu\psi+Y_R\psi)\right]. \tag{2.4}
\end{split}
\]

Here $v=\phi_0$, the internal Minkowski metric is $\eta=\operatorname{diag}(-1,1,1,1)$, the induced spacetime metric is $g=e^T\eta e$, and the volume density is $\nu_e=|\det e|$. Extending the Lorentz indices of the spin connection antisymmetrically to all $a,b$, covariant derivatives and frame contractions are given by

\[
 \begin{gathered}
 \Gamma_e^\mu=(e^{-1})^\mu{}_a\gamma^a,\qquad
 \Omega_\mu=\tfrac14\omega_{\mu ab}\gamma^a\gamma^b,\\
 D_\mu\psi=(\partial_\mu+\Omega_\mu+\rho(A_\mu))\psi,\quad
 D_\mu\phi=(\partial_\mu+\rho_4(A_\mu))\phi,
 \end{gathered}
\]

with coframe quadratic wedge $\Sigma_e^{ab}=e^a\wedge e^b$. Gauge curvature is $F_{\mu\nu}=\partial_\mu A_\nu-\partial_\nu A_\mu+[A_\mu,A_\nu]$ and Lorentz curvature $\widehat F_\omega$ follows the same convention. Both spacetime and internal two-form indices are ordered as $01,02,03,23,31,12$ with orientation $\varepsilon^{0123}=1$ (explicit $6\times 6$ matrices for $J$ and $\mathcal W$ appear in Appendix A.1). The gauge bilinear pairing equals $-\operatorname{Re}\operatorname{tr}(XX^\prime)$ on the $\mathfrak{su}(3)$ and $\mathfrak{su}(2)$ blocks, and $-\operatorname{Re}(yz)$ in the native $\mathfrak u(1)$ coordinate (without an extra two-slot trace factor of $2$).

### 2.2 Unique Background Constants, Physical Time, and Momentum Conversion Table

Under weak historical recovery, the unique non-degenerate nine-field classical solution of the mother action locks the background constants [[1]](#ref-1)

\[
 N=\frac{3\sqrt{30}}{25},\quad s_0=\sqrt2,\quad a=\frac{3\sqrt2}{5},\quad
 \omega_0=\frac{3N\sqrt2}{5},\quad \sigma=\frac12,\quad e=\operatorname{diag}(N,1,1,1). \tag{2.5}
\]

Its spatial spin-connection components are $\omega_{1,23}=\omega_{2,31}=\omega_{3,12}=\sqrt2$, and its gauge background is $A_0=0,A_j=a\tau_j$ (with $\tau_j=i\sigma_j/2$ embedded in the $0,1$ color block). At $t=0$, the classical matter and dual backgrounds equal $\psi_0=2w$ and $\chi_0=2\sqrt2\,w^\dagger S$ (the four nonzero entries of $w$ are listed in (4.6)). In the co-rotating frame below, $(\psi_0,\chi_0)$ is constant in time while physical-time phase precession is restored exactly by the unitary rotation $U_{\mathrm{rot}}(t)$; all variations continue to treat $(\psi,\chi)$ independently.

Physical time $t$ serves as the reference clock throughout; rescaled variables $\tau=Nt$ or $ct$ appear solely as local algebraic substitutions. Shared time, momentum, and window notations are summarized below:

| Symbol | Mathematical/physical meaning and exact conversion |
|---|---|
| \(\lambda\) | Physical-time Laplace exponent; real oscillation energy \(E\) corresponds to \(\lambda=-iE\) |
| \(u,q_{\mathrm{ax}}\) | Rationalized axial spectral and momentum coordinates: \(\lambda=N\sqrt2\,u,\ k_3=\sqrt2\,q_{\mathrm{ax}}\) |
| \(p=2\pi\xi\) | Physical spatial momentum in Fourier transforms of matter wave packets |
| \(y,d\) | Incoming bosonic physical momentum and external probe momentum; outgoing momentum is \(y-d\) under negative spatial phase |
| \(c=N\sqrt2\) | Source-locked Laplace rate constant (\(6\sqrt{15}/25\)), not an externally imposed light-speed scale |
| \(B=\sqrt2\epsilon_B\) | Common radius of the incoming and observing 3D momentum balls, distinct from the unit-radius (\(1\)) position-space preparation ball |

In the 289-real-field linearized algebra, matter and dual coordinates are written in the co-rotating frame that removes background phase precession: setting the charge matrix $Q=\gamma_5+2P_6$ and $U_{\mathrm{rot}}(t)=e^{-i\omega_0tQ}$, the co-rotating generator is $H_{\mathrm{st}}=H_{\mathrm{orig}}-\omega_0Q$. Physical time itself is unchanged, with

\[
 \psi_{\mathrm{orig}}(t)=U_{\mathrm{rot}}(t)\psi_0,\qquad
 \chi_{\mathrm{orig}}(t)=\chi_0S U_{\mathrm{rot}}(t)^\dagger S.
\]

Two coordinate assignments must be kept distinct: the real-time spatial current of Section 6 evolves under the unsubtracted physical-time generator $H_{\mathrm{orig}}$, whereas the 289-field algebraic eliminations of Sections 5 and 12 use the constant-coefficient co-rotating frame; the position-space preparation ball always has radius $1$, and its Dirac-filtered normalization constant $n$ (Eq. (6.6)) remains strictly fixed regardless of the momentum-window radius $B$ or external probe.

### 2.3 Two Matrix Transposes and the Terminal Whole-Word Evaluation Rule

On finite-dimensional complex fiber matrices, $\dagger$ denotes conjugate transpose (Hermitian adjoint); on realified first-jet Euler–Jacobi operator matrices incorporating the independent dual, the second variation of the mother action obeys the formal transpose symmetry $H(-p)^T=H(p)$, where $T$ is pure matrix transposition without complex conjugation. Pure transpose $T$ and Hermitian adjoint $\dagger$ are never interchanged. Calling a complex parameter set a *regular domain* always means that the principal symbol or block submatrix inverted at that step admits an exact two-sided inverse there (concrete domains are specified in §§3.2, 5.2, 9.4, and 12.3).

The baseline state functional induced by the unit occupied vector $w$ is $\Omega(A)=\langle w,Aw\rangle$; any isometric continuum embedding $E$ preserves $\Omega(E^\dagger AE)=\langle Ew,AEw\rangle$. Expressed through the independent dual background $(\psi_0,\chi_0)$, the same reading takes the exact form [[1]](#ref-1)

\[
 \Omega(A)=\frac{\chi_0(SA\psi_0)}{4\sqrt2}=\langle w,Aw\rangle. \tag{2.6}
\]

Here $S^2=I$, and the spinor-swap matrix $S=\gamma^0\gamma_5$ **acts once on the far left only after the entire operator word $A$ has been multiplied**, never inserted between interior factors; likewise, $\Omega$ is evaluated once at the end of the completed product without intermediate rank-one projections. Both the second-quantized Fock words of Section 4 and the two-time continuum complex Gram matrices of Section 6 adhere strictly to this terminal evaluation rule. To prevent cross-section conflation of identically named concepts, Table 2 summarizes all four quantum carriers, two coupled reduction chains, two “connected” functionals, and three resolvent/phase conventions used across the paper.

**Table 2 Master dictionary of quantum carriers, coupled reduction chains, connected functionals, and resolvent/phase conventions.**

| Structural dimension | Symbol & mathematical object | Active sections & claims | Exact definition & non-interchangeability rule |
|---|---|---|---|
| **Quantum carriers I–II** | Finite chiral fiber $\mathcal M$ ($\mathbb C^{252}$) and antisymmetric Fock space $\mathcal F_-(\mathcal M)=\bigoplus_{r=0}^{252}\Lambda^r\mathcal M$ | §§3–4 (Q1–Q2) | Purely algebraic operator words at fixed leg momenta; single-particle $d\Gamma(A_1)\cdots d\Gamma(A_m)J_1w=J_1(A_1\cdots A_mw)$ multiplies the full word prior to projection, with no spatial integration |
| **Quantum carrier III** | 12D occupied continuum space $L^2(\mathbb R^3,\mathcal H_{12})$ (isometric inclusion $F_{12}:\mathcal H_{12}\to\mathcal M$) | §§6–11 (Q4) | Reducing self-adjoint subspace of the free generator ($F_{12}^\dagger Y_RF_{12}=0$); unit position ball filtered by the Dirac resolvent at spectral point $i$ yields normalized $\psi$ |
| **Quantum carrier IV** | Full configuration Hilbert space $\mathscr H_{\mathrm{cfg}}=\mathcal H$ and bounded algebra $\mathcal B(\mathcal H)$ | §§13–14 (Q6–Q7) | Spans both the finite reference frame $F_d$ and multi-particle uncut-$Y$ outside words; ordered five-factor kernel multiplies completely before outer readout |
| **Reduction chains A–B** | Chain A: $289\to 103\to 55$ fermionic Schur complement $S_{55}$ (§5, Q3); Chain B: $5\oplus(45+21+32)$ four-momentum origin kernel $E(p)$ (§12, Q5) | §§5, 7, 12 | Chain A eliminates 48 real matter slots and writes back all 289 rows via $J_{\mathrm{src}}$ (32 Ward entries); Chain B uses an oblique coordinate complement across $p\in\mathbb C^4$ to recover contact, active, and 9 null modes |
| **“Connected” functionals I–II** | Spatial projector complement $I-P$ ($P=\lvert\psi\rangle\langle\psi\rvert$) vs. creation-minus-background $\ell_d(A)=-\langle u_\varepsilon,Au_\varepsilon\rangle+\langle v_\varepsilon,Av_\varepsilon\rangle$ | §§6.3–11 vs. §§13.2–14.3 | $I-P$ subtracts complex mean products inside one fixed wave packet (`raw = mean + conn`); $\ell_d$ subtracts shared-profile background expectations on $\mathcal H$ while retaining original Euler sign ($\|\ell_d\|\le 2$) |
| **Resolvents & momentum phases** | Fiber Dirac inverse $G_D(z)=i(z-H)^{-1}C_0^{-1}$ (Eq. 3.1); 12D Sylvester current kernel $G_z(k)$ (Eq. 6.14); quotient bilateral resolvent $\mathcal S_q(\lambda)=(\lambda I-\mathcal T_q)^{-1}$ (Eqs. 14.4–14.6) | §§3, 6, 13–14 | Wave-packet polarization (§§7–10) uses negative spatial phase $e^{-ik\cdot x}$ (outgoing momentum $y-d$); configuration kernels (§§13–14) assign left/right momenta $(p_d-k,p_d)$, never mixed across chapters |

## 3 Noncommutative Ordered Closed-Trace Reduction: One-Way Arrows and Graded Ideals (Q1)

This section resolves the first question on the upper branch of Figure 1: when the Lorentzian Dirac generator fails to be self-adjoint owing to the independent dual and the chiral exterior-wedge term $Y_R$, can arbitrary-order scalar transitions proliferate uncontrollably inside one-loop closed traces? Without performing momentum integrations, introducing ultraviolet regulators, or permuting distinct vertices, we prove that the $P_6$ chiral grading confines all one-way terms inside a square-zero ideal, reducing the closed trace of every finite admissible ordered gauge-propagation word to that of its free block-diagonal counterpart.

### 3.1 Independent-Dual Evolution and the Exact Dirac Resolvent

On a fixed spatial-momentum fiber, write the first-order matter equation as $D\psi=(C_0\partial_t+L)\psi=0$, where the temporal principal matrix $C_0=i\gamma^0/N$ is everywhere invertible. The Hamiltonian generator and the Dirac resolvent at spectral parameter $z\in\mathbb C$ satisfy

\[
 H=-iC_0^{-1}L,\quad D_z=-iC_0(z-H),\qquad
 G_D(z)=i(z-H)^{-1}C_0^{-1}. \tag{3.1}
\]

Direct left and right multiplication confirms $D_zG_D(z)=G_D(z)D_z=I$; both the trailing factor $C_0^{-1}$ and the prefactor $i$ are fixed by the first-order Lagrangian density and cannot be omitted.

Setting $A=-C_0^{-1}L=-iH$ and $U(t)=e^{tA}$, the paired time evolution of the matter spinor and its independent variational dual is

\[
 \psi(t)=U(t)\psi(0),\qquad
 \chi(t)=\chi(0)C_0U(-t)C_0^{-1}. \tag{3.2}
\]

Differentiating in $t$ immediately yields conservation of the canonical pairing, $\partial_t(\chi C_0\psi)=0$. Nowhere does (3.2) replace $\chi(t)$ by $\psi(t)^\dagger$, nor is the one-way wedge term inside the 252-dimensional generator $H$ self-adjoint under the standard complex inner product.

### 3.2 The $P_6$ Chiral Graded Ideal and Arbitrary-Length Ordered Gauge-Word Reduction

On $\mathcal M=\mathbb C^4\otimes(\Lambda^6\oplus\Lambda^2\oplus\Lambda^4)\mathbb C^7$, define the orthogonal projector onto the top exterior sector $\mathbb C^4\otimes\Lambda^6\mathbb C^7$:

\[
 P_6=I_4\otimes\operatorname{diag}(I_7,0_{21},0_{35}). \tag{3.3}
\]

Call $B\in\operatorname{End}(\mathcal M)$ **block-diagonal** if $[B,P_6]=0$, and call $N_a\in\operatorname{End}(\mathcal M)$ a **one-way arrow** if

\[
 P_6N_a=N_a,\qquad N_aP_6=0. \tag{3.4}
\]

Condition (3.4) states that $N_a=P_6N_a(I-P_6)$ maps lower exterior sectors irreversibly into $\Lambda^6$ with no return channel. For every block-diagonal operator $B$ and any one-way arrows $N_a,N_b$, three foundational ideal identities follow at once:

\[
 N_aBN_b=0,\quad BN_a,\ N_aB\text{ remain arrows},\quad \operatorname{tr}N_a=0, \tag{3.5}
\]

the trace identity following directly from cyclicity on finite-dimensional matrices, $\operatorname{tr}(P_6N_a)=\operatorname{tr}(N_aP_6)=0$.

<a id="def-3-1"></a>

**Definition 3.1 (admissible ordered gauge-propagation word).** For finite leg indices $j=1,\ldots,m$, let $H_{0,j}$ be free block-diagonal fiber generators, $N_j$ one-way terms, $z_j\in\mathbb C$ spectral parameters, and $V_j$ gauge-density coupling vertices satisfying $[H_{0,j},P_6]=[C_{0,j},P_6]=[V_j,P_6]=0$, the one-way condition (3.4) for each $N_j$, and two-sided invertibility of $C_{0,j}$ and $z_j-H_{0,j}$. Any finite ordered product $W$ of full Dirac resolvent legs $G_{D,j}=i(z_j-H_{0,j}-N_j)^{-1}C_{0,j}^{-1}$ and gauge vertices $V_j$ (allowing independent leg momenta and spectral parameters) is called an admissible ordered gauge-propagation word.

<a id="thm-3-2"></a>

**Theorem 3.2 (closed-trace reduction for arbitrary finite admissible ordered gauge words).** Write each leg generator as $H_j=H_{0,j}+N_j$. On the regular domain of Definition 3.1, the full resolvent truncates exactly at first order:

\[
 (z_j-H_j)^{-1}=R_{0,j}+R_{0,j}N_jR_{0,j},
 \quad R_{0,j}=(z_j-H_{0,j})^{-1}. \tag{3.6}
\]

Replacing every full leg $G_{D,j}$ in $W$ by its free block-diagonal leg $iR_{0,j}C_{0,j}^{-1}$ to form the free graded word $W_0$, one has

\[
 W=W_0+N_W,\qquad P_6N_W=N_W,\quad N_WP_6=0,\qquad
 \operatorname{tr}W=\operatorname{tr}W_0. \tag{3.7}
\]

**Proof.** Because $[R_{0,j},P_6]=0$, (3.5) gives $N_jR_{0,j}N_j=0$; multiplying $z_j-H_{0,j}-N_j$ on both the left and the right by $R_{0,j}+R_{0,j}N_jR_{0,j}$ annihilates the quadratic arrow term and establishes (3.6). Since $C_{0,j}^{-1}$ and $V_j$ commute with $P_6$, every factor in $W$ decomposes as “block-diagonal operator plus one-way arrow” (explicit block-lower-triangular multiplication is displayed in Appendix A.2, Eq. (A.4)). Expanding the finite product in fixed left-to-right order, every term containing two or more arrows separates adjacent arrows solely by block-diagonal factors and vanishes by the first identity of (3.5); the sum $N_W$ of all terms containing exactly one arrow remains a one-way arrow by the second identity of (3.5); and the unique arrow-free term is $W_0$. Taking the trace of $W=W_0+N_W$ and invoking $\operatorname{tr}N_W=0$ yields $\operatorname{tr}W=\operatorname{tr}W_0$. □

In sharp contrast to continuum chiral-anomaly calculations where divergent loop integrals are sensitive to momentum routing and trace cyclic shifts [[9]](#ref-9), [[10]](#ref-10), Theorem 3.2 holds purely algebraically on the 252-dimensional fiber at fixed leg momenta and spectral parameters, without permuting distinct vertices, imposing momentum regulators, or truncating word length.

<a id="cor-3-3"></a>

**Corollary 3.3 (vanishing of one-way scalar closed traces and double-insertion open chains).** For the one-way vertices $Y_a$ ($a=1,\ldots,70$) generated by all $70$ real scalar perturbation directions of the mother action and any admissible ordered gauge words $W,W_L,W_R$,

\[
 \operatorname{tr}(W_LY_aW_R)=0,\qquad
 Y_a W Y_b=0\quad\text{as an exact open-operator identity}. \tag{3.8}
\]

**Proof.** Every original scalar vertex $Y_a$ satisfies the arrow condition (3.4). Substituting $W=W_0+N_W$ from Theorem 3.2 into $Y_aWY_b$ gives $Y_aW_0Y_b=0$ and $Y_aN_WY_b=0$ by (3.5), proving the open-operator identity; similarly, expanding $W_LY_aW_R$ leaves only single-arrow terms (of trace zero) and multi-arrow terms (identically zero). Covering all $70^2=4,900$ co-directional scalar pairs at once, (3.8) is verified both by formal proof in Lean and by exhaustive rational evaluation at baseline `T`. □

### 3.3 Paired Negative Controls: Nonzero Gauge Traces, Nonzero Open Remainders, and Hermitian Back-Channels

Corollary 3.3 neither renders gauge closed traces trivial nor implies that open propagation words lack one-way transitions. Three explicit negative controls fix its exact boundary:

1. **Two-gauge-vertex closed traces are genuinely nonzero.** Taking the first gauge vertex in Appendix A.1 ($A_{01}$ on $A_0$) twice with leg parameters
   \[
    (k_1,z_1)=(0,1+2i),\qquad
    (k_2,z_2)=((0,0,3\sqrt2/2),3+i),
   \]
   exact rational evaluation of the full Dirac resolvent (3.1) produces a nonzero 53-digit Gaussian rational closed trace:
   \[
    \operatorname{tr}W=
    \frac{\begin{gathered}-95360266467327071496720412359528906607208738863660800\\
    -53185433068294844818992564133304778477617846100000000\,i\end{gathered}}
    {15868525877183800686561094790721538271497991716304161}\ne0. \tag{3.9}
   \]
2. **Equal closed traces do not imply equal open operators.** A three-gauge-vertex admissible word from the same vertex table has vanishing closed trace by symmetry, yet its open one-way remainder $N_W=W-W_0$ is strictly nonzero as a $252\times 252$ matrix.
3. **Artificially substituting the Hermitian adjoint opens a reverse channel.** Taking the conjugate transpose $N^\dagger$ of the background one-way temporal operator $N$ gives
   \[
    \operatorname{tr}(N^\dagger N)=\frac{1296}{125},\qquad
    \operatorname{tr}(N+N^\dagger)^2=\frac{2592}{125}. \tag{3.10}
   \]
   Because $N^\dagger=(I-P_6)N^\dagger P_6$ maps $\Lambda^6$ back into lower exterior powers, it violates (3.4). Equations (3.10) and (3.8) thus evaluate physically distinct operator classes: replacing independent-dual one-way vertices with Hermitian-symmetrized readouts manually injects a reverse transition channel absent from the mother action.

## 4 Whole-Word Fock Evaluation in Prepared States: Open Return $-1$ vs. Spurious Projection Zero (Q2)

In closed-time-path (in-in) quantum dynamics [[11]](#ref-11), [[12]](#ref-12), experimental probes measure not the full-carrier bare trace $\operatorname{tr}W$, but the real-time expectation of a completed second-quantized operator word in a prepared initial state. Working on the 252-mode antisymmetric Fock space $\mathcal F_-(\mathcal M)$, we establish the terminal whole-word evaluation rule [[13]](#ref-13) and demonstrate how premature rank-one state projection erases genuine open transitions.

### 4.1 Unit Prepared State, Boundary Weight $K$, and Whole-Word Fock Readback

The background-selected unit occupied vector $w\in\mathcal M$ lies entirely inside $\Lambda^2\mathbb C^7$, satisfying $P_6w=0$; hence every one-way arrow $N_a$ maps $w$ into $P_6\mathcal M\perp w$ and obeys $\langle w,N_aw\rangle=0$. On a general coframe $e$, the real-time boundary weight operator is

\[
 K_e=-i|\det e|\sqrt2\,S C_0(e),\qquad K=\sqrt2\gamma_5 \text{ on the classical background}. \tag{4.1}
\]

Clearly $[K,P_6]=0$. Combining (4.1) with (3.7) of Theorem 3.2 reduces both the unweighted and $K$-weighted expectations of every admissible ordered gauge word $W$ in $w$ to its free block-diagonal part:

\[
 \langle w,Ww\rangle=\langle w,W_0w\rangle,\qquad
 \langle w,KWw\rangle=\langle w,KW_0w\rangle. \tag{4.2}
\]

Let $\mathcal F_-({\mathcal M})=\bigoplus_{r=0}^{252}\Lambda^r\mathcal M$ denote the fermionic Fock space with one-particle isometric embedding $J_1:\mathcal M\to\mathcal F_-$. The second quantization $d\Gamma(A)$ of a one-body operator $A$ acts slotwise as a derivation on each $r$-particle sector [[13]](#ref-13). For any finite ordered sequence $A_1,\ldots,A_m$, the whole-word product satisfies

\[
 \mathbb W=d\Gamma(A_1)\cdots d\Gamma(A_m),\qquad
 \mathbb WJ_1v=J_1(A_1\cdots A_m)v. \tag{4.3}
\]

<a id="prop-4-1"></a>

**Proposition 4.1 (unit prepared-state readback of completed Fock words).** Multiplying the full operator word $\mathbb W$ on $\mathcal F_-(\mathcal M)$ prior to compressing against the one-particle prepared state $J_1w$ reproduces the exact independent-dual pairing:

\[
 \langle J_1w,\mathbb WJ_1w\rangle
 =\Omega(J_1^\dagger\mathbb WJ_1)
 =\langle w,A_1\cdots A_mw\rangle. \tag{4.4}
\]

Left-multiplying by $d\Gamma(K)$ yields the corresponding $K$-weighted whole-word reading.

**Proof.** Induction on $m$ using $d\Gamma(A)J_1=J_1A$ gives the second relation of (4.3); combining $J_1^\dagger J_1=I_{\mathcal M}$ with (2.6) yields (4.4). On multi-particle sectors $\mathbb W$ is in general distinct from the single derivation $d\Gamma(A_1\cdots A_m)$; for the full configuration-space words of §§13–14 containing explicit creation and annihilation operators, one must multiply the complete ordered Fock word before applying state evaluation, never applying (4.3) to particle-number-changing intermediate factors. □

For the spin-swap test operator $T_S=-iC_0^{-1}S$, substituting (4.1) exhibits the separation between prepared readouts and bare traces:

\[
 KT_S=-N\sqrt2 I,\qquad
 \langle w,KT_Sw\rangle=-N\sqrt2=-\frac{6\sqrt{15}}{25}, \tag{4.5}
\]

whereas the full-carrier bare trace of $KT_S$ equals $-252N\sqrt2$. More generally, for a mother coupling vertex $V$ with push generator $T=-iC_0^{-1}V$ and current readout $B_V=-KT$, the classical background $\psi_0=2w$ (amplitude squared $4$) produces volume current $4\langle w,B_Vw\rangle$, using the full-carrier weight $\sqrt2\gamma_5$ rather than substituting the co-rotating charge $Q=\gamma_5+2P_6$ prematurely.

### 4.2 Open Scalar Return $-1$ and Spurious Zero from Intermediate Rank-One Projection

As verified by hand in Example 1.1(a), the four nonzero entries of $w$, indexed by “(spin slot; ascending $\Lambda^2$ basis)”, are

\[
 w_{0;15}=\tfrac12,\quad w_{1;05}=-\tfrac12,\quad
 w_{2;15}=\tfrac12,\quad w_{3;05}=-\tfrac12. \tag{4.6}
\]

Select the scalar perturbation $\delta\phi=e_{0234}$, let the linear functional $r$ read the spin-$2$ coordinate along $e_{012345}\in\Lambda^6\mathbb C^7$, and write $Y=Y_{\delta\phi}$. The five-inversion wedge sign in (2.3) gives $rY(2w)=-1$, so the explicit open-return operator $R=2wr$ satisfies

\[
 RYw=-w,\quad \langle w,RYw\rangle=-1,\qquad
 \langle w,R P_wYw\rangle=0,\quad P_w=|w\rangle\langle w|. \tag{4.7}
\]

Equation (4.7) draws a sharp operational line between “vanishing diagonal expectation” and “zero physical transition”: $Y$ genuinely maps $w$ into the orthogonal sector $P_6\mathcal M$, so $\langle w,Yw\rangle=0$; the explicit return operator $R$ detects that open transition with reading $-1$, whereas inserting $P_w$ between $R$ and $Y$ projects out $P_6\mathcal M$ prior to return and manufactures a spurious $0$.

Across all $70$ real scalar directions, exactly $18$ satisfy $Y_aw\ne 0$ despite $\langle w,Y_aw\rangle=0$; under Hermitian-symmetrized real scalar force readouts, the two-scalar connected array acquires $36$ strictly nonzero entries. Admissible gauge words obey the same prohibition against intermediate rank-one projections: across $16$ certified two-gauge benchmark words, inserting $P_w$ mid-word alters the exact value of $6$ words.

### 4.3 Retarded Invertibility Domain and Continuum Filtered Preparation

On continuum spatial-momentum fibers, the free block-diagonal generator $H_0(p)$ is self-adjoint and therefore invertible across the entire upper complex energy half-plane $z=E+i\eta$ ($\eta>0$); Eq. (3.6) of Theorem 3.2 immediately lifts that resolvent to the full Dirac operator including $Y_R$. In chiral block form, the two-sided inverse reads

\[
 D=\begin{pmatrix}0&A\\B&Y_R\end{pmatrix},\qquad
 D^{-1}=\begin{pmatrix}-B^{-1}Y_RA^{-1}&B^{-1}\\ A^{-1}&0\end{pmatrix}, \tag{4.8}
\]

verified directly by left and right multiplication, which uniquely locks the lower-left one-way cross term $-B^{-1}Y_RA^{-1}$. When lifting the occupied state to a three-dimensional wave-packet preparation, the Dirac filter $R=G_D(i)$ acts once at each outer endpoint of an observable $A$: for the spatial ball embedding $e=Ew$ with fixed filtered norm $n=\|Re\|>0$, the continuum prepared expectation is

\[
 \Omega(E^\dagger R^\dagger A R E)/n^2
 =\langle\psi,A\psi\rangle,\qquad \psi=Re/n. \tag{4.9}
\]

The normalization $n$ depends solely on the fixed initial ball embedding $e$, is never recomputed per observable $A$ or external momentum probe, and is never re-inserted between interior operator factors. Every real-time continuum complex Gram matrix in Section 6 is generated uniformly from (4.9).

## 5 Fermionic Schur-Complement Bosonic Operator, Whole-Field Write-Back, and the Five-Dimensional Origin Light Kernel (Q3)

We now enter the lower branch of Figure 1: expanding the mother action around the nine-field classical solution couples 289 real bosonic and fermionic coordinates. Truncating heavy degrees of freedom into an asymptotic series in inverse mass powers, as in standard covariant derivative expansions (CDE) [[14]](#ref-14), [[15]](#ref-15), [[16]](#ref-16), both sacrifices finite-momentum poles and forfeits exact row-by-row satisfaction of the 289 coupled equations. On a common block-regular domain, we construct the lossless reduction chain $289\to 103\to 55$, prove that a single fermionic Schur complement [[18]](#ref-18) paired with source quotient-transpose maps restores all 289 mother equations symbolically, and extract at the singular origin a five-dimensional light kernel governing both linear and quadratic momentum time scales.

### 5.1 Lossless Constrained Reduction $289\to 103$: Eliminating Redundant Coordinates While Preserving All Equations

In the co-rotating frame, the 289 active real coordinates comprise $16$ coframe components, $24$ Lorentz spin-connection components, $36+36$ gravitational auxiliary fields $(B_{\mathrm{gr}},\lambda)$, $48$ gauge connections, $72$ gauge auxiliary two-forms $B_g$, $9$ scalar orbital directions, and $24+24$ active matter and independent-dual coordinates. Denote the real second-variation Fourier–Euler matrix of (2.4) by $H_{289}(p)$ (§12.1 proves formally across all $p\in\mathbb C^4$ its entrywise identity with the 1,445-slot first-jet second Fréchet derivative).

Purely algebraic auxiliary equations in the second variation [[20]](#ref-20) solve directly for

\[
 B_g=-\sigma^{-1}*_eF_A,\quad
 \delta B_g=K_g^{-1}(\delta F_A-\delta K_g\,B_{g,0}),
 \quad\delta B_{\mathrm{gr}}=J\delta\Sigma_e,\quad
 \delta\lambda=J\delta B_{\mathrm{gr}}-\delta\widehat F_\omega. \tag{5.1}
\]

In the second relation of (5.1), $K_g$ is the constitutive linear operator multiplying $B_g$: perturbing the coframe $e$ varies the Hodge star $*_e$ and generates the metric-gauge cross term $\delta K_g\,B_{g,0}$, forbidding any frozen-metric shortcut. Eliminating in succession the $72+72$ gravitational and gauge auxiliary coordinates, $24$ Lorentz spin-connection coordinates, $9$ scalar-potential Ward orbital directions, and $9$ source-symmetry gauge directions ($3$ color $\mathrm{SU}(2)$ plus $6$ local Lorentz generators) yields the exact dimension chain

\[
 289\longrightarrow217\longrightarrow145\longrightarrow121
 \longrightarrow112\longrightarrow103, \tag{5.2}
\]

storing at every step both the forward field-reconstruction map and the reverse-transposed source-covector map. A sharp negative control arises at step three: while eliminating $B_{\mathrm{gr}},\lambda,B_g$ leaves the matter block untouched, eliminating the $24$ real Lorentz spin-connection components (the first-order spin-torsion contact interaction) modifies exactly $128$ entries of the matter block; bypassing spin-connection elimination and inverting the bare free matter block misrepresents the mother dynamics.

### 5.2 Single Fermionic Feedback, the Rational Bosonic Operator $S_{55}$, and Symbolic 289-Row Write-Back

Partition the resulting $103$-dimensional system into bosonic coordinates $b\in\mathbb C^{55}$ and active matter-plus-dual coordinates $m\in\mathbb C^{48}$, and form the single fermionic Schur complement [[18]](#ref-18):

\[
 K_{103}=\begin{pmatrix}K_{bb}&K_{bm}\\K_{mb}&M\end{pmatrix},
 \qquad W=-M^{-1}K_{mb},\qquad
 S_{55}=K_{bb}-K_{bm}M^{-1}K_{mb}. \tag{5.3}
\]

<a id="def-5-1"></a>

**Definition 5.1 (common block-regular domain of the two elimination orders).** Define the common comparison domain for “auxiliary-then-matter” versus “matter-then-auxiliary” elimination as the complex momentum locus where the total auxiliary block $A_{\mathrm{aux}}$, the original matter block $D_{\mathrm{mat}}$, and both Schur complements $D_{\mathrm{mat}}-CA_{\mathrm{aux}}^{-1}B$ and $A_{\mathrm{aux}}-BD_{\mathrm{mat}}^{-1}C$ admit two-sided inverses (Eq. (5.3) itself requires only invertibility of the reduced $48\times 48$ block $M$). This locus is nonempty: at the rational test point $u=\frac35(1-3i),q_{\mathrm{ax}}=\frac3{10}$, every block along both orders has an exact two-sided inverse.

<a id="thm-5-2"></a>

**Theorem 5.2 (single-matter Schur operator $S_{55}$ and symbolic 289-row field/source write-back).** On the common regular domain of Definition 5.1, both admissible elimination orders produce the identical rational bosonic operator $S_{55}$. Moreover, there exist a field-reconstruction matrix $F\in\mathbb C^{289\times55}$ composed from the step solution graphs and an independently constructed source-lift matrix $J_{\mathrm{src}}\in\mathbb C^{289\times55}$ composed from quotient projections and reverse transposes such that the polynomial-rational matrix identity

\[
 H_{289}F=J_{\mathrm{src}}S_{55} \tag{5.4}
\]

holds entry by entry. In particular, wherever $S_{55}R_{55}=I_{55}$, setting $x=FR_{55}j$ solves all $289$ rows of the original coupled linearized equations $H_{289}x=J_{\mathrm{src}}j$ identically.

**Proof.** The nontrivial content of (5.4) lies in constructing $J_{\mathrm{src}}$ independently rather than tautologically defining the source as $H_{289}F$. For any invertible upper-left block $A$, block Gaussian elimination gives

\[
 \begin{pmatrix}A&B\\C&D\end{pmatrix}
 \begin{pmatrix}-A^{-1}B\\I\end{pmatrix}
 =\begin{pmatrix}0\\D-CA^{-1}B\end{pmatrix}. \tag{5.5}
\]

Composing the step solution graphs along (5.2) (including $m=Wb$ and the auxiliary graphs) constructs $F$; on the source side, starting from the reverse transpose $Q(-p)^T$ of the $112\to 103$ quotient projection $Q$ and restoring the Ward scalar-orbit and auxiliary rows in reverse order constructs $J_{\mathrm{src}}$ independently. Across any pair of invertible blocks, single-step and two-step elimination produce identical Schur complements by the Banachiewicz–Woodbury block-inversion identity, establishing (5.4) by finite composition. □

Within $J_{\mathrm{src}}$, exactly $32$ nonzero Ward scalar source compensation entries of the form $-T_{\mathrm{other}}(-p)^TJ_{112}$ are present; omitting those 32 entries immediately falsifies (5.4). Physically, the linearized current coupling between classical background matter and the gauge/gravitational fields is already encoded in $K_{bm},K_{mb}$, so (5.3) incorporates that linearized fermionic feedback once without double counting; it is distinct from an added one-loop vacuum determinant $\operatorname{Tr}\log$ [[16]](#ref-16).

### 5.3 Origin Singularity Decomposition: 42 Heavy and 6 Light Matter Directions

At the four-momentum origin $p=0$, the matter block $M_0=M(0,0)$ is singular, so (5.3) cannot be evaluated there directly. Exact rational rank and principal-minor evaluation give

\[
 \operatorname{rank}M_0=42,\qquad
 \det M_{hh,0}=
 -\frac{58990238851842729101108654352661116616704}
 {9094947017729282379150390625}\ne0. \tag{5.6}
\]

This provides an exact algebraic realization of Appelquist–Carazzone heavy-mode separation [[17]](#ref-17): using $G_0=M_{hh,0}^{-1}$ on the invertible $42\times 42$ heavy matter subblock, the full 48-dimensional embedding of the $6$ light matter null modes at the origin is

\[
 E_6=\begin{pmatrix}-G_0M_{h\ell,0}\\I_6\end{pmatrix},\qquad M_0E_6=0. \tag{5.7}
\]

The $6$ retained coordinate axes do not annihilate $M_0$ on their own; they require the heavy-mode dressing $-G_0M_{h\ell,0}$ in the upper block of (5.7). Writing $M_{hh}=M_{hh,0}+\Delta$, on $\|G_0\Delta\|<1$ one has the exact resolvent identity

\[
 M_{hh}^{-1}=G_0-G_0\Delta G_0+G_0\Delta G_0\Delta G_0
 -(G_0\Delta)^3M_{hh}^{-1}. \tag{5.8}
\]

Truncating at total momentum degree two yields a $61$-dimensional quadratic effective system ($55$ bosonic plus $6$ light matter coordinates) with remainder bounded by $\|G_0\Delta\|^3\|G_0\|/(1-\|G_0\Delta\|)$; substituting back into all 289 mother equations leaves zero first- and second-order residuals and a genuinely nonzero cubic residual (Section 12 upgrades this to an untruncated four-complex-momentum Schur kernel with explicit cubic resolvent bounds).

### 5.4 The Five-Dimensional Origin Light Kernel and Dual Linear/Quadratic Time Scales

<a id="thm-5-3"></a>

**Theorem 5.3 (five-dimensional origin light kernel and dual linear/quadratic momentum time scales).** The zero-momentum constant matrix of the $61$-dimensional quadratic system has exact rank $56$. Eliminating those $56$ heavy bosonic-plus-light-matter constant directions leaves a five-dimensional origin light kernel that agrees entrywise with one-shot elimination of all $98$ heavy directions directly from the $103$-dimensional system (retaining original coordinates $94,100,106,112,118$ together with their full heavy-field recovery graphs).

Along five symmetry/dual deformation paths of $(\psi_0,\chi_0)$—opposite real rescaling, opposite overall phase rotation, axial real rescaling, axial phase rotation, and pure imaginary variation of the independent dual (explicitly listed in Appendix B, Eq. (B.3))—one obtains a natural five-dimensional basis (change-of-basis determinant $4$ to the retained coordinates). In this natural basis, the first-order momentum matrix $K_1$ has only a single antisymmetric temporal pair nonzero (indices $1,\ldots,5$):

\[
 (K_1)_{35}=-8u,\qquad (K_1)_{53}=8u, \tag{5.9}
\]

while the full quadratic matrix $K_2$ is given in Appendix B, Eqs. (B.1)–(B.2), and its restriction to the three-dimensional nullspace of $K_1$ is strictly diagonal:

\[
 \operatorname{diag}\left(
 \frac{16}{9}(5q_{\mathrm{ax}}^2+3u^2),
 \frac{32}{737}(55q_{\mathrm{ax}}^2+67u^2),
 \frac{20}{81}(125q_{\mathrm{ax}}^2-162u^2)\right). \tag{5.10}
\]

**Proof and dual-scale dispersion.** Rank $56$ is certified by an explicit invertible $56\times 56$ principal minor and five nullspace solution columns; two-stage ($103\to 61\to 5$) and single-stage ($103\to 5$) reductions match entrywise across all six monomial matrices $1,u,q_{\mathrm{ax}},u^2,uq_{\mathrm{ax}},q_{\mathrm{ax}}^2$. Under hyperbolic rescaling $(u,q_{\mathrm{ax}})\mapsto(tu,tq_{\mathrm{ax}})$, the leading $t^8$ determinant coefficient is

\[
 \lim_{t\to0}\frac{\det K(tu,tq_{\mathrm{ax}})}{t^8}
 =\frac{655360}{537273}u^2(5q_{\mathrm{ax}}^2+3u^2)
 (55q_{\mathrm{ax}}^2+67u^2)(125q_{\mathrm{ax}}^2-162u^2), \tag{5.11}
\]

(transforming back to the retained coordinates multiplies by $4^2=16$). The three non-degenerate quadratic factors in (5.11) define three linear propagation cones (converting to physical $\lambda=N\sqrt2\,u,k_3=\sqrt2\,q_{\mathrm{ax}}$):

\[
 \frac{\lambda^2}{k^2}=-\frac{18}{25},\quad
 -\frac{594}{1675},\quad \frac13. \tag{5.12}
\]

Meanwhile, the double factor $u^2$ in (5.11) harbors a **quadratic slow time scale** driven by the antisymmetric linear coupling (5.9): setting $u=\varsigma q_{\mathrm{ax}}^2$ reduces the $(3,5)$ block to $\left(\begin{smallmatrix}-40/3&-8\varsigma\\8\varsigma&-10/3\end{smallmatrix}\right)$ and yields the leading $q_{\mathrm{ax}}^{10}$ determinant coefficient

\[
 \frac{512000000}{439587}(36\varsigma^2+25), \tag{5.13}
\]

whose roots $\varsigma=\pm 5i/6$ correspond to the quadratic dispersion $\lambda^2/k^4=-3/20$. One and the same five-dimensional origin kernel thus unifies linear cones and quadratic slow modes; exact poles at finite nonzero momentum require the untruncated sextic factor (Appendix B, Eq. (B.4), and Appendix C.1). □

### 5.5 Dynamical Metric $g_{00}$ Source Injection and Ray-Dependent Origin Limits

Consider the temporal metric perturbation $\delta g_{00}=-2N\,\delta e_{00}$. Under an action source term $+J_{00}\delta g_{00}$, the forced field equals minus the inverse applied to the source, whereas writing $Hx=J$ keeps the plus sign; $F$ and $J_{\mathrm{src}}$ align both conventions automatically.

Injecting a dynamical $g_{00}$ source, solving the reduced $25$-dimensional coupled system, and writing back the $33$ independent-dual coordinates and all $289$ fields yields the exact rational Green response. Approaching the origin along a fixed ray $u=rq_{\mathrm{ax}}$ gives

\[
 \lim_{q_{\mathrm{ax}}\to0}G_{00}(rq_{\mathrm{ax}},q_{\mathrm{ax}})
 =\frac{54\sqrt{30}(297r^2-125)}{3125(162r^2-125)},
 \quad r^2\ne\frac{125}{162}. \tag{5.14}
\]

Its static limit ($r=0$) equals $18N/125$, whereas its spatially homogeneous limit ($r\to\infty$) equals $33N/125$: no direction-independent limit exists at $(0,0)$. In the three-dimensional principal decomposition (5.10), the $g_{00}$ readout row and injection column equal $(0,0,-36u/25)$ and $(0,0,+36u/25)$, exciting the axial light phase mode

\[
 \theta=\frac{729u}{125(125q_{\mathrm{ax}}^2-162u^2)}. \tag{5.15}
\]

Adding the contact constant $18N/125$ to the dynamical pole term $\frac{486Nu^2}{25(162u^2-125q_{\mathrm{ax}}^2)}$ recovers (5.14) and identifies the axial pole in the $g_{00}$ read. Luttinger separates the spatially homogeneous and static limits of response to a temporal metric perturbation [[31]](#ref-31). Weldon shows how static screening and long-wavelength collective response differ in a relativistic plasma [[32]](#ref-32), whose propagating plasma modes have a frequency threshold. Here the zero-temperature coframe $e=\operatorname{diag}(N,1,1,1)$ and the five-dimensional source kernel give the gapless real axial growth branch $u^2=\frac{125}{162}q_{\mathrm{ax}}^2$ (Figure 2).

![Figure 2: Dual-scale dispersion of the 5D origin light kernel and ray-dependent metric response.](figures/fig06-light-kernel-v2-en.svg)

**Figure 2. Dual-scale dispersion of the 5D origin light kernel and ray-dependent metric response.** Left: exact leading dispersion laws derived from Appendix B's $5\times 5$ matrix kernel (B.1)–(B.2) and Eqs. (5.11)–(5.13), displaying the two oscillatory linear cones $|\operatorname{Im}u|=\sqrt{5/3}\,q_{\mathrm{ax}},\,\sqrt{55/67}\,q_{\mathrm{ax}}$, the real growth/decay cone $u=\sqrt{125/162}\,q_{\mathrm{ax}}$ coupled directly to dynamical metric perturbations (vermilion), and the quadratic slow mode $|\operatorname{Im}u|=\frac56q_{\mathrm{ax}}^2$ driven by the antisymmetric linear coupling $K_1$ (gold). Right: exact two-branch rational curve of $G_{00}(rq_{\mathrm{ax}},q_{\mathrm{ax}})/N=\frac{18(297r^2-125)}{125(162r^2-125)}$ versus origin-approach ray slope $r=u/q_{\mathrm{ax}}$ (Eqs. 5.14–5.15), separating the static screening limit $18/125=0.144$ ($r=0$), the resonant collective pole $r_*=\sqrt{125/162}\approx 0.878$, and the spatially homogeneous limit $33/125=0.264$ ($r\to\infty$).

## 6 Real-Time Evolution on the 12-Dimensional Occupied Subspace, the Sylvester Current Kernel, and Complex Gram Decomposition

Connecting Section 5's effective bosonic propagation operator to physical quantum probe measurements requires moving beyond static $t=0$ matrix elements to follow the two-time current autocorrelation and perturbative Kubo response [[27]](#ref-27) of the position-ball filtered state $\psi\in L^2(\mathbb R^3,\mathbb C^{12})$ under global real-time unitary evolution [[2]](#ref-2). This section derives the closed-form filtered profile on the 12-dimensional reduced carrier, the operator Sylvester frequency kernel under cosine gauge driving [[28]](#ref-28), [[29]](#ref-29), and the orthogonal `raw = mean + connected` decomposition in a fixed prepared state [[7]](#ref-7).

### 6.1 Position-Ball Dirac-Filtered Preparation and the Global Rank-One Projector $P$

Define the unit-radius position-ball embedding and its normalized Dirac-filtered wave packet at spectral point $i$:

\[
 e(x)=\frac{\mathbf1_{|x|\le1}}{\sqrt{4\pi/3}}w,\qquad
 \widehat\psi(p)=\frac{f(p)b(|p|)}n,\quad
 f(p)=i(i-H(p))^{-1}C_0^{-1}w, \tag{6.1}
\]

with spherical Fourier transform $b(r)=4\pi(\sin r-r\cos r)/(r^3\sqrt{4\pi/3})$ and squared norm $n^2=\int\|f(p)b(|p|)\|^2d^3p/(2\pi)^3$. By Theorem 7.1 of Case 1 [[2]](#ref-2), the 12-complex-dimensional occupied carrier $\mathcal H_{12}=\mathbb C^4\otimes\operatorname{span}\{e_{05},e_{15},e_{25}\}$ (isometric inclusion $F_{12}:\mathcal H_{12}\to\mathcal M$) is a reducing invariant subspace of the 252-dimensional free generator: although $Y_R\ne 0$ on $\mathcal M$, its two-sided compression $F_{12}^\dagger Y_RF_{12}$ vanishes identically on $\mathcal H_{12}$. On $\mathcal H_{12}$, the fiber Hamiltonian $H(p)=H_0+\sum p_jH_j$ is strictly self-adjoint, commutes with the boundary weight $[K,H(p)]=0$, and satisfies

\[
 \left(\sum p_jH_j\right)^2=N^2|p|^2I,\qquad K^2=2I. \tag{6.2}
\]

Padding the $0,1$ color generators $\tau_j$ by zero to $3\times 3$ matrices, the unsubtracted physical-time fiber Hamiltonian reads

\[
 H(p)=\frac{3N\sqrt2}{2}(\gamma_5\otimes I_3)
 +Na\sum_{j=1}^3 i\gamma^0\gamma^j\otimes\tau_j
 -N\sum_{j=1}^3p_j\gamma^0\gamma^j\otimes I_3.
\]

Set $Q=K/\sqrt2$ and $G_0=C_0^{-1}/(iN)$. In each chirality sector $\chi=\pm1$, the seed vector $s_\chi=(I+\chi Q)G_0w/2$ and its momentum companion $t_\chi=(\chi H-\omega_0)s_\chi/N$ span a closed two-dimensional invariant subspace:

\[
 \|s_\chi\|^2=\tfrac12,\quad
 \langle s_\chi,t_\chi\rangle=0,\quad
 \|t_\chi\|^2=|p|^2/2,\quad
 Hs_\chi=\chi(\omega_0s_\chi+Nt_\chi),\quad
 Ht_\chi=\chi(N|p|^2s_\chi+3\omega_0t_\chi). \tag{6.3}
\]

For $r=|p|>0$, $(\sqrt2s_\chi,\sqrt2t_\chi/r)$ forms an orthonormal pair reducing $H(p)$ to the $2\times 2$ real symmetric block $\chi\left(\begin{smallmatrix}\omega_0&Nr\\Nr&3\omega_0\end{smallmatrix}\right)$; although $t_\chi=0$ at $p=0$, expressing the filter directly in terms of the unnormalized polynomial vector $t_\chi$ yields a globally smooth profile across all $p\in\mathbb R^3$:

\[
 f(p)=-N\sum_{\chi=\pm1}
 \frac{(i-3\chi\omega_0)s_\chi+\chi Nt_\chi}
 {(i-\chi\omega_0)(i-3\chi\omega_0)-N^2|p|^2}, \tag{6.4}
\]

whose denominator has constant imaginary part $-4\chi\omega_0\ne 0$ and never vanishes for real $p$.

Self-convolution of the unit ball indicator has radial overlap $1-\frac34r+\frac1{16}r^3$ ($0\le r\le2$). Introducing the elementary exponential moment

\[
 J(\kappa)=\int_0^2(r-3r^2/4+r^4/16)e^{-\kappa r}\,dr
 =\frac{2\kappa^3-3\kappa^2+3-3(\kappa+1)^2e^{-2\kappa}}{2\kappa^5}, \tag{6.5}
\]

with complex decay wavenumber $\kappa^2=(1-3\omega_0^2+4i\omega_0)/N^2$ ($\operatorname{Re}\kappa>0$) and $Z=(i-3\omega_0)J(\kappa)$, exact angular and contour integration of (6.4) yields the filter norm squared and zero-momentum phase-current expectation:

\[
 n^2=\operatorname{Im}Z\simeq0.208904454900,\quad
 \mu_0=\frac{2\sqrt2}{N^2}\frac{\operatorname{Re}Z}{\operatorname{Im}Z}
 \simeq-0.701355479214, \tag{6.6}
\]

\[
 \|A_0\psi\|^2=\frac8{N^2n^2}-\frac8{N^4},\qquad
 \|(A_0-\mu_0)\psi\|^2\simeq45.287036020565, \tag{6.7}
\]

where $A_0=2KH/N^2$ is the native phase-current operator at zero spatial momentum transfer (subscript $0$ denotes $k=0$, not the temporal gauge potential). Throughout §§6–11, $P=|\psi\rangle\langle\psi|$ denotes the global rank-one projector on $L^2(\mathbb R^3,\mathcal H_{12})$—never a fiberwise momentum slice projector or secondary internal truncation.

### 6.2 Cosine-Field Duhamel Perturbation and the Frequency-Space Sylvester Current Kernel

Write $M_k=e^{ik\cdot X}$ for the spatial plane-wave multiplier. On the common domain $\operatorname{Dom}(H)$, the momentum-transfer-$k$ current operator and its perturbed Heisenberg evolution are

\[
 A_k=N^{-2}(KM_kH+H^\sharp M_kK),\qquad
 B_{\varepsilon,k}(t)=U_\varepsilon(t)^\dagger A_{\varepsilon,k}U_\varepsilon(t). \tag{6.8}
\]

On $\mathcal H_{12}$ one has $H^\sharp=H$, whereas on the full 252-dimensional domain $H=H_{\mathrm{free}}+N_Y$ has adjoint $H^\sharp=H_{\mathrm{free}}+N_Y^\dagger$ (with $N_Y=-iC_0^{-1}Y_R$ and $N_Y^\dagger=iY_R^\dagger(C_0^{-1})^\dagger$ in reversed factor order). Each momentum shift of $\cos(k\cdot X)=\frac12(e^{ik\cdot X}+e^{-ik\cdot X})$ carries a half-amplitude factor $1/2$:

\[
 A_{\cos k}(p_{\mathrm{out}},p_{\mathrm{in}})
 =\frac{KH(p_{\mathrm{in}})+H(p_{\mathrm{out}})^\dagger K}{2N^2},
 \quad p_{\mathrm{out}}=p_{\mathrm{in}}\pm k, \tag{6.9}
\]

matching the exact one-particle restriction of $\frac2N\operatorname{Herm}[d\Gamma(K)d\Gamma(M_{\cos k}H/N)]$ (with Hermitian symmetrization applied after forming the whole Fock product).

Fix the external gauge direction $dx^1S_{01}$ (using the unhalved generator $S_{01}=2\tau_1$ of Appendix A.1). Including the coframe volume density, the mother vertex induces the bounded self-adjoint fiber perturbation

\[
 V_{252}=-iC_0^{-1}\frac{V_{\mathrm{density}}(1,S_{01})}{N},\qquad
 V=F_{12}^\dagger V_{252}F_{12},\quad V^\dagger=V,\quad [K,V]=0,\quad\|V\|=N. \tag{6.10}
\]

For $W_d=\cos(d\cdot X)V$, the perturbed generator $H_\varepsilon=H+\varepsilon W_d$ preserves $\operatorname{Dom}(H_\varepsilon)=\operatorname{Dom}(H)$ and generates $U_\varepsilon(t)=e^{-itH_\varepsilon}$, whose operator-norm Fréchet derivative at $\varepsilon=0$ [[2]](#ref-2) is given by Duhamel's formula

\[
 D_d(t)=-i\int_0^tU(t-s)W_dU(s)\,ds. \tag{6.11}
\]

Separating the unhalved fiber Duhamel kernel for each momentum-shift sign $\sigma=\pm1$,

\[
 d_\sigma(t,p)=-i\int_0^tE_{p+\sigma d}(t-s)V E_p(s)\,ds,\qquad E_p(t)=e^{-itH(p)}, \tag{6.12}
\]

gives $\widehat{D_df}(r)=\frac12\sum_{\sigma=\pm 1}d_\sigma(t,r-\sigma d)\widehat f(r-\sigma d)$, with half-line Laplace transform $\frac12\cdot(-i)(z+iH(p+\sigma d))^{-1}V(z+iH(p))^{-1}$.

Differentiating the Heisenberg current (6.8) at $\varepsilon=0$ produces, in each branch $\sigma=\pm 1$, one direct contact term and two unitary-evolution variation terms:

\[
\begin{split}
 C_{\sigma,k}(t,p)={}&E_{p+k+\sigma d}^\dagger\frac{KV}{N^2}E_p\\
 &+\tfrac12d_{-\sigma}(t,p+k+\sigma d)^\dagger A_k(p)E_p\\
 &+\tfrac12E_{p+k+\sigma d}^\dagger A_k(p+\sigma d)d_\sigma(t,p),
 \quad A_k(p)=\frac{K[H(p+k)+H(p)]}{N^2}, \tag{6.13}
\end{split}
\]

where the direct contact term already incorporates the cosine factor $1/2$. Define the two-momentum commutator superoperator $\mathcal L_{\ell,r}X=i[H(\ell)X-XH(r)]$: because $H(\ell)$ and $H(r)$ are self-adjoint on $\mathcal H_{12}$, $\mathcal L_{\ell,r}$ is skew-adjoint on Hilbert–Schmidt operators, so for every $\operatorname{Re}z>0$ the Sylvester resolvent [[28]](#ref-28), [[29]](#ref-29) $\mathcal R_{z;\ell,r}=(z-\mathcal L_{\ell,r})^{-1}$ exists with $\|\mathcal R_{z;\ell,r}\|\le 1/\operatorname{Re}z$. Taking Laplace transforms closes both the unperturbed and first-order currents in frequency space:

\[
 \widehat B_k(z,p)=\mathcal R_{z;p+k,p}(A_k(p)), \tag{6.14}
\]

\[
 \widehat C_{\sigma,k}(z,p)=\mathcal R_{z;p+k+\sigma d,p}
 \left[\frac{KV}{N^2}+\frac i2\{V\widehat B_k(z,p)-\widehat B_k(z,p+\sigma d)V\}\right]. \tag{6.15}
\]

Equations (6.14)–(6.15) invert a genuine bilateral Sylvester equation coupling left and right momentum spectra; they cannot be factored into ordinary products of separate one-sided resolvents.

### 6.3 Orthogonal Decomposition into `raw`, `mean`, and `connected` in a Fixed Prepared State

Set $\Pi_{\mathrm{raw}}=I,\Pi_{\mathrm{mean}}=P,\Pi_{\mathrm{conn}}=I-P$, and define projected current vectors $j^\alpha_k(t)=\Pi_\alpha B_k(t)\psi$ and $\zeta^\alpha_{d,k}(t)=\Pi_\alpha C_{d,k}(t)\psi$. Their zeroth- and first-order two-time Laplace–Gram functionals are

\[
 \mathcal N_0^\alpha(k,l;z,w)
 =\int_0^\infty\!\!\int_0^\infty e^{-\bar zt-ws}
 \langle j_k^\alpha(t),j_l^\alpha(s)\rangle\,dt\,ds, \tag{6.16}
\]

\[
 \mathcal N_1^\alpha(d;k,l;z,w)
 =\iint e^{-\bar zt-ws}
 \left[\langle\zeta_{d,k}^\alpha(t),j_l^\alpha(s)\rangle
 +\langle j_k^\alpha(t),\zeta_{d,l}^\alpha(s)\rangle\right]dt\,ds. \tag{6.17}
\]

Orthogonality $P(I-P)=0$ yields the exact Pythagorean identity $\mathcal N^{\mathrm{raw}}=\mathcal N^{\mathrm{mean}}+\mathcal N^{\mathrm{conn}}$. We note the precise conceptual distinction from Abbott's background-field 1PI functional [[7]](#ref-7): whereas vacuum 1PI vertices arise by Legendre-transforming a vacuum connected generating functional, here `connected` subtracts the factorized state expectation $\mathcal N_0^{\mathrm{mean}}=\overline{\mu_B(k,z)}\mu_B(l,w)$ inside the **same fixed non-vacuum wave-packet preparation** $|\psi\rangle$; because our inner product is conjugate-linear in its first slot, general two-probe Gram entries at $(k,l)$ are genuinely complex and carry the conjugated left Laplace weight $e^{-\bar zt}$.

<a id="prop-6-1"></a>

**Proposition 6.1 (absolute convergence and derivative-integral interchange for the two-time Laplace–Gram functionals).** For all $\operatorname{Re}z>0,\operatorname{Re}w>0$, the improper double integrals (6.16)–(6.17) converge absolutely, and $\varepsilon$-differentiation at $\varepsilon=0$ commutes with $\int_0^\infty\!\!\int_0^\infty dt\,ds$; on the bounded momentum balls and frequency domain of Section 9, mixed momentum derivatives up to fourth order are uniformly dominated by position moments of the initial state.

**Proof.** Two Duhamel iterations give $\|U_\varepsilon(t)-U(t)\|\le|\varepsilon|N|t|$ and $\|U_\varepsilon(t)-U(t)-\varepsilon D_d(t)\|\le\varepsilon^2N^2t^2/2$. With $\alpha_0=\sqrt2/N^2$, $h=\|H\psi\|$, $a_k=\alpha_0(2h+N|k|)$, and $b_0=2\alpha_0N$, the first variation and quadratic remainder of the current vector obey

\[
 z_k(t)=b_0+2Na_k|t|,\qquad
 d_k(t)=2Nb_0|t|+2N^2a_kt^2, \tag{6.18}
\]

bounding the $\varepsilon^2$ inner-product remainder by $\varepsilon^2[d_k(t)a_l+a_kd_l(s)+z_k(t)z_l(s)]$. Since $\int_0^\infty e^{-\eta t}t^m\,dt=m!/\eta^{m+1}<\infty$ for $\eta=\min(\operatorname{Re}z,\operatorname{Re}w)>0$, dominated convergence justifies absolute integrability, Fubini interchange, and differentiation under the integral sign at $\varepsilon=0$. Uniform fourth-order momentum-derivative bounds follow from the weighted position-commutator recursion in Appendix D.3 (requiring only fourth position moments of $\psi$ and $H\psi$, without assuming $\psi\in\operatorname{Dom}(H^2)$). □

### 6.4 Negative Control: Isotropic Negativity of the Zero-Probe Quantum Source and Centering Sign Flip

Inspect first the zero-probe limit $k=0$, where $B_{\varepsilon,0}(t)=2K(H+\varepsilon W_d)/N^2$ is time-independent, external-momentum second derivatives simplify to

\[
 C''_{ij}\widehat\psi(p)=\frac{2KV}{N^2n}\,
 \partial_{p_i}\partial_{p_j}[f(p)b(|p|)], \tag{6.19}
\]

and the double Laplace integral collapses to $1/|z|^2$. At $|z|^2=7776/125$, exact full-space integration of (6.4)–(6.5) yields the midpoint values below (rigorous outward-rounded enclosures appear in Appendix D):

| External momentum axis | `raw` quantum-source Hessian | `mean` quantum-source Hessian | `connected` quantum-source Hessian |
|---|---:|---:|---:|
| \(e_1\) | \(-0.014034767643875352\) | \(-0.021154588614571218\) | \(+0.007119820970695866\) |
| \(e_2, e_3\) | \(-0.014034767643875352\) | \(-0.011031425013252896\) | \(-0.003003342630622456\) |

Two structural lessons are immediate: first, the `raw` quantum-source Hessian alone is isotropic and strictly negative along all three axes (confirming §1.1: without restoring the bosonic propagation legs, `raw` can never acquire a positive eigenvalue); second, subtracting the mean product term $\mu_0\mu''_{ij}$ already flips the sign of `connected` along $e_1$. Once $k\ne 0$, the genuine Sylvester derivative (6.15) evolves nontrivially in time and develops a nonzero imaginary part (e.g., its right-leg second-order `connected` entry is approximately $-0.222877720447-0.018187219957i$), invalidating any static $t=0$ shortcut divided by $|z|^2$.

## 7 Five-Channel Wave-Packet Polarization Assembly and the Zero-Counterterm Instantaneous Kernel

This section couples Section 5's effective bosonic propagation to Section 6's real-time quantum currents across the two-ball wave-packet window. Three mathematical hurdles are resolved head-on: (i) reconstructing global three-momentum propagation columns from axial $g_{00}$ residues with zero polar-angle singularities; (ii) solving the nine-row Noether compensation source from a two-sided cubic Ward identity [[21]](#ref-21) prior to inverting the perturbed field equation; and (iii) isolating the $\delta'_0,\delta_0$ instantaneous distributional parts of the perturbed propagator in position-time convolution—where, unlike Epstein–Glaser causal splitting with undetermined local counterterm polynomials [[5]](#ref-5), $(P_1,P_0)$ are uniquely locked by $|\lambda|=5c$ contour integrals and high-frequency mother identities with zero free subtraction constants.

### 7.1 Singularity-Free Global Three-Momentum Reconstruction from the Light $g_{00}$ Branch

Set $T=|k|^2/2$ and let $\widehat F(U,T)$ denote the even sextic dispersion factor of the mother system (exact integer coefficients in Appendix C.1, Eq. (C.1)). Fix the normalization constant and implicit light-branch conditions

\[
 \begin{gathered}
 c_F=-100383300000000,\quad
 \widehat F(U(T),T)=0,\quad U(0)=0,\\
 U'(0)=\frac{125}{162},\quad
 D(U,T)=\widehat F_U(U,T)/c_F.
 \end{gathered} \tag{7.1}
\]

From the mother equations one constructs three global 289-component polynomial columns $\mathcal A(k,U,T),\mathcal B(k,U,T),\mathcal Z(k,U,T)$ (with $87,114,56$ nonzero rows respectively) obeying, prior to root substitution, the exact polynomial identity

\[
 H_{289}(\lambda,-ik)(\lambda\mathcal A+\mathcal B)
 =(\lambda^2-c^2U)\mathcal Z-\frac{c^2}{c_F}\widehat F(U,T)j_{00}, \tag{7.2}
\]

where $j_{00}$ is §5.5's dynamical $g_{00}$ injection column (nonzero entry $-2N$). Restricting (7.2) to the implicit light-root manifold $\widehat F(U(T),T)=0$ and setting

\[
 F_\lambda(k)=\frac{\lambda\mathcal A(k,U,T)+\mathcal B(k,U,T)}
 {D(U,T)(\lambda^2-c^2U)},\qquad I_0(k)=\frac{\mathcal Z(k,U,T)}{D(U,T)}, \tag{7.3}
\]

annihilates the final term of (7.2) and produces the global three-momentum solution $H_{289}(\lambda,-ik)F_\lambda(k)=I_0(k)$ ($I_0$ being the projected source of this light pole rather than the bare point source $j_{00}$).

**Construction and proof.** Separating the axial residue column $\mathcal V(u,q_{\mathrm{ax}})$ by $u$-parity gives

\[
 \mathcal A_{\mathrm{ax}}=-\frac c{c_F}\frac{\mathcal V(u,q_{\mathrm{ax}})-\mathcal V(-u,q_{\mathrm{ax}})}{2u},
 \qquad
 \mathcal B_{\mathrm{ax}}=-\frac {c^2}{c_F}\frac{\mathcal V(u,q_{\mathrm{ax}})+\mathcal V(-u,q_{\mathrm{ax}})}{2}. \tag{7.4}
\]

Transporting field columns under the mother spatial rotation generators and source covectors under their inverse transposes, the total angular-momentum Casimir decomposes these axial columns purely into $j=0,1,2$ sectors whose radial factors equal $q_{\mathrm{ax}}^j$ times polynomials in $(U,T)$. Consequently, the degree-two Cartesian spherical-harmonic formula (C.2) reconstructs global polynomial columns $\mathcal A,\mathcal B,\mathcal Z$ over all $k\in\mathbb R^3$ without polar denominators $\sqrt{k_x^2+k_y^2}$. Direct substitution into $H_{289}$ verifies (7.2), and dividing by $D(U,T)\in[39/40,41/40]$ on the implicit root yields (7.3).

In physical time, the corresponding retarded causal propagation kernel is

\[
 K_0(t,k)=\mathbf1_{t\ge0}
 \frac{\mathcal A\cosh(c\sqrt U\,t)+\mathcal B\sinh(c\sqrt U\,t)/(c\sqrt U)}D, \tag{7.5}
\]

(analytic continuation $\sinh(c\sqrt U\,t)/(c\sqrt U)=t$ at $U=0$). Temporal-degree identities $H_2\mathcal A=H_2\mathcal B=0$, $H_1\mathcal A=\mathcal Z$, and $H_0\mathcal A+H_1\mathcal B=0$ confirm $H_{289}K_0=(\mathcal Z/D)\delta_0$ with zero past support, whose Laplace transform on $\operatorname{Re}\lambda>c\sqrt U$ equals (7.3).

### 7.2 Two-Sided Cubic Ward Identity and Prior Solution of the Nine-Row Compensation Source

Fix the positive-phase external gauge plane wave $a_\delta=e^{i\delta\cdot x}dx^1S_{01}$. Linearized curvature and the coframe Hodge star determine its companion auxiliary variation:

\[
 b_{g,1}=-\sigma^{-1}*_eD_A(p_e)a_\delta,\qquad p_e=(0,i\delta). \tag{7.6}
\]

Setting $b_1=(a_\delta,b_{g,1})$ with background residual $E_1=H_{289}(p_e)b_1$, gauge and local Lorentz symmetry variations of the mother action generate the perturbed symmetry columns $K_1$ and source-curvature correction $C_1$, satisfying the exact two-sided generalized Ward–Takahashi identities [[21]](#ref-21)

\[
 V_\delta K(p_{\mathrm{in}})+H(p_{\mathrm{out}})K_1+C_1=0,
 \quad
 K(-p_{\mathrm{out}})^TV_\delta+K_1^TH(p_{\mathrm{in}})+C_1^T=0. \tag{7.7}
\]

For outgoing momentum $K$ and incoming momentum $K+\delta$ ($p_{\mathrm{out}}=(z,-iK)$), one **first solves the rightward Ward identity for the Noether compensation source $I_{1,\delta}$, and only then solves for the perturbed bosonic propagator $G_{z,\delta}(K)$**:

\[
 K(-p_{\mathrm{out}})^TI_{1,\delta}
 =-K_1^TI_0-C_1^TF_z(K+\delta),\qquad
 H(p_{\mathrm{out}})G_{z,\delta}(K)
 =I_{1,\delta}-V_\delta F_z(K+\delta). \tag{7.8}
\]

Appendix C.2, Eq. (C.3), proves that the $9\times 9$ symmetric minor of the gauge-fixed rows $\det K_{\mathrm{removed}}=\frac{3\sqrt2}{1000}(18-25k_x^2)$ is strictly nonzero across $|k|\le B$: setting the other $280$ entries of $I_{1,\delta}$ to zero uniquely determines $I_{1,\delta}$, after which solving on the reduced slice and restoring auxiliary graphs yields $G_{z,\delta}(K)$ (with incoming $U,I_0,D$ evaluated strictly at $K+\delta$, and inhomogeneous auxiliary particular terms supported solely on the $72$ gauge auxiliary coordinates).

### 7.3 Zero-Counterterm Contour Locking of the Instantaneous $(\delta'_0,\delta_0)$ Terms

Asymptotic degree analysis of $G_{\lambda,\delta}(k)$ as $|\lambda|\to\infty$ shows that the 103-field determinant has constant $\lambda$-degree $126$, while sparse cofactor bounds restrict all nine external-source write-backs in 289 fields to at most linear $O(\lambda)$ growth. Hence its inverse Laplace distribution splits cleanly as

\[
 \mathcal G_{k,\delta}
 =P_1(k,\delta)\delta'_0+P_0(k,\delta)\delta_0
 +\mathbf1_{t\ge0}K_1(t;k,\delta). \tag{7.9}
\]

Across $|k|\le B$, paired incoming frames, and $\max_i|\delta_i|\le 1/200\,000$, all poles lie strictly inside the circle $|\lambda|=\Gamma=5c$ with uniform boundary bound $\|G_\lambda\|_\infty\le C$. Integrating around the single contour $|\lambda|=5c$ extracts all three components without ambiguity:

\[
 P_1=\frac1{2\pi i}\oint\frac{G_\lambda}{\lambda^2}\,d\lambda,\quad
 P_0=\frac1{2\pi i}\oint\frac{G_\lambda}{\lambda}\,d\lambda,\quad
 K_1(t)=\frac1{2\pi i}\oint e^{\lambda t}G_\lambda\,d\lambda, \tag{7.10}
\]

with $\|\partial_t^mK_1(t)\|_\infty\le5^{m+1}Ce^{75t/16}$; since $\operatorname{Re}z=6c>5c>75/16$, every half-line Laplace integral converges absolutely. High-frequency coefficients of the mother equation simultaneously enforce

\[
 H_2P_1=0,\quad H_2P_0+H_1P_1=0,\quad
 H_2K_1(0)+H_1P_0+H_0P_1=0, \tag{7.11}
\]

together with $H_2K_1'(0)+H_1K_1(0)+H_0P_0=I_1(\infty)$, canceling every singular $\delta$ residual in the zero-past distributional equation. In contrast to Epstein–Glaser causal splitting where singular degree $\omega\ge 0$ leaves free polynomial subtraction constants [[5]](#ref-5), (7.10)–(7.11) lock $(P_1,P_0)$ uniquely from the rational mother contour with zero free counterterms.

Convolving $\mathcal G_{k,\delta}$ with the half-line quantum current $j_+=\mathbf1_{t\ge 0}j$ gives

\[
 \mathcal G*j_+=P_1\delta_0j(0)
 +\mathbf1_+[P_1j'+P_0j+K_1*j]. \tag{7.12}
\]

Under Laplace transformation, the initial-value term $-P_1j(0)$ from $\widehat{j'}=z\widehat j-j(0)$ cancels the boundary impulse $+P_1\delta_0j(0)$ in (7.12), recovering $G_z\widehat j$ identically. Because left and right current legs carry independent time variables and variational readout derivatives act via distributional integration by parts, no ill-defined product of coincident singular distributions ever occurs, and uniform exponential, momentum-derivative, and compact-ball bounds justify interchanging time and momentum integrals.

### 7.4 General Two-Window Formula for the Complete Five-Channel Polarization Amplitude

Write $d\mu(k)=(2\pi)^{-3}d^3k$, incoming ball indicator $w_B(k)=\mathbf1_{|k|\le B}$, and observing ball indicator $w_R$. Bosonic fields and readout currents use negative spatial phase: at total output momentum $p$, the two bosonic legs carry momenta $k$ and $k-p$, while quantum current probes retain $M_k$. Set

\[
 L_z(k)=(\bar z,+ik),\quad R_w(l)=(w,-il),\quad
 r_b=(-\bar z-w,-ip). \tag{7.13}
\]

Let $Q_b(L,R)$ be the mother quadratic-fluctuation readout matrix (incorporating second-order constitutive $B_g$ write-back) and $Q'_{b,\delta}$ its first variation with respect to the external gauge field (satisfying four-momentum conservation $L+R+(0,i\delta)+r_b=0$ for $\delta=\sigma d,l=k-p+\delta$). Writing $\langle Fj,QGj'\rangle$ for the joint 289-field $Q$-contraction and $\mathcal H_{12}$ inner product (conjugate-linear in the first slot), the five polarization channel kernels for projected Laplace vectors $j,\zeta$ of §6.3 are

\[
\begin{aligned}
 \Phi_{R\sigma}(k)&=\langle F_z(k)j_z(k),
 Q_b(L_z(k),R_w(k-p))G_{w,\delta}(k-p)j_w(l)\rangle,\\
 \Phi_{L\sigma}(k)&=\langle G_{z,-\delta}(k+\delta)j_z(k),
 Q_b(L_z(k+\delta),R_w(l))F_w(l)j_w(l)\rangle,\\
 \Phi_{C\sigma}(k)&=\langle F_z(k)j_z(k),
 Q'_{b,\delta}(L_z(k),R_w(l))F_w(l)j_w(l)\rangle,\\
 \Phi_{NZ}(k)&=\langle F_z(k)\zeta_{z,d}(k),
 Q_b(L_z(k),R_w(k-p))F_w(k-p)j_w(k-p)\rangle,\\
 \Phi_{ZN}(k)&=\langle F_z(k)j_z(k),
 Q_b(L_z(k),R_w(k-p))F_w(k-p)\zeta_{w,d}(k-p)\rangle, \tag{7.14}
\end{aligned}
\]

each multiplied by the exact incoming and observing window indicators dictated by its physical legs:

| Polarization channel | Incoming window factor | Observing window factor |
|---|---|---|
| \(\Phi_{R\sigma}\) (right bosonic propagation) | \(w_B(k)w_B(l)\) | \(w_R(k)w_R(k-p)\) |
| \(\Phi_{L\sigma}\) (left bosonic propagation) | \(w_B(k)w_B(l)\) | \(w_R(k+\delta)w_R(l)\) |
| \(\Phi_{C\sigma}\) (central readout contact) | \(w_B(k)w_B(l)\) | \(w_R(k)w_R(l)\) |
| \(\Phi_{NZ},\Phi_{ZN}\) (left/right quantum source) | \(w_B(k)w_B(k-p)\) | \(w_R(k)w_R(k-p)\) |

Denoting by $T_\bullet$ each kernel in (7.14) multiplied by both window factors in its row, the complete first-order polarization amplitude is

\[
 \mathcal P_b(p,d;z,w)=\frac14\sum_{\sigma=\pm1}\int
 (T_{R\sigma}+T_{L\sigma}+T_{C\sigma})\,d\mu
 +\frac12\int(T_{NZ}+T_{ZN})\,d\mu. \tag{7.15}
\]

Every prefactor is accounted for: the quadratic fluctuation current supplies $1/2$; in the three bosonic/contact channels, the two cosine branches $\sigma=\pm 1$ supply another $1/2$ to give $1/4$; in $\Phi_{NZ},\Phi_{ZN}$, the cosine half-amplitude is already absorbed inside $\zeta$ in (6.13), leaving $1/2$. Taking the real part of (7.15) at equal parameters produces $\mathcal R_\alpha$ of Definition 1.1.

**Proof.** Applying the five-factor Leibniz product rule at $\varepsilon=0$ to $\frac12\langle F_\varepsilon j_\varepsilon,Q_\varepsilon F_\varepsilon j_\varepsilon\rangle$, substituting (7.8) and (6.13), and relabeling $\sigma\mapsto-\sigma$ with a momentum shift on the left propagation variation yields the distinct window products above and (7.15). Uniform rational bounds on compact balls, $L^2$ Cauchy–Schwarz on the quantum legs, (7.12), and Proposition 6.1 establish equality with the real-time double integral. □

### 7.5 Specialization to the Present Protocol ($p=0,R=B$): Moving Lens vs. Fixed Ball

Specialize henceforth to $p=0,R=B,z=w=6c(1-i)$, where total readout decay is $-\bar z-z=-12c$ and the static cosine probe has zero explicit time derivative.

By Hermitian symmetry of $Q_{\mathrm{native}}$ and momentum relabeling, the left and right bosonic propagation legs combine into

\[
 \mathscr R_\alpha(y,d)=F_z(y-d)^\dagger Q_{\mathrm{native}}(y-d)
 G_{z,d}(y-d;y)\,\mathcal N_0^\alpha(y-d,y;z,z), \tag{7.16}
\]

\[
 I_G^\alpha(d)=\frac12\sum_{\sigma=\pm1}\operatorname{Re}
 \int_{|y|\le B,\ |y-\sigma d|\le B}\mathscr R_\alpha(y,\sigma d)\,d\mu(y). \tag{7.17}
\]

In (7.16), the incoming momentum $y$ locks the incoming light root $U(|y|^2/2)$, denominator $D$, and projected source $I_0(y)$: differentiating in $d$ acts solely on the outgoing side and $G_{z,d}(y-d;y)$, never mistaking the incoming root for an outgoing one.

Conversely, at $p=0,R=B$ both quantum-source channels integrate over the unshifted ball $|k|\le B$. Their bosonic contraction weight

\[
 C(k)=\frac12F_z(k)^\dagger Q_{\mathrm{native}}(k)F_z(k)
 =\frac{P_C(k,U,T)}{D(U,T)^2c^4(U^2+5184)} \tag{7.18}
\]

is given by a $685$-term real polynomial $P_C$ (including full auxiliary write-back) with $C(0)=\sqrt{15}/25000$. Across $|k|\le B$, rigorous enclosures lock both $C(k)$ and the window measure inside narrow positive bands:

\[
 \begin{gathered}
 0.0001549193308186325975<C(k)<0.0001549193368779607818,\\
 \mu(B)=\frac{B^3}{6\pi^2}\in[2.6685289152662552116,2.6685289152662552117]10^{-16}.
 \end{gathered} \tag{7.19}
\]

Because the quantum-source directional second derivative satisfies $H_n(k)\in[-0.015140743694,-0.012928791594]<0$ across $|k|\le B$, the combined `raw` quantum-source Hessian is strictly negative in every unit direction $n$:

\[
 S_n^{\mathrm{raw}}\in[-6.25928534,-5.34484924]10^{-22}\quad(|n|=1). \tag{7.20}
\]

Halving (7.20) contributes only about $-3\times 10^{-22}$ to $\mathsf K_{\mathrm{raw}}$; the $O(10^{-20})$ scale and the positive second-axis eigenvalue come decisively from the moving-lens propagation integral (7.17).

## 8 Sharp Two-Ball Window Asymptotics: Covariogram $|d|$ Cusp and Dual Spherical Boundary Fluxes

The integration domain $B_B\cap(B_B+\sigma d)$ in (7.17) has a sharp spherical boundary. By the Matheron–Galerne set-covariogram theorem in integral geometry [[22]](#ref-22), shifting the indicator overlap of any bounded set of finite perimeter produces a non-analytic $|s|$ cusp at the origin proportional to directional perimeter variation. Here we derive the exact second-order chord-slice expansion for smooth kernels on a moving two-ball intersection, separate first-order and zeroth-order spherical boundary fluxes, and exhibit affine and counter-phased negative controls showing how omitting either boundary flux or complex cross-Gram imaginary parts falsifies curvature.

### 8.1 Two-Ball Intersection Volume Cusp and Chord-Endpoint Quadratic Expansion

For two balls of radius $B$ in $\mathbb R^3$ at center separation $s\in[0,2B]$, solid-of-revolution slicing yields

\[
 \operatorname{Vol}(B_B\cap(B_B+sn))
 =\frac{4\pi B^3}{3}-\pi B^2s+\frac{\pi s^3}{12}. \tag{8.1}
\]

Extending to $s\in\mathbb R$ exhibits the $-\pi B^2|s|$ cusp: even on the constant integrand $1$, the sharp-window integral fails to be twice differentiable at $s=0$.

Centering coordinates at the midpoint between the two balls with half-shift $h_0s$ ($s\ge 0$) and writing $\Psi_j=(\partial_s+a\partial_n)^j\Phi|_{s=0}$ ($a$ being the midpoint offset parameter), the first three $s$-expansion coefficients of the moving-lens integral are

\[
 I_0=\int_B\Psi_0,\quad
 I_1=\int_B\Psi_1-h_0\int_{\partial B}|n\cdot\nu|\Psi_0, \tag{8.2}
\]

\[
 I_2=\frac12\int_B\Psi_2
 +\frac{h_0^2}{2}\int_{\partial B}(n\cdot\nu)\partial_n\Psi_0
 -h_0\int_{\partial B}|n\cdot\nu|\Psi_1. \tag{8.3}
\]

**Proof.** Decompose $B_B$ into chords parallel to $n$: at transverse coordinate $y\perp n$ ($|y|<B$), the unshifted half-chord length is $h(y)=\sqrt{B^2-|y|^2}$. On the interior disk $h(y)\ge h_0s$, the overlap interval shrinks to $[-h(y)+h_0s,\,h(y)-h_0s]$; expanding both the integrand in $s$ and the endpoints in $h_0s$, then converting $dy_\perp=|n\cdot\nu|\,dS$, produces (8.2)–(8.3). On the equatorial rim $h(y)<h_0s$, the projected annulus has area $\pi B^2-\pi(B^2-h_0^2s^2)=\pi h_0^2s^2$ and chord length at most $2h_0s$, bounding its total volume by $\frac{4\pi}{3}h_0^3s^3=O(s^3)$, which contributes zero at orders $s$ and $s^2$; uniform continuity of second derivatives on the closed ball yields the $o(s^2)$ remainder. □

### 8.2 Bulk Integral, First Spherical Flux, and Zeroth Spherical Flux in Paired Incoming Frames

In (7.17), parameterize incoming rays by $y=r\nu$, $d=sn$, and $u=n\cdot\nu$ ($\nu\in S^2$). Along ray $\nu$, the exact radial upper limit of the two-ball lens is

\[
 r_{\max,\sigma}(s)=\min\{B,\ \sigma su+\sqrt{B^2-s^2(1-u^2)}\}. \tag{8.4}
\]

Averaging $\int_0^{r_{\max,\sigma}(s)}r^2\operatorname{Re}\mathscr R_\alpha(r\nu,\sigma sn)\,dr$ over $\sigma=\pm 1$ and expanding to order $s^2$ (the active moving cap occurring whenever $\sigma u<0$, while $\sigma u>0$ stays pinned at $B$) decomposes the propagation curvature into one bulk integral and two spherical boundary fluxes (Figure 3):

\[
\begin{split}
 K_G^\alpha(n)={}&\underbrace{\frac12\int_B\operatorname{Re}\mathscr R_{dd}}_{\text{bulk integral (body)}}
 +\underbrace{\frac12\int_{\partial B}u\operatorname{Re}\mathscr R_d}_{\text{first spherical flux}}\\
 &+\underbrace{\frac14\int_{\partial B}
 \left[u^2\partial_r\operatorname{Re}\mathscr R_0
 +\frac{3u^2-1}{B}\operatorname{Re}\mathscr R_0\right]}_{\text{zeroth spherical flux}}. \tag{8.5}
\end{split}
\]

Both volume and surface measures retain $(2\pi)^{-3}$; subscript $d$ differentiates in external momentum along $n$ at fixed incoming $y$, and $\partial_r$ differentiates radially at fixed ray direction $\nu$—requiring only Borel measurability and uniform boundedness of the paired incoming frame across angular seams (avoiding any hairy-ball obstruction on $S^2$).

![Figure 3: Sharp two-ball lens geometry, linear cap loss, and dual spherical boundary fluxes.](figures/fig02-lens-flux-v2-en.svg)

**Figure 3. Sharp two-ball lens geometry, linear cap loss, and dual spherical boundary fluxes.** Left: the shaded lens $|y|\le B\cap|y-d|\le B$ is the active integration domain whose vermilion spherical arcs carry the first and zeroth boundary fluxes; the pale crescent clipped outside the observing ball produces the $-\pi B^2|s|$ linear cusp $a_\alpha(n)|s|$ in (1.3). Right: under fixed incoming ray frames, the quadratic curvature splits into the bulk integral, first spherical flux, and zeroth spherical flux, with the bottom strip recording exact cancellation between positive boundary flux and negative bulk gradient energy on an affine test field (proportions are schematic; exact integration uses (8.4) and $(2\pi)^{-3}$).

### 8.3 Negative Control I: Chord-Endpoint Cancellation Never Eliminates Spherical Flux

To distinguish chord-endpoint symmetry from disappearance of boundary flux, consider the Hermitian autocorrelation functional

\[
 L(s)=\frac1{2(2\pi)^3}\int B_Q(a(k),a(k+sn))
 \mathbf1_{B_B}(k)\mathbf1_{B_B}(k+sn)\,d^3k,\qquad
 B_Q(a,b)=\operatorname{Re}(a^\dagger Qb). \tag{8.6}
\]

Along each 1D chord, $c(t)=B_Q(a,a)$ and $e(t)=B_Q(a,a')$ obey $c'=2e$, canceling $+s^2c'(h)/2$ against $-s^2e(h)$ at the upper chord endpoint and leaving

\[
 K(n)=\frac1{4(2\pi)^3}\int_BB_Q(a,\partial_n^2a)
 =\frac1{4(2\pi)^3}\left[
 \int_{\partial B}(n\cdot\nu)B_Q(a,\partial_na)-\int_BB_Q(\partial_na,\partial_na)\right]. \tag{8.7}
\]

Crucially, the spherical flux $\int_{\partial B}(n\cdot\nu)B_Q(a,\partial_na)$ on the right-hand side of (8.7) **does not vanish**. Choosing $b=e_9+e_{259}\in\mathbb R^{289}$ ($b^TQb=4$) and evaluating (8.7) along $n=e_3$ on four closed-form test fields gives:

| 3D test field (\(n=e_3\)) | Exact quadratic coefficient \(K(e_3)\) |
|---|---:|
| \(a=b\) (constant field) | \(0\) |
| \(a=[1+(2+i)k_3]b\) (complex affine field) | \(0\) |
| \(a=[1+(1+i)k_3+(2-i)k_3^2]b\) (quadratic field) | \(B^3(B^2+2)/(3\pi^2)\) |
| \(a=e^{i\kappa k_3}b\) (plane-wave field) | \(-\kappa^2B^3/(6\pi^2)\) |

As verified in Example 1.1(b), the zero in row two arises from exact cancellation between $+20\operatorname{Vol}(B_B)$ on $\partial B$ and $-20\operatorname{Vol}(B_B)$ inside $B$: omitting the boundary flux misclassifies an affine field as strictly negatively curved. Moreover, because the perturbed propagation kernel (7.16) is asymmetric between its left and right legs, $c'=2e$ no longer holds (e.g., $\Phi=s$ generates a genuine quadratic surface contribution $-2\pi B^2h_0$), making all three terms of (8.5) mandatory in Section 10.

### 8.4 Negative Control II: Dropping One Cross-Gram Imaginary Part Reverses the Verdict

Factor a field-state product as $a=WJ$ with bosonic column $W$ and quantum vector $J$. Writing $\alpha=W^\dagger QW\in\mathbb R$, $\beta_n=W^\dagger QW_n$, $\delta_n=W^\dagger QW_{nn}$ and $\nu=\langle J,J\rangle,\theta_n=\langle J,J_n\rangle,\eta_n=\langle J,J_{nn}\rangle$, the directional second derivative expands as

\[
 B_Q(a,a_{nn})=\operatorname{Re}\delta_n\,\nu
 +2\operatorname{Re}(\beta_n\theta_n)+\alpha\operatorname{Re}\eta_n, \tag{8.8}
\]

whose middle cross term equals $2(\operatorname{Re}\beta_n\operatorname{Re}\theta_n-\operatorname{Im}\beta_n\operatorname{Im}\theta_n)$. On the counter-phased test pair $W=e^{2ik_3}b,J=e^{-2ik_3}$, the product $a(k)=WJ\equiv b$ is constant and $B_Q(a,a_{nn})=0$ identically; discarding $\operatorname{Im}\theta_n$ prematurely corrupts (8.8) from $0$ to $-32$. Accordingly, §§9–10 retain all 58 complex two-probe Gram weights intact until taking the real part at the end of spherical integration.

## 9 Global Implicit Dispersion Derivatives, Complex Two-Probe Gram Moments, and Anti-Wrapping Recursive Enclosures

Turning (8.5) into a rigorous dyadic rational enclosure with zero truncation gaps requires four analytic ingredients: exact higher derivatives of the implicit sextic root $U(T)$, closed-form evaluation of all 58 complex two-probe Gram moments of the filtered ball state, high-order suppression bounds on the central contact channel, and anti-wrapping recursive enclosures [[26]](#ref-26) for 11,760 source-contracted power-series coefficients.

### 9.1 First and Second Spatial Derivatives of the Implicit Sextic Dispersion Root

In (7.3), $U(T)$ is defined implicitly by $\widehat F(U(T),T)=0$ rather than approximated by its origin tangent $\frac{125}{162}T$. Writing $f=\widehat F/c_F$, the first and second $T$-derivatives $S=U'(T)$ and $C=U''(T)$ satisfy

\[
 S=-\frac{f_T}{f_U},\qquad
 C=-\frac{f_{TT}+2f_{UT}S+f_{UU}S^2}{f_U},\qquad
 S(0)=\frac{125}{162},\quad C(0)=-\frac{76325}{78732}. \tag{9.1}
\]

With total radial differential operator $\mathcal D=S\partial_U+\partial_T$, any polynomial entry $g(k,U,T)$ restricted to the implicit root manifold has exact Cartesian momentum derivatives

\[
 \partial_ag=g_a+k_a\mathcal Dg, \tag{9.2}
\]

\[
 \partial_a\partial_bg=g_{ab}+k_a\mathcal Dg_b+k_b\mathcal Dg_a
 +\delta_{ab}\mathcal Dg
 +k_ak_b(S^2g_{UU}+2Sg_{UT}+g_{TT}+Cg_U), \tag{9.3}
\]

($g_a,g_{ab}$ denoting partial derivatives in explicit $k_a$). Applying (9.2)–(9.3) and the quotient rule to numerators and $D(U,T)$ yields exact global derivatives of $F_z$ and $G_{z,d}$.

Cross-checking on the static residue seed $W(k)=-\sum_{\sigma=\pm1}\ell_\sigma(-k)$ (87 nonzero rows contracting against 188 nonzero entries of $Q$ across 56 active pairs) in the eight-element algebraic basis $(1,\sqrt2,\sqrt{15},\sqrt{30},i,i\sqrt2,i\sqrt{15},i\sqrt{30})$ gives exact origin values

\[
 \alpha_0=\frac{1944\sqrt{15}}{390625},\quad
 \beta_a(0)=0,\quad
 \delta_{ab}(0)=\frac{144\sqrt{15}}{78125}\delta_{ab}. \tag{9.4}
\]

Canceling the constant term of $-f_T-\frac{125}{162}D$ algebraically prior to interval evaluation over $0\le T\le\epsilon_B^2$, $0\le U\le\frac{1331}{1620}\epsilon_B^2$ locks the slope drift and second derivative within

\[
 |S-125/162|\le3.09374932\,10^{-10},\qquad |C|\le11.211290904, \tag{9.5}
\]

bounding seed deviations by $|\alpha-\alpha_0|\le2.54913989\,10^{-10}$, $|\beta_n|\le3.169153940416\,10^{-6}$, and $|\delta_n-144\sqrt{15}/78125|\le6.14562710075\,10^{-7}$ (while the full five-channel proof evaluates the dynamical columns (7.3) and (7.8) directly). Quotient-ring and Sturm-isolation checks at $q_{\mathrm{ax}}=1/262144$ confirm that artificially freezing $S(0)\mapsto 1$ shifts $\delta_{11}(0)$ alone by the exact algebraic error

\[
 -\frac{10755974\sqrt{15}}{4150390625}\ne0. \tag{9.6}
\]

### 9.2 Closed-Form Evaluation of All 58 Complex Two-Probe Quantum Gram Moments

At fixed output momentum $p$, the incoming momentum of the current probe is $p-k$. Writing $G(k,p)$ for the Sylvester kernel (6.14), probe-momentum derivatives of $G(k,p)\widehat\psi(p-k)$ combine kernel and wave-packet derivatives:

\[
 g_i=G_i\widehat\psi-G_0\partial_i\widehat\psi,\quad
 g_{ij}=G_{ij}\widehat\psi-G_i\partial_j\widehat\psi-G_j\partial_i\widehat\psi
 +G_0\partial_{ij}\widehat\psi; \tag{9.7}
\]

differentiating only the kernel or only the wave packet drops genuine cross terms.

Setting $p=\sqrt2v,x=v\cdot v\ge 0$, exact Sylvester elimination on each chiral block factors the radial denominator into four complex poles strictly off the positive real axis:

\[
 D_x=(x-18i)
 \left(x-\frac{83520+967032i}{48841}\right)
 \left(x+\frac9{25}-18i\right)
 \left(x+\frac{61920-530712i}{32761}\right). \tag{9.8}
\]

Summing both chiral blocks on $\mathcal H_{12}$ and integrating over $\widehat p\in S^2$ reduces all quantum inputs to $1$ normalization weight, $20$ complex mean weights, and $58$ two-probe complex Gram weights (including $6$ left-leg, $6$ right-leg, and all $9$ mixed left-right second-order components). Rather than discretizing $\mathbb R^3$ on a numerical grid, **all unbounded momentum integrals are evaluated analytically**: Appendix D.1 reduces radial integrands via spherical-Bessel identities and integration by parts to rational weights times $b(r)^2$, applies partial fractions across all $11$ complex poles (multiplicity $\le 3$) into closed-form moments (6.5) and their $\kappa$-derivatives, and encloses series at order $130$ with explicit factorial tails.

Setting $k=l$ provides a sharp symmetry check via the synchronous combination $L_{ij}+R_{ij}+2M_{ij}$: in the `connected` sector, the unperturbed current recovers exact rotational isotropy

\[
 (L+R+2M)_{N_0}=0.1622411553760404839\,I_3, \tag{9.9}
\]

whereas the $dx^1S_{01}$-perturbed source breaks full isotropy to $0.0255929216787139673$ along $e_1$ and $0.0120264349193238322$ along $e_2,e_3$—a pattern invisible to the right-leg Hessian alone.

### 9.3 $O(B^5)$ Suppression of Central Readout Contact Curvature vs. Nonzero $|d|$ Cusp

In midpoint momentum coordinates, the central readout contact integrand in (7.14) takes the form

\[
 \mathcal C(k,s)=\operatorname{Re}
 \langle A(k-sn/2),(Q_0+sQ_n)A(k+sn/2)\rangle,
 \quad Q_0^\dagger=Q_0,\quad Q_n^\dagger=-Q_n, \tag{9.10}
\]

where $A$ tensors the coframe propagation column with the quantum current ($97$ nonzero coframe contact entries; $4$ scalar contact entries vanish identically on the light-branch column). Applying (8.3) and skew-Hermitian boundary cancellation reduces the quadratic contact curvature to a pure volume integral:

\[
 K_C(n)=\int_B\left[\frac14\operatorname{Re}\langle A,Q_0A_{nn}\rangle
 +\frac12\operatorname{Re}\langle A,Q_nA_n\rangle\right]d\mu. \tag{9.11}
\]

Because the coframe column vanishes at the origin, $F_e(0)=0$, with odd linear leading term, parity over $B_B$ annihilates all $O(B^3)$ contributions and pushes $K_C$ to $O(B^5)$, uniformly bounded by

\[
 \|\mathsf K_C\|\le3.686515414428545\,10^{-26}, \tag{9.12}
\]

more than five orders of magnitude below the $10^{-20}$ propagation curvature. Yet its linear cusp $a_C(n)|s|$ is nonzero: from the origin derivative matrix

\[
 (DF_e(0))^\dagger Q_0DF_e(0)
 =-\tau\operatorname{diag}(2,1,1),\qquad
 \tau=\frac{32041\sqrt{30}}{31492800}, \tag{9.13}
\]

the contact channel contributes a positive $\sim +10^{-23}$ cusp that combines with the negative propagation-leg cusp in $[-7.470844,-7.370030]\times 10^{-18}$ to leave a genuine $|d|$ cusp in the total five-channel response.

### 9.4 Eliminating Interval Wrapping Inflation: Source-Contracted Recursive Enclosures Prior to Readout

Because interval arithmetic is only subdistributive, $[a]\cdot([b]+[c])\subsetneq[a]\cdot[b]+[a]\cdot[c]$, bounding a $112\times 112$ matrix inverse, external source, and readout separately in norm before multiplying inflates interval widths by orders of magnitude via the wrapping effect [[25]](#ref-25), [[26]](#ref-26). Instead, for $A(q,d)Y(q,d)=f(q,d)$ with $P_0=A(0,0)^{-1}$, we generate the multi-index power-series coefficients of the **single source-contracted solution** $Y$ directly by recursion:

\[
 Y_{n,\alpha}=P_0f_{n,\alpha}
 -\sum_{(j,\beta)\ne(0,0)}{\alpha\choose\beta}
 P_0A_{j,\beta}Y_{n-j,\alpha-\beta}. \tag{9.14}
\]

Preserving exact noncommutative matrix order throughout, inverse series are kept to order $40$ and $Y$ to order $36$, enclosing all 11,760 complex coefficients (2,231 nonzero) inside outward-rounded $256$-bit dyadic rational complex rectangles (Appendix D.2, Eq. (D.4)).

To bound the infinite tail beyond order $36$, choose the complex circle $|q|=\rho_*=1/8192\approx 1.22\times 10^{-4}$ strictly enclosing $\epsilon_B\approx 1.77\times 10^{-5}$. On this polydisk, the reduced sextic satisfies

\[
 \bar F(Tr,T)=T\left(r-\frac{125}{162}+TP(r,T)\right),\quad
 \rho_*^2\sup|P|<\frac1{20},\quad \rho_*^2\sup|P_r|<1, \tag{9.15}
\]

so Banach contraction guarantees a unique holomorphic root branch around $125/162$ agreeing on the real axis with Sturm-isolated $U(T)$, while Neumann bounds certify holomorphic invertibility of $A(q,d)$. Applying Cauchy's tail formula (D.5) directly to the solved column $Y$ on $|q|=\rho_*$ bounds normalized axial derivatives of orders $0\ldots 4$ below $(0.001669,0.190606,0.074193,0.141750,0.357796)$, which then contract with $F^\dagger QED$, the gauge auxiliary particular term, the nine-direction dyadic $\ell^1$ factor $9$, and $2^{-1/2}$ without wrapping blow-up.

## 10 Paired-Frame Spherical Beta Integration and Fourth-Moment Remainder Closure

### 10.1 Finite Spatial-Rotation Covariance and Paired Northern-Hemisphere Radial Measure

The three total spatial angular-momentum generators of the mother action act simultaneously on all 289 fields, the independent dual, spatial momenta, and gauge indices. The background readout matrix obeys the infinitesimal covariance equation

\[
 J^TQ_a+Q_aJ+D_{(S^TL,S^TR)}Q_a+Q_{Ja}=0, \tag{10.1}
\]

with $DB_a+B_{Ja}=JB_a$ on the constitutive auxiliary map; integrating along great circles from the identity establishes exact finite-rotation covariance of the full cubic current at independent four-momenta.

On incoming directions we employ the two-step Euler paired frame

\[
 L=L_z(t_z)L_y(t_y),\quad R=R_y(t_y)R_z(t_z),\quad
 L^{-1}(dx^1S_{01})=\sum_{ij}v_iv_jE_{ij},\quad v=Re_1,\quad m=Rn, \tag{10.2}
\]

where $E_{ij}$ ranges over the nine spatial gauge basis elements $dx^i\otimes(g_1,g_0,g_6-g_7)_j$ (unhalved $g_6-g_7$ making the three-generator pairing Gram equal $2I_3$). Spherical integration pairs $\pm r$ across $r\in[-B,B]$ on a single northern-hemisphere frame (multiplying the northern-hemisphere integral by $2$): with $t=\cos\theta\in[0,1]$ and $s_\theta=\sqrt{1-t^2}$,

\[
 R=\begin{pmatrix}
 t\cos\varphi&t\sin\varphi&-s_\theta\\
 -\sin\varphi&\cos\varphi&0\\
 s_\theta\cos\varphi&s_\theta\sin\varphi&t
 \end{pmatrix}. \tag{10.3}
\]

Because $\{r=0\}$ has Lebesgue measure zero, the bounded measurable frame (10.3) carries the exact whole-ball integral free of polar coordinate singularities.

### 10.2 Exact Beta Cancellation Across Bulk and Boundary Fluxes and the 77-Digit Leading Integers

Let $D(r,d)$ denote the bosonic scalar contraction in (7.16), with origin Gram values $g=\mathcal N_0(0,0)$, left-leg second derivative $\ell=\ell_R+i\ell_I$, and mixed derivative $m_0$. Contracting the nine-direction dyadic tensor yields $15$ second-order radial/external derivatives, vanishing first jets along the rank-one probe, and exact origin constant

\[
 C_*=(366033271/1585732915875000
 +15362367173\,i/19028794990500000)\sqrt{30}. \tag{10.4}
\]

With $u=n\cdot\nu$, the three second derivatives of the product kernel read

\[
 \Phi_{dd}=D_{dd}g+C_*\ell|n|^2,\quad
 \Phi_{rd}=D_{rd}g-C_*(\ell+m_0)u,\quad
 \Phi_{rr}=D_{rr}g+C_*(2\ell_R+2m_0), \tag{10.5}
\]

producing at leading order $B^3$ in (8.5) the three angular integrands

\[
 \frac16\operatorname{Re}\Phi_{dd},\qquad
 \frac u2\operatorname{Re}\Phi_{rd},\qquad
 \frac{5u^2-|n|^2}{8}\operatorname{Re}\Phi_{rr}. \tag{10.6}
\]

Symbolic integration of every angular monomial from (10.3) via the closed-form Gamma/Beta identities (E.1)–(E.2) (independently confirmed via finite Laurent–Fourier trigonometric words) reveals a striking pairwise cancellation: **the left-leg imaginary part $\ell_I$ cancels with exact opposite signs between the bulk integral and the first spherical flux** (the zeroth flux containing no $\ell_I$), while **the mixed moment $m_0$ cancels with exact opposite signs between the first spherical flux and the zeroth spherical flux** (the bulk integral containing no $m_0$), so only after summing all three channels of (8.5) do both $\ell_I$ and $m_0$ vanish identically in every direction, alongside all leading off-diagonal monomials.

Five exact multi-digit integers lock the resulting $O(B^3)$ diagonal tensor:

\[
 A=22167194028817237306747382536724582082089691131746230098538055829760,
\]
\[
 D_*=144049402099638285990225019962670247878188911404813573223075013222960000000,
\]
\[
\begin{aligned}
 b_1&=-2320339522879271170011217524973217861256927053064666079052657705109338,\\
 b_2&=3921375100572892251186223581547532771093087034683851044524183837417062,\\
 b_3&=-3012102837963769108469432161130193495577865811561102038217309537582938,
\end{aligned}
\]

giving the exact leading two-leg propagation curvature tensor

\[
 \mathsf K_{G,0}^\alpha
 =\frac{B^3\sqrt{30}}{8\pi^2D_*}
 \operatorname{diag}(A\ell_R^\alpha+b_1g^\alpha,
 A\ell_R^\alpha+b_2g^\alpha,
 A\ell_R^\alpha+b_3g^\alpha). \tag{10.7}
\]

Evaluated on `raw` $(g^{\mathrm{raw}},\ell_R^{\mathrm{raw}})\simeq(0.73590110,-0.22322738)$, the isotropic term $A\ell_R^{\mathrm{raw}}$ contributes a slight negative shift $-0.003766\times 10^{-20}$ on all three axes (since $\ell_R^{\mathrm{raw}}<0$), whereas $b_2g^{\mathrm{raw}}\simeq+2.196040\times 10^{-20}$ single-handedly drives the strictly positive peak along $e_2$, centering (10.7) at $-1.3031969814$, $+2.1922740186$, and $-1.6905967190$ (in units of $10^{-20}$). To make the geometric and physical origin of the $(2,1,0)$ signature transparent, the table below decomposes the exact rational spherical integrals of (8.5) channel by channel on `raw` (units of $10^{-20}$):

| Channel of Eq. (8.5) (`raw` leading order $O(B^3)$) | Axis \(e_1\) | Axis \(e_2\) | Axis \(e_3\) | Geometric & symmetry mechanism |
|---|---:|---:|---:|---|
| Bulk integral (`body`, $g^{\mathrm{raw}}$ part) | \(-1.436641\) | \(-0.184498\) | \(-0.184498\) | All-negative and \(e_2=e_3\) degenerate (spurious \((3,0,0)\)) |
| First spherical flux (`first flux`, $g^{\mathrm{raw}}$ part) | \(-139.197532\) | \(-41.096041\) | \(-32.036010\) | Splits \(e_2\leftrightarrow e_3\) and cancels \(\ell_I\) against `body` |
| Zeroth spherical flux (`zeroth flux`, $g^{\mathrm{raw}}$ part) | \(+139.334741\) | \(+43.476580\) | \(+30.533677\) | Splits \(e_2\leftrightarrow e_3\) and cancels \(m_0\) against first flux |
| **Net spherical flux** (`first + zeroth`, $g^{\mathrm{raw}}$ part) | \(\mathbf{+0.137209}\) | \(\mathbf{+2.380538}\) | \(\mathbf{-1.502333}\) | **Injects $+2.38$ across zero on $e_2$ and deepens $e_3$ by $-1.50$** |
| Three-channel $b_i g^{\mathrm{raw}}$ sum | \(-1.299431\) | \(+2.196040\) | \(-1.686831\) | Locks the whole-ball $g^{\mathrm{raw}}$ sign pattern to \((-,+,-)\) |
| Isotropic $A\ell_R^{\mathrm{raw}}$ shift (three-channel sum) | \(-0.003766\) | \(-0.003766\) | \(-0.003766\) | Uniform small negative shift from \(\ell_R^{\mathrm{raw}}<0\) |
| **Leading propagation total \(\mathsf K_{G,0}^{\mathrm{raw}}\) (Eq. 10.7)** | \(\mathbf{-1.303197}\) | \(\mathbf{+2.192274}\) | \(\mathbf{-1.690597}\) | **Two minuses, one plus; dropping either flux destroys the sign** |

Two physical insights emerge immediately from this breakdown. First, at $r=0$ the pure external second jet $D_{dd}$ contracts solely along the world probe $dx^1S_{01}$, preserving transverse $e_2\leftrightarrow e_3$ symmetry and staying strictly negative on all three axes; any smooth unbounded perturbation theory that omits sharp-window boundary fluxes would misclassify the tensor as all-negative $(3,0,0)$. Second, on $\partial B$ the radial jets $D_{rd},D_{rr}$ couple the probe $S_{01}=2\tau_1$ simultaneously to the non-Abelian background $A_j=a\tau_j$ (via $[\tau_1,\tau_2]=i\tau_3$), the chiral spin-connection torsion $\omega_{j,\cdot}=\sqrt2$, and the gauge-fixed slice minor $\det K_{\mathrm{removed}}=\frac{3\sqrt2}{1000}(18-25k_x^2)$ (Appendix C, Eq. (C.3)); integrated against the paired incoming frame (10.2)–(10.3), these chiral/non-Abelian radial terms split $e_2$ from $e_3$ and leave, after delicate cancellation between $O(10^2)$ first and zeroth fluxes, a net $+2.380538\times 10^{-20}$ boundary contribution that flips $e_2$ positive. The `connected` sector exhibits the exact same mechanism (bulk alone $(-1.4212,-0.1825,-0.1825)\times 10^{-20}$, net boundary flux $+2.3550\times 10^{-20}$ on $e_2$, total $\mathsf K_{G,0}^{\mathrm{conn}}\simeq(-1.289229,+2.168683,-1.672466)\times 10^{-20}$).

### 10.3 $O(B^5)$ Whole-Ball Remainder Theorem Under Fourth Position Moments

For $\nu\in S^2$, write $M_j(v)=\|X_\nu^jv\|_{L^2}$. The ball indicator and smooth filter (6.4) endow both $\psi$ and $H\psi$ with finite position moments up to order $4$. From $[H,X_\nu^j]=-ijh_\nu X_\nu^{j-1}$ and $\|h_\nu\|=N$, free unitary evolution obeys the polynomial moment bound

\[
 \|X_\nu^mU(t)v\|\le P_m(t;v)
 :=\sum_{j=0}^m{m\choose j}(N|t|)^{m-j}M_j(v), \tag{10.8}
\]

with mixed directional derivatives controlled uniformly via Hölder's inequality. Setting $\alpha_0=\sqrt2/N^2$, the $m$-th probe derivatives of the unperturbed and first-order currents obey

\[
 B_m(t,k)=\alpha_0[2P_m(t;H\psi)+N|k|P_m(t;\psi)
 +mN P_{m-1}(t;\psi)], \tag{10.9}
\]

\[
 C_m(t,k)=\alpha_0N[2P_m(t;\psi)+4tP_m(t;H\psi)
 +2N|k|tP_m(t;\psi)+2mNtP_{m-1}(t;\psi)], \tag{10.10}
\]

whose Laplace-integrated uniform bounds $B_0,\ldots,B_4$ lie strictly below $1.255144$, $3.215825$, $5.536819$, $11.648259$, and $31.085903$.

Along $(k,l)=(r\nu-dn,r\nu)$, mixed radial/external derivatives of $\mathcal N_0$ satisfy

\[
 |\partial_r^a\partial_d^b\mathcal N_0|
 \le\sum_{j=0}^a{a\choose j}B_{b+j}B_{a-j},\qquad a+b\le4. \tag{10.11}
\]

Combining (10.11) with §9.4's enclosed field-solution derivatives produces uniform fourth-order constants $M_{22},M_{31},M_{40}$. Because paired integration over $r\in[-B,B]$ annihilates the odd $r^1$ bulk term, odd $r^2$ first-flux term, and odd $r^3$ zeroth-flux term identically, all remainders start cleanly at $O(B^5)$.

<a id="prop-10-1"></a>

**Proposition 10.1 (uniform $O(B^5)$ whole-ball remainder bound).** Across $|k|\le B$ and every unit vector $n\in S^2$, the propagation curvature minus its leading diagonal tensor (10.7) obeys the uniform bound

\[
 |K_G^\alpha(n)-n^T\mathsf K_{G,0}^\alpha n|
 \le\frac{B^5}{\pi^2}\left[
 \frac{M_{22}}{40}+\frac{M_{31}}{48}
 +\frac{1+1/\sqrt3}{144}M_{40}\right]. \tag{10.12}
\]

**Proof.** Integral-form Taylor remainders on $r\in[-B,B]$ bound the bulk remainder by $r^2M_{22}/2$, first-flux remainder by $|r|^3M_{31}/6$, and the $\partial_r\operatorname{Re}\mathscr R_0$ and $\operatorname{Re}\mathscr R_0$ parts of the zeroth-flux remainder by $|r|^3M_{40}/6$ and $r^4M_{40}/24$. Substituting into (8.5) with $\int_{S^2}|u|\,d\Omega=2\pi$, $\int_{S^2}u^2\,d\Omega=4\pi/3$, $\int_{S^2}|3u^2-1|\,d\Omega=16\pi/(3\sqrt3)$, and $(2\pi)^{-3}$ yields (10.12). □

Outward-rounded rational evaluation of (10.12) gives the spectral-norm remainder bounds:

| Sector | Uniform spectral-norm bound on \(\|\mathsf K_G^\alpha-\mathsf K_{G,0}^\alpha\|_2\) |
|---|---:|
| `raw` (uncentered) | \(2.070266\times10^{-22}\) |
| `mean` (mean product) | \(1.336530\times10^{-24}\) |
| `connected` (centered) | \(2.052970\times10^{-22}\) |

Because the operator norm of a real symmetric matrix equals $\sup_{|n|=1}|n^T\Delta\mathsf K\,n|$ and bounds every diagonal and off-diagonal entry simultaneously, all mixed entries are controlled without directional sampling.

## 11 Whole-Ball Curvature Synthesis and Continuous-Homotopy $(2,1,0)$ Inertia Locking (Q4)

### 11.1 Five-Channel Synthesis and Independent Centered Interval Discipline

Denoting the two-leg quantum-source external-momentum Hessian by $\mathsf S_N^\alpha$ and the central readout contact quadratic matrix by $\mathsf K_C^\alpha$, the complete five-channel whole-ball curvature tensor is

\[
 \mathsf K_\alpha
 =\mathsf K_G^\alpha+\frac12\mathsf S_N^\alpha+\mathsf K_C^\alpha,\qquad
 \mathsf K_{\mathrm{raw}}=\mathsf K_{\mathrm{mean}}+\mathsf K_{\mathrm{conn}}, \tag{11.1}
\]

where $1/2$ converts the second-derivative Hessian $\mathsf S_N^\alpha$ into a Taylor quadratic-form coefficient (all cosine and fluctuation half-factors in (7.15) having already been included).

In the `raw` sector, $\frac12\mathsf S_N^{\mathrm{raw}}+\mathsf K_C^{\mathrm{raw}}$ lies inside $[-3.13001133,-2.67205597]\times 10^{-22}$ along every unit direction, shifting (10.7) downward by $\sim 0.029\times 10^{-20}$ to yield the certified intervals in §1.2 while leaving the $+2.16\times 10^{-20}$ peak along $e_2$ untouched. Following §9.4's anti-wrapping rule [[26]](#ref-26), `mean` and `connected` are enclosed directly from their own mean and centered complex Gram inputs rather than by endpoint subtraction `raw - mean`, giving `connected` the same tight $4.56\times 10^{-22}$ width as `raw`.

### 11.2 Uniform Off-Diagonal Bounds and the Continuous-Scaling Gershgorin Proof of Theorem 1.2

Writing $d_i\pm e_i$ for the certified diagonal enclosures, combining (10.7), Proposition 10.1, quantum-source anisotropy bounds, and (9.12) places the full symmetric matrix $\mathsf K_\alpha$ inside

\[
 K_{ii}\in[d_i-e_i,d_i+e_i],\quad |K_{ij}|\le m_\alpha\ (i\ne j), \tag{11.2}
\]

with $m_{\mathrm{raw}}<2.299243\times 10^{-22}$ and $m_{\mathrm{conn}}<2.281948\times 10^{-22}$. By Gershgorin's circle theorem [[24]](#ref-24), row $i$ of a $3\times 3$ matrix has disk radius at most $2m_\alpha$. Using the outward-rounded decimal enclosures of §1.2, the three Gershgorin intervals for `raw` lie strictly inside (units of $10^{-20}$)

\[
 [-1.401185,-1.263229],\quad[2.094286,2.232242],\quad
 [-1.788585,-1.650629], \tag{11.3}
\]

and those for `connected` lie strictly inside (units of $10^{-20}$)

\[
 [-1.342971,-1.206052],\quad[2.094015,2.230935],\quad
 [-1.747134,-1.610214]. \tag{11.4}
\]

**Proof of Theorem 1.2.** Form the linear homotopy of real symmetric matrices $\mathsf K_\alpha(t)=\operatorname{diag}(K_{11}^\alpha,K_{22}^\alpha,K_{33}^\alpha)+t(\mathsf K_\alpha-\operatorname{diag}\mathsf K_\alpha)$ for $t\in[0,1]$. Because $|tK_{ij}^\alpha|\le|K_{ij}^\alpha|\le m_\alpha$ holds uniformly for every $t\in[0,1]$, all three real eigenvalues of $\mathsf K_\alpha(t)$ remain confined inside the union of (11.3) (for `raw`) or (11.4) (for `connected`) throughout $t\in[0,1]$. Every interval in (11.3) and (11.4) is separated from $0$ by more than $1.20\times 10^{-20}$, so by continuity of eigenvalues of symmetric matrices in $t$, no eigenvalue can cross $0$ along $[0,1]$. At $t=0$, the diagonal matrix manifestly has two strictly negative and one strictly positive eigenvalue; at $t=1$, Sylvester's inertia [[23]](#ref-23) is therefore locked at $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0)$. □

![Figure 4: Diagonal rational intervals, boundary-flux flip, Gershgorin bands, and microscopic zooms.](figures/fig03-inertia-v2-en.svg)

**Figure 4. Diagonal rational intervals, boundary-flux flip, Gershgorin bands, and microscopic zooms.** Units of $10^{-20}$ throughout. Upper tier (A): full-scale $[-2.05,+2.55]$ enclosures of `raw` (deep blue) and `connected` (gold) along $e_1,e_2,e_3$ with $\pm 2|K_{ij}|$ Gershgorin bands, highlighting on `raw / e_2` how the $+2.38$ net spherical boundary flux flips the spurious negative bulk value $-0.19$ across the vermilion zero line to $+2.16$; all six Gershgorin bands clear $0$ by over $1.2\times 10^{-20}$. Lower tier (B): three microscopic zoom insets resolving at $\times 27$ (left) and $\times 20$ (center) the tight $0.046\times 10^{-20}$ dyadic rational cores inside their Gershgorin halos, and displaying at right how `mean / e_2` ($[-0.001635,+0.003212]\times 10^{-20}$) straddles zero and is therefore reported in §1.2 without an inertia claim.

Two geometric and physical boundaries bear emphasis: for any unit vector $n\in S^2$, the directional quadratic coefficient is $n^T\mathsf K_\alpha n$; inertia $(2,1,0)$ locks two negative and one positive principal curvatures under orthogonal diagonalization without requiring $(e_1,e_2,e_3)$ themselves to be exact eigenvectors (small $K_{ij}$ permit a tiny orthogonal frame tilt). Moreover, (1.4) characterizes the external-momentum curvature of the induced five-channel polarization under our fixed probe protocol, not dynamical stability of the unperturbed classical background (which is independently established by symmetric-hyperbolic positive-energy closure in Theorems 4.6–4.7 of [[1]](#ref-1)).

## 12 Full Four-Complex-Momentum Mother-Action Second-Fréchet-Variation Identification and Origin-Kernel Schur Reconstruction (Q5)

Section 5 derived a quadratic expansion of the five-dimensional origin light kernel along axial and common block-regular slices. We now settle the deeper variational foundation [[6]](#ref-6), [[19]](#ref-19): does the $289\times 289$ linearized propagation matrix $H_{289}(p)$ agree identically at **every complex four-momentum $p\in\mathbb C^4$** with the second Fréchet derivative of the nonlinear mother Lagrangian density over all first-jet variables? And can the five-dimensional origin kernel be extended without quadratic truncation to an exact rational Schur kernel across four-momentum space that reconstructs denominator-cleared Green solutions across all 289 field coordinates? Both answers are affirmative.

### 12.1 Entrywise Identification of the 1,445-Slot First-Jet Second Fréchet Derivative with $H_{289}(p)$

<a id="prop-12-1"></a>

**Proposition 12.1 (entrywise equality of the four-momentum first-jet second Fréchet variation with $H_{289}(p)$).** On the real first-jet space $j\in\mathbb R^{1445}$ around the nine-field classical background (289 field values plus $289\times 4$ spacetime gradient slots), lift all nine field sectors and their partial derivatives into holomorphic local configurations of the mother action via

\[
\mathcal L_{\mathrm{nat}}(j)=\mathcal L_{\mathrm{mother}}(\mathrm{Lift}(j)), \tag{12.1}
\]

retaining the full coframe, spin connection, gravitational and gauge auxiliary two-forms, exterior-power scalar, matter spinor, and independent variational dual together with their four-gradients. Denote the second Fréchet derivative bilinear form at the background origin by

\[
\mathcal H=D^2\mathcal L_{\mathrm{nat}}(0). \tag{12.2}
\]

Then its associated Fourier–Euler second-variation operator matrix [[6]](#ref-6) agrees entry by entry across **every complex four-momentum $p\in\mathbb C^4$** with $H_{289}(p)$:

\[
K_{\rm nat}(p)_{ij}
=\sum_{\alpha,\beta\in\{\varnothing,0,1,2,3\}}
 \mathcal H(e_{\alpha i},e_{\beta j})
 s_\alpha(-p)s_\beta(p)
=H_{289}(p)_{ij},\qquad
s_\varnothing(p)=1,\quad s_\mu(p)=p_\mu, \tag{12.3}
\]

where $e_{\alpha i}$ denotes the standard real first-jet basis ($\varnothing$ indexing field values and $\mu=0,1,2,3$ indexing partial-derivative slots).

**Proof.** Pointwise agreement of $\mathcal L_{\mathrm{nat}}$ with (2.4) and rational smoothness over the background coframe ensure existence and symmetry of $\mathcal H$. Keeping all $289\times 5=1,445$ real jet slots ($637$ active nonzero slots on the classical background), the gravitational, gauge, exterior-scalar, and independent-dual matter sectors generate $234$, $406$, $220$, and $790$ quadratic jet terms respectively, totaling $1,650$ terms. Applying left/right Euler integration-by-parts signs expands these into $3,300$ two-leg Fourier monomials; collecting like momentum multi-indices over the four-radical basis $(1,\sqrt2,\sqrt{15},\sqrt{30})$ of $\mathbb Q(\sqrt2,\sqrt{15})$ produces a $3,071$-entry Jacobi dictionary identical byte for byte with $H_{289}(p)$ across all polynomial coefficients. □

### 12.2 Five Origin Null Columns and the 98-Dimensional Non-Orthogonal Coordinate Complement

Abbreviate $H(p)=H_{289}(p)$. An invertible polynomial field transformation $F(p)$ (with exact polynomial two-sided inverse) brings $H(p)$ to $D(p)=F(-p)^TH(p)F(p)$, splitting into an algebraic contact block, $103$ dynamically active coordinates, and $9$ gauge/symmetry null directions. Denote the zero-padded $289\times 289$ active block by $K(p)$ with mutually orthogonal coordinate projectors $P_a$ (rank $103$), $P_c$ (contact), and $P_n$ (nine null modes) satisfying $P_a+P_c+P_n=I_{289}$ and $K(-p)^T=K(p)$.

Writing $e_j$ for the transformed unit basis vectors, the five-dimensional nullspace of $K(0)$ is spanned by $N=(n_0,\ldots,n_4)\in\mathbb C^{289\times5}$:

\[
 n_0=\frac{3\sqrt2}{10}(e_{21}-e_{34})+e_{79}+e_{83},\qquad
 n_1=\frac{3\sqrt2}{10}(e_{21}-e_{34})+e_{79}+e_{85}, \tag{12.4}
\]

\[
 n_2=e_{89}-e_{91},\qquad n_3=e_{95}-e_{97},\qquad
 n_4=e_{101}-e_{103}+e_{107}-e_{109}, \tag{12.5}
\]

($n_0,n_1$ generated by the canonical occupied state and $n_2,n_3,n_4$ by the independent variational dual), obeying $K(0)N=0$. Define the five-slot coordinate readout $Cx=(x_{83},x_{85},x_{89},x_{95},x_{101})$, which satisfies $CN=I_5$, and the $98$-dimensional coordinate-complement projector

\[
 P_h=P_a-\sum_{j\in\{83,85,89,95,101\}}e_je_j^T.
\]

For every active vector $P_ax=x$, setting $c_N=Cx\in\mathbb C^5$ and $y=x-Nc_N$ gives $Cy=Cx-CNc_N=0$, hence $P_hy=y$. Unlike Feshbach's orthogonal subspace projection [[19]](#ref-19), $\operatorname{Im}N\oplus\operatorname{Im}P_h$ is an **oblique coordinate direct sum**: $n_0,\ldots,n_4$ retain nonzero entries on complement slots ($21,34,79,91,97,103,107,109$), preserving exact algebraic coefficients without irrational Gram–Schmidt square roots.

### 12.3 Exact $45+21+32$ Origin Block Inverses and the Nonempty Four-Momentum Regular Domain

Sparsity of $K(0)$ splits $P_h$ into three disjoint invariant coordinate blocks of dimensions $45,21,32$:

\[
\begin{aligned}
 I_{45}=\{&9,10,15,16,19,20,21,22,27,28,31,32,33,34,39,\\
 &40,43,44,45,46,51,52,55,56,57,58,59,60,61,62,\\
 &63,64,65,66,67,69,70,72,73,75,76,79,80,82,86\},\\
 I_{21}=\{&88,90,91,92,93,94,96,97,98,99,100,102,\\
 &103,104,105,106,107,108,109,110,111\},\\
 I_{32}=\{&11,12,13,14,17,18,23,24,25,26,29,30,35,36,37,38,\\
 &41,42,47,48,49,50,53,54,68,71,74,77,78,81,84,87\}.
\end{aligned}
\]

With block projectors $P_i$ and $A_i=P_iK(0)P_i$, exact algebraic tables supply block inverses $B_i$ satisfying $B_iA_i=P_i$, $P_iB_i=B_i=B_iP_i$, and $B_iA_j=0$ ($i\ne j$). Their sum $B=\sum_iB_i$ obeys

\[
 B(P_hK(0)P_h)=P_h,\qquad P_hB=B=BP_h. \tag{12.6}
\]

Padding outside $P_h$ by $I-P_h$ defines $A(p)=P_hK(p)P_h+(I-P_h)$ and $A_0^{-1}=B+(I-P_h)$. Equation (12.6) gives $A_0^{-1}A(0)=I_{289}$, hence $A(0)A_0^{-1}=I_{289}$ and $\det A(0)\ne 0$ on finite-dimensional matrices. Continuity of $\det A(p)$ therefore certifies internally that $\mathcal U=\{p\in\mathbb C^4:\det A(p)\ne0\}$ is an open neighborhood of $0\in\mathbb C^4$. Setting $G_c(p)=P_hA(p)^{-1}P_h$ on $\mathcal U$ yields

\[
 G_cKP_h=P_h,\quad P_hKG_c=P_h,\quad G_c(0)=B. \tag{12.7}
\]

### 12.4 Exact Four-Complex-Momentum Schur Kernel and Active-Field Recovery Theorem

<a id="thm-12-2"></a>

**Theorem 12.2 (four-complex-momentum $5\oplus 98$ Schur reconstruction and denominator-cleared 289-field recovery).** On $\mathcal U\subset\mathbb C^4$, define the exact five-dimensional effective kernel $E(p)\in\mathbb C^{5\times5}$, source-compression map $L_S(p)\in\mathbb C^{5\times289}$, and dressed origin embedding $N_{\mathrm{eff}}(p)\in\mathbb C^{289\times5}$:

\[
 E(p)=N^TK(p)N-N^TK(p)G_c(p)K(p)N, \tag{12.8}
\]

\[
 L_S(p)=N^T-N^TK(p)G_c(p),\qquad N_{\rm eff}(p)=N-G_c(p)K(p)N. \tag{12.9}
\]

For every active vector $P_ax=x$ solving $K(p)x=s$, setting $c_N=Cx\in\mathbb C^5$ and $y=x-Nc_N$ yields the exact complement, effective five-mode equation, and full active-field reconstruction

\[
 y=G_c(s-KNc_N),\qquad E(p)c_N=L_S(p)s, \tag{12.10}
\]

\[
 x=N_{\rm eff}(p)c_N+G_c(p)s. \tag{12.11}
\]

**Proof.** Left-multiplying $K(p)(Nc_N+y)=s$ by $G_c(p)P_h$ and invoking $G_cKP_h=P_h$ from (12.7) together with $P_hy=y$ gives $y=G_c(s-KNc_N)$. Meanwhile, (12.9) and $P_hKG_c=P_h$ imply $L_S(p)K(p)P_h=N^TKP_h-N^TKG_cKP_h=0$: left-multiplying $K(p)(Nc_N+y)=s$ by $L_S(p)$ eliminates the 98-dimensional complement $y$ in one step, leaving $L_S(p)K(p)Nc_N=E(p)c_N=L_S(p)s$. Substituting $y$ into $x=Nc_N+y$ gives (12.11). At $p=0,s=0$, $K(0)N=0$ forces $y=0$, confirming that $N$ spans the entire active nullspace at the origin. □

### 12.5 Explicit Local Neumann Radius $\rho$ and Full-Block Cubic Resolvent Remainder Bound

Set $\Delta K(p)=K(p)-K(0)$. Expanding the first-order origin replacement splits into a $36$-entry linear/quadratic table $T_{12}(p)$ and a $48$-entry cubic/quartic table $T_{34}(p)$:

\[
 N^TKN-N^TKBKN=T_{12}+T_{34}. \tag{12.12}
\]

Using $K(0)N=0$ and $K(0)^T=K(0)$, (12.8) admits the exact resolvent decomposition

\[
 E=T_{12}+T_{34}-N^T\Delta K\,(G_c-B)\Delta K\,N. \tag{12.13}
\]

Under the maximum row-sum matrix norm, bound coefficients in $\mathbb Q(\sqrt2,\sqrt{15})$ via the rational outward weight

\[
 \operatorname{wt}(a+b\sqrt2+c\sqrt{15}+d\sqrt{30})
 =|a|+2|b|+4|c|+8|d|. \tag{12.14}
\]

Summing monomial by monomial over the mother dictionaries yields four explicit rational constants:

\[
 I_B=1+\frac{3267130962160409}{14460684885900},\qquad
 V_B=1+\frac{1359392}{375},\qquad
 N_B=\frac{72}{5},\qquad H_B=\frac{4200156368}{32034375}, \tag{12.15}
\]

bounding $A_0^{-1}$, $\Delta K$, $N$ and $N^T$, and $T_{34}$ respectively. Define the source-generated four-complex-momentum Neumann radius

\[
 \rho=(4I_BV_B)^{-1}
 =\frac{1355689208053125}{4462200029129218450003}. \tag{12.16}
\]

On the polydisk $0\le\max_\mu|p_\mu|\le r\le\rho$, $\|A_0^{-1}[A(p)-A(0)]\|\le 1/4<1$ guarantees absolute Neumann convergence and $\|G_c(p)\|\le 2I_B$. Combining the exact resolvent difference

\[
 G_c-B=-G_c\Delta K B \tag{12.17}
\]

with $\|\Delta K\|\le V_Br$ gives $\|G_c(p)-B\|\le 2I_B^2V_Br$; inserting $\|N\|,\|N^T\|\le N_B$ and $\|T_{34}(p)\|\le H_Br^3$ ($r\le 1$) into (12.13) proves the rigorous cubic remainder bound across the entire $5\times 5$ effective kernel:

\[
 \|E(p)-T_{12}(p)\|
 \le C_Er^3,\qquad
 C_E=H_B+2N_B^2I_B^2V_B^3. \tag{12.18}
\]

Here $\rho$ controls the general four-complex-momentum complement inverse on $\mathbb C^4$, while the 3D momentum ball $|k|\le B$ of §§7–11 remains governed independently by $\rho_*=1/8192$ in (9.15).

### 12.6 Simultaneous Recovery of Contact, Active, and All Nine Null Modes from Denominator-Cleared Green Solutions

At a prepared response point $q$ with independent left/right real momenta $p_L,p_R$, rest external state, readout frequency $\lambda$, and finite window $T$, let $J\in\mathbb C^{289}$ be the two-sector quantum current sum and $\kappa=F(-P)^TJ$ its transformed cosource at $P=(\lambda,i(p_R-p_L))$.

Denoting by $d(P)$ the common polynomial denominator of the constrained rational Green matrix and by $\widetilde G(P)$ its denominator-cleared polynomial adjugate Green matrix, $\widetilde X=\widetilde G(P)J$ satisfies the exact mother equation including nine-null-mode compatibility projection:

\[
 \widetilde X=\widetilde G(P)J,\qquad
 H(P)\widetilde X=d(P)\{J-F(-P)^{-T}P_n\kappa\}. \tag{12.19}
\]

Setting $x=P_aF(P)^{-1}\widetilde X$ and $s=d(P)P_a\kappa$, left-multiplying the second identity of (12.19) by $P_aF(-P)^T$ and using $P_aP_n=0$ yields $K(P)x=s$. Applying Theorem 12.2 and reassembling $P_c$, (12.11), and $P_n$ reconstructs the complete denominator-cleared 289-component field vector:

\[
\begin{split}
 \widetilde X={}&F(P)P_cF(P)^{-1}\widetilde X\\
 &+F(P)\{N_{\rm eff}(P)c_N+G_c(P)s\}\\
 &+F(P)P_nF(P)^{-1}\widetilde X.
\end{split} \tag{12.20}
\]

For rest external insertions, current support locks the exact origin readout pairing on $N_{\mathrm{native}}(0)=F(0)N\in\mathbb C^{289\times 5}$:

\[
 N_{\rm native}(0)^T J=(w_J,w_J,0,0,0),\qquad
 w_J=\frac{3\sqrt2}{10}(J_{21}-J_{34}),\quad N_{\rm native}(0)=F(0)N, \tag{12.21}
\]

while on $\max_\mu|P_\mu|\le r\le\rho$ the five-mode coordinate $c_N$ obeys the quadratic-truncation residual bound

\[
 \|T_{12}(P)c_N-L_S(P)s\|\le C_Er^3\|c_N\|. \tag{12.22}
\]

Wherever $d(P)\ne 0$, dividing (12.20) by the scalar $d(P)$ recovers the physical field with contact terms, five light modes, 98 heavy complement modes, and all nine null directions intact.

## 13 Ordered Configuration Histories, the Nonlinear Finite-Window $289\times289$ Polarization Tensor, and Cauchy Update (Q6)

Sections 6–11 analyzed the one-particle 12-dimensional ball-filtered wave packet under cosine gauge probing. We now step into the full many-body configuration Hilbert space $\mathscr H_{\mathrm{cfg}}$ (the 100-dimensional configuration half-density space tensored with the 504-mode global CAR Fock space [[1]](#ref-1)): when driven along nonlinear time histories across all 289 real field slots and observed by the CAR creation-minus-background functional, how does quantum polarization feed back into the mother Euler equations? We establish the real-field half-line Bochner operator $\mathcal J_\infty$, the full $289\times 289$ causal polarization tensor $\Pi_{d,T}(P,\lambda)$ on a positive nonlinear window $[0,\tau)$, and the voltage Cauchy whole-field update (keeping these configuration preparations and Laplace convergence conditions strictly distinct from §§7–11's two-ball protocol).

### 13.1 From the Ordered Five-Factor Configuration Kernel to the Real 289-Field Half-Line Operator $\mathcal J_\infty$

Fix a configuration response point $q$ on $\mathscr H_{\mathrm{cfg}}$: positive preparation precision, matter momentum $p$, momentum transfer $k$, finite frame $F$, two completed preparation legs, and off-axis matter frequencies $\operatorname{Im}z\ne 0,\operatorname{Im}w\ne 0$ (independent of the external observation wavevector $w_{\mathrm{obs}}\in\mathbb R^3$ and field Laplace parameter $\lambda$). For a real field perturbation $h$, left/right time evolutions, left/right matter resolvents, and the central raw variational current operator multiply in fixed left-to-right order:

\[
\mathcal W(h,t)=U_+(h,-t)R_+(h,z)B_{\rm raw}(h)R_-(h,w)U_-(h,t). \tag{13.1}
\]

With half-density weight $W$, the central raw current operator is the global CAR lift of $-4W\,DH$ formed after completing the independent-dual fiber product, with second-order contact $-4(DW\,DH+W\,D^2H)$. Differentiating along $h=rf$ ($f\in\mathbb R^{289}$) at $r=0$ applies the five-factor Leibniz rule across left time, left resolvent, central current, right resolvent, and right time prior to taking the outer prepared inner product.

Passing from raw variational readout $J_{\mathrm{raw}}$ to fixed-canonical-momentum Noether readout $J_N$ satisfies $J_N(0)=J_{\mathrm{raw}}(0)$ at zero perturbation, yet its directional first derivative carries a nonzero **central transport contact shift**:

\[
 S_q^N=S_q^{\mathrm{raw}}+
 \langle v_{L,q},(J_N'[f]-J_{\mathrm{raw}}'[f])v_{R,q}\rangle, \tag{13.2}
\]

where $v_{L,q},v_{R,q}$ incorporate unperturbed time evolutions and matter resolvents (leaving the four outer factor derivatives unchanged while completing the central contact slope via (13.2)). Moreover, the real coupling $\operatorname{Re}(\pi\psi)$ activates forward, reverse, and two cross paths $F,R,D_R,D_L$, assembling four momentum-transfer frequencies:

\[
 -\frac12\left[
 \delta_{-k}(F+\overline R)+\delta_k(R+\overline F)
 +\delta_{2p+k}(D_R+\overline{D_L})
 +\delta_{-(2p+k)}(D_L+\overline{D_R})\right], \tag{13.3}
\]

where $\delta_v$ denotes a point mass at wavevector $v$ in the finitely supported Fourier spectrum—whenever distinct transfer frequencies coincide at special $(p,k)$, **their complex amplitudes are summed prior to evaluating at the target wavevector $w_{\mathrm{obs}}$**, and the overall minus sign moves the source to the right-hand side of the mother Euler equation.

At a fixed observation wavevector $w_{\mathrm{obs}}\in\mathbb R^3$, let $\mathcal D_q(t):\mathbb R^{289}\to\mathbb C^{289}$ denote the resulting real Noether–Euler derivative operator combining (13.2) and (13.3). Smoothness ($C^2$) of the shared field coefficients and uniform local integrability on compact time tubes yield the exact finite-window Fréchet derivative

\[
D_h J_T(q,h;\lambda)|_{h=0}[f]
=\int_0^Te^{-\lambda t}\,\mathcal D_q(t)f\,dt. \tag{13.4}
\]

<a id="prop-13-1"></a>

**Proposition 13.1 (half-line Noether–Bochner response operator and exponential tail bound on all 289 real fields).** For every $\operatorname{Re}\lambda>0$, the mother source parameters determine a finite constant $C_q(\lambda)\ge 0$ such that

\[
\|e^{-\lambda t}\mathcal D_q(t)\|
\le C_q(\lambda)e^{-\Re\lambda\,t/2},\qquad t\ge0, \tag{13.5}
\]

ensuring absolute Bochner integrability of $\mathcal J_\infty(q,\lambda)\in\mathcal L(\mathbb R^{289},\mathbb C^{289})$ and exponential operator-norm convergence of $\mathcal J_T$:

\[
\mathcal J_\infty(q,\lambda)
=\int_0^\infty e^{-\lambda t}\mathcal D_q(t)\,dt,
\qquad
\|\mathcal J_\infty-\mathcal J_T\|
\le\frac{2C_q(\lambda)}{\Re\lambda}
 e^{-\Re\lambda T/2}. \tag{13.6}
\]

**Proof.** Splitting the shared time generator into particle-number-preserving $C$ and grade-raising $A$, ODE uniqueness truncates the partial evolution at an exact $57$-term sum, bounding growth polynomially in $t\ge 0$. Combining Duhamel variations, five-factor time jets, (13.2), and (13.3) with $t^me^{-\eta t}\le m!/\eta^m$ at $\eta=\operatorname{Re}\lambda/8>0$ across all 289 basis inputs and outputs gives (13.5), from which Bochner integrability and tail integration over $[T,\infty)$ yield (13.6). □

**Whole-field return through the mother Green matrix and curvature readout.** Write $\mathcal R_{36}(P)\in\mathbb C^{36\times289}$ for the native ordinary-curvature readout, $\mathcal C(P)=P_nF(-P)^T\in\mathbb C^{289\times289}$ for the nine-null-mode compatibility projector, and $L_{\mathrm{src}}(P)=F(-P)^{-T}\in\mathbb C^{289\times289}$ for the inverse-transpose source lift (distinct from §12.4's $5\times 289$ map $L_S$). Specializing to $w_{\mathrm{obs}}=k$, wherever $P_k=(\lambda,ik)$ lies in the regular domain of the constrained mother Green matrix $\mathcal G(P_k)$, Proposition 12.1 yields

\[
K_{\rm nat}(P_k)\mathcal G(P_k)\mathcal J_\infty f
=\mathcal J_\infty f-L_{\mathrm{src}}(P_k)\mathcal C(P_k)\mathcal J_\infty f; \tag{13.7}
\]

since field reconstruction is at most second order in time, two integrations by parts retain the $t=0$ boundary cosource while sending $T\to\infty$ boundary terms exponentially to zero across all 289 fields and $\mathcal R_{36}$.

### 13.2 The CAR Creation-Minus-Background Functional $\ell_d$ and Nonlinear History Evolution

Fix a dressed source event

\[
d=(\epsilon>0,\ p\in\mathbb R^3,\ F,\ m\in\mathbb N,\ \zeta\in\mathbb C,\ \Im\zeta\ne0), \tag{13.8}
\]

comprising configuration precision $\epsilon$, matter momentum $p$, finite frame $F$, cutoff index $m$, and shared nonreal resolvent frequency $\zeta$, together with physical momentum transfer $k\in\mathbb R^3$.

Let $v_\epsilon=\mathcal Px_\epsilon$ ($\|v_\epsilon\|=1$) be the normalized background state produced by the configuration preparation map $\mathcal P$. Exciting channel $1$, spin $0$ on the 504-mode global CAR creation branch produces $\mathcal A_{\mathrm{cr}}x_\epsilon$: because the scalar profile weight is bounded below by $1/2$ on the source box, pulling back via the unoccupied color annihilation operator and applying the half-density CAR anticommutator identity yields

\[
\|\mathcal P x\|^2
\le4\|\mathcal A_{\rm cr}x\|^2, \tag{13.9}
\]

guaranteeing $\|\mathcal A_{\mathrm{cr}}x_\epsilon\|\ge 1/2>0$. Multiplying by the nonzero electromagnetic dressing character to form $g_\epsilon$ and normalizing defines the unit created state

\[
u_\epsilon=g_\epsilon/\|g_\epsilon\|,
\qquad\|u_\epsilon\|=\|v_\epsilon\|=1. \tag{13.10}
\]

Applied strictly after multiplying the entire noncommutative operator word, the **creation-minus-background observer functional** (carrying the mother-Euler minus sign) is

\[
\ell_d(A)=-\langle u_\epsilon,A u_\epsilon\rangle
+\langle v_\epsilon,A v_\epsilon\rangle,
\qquad\|\ell_d\|\le2, \tag{13.11}
\]

(bounded by Cauchy–Schwarz on two unit vectors; $\ell_d$ compares the many-body created state $u_\epsilon$ against $v_\epsilon$, distinct from §6.3's one-particle $I-P$ projection).

Setting $p_-=p,p_+=p-k$, write $G_\pm(h)$ for the instantaneous real-field-dependent time generators, $R_\pm(h)$ for the matter resolvents, and $N_f(h)$ for the central Noether readout. For any real 289-field history $h(t)$ that is $C^1$ near $t=0$, uniform Lipschitz bounds on compact amplitude-time rectangles construct via Picard–Volterra contraction the exact nonlinear bilateral evolutions on a positive amplitude-time neighborhood:

\[
\begin{gathered}
\partial_tU_\rho(t)=A_{-,\rho}(t)U_\rho(t),
\qquad
\partial_tV_\rho(t)=-V_\rho(t)A_{+,\rho}(t),\\
A_{\pm,\rho}(t)=-iG_\pm(\rho h(t)),
\qquad U_\rho(0)=V_\rho(0)=I,
\end{gathered} \tag{13.12}
\]

where the independent-dual left leg $V_\rho(t)$ evolves by right multiplication. Gronwall estimates and dominated difference quotients establish genuine $\rho=0$ derivatives (writing $U_0,V_0$ for $\rho=0$ evolutions and $J_\pm(h)$ for generator field derivatives):

\[
\dot U(t)=U_0(t)\int_0^tU_0(-s)(-iJ_-(h(s)))U_0(s)\,ds, \tag{13.13}
\]

\[
\dot V(t)=-\left[\int_0^tV_0(s)(-iJ_+(h(s)))V_0(-s)\,ds\right]V_0(t),
\quad
\dot R_\pm=-R_\pm J_\pm(h(0))R_\pm,
\quad\dot N_f=N_f'[h(t)]. \tag{13.14}
\]

Multiplying the nonlinear five-factor ordered kernel on $\mathscr H_{\mathrm{cfg}}$,

\[
\mathcal K_{f,\rho}(t)
=V_\rho(t)R_+(\rho h(0))N_f(\rho h(t))R_-(\rho h(0))U_\rho(t), \tag{13.15}
\]

its exact $\rho=0$ derivative expands into five ordered operator terms:

\[
\begin{aligned}
\partial_\rho\mathcal K_{f,\rho}(t)|_0={}&
\dot V R_+N_fR_-U_0
+V_0\dot R_+N_fR_-U_0
+V_0R_+\dot N_fR_-U_0\\
&+V_0R_+N_f\dot R_-U_0
+V_0R_+N_fR_-\dot U,
\end{aligned} \tag{13.16}
\]

with $\dot N_f$ retaining the full transported Noether contact derivative; letting $f$ run over all $289$ basis slots and applying $\ell_d$ outside generates all nonlinear quantum-source derivatives.

### 13.3 Quadrature Real Histories and the Full $289\times289$ Causal Polarization Tensor $\Pi_{d,T}(P,\lambda)$

For any $P=(P_0,P_1,P_2,P_3)\in\mathbb C^4$ and complex amplitude $a\in\mathbb C^{289}$, form the quadrature pair of real spacetime histories

\[
h_a(x)=\Re(e^{P\cdot x}a),\qquad
h_{-ia}(x)=\Re(e^{P\cdot x}(-ia)), \tag{13.17}
\]

and let $\tau(d,k,P,a)>0$ be the minimum of their positive Picard existence windows. Denoting by $L_d(P,t):\mathbb C^{289}_{\mathbb R}\to\mathbb C^{289}$ the real-linear map induced across all 289 rows by applying $\ell_d$ to (13.16) on $h_a$, quadrature recombination

\[
\mathscr D_d(P,t)a=L_d(P,t)a+iL_d(P,t)(-ia) \tag{13.18}
\]

satisfies $\mathscr D_d(P,t)(ia)=L_d(P,t)(ia)+iL_d(P,t)a=i\mathscr D_d(P,t)a$, making $\mathscr D_d(P,t)$ strictly $\mathbb C$-linear on $\mathbb C^{289}$. Defining the instantaneous $289\times 289$ polarization matrix columnwise by

\[
\Pi_d(P,t)_{ij}=\bigl(\mathscr D_d(P,t)e_j\bigr)_i, \tag{13.19}
\]

gives $\mathscr D_d(P,t)a=\Pi_d(P,t)a$ for all $a\in\mathbb C^{289}$ (retaining all 289 input and output slots including the nine scalar-orbit directions).

Writing $E_d(r,t)$ for the quadrature complex combination of the two holomorphically lifted mother-Euler residuals at real amplitude $r$ minus the nonlinear prepared quantum reading, subtracting (13.16)–(13.19) from Proposition 12.1 row by row yields on the shared positive window

\[
\partial_rE_d(r,t)|_0
=K_{\rm nat}(P)e^{P_0t}a-\Pi_d(P,t)a,
\qquad0\le t<\tau(d,k,P,a). \tag{13.20}
\]

Define the finite-window exponential time weight and Laplace polarization matrix:

\[
W_T(P_0,\lambda)=\int_0^Te^{-\lambda t}e^{P_0t}\,dt,
\qquad
\Pi_{d,T}(P,\lambda)=\int_0^Te^{-\lambda t}\Pi_d(P,t)\,dt. \tag{13.21}
\]

<a id="thm-13-2"></a>

**Theorem 13.2 (exact mother-Euler zero-amplitude-derivative response pencil on the nonlinear positive window).** For every $\lambda\in\mathbb C$, $P\in\mathbb C^4$, $a\in\mathbb C^{289}$, and cutoff $0\le T<\tau(d,k,P,a)$, the finite Laplace integral of the nonlinear mother-Euler–quantum residual derivative equals the exact matrix-pencil action

\[
\boxed{\int_0^Te^{-\lambda t}\partial_rE_d(r,t)|_0\,dt
=\bigl[W_T(P_0,\lambda)K_{\rm nat}(P)-\Pi_{d,T}(P,\lambda)\bigr]a.} \tag{13.22}
\]

**Proof.** Continuity in $t$ on $[0,T]\subset[0,\tau)$ commutes finite-dimensional matrix multiplication with definite integration in (13.20), integrating the classical mother-Euler term to $W_T(P_0,\lambda)K_{\mathrm{nat}}(P)a$ and the quantum derivative term to $\Pi_{d,T}(P,\lambda)a$. When observation and input clocks coincide ($\lambda=P_0$), $e^{(P_0-\lambda)t}\equiv 1$ gives $W_T(P_0,P_0)=T$ (kept unnormalized without dividing by $T$); for mismatched clocks such as $P=0,\lambda=1,T=1$, $W_1(0,1)=1-e^{-1}\ne 1$, and (13.22) preserves the exact exponential weight. □

Alongside the nonlinear window $0\le T<\tau$, **the linearized operator $\mathscr D_d(P,t)$ itself** admits a half-line Bochner limit whenever $\Delta=\operatorname{Re}\lambda-\gamma(P)>0$ with $\gamma(P)=\max(0,\operatorname{Re}P_0)$: unit-state norms, $C^2$ field bounds, and polynomial evolution bounds furnish $C_d=C_d(k,P,\lambda)\ge 0$ such that

\[
\|e^{-\lambda t}\mathscr D_d(P,t)\|
\le C_d e^{-\Delta t/2}\qquad(t\ge0), \tag{13.23}
\]

yielding $\Pi_\infty=\int_0^\infty e^{-\lambda t}\Pi_d(P,t)\,dt$ with explicit operator-norm tail bound

\[
\|\Pi_\infty-\Pi_T\|
\le\frac{2C_d}{\Delta}e^{-\Delta T/2}\qquad(T\ge0). \tag{13.24}
\]

Figure 5 displays these three distinct convergence regimes side by side: $\operatorname{Re}\lambda>0$ for the real-field half-line operator (Proposition 13.1), $0\le T<\tau(d,k,P,a)$ for the nonlinear amplitude-derivative pencil (Theorem 13.2), and $\operatorname{Re}\lambda>\gamma(P)$ for the linearized half-line limit (13.24).

### 13.4 Time-Jet Endpoint Cosources and Voltage Cauchy Whole-Field Closure

By quadrature construction, $\Pi_{d,T}(P,\lambda)a=j_T[h_a]+i\,j_T[h_{-ia}]$. On the regular domain of $\mathcal G(P_k)$ ($P_k=(\lambda,ik)$), feeding $j_T=\Pi_{d,T}(P,\lambda)a$ into $\mathcal G(P_k)$ gives via Proposition 12.1

\[
x_T=\mathcal G(P_k)j_T,
\quad
K_{\rm nat}(P_k)x_T=j_T-L_{\mathrm{src}}(P_k)\mathcal C(P_k)j_T, \tag{13.25}
\]

while two integrations by parts on zeroth-, first-, and second-order time jets isolate the interior time source and shared $t=0,T$ boundary terms:

\[
F(-P_k)^Tj_T
=\int_0^Te^{-\lambda t}j_{\rm time}(t)\,dt
-\bigl[B_\lambda(T)-B_\lambda(0)\bigr], \tag{13.26}
\]

with $j_{\mathrm{time}}=j_{\mathrm{time}}[h_a]+i\,j_{\mathrm{time}}[h_{-ia}]$ and $B_\lambda=B_\lambda[h_a]+i\,B_\lambda[h_{-ia}]$.

**Voltage Cauchy update instance.** For the linear-in-time Cauchy history $h_{\mathrm v}(t)=u_{\mathrm v}(k)+t\,v_{\mathrm v}$ induced by a static voltage source (spatial voltage vector $u_{\mathrm v}(k)$ and temporal slope $v_{\mathrm v}$), let $X_{\mathrm{cl},T}=\int_0^Te^{-\lambda t}h_{\mathrm v}(t)\,dt$ and let $j_T^{\mathrm{Re}},j_T^{\mathrm{Im}}$ be the five-term quantum forcing vectors of its real and imaginary Cauchy signals. Combining the classical window Green identity with both quantum forcings gives the complete voltage Cauchy update

\[
 X_{\mathrm{upd},T}=X_{\mathrm{cl},T}
 -F(P_k)P_nF(P_k)^{-1}X_{\mathrm{cl},T}
 +\mathcal G(P_k)j_T^{\mathrm{Re}}+i\mathcal G(P_k)j_T^{\mathrm{Im}}, \tag{13.27}
\]

acted on rowwise by $\mathcal R_{36}(P_k)$ while retaining initial/terminal cosources, nine-null-mode subtraction, and all 289 field slots for downstream 72-component holonomic gauge curvature and physical pole matching [[2]](#ref-2), [[3]](#ref-3).

![Figure 5: Mother-action second-Fréchet-variation identification, four-momentum Schur reconstruction, and nonlinear Noether polarization return.](figures/fig04-full-return-v2-en.svg)

**Figure 5. Mother-action second-Fréchet-variation identification, four-momentum Schur reconstruction, and nonlinear Noether polarization return.** Top banner: the second Fréchet derivative of the mother density across 1,445 real first-jet slots matches $H_{289}(p)$ over all $p\in\mathbb C^4$ (Proposition 12.1). Upper half (Q5): five origin columns and the $45+21+32$ direct-sum complement construct the four-complex-momentum Schur kernel $E(p)$, recovering contact, active, and all nine null directions from denominator-cleared Green solutions (Theorem 12.2). Lower half (Q6): the ordered five-factor configuration kernel multiplies prior to outer readout while retaining the central raw-to-Noether contact shift and four-frequency Fourier assembly; the left branch yields $\mathcal J_\infty$ on $\operatorname{Re}\lambda>0$ (Proposition 13.1), while the right branch applies $\ell_d$ on $0\le T<\tau(d,k,P,a)$ to produce $\Pi_{d,T}(P,\lambda)$ and the mother-Euler pencil (Theorem 13.2, vermilion focus) closing the voltage Cauchy update through $\mathcal G(P_k)$.

## 14 Minimal-Polynomial Sylvester Matrix Collapse and Phase-Free Dressed Photon Feed (Q7)

### 14.1 Commuting Integral Generators and the Minimal-Polynomial Quotient Resolvent

At static input clock $P_0=0$, the actual finite-window Noether matrix $\Pi_{d,T}((0,ik),\lambda)$ converges to $\Pi_d^{\mathrm{st}}(k,\lambda)$ for every $\operatorname{Re}\lambda>0$. This identification uses the same event and transfer in `static_polarization_window_limit`, with independent Laplace frequency $\lambda$ and the source operator-norm estimate behind (13.24). Classical solutions of Sylvester equations include semigroup integrals, series and contour formulas [[28]](#ref-28), [[29]](#ref-29). Here the full-$Y$ left and right generators from the mother action generate a common polynomial relation before either forcing or readout. The quotient inverse gives one finite weight vector for all $289^2$ Noether entries, and the actual created-state norm removes the preparation phase in the photon feed.

Fix a dressed event $d$ and physical momentum transfer $k\in\mathbb R^3$; the induced kinematic point $q=q(d,k)$ assigns left/right leg momenta $(p_+,p_-)=(p_d-k,p_d)$ (matching §13.2) while retaining the finite frame $F_d$ and complex resolvent frequencies $z=w=\zeta_d$. On $\mathcal B(\mathcal H)$, writing $G(\cdot,F_d,0,0)$ for the complete spatial generator at zero spectral shift and zero background perturbation, define left multiplication $\mathcal L_q(X)=G(p_d-k,F_d,0,0)X$, right multiplication $\mathcal R_q(X)=X\,G(p_d,F_d,0,0)$, and the joint bilateral Sylvester generator

\[
\mathcal T_q(X)=i\,\mathcal L_q(X)-i\,\mathcal R_q(X)
=i\,G(p_d-k,F_d,0,0)X-i\,X\,G(p_d,F_d,0,0),
\qquad X\in\mathcal B(\mathcal H). \tag{14.1}
\]

By operator associativity, $\mathcal L_q$ and $\mathcal R_q$ commute: $\mathcal L_q(\mathcal R_q(X))=G(p_d-k,F_d,0,0)X\,G(p_d,F_d,0,0)=\mathcal R_q(\mathcal L_q(X))$. At each momentum and frame, the complete spatial generator $G(\cdot,F_d,0,0)$ (covering both the reduced finite carrier and uncut-$Y$ outside words) is annihilated by its source-generated monic joint polynomial, making $\mathcal L_q$ and $\mathcal R_q$ integral over $\mathbb C$. Because scalar multiples and sums of commuting integral elements over $\mathbb C$ remain integral, $\mathcal T_q\in\operatorname{End}_{\mathbb C}(\mathcal B(\mathcal H))$ is algebraic over $\mathbb C$ and possesses a unique monic minimal polynomial

\[
P_q(X)=\operatorname{minpoly}_{\mathbb C}(\mathcal T_q)\in\mathbb C[X],
\qquad N_q=\deg P_q<\infty,
\qquad P_q(\mathcal T_q)=0. \tag{14.2}
\]

Crucially, $P_q(X)$ is extracted intrinsically from $\mathcal T_q$ **before choosing any field readout slot $e_i$ or external force slot $e_j$**.

Off the imaginary axis ($\operatorname{Re}\lambda\ne 0$), $\lambda I-\mathcal T_q$ admits the continuous two-sided resolvent $\mathcal S_q(\lambda)=(\lambda I-\mathcal T_q)^{-1}$ on $\mathcal B(\mathcal H)$. Dividing $P_q(X)$ by the monic linear factor $(X-\lambda)$ gives $P_q(X)=(X-\lambda)Q_{q,\lambda}(X)+P_q(\lambda)$ with $\deg Q_{q,\lambda}=N_q-1<\deg P_q$. Evaluating at $X=\mathcal T_q$ yields $(\mathcal T_q-\lambda I)Q_{q,\lambda}(\mathcal T_q)=-P_q(\lambda)I$: if $P_q(\lambda)=0$, left-multiplying by $-\mathcal S_q(\lambda)$ would force $Q_{q,\lambda}(\mathcal T_q)=0$, contradicting minimality of $\deg P_q$. Spectral non-vanishing is thus locked unconditionally:

\[
\operatorname{Re}\lambda\ne 0
\implies P_q(\lambda)\ne 0. \tag{14.3}
\]

Pass to the $N_q$-dimensional commutative quotient algebra $\mathcal A_q=\mathbb C[X]/(P_q(X))$ with residue $\bar X=X\bmod P_q$ and standard power basis $\{1,\bar X,\ldots,\bar X^{N_q-1}\}$. Define the quotient pencil $p_q(\lambda)=\lambda-\bar X\in\mathcal A_q$ and quotient Green element

\[
g_q(\lambda)=\frac{1}{P_q(\lambda)}\,\overline{P_q(X)/_{\mathrm m}(X-\lambda)}\in\mathcal A_q,
\qquad p_q(\lambda)\,g_q(\lambda)=1\quad(\operatorname{Re}\lambda>0), \tag{14.4}
\]

where $/_{\mathrm m}$ denotes monic polynomial division by $(X-\lambda)$. Projecting $P_q(X)=(X-\lambda)(P_q(X)/_{\mathrm m}(X-\lambda))+P_q(\lambda)$ modulo $P_q(X)$ immediately gives $(\lambda-\bar X)\,\overline{P_q(X)/_{\mathrm m}(X-\lambda)}=P_q(\lambda)\cdot 1$, and scaling by $P_q(\lambda)^{-1}\ne 0$ from (14.3) proves $p_q(\lambda)g_q(\lambda)=1$ with zero external invertibility input.

Let $M_q(\lambda)=\operatorname{LMat}_{\mathcal A_q}(p_q(\lambda))\in\mathbb C^{N_q\times N_q}$ be the left-multiplication matrix of $p_q(\lambda)$ in the power basis $\{1,\bar X,\ldots,\bar X^{N_q-1}\}$. Because the left regular representation is an algebra homomorphism, $M_q(\lambda)\operatorname{LMat}_{\mathcal A_q}(g_q(\lambda))=I_{N_q}$, so $M_q(\lambda)^{-1}=\operatorname{LMat}_{\mathcal A_q}(g_q(\lambda))$. Setting $e_0=(1,0,\ldots,0)^{\mathsf T}\in\mathbb C^{N_q}$ and defining the rational weight vector

\[
w_q(\lambda)=M_q(\lambda)^{-1}e_0\in\mathbb C^{N_q},
\qquad (e_0)_a=\delta_{a,0}\quad(0\le a<N_q), \tag{14.5}
\]

identifies $w_q(\lambda)$ with the power-basis coordinate vector of $g_q(\lambda)=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\bar X^a$. Pushing forward along the well-defined algebra action $\Phi_q:\mathcal A_q\to\operatorname{End}_{\mathbb C}(\mathcal B(\mathcal H))$, $\bar X^a\mapsto\mathcal T_q^a$, turns $\Phi_q(g_q(\lambda))=\mathcal S_q(\lambda)$ into an exact finite operator expansion on $\operatorname{Re}\lambda>0$:

\[
\mathcal S_q(\lambda)(A)=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\,\mathcal T_q^a(A),
\qquad \forall\,A\in\mathcal B(\mathcal H),\;\operatorname{Re}\lambda>0. \tag{14.6}
\]

### 14.2 Two-Stage Driven Half-Inverse and the Full $289\times 289$ Static Noether Quadratic Form

Returning to §13's five-factor kernel (13.15) at static clock $P_0=0$, for any readout slot $e_i$ and force slot $e_j$ ($0\le i,j<289$), denote the raw initial vertex by $I_q^{\mathrm{raw}}(e_i)$, the static Noether contact-plus-slope initial operator by $I_q^{\mathrm{Noether}}(e_i,e_j)=I_q^{\mathrm{slope}}(e_i,e_j)+\Delta C_q^{\mathrm{Noether}}(e_i,e_j)$, and the bilateral current-drive superoperator induced by $e_j$ by

\[
\mathcal D_q(e_j)(B)=-J_L(q,e_j)\,B+B\,J_R(q,e_j),
\qquad B\in\mathcal B(\mathcal H), \tag{14.7}
\]

where $J_L(q,e_j),J_R(q,e_j)$ are the reduced left/right propagator current insertions. Performing the inner and outer Laplace resolvent reductions on $\operatorname{Re}\lambda>0$ yields the exact two-stage Sylvester cascade

\[
\mathcal H_q^{\mathrm{Noether}}(e_i,e_j;\lambda)
=\mathcal S_q(\lambda)\Bigl(I_q^{\mathrm{Noether}}(e_i,e_j)
+\mathcal D_q(e_j)\bigl(\mathcal S_q(\lambda)(I_q^{\mathrm{raw}}(e_i))\bigr)\Bigr). \tag{14.8}
\]

Equation (14.8) makes the rational pole structure transparent: $I_q^{\mathrm{Noether}}(e_i,e_j)$ undergoes a single outer resolvent $\mathcal S_q(\lambda)$, whereas $I_q^{\mathrm{raw}}(e_i)$ undergoes inner propagation $\mathcal S_q(\lambda)$, bilateral driving $\mathcal D_q(e_j)$ on both legs, and outer propagation $\mathcal S_q(\lambda)$.

Evaluating the creation-minus-background functional $\ell_d$ (Eq. (13.11)) on the $\lambda$-independent finite generator words defines the **direct moment vector** $D_{d,k}^{(ij)}\in\mathbb C^{N_q}$ and **driven moment matrix** $R_{d,k}^{(ij)}\in\mathbb C^{N_q\times N_q}$:

\[
\begin{aligned}
D_{d,k;a}^{(ij)}&=\ell_d\!\Bigl(\mathcal T_q^a\bigl(I_q^{\mathrm{Noether}}(e_i,e_j)\bigr)\Bigr),\\
R_{d,k;ab}^{(ij)}&=\ell_d\!\Bigl(\mathcal T_q^a\Bigl(\mathcal D_q(e_j)\bigl(\mathcal T_q^b(I_q^{\mathrm{raw}}(e_i))\bigr)\Bigr)\Bigr),
\end{aligned}
\qquad 0\le a,b<N_q. \tag{14.9}
\]

Every entry of (14.9) is an exact source-word expectation in $\ell_d$—neither an externally supplied realization matrix nor a boost to an auxiliary rest frame.

<a id="thm-14-1"></a>

**Theorem 14.1 (finite Sylvester matrix collapse of the full $289\times 289$ static Noether polarization tensor).** For every dressed event $d$, physical momentum transfer $k\in\mathbb R^3$, complex frequency $\lambda\in\mathbb C$ with $\operatorname{Re}\lambda>0$, and all $289\times 289$ field pairs $0\le i,j<289$, the static half-line Noether polarization entry $\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}=\ell_d(\mathcal H_q^{\mathrm{Noether}}(e_i,e_j;\lambda))$ equals, with zero truncation error, the finite bilinear quadratic form

\[
\boxed{\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}
=w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}\,w_q(\lambda)
=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\,D_{d,k;a}^{(ij)}
+\sum_{a=0}^{N_q-1}\sum_{b=0}^{N_q-1}w_{q,a}(\lambda)\,w_{q,b}(\lambda)\,R_{d,k;ab}^{(ij)}.} \tag{14.10}
\]

**Proof.** Fix $\operatorname{Re}\lambda>0$. Applying (14.6) to the inner argument $I_q^{\mathrm{raw}}(e_i)$ gives $\mathcal S_q(\lambda)(I_q^{\mathrm{raw}}(e_i))=\sum_{b=0}^{N_q-1}w_{q,b}(\lambda)\mathcal T_q^b(I_q^{\mathrm{raw}}(e_i))$. Because $\mathcal D_q(e_j)$ and $\mathcal T_q^a$ are $\mathbb C$-linear on $\mathcal B(\mathcal H)$, substituting into (14.8) and applying (14.6) to both outer terms yields

\[
\mathcal H_q^{\mathrm{Noether}}(e_i,e_j;\lambda)
=\sum_{a=0}^{N_q-1}w_{q,a}(\lambda)\,\mathcal T_q^a\bigl(I_q^{\mathrm{Noether}}(e_i,e_j)\bigr)
+\sum_{a=0}^{N_q-1}\sum_{b=0}^{N_q-1}w_{q,a}(\lambda)w_{q,b}(\lambda)\,
\mathcal T_q^a\!\Bigl(\mathcal D_q(e_j)\bigl(\mathcal T_q^b(I_q^{\mathrm{raw}}(e_i))\bigr)\Bigr).
\]

Applying the continuous linear observer $\ell_d$ and substituting (14.9) establishes (14.10). All $289^2$ entries share the single $N_q\times N_q$ companion-pencil inverse $M_q(\lambda)^{-1}$ through $w_q(\lambda)$. □

The same static matrix also admits an explicit polynomial evaluation. The two source joint polynomials give a monic annihilator of the Sylvester generator whose degree is the product of their degrees. Removing any factor at the chosen Laplace frequency gives finite coefficients for the whole Noether matrix. The declarations `ActualExplicitEvolutionPolynomial` and `explicit_full_noether_polarization` give this construction for the original event and all field pairs.

<a id="ex-14-1"></a>

**Example 14.1 (pen-and-paper check of the $N_q=2$ companion-pencil inverse and two-stage rational poles).** To see (14.4)–(14.5) and (14.10) concretely, suppose on a two-level invariant subsector $P_q(X)=X^2+c_1X+c_0$ ($N_q=2$). In the power basis $\{1,\bar X\}$ of $\mathcal A_q=\mathbb C[X]/(P_q(X))$, $\bar X\cdot 1=\bar X$ and $\bar X\cdot\bar X=-c_0-c_1\bar X$, so

\[
\operatorname{LMat}_{\mathcal A_q}(\bar X)=
\begin{pmatrix}0&-c_0\\1&-c_1\end{pmatrix},
\qquad
M_q(\lambda)=\lambda I_2-\operatorname{LMat}_{\mathcal A_q}(\bar X)=
\begin{pmatrix}\lambda&c_0\\-1&\lambda+c_1\end{pmatrix},
\]

with $\det M_q(\lambda)=\lambda(\lambda+c_1)+c_0=P_q(\lambda)\ne 0$ on $\operatorname{Re}\lambda>0$ by (14.3). Inverting the $2\times 2$ matrix on $e_0=(1,0)^{\mathsf T}$ gives directly

\[
w_q(\lambda)=M_q(\lambda)^{-1}e_0
=\frac{1}{P_q(\lambda)}\begin{pmatrix}\lambda+c_1\\1\end{pmatrix},
\]

matching the power-basis coordinates $(\lambda+c_1,\,1)^{\mathsf T}$ of $(X^2+c_1X+c_0)/_{\mathrm m}(X-\lambda)=X+(\lambda+c_1)$. Substituting $w_q(\lambda)$ into (14.10) expands $\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}$ explicitly as

\[
\Pi_d^{\mathrm{st}}(k,\lambda)_{ij}
=\frac{(\lambda+c_1)D_{d,k;0}^{(ij)}+D_{d,k;1}^{(ij)}}{P_q(\lambda)}
+\frac{(\lambda+c_1)^2R_{d,k;00}^{(ij)}+(\lambda+c_1)\bigl(R_{d,k;01}^{(ij)}+R_{d,k;10}^{(ij)}\bigr)+R_{d,k;11}^{(ij)}}{P_q(\lambda)^2},
\]

separating single-resolvent contact/slope poles $P_q(\lambda)^{-1}$ from double-resolvent driven poles $P_q(\lambda)^{-2}$ with zero improper time integration.

### 14.3 Dressing-Phase Cancellation and Source-Prepared Photon Connected Feed

Theorem 14.1 collapses the static polarization matrix; the final step of Q7 proves that contracting the dressed connected current with any source-native frequency polarization cancels the electromagnetic dressing phase automatically and feeds directly into the two-leg prepared photon amplitude.

In a dressed event $d=(\epsilon_d>0,\ p_d\in\mathbb R^3,\ F_d,\ m_d\in\mathbb N,\ \zeta_d\in\mathbb C,\ \operatorname{Im}\zeta_d\ne 0)$ (matching (13.8), where $\epsilon_d>0$ is the positivity witness of preparation precision), denote the shared source profile by $\phi_d=\phi_{\epsilon_d}$, the background state by $v_d=\psi_{\mathrm{prep}}(\phi_d)$, the unnormalized completed preparation leg by $\ell_{\mathrm{leg}}(d)\in\mathcal H$, the dressed excitation by $g_d$, and the positive creation-branch electromagnetic character value by $\chi_{\mathrm{EM}}^+\in\mathbb C$. The unit dressed state $u_d\in\mathcal H$ ($\|u_d\|_{\mathcal H}=1$) equals $u_d=c_d\,\ell_{\mathrm{leg}}(d)$ with $c_d=\|g_d\|_{\mathcal H}^{-1}\chi_{\mathrm{EM}}^+$.

Before any Green inversion or photon readout takes place, $\|c_d\,\ell_{\mathrm{leg}}(d)\|_{\mathcal H}=|c_d|\,\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}=1$ forces $\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}>0$ and eliminates the arbitrary complex phase of $\chi_{\mathrm{EM}}^+$:

\[
\overline{c_d}\,c_d=|c_d|^2=\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}^{-2}>0. \tag{14.11}
\]

Across all $0\le i<289$, the dressed connected current subtracts background from created expectations on the full current vertex $V_{\mathrm{curr}}(e_i;p_d,-k)$:

\[
J_{d,k;i}^{\mathrm{conn}}
=\bigl\langle u_d,\,V_{\mathrm{curr}}(e_i;p_d,-k)u_d\bigr\rangle_{\mathcal H}
-\bigl\langle v_d,\,V_{\mathrm{curr}}(e_i;p_d,-k)v_d\bigr\rangle_{\mathcal H}.
\]

For any photon branch $b\in\{0,1\}$, nonzero frequency scale $\epsilon_{\mathrm{ph}}\in\mathbb R\setminus\{0\}$, parameter $s\in\mathbb R$, and propagation direction $n\in\mathbb R^3$, let $e_{\mathrm{nat}}^{(b,\epsilon_{\mathrm{ph}},s,n)}\in\mathbb C^{289}$ denote the source-native frequency polarization vector.

<a id="thm-14-2"></a>

**Theorem 14.2 (dressing-phase cancellation and source-native connected photon feed).** For every dressed event $d$, physical momentum transfer $k\in\mathbb R^3$, and source-native polarization parameters $(b,\epsilon_{\mathrm{ph}},s,n)$ with $\epsilon_{\mathrm{ph}}\ne 0$, the 289-slot contraction of the connected current equals the phase-free prepared photon amplitude minus the shared-profile background photon pair:

\[
\boxed{\sum_{i=0}^{288}e_{\mathrm{nat},i}^{(b,\epsilon_{\mathrm{ph}},s,n)}\,J_{d,k;i}^{\mathrm{conn}}
=\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}^{-2}\,
\mathcal A_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;d)
-\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;v_d,v_d),} \tag{14.12}
\]

where $\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;x,y)$ is the whole-configuration photon bilinear pair with both finite Green legs intact, and $\mathcal A_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;d)=\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;\ell_{\mathrm{leg}}(d),\ell_{\mathrm{leg}}(d))$.

**Proof.** Whenever $\epsilon_{\mathrm{ph}}\ne 0$, for all $x,y\in\mathcal H$ summing the configuration first-jet current readout over $i=0,\ldots,288$ identifies $\sum_{i=0}^{288}e_{\mathrm{nat},i}^{(b,\epsilon_{\mathrm{ph}},s,n)}\langle x,V_{\mathrm{curr}}(e_i;p_d,-k)y\rangle_{\mathcal H}=\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;x,y)$. Sesquilinearity on $x=y=u_d=c_d\,\ell_{\mathrm{leg}}(d)$ together with (14.11) gives

\[
\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;u_d,u_d)
=(\overline{c_d}\,c_d)\,\mathcal P_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}\bigl(p_d,-k;\ell_{\mathrm{leg}}(d),\ell_{\mathrm{leg}}(d)\bigr)
=\|\ell_{\mathrm{leg}}(d)\|_{\mathcal H}^{-2}\,\mathcal A_{\mathrm{ph}}^{(b,\epsilon_{\mathrm{ph}},s,n)}(p_d,-k;d).
\]

Subtracting the corresponding identity at $x=y=v_d$ and distributing the finite sum over subtraction yields (14.12). □

Finally, a dressed event tuple $d=(\epsilon_d>0,\ p_d,\ F_d,\ m_d\in\mathbb N,\ \zeta_d,\ \operatorname{Im}\zeta_d\ne 0)$ carries a discrete Volterra Yukawa cutoff index $m_d\in\mathbb N$. To seal the exact meaning of “cutoff-free” on the configuration-space response side, for any replacement cutoff integer $m'\in\mathbb N$ let $d[m']:=(\epsilon_d,\ p_d,\ F_d,\ m',\ \zeta_d)$ denote the event with $m_d$ replaced by $m'$ and all remaining source data unchanged.

<a id="thm-14-3"></a>

**Theorem 14.3 (exact Yukawa-cutoff elimination for static polarization, the physical $N=3$ causal window, and sixth-order infrared return).** For every dressed event $d$ and every discrete cutoff integer $m'\in\mathbb N$, the following three cutoff-invariance identities hold:

1. **Full $289\times 289$ static polarization invariance**: for every momentum transfer $k\in\mathbb R^3$ and complex parameter $\lambda\in\mathbb C$, the Lean Bochner definition satisfies the following identity. The integral converges for $\operatorname{Re}\lambda>0$.

\[
\Pi_{d[m']}^{\mathrm{st}}(k,\lambda)=\Pi_d^{\mathrm{st}}(k,\lambda)\in\mathbb C^{289\times 289}. \tag{14.13}
\]

2. **Physical three-fermion ($N=3$) five-leg causal window invariance**: denoting by $\mathcal W_d^{N=3}(\ell_{\mathrm{comp}},k,\lambda,T;f_{\mathrm{read}},f_{\mathrm{force}})\in\mathbb C$ the finite-time five-leg causal response window evaluated between the physical three-fermion electron state $\Psi_e^{N=3}(p_d,\zeta_d,\ell_{\mathrm{comp}})$ and the shared source Noether background, for every composite leg $\ell_{\mathrm{comp}}$, $k\in\mathbb R^3$, $\lambda\in\mathbb C$, $T\in\mathbb R$, and $f_{\mathrm{read}},f_{\mathrm{force}}\in\mathbb R^{289}$,

\[
\mathcal W_{d[m']}^{N=3}(\ell_{\mathrm{comp}},k,\lambda,T;f_{\mathrm{read}},f_{\mathrm{force}})
=\mathcal W_d^{N=3}(\ell_{\mathrm{comp}},k,\lambda,T;f_{\mathrm{read}},f_{\mathrm{force}}). \tag{14.14}
\]

3. **Uniform sixth-order infrared return across all cutoff labels**: one matrix function $G_d$ is analytic at zero. On a single neighborhood in the right half-plane, $z^4\Pi_{d[m']}^{\mathrm{st}}(0,z)=G_d(z)$ for every cutoff label. For **every** $m'\in\mathbb N$, along the punctured right half-plane $\{z\in\mathbb C:\operatorname{Re}z>0\}$,

\[
\lim_{\substack{z\to 0\\\operatorname{Re}z>0}}z^6\,\Pi_{d[m']}^{\mathrm{st}}(0,z)=L_d=0. \tag{14.15}
\]

**Proof and exact scope boundary.** Both the full-$Y$ kinematic map $q(d[m'],k)=q(d,k)$ and the dressed Euler observer $\ell_{d[m']}=\ell_d$ operate on the full-$Y$ source object where finite Volterra truncation has already been removed, so neither reads $m'$ definitionally; extensionality across $0\le i,j<289$ immediately gives (14.13). Likewise, the five-leg full Noether variation, the physical three-fermion electron state (depending only on $(p_d,\zeta_d,\ell_{\mathrm{comp}})$), and the shared background state (depending only on $\epsilon_d$) are definitionally independent of $m'$, yielding (14.14). The original matrix has the fourth-order analytic representative $G_d$ by `actual_fourth_ir_regularization`. Substituting (14.13) at $k=0$ gives the same representative on the same neighborhood for all labels. Analyticity then gives $z^2G_d(z)	o0$, proving (14.15). Three formal scope boundaries are maintained strictly: (i) in Theorem 14.1, $P_q(X)$ is the abstract monic minimal polynomial over $\mathbb C$ guaranteed by integrality (proving exact finite-word collapse without evaluating literal polynomial degrees here); (ii) Theorem 14.3 eliminates cutoff dependence in (14.13)–(14.15), whereas the prepared photon pair $\mathcal P_{\mathrm{ph}}$ in Theorem 14.2 (Eq. (14.12)) retains explicit finite Green legs indexed by $m_d$ (so cutoff invariance is not claimed for (14.12), nor are moments transplanted between $\ell_d$ and the physical $N=3$ preparation); and (iii) matching $e_{\mathrm{nat}}^{(b,\epsilon_{\mathrm{ph}},s,n)}$ to the corrected physical light cone and the source-native Thomson formula for $\alpha(0)$ belongs to Case 3, with each theorem module certified on its own upstream import chain under the three standard Lean axioms. □

![Figure 6: Commuting integral evolution, minimal-polynomial quotient inverse, 289x289 Sylvester collapse, and Yukawa-cutoff elimination.](figures/fig05-sylvester-collapse-v2-en.svg)

**Figure 6. Commuting integral evolution, minimal-polynomial quotient inverse, $289\times 289$ Sylvester collapse, and Yukawa-cutoff elimination.** Top row (left to right): integrality of commuting left/right multiplications $\mathcal L_q,\mathcal R_q$ extracts the monic minimal polynomial $P_q(X)$ of $\mathcal T_q$ prior to any readout or force (covering uncut-$Y$ outside words), while $\mathcal A_q=\mathbb C[X]/(P_q(X))$ produces the quotient inverse $g_q(\lambda)$ and $N_q$-dimensional companion-pencil weights $w_q(\lambda)=M_q(\lambda)^{-1}e_0$ with zero external certificate. Second row: single-resolvent contact/slope direct moments $D$ (left) and double-resolvent bilaterally driven moments $R$ (right). Central vermilion focus panel: all $289\times 289$ static polarization entries collapse to $w_q(\lambda)^{\mathsf T}D_{d,k}^{(ij)}+w_q(\lambda)^{\mathsf T}R_{d,k}^{(ij)}w_q(\lambda)$ (Theorem 14.1). Bottom three boxes: phase-free photon connected feed (Theorem 14.2), exact Yukawa-cutoff elimination across static, $N=3$ window, and sixth-order IR limits (Theorem 14.3, gold accent), and zero-knob handoff to Case 3.

## 15 Five-Axis Literature Synthesis and Zero-Knob Handoff Contract

### 15.1 Five-Axis Literature Synthesis: Classical Inheritance and Structural Advances

With all seven propositions (Q1–Q7) proved, we situate our results systematically along five classical streams of mathematical physics (detailed bibliographic verification records appear in the accompanying literature ledger), separating inherited classical tools from the structural advances established here inside a parameter-free unified field theory.

1. **Cutoff-free one-loop polarization, zero-counterterm distributional kernels, and Lorentzian non-self-adjoint structure** [[4]](#ref-4), [[5]](#ref-5), [[6]](#ref-6), [[7]](#ref-7), [[8]](#ref-8). Schwinger's proper-time representation [[4]](#ref-4) and the Chamseddine–Connes Euclidean spectral action $\operatorname{Tr}\chi(D/\Lambda)$ [[8]](#ref-8) extract bosonic couplings via an ultraviolet scale $\Lambda$ or asymptotic heat-kernel expansions; Epstein–Glaser causal perturbation theory [[5]](#ref-5) avoids momentum cutoffs in position space yet leaves degree-$\omega$ free polynomial counterterms whenever singular order $\omega\ge 0$; DeWitt [[6]](#ref-6) and Abbott [[7]](#ref-7) established covariant background-field second variations, constrained Green functions, and the separation between connected generating functionals and 1PI effective actions. Working in Lorentzian physical time with an independent variational dual $\chi$ (never setting $\chi=\psi^\dagger$), we prove exact closed-trace reduction for arbitrary-length ordered gauge words on the finite chiral fiber with zero cutoffs (Theorem 3.2), lock the $\delta'_0,\delta_0$ instantaneous matrices $(P_1,P_0)$ in (7.9) uniquely via $|\lambda|=5c$ contour integrals and high-frequency mother identities with zero free subtraction constants, and identify the 1,445-slot first-jet second Fréchet derivative entry by entry with $H_{289}(p)$ (Proposition 12.1).
2. **Chiral finite-fiber traces, closed-time-path (in-in) prepared states, and antisymmetric Fock word order** [[9]](#ref-9), [[10]](#ref-10), [[11]](#ref-11), [[12]](#ref-12), [[13]](#ref-13). Adler [[9]](#ref-9) and Bell–Jackiw [[10]](#ref-10) related momentum routing and regularization in the divergent triangle loop to the Ward surface term; Schwinger [[11]](#ref-11) and Keldysh [[12]](#ref-12) formulated forward-backward real-time expectations in prepared states; Tasaki [[13]](#ref-13) gave standard second-quantized $d\Gamma(A)$ action formulas on fermionic Fock sectors. Merging these threads on our one-way $Y_R$ algebra, Theorem 3.2 operates purely algebraically at fixed leg momenta without permuting distinct vertices; Proposition 4.1 proves that one-particle Fock expectations require multiplying the entire word prior to state compression, whereas intermediate rank-one projections $P_w$ erase the $-1$ open return and corrupt $6$ of $16$ benchmark gauge words; and §§6 and 13 evaluate nonequilibrium zero-temperature prepared responses directly through independent left and right evolution legs.
3. **Covariant derivative expansions (CDE), heavy-mode decoupling, full-momentum Schur recovery, and non-commuting collective origin limits** [[14]](#ref-14), [[15]](#ref-15), [[16]](#ref-16), [[17]](#ref-17), [[18]](#ref-18), [[19]](#ref-19), [[20]](#ref-20), [[21]](#ref-21), [[31]](#ref-31), [[32]](#ref-32). Gaillard [[14]](#ref-14), Cheyette [[15]](#ref-15), and Henning–Lu–Murayama [[16]](#ref-16) organized one-loop functional traces via local covariant derivative expansions while separating internal traces $\operatorname{tr}$ from functional traces $\operatorname{Tr}\log$; Appelquist–Carazzone [[17]](#ref-17) proved infrared heavy-field decoupling; Schur [[18]](#ref-18), Feshbach [[19]](#ref-19), Dirac [[20]](#ref-20), and Takahashi [[21]](#ref-21) established block elimination, subspace effective Hamiltonians, constrained reduction, and finite-momentum-transfer Ward identities; Luttinger [[31]](#ref-31) and Weldon [[32]](#ref-32) established the distinction between static and homogeneous temporal-metric response and between plasma screening and long-wavelength collective response. Strictly separating internal traces (§3), single-matter coupled Schur complements (§§5, 12), and wave-packet integrals (§§7–11) without $1/M^2$ truncation, Theorem 5.2 restores all 289 mother equations symbolically via $H_{289}F=J_{\mathrm{src}}S_{55}$ (retaining 32 nonzero Ward scalar source entries), Theorem 5.3 and §5.5 extract the dual-time-scale five-dimensional origin kernel and the $18N/125$ vs. $33N/125$ ray limit (Figure 2), and Theorem 12.2 recovers contact, five light modes, and all nine null modes from denominator-cleared Green solutions via an oblique coordinate direct sum.
4. **Sharp-window covariogram geometry, Gershgorin homotopy inertia locking, and anti-wrapping rigorous interval proofs** [[22]](#ref-22), [[23]](#ref-23), [[24]](#ref-24), [[25]](#ref-25), [[26]](#ref-26). Galerne's set-covariogram boundary formula [[22]](#ref-22) explains the geometric origin of the $|s|$ cusp on shifted ball intersections; Sylvester's law of inertia [[23]](#ref-23) and Gershgorin's disk theorem [[24]](#ref-24) isolate eigenvalue signs of symmetric forms; Tucker [[25]](#ref-25) and Gómez-Serrano [[26]](#ref-26) established outward-rounded interval arithmetic plus analytic tail bounds as rigorous mathematical proof and highlighted how evaluation order suppresses wrapping blow-up. Retaining the bulk integral and both spherical boundary fluxes (Example 1.1b and §10.2's $+2.38\times 10^{-20}$ boundary-flux sign flip), solving 11,760 source-contracted series coefficients recursively prior to readout, and enclosing `connected` directly from centered Gram data locks the $4.6\times 10^{-22}$-wide enclosures and $(2,1,0)$ inertia via continuous homotopy (Theorem 1.2, Figure 4).
5. **Nonequilibrium Kubo response, Sylvester equations, quotient collapse, and cutoff elimination** [[1]](#ref-1), [[2]](#ref-2), [[3]](#ref-3), [[27]](#ref-27), [[28]](#ref-28), [[29]](#ref-29), [[30]](#ref-30). Kubo [[27]](#ref-27) formulated retarded linear response; Rosenblum [[28]](#ref-28) and Bhatia–Rosenthal [[29]](#ref-29) developed spectral criteria and semigroup integral inverses for operator Sylvester equations; de Moura–Ullrich [[30]](#ref-30) built Lean 4's small-kernel verification architecture. Building on the flagship monograph [[1]](#ref-1), Case 1 [[2]](#ref-2), and the first edition [[3]](#ref-3), Theorem 13.2 proves the unnormalized mother-Euler pencil $[W_T(P_0,\lambda)K_{\mathrm{nat}}(P)-\Pi_{d,T}(P,\lambda)]a$ on $0\le T<\tau(d,k,P,a)$, while Theorems 14.1–14.3 exploit commuting generator integrality in $\mathbb C[X]/(P_q(X))$ to collapse all $289^2$ static entries on $\operatorname{Re}\lambda>0$ into a finite quadratic form, cancel the dressing phase, and eliminate discrete Yukawa cutoffs with zero custom axioms in Lean `v4.33.0`.

**Table 3 Five-axis literature comparison and structural advances of the present work**

| Dialogue axis | Representative primary literature | Standard premise & treatment in classical frameworks | Structural advance & exact boundary in this work (Q1–Q7) |
| --- | --- | --- | --- |
| **Axis I: Cutoff-free polarization & zero-counterterm kernel** | Schwinger [[4]](#ref-4); Epstein–Glaser [[5]](#ref-5); DeWitt [[6]](#ref-6); Abbott [[7]](#ref-7); Chamseddine–Connes [[8]](#ref-8) | UV cutoff $\Lambda$ / heat-kernel asymptotics, or degree-$\omega$ free counterterms at $\omega\ge 0$; Euclidean self-adjoint Dirac operator | Lorentzian independent dual $\chi$; cutoff-free finite-fiber closed trace (Theorem 3.2); $|\lambda|=5c$ contour + high-frequency identities uniquely lock $\delta'_0,\delta_0$ matrices $P_1,P_0$ (zero counterterms); 1,445-slot second variation $=H_{289}(p)$ (Proposition 12.1) |
| **Axis II: Chiral fiber trace, in-in states & Fock order** | Adler [[9]](#ref-9); Bell–Jackiw [[10]](#ref-10); Schwinger [[11]](#ref-11); Keldysh [[12]](#ref-12); Tasaki [[13]](#ref-13) | Regularization of divergent continuum loops; two-branch nonequilibrium real-time Green functions; self-adjoint one-body $d\Gamma$ | Fixed-momentum finite-dimensional $P_6$ ideal identity; Fock readouts require whole-word multiplication before projection—mid-word $P_w$ erases $-1\mapsto 0$ and alters $6/16$ gauge words (Proposition 4.1) |
| **Axis III: CDE, decoupling, Schur recovery & collective origin limits** | Gaillard [[14]](#ref-14); Cheyette [[15]](#ref-15); Henning et al. [[16]](#ref-16); Appelquist–Carazzone [[17]](#ref-17); Schur [[18]](#ref-18); Feshbach [[19]](#ref-19); Dirac [[20]](#ref-20); Takahashi [[21]](#ref-21); Luttinger [[31]](#ref-31); Weldon [[32]](#ref-32) | Local $1/M^2$ operator truncation; orthogonal Feshbach projection; fast/slow limits in thermal baths or plasmas | Strict separation of $\operatorname{tr}$, coupled Schur $S_{55}$, and wave-packet integrals; $J_{\mathrm{src}}$ (32 Ward entries) restores all 289 rows (Theorem 5.2); 5D origin kernel isolates dual scales and $18N/125$ vs. $33N/125$ ray limits (Theorem 5.3, Figure 2); 4-momentum 9-null-mode recovery (Theorem 12.2) |
| **Axis IV: Sharp-lens geometry, inertia & interval proofs** | Galerne [[22]](#ref-22); Sylvester [[23]](#ref-23); Gershgorin [[24]](#ref-24); Tucker [[25]](#ref-25); Gómez-Serrano [[26]](#ref-26) | Set-covariogram perimeter derivative; disk eigenvalue isolation; outward interval arithmetic with analytic tails | Retains $|d|$ cusp plus zeroth and first spherical fluxes ($+2.38\times 10^{-20}$ flip on $e_2$); source-contracted recursion suppresses wrapping to $4.6\times 10^{-22}$ width and locks $(2,1,0)$ inertia via homotopy (Theorem 1.2) |
| **Axis V: Nonequilibrium Kubo, Sylvester, finite collapse & cut elimination** | Gao [[1]](#ref-1)–[[3]](#ref-3); Kubo [[27]](#ref-27); Rosenblum [[28]](#ref-28); Bhatia–Rosenthal [[29]](#ref-29); de Moura–Ullrich [[30]](#ref-30) | Equilibrium linear response; improper semigroup time integrals or external spectral-separation certificates | Unnormalized mother-Euler pencil on $0\le T<\tau$ (Theorem 13.2); $\mathbb C[X]/(P_q(X))$ collapses all $289^2$ static entries to a finite quadratic form, cancels dressing phase, and eliminates discrete Yukawa cutoffs (Theorems 14.1–14.3) |

### 15.2 Closing Synthesis and the Zero-Knob Handoff Contract to Case 3

Returning to the central question posed in the Introduction, all seven results interlock into one parameter-free chain:

- **Bare traces and prepared expectations keep their distinct jurisdictions, and word order is inviolable**: the identity operator's bare carrier trace $252$ and unit prepared expectation $1$ answer two distinct linear functionals; one-way chiral arrows vanish identically inside closed gauge traces (Theorem 3.2), register a nonzero real open return $-1$, and are erased to $0$ by any premature rank-one projection (Proposition 4.1).
- **Elimination drops no source, sharp windows drop no boundary flux, and whole-ball inertia transcends coordinate axes**: $289\to 103\to 55$ reduction writes back all 289 equations symbolically via $H_{289}F=J_{\mathrm{src}}S_{55}$ and isolates the dual-scale five-dimensional origin kernel and non-commuting metric ray limit (Theorems 5.2–5.3, Figure 2); the shifted two-ball lens retains the $|d|$ cusp, bulk integral, both spherical boundary fluxes, and the full complex Gram matrix, locking $\operatorname{Inertia}(\mathsf K_{\mathrm{raw}})=\operatorname{Inertia}(\mathsf K_{\mathrm{conn}})=(2,1,0)$ via rigorous enclosures and Gershgorin homotopy (Theorem 1.2, Figure 4; `mean` straddles zero on $e_2$ and is recorded separately).
- **From mother second variation to nonlinear causal pencils, finite Sylvester collapse, and cutoff-free IR return**: the 1,445-slot first-jet second variation equals $H_{289}(p)$ across $\mathbb C^4$ (Proposition 12.1), the four-momentum Schur kernel recovers contact and all nine null modes from denominator-cleared Green solutions (Theorem 12.2), creation-minus-background $\ell_d$ produces $\Pi_{d,T}(P,\lambda)$ and the mother-Euler pencil on $[0,\tau)$ (Theorem 13.2), and minimal-polynomial quotient inversion collapses the static half-line matrix into a finite quadratic form while feeding the phase-free photon amplitude and eliminating discrete Yukawa cutoffs (Theorems 14.1–14.3, Figure 6).

Every object handed off to Case 3 (source-native heavy-minus-light threshold decoupling, the $192/97$ electromagnetic factor-cancellation fraction, and single-pole physical frequency matching) is locked with zero adjustable knobs, as summarized in Table 4.

**Table 4 Zero-knob output contract handed off to downstream low-energy matching (Case 3)**

| Handoff object | Exact definition & theorem locus | Fixed constants / dimensions & irreducible structure | Downstream consumption in Case 3 |
| --- | --- | --- | --- |
| Source-native 5-channel spatial response & fixed window | Eqs. (1.2), (6.5), (7.15) (§7.4) | $c=\frac{6\sqrt{15}}{25},\;B=\sqrt2\epsilon_B,\;z=w=6c(1-i)$, ball overlap $r\in[0,2]$ | Cross-channel comparison of six external gauge/metric directions under identical windows |
| Fixed one-particle complex Gram & 3-sector orthogonal split | Eqs. (6.16)–(6.17), (8.8), App. D.1 | $58$ two-probe complex Gram weights & $20$ complex mean weights; $\mathrm{raw}=\mathrm{mean}+\mathrm{conn}$ | Preserves one global quantum preparation across all $k$-integrals without re-preparing per slice |
| Whole-ball curvature tensor & dyadic rational enclosures | Def. 1.1, Thm. 1.2, Eqs. (11.1)–(11.4) | $3\times 3$ real symmetric tensor, bulk + zeroth/first spherical fluxes, inertia $(2,1,0)$ | Low-energy polarization anisotropy benchmark and wave-packet boundary-flux audit |
| Four-complex-momentum mother Hessian & 9-null-mode recovery | Prop. 12.1, Thm. 12.2, Eqs. (12.12)–(12.20) | $p\in\mathbb C^4$, 5D origin kernel $N$ + $45+21+32$ complement, all 289 fields + 9 null modes | 72-component holonomic gauge-curvature readout and finite-momentum pole field recovery |
| Finite-window mother-Euler pencil, Sylvester matrix, photon feed & cut elimination | Thm. 13.2, Thms. 14.1–14.3, Eqs. (13.22),(14.10),(14.12)–(14.15) | $289\times 289$ quadratic form $w_q^{\mathsf T}D+w_q^{\mathsf T}Rw_q$; phase-free weight $\|\ell_{\mathrm{leg}}(d)\|^{-2}$; cutoff-free IR limit $L_d$ | Direct connected photon amplitude feed, cutoff-free sixth-order IR matching, and heavy-minus-light decoupling |

## Appendix A Explicit Reconstruction of the Linearized Mother Matrix and Graded Arrow Algebra

### A.1 Matter and Gauge Basis Orderings, Background Auxiliaries, and First-Jet Second Variation

The 252 complex matter basis elements are ordered first by spin index $0,1,2,3$ and then in ascending lexicographic order within $\Lambda^6,\Lambda^2,\Lambda^4$; consequently $P_6$ equals $1$ on the first $7$ diagonal slots of each $63$-dimensional spin block and $0$ on the remaining $56$. Setting $A_{ij}=E_{ij}-E_{ji}$, $S_{ij}=i(E_{ij}+E_{ji})$, and $D_{i-j}=i(E_{ii}-E_{jj})$, the 12 active $\mathfrak{su}(7)$ gauge generators are ordered as

\[
(A_{01},S_{01},A_{02},S_{02},A_{12},S_{12},D_{0-2},D_{1-2},A_{34},S_{34},D_{3-4},Y), \tag{A.1}
\]

with hypercharge generator $Y=i\operatorname{diag}(0,0,0,0,0,1,-1)$. The three spatial background $\mathfrak{su}(2)$ generators are

\[
(\tau_1,\tau_2,\tau_3)=\tfrac12(S_{01},A_{01},D_{0-2}-D_{1-2}), \tag{A.2}
\]

supported in colors $0,1,2$; the external gauge probe of §§6–11 uses the unhalved generator $S_{01}=2\tau_1$. Vertex index $0$ in (3.9) refers to $A_{01}$ on the temporal component $A_0$, not an alias for $dx^1S_{01}$.

On spacetime two-forms ordered as $(01,02,03,23,31,12)$, the background Hodge star reads

\[
*_e(f_1,f_2,f_3,f_4,f_5,f_6)
=(f_4/N,f_5/N,f_6/N,-Nf_1,-Nf_2,-Nf_3). \tag{A.3}
\]

On internal Lorentz two-forms in the same order $(01,02,03,23,31,12)$, the wedge bilinear form and swap operator are

\[
\begin{gathered}
J=\begin{pmatrix}0&I_3\\-I_3&0\end{pmatrix},\qquad
\mathcal W(X,Y)=\sum_{I,p}\epsilon_I X_{Ip}Y_{I,p^*},\\
\epsilon=(-1,-1,-1,1,1,1),\quad p^*=(3,4,5,0,1,2),
\end{gathered}
\]

with $p\in\{0,\ldots,5\}$, dual index $p^*$, and Lorentz signature signs $\epsilon_I$; $\mathcal W_g(X,Y)=\sum_p\langle X_p,Y_{p^*}\rangle_g$ uses Section 2's gauge pairing. On the nine-field classical background,

\[
\begin{gathered}
B_{\mathrm{gr},0}=\begin{pmatrix}0&I_3\\-NI_3&0\end{pmatrix},\qquad
\lambda_0=\operatorname{diag}(-N,-N,-N,s_0^2-1,s_0^2-1,s_0^2-1),\\
B_{g,0}=\frac{a^2}{\sigma N}(\tau_1,\tau_2,\tau_3,0,0,0),
\end{gathered}
\]

matching (5.1) at $A_j=a\tau_j$. Treating all 289 real fields and their spacetime first derivatives (1,445 real first-jet coordinates) as independent variables, extracting the $\varepsilon^2$ quadratic form of (2.4) and taking its Hessian under Euler sign $\partial_q\mathcal L-\partial_\mu\partial_{\partial_\mu q}\mathcal L$ at $p=(\lambda,ik)$ (substituting $k\mapsto -k$ on negative-phase columns) reconstructs $H_{289}(p)$ entry by entry (Proposition 12.1). Public evidence archives retain all 289 field names, jet coordinates, quadratic blocks, sparse Fourier–Jacobi entries, step-by-step auxiliary and Ward eliminations, all 158 density vertices, and the 252-dimensional free, one-way, and dual temporal matrices.

### A.2 Explicit Block-Lower-Triangular Algebra of Block-Diagonal Plus Arrow Operators

In the decomposition $(I-P_6)\mathcal M\oplus P_6\mathcal M$ ($224\oplus 28$), any operator $A=A_0+N$ with $[A_0,P_6]=0$ and $N=P_6N(I-P_6)$ is block-lower-triangular and multiplies as

\[
A=\begin{pmatrix}a&0\\n&b\end{pmatrix},\quad
A'=\begin{pmatrix}a'&0\\n'&b'\end{pmatrix},\quad
AA'=\begin{pmatrix}aa'&0\\na'+bn'&bb'\end{pmatrix}. \tag{A.4}
\]

Equation (3.7) is finite induction on (A.4). Every gauge vertex is strictly block-diagonal ($n=0$); among the 16 coframe vertices of the mother action, 4 diagonal coframe variations carry a nonzero lower-left arrow block $n\ne 0$ generated by $Y_R$ or its lapse multiple, while the other 12 are block-diagonal. Words containing coframe vertices must therefore decompose each factor individually via (A.4) rather than assuming every non-scalar vertex is block-diagonal.

The four nonzero entries of $w$ are given in (4.6) with classical background amplitude $2w$; full independent-dual bilinear densities carry $4\sqrt2$ and spin swap $S$, whereas unit-norm probabilistic Fock and continuum preparations normalize via (4.4) and (4.9).

## Appendix B Five-Dimensional Light-Kernel Entries, Symmetry Generators, and the Dynamical Metric Denominator

Writing $q=q_{\mathrm{ax}}$ and growth variable $u$, set

\[
\begin{aligned}
r&=80q^2/9+16u^2/3,& v&=160q^2/67+32u^2/11,\\
a&=2500q^2/81-40u^2,& r_m&=80iqu/9+16u^2/3,\\
v_m&=-80q^2/67-32u^2/11,& a_m&=-20iqu/3,\\
p_1&=-40q^2/3+80iqu/3+88u^2/9,&
p_2&=-550q^2/201-2438u^2/561.
\end{aligned} \tag{B.1}
\]

In the natural symmetry basis of §5.4 (Theorem 5.3), the complete quadratic and linear $5\times 5$ light-kernel matrices are

\[
K_2=\begin{pmatrix}
r&0&r_m&0&0\\
0&v&0&0&v_m\\
r_m&0&p_1&0&0\\
0&0&0&a&a_m\\
0&v_m&0&a_m&p_2
\end{pmatrix},\qquad
K_1=\begin{pmatrix}0&0&0&0&0\\0&0&0&0&0\\0&0&0&0&-8u\\0&0&0&0&0\\0&0&8u&0&0\end{pmatrix}. \tag{B.2}
\]

The kernel satisfies the Lorentzian formal transpose symmetry $K(-u,-q)^{\mathsf T}=K(u,q)$ rather than Euclidean self-adjointness on real $u$. Its five basis vectors are generated as $\varepsilon=0$ tangents along five deformation paths of $(\psi_0,\chi_0)$:

\[
\begin{array}{ll}
\bigl((1+\varepsilon)\psi_0,\,\chi_0/(1+\varepsilon)\bigr),&
\bigl(e^{i\varepsilon}\psi_0,\,e^{-i\varepsilon}\chi_0\bigr),\\
\bigl(e^{-\varepsilon\gamma_5}\psi_0,\,\chi_0e^{-\varepsilon\gamma_5}\bigr),&
\bigl(e^{-i\varepsilon\gamma_5}\psi_0,\,\chi_0e^{-i\varepsilon\gamma_5}\bigr),\\
\bigl(\psi_0,\,(1+i\varepsilon)\chi_0\bigr),&
\end{array} \tag{B.3}
\]

whose companion coframe, connection, auxiliary, and heavy-matter components are uniquely determined by the origin nullspace graph rather than set to zero by hand. All $289\times 5$ null columns, 103-coordinate readbacks, basis transforms, source matrices for (B.2), $(F,J_{\mathrm{src}})$ for (5.4), and rational $g_{00}$ numerators, denominators, and 289-row checks are archived in the public evidence package.

Crucially, although the leading small-momentum axial cone is $u^2=125q^2/162$ ((5.12)), evaluating the full dynamical denominator on that cone yields

\[
\begin{aligned}
&\frac{781250q^4}{59049}
(790649734875q^8+2150126388440q^6-1399007363958q^4\\
&\qquad+2468324502972q^2-3677642578800),
\end{aligned} \tag{B.4}
\]

which does not vanish identically for $q\ne 0$. Equation (5.12) therefore governs the leading long-wavelength cone, while exact poles at finite momentum require Appendix C's full sextic root and dynamical denominator.

## Appendix C Exact Sextic Coefficients, Pole-Free Global Reconstruction, and Off-Axis Verification

### C.1 Exact Integer Polynomial Coefficients of the Sextic Factor

For independent verification of (7.3), the sextic factor $\widehat F(U,T)=\sum_{j=0}^6a_j(T)U^j$ in $T=|k|^2/2$ has exact coefficients

\[
\begin{aligned}
a_6={}&103312130400,\\
a_5={}&88042059000T-1326196135152,\\
a_4={}&-2812927273200T^2+7146135894492T-10666675605312,\\
a_3={}&-348356420550T^3-4054836616488T^2
+54877225175424T-29979885888000,\\
a_2={}&8566446093750T^4+14320336749875T^3
-13331559163500T^2\\&\quad-44274070098000T-232960429728000,\\
a_1={}&7105914843750T^5+20863513093750T^4
-54526414743750T^3\\&\quad+54793278225000T^2
+333108288000000T-100383300000000,\\
a_0={}&988769531250T^6+3515380859375T^5
+10071269531250T^4\\&\quad+30510703125000T^3
-166986562500000T^2+77456250000000T.
\end{aligned} \tag{C.1}
\]

Across $|k|\le B$ ($T=|k|^2/2$), writing $U=T\,R(T)$ isolates a unique ratio root $R(T)\in[125/162-1/20,\,125/162+1/20]$ with $D=f_U\in[39/40,\,41/40]$, and the evaluation frequency $z=6c(1-i)$ stays strictly bounded away from both poles.

### C.2 Singularity-Free Global Polynomial Reconstruction and Off-Axis Substitution Checks

For the $j=0,1,2$ radial blocks $W_0,W_1,W_2$ of any response column, setting $C_2=(G_y^2W_2+3W_2)/2$ and $E_2=G_zC_2$ ($G_x,G_y,G_z$ denoting the shared rotation generators) yields the global three-momentum numerator polynomial free of $\sqrt{k_x^2+k_y^2}$ denominators:

\[
\begin{split}
\mathcal N_W={}&W_0-\frac{k_zW_1+k_xG_yW_1-k_yG_xW_1}{\sqrt2}
+\frac{2k_z^2-k_x^2-k_y^2}{4}W_2\\
&+\frac{k_xk_z}{2}G_yW_2-\frac{k_yk_z}{2}G_xW_2
+\frac{k_x^2-k_y^2}{2}C_2+\frac{k_xk_y}{2}E_2. \tag{C.2}
\end{split}
\]

Field columns use $G$ while source covectors use $-G^{\mathsf T}$ (reflecting negative spatial phase). Casimir projection, Lie-algebra commutation, reflection parity, and great-circle ODE uniqueness identify (C.2) pointwise over $\mathbb R^3$ with finite spherical transport.

Gauge fixing removes the $9$ reduced rows $(21,27,39,58,59,60,63,64,68)$. Although $\mathcal A$ vanishes on all $9$ rows, $\mathcal B$ carries nonzero off-axis products $k_xk_y,k_xk_z,k_yk_z$ on $6$ of them—forbidding naive extrapolation of axial zeros to $\mathbb R^3$. Their $9\times 9$ symmetric minor equals

\[
\det K_{\mathrm{removed}}=\frac{3\sqrt2}{1000}(18-25k_x^2), \tag{C.3}
\]

which is strictly nonzero across $|k|\le B=\sqrt2\epsilon_B$ (since $25k_x^2\le 50\epsilon_B^2\ll 18$), guaranteeing unique global solvability of $I_{1,\delta}$ in (7.8).

Two independent exact rational substitution checks validate the global columns: (1) at the off-axis rational ray $k=\sqrt2\rho(2,-3,6)/7$ ($\rho=1/131072$) and $\lambda=c(7-2i)$, substituting into all 289 mother rows (including 3 first-order and 6 second-order equations) leaves zero residual; (2) at $q=1/262144$, all 9 external source directions, 10 spatial jets up to degree two, 289 mother rows, and the full sextic factor vanish identically. Positive- and negative-phase inverse tables satisfy $P_+(q)=P_-(-q)$, flipping all odd radial derivatives.

## Appendix D Closed-Form Radial Gram Integration, Complex Rectangle Arithmetic, and Strong-Derivative Remainders

### D.1 Integration by Parts on Spherical Radial Weights and Pole-Order Recursion

Set $x=r^2/2$, $t_b(r)=b'(r)/r$, and $u_b(r)=(b''(r)-b'(r)/r)/r^2$, with origin values $b(0)=\sqrt{4\pi/3}$, $t_b(0)=-b(0)/5$, and $u_b(0)=b(0)/35$. Every radial combination $\alpha b^2+\beta b t_b+\delta_{bu}b u_b+\delta_{tt}t_b^2$ entering the complex Gram matrix reduces via the spherical-Bessel differential equation and two integrations by parts to $W(x)b(r)^2$, where

\[
A=\alpha-\frac{\delta_{bu}}{2x}+\frac{\delta_{tt}}{2x},\quad
B_1=\beta-\frac{5\delta_{bu}}{2x}+\frac{2\delta_{tt}}x-\delta'_{tt},\quad
W=A-\frac{B_1}{4x}-\frac{B_1'}2, \tag{D.1}
\]

with boundary terms $rB_1b^2/2$ and $\delta_{tt}bb'$ vanishing identically on all actual rational weights. Simple-pole factors $(r^2+\kappa^2)^{-1}$ are integrated analytically via (6.5), while higher-multiplicity poles $(r^2+\kappa^2)^{-m}$ follow the exact $\kappa$-derivative recursion

\[
R_{m+1}(\kappa)=-\frac1{2m\kappa}\partial_\kappa R_m(\kappa). \tag{D.2}
\]

Rational overlap moments on $r\in[0,2]$ equal

\[
M_j=\int_0^2r^j\bigl(r-3r^2/4+r^4/16\bigr)\,dr
=\frac{3\,2^{j+2}}{(j+2)(j+3)(j+5)}. \tag{D.3}
\]

Truncating $J(\kappa)=\sum_{j\ge 0}(-\kappa)^jM_j/j!$ at order $130$ bounds the $j$-th derivative tail across all poles $|\kappa|<7$ by $2^j(2/5)3^{14}14^{131}/131!$. Complex pole locations, $\pi$, rational partial-fraction weights, and series tails are evaluated in outward-rounded dyadic interval arithmetic; full real/imaginary enclosures are stored in the evidence archive while §§6.4 and 11.1 display decimal midpoints.

### D.2 Outward Complex Rectangle Multiplication and Cauchy Tail Composition

For complex numbers enclosed in dyadic rectangles $z=(z_R\pm a)+i(z_I\pm a)$ and $w=(w_R\pm b)+i(w_I\pm b)$, the product midpoint is $(z_Rw_R-z_Iw_I)+i(z_Rw_I+z_Iw_R)$ with outward half-width in both real and imaginary slots bounded by

\[
(|z_R|+|z_I|)b+a(|w_R|+|w_I|)+2ab, \tag{D.4}
\]

rounded outward onto the target dyadic grid across every ordered matrix operation. Given a uniform bound $M$ on $|q|=\rho_*$ and series truncation at order $N$, at $t=\epsilon_B/\rho_*<1$ the $a$-th radial-derivative tail is bounded by

\[
\frac{M(N+1)^a a!}{\rho_*^a}
\frac{t^{N+1-a}}{(1-t)^{a+1}}, \tag{D.5}
\]

combined with outer multi-index factorials and polydisk Cauchy radii. As explained in §9.4, (D.5) acts directly on the source-contracted solution $Y$ in (9.14) rather than on an uncontracted $112\times 112$ matrix inverse, preventing wrapping blow-up [[26]](#ref-26).

### D.3 Weighted Position Commutators on the First-Order Energy Domain

The ball-filtered state $\psi_0=G_D(i)e_{\mathrm{ball}}/\|G_D(i)e_{\mathrm{ball}}\|$ lies in $\operatorname{Dom}(H_{\mathrm{free}})$, whereas the sharp jump at $r=1$ precludes $H_{\mathrm{free}}^2\psi_0\in L^2$; nowhere does our proof assume $\psi_0\in\operatorname{Dom}(H^2)$. Fourth-order probe derivatives in (10.8) follow inductively from $X_\nu^j\psi_0$, $X_\nu^jH_{\mathrm{free}}\psi_0$, and bounded $[H_{\mathrm{free}},X_\nu]$: integral-remainder identities proved on smooth compactly supported cores extend by graph closure to $\psi_0$, with Hölder's inequality bounding all mixed directions uniformly.

Because $\|P_0v\|\le\|v\|$ and $\|(I-P_0)v\|\le\|v\|$ for $P_0=|\psi_0\rangle\langle\psi_0|$, `mean` remainders tighten directly from complex mean bounds while `raw` and `connected` combine their own zeroth- and first-order complex Gram data with the shared fourth-moment vector bound, keeping one identical prepared state across all three sectors.

## Appendix E Closed-Form Spherical Monomial Integrals and Dual-Track Verification Ledger

### E.1 Exact Spherical Gamma Integrals and Independent Fourier-Word Cross-Check

For nonnegative integers $a,b,c,d$, spherical monomial integrals under northern-hemisphere extension are given in closed form by Euler–Beta identities:

\[
\int_0^{2\pi}\cos^c\varphi\sin^d\varphi\,d\varphi
=\begin{cases}
\displaystyle\frac{2\Gamma((c+1)/2)\Gamma((d+1)/2)}{\Gamma((c+d+2)/2)},&c,d\text{ both even},\\[8pt]
0,&\text{otherwise},
\end{cases} \tag{E.1}
\]

\[
\int_0^1 t^a(1-t^2)^{b/2}\,dt
=\frac{\Gamma((a+1)/2)\Gamma((b+2)/2)}{2\Gamma((a+b+3)/2)}, \tag{E.2}
\]

multiplied by $2$ for the two paired hemispheres. Contracting the $9\times 9$ source tensor in (10.3) and integrating via (E.1)–(E.2) produces (10.7). An independent implementation expands every trigonometric polynomial into finite Laurent–Fourier words evaluated analytically at $1,i$, matching the bulk, first-flux, zeroth-flux, and total rational numbers digit for digit.

### E.2 Dual-Track Verification Inventory and Kernel Axiom Audit

Every theorem in this paper is machine-verified along its matching mathematical track:

1. **Lean 4 formal kernel proof track** (fixed toolchain Lean `v4.33.0` and mathlib `db584cd6d46c92f209a44c0f1c829460d327499d` [[30]](#ref-30)): covers Q1 ($P_6$ graded closed-trace Theorem 3.2 and Corollary 3.3), Q2 (Fock whole-word Proposition 4.1), Q3 (source-preserving Schur Theorem 5.2 and abstract five-dimensional light-kernel algebra), the consumed Case 1 L1–L17 continuum unitary evolution and operator-norm derivative interface [[2]](#ref-2), Q5 (1,445-slot mother second-variation Proposition 12.1 and four-complex-momentum nine-null-mode recovery Theorem 12.2), Q6 (real-field half-line Noether Proposition 13.1, nonlinear positive-window mother-Euler pencil Theorem 13.2, and voltage Cauchy update), and second-edition Q7 (minimal-polynomial quotient resolvent, full $289\times 289$ static Sylvester collapse Theorem 14.1, phase-free dressed photon connected feed Theorem 14.2, and exact Yukawa-cutoff elimination Theorem 14.3). Dedicated kernel audit modules (`ActualSourceFullSylvesterMatrixFullAudit`, `ActualSourceEMEventFeedFullAudit`, and `ActualSourceEventCutFullAudit`) verify that `source_green_inverse`, `source_inverse_matrix_return`, `source_full_noether_polarization_matrix`, `actual_preparation_weight`, `actual_dressed_photon_connected_feed`, `actual_cut_free_static`, `actual_cut_free_physical_n3_window`, and `actual_cut_free_sixth_ir_return` depend solely on `[propext, Classical.choice, Quot.sound]`, with zero `sorry` and zero custom physical axioms.
2. **Exact rational algebra and outward-rounded interval proof track** [[25]](#ref-25), [[26]](#ref-26): covers concrete $289\times 289$ elimination and dynamical $g_{00}$ write-back in Q3, together with Q4 (Theorem 1.2): sextic root isolation, 256/512-bit analytic radial Gram integration, 11,760 source-contracted coefficients and Cauchy tails, exact spherical Beta integration, five-channel `raw`/`mean`/`connected` diagonal intervals, uniform off-diagonal bounds, and the Gershgorin homotopy criterion. The standalone zero-dependency script `validation/verify_manuscript_formulas_v2.py` independently verifies in under 1 second the key rational identities, $5\times 5$ light-kernel polynomial determinant, implicit sextic derivatives, 76-digit boundary-flux cancellations, and Gershgorin disk separation; every public artifact is indexed by fixed Git object, SHA-256 digest, and byte length.

<!-- code-availability:begin -->
## Code and Data Availability

The second-edition [public claim map](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-map.json) and [reproduction guide](https://github.com/Sapientropic/H0mework/blob/d916604d403ae97e19779ff6fcd789e0184a468d/docs/low-energy-v2-reproduction.md) for Q1–Q7 are pinned to H0mework commit `d916604d403ae97e19779ff6fcd789e0184a468d` (Apache-2.0). Each entry gives the original source epoch, public declaration, downstream verification, resources, historical certification and public kernel acceptance. The [fixed first-edition map](https://github.com/Sapientropic/H0mework/blob/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/low-energy-release-map.json) supplies the original proofs and exact scientific evidence.

Use a fresh output directory for each check. These commands verify the fixed map and original certifications, then build and audit the second-edition scope Q7. The guide also links the inherited proofs and exact resources.

```sh
git checkout d916604d403ae97e19779ff6fcd789e0184a468d
python3 tools/low_energy_v2.py entry --paper low-energy-loop-response
for check in build trust types; do
  LEAN_NUM_THREADS=2 python3 tools/low_energy_v2.py "$check"     --paper low-energy-loop-response --output ".local/low-energy-v2-$check"
done
```
<!-- code-availability:end -->

## References

<a id="ref-1"></a>
[1] Jian Gao. *From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory*. CourtyCourt · Case 0, Third Edition (v3), Zenodo, 2026. DOI: [10.5281/zenodo.24100339](https://doi.org/10.5281/zenodo.24100339) (First Edition v1 DOI: [10.5281/zenodo.23210292](https://doi.org/10.5281/zenodo.23210292); Second Edition v2 DOI: [10.5281/zenodo.23297179](https://doi.org/10.5281/zenodo.23297179)).

<a id="ref-2"></a>
[2] Jian Gao. *The Current Takes the Stand: From Coupled Propagation to Actual Electrons, Coulomb Response, and Born Dressing*. CourtyCourt · Case 1, First Edition (v1), Zenodo, 2026. DOI: [10.5281/zenodo.23299174](https://doi.org/10.5281/zenodo.23299174). Upstream L1–L17 baseline `Homework` `S = 30218c1aea92640eae09b1d9204a09b01a2d0e47`; [public proof entry](https://github.com/Sapientropic/H0mework/blob/b9d66048342b1a5aeac3e112d920ed85401bb20a/Lean/H0mework/Papers/LowEnergyPhenomenology.lean).

<a id="ref-3"></a>
[3] Jian Gao. *Two Minuses, One Plus, and a Bare Trace Under Oath: Ordered Closed Traces and Whole-Ball Response Curvature*. CourtyCourt · Case 2, First Edition (v1), Zenodo, 2026. DOI: [10.5281/zenodo.23299177](https://doi.org/10.5281/zenodo.23299177); public proof archive `H0mework` commit [`b9d66048342b1a5aeac3e112d920ed85401bb20a`](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a).

<a id="ref-4"></a>
[4] Julian Schwinger. *On Gauge Invariance and Vacuum Polarization*. Physical Review, 82(5), 664–679, 1951. DOI: [10.1103/PhysRev.82.664](https://doi.org/10.1103/PhysRev.82.664).

<a id="ref-5"></a>
[5] Henri Epstein and Vladimir Glaser. *The Role of Locality in Perturbation Theory*. Annales de l'Institut Henri Poincaré, Section A (Physique théorique), 19(3), 211–295, 1973. [NUMDAM full text](http://www.numdam.org/item/AIHPA_1973__19_3_211_0/) (verified §§1, 5.1–5.2, 6.1 on position-space causal distribution splitting and singular-order polynomial ambiguity).

<a id="ref-6"></a>
[6] Bryce S. DeWitt. *Quantum Theory of Gravity. II. The Manifestly Covariant Theory*. Physical Review, 162(5), 1195–1239, 1967. DOI: [10.1103/PhysRev.162.1195](https://doi.org/10.1103/PhysRev.162.1195).

<a id="ref-7"></a>
[7] Laurence F. Abbott. *Introduction to the Background Field Method*. Acta Physica Polonica B, 13(1–2), 33–50, 1982. [Journal PDF](https://www.actaphys.uj.edu.pl/R/13/1/33/pdf) (verified §2.2, pp. 39–42 separating connected generating functionals from 1PI effective actions).

<a id="ref-8"></a>
[8] Ali H. Chamseddine and Alain Connes. *The Spectral Action Principle*. Communications in Mathematical Physics, 186(3), 731–750, 1997. DOI: [10.1007/s002200050126](https://doi.org/10.1007/s002200050126). arXiv:[hep-th/9606001](https://arxiv.org/abs/hep-th/9606001) (verified §§1–2 on Euclidean self-adjoint Dirac operators and $\Lambda$-cutoff heat-kernel asymptotics).

<a id="ref-9"></a>
[9] Stephen L. Adler. *Axial-Vector Vertex in Spinor Electrodynamics*. Physical Review, 177(5), 2426–2438, 1969. DOI: [10.1103/PhysRev.177.2426](https://doi.org/10.1103/PhysRev.177.2426).

<a id="ref-10"></a>
[10] John S. Bell and Roman Jackiw. *A PCAC puzzle: $\pi^0\to\gamma\gamma$ in the $\sigma$-model*. Il Nuovo Cimento A, 60(1), 47–61, 1969. DOI: [10.1007/BF02823296](https://doi.org/10.1007/BF02823296).

<a id="ref-11"></a>
[11] Julian Schwinger. *Brownian Motion of a Quantum Oscillator*. Journal of Mathematical Physics, 2(3), 407–432, 1961. DOI: [10.1063/1.1703727](https://doi.org/10.1063/1.1703727).

<a id="ref-12"></a>
[12] Leonid V. Keldysh. *Diagram Technique for Nonequilibrium Processes*. Zhurnal Eksperimental'noi i Teoreticheskoi Fiziki, 47, 1515–1527, 1964 (English translation: *Soviet Physics JETP*, 20(4), 1018–1026, 1965).

<a id="ref-13"></a>
[13] Hal Tasaki. *Introduction to the “Second Quantization” Formalism for Non-Relativistic Quantum Mechanics: A Possible Substitution for Sections 6.7 and 6.8 of Feynman's “Statistical Mechanics”*. arXiv:[1812.10732v5](https://arxiv.org/abs/1812.10732), 2018 (v5 revised 2023; verified §3, Eqs. (3.22)–(3.29) on fermionic Fock space and one-body $d\Gamma$ operators).

<a id="ref-14"></a>
[14] Mary K. Gaillard. *The Effective One-Loop Lagrangian with Derivative Couplings*. Nuclear Physics B, 268(3–4), 669–692, 1986. DOI: [10.1016/0550-3213(86)90264-6](https://doi.org/10.1016/0550-3213(86)90264-6).

<a id="ref-15"></a>
[15] Oren Cheyette. *Effective Action for the Standard Model with Large Higgs Mass*. Nuclear Physics B, 297(1), 183–204, 1988. DOI: [10.1016/0550-3213(88)90205-2](https://doi.org/10.1016/0550-3213(88)90205-2).

<a id="ref-16"></a>
[16] Brian Henning, Xiaochuan Lu, and Hitoshi Murayama. *How to use the Standard Model effective field theory*. Journal of High Energy Physics, 2016(01), 023, 2016. DOI: [10.1007/JHEP01(2016)023](https://doi.org/10.1007/JHEP01(2016)023). arXiv:[1412.1837v2](https://arxiv.org/abs/1412.1837) (verified §2.1 distinguishing tree-level elimination, internal traces $\operatorname{tr}$, and functional traces $\operatorname{Tr}\log$).

<a id="ref-17"></a>
[17] Thomas Appelquist and J. Carazzone. *Infrared Singularities and Massive Fields*. Physical Review D, 11(10), 2856–2861, 1975. DOI: [10.1103/PhysRevD.11.2856](https://doi.org/10.1103/PhysRevD.11.2856) (verified Introduction and §§III–IV on infrared decoupling of heavy fields).

<a id="ref-18"></a>
[18] Issai Schur. *Über Potenzreihen, die im Innern des Einheitskreises beschränkt sind*. Journal für die reine und angewandte Mathematik, 147, 205–232, 1917. DOI: [10.1515/crll.1917.147.205](https://doi.org/10.1515/crll.1917.147.205).

<a id="ref-19"></a>
[19] Herman Feshbach. *Unified Theory of Nuclear Reactions*. Annals of Physics, 5(4), 357–390, 1958. DOI: [10.1016/0003-4916(58)90007-1](https://doi.org/10.1016/0003-4916(58)90007-1).

<a id="ref-20"></a>
[20] Paul A. M. Dirac. *Generalized Hamiltonian Dynamics*. Canadian Journal of Mathematics, 2, 129–148, 1950. DOI: [10.4153/CJM-1950-012-1](https://doi.org/10.4153/CJM-1950-012-1) (verified constraint classification and auxiliary elimination consistency).

<a id="ref-21"></a>
[21] Yasushi Takahashi. *On the Generalized Ward Identity*. Il Nuovo Cimento, 6(2), 371–375, 1957. DOI: [10.1007/BF02832514](https://doi.org/10.1007/BF02832514).

<a id="ref-22"></a>
[22] Bruno Galerne. *Computation of the Perimeter of Measurable Sets via their Covariogram. Applications to Random Sets*. Image Analysis & Stereology, 30(1), 39–51, 2011. DOI: [10.5566/ias.v30.p39-51](https://doi.org/10.5566/ias.v30.p39-51).

<a id="ref-23"></a>
[23] James Joseph Sylvester. *A demonstration of the theorem that every homogeneous quadratic polynomial is reducible by real orthogonal substitutions to the form of a sum of positive and negative squares*. The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science, Series 4, 4(23), 138–142, 1852. DOI: [10.1080/14786445208647087](https://doi.org/10.1080/14786445208647087).

<a id="ref-24"></a>
[24] Semyon A. Gershgorin. *Über die Abgrenzung der Eigenwerte einer Matrix*. Bulletin de l'Académie des Sciences de l'URSS, Classe des sciences mathématiques et naturelles (*Izvestiya Akademii Nauk SSSR, Otdelenie Matematicheskikh i Estestvennykh Nauk*), VII série, (6), 749–754, 1931.

<a id="ref-25"></a>
[25] Warwick Tucker. *A Rigorous ODE Solver and Smale's 14th Problem*. Foundations of Computational Mathematics, 2(1), 53–117, 2002. DOI: [10.1007/s102080010018](https://doi.org/10.1007/s102080010018).

<a id="ref-26"></a>
[26] Javier Gómez-Serrano. *Computer-Assisted Proofs in PDE: A Survey*. SeMA Journal, 76(3), 459–484, 2019. DOI: [10.1007/s40324-019-00186-x](https://doi.org/10.1007/s40324-019-00186-x). arXiv:[1810.00745](https://arxiv.org/abs/1810.00745) (verified §§1–2 on outward interval arithmetic and Example 2.1 on wrapping inflation).

<a id="ref-27"></a>
[27] Ryogo Kubo. *Statistical-Mechanical Theory of Irreversible Processes. I. General Theory and Simple Applications to Magnetic and Conduction Problems*. Journal of the Physical Society of Japan, 12(6), 570–586, 1957. DOI: [10.1143/JPSJ.12.570](https://doi.org/10.1143/JPSJ.12.570).

<a id="ref-28"></a>
[28] Marvin Rosenblum. *On the Operator Equation $BX - XA = Q$*. Duke Mathematical Journal, 23(2), 263–269, 1956. DOI: [10.1215/S0012-7094-56-02324-9](https://doi.org/10.1215/S0012-7094-56-02324-9).

<a id="ref-29"></a>
[29] Rajendra Bhatia and Peter Rosenthal. *How and Why to Solve the Operator Equation $AX - XB = Y$*. Bulletin of the London Mathematical Society, 29(1), 1–21, 1997. DOI: [10.1112/S0024609396001828](https://doi.org/10.1112/S0024609396001828).

<a id="ref-30"></a>
[30] Leonardo de Moura and Sebastian Ullrich. *The Lean 4 Theorem Prover and Programming Language*. Automated Deduction – CADE 28, Lecture Notes in Computer Science, 12699, 625–635, 2021. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37). [Author PDF](https://lean-lang.org/papers/lean4.pdf) (verified §§1, 5 on small trusted kernel and external reference checker).

<a id="ref-31"></a>
[31] J. M. Luttinger. *Theory of Thermal Transport Coefficients*. Physical Review, 135(6A), A1505–A1514, 1964. DOI: [10.1103/PhysRev.135.A1505](https://doi.org/10.1103/PhysRev.135.A1505).

<a id="ref-32"></a>
[32] H. Arthur Weldon. *Covariant Calculations at Finite Temperature: The Relativistic Plasma*. Physical Review D, 26(6), 1394–1407, 1982. DOI: [10.1103/PhysRevD.26.1394](https://doi.org/10.1103/PhysRevD.26.1394).
