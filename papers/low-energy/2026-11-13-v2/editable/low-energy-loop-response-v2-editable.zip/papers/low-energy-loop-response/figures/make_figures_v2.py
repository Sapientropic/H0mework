#!/usr/bin/env python3
"""Generate the six bilingual Case 2 v2 vector plates (SVG + vector PDF).

Preserves all v1 figure files (`fig01`..`fig04` without `-v2`) byte-for-byte.
Uses `shared/figure-style` (`house_style.py` and `svg_text.py`) with fontTools
width assertions so no label clips or overflows in either Chinese or English.
"""
from __future__ import annotations
from html import escape
from pathlib import Path
import argparse
import math
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, GOLD, WASH
from svg_text import line as text_line, text_width

W = 1000
MIN_SIZE = 17
FULLWIDTH_EN = re.compile(r'[｜：；，。（）　]')


class Plate:
    def __init__(self, height: int, lang: str, title: tuple[str, str]):
        self.h = height
        self.lang = lang
        chosen = self.choose(title)
        self.items = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
            f'viewBox="0 0 {W} {height}" role="img" xml:lang="{lang}">',
            f'<title>{escape(chosen)}</title>',
            f'<rect width="100%" height="100%" fill="white"/>',
        ]

    def choose(self, value):
        return value[0 if self.lang == 'zh' else 1] if isinstance(value, tuple) else value

    def text(self, x: float, y: float, value, size: float = MIN_SIZE,
             color: str = INK, weight: int = 400, anchor: str = 'start',
             max_width: float = 960):
        s = str(self.choose(value))
        assert size >= MIN_SIZE, (s, size)
        if self.lang == 'en':
            bad = FULLWIDTH_EN.findall(s)
            assert not bad, f'full-width char in EN figure text: {s!r} -> {bad}'
        w = text_width(s, size) * (1.07 if (self.lang == 'en' and weight >= 600) else 1.0)
        assert w <= max_width, (self.lang, s, round(w, 1), max_width)
        self.items.append(text_line(x, y, s, size, color, weight, anchor))

    def card(self, x: float, y: float, w: float, h: float,
             fill: str = 'white', stroke: str = HAIR, accent: str | None = DEEP):
        self.items.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="1.2"/>'
        )
        if accent:
            self.items.append(
                f'<rect x="{x}" y="{y + 3}" width="4" height="{h - 6}" fill="{accent}"/>'
            )

    def box(self, x: float, y: float, w: float, h: float, title, lines,
            fill: str = 'white', accent: str = DEEP, title_color: str = INK,
            size: float = MIN_SIZE, line_step: float = 25):
        self.card(x, y, w, h, fill=fill, accent=accent)
        self.text(x + 16, y + 29, title, 19, color=title_color, weight=600, max_width=w - 30)
        for i, row in enumerate(lines):
            self.text(x + 16, y + 56 + line_step * i, row, size=size, max_width=w - 30)

    def line(self, x1: float, y1: float, x2: float, y2: float,
             stroke: str = SLATE, width: float = 1.6, arrow: bool = False, dash: str = ''):
        if arrow:
            length = math.hypot(x2 - x1, y2 - y1)
            ux, uy = (x2 - x1) / length, (y2 - y1) / length
            bx, by = x2 - 10 * ux, y2 - 10 * uy
            self.items.append(
                f'<polygon points="{x2:.1f},{y2:.1f} {bx - 4.5 * uy:.1f},{by + 4.5 * ux:.1f} '
                f'{bx + 4.5 * uy:.1f},{by - 4.5 * ux:.1f}" fill="{stroke}"/>'
            )
            x2, y2 = bx, by
        extra = f' stroke-dasharray="{dash}"' if dash else ''
        self.items.append(
            f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="{stroke}" stroke-width="{width}"{extra}/>'
        )

    def polyline(self, pts: list[tuple[float, float]], stroke: str = DEEP,
                 width: float = 2.4, dash: str = ''):
        coords = ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)
        extra = f' stroke-dasharray="{dash}"' if dash else ''
        self.items.append(
            f'<polyline points="{coords}" fill="none" stroke="{stroke}" '
            f'stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round"{extra}/>'
        )

    def circle(self, cx: float, cy: float, r: float = 4.5,
               fill: str = DEEP, stroke: str = 'white', width: float = 1.4):
        self.items.append(
            f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="{fill}" '
            f'stroke="{stroke}" stroke-width="{width}"/>'
        )

    def save(self, stem: str) -> Path:
        suffix = '-en' if self.lang == 'en' else ''
        out = HERE / f'{stem}-v2{suffix}.svg'
        out.write_text('\n'.join(self.items + ['</svg>']) + '\n')
        return out


def draw_fig01(lang: str) -> Path:
    s = Plate(636, lang, (
        '同一母作用的两条并行支路与双球五通道极化合成',
        'Two parallel branches from the common mother action and five-channel polarization assembly',
    ))
    s.box(20, 18, 220, 124,
          ('统一母作用 · 零旋钮源', 'Mother action'),
          [('独立变分对偶 {i:ψ}, {i:χ}', 'Independent duals {i:ψ}, {i:χ}'),
           ('唯一九场背景与占据态 {i:w}', '9-field solution & state {i:w}'),
           ('289 实场 / 252 复维物质', '289 fields / 252D matter')])
    s.box(272, 18, 326, 124,
          ('Q1 · 非交换有序闭迹支路', 'Q1 · Ordered closed-trace branch'),
          [('{i:P}{sub:6} 手征分级与单向幂零项 {i:N}', '{i:P}{sub:6} grading & one-way nilpotent {i:N}'),
           ('任意长合法规范词 tr {i:W} = tr {i:W}{sub:0}', 'Any legal gauge word: tr {i:W} = tr {i:W}{sub:0}'),
           ('裸迹 252 ≠ 单位制备态期望 1', 'Bare trace 252 ≠ prepared value 1')])
    s.box(630, 18, 350, 124,
          ('Q2 · Fock 整词评价与开放返回', 'Q2 · Whole-word Fock readback'),
          [('单向标量闭迹 0；开放返回 −1', 'One-way scalar trace 0; return −1'),
           ('中途秩一投影 {i:P}{isub:w} 抹除为 0', 'Mid-word projection {i:P}{isub:w} erases to 0'),
           ('先合成整词 dΓ 再作单粒子压缩', 'Multiply full dΓ word before readout')])
    s.line(240, 80, 272, 80, arrow=True)
    s.line(598, 80, 630, 80, arrow=True)

    s.line(130, 142, 130, 165)
    s.line(130, 165, 830, 165)
    for x in (170, 500, 830):
        s.line(x, 165, x, 188, arrow=True)

    s.box(20, 188, 300, 124,
          ('Q3 · 费米子 Schur 补与轻核', 'Q3 · Fermionic Schur kernel'),
          [('289 → 103 → 有理玻色核 {i:S}{sub:55}', '289 → 103 → rational {i:S}{sub:55}'),
           ('全 289 行符号回写 {i:HF} = {i:J}{sub:src}{i:S}{sub:55}', '289-row readback {i:HF} = {i:J}{sub:src}{i:S}{sub:55}'),
           ('原点 61 维二阶 → 5 维轻核', 'Origin 61D order-2 → 5D kernel')])
    s.box(350, 188, 300, 124,
          ('实时间占据演化与复 Gram', 'Real-time state & Gram'),
          [('全空间投影 {i:P}；双 Laplace 核', 'Full-space {i:P}; double Laplace'),
           ('未中心化 / 均值 / 连通正交分解', 'Raw / mean / connected split'),
           ('{i:S}{sub:01} d{i:x}{sup:1} 外源与两个同源半幅', '{i:S}{sub:01} d{i:x}{sup:1} source & two half-modes')])
    s.box(680, 188, 300, 124,
          ('母作用生成三类微扰变化', 'Action-derived variations'),
          [('双侧 Ward 补源 → 两条传播腿', 'Two-sided Ward → two {i:G} legs'),
           ('背景电流变分 → 读出接触项', 'Current variation → contact term'),
           ('Duhamel 导数 → 两条量子源腿', 'Duhamel → two quantum legs')])

    for x in (170, 500, 830):
        s.line(x, 312, x, 334)
    s.line(110, 334, 890, 334)

    legs = [
        (('量子源左腿', 'Left source leg'), [('量子 Gram 左槽', 'Gram slot 1'), ('固定入射球窗', 'Fixed ball window')]),
        (('量子源右腿', 'Right source leg'), [('量子 Gram 右槽', 'Gram slot 2'), ('固定入射球窗', 'Fixed ball window')]),
        (('变分读出接触', 'Readout contact'), [('电流双线性变分', 'Bilinear variation'), ('随 {i:d} 移动双球交集', 'Moving 2-ball lens')]),
        (('场传播左腿', 'Left field leg'), [('共轭传播核变分', 'Conjugate {i:G} varies'), ('随 {i:d} 移动双球交集', 'Moving 2-ball lens')]),
        (('场传播右腿', 'Right field leg'), [('玻色传播核变分', 'Field {i:G} varies'), ('随 {i:d} 移动双球交集', 'Moving 2-ball lens')]),
    ]
    for j, (head, rows) in enumerate(legs):
        x = 20 + j * 195
        s.line(x + 90, 334, x + 90, 356, arrow=True)
        s.box(x, 356, 180, 106, head, rows, accent=VERMILION, title_color=VERMILION)
        s.line(x + 90, 462, x + 90, 492, arrow=True)

    s.card(20, 492, 960, 124, fill=WASH, accent=VERMILION)
    s.text(38, 525,
           ('Q4 · 五通道整球极化合成：{i:K}{isub:α} = {i:K}{sub:G}{sup:α} + ½ {i:S}{sub:N}{sup:α} + {i:K}{sub:C}{sup:α}',
            'Q4 · Five-channel whole-ball curvature: {i:K}{isub:α} = {i:K}{sub:G}{sup:α} + ½ {i:S}{sub:N}{sup:α} + {i:K}{sub:C}{sup:α}'),
           20, weight=600)
    s.text(38, 558,
           ('分离尖窗非解析一次项 |{i:d}|，保留球内体积分、两类球面通量、完整复交叉 Gram 与 11,760 项复围道包络',
            'Separate the sharp-lens |{i:d}| cusp; retain bulk integral, two sphere fluxes, complex cross-Gram & 11,760 contour enclosures'),
           17.5)
    s.text(38, 590,
           ('连续缩放混合项 Gershgorin 无过零分离 ⇒ 未中心化（raw）与连通（connected）惯性指数同为 (2, 1, 0)',
            'Continuous-path Gershgorin separation from zero ⇒ Inertia({i:K}{sub:raw}) = Inertia({i:K}{sub:conn}) = (2, 1, 0)'),
           18, color=VERMILION, weight=600)
    return s.save('fig01-two-branches')


def draw_fig02(lang: str) -> Path:
    s = Plate(566, lang, (
        '双球尖窗交集几何、一次球冠损失与两类球面通量对消',
        'Two-ball sharp-lens geometry, linear cap loss, and boundary-flux cancellation',
    ))
    cy, r, c1, c2 = 206, 128, 158, 246
    hx = (c1 + c2) / 2
    hy = math.sqrt(r * r - ((c2 - c1) / 2) ** 2)
    s.items.append(f'<circle cx="{c1}" cy="{cy}" r="{r}" fill="{WASH}" stroke="{SLATE}" stroke-width="1.6"/>')
    s.items.append(f'<circle cx="{c2}" cy="{cy}" r="{r}" fill="none" stroke="{DEEP}" stroke-width="1.6"/>')
    lens = (f'M{hx:.2f},{cy - hy:.2f} A{r},{r} 0 0 0 {hx:.2f},{cy + hy:.2f} '
            f'A{r},{r} 0 0 0 {hx:.2f},{cy - hy:.2f} Z')
    s.items.append(f'<path d="{lens}" fill="{DEEP}" fill-opacity="0.56" stroke="{VERMILION}" stroke-width="3.2"/>')
    s.line(c1, cy, c2, cy, stroke='white', width=2.0, arrow=True)
    s.text((c1 + c2) / 2, cy - 14, '{i:d} = {i:s n}', 19, color='white', anchor='middle', max_width=140)
    s.text(26, 62, ('入射球 |{i:y}| ≤ {i:B}', 'Incident ball |{i:y}| ≤ {i:B}'), 18.5, color=SLATE, max_width=240)
    s.text(c2 + 12, 366, ('观察球 |{i:y} − {i:d}| ≤ {i:B}', 'Observation ball |{i:y} − {i:d}| ≤ {i:B}'),
           18.5, color=DEEP, anchor='middle', max_width=280)
    s.text(24, 402,
           ('深色透镜：保留的双球交集；朱红球弧：承载两类边界通量的球面',
            'Dark lens: retained two-ball overlap; vermilion arcs: sphere supporting both boundary fluxes'),
           17, max_width=952)

    s.box(432, 32, 548, 132,
          ('集合协方差尖点：|{i:s}| 先于 {i:s}{sup:2} 抵达',
           'Covariogram cusp: |{i:s}| arrives before {i:s}{sup:2}'),
          [('Vol(交集) = 4π{i:B}{sup:3}/3 − π{i:B}{sup:2}|{i:s}| + π|{i:s}|{sup:3}/12',
            'Vol(lens) = 4π{i:B}{sup:3}/3 − π{i:B}{sup:2}|{i:s}| + π|{i:s}|{sup:3}/12'),
           ('0 ≤ |{i:s}| ≤ 2{i:B}（裁去球冠产生非解析一次损失）',
            '0 ≤ |{i:s}| ≤ 2{i:B} (trimmed cap yields linear loss)'),
           ('曲率张量 {i:K}{isub:α} 为 {i:s}{sup:2} 系数，非原点光滑 Hessian',
            '{i:K}{isub:α} is the {i:s}{sup:2} coefficient, not a smooth Hessian')])
    s.box(432, 184, 548, 140,
          ('固定入射标架下的精确三项分解', 'Exact three-part decomposition in incident frame'),
          [('球内体积分：½ ∫{sub:B} Re {i:R}{sub:dd}',
            'Bulk integral: ½ ∫{sub:B} Re {i:R}{sub:dd}'),
           ('一阶球面通量：½ ∫{sub:∂B} {i:u} Re {i:R}{isub:d}',
            'First boundary flux: ½ ∫{sub:∂B} {i:u} Re {i:R}{isub:d}'),
           ('零阶球面通量：¼ ∫{sub:∂B} [{i:u}{sup:2}∂{isub:r} Re {i:R}{sub:0} + (3{i:u}{sup:2}−1)Re {i:R}{sub:0}/{i:B}]',
            'Zeroth flux: ¼ ∫{sub:∂B} [{i:u}{sup:2}∂{isub:r} Re {i:R}{sub:0} + (3{i:u}{sup:2}−1)Re {i:R}{sub:0}/{i:B}]')],
          size=17)

    s.card(20, 424, 960, 124, fill=WASH, accent=VERMILION)
    s.text(38, 457,
           ('反向控制（仿射测试场）：{i:a}({i:k}) = [1 + (2 + i){i:k}{sub:3}] {i:b}，其中 {i:b}{sup:T}{i:Qb} = 4',
            'Negative control (affine test field): {i:a}({i:k}) = [1 + (2 + i){i:k}{sub:3}] {i:b}, with {i:b}{sup:T}{i:Qb} = 4'),
           18.5, weight=600)
    s.text(38, 491,
           ('球面通量精确抵消非零球内梯度能 ⇒ 真实二次系数严格等于 0',
            'Spherical boundary flux cancels nonzero interior gradient energy ⇒ exact quadratic coefficient = 0'),
           19.5, color=VERMILION, weight=600)
    s.text(38, 524,
           ('若人为漏掉球面通量，将凭空伪造严格负曲率；体／面测度全程保留 (2π){sup:−3} 因子。',
            'Dropping the boundary flux fabricates a spurious negative curvature; both measures retain (2π){sup:−3}.'),
           17)
    return s.save('fig02-lens-flux')


def draw_fig03(lang: str) -> Path:
    s = Plate(780, lang, (
        '对角有理区间、球面通量翻转、Gershgorin 包围与三窗口显微放大',
        'Diagonal rational intervals, boundary-flux flip, Gershgorin bands, and microscopic zooms',
    ))
    s.text(22, 34,
           ('A · 全尺度三轴区间与球面通量符号逆转（单位 10{sup:−20}）',
            'A · Full-scale principal intervals & spherical-flux sign reversal (units 10{sup:−20})'),
           18.5, weight=600, max_width=956)
    x0, x1, lo, hi = 248, 962, -2.05, 2.55
    xp = lambda v: x0 + (x1 - x0) * (v - lo) / (hi - lo)
    top, bottom = 54, 384
    for v in (-2, -1, 1, 2):
        s.line(xp(v), top, xp(v), bottom, HAIR, 1.0, dash='4 5')
        s.text(xp(v), bottom + 25, str(v).replace('-', '−'), 17.5, color=SLATE, anchor='middle', max_width=80)
    s.line(x0, bottom, x1, bottom, SLATE, 1.2)

    intervals = [
        (('未中心化', 'raw'), DEEP, '#c9d5e1', 0.02299243,
         [(-1.355200, -1.309214), (2.140271, 2.186257), (-1.742600, -1.696614)]),
        (('连通部分', 'connected'), GOLD, '#eadbb6', 0.02281948,
         [(-1.297332, -1.251692), (2.139655, 2.185295), (-1.701494, -1.655854)]),
    ]
    for si, (sec_name, col, band, m, vals) in enumerate(intervals):
        for j, (a, b) in enumerate(vals):
            y = 84 + si * 164 + j * 49
            label_left = (f'{sec_name[0]} / {{i:e}}{{sub:{j + 1}}}', f'{sec_name[1]} / {{i:e}}{{sub:{j + 1}}}')
            s.text(22, y + 6, label_left, 18, color=col, weight=600, max_width=216)
            s.line(xp(a - 2 * m), y, xp(b + 2 * m), y, band, 15)
            s.line(xp(a), y, xp(b), y, col, 7)
            for v in (a, b):
                s.line(xp(v), y - 8, xp(v), y + 8, col, 2)
            iv_txt = f'[{a:.6f}, {b:.6f}]'.replace('-', '−')
            cx = (xp(a) + xp(b)) / 2
            anchor = 'end' if cx + 100 > 978 else 'middle'
            tx = min(cx, 976)
            s.text(tx, y - 14, iv_txt, 17, color=col, anchor=anchor, max_width=260)

    # Highlight bulk-only negative point (-0.1883) -> boundary-flux flip (+2.3805) on raw / e_2
    y_e2 = 84 + 49
    x_bulk = xp(-0.188264)
    s.circle(x_bulk, y_e2, r=5.0, fill='white', stroke=SLATE, width=2.0)
    s.line(x_bulk + 8, y_e2, xp(2.07), y_e2, stroke=VERMILION, width=1.8, arrow=True, dash='6 4')
    s.text((x_bulk + xp(1.88)) / 2, y_e2 + 22,
           ('仅球内 −0.19  →  两类球面通量 +2.38 跨零逆转',
            'Bulk −0.19  →  +2.38 sphere-flux flip across 0'),
           17, color=VERMILION, weight=600, anchor='middle', max_width=430)

    s.line(xp(0), top - 6, xp(0), bottom, VERMILION, 2.6)
    s.text(xp(0), bottom + 25, '0', 18, color=VERMILION, anchor='middle', max_width=50)
    s.text(xp(0) + 10, top + 12,
           ('六个 Gershgorin 圆盘与 0 严格分离 (> 1.2)', 'All six Gershgorin disks clear 0 (> 1.2)'),
           17.5, color=VERMILION, weight=600, max_width=390)

    # Tier B: Three microscopic zoom insets
    s.text(22, 444,
           ('B · 局部显微放大：二进有理紧核、±2|{i:K}{isub:ij}| 圆盘外晕与均值项跨零实况',
            'B · Microscopic zooms: dyadic core intervals, ±2|{i:K}{isub:ij}| halos, and mean {i:e}{sub:2} zero-crossing'),
           18.5, weight=600, max_width=956)

    def zoom_panel(px: float, pw: float, head, zlo: float, zhi: float, ticks, rows, show_zero: bool = False):
        py, ph = 460, 200
        s.card(px, py, pw, ph, fill='white', accent=SLATE)
        s.text(px + 14, py + 27, head, 17.5, weight=600, max_width=pw - 24)
        zx0, zx1 = px + 22, px + pw - 22
        zxp = lambda v: zx0 + (zx1 - zx0) * (v - zlo) / (zhi - zlo)
        zy_top, zy_bot = py + 48, py + 158
        for tv, tlab in ticks:
            s.line(zxp(tv), zy_top, zxp(tv), zy_bot, HAIR, 1.0, dash='3 4')
            s.text(zxp(tv), zy_bot + 24, tlab, 17, color=SLATE, anchor='middle', max_width=90)
        s.line(zx0, zy_bot, zx1, zy_bot, SLATE, 1.2)
        if show_zero:
            s.line(zxp(0.0), zy_top - 4, zxp(0.0), zy_bot, VERMILION, 2.3)
        for ri, (rlabel, rcol, rband, ra, rb, rm) in enumerate(rows):
            ry = py + 78 + ri * 52
            if rm > 0:
                s.line(zxp(ra - 2 * rm), ry, zxp(rb + 2 * rm), ry, rband, 16)
            s.line(zxp(ra), ry, zxp(rb), ry, rcol, 7)
            for rv in (ra, rb):
                s.line(zxp(rv), ry - 8, zxp(rv), ry + 8, rcol, 2)
            if show_zero:
                s.items.append(
                    f'<rect x="{px + 56:.1f}" y="{ry - 31:.1f}" width="{pw - 112:.1f}" '
                    f'height="21" rx="3" fill="white" fill-opacity="0.92"/>'
                )
            s.text((zxp(ra) + zxp(rb)) / 2, ry - 14, rlabel, 17, color=rcol, weight=600,
                   anchor='middle', max_width=pw - 28)

    zoom_panel(
        20, 306,
        ('{i:e}{sub:2} 正峰放大 (×27)', '{i:e}{sub:2} positive peak (×27)'),
        2.080, 2.248,
        [(2.10, '2.10'), (2.16, '2.16'), (2.22, '2.22')],
        [
            (('raw 核宽 0.046', 'raw width 0.046'), DEEP, '#c9d5e1', 2.140271, 2.186257, 0.02299243),
            (('conn 核宽 0.046', 'conn width 0.046'), GOLD, '#eadbb6', 2.139655, 2.185295, 0.02281948),
        ],
    )
    zoom_panel(
        347, 306,
        ('{i:e}{sub:1} 负谷放大 (×20)', '{i:e}{sub:1} negative well (×20)'),
        -1.415, -1.190,
        [(-1.38, '−1.38'), (-1.30, '−1.30'), (-1.22, '−1.22')],
        [
            (('raw [−1.355, −1.309]', 'raw [−1.355, −1.309]'), DEEP, '#c9d5e1', -1.355200, -1.309214, 0.02299243),
            (('conn [−1.297, −1.252]', 'conn [−1.297, −1.252]'), GOLD, '#eadbb6', -1.297332, -1.251692, 0.02281948),
        ],
    )
    zoom_panel(
        674, 306,
        ('均值项 {i:e}{sub:2} 跨零放大', 'mean / {i:e}{sub:2} straddles 0'),
        -0.0032, 0.0048,
        [(-0.002, '−0.002'), (0.0, '0'), (0.003, '+0.003')],
        [
            (('[−0.0016, +0.0032]', '[−0.0016, +0.0032]'), SLATE, '#dce2e8', -0.001635, 0.003212, 0.000242343),
        ],
        show_zero=True,
    )
    s.items.append('<rect x="692" y="576" width="270" height="24" rx="3" fill="white" fill-opacity="0.92"/>')
    s.text(674 + 153, 460 + 134,
           ('含 0：如实单列，不作号差裁决', 'Contains 0: no inertia claim'),
           17, color=VERMILION, weight=600, anchor='middle', max_width=278)

    s.card(20, 676, 960, 88, fill=WASH, accent=VERMILION)
    s.text(38, 708,
           ('非对角统一界：|{i:K}{isub:ij}| < 2.299243 × 10{sup:−22}（raw）；< 2.281948 × 10{sup:−22}（connected），{i:i} ≠ {i:j}',
            'Off-diagonal bounds: |{i:K}{isub:ij}| < 2.299243 × 10{sup:−22} (raw); < 2.281948 × 10{sup:−22} (connected), {i:i} ≠ {i:j}'),
           17.5)
    s.text(38, 742,
           ('沿 {i:t} ∈ [0, 1] 连续缩放非对角元无特征值穿零 ⇒ 完整实对称张量惯性指数 (负, 正, 零) = (2, 1, 0)',
            'Scaling off-diagonal entries across {i:t} ∈ [0, 1] crosses no zero ⇒ full tensor inertia (neg, pos, zero) = (2, 1, 0)'),
           18, weight=600)
    return s.save('fig03-inertia')


def draw_fig04(lang: str) -> Path:
    s = Plate(1156, lang, (
        '母作用二阶 Fréchet 变分认回、四动量 Schur 重构与非线性 Noether 极化返回',
        'Mother second-variation identification, four-momentum Schur recovery, and nonlinear Noether return',
    ))
    s.box(20, 18, 960, 86,
          ('母作用密度的全四复动量二阶 Fréchet 变分认回（命题 12.1）',
           'All-four-momentum second Fréchet variation of the mother action density (Proposition 12.1)'),
          [('1,445 个一阶射流槽 → 3,071 项 Jacobi 字典：{i:K}{sub:nat}({i:p}) = {i:H}{sub:289}({i:p})（∀ {i:p} ∈ ℂ{sup:4}）',
            '1,445 first-jet slots → 3,071-term Jacobi dictionary: {i:K}{sub:nat}({i:p}) = {i:H}{sub:289}({i:p}) (∀ {i:p} ∈ ℂ{sup:4})')],
          fill=WASH)

    s.text(20, 134,
           ('Q5 · 五维原点核与 98 维坐标补空间的全四动量 Schur 重构',
            'Q5 · Five origin modes and 98D coordinate-complement Schur reconstruction'),
           19, weight=600)
    s.box(20, 150, 415, 118,
          ('5 列原点核 + 98 维直和补坐标', '5 origin columns + 98D complement'),
          [('98 = 45 + 21 + 32 三块原点双侧逆', '98 = 45 + 21 + 32 origin two-sided inverse'),
           ('{i:p} ∈ ℂ{sup:4}，非空正则域 det {i:A}({i:p}) ≠ 0', '{i:p} ∈ ℂ{sup:4}, regular domain det {i:A}({i:p}) ≠ 0'),
           ('Neumann 半径 {i:ρ} 与整块三阶余项 {i:C}{sub:E}{i:r}{sup:3}', 'Neumann radius {i:ρ} & cubic bound {i:C}{sub:E}{i:r}{sup:3}')])
    s.line(435, 209, 470, 209, arrow=True)
    s.box(470, 150, 510, 118,
          ('有效核与全场有理恢复映射', 'Exact Schur kernel & field recovery maps'),
          ['{i:E}({i:p}) = {i:N}{sup:T}{i:KN} − {i:N}{sup:T}{i:KG}{sub:c}{i:KN}',
           '{i:E c}{sub:N} = {i:L}{sub:S}{i:s};   {i:x} = {i:N}{sub:eff}{i:c}{sub:N} + {i:G}{sub:c}{i:s}',
           ('保留全部四复动量有理依赖', 'Exact rational identity across ℂ{sup:4}')])
    s.line(725, 268, 725, 296, arrow=True)
    s.box(20, 296, 960, 112,
          ('量子电流窗口 → 清分母 Green 解 → 全 289 场逐项恢复',
           'Quantum current window → denominator-cleared Green → all 289 fields restored'),
          [('Ward 共源 {i:κ} = {i:F}(−{i:P}){sup:T}{i:J}；清分母方程保持同一共同分母 {i:d}({i:P})',
            'Ward co-source {i:κ} = {i:F}(−{i:P}){sup:T}{i:J}; cleared equation keeps common denominator {i:d}({i:P})'),
           ('完整直和恢复：接触投影 + 活跃块（5 + 98）+ 九个零模方向',
            'Complete recovery: contact projection + active (5 + 98) + all nine null directions')])

    s.text(20, 448,
           ('Q6 · 配置空间有序五因子核：先完成整词乘积，再施加制备读出',
            'Q6 · Configuration-space ordered five-factor kernel: multiply whole word before readout'),
           19, weight=600)
    factors = [
        (('左对偶时间', 'Left dual time'), '{i:V}{isub:ρ}({i:t})'),
        (('左物质预解逆', 'Left matter inv.'), '{i:R}{sub:+}({i:ρh}(0))'),
        (('中央变分读出', 'Central readout'), '{i:B}{sub:raw} / {i:N}{isub:f}'),
        (('右物质预解逆', 'Right matter inv.'), '{i:R}{sub:−}({i:ρh}(0))'),
        (('右原场时间', 'Right field time'), '{i:U}{isub:ρ}({i:t})'),
    ]
    for i, (head, form) in enumerate(factors):
        x = 20 + 198 * i
        s.card(x, 466, 168, 86)
        s.text(x + 84, 495, head, 18.5, weight=600, anchor='middle', max_width=152)
        s.text(x + 84, 527, form, 19.5, anchor='middle', max_width=152)
        if i < 4:
            s.line(x + 168, 509, x + 198, 509, arrow=True)

    s.text(20, 584,
           ('乘积法则依次落于五处因子；中央项保留 raw → Noether 运输接触差并合并四个动量转移频点',
            'Product rule hits all five factors; central term keeps raw → Noether contact shift & merges four transfer frequencies'),
           17.5)
    s.line(500, 598, 500, 610)
    s.line(245, 610, 755, 610)
    s.line(245, 610, 245, 626, arrow=True)
    s.line(755, 610, 755, 626, arrow=True)

    s.box(20, 626, 455, 152,
          ('实 289 场 Noether 半轴算子（命题 13.1）', 'Real 289-field half-line operator (Prop. 13.1)'),
          ['{i:𝒥}{sub:∞}({i:q}, {i:λ}): ℝ{sup:289} → ℂ{sup:289}',
           ('独立非实频率 Im {i:z}, Im {i:w} ≠ 0', 'Independent nonreal Im {i:z}, Im {i:w} ≠ 0'),
           ('Re {i:λ} > 0 正半轴 Bochner 可积', 'Bochner integrable on Re {i:λ} > 0'),
           ('显式指数尾界 2{i:C}{isub:q} e{sup:−Re λ T/2} / Re {i:λ}',
            'Explicit tail 2{i:C}{isub:q} e{sup:−Re λ T/2} / Re {i:λ}')])
    s.box(525, 626, 455, 152,
          ('产生态减背景差读出泛函 ℓ{isub:d}', 'Creation-minus-background functional ℓ{isub:d}'),
          [('单位创建态 {i:u}{isub:ε} 与同源背景 {i:v}{isub:ε}（{i:z}={i:w}={i:ζ}）',
            'Created unit {i:u}{isub:ε} & background {i:v}{isub:ε} ({i:z}={i:w}={i:ζ})'),
           '{i:ℓ}{isub:d}({i:A}) = −⟨{i:u}{isub:ε}, {i:Au}{isub:ε}⟩ + ⟨{i:v}{isub:ε}, {i:Av}{isub:ε}⟩',
           ('泛函范数 ‖{i:ℓ}{isub:d}‖ ≤ 2；保持原 Euler 号', 'Norm ‖{i:ℓ}{isub:d}‖ ≤ 2; original Euler sign'),
           ('正交双实相位信号恢复复线性映射', 'Two real quadratures restore ℂ-linearity')])

    s.line(245, 778, 245, 814, arrow=True)
    s.line(755, 778, 755, 814, arrow=True)

    s.box(20, 814, 455, 166,
          ('时间射流分部积分与端点共源', 'Time-jet integration by parts & endpoints'),
          [('零、一、二阶时间射流逐项分部积分', '0th, 1st, 2nd time jets integrated by parts'),
           ('有限窗：体源 − [{i:B}{isub:λ}({i:T}) − {i:B}{isub:λ}(0)]',
            'Window: bulk − [{i:B}{isub:λ}({i:T}) − {i:B}{isub:λ}(0)]'),
           ('正半轴：保留初端 {i:B}{isub:λ}(0)，末端趋零',
            'Half-line: keeps {i:B}{isub:λ}(0); terminal → 0'),
           ('36 维曲率算符 {i:R}{sub:36} 逐行读回更新场',
            '36-curvature map {i:R}{sub:36} reads updated field')])
    s.box(525, 814, 455, 166,
          ('全 289 × 289 极化张量（定理 13.2）', 'Full 289 × 289 polarization (Thm. 13.2)'),
          [('非线性共同正窗：0 ≤ {i:T} < {i:τ}({i:d}, {i:k}, {i:P}, {i:a})',
            'Nonlinear window: 0 ≤ {i:T} < {i:τ}({i:d}, {i:k}, {i:P}, {i:a})'),
           ('母 Euler 铅笔：[{i:W}{sub:T}{i:K}{sub:nat}({i:P}) − {i:Π}{isub:d,T}({i:P},{i:λ})]{i:a}',
            'Euler pencil: [{i:W}{sub:T}{i:K}{sub:nat}({i:P}) − {i:Π}{isub:d,T}({i:P},{i:λ})]{i:a}'),
           ('线性化半轴：{i:Δ} = Re {i:λ} − max(0, Re {i:P}{sub:0}) > 0',
            'Linearized half-line: {i:Δ} = Re {i:λ} − max(0, Re {i:P}{sub:0}) > 0'),
           ('同钟 {i:W}{sub:T} = {i:T}；异钟保留精确指数权',
            'Coincident clock {i:W}{sub:T} = {i:T}; general {i:W}{sub:T} kept')],
          fill=WASH, accent=VERMILION, title_color=VERMILION)

    s.line(245, 980, 245, 1018, arrow=True)
    s.line(755, 980, 755, 1018, arrow=True)

    s.box(20, 1018, 960, 116,
          ('同一母 Hessian 与受约束 Green 矩阵：量子强迫项闭合 Cauchy 全场更新',
           'Same mother Hessian & constrained Green matrix: quantum forcing closes Cauchy field update'),
          [('量子源 {i:j}{sub:T} = {i:Π}{isub:d,T}{i:a} 与 {i:j}{sub:∞} = {i:𝒥}{sub:∞}{i:f} 代入 {i:x} = {i:𝒢}({i:P}{isub:k}){i:j}',
            'Quantum forcings {i:j}{sub:T} = {i:Π}{isub:d,T}{i:a} and {i:j}{sub:∞} = {i:𝒥}{sub:∞}{i:f} enter {i:x} = {i:𝒢}({i:P}{isub:k}){i:j}'),
           ('电压 Cauchy 更新 {i:X}{sub:upd,T} 同时保留经典窗、九零模投影扣除与实虚两路量子反馈',
            'Voltage Cauchy update {i:X}{sub:upd,T} retains classical window, 9-null subtraction & both quantum forcings')],
          fill=WASH)
    return s.save('fig04-full-return')


def draw_fig05(lang: str) -> Path:
    s = Plate(684, lang, (
        'Q7 · 传播极小多项式商逆、全 289×289 Sylvester 二次型坍缩与光子振幅接口',
        'Q7 · Minimal-polynomial quotient inverse, 289×289 Sylvester collapse, and photon-amplitude feed',
    ))
    s.box(20, 18, 300, 132,
          ('交换左右生成元与整性', 'Commuting generators'),
          ['{i:𝒯}{isub:q}({i:X}) = i {i:G}{sub:+}{i:X} − i {i:XG}{sub:−}',
           ('左乘 {i:ℒ}{isub:q} 与右乘 {i:ℛ}{isub:q} 严格对易', 'Left {i:ℒ}{isub:q} and right {i:ℛ}{isub:q} commute'),
           ('各自满足首一联合特征多项式', 'Each integral over ℂ via {i:P}{sub:joint}')])
    s.box(350, 18, 300, 132,
          ('先于读出／外力的极小多项式', 'Minimal polynomial {i:P}{isub:q}({i:X})'),
          ['{i:P}{isub:q}({i:X}) = minpoly{sub:ℂ}({i:𝒯}{isub:q})',
           ('有限阶 {i:N}{isub:q} = deg {i:P}{isub:q}，覆盖全演化', 'Finite degree {i:N}{isub:q}; uncut-{i:Y} words'),
           ('Re {i:λ} > 0 双侧逆 ⇒ {i:P}{isub:q}({i:λ}) ≠ 0', 'Re {i:λ} > 0 resolvent ⇒ {i:P}{isub:q}({i:λ}) ≠ 0')])
    s.box(680, 18, 300, 132,
          ('有限维商代数与双逆权重', 'Quotient inverse & weights'),
          ['{i:𝒜}{isub:q} = ℂ[{i:X}] / ({i:P}{isub:q}({i:X}))',
           ('({i:λ} − {i:X̄}) {i:g}{isub:q}({i:λ}) = 1（零外置证书）', '({i:λ} − {i:X̄}) {i:g}{isub:q}({i:λ}) = 1 (no extra cert)'),
           ('{i:w}{isub:q}({i:λ}) = {i:M}{isub:q}({i:λ}){sup:−1}{i:e}{sub:0}（{i:N}{isub:q} 维）',
            '{i:w}{isub:q}({i:λ}) = {i:M}{isub:q}({i:λ}){sup:−1}{i:e}{sub:0} (dim {i:N}{isub:q})')])
    s.line(320, 84, 350, 84, arrow=True)
    s.line(650, 84, 680, 84, arrow=True)

    s.line(830, 150, 830, 178)
    s.line(255, 178, 830, 178)
    s.line(255, 178, 255, 204, arrow=True)
    s.line(745, 178, 745, 204, arrow=True)

    s.box(20, 204, 465, 146,
          ('一次预解通道：直接／接触源词矩 {i:D}', 'Single-resolvent channel: direct moments {i:D}'),
          [('初值 {i:I}{sub:Noether} = 斜率初值 + Noether 接触增量',
            '{i:I}{sub:Noether} = slope initial + Noether contact shift'),
           '{i:D}{isub:a}{sup:(ij)} = {i:ℓ}{isub:d}({i:𝒯}{isub:q}{sup:a}({i:I}{sub:Noether}({i:e}{isub:i}, {i:e}{isub:j})))',
           ('{i:N}{isub:q} 维有限向量，先乘整词后评价', 'Finite {i:N}{isub:q}-vector; full word evaluated')])
    s.box(515, 204, 465, 146,
          ('二次预解通道：双驱动源词矩矩阵 {i:R}', 'Double-resolvent channel: driven matrix {i:R}'),
          [('双侧流驱动 {i:𝒟}{isub:q}({i:e}{isub:j})({i:B}) = −{i:J}{sub:L}{i:B} + {i:BJ}{sub:R}',
            'Two-leg drive {i:𝒟}{isub:q}({i:e}{isub:j})({i:B}) = −{i:J}{sub:L}{i:B} + {i:BJ}{sub:R}'),
           '{i:R}{isub:ab}{sup:(ij)} = {i:ℓ}{isub:d}({i:𝒯}{isub:q}{sup:a}({i:𝒟}{isub:q}({i:e}{isub:j})({i:𝒯}{isub:q}{sup:b}({i:I}{sub:raw}({i:e}{isub:i})))))',
           ('{i:N}{isub:q} × {i:N}{isub:q} 有限矩阵，替代嵌套半轴积分',
            'Finite {i:N}{isub:q} × {i:N}{isub:q} matrix; replaces nested integrals')])

    s.line(255, 350, 255, 382, arrow=True)
    s.line(745, 350, 745, 382, arrow=True)

    s.card(20, 382, 960, 118, fill=WASH, accent=VERMILION)
    s.text(38, 415,
           ('定理 14.1 · 全部 289{sup:2} 个静态钟 Noether 极化分量的有限 Sylvester 二次型闭式（∀ Re {i:λ} > 0）',
            'Theorem 14.1 · Closed-form finite Sylvester quadratic form across all 289{sup:2} directions (∀ Re {i:λ} > 0)'),
           19.5, color=VERMILION, weight=600)
    s.text(38, 450,
           ('{i:Π}{sub:d}{sup:st}({i:k}, {i:λ}){isub:ij}  =  {i:w}{isub:q}({i:λ}){sup:T} {i:D}{isub:d,k}{sup:(ij)}  +  {i:w}{isub:q}({i:λ}){sup:T} {i:R}{isub:d,k}{sup:(ij)} {i:w}{isub:q}({i:λ})',
            '{i:Π}{sub:d}{sup:st}({i:k}, {i:λ}){isub:ij}  =  {i:w}{isub:q}({i:λ}){sup:T} {i:D}{isub:d,k}{sup:(ij)}  +  {i:w}{isub:q}({i:λ}){sup:T} {i:R}{isub:d,k}{sup:(ij)} {i:w}{isub:q}({i:λ})'),
           20.5, weight=600)
    s.text(38, 482,
           ('无穷时间 Bochner–Laplace 算子积分无截断坍缩为有限源代数矩阵乘积，零数值求积误差',
            'Infinite-time Bochner–Laplace resolvent collapses algebraically into finite matrix products with zero quadrature error'),
           17.5)

    s.line(500, 500, 500, 520)
    s.line(170, 520, 830, 520)
    for bx in (170, 500, 830):
        s.line(bx, 520, bx, 536, arrow=True)

    s.box(20, 536, 300, 132,
          ('定理 14.2 · 消相光子连通馈入', 'Thm. 14.2 · Photon feed'),
          [('{i:c̄}{isub:d}{i:c}{isub:d} = ‖{i:ℓ}{sub:leg}({i:d})‖{sup:−2} > 0',
            '{i:c̄}{isub:d}{i:c}{isub:d} = ‖{i:ℓ}{sub:leg}({i:d})‖{sup:−2} > 0'),
           '∑ {i:e}{sub:nat}{i:J}{sup:conn} = ‖{i:ℓ}{sub:leg}‖{sup:−2}{i:𝒜}{sub:ph} − {i:𝒫}{sub:ph}',
           ('保留双侧有限 Green 腿', 'Both finite Green legs kept')])
    s.box(350, 536, 300, 132,
          ('定理 14.3 · Yukawa 截断消除', 'Thm. 14.3 · Cut elimination'),
          [('∀ {i:m}′ ∈ ℕ: {i:Π}{sub:d[m′]}{sup:st} = {i:Π}{sub:d}{sup:st}',
            '∀ {i:m}′ ∈ ℕ: {i:Π}{sub:d[m′]}{sup:st} = {i:Π}{sub:d}{sup:st}'),
           ('物理 {i:N}=3 五腿窗 {i:𝒲}{sub:d[m′]}{sup:N=3} = {i:𝒲}{sub:d}{sup:N=3}',
            '{i:N}=3 5-leg window cut-invariant'),
           ('一致六阶红外极限 {i:z}{sup:6}{i:Π}{sup:st} → {i:L}{isub:d}',
            'Uniform IR {i:z}{sup:6}{i:Π}{sup:st}(0,{i:z}) → {i:L}{isub:d}')],
          accent=GOLD)
    s.box(680, 536, 300, 132,
          ('移交 Case 3 零旋钮接口', 'Zero-knob handoff to Case 3'),
          [('五通道波包 + 复 Gram → 4×6 左逆',
            '5-channel + Gram → 4×6 inverse'),
           ('{i:H}{sub:289} + 有限 {i:Π}{sup:st} → 192/97 消因子',
            '{i:H}{sub:289} + {i:Π}{sup:st} → 192/97 Ward ratio'),
           ('连通光子馈入 → Thomson {i:α}{sub:src}(0)',
            'Photon feed → Thomson {i:α}{sub:src}(0)')],
          fill=WASH)
    return s.save('fig05-sylvester-collapse')


def draw_fig06(lang: str) -> Path:
    s = Plate(558, lang, (
        '五维原点轻核的双时间尺度色散谱与动态度规射线极限',
        'Dual-scale dispersion of the 5D origin light kernel and ray-dependent metric response',
    ))
    # Left panel: Dual-scale dispersion curves |u| vs q_ax
    s.card(20, 18, 468, 412, fill='white', accent=DEEP)
    s.text(36, 48,
           ('五维原点轻核：三线性锥 + 二次慢模',
            '5D origin light kernel: 3 cones + slow mode'),
           18.5, weight=600, max_width=436)
    lx0, lx1, ly0, ly1 = 92, 462, 372, 82
    q_max, u_max = 1.0, 1.35
    lxp = lambda q: lx0 + (lx1 - lx0) * (q / q_max)
    lyp = lambda u: ly0 - (ly0 - ly1) * (u / u_max)

    for qv in (0.0, 0.25, 0.5, 0.75, 1.0):
        s.line(lxp(qv), ly1, lxp(qv), ly0, HAIR, 1.0, dash='3 4')
        s.text(lxp(qv), ly0 + 23, f'{qv:.2g}', 17, color=SLATE, anchor='middle', max_width=64)
    for uv in (0.0, 0.4, 0.8, 1.2):
        s.line(lx0, lyp(uv), lx1, lyp(uv), HAIR, 1.0, dash='3 4')
        s.text(lx0 - 10, lyp(uv) + 6, f'{uv:.1f}', 17, color=SLATE, anchor='end', max_width=52)
    s.line(lx0, ly0, lx1, ly0, SLATE, 1.3)
    s.line(lx0, ly1, lx0, ly0, SLATE, 1.3)
    s.text((lx0 + lx1) / 2, ly0 + 48,
           ('轴向波数 {i:q}{sub:ax} = {i:k}{sub:3} / √2', 'Axial wavenumber {i:q}{sub:ax} = {i:k}{sub:3} / √2'),
           17.5, color=SLATE, anchor='middle', max_width=360)
    s.text(36, 74, '|{i:u}|', 18, color=SLATE, weight=600, max_width=50)

    c_fast1 = math.sqrt(5.0 / 3.0)       # 1.29099
    c_fast2 = math.sqrt(55.0 / 67.0)     # 0.90599
    c_real = math.sqrt(125.0 / 162.0)    # 0.87831
    s.polyline([(lxp(0), lyp(0)), (lxp(1.0), lyp(c_fast1))], stroke=SLATE, width=2.2, dash='7 5')
    s.polyline([(lxp(0), lyp(0)), (lxp(1.0), lyp(c_fast2))], stroke=DEEP, width=2.3)
    s.polyline([(lxp(0), lyp(0)), (lxp(1.0), lyp(c_real))], stroke=VERMILION, width=2.8)
    slow_pts = [(lxp(k / 40.0), lyp((5.0 / 6.0) * (k / 40.0) ** 2)) for k in range(41)]
    s.polyline(slow_pts, stroke=GOLD, width=2.9)

    # Place all 3 linear-cone labels in the clear upper-left triangle (q < 0.56, u > 0.72)
    s.line(lxp(0.54), lyp(1.17), lxp(0.82), lyp(0.82 * c_fast1), stroke=SLATE, width=1.1)
    s.text(lxp(0.03), lyp(1.15),
           ('|Im {i:u}| = √(5/3) {i:q}{sub:ax}', '|Im {i:u}| = √(5/3) {i:q}{sub:ax}'),
           17, color=SLATE, max_width=200)
    s.line(lxp(0.56), lyp(0.96), lxp(0.76), lyp(0.76 * c_fast2), stroke=DEEP, width=1.1)
    s.text(lxp(0.03), lyp(0.94),
           ('|Im {i:u}| = √(55/67) {i:q}{sub:ax}', '|Im {i:u}| = √(55/67) {i:q}{sub:ax}'),
           17, color=DEEP, max_width=215)
    s.line(lxp(0.65), lyp(0.75), lxp(0.84), lyp(0.84 * c_real), stroke=VERMILION, width=1.2)
    s.text(lxp(0.03), lyp(0.73),
           ('实锥 {i:u} = √(125/162) {i:q}{sub:ax}', 'Real {i:u} = √(125/162) {i:q}{sub:ax}'),
           17, color=VERMILION, weight=600, max_width=235)
    # Place slow-mode label in the clear lower-right zone below the parabola
    s.line(lxp(0.66), lyp(0.13), lxp(0.58), lyp((5.0 / 6.0) * 0.58 ** 2), stroke=GOLD, width=1.2)
    s.text(lxp(0.99), lyp(0.07),
           ('慢模 |Im {i:u}| = (5/6){i:q}{sub:ax}{sup:2}', 'Slow |Im {i:u}| = (5/6){i:q}{sub:ax}{sup:2}'),
           17, color=GOLD, weight=600, anchor='end', max_width=230)

    # Right panel: Ray-dependent metric limit G_00(r q, q) / N vs r = u / q_ax
    s.card(512, 18, 468, 412, fill='white', accent=VERMILION)
    s.text(528, 48,
           ('度规 {i:G}{sub:00}({i:rq}{sub:ax}, {i:q}{sub:ax}) / {i:N} 的非交换射线极限',
            'Non-commuting ray limit {i:G}{sub:00}({i:rq}{sub:ax}, {i:q}{sub:ax}) / {i:N}'),
           18.5, weight=600, max_width=436)
    rx0, rx1, ry0, ry1 = 592, 958, 372, 82
    r_max, y_lo, y_hi = 2.4, -0.35, 0.65
    rxp = lambda r: rx0 + (rx1 - rx0) * (r / r_max)
    ryp = lambda y: ry0 - (ry0 - ry1) * ((y - y_lo) / (y_hi - y_lo))

    for rv in (0.0, 0.6, 1.2, 1.8, 2.4):
        s.line(rxp(rv), ry1, rxp(rv), ry0, HAIR, 1.0, dash='3 4')
        s.text(rxp(rv), ry0 + 23, f'{rv:.1f}', 17, color=SLATE, anchor='middle', max_width=64)
    for yv in (-0.2, 0.0, 0.2, 0.4, 0.6):
        s.line(rx0, ryp(yv), rx1, ryp(yv), HAIR, 1.0, dash='3 4')
        s.text(rx0 - 10, ryp(yv) + 6, f'{yv:.1f}'.replace('-', '−'), 17, color=SLATE, anchor='end', max_width=56)
    s.line(rx0, ryp(0.0), rx1, ryp(0.0), SLATE, 1.1)
    s.line(rx0, ry0, rx1, ry0, SLATE, 1.3)
    s.line(rx0, ry1, rx0, ry0, SLATE, 1.3)
    s.text((rx0 + rx1) / 2, ry0 + 48,
           ('趋近原点射线斜率 {i:r} = {i:u} / {i:q}{sub:ax}', 'Origin approach ray slope {i:r} = {i:u} / {i:q}{sub:ax}'),
           17.5, color=SLATE, anchor='middle', max_width=360)

    def g00_over_n(r: float) -> float:
        return 18.0 * (297.0 * r * r - 125.0) / (125.0 * (162.0 * r * r - 125.0))

    r_pole = math.sqrt(125.0 / 162.0)
    # Asymptotes: vertical pole r_* and horizontal homogeneous limit 33/125 = 0.264
    s.line(rxp(r_pole), ry1, rxp(r_pole), ry0, VERMILION, 1.8, dash='6 4')
    s.line(rx0, ryp(0.264), rx1, ryp(0.264), GOLD, 1.8, dash='6 4')

    left_branch = []
    for k in range(0, 79):
        rv = 0.78 * k / 78.0
        yv = g00_over_n(rv)
        if yv >= y_lo:
            left_branch.append((rxp(rv), ryp(yv)))
    right_branch = []
    for k in range(0, 95):
        rv = 1.045 + (r_max - 1.045) * k / 94.0
        yv = g00_over_n(rv)
        if yv <= y_hi:
            right_branch.append((rxp(rv), ryp(yv)))
    s.polyline(left_branch, stroke=DEEP, width=2.8)
    s.polyline(right_branch, stroke=DEEP, width=2.8)
    s.circle(rxp(0.0), ryp(0.144), r=5.2, fill=DEEP)

    s.text(rxp(0.03), ryp(0.19),
           ('{i:r}=0: 18/125', '{i:r}=0: 18/125'),
           17, color=DEEP, weight=600, max_width=120)
    s.text(rxp(r_pole) + 8, ry1 + 20,
           ('极点 {i:r}{sub:*} ≈ 0.878', 'Pole {i:r}{sub:*} ≈ 0.878'),
           17, color=VERMILION, weight=600, max_width=180)
    s.text(rxp(2.38), ryp(0.17),
           ('齐次 {i:r}→∞: 33/125 = 0.264', '{i:r} → ∞: 33/125 = 0.264'),
           17, color=GOLD, weight=600, anchor='end', max_width=218)

    s.card(20, 444, 960, 96, fill=WASH, accent=VERMILION)
    s.text(38, 478,
           ('精确分解（式 5.14–5.15）：lim {i:G}{sub:00}({i:rq}{sub:ax},{i:q}{sub:ax}) / {i:N}  =  18/125（局部接触） +  486{i:r}{sup:2} / [25(162{i:r}{sup:2} − 125)]（轴向轻相位极点）',
            'Exact decomposition (Eqs. 5.14–5.15): lim {i:G}{sub:00}({i:rq}{sub:ax},{i:q}{sub:ax}) / {i:N}  =  18/125 (contact) + 486{i:r}{sup:2} / [25(162{i:r}{sup:2} − 125)] (light pole)'),
           17.5, weight=600)
    s.text(38, 514,
           ('无隙集体传播锥使静态筛选极限 ({i:r} = 0) 与空间齐次极限 ({i:r} → ∞) 在二元原点 (0, 0) 严格不可交换。',
            'The gapless collective cone renders the static ({i:r} = 0) and homogeneous ({i:r} → ∞) limits strictly non-commuting at (0, 0).'),
           17.5, color=VERMILION)
    return s.save('fig06-light-kernel')


def render_pdf_and_preview(svg_path: Path, preview_dir: Path | None = None) -> Path:
    chrome = Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    pdftoppm = shutil.which('pdftoppm') or '/opt/homebrew/bin/pdftoppm'
    head = svg_path.read_text()[:600]
    m = re.search(r'viewBox="0 0 (\d+) (\d+)"', head)
    assert m, svg_path
    w, h = int(m.group(1)), int(m.group(2))
    pdf_path = svg_path.with_suffix('.pdf')
    pdf_path.unlink(missing_ok=True)
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as work:
        work_p = Path(work)
        page = work_p / 'page.html'
        page.write_text(
            '<!doctype html><html><head><meta charset="utf-8"><style>'
            f'@page{{size:{w}px {h}px;margin:0}}html,body{{margin:0;padding:0}}'
            f'img{{display:block;width:{w}px;height:{h}px}}</style></head>'
            f'<body><img src="{svg_path.resolve().as_uri()}"></body></html>'
        )
        proc = subprocess.Popen(
            [str(chrome), '--headless=new', '--disable-gpu', '--no-first-run',
             '--no-pdf-header-footer', '--allow-file-access-from-files',
             f'--user-data-dir={work_p}/profile', f'--print-to-pdf={pdf_path}',
             page.as_uri()],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
        )
        started = time.monotonic()
        while not (pdf_path.exists() and pdf_path.stat().st_size > 1000) and time.monotonic() - started < 35:
            time.sleep(0.2)
        time.sleep(0.3)
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
        assert pdf_path.exists() and pdf_path.stat().st_size > 1000, pdf_path
        if preview_dir is not None:
            preview_dir.mkdir(parents=True, exist_ok=True)
            subprocess.run(
                [pdftoppm, '-png', '-singlefile', '-scale-to-x', str(2 * w), '-scale-to-y', '-1',
                 str(pdf_path), str(preview_dir / svg_path.stem)],
                check=True, capture_output=True,
            )
    return pdf_path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--lang', choices=('zh', 'en', 'both'), default='both')
    ap.add_argument('--svg-only', action='store_true')
    ap.add_argument('--preview-dir', type=Path, default=None,
                    help='Optional temporary directory for 2x PNG visual inspection')
    args = ap.parse_args()
    langs = ('zh', 'en') if args.lang == 'both' else (args.lang,)
    builders = (draw_fig01, draw_fig02, draw_fig03, draw_fig04, draw_fig05, draw_fig06)
    written = []
    for lang in langs:
        for fn in builders:
            svg = fn(lang)
            if not args.svg_only:
                render_pdf_and_preview(svg, args.preview_dir)
            written.append(svg.name)
    print(f'Generated {len(written)} v2 figure sets: {", ".join(written)}')


if __name__ == '__main__':
    main()
