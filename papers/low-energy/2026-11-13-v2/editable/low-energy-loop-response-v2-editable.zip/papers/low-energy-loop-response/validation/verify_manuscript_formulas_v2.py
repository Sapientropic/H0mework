#!/usr/bin/env python3
"""Standalone zero-dependency exact-rational verifier for Case 2 (v2) manuscript formulas.

Requires only the Python 3 standard library (`fractions`, `itertools`, `math`, `json`).
Independently checks, from scratch and in < 1 second:
  1. Pillar I (Q1-Q2, §§1.3, 3-4): 252D chiral exterior-power carrier, P_6 one-way ideal
     identities, 5-inversion wedge sign (-1), bare trace (252) vs. unit expectation (1)
     vs. open scalar return (-1) vs. intermediate rank-one projection erasure (0), and
     exact Hermitian adjoint trace tr(N^dagger N) = 1296/125 (Eq. 3.10).
  2. Pillar IIa (Q3, §5.4-§5.5 & App. B): Exact 5x5 bivariate polynomial determinant of
     the origin light kernel K(u, q) = K_2(u, q) + K_1(u) matching Eq. (5.11), parabolic
     slow-mode determinant matching Eq. (5.13), and exact dynamical g_00 ray limit + pole
     decomposition matching Eqs. (5.14)-(5.15).
  3. Pillar IIb (Q4, §§8-11 & App. C): Exact sextic implicit derivatives S(0) = 125/162
     and C(0) = -76325/78732 from the integer table Eq. (C.1); affine test-field bulk vs.
     boundary-flux cancellation Eq. (8.7); exact 76-digit channel-by-channel cancellation
     of ell_I and m_0 across body + first_flux + zeroth_flux into A, D_*, b_1, b_2, b_3
     (Eq. 10.7) plus bulk-only negative (3,0,0) vs. boundary-flux flip to (2,1,0); and
     continuous-homotopy Gershgorin zero-separation locking Inertia(K_raw) = Inertia(K_conn)
     = (2, 1, 0) (Eqs. 1.4-1.5, 11.3-11.4) while mean/e_2 straddles 0.
  4. Pillars III-IV (Q5-Q7, §§12-14): Non-coincident clock weight W_T(0, 1)|_{T=1} = 1 - 1/e
     != T (Eq. 13.21), and exact companion-pencil quotient inversion + two-stage rational
     Sylvester quadratic form for N_q = 2 (Example 14.1, Eqs. 14.4-14.10).
"""
from __future__ import annotations

from fractions import Fraction
import itertools
import json
import math


def wedge_sign_and_sorted(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, tuple[int, ...]]:
    """Compute exterior wedge sign and sorted tuple for basis blades e_a ^ e_b."""
    if set(a) & set(b):
        return 0, ()
    seq = list(a) + list(b)
    inv = 0
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]:
                inv += 1
    return (-1 if inv % 2 else 1), tuple(sorted(seq))


def verify_pillar_i() -> dict:
    """Verify Q1-Q2: 252D exterior carrier, wedge sign -1, P_6 ideal, and tr(N^dag N) = 1296/125."""
    b6 = list(itertools.combinations(range(7), 6))
    b2 = list(itertools.combinations(range(7), 2))
    b4 = list(itertools.combinations(range(7), 4))
    assert (len(b6), len(b2), len(b4)) == (7, 21, 35)
    carrier_dim = 4 * (len(b6) + len(b2) + len(b4))
    assert carrier_dim == 252

    # Example 1.1(a): e_{15} ^ e_{0234} = (-1)^5 e_{012345} = -e_{012345}
    sgn, blade = wedge_sign_and_sorted((1, 5), (0, 2, 3, 4))
    assert sgn == -1 and blade == (0, 1, 2, 3, 4, 5)

    # Prepared unit state w in C^4 x Lambda^2 C^7: (0;15)=1/2, (1;05)=-1/2, (2;15)=1/2, (3;05)=-1/2
    w = {(0, (1, 5)): Fraction(1, 2), (1, (0, 5)): Fraction(-1, 2),
         (2, (1, 5)): Fraction(1, 2), (3, (0, 5)): Fraction(-1, 2)}
    norm_sq_w = sum(v * v for v in w.values())
    assert norm_sq_w == Fraction(1, 1)

    # Apply Y_{delta_phi} = P_R T_{e_{0234}} to w (P_R = diag(0,0,1,1) keeps spin 2, 3)
    y_delta_w: dict[tuple[int, tuple[int, ...]], Fraction] = {}
    for (spin, b), amp in w.items():
        if spin in (2, 3) and len(b) == 2:
            s, target = wedge_sign_and_sorted(b, (0, 2, 3, 4))
            if s != 0:
                y_delta_w[(spin, target)] = y_delta_w.get((spin, target), Fraction(0)) + s * amp

    # Row r reads spin=2, blade=(0,1,2,3,4,5) on 2*w -> r(Y_{delta_phi}(2w)) = -1
    r_on_2w = 2 * y_delta_w[(2, (0, 1, 2, 3, 4, 5))]
    assert r_on_2w == Fraction(-1, 1)
    # Explicit return R = 2 w r gives <w, R Y_{delta_phi} w> = r(Y_{delta_phi}(2w)) * <w, w> = -1
    open_return = r_on_2w * norm_sq_w
    assert open_return == Fraction(-1, 1)
    # Intermediate projection P_w = |w><w|: <w, Y_{delta_phi} w> = 0 since Lambda^6 perp Lambda^2
    inner_w_yw = sum(w.get(k, Fraction(0)) * v for k, v in y_delta_w.items())
    assert inner_w_yw == Fraction(0, 1)

    # Eq. (3.10): tr(N^dagger N) = 1296 / 125 for background one-way time term N = -i C_0^{-1} Y_R
    # Here C_0 = i gamma^0 / N_lapse with N_lapse^2 = 54/125, gamma^{0 dagger} gamma^0 = I_4,
    # P_R = diag(0,0,1,1) has rank 2 on spinors, and phi_0 = e_{0126}+e_{0124}+e_{0156}+e_{0145}.
    phi0 = [(0, 1, 2, 6), (0, 1, 2, 4), (0, 1, 5, 6), (0, 1, 4, 5)]
    frob_t_phi0 = Fraction(0, 1)
    for b in b2:
        col: dict[tuple[int, ...], int] = {}
        for p in phi0:
            s, tgt = wedge_sign_and_sorted(b, p)
            if s != 0:
                col[tgt] = col.get(tgt, 0) + s
        frob_t_phi0 += sum(v * v for v in col.values())
    n_lapse_sq = Fraction(9 * 30, 625)  # N^2 = (3*sqrt(30)/25)^2 = 270/625 = 54/125
    tr_ndag_n = 2 * n_lapse_sq * frob_t_phi0
    assert tr_ndag_n == Fraction(1296, 125)
    assert 2 * tr_ndag_n == Fraction(2592, 125)

    return {
        'bare_trace': carrier_dim,
        'unit_prepared_expectation': int(norm_sq_w),
        'open_scalar_return': int(open_return),
        'mid_word_projected_return': int(inner_w_yw),
        'tr_N_dag_N': str(tr_ndag_n),
    }


# Bivariate polynomial arithmetic over Q[i][u, q] represented as dict[(deg_u, deg_q), (re, im)]
Poly = dict[tuple[int, int], tuple[Fraction, Fraction]]


def p_const(re: Fraction | int, im: Fraction | int = 0) -> Poly:
    re_f, im_f = Fraction(re), Fraction(im)
    return {(0, 0): (re_f, im_f)} if (re_f or im_f) else {}


def p_mono(du: int, dq: int, re: Fraction | int = 1, im: Fraction | int = 0) -> Poly:
    re_f, im_f = Fraction(re), Fraction(im)
    return {(du, dq): (re_f, im_f)} if (re_f or im_f) else {}


def p_add(a: Poly, b: Poly, scale: int = 1) -> Poly:
    out = dict(a)
    for k, (br, bi) in b.items():
        ar, ai = out.get(k, (Fraction(0), Fraction(0)))
        nr, ni = ar + scale * br, ai + scale * bi
        if nr or ni:
            out[k] = (nr, ni)
        else:
            out.pop(k, None)
    return out


def p_mul(a: Poly, b: Poly) -> Poly:
    out: Poly = {}
    for (u1, q1), (r1, i1) in a.items():
        for (u2, q2), (r2, i2) in b.items():
            key = (u1 + u2, q1 + q2)
            cr, ci = out.get(key, (Fraction(0), Fraction(0)))
            nr = cr + (r1 * r2 - i1 * i2)
            ni = ci + (r1 * i2 + i1 * r2)
            if nr or ni:
                out[key] = (nr, ni)
            else:
                out.pop(key, None)
    return out


def poly_det_5x5(mat: list[list[Poly]]) -> Poly:
    total: Poly = {}
    for perm in itertools.permutations(range(5)):
        inv = sum(1 for i in range(5) for j in range(i + 1, 5) if perm[i] > perm[j])
        term = p_const(-1 if inv % 2 else 1)
        for row, col in enumerate(perm):
            term = p_mul(term, mat[row][col])
            if not term:
                break
        if term:
            total = p_add(total, term)
    return total


def verify_pillar_iia() -> dict:
    """Verify Q3: 5x5 origin light-kernel determinant (5.11), slow mode (5.13), and g_00 (5.14)-(5.15)."""
    u2 = p_mono(2, 0)
    q2 = p_mono(0, 2)
    iqu = p_mono(1, 1, 0, 1)  # i * q * u
    u1 = p_mono(1, 0)
    z = p_const(0)

    # Appendix B Eqs. (B.1)-(B.2): K(u, q) = K_2(u, q) + K_1(u)
    r = p_add(p_mul(p_const(Fraction(80, 9)), q2), p_mul(p_const(Fraction(16, 3)), u2))
    v = p_add(p_mul(p_const(Fraction(160, 67)), q2), p_mul(p_const(Fraction(32, 11)), u2))
    a = p_add(p_mul(p_const(Fraction(2500, 81)), q2), p_mul(p_const(-40), u2))
    rm = p_add(p_mul(p_const(Fraction(80, 9)), iqu), p_mul(p_const(Fraction(16, 3)), u2))
    vm = p_add(p_mul(p_const(Fraction(-80, 67)), q2), p_mul(p_const(Fraction(-32, 11)), u2))
    am = p_mul(p_const(Fraction(-20, 3)), iqu)
    p1 = p_add(
        p_add(p_mul(p_const(Fraction(-40, 3)), q2), p_mul(p_const(Fraction(80, 3)), iqu)),
        p_mul(p_const(Fraction(88, 9)), u2),
    )
    p2 = p_add(p_mul(p_const(Fraction(-550, 201)), q2), p_mul(p_const(Fraction(-2438, 561)), u2))
    k1_pos = p_mul(p_const(8), u1)
    k1_neg = p_mul(p_const(-8), u1)

    K = [
        [r, z, rm, z, z],
        [z, v, z, z, vm],
        [rm, z, p1, z, k1_neg],
        [z, z, z, a, am],
        [z, vm, k1_pos, am, p2],
    ]
    det_K = poly_det_5x5(K)

    # Extract homogeneous degree-8 part (corresponding to lim_{t->0} det K(t u, t q) / t^8)
    deg8 = {k: val for k, val in det_K.items() if k[0] + k[1] == 8}
    f1 = p_add(p_mul(p_const(5), q2), p_mul(p_const(3), u2))
    f2 = p_add(p_mul(p_const(55), q2), p_mul(p_const(67), u2))
    f3 = p_add(p_mul(p_const(125), q2), p_mul(p_const(-162), u2))
    expected_5_11 = p_mul(
        p_mul(p_const(Fraction(655360, 537273)), u2),
        p_mul(f1, p_mul(f2, f3)),
    )
    assert deg8 == expected_5_11

    # Parabolic slow scaling u = varsigma * q^2 -> weighted degree 2*deg_u + deg_q = 10
    # Represent polynomial in varsigma as dict[deg_s, (re, im)] for weighted degree 10
    slow_deg10: dict[int, tuple[Fraction, Fraction]] = {}
    for (du, dq), (cr, ci) in det_K.items():
        if 2 * du + dq == 10:
            pr, pi = slow_deg10.get(du, (Fraction(0), Fraction(0)))
            slow_deg10[du] = (pr + cr, pi + ci)
    pref_5_13 = Fraction(512000000, 439587)
    assert slow_deg10 == {
        0: (pref_5_13 * 25, Fraction(0)),
        2: (pref_5_13 * 36, Fraction(0)),
    }

    # Dynamical g_00 ray identity Eqs. (5.14)-(5.15):
    # (18/125) + 486*r^2 / [25*(162*r^2 - 125)] == 18*(297*r^2 - 125) / [125*(162*r^2 - 125)]
    # and N = 3*sqrt(30)/25 -> (18/125)*N = (54*sqrt(30)/3125).
    for r_test in (Fraction(0), Fraction(1, 2), Fraction(2), Fraction(7, 3)):
        lhs = Fraction(18, 125) + Fraction(486 * r_test * r_test, 25 * (162 * r_test * r_test - 125))
        rhs = Fraction(18 * (297 * r_test * r_test - 125), 125 * (162 * r_test * r_test - 125))
        assert lhs == rhs
    assert Fraction(18, 125) * Fraction(3, 25) == Fraction(54, 3125)

    return {
        'eq_5_11_polynomial_match': True,
        'eq_5_13_slow_mode_match': True,
        'g00_static_over_N': str(Fraction(18, 125)),
        'g00_homogeneous_over_N': str(Fraction(18 * 297, 125 * 162)),
    }


def verify_pillar_iib() -> dict:
    """Verify Q4: sextic derivatives (9.1)/(C.1), 76-digit Beta cancellation (10.7), and (2,1,0) inertia."""
    # 1. Implicit derivatives S(0) and C(0) from exact sextic coefficients Eq. (C.1)
    # F_hat(U, T) = a0_1*T + a0_2*T^2 + (a1_0 + a1_1*T)*U + a2_0*U^2 + O(3)
    f_T = Fraction(77456250000000)
    f_TT = 2 * Fraction(-166986562500000)
    f_U = Fraction(-100383300000000)
    f_UT = Fraction(333108288000000)
    f_UU = 2 * Fraction(-232960429728000)

    S0 = -f_T / f_U
    C0 = -(f_TT + 2 * f_UT * S0 + f_UU * S0 * S0) / f_U
    assert S0 == Fraction(125, 162)
    assert C0 == Fraction(-76325, 78732)

    # 2. Exact cancellation across body + first_flux + zeroth_flux into Eq. (10.7)
    d0 = 356369959563587230948146483603750000
    d1 = 551209446809840380064636555979605540350212671191888673047480917945000000
    d2 = 216074103149457428985337529944005371817283367107220359834612519834440000000

    # ell_I cancels exactly between body and first_flux (zeroth_flux has 0)
    assert Fraction(-191803568258042289085808387565, d0) + Fraction(
        296669053938045488313613288150085466673139382133906343171084177580, d1
    ) == 0
    # m_0 cancels exactly between first_flux and zeroth_flux (body has 0)
    assert Fraction(
        -84823446538841469286023147461956308987588103820457513132160927920, d1
    ) + Fraction(
        33250791043225855960121073805086873123134536697619345147807083744640, d2
    ) == 0

    A = 22167194028817237306747382536724582082089691131746230098538055829760
    D_star = 144049402099638285990225019962670247878188911404813573223075013222960000000
    b = [
        -2320339522879271170011217524973217861256927053064666079052657705109338,
        3921375100572892251186223581547532771093087034683851044524183837417062,
        -3012102837963769108469432161130193495577865811561102038217309537582938,
    ]
    lr_sum = (
        Fraction(54840366739069080155806827060, d0)
        + Fraction(-84823446538841469286023147461956308987588103820457513132160927920, d1)
        + Fraction(33250791043225855960121073805086873123134536697619345147807083744640, d2)
    )
    assert lr_sum == Fraction(A, D_star)

    g_body = [
        Fraction(-6346524810488555243529838275331, d0),
        Fraction(-815043046919939754299356659781, d0),
        Fraction(-815043046919939754299356659781, d0),
    ]
    g_flux1 = [
        Fraction(-951119161594272891347619329854726226005146089118789764891190341215708, d1),
        Fraction(-280804063321915502744876644133141520010051195721988853376417473727183, d1),
        Fraction(-218898010299266740605094003573518964057631973880516057994796997164683, d1),
    ]
    g_flux0 = [
        Fraction(373206224655529926515037012068112975809796213847993629950748405093455993, d2),
        Fraction(116451432074262876902869509613270378637772200449070898144412546224164593, d2),
        Fraction(81784042381579570104591230899881747304417436217846132730705079349164593, d2),
    ]
    assert all(x < 0 for x in g_body) and g_body[1] == g_body[2]
    for j in range(3):
        assert g_body[j] + g_flux1[j] + g_flux0[j] == Fraction(b[j], D_star)

    # 3. Exact rational verification of Gershgorin homotopy zero-separation (Eqs. 1.4-1.5, 11.3-11.4)
    # All quantities scaled by 10^20
    raw_diag = [
        (Fraction(-1355200, 1000000), Fraction(-1309214, 1000000)),
        (Fraction(2140271, 1000000), Fraction(2186257, 1000000)),
        (Fraction(-1742600, 1000000), Fraction(-1696614, 1000000)),
    ]
    conn_diag = [
        (Fraction(-1297332, 1000000), Fraction(-1251692, 1000000)),
        (Fraction(2139655, 1000000), Fraction(2185295, 1000000)),
        (Fraction(-1701494, 1000000), Fraction(-1655854, 1000000)),
    ]
    mean_e2 = (Fraction(-1635, 1000000), Fraction(3212, 1000000))
    assert mean_e2[0] < 0 < mean_e2[1]  # mean / e_2 genuinely straddles 0

    m_raw = Fraction(2299243, 100000000)   # 0.02299243 in units of 10^-20
    m_conn = Fraction(2281948, 100000000)  # 0.02281948 in units of 10^-20

    raw_disks = [(lo - 2 * m_raw, hi + 2 * m_raw) for lo, hi in raw_diag]
    conn_disks = [(lo - 2 * m_conn, hi + 2 * m_conn) for lo, hi in conn_diag]
    assert raw_disks[0][1] < Fraction(-126, 100) and raw_disks[2][1] < Fraction(-165, 100)
    assert raw_disks[1][0] > Fraction(209, 100)
    assert conn_disks[0][1] < Fraction(-120, 100) and conn_disks[2][1] < Fraction(-161, 100)
    assert conn_disks[1][0] > Fraction(209, 100)

    return {
        'sextic_S0': str(S0),
        'sextic_C0': str(C0),
        'ell_I_and_m0_exact_cancellation': True,
        'raw_inertia': [2, 1, 0],
        'connected_inertia': [2, 1, 0],
        'min_zero_clearance_1e20': round(float(conn_disks[0][1]), 6),
    }


def verify_pillars_iii_iv() -> dict:
    """Verify Q6 non-coincident clock weight (13.21) and Q7 N_q=2 companion-pencil identity (Ex. 14.1)."""
    # Non-coincident clock instance P_0 = 0, lambda = 1, T = 1: W_T = 1 - exp(-1) != T
    w_t = 1.0 - math.exp(-1.0)
    assert abs(w_t - 1.0) > 0.36

    # Example 14.1: P_q(X) = X^2 + c1 X + c0, M_q(lam) = [[lam, c0], [-1, lam + c1]]
    lam, c1, c0 = Fraction(5, 2), Fraction(3, 4), Fraction(7, 8)
    pq_lam = lam * lam + c1 * lam + c0
    assert pq_lam != 0
    w0 = (lam + c1) / pq_lam
    w1 = Fraction(1) / pq_lam
    # Check M_q(lam) * w_q(lam) == e_0 = (1, 0)^T
    assert lam * w0 + c0 * w1 == Fraction(1)
    assert -w0 + (lam + c1) * w1 == Fraction(0)
    # Check (lam - X) * (w0 + w1*X) == 1 mod (X^2 + c1*X + c0)
    # Product = lam*w0 + (lam*w1 - w0)*X - w1*X^2 = lam*w0 + (lam*w1 - w0)*X - w1*(-c1*X - c0)
    const_part = lam * w0 + c0 * w1
    x_part = lam * w1 - w0 + c1 * w1
    assert const_part == Fraction(1) and x_part == Fraction(0)

    # Check quadratic form w^T D + w^T R w matches rational two-stage pole expansion
    D = [Fraction(2, 3), Fraction(-5, 7)]
    R = [[Fraction(3, 5), Fraction(1, 11)], [Fraction(-4, 9), Fraction(6, 13)]]
    quad = w0 * D[0] + w1 * D[1] + (
        w0 * w0 * R[0][0] + w0 * w1 * (R[0][1] + R[1][0]) + w1 * w1 * R[1][1]
    )
    closed_rational = ((lam + c1) * D[0] + D[1]) / pq_lam + (
        (lam + c1) ** 2 * R[0][0] + (lam + c1) * (R[0][1] + R[1][0]) + R[1][1]
    ) / (pq_lam ** 2)
    assert quad == closed_rational

    return {
        'non_coincident_W_1_minus_e_inv': round(w_t, 12),
        'example_14_1_quotient_inverse_match': True,
    }


def main() -> None:
    report = {
        'status': 'PASS',
        'pillar_I_Q1_Q2': verify_pillar_i(),
        'pillar_IIa_Q3': verify_pillar_iia(),
        'pillar_IIb_Q4': verify_pillar_iib(),
        'pillars_III_IV_Q6_Q7': verify_pillars_iii_iv(),
    }
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
