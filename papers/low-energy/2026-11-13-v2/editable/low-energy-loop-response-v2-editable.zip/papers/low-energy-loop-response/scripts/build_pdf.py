#!/usr/bin/env python3
"""Build both Case 2 Second Edition (v2) PDFs using the shared publication layout."""
import argparse
import json
import os
import re
import signal
import subprocess
import sys
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
sys.path.insert(0, str(ROOT / 'shared/scripts'))
import build_pdf as shared

ZH = 'papers/low-energy-loop-response/manuscript.md'
EN = 'papers/low-energy-loop-response/manuscript-en.md'
shared.RUNHEADS[ZH] = (
    'low-energy-loop-response',
    'CourtyCourt · Case 2',
    '无截断极化曲率与整球 (2,1) 惯性律',
)
shared.RUNHEADS[EN] = (
    'low-energy-loop-response',
    'CourtyCourt · Case 2',
    'Cutoff-Free Polarization Curvature and (2,1) Inertia',
)
shared.CONTINUOUS_APPENDICES.add(ZH)
shared.CONTINUOUS_APPENDICES.add(EN)

# Prevent body headings or bold notes in English from being consumed as a subtitle.
_latin_title = shared.latin_title
def _subtitle(line):
    stripped = line.strip()
    if stripped in ('# Abstract', '## Abstract') or stripped.startswith('**Formal verification'):
        return None
    return _latin_title(line)
shared.latin_title = _subtitle

# Unbox multi-paragraph abstracts and the multi-page 32-item bibliography so
# neither overflows a single-page minipage, while keeping headings glued.
_prepare = shared.prepare
def _prepare_paginated_refs(source, toc, profile):
    title, subtitle, body = _prepare(source, toc, profile)
    body = re.sub(
        r'```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n'
        r'(#{1,2} (?:摘要|Abstract(?: \(English\))?)\s*)\n\n'
        r'```\{=latex\}\n(\\begingroup\\small[^\n]+)\n```'
        r'(.*?)'
        r'```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```',
        lambda m: (
            '```{=latex}\n\\Needspace{9\\baselineskip}\n```\n\n'
            + m.group(1)
            + '\n\n```{=latex}\n'
            + m.group(2)
            + '\n```'
            + m.group(3)
            + '```{=latex}\n\\endgroup\\par\n```'
        ),
        body,
        flags=re.S,
    )
    body = re.sub(
        r'```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n'
        r'(# (?:参考文献|References)\s*)\n\n'
        r'```\{=latex\}\n(\\begingroup\\footnotesize[^\n]+)\n```',
        lambda m: (
            '```{=latex}\n\\Needspace{8\\baselineskip}\n```\n\n'
            + m.group(1)
            + '\n\n```{=latex}\n'
            + m.group(2)
            + '\n```'
        ),
        body,
        count=1,
    )
    body = re.sub(
        r'```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```\s*\Z',
        lambda _: '```{=latex}\n\\endgroup\\par\n```\n',
        body,
        count=1,
    )
    return title, subtitle, body
shared.prepare = _prepare_paginated_refs

# Scale tall architecture plates cleanly and keep continuous appendix headings off page feet.
_compile_tex = shared.compile_tex
def _compile_with_v2_plates(tex):
    params = tex.parent / 'paper-params.tex'
    if params.exists():
        ptext = params.read_text()
        guard = '\\AtBeginDocument{\\pretocmd{\\section}{\\Needspace{11\\baselineskip}}{}{}}\n'
        if guard not in ptext:
            params.write_text(ptext + guard)
    text = tex.read_text()
    text = re.sub(
        r'(\\includegraphics\[width=\\linewidth,height=)0\.62'
        r'(\\textheight,keepaspectratio\]\{[^}]*fig03-inertia-v2(?:-en)?\.pdf\})',
        r'\g<1>0.74\2',
        text,
    )
    text = re.sub(
        r'(\\includegraphics\[width=\\linewidth,height=)0\.62'
        r'(\\textheight,keepaspectratio\]\{[^}]*fig04-full-return(?:-v2)?(?:-en)?\.pdf\})',
        r'\g<1>0.80\2',
        text,
    )
    text = re.sub(
        r'(\\includegraphics\[width=\\linewidth,height=)0\.62'
        r'(\\textheight,keepaspectratio\]\{[^}]*fig05-sylvester-collapse-v2(?:-en)?\.pdf\})',
        r'\g<1>0.72\2',
        text,
    )
    tex.write_text(text)
    return _compile_tex(tex)
shared.compile_tex = _compile_with_v2_plates

_run = shared.run
def _run_in_paper_cache(command, cwd=None):
    args = [str(item) for item in command]
    if args[0] == shared.CHROME:
        cache = PAPER / 'build/chrome-pdf'
        cache.mkdir(parents=True, exist_ok=True)
        args[1:1] = ['--user-data-dir=' + str(cache), '--no-first-run',
                     '--disable-background-networking']
        target = next((Path(arg.split('=', 1)[1]) for arg in args
                       if arg.startswith('--print-to-pdf=')), None)
        if target is not None:
            target.unlink(missing_ok=True)
            process = subprocess.Popen(args, cwd=cwd, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True,
                                       start_new_session=True)
            try:
                output, _ = process.communicate(timeout=25)
            except subprocess.TimeoutExpired:
                valid = target.exists() and target.stat().st_size > 1000
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    output, _ = process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    output, _ = process.communicate()
                if not valid:
                    raise RuntimeError('Chrome did not finish the figure PDF')
            if not target.exists():
                raise RuntimeError('Chrome did not print the figure PDF')
            subprocess.run(['pdfinfo', str(target)], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            return output
    return _run(args, cwd)
shared.run = _run_in_paper_cache


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('zh', 'en', 'both'), default='both')
    parser.add_argument('--no-toc', action='store_true')
    parser.add_argument(
        '--output-dir',
        type=Path,
        default=PAPER / 'build/reading-review-v2',
        help='Output directory for v2 PDFs (defaults to build/reading-review-v2 to protect frozen v1 PDFs)',
    )
    args = parser.parse_args()
    out_dir = args.output_dir.resolve()
    if out_dir == (PAPER / 'build').resolve():
        raise RuntimeError(
            'Refusing to overwrite frozen v1 published PDFs in build/; '
            'pass --output-dir papers/low-energy-loop-response/build/reading-review-v2'
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    temp = out_dir / 'tmp'
    temp.mkdir(parents=True, exist_ok=True)
    os.environ['TMPDIR'] = str(temp)
    for lang, rel in [('zh', ZH), ('en', EN)]:
        if args.lang in (lang, 'both'):
            print(json.dumps(shared.build(rel, not args.no_toc, out_dir), ensure_ascii=False))


if __name__ == '__main__':
    main()
