# War and Peace: editable source

The source tree preserves the paper and its read-only shared layout dependencies.
Start with papers/enforceable-peace/scripts/PDF-BUILD.md.

Rebuild the reading editions from this directory:

    python3 papers/enforceable-peace/scripts/build_reading.py

The paper identifies the original research repositories and deployment records through their fixed source bindings.
