#!/usr/bin/env python3
"""Editable bilingual figures for War and Peace: A Source-Generated Terminal Theorem.

Run with the dependencies listed in the figure README.
Shared fonts and colors are read-only dependencies. No manuscript text is changed.
SVG text stays editable; PDFs contain text and vector paths, never preview pixels.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from html import escape
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys
import unicodedata

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION
import svg_text
from svg_text import line
svg_text.OPS.update("∅∪∩⊆⊂⊊∖−…¬∧∨∞°")
W, PRINT_WIDTH, MIN_SIZE = 1440, 464, 26
LANG = "zh"
CHECK_ONLY = False
PARTS, BOXES, SHAPES, MANIFEST = [], [], [], []
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"


def L(zh, en):
    return zh if LANG == "zh" else en


@lru_cache(maxsize=None)
def metrics(cls, weight):
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont
    font_path = svg_text._FONT_FILES[cls]
    if cls == "zh" and weight >= 600:
        suffix = "Bold" if weight >= 700 else "SemiBold"
        font_path = Path.home() / "Library/Fonts" / ("NotoSerifCJKsc-" + suffix + ".otf")
    font = TTFont(str(font_path))
    if "fvar" in font:
        font = instantiateVariableFont(font, {"wght": weight}, inplace=True)
    return font.getBestCmap(), font["hmtx"].metrics, font["head"].unitsPerEm


def width(text, size, weight):
    total = 0
    for piece, tag in svg_text._pieces(str(text)):
        actual_size = svg_text._script(size, MIN_SIZE) if tag in ("sub", "sup", "isub") else size
        actual_weight = 700 if tag == "b" else weight
        for ch in piece:
            cls = "en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i", "isub") and cls == "en":
                cls = "it"
            cmap, hmtx, upm = metrics(cls, actual_weight)
            glyph = cmap.get(ord(ch))
            assert glyph in hmtx, ("missing glyph", ch, cls, actual_weight)
            total += hmtx[glyph][0] * actual_size / upm
    return total


def start(height, title, description):
    PARTS.clear()
    BOXES.clear()
    SHAPES.clear()
    PARTS.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
        f'viewBox="0 0 {W} {height}" role="img">'
    )
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append('<style>text{font-variant-ligatures:none;font-feature-settings:"liga" 0,"clig" 0}</style>')
    PARTS.append(
        f'<defs>'
        f'<marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
        f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{DEEP}"/></marker>'
        f'<marker id="arrow-red" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
        f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{VERMILION}"/></marker>'
        f'</defs>'
    )
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height


def txt(x, y, text, size=28, color=INK, weight=400, anchor="start", max_width=None):
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, tw, max_width)
    x0 = x - {"start": 0, "middle": tw / 2, "end": tw}[anchor]
    BOXES.append({"box": [x0, y - 0.90 * size, x0 + tw, y + 0.28 * size], "text": text, "font_px": size})
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))


def path(d, bounds, color=HAIR, stroke=1.8, arrow=False, dashed=False, red_arrow=False):
    marker = ' marker-end="url(#arrow-red)"' if red_arrow else (' marker-end="url(#arrow)"' if arrow else "")
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(
        f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{stroke}" '
        f'stroke-linecap="round" stroke-linejoin="round"{marker}{dash}/>'
    )
    SHAPES.append(bounds)


def segment(x1, y1, x2, y2, color=HAIR, stroke=1.8, arrow=False, dashed=False, red_arrow=False):
    path(
        f"M {x1} {y1} L {x2} {y2}",
        [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)],
        color,
        stroke,
        arrow,
        dashed,
        red_arrow,
    )


def rect(x, y, w, h, stroke=HAIR, fill="white", sw=1.8):
    PARTS.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    SHAPES.append([x, y, x + w, y + h])


def circle(x, y, r, color=DEEP, fill="white", sw=2.4):
    PARTS.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="{sw}"/>')
    SHAPES.append([x - r, y - r, x + r, y + r])


def rule(y):
    segment(48, y, 1392, y, HAIR, 1.5)


def normalized(text):
    return "".join(unicodedata.normalize("NFKC", text).split())


def repair_pdf_text_mapping(pdf, expected):
    """Preserve source characters when Chrome chooses a same-glyph radical alias."""
    import pymupdf
    cmap = metrics("zh", 400)[0]
    glyph_sources = {}
    for ch in set(expected):
        if 0x3400 <= ord(ch) <= 0x9FFF and ord(ch) in cmap:
            glyph_sources.setdefault(cmap[ord(ch)], set()).add(ch)
    aliases = {}
    for cp, glyph in cmap.items():
        choices = glyph_sources.get(glyph, set())
        if 0x2E80 <= cp <= 0x2FFF and len(choices) == 1:
            aliases[chr(cp)] = next(iter(choices))
    repairs = {}
    temporary = pdf.with_suffix(".unicode.pdf")
    with pymupdf.open(pdf) as doc:
        changed = False
        for xref in range(1, doc.xref_length()):
            if not doc.xref_is_stream(xref):
                continue
            stream = doc.xref_stream(xref)
            if b"begincmap" not in stream:
                continue

            def replace(match):
                original = chr(int(match[2], 16))
                replacement = aliases.get(original)
                if replacement is None:
                    return match[0]
                repairs[original] = replacement
                return match[1] + ("<%04X>" % ord(replacement)).encode()

            repaired = re.sub(rb"(<[0-9A-Fa-f]+>\s+)<([0-9A-Fa-f]{4})>", replace, stream)
            if repaired != stream:
                doc.update_stream(xref, repaired)
                changed = True
        if changed:
            doc.save(temporary, garbage=4, deflate=True)
    if repairs:
        temporary.replace(pdf)
    return repairs


def save(stem, height, semantics):
    for i, item in enumerate(BOXES):
        a = item["box"]
        assert a[0] >= 16 and a[2] <= W - 16 and a[1] >= 8 and a[3] <= height - 8, ("outside canvas", item)
        for other in BOXES[i + 1 :]:
            b = other["box"]
            assert not (a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]), (
                "text overlap",
                item["text"],
                other["text"],
            )
    for s in SHAPES:
        assert min(s[:2]) >= 8 and s[2] <= W - 8 and s[3] <= height - 8, ("shape outside", s)
    name = stem + ("-en" if LANG == "en" else "")
    entry = {
        "stem": name,
        "language": LANG,
        "canvas_px": [W, height],
        "print_width_pt": PRINT_WIDTH,
        "minimum_text_px": MIN_SIZE,
        "glyph_coverage": "pass",
        "text_geometry": "pass",
        "shape_bounds": "pass",
        "semantics": semantics,
        "labels": list(BOXES),
    }
    if CHECK_ONLY:
        MANIFEST.append(entry)
        return
    svg = OUT / (name + ".svg")
    svg.write_text("\n".join(PARTS + ["</svg>"]) + "\n", encoding="utf-8")
    preview = OUT / ".review"
    preview.mkdir(exist_ok=True)
    page = preview / (name + ".html")
    hp = height / W * PRINT_WIDTH
    page.write_text(
        "<!doctype html><html><head><meta charset=\"utf-8\"><style>"
        + f"@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}"
        + f"img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>"
        + f"<body><img src=\"{svg.as_uri()}\"></body></html>"
    )
    pdf = OUT / (name + ".pdf")
    result = subprocess.run(
        [
            CHROME,
            "--headless=new",
            "--disable-gpu",
            "--no-pdf-header-footer",
            "--no-first-run",
            "--allow-file-access-from-files",
            f"--user-data-dir={preview / 'chrome-profile'}",
            f"--print-to-pdf={pdf}",
            page.as_uri(),
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:] + result.stderr[-2000:])
    import pymupdf
    expected = "".join(piece for b in BOXES for piece, _ in svg_text._pieces(b["text"]))
    text_repairs = repair_pdf_text_mapping(pdf, expected)
    with pymupdf.open(pdf) as doc:
        assert len(doc) == 1, ("page count", name, len(doc))
        p = doc[0]
        assert abs(p.rect.width - PRINT_WIDTH) < 1 and abs(p.rect.height - hp) < 1
        assert not p.get_images(full=True), ("raster image in vector PDF", name)
        pdf_text = p.get_text()
        assert "\ufffd" not in pdf_text, ("replacement character", name)
        missing = Counter(normalized(expected)) - Counter(normalized(pdf_text))
        assert not missing, ("text missing from PDF", name, dict(missing))
        span_count = 0
        for block in p.get_text("dict")["blocks"]:
            for ln in block.get("lines", []):
                for span in ln["spans"]:
                    span_count += 1
                    x0, y0, x1, y1 = span["bbox"]
                    assert x0 >= -1 and y0 >= -1 and x1 <= p.rect.width + 1 and y1 <= p.rect.height + 1, (
                        "PDF text outside",
                        name,
                        span,
                    )
                    assert span["size"] >= MIN_SIZE / W * PRINT_WIDTH * 0.95, ("PDF type below floor", name, span)
        assert span_count > 0 and p.get_drawings(), ("empty PDF", name)
        fonts = sorted({font[3] for font in p.get_fonts(full=True)})
        p.get_pixmap(matrix=pymupdf.Matrix(W / p.rect.width, W / p.rect.width), alpha=False).save(preview / (name + ".png"))
        entry["pdf_checks"] = {
            "pages": 1,
            "raster_images": 0,
            "editable_text_spans": span_count,
            "glyph_text_preserved": True,
            "all_text_in_page": True,
            "fonts": fonts,
            "font_types": sorted({f[2] for f in p.get_fonts(full=True)}),
            "source_character_mapping_repairs": text_repairs,
        }
    entry["files"] = {}
    for ext in ("svg", "pdf"):
        f = OUT / (name + "." + ext)
        entry["files"][ext] = {
            "path": f.name,
            "bytes": f.stat().st_size,
            "sha256": hashlib.sha256(f.read_bytes()).hexdigest(),
        }
    MANIFEST.append(entry)


def war_and_ceasefire():
    h = start(
        1120,
        L("开战账翻转、单签死锁与可强制止战", "War-payoff reversal, unilateral deadlock, and enforceable ceasefire"),
        L(
            "上部为责任回接临界与观察纤维对偶，中部比较旧单签不减界与原位双签最宽安全门禁，下部对比优先兑现、无优先权无限挂起和不可重置硬期限。",
            "Top: responsibility reattachment threshold and observation-fibre duality. Middle: unilateral non-reduction versus widest safe dual-signed guard. Bottom: priority completion, unprioritized stall, and non-resettable deadline.",
        ),
    )
    txt(48, 52, L("为什么止战需要回接、双签与优先权", "Why ceasefire requires reattachment, dual signatures, and priority"), 34, DEEP, 600)
    txt(
        48,
        98,
        L(
            "同一六单位原债 ρ{sub:0} = (2, 0, (false, true, false)) 上的三道充要边界。",
            "Three exact boundaries on the original six-unit claim ρ{sub:0} = (2, 0, (false, true, false)).",
        ),
        28,
        SLATE,
    )

    # Band 1: Reattachment flip and observation-fibre duality
    txt(48, 152, L("1. 责任回接 Δ(λ) = m − λT  (m = 4, T = 6)", "1. Reattachment Δ(λ) = m − λT  (m = 4, T = 6)"), 29, DEEP, 600)
    for x, label_zh, label_en, val, col in [
        (195, "λ = 0 外部转嫁", "λ = 0 shifted", "+4", VERMILION),
        (515, "λ* = 2/3 平局临界", "λ* = 2/3 tie", "0", DEEP),
        (835, "λ = 1 足额回接", "λ = 1 full", "−2", DEEP),
    ]:
        txt(x, 206, L(label_zh, label_en), 27, SLATE, 400, "middle")
        txt(x, 266, val, 44, col, 600, "middle")
    segment(275, 250, 425, 250, DEEP, 2.2, True)
    segment(605, 250, 745, 250, DEEP, 2.2, True)
    txt(515, 318, L("冲突严格占优 → 和平严格占优", "Strict war advantage → strict peace advantage"), 27, INK, 400, "middle")

    rect(985, 132, 399, 204, HAIR, "white", 1.8)
    txt(1184, 174, L("阻塞与不完全观察对偶", "Obstruction & fibre duality"), 28, DEEP, 600, "middle")
    txt(1184, 224, "T = 0, m > 0 ⇒ ∀λ, Δ > 0", 28, VERMILION, 600, "middle")
    txt(1184, 272, "sup P = inf{sub:s} sup F(s)", 28, DEEP, 600, "middle")
    txt(1184, 316, L("绑定纤维决定最优策略实达", "Binding fibres govern attainment"), 26, SLATE, 400, "middle")

    rule(362)

    # Band 2: Unilateral non-reduction vs widest safe dual-signed guard
    txt(48, 414, L("2. 单方签收不减总债，原位双签构成最宽安全准入", "2. Unilateral receipts never cut debt; dual-signed guard is widest safe"), 29, DEEP, 600)
    rect(48, 442, 646, 224, VERMILION, "white", 1.9)
    txt(74, 488, L("旧单签规则（不可能性下界）", "Old single-signer rule (lower bound)"), 29, VERMILION, 600)
    txt(74, 542, "Out{sub:g}(h ++ u) ≥ Out{sub:g}(h) ≥ 6", 31, VERMILION, 600)
    txt(74, 594, L("跨界单签冲抵在同位开出等额反向新损；", "Unilateral credit opens equal reverse damage;"), 27, INK)
    txt(74, 638, L("旧生产律在钟 5 后耗尽食物且失去独立出口。", "old production exhausts food and exit after clock 5."), 27, SLATE)

    rect(746, 442, 646, 224, DEEP, "white", 1.9)
    txt(772, 488, L("双签原位分配与最宽安全门禁", "Dual-signed debit & widest safe guard"), 29, DEEP, 600)
    txt(772, 542, "d{sub:ρ} = r{sub:ρ}(n) + p{sub:ρ}(n),   6 → 4 → 0", 31, DEEP, 600)
    txt(772, 594, L("精确放行全部原合法无新损请求（最大安全核）；", "Forwards every lawful zero-damage act (maximal);"), 27, INK)
    txt(772, 638, L("序号 ν 严格递增，同一收据不可二次冲抵。", "strict ordinal ν prevents replaying any receipt."), 27, SLATE)

    rule(696)

    # Band 3: Priority bound vs pocket-veto stall & non-resettable deadline
    txt(48, 748, L("3. 强制撤权紧界、无优先权挂起反证与硬期限终局", "3. Sharp priority bound, pocket-veto stall, and hard deadline"), 29, DEEP, 600)
    rows = [
        (
            816,
            "有优先调度",
            "Priority queue",
            "N = r{sub:0} + |w|",
            "精确访问兑现撤权；抵御任意自适应联盟保底仓与旧债",
            "Exact-visit revocation; blocks every adaptive coalition",
            DEEP,
        ),
        (
            908,
            "无优先调度",
            "No priority",
            "stopReview{sup:∞}",
            "已交撤权永久未兑现，物理时钟卡在 τ{sub:0} + 1 内",
            "Lodged withdrawal stalls forever; clock stays < τ{sub:0} + 1",
            VERMILION,
        ),
        (
            1000,
            "应急硬期限",
            "Hard expiry",
            "τ > T{sub:dead}",
            "全后缀禁发提名、接受与续任；钟 1→3→4 双复审实付",
            "All suffixes bar grants/renewals; clocks 1→3→4 dual review",
            DEEP,
        ),
    ]
    for i, (y, a_zh, a_en, formula, c_zh, c_en, color) in enumerate(rows):
        txt(62, y, f"0{i+1}", 27, color, 600)
        txt(126, y, L(a_zh, a_en), 28, color, 600)
        txt(365, y, formula, 29, color, 600)
        segment(608, y - 10, 672, y - 10, color, 2.1, arrow=(color == DEEP), red_arrow=(color != DEEP))
        txt(698, y, L(c_zh, c_en), 27, INK, 400)

    txt(
        720,
        1078,
        L(
            "复权充要条件：反查原任务成员实付提名及每位原暴露者在原物量位的本人肯定答复。",
            "Revival iff traced to an earlier paid task-member proposal and each exposed bearer's own yes.",
        ),
        26,
        SLATE,
        400,
        "middle",
    )

    save(
        "01-war-and-ceasefire",
        h,
        {
            "source_claims": ["PE1", "PE2", "PE3", "PE4", "PE5", "PE6", "PE17", "PE22"],
            "address": [2, 0, [False, True, False]],
            "reattachment_margins": {"0": 4, "2/3": 0, "1": -2},
            "unilateral_lower_bound": 6,
            "priority_visit_bound": "r_0 + |w|",
            "emergency_clocks": [1, 3, 4],
        },
    )


def material_history():
    h = start(
        1180,
        L("同一笔债：增产清偿、反脆弱修订与双轨衔接", "One debt: productive settlement, anti-fragile revision, and dual branches"),
        L(
            "上部为同一六单位原债的实际库存与结清，中部为清偿后态上的两次付费最小语言修订，下部给出反脆弱不变量及通往钟12四机起点的九阶段部署链。",
            "Top: actual stocks and settlement of the six-unit debt. Middle: two paid minimal language revisions. Bottom: anti-fragile invariants and the nine-stage deployed chain reaching the clock-12 four-host checkpoint.",
        ),
    )
    txt(48, 52, L("实际库存决定和平从哪里开始", "Peace begins from the actual post-settlement stocks"), 34, DEEP, 600)
    txt(
        48,
        98,
        L(
            "偿债物料库存：新规则试产先入仓，再由双方同位签收清偿（111 < 113）。",
            "Repayment-material stocks: approved trial production first, then dual-signed debit (111 < 113).",
        ),
        28,
        SLATE,
    )
    for x, zh, en in [(370, "原库存", "Prior stock"), (770, "新规则试产", "Trial production"), (1170, "原位双签实付", "Dual-signed debit")]:
        txt(x, 156, L(zh, en), 28, DEEP, 600, "middle")
    txt(48, 228, L("付款人", "Payer"), 30, SLATE)
    txt(48, 304, L("受害人", "Claimant"), 30, SLATE)
    txt(48, 380, L("原债余额", "Debt balance"), 30, SLATE)
    for x, a, b, c in [(370, 113, 111, 6), (770, 117, 115, 6), (1170, 111, 121, 0)]:
        txt(x, 228, str(a), 44, DEEP, 600, "middle")
        txt(x, 304, str(b), 40, INK, 400, "middle")
        txt(x, 380, str(c), 38, VERMILION if c else DEEP, 600, "middle")
    for yy in [214, 290, 366]:
        segment(435, yy, 698, yy, DEEP, 2.2, True)
        segment(835, yy, 1098, yy, DEEP, 2.2, True)
    for x, y, label in [(568, 193, "+4"), (968, 193, "−6"), (568, 269, "+4"), (968, 269, "+6")]:
        txt(x, y, label, 27, SLATE, 400, "middle")
    txt(
        720,
        434,
        L(
            "原债地址 ρ{sub:0} = (2, 0, (false, true, false)) 全程保留",
            "Original address ρ{sub:0} = (2, 0, (false, true, false)) retained throughout",
        ),
        27,
        DEEP,
        400,
        "middle",
    )
    rule(462)
    txt(48, 514, L("结清后态 (121, 111)", "Settled state (121, 111)"), 29, DEEP, 600)
    segment(398, 504, 466, 504, DEEP, 2.2, True)
    txt(490, 514, L("核验可重复生产与逐人退出", "Production & exits verified"), 28, INK)
    segment(900, 504, 968, 504, DEEP, 2.2, True)
    txt(992, 514, L("开启开放语法和平", "Open-syntax peace"), 29, DEEP, 600)
    rule(548)

    txt(48, 598, L("支路 I：两次实付语言修订与反脆弱自锁", "Branch I: two paid language revisions and anti-fragile locking"), 31, DEEP, 600)
    for x, zh, en in [
        (250, "初始覆盖（钟 5）", "Initial (clock 5)"),
        (720, "条款保护（钟 6）", "Terms (clock 6)"),
        (1190, "退出保护（钟 7）", "Exit (clock 7)"),
    ]:
        txt(x, 654, L(zh, en), 27, SLATE, 400, "middle")
    txt(250, 712, "C{sub:0} = ∅", 34, DEEP, 600, "middle")
    txt(720, 712, L("C{sub:1} = {条款}", "C{sub:1} = {terms}"), 32, DEEP, 600, "middle")
    txt(1190, 712, L("C{sub:2} = {条款, 退出}", "C{sub:2} = {terms, exit}"), 31, DEEP, 600, "middle")
    segment(355, 699, 548, 699, DEEP, 2.4, True)
    segment(880, 699, 1000, 699, DEEP, 2.4, True)
    txt(452, 750, L("食物付 1/2", "food: 1/2"), 27, VERMILION, 600, "middle")
    txt(940, 750, L("食物付 1/2", "food: 1/2"), 27, VERMILION, 600, "middle")
    txt(
        720,
        808,
        "C{sub:n+1} = C{sub:n} ∪ E{sub:n},   "
        + L("新增拒绝 = E{sub:n} ∖ C{sub:n},   脆弱面 U{sub:n+1} ⊊ U{sub:n}", "new refusal = E{sub:n} ∖ C{sub:n},   U{sub:n+1} ⊊ U{sub:n}"),
        28,
        DEEP,
        600,
        "middle",
    )
    txt(
        720,
        854,
        L(
            "原合法生产与个人退出编译精确保持；越权试探在任意正权重下严格净亏损；零费试探整轨擦除。",
            "Every native productive/exit word is preserved; paid probes incur strict loss; zero-fee probes erase.",
        ),
        26,
        INK,
        400,
        "middle",
    )
    rule(888)

    txt(
        48,
        938,
        L("支路 II：持久部署轨道（钟 5 → 12）生成四物理节点封存账头", "Branch II: persistent Ingress track (clocks 5 → 12) seeding four-host head"),
        30,
        DEEP,
        600,
    )
    stages = [
        (175, "钟 5→6", "5→6", "待签续付/拒签", "Due & refusal"),
        (465, "钟 6", "6", "晚签结清开网", "Late settlement"),
        (755, "钟 7→8", "7→8", "预缴+宽4合成", "Prepay & width-4"),
        (1045, "钟 9→10", "9→10", "待证续付+写U8", "Wait & U8 at 10"),
        (1295, "钟 11→12", "11→12", "续付封存四机头", "Seal 4-host head"),
    ]
    segment(175, 1005, 1295, 1005, HAIR, 2.2)
    for x, c_zh, c_en, s_zh, s_en in stages:
        circle(x, 1005, 7, DEEP, DEEP, 1.8)
        txt(x, 1052, L(c_zh, "clk " + c_en), 29, DEEP, 600, "middle")
        txt(x, 1096, L(s_zh, s_en), 26, INK, 400, "middle")
    txt(
        720,
        1148,
        L(
            "无等待批量轨道在钟 8 写 U8 并续付至钟 13（本机 13 观察一致）；持久轨道钟 12 账头进入图 3 四节点。",
            "Unwaited batch track writes U8 at clock 8 to 13 (13 local checks); persistent clock-12 head seeds Figure 3.",
        ),
        26,
        SLATE,
        400,
        "middle",
    )

    save(
        "02-debt-and-revision",
        h,
        {
            "source_claims": ["PE9", "PE10", "PE12", "PE13", "PE17", "PE19", "PE23", "PE24", "PE25", "PE26"],
            "payer_stock": [113, 117, 111],
            "claimant_stock": [111, 115, 121],
            "debt": [6, 6, 0],
            "address": [2, 0, [False, True, False]],
            "branch_1_clocks": [5, 6, 7],
            "branch_2_clocks": [5, 6, 7, 8, 9, 10, 11, 12],
            "batch_stage_clocks": [5, 6, 7, 8, 9, 12, 13],
            "fees": ["1/2", "1/2"],
        },
    )


def certified_history():
    h = start(
        1280,
        L("3f + 1 换届认证、角色封印判据与钟 12–28 实证", "3f + 1 certified handover, role-seal criterion, and clocks 12–28"),
        L(
            "上部为旧届三签与新届四份原生复演的双重认证及无死锁收回，中部为角色封印充要判据与三路处置，下部为同一六单位原账钟12至28的四物理节点轨迹。",
            "Top: dual certification by three outgoing votes and four incoming replays with deadlock-free disposal. Middle: role-seal criterion and three dispositions. Bottom: clocks 12–28 on four physical hosts.",
        ),
    )
    txt(48, 52, L("核验者全员可换，已发生的付款只有一条历史", "Every verifier can change; past payments keep one history"), 34, DEEP, 600)
    txt(
        48,
        98,
        L(
            "每父账头 3f + 1 = 4 人（f = 1）：两套三签必共享守约者；相邻两届可完全不相交。",
            "At each parent, 3f + 1 = 4 (f = 1): two 3-quorums share an honest member; rosters may be disjoint.",
        ),
        27,
        SLATE,
    )
    txt(310, 152, L("旧届 O（4人）", "Outgoing O (4)"), 29, DEEP, 600, "middle")
    txt(1130, 152, L("拟新届 N（4人）", "Incoming N (4)"), 29, DEEP, 600, "middle")
    for i, x in enumerate([160, 260, 360, 460]):
        circle(x, 206, 22, DEEP, DEEP if i < 3 else "white", 2.3)
    for x in [980, 1080, 1180, 1280]:
        circle(x, 206, 22, DEEP, DEEP, 2.3)
    segment(500, 206, 610, 206, DEEP, 2.3, True)
    segment(940, 206, 830, 206, DEEP, 2.3, True)
    txt(720, 202, L("同一实付", "same payment"), 29, VERMILION, 600, "middle")
    txt(720, 240, L("到期续付 due", "scheduled due"), 27, SLATE, 400, "middle")
    txt(310, 278, L("至少三人表决", "≥ 3 decision votes"), 28, DEEP, 400, "middle")
    txt(1130, 278, L("四人从原源复演", "4/4 native replay"), 28, DEEP, 400, "middle")
    txt(
        720,
        322,
        L(
            "有序规则：新届复演齐备前旧届不表决 ⇒ 即使拟新届 0/4 响应，旧届三份封印仍可无死锁收回。",
            "Ordered rule: replay precedes voting ⇒ even if 0/4 incoming respond, 3 outgoing seals dispose safely.",
        ),
        26,
        INK,
        400,
        "middle",
    )
    rule(350)

    txt(
        48,
        398,
        L("失联成案判据：发不可撤销封印前先检最大证据 (D{sub:max}, S{sub:max})", "Interruption test: pre-check maximal seals (D{sub:max}, S{sub:max}) first"),
        30,
        DEEP,
        600,
    )
    txt(720, 456, "F(Q) = (Q ∩ D) ∪ (N ∩ S)", 35, DEEP, 600, "middle")
    txt(48, 504, L("D：旧届未表决封印", "D: outgoing no-vote seals"), 27, SLATE)
    txt(775, 504, L("S：新届未复演封印", "S: incoming no-replay seals"), 27, SLATE)
    txt(720, 552, "∃ Q ⊆ O,  |Q| = 3 :     |F(Q) ∩ O| ≤ 1   ∧   |F(Q) ∩ N| ≤ 1", 29, DEEP, 600, "middle")
    rows = [
        (618, "完整证书齐备", "Full certificate", "按原 ID 完成或冷恢复同一次后继", "Complete or cold-recover original ID", DEEP),
        (696, "至少一组 Q 相容", "Some Q compatible", "保留原签认通路，返回具名缺口", "Keep signing route; name missing roles", DEEP),
        (
            774,
            "四组 Q 全部排除",
            "All four Q excluded",
            "同父账头实付撤回或改派；保留票 V° = V ∧ ¬E",
            "Paid withdraw/reassign at parent; V° = V ∧ ¬E",
            VERMILION,
        ),
    ]
    for i, (y, a, b, c, d, color) in enumerate(rows):
        txt(62, y, f"0{i+1}", 27, color, 600)
        txt(128, y, L(a, b), 28, color, 600)
        segment(456, y - 10, 530, y - 10, color, 2.1, arrow=(color == DEEP), red_arrow=(color != DEEP))
        txt(556, y, L(c, d), 27, color, 400)
    rule(818)

    txt(
        48,
        868,
        L(
            "同一六单位原账 ρ{sub:0} 的四物理节点运行（钟 12–28，余额恒为 0）",
            "Four-host execution of the same ρ{sub:0} ledger (clocks 12–28, balance 0)",
        ),
        30,
        DEEP,
        600,
    )
    for y, events in [
        (
            936,
            [
                ("12–16", "四机准入封存", "Admit & seal"),
                ("17–18", "冷恢复与换届", "Recover; abce"),
                ("19–20", "三远端重建", "3-host rebuild"),
                ("21–22", "有序撤回恢复", "Seal withdraw"),
            ],
        ),
        (
            1106,
            [
                ("23", "排除后改派", "Reassign abcf"),
                ("24", "找回三票成案", "3rd vote abcg"),
                ("25–26", "三封释票续付", "Release & due"),
                ("27–28", "双票保路读回", "Keep 2; abcf"),
            ],
        ),
    ]:
        xs = [180, 540, 900, 1260]
        segment(xs[0], y, xs[-1], y, HAIR, 2.2)
        for x, (n, a, b) in zip(xs, events):
            circle(x, y, 7, DEEP, DEEP, 1.8)
            txt(x, y + 48, n, 33, DEEP, 600, "middle")
            txt(x, y + 92, L(a, b), 27, INK, 400, "middle")
    txt(
        720,
        1248,
        L(
            "离线复核：95 枚公钥签名、钟 21–28 八条认证行与三处四组三签排除全部通过。",
            "Offline check: 95 signatures, 8 certified rows (clocks 21–28), and 3 exclusions verified.",
        ),
        26,
        SLATE,
        400,
        "middle",
    )

    save(
        "03-certified-history",
        h,
        {
            "source_claims": ["PE27", "PE28", "PE29", "PE30", "PE31", "PE32", "PE33"],
            "quorum_geometry": "3f + 1 = 4, f = 1, outgoing >= 3, incoming 4/4 native replay",
            "deadlock_freedom": "interrupted_before_decision_can_be_disposed",
            "criterion": "exists Q subset O, |Q|=3: |F(Q) cap O|<=1 and |F(Q) cap N|<=1",
            "milestones": ["12-16", "17-18", "19-20", "21-22", "23", "24", "25-26", "27-28"],
            "address": [2, 0, [False, True, False]],
            "balance": 0,
        },
    )


def main():
    global LANG, CHECK_ONLY
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--language", choices=["zh", "en", "both"], default="both")
    args = ap.parse_args()
    CHECK_ONLY = args.check_only
    for LANG in (["zh", "en"] if args.language == "both" else [args.language]):
        war_and_ceasefire()
        material_history()
        certified_history()
    if not CHECK_ONLY:
        (OUT / "manifest.json").write_text(
            json.dumps(
                {"created_utc": datetime.now(timezone.utc).isoformat(), "figures": MANIFEST},
                ensure_ascii=False,
                indent=2,
            )
            + "\n"
        )
    print(json.dumps({"figures": len(MANIFEST), "check_only": CHECK_ONLY, "status": "passed"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
