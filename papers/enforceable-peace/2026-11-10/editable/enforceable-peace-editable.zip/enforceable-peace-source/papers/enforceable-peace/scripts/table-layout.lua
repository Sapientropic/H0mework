-- Paper-local column allocation; no content or mathematical changes.
function Table(el)
  if not FORMAT:match('latex') or not el.head or #el.head.rows == 0 then return nil end
  local row = el.head.rows[1]
  if #row.cells == 0 then return nil end
  local label = pandoc.utils.stringify(row.cells[1].contents)
  local n = #el.colspecs
  local widths = nil
  if label == 'PE' then
    if n == 3 then widths = {0.07, 0.49, 0.44} end
    if n == 4 then widths = {0.08, 0.18, 0.38, 0.36} end
  elseif n == 3 and (label == '固定组' or label == 'Fixed group') then
    widths = {0.16, 0.32, 0.52}
  elseif (label == '原钟' or label == 'Clock' or label == 'Original clock' or label == 'Source clock') then
    if n == 3 then widths = {0.10, 0.75, 0.15} end
    if n == 4 then widths = {0.10, 0.42, 0.24, 0.24} end
  elseif n == 2 and (label == '回执' or label == 'Receipt') then
    widths = {0.38, 0.62}
  elseif n == 2 and (label == '已取得的证据' or label == 'Evidence obtained' or label == 'Available evidence') then
    widths = {0.24, 0.76}
  elseif n == 3 and (label == '完备性' or label == 'Completeness') then
    widths = {0.16, 0.48, 0.36}
  end
  if widths then
    for i,w in ipairs(widths) do el.colspecs[i][2] = w end
  end
  if (label == 'Current evidence' or label == '当前证据') and n == 3 then
    return {pandoc.RawBlock('latex', '\\Needspace{14\\baselineskip}'), el}
  end
  if widths then return el end
end

local function is_statement_lead(block)
  if block.t ~= 'Para' or #block.content == 0 or block.content[1].t ~= 'Strong' then
    return false
  end
  local head = pandoc.utils.stringify(block.content[1])
  return head:match('^定理%s*%d+') ~= nil
    or head:match('^命题%s*%d+') ~= nil
    or head:match('^引理%s*%d+') ~= nil
    or head:match('^推论%s*%d+') ~= nil
    or head:match('^Theorem%s+%d+') ~= nil
    or head:match('^Proposition%s+%d+') ~= nil
    or head:match('^Lemma%s+%d+') ~= nil
    or head:match('^Corollary%s+%d+') ~= nil
end

function Pandoc(doc)
  if not FORMAT:match('latex') then return nil end
  local out = pandoc.List()
  for i, block in ipairs(doc.blocks) do
    local nxt = doc.blocks[i + 1]
    local already_guarded = nxt and (nxt.t == 'Table' or nxt.t == 'OrderedList' or nxt.t == 'BulletList')
    if is_statement_lead(block) and not already_guarded then
      out:insert(pandoc.RawBlock('latex', '\\Needspace{4\\baselineskip}'))
    end
    out:insert(block)
  end
  doc.blocks = out
  return doc
end
