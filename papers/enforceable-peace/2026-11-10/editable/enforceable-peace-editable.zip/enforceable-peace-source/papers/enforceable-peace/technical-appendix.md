# 技术附录：清偿、开放修订与原历史的精确结构

本附录给出正文使用的定义、承重证明及 PE1–PE26 的源码对应；状态、库存、物理钟与原债键在本附录中分别记为 \(x,s_x,t_x,a\)（对应正文的 \(s,\sigma,\tau,\rho\)）。认证历史与换届处置的对应另见执行附录。每项物量各用自己的单位；追偿余额、金融本金、食物与审查费用分别记账。

## A. 原历史、损失、单签下界与可续清偿域

设参与者、物量、端口、技术、金融工具及共同体分别取任意给定类型。实际状态记为 \(x\)，包含库存 \(s_x(p,g)\in\mathbb Q\)、物理时钟 \(t_x\)、优先待办队列、访问序号 \(\operatorname{ord}(x)\in\mathbb N\)、现行技术和完整责任账。制度提供字面行动的授权、实际扣入料和下一状态。一次提交可包含多个实际物量项；访问序号、物量项序号和物理时钟分别记录。

一次未获受损者同意的跨共同体正净扣料，以
\[
a=(\text{提交序号},\text{实际项序号},(\text{受害者},\text{付款人},\text{物量}))
\]
命名。发生 \(a\) 的原损失为 \(d_a>0\)，余债为 \(b_a\ge0\)。后来的金融登记和制度修订保留该地址的原出处。整案因另一项短缺而被拒时，已经实际扣出的物量仍开户。

**逐物量守恒（PE3）。** 对任意实际历史 \(h\) 和物量 \(g\)，
\[
\sum_{a:\,g(a)=g}b_a(h)+\operatorname{Paid}_g(h)
=\operatorname{Damage}_g(h),
\qquad
\operatorname{Paid}_g(h)\le \operatorname{Signed}_g(h).
\]
其中已付量只计分配器在实际物量位置消费的合格签收。证明对历史末端追加一项归纳：先把新损失加入原账，再按合格交付量逐原行分配；局部恒等式“分配后余债＋本次分配＝分配前余债”与此前守恒相加。较早合格行优先，单个实际交付位置的合计冲抵不超过该位置的签收量。

**旧单签规则的双单边死锁、不减下界与最宽安全门禁（PE3、PE6）。** 在未安装受害者同位独立签收通道的旧单签规则下，付款人单签不冲抵跨界旧债（原六单位例中付款人单签 `returnAt 6` 使库存移至 \((117,107)\) 而冲抵为零，原行 \([(\rho_0,6)]\) 原封不动，`after_the_payer_returns_six_the_original_six_is_still_in_the_whole_account`），而任一跨共同体正额单签收据在同一物量位置 \(pos\) 冲销旧债的同时必开立等额反向跨界新损（受害者单签 `receipt 6` 清零 \(\rho_0\) 却同位写入 `(reverseOccurrence, 6)`，`the_victims_receipt_really_closes_the_old_six_and_writes_the_reverse_six`；一般形式为 `every_cross_community_receipt_opens_its_equal_reverse_damage`）。因同一物量位置的单次操作不能将同一物量重复支用两次，位置 \(pos\) 对物量 \(g\) 的总分配冲抵不超过该收据数量，从而不超过 \(pos\) 处新立案的物量 \(g\) 损失；对单次输入的全部不重合位置求和得 \(\operatorname{Assigned}_g\le\operatorname{Filed}_g\)。结合单步守恒恒等式，对任意原前缀 \(h\) 与任意长后续脚本 \(u\) 恒有
\[
\operatorname{Out}_g(h)\le\operatorname{Out}_g(h\mathbin{+\!\!+}u).
\]
在六单位原账 \(h_0\) 上恒有 \(6\le\operatorname{Out}_{\mathrm{false}}(h_0\mathbin{+\!\!+}u)\)，同时沿用旧生产律在钟 \(5\) 执行一轮生计后食物交付为 \(0\)、需求为 \(1\) 且失去全部个人独立出口，构成材料与收据的双重终端阻塞。安装跨界损害门禁后，请求获放行当且仅当它原合法且跨共同体新损为零；任何只放行原合法零新损请求的规则均包含于该门禁之内。

一个**续行步**包括从当前库存实际支付的注册共同词，以及每名在册成员可独立支付的退出词。共同词逐项满足原与当前两组生计、维护底线，且实际时长为正。把这类步串成有限路径。对状态集合 \(R\)，定义
\[
\Phi(R)=\{x:\ \forall B\in\mathbb Q,\ \exists\text{有限实际路径 }x\leadsto y,\
y\in R,\ t_y>B\}.
\]
最大可续域为
\[
V=\bigcup\{R:R\subseteq\Phi(R)\}.
\]
它由能越过每个原钟界并回到自身的实际有限路径确定。

**可续域定理（PE6）。**
\[
x\in V\quad\Longleftrightarrow\quad
\text{从 }x\text{ 存在一条注册实付且时钟共终的轨迹}.
\]
右向左取轨迹所有后态组成 \(R\)。左向右在当前态选越过目标钟界的最短实际路径，逐步消费；到达后从同一后态重置目标并再选路径。对整数增量归纳，得到任意 \(k\) 之后仍可越过任意有理界 \(B\)。路径沿同一实际下一状态拼接，每步的生计和独立退出也随之接续。

给定原侵夺、独立签收通道、注册提交域与获准生产候选，令 \(x_h\) 为前缀 \(h\) 的真实后态。定义
\[
\begin{split}
\operatorname{Entry}(h)\ \Longleftrightarrow\;&
h\text{ 通过原准入，原待办及复审入口就绪，且}\\
&\exists c,m:\ c\text{ 是获批生产选择，}\\
&m\text{ 从 }x_h\text{ 实付并满足 }c\text{ 的首试产要求，}\quad m(x_h)\in V_c .
\end{split}
\]
生产选择 \(c\) 可为空，此时保留现行规则与原名册；选择候选时，须通过原批准，并由 \(m\) 执行该候选的字面首试产。\(V_c\) 是该选择的执行法、原生活基准和名册所确定的最大可续域；首试产的真实后态进入 \(V_c\)，后续从此处继续。

全账可持续清偿域是
\[
\mathcal S=\{h:\operatorname{Entry}(h)\ \land\
                 \forall a\in L(h),\ b_a(h)=0\}.
\]

**全账终端定理（PE6–PE8）。** 构造返回实际全账清偿，当且仅当 \(\mathcal S\ne\varnothing\)。此时选出的 \(h_*\in\mathcal S\) 满足
\[
|h_*|=\min\{|h|:h\in\mathcal S\},
\]
且全账清偿报告与全账最优报告使用同一个字面前缀和同一实际运行。若 \(\mathcal S=\varnothing\)，每条实际可续候选都保留一条正余额原行；若连可续入口也不存在，则逐候选保留原准入或可续性阻塞。

证明用全账指标 \(\mathbf1_{\{\exists a,\ b_a(h)>0\}}\) 取最小值。它逐行检验零余额，无须把不同单位的损失相加。有可清前缀时指标实际取零，再对自然数长度取最小；反之，零余额实际输出本身就是 \(\mathcal S\) 的元素。单条原债的余额优化另用有下界的实数值域，分别生成下确界实达、任意正精度内的严格逼近、或空域处置。

访问数的最小值与物理时间前沿分别计算。对装入联合试产菜单的可续清偿域 \(\mathcal S\)，令
\[
T_*=\inf\{t_{x_h}:h\in\mathcal S\}.
\]
域非空时，对每个 \(T>T_*\) 都存在实际清偿前缀在 \(T\) 前完成。若 \(T_*\) 实达，在该时刻的前缀中再选最少访问；若不实达，则每个严格更晚的期限都有真实前缀见证。

**强制汇合、唯一和平尾迹与反拉布整点推进（PE6）。** 在原六单位宪制终端下，无论竞争交错如何排布，全部合法运行均在第 \(4\) 次访问（物理钟 \(5\)）强制汇合于同一和平整账状态并拥有唯一续行尾迹（\(\exists!\,\mathrm{tail}\)，`source_generated_terminal_peace`），在保住已结清原行 \([(\rho_0,0)]\) 的同时原样保留另列金融本金 \(6\)。续行阶段永不跳越整数小时，任何竞争交错均不能把到期生计推迟超过当前优先待办队列长度（至多 \(\operatorname{pending}(x_n)+1\) 次访问内必跨入下一小时，`the_due_service_cannot_be_delayed_past_the_pending_queue`），且首次跨入每个开放整点 \(h+1\) 的访问必向全体成员各实付至少 \(1\) 单位食物（`the_first_crossing_of_each_open_hour_is_paid`）。

## B. 回接阈值、观察纤维对偶、生产界与原位支付

### B.1 开战优势翻转、回接阻塞与观察纤维对偶

可执行菜单 \(M\) 由候选集合和收益读数 \(u\) 给出，前沿为
\[
v(M)=\sup\{u(w):w\in M,\ w\text{实际可执行}\}.
\]
对旧战、旧和、回接后战、回接后和四个各自非空且有上界的菜单，严格翻转
\[
v(W_0)>v(P_0),\qquad v(W_1)<v(P_1)
\]
等价于两条带统一正间隔的实际见证：
\[
\exists w\in W_0,\delta>0,\ \forall p\in P_0,\ u(p)+\delta\le u(w),
\]
\[
\exists p\in P_1,\varepsilon>0,\ \forall w\in W_1,\ u(w)+\varepsilon\le u(p).
\]
证明从前沿的严格间隔中选取一个实际近似者；反向用该统一间隔给对方前沿以上界。上确界可以不实达。空菜单、无界、实达和严格逼近各由自己的分支处理。（PE1）

在不完全观察 \(\omega:\mathcal W\to\mathcal O\)（\(\mathcal W\) 非空）下，令观察纤维 \(s\in\operatorname{range}(\omega)\) 的局部可保底集为 \(\mathcal F(s)=\{b\in\mathbb R:\exists a,\ \forall w\in\omega^{-1}(s),\ a\text{ 可执行且 }u(w,a)\ge b\}\)，事前策略的全局可保底集为 \(\mathcal P=\bigcap_s\mathcal F(s)\)。当 \(\mathcal P\ne\varnothing\) 且各 \(\mathcal F(s)\) 有上界时，鲁棒前沿满足对偶等式与实达判据：
\[
\sup\mathcal P=\inf_{s\in\operatorname{range}(\omega)}\sup\mathcal F(s),
\qquad
b_*\in\mathcal P\ \Longleftrightarrow\
\forall s,\ \bigl(\sup\mathcal F(s)=b_*\Rightarrow b_*\in\mathcal F(s)\bigr),
\]
其中 \(b_*=\sup\mathcal P\)。左式由 \(\mathcal P\subseteq\mathcal F(s)\) 给出 \(\le\)，反证若有严格空隙 \(c\)，对每个纤维取超过 \(c\) 的受支持底并用 \(\mathcal F(s)\) 的向下封闭性得 \(c\in\mathcal P\)，矛盾；右式在非绑定纤维（\(b_*<\sup\mathcal F(s)\)）上同样借严格空隙与向下封闭性取得 \(b_*\in\mathcal F(s)\)。（PE1）

固定同一可付冲突词及和平基准，回接比例 \(\lambda\) 的原差额是 \(m-\lambda T\)（\(T\ge0\)）。原三方物量对照揭示负和战争的私人正诱因与回接净额守恒（`exact_native_material_controls`、`a_paid_return_has_exact_coalition_incidence`）：和平基准库存 \((4,7,10)\) 总量为 \(21\)，转嫁开战 \((8,7,4)\) 使社会总量跌至 \(19\)（净毁损 \(-2\)），但发起人把 \(6\) 单位成本外推后反而获得 \(+4=-2+6\) 的私人收益；足额回接 \((2,7,10)\) 在两联盟之间严格守恒战后总物量 \(19\)，同时把净毁损 \(-2\) 准确归位给发起人。足额回接严格翻转恰在 \(0<m<T\)。对有限候选族，存在 \(\lambda\in[0,1]\) 使全族差额非正当且仅当 \(\lambda=1\) 可行；不可行当且仅当存在零转嫁正收益项（\(T_i=0,m_i>0\)，对一切 \(\lambda\) 阻塞）或转嫁不足项（\(0<T_i<m_i\)）。可行时令
\[
\lambda_*=\max\bigl(\{0\}\cup\{m_i/T_i:T_i>0\}\bigr),
\]
对非负比例，全部差额非正当且仅当 \(\lambda\ge\lambda_*\)；每个更小比例均有原候选保持正差额；若 \(\lambda_*>0\)，至少一正转嫁项在 \(\lambda_*\) 处平局。全部严格为负当且仅当每个零转嫁项原已满足 \(m_i<0\) 且每个正转嫁项满足 \(m_i/T_i<\lambda\)（当 \(\lambda_*>0\) 时等价于 \(\lambda>\lambda_*\)；当 \(\lambda_*=0\) 时在 \(\lambda=0\) 处已严格为负，`strict_exclusion_exact`、`strict_after_positive_minimum`）。当付款容量把可实付比例上界限制在 \(\lambda_{\mathrm{cap}}=\min_j c_j\in[0,1]\) 时，可实付且消去开战优势的比例精确构成闭区间 \(\Lambda_{\mathrm{peace}}=[\lambda_*,\lambda_{\mathrm{cap}}]\)（`joint_interval`）；一旦 \(\lambda_{\mathrm{cap}}<\lambda_*\)，高于 \(\lambda_{\mathrm{cap}}\) 的比例遭遇具名库存短缺而低于等于 \(\lambda_{\mathrm{cap}}\) 的比例保留正开战差额（`source_minimum_or_named_shortage`、`strict_source_rate_exists_iff`），构成单靠事后追偿无法阻断战争的破产免责阻塞。当授权和容量随金额变化，逐比例重新验收原字面词，取实际可付域与该阈值射线的交集。（PE2）

### B.2 生产清偿的精确周期界

以 \(c=(p,g)\) 表示付款人与物量单元，令 \(D_c\) 为该单元全部原欠额，\(s_c\ge0\) 为保留生产底仓后的可支用额，\(r_c\ge0\) 为每期实际净增。对有限原账，
\[
\exists n\in\mathbb N\ \forall c,\quad D_c\le s_c+nr_c
\quad\Longleftrightarrow\quad
\forall c,\ s_c<D_c\Rightarrow r_c>0.
\]
在右侧成立时，
\[
n_*=\max_c\left\lceil\frac{D_c-s_c}{r_c}\right\rceil_+
\]
满足 \(n\ge n_*\) 当且仅当第 \(n\) 期的库存覆盖全部欠额；已足额单元的贡献为零。证明逐单元使用上整的定义，再对原账有限支撑取最大。结合原供给放行和独立签收，构造选最早实际足额截点，逐键支付，并从支付后保留的库存重启同一生产。（PE7）

### B.3 同一扣料位上的双方签收

设 \(n_0(p,g),n_y(p,g)\) 分别为原截点及实际后态 \(y\) 的生活需要，\(m_0(p,g),m_y(p,g)\) 为相应维护需要，均由本次执行法读取。动态保护底仓为
\[
R_y(p,g)=\max\{0,n_0(p,g),n_y(p,g)\}
        +\max\{0,m_0(p,g),m_y(p,g)\}.
\]
\(R_y(p,g)\le s_y(p,g)\) 当且仅当能把该库存分为非负的生活与维护两份，各自覆盖原及当前需要。这由两项最大值逐项比较得出；两种用途消费各自份额。原每个中间库存位置均按该条件核验。（PE16）

在当前真实状态 \(x\)、原债键 \(k=(v,p,g)\) 上，正有理支付 \(q\) 的合格条件为
\[
\begin{gathered}
v\ne p,\quad 0<q\le b_k(x),\quad
\operatorname{Valid}_x(\operatorname{pay}(k,q)),\\
\operatorname{Answer}_p(x,\operatorname{ord}(x),\operatorname{pay}(k,q))=\mathrm{true},\\
\operatorname{Answer}_v(x,\operatorname{ord}(x),\operatorname{pay}(k,q))=\mathrm{true},\\
\forall z,g',\quad
s_{\operatorname{pay}(x)}(z,g')\ge
\operatorname{Required}_x(\operatorname{pay}(x))(z,g').
\end{gathered}
\]
两人的答复读取同一账本驻点、实际序号、当前库存和字面转账。动态底仓在真实支付后态上计算。实际检查入口带有覆盖全部待检查地址的有限枚举；数学支付构造也可直接消费上述合格证明。

成功时，分配器消费刚写出的那个实际位置，产生
\[
b_{k'}(x')=b_{k'}(x)-\mathbf1_{\{k'=k\}}q.
\]
其他原地址保持。生产改订先获得原有关者的批准，再实际试产，试产输出进入支付检查的真实库存。拒签、授权失败、超原债或物量不足都生成带具体理由的原账后继。（PE16–PE17）

令 \(\mathcal A_k(x)\subseteq\mathbb R\) 为全部合格有理支付额的嵌入，\(q_*=\sup\mathcal A_k(x)\)。非空时 \(q_*\le b_k(x)\)，且 \(q_*\) 是紧上界。实达分支生成其实际支付；非实达分支对每个 \(\epsilon>0\) 生成
\[
q_*-\epsilon<q<q_*,
\]
连同 \(q\) 的实际支付后态；空域逐金额给具名拒绝。原债全额合格时 \(q_*=b_k(x)\)，构造选全额。（PE18）

**不可重复冲抵。** 每张实际收据的地址首分量等于生成它的当前序号，任意调度历史第 \(n\) 步序号为 \(\operatorname{ord}(x_0)+n\)。若同一收据在 \(i<j\) 两次被冲抵，其地址将同时等于这两个不同自然数，矛盾。生产改订和拒绝也消耗自己的序号，故该论证覆盖任意三类提交的交错。（PE17）

## C. 真实清偿后态与开放语言

### C.1 从实际库存开启和平

在结清后态 \(x_*\) 上检验共同生产词 \(w\) 和每名在册成员的独立退出词 \(e_p\)。检验包括注册、逐项授权、原与当前两组生计维护底线、共同词的非负净积累和至少一项正净增，以及正实际时长 \(q>0\)。反复使用同一词的稳定性由时间平移不改动作效果、增加非负储备不改注册和技术规则、实际时长在这些平移下保持的证明承担。

通过后，从 \(x_*\) 的整个原账、实际库存和现行生产规则生成运行入口；初始语言覆盖为空。以 \(x_*\) 为共同底仓，对任意公开历史驱动策略 \(\pi\) 和任意 \(n\)，第 \(n\) 次后继实际执行共同生产，支付生计，保每人的独立退出与全部结清原行，逐实际项新损失为零，且至少一个库存坐标严格增加。对任意起点 \(a\) 和经过轮数 \(n\)，
\[
t_{a+n}\ge t_a+nq.
\]
这给出从任意截点开始的时钟共终。（PE13、PE19）

原六单位实例的偿债物料库存按“受害者／付款人”读取：
\[
(111,113)\xrightarrow{\text{获批新规则试产}}(115,117)
\xrightarrow{\text{双方签收六单位}}(121,111).
\]
试产和清偿后时钟均为 \(5\)。清偿后付款人的 \(111\) 直接进入续产与退出检验。原地址
\[
a_0=(2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))
\]
保留且余债为零。第一个付费提案在钟 \(5\) 暴露受保护条款改变，后态在钟 \(6\)；第二个在钟 \(6\) 暴露原个人退出被移除，后态在钟 \(7\)。两次各支付半单位食物。第三餐对照在实际位置 \(2\) 返回付款人的食物短缺 \(0<1\)，保留同一结清原账。（PE19）

PE14 的较早消费者用另一条已结清入口，先暴露个人退出、后暴露公开条款；两次也分别实扣半单位并保同一原债地址。两条历史各保持自己的次序。

### C.2 表达失败、最小扩充与反脆弱不变量

效果类型包含“原可实付的具名续行在候选规则下失去可支付性”与“受保护公共条款改变”。效果在已扣费访问的实际前态和字面候选规则上判定。两项候选制度可以共享完全相同的零扣料旧要约词 `oldOfferWord` 或相同旧报价，而其中一项保留原个人独立退出、另一项通过改写技术或许可前提悄悄撤去该退出，使任何仅读取旧词或旧报价的分类器均无法区分隐形夺权（\(\neg\exists\operatorname{classify},\ \forall q,\ \operatorname{classify}(\operatorname{obs}_{\mathrm{old}}(q))=\operatorname{losses}(P(q))\)，`no_exact_loss_classifier`、`old_offer_word_cannot_classify_loss`）。（PE11）

语言定义为编码类型与拒绝指称 \((\mathrm{Code}_n,D_n)\)，当前覆盖为 \(C_n=\bigcup_{c\in\mathrm{Code}_n}D_n(c)\)，本次已付证据给出的效果集合为 \(E_n\)。生成语言修订当且仅当
\[
E_n\setminus C_n\ne\varnothing.
\]
修订取和类型 \(\mathrm{Code}_{n+1}=\mathrm{Code}_n\oplus\mathbf1\)，把每个旧表达嵌入新语言并保持其原义 \(D_{n+1}(\operatorname{inl}c)=D_n(c)\)，新增拒绝方向的指称恰为 \(D_{n+1}(\operatorname{inr}())=E_n\setminus C_n\)。于是
\[
C_{n+1}=C_n\cup E_n,
\qquad
C_{n+1}\subseteq B\ \Longleftrightarrow\
C_n\subseteq B\ \land\ E_n\subseteq B.
\]
这就是覆盖集合上的精确最小性。从空覆盖开始归纳，
\[
e\in C_n\quad\Longleftrightarrow\quad \exists i<n,\ e\in E_i.
\]
每个新表达都有自己的原付费见证，每个旧暴露持续可表达。在效果全集 \(\mathcal E\) 上，未封闭脆弱集 \(U_n=\mathcal E\setminus C_n\) 在每次新暴露下满足严格真包含缩小 \(U_{n+1}\subsetneq U_n\)（在适应性和平层的 `Party × Good` 子键域上同样严格缩小，并在该键域有限时给出新暴露轮数上界）；修订保持整个原生执行面，使任意有限原生词 `word` 的公共编译结果及每人每物量的生产净增恒等不变。（PE10、PE12）

该新语言写入所生成的账本驻点，等于下一轮运行实际读取的驻点。旧行、请求权和预算由同一次写入承接，新方向以零预算入账；下一轮共同生产从该状态读取原报价和签令。因此最小修订同时有语义结论和下一次实际消费。（PE13）

任意每拍语法可以依赖轮数、公开历史、原钟、公开条款和当前语言。解释器把该语法送入同一执行输入；解析失败给原到期续付。对这一全称策略域，上述不变量与修订充要条件逐轮保持。（PE11–PE13、PE19）

### C.3 归档阻碍的当前来源

修订把旧世界各支撑上的阻碍保留在归档中。记旧支撑集为 \(S\)，新支撑集为 \(S'\)，本次修订的回译为 \(b:S'\to S\)。旧支撑 \(s\) 上的阻碍 \(o\) 在归档中具有地址 \((s,o)\)。对当前新支撑 \(a\)，
\[
(s,o)\text{ 是当前局部阻碍}
\quad\Longleftrightarrow\quad s=b(a).
\]
必要性读取归档地址的第一分量；充分性在两支撑相等时直接采用同一原阻碍。全部原归档得以保留，当前实际处置则由自身回译支撑上的阻碍生成。（PE13）

## D. 审查费用、零费擦除、隐私与晚到证据

给定实际开局上的申报工序和逐申请复审工序，每个工序逐实际位置检验授权、扣料承担者及物量流。把这些合格工序的逐物量扣料相加，得到费用向量 \(c\)。对任意足额收费向量 \(b\)，
\[
b_g\ge\operatorname{cost}_g\quad(\forall g)
\quad\Longrightarrow\quad c_g\le b_g\quad(\forall g),
\qquad c_g=\operatorname{cost}_g.
\]
这里最小性相对于这组已核验工序。原调度保留共同生产位置，该报价的生产占位机会成本为零。申报正额、付款签令和共同预算通过后，费用在下一真实物量位一次扣清；预算短缺或费用耗尽生产净增时走原续产。（PE15）

同钟普通续付作为比较基准，每笔合法实付审查在任意逐物量严格正权重下都使付款人净收益严格为负。拆成多份已付片段仍按各原序号计费，并为每份重复支付申报费；换用不同代理付款人（`delegated.payer` \(\ne\) `levy.signer`）重投已覆盖范围，同样从实际付款人账户实扣半单位食物并返回固定拒绝，绝不重开二次审查（`a_different_filer_cannot_reopen_the_same_scope`）。未产生实际收费的呈示可从全轨迹擦除，整条无限状态—观察运行及任意行动读出泛函诱导的信息纤维均不变；任何读数变化必反查到发起人本人的实付写入。（PE8–PE10）

**双轨预缴隐私（PE9、PE21）。** 比较共享同一底仓、相同报价与付款／提案签令的两个实际入口。允许其底仓之上的隐藏库存和私人资格答复不同。给定相同公开策略，并要求在共同观察前缀处公开到期议程相同，则每个尚未实扣的前缀保持公开记录和语言相同。首次新区别必有同一张账单在两侧分别实际扣料。

证明按前缀归纳：共同观察和议程选同一输入、同一收费分支；未实扣时，两侧答复均是原公开议程，语言也保持。若下一前缀不同，未实扣分支导致矛盾，故两侧均有同一字面账单的收据。该结论将首异定位到真实支付，并保持两侧各自真实后态。

跨换仓时，用保留原库存下界、金融账和技术坐标的共同储备关系接续同一论证。刷新回执依事前公告，公告的落钟等于实际到账钟。若刷新后的新公开供给条款不同，则两侧已执行的具体生产词不同；新供给条款随实际生产公开。（PE25）

**原付款上的晚到证据（PE20、PE25）。** 已扣费而覆盖证据尚未齐备时，保留原收据、精确效果范围和真实物量后态。证据补齐后，在实际到达的驻点读取原范围。若范围已有覆盖，后态就是该驻点且无新语言写入；若仍有缺口，则在这里写入最小扩充。跨多轮实际续付和换仓的读路径保持同一原范围，补证从原收据完成处置。补证沿用原付款，原审查费不再扣取；原签令作为这次已付发生的证据保留。

有限自适应的时长观察无法判定全部保护条款与已付作用范围：对任意只查询有限步集合 \(S_Q\) 时长的自适应读取器，令对角化时刻 \(t^\dagger=\max(\{0\}\cup\{\tau(s):s\in S_Q\})+1\)，在全部已查位置保持原读数而在钟 \(t^\dagger\) 改写受保护条款，即得到 \(S_Q\) 观察完全相同但已付范围非空的对照制度（`every_finite_duration_reader_has_a_hidden_protected_change`、`no_finite_duration_reader_decides_the_paid_scope`）。这一对角化构造给出补证所需的具体对象。（PE20）

## E. 未结清时续付、生产词生成与九阶段部署轨道

在具备已验续付配方的未结清状态上，每轮先执行当期生计和独立退出，再读取清偿或生产改订提交。对任意自适应策略和任意有限等待，原债地址保持，拒签保持原余额，实际时钟满足 \(t_n\ge t_0+nq\)。双签晚到时，在该轮已续付的实际库存上核验支付；足额便实扣原债，结清后直接进入整网。（PE23）

生产修复先检查原注册配方，再检查一轮具名编辑。给定有限的原注册动作基底和有限在册名单，两层耗尽后联合搜索共同生产词 \(w\) 和各人独立退出词 \(e_p\)。宽度定义为
\[
\operatorname{width}(w,(e_p))=
\max\bigl(|w|,\max_{p\in P}|e_p|\bigr).
\]
固定当前态时，每个有限宽度都被完整检查。存在可行新联合配方，当且仅当某个有限宽度的搜索成功。首个成功宽度附有所有更窄宽度的具名拒因。证明把任意可行配方放入其有限宽度层；若该层被拒，拒因会直接反驳该配方的生产或个人退出条件。（PE24）

运行入口还检验当前实际时长、注册基准和本拍搜索窗。窗口内已有可行词就写入首个成功宽度的真实生产后态；窗口用尽则照付原到期并保留已查层的拒因。实际序位使可查宽度无界。原六单位部署在钟 \(7\) 的空词失败后，在钟 \(8\) 实写宽度四的生成词，两人的偿债物料各净增二。默认入口 `Deployment.{Facade,Ingress}` 从同一试产后态（`source`，钟 \(5\)，余债 \(6\)）依次推进 `due`（钟 \(5\to6\)，余债 \(6\)）、`refusal`（钟 \(6\)，余债 \(6\)）、`settlement` 与 `installation`（钟 \(6\)，余债 \(0\)）、`pendingReview`（钟 \(7\)）及 `rebase`（钟 \(8\)）：此后无等待批量轨道（`Facade.Stage`）在钟 \(8\) 立即执行 `revision`（证据仅允许消费一次）并经 \(5\) 次 `renewal` 抵达钟 \(13\)（完成本机批量与逐步进程 \(13\) 个观察对齐）；而持久在线入口（`Ingress`）在钟 \(9\)–\(10\) 先行两轮待证续付（`waiting 1, 2`），于钟 \(10\) 冷恢复后实写 U8（`revised 2 0`），再经钟 \(11\)–\(12\) 两轮续付（`revised 2 2`，游标 \(11\)）生成四物理节点准入封存的精确钟 \(12\) 原账头（`013bd261...`）。它们与 C.1 中试产后立即双签并完成两次即时修订（钟 \(5\to6\to7\)）的历史各自保持独立原身份。（PE24–PE26）

## F. 外部逐写因子化与历史身份

设原历史为状态 \(x_n\) 和实际写入 \(w_n\)。外部呈示给状态 \(y_k\) 与可空写入 \(e_k\)，定义
\[
o(0)=0,\qquad
o(k+1)=o(k)+\mathbf1_{\{e_k\ne\varnothing\}}.
\]
逐写检查要求：空写入保持 \(y_{k+1}=y_k\)；非空写入恰为 \(w_{o(k)}\)，并落到 \(x_{o(k)+1}\)。起点相同且所有逐写检查通过，当且仅当存在唯一因子化 \(f\)，同时保持状态、写入和序位递推。该 \(f\) 必为 \(o\)：由起点零和每次增加零或一归纳确定；状态相等再按逐写检查归纳。（PE8）

外部进展
\[
\forall n\ \exists k,\quad n\le o(k)
\]
等价于每个原截点都有唯一首次到达。没有进展时存在最后截点，此后全部为空写入。检查失败则定位错起点或首个异写，并保此前已经一致的前缀。

两类直接反例分别呈现失败的关系。第一类在共同开局后再次侵夺，然后持续实付生计、保旧行结清并保持时钟共终，首个再侵夺写入不等于原写入。第二类只交换两人的无害供给顺序：
\[
(\mathrm{true},\mathrm{true},\mathrm{false},\mathrm{false})
\quad\hbox{与}\quad
(\mathrm{false},\mathrm{false},\mathrm{true},\mathrm{true}).
\]
两条历史每拍完整物量状态和时钟相同，独立退出仍在、无新损失、旧账已清；其实际项次序不同，故无法因子化为同一固定顺序。逐写身份因此保留了末状态读数已经消去的真实发生信息。（PE8）

## G. 止战、无优先挂起反证、独立复权与不可重置期限

给定观察函数，把具有同一可见历史的实际状态组成观察纤维。持续保护策略存在，当且仅当存在包含开局的可保护族，使每个可达纤维共享一个平民行动，且对方看到该行动后的任何原生应对仍把实际后态留在族内。每个对手前缀均有同策略给出的独立退出；平民已提交词的中间位置先保原核验续段，再实付退出。由成功策略取其可达位置得必要性；由逐纤维共同动作选定一个策略，再对轮数归纳得充分性。（PE4）

每套失败策略有携原整账的有限首败。要求实际时钟共终时，失败恰分为有限首败或全部局部访问通过而原钟有界。在已签宪制博弈下，强制止战撤权策略不存在当且仅当每套已签策略落入局部菜单死胡同、有限联合越界或无限挂起未付三分支之一；与 \(\exists\pi\,\forall\alpha\) 对偶，若存在同一进攻策略击败全部已签平民策略（\(\exists\alpha\,\forall\pi\)），首次越界进攻的下一拍 \(t_*+1\) 必在原整账自动立下活的原追偿行（`the_uniform_attacker_files_the_first_original_loss_against_every_signed_policy`）。（PE4–PE5）

在已安装的应急规则、获准撤权、可保护观察族和非空合法局部菜单下，先选一套策略，再量化全部对手和合法交错。撤权优先实付：给定已核验字面行动，若原待办数为 \(N\)、正文长度为 \(\ell\)，完成恰在第 \(N+\ell\) 次访问，绝对完成钟等于原字面词真实终点，与竞争交错无关。反之，去掉优先规则后，当开局存在待办且复审可用时，第 \(0\) 拍合法递交撤权而第 \(\ge1\) 拍由对手持续提交零物量 `stopReview`，每步保持累计物量写入为空且物理时钟停在 \(\tau_0<\tau_0+1\)，使撤权在全部自然数拍上永不完成。撤权完成后再次取得权限当且仅当存在真实的独立复权记录；单一签署者不能独自再生权限。原暴露者持续拒绝时，任意自适应联盟保持其库存不减、原追偿行不丢和已撤权限不复活；任何受控操作的实付复现均可反查到原任务成员先前的实付 `.propose` 提名及每位原暴露者在原物量位置的本人 `true` 答复。（PE5）

应急授权逐有理截止检查实际签发、服务、两名独立复审人的扣料及每人退出，生成完整可行域、最早实达及最晚实达或严格逼近。PE22 原例在钟 \(1\) 签发、截止 \(3\)、服务到期 \(4\)，两名复审人各付一单位；缺第二份实付或缺个人退出均有自己的具名拒绝。一旦某截点满足 \(T_{\mathrm{dead}}<t_x\)，因任何合法原脚本从不倒拨物理时钟，沿此后的任意原输入后缀恒保持 \(T_{\mathrm{dead}}<t_y\)，一切 `.propose`、`.accept`、`.renew` 命令及受保护 `TaskUse` 均永久被拒，无法通过重查或未完复审重置期限。（PE5、PE22）

## H. 固定版本与命题映射

源码统一根目录为 `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/`，下表记为 **C**。进一步记 `T=C/Constitution/TerminalPeace`，`U=T/Universal`，`F=U/Terminal/FixedPoint`，`O=F/OpenPeace`，`J=U/Terminal/Productive/Clearance/Joint`，`X=J/Reinterpreted`，`R=O/Network/Runtime`，`E=C/Emergency/Installation`。模块名和声明是原源码中的精确标识。

| 固定组 | Homework 版本 | 原验收身份 |
| --- | --- | --- |
| [PE1–PE10](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/Terminal.lean) | `7e4da746f300b3796b8b18afb26cb0765c29afcb` | 原追偿、持续止战、共终、联合清偿、预缴与自适应修订各自回执 |
| [PE11–PE14](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/OpenLanguage.lean) | `b675168bda8f52a6565a8db3617e262daa738bb0` | 开放语言源 `4dc2e25393`，整网首写 `369df502de`，递归源 `4caa9fd0a2` |
| [PE15–PE22](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/ActualClearance.lean) | `71cb159f4f0727d8fb67e7a436a1476e03a0d913` | 实操工序 `b867cdf377`，新解释器原位清偿 `5c649ff440`，实际共同底仓 `71cb159f4f` |
| [PE23–PE26](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace.lean) | `3a90cba5ac7427737ee2fe630612dfed43e45da1` | 续付 `46afb0dec1`，部署 `f3014e5e63`，规则生成 `c58d788478`，联合刷新 `f4578baa82` |
| 收稿上限 | `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0` | PE27–PE33 执行、恢复与处置见对应执行附录 |

### H.1 生产声明、消费者与关键对照

| PE | 生产声明／证明 | 直接消费者与用途 |
| --- | --- | --- |
| 1 | `C/Choice/Frontier.lean`：`strict_flip_iff`；`C/Choice/Robust.lean`：`robust_frontier_eq_worst_observation`、`robust_frontier_attained_iff_binding_fibers_attain`；`C/Root/{Menus,History,Cofinal,Policy,Restitution}.lean`：`a_paid_return_has_exact_coalition_incidence` | `C/Consumers/{Menu,Timing,Native}.lean`：`exact_native_material_controls`、同截点 \(+4,0,-2\)、三态总量 \(21/19/19\) 与观察纤维保证 |
| 2 | `C/Threshold/Reattachment.lean`：`exact_upper_ray`、`no_admissible_rate_exact`、`any_positive_unshifted_blocks_every_rate`、`strict_exclusion_exact`；`C/Threshold/Capacity.lean`：`joint_interval`、`source_minimum_or_named_shortage`、`strict_source_rate_exists_iff`；`C/Root/RateDomain.lean` | `C/Consumers/{Native,Exact,Endpoint}.lean`：原槽、\(2/3\) 实达、容量闭区间、破产免责阻塞与超库存／重复清偿拒绝 |
| 3 | `C/Reparation/Actual/Root/Batch.lean`：`every_affected_address_is_filed_on_the_same_generated_next`；`Run/Conservation.lean`：`the_original_whole_ledger_conserves_each_material_good`；`T/Material/{Payer,ReceiptAccount,Outstanding}.lean`：`after_the_payer_returns_six_the_original_six_is_still_in_the_whole_account`、`the_victims_receipt_really_closes_the_old_six_and_writes_the_reverse_six`、`every_original_history_keeps_or_increases_outstanding_reparation`；`U/Protection/Guard.lean`：`the_guard_forwards_exactly_the_safe_original_requests` | 同层 `Consumers/{Joint,Registration}.lean`；`C/Reparation/Consumers/ActualDamage.lean`；双单边死锁与最宽安全门禁 `any_safe_original_admission_is_contained_in_the_guard` |
| 4 | `C/Constitution/Peace/Contract.lean`：`sustainable_civilian_peace_iff_one_move_protects_each_reachable_observation_fibre`；`a_cofinal_policy_fails_iff_first_counterexample_or_an_original_clock_bound` | 同目录 Root、Failure、Shortage：每条实际对手前缀、首败与独立退出 |
| 5 | `C/Constitution/ForcePeace/Contract/{Root,Delay,Defeat,Adversary}.lean`：`peace_is_enforceable_and_war_authority_cannot_be_unilaterally_reborn`、`a_lodged_withdrawal_has_an_actual_infinite_delay_without_priority`、`no_civilian_strategy_forces_peace_iff_each_signed_policy_has_an_original_obstruction`、`the_uniform_attacker_files_the_first_original_loss_against_every_signed_policy`；`ExposureGuard/Contract/Root.lean`；`C/Civil/Mandate/Root.lean`；`Commitment/Timing.lean`：`initial_native_rank_and_body_length_give_the_sharp_bound` | `ExposureGuard/Commitment/Consumers/Installed.lean`；`ExposureGuard/Consumers/Renewable/Dispatcher.lean`：联盟拒绝三不变量、统一进攻者自动立案与复权提名反查 |
| 6 | `U/Runtime/Viability/Strategy.lean`：`live_iff_cofinal_trajectory`；`U/Terminal/Whole.lean`：`simultaneous_clearance_is_generated_exactly_when_a_live_original_prefix_pays_every_row`；`T/Root.lean`：`the_original_source_has_independent_material_and_receipt_obstructions`；`T/Renewal/Cofinality.lean`：`the_due_service_cannot_be_delayed_past_the_pending_queue`、`the_first_crossing_of_each_open_hour_is_paid` | `T/Completion/Root.lean`：`source_generated_terminal_peace`；访问序号 \(4\) 强制汇合、唯一和平尾迹、反拉布整点实付与旧单签 \(\ge6\) 下界 |
| 7 | `U/Terminal/Productive/Clearance/Budget.lean`：`fundingCycles_le_iff_funds`；`Compiler.lean`：`finite_original_losses_are_cleared_by_production`；`J/Compiler.lean`：`compileJoint_pays_iff` | `Clearance/Consumers/OriginalBatch.lean`；`J/Consumers/Settlement.lean`：换料倒序短六单位 |
| 8 | `F/{Compiler,Closure}.lean`；`U/External/Trace.lean`：`exact_local_checks_iff_unique_factor`；`U/External/Frontier.lean`：`progress_iff_every_original_cut_has_unique_first_visit` | `F/NoFreeProbe/Prepayment/Consumers/JointOpening.lean`；`U/External/Countermodel/{Cofinal,SafeOrder}.lean` |
| 9 | `F/NoFreeProbe/Influence.lean`：`zero_tenders_leave_every_information_fibre_unchanged`、`any_changed_read_traces_to_a_payers_actual_write`；`RepeatedCharges.lean`；`Prepayment/Run.lean`：`locate_the_first_paid_distinction` | `Prepayment/Consumers/{Original,JointOpening}.lean`：半单位先扣；超净增投单走同一续产 |
| 10 | `F/AdaptivePeace/Contract.lean`：`every_novel_attack_generates_stronger_peace`、`Step.strictly_shrinks_unsealed`、`Step.keeps_every_native_word`；`History.lean`：`coverage_has_exactly_its_original_paid_witnesses`、`an_old_scope_cannot_open_another_review` | `AdaptivePeace/Consumers/{Original,JointOpening}.lean`：`a_different_filer_cannot_reopen_the_same_scope`、原征收修订、收费复投与代理付款防线 |
| 11 | `O/Boundary.lean`：`paidLosses_eq`、`no_exact_loss_classifier`、`old_offer_word_cannot_classify_loss`；`O/{Ingress,Dispatch,Payment}.lean` | `O/Consumers/Original.lean`：`a_new_policy_removes_an_exact_paid_exit_from_the_same_word`、`the_old_quote_does_not_classify_the_new_continuation_loss` |
| 12 | `O/Language.lean`：`least_repair_iff`、`denotes_inherited`、`denotes_fresh`；`O/Repair.lean`；`O/Universal.lean`：`open_future_permanent_peace` | `O/Consumers/JointOpening.lean`；`O/Network/Compile.lean`：每个表达的原付费见证 |
| 13 | `R/Advance.lean`：`next_reads_generated_first_write`；`R/History.lean`：`the_revised_resident_drives_the_next_material_write`、`history_is_living_and_peaceful`、`history_clock_bound`；`R/LocalU7.lean`：`archived_obstruction_is_local_iff` | `R/Consumers/Original.lean`：新驻点直接驱动第二次物量写入 |
| 14 | `O/Network/Consumers/Original.lean`；`R/Consumers/Original.lean`：`two_paid_gaps_reenter_the_material_dispatcher` | 两次各扣半单位，已覆盖复投、错误签署者及过期签令对照 |
| 15 | `F/NoFreeProbe/Pricing/Quote.lean`：`the_generated_fee_is_the_least_full_charge`；`Pricing/Entrance.lean`：`installation_reads_the_same_cost_at_every_epoch` | `Pricing/Consumers/{Work,Original}.lean`：合格实际工序、短款与原续产 |
| 16 | `J/Revision/{Reserve,Technology,Protected,Portfolio}.lean`；`O/Operational/Certificate.lean`：`verifyPrepared_accepts_every_admissible_word` | `O/Operational/Consumers/{Certificate,OriginalInventory}.lean`：完整实付词与替代次序 |
| 17 | `X/Funding.lean`：`checkFunding_exact`；`X/Payment.lean`：`PaidWrite.whole_successor`；`X/History.lean`：`every_history_preserves_its_original_addresses`、`no_receipt_can_be_booked_again_in_the_same_history` | `X/Consumers/{OriginalTrial,OriginalPayment,OriginalSource}.lean` |
| 18 | `X/Amount.lean`：`paymentUpper_is_exact`、`resolve_selects_the_funded_full_balance` | `X/Consumers/OriginalPayment.lean`：六单位全额、受害者拒签保原债 |
| 19 | `X/Network.lean`：`opens_network_at_the_original_resident`；`X/Renewal.lean`；`R/History.lean` | `X/Consumers/{OriginalNetwork,OriginalRevision/Repeated,OriginalShortage}.lean` |
| 20 | `R/Decision/Pending.lean`：`pending_completion_uses_the_posted_receipt`；`R/Decision/Observation.lean`：`every_finite_duration_reader_has_a_hidden_protected_change`、`no_finite_duration_reader_decides_the_paid_scope` | `R/Decision/Consumers/{Original,Pending}.lean`：对角化不可判定与补证同次完成 |
| 21 | `R/Privacy/History.lean`：`every_unpaid_prefix_keeps_the_transcript_and_language`、`a_new_distinction_requires_the_same_actual_payment_on_both_sides` | PE19 的实际共同底仓与两条各自继续运行的原后态 |
| 22 | `E/Protection.lean`：`protected_frontier_exact`、`shortest_protected_exact`、`longest_protected_exact`；`C/Emergency/Horizon.lean`：`no_reset_on_any_original_successor`、`no_authority_after_a_crossing`；`E/{Calendar,Envelope,Solver,Publication,Lifecycle}.lean` | `E/Consumers.lean`：钟 \(1,3,4\)、两名复审人实付、退出缺项与越界全后缀禁发 |
| 23 | `X/Scheduled/{Due,Motion,History}.lean`：`writeDue`、`every_round_consumes_the_original_successor`、`the_unsettled_clock_is_cofinal` | `X/Consumers/OriginalDue/Settlement.lean` |
| 24 | `O/Operational/Joint/Search.lean`：`search_is_complete_at_every_width`、`checked_prefixes_cover_every_finite_joint_recipe`；`R/Rebase/Completeness.lean`：`available_joint_production_forces_the_first_write` | `T/Deployment/Replacement.lean`：宽度四首写；宽度一仍付当期对照 |
| 25 | `R/Decision/Deferred/Transport.lean`：`Deferred.completion_along_reads_the_same_original_scope`、`Deferred.covered_paid_scope_does_not_write_twice`；`R/Rebase/Privacy.lean` | `X/Consumers/OriginalRevision/{Rebase,Mixed}.lean`；`T/Deployment/Continuation/Waiting.lean` |
| 26 | `Lean/SaturationMonoid/Tracks/LivingLawTerminalPeaceInstance.lean`；`T/Deployment/{Facade,Ingress,Continuation/Waiting}.lean` | `Lean/scripts/{living_law_runtime,terminal_peace_worker}.py`：批量钟 \(5\to13\)（\(13\) 观察一致）与持久入口 `Ingress` 钟 \(10\) 写 U8、钟 \(12\) 四机封存账头，原 ID 回读与同父事务 |

逐主张映射给出 PE1–PE33 的主要公开声明与完整 Lean 类型。复现指南列出原回执和本地核验。[公开主张映射](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) · [复现指南](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md)

PE3 的单边死锁与安全门禁、PE6 的材料和签收阻塞，使用原证明体在 Homework `3a90cba5ac` 依赖环境下的公开模块。`Root.lean` 在该纪元扩充了导入表。PE3 [`Payer.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Material/Payer.lean) · [`ReceiptAccount.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Material/ReceiptAccount.lean) · [`Outstanding.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Material/Outstanding.lean) · [`Guard.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Universal/Protection/Guard.lean)。PE6 [`Root.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Root.lean)。
