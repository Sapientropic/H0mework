# Sources and reproduction

The claims, paper and two technical appendices use the fixed objects below. The intake ceiling is Homework commit `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0`; each claim group retains its original epoch. Definitions and decisive proofs appear in the paper and Appendices A–I. Exact declarations and direct consumers are listed in [claims](claims.md) and the appendix source tables.

## Fixed research sources

| Claims | Fixed Homework commit | Contents |
| --- | --- | --- |
| [PE1–PE10](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/Terminal.lean) | `7e4da746f300b3796b8b18afb26cb0765c29afcb` | Responsibility reattachment, observation policies, original claims, joint settlement, prepayment and adaptive peace |
| [PE11–PE14](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/OpenLanguage.lean) | `b675168bda8f52a6565a8db3617e262daa738bb0` | Open languages, the first network write and actual recursion |
| [PE15–PE22](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/ActualClearance.lean) | `71cb159f4f0727d8fb67e7a436a1476e03a0d913` | Actual review fees, production revision, payment at its original position, network opening, evidence completion and authorisation deadlines |
| [PE23–PE27](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace.lean) | `3a90cba5ac7427737ee2fe630612dfed43e45da1` | Continuation with unsettled debt, recipe search, receipt transport across rebasing, default entry and four-node admission |
| [PE28–PE30](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/QuorumRecovery.lean) | `b5b9c5f86cab0bb212e306ab89db4bf5b177a177` | Cold recovery, paid reconfiguration and uniqueness of certified histories |
| [PE31–PE33](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/HandoffDisposition.lean) | `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0` | Exact completion, role seals, disposition at the original parent and consistency through arbitrary dispositions |

The source root is `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/`. Appendix H gives complete relative paths and declarations for PE1–PE26; Appendix I.7 gives the Lean and Python interfaces for PE27–PE33. Read each fixed object by its commit and path:

```bash
git -C /path/to/Homework show COMMIT:PATH
```

The general settlement domain uses mathematical choice, least natural numbers and real infima or suprema. Finite recipe search performs complete width checks over a finite registered action basis and a finite roster. Numerical consumers, offline durable-transaction fixtures and four-physical-node receipts retain their respective inputs and execution identities.

## Verified public selection

The PE1–PE33 map identifies the public modules, complete Lean types, direct consumers and original receipts at fixed H0mework revision `267889674048`. The machine-readable binding separately records the five supporting source files for PE3 and PE6 at the epoch of their public owners. [Claim map](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) · [Machine-readable binding](public-source-binding.json) · [Reproduction guide](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md)

Run the following commands from that checkout. For a fresh checkout, prepare the pinned dependencies with `make bootstrap`. The replay uses the pinned Lean toolchain and Python with `cryptography`.

```bash
python3 tools/enforceable_peace.py entry
python3 tools/enforceable_peace.py build --output .local/peace-build
python3 tools/enforceable_peace.py replay --output .local/peace-replay
```

The original receipts preserve the SHA-256 digests of the temporary PE27 runtime override and early PE28–PE29 transport adapter. The archived journal and the fixed public programmes support the offline verification.

## Frozen execution evidence

The links below resolve to the three original receipts. Each later receipt binds the preceding execution by its original digest.

| Receipt | SHA-256 |
| --- | --- |
| [`acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rc882831f/living-law/terminal-peace/original-six/acceptance.json) | `c087bd309a4e92b62ac3d88a17ec219c710e9fee929532a8a861dca26a6d968d` |
| [`recovery-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rb5b9c5f8/living-law/terminal-peace/original-six/recovery-acceptance.json) | `26522f53e07161b9bd8504c609292295168b90f6ba7927ad77c2e22cbc2847ad` |
| [`handoff-resolution-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rcf880bb2/living-law/terminal-peace/original-six/handoff-resolution-acceptance.json) | `7fe676f6d8dd085b959c92aa5ca151b7e2a9478378306a80a44d82924733c56b` |

Run the read-only verification from the paper directory against either the public `H0mework` evidence tree or a flat `original-six` directory (passing `--homework /path/to/Homework` optionally cross-checks the raw research Git blobs):

```bash
python3 scripts/verify_frozen_execution.py \
  --evidence-root /path/to/H0mework/evidence/enforceable-peace/original
```

The script checks 95 signatures, the eight certified rows at clocks 21–28 and three exclusions against the frozen public-key policy, together with the receipt-recorded digests of the two fixed Lean objects (and their raw Git blobs when `--homework` is supplied). The observed result is PASS. Its inputs are the original public policy, frozen receipts and fixed Git objects; the four live nodes retain their original execution state.

## Reading editions and editable sources

`scripts/build_reading.py` produces four PDFs: the Chinese and English papers and their technical supplements. `scripts/package_editable.py` collects the bilingual Markdown, bibliography, vector figures, generators, paper-specific build scripts and their shared layout dependencies. See [PDF-BUILD](scripts/PDF-BUILD.md) for dependencies and commands and [figures/README](figures/README.md) for figure sources, units and actual data.

The editable archive preserves the paper's writing and figure sources. The research repositories and original deployment records are connected through the fixed references in this note and the appendices. The paper directory’s `release-artifacts.json` records the PDF and ZIP identities; `manifest.json` at the archive root records every included file’s bytes and digest.
