# Appendix I. Certified Histories, Handover, and Interrupted Attempts

## I.1. Certified objects and signing obligations

Let \(P\) be the type of ledger heads and \(M\) the type of verifier identities. Each head \(p\in P\) obtains a four-member roster \(O(p)\subset M\) from its already certified history, instantiating the \(n=3f+1=4\ (f=1)\), quorum-size \(2f+1=3\) intersection geometry against equivocation and seal violation at every parent head. A successor \(q\) contains the original request identifier, the literal input, the actual payment at that occurrence, the resulting readout, and the next roster. Every attestation binds the same parent head \(p\) and candidate successor \(q\).

Write \(V(m,p,q)\) for member \(m\)'s durable decision vote for this successor, and \(R(m,p,q)\) for its attestation that it replayed the same payment from the original source. Define certification by

\[
\begin{aligned}
\operatorname{Cert}(p,q)\Longleftrightarrow{} &
\left[\exists Q\subseteq O(p),\ |Q|\ge3,\
\forall m\in Q,\ V(m,p,q)\right]\\
&{}\land\left[O(q)\ne O(p)\Rightarrow
\forall m\in O(q),\ R(m,p,q)\right].
\end{aligned}
\tag{I.1}
\]

Each handover connects an outgoing three-member decision quorum to the incoming roster's complete replay of that occurrence. The roster takes effect through this edge, and the next write is verified under the new roster.

Ordinary certification uses the following durable signing constraint. At each parent \(p\), at most one member belongs to the fault set \(B_p\); every other member may vote for only one successor at that parent. The fault set may change with the parent. When withdrawal and reassignment are allowed, the constraint becomes: if a member that observes the constraint has voted for two distinct candidates, at least one candidate must have a valid exclusion. We derive sound exclusion from role-specific seals below, then prove that this weaker signing constraint still preserves a unique history.

## I.2. Quorum intersection through arbitrarily many handovers

**Lemma I.1 (An intersection outside the fault set).** Let \(|O|=4\), \(|B|\le1\), and \(W,U\subseteq O\), with \(|W|,|U|\ge3\). Then \(W\cap U\) contains a member outside \(B\).

**Proof.** Since \(W\cup U\subseteq O\),

\[
|W\cap U|
=|W|+|U|-|W\cup U|
\ge3+3-4=2.
\]

A fault set of size at most one cannot contain this intersection. Choose an intersecting member outside it. \(\square\)

**Theorem I.2 (A unique prefix order for certified histories).** Suppose every parent head satisfies the four-member, single-fault, and durable signing conditions of Lemma I.1. Then:

1. Any two certified successors of the same parent are equal.
2. Any two finite certified histories from the same root are prefix comparable.
3. Any two infinite certified continuations from the same root agree at every write index.

Successive rosters may be completely disjoint.

**Proof.** Each certified edge provides an outgoing decision quorum. Lemma I.1 finds a member outside the fault set who has voted for both edges. Its durable signing constraint forces the successors to coincide, proving the first assertion. For finite histories, induct on their length: the empty history is a prefix of every history; two nonempty histories have the same first successor, so the induction hypothesis applies at that successor. For infinite histories, begin at their common root and repeatedly apply successor uniqueness. The argument at each step uses only the roster of that parent, so no overlap between successive rosters is required. \(\square\)

Lemma I.1 also applies to three fresh read responses and the three members that durably stored a write. Two read responses do not give the same guarantee. Take \(O=\{0,1,2,3\}\), durable writers \(\{0,1,2\}\), readers \(\{2,3\}\), and sole faulty member \(2\). The two sets intersect only at the faulty identity. This is the exact counterexample underlying the three-read threshold for cold recovery.

## I.3. An exact completion criterion after an interrupted handover

Fix one parent head, one epoch, and one handover candidate. Let \(O\) be the outgoing roster and \(N\) the proposed incoming roster, each with four members. Let \(D\subseteq O\) record outgoing **no-decision seals**, and let \(S\subseteq N\) record incoming **no-replay seals**. A seal carries two durable obligations: the member has not previously signed that role and will not sign that role subsequently.

For an outgoing triple \(Q\subseteq O\), define

\[
F(Q)=(Q\cap D)\cup(N\cap S).
\tag{I.2}
\]

Call a pair \((B,C)\) of finite sets a **compatible completion** under \((D,S)\) if the outgoing decision set \(C\subseteq O\) satisfies \(|C|\ge3\), the fault set \(B\) satisfies \(|B\cap O|\le1\) and \(|B\cap N|\le1\), and \((C\cap D)\cup(N\cap S)\subseteq B\). If the votes of \(Q\) and the replays of all of \(N\) can jointly form a certificate, every member of \(Q\cap D\) has both voted and sealed against voting, while every member of \(N\cap S\) has both replayed and sealed against replay. These identities must therefore belong to the fault set. An overlapping identity is counted once in the union; each roster checks its own fault budget.

**Theorem I.3 (Exact completion criterion).** A compatible completion \((B,C)\) respecting the fault budget of at most one member in each roster exists under \((D,S)\) if and only if

\[
\exists Q\subseteq O,\quad |Q|=3,\qquad
|F(Q)\cap O|\le1,\qquad |F(Q)\cap N|\le1.
\tag{I.3}
\]

When \(|O|=4\), exactly four outgoing triples need to be examined.

**Proof.** If (I.3) holds, take the fault set to be exactly \(F(Q)\). The outgoing triple \(Q\) supplies the decision votes and the incoming roster \(N\) supplies the replays. Every identity whose role conflicts with a seal is already included in this fault set, and both roster budgets are satisfied. This constructs a combination of certifying roles compatible with the evidence.

Conversely, suppose a compatible fault set \(B\) and outgoing signer set \(C\subseteq O\) exist, where \(|C|\ge3\) and \(|B\cap O|,|B\cap N|\le1\). Choose a triple \(Q\subseteq C\). Every identity in \(Q\cap D\) or \(N\cap S\) must belong to \(B\), so \(F(Q)\subseteq B\). Intersecting with either roster preserves the cardinality bound of one, yielding (I.3). \(\square\)

Compatibility answers a specific question: does the current evidence still permit the original candidate to obtain complete certification? The execution returns the witness \(Q,N,F(Q)\), keeping the missing evidence explicit. Only when all four triples fail (I.3) does the evidence exclude the original candidate.

**Corollary I.4 (A certified candidate cannot be validly excluded).** If the original candidate is already certified and identities that contradict role-specific seals respect the fault budget in each roster, then the candidate continues to satisfy (I.3).

**Proof.** Use the certificate's actual outgoing signer set and the actual fault set. Every contradiction between an attestation and a seal lies in that fault set. The converse argument in Theorem I.3 supplies a compatible triple. \(\square\)

**Corollary I.5 (Three seals exclude; two can remain compatible).** Three outgoing no-decision seals in a four-member roster suffice to exclude the original handover. Two such seals can remain compatible.

**Proof.** Every outgoing decision triple intersects a three-member seal set in at least two members. Thus \(F(Q)\cap O\) contains at least two identities, exceeding the outgoing fault budget. For the counterexample, take

\[
O=N=\{0,1,2,3\},\quad D=\{0,1\},\quad S=\varnothing,\quad Q=\{0,2,3\}.
\]

Here \(F(Q)=\{0\}\); the fault count is one in both rosters, so (I.3) holds. \(\square\)

This counterexample shows that two outgoing seals alone cannot support a universal exclusion rule. Each actual candidate is still checked by substituting all available outgoing and incoming role-specific seals into (I.3).

## I.4. Checking the maximum obtainable evidence first

A seal permanently closes the corresponding signing role, so the order in which seals are issued is itself part of the execution.

Suppose the current responders can supply at most \(D_{\max},S_{\max}\). If the original candidate satisfies (I.3) even for these maximum seal sets, then it also satisfies the criterion for every \(D\subseteq D_{\max}\), \(S\subseteq S_{\max}\). For the same witnessing triple,

\[
(Q\cap D)\cup(N\cap S)
\subseteq
(Q\cap D_{\max})\cup(N\cap S_{\max}),
\]

so both cardinality constraints can only weaken. The execution therefore stops before requesting irrevocable seals, returns the named evidence gap, and preserves the route for completing the original certificate under the original request identifier.

An ordered handover first durably retains the original intent at at least three outgoing nodes, then obtains all four incoming replays. Outgoing decision votes must consume that complete replay evidence.

**Corollary I.6 (Deadlock-free disposal before replay completion).** Suppose \(|O|=4\), \(D\subseteq O\), and casting an outgoing decision vote requires complete incoming replay. If the handover is interrupted before incoming replay is complete, then even if all four nominated incoming members stay unreachable (no incoming responses), responses from any set \(R_{\mathrm{out}}\subseteq O\) of at least three reachable outgoing members—each returning either an actual decision vote or a no-decision seal in \(D\)—necessarily refute (I.3) and validly exclude the attempt.

**Proof.** Every \(m\in R_{\mathrm{out}}\) either has cast a decision vote or satisfies \(m\in D\). Because incoming replay is incomplete, no outgoing decision vote can exist, forcing \(R_{\mathrm{out}}\subseteq D\) and hence \(|D|\ge|R_{\mathrm{out}}|\ge3\). Corollary I.5 immediately excludes the candidate. \(\square\)

The execution thus has three outcomes:

| Available evidence | Actual successor |
| --- | --- |
| The original certificate is complete | Complete the original request identifier and recover the same original payment |
| A compatible combination remains | Return the outgoing triple, required faulty identities, and missing evidence; retain the original signing route |
| All four triples are excluded | Under the original caller's authorization, submit an actual due payment at the same parent head and record withdrawal or reassignment together with all exclusion evidence |

With repeated reassignment, each excluded candidate's request identifier, candidate head, original authorization, and proposed roster are retained in the final paid row. A later lookup of an original identifier returns its own disposition and the actual successor.

## I.5. Unique histories with valid exclusion

Write \(E(p,q)\) when candidate \(q\) has a valid exclusion at parent \(p\). Assume

\[
\operatorname{Cert}(p,q)\Rightarrow\neg E(p,q),
\tag{I.4}
\]

and that at each parent at most one member of the four-member roster violates the signing constraint

\[
V(m,p,q_1)\land V(m,p,q_2)
\Rightarrow
q_1=q_2\ \lor\ E(p,q_1)\ \lor\ E(p,q_2).
\tag{I.5}
\]

Corollary I.4 supplies (I.4). Nodes enforce (I.5) by verifying the candidate's exclusion chain within a durable transaction.

**Theorem I.7 (Arbitrary dispositions preserve the common-root history).** Under these conditions, any two finite certified histories from the same root are prefix comparable, and any two infinite certified continuations from that root agree at every index. The conclusion covers arbitrarily many handovers, withdrawals, and reassignments.

**Proof.** Define a surviving vote by

\[
V^\circ(m,p,q):=V(m,p,q)\land\neg E(p,q).
\]

By (I.4), every vote on an original certified edge becomes a surviving vote, so every original certified history is retained. If a member that observes the signing constraint has surviving votes for \(q_1,q_2\), the last two alternatives in (I.5) contradict the survival conditions. Hence \(q_1=q_2\). Surviving votes therefore satisfy the strict durable signing condition of Theorem I.2. That theorem gives finite prefix comparability and infinite pointwise agreement. \(\square\)

The proof retains every already certified edge and releases only candidates with valid exclusions. Withdrawal allows a verifier to take part in the actual payment at the original parent without changing any established history.

## I.6. The certified execution of the original six-unit ledger

Three frozen receipts successively consume the same source, `terminal-peace/original-six`. In every paid successor below, the original debt address is \((2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))\), and the reparation balance is zero. The clock is generated by actual payments in the source execution; request identifiers and visit cursors are retained separately.

| Source clock | Recorded execution | Roster after completion |
| --- | --- | --- |
| 12 | Shared original head before four-host admission | \(abcd\) |
| 13 | A three-vote wait is followed by all four native replays, completing the first admitted write | \(abcd\) |
| 14 | Three nodes attest the next actual renewal payment | \(abcd\) |
| 15 | The returning node replays the exact original prefix before attesting | \(abcd\) |
| 16 | The installed entry point makes an actual payment; the original caller and four nodes seal this prefix | \(abcd\) |
| 17 | After loss of the primary journal and local intent, the original payment is completed under its original identifier; two fresh read responses had named \(b,c\) as missing | \(abcd\) |
| 18 | Paid handover \(abcd\to abce\); absence of \(e\) halts at incoming replay, and completion follows when its evidence arrives | \(abce\) |
| 19 | After rollback of the primary to clock 16, the latest original ledger is reconstructed from certified history | \(abce\) |
| 20 | The installed entry point pays; the three remote hosts \(b,c,e\) alone recover the original head and request identifier | \(abce\) |
| 21 | An actual payment activates the ordered entry: replay precedes decision voting | \(abce\) |
| 22 | Remote seals recover the original paid withdrawal; late replay cannot cross the outgoing seals | \(abce\) |
| 23 | Valid exclusion is followed by paid reassignment, completing \(abce\to abcf\) | \(abcf\) |
| 24 | Recovery of the third actual decision vote completes the already selected original identifier and the handover \(abcf\to abcg\) | \(abcg\) |
| 25 | Outgoing seals from \(b,c,g\) exclude a candidate with one stored vote; that voter verifies exclusion and signs the paid withdrawal | \(abcg\) |
| 26 | The installed entry point pays the next due; three remote hosts recover the current-roster ledger | \(abcg\) |
| 27 | Two stored decision votes still admit a compatible combination; the original route is retained and the same identifier completes \(abcg\to abcf\) | \(abcf\) |
| 28 | The next due is paid, and three remote hosts recover the same final head | \(abcf\) |

The actual certified rows at clocks 21–28 are listed below. An empty incoming column means that the payment retains the current roster. Clock 24 has exactly three outgoing decision votes; the other records retain all four votes received at those occurrences.

| Source clock | Actual request identifier | Outgoing decisions | Incoming replays |
| --- | --- | --- | --- |
| 21 | `ordered-protocol-21` | \(a,b,c,e\) | — |
| 22 | `withdraw-f-22` | \(a,b,c,e\) | — |
| 23 | `reassign-to-f-23` | \(a,b,c,e\) | \(a,b,c,f\) |
| 24 | `hidden-selected-g-24` | \(a,b,c\) | \(a,b,c,g\) |
| 25 | `recovered-capacity-25` | \(a,b,c,g\) | — |
| 26 | `ordered-peace-continues-26` | \(a,b,c,g\) | — |
| 27 | `two-outgoing-live-27` | \(a,b,c,g\) | \(a,b,c,f\) |
| 28 | `guarded-ordinary-28` | \(a,b,c,f\) | — |

The thresholds have distinct roles. Initial four-host admission and bootstrap sealing require four attestations; subsequent ordinary writes and fresh reads of the current roster require at least three. A handover certificate requires at least three outgoing decision votes and all four incoming replays. Normal completion also durably stores the complete certificate at at least three nodes in each roster. At clock 18, the incoming identity \(e\) uses the retired identity \(d\)'s original host with a separate new key; physical hosts and changes of logical identity are recorded separately. An independent local regression exercises the completely disjoint handover \(abcd\to efgh\) under the same contract.

## I.7. Claims, proofs, and direct acceptance evidence

This appendix binds theorems, process regressions, and physical-node executions separately. The Lean theorems quantify over arbitrary identities, heads, and admissible certified histories. Local regressions test fault schedules with either a deterministic native interface or the actual Lean entry point. The four-host receipts preserve the execution of the same original six-unit source described above.

In the table, \(D\) = `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Deployment/` and \(P\) = `Lean/scripts/terminal_peace_replication/`.

| PE | Fixed Homework revision | Original producer or execution entry | Direct consumer, counterexample, and acceptance |
| --- | --- | --- | --- |
| PE27 | `3a90cba5ac7427737ee2fe630612dfed43e45da1`, original increment `c882831f9a` | `terminal_peace_anchor.py`, `terminal_peace_submit.py`, `terminal_peace_worker.py` | `terminal-peace-admission-check.py`; four-host `acceptance.json`, clocks 12–16, retention of the original intent when votes are missing, and rejection of an older parent at all four nodes |
| PE28 | `b5b9c5f86cab0bb212e306ab89db4bf5b177a177` | \(P\)`replica.py::Replica.prepare/status/store`, `quorum.py::Quorum.latest`, `operator.py::Primary.recover/install` | Lost journal, stale challenge, original identifier, rollback, and partial archive in `terminal-peace-replication-check.py`; four-host `recovery-acceptance.json` |
| PE29 | As PE28 | \(P\)`protocol.py::Timeline.candidate/verify_votes/apply`, `Quorum.choose/store` | The same native `due` and the clock-18 handover; the local \(abcd\to efgh\) consumer |
| PE30 | As PE28 | \(D\)[`Recovery/Quorum.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/Rb5b9c5f8/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Deployment/Recovery/Quorum.lean): `honest_overlap`, `unique_successor`, `original_histories_are_prefix_comparable`, `cofinal_histories_agree` | `two_reads_can_miss_an_honest_durable_verifier`; the quorum contract for cold recovery and handover |
| PE31 | `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0` | \(D\)[`Recovery/HandoffDisposition.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/Rcf880bb2/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Deployment/Recovery/HandoffDisposition.lean): `possible_iff_completion`, `possible_with_maximal_seals`, `selected_stays_possible`, `three_outgoing_seals_exclude` | `two_outgoing_seals_can_leave_a_completion`, `interrupted_before_decision_can_be_disposed`; \(P\)`rounds.py::possible_completion`, `Quorum.resolve` |
| PE32 | As PE31 | `dispositions_preserve_original_prefix_order` and `dispositions_preserve_every_cofinal_cut` in the same file | \(P\)`Timeline.exclusion/resolved/apply`, `Replica.stage/ready/seal/prepare`, `Primary.resolve/recover/read_result` |
| PE33 | As PE31 | The original execution above and the `terminal_peace_online.py` entry point | Repeated reassignment, late replay, hidden selection, and preservation of two live votes in `terminal-peace-handoff-resolution-check.py`; four-host `handoff-resolution-acceptance.json`, clocks 21–28 |

The three frozen receipts are linked below with their original SHA-256 digests.

| Receipt | SHA-256 |
| --- | --- |
| [`acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rc882831f/living-law/terminal-peace/original-six/acceptance.json) | `c087bd309a4e92b62ac3d88a17ec219c710e9fee929532a8a861dca26a6d968d` |
| [`recovery-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rb5b9c5f8/living-law/terminal-peace/original-six/recovery-acceptance.json) | `26522f53e07161b9bd8504c609292295168b90f6ba7927ad77c2e22cbc2847ad` |
| [`handoff-resolution-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rcf880bb2/living-law/terminal-peace/original-six/handoff-resolution-acceptance.json) | `7fe676f6d8dd085b959c92aa5ca151b7e2a9478378306a80a44d82924733c56b` |

Each later receipt retains the preceding receipt's digest. The original kernel acceptance records `propext`, `Classical.choice`, and `Quot.sound` for the five ordinary recovery declarations and the eight disposition declarations. The original source SHA-256 digests recorded in the frozen receipts for `Quorum.lean` and `HandoffDisposition.lean` are `09dc0782ab9361c0be28f1b1fd83ab07bf6df3773dbe80a17485c3044a2f3e34` and `7d3ba9fbd16aa63c3ce3003ae5cf4132f76380835dd84cfe26dcb4bce83ebfee` (in the public selection, `HandoffDisposition.lean` rewrites only its one-line versioned `import`, and `python3 tools/enforceable_peace.py source` recovers the exact original digest byte for byte).

Offline acceptance verifies 95 public-key signatures covering initial admission, bootstrap sealing, the clock-18 handover, and clocks 21–28. It recomputes the eight new heads, checks their successive parents, original debt address, zero balance, and clock continuity, and enumerates the four outgoing triples at each of the three dispositions. The identities of the physical-node executions are fixed by the three original receipts.

The [public map for PE1–PE33](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) identifies the fixed execution programs and direct consumers. The [offline replay](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md) uses the [original certified journal](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/certified-journal.json) and verifies the same Lean continuation through clock 28.
