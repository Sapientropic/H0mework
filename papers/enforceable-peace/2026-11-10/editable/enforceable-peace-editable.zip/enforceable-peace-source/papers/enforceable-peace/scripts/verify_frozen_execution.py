#!/usr/bin/env python3
"""Verify frozen PE27--PE33 execution evidence without contacting live nodes.

Inputs are the three original acceptance receipts, their public-key policy, and
two fixed Git blobs. No private keys, live journals, or node commands are read.
The program prints a compact JSON report and makes no filesystem changes.

Requires Python 3.10+ and cryptography.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import itertools
import json
from pathlib import Path
import subprocess

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

DOMAIN = b"public-source-audit/network/v1\x00"
SOURCE = "terminal-peace/original-six"
RECEIPTS = {
    "acceptance.json": "c087bd309a4e92b62ac3d88a17ec219c710e9fee929532a8a861dca26a6d968d",
    "recovery-acceptance.json": "26522f53e07161b9bd8504c609292295168b90f6ba7927ad77c2e22cbc2847ad",
    "handoff-resolution-acceptance.json": "7fe676f6d8dd085b959c92aa5ca151b7e2a9478378306a80a44d82924733c56b",
}
PUBLIC_RECEIPT_PATHS = {
    "acceptance.json": "Rc882831f/living-law/terminal-peace/original-six/acceptance.json",
    "recovery-acceptance.json": "Rb5b9c5f8/living-law/terminal-peace/original-six/recovery-acceptance.json",
    "handoff-resolution-acceptance.json": "Rcf880bb2/living-law/terminal-peace/original-six/handoff-resolution-acceptance.json",
}
PUBLIC_POLICY_PATH = "Rc882831f/living-law/terminal-peace/original-six/policy.canonical.json"
RECOVERY = (
    "Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/"
    "Constitution/TerminalPeace/Deployment/Recovery/"
)
SOURCE_BLOBS = (
    (
        "b5b9c5f86cab0bb212e306ab89db4bf5b177a177",
        "Quorum.lean",
        "09dc0782ab9361c0be28f1b1fd83ab07bf6df3773dbe80a17485c3044a2f3e34",
    ),
    (
        "cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0",
        "HandoffDisposition.lean",
        "7d3ba9fbd16aa63c3ce3003ae5cf4132f76380835dd84cfe26dcb4bce83ebfee",
    ),
)


def canonical(value):
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check(homework, evidence_root):
    records = {}
    for filename, expected in RECEIPTS.items():
        candidate = evidence_root / filename
        if not candidate.is_file():
            candidate = evidence_root / PUBLIC_RECEIPT_PATHS[filename]
        raw = candidate.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == expected, f"receipt SHA: {filename}")
        records[filename] = json.loads(raw)
        require(records[filename]["source"] == SOURCE, f"source: {filename}")
    policy_path = evidence_root / "policy.json"
    if not policy_path.is_file():
        policy_path = evidence_root / PUBLIC_POLICY_PATH
    policy = json.loads(policy_path.read_text())
    owner = policy["owner"]
    counts = {"signatures": 0, "certified_rows": 0, "exclusions": 0}

    def verify(key, receipt, kind, body):
        require(
            set(receipt) == {"kind", "body", "signature"}
            and receipt["kind"] == kind
            and receipt["body"] == body,
            f"signature role/body: {kind}",
        )
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(key)).verify(
            base64.b64decode(receipt["signature"], validate=True),
            DOMAIN + kind.encode() + b"\x00" + canonical(body),
        )
        counts["signatures"] += 1

    first = records["acceptance.json"]
    recovery = records["recovery-acceptance.json"]
    resolved = records["handoff-resolution-acceptance.json"]
    require(
        recovery["previous_acceptance_sha256"] == RECEIPTS["acceptance.json"]
        and resolved["previous_acceptance_sha256"] == RECEIPTS["recovery-acceptance.json"],
        "receipt-chain binding",
    )

    previous = first["before"]
    for certificate, after in zip(first["certificates"], first["after"], strict=True):
        authorization = certificate["owner"]
        verify(owner, authorization, "terminal-peace-owner-input/v1", authorization["body"])
        require(
            authorization["body"]["request"]["parent"] == previous["head"],
            "initial admission parent",
        )
        for name, vote in certificate["votes"].items():
            point = vote["body"]
            require(
                point["authorization"] == digest(authorization)
                and point["next"] == after
                and point["parent"] == previous,
                "initial admission occurrence",
            )
            verify(policy["members"][name], vote, "terminal-peace-native-vote/v1", point)
        previous = after
    require(previous == recovery["original_prefix"], "clock-16 original prefix")

    bootstrap = recovery["bootstrap"]
    point = bootstrap["owner"]["body"]
    verify(owner, bootstrap["owner"], "terminal-peace-replica-bootstrap-owner/v1", point)
    require(point["cut"] == recovery["original_prefix"], "bootstrap cut")
    for name, vote in bootstrap["votes"].items():
        verify(policy["members"][name], vote, "terminal-peace-replica-bootstrap/v1", point)

    certificate = recovery["handoff_certificate"]
    authorization = certificate["intent"]["owner"]
    terms = authorization["body"]
    record = certificate["intent"]["record"]
    verify(owner, authorization, "terminal-peace-replica-input/v1", terms)
    known = {**policy["members"], **terms["incoming"]}
    for name, vote in certificate["votes"].items():
        point = vote["body"]
        expected_head = digest(
            [terms["request"]["parent"], terms["request"]["id"], "due", record, terms]
        )
        require(
            point["epoch"] == terms["epoch"]
            and point["intent"] == digest(certificate["intent"])
            and point["next"] == dict(record, head=expected_head),
            "clock-18 handover occurrence",
        )
        verify(known[name], vote, "terminal-peace-replica-chosen/v1", point)

    current = recovery["current"]
    outgoing = terms["incoming"]
    epoch = recovery["epoch"]
    bootstrap_id = terms["bootstrap"]
    rows = []
    proofs = sorted(
        resolved["proofs"].items(), key=lambda item: int(item[1]["intent"]["record"]["clock"])
    )
    for final_id, proof in proofs:
        intent = proof["intent"]
        authorization = intent["owner"]
        terms = authorization["body"]
        record = intent["record"]
        verify(owner, authorization, "terminal-peace-ordered-input/v1", terms)
        require(
            terms["bootstrap"] == bootstrap_id
            and terms["epoch"] == epoch
            and terms["request"]["parent"] == current["head"]
            and terms["native"] == digest(record),
            f"original authorization: {final_id}",
        )
        incoming = terms["incoming"]
        request = terms["request"]

        def candidate_point(auth, original_request):
            transport = {key: auth[key] for key in ("kind", "body")}
            head = digest(
                [
                    original_request["parent"],
                    original_request["id"],
                    original_request["event"],
                    record,
                    transport,
                ]
            )
            return {
                "epoch": epoch,
                "intent": digest([auth, record]),
                "parent": current,
                "next": dict(record, head=head),
            }

        point = candidate_point(authorization, request)
        for disposition in intent.get("rounds", []):
            for name, seal in disposition["no_decision"].items():
                verify(outgoing[name], seal, "terminal-peace-no-outgoing-decision/v1", point)
            for name, seal in disposition["no_ready"].items():
                verify(incoming[name], seal, "terminal-peace-no-incoming-replay/v1", point)
            old, new = set(outgoing), set(incoming)
            no_decision, no_ready = set(disposition["no_decision"]), set(disposition["no_ready"])
            for triple in itertools.combinations(sorted(old), 3):
                forced = (set(triple) & no_decision) | (new & no_ready)
                require(
                    len(forced & old) > 1 or len(forced & new) > 1,
                    f"unjustified exclusion: {final_id}",
                )
            counts["exclusions"] += 1
            order = disposition["order"]
            body = order["body"]
            require(
                body["bootstrap"] == bootstrap_id
                and body["epoch"] == epoch
                and body["parent"] == current["head"]
                and body["target"] == point["next"]["head"],
                f"disposition binding: {final_id}",
            )
            verify(owner, order, "terminal-peace-resolve-original-handoff/v1", body)
            incoming = body["incoming"]
            request = dict(op="submit", parent=current["head"], id=body["id"], event="due")
            point = candidate_point(order, request)

        require(request["id"] == final_id, f"final request identifier: {final_id}")
        require(
            len(proof["votes"]) >= 3 and set(proof["votes"]) <= set(outgoing),
            f"outgoing quorum: {final_id}",
        )
        for name, vote in proof["votes"].items():
            verify(outgoing[name], vote, "terminal-peace-outgoing-decision/v1", point)
        if incoming:
            require(set(proof["ready"]) == set(incoming), f"incoming replay set: {final_id}")
            for name, replay in proof["ready"].items():
                verify(incoming[name], replay, "terminal-peace-incoming-replay/v1", point)
        else:
            require(not proof["ready"], f"unexpected incoming replay: {final_id}")
        require(
            int(record["clock"]) == int(current["clock"]) + 1
            and record["address"] == current["address"]
            and record["remaining"] == "0",
            f"clock and debt continuity: {final_id}",
        )
        current = point["next"]
        counts["certified_rows"] += 1
        if incoming:
            outgoing = incoming
            epoch = current["head"]
        rows.append(
            dict(
                clock=record["clock"],
                id=final_id,
                roster="".join(sorted(outgoing)),
                votes="".join(sorted(proof["votes"])),
                ready="".join(sorted(proof["ready"])),
            )
        )

    require(
        current == resolved["current"] and set(outgoing) == set(resolved["active_members"]),
        "clock-28 final head and roster",
    )
    source_hashes = {}
    if homework is not None:
        for revision, filename, expected in SOURCE_BLOBS:
            blob = subprocess.check_output(
                ["git", "-C", str(homework), "show", revision + ":" + RECOVERY + filename]
            )
            actual = hashlib.sha256(blob).hexdigest()
            require(actual == expected, f"fixed source SHA: {filename}")
            source_hashes[filename] = dict(revision=revision, sha256=actual)
    else:
        for revision, filename, expected in SOURCE_BLOBS:
            source_hashes[filename] = dict(revision=revision, receipt_recorded_sha256=expected)
    require(
        recovery["kernel"]["source_sha256"] == SOURCE_BLOBS[0][2]
        and resolved["kernel"]["prior_quorum_source_sha256"] == SOURCE_BLOBS[0][2]
        and resolved["kernel"]["source_sha256"] == SOURCE_BLOBS[1][2],
        "receipt-to-source binding",
    )
    require(counts == {"signatures": 95, "certified_rows": 8, "exclusions": 3}, "coverage counts")
    return dict(
        result="PASS",
        checks=counts,
        rows=rows,
        receipt_sha256=RECEIPTS,
        source_hashes=source_hashes,
        scope=(
            "Offline frozen receipts, public-key signatures, original parent chain, "
            "and exact exclusion enumeration. No live node calls or Lean rebuild."
        ),
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--homework", type=Path, default=None)
    parser.add_argument("--evidence-root", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(check(args.homework, args.evidence_root), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
