# 阅读版与可编辑源码包

从 publish 根目录运行。本构建器只读取本稿和共用排版资源，只写本稿 `build/`。Markdown 是正文与附录的可编辑事实源，SVG 与绘图程序是图件编辑源。

## 构建命令

```sh
python3 papers/enforceable-peace/scripts/build_reading.py
```

默认生成四份阅读版：

- `build/enforceable-peace.pdf`
- `build/enforceable-peace-en.pdf`
- `build/enforceable-peace-supplement.pdf`
- `build/enforceable-peace-supplement-en.pdf`

分别构建：

```sh
python3 papers/enforceable-peace/scripts/build_reading.py --language zh --part main
python3 papers/enforceable-peace/scripts/build_reading.py --language en --part supplement
```

`--figures` 先重建六份双语矢量图。正文定稿后的完整重建应包括所有受影响语言与附录。

## 源文件

中文正文为 `manuscript.md`，英文为 `manuscript-en.md`。技术附录按顺序组合以下源，不改动它们的内容：

1. `technical-appendix.md` / `technical-appendix-en.md`
2. `appendix-execution.md` / `appendix-execution-en.md`

合成输入保存在 `build/input/`，原文件仍独立可编辑。每次构建记录原文件及最终 PDF 的 SHA-256；若构建中源文件发生变化，程序要求重新构建。书目从本稿 `references.bib` 读取，Pandoc citeproc 使用 `scripts/numbered.csl` 将 `[@Key]` 按首次引用次序排为编号，并在正文 `#refs` 容器中生成文献表。

## 环境

正文沿用仓内 `shared/scripts/build_pdf.py`、`byline.py` 与 `shared/styles/`。需要 Python 3、pandoc、XeLaTeX 及 xeCJK/unicode-math 等既有排版包。Noto Serif/Sans CJK SC 位于 `~/Library/Fonts` 或 `/Library/Fonts`。正文拉丁字体来自 TeX Live。图件需要 Chrome、fontTools、PyMuPDF 和本机 Noto Serif CJK SC / STIX Two 字体；本机图件解释器为 `~/.venvs/figtools/bin/python`。

图 1、图 2、图 3 在正文分别引用 `figures/01-war-and-ceasefire.pdf`、`figures/02-debt-and-revision.pdf`、`figures/03-certified-history.pdf`；英文引用同名 `-en.pdf`。所有图均为矢量 PDF，可选择文字。

## 成品复查

每份成品的构建报告在 `build/build-report-*.json`。逐页查看图注、表格换行、公式、章节标题和书目，并核对 `missing_characters` 与 `overfull_boxes`。用 Poppler 渲染阅读版：

```sh
mkdir -p papers/enforceable-peace/build/pdf-review
pdftoppm -r 120 -png papers/enforceable-peace/build/enforceable-peace.pdf \
  papers/enforceable-peace/build/pdf-review/page
```

PDF 目视复查与科学来源核查分别记录。

## 打包

```sh
python3 papers/enforceable-peace/scripts/package_editable.py
```

输出 `build/enforceable-peace-editable.zip`，包含中英正文、两组技术附录、图件编辑源与矢量 PDF、构建脚本、所需共用排版依赖，以及四份阅读 PDF。根 `manifest.json` 逐文件记录 SHA-256，打包完成后逐字节核对归档内容。包内目录保留 `papers/enforceable-peace/` 与 `shared/` 的相对关系，解包后从包根运行同一个构建命令。原研究仓与四节点原始回执依论文固定来源定位。

本稿根级 `public-source-binding.json` 随包保存；外部成品清单 `release-artifacts.json` 记录 ZIP 本身的 SHA-256，因此不放入 ZIP，以免形成自引用。包内 `manifest.json` 负责归档各文件的完整性。

`--source-only` 仅用于明确需要纯源码包时；完整交付用默认命令。
