# 附录 I　认证历史、换届与失联处置

## I.1　认证对象与责任约束

设 \(P\) 是账头的类型，\(M\) 是验证者身份的类型。每个账头 \(p\in P\) 从其已经认证的历史取得四人名册 \(O(p)\subset M\)，在每个父账头构成 \(n=3f+1=4\ (f=1)\)、法定人数 \(2f+1=3\) 的防双签与防违封交集几何。一个后继 \(q\) 包含原请求号、字面输入、该次实际支付、执行后的读数与下一届名册。签认始终绑定同一个父账头 \(p\) 和候选后继 \(q\)。

记 \(V(m,p,q)\) 为成员 \(m\) 对这次后继的持久表决，\(R(m,p,q)\) 为其从原源复演同一次支付的签认。认证关系定义为

\[
\begin{aligned}
\operatorname{Cert}(p,q)\Longleftrightarrow{} &
\left[\exists Q\subseteq O(p),\ |Q|\ge3,\
\forall m\in Q,\ V(m,p,q)\right]\\
&{}\land\left[O(q)\ne O(p)\Rightarrow
\forall m\in O(q),\ R(m,p,q)\right].
\end{aligned}
\tag{I.1}
\]

每次换届都由旧届的三人表决和新届全员的同次复演连接。名单本身由这条边取得效力，下一拍即以新名单核验。

普通认证使用如下持久签认约束：对每个父账头 \(p\)，至多一名成员属于故障集 \(B_p\)，且其余成员不能对两个不同后继同时表决。故障集可以随父账头改变。允许撤回和改派时，约束改为：守约成员若签过两个不同候选，则其中至少一个候选已经获得有效排除。后文从角色封印推出排除可靠性，再证明这个较宽约束仍保持历史唯一。

## I.2　三签交集与任意次换届

**引理 I.1（守约交集）。** 设 \(|O|=4\)、\(|B|\le1\)，且 \(W,U\subseteq O\) 满足 \(|W|,|U|\ge3\)。则 \(W\cap U\) 中至少有一名不属于 \(B\) 的成员。

**证明。** 因为 \(W\cup U\subseteq O\)，

\[
|W\cap U|
=|W|+|U|-|W\cup U|
\ge3+3-4=2.
\]

至多一名故障成员不能占满这个交集。取交集中一名守约成员即可。证毕。

**定理 I.2（认证历史的唯一前缀序）。** 若每个父账头均满足引理 I.1 的四人、单故障与持久签认条件，则：

1. 同一父账头的任意两个认证后继相等；
2. 任意两条同根有限认证历史互为前缀；
3. 任意两条同根无限认证续行在每个写入序位相等。

相邻两届的名册可以完全不相交。

**证明。** 两条认证边各给出旧届的三签集合。引理 I.1 找到同时签过两边的守约成员，其持久签认约束迫使后继相等。这证明第一项。对有限历史作长度归纳：空历史是任意历史的前缀；两条非空历史的首个后继相同，再在该后继应用归纳假设。对无限历史从共同根开始，反复使用后继唯一性，得到任意序位相等。每一步只使用当前父账头自己的名册，因此无须假设前后两届相交。证毕。

三份新鲜读回与已持久保存写入的三人集合也适用引理 I.1。两份读回没有同样保证：取 \(O=\{0,1,2,3\}\)，持久写入者为 \(\{0,1,2\}\)，读回者为 \(\{2,3\}\)，唯一故障者为 \(2\)。两集合仅在故障者处相交。这是冷恢复采用三读门槛的精确反例。

## I.3　半途失联的成案充要条件

固定同一父账头、同一届次与同一交接候选。令 \(O\) 为旧届，\(N\) 为拟新届。两者各有四名成员。令 \(D\subseteq O\) 记录旧届的**未表决封印**，\(S\subseteq N\) 记录新届的**未复演封印**。一个封印承担两件持久责任：此前没有签认该角色，此后也不再签认该角色。

给定旧届三人组 \(Q\subseteq O\)，定义

\[
F(Q)=(Q\cap D)\cup(N\cap S).
\tag{I.2}
\]

称有限集二元组 \((B,C)\) 为当前封印 \((D,S)\) 下的**相容完成组合**，若旧届决定集 \(C\subseteq O\) 满足 \(|C|\ge3\)，故障集 \(B\) 满足两届预算 \(|B\cap O|\le1\)、\(|B\cap N|\le1\)，且 \((C\cap D)\cup(N\cap S)\subseteq B\)。若 \(Q\) 的表决和新届全员复演能够共同组成证书，则 \(Q\cap D\) 中的成员同时表决和封印，\(N\cap S\) 中的成员同时复演和封印；这些身份必须计入故障集。重叠身份在集合并中只计一次，两届分别检查自己的故障预算。

**定理 I.3（精确成案判据）。** 在 \((D,S)\) 下存在满足两届各至多一名故障条件的相容完成组合 \((B,C)\)，当且仅当

\[
\exists Q\subseteq O,\quad |Q|=3,\qquad
|F(Q)\cap O|\le1,\qquad |F(Q)\cap N|\le1.
\tag{I.3}
\]

当 \(|O|=4\) 时，只需检查四组三人集合。

**证明。** 若式（I.3）成立，取故障集恰为 \(F(Q)\)。旧届三人 \(Q\) 提供表决，新届 \(N\) 提供复演；所有与封印相冲突的身份均已在该故障集中，两届预算都满足。因此得到与证据相容的一组成案角色。

反过来，设有相容的故障集 \(B\) 和旧届签认集 \(C\subseteq O\)，其中 \(|C|\ge3\)，并且 \(|B\cap O|,|B\cap N|\le1\)。从 \(C\) 中取三人子集 \(Q\)。凡属于 \(Q\cap D\) 或 \(N\cap S\) 的身份均必属于 \(B\)，故 \(F(Q)\subseteq B\)。与两届相交后，基数仍各不超过一，得到式（I.3）。证毕。

这里的相容性具体回答：当前证据是否仍允许原候选取得完整认证。执行直接返回见证 \(Q,N,F(Q)\)，使尚缺什么保持具名。四组均不满足式（I.3）时，证据才排除原候选。

**推论 I.4（已认证者不可被有效排除）。** 若原候选已经取得认证，且签认与封印的冲突身份遵守两届故障预算，则它始终满足式（I.3）。

**证明。** 取原证书的实际旧届签认集与实际故障集。任何签认与封印的矛盾均落在该故障集中，定理 I.3 的反向证明即给出相容三人组。证毕。

**推论 I.5（三封印的排除与两封印的反例）。** 四人旧届的三份未表决封印足以排除原交接。两份这样的封印仍可能相容。

**证明。** 任意旧届三人表决组与三人封印组至少相交两名；于是 \(F(Q)\cap O\) 至少有两名，超过旧届故障预算。反例取

\[
O=N=\{0,1,2,3\},\quad D=\{0,1\},\quad S=\varnothing,\quad Q=\{0,2,3\}.
\]

此时 \(F(Q)=\{0\}\)，两届的故障数都只有一，式（I.3）成立。证毕。

这个反例说明两份旧届封印不能独自承担普遍排除规则。具体候选仍应把旧届和新届全部可用角色封印代入式（I.3）。

## I.4　先检查最大可取证集合

封印会永久关闭相应角色的签认能力，因此其发出顺序本身属于执行。

设当前响应者最多能给出封印集合 \(D_{\max},S_{\max}\)。若原候选在这个最大集合下仍满足式（I.3），则它在任何 \(D\subseteq D_{\max}\)、\(S\subseteq S_{\max}\) 下都仍相容。理由是对同一个见证三人组，

\[
(Q\cap D)\cup(N\cap S)
\subseteq
(Q\cap D_{\max})\cup(N\cap S_{\max}),
\]

故两个基数约束只会变弱。执行据此在发送不可撤销封印之前停止，返回具名缺口，保留按原请求号补成原证书的通路。

有序交接先在旧届至少三节点持久保留原意图，再取得新届四份复演，旧届表决必须消费这四份证据。

**推论 I.6（复演未齐时的无死锁排除）。** 设 \(|O|=4\)，\(D\subseteq O\)，且协议满足“旧届成员投出决定票蕴含新届全员复演已完成”。若交接在新届全员复演完成之前中断，则即便拟新届四人全部失联（无任何新届响应），只要存在至少三名可达旧届成员 \(R_{\mathrm{out}}\subseteq O\)（\(|R_{\mathrm{out}}|\ge3\)）各自返回已投决定票或未表决封印 \(D\)，原交接即必然违反式（I.3）而获得合法排除。

**证明。** 对任意 \(m\in R_{\mathrm{out}}\)，其响应必为已投决定票或 \(m\in D\)；因新届全员复演尚未完成，由协议前提知已投决定票不可能成立，故 \(R_{\mathrm{out}}\subseteq D\)，从而 \(|D|\ge|R_{\mathrm{out}}|\ge3\)。直接应用推论 I.5 即得排除。证毕。

运行由此分为三种结果：

| 已取得的证据 | 实际后继 |
| --- | --- |
| 原证书齐备 | 完成原请求号，读回同一次原支付 |
| 尚有相容组合 | 返回三人组、必需故障身份及缺证位置，保留原签认通路 |
| 四组均被排除 | 凭原调用者授权，在同一父账头提交一笔实际到期付款，写入撤回或改派及全部排除证据 |

反复改派时，每个已排除候选的请求号、候选账头、原授权和拟交接名单都随最终实付行保存。原请求号以后读回它自己的处置和实际后继。

## I.5　允许有效排除后的历史唯一性

记 \(E(p,q)\) 为候选 \(q\) 在父账头 \(p\) 获得有效排除。假定：

\[
\operatorname{Cert}(p,q)\Rightarrow\neg E(p,q),
\tag{I.4}
\]

且每个父账头的四人名单至多有一名成员违背如下签认约束：

\[
V(m,p,q_1)\land V(m,p,q_2)
\Rightarrow
q_1=q_2\ \lor\ E(p,q_1)\ \lor\ E(p,q_2).
\tag{I.5}
\]

式（I.4）由推论 I.4 提供。式（I.5）由节点在持久事务中核验候选的排除链来执行。

**定理 I.7（任意处置保持同根历史）。** 在上述条件下，任意两条同根有限认证历史互为前缀，任意两条同根无限认证续行逐拍相等；结论覆盖任意次数的换届、撤回及改派。

**证明。** 定义保留票

\[
V^\circ(m,p,q):=V(m,p,q)\land\neg E(p,q).
\]

由式（I.4），任何原认证边的所有票都成为保留票，原认证历史仍然成立。一个守约成员若对 \(q_1,q_2\) 都有保留票，式（I.5）的后两项分别与保留条件矛盾，故 \(q_1=q_2\)。因此保留票满足定理 I.2 的持久唯一签认条件。应用该定理即得有限前缀可比与无限逐拍一致。证毕。

证明保留已经认证的每一条边，并只释放确已排除的候选。一次撤回使验证者能够继续承担原父账头的实际支付，同时不改变任何既成历史。

## I.6　六单位原账的认证运行

三份冻结回执连续消费同一原源 `terminal-peace/original-six`。以下各实付后继的原债地址均为 \((2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))\)，追偿余额均为零。这里的时钟是原实际支付生成的时钟；请求号和访问游标另行保存。

| 原钟 | 已记录的原执行 | 完成后的名册 |
| --- | --- | --- |
| 12 | 四机准入前的共同原账头 | \(abcd\) |
| 13 | 三票等待后补齐四份原生复演，完成首笔准入 | \(abcd\) |
| 14 | 三节点签认下一次实际续付 | \(abcd\) |
| 15 | 回归节点复演精确原前缀后签认 | \(abcd\) |
| 16 | 正式独立安装入口实付；原调用者与四节点封存该前缀 | \(abcd\) |
| 17 | 主账及本地意图丢失后，按原请求号补成原支付；两份新鲜读回曾具名缺 \(b,c\) | \(abcd\) |
| 18 | 实付交接 \(abcd\to abce\)；缺 \(e\) 时停在新届复演阶段，补齐后完成 | \(abce\) |
| 19 | 主账回滚至钟 16 后，按认证历史重建最新原账 | \(abce\) |
| 20 | 正式入口实付；仅 \(b,c,e\) 三台远端重建原账头与原请求号 | \(abce\) |
| 21 | 实付启用先复演、后表决的有序交接入口 | \(abce\) |
| 22 | 从远端封印冷恢复原撤回；迟到复演无法越过旧届封印 | \(abce\) |
| 23 | 原交接被排除后实付改派，完成 \(abce\to abcf\) | \(abcf\) |
| 24 | 第三张实际表决恢复，按已经选定的原请求号完成 \(abcf\to abcg\) | \(abcg\) |
| 25 | \(b,c,g\) 三份旧届封印排除只存一票的候选；该表决者核验排除后签认实付撤回 | \(abcg\) |
| 26 | 正式入口实付续行，由三台远端恢复当前届原账 | \(abcg\) |
| 27 | 两份实存表决尚有相容组合，保留原通路，按原请求号补成交接 \(abcg\to abcf\) | \(abcf\) |
| 28 | 继续实付下一拍，三台远端读回同一末账头 | \(abcf\) |

钟 21–28 的实际认证行如下。空的新届栏表示该次支付沿用当前名单。钟 24 的旧届证据恰为三票，其他记录保存了当时已收到的四票。

| 原钟 | 实际请求号 | 旧届表决 | 新届复演 |
| --- | --- | --- | --- |
| 21 | `ordered-protocol-21` | \(a,b,c,e\) | — |
| 22 | `withdraw-f-22` | \(a,b,c,e\) | — |
| 23 | `reassign-to-f-23` | \(a,b,c,e\) | \(a,b,c,f\) |
| 24 | `hidden-selected-g-24` | \(a,b,c\) | \(a,b,c,g\) |
| 25 | `recovered-capacity-25` | \(a,b,c,g\) | — |
| 26 | `ordered-peace-continues-26` | \(a,b,c,g\) | — |
| 27 | `two-outgoing-live-27` | \(a,b,c,g\) | \(a,b,c,f\) |
| 28 | `guarded-ordinary-28` | \(a,b,c,f\) | — |

换届的三种门槛各有作用。第一次四机准入及初始封存取得四份签认；此后的普通写入与当前届新鲜读回取得至少三份。交接证书取得旧届至少三份表决与拟新届四份复演，正常提交还在两届各至少三个节点持久保存完整证书。原钟 18 的新身份 \(e\) 使用退役身份 \(d\) 的原宿主及独立新钥，因此四物理节点与逻辑身份更替分别记账。完全不相交的 \(abcd\to efgh\) 名单交接由独立本机回归消费同一合同。

## I.7　命题、证明与直接验收对应

本附录把定理、进程回归和物理节点运行分别绑定。Lean 定理量化任意身份、账头及合格认证历史；本机回归分别检验确定性原生接口或实际 Lean 入口的故障时序；四机回执保存上述同一六单位源的原执行。

下表使用 \(D\) = `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Deployment/`，\(P\) = `Lean/scripts/terminal_peace_replication/`。

| PE | 固定 Homework 版本 | 原生产声明或执行入口 | 直接消费者、反例和验收 |
| --- | --- | --- | --- |
| PE27 | `3a90cba5ac7427737ee2fe630612dfed43e45da1`，原增量 `c882831f9a` | `terminal_peace_anchor.py`、`terminal_peace_submit.py`、`terminal_peace_worker.py` | `terminal-peace-admission-check.py`；四机 `acceptance.json`，钟 12–16、缺票保留原意图及四节点旧父头拒绝 |
| PE28 | `b5b9c5f86cab0bb212e306ab89db4bf5b177a177` | \(P\)`replica.py::Replica.prepare/status/store`，`quorum.py::Quorum.latest`，`operator.py::Primary.recover/install` | `terminal-peace-replication-check.py` 的失账、旧挑战、原 ID、回滚与部分归档；四机 `recovery-acceptance.json` |
| PE29 | 同 PE28 | \(P\)`protocol.py::Timeline.candidate/verify_votes/apply`，`Quorum.choose/store` | 同一原生 `due` 及钟 18 交接；本机 \(abcd\to efgh\) 消费者 |
| PE30 | 同 PE28 | \(D\)[`Recovery/Quorum.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/Rb5b9c5f8/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Deployment/Recovery/Quorum.lean)：`honest_overlap`、`unique_successor`、`original_histories_are_prefix_comparable`、`cofinal_histories_agree` | `two_reads_can_miss_an_honest_durable_verifier`；冷恢复与换届的三签合同 |
| PE31 | `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0` | \(D\)[`Recovery/HandoffDisposition.lean`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/Rcf880bb2/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Deployment/Recovery/HandoffDisposition.lean)：`possible_iff_completion`、`possible_with_maximal_seals`、`selected_stays_possible`、`three_outgoing_seals_exclude` | `two_outgoing_seals_can_leave_a_completion`、`interrupted_before_decision_can_be_disposed`；\(P\)`rounds.py::possible_completion`、`Quorum.resolve` |
| PE32 | 同 PE31 | 同文件的 `dispositions_preserve_original_prefix_order`、`dispositions_preserve_every_cofinal_cut` | \(P\)`Timeline.exclusion/resolved/apply`、`Replica.stage/ready/seal/prepare`、`Primary.resolve/recover/read_result` |
| PE33 | 同 PE31 | 上述原执行及 `terminal_peace_online.py` 入口 | `terminal-peace-handoff-resolution-check.py` 的重复改派、迟到复演、隐蔽已选及双票保留；四机 `handoff-resolution-acceptance.json`，钟 21–28 |

三份冻结回执的公开链接和原 SHA-256 如下。

| 回执 | SHA-256 |
| --- | --- |
| [`acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rc882831f/living-law/terminal-peace/original-six/acceptance.json) | `c087bd309a4e92b62ac3d88a17ec219c710e9fee929532a8a861dca26a6d968d` |
| [`recovery-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rb5b9c5f8/living-law/terminal-peace/original-six/recovery-acceptance.json) | `26522f53e07161b9bd8504c609292295168b90f6ba7927ad77c2e22cbc2847ad` |
| [`handoff-resolution-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rcf880bb2/living-law/terminal-peace/original-six/handoff-resolution-acceptance.json) | `7fe676f6d8dd085b959c92aa5ca151b7e2a9478378306a80a44d82924733c56b` |

后一回执逐次保存前一回执的摘要。原内核验收对五个普通恢复声明和八个处置声明记录的公理均为 `propext`、`Classical.choice`、`Quot.sound`。回执记录的 `Quorum.lean` 与 `HandoffDisposition.lean` 原始源码 SHA-256 分别为 `09dc0782ab9361c0be28f1b1fd83ab07bf6df3773dbe80a17485c3044a2f3e34` 和 `7d3ba9fbd16aa63c3ce3003ae5cf4132f76380835dd84cfe26dcb4bce83ebfee`（公开选集中的 `HandoffDisposition.lean` 仅改写首行版本化 `import`，由 `python3 tools/enforceable_peace.py source` 逐字节恢复原始摘要）。

离线验收逐枚检验初次准入、封存、钟 18 交接以及钟 21–28 的 95 枚公钥签名，重算八个新增账头，核对逐行父头、原债地址、零余额与时钟连续性，并对三处处置分别枚举四组旧届三签。物理节点运行的身份由三份原回执固定。

Lean 从原认证账本逐笔复演至钟 28。[公开映射](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) · [原认证账本](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/certified-journal.json) · [复演入口](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md)
