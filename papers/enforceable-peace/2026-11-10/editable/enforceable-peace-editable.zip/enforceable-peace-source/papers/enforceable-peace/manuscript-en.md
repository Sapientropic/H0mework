# War and Peace: A Source-Generated Terminal Theorem

**Author: Jian Gao**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

This paper proves constructive completeness of peace for open social worlds, establishing impossibility theorems and exact characterisations across five institutional boundaries. In the responsibility-reattachment comparison, conflict destroys material. The initiator gains when the shifted liability exceeds the destruction they bear. Once spendable capacity falls below the least eliminating rate, no ex post liability rate deters war (judgment-proof obstruction), while under incomplete observation a single prior policy's optimal guarantee equals the infimum of local observation-fibre suprema and is attained iff every binding fibre attains it. Under the old single-signature compiler erasing cross-community consent, unilateral return credits nothing whereas a cross-community receipt opens an equal reverse debt at the position it clears, keeping total unpaid reparation non-decreasing; the damage guard forwards exactly the lawful zero-damage requests as the widest safe admission. Without priority scheduling, zero-material stop inputs stall a lodged withdrawal forever within bounded time; priority yields sharp completion and anti-filibuster hourly progress bounds, and crossing an emergency hard deadline bars grants across all suffixes. For arbitrary participants, goods, technologies, and admitted histories, sustainable joint settlement holds iff the viable clearing domain is nonempty, attaining minimum visits. Verified post-settlement stock directly opens open-syntax peaceful continuation: zero-debit policy proposals can strip personal exits under an unchanged old quote word and evade any given finite adaptive duration query tree via out-of-sample alteration—ruling out static and finite-sample classifiers; dynamic prepaid verification triggers minimal semantic extensions that strictly shrink unsealed vulnerabilities, preserve every native word, impose strict net losses on overreaching or proxy probes, and erase zero-fee probes. Pending signatures, shortages, and delayed evidence are handled by paid due continuation, width-complete recipe search, and receipt transport.

At the execution layer, safe stock-identical permuted replays refute snapshot criteria, and each parent head uses \(3f+1=4\ (f=1)\) quorum intersection, certifying handovers by three outgoing votes and four incoming source replays. Role-seal fault budgets pre-check maximal obtainable evidence first, and before replay completes, three honest outgoing seals dispose of stalled attempts without deadlock even if `0/4` nominees respond. Under reliable exclusion and exclusion-gated vote changes, arbitrarily many handovers, withdrawals, and reassignments keep finite certified histories prefix-comparable and infinite continuations identical at every index across possibly disjoint rosters; the same six-unit ledger runs continuously through productive settlement, two language revisions, deployed staging, cold recovery, and four-host handovers from clock 12 to clock 28.

**Keywords:** war and commitment; responsibility reattachment; unilateral impossibility; joint settlement; stealth institutional capture; anti-fragile revision; Byzantine handover

## 1 Peace must begin with its past

A war can diminish society's total stock and still reward its initiator. The initiator gains when the liability shifted onto others exceeds the destruction they bear. In the three-party native benchmark isolating external shifting, peaceful execution leaves stocks at \((4,7,10)\), a social total of 21; initiating conflict drops the social total to 19 (net destruction of 2 units), yet shifting 6 units of liability raises the initiator's own stock to \((8,7,4)\), creating a net private advantage of \(+4=-2+6\); reattaching all 6 units along the recorded third-party advance claim (the original financial slot) conserves the post-war social total at 19 while moving stocks to \((2,7,10)\), placing the entire 2-unit destruction back on the initiator and reversing the net margin from \(+4\) through \(0\) to \(-2\). In the main two-community productive-settlement ledger carrying the same 6-unit cross-community loss, an approved new production rule raises the payer's stock of settlement material from 113 to 117; six units are delivered with both parties' signatures at the same position, and peace begins with 111.

111 is less than 113. That difference carries the central question of this paper: once compensation actually takes place rather than remaining a paper transfer, how can a society continue to live on its diminished remaining stock and prevent renewed appropriation? Production recipes change, the institutional language protecting members expands, and every verifier holding the ledger may be replaced. What makes past responsibilities remain identifiable from the same source throughout?

We construct this causal chain and simultaneously prove the converse impossibility theorems across five institutional boundaries: (i) **judgment-proof obstruction**: when spendable capacity lies below the minimum war-eliminating rate, no ex post reparation rate can deter conflict; (ii) **double unilateral deadlock**: without independent two-party acceptance at the same position, unilateral return leaves old debt intact while cross-community unilateral receipts open equal reverse debts, preventing total liability from ever falling; (iii) **pocket-veto and soft-expiry failure**: without priority scheduling, zero-material procedural inputs stall a lodged withdrawal forever within a bounded clock interval; (iv) **blindness of static codes**: zero-debit rule proposals can strip an individual's independent exit under an unchanged old quote word and evade any given finite adaptive duration query tree via out-of-sample alteration, ruling out static and finite-sample classifiers; and (v) **snapshot and timeout ambiguity**: a safe replay with identical stocks and clocks at every visit can permute performance order, while two reads or two seals admit single-fault counterexamples. “Terminal” in the title means that original reparation receives a complete disposition within the same actual history; every action thereafter still obtains its own resources, authority, and successor from the actual resulting state.

### 1.1 The objects of study, introduced through a payment

Participants hold stocks measured in their own units, such as grain, fuel, and labour inputs; technology specifies what an action sequence actually consumes and produces; institutional law specifies who may propose, approve, perform, and refuse that sequence. Each execution leaves the prior state, the actual operation, the resulting state, the visit ordinal, and the physical clock. History joins these operations in the actual order in which they occur.

**Source-generated** means that institutional objects obtain their warrant from the same actual execution: a loss is opened at the cross-community debit where it occurs, settlement is credited at actual delivery at that position, a language revision acquires its new refusal direction from effects whose review fee has already been debited, and the next step reads the actual resulting state just produced. An original debt address binds the filing visit, the material-item index, the victim, the payer, and the good; subsequent registration updates, instalments, and rule revisions retain this address.

**Independent exit** means that every registered member possesses an action sequence exercisable in person, with its costs supported, that remains executable after leaving the current relation of control. Admission of joint production verifies this condition member by member. **Sustainable operation** further requires the physical clock to pass every finite bound; an execution that compresses infinitely many steps into a bounded time interval does not qualify as sustained peace.

### 1.2 Constructive completeness of peace for open social worlds

Let \(x\) be an admissible historical cut after an actual appropriation, fixing its execution law, original debts, acceptance channels, and institutional registration. Let \(\mathcal S(x)\) denote the set of finite action prefixes from \(x\) that pass the original execution checks, jointly clear every original row, and leave an opening for continued operation with actual payments, independent exits, and a cofinal clock; §4 gives the complete definition.

**Theorem 1 (Constructive completeness of peace).** For any such source and its participants, material goods, and technologies, the following hold.

1. **Exact completion of settlement and unilateral obstruction.** The original execution generates successors for actual production revisions and settlement submissions, retaining the specific refusal ground and original responsibilities upon rejection; the damage guard forwards exactly the originally lawful requests with zero new cross-community damage, forming the widest safe admission rule. Under the old single-signature receipt rule without independent two-party acceptance at the same position, total unpaid cross-community reparation never decreases along any continuation. Once two-party acceptance at the original position is installed, joint settlement returns an actual fully paid sustainable execution if and only if \(\mathcal S(x)\ne\varnothing\), attaining the minimum visit count over \(\mathcal S(x)\). When \(\mathcal S(x)=\varnothing\), every viable candidate retains a positive original debt, while remaining candidates retain an original-admission or viability obstruction.
2. **Anti-fragile peace across an arbitrary open future.** From any actual settled resident, if joint production and individual exits on the current stock pass the repeatability checks, an opening for peace is generated directly. For arbitrary proposal syntax varying with public history, clock, public terms, and current language, together with its interpreter and adaptive strategy, and for every round, the generated history preserves zero new appropriation at each executed item, actual production, subsistence and maintenance, individual independent exits, and original responsibility addresses. Paid effects exceed current language coverage if and only if a minimal first language write is generated; each novel exposure strictly shrinks the unsealed vulnerability set, preserves public compilation of every finite native word and productive gains, and hands the resulting state directly to the next step. Every paid review visit incurs a strictly negative material payoff relative to ordinary renewal at the same clock under every strictly positive per-good weight, whereas zero-fee probes erase from the entire infinite trajectory without changing any action-facing information fibre. Whenever each round carries a certified time increment of at least \(\delta>0\), the physical clock satisfies
   \[
   \tau_{n+k}\ge \tau_n+k\delta.
   \tag{1}
   \]
3. **One history through handovers and deadlock-free disposition.** Suppose every parent head has exactly four verifiers, at most one violates its durable signing constraint, valid exclusion never negates an already certified edge, and a constraint-observing member changes its vote between distinct candidates only on the basis of valid exclusion. Then any two finite continuations of the same initial certified history are prefix comparable, and any two infinite continuations agree at every index. Handovers may recur arbitrarily often, and successive rosters may be completely disjoint. Interrupted handovers are adjudicated by the two-roster role-seal budget criterion; under the ordered rule requiring full incoming replay before outgoing voting, if interruption occurs before replay completes, three honest outgoing no-decision seals dispose of the candidate without deadlock even if all four incoming nominees are unreachable.

The five dimensions of completeness map to the sections below:

| Completeness | Positive and converse results proved | Sections |
| --- | --- | --- |
| Representation | Arbitrary participants, goods, and technologies; observation-fibre robust duality and variable proposal syntax enter one execution | §§2, 5 |
| Generation | Double unilateral deadlock and judgment-proof obstruction; viable settlement equivalence, minimum visits, tight period bound, and amount resolution | §§2, 4 |
| Expression | Non-classifiability by old readouts or finite duration queries; paid gap triggers minimal write, shrinks vulnerability, and preserves native words | §§5–6 |
| Responsibility | Original-position conservation, widest safe guard, priority bound vs stall, anti-filibuster hourly step, and irreversible hard expiry | §§2–3, 5–6 |
| History | Compulsory convergence to a unique peace tail, unique write-by-write factorisation, \(3f+1\) uniqueness, and deadlock-free seal disposal | §§5, 7–10 |

### 1.3 Positioning the problem across five intellectual traditions

The source-generated terminal theorem proved here confronts five long-separated classical traditions and closes their structural gaps within one execution kernel.

First, **sovereign coercion and rationalist bargaining over war**. Hobbes held that “Covenants, without the Sword, are but Words,” tying peace to an unreplaced sovereign standing above society [@Hobbes1651, chs. 13, 17]. Modern rationalist war theory asks why mutually costly wars still occur: Fearon traces breakdown to private information and commitment failure without external enforcement; Powell shows that rapid power shifts destroy the credibility of staged concessions; and Jackson and Morelli prove that when a pivotal leader's political bias \(B_j>1\) is sufficiently large, negative-sum war can occur even under complete information, while pre-war appeasement transfers from the victim fail under large bias or lack of commitment [@Fearon1995, pp. 381–382, 401–402; @Powell2006, pp. 183, 188–189; @JacksonMorelli2007, §§I–II]. Dispensing with victim-paid bribes and permanent Leviathans, §2 establishes original-slot liability reattachment and observation-fibre robust duality, §5 resolves power-shift commitment via dynamic reserves and self-locking language revision, and §8 eliminates permanent sovereign offices.

Second, **entitlement protection rules, judgment-proofness, and mathematical accounting**. Calabresi and Melamed distinguish *property rules* (ex ante consent), *liability rules* (ex post court-assessed damages), and *inalienability* boundaries; Shavell shows that once an injurer's assets fall below potential harm, ex post liability loses deterrent force (*judgment-proofness*); and Ellerman formalises double-entry bookkeeping as a Pacioli group of equivalence classes of nonnegative T-account pairs (explicitly avoiding signed scalars), where equal debits and credits quotient to the zero account [@CalabresiMelamed1972; @Shavell1986; @Ellerman2014Accounting]. Building on source-native whole-ledger lineage preservation [@Gao2026WholeLedger], §§2 and 4 prove that on a cross-community conflict ledger, pure ex post liability hits an empty judgment-proof region, single-signer primitives erasing cross-community consent induce a double unilateral deadlock, and T-account group quotienting erases original claim provenance; clearing debt requires welding the ex ante damage guard, same-position dual signing, and constitutional inalienability boundaries.

Third, **self-enforcing constitutional coordination and emergency sunset limits**. Weingast analyses sovereign *divide-and-conquer* selective transgressions and models constitutional stability as a repeated-game citizen coordination equilibrium relying on a shared focal point; Ferejohn and Pasquino recover the neo-Roman dictatorship, separating declaration from exercise under fixed terms so emergency power remains *conservative*—restoring rather than rewriting permanent law [@Weingast1997; @FerejohnPasquino2004]. Yet divergent local observations fracture focal points, costless procedural inputs create pocket vetoes, and soft deadlines invite self-renewal through unfinished business. Without assuming shared focal beliefs, §3 proves an exact observation-fibre ceasefire equivalence, pairs a sharp priority bound against an unprioritised infinite-stall countermodel, establishes anti-coalition refusal invariants blocking selective transgression, and proves irreversible post-deadline expiry across all suffixes.

Fourth, **exit–voice dynamics, incomplete contracts, institutional grammars, and theory revision**. Hirschman examined both the substitution tension between exit and voice and the conditions under which credible exit strengthens voice; Grossman and Hart derived residual control rights from ex ante non-contractibility and third-party unverifiability, whereas Maskin and Tirole showed that when payoff consequences are foreseeable, subgame-perfect ex post message mechanisms can restore optimal outcomes if renegotiation is barred or resisted under strict risk aversion; Crawford and Ostrom formulated static ADICO institutional grammars, and Alchourrón, Gärdenfors, and Makinson (AGM) axiomatised norm change via partial-meet contraction and revision [@Hirschman1970, pp. 3–4, 35–36, 81–82; @GrossmanHart1986; @MaskinTirole1999; @CrawfordOstrom1995, pp. 583–586; @Alchourron1985TheoryChange, §§1–2]. Partitioning interfaces with three companion studies—actual exit and responsibility transport [@Gao2026Society], an economic constitution of revocable public mandates whose expired terms never self-revive [@Gao2026Constitution], and joint ledger conservation across institutional transformation [@Gao2026Capital]—§§5–6 prove dual undecidability of zero-debit stealth capture against static grammars and finite duration sampling, discipline ex post message mechanisms via zero-fee erasure and prepayment privacy, and lock payable exit to prepaid voice under conflict-free monotonic extension.

Fifth, **Byzantine resilience, asynchronous consensus impossibility, and state-machine reconfiguration**. Lamport, Shostak, and Pease established the \(3m+1\) oral-message Byzantine bound alongside signed synchronous protocols; Fischer, Lynch, and Paterson (FLP) proved that in a clockless asynchronous network, a single unannounced crash allows an adversary schedule to keep any deterministic consensus protocol bivalent forever; Malkhi and Reiter's self-verifying dissemination quorums together with Castro and Liskov's PBFT achieve fixed-roster safety against equivocation under signatures via \(n=3f+1\) and \(2f+1\) quorum intersection, whereas Lamport, Malkhi, and Zhou's Vertical Paxos under crash faults delegates configuration transitions and state-transfer activation gating to an external configuration master [@LamportShostakPease1982, §§2, 4; @FischerLynchPaterson1985, pp. 377–379; @MalkhiReiter1998, pp. 204–206; @CastroLiskov1999, §§3–4; @LamportMalkhiZhou2009, §§1–2]. Sections 7–9 refute snapshot state-transfer equivalence, replace external configuration masters at every parent head by three outgoing votes plus four incoming native Lean replays, and use durable role seals, maximal-evidence pre-checks, and replay-before-vote ordering to eliminate unreachable-nominee deadlock without timeout guesswork (dynamic expansion and contraction of roster size itself is treated separately in the companion study on paid membership renewal).

## 2 How appropriation leaves a responsibility that persists

### 2.1 State, original-position conservation, and double unilateral deadlock

Write the current execution state as the seven-tuple
\[
s=(L,\sigma,\mathcal R,Q,\tau,\nu,h).
\tag{2}
\]
Here \(L\) is the operative institutional rule, technological interpretation, and language state; \(\sigma(i,g)\in\mathbb Q\) is participant \(i\)'s stock of material good \(g\); \(\mathcal R\) holds original reparation rows and other responsibility entries; \(Q\) is the original priority pending queue; \(\tau\in\mathbb Q\) is the physical clock; \(\nu=\operatorname{ord}(s)\in\mathbb N\) is the strictly advancing visit ordinal; and \(h\) is the literal history of occurrences. Checking a submitted request for authority, spendable stock, and applicable protections produces either an executed action or a refusal with named grounds; both outcomes consume the current visit ordinal and enter their respective deterministic successors.

“Admitted at the source” means that the entry carries the lawful provenance, registered procedure, actual signed orders, and protective evidence required for this occurrence. Types of participants, goods, ports, technologies, and financial instruments are arbitrary parameters; finite executable checks carry complete address enumerations, whereas universal theorems quantify address by address.

A positive net debit across communities without the affected person's consent immediately opens an original reparation address \(\rho\) indexed by submission ordinal, material-item ordinal, and the triple \((\text{victim},\text{payer},\text{good})\). Write \(d_\rho>0\) for its initial loss, and \(r_\rho(n)\ge0\), \(p_\rho(n)\ge0\) for its remaining balance and cumulative paid credit at step \(n\).

**Theorem 2 (Conservation at the original position and single use of receipts).** For any original appropriation and any admissible actual history from it, the identity
\[
d_\rho=r_\rho(n)+p_\rho(n)
\tag{3}
\]
holds at every original address and after aggregation by material good. A credit can consume only a receipt carrying both the payer's authorisation and the victim's independent acceptance at that actual delivery position; the same receipt can never be credited again at any later visit. Registration updates, instalments, and production revisions preserve all original addresses; if a multi-item submission is rejected because a later item fails, cross-community debits already written still open their original liabilities.

**Proof.** Filing reads cross-community positive net debits already executed, entering each new loss into its own row. Refusal branches and production revisions transport existing rows without reducing balances. Lawful payment checks the literal delivery and both parties' affirmative answers at the same reached stock position; the allocator moves only the authorised quantity from \(r_\rho\) to \(p_\rho\) in original filing order, with total credit at one position bounded by the signed delivery there, preserving (3) at every step. The first component of each receipt's address is the visit ordinal \(\nu_0\) at which it was created; step \(k\ge1\) thereafter has ordinal \(\nu_0+k\ne\nu_0\), so no earlier receipt can pass same-position verification again. Induction along the history completes the proof. \(\square\)

In the main two-community six-unit ledger, the Boolean values \(\mathrm{false}\) and \(\mathrm{true}\) encode the victim (claimant) and payer on the participant coordinate, and the settlement-carrier material and food on the good coordinate; the initial appropriation at visit 2, item 0 opens the address \(\rho_0=(2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))\). That row persists after the victim exits: dual-signed deliveries of two and four units reduce the balance from six through four to zero; financial registration without same-position acceptance credits nothing, and separately booked financial principal of 6 remains untouched when reparation clears. The next theorem proves that under the old single-signer rule erasing cross-community consent, total unpaid cross-community debt can never fall.

**Theorem 3 (Double unilateral deadlock, non-decreasing liability, and the widest safe guard).** Fix any original source cut, community partition, and historical prefix \(h\).

1. **Double unilateral deadlock and monotone non-decreasing liability.** Under the old single-signature receipt rule (where material compilation erases cross-community consent lists), a payer's unilateral return physically transfers the goods without new damage yet credits zero against the claim—on the six-unit ledger, \((\text{victim},\text{payer})\) stocks of settlement material move from \((111,113)\) to \((117,107)\) while \([(\rho_0,6)]\) remains unpaid; conversely, a victim-side cross-community receipt, even with affirmative answers from both parties, clears the old row to \((\rho_0,0)\) only by simultaneously opening an equal reverse cross-community debt \((\rho_{\mathrm{rev}},6)\) at that same material position. In general, for every good \(g\) and continuation script \(u\), total outstanding cross-community reparation satisfies
   \[
   \operatorname{Out}_g(h\mathbin{+\!\!+}u)\ge\operatorname{Out}_g(h).
   \tag{4}
   \]
   On the original six-unit history \(h_0\), every old-rule continuation satisfies \(\operatorname{Out}_{\mathrm{false}}(h_0\mathbin{+\!\!+}u)\ge6\), while retaining the old production law exhausts food and eliminates all individual independent exits after clock 5.
2. **Universal property of the damage guard as the widest safe admission.** Once the cross-community damage guard is installed, it forwards an input request \(req\) if and only if \(req\) is originally lawful and opens zero new cross-community damage at every material position; every admission predicate forwarding only lawful zero-damage requests is contained in this guard.

**Proof.** On the six-unit source, the payer-signed six-unit return debits the signer itself (opening no foreign damage), but the receipt-credit function requires the victim's signature and evaluates to 0, leaving \([(\rho_0,6)]\) untouched; the victim-signed six-unit receipt credits 6 to \(\rho_0\), yet because raw compilation strips cross-community consent, its debit of 6 against the payer at item position 0 files a unique reverse reparation row \(\rho_{\mathrm{rev}}\) of quantity 6 with no reverse receipt, yielding \([(\rho_0,0),(\rho_{\mathrm{rev}},6)]\). Generally, at any material position \(pos\) in \(h\to h\mathbin{+\!\!+}[a]\), assigning positive credit to good \(g\) consumes a cross-community unilateral receipt that opens an equal reverse good-\(g\) loss at \(pos\). Because one item cannot spend the same good twice, total credit assigned to good \(g\) at \(pos\) is at most that receipt's quantity and hence at most the new good-\(g\) loss filed at \(pos\). Summing over distinct positions gives \(\operatorname{Assigned}_g\le\operatorname{Filed}_g\); combined with \(\operatorname{Out}_g(h')+\operatorname{Assigned}_g=\operatorname{Out}_g(h)+\operatorname{Filed}_g\), this yields \(\operatorname{Out}_g(h')\ge\operatorname{Out}_g(h)\) and, by induction, (4). Under old production, advancing one period to clock 5 delivers zero food against unit demand and admits no exit under any control map. Part 2 holds directly because emitted inputs are lawful with zero cross-community damage, and any lawful zero-damage input evaluates to the singleton emitted list. \(\square\)

Theorems 2 and 3 clarify the exact division of labour between mathematical bookkeeping and law-and-economics entitlement rules. Ellerman constructs the Pacioli group from nonnegative T-account pairs to avoid signed scalars, yet quotienting equal debits and credits to the zero account (\([d//d]=[0//0]\)) erases original claim provenance once settled [@Ellerman2014Accounting; @Gao2026WholeLedger]; inequality (4) shows further that single-signer primitives erasing cross-community consent cannot even reach zero—unilateral return \((117,107)\) credits nothing while a unilateral cross-community receipt spawns an equal reverse liability \(\rho_{\mathrm{rev}}\). Against Calabresi and Melamed's taxonomy [@CalabresiMelamed1972], Part 2 characterises ex ante property protection as the universal widest safe damage guard (without freezing lawful exchange), while Part 1 proves that ex post liability settlement itself requires symmetric two-party consent at the delivery position (Theorem 2).

### 2.2 Reattachment threshold, capacity interval, and observation-fibre duality

Comparisons of war incentives must start from the same actual cut: before native registration completes or while an action remains pending, the peace menu has no paid word so war–peace pressure is undefined, and along evolving prefixes the first positive war-margin crossing and peak margin are tracked separately (in the three-party benchmark, native registration at cut 2 triggers the first crossing and simultaneously attains the peak \(+4\)). At a registered cut, reattachment appends a paid return transfer from the original debtor to the bearer of shifted liability, preserving all native financial slots while keeping total stock of every good invariant across every coalition containing both parties. Suppose a conflict candidate has original net advantage \(m\in\mathbb Q\) over peace while shifting responsibility \(T\ge0\). Reattaching at rate \(\lambda\ge0\) gives
\[
\Delta(\lambda)=m-\lambda T.
\tag{5}
\]

**Proposition 4 (Reattachment threshold, capacity interval, and judgment-proof obstruction).** For a single candidate, full reattachment (\(\lambda=1\)) strictly reverses a positive conflict advantage into a peace advantage if and only if
\[
0<m<T.
\tag{6}
\]
For a finite family \(\{(m_i,T_i)\}_{i=1}^k\) (\(T_i\ge0\)), an eliminating rate \(\lambda\in[0,1]\) (\(\forall i,\ \Delta_i(\lambda)\le0\)) exists iff \(\lambda=1\) eliminates all positive margins; infeasibility holds iff some row has unshifted positive gain (\(T_i=0,m_i>0\), giving \(\Delta_i(\lambda)=m_i>0\) for all \(\lambda\in\mathbb Q\)) or insufficient shift (\(0<T_i<m_i\)). When \(\lambda=1\) succeeds, the least nonnegative eliminating rate is
\[
\lambda_*=\max\!\left(\{0\}\cup
 \left\{\frac{m_i}{T_i}:T_i>0\right\}\right)\in[0,1],
\tag{7}
\]
leaving a positive-margin candidate below \(\lambda_*\) and a binding tie at \(\lambda_*>0\); a nonnegative rate \(\lambda\) makes peace strictly preferred throughout (\(\forall i,\ \Delta_i(\lambda)<0\)) iff every \(T_i=0\) row has \(m_i<0\) and every \(T_i>0\) row has \(m_i/T_i<\lambda\) (equivalently \(\lambda>\lambda_*\) when \(\lambda_*>0\)). Moreover, if spendable allowances \(\mathrm{avail}_a\ge0\) against full-reattachment draws \(\mathrm{full}_a\ge0\) define the capacity ceiling \(\lambda_{\mathrm{cap}}=\min_a\min(1,\mathrm{avail}_a/\mathrm{full}_a)\in[0,1]\) (taking \(1\) when \(\mathrm{full}_a=0\)), the payable war-eliminating rates form the exact closed interval
\[
\Lambda_{\mathrm{peace}}=[\lambda_*,\lambda_{\mathrm{cap}}].
\tag{8}
\]
Whenever \(\lambda_{\mathrm{cap}}<\lambda_*\), \(\Lambda_{\mathrm{peace}}=\varnothing\) and a named budget row exhibits a strict shortfall \(\lambda_*\mathrm{full}_a>\mathrm{avail}_a\) blocking every eliminating rate in \([0,1]\) (judgment-proof obstruction); a payable strictly peace-preferring rate exists iff every \(T_i=0\) row has \(m_i<0\), with \(\lambda_*<\lambda_{\mathrm{cap}}\) when \(\lambda_*>0\) and strict negativity at \(\lambda=\lambda_{\mathrm{cap}}\) when \(\lambda_*=0\). When authority varies with amount, literal re-verification intersects with this interval.

**Proof.** Antitonicity of \(\Delta_i(\lambda)\) equates feasibility on \([0,1]\) to \(\lambda=1\); splitting a \(\lambda=1\) violation on \(T_i=0\) versus \(T_i>0\) gives the two obstructions, while taking the finite maximum of \(m_i/T_i\) yields (7), the tie, and the strict negativity criterion. On the capacity side, for \(\lambda\le1\), \(\lambda\,\mathrm{full}_a\le\mathrm{avail}_a\iff\lambda\le\mathrm{avail}_a/\mathrm{full}_a\) when \(\mathrm{full}_a>0\); taking the minimum with \(1\) characterises affordability as \(\lambda\le\lambda_{\mathrm{cap}}\), meeting \(\lambda\ge\lambda_*\) in (8). A shortfall at \(\lambda_*\) worsens for all \(\lambda\ge\lambda_*\), while antitonicity at \(\lambda_{\mathrm{cap}}\) characterises payable strict peace preference. In the three-party benchmark, \(m=4,T=6\), \(\lambda_*=2/3\) is attained, and \(\Delta(0)=4,\Delta(2/3)=0,\Delta(1)=-2\). \(\square\)

Proposition 4 unifies political-bias war incentives with the judgment-proofness boundary [@JacksonMorelli2007, §§I–II; @Shavell1986]. In Jackson and Morelli's model, when a pivotal leader's political bias \(B_j>1\) is sufficiently large, negative-sum war can occur even under complete information, and pre-war victim transfers \(t_{ij}>0\) collapse without commitment; relations (5)–(8) invert the transfer by returning shifted cost \(T\) along the original financial slot to the decision-maker, while isolating the two exact blind spots of ex post billing—unshifted positive war gains (\(T_i=0,m_i>0\)) and Shavellian judgment-proofness (\(\lambda_{\mathrm{cap}}<\lambda_*\implies\Lambda_{\mathrm{peace}}=\varnothing\)). Purely ex post liability cannot cross that gap, necessitating the ex ante guard and enforceable ceasefire of §3.

When conflict and peace menus contain infinitely many candidates whose suprema need not be attained, suppose the four executable menus \(W_0,P_0,W_1,P_1\) before and after reattachment are nonempty and bounded above. Strict conflict dominance before reattachment (\(\sup W_0>\sup P_0\)) together with strict peace dominance afterwards (\(\sup W_1<\sup P_1\)) holds if and only if there exist an executable conflict word in \(W_0\) dominating all of \(P_0\) by a uniform positive margin \(\delta>0\) and an executable peace word in \(P_1\) dominating all of \(W_1\) by a uniform positive margin \(\varepsilon>0\), proved by picking interior points between the separated suprema.

Under incomplete observation, let \(\mathcal W\) be a nonempty set of possible worlds, \(\omega:\mathcal W\to\mathcal O\) an observation map, and \(u:\mathcal W\times\mathcal A\to\mathbb R\) the score. Worlds sharing a visible record \(s\in\operatorname{range}(\omega)\) form one observation fibre \(\omega^{-1}(s)\), on which any single prior policy \(\pi:\mathcal O\to\mathcal A\) must commit to one common signed action. Define the set of locally supported floors on fibre \(s\) by
\[
\mathcal F(s)=\bigl\{b\in\mathbb R:\exists a\in\mathcal A,\ \forall w\in\omega^{-1}(s),\
  a\text{ is executable at }w\text{ and }u(w,a)\ge b\bigr\},
\]
and the set of uniform floors of global prior policies by \(\mathcal P=\{b\in\mathbb R:\exists\pi,\ \forall w\in\mathcal W,\ \pi(\omega(w))\text{ is executable at }w\text{ and }u(w,\pi(\omega(w)))\ge b\}\).

**Theorem 5 (Robust frontier duality and binding-fibre attainment under incomplete observation).** Suppose \(\mathcal P\) is nonempty and \(\mathcal F(s)\) is bounded above for every \(s\in\operatorname{range}(\omega)\). Then the optimal uniform guarantee of a single prior policy equals the infimum of the local observation-fibre suprema:
\[
\sup\mathcal P=\inf_{s\in\operatorname{range}(\omega)}\sup\mathcal F(s).
\tag{9}
\]
Write \(b_*=\sup\mathcal P\) for this common frontier. A prior policy actually attains \(b_*\) (that is, \(b_*\in\mathcal P\)) if and only if every binding observation fibre satisfying \(\sup\mathcal F(s)=b_*\) attains that supremum (\(b_*\in\mathcal F(s)\)).

**Proof.** Choosing actions fibre by fibre shows \(b\in\mathcal P\iff\forall s\in\operatorname{range}(\omega),\ b\in\mathcal F(s)\), so \(\mathcal P=\bigcap_s\mathcal F(s)\). For each \(s\), \(\mathcal P\subseteq\mathcal F(s)\) implies \(\sup\mathcal P\le\sup\mathcal F(s)\); because \(\mathcal W\) is nonempty, \(\operatorname{range}(\omega)\) is nonempty, giving \(\sup\mathcal P\le\inf_s\sup\mathcal F(s)\). If strict inequality held, choose \(c\) with \(\sup\mathcal P<c<\inf_s\sup\mathcal F(s)\). For every \(s\), \(c<\sup\mathcal F(s)\) yields \(b_s\in\mathcal F(s)\) with \(c<b_s\); since each \(\mathcal F(s)\) is downward closed (an action guaranteeing at least \(b_s\) also guarantees at least \(c\)), \(c\in\mathcal F(s)\) for all \(s\), whence \(c\in\mathcal P\), contradicting \(c>\sup\mathcal P\). This proves (9).

For attainment, necessity is immediate from \(\mathcal P\subseteq\mathcal F(s)\). Conversely, assume \(b_*\in\mathcal F(s)\) whenever \(\sup\mathcal F(s)=b_*\). Take any fibre \(s\): we already have \(b_*\le\sup\mathcal F(s)\). If equality holds, \(b_*\in\mathcal F(s)\) by hypothesis; if \(b_*<\sup\mathcal F(s)\), choose \(b_s\in\mathcal F(s)\) with \(b_*<b_s\) and apply downward closure of \(\mathcal F(s)\) to obtain \(b_*\in\mathcal F(s)\) again. Assembling these fibrewise actions defines a prior policy witnessing \(b_*\in\mathcal P\). \(\square\)

Theorem 5 characterises optimal uniform guarantees under private information [@Fearon1995]: pooling indistinguishable worlds into \(\omega^{-1}(s)\) tests a single action against the worst state in that fibre, while non-binding fibres with strict slack need not attain their own suprema for an optimal peaceful policy to exist.

## 3 Making refusal an action that sustains ceasefire

Reducing war payoffs below zero must be paired with strictly bounded self-defence and civilian revocation. Lawful self-defence satisfies five source-generated boundaries simultaneously: the victim holds standing in the local roster, the foreign capture permission is still live (ruling out ex post retaliation against an already closed intrusion), a paid instruction signed in person by a local resident closes that permission (ruling out third-party intervention, with the closed stock port refusing every request charging that address even under a renamed purpose field), the defensive response opens zero reverse cross-community damage, and its literal successor pays every local resident's independent exit floor while retaining the prior financial claim history. Within a community, once emergency war authority is revoked, any subsequent restoration must leave a fresh affirmative record signed by the exposed person.

### 3.1 One strategy against every later response

Given a civilian observation map \(\omega\), histories with identical visible records lie in the same observation fibre. A civilian strategy \(\pi\) selects actions solely from the visible record; the opponent may observe the submitted civilian action before choosing any response permitted by the original execution. Every prefix of the opponent's response, and every intermediate position of the civilian's submitted word, must retain its checked continuation and individual independent exit.

Call a family \(K\) of histories **protectable** if it contains the actual opening and every reachable observation fibre admits one shared executable civilian action whose allowed opponent responses all remain in \(K\), while intermediate positions retain the submitted word's checked continuation and independent exit; members acquiring standing later enter protection at their actual cut. In the **signed constitutional game**—where civilian and opponent alternate signed commands—any tick carrying an unconsented cross-community debit is followed immediately by a ledger publication visit booking that loss.

**Theorem 6 (Sustained civilian ceasefire, complete failure decomposition, and uniform-adversary filing).** An observation strategy continually protecting members against every allowed opponent exists if and only if such a protectable family exists, with quantifier order
\[
\exists\pi\ \forall\alpha\ \forall n:
  \text{the }n\text{th actual prefix and its intermediate action positions are protected}.
\tag{10}
\]
For a fixed strategy, protection fails if and only if there is an actual finite first failure carrying the original whole ledger; when clock cofinality is required, failure decomposes into either a finite first counterexample or an execution passing every local visit whose physical clock remains bounded above. In the signed constitutional game, no civilian strategy forces ceasefire and withdrawal completion if and only if every signed civilian policy suffers one of three original obstructions: an allowed-play dead end with a named refusal, a finite joint-safety breach, or a lawful opponent and schedule under which withdrawal remains unpaid at every tick forever. Dually, whenever one fixed opponent observation strategy \(\alpha\) defeats every signed civilian policy (\(\exists\alpha\,\forall\pi\)), after the first attack tick \(t_*\) on every lawful interleaving, the immediately following publication visit \(t_*+1\) automatically files that actual appropriation as a live original reparation row.

**Proof.** Reachable histories of a successful strategy form a protectable family because identical observations select the same action and continual protection keeps all responses inside the family; conversely, choosing the shared action on each reachable fibre and inducting over rounds preserves all prefixes, with intermediate positions covered by the word's checked suffix and exit. Well-ordering of \(\mathbb N\) locates the earliest local failure carrying the whole ledger, whereas passing all local visits without cofinality bounds the clock set. In the signed constitutional game, if forcing fails, excluded middle on existence of a lawful replay and preservation of all finite joint boundaries yields: if no lawful replay exists, a local dead end with an explicit admission violation; if some finite boundary fails, a joint breach; if both hold yet completion is not forced, a lawful opponent and schedule maintaining life and exit at every step while withdrawal never completes at any \(n\in\mathbb N\). The converse implications are mutually exclusive with forcing. When a uniform attacker \(\alpha\) exists, its first unconsented cross-community debit at tick \(t_*\) is immediately booked by the ensuing publication visit \(t_*+1\) as a live reparation row, placing the play in the joint-breach branch. \(\square\)

Theorem 6 separates “each branch has a rescue in hindsight” from “one observable policy defeats all lawful responses in advance,” while its third obstruction—indefinite pending without finite breach—isolates the constitutional necessity of priority scheduling.

### 3.2 Sharp priority bound, unprioritised infinite stall, and irreversible hard deadlines

**Theorem 7 (Sharp priority bound, unprioritised infinite stall, and anti-coalition refusal invariants).** Under the installed emergency law, an admitted revocation, a closed protective observation family, and nonempty lawful local menus, the following positive and converse results hold simultaneously.

1. **Sharp priority bound versus pocket-veto stall.** Under original priority scheduling, if the priority queue currently holds \(r_0\) pending items, an approved literal withdrawal or commitment word \(w\) completes at exactly visit
   \[
   N=r_0+|w|
   \tag{11}
   \]
   under every lawful competing interleaving, with its terminal physical clock fixed by the literal endpoint of \(w\). Conversely, without priority scheduling, whenever the cut has pending work and review is available, even though the civilian lawfully lodges the withdrawal input at tick 0, an opponent who submits the zero-material stop-review input (`stopReview`) at every subsequent tick keeps the withdrawal incomplete at every \(n\in\mathbb N\) and stalls the physical clock forever below \(\tau_0+1\).
2. **No unilateral rebirth and three anti-coalition refusal invariants.** After revocation, no single signer can regenerate controlled authority alone. So long as one originally exposed bearer continuously refuses, any adaptive coalition across all rival visits preserves three invariants simultaneously: that bearer's stock of every good never decreases, every original reparation row and balance owed to that bearer persists intact, and the revoked mandate remains released. Any subsequent paid execution of a controlled operation necessarily traces back to an earlier paid proposal by a task member together with each original bearer's own affirmative answer at the original material grant item.

**Proof.** Under priority scheduling, each effective visit reduces the original pending rank by one until all \(r_0\) items clear, and then executes the \(|w|\) literal items of \(w\) in order; competing inputs cannot insert ahead of original pending work, giving \(r_0+|w|\) visits. For the unprioritised countermodel, assign tick 0 to the civilian (lodging the withdrawal while busy, emitting no material item) and every tick \(k\ge1\) to the opponent submitting `stopReview`: when the review gate is available, `stopReview` spends zero material and leaves the raw state, clock \(\tau_0\), and control unchanged. Induction gives an empty cumulative material inventory and \(\tau_k=\tau_0<\tau_0+1\) for all \(k\in\mathbb N\); because completing withdrawal requires consuming a post-submission material receipt at the review gate, withdrawal never completes at any tick.

Against an adaptive coalition, every rival visit passes through the grant gate: without the refusing bearer's affirmative answer, any item debiting their stock, crediting their reparation, or recording a fresh grant is rejected, preserving their stocks, reparation rows, and absence of grants; induction over rival prefixes keeps the mandate released. If authority later revives or a controlled action is paid, assuming no personal-lane grant occurred keeps the mandate released up to that cut and refutes admissibility of the controlled action; unpacking the written grant recovers both the task member's earlier paid proposal item and the exposed bearer's affirmative reply at that original item position. \(\square\)

Temporal limits on emergency authority are likewise enforced without discretionary reset.

**Proposition 8 (Emergency-deadline frontier and irreversible expiry across all suffixes).** Checking all rational candidate deadlines on the original calendar for actual issuance, service, resource debits by two independent reviewers, and each member's independent exit produces the complete feasible domain, its earliest attained deadline, and its latest attained or strictly approached frontier. Once the physical clock at any cut strictly crosses the task's hard deadline (\(\tau>T_{\mathrm{dead}}\)), along **every subsequent original input suffix**, the emergency law remains installed, the clock satisfies \(\tau'>T_{\mathrm{dead}}\), and every proposal, acceptance, and renewal command as well as every protected task use is permanently refused; re-querying the state or carrying unfinished review liabilities never resets an expired mandate.

**Proof.** Calendar verification and real Dedekind bounds yield the feasible interval and both endpoints: in the three-party emergency benchmark, authority is issued at clock 1 and task service falls at clock 4, producing the half-open feasible deadline interval \([3,4)\)—earliest deadline \(3\) is attained (with two independent reviewers each paying 1 unit, and omitting the second unit or any personal exit returning a named refusal), whereas ceiling \(4\) is strictly open because service itself already falls at \(4\). Once \(\tau(s)>T_{\mathrm{dead}}\), because no actual original script ever runs the physical clock backwards, the terminal state \(s'\) reached along any suffix \(u\) satisfies \(\tau(s')\ge\tau(s)>T_{\mathrm{dead}}\), and every item within an atomic word reads that current clock; since valid proposal, acceptance, renewal, and protected task-use items all require \(\tau\le T_{\mathrm{dead}}\), all of them are unconditionally rejected across every suffix. \(\square\)

Theorems 6–7 and Proposition 8 place self-enforcing constitutionalism and emergency sunset limits on an exact procedural timescale [@Weingast1997; @FerejohnPasquino2004; @CalabresiMelamed1972]. In Weingast's framework, a sovereign attempts *divide-and-conquer* selective transgressions by allying with a subset of citizens, deterred only if all citizens share a focal threshold in a repeated game; Theorem 6 replaces exogenous focal beliefs with observation-fibre protectable families, while Theorem 7(2)'s three refusal invariants block any adaptive divide-and-conquer coalition directly at the execution gate. Simultaneously, Theorem 7(1) exposes the procedural vulnerability of neo-Roman fixed terms—without queue priority, zero-material `stopReview` inputs create an infinite pocket veto below \(\tau_0+1\)—and Proposition 8 enforces suffix-irreversible expiry as a formal constitutional inalienability boundary.

![War-payoff reversal, unilateral deadlock, and enforceable ceasefire](figures/01-war-and-ceasefire-en.pdf)

Figure 1. Three exact boundaries on the six-unit claim \(\rho_0=(2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))\). Top: responsibility reattachment \(\Delta(\lambda)=m-\lambda T\), zero-shift blocking, and observation-fibre duality. Middle: single-signer non-decreasing liability versus same-position dual signing and the widest safe guard. Bottom: sharp priority completion \(N=r_0+|w|\), unprioritised `stopReview` stall, and irreversible expiry \(\tau>T_{\mathrm{dead}}\).

## 4 When can the entire reparation ledger be settled?

### 4.1 Generating the settlement domain from actual reachability

Settlement must deliver the owed quantities to their original victim addresses without exhausting the conditions required for social life and independent exit to continue. Throughout, the construction enforces **incommensurable multi-good accounting**: distinct goods \(g\in\mathcal G\) never introduce exogenous shadow prices or cross-good scalar netting—conservation holds good by good, whole-ledger clearance evaluates a unit-free indicator, productive funding takes the worst-cell ceiling, review fees sum per-good work debits, and net review losses hold simultaneously under every strictly positive weight vector.

Call a set \(V\) of states a **cofinal viable region** if, for every \(y\in V\) and every finite clock bound \(B\in\mathbb Q\), there exists a finite actual path passing the original checks,
\[
y\longrightarrow y'\in V,\qquad \tau(y')>B,
\tag{12}
\]
each step paying common subsistence and maintenance from current inventory while retaining an independently payable exit word for each listed member. Write \(V_{\max}\) for the union of all cofinal viable regions.

**Lemma 9 (The maximal viable region).** A state belongs to \(V_{\max}\) if and only if an actual registered, step-by-step paid, clock-cofinal infinite trajectory starts from it.

The states visited by a cofinal trajectory satisfy (12). Conversely, arbitrary unions preserve (12), making \(V_{\max}\) itself the largest cofinal viable region; starting at \(y_0\in V_{\max}\), select a shortest admissible finite path past the next integer clock bound to some \(y_1\in V_{\max}\), reset the target bound at that exact resulting state \(y_1\), and concatenate by induction to obtain one registered cofinal trajectory.

Define a viable settlement entry \(\operatorname{Entry}_x(w)\) to hold when a finite submission prefix \(w\) passes original admission, protected reserves, and pending-work checks, and its actual resulting state \(x_w\) admits an approved production choice (retaining the current rule, or adopting an originally approved new rule and executing its literal first trial) whose post-trial state lies in the maximal viable region \(V_{\max}\) for that rule and roster. The viable whole-ledger settlement domain is
\[
\mathcal S(x)=
\{w:\operatorname{Entry}_x(w)\ \land\
       \forall\rho,\ r_\rho(w)=0\}.
\tag{13}
\]

**Theorem 10 (Sustainable joint settlement: equivalence and minimum visits).** For any original appropriation, independent acceptance channel, and registration source, the joint settlement construction returns a sustainable execution clearing all original rows if and only if \(\mathcal S(x)\ne\varnothing\). On success it attains the minimum visit count
\[
\ell_*=\min\{|w|:w\in\mathcal S(x)\},
\tag{14}
\]
and the whole-settlement report and whole-portfolio optimum report select the same shortest literal prefix and the same complete execution. When \(\mathcal S(x)=\varnothing\), every candidate with a viable entry retains at least one positive original debt row, while remaining candidates retain an original-admission or viability obstruction.

**Decisive proof.** Any successful output carries its literal word, complete execution trace, zero balances on all original rows, and viable-entry witness into \(V_{\max}\), placing it in \(\mathcal S(x)\). Conversely, when \(\mathcal S(x)\ne\varnothing\), minimising the unit-free whole-portfolio indicator \(\mathbf1_{\{\exists\rho,\ r_\rho(w)>0\}}\) attains zero without summing across distinct goods, and well-ordering of \(\mathbb N\) selects the least length \(\ell_*\) and a canonical attaining run; position-by-position checks already enforce payment order, dynamic reserves, and same-position two-party acceptance, while Lemma 9 continues cofinally from the settled state. If \(\mathcal S(x)=\varnothing\), a viable candidate clearing every row would belong to \(\mathcal S(x)\), a contradiction; hence every viable candidate retains positive debt and all others keep their admission or viability failure. \(\square\)

The natural-number visit minimum \(\ell_*\) and the physical-time infimum \(T_*=\inf\{\tau(x_w):w\in\mathcal S(x)\}\) are resolved separately: when \(\mathcal S(x)\ne\varnothing\), attainment of \(T_*\) further minimises visits among prefixes at \(T_*\), whereas nonattainment produces an actual clearing prefix before \(T\) for every \(T>T_*\).

### 4.2 Exact production-period threshold and delivery order

Debts unreachable under old production become payable once a recipe supplies positive net increments above the reserve. Pair each payer and good as a cell \(c=(i,g)\), writing \(D_c\ge0\) for total original debt on \(c\), \(s_c\ge0\) for currently spendable stock above the production reserve, and \(r_c\ge0\) for the repeatable net increment per period.

**Proposition 11 (Feasibility and exact period bound for productive settlement).** A natural number of production periods \(n\in\mathbb N\) covers all original debts simultaneously (\(\forall c,\ D_c\le s_c+nr_c\)) if and only if every cell with a current shortfall has a strictly positive net increment, \(\forall c,\ s_c<D_c\Rightarrow r_c>0\). Under this condition, stock at period \(n\) covers every original debt if and only if
\[
n\ge N_{\mathrm{prod}}
=\max_c\left\lceil\frac{D_c-s_c}{r_c}\right\rceil_+,
\tag{15}
\]
where cells already covered (\(D_c\le s_c\)) contribute \(0\). Combined with supply release and independent acceptance channels, the compiler selects the earliest funded cut, pays key by key, and restarts long-term operation of the same recipe from its retained reserve.

**Proof.** If \(s_c<D_c\) and \(r_c=0\), then \(s_c+nr_c=s_c<D_c\) for all \(n\); conversely, when every shortfall cell has \(r_c>0\), \(D_c\le s_c+nr_c\iff\lceil(D_c-s_c)/r_c\rceil\le n\) on each shortfall cell, and taking the maximum over the finite ledger support gives the exact equivalence and tight threshold \(N_{\mathrm{prod}}\) in (15). The batch consumer applies this bound uniformly to clear original debts of \(6(n+1)\) at net increment \(18\) per period for every \(n\in\mathbb N\). \(\square\)

Order of operations matters even when totals match: receiving an exchanged input before paying a claim passes verification, whereas reversing those two operations leaves a six-unit intermediate deficit at the payment position. The joint compiler therefore replays production, exchange, instalments, and reserves position by position rather than netting aggregate totals.

### 4.3 New rules produce first; old debts are paid from the new stock

Revising a production technology requires approval from the originally affected parties followed by execution of its literal trial-production word. The trial output enters the actual current stock checked for payment; both the payer's order and the victim's acceptance bind that new current state, the same visit ordinal \(\nu\), and the literal transfer. At state \(s\) and original debt key \(\rho\), define the funded rational amount set
\[
\begin{split}
A_\rho(s)=\{q\in\mathbb Q:\;&0<q\le r_\rho(s),\\
 &q\text{ is valid at }s\text{ with both parties' affirmative acceptance at that position},\\
 &\text{the post-delivery state }s'\text{ satisfies every dynamic protected reserve}\}.
\end{split}
\tag{16}
\]
Here the dynamic protected reserve at the post-delivery state \(s'\) is
\[
R_{s'}(i,g)=\max\{0,\ell^0_{s'}(i,g),\ell_{s'}(i,g)\}
          +\max\{0,m^0_{s'}(i,g),m_{s'}(i,g)\},
\tag{17}
\]
where \(\ell^0,\ell\) are original and current subsistence needs and \(m^0,m\) are original and current maintenance needs. Componentwise comparison shows \(\sigma_{s'}(i,g)\ge R_{s'}(i,g)\) if and only if the stock splits into disjoint nonnegative subsistence and maintenance shares each covering both original and current baselines.

**Theorem 12 (Exact disposition of the full payment-amount domain).** Whenever \(A_\rho(s)\) is nonempty, its real embedding has a tight upper bound \(q_*=\sup A_\rho(s)\le r_\rho(s)\). If \(q_*\in A_\rho(s)\), the construction generates the actual payment of \(q_*\); if \(q_*\) is not attained, then for every \(\varepsilon>0\) it generates a funded rational amount \(q\in A_\rho(s)\) and its actual successor satisfying
\[
\sup A_\rho(s)-\varepsilon<q<\sup A_\rho(s).
\tag{18}
\]
When \(A_\rho(s)=\varnothing\), every candidate amount receives its named refusal at the original position with unchanged debt. Whenever the full balance \(r_\rho(s)\) belongs to \(A_\rho(s)\), full settlement is selected directly.

Joining exact single-amount funding verification to the supremum property ensures that every witness carries lawful execution, same-position two-party acceptance, and reserve decomposition (17) before reducing balance \(\rho\) alone. Inducting across arbitrary adaptive interleavings of production revisions, partial payments, and refusals advances \(\nu_n=\nu_0+n\) strictly at each step, preserving every original debt address while preventing receipt replay.

## 5 How the settled world continues on its own

### 5.1 Compulsory convergence, anti-filibuster hourly progress, and the 111-unit reserve

Once dual-signed allocation and the damage guard are installed on the six-unit source, we first test whether competing schedules or arbitration interleavings can block entry into peace or starve current subsistence through procedural flooding. In this two-good economy, the settlement material (`good = false`) simultaneously serves as working-capital carrier stock: each personal production step stakes 18 units of carrier stock (if carrier stock lies below 18, the material compiler rejects the entire personal period and leaves the state untouched), immediately recovers those 18 units while outputting 1 unit of food (`good = true`), and the ensuing meal step consumes that 1 unit of food.

**Proposition 13 (Compulsory convergence, unique peace tail, and anti-filibuster hourly progress).** On the six-unit source equipped with dual-signed settlement and the cross-community guard, under every competing interleaving policy: every lawful actual run converges at visit 4 (physical clock 5) to the exact same peaceful whole-ledger resident, clearing the reparation balance to zero while preserving the separate financial principal of 6, and admits a unique peaceful continuation tail (\(\exists!\,\mathrm{tail}\)). Along that tail, each step advances the physical clock by \(0\) or \(1\) without skipping hours; from any cut \(x_n\) with \(\operatorname{pending}(x_n)\) queued ordinary items, the next open hour is crossed within at most \(\operatorname{pending}(x_n)+1\) visits:
\[
\tau\bigl(x_{n+\operatorname{pending}(x_n)+1}\bigr)\ge\tau(x_n)+1,
\tag{19}
\]
and every hour-crossing visit actually pays at least 1 unit of food subsistence to every member while preserving zero new damage and individual independent exits throughout.

**Proof.** The protected cut at clock 4 uniquely carries the whole ledger; dual-signed delivery of 6 units installs the 18-unit carrier-turnover food recipe above, writing the unique initial peace state at visit 4 (clock 5) through which every lawful future uniquely factors. At any cut \(x_n\), if \(\operatorname{pending}(x_n)=0\), the next visit executes due service, advancing \(\tau\) by 1 and paying every member's food; if \(\operatorname{pending}(x_n)=k+1\), competing dispatch never rolls back \(\tau\) and reduces pending count to \(k\), yielding (19) by induction on \(k\), while the least crossing index witnesses paid hourly subsistence. \(\square\)

We now lift this single-source tail to open-syntax worlds under reinterpreted production. Listing settlement-carrier inventories in the order \((\text{claimant},\text{payer})\) gives
\[
(111,113)
 \xrightarrow{\text{approved new-rule trial}}
(115,117)
 \xrightarrow{\text{dual-signed six-unit delivery}}
(121,111).
\tag{20}
\]
Trial production adds 4 units to each party, and dual-signed delivery transfers 6 units from payer to claimant at clock 5, clearing the balance from 6 to 0 while retaining \(\rho_0=(2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))\).

The network peace-opening procedure (`openNetwork`) reads \((121,111)\) directly: it verifies zero remaining balance on every row, executes the common production word and each member's independent exit word on the payer's reduced carrier stock of 111, and verifies dynamic reserves (17), repeatability under time shifts and added reserves, nonnegative accumulation, at least one strictly positive net gain, and a positive duration increment \(\delta>0\). This directly answers the opening “\(111<113\)” question: after transferring 6 units, the payer's carrier stock \(111\ge18\) remains well above the 18-unit production threshold and dynamic reserve, so peace opens and continues accumulating from the diminished post-settlement stock; whereas food (`good = true`) produces and consumes 1 unit per round with zero slack, so submitting an alternative word demanding a third meal hits the explicit food shortage \(0<1\) at actual position 2 and reverts to the ordinary successor.

**Theorem 14 (Arbitrary open-syntax peaceful continuation from the actual settled state).** From any settled resident passing these checks, for arbitrary proposal syntax depending on round, public transcript, physical clock, public terms, and current language epoch, together with its interpreter and adaptive strategy, every round \(n\in\mathbb N\) generates an actual successor: it pays current subsistence and maintenance, preserves every member's independent exit, incurs zero new cross-community appropriation at every executed item, preserves all settled original debt addresses and protected public terms, strictly increases stock at at least one participant–good coordinate, and satisfies the cofinal clock bound (1).

**Proof.** Mapping each round's syntax through the interpreter (with parse failures defaulting to ordinary due renewal) routes execution into one of three deterministic branches: ordinary due renewal, fixed refusal of a paid proposal within existing coverage, or a minimal first language write. All three branches execute the same repeatability-certified material and prepayment successor, preserving subsistence, exits, zero new damage, and positive net gain; when a language revision occurs (Theorem 15), its newly written institutional ledger becomes the exact resident read by the next round without altering the physical programme or original debt stack. Inducting over \(n\) and summing per-round increments of at least \(\delta>0\) establishes all invariants and (1). \(\square\)

### 5.2 Non-classifiability of stealth capture, minimal extension, and anti-fragile locking

Why is an exogenous damage guard (Theorem 3) insufficient on its own, making self-revising institutional language indispensable? Once direct cross-community seizure is blocked, predation mutates into **zero-debit stealth institutional capture**: a proposed rule change can debit zero foreign material (`DemandsAggression = false`) and share **the exact same old review quote or old offer word** as a harmless proposal, while quietly revoking an individual's originally payable independent exit or altering protected public terms at the rule-interpretation layer.

Write \(\mathcal L_{\mathrm{cont}}\) for the type of named continuation claims (pairs of bearer lists and native action words), and for any candidate programme \(P\), let \(\operatorname{losses}(P)\subseteq\mathcal L_{\mathrm{cont}}\) denote the set of continuations payable at the current paid pre-state that cease to be payable under \(P\). Define the refusal language at epoch \(n\) as \((\mathrm{Code}_n,D_n)\), where \(D_n:\mathrm{Code}_n\to\mathcal P(\mathcal E)\) assigns to each code the set of effects it refuses (over \(\mathcal E=\mathcal L_{\mathrm{cont}}\sqcup\{\text{term change}\}\)). Initialising \(D_0(c)=\varnothing\), current coverage is
\[
C_n=\bigcup_{c\in\mathrm{Code}_n}D_n(c).
\tag{21}
\]
When the \(n\)th paid visit exposes an effect set \(E_n\subseteq\mathcal E\) with \(E_n\setminus C_n\ne\varnothing\), revision forms the sum type \(\mathrm{Code}_{n+1}=\mathrm{Code}_n\sqcup\{\star\}\), preserves every inherited code verbatim via \(D_{n+1}(\iota(c))=D_n(c)\), and assigns the single fresh code to \(D_{n+1}(\star)=E_n\setminus C_n\). Write \(U_n=\mathcal E\setminus C_n\) for the unsealed vulnerability set.

**Theorem 15 (Old-readout non-classifiability, exact expression failure, and anti-fragile invariants).** Along any open-syntax peaceful continuation of Theorem 14, let \(E_n\) be the effect set exposed at round \(n\).

1. **Zero-debit stealth capture and non-classifiability by old readouts.** On the settled six-unit base, there exists a named candidate policy preserving literal action registration and incurring zero cross-community debit while revoking an originally payable personal exit, sharing the exact same harmless wire and old review quote as the baseline policy; generally, for any proposal domain \(\mathcal Q_{\mathrm{prop}}\), candidate map \(q\mapsto P(q)\), and old readout \(\operatorname{obs}_{\mathrm{old}}:\mathcal Q_{\mathrm{prop}}\to\mathcal O_{\mathrm{old}}\) (instantiated both by the old offer word \(\mathcal O_{\mathrm{old}}=\mathrm{Word}\) and by the old review quote \(\mathcal O_{\mathrm{old}}=\mathrm{ReviewBid}\)), whenever \(q_0,q_1\in\mathcal Q_{\mathrm{prop}}\) satisfy \(\operatorname{obs}_{\mathrm{old}}(q_0)=\operatorname{obs}_{\mathrm{old}}(q_1)\) with \(\operatorname{losses}(P(q_0))\ne\operatorname{losses}(P(q_1))\), **no** classifier reading only \(\operatorname{obs}_{\mathrm{old}}\) can decide continuation losses:
   \[
   \neg\exists\operatorname{classify}:\mathcal O_{\mathrm{old}}\to\mathcal P(\mathcal L_{\mathrm{cont}}),\quad
   \forall q\in\mathcal Q_{\mathrm{prop}},\
   \operatorname{classify}\bigl(\operatorname{obs}_{\mathrm{old}}(q)\bigr)=\operatorname{losses}\bigl(P(q)\bigr).
   \tag{22}
   \]
2. **First-write equivalence and least coverage.** Round \(n\) generates a whole-network first language write if and only if \(E_n\) at the paid pre-state contains an effect inexpressible in the old language:
   \[
   E_n\setminus C_n\ne\varnothing
   \quad\Longleftrightarrow\quad
   \text{a first language write occurs at round }n.
   \tag{23}
   \]
   Revision preserves the denotation of every inherited code, and the updated coverage satisfies the least-upper-bound universal property for every candidate coverage \(D\subseteq\mathcal E\):
   \[
   C_{n+1}=C_n\cup E_n,\qquad
   C_{n+1}\subseteq D\ \Longleftrightarrow\ C_n\subseteq D\ \land\ E_n\subseteq D.
   \tag{24}
   \]
   Starting from \(C_0=\varnothing\), an effect is covered later iff it was witnessed at some earlier paid visit; resubmitting a nonempty covered scope triggers the installed refusal without another write.
3. **Zero collateral damage, anti-fragile locking, and archive localisation.** Every novel exposure strictly shrinks the unsealed vulnerability set (\(U_{n+1}\subsetneq U_n\)); public physical compilation of every finite native word `word` and every participant–good productive gain remain identically unchanged across the amendment (zero collateral damage to lawful production and independent exits); every paid overreaching submission incurs a strictly negative net material payoff under every strictly positive per-good weight \(w(g)>0\); the fresh direction enters with zero budget, the revised resident directly drives the next material round, and along the support restriction \(\beta:\Sigma_{n+1}\to\Sigma_n\) between pre- and post-revision network support sets, an archived obstruction \((\sigma,o)\) is locally active at \(\alpha\in\Sigma_{n+1}\) iff \(\sigma=\beta(\alpha)\) (Technical Appendix C.3).

**Proof.** On the settled six-unit base, construct `locked` retaining literal exit registration and the harmless zero-debit wire while setting the internal policy predicate to false, placing the claimant's exit claim in \(\operatorname{losses}(\mathtt{locked})\) whereas the baseline satisfies \(\operatorname{losses}=\varnothing\) under identical harmless wires and old quotes; for any pair with \(\operatorname{obs}_{\mathrm{old}}(q_0)=\operatorname{obs}_{\mathrm{old}}(q_1)\) and \(\operatorname{losses}(P(q_0))\ne\operatorname{losses}(P(q_1))\), any factorising `classify` in (22) assigns equal sets to both sides, a contradiction. If \(E_n\subseteq C_n\), existing codes refuse without writing; if \(E_n\setminus C_n\ne\varnothing\), any \(e\in E_n\setminus C_n\) lies in \(D_{n+1}(\star)\), forcing the unique fresh write, while union universality and induction yield (24) and the paid-witness identity. Any \(e\in E_n\setminus C_n\) lies in \(U_n\setminus U_{n+1}\), giving \(U_{n+1}\subsetneq U_n\); updating only the refusal-language component preserves the physical programme and material successor, keeping native `word` compilation and productive gains identical; positive fee debits yield strictly negative net material payoff under every weight \(w>0\); reading the first component of \((\sigma,o)\) gives \(\sigma=\beta(\alpha)\). \(\square\)

### 5.3 Two paid revisions, proxy-filer defence, and resolution of dynamic-power commitment

From the settled six-unit state \((121,111)\), the first paid proposal at clock 5 exposes a change to protected public terms, and the second at clock 6 exposes removal of an individual independent exit; each debits three portions of \(1/6\) unit of food at original material index 6 (\(1/2\) unit per revision), advancing to clocks 6 and 7 as coverage grows from \(C_0=\varnothing\) to \(C_1=\{\text{terms}\}\) and \(C_2=\{\text{terms},\text{exit}\}\), with the second material round reading the institutional ledger written by the first while \(\rho_0\) remains live at balance zero. In the companion three-step open-revision consumer, resubmitting a covered scope a third time under a fresh order still pays the fee and receives immediate refusal without a third language write, whereas wrong signers or stale orders are erased back to ordinary material renewal; likewise, in the cross-community levy consumer, routing an already covered exposure coordinate through a different filing payer (`delegated.payer` \(\ne\) `levy.signer`) still identifies the same exposed victim cell, returns the fixed refusal, and debits the \(1/2\) unit of food directly from that proxy filer.

This construction connects commitment under shifting power, exit–voice theory, incomplete-contract grammars, and formal norm revision. Against Powell's rapid power-shift dilemma [@Powell2006, pp. 183, 188–189], raising output (`113 → 117` and subsequent net accumulation) gives the payer no leverage to overturn settlement or strip the claimant's exit, because unilateral debt non-reduction, the widest safe guard, dynamic reserves, and strictly costly self-locking probes dispense with exogenous high discount factors. Against Hirschman's exit–voice substitution tension and coupling conditions [@Hirschman1970, pp. 35–36, 81–82] alongside Calabresi and Melamed's inalienability boundary [@CalabresiMelamed1972], each member's payable **independent exit** is constitutionally protected as an inalienable baseline: any stealth attempt to revoke exit is caught by **prepaid voice** and sealed into the refusal language, making exit and voice mutually reinforcing. Against Grossman and Hart's residual control rights under ex ante non-contractibility [@GrossmanHart1986] and Crawford and Ostrom's static institutional grammar [@CrawfordOstrom1995, pp. 583–586], (22) proves that static grammars cannot detect zero-debit capture from old readouts, placing residual safety in dynamic self-amending language rather than unilateral ownership. Finally, in AGM theory revision, resolving conflict with prior beliefs requires partial-meet contraction [@Alchourron1985TheoryChange, §§1–2]; here the damage guard and typed refusal language \((\mathrm{Code}_n,D_n)\) keep newly exposed harms \(E_n\setminus C_n\) disjoint from lawful native production and exit words, confining institutional hardening strictly to the conflict-free monotonic branch with **zero contraction** of native words.

## 6 Waiting, shortage, and late evidence share one clock

### 6.1 Today's needs are paid while the debt remains unsettled

While two-party settlement signatures are still pending, the institution neither erases the original debt nor suspends current subsistence.

**Proposition 16 (Paid continuation with unsettled debt).** At any unsettled state equipped with a verified continuation recipe and under any adaptive schedule, each round first executes current subsistence, maintenance, and individual independent exits before reading a settlement or revision request. Victim refusal preserves the original debt address and balance; every finite wait advances through actual successors with a cofinal clock. When both same-position signatures arrive at round \(k\), funding is checked against the inventory actually remaining after round \(k\)'s due step; if sufficient, the allocator clears the debt and enters the peace opening of Theorem 14 directly.

Induction over rounds shows that food eaten and maintenance materials consumed while waiting enter the real stock condition faced by later payment; no old order can roll inventory back to an earlier cut.

### 6.2 Generating the first feasible recipe from an actual shortage

When stock changes render registered recipes and one-step named edits infeasible, execution searches jointly over a finite basis of originally registered actions and a finite roster for a common production word \(u\) together with an independent exit word \(e_i\) for each listed member. Define joint width by
\[
\operatorname{width}(u,(e_i))=\max\bigl(|u|,\max_i|e_i|\bigr).
\tag{25}
\]

**Theorem 17 (Width completeness of joint-recipe search and first-write rebasing).** Fix the current state, a finite basis of originally registered actions, a finite roster, and admissibility conditions for a new recipe. A finite feasible joint recipe exists if and only if complete search succeeds at some finite width. The first success returns a feasible joint recipe of minimum width together with named refusal grounds at every smaller width; once the original menu and single-step edits are exhausted, duration checks pass, and that minimum width lies within the current search window, the selected recipe directly executes an actual rebase and first production write. Exhausting a finite window pays the current due step while retaining all checked prefixes and refusal grounds; advancing visit ordinals make the searchable width unbounded.

Every finite recipe has a finite width (25) reached by complete enumeration, and minimality records concrete failures across all narrower layers. Along the deployed six-unit track, an empty-word shortage at clock 7 synthesises and writes a width-4 joint recipe at clock 8, yielding a net gain of 2 units of settlement material for each of the two members.

### 6.3 Review fees, zero-fee erasure, and privacy before payment

Reviewing proposals consumes real labour and material. Summing actual per-good debits across verified filing and per-request review procedures defines the generated fee vector \(c(g)\).

**Proposition 18 (Least sufficient fee for the original procedure and non-discountable fragmentation).** For every good, the generated fee equals the review procedure's exact total debit and never exceeds any fee vector sufficient to fund that procedure; because the original dispatcher preserves the common production slot, the production-displacement opportunity cost in this quote is zero. The fee is debited once at the next actual material position, reverting to ordinary production upon insufficient budget, charges exceeding productive gain, or zero declarations; splitting a submission into repeated paid fragments charges each original ordinal and repeats the filing fee, never discounting the total charge.

Prepayment simultaneously establishes exact anti-spam erasure and pre-charge privacy.

**Theorem 19 (Whole-trace erasure of zero-fee probes and the paid position of the first public distinction).** Fix the tariff and response channels under prepaid execution.

1. **Whole-trace erasure of zero-fee probes.** For any adaptive coalition policy, erasing all zero-fee presentations that incur no actual material debit leaves the entire infinite state–observation trajectory unchanged at every index, and leaves unchanged the partition of possible source histories (information fibres) induced by any action-facing readout functional; consequently, any changed readout at any cut traces back to an earlier actual material write authorised by its payer.
2. **Two-trajectory prepayment privacy.** Compare two openings sharing the same reserve base, tariff, signed orders, public due agenda, and public strategy, while differing in hidden stocks above that base and private qualification replies: every finite or infinite prefix prior to an actual fee debit retains the exact same public transcript and language; if a new public distinction first appears, both trajectories have actually debited the same literal bill at that same visit position. Across rebasing, any difference in newly published supply terms traces back to distinct production words actually executed on the two sides.

**Proof.** An uncharged presentation reduces in one step to the exact ordinary due transition; induction on rounds keeps the root state and observation identical at every finite cut and hence across the whole infinite trajectory, preserving equality of any readout functional on both sides. If a readout differs from the attack-free baseline, some earlier step must therefore carry a paid receipt signed by its initiator. For two-trajectory privacy, common observations and due agendas choose the same input and payment branch along any unpaid prefix, emitting identical public due acknowledgements and keeping the language fixed; thus the first public divergence cannot occur on an unpaid branch and requires same-position receipts for the same literal bill on both sides. \(\square\)

### 6.4 Evidence arrives later; its receipt remains in its own history

After a review fee is debited, direct evidence of protected-term changes or lost exits may arrive several rounds later, after intervening due renewals and production rebases.

**Theorem 20 (Receipt transport across renewal and rebasing, and diagonal undecidability by finite duration queries).** When charging has occurred but scope evidence is incomplete, execution retains the original receipt, signed-order identity, and actual material successor. Across arbitrarily many intervening paid renewals and production rebases, the receipt reads back the exact same original paid scope; when evidence arrives, language disposition completes directly at the resident actually reached without debiting the review fee again (reusing that resident without a second write if already covered in the interim, or writing the least extension there if a gap remains). Moreover, no finite adaptive tree of duration queries can decide initial language coverage in general: for any finite adaptive query tree \(Q\) and baseline programme \(P_0\), there exists a candidate programme \(P^\dagger\) yielding the exact same query trace and Boolean output as \(P_0\) under \(Q\) while violating protected public terms at a named physical site.

**Proof.** Inducting across renewals and rebases transports the signed-order identity and pre-state, keeping the paid scope invariant. For undecidability, construct \(P^\dagger\) by diagonalisation: run the finite adaptive tree \(Q\) against \(P_0\)'s duration function \(d_0\), let \(S_Q\) be the finite list of states queried, set
\[
t^\dagger=\max\bigl(\{0\}\cup\{\tau(s):s\in S_Q\}\bigr)+1,
\]
and define \(P^\dagger\) to alter duration to \(d_0(s)+1\) solely when \(\tau(s)=t^\dagger\), keeping \(d_0(s)\) everywhere else. Every \(s\in S_Q\) satisfies \(\tau(s)<t^\dagger\) (with \(t^\dagger=1\) when \(S_Q=\varnothing\)), so trace induction shows \(Q\) reads identical answers at every node and returns the same Boolean verdict on \(P^\dagger\) and \(P_0\); yet at clock \(t^\dagger\), \(d^\dagger\ne d_0\), violating protected public terms and placing \(P^\dagger\)'s paid effect outside \(C_0=\varnothing\). Any \(Q\) deciding initial coverage would accept \(P_0\) (empty scope) and hence falsely accept \(P^\dagger\). \(\square\)

Proposition 18 and Theorems 19–20 delineate the operational preconditions of ex post message mechanisms in incomplete-contract theory [@MaskinTirole1999]. Maskin and Tirole showed that when parties dynamically foresee payoff consequences, subgame-perfect ex post message mechanisms can restore optimal outcomes if ex post renegotiation is barred—or despite renegotiation under strict risk aversion. In a running institution, however, unpriced message submissions invite strategic probing of private reserves and agenda congestion; Proposition 18 and Theorem 19 prove that work-derived prepayment erases zero-fee probes across the entire infinite trajectory and confines the first public divergence to mutually paid positions, while Theorem 20 proves that no finite adaptive duration sampling can substitute for original-receipt scope transport across rebases.

## 7 Why the same balance is not the same history

Original-position conservation (Theorem 2) determines who is owed what and how much has been paid [@Gao2026WholeLedger]. Moving from a single machine to crash-recoverable processes and multiple physical hosts raises a sharper question: if an external execution exhibits the same final zero balance—or even the exact same raw stocks and physical clock at every visit—does it represent the original history? It does not.

Two countermodels establish this separation. The first appropriates resources anew after the common opening and then pays subsistence cofinally while keeping old rows cleared—refuting “progress with zero old debt implies peace.” The second keeps zero new loss, all old debts cleared, every independent exit available, and **the exact same raw material inventory and clock at every visit**, while reversing the signer order of the four production-and-meal writes in one two-person round:
\[
(\mathrm{true},\mathrm{true},\mathrm{false},\mathrm{false})
\quad\text{versus}\quad
(\mathrm{false},\mathrm{false},\mathrm{true},\mathrm{true}).
\]
Snapshot balances erase this permutation and therefore cannot tell a recovering server which specific request has already been performed.

Write \(x_n\) and \(w_n\) for the original states and actual writes. An external presentation supplies states \(y_k\) and optional writes \(e_k\). Set \(o_0=0\), \(o_{k+1}=o_k\) when \(e_k=\varnothing\), and \(o_{k+1}=o_k+1\) when \(e_k\ne\varnothing\). Local write-by-write verification requires \(y_0=x_0\) and, for all \(k\in\mathbb N\),
\[
\begin{aligned}
e_k=\varnothing&\ \Longrightarrow\ y_{k+1}=y_k,\\
e_k\ne\varnothing&\ \Longrightarrow\
 e_k=w_{o_k},\quad y_{k+1}=x_{o_k+1}.
\end{aligned}
\]

**Theorem 21 (Write-by-write fidelity and unique factorisation of external history).** For any original registered execution, an external presentation passes the origin check and every local write-by-write check if and only if it admits an original-ordinal factorisation \(f:\mathbb N\to\mathbb N\) preserving state readouts, actual writes, and \(0/1\) step recursion; whenever such a map exists, it is uniquely \(f(k)=o_k\). Under this condition, unbounded progress \(\forall n\,\exists k:\ n\le o_k\) holds if and only if every original cut has a unique first visit in the external presentation; a foreign origin, the first mismatching write, and permanent bounded stuttering are each located at their own actual address.

**Proof.** Any \(f\) satisfying \(f(0)=0\) and \(f(k+1)=f(k)+\mathbf1_{\{e_k\ne\varnothing\}}\) shares the initial value and recurrence of \(o_k\), forcing \(f(k)=o_k\) by induction even if states or literal writes repeat later. Induction over local checks yields \(y_k=x_{o_k}\) and matches every nonempty write to \(w_{o_k}\), and conversely factorisation implies all local checks. Because \(o_k\) is monotone with increments in \(\{0,1\}\), it skips no natural number: if \(\forall n\,\exists k:\ n\le o_k\), the least \(k_*\) with \(n\le o_{k_*}\) satisfies \(o_{k_*}=n\) and \(o_j<n\) for all \(j<k_*\), giving the unique first visit. \(\square\)

The deployment module `LivingLawTerminalPeaceInstance` joins the stages of the same six-unit source into a deterministic state machine, bridging the clocks of §5 and §10 while exemplifying Theorem 21. Starting from the post-trial state (`source`, clock 5, debt 6)—rather than taking Branch I's immediate settlement and two back-to-back revisions in §5.3 (clocks `5 → 6 → 7`)—Branch II executes: first unsettled due renewal (`due`, clock 5→6, debt 6), victim refusal preserving debt (`refusal`, clock 6, debt 6), late dual-signed settlement and network installation (`settlement` / `installation`, clock 6, debt 0), prepaid review submission awaiting scope evidence (`pendingReview`, clock 7), and width-4 joint-recipe synthesis and rebase after an empty-word shortage (`rebase`, clock 8, adding 2 units of settlement material per person). From clock 8, the unwaited batch schedule (`Facade.Stage`) immediately executes the minimal-language first write (`U8` in the deployed state labels) at clock 8 (`revision`) and runs five due renewals to clock 13 (matching all 13 public observations between batch and stepwise processes); whereas the persistent online entry (`Ingress`) executes two waiting due renewals across clocks 9–10 (`waiting 1, 2`), cold-recovers the journal and writes `U8` upon late evidence at clock 10 (`revised 2 0`, recording 2 waiting rounds and 0 post-revision renewals), and completes two renewals across clocks 11–12 (`revised 2 2`, observation cursor 11) to produce **the exact clock-12 parent head (`013bd261...`) sealed for four-host admission in §10**. Both schedules share zero remaining debt and identical stocks at clock 12, yet retain distinct literal histories because their `U8` writes occur at different ordinals; resubmitting an identifier returns its original receipt, concurrent same-parent submissions are mutually exclusive, and post-commit restarts recover the committed successor.

![One debt: productive settlement, anti-fragile revision, and dual branches](figures/02-debt-and-revision-en.pdf)

Figure 2. Progression of the six-unit claim \(\rho_0\) from productive settlement to open-language revision and the four-host entry point. Top: \((\text{claimant},\text{payer})\) carrier stocks move from `(111,113)` to `(115,117)` under approved trial production and `(121,111)` upon dual-signed six-unit delivery, clearing the debt. Middle: Branch I (clocks `5 → 6 → 7`) performs two half-unit food-paid revisions establishing the anti-fragile invariants. Bottom: Branch II runs the persistent `Ingress` track (clocks `5 → 12`, writing `U8` at clock 10 and sealing the clock-12 parent head for Figure 3; the unwaited batch track writes `U8` at clock 8 through clock 13).

## 8 Verifiers can change; payments already made have one history

### 8.1 \(3f+1\) quorum intersections at each parent head and unique history across handovers

We now lift write-by-write history to a distributed setting without any permanent sovereign office [@Gao2026Constitution]. Call the currently certified record the **parent head** \(p\); a candidate successor \(q\) binds \(p\), the original request identifier, caller authorisation, literal input, complete readback after native Lean execution, and the next four-verifier roster. Each parent head \(p\) has a four-member roster \(O(p)\), instantiating the \(n=3f+1=4\ (f=1)\), dissemination-quorum \(2f+1=3\) Byzantine intersection geometry [@MalkhiReiter1998, pp. 205–206; @CastroLiskov1999, §§3–4]. Each verifier signs only after committing its durable local transaction and remains bound across restarts by its stored state at \(p\).

**Lemma 22 (An honest intersection of three-signature sets).** Any two subsets \(Q_1,Q_2\subseteq O\) of size at least three within a four-member roster \(O\) intersect in at least two members; if at most one member violates its durable signing constraint, at least one member in \(Q_1\cap Q_2\) observes the constraint.

By inclusion–exclusion,
\[
|Q_1\cap Q_2|
\ge |Q_1|+|Q_2|-|O|
\ge 3+3-4=2.
\tag{26}
\]
Removing at most one faulty member leaves at least one constraint-observing member.

**Theorem 23 (Unique certified history through arbitrary handovers).** Suppose at every parent head \(p\) the current roster has four verifiers, at most one violates durable unique signing at \(p\), and every other member signs at most one successor at \(p\). A certified edge requires decision votes from at least three outgoing members and, whenever the roster changes, independent native replay of the original prefix and current payment from the original Lean source by all four incoming members. Then any two finite certified histories from the same root are prefix comparable, and any two infinite certified continuations from the same root agree at every write index; handovers may recur arbitrarily often, and successive rosters may be completely disjoint.

**Proof.** Two certified successors \(q_1,q_2\) at the same parent \(p\) carry outgoing three-vote sets sharing a constraint-observing member by Lemma 22, forcing \(q_1=q_2\). Inducting on finite history length, the empty history is a prefix of every history, while two nonempty histories share their first successor \(q_1\) and hence read the exact same next roster \(O(q_1)\), where the induction hypothesis applies. Agreement at every finite depth yields pointwise equality of infinite continuations. Because each step uses quorum intersection solely within \(O(p)\), consecutive rosters require no common member. \(\square\)

Theorem 23 simultaneously answers the political-philosophical postulate of Leviathan and the architecture of state-machine reconfiguration [@Hobbes1651, ch. 17; @LamportShostakPease1982, §§2, 4; @MalkhiReiter1998, pp. 205–206; @CastroLiskov1999, §§3–4; @LamportMalkhiZhou2009, §§1–2]. Unlike the \(3m+1\) oral-message bound (which drops to \(m+2\) under synchronous signatures), tolerating up to \(f\) non-responsive nodes asynchronously while preventing equivocation under digital signatures still requires \(n=3f+1=4\) and self-verifying dissemination quorums of size \(2f+1=3\); across reconfigurations, Vertical Paxos further relies on an external configuration master to decide configuration transitions and gate state-transfer activation. Theorem 23 dispenses with both permanent sovereigns and external configuration masters: three outgoing votes fix the unique successor, while `4/4` independent native replay from the original Lean source guarantees that incoming verifiers inherit verified source execution rather than an unverified snapshot, preserving one history even across completely disjoint rosters (`abcd → efgh`). Whether requiring `4/4` incoming replay risks deadlock when a nominee stays silent is resolved completely in §9.

### 8.2 How cold recovery recognises the original request

When the primary journal is lost or rolled back, cold recovery identifies the active four-member roster from ancestor certificates, issues a fresh challenge readback, collects three valid responses, and replays the certified chain from the original Lean source to reconstruct the latest head, request identifier, and successor.

By Lemma 22, three fresh readbacks and three durable writers share at least one honest durable member. Two readbacks fail via an exact counterexample: take roster \(\{a,b,c,d\}\), durable writers \(\{a,b,c\}\), readers \(\{c,d\}\), and sole faulty member \(c\) withholding its stored write, proving sharpness of the three-read threshold.

Recovery branches cleanly by evidence: a committed identifier returns its original readout; partial signatures complete under the original identifier and caller authorisation; insufficient evidence names the parent head, phase, and missing members without double-charging.

## 9 Interrupted handover: which evidence releases the old candidate?

### 9.1 Compatible completions and the exact certification criterion

When a handover stalls mid-flight, an unresponsive node may be slow or permanently gone. Aborting on a timeout risks violating an already certified edge; waiting forever sacrifices liveness. Role-specific seals with durable past-and-future obligations replace timeout guesswork.

Fix one parent head, epoch, and handover candidate between outgoing roster \(O\) and proposed incoming roster \(N\), with \(|O|=|N|=4\). An **outgoing no-decision seal** attests that its signer has not cast an outgoing decision vote for this candidate and durably commits never to do so; an **incoming no-replay seal** makes the corresponding commitment for incoming replay. Write \(D\subseteq O\) and \(S\subseteq N\) for the collected seal sets. An identity \(m\in O\cap N\) holds distinct signing roles in \(O\) and \(N\), yet violating either seal places \(m\) once into the shared fault set \(B\), counting simultaneously toward both single-fault budgets \(|B\cap O|\le1\) and \(|B\cap N|\le1\).

Formally, a pair \((B,C)\) of finite sets is a **compatible completion** under \((D,S)\) if the outgoing decision set \(C\subseteq O\) satisfies \(|C|\ge3\), the fault set \(B\) satisfies \(|B\cap O|\le1\) and \(|B\cap N|\le1\), and every identity violating a seal upon completion by \(C\) and all of \(N\) lies in \(B\), namely \((C\cap D)\cup(N\cap S)\subseteq B\). For any outgoing triple \(Q\subseteq O\) (\(|Q|=3\)), define its forced fault set
\[
F(Q)=(Q\cap D)\cup(N\cap S).
\tag{27}
\]

**Theorem 24 (Exact compatibility with certification).** A compatible completion \((B,C)\) exists under \((D,S)\) if and only if at least one of the four outgoing triples satisfies both rosters' fault budgets:
\[
\exists Q\subseteq O,\ |Q|=3:\quad
|F(Q)\cap O|\le1
\quad\land\quad
|F(Q)\cap N|\le1.
\tag{28}
\]
Current seal evidence excludes the candidate if and only if all four triples fail (28).

**Proof.** If (28) holds for \(Q\), setting \(C=Q\) and \(B=F(Q)\) gives \(|C|=3\), \((C\cap D)\cup(N\cap S)=B\), and both budget bounds. Conversely, given a compatible completion \((B,C)\), choose a three-element subset \(Q\subseteq C\subseteq O\); then
\[
F(Q)=(Q\cap D)\cup(N\cap S)\subseteq(C\cap D)\cup(N\cap S)\subseteq B,
\]
so intersecting with \(O\) and \(N\) yields \(|F(Q)\cap O|\le|B\cap O|\le1\) and \(|F(Q)\cap N|\le|B\cap N|\le1\). With \(|O|=4\), checking all \(\binom{4}{3}=4\) triples is exact. \(\square\)

### 9.2 Sharpness of the seal threshold

Criterion (28) immediately pins down the exact outgoing-seal threshold: **three** outgoing no-decision seals (\(|D|\ge3\)) suffice alone to exclude the candidate, since every triple \(Q\subseteq O\) intersects \(D\) in at least two members by Lemma 22, forcing \(|F(Q)\cap O|\ge2>1\) across all four triples. Conversely, **two** outgoing seals admit the compatible counterexample
\[
O=N=\{0,1,2,3\},\qquad
D=\{0,1\},\qquad S=\varnothing.
\tag{29}
\]
Choosing \(Q=\{0,2,3\}\) gives \(F(Q)=\{0\}\), within budget \(1\) in both rosters (identity `0` is the single faulty member voting despite its seal while honest `2,3` vote normally). Two outgoing seals therefore never justify universal withdrawal.

### 9.3 Maximal-evidence pre-check and deadlock-free disposal under unreachable nominees

Because issuing a role seal permanently closes that signing role, requesting seals when even the fullest reachable evidence cannot exclude the candidate would needlessly trap a completable payment. Let \((D_{\max},S_{\max})\) be the maximal seal sets obtainable from current responders. Monotonicity of \(F(Q)\) implies
\[
\operatorname{Possible}(D_{\max},S_{\max})
\Longrightarrow
\operatorname{Possible}(D,S)
\quad
(D\subseteq D_{\max},\,S\subseteq S_{\max}),
\tag{30}
\]
where \(\operatorname{Possible}(D,S)\) denotes (28). Execution evaluates \((D_{\max},S_{\max})\) before requesting irrevocable seals; if compatible, it halts seal issuance, preserves the signing route, and returns the named missing roles.

Joined to the ordered handover rule—durable storage of intent at three outgoing nodes, followed by all `4/4` incoming native replays before any outgoing member may cast a decision vote—criterion (28) guarantees both safety of certified edges and deadlock-free disposal when nominees fail to respond.

**Corollary 25 (Protection of certified candidates and deadlock-free disposal before replay completion).** Suppose \(|O|=|N|=4\) and actual seal-violating identities respect the single-fault budget in each roster.

1. **Certified edges cannot be excluded.** Any candidate already holding a complete certificate (at least three outgoing votes and all four incoming replays) satisfies (28) under all reachable seal sets and can never be validly excluded.
2. **Deadlock-free disposal under total incoming unavailability.** Under the ordered rule requiring complete `4/4` incoming replay before any outgoing decision vote, if an attempt is interrupted before incoming replay completes, then even if all four proposed incoming members stay completely unreachable (zero incoming responses, \(S=\varnothing\)), responses from any three reachable honest outgoing members necessarily supply three outgoing no-decision seals (\(|D|\ge3\)), validly excluding the candidate under (28) and enabling paid withdrawal or reassignment at the same parent head.

**Proof.** Part 1: constraint-observing signers never seal against a role already performed, placing \(Q\cap D\) and \(N\cap S\) inside the actual fault set \(B\); the converse direction of Theorem 24 gives \(\operatorname{Possible}(D,S)\). Part 2: let \(R_{\mathrm{out}}\subseteq O\) be the reachable honest outgoing responders with \(|R_{\mathrm{out}}|\ge3\). Each \(m\in R_{\mathrm{out}}\) either has already cast a decision vote or issues a no-decision seal \(m\in D\); because casting a decision vote requires complete incoming replay, which has not occurred, the first case is impossible, giving \(R_{\mathrm{out}}\subseteq D\) and \(|D|\ge3\). By §9.2, three outgoing seals exclude all four triples, proving \(\neg\operatorname{Possible}(D,S)\). \(\square\)

Corollary 25 engages the FLP asynchronous consensus impossibility theorem along an exact formal boundary [@FischerLynchPaterson1985, pp. 377–379]. FLP proves that in a clockless asynchronous network where slow messages and unannounced crashes are indistinguishable, no deterministic protocol can guarantee both agreement and termination under even one fault; consequently, engineering heuristics that abort stalled handovers on local timeouts risk violating certified safety or remain vulnerable to adversarial scheduling. Rather than claiming seal-free termination under pure FLP silence, our mechanism identifies the exact cryptographic evidence replacing timeout guesswork: compatible \((D_{\max},S_{\max})\) halts seal issuance to protect safety, while under replay-before-vote ordering an unreachable nominee leaves outgoing votes uncast, so three honest outgoing seals (`3/4` majority) dispose of the candidate without deadlock:

| Current evidence | Disposition | Original payment and responsibility |
| --- | --- | --- |
| Complete certification | Complete or recover under the original identifier | Recognise the same successor already selected |
| A compatible completion remains | Preserve the signing route and name the missing roles and identities | Preserve the original parent head, intent, and existing signatures |
| Every completion is excluded | Withdraw or reassign under the original caller authorisation and actually pay one due action | Bind the disposition to the same parent head; the old identifier returns this actual result |

![Certified history and the three dispositions of an interrupted handover](figures/03-certified-history-en.pdf)

Figure 3. Top: each parent head uses \(3f+1=4\) outgoing votes and `4/4` native replays, while replay-before-vote ordering lets three outgoing seals dispose of an interrupted attempt without deadlock even if `0/4` nominees respond. Middle: pre-checking \((D_{\max},S_{\max})\) routes execution into three exact dispositions. Bottom: clocks 12–28 on four physical hosts for \(\rho_0\) (95 signatures, 8 certified rows, and 3 exclusions verified offline).

### 9.4 Signatures can be released; history remains unique

Once a candidate is validly excluded, honest members who voted for it must be released to sign a withdrawal or reassignment at the same parent head. Write \(V(m,p,q)\) when member \(m\) has cast a decision vote for \(q\) at parent \(p\), and \(E(p,q)\) when \(q\) is validly excluded at \(p\). Define the **surviving vote** predicate
\[
V^\circ(m,p,q)=V(m,p,q)\land\neg E(p,q).
\tag{31}
\]

**Theorem 26 (History agreement after arbitrarily many dispositions).** Suppose every parent head has four verifiers with at most one faulty member, valid exclusion is sound for certified edges (no certified edge is ever excluded), and a constraint-observing member votes for two distinct candidates \(q_1\ne q_2\) at \(p\) only if at least one has been validly excluded (\(E(p,q_1)\lor E(p,q_2)\)). After arbitrarily many handovers, withdrawals, and repeated reassignments, finite certified histories from the same root remain prefix comparable, and infinite certified continuations agree at every index.

**Proof.** By Corollary 25(1), every certified edge \((p,q)\) satisfies \(\neg E(p,q)\), so all three of its outgoing votes survive in \(V^\circ\) and every certified history remains certified under \(V^\circ\). If a constraint-observing member holds surviving votes \(V^\circ(m,p,q_1)\) and \(V^\circ(m,p,q_2)\), then \(\neg E(p,q_1)\) and \(\neg E(p,q_2)\), so the fence condition forces \(q_1=q_2\). Thus \(V^\circ\) satisfies the strict unique-signing hypothesis of Theorem 23, whose induction over parent heads yields prefix comparability and pointwise infinite agreement. \(\square\)

## 10 The same six-unit ledger from clock 12 to clock 28

### 10.1 Mathematical constructions, process checks, and physical nodes

The theorems of §§1–9 quantify over arbitrary admissible sources, observation structures, adaptive strategies, and certified histories. Lean proof bodies carry those universal quantifiers, direct consumers instantiate them on the six-unit source, local durable-transaction fixtures exercise concurrency and fault schedules, and four physical hosts take over the clock-12 head produced by §7's Branch II, independently replaying the same Lean source and signing readbacks through clock 28.

Throughout, the original reparation address is
\[
\rho_0=(2,0,(\mathrm{false},\mathrm{true},\mathrm{false})),
\tag{32}
\]
recording filing visit 2, material item 0, injured party, payer, and settlement-carrier good. Every certified payment from clock 12 to clock 28 reads back the same \(\rho_0\) and zero remaining balance:

| Source clock | Actual event in the same original ledger | Verifiers after completion |
| --- | --- | --- |
| 12–13 | Initial admission waits when short one vote; all four votes advance the original ID | \(a,b,c,d\) |
| 14–16 | Three-vote advance, returning-node replay, and sealed independent entry | \(a,b,c,d\) |
| 17 | Primary journal and local intent lost; three fresh readbacks cold-recover the original ID | \(a,b,c,d\) |
| 18 | Incoming member replays prefix and due payment from source, completing handover | \(a,b,c,e\) |
| 19–20 | Row-by-row rebuild after rollback to clock 16; three remotes \(b,c,e\) alone recover head | \(a,b,c,e\) |
| 21–22 | Paid activation of replay-before-vote entry; remote seals cold-recover paid withdrawal | \(a,b,c,e\) |
| 23 | Excluded handover reassigned and paid at the same parent head | \(a,b,c,f\) |
| 24 | Third original decision vote recovered; handover completes under selected original ID | \(a,b,c,g\) |
| 25–26 | Three outgoing seals release a single vote for paid withdrawal; ordinary due follows | \(a,b,c,g\) |
| 27 | Two stored votes keep maximal seals compatible; route preserved and original ID completes | \(a,b,c,f\) |
| 28 | Next step paid and independently read back by three remote hosts | \(a,b,c,f\) |

These seventeen clocks instantiate every boundary theorem of §§8–9 under live Ed25519 signatures. At clock 18, incoming identity \(e\) assumes retired identity \(d\)'s physical host with an independent key and fresh durable store: missing \(e\) halts specifically at incoming native replay, completion installs `abce`, and later signatures from retired \(d\) are rejected (a separate local fixture verifies disjoint `abcd → efgh` handover).

Clocks 22 and 24 exhibit exact mirror cases: at clock 22, moving away the primary journal cold-recovers a seal-certified withdrawal that no late incoming replay can overturn; at clock 24, recovering a third already-cast outgoing vote completes positive certification of `abcf → abcg` under its original identifier. Clocks 25 and 27 contrast single-vote release with two-vote preservation: at clock 25, seals from `b,c,g` exclude a one-vote attempt so the lone voter lawfully signs withdrawal; at clock 27, two stored votes pass the maximal-seal pre-check (30), preserving the signing route to complete `abcg → abcf` before three remote hosts verify clock 28.

Three hash-chained frozen receipts bind admission (clocks 12–16), cold recovery and handover (clocks 16–20), and interrupted-handover disposition (clocks 21–28). Read-only offline verification checks all 95 Ed25519 signatures against the frozen public-key policy, recomputes the 8 certified heads at clocks 21–28, checks parent links and \(\rho_0\) zero-balance continuity, and enumerates all four outgoing triples at each of the 3 exclusions under (28).

### 10.2 Theoretical coordinates: five classical propositions reshaped by the terminal theorem

Across the 26 numbered results, five converse impossibility bounds interlock with positive constructions to reshape five foundational propositions:

1. **From victim-paid appeasement to original-slot reattachment and the judgment-proof boundary:** Private gains from negative-sum war arise from outward liability shifting and are reversed on the closed reattachment interval; yet the empty judgment-proof region proves that ex post billing alone cannot universally deter conflict, requiring the widest safe ex ante guard and observation-fibre ceasefire policies (Theorem 3, Proposition 4, Theorems 5–6).
2. **From single-signer settlement and T-account quotienting to same-position dual signing with preserved lineage:** Single-signer primitives erasing cross-community consent induce double unilateral deadlock, whereas quotienting opposite T-account pairs to the zero account erases prior claim provenance; only combining the widest safe guard, symmetric delivery-position signatures, and multi-good productive surplus over dynamic reserves clears debt in minimum visits while retaining the original address (Theorems 2–3 and 10, Proposition 11, Theorem 12).
3. **From repeated-game focal beliefs and soft terms to sharp priority bounds, anti-coalition refusal, and hard expiry:** Without queue priority, zero-material procedural inputs create an infinite pocket veto within bounded time; sharp priority completion, anti-filibuster hourly subsistence progress, refusal invariants blocking selective-transgression coalitions, and suffix-irreversible refusal past hard deadlines enforce genuine temporal limits on emergency power (Theorem 7, Proposition 8, Proposition 13).
4. **From static grammars and conflict contraction to prepaid privacy and zero-contraction self-amending language:** Zero-debit rule proposals can strip personal exits under unchanged old readouts and evade any given finite adaptive duration query tree via out-of-sample alteration; work-derived prepayment erases zero-fee probes, while the damage guard and typed refusal language keep newly exposed harms disjoint from lawful native words, turning overreaching or proxy probes into strict net losses and conflict-free monotonic hardening (Theorems 14–15, Proposition 18, Theorems 19–20).
5. **From permanent Leviathan, snapshot transfer, and timeout heuristics to sovereignless source replay and role seals:** Stock-identical permuted replays refute snapshot criteria, and two reads or two seals admit single-fault counterexamples; write-by-write factorisation, outgoing three-vote quorums paired with full incoming source replay, maximal-evidence pre-checks, and replay-before-vote three-seal disposal maintain one continuous history across complete verifier turnover (Theorem 21, Lemma 22, Theorems 23–24, Corollary 25, Theorem 26).

These theorems hold strictly within their stated institutional inputs and fault budgets: they establish constructive equivalences and converse impossibility bounds for arbitrary participant, good, and technology types rather than econometric estimates of historical wars, and handover liveness is paid by role seals from reachable honest majorities rather than claiming seal-free termination under pure FLP silence. Within those exact bounds, enforceable peace requires neither an external benevolent enforcer, nor untestable discount-factor assumptions, nor permanent guardians in office: original debt reaches its terminal settlement while \(\rho_0\) remains on the books, and the institution advances through each new actual payment.

## Formal sources and technical appendices

The definitions and decisive proofs of the 26 numbered results form the complete paper together with two appendices: Technical Appendix A–H (original-position conservation, double unilateral deadlock, capacity intervals, observation-fibre duality, viable settlement, anti-filibuster progress, old-readout non-classifiability, anti-fragile invariants, diagonal undecidability, write-by-write factorisation, priority vs stall, hard expiry, and PE1–PE26 declarations) and Execution Appendix I.1–I.7 (\(3f+1\) certification, role-seal budgets, deadlock-free disposal, surviving-vote agreement, clocks 12–28, and PE27–PE33 correspondence).

Formal sources are pinned up to Homework revision `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0`. The [fixed public proof map](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) gives the primary public modules, complete Lean types, and direct consumers for PE1–PE33, while remaining co-epoch converse and auxiliary declarations reside in the import closure of [the same public revision](https://github.com/Sapientropic/H0mework/tree/2678896740481f6eb6fc248c38d86549a6b6911d); frozen receipts and offline checks appear in the [reproduction guide](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md), and the editable archive packages both languages, both appendices, the three bilingual vector figures, and the bibliography.

## References

::: {#refs}
:::
