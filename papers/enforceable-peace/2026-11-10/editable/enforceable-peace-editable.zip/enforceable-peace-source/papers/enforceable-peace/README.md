# 战争与和平的源生终局定理

*War and Peace: A Source-Generated Terminal Theorem*

中文正文从同一笔六单位损失展开责任回接、双单边死锁与双签清偿、强制汇合与反脆弱开放和平及任意拜占庭换届中的历史一致性；英文逐项忠实对应。主文含26项编号结果、32个编号公式与三幅双语矢量主图，两份技术附录展开完整证明与固定来源。

## 阅读与编辑

| 内容 | 中文 | English |
| --- | --- | --- |
| 正文PDF | [enforceable-peace.pdf](build/enforceable-peace.pdf) | [enforceable-peace-en.pdf](build/enforceable-peace-en.pdf) |
| 技术补充PDF | [enforceable-peace-supplement.pdf](build/enforceable-peace-supplement.pdf) | [enforceable-peace-supplement-en.pdf](build/enforceable-peace-supplement-en.pdf) |
| 正文来源 | [manuscript.md](manuscript.md) | [manuscript-en.md](manuscript-en.md) |
| 数学附录A–H | [technical-appendix.md](technical-appendix.md) | [technical-appendix-en.md](technical-appendix-en.md) |
| 执行附录I | [appendix-execution.md](appendix-execution.md) | [appendix-execution-en.md](appendix-execution-en.md) |
| 来源与复现 | [source-availability.md](source-availability.md) | [source-availability-en.md](source-availability-en.md) |

[完整可编辑包](build/enforceable-peace-editable.zip)包含双语来源、书目、三套双语矢量图、生成器、排版依赖及四份阅读PDF。版本身份见`release-artifacts.json`。

## 三幅主图

图1给出同一原债上的责任回接翻转、单签不减下界、最宽安全门禁与优先止战边界；图2连接增产清偿、两次反脆弱语言修订与通往钟12四机封存起点的九阶段部署链；图3将 \(3f+1\) 换届认证、无死锁角色封印判据、三路处置和钟12–28的四物理节点实证放到同一阅读面。双语SVG、PDF及数据说明见[figures](figures/README.md)。

## 作者与核验入口

立题见[brief](brief.md)，章节与论证见[outline](outline.md)，PE1–PE33的真实量词、固定源码和直接消费者见[claims](claims.md)。[editorial-notes](editorial-notes.md)记录当前稿的概念约定、独立审读修正和实际验收。构建方法见[PDF-BUILD](scripts/PDF-BUILD.md)。
