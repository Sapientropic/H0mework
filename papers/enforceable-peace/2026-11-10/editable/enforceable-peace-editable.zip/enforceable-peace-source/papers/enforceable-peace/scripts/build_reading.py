#!/usr/bin/env python3
"""Build the bilingual reading editions of enforceable-peace.

The manuscript and the two technical appendices remain the editable sources.
The shared typography is a read-only dependency.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
SHARED = PUBLISH / "shared" / "scripts"
sys.dont_write_bytecode = True
sys.path.insert(0, str(SHARED))
spec = importlib.util.spec_from_file_location("peace_shared_pdf", SHARED / "build_pdf.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
shared_prepare = builder.prepare
shared_latin_title = builder.latin_title

def latin_title(line):
    if re.match(r"^#{1,2}\s+(?:Abstract\b|References\b|Technical Appendix\b|[A-Z](?:\.\d+)*\s|\d+(?:\.\d+)*\s)", line.strip()):
        return None
    return shared_latin_title(line)
builder.latin_title = latin_title

def prepare(source, toc, profile):
    title, subtitle, body = shared_prepare(source, toc, profile)
    # Bibliography entries may span pages; the shared minipage is for short lists.
    ref = re.search("(?m)" + builder.REFERENCES, body)
    if ref:
        opening = "```{=latex}\n\\noindent\\begin{minipage}{\\linewidth}\n```\n\n"
        prefix = body[:ref.start()]
        if prefix.endswith(opening):
            body = prefix[:-len(opening)] + body[ref.start():]
            closing = "\\endgroup\\end{minipage}\\par"
            pos = body.rfind(closing)
            if pos >= 0:
                body = body[:pos] + "\\endgroup\\par" + body[pos+len(closing):]
    # Keep the H.1 subheading attached to the opening rows of its PE table.
    body = re.sub(r"(?m)^(#{2,4}\s+H\.1\b)",
                  lambda m: "```{=latex}\n\\Needspace{10\\baselineskip}\n```\n\n" + m[0], body)
    # Keep the frozen-receipt table with its verification paragraph.
    body = re.sub(r"(?m)^(三份冻结回执|The three frozen receipts)",
                  lambda m: "```{=latex}\n\\Needspace{24\\baselineskip}\n```\n\n" + m[0], body)
    return title, subtitle, body
builder.prepare = prepare

shared_run = builder.run
def run(command, **kwargs):
    command = list(command)
    if command and str(command[0]) == "pandoc":
        bibliography = PAPER / "references.bib"
        if not bibliography.is_file():
            raise FileNotFoundError(bibliography)
        command.extend(["--citeproc", "--bibliography", str(bibliography),
                        "--csl", str(PAPER / "scripts/numbered.csl"),
                        "--lua-filter", str(PAPER / "scripts/table-layout.lua")])
    return shared_run(command, **kwargs)
builder.run = run

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def supplement_source(lang, output):
    suffix = "-en" if lang == "en" else ""
    paths = [PAPER / ("technical-appendix" + suffix + ".md"),
             PAPER / ("appendix-execution" + suffix + ".md")]
    title = ("War and Peace: A Source-Generated Terminal Theorem — Technical Supplement"
             if lang == "en" else "战争与和平的源生终局定理 · 技术附录")
    chunks = ["# " + title]
    for p in paths:
        if not p.is_file():
            raise FileNotFoundError(p)
        text = p.read_text()
        # Preserve section hierarchy under one supplement title.
        text = re.sub(r"(?m)^(#{1,5}) ", lambda m: m[1] + "# ", text)
        # Rebase file links while preserving URI schemes and fragment links.
        text = re.sub(r"(!?\[[^\]]*\]\()((?![A-Za-z][A-Za-z0-9+.-]*:)[^#:/][^)]*)(\))",
                      lambda m: m[1] + str((p.parent / m[2]).resolve()) + m[3], text)
        chunks.append(text)
    target = output / "input" / ("supplement" + suffix + ".md")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n\n".join(chunks) + "\n")
    return target, paths

def build_one(part, lang, output, toc):
    suffix = "-en" if lang == "en" else ""
    if part == "main":
        source = PAPER / ("manuscript" + suffix + ".md")
        owners = [source]
        stem = "enforceable-peace"
        right = "原责任、清偿与历史一致" if lang == "zh" else "Responsibility, settlement and one history"
    else:
        source, owners = supplement_source(lang, output)
        stem = "enforceable-peace-supplement"
        right = "命题与证明对应" if lang == "zh" else "Claims, proofs and source correspondence"
    if not source.is_file():
        raise FileNotFoundError(source)
    rel = source.relative_to(PUBLISH).as_posix()
    left = "战争与和平的源生终局定理" if lang == "zh" else "War and Peace"
    builder.EXPLICIT_RUNHEADS[rel] = (stem, left, right)
    builder.CONTINUOUS_APPENDICES.add(rel)
    owners += [PAPER/"references.bib", PAPER/"scripts/numbered.csl",
               PAPER/"scripts/table-layout.lua", Path(__file__).resolve(),
               SHARED/"build_pdf.py", SHARED/"byline.py",
               PUBLISH/"shared/styles/article-filter.lua",
               PUBLISH/"shared/styles"/("article-header-en.tex" if lang == "en" else "article-header.tex")]
    for figure in re.findall(r"!\[[^\]]*\]\(([^)]+\.pdf)\)", source.read_text()):
        p = Path(figure)
        owners.append(p if p.is_absolute() else source.parent/p)
    initial = {str(p.relative_to(PUBLISH)): digest(p) for p in owners}
    print(json.dumps({"building":rel}, ensure_ascii=False), flush=True)
    report = builder.build(rel, toc=toc, output_dir=output)
    if any(digest(PUBLISH / p) != value for p,value in initial.items()):
        raise RuntimeError("An editable source changed during the build; rebuild its stable version.")
    pdf = PUBLISH / report["pdf"]
    report.update(part=part, language=lang, source_sha256=initial, pdf_sha256=digest(pdf))
    print(json.dumps(report, ensure_ascii=False), flush=True)
    return report

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--language", choices=["zh","en","both"], default="both")
    ap.add_argument("--part", choices=["main","supplement","all"], default="all")
    ap.add_argument("--figures", action="store_true")
    ap.add_argument("--no-toc", action="store_true")
    ap.add_argument("--output-dir", type=Path, default=PAPER/"build")
    args = ap.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if args.figures:
        py = Path.home() / ".venvs/figtools/bin/python"
        subprocess.run([str(py), str(PAPER/"figures/make_figures.py")], check=True)
    langs = ["zh","en"] if args.language == "both" else [args.language]
    parts = ["main","supplement"] if args.part == "all" else [args.part]
    reports = [build_one(part,lang,output,not args.no_toc) for part in parts for lang in langs]
    record = {"created_utc":datetime.now(timezone.utc).isoformat(),
              "scope":"enforceable-peace only",
              "visual_review":"The actual final PDF pages must be displayed.",
              "builds":reports}
    name = "build-report-" + args.part + "-" + args.language + ".json"
    (output/name).write_text(json.dumps(record, ensure_ascii=False, indent=2)+"\n")
    if any(r["missing_characters"] or r["overfull_boxes"] for r in reports):
        raise SystemExit("Layout findings remain; inspect the build reports.")
if __name__ == "__main__":
    main()
