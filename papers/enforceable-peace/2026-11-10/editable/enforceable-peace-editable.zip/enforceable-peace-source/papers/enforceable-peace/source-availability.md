# 来源与复现

本稿的命题、正文和两份技术附录使用以下固定对象。收稿上限为Homework `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0`；各组命题保留自己的原纪元。数学定义与决定性证明见正文及技术附录A–I，精确声明与直接消费者见[claims](claims.md)及两份附录的来源表。

## 研究源码的固定身份

| 命题 | Homework固定提交 | 内容 |
| --- | --- | --- |
| [PE1–PE10](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/Terminal.lean) | `7e4da746f300b3796b8b18afb26cb0765c29afcb` | 责任回接、观察策略、原追偿、联合清偿、预缴与适应性和平 |
| [PE11–PE14](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/OpenLanguage.lean) | `b675168bda8f52a6565a8db3617e262daa738bb0` | 开放语言、整网首写与真实递归 |
| [PE15–PE22](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/ActualClearance.lean) | `71cb159f4f0727d8fb67e7a436a1476e03a0d913` | 实际工序费、生产改订、原位清偿、整网开局、补证与授权期限 |
| [PE23–PE27](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace.lean) | `3a90cba5ac7427737ee2fe630612dfed43e45da1` | 未清债续行、配方搜索、跨换仓收据、默认入口与四节点准入 |
| [PE28–PE30](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/QuorumRecovery.lean) | `b5b9c5f86cab0bb212e306ab89db4bf5b177a177` | 冷恢复、实付换届与认证历史唯一性 |
| [PE31–PE33](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/HandoffDisposition.lean) | `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0` | 精确成案、角色封印、原位处置与任意处置一致性 |

源码根为 `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/`。技术附录H列出PE1–PE26的完整相对路径及声明，执行附录I.7列出后七项的Lean与Python接口。读取固定对象时采用Git提交与路径的组合：

```bash
git -C /path/to/Homework show COMMIT:PATH
```

一般清偿域使用数学选择、自然数最小元与实数确界。有限配方搜索在有限原动作基底和有限名册上执行完整宽度检查。原数值消费者、离线持久事务夹具与四物理节点回执各保留自己的输入和执行身份。

## 已验公开选集

[H0mework 固定版本 `267889674048`](https://github.com/Sapientropic/H0mework/tree/2678896740481f6eb6fc248c38d86549a6b6911d) 的 PE1–PE33 映射给出各主张的公开模块、完整 Lean 类型、直接消费者和原回执。PE3 和 PE6 的五个辅助源码对象另按公开 owner 的实际编译纪元登记于机器可读绑定。[逐主张映射](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) · [机器可读绑定](public-source-binding.json) · [复现指南](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md)

在该版本的仓库根目录运行以下命令。新检出可用 `make bootstrap` 准备固定依赖。离线复演使用固定 Lean 工具链和装有 `cryptography` 的 Python。

```bash
python3 tools/enforceable_peace.py entry
python3 tools/enforceable_peace.py build --output .local/peace-build
python3 tools/enforceable_peace.py replay --output .local/peace-replay
```

PE27 的临时运行时覆盖与 PE28–PE29 的早期传输适配器保留原回执中的 SHA-256。离线核验使用原认证账本和固定的公开程序。

## 冻结执行证据

下表链接到三份原字节回执。后续回执保留前次运行的原摘要。

| 回执 | SHA-256 |
| --- | --- |
| [`acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rc882831f/living-law/terminal-peace/original-six/acceptance.json) | `c087bd309a4e92b62ac3d88a17ec219c710e9fee929532a8a861dca26a6d968d` |
| [`recovery-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rb5b9c5f8/living-law/terminal-peace/original-six/recovery-acceptance.json) | `26522f53e07161b9bd8504c609292295168b90f6ba7927ad77c2e22cbc2847ad` |
| [`handoff-resolution-acceptance.json`](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/evidence/enforceable-peace/original/Rcf880bb2/living-law/terminal-peace/original-six/handoff-resolution-acceptance.json) | `7fe676f6d8dd085b959c92aa5ca151b7e2a9478378306a80a44d82924733c56b` |

只读复核入口支持直接读取公开选集目录或原平铺目录（可选传入 `--homework` 交叉核对原始 Git 对象）：

```bash
python3 scripts/verify_frozen_execution.py \
  --evidence-root /path/to/H0mework/evidence/enforceable-peace/original
```

在稿件目录运行。脚本以冻结公钥策略核验95份签名、钟21–28的8条认证行及3处排除，并核对回执内嵌的两个固定Lean对象摘要（传入 `--homework /path/to/Homework` 时同步复算原始Git对象字节）。本次运行结果为PASS。原公开策略、回执与固定Git对象作为输入，四个在线节点保留原运行状态。

## 阅读版与可编辑来源

`scripts/build_reading.py`生成中英文正文和中英文技术补充共四份PDF；`scripts/package_editable.py`收录双语Markdown、书目、矢量图、生成器、本稿构建脚本及其共享排版依赖。依赖和命令见[PDF-BUILD](scripts/PDF-BUILD.md)。图源、量纲与实际数据的对应见[figures/README](figures/README.md)。

可编辑包保存本稿写作与构图来源；研究仓、原部署记录和它们的核验身份由本说明及附录的固定引用连接。稿件目录的`release-artifacts.json`记录PDF及ZIP的成品身份；可编辑包根目录的`manifest.json`逐文件记录包内字节与摘要。
