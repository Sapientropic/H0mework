#!/usr/bin/env python3
"""Package this paper's editable sources, vector figures and reading PDFs."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
PREFIX = "enforceable-peace-source"

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, default=PAPER/"build/enforceable-peace-editable.zip")
    ap.add_argument("--source-only", action="store_true")
    args = ap.parse_args()
    required = ["manuscript.md","manuscript-en.md","technical-appendix.md",
                "technical-appendix-en.md","appendix-execution.md","appendix-execution-en.md",
                "figures/01-war-and-ceasefire.svg","figures/01-war-and-ceasefire-en.svg",
                "figures/02-debt-and-revision.svg","figures/02-debt-and-revision-en.svg",
                "figures/03-certified-history.svg","figures/03-certified-history-en.svg"]
    for rel in required:
        if not (PAPER/rel).is_file():
            raise FileNotFoundError(PAPER/rel)
    items = list(PAPER.glob("*.md")) + list(PAPER.glob("*.bib"))\
          + [p for p in PAPER.glob("*.json") if p.name != "release-artifacts.json"]
    for sub in ["figures","scripts"]:
        items += [p for p in (PAPER/sub).rglob("*") if p.is_file()
                  and not any(x.startswith(".") or x == "__pycache__" for x in p.relative_to(PAPER).parts)
                  and p.suffix in {".md",".py",".lua",".csl",".svg",".pdf",".json"}]
    for name in ["article-header.tex","article-header-en.tex","article-filter.lua"]:
        items.append(PUBLISH/"shared/styles"/name)
    for name in ["build_pdf.py","byline.py"]:
        items.append(PUBLISH/"shared/scripts"/name)
    for name in ["house_style.py","svg_text.py"]:
        items.append(PUBLISH/"shared/figure-style"/name)
    if not args.source_only:
        for name in ["enforceable-peace.pdf","enforceable-peace-en.pdf",
                     "enforceable-peace-supplement.pdf","enforceable-peace-supplement-en.pdf"]:
            p = PAPER/"build"/name
            if not p.is_file():
                raise FileNotFoundError(p)
            items.append(p)
    items = sorted(set(items))
    manifest = []
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.output,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in items:
            rel = p.relative_to(PUBLISH).as_posix()
            data = p.read_bytes()
            z.writestr(PREFIX+"/"+rel,data)
            manifest.append({"path":rel,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
        z.writestr(PREFIX+"/manifest.json",json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
        z.writestr(PREFIX+"/README.md",
            "# War and Peace: editable source\n\n"
            "The source tree preserves the paper and its read-only shared layout dependencies.\n"
            "Start with papers/enforceable-peace/scripts/PDF-BUILD.md.\n\n"
            "Rebuild the reading editions from this directory:\n\n"
            "    python3 papers/enforceable-peace/scripts/build_reading.py\n\n"
            "The paper identifies the original research repositories and deployment records "
            "through their fixed source bindings.\n")
    with zipfile.ZipFile(args.output) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
        for item in manifest:
            data=z.read(PREFIX+"/"+item["path"])
            assert hashlib.sha256(data).hexdigest()==item["sha256"]
    print(json.dumps({"archive":str(args.output),"files":len(manifest),
                      "sha256":hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      "integrity":"all archived bytes verified"},ensure_ascii=False))
if __name__=="__main__":
    main()
