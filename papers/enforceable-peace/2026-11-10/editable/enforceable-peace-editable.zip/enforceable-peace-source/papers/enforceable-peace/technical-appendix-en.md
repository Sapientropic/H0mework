# Technical Appendix: Exact Settlement, Open Revision, and Original History

This appendix gives the definitions, decisive arguments, and source correspondence for PE1–PE26; execution states, stocks, physical clocks, and original debt keys are written here as \(x,s_x,t_x,a\) (corresponding to \(s,\sigma,\tau,\rho\) in the main text). Certified histories and handoff dispositions have a separate execution appendix. Each material good retains its own unit; reparations, financial principal, food, and review charges have separate accounts.

## A. Original histories, losses, the unilateral bound, and the viable settlement domain

Let participants, goods, ports, technologies, financial instruments, and communities range over given types. An actual state \(x\) contains stocks \(s_x(p,g)\in\mathbb Q\), a physical clock \(t_x\), the priority pending queue, the visit ordinal \(\operatorname{ord}(x)\in\mathbb N\), the operative technology, and the complete responsibility ledger. The institution supplies authorization, actual debits and credits, and the successor of a literal action. A submission can emit several material items. Visit ordinal, material-item ordinal, and physical time are recorded separately.

A positive net debit across a community boundary, made without the affected person's consent, is addressed by
\[
a=(\text{submission ordinal},\text{actual-item ordinal},
(\text{victim},\text{payer},\text{good})).
\]
The original loss at \(a\) is \(d_a>0\), and its outstanding balance is \(b_a\ge0\). Subsequent financial registration and institutional revision retain the original provenance of this address. If a submission is rejected because another item fails, material already debited still opens its liability.

**Conservation by good (PE3).** For every actual history \(h\) and good \(g\),
\[
\sum_{a:\,g(a)=g}b_a(h)+\operatorname{Paid}_g(h)
=\operatorname{Damage}_g(h),
\qquad
\operatorname{Paid}_g(h)\le \operatorname{Signed}_g(h).
\]
Paid quantities count only eligible receipts consumed by the allocator at actual material positions. Induction appends one input: first post its new losses, then allocate eligible delivery to original rows. The local identity “remaining after allocation plus the new allocation equals remaining before allocation” adds to the preceding conservation identity. Earlier eligible rows have priority, and total credit assigned at one delivery position cannot exceed the signed quantity at that position.

**Double unilateral deadlock, non-reduction bound, and widest safe guard (PE3, PE6).** Under the old single-signature receipt rule without an independent victim-acceptance channel at the same position, a payer's unilateral order credits no cross-community debt (on the six-unit source, payer-signed `returnAt 6` moves stocks to \((117,107)\) with zero credit while \([(\rho_0,6)]\) remains intact, `after_the_payer_returns_six_the_original_six_is_still_in_the_whole_account`), while every positive cross-community unilateral receipt clears old debt only by simultaneously opening an equal reverse cross-community loss at the same material position \(pos\) (victim-signed `receipt 6` closes \(\rho_0\) to \(0\) and writes `(reverseOccurrence, 6)` at that position, `the_victims_receipt_really_closes_the_old_six_and_writes_the_reverse_six`; generally `every_cross_community_receipt_opens_its_equal_reverse_damage`). Because one material item cannot spend the same good twice, total credit assigned to good \(g\) at \(pos\) is bounded by that receipt's quantity and hence by the new good-\(g\) loss filed at \(pos\); summing across distinct positions of one input gives \(\operatorname{Assigned}_g\le\operatorname{Filed}_g\). Combining this with step conservation shows that for every prefix \(h\) and every continuation script \(u\),
\[
\operatorname{Out}_g(h)\le\operatorname{Out}_g(h\mathbin{+\!\!+}u).
\]
On the original six-unit history \(h_0\), \(6\le\operatorname{Out}_{\mathrm{false}}(h_0\mathbin{+\!\!+}u)\) holds throughout, while retaining the old production law to clock \(5\) yields zero food delivered against unit demand and leaves no independent exit under any control map, establishing dual material and receipt obstructions. Once the cross-community damage guard is installed, it forwards a request if and only if it is originally lawful with zero new cross-community damage, containing every safe admission predicate as a subset.

A **continuation step** consists of a registered common word actually paid from the current inventory, together with an independently payable exit word for each listed participant. Every common-word item respects both original and current subsistence and maintenance floors, and the actual duration is positive. Finite paths concatenate these steps. For a set \(R\) of states, define
\[
\Phi(R)=\{x:\ \forall B\in\mathbb Q,\ \exists\text{ a finite actual path }x\leadsto y,\
y\in R,\ t_y>B\}.
\]
The largest viable region is
\[
V=\bigcup\{R:R\subseteq\Phi(R)\}.
\]
Its defining objects are finite paid paths that return to the region beyond every original-clock bound.

**Viability theorem (PE6).**
\[
x\in V\quad\Longleftrightarrow\quad
\text{a registered, paid, clock-cofinal trajectory starts at }x.
\]
For necessity, take the set of all states of the trajectory. For sufficiency, select a shortest actual path beyond the current target clock and consume it step by step. At its endpoint, reset the target and select again from that same successor. Induction on integer clock increments reaches every rational bound after every prescribed cut. Actual successor identities concatenate the paths, carrying subsistence and independent exit with them.

Fix an original loss occurrence, independent receipt channels, registered submissions, and approved production alternatives. Let \(x_h\) be the actual state reached by a prefix \(h\). Define
\[
\begin{split}
\operatorname{Entry}(h)\ \Longleftrightarrow\;&
h\text{ passes original admission and its pending work and review entry are ready, and}\\
&\exists c,m:\ c\text{ is an approved production choice,}\\
&m\text{ is paid from }x_h\text{ and meets the first-trial requirement of }c,\quad
m(x_h)\in V_c .
\end{split}
\]
The optional production choice \(c\) may be empty, retaining the current rule and original roster. Choosing an alternative requires original approval, and \(m\) executes that alternative's literal first trial. The region \(V_c\) is determined by the chosen execution law, original subsistence baseline, and roster. The actual first-trial successor belongs to \(V_c\), and continuation begins there.

The viable whole-ledger settlement domain is
\[
\mathcal S=\{h:\operatorname{Entry}(h)\ \land\
                 \forall a\in L(h),\ b_a(h)=0\}.
\]

**Whole-ledger terminal theorem (PE6–PE8).** The construction returns an actual whole-ledger settlement exactly when \(\mathcal S\ne\varnothing\). Its selected \(h_*\in\mathcal S\) satisfies
\[
|h_*|=\min\{|h|:h\in\mathcal S\}.
\]
The whole-settlement report and the whole-portfolio optimum report select the same literal prefix and the same actual realization. If \(\mathcal S=\varnothing\), every actually viable candidate retains a positive original row. If no viable entry exists, each candidate retains its original admission or viability obstruction.

The proof minimizes the whole-portfolio indicator \(\mathbf1_{\{\exists a,\ b_a(h)>0\}}\). This tests zero balance row by row without adding goods with different units. A clearing prefix attains zero; minimization of natural-number length then selects the first attainable visit count. Conversely, an actual zero-balance output is itself an element of \(\mathcal S\). Optimization for one original claim separately uses its lower-bounded real value set and distinguishes an attained infimum, strict approximation at every positive tolerance, and an empty domain.

Visit count and physical time have separate frontiers. Over the viable settlement domain \(\mathcal S\) equipped with joint production trials, put
\[
T_*=\inf\{t_{x_h}:h\in\mathcal S\}.
\]
When this domain is nonempty, every \(T>T_*\) admits an actual settlement prefix completed before \(T\). If \(T_*\) is attained, select the fewest visits among prefixes at that time. Otherwise every strictly later deadline has an actual-prefix witness.

**Compulsory convergence, unique peace tail, and anti-filibuster hourly progress (PE6).** Under the constitutional terminal construction on the six-unit source, regardless of competing interleavings, every lawful continuation converges at visit \(4\) (physical clock \(5\)) to the same peaceful whole-ledger resident with a unique continuation tail (\(\exists!\,\mathrm{tail}\), `source_generated_terminal_peace`), preserving separate financial principal \(6\) alongside cleared \([(\rho_0,0)]\). Along continuation, integer hours are never skipped, no competing interleaving can delay due subsistence past the current priority queue (crossing into the next hour within \(\operatorname{pending}(x_n)+1\) visits, `the_due_service_cannot_be_delayed_past_the_pending_queue`), and the first visit crossing each open hour \(h+1\) pays at least \(1\) unit of food to every member (`the_first_crossing_of_each_open_hour_is_paid`).

## B. Reattachment thresholds, observation-fibre duality, production bounds, and payment at the original position

### B.1 Strict reversal, reattachment obstructions, and observation-fibre duality

An executable menu \(M\) consists of candidates with a score \(u\), and has frontier
\[
v(M)=\sup\{u(w):w\in M,\ w\text{ is actually executable}\}.
\]
Suppose the original war and peace menus and the reattached war and peace menus are each nonempty and bounded above. Strict reversal
\[
v(W_0)>v(P_0),\qquad v(W_1)<v(P_1)
\]
is equivalent to two actual witnesses with uniform positive gaps:
\[
\exists w\in W_0,\delta>0,\ \forall p\in P_0,\ u(p)+\delta\le u(w),
\]
\[
\exists p\in P_1,\varepsilon>0,\ \forall w\in W_1,\ u(w)+\varepsilon\le u(p).
\]
The forward direction selects an actual candidate inside the strict gap between frontiers. The reverse direction bounds the opposing frontier using the uniform gap. The suprema need not be attained. Empty, unbounded, attained, and strictly approached menus have their respective dispositions. (PE1)

Under incomplete observation \(\omega:\mathcal W\to\mathcal O\) (\(\mathcal W\) nonempty), write \(\mathcal F(s)=\{b\in\mathbb R:\exists a,\ \forall w\in\omega^{-1}(s),\ a\text{ is executable and }u(w,a)\ge b\}\) for local fibre floors and \(\mathcal P=\bigcap_s\mathcal F(s)\) for global prior-policy floors. When \(\mathcal P\ne\varnothing\) and every \(\mathcal F(s)\) is bounded above, the robust frontier satisfies
\[
\sup\mathcal P=\inf_{s\in\operatorname{range}(\omega)}\sup\mathcal F(s),
\qquad
b_*\in\mathcal P\ \Longleftrightarrow\
\forall s,\ \bigl(\sup\mathcal F(s)=b_*\Rightarrow b_*\in\mathcal F(s)\bigr),
\]
where \(b_*=\sup\mathcal P\). Inclusion \(\mathcal P\subseteq\mathcal F(s)\) gives \(\le\); any strict gap \(c\) would lie below \(\sup\mathcal F(s)\) on every fibre and hence inside every \(\mathcal F(s)\) by downward closure, placing \(c\in\mathcal P\), a contradiction. Non-binding fibres (\(b_*<\sup\mathcal F(s)\)) likewise contain \(b_*\) by downward closure, isolating attainment on binding fibres. (PE1)

For the same payable conflict word and peaceful benchmark, reattachment at rate \(\lambda\) yields the original margin \(m-\lambda T\) (\(T\ge0\)). The native three-party material control exposes private gain under negative-sum war and coalition stock invariance (`exact_native_material_controls`, `a_paid_return_has_exact_coalition_incidence`): peaceful stocks \((4,7,10)\) total \(21\), shifted war \((8,7,4)\) drops total social stock to \(19\) (net destruction \(-2\)) while giving the initiator \(+4=-2+6\) by externalising \(6\) units, and full reattachment \((2,7,10)\) conserves total post-war stock across the two coalitions at \(19\) while returning the \(-2\) loss to the initiator. Full reattachment strictly reverses the comparison exactly when \(0<m<T\). For a finite family, an eliminating rate \(\lambda\in[0,1]\) exists if and only if \(\lambda=1\) eliminates all positive margins; infeasibility holds if and only if some row has unshifted positive gain (\(T_i=0,m_i>0\), blocking every rate \(\lambda\)) or insufficient shift (\(0<T_i<m_i\)). When feasible, define
\[
\lambda_*=\max\bigl(\{0\}\cup\{m_i/T_i:T_i>0\}\bigr).
\]
For nonnegative rates, all margins are nonpositive exactly when \(\lambda\ge\lambda_*\); every smaller rate leaves a positive-margin candidate, and \(\lambda_*>0\) produces a binding tie on a positive-shift row. Strict negativity throughout holds if and only if every zero-transfer row already has \(m_i<0\) and every positive-transfer row has \(m_i/T_i<\lambda\) (equivalently \(\lambda>\lambda_*\) when \(\lambda_*>0\), whereas when \(\lambda_*=0\) strict negativity already holds at \(\lambda=0\); `strict_exclusion_exact`, `strict_after_positive_minimum`). When payment capacity caps payable rates at \(\lambda_{\mathrm{cap}}=\min_j c_j\in[0,1]\), payable war-eliminating rates form the exact closed interval \(\Lambda_{\mathrm{peace}}=[\lambda_*,\lambda_{\mathrm{cap}}]\) (`joint_interval`); whenever \(\lambda_{\mathrm{cap}}<\lambda_*\), every \(\lambda>\lambda_{\mathrm{cap}}\) incurs a named material shortfall while every \(\lambda\le\lambda_{\mathrm{cap}}\) leaves a positive war margin (`source_minimum_or_named_shortage`, `strict_source_rate_exists_iff`), establishing the judgment-proof obstruction where ex post liability alone cannot deter war. When authority or capacity changes with amount, the literal word is checked again at each rate and intersected with \(\lambda\ge\lambda_*\). (PE2)

### B.2 The exact production-period bound

Let \(c=(p,g)\) identify a payer and good. Write \(D_c\) for all original debt drawn on that cell, \(s_c\ge0\) for spendable stock after reserving production needs, and \(r_c\ge0\) for the actual net gain per period. For a finite original ledger,
\[
\exists n\in\mathbb N\ \forall c,\quad D_c\le s_c+nr_c
\quad\Longleftrightarrow\quad
\forall c,\ s_c<D_c\Rightarrow r_c>0.
\]
Under the condition on the right,
\[
n_*=\max_c\left\lceil\frac{D_c-s_c}{r_c}\right\rceil_+
\]
satisfies \(n\ge n_*\) exactly when stock at period \(n\) covers every debt. Cells already covered contribute zero. The proof applies the ceiling identity at each cell and takes the maximum over the finite ledger support. With original funding release and independent receipt channels, the construction selects the earliest actually funded cut, pays by original key, and restarts the same production from its retained inventory. (PE7)

### B.3 Both parties sign the same actual debit

Let \(n_0(p,g),n_y(p,g)\) be subsistence needs at the original cut and actual successor \(y\), and let \(m_0(p,g),m_y(p,g)\) be their maintenance needs, all read by the operative law. The dynamic protected reserve is
\[
R_y(p,g)=\max\{0,n_0(p,g),n_y(p,g)\}
        +\max\{0,m_0(p,g),m_y(p,g)\}.
\]
The condition \(R_y(p,g)\le s_y(p,g)\) holds exactly when the stock can be divided into nonnegative subsistence and maintenance shares, each covering both original and current needs. Compare the two maxima componentwise for the proof. The two services consume separate shares, and every actual intermediate inventory is checked this way. (PE16)

At an actual state \(x\) and original debt key \(k=(v,p,g)\), a positive rational payment \(q\) is funded when
\[
\begin{gathered}
v\ne p,\quad 0<q\le b_k(x),\quad
\operatorname{Valid}_x(\operatorname{pay}(k,q)),\\
\operatorname{Answer}_p(x,\operatorname{ord}(x),\operatorname{pay}(k,q))=\mathrm{true},\\
\operatorname{Answer}_v(x,\operatorname{ord}(x),\operatorname{pay}(k,q))=\mathrm{true},\\
\forall z,g',\quad
s_{\operatorname{pay}(x)}(z,g')\ge
\operatorname{Required}_x(\operatorname{pay}(x))(z,g').
\end{gathered}
\]
Both answers read the same ledger resident, actual ordinal, current stock, and literal transfer. The dynamic reserve is evaluated at the actual post-payment state. The executable checking entry takes a finite enumeration covering every address it checks; the mathematical payment construction can also consume the fundedness proof directly.

On success the allocator consumes the position just written and produces
\[
b_{k'}(x')=b_{k'}(x)-\mathbf1_{\{k'=k\}}q.
\]
All original addresses remain. A production revision first obtains the affected original parties' approval and executes its trial; the trial's output then enters the actual inventory checked for payment. Refusal, unauthorized action, overpayment, and material shortage each generate an original-ledger successor with a specific reason. (PE16–PE17)

Let \(\mathcal A_k(x)\subseteq\mathbb R\) be the embedded set of all funded rational amounts and let \(q_*=\sup\mathcal A_k(x)\). When nonempty, \(q_*\le b_k(x)\) is its exact upper bound. Attainment generates the actual payment. Nonattainment generates, for every \(\epsilon>0\),
\[
q_*-\epsilon<q<q_*,
\]
together with the actual successor for \(q\). The empty case supplies a named refusal for every amount. If the full original balance is funded, \(q_*=b_k(x)\) and the construction selects it. (PE18)

**A receipt cannot be credited twice.** The first component of each actual receipt address is the ordinal at its creation. At step \(n\) of any dispatch history, the ordinal is \(\operatorname{ord}(x_0)+n\). Reusing one receipt at \(i<j\) would make its address equal to two different natural numbers. Production revisions and refusals also consume their own ordinals, so the argument covers every interleaving of the three submission classes. (PE17)

## C. The actual settled state and the open language

### C.1 Opening peace from actual inventory

At the settled state \(x_*\), check a common production word \(w\) and an independent exit word \(e_p\) for every listed participant. The checks include registration, itemwise authorization, original and current subsistence and maintenance floors, nonnegative accumulation with at least one positive net gain, and positive actual duration \(q>0\). Repetition uses certified stability: shifting the clock does not change action effects, adding nonnegative reserves preserves operative rules and registration, and duration is preserved under these transformations.

Successful checks generate the running entry from the entire original ledger, actual stocks, and operative production rule at \(x_*\); initial language coverage is empty. Taking \(x_*\) as the common reserve base, for every public-history-driven strategy \(\pi\) and every \(n\), the next transition actually produces, pays subsistence, preserves each independent exit and every settled original row, emits zero new loss at every actual item, and strictly increases at least one stock coordinate. For every starting cut \(a\) and elapsed number of rounds \(n\),
\[
t_{a+n}\ge t_a+nq.
\]
This gives clock cofinality after every cut. (PE13, PE19)

The original six-unit consumer has debt-material inventories, written as “victim/payer,”
\[
(111,113)\xrightarrow{\text{approved new-rule trial}}(115,117)
\xrightarrow{\text{six-unit delivery signed by both}}(121,111).
\]
The trial and settlement states both have clock \(5\). The payer's actual \(111\) directly enters the continuation and exit checks. The original address
\[
a_0=(2,0,(\mathrm{false},\mathrm{true},\mathrm{false}))
\]
remains with zero balance. The first paid proposal starts at clock \(5\), exposing a protected-term change and reaching clock \(6\). The second starts at clock \(6\), exposing removal of an original personal exit and reaching clock \(7\). Each pays half a unit of food. A third-meal counterexample identifies the payer's food shortage \(0<1\) at actual position \(2\), retaining the same settled ledger. (PE19)

The earlier PE14 consumer uses a different settled entry: personal exit is exposed first and public terms second. Both visits likewise debit half a unit and retain the original debt address. Each history retains its own order.

### C.2 Expressive failure, least extension, and anti-fragile invariants

The effect type includes “an originally payable named continuation ceases to be payable under the proposed rule” and “a protected public term changes.” Effects are determined at the actual pre-state of the paid visit and its literal proposed rule. Two candidate institutions can share the exact same zero-debit old offer word `oldOfferWord` or identical old tariff quote while one preserves and the other strips an originally payable personal exit, so no classifier reading only the old word or old quote can detect stealth capture (\(\neg\exists\operatorname{classify},\ \forall q,\ \operatorname{classify}(\operatorname{obs}_{\mathrm{old}}(q))=\operatorname{losses}(P(q))\), `no_exact_loss_classifier`, `old_offer_word_cannot_classify_loss`). (PE11)

Represent the refusal language by \((\mathrm{Code}_n,D_n)\) with coverage \(C_n=\bigcup_{c\in\mathrm{Code}_n}D_n(c)\), and let \(E_n\) be the effects witnessed at round \(n\). A language revision is generated exactly when
\[
E_n\setminus C_n\ne\varnothing.
\]
Revision forms \(\mathrm{Code}_{n+1}=\mathrm{Code}_n\oplus\mathbf1\), embeds every old code with unchanged meaning \(D_{n+1}(\operatorname{inl}c)=D_n(c)\), and sets \(D_{n+1}(\operatorname{inr}())=E_n\setminus C_n\). Hence
\[
C_{n+1}=C_n\cup E_n,
\qquad
C_{n+1}\subseteq B\ \Longleftrightarrow\
C_n\subseteq B\ \land\ E_n\subseteq B.
\]
This is exact leastness of coverage. Induction from empty initial coverage gives
\[
e\in C_n\quad\Longleftrightarrow\quad \exists i<n,\ e\in E_i.
\]
Every new expression has an original paid witness, and each earlier exposure remains expressible. Over the full effect space \(\mathcal E\), the unsealed vulnerability set \(U_n=\mathcal E\setminus C_n\) shrinks strictly (\(U_{n+1}\subsetneq U_n\)) at every novel exposure (likewise shrinking strictly on the `Party × Good` sub-key domain of adaptive peace, bounding novel-exposure count whenever that key domain is finite), while preserving the entire native execution surface—so public compilation of every finite native word `word` and every participant–good productive gain remain identical. (PE10, PE12)

The ledger resident generated by this language write is exactly the resident used by the next material round. The same write carries original rows, rights to request, and budgets; the new direction enters with zero budget. The next production reads the original tariff and orders at this state. Least revision thus has both a semantic conclusion and an actual subsequent consumption. (PE13)

At every round the proposal syntax may depend on the round, public history, original clock, public terms, and current language. An interpreter maps that syntax into the same execution input; failed interpretation takes the original due continuation. Over this universally quantified strategy domain, the invariants and the equivalence for revision hold at every round. (PE11–PE13, PE19)

### C.3 The current source of an archived obstruction

Revision retains obstructions from all old supports in its archive. Let \(S\) and \(S'\) be the old and new support sets, with restriction map \(b:S'\to S\). An obstruction \(o\) at old support \(s\) has archive address \((s,o)\). For an active new support \(a\),
\[
(s,o)\text{ is a current local obstruction}
\quad\Longleftrightarrow\quad s=b(a).
\]
Necessity reads the first component of the archive address. For sufficiency, equality of the supports lets the same original obstruction serve locally. The complete archive persists, while the next actual disposition is generated by an obstruction at the active support's restriction. (PE13)

## D. Review costs, zero-fee erasure, privacy, and delayed evidence

Fix filing work and per-request review work at an actual public cut. Each work item is checked for authorization, debit bearer, and material flow. Sum the actual per-good debits of these admissible procedures to obtain the charge vector \(c\). For any fully covering charge vector \(b\),
\[
b_g\ge\operatorname{cost}_g\quad(\forall g)
\quad\Longrightarrow\quad c_g\le b_g\quad(\forall g),
\qquad c_g=\operatorname{cost}_g.
\]
Leastness is relative to these checked work procedures. The original dispatcher preserves the common production slot, so this tariff's production-slot opportunity component is zero. A positive filing amount, valid payment order, and common budget admit a single debit at the next actual material position; insufficient funds or a charge exhausting the productive gain takes the original production continuation. (PE15)

Against ordinary continuation at the same clock, each paid review has strictly negative material payoff for its actual payer under every strictly positive per-good weighting. Splitting a submission into paid fragments counts each original ordinal once and repeats the filing charge for each fragment; routing an already covered scope through a distinct proxy payer (`delegated.payer` \(\ne\) `levy.signer`) likewise debits the half-unit food fee from the actual payer and returns the fixed refusal without opening a second review (`a_different_filer_cannot_reopen_the_same_scope`). Presentations producing no actual charge can be erased from the entire infinite state–observation trace without changing any action-facing information fibre; any changed readout traces back to an earlier actual material write authorised by its payer. (PE8–PE10)

**Two-history prepayment privacy (PE9, PE21).** Compare two actual openings with the same reserve base, tariff, and payment/proposal orders. Hidden inventories above that base and private qualification answers may differ. Fix the same public strategy and require the same public due agenda whenever observations agree. Every prefix before an actual charge has the same public transcript and language. The first new distinction requires the same bill to have been actually debited on both sides.

Induction on the prefix proves this result. Common observation and agenda select the same input and payment branch. Before payment, both replies equal the original public agenda and both languages persist. If the next prefixes differ, the unpaid branch is impossible, so both visits have receipts for the same literal bill. The theorem locates the first difference at actual payment while retaining each side's actual successor.

Across rebases, a shared reserve relation retains the original stock lower bound, financial claims, and technology coordinates. The refresh acknowledgement factors through the pre-write agenda, whose announced landing clock equals the actual landing clock. If the new published supply terms differ, the actual production words executed on the two sides differ; new supply terms are released with actual production. (PE25)

**Delayed evidence on the original payment (PE20, PE25).** When charging has occurred but coverage evidence remains incomplete, retain the original receipt, exact effect scope, and actual material successor. Completed evidence reads that scope at the state actually reached. If it is already covered, the successor is that same state and there is no new language write. Otherwise the least extension is written there. Read paths across actual due payments and rebases preserve the same original scope; completion consumes the original receipt. Completion uses the existing payment without charging the original review fee again; its original orders remain evidence of that paid occurrence.

A finite adaptive duration observation cannot determine all protected terms or decide the paid scope: for any adaptive reader querying durations on a finite step set \(S_Q\), set the diagonal clock \(t^\dagger=\max(\{0\}\cup\{\tau(s):s\in S_Q\})+1\) and keep the original readings on \(S_Q\) while altering a protected term at \(t^\dagger\), yielding an institution with identical \(S_Q\)-observations and a nonempty paid scope (`every_finite_duration_reader_has_a_hidden_protected_change`, `no_finite_duration_reader_decides_the_paid_scope`). This diagonal construction identifies the exact object for which evidence is still needed. (PE20)

## E. Continuation before settlement, generated production words, and the nine-stage deployed track

At an unsettled state with a checked continuation recipe, each round first executes current subsistence and independent exits, then reads a payment or production-revision request. For every adaptive strategy and finite waiting period, original addresses persist, refusal retains debt, and physical time satisfies \(t_n\ge t_0+nq\). When both signatures arrive later, payment is checked against that round's actual inventory after the due step. Sufficient stock pays the original debt and the settled state enters the network directly. (PE23)

Production repair checks registered recipes first, followed by one round of named edits. Given a finite original registered alphabet and a finite participant roster, after both layers are exhausted it jointly searches for a common production word \(w\) and each person's exit word \(e_p\). Define width by
\[
\operatorname{width}(w,(e_p))=
\max\bigl(|w|,\max_{p\in P}|e_p|\bigr).
\]
At a fixed current state every finite width is completely checked. A fresh feasible joint recipe exists exactly when search succeeds at some finite width. The first successful width carries named obstructions at every narrower width. For the proof, place any feasible recipe in its finite width layer; rejection of that layer directly contradicts its production or personal-exit conditions. (PE24)

The running entry also checks actual duration, its registered basis, and the current search window. A feasible word within the window forces the first successful-width actual production write. Exhausting the window still pays the original due step and retains the checked layers' obstructions. Actual ordinals make the available width unbounded. In the original six-unit deployment, an empty-word failure at clock \(7\) leads to the generated width-four write at clock \(8\), increasing each person's debt material by two. From the same post-trial state (`source`, clock \(5\), debt \(6\)), `Deployment.{Facade,Ingress}` advances deterministically through `due` (clock \(5\to6\), debt \(6\)), `refusal` (clock \(6\), debt \(6\)), `settlement` and `installation` (clock \(6\), debt \(0\)), `pendingReview` (clock \(7\)), and `rebase` (clock \(8\)): from there, the unwaited batch schedule (`Facade.Stage`) immediately executes `revision` at clock \(8\) (admitting evidence only once) and five `renewal` rounds to clock \(13\) (matching all \(13\) local observations between batch and stepwise processes), whereas the persistent online entry (`Ingress`) runs two waiting due steps across clocks \(9\)–\(10\) (`waiting 1, 2`), cold-recovers and writes U8 at clock \(10\) (`revised 2 0`), and completes two renewals across clocks \(11\)–\(12\) (`revised 2 2`, cursor \(11\)) to produce the exact clock-\(12\) parent head (`013bd261...`) sealed for four-host admission. Both schedules and the immediate-revision branch in C.1 (clocks \(5\to6\to7\)) retain separate literal identities from the same trial state. (PE24–PE26)

## F. External write-by-write factorization and historical identity

Let the original history consist of states \(x_n\) and actual writes \(w_n\). An external presentation supplies states \(y_k\) and optional writes \(e_k\). Set
\[
o(0)=0,\qquad
o(k+1)=o(k)+\mathbf1_{\{e_k\ne\varnothing\}}.
\]
The local check requires an empty write to preserve \(y_{k+1}=y_k\). A nonempty write must be exactly \(w_{o(k)}\) and land at \(x_{o(k)+1}\). A common origin and all local checks hold exactly when there is a unique factorization \(f\) preserving states, writes, and ordinal recursion. Necessarily \(f=o\): induction from zero and increments of zero or one determines the index, and local-check induction determines the states. (PE8)

External progress
\[
\forall n\ \exists k,\quad n\le o(k)
\]
is equivalent to a unique first visit to every original cut. Without progress there is a last cut and all later writes are empty. Failed checks locate a foreign origin or the first mismatching write, retaining the already matching prefix.

Two direct counterexamples exhibit different failures. The first renews aggression after the common opening, then continually pays subsistence, retains settlement of the old rows, and has a cofinal clock; the renewed aggressive write differs from the original. The second merely reverses the order of two harmless supply sequences:
\[
(\mathrm{true},\mathrm{true},\mathrm{false},\mathrm{false})
\quad\hbox{and}\quad
(\mathrm{false},\mathrm{false},\mathrm{true},\mathrm{true}).
\]
The complete raw material states and clocks agree at every visit; independent exits remain, no new loss is opened, and the old ledger is cleared. Their actual-item orders differ, so they cannot factor through the same fixed order. Write identity retains information about actual occurrence that endpoint readings erase. (PE8)

## G. Ending war, unprioritized stall countermodel, independent renewal, and irreversible deadlines

For a given observation function, states with the same visible history form an observation fibre. A sustained protective strategy exists exactly when a protective family contains the opening and each reachable fibre has one shared civilian action whose every original opponent response remains in that family. The opponent may observe the civilian action before responding. Every opponent prefix admits an independent exit under the same strategy. At an intermediate position of a submitted civilian word, the checked suffix remains executable before a fresh exit is paid. Necessity takes the positions reachable under a successful strategy. Sufficiency chooses the shared action at each fibre and inducts on rounds. (PE4)

Each failed strategy has a finite first failure carrying the original whole ledger. With clock cofinality required, failure is exactly a finite first counterexample or a trajectory that passes every local visit while its original clock remains bounded. In the signed constitutional game, no civilian strategy forces ceasefire and withdrawal completion if and only if every signed policy suffers an allowed-play dead end, a finite joint breach, or indefinite unpaid delay; dual to \(\exists\pi\,\forall\alpha\), whenever one uniform opponent policy defeats every signed civilian policy (\(\exists\alpha\,\forall\pi\)), tick \(t_*+1\) immediately following the first attack automatically files a live original reparation row in the whole ledger (`the_uniform_attacker_files_the_first_original_loss_against_every_signed_policy`). (PE4–PE5)

Under the installed emergency law, admitted withdrawal, a closed protective observation family, and nonempty lawful local menus, choose one strategy before quantifying over opponents and lawful interleavings. Under priority scheduling, a checked literal commitment with \(N\) original pending entries and body length \(\ell\) completes at visit \(N+\ell\) with absolute endpoint clock independent of competing interleavings. Conversely, without priority scheduling, when pending work exists and review is available, lodging withdrawal at tick \(0\) followed by `stopReview` from the opponent at every tick \(\ge1\) emits an empty material inventory forever and keeps the clock at \(\tau_0<\tau_0+1\), leaving withdrawal incomplete at every tick. After revocation, subsequent authority exists if and only if an actual independent renewal record exists; no single signer can regenerate it alone. A continuously refusing exposed bearer retains their stocks, reparation rows, and released mandate against any adaptive coalition, and any subsequent paid controlled action traces back to an earlier paid `.propose` item by a task member and each original bearer's affirmative `true` answer at that material grant item. (PE5)

Emergency authorization checks every rational candidate expiry against actual issuance, service, both independent review payments, and each personal exit, producing the feasible domain and its earliest and latest frontiers. The PE22 consumer issues at clock \(1\), expires at \(3\), and serves through \(4\) with two unit review payments; missing the second payment or a personal exit produces distinct named refusals. Once \(T_{\mathrm{dead}}<t_x\), because no lawful original script runs the physical clock backwards, every subsequent input suffix preserves \(T_{\mathrm{dead}}<t_y\) and permanently refuses every `.propose`, `.accept`, `.renew`, and protected `TaskUse` item without possibility of reset. (PE5, PE22)

## H. Fixed versions and proposition correspondence

The source root is `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/`, abbreviated **C**. Further abbreviations are `T=C/Constitution/TerminalPeace`, `U=T/Universal`, `F=U/Terminal/FixedPoint`, `O=F/OpenPeace`, `J=U/Terminal/Productive/Clearance/Joint`, `X=J/Reinterpreted`, `R=O/Network/Runtime`, and `E=C/Emergency/Installation`. Module and declaration names below are exact source identifiers.

| Fixed group | Homework version | Original acceptance identity |
| --- | --- | --- |
| [PE1–PE10](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/Terminal.lean) | `7e4da746f300b3796b8b18afb26cb0765c29afcb` | Separate original receipts for reparations, sustained stopping, cofinality, joint settlement, prepayment, and adaptive revision |
| [PE11–PE14](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/OpenLanguage.lean) | `b675168bda8f52a6565a8db3617e262daa738bb0` | Open language `4dc2e25393`, network first write `369df502de`, recursion `4caa9fd0a2` |
| [PE15–PE22](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace/ActualClearance.lean) | `71cb159f4f0727d8fb67e7a436a1476e03a0d913` | Actual work `b867cdf377`, reinterpreted settlement `5c649ff440`, actual reserve base `71cb159f4f` |
| [PE23–PE26](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Papers/EnforceablePeace.lean) | `3a90cba5ac7427737ee2fe630612dfed43e45da1` | Interleaved due `46afb0dec1`, deployment `f3014e5e63`, generated production `c58d788478`, joint refresh `f4578baa82` |
| Intake ceiling | `cf880bb282f0ff28d6e9f9fc890341baaa8b0eb0` | PE27–PE33 execution, recovery, and disposition are mapped in the execution appendix |

### H.1 Producing declarations, direct consumers, and decisive comparisons

| PE | Producing declaration or proof | Direct consumer and use |
| --- | --- | --- |
| 1 | `C/Choice/Frontier.lean`: `strict_flip_iff`; `C/Choice/Robust.lean`: `robust_frontier_eq_worst_observation`, `robust_frontier_attained_iff_binding_fibers_attain`; `C/Root/{Menus,History,Cofinal,Policy,Restitution}.lean`: `a_paid_return_has_exact_coalition_incidence` | `C/Consumers/{Menu,Timing,Native}.lean`: `exact_native_material_controls`, \(+4,0,-2\) at the same cut, totals \(21/19/19\), and observation-fibre guarantees |
| 2 | `C/Threshold/Reattachment.lean`: `exact_upper_ray`, `no_admissible_rate_exact`, `any_positive_unshifted_blocks_every_rate`, `strict_exclusion_exact`; `C/Threshold/Capacity.lean`: `joint_interval`, `source_minimum_or_named_shortage`, `strict_source_rate_exists_iff`; `C/Root/RateDomain.lean` | `C/Consumers/{Native,Exact,Endpoint}.lean`: original slot, attained \(2/3\), capacity interval, judgment-proof obstruction, and overstock/repeated-settlement refusal |
| 3 | `C/Reparation/Actual/Root/Batch.lean`: `every_affected_address_is_filed_on_the_same_generated_next`; `Run/Conservation.lean`: `the_original_whole_ledger_conserves_each_material_good`; `T/Material/{Payer,ReceiptAccount,Outstanding}.lean`: `after_the_payer_returns_six_the_original_six_is_still_in_the_whole_account`, `the_victims_receipt_really_closes_the_old_six_and_writes_the_reverse_six`, `every_original_history_keeps_or_increases_outstanding_reparation`; `U/Protection/Guard.lean`: `the_guard_forwards_exactly_the_safe_original_requests` | `Consumers/{Joint,Registration}.lean`; `C/Reparation/Consumers/ActualDamage.lean`; double unilateral deadlock and widest safe guard `any_safe_original_admission_is_contained_in_the_guard` |
| 4 | `C/Constitution/Peace/Contract.lean`: `sustainable_civilian_peace_iff_one_move_protects_each_reachable_observation_fibre`; `a_cofinal_policy_fails_iff_first_counterexample_or_an_original_clock_bound` | Root, Failure, and Shortage in the same directory: actual opponent prefixes, first failure, and independent exit |
| 5 | `C/Constitution/ForcePeace/Contract/{Root,Delay,Defeat,Adversary}.lean`: `peace_is_enforceable_and_war_authority_cannot_be_unilaterally_reborn`, `a_lodged_withdrawal_has_an_actual_infinite_delay_without_priority`, `no_civilian_strategy_forces_peace_iff_each_signed_policy_has_an_original_obstruction`, `the_uniform_attacker_files_the_first_original_loss_against_every_signed_policy`; `ExposureGuard/Contract/Root.lean`; `C/Civil/Mandate/Root.lean`; `Commitment/Timing.lean`: `initial_native_rank_and_body_length_give_the_sharp_bound` | `ExposureGuard/Commitment/Consumers/Installed.lean`; `ExposureGuard/Consumers/Renewable/Dispatcher.lean`: coalition refusal invariants, uniform-adversary auto-filing, and revival proposal trace |
| 6 | `U/Runtime/Viability/Strategy.lean`: `live_iff_cofinal_trajectory`; `U/Terminal/Whole.lean`: `simultaneous_clearance_is_generated_exactly_when_a_live_original_prefix_pays_every_row`; `T/Root.lean`: `the_original_source_has_independent_material_and_receipt_obstructions`; `T/Renewal/Cofinality.lean`: `the_due_service_cannot_be_delayed_past_the_pending_queue`, `the_first_crossing_of_each_open_hour_is_paid` | `T/Completion/Root.lean`: `source_generated_terminal_peace`; visit-\(4\) compulsory convergence, unique peace tail, anti-filibuster hourly step, and unilateral \(\ge6\) bound |
| 7 | `U/Terminal/Productive/Clearance/Budget.lean`: `fundingCycles_le_iff_funds`; `Compiler.lean`: `finite_original_losses_are_cleared_by_production`; `J/Compiler.lean`: `compileJoint_pays_iff` | `Clearance/Consumers/OriginalBatch.lean`; `J/Consumers/Settlement.lean`: reversed exchange is short by six |
| 8 | `F/{Compiler,Closure}.lean`; `U/External/Trace.lean`: `exact_local_checks_iff_unique_factor`; `U/External/Frontier.lean`: `progress_iff_every_original_cut_has_unique_first_visit` | `F/NoFreeProbe/Prepayment/Consumers/JointOpening.lean`; `U/External/Countermodel/{Cofinal,SafeOrder}.lean` |
| 9 | `F/NoFreeProbe/Influence.lean`: `zero_tenders_leave_every_information_fibre_unchanged`, `any_changed_read_traces_to_a_payers_actual_write`; `RepeatedCharges.lean`; `Prepayment/Run.lean`: `locate_the_first_paid_distinction` | `Prepayment/Consumers/{Original,JointOpening}.lean`: half-unit prepayment; a charge exceeding net gain takes the same renewal |
| 10 | `F/AdaptivePeace/Contract.lean`: `every_novel_attack_generates_stronger_peace`, `Step.strictly_shrinks_unsealed`, `Step.keeps_every_native_word`; `History.lean`: `coverage_has_exactly_its_original_paid_witnesses`, `an_old_scope_cannot_open_another_review` | `AdaptivePeace/Consumers/{Original,JointOpening}.lean`: `a_different_filer_cannot_reopen_the_same_scope`, original levy repair, paid resubmission, and proxy-filer defence |
| 11 | `O/Boundary.lean`: `paidLosses_eq`, `no_exact_loss_classifier`, `old_offer_word_cannot_classify_loss`; `O/{Ingress,Dispatch,Payment}.lean` | `O/Consumers/Original.lean`: `a_new_policy_removes_an_exact_paid_exit_from_the_same_word`, `the_old_quote_does_not_classify_the_new_continuation_loss` |
| 12 | `O/Language.lean`: `least_repair_iff`, `denotes_inherited`, `denotes_fresh`; `O/Repair.lean`; `O/Universal.lean`: `open_future_permanent_peace` | `O/Consumers/JointOpening.lean`; `O/Network/Compile.lean`: the original paid witness for every expression |
| 13 | `R/Advance.lean`: `next_reads_generated_first_write`; `R/History.lean`: `the_revised_resident_drives_the_next_material_write`, `history_is_living_and_peaceful`, `history_clock_bound`; `R/LocalU7.lean`: `archived_obstruction_is_local_iff` | `R/Consumers/Original.lean`: the revised resident drives the second material write |
| 14 | `O/Network/Consumers/Original.lean`; `R/Consumers/Original.lean`: `two_paid_gaps_reenter_the_material_dispatcher` | Two half-unit debits; covered resubmission, wrong signer, and stale-order comparisons |
| 15 | `F/NoFreeProbe/Pricing/Quote.lean`: `the_generated_fee_is_the_least_full_charge`; `Pricing/Entrance.lean`: `installation_reads_the_same_cost_at_every_epoch` | `Pricing/Consumers/{Work,Original}.lean`: checked work, insufficient payment, and original production |
| 16 | `J/Revision/{Reserve,Technology,Protected,Portfolio}.lean`; `O/Operational/Certificate.lean`: `verifyPrepared_accepts_every_admissible_word` | `O/Operational/Consumers/{Certificate,OriginalInventory}.lean`: full paid word and alternative ordering |
| 17 | `X/Funding.lean`: `checkFunding_exact`; `X/Payment.lean`: `PaidWrite.whole_successor`; `X/History.lean`: `every_history_preserves_its_original_addresses`, `no_receipt_can_be_booked_again_in_the_same_history` | `X/Consumers/{OriginalTrial,OriginalPayment,OriginalSource}.lean` |
| 18 | `X/Amount.lean`: `paymentUpper_is_exact`, `resolve_selects_the_funded_full_balance` | `X/Consumers/OriginalPayment.lean`: full six-unit payment and victim refusal retaining the original debt |
| 19 | `X/Network.lean`: `opens_network_at_the_original_resident`; `X/Renewal.lean`; `R/History.lean` | `X/Consumers/{OriginalNetwork,OriginalRevision/Repeated,OriginalShortage}.lean` |
| 20 | `R/Decision/Pending.lean`: `pending_completion_uses_the_posted_receipt`; `R/Decision/Observation.lean`: `every_finite_duration_reader_has_a_hidden_protected_change`, `no_finite_duration_reader_decides_the_paid_scope` | `R/Decision/Consumers/{Original,Pending}.lean`: diagonal undecidability and same-receipt completion |
| 21 | `R/Privacy/History.lean`: `every_unpaid_prefix_keeps_the_transcript_and_language`, `a_new_distinction_requires_the_same_actual_payment_on_both_sides` | The actual common reserve from PE19 and both histories' actual continuations |
| 22 | `E/Protection.lean`: `protected_frontier_exact`, `shortest_protected_exact`, `longest_protected_exact`; `C/Emergency/Horizon.lean`: `no_reset_on_any_original_successor`, `no_authority_after_a_crossing`; `E/{Calendar,Envelope,Solver,Publication,Lifecycle}.lean` | `E/Consumers.lean`: clocks \(1,3,4\), two actual review payments, missing exit, and post-crossing refusal |
| 23 | `X/Scheduled/{Due,Motion,History}.lean`: `writeDue`, `every_round_consumes_the_original_successor`, `the_unsettled_clock_is_cofinal` | `X/Consumers/OriginalDue/Settlement.lean` |
| 24 | `O/Operational/Joint/Search.lean`: `search_is_complete_at_every_width`, `checked_prefixes_cover_every_finite_joint_recipe`; `R/Rebase/Completeness.lean`: `available_joint_production_forces_the_first_write` | `T/Deployment/Replacement.lean`: width-four first write and width-one due-payment comparison |
| 25 | `R/Decision/Deferred/Transport.lean`: `Deferred.completion_along_reads_the_same_original_scope`, `Deferred.covered_paid_scope_does_not_write_twice`; `R/Rebase/Privacy.lean` | `X/Consumers/OriginalRevision/{Rebase,Mixed}.lean`; `T/Deployment/Continuation/Waiting.lean` |
| 26 | `Lean/SaturationMonoid/Tracks/LivingLawTerminalPeaceInstance.lean`; `T/Deployment/{Facade,Ingress,Continuation/Waiting}.lean` | `Lean/scripts/{living_law_runtime,terminal_peace_worker}.py`: batch clocks \(5\to13\) (\(13\) checks) vs persistent `Ingress` U8 write at \(10\) and four-host head at \(12\); original-ID readback and same-parent transactions |

PE1–PE33 public declarations and complete types. [public claim map](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-map.json) · [reproduction guide](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/docs/enforceable-peace-reproduction.md)

Supporting proofs at Homework `3a90cba5ac`. PE3 [Payer](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Material/Payer.lean) · [ReceiptAccount](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Material/ReceiptAccount.lean) · [Outstanding](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Material/Outstanding.lean) · [Guard](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Universal/Protection/Guard.lean). PE6 [Root](https://github.com/Sapientropic/H0mework/blob/2678896740481f6eb6fc248c38d86549a6b6911d/Lean/H0mework/Versions/R3a90cba5/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Conflict/Constitution/TerminalPeace/Root.lean).
