#!/usr/bin/env python3
"""Editable SVG diagrams for observation dynamics; render previews with CairoSVG.

All coordinates are editorial choices; numerical labels reproduce the
manuscript. Series visual language (shared/figure-style): no in-figure
headline, serif type, ink/grey structure, deep blue for generated objects,
gold for the second fine fibre, and one vermilion accent per figure. The
canvas is 1100 px wide and prints at about 6 in, so no text is below 19 px.
"""
from pathlib import Path
from html import escape
import json
import math
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, GOLD, WASH  # noqa: E402
from svg_text import line, text_width, register_cjk_for_cairo  # noqa: E402

W = 1100
MIN_SIZE = W / 60


class SVG:
    def __init__(self, height, title, desc):
        self.h, self.boxes = height, []
        markers = ''.join(
            f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
            f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>' for n, c in [('ink', SLATE), ('acc', VERMILION)])
        self.parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" viewBox="0 0 {W} {height}" role="img">',
                      f'<title>{escape(title)}</title><desc>{escape(desc)}</desc>', f'<defs>{markers}</defs>',
                      f'<rect width="{W}" height="{height}" fill="white"/>']

    def text(self, x, y, s, size=20, fill=INK, anchor='start', bold=False):
        assert size >= MIN_SIZE - 1e-9, (s, size)
        width = text_width(str(s), size, MIN_SIZE)
        x0 = x - {'start': 0, 'middle': width / 2, 'end': width}[anchor]
        self.boxes.append((x0, y - .82 * size, x0 + width, y + .22 * size, str(s)))
        self.parts.append(line(x, y, str(s), size, fill, 600 if bold else 400, anchor, min_size=MIN_SIZE))

    def line(self, x1, y1, x2, y2, color=SLATE, width=2, arrow=False, dash=False):
        marker = f' marker-end="url(#arrow-{"acc" if color == VERMILION else "ink"})"' if arrow else ''
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"'
                          + marker + (' stroke-dasharray="6 6"' if dash else '') + '/>')

    def rect(self, x, y, w, h, fill='none', stroke=HAIR, radius=4, width=1.6):
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')

    def ellipse(self, x, y, rx, ry, stroke=HAIR, fill='none', width=1.8):
        self.parts.append(f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')

    def point(self, x, y, label='', color=DEEP, r=7, size=19):
        self.parts.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}"/>')
        if label:
            self.text(x, y + r + 21, label, size, anchor='middle')

    def polyline(self, pts, color=DEEP, width=2.4, dash=False):
        coords = ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)
        self.parts.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="{width}"'
                          + (' stroke-dasharray="7 5"' if dash else '') + '/>')

    def polygon(self, pts, fill=WASH, stroke='none', width=1.0):
        coords = ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)
        self.parts.append(f'<polygon points="{coords}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')

    def save(self, name):
        for i, a in enumerate(self.boxes):
            assert a[0] >= 6 and a[2] <= W - 6 and a[1] >= 4 and a[3] <= self.h - 4, ('outside canvas', a)
            for b in self.boxes[i + 1:]:
                if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                    raise AssertionError(('text overlap', a[4], b[4]))
        (ROOT / (name + '.svg')).write_text('\n'.join(self.parts + ['</svg>']), encoding='utf-8')
        return name


names = []

# 1. Accent: the trajectory that leaves the common fibre (s1 -> s2, next o = 1).
s = SVG(510, '图1 同一读数，不同下一拍',
        '左：例2.1中当前读数同为o=0的两个实际状态在原作用后分入不同读数格。右：例1.2(a)中位置2上的单位信号在位置1、3的空间采样为零，但完整响应由(7,13)推进至(9,18)与(11,21)。')
s.text(40, 40, '观察纤维分裂（例 2.1）', 22, bold=True)
s.text(580, 40, '位置 2 单位信号（例 1.2a）', 22, bold=True)
s.line(545, 20, 545, 490, color=HAIR, width=1)
s.ellipse(140, 268, 78, 125, fill=WASH)
s.text(140, 122, '当前 {i:o} = 0', 20, anchor='middle')
s.point(140, 228, '{i:s}{sub:0}')
s.point(140, 318, '{i:s}{sub:1}', VERMILION)
s.ellipse(410, 188, 66, 60)
s.ellipse(410, 372, 66, 60, stroke=VERMILION, width=2.4)
s.text(410, 108, '下一拍 {i:o} = 0', 20, anchor='middle')
s.text(410, 462, '下一拍 {i:o} = 1', 20, fill=VERMILION, anchor='middle')
s.point(410, 182, '{i:s}{sub:1}')
s.point(410, 366, '{i:s}{sub:2}', VERMILION)
s.line(152, 225, 392, 185, arrow=True)
s.line(152, 323, 392, 362, color=VERMILION, width=2.4, arrow=True)
s.text(264, 184, '原作用 {i:A}', 20, fill=SLATE, anchor='middle')
for y, title, spike in [(170, '当前（{i:t} = 0）', 2), (330, '下一拍（{i:t} = 1）', 3)]:
    s.text(580, y - 70, title, 20, bold=True)
    s.line(610, y, 1060, y, color=MUTE)
    for k in range(5):
        x = 640 + 100 * k
        s.line(x, y - 5, x, y + 5, color=MUTE)
        s.text(x, y + 30, k, 19, fill=SLATE, anchor='middle')
        if k in [1, 3]:
            s.ellipse(x, y, 15, 15, stroke=SLATE, width=1.6)
    x = 640 + 100 * spike
    s.line(x, y, x, y - 54, color=DEEP, width=4)
    s.point(x, y - 54, r=6)
    s.text(x + 14, y - 50, '1', 19, fill=DEEP)
s.text(580, 412, '空间采样　(0, 0) → (0, 1)', 20)
s.text(580, 446, '质量 1，时钟 3 → 4 → 5', 20)
s.text(580, 482, '完整响应　(7, 13) → (9, 18) → (11, 21)', 20, bold=True)
names.append(s.save('01-observation-fibres'))

# 2. Accent: the third frame, the last independent equation.
s = SVG(435, '图2 最后一条独立方程',
        'a=n=2时位置2单位信号的全列响应矩阵：三帧消去h1恢复四个空间坐标及独立的质量与时钟；两帧不足以在整个载体上支持任意自主更新。')
s.text(40, 40, '全列响应（固定原观测器）', 22, bold=True)
s.text(228, 88, '{i:j} = 0', 20, anchor='middle')
s.text(362, 88, '{i:j} = 1', 20, anchor='middle')
for t, row in enumerate([(7, 13), (9, 18), (11, 21)]):
    y = 108 + t * 78
    s.text(70, y + 42, '{i:t} = ' + str(t), 20)
    for j, val in enumerate(row):
        x = 170 + j * 134
        if t < 2:
            s.rect(x, y, 115, 64)
        else:
            s.rect(x, y, 115, 64, fill=WASH, stroke=VERMILION, width=2.4)
        s.text(x + 57, y + 43, val, 30, fill=VERMILION if t == 2 else INK, anchor='middle', bold=t == 2)
s.text(40, 372, '两帧：至多 4 个独立标量', 20)
s.text(40, 408, '目标：4 个空间坐标 + 质量 + 时钟 = 6', 20, bold=True)
s.line(456, 218, 540, 218, arrow=True)
s.text(498, 198, '解码', 20, fill=SLATE, anchor='middle')
s.text(575, 40, '三帧消元解出全部可见坐标', 22, bold=True)
s.text(575, 96, '{i:m} = (21 − 7 − 11) / 3 = 1', 24)
s.text(575, 132, '7 与 21 同含 {i:h}{sub:1}，相减消去空间项', 19, fill=SLATE)
s.text(575, 178, '{i:c} = (11 − 1) / 2 − 2 = 3', 24)
s.text(575, 214, '第 3 帧首列的源下标为 −1，空间项为 0', 19, fill=SLATE)
for k in range(4):
    x = 620 + k * 114
    s.ellipse(x, 294, 36, 36, stroke=DEEP)
    s.text(x, 305, int(k == 2), 28, fill=DEEP, anchor='middle')
    s.text(x, 362, '{i:h}{sub:' + str(k) + '}', 22, anchor='middle')
names.append(s.save('02-minimum-window'))

# 3. Accent: the newborn participant 4, identical on both paths.
s = SVG(560, '图3 合并与更新到达同一完整接收态',
        '两条互不相交细纤维中的四个实际参与者，随后参与者4出生。先合并后更新与先更新后合并得到同一计数、后验与完整坐标矩。')


def cloud(svg, cx, cy, merged, born):
    pts = [(-74, -8, '0', DEEP), (-30, 20, '2', DEEP), (38, -8, '1', GOLD), (78, 20, '3', GOLD)]
    if born:
        pts.append((-44, -44, '4', VERMILION))
    if merged:
        svg.ellipse(cx, cy, 132, 72, stroke=SLATE, fill=WASH)
    else:
        svg.ellipse(cx - 54, cy - 4, 56, 72, stroke=DEEP, width=1.6)
        svg.ellipse(cx + 58, cy + 6, 46, 60, stroke=GOLD, width=1.6)
    for dx, dy, label, col in pts:
        svg.point(cx + dx, cy + dy, label, col, r=7 if label != '4' else 10)
    svg.text(cx, cy + 104, ('计数 ' + ('5' if born else '4')) if merged else ('计数 3, 2' if born else '计数 2, 2'), 20, anchor='middle')


cloud(s, 248, 140, False, False)
cloud(s, 846, 140, False, True)
cloud(s, 248, 375, True, False)
cloud(s, 846, 375, True, True)
s.text(248, 40, '细读数格', 22, anchor='middle', bold=True)
s.text(846, 40, '细读数格 + 新生参与者', 22, anchor='middle', bold=True)
s.line(398, 138, 685, 138, arrow=True)
s.text(541, 118, '实际收据：参与者 {v:4}', 20, anchor='middle')
s.line(248, 256, 248, 290, arrow=True)
s.text(232, 280, '合并', 20, fill=SLATE, anchor='end')
s.line(846, 256, 846, 290, arrow=True)
s.text(862, 280, '合并', 20, fill=SLATE)
s.line(398, 375, 685, 375, arrow=True)
s.text(541, 355, '同一收据，粗读数', 20, anchor='middle')
s.text(550, 535, '{i:C}{sub:z} {i:r}{sub:z} = Σ {i:c}{isub:y} {i:r}{isub:y}   →   {i:C}′{sub:z} {i:r}′{sub:z} = {i:C}{sub:z} {i:r}{sub:z} + {i:b}', 23, anchor='middle')
names.append(s.save('03-merge-update'))

# 4. Accent: the fine-to-coarse gap gGap (gain vector and the 1/5 bar).
s = SVG(485, '图4 同一任务，精确收益',
        '左：原加权L2中粗残差、细残差与细到粗条件均值差的正交分解。右：五参与者例的空间风险3/5与4/5，完整G新增损失1/5，两端时钟总风险均为8而新增时钟风险为零。')
s.text(40, 40, '原加权 {i:L}{sup:2} 中的正交分解', 22, bold=True)
s.line(90, 330, 343, 330, color=VERMILION, width=4)
s.line(343, 330, 343, 117, color=DEEP, width=4)
s.line(90, 330, 343, 117, color=INK, width=2.4)
s.rect(325, 312, 18, 18, fill='white', stroke=INK, radius=0, width=1.4)
s.point(90, 330, '粗均值 {i:ν}', VERMILION)
s.point(343, 330, '细均值 {i:μ}')
s.point(343, 117, '', INK)
s.text(362, 112, '任务 {i:Z}', 20)
s.text(196, 198, '粗残差 {i:Z} − {i:ν}', 19, fill=INK, anchor='end')
s.text(216, 314, '均值差 {i:μ} − {i:ν}', 19, fill=VERMILION, anchor='middle')
s.text(358, 230, '细残差 {i:Z} − {i:μ}', 19, fill=DEEP)
s.text(40, 446, 'Risk{sub:coarse} = Risk{sub:fine} + gGap', 26)
s.text(580, 40, '五参与者例，复制尺度 2', 22, bold=True)
s.text(580, 95, '空间风险', 20)
s.text(1060, 95, '单位：{i:G} 范数平方', 19, fill=SLATE, anchor='end')
s.text(580, 150, '细', 20)
s.rect(640, 120, 300, 45, fill=DEEP, stroke='none', radius=0)
s.text(790, 151, '3/5', 23, fill='white', anchor='middle', bold=True)
s.text(580, 230, '粗', 20)
s.rect(640, 200, 300, 45, fill=DEEP, stroke='none', radius=0)
s.rect(940, 200, 100, 45, fill=VERMILION, stroke='none', radius=0)
s.text(790, 231, '3/5', 23, fill='white', anchor='middle', bold=True)
s.text(990, 231, '1/5', 23, fill='white', anchor='middle', bold=True)
s.line(640, 272, 1040, 272, color=MUTE)
s.text(640, 300, '0', 19, fill=SLATE, anchor='middle')
s.text(1040, 300, '4/5', 19, fill=SLATE, anchor='middle')
s.text(580, 356, '完整新增损失 gGap = 1/5 > 0', 23, fill=VERMILION, bold=True)
s.text(580, 398, '新增时钟风险 0（两细格时钟均值均为 8）', 20)
s.text(580, 438, '两端时钟总风险均为 8；完整风险 43/5 → 44/5', 19, fill=SLATE)
names.append(s.save('04-exact-risk'))

# 5. Accent: odd-depth birth reversal and long-tail shifted-power retention reserve.
s = SVG(520, '图5 奇偶出生交替定律与完全单调移位幂律遗忘桥',
        '左：每个新生深度d比较旧材料(d+2)与新材料(d+3)的二值乘子，偶数深度改进新任务，奇数深度对旧任务产生严格恢复损失。右：异质指数衰减在Gamma测度混合下生成移位幂律保持曲线(1+t/r)^(-α)，图示取α=1并与同均值单一指数对比。')
s.text(40, 40, '奇偶出生交替恢复宇称律', 22, bold=True)
s.text(580, 40, 'Gamma 混合移位幂律保持曲线', 22, bold=True)
s.line(545, 20, 545, 500, color=HAIR, width=1)

s.text(48, 86, '深度', 19, fill=SLATE)
s.text(136, 86, '旧 / 新乘子', 19, fill=SLATE)
s.text(266, 86, '同任务最优比较与硬界', 19, fill=SLATE)
rows_5 = [
    (2, '0 / 1', '新任务优：旧码 ≥ 3/4', False),
    (3, '1 / 0', '旧任务损：新码 ≥ 4/5', True),
    (4, '0 / 1', '新任务优：旧码 ≥ 5/6', False),
    (5, '1 / 0', '旧任务损：新码 ≥ 6/7', True),
]
for idx, (d_val, bits, verdict, is_odd) in enumerate(rows_5):
    ry = 104 + idx * 72
    s.rect(40, ry, 482, 56, fill=WASH if is_odd else 'none',
           stroke=VERMILION if is_odd else HAIR, width=2.2 if is_odd else 1.5)
    col = VERMILION if is_odd else DEEP
    s.text(54, ry + 36, '{i:d} = ' + str(d_val), 20, fill=col, bold=is_odd)
    s.text(158, ry + 36, bits, 20, fill=INK)
    s.text(266, ry + 36, verdict, 19.5, fill=col, bold=is_odd)
s.text(40, 426, '偶 {i:d}（新任务）：Risk{sub:old} = Risk{sub:new} + gGap', 19.5, fill=DEEP)
s.text(40, 468, '奇 {i:d}（旧任务）：{v:Risk}{sub:new} = Risk{sub:old} + {v:gGap}', 19.5, bold=True)

s.text(1055, 76, '图示取形状 α = 1', 19, fill=SLATE, anchor='end')
px0, px1, py0, py1 = 635, 1055, 345, 104
s.line(px0, py0, px1, py0, color=SLATE, width=1.6)
s.line(px0, py0, px0, py1, color=SLATE, width=1.6)
s.text(px0 - 12, py1 + 8, '1', 19, fill=SLATE, anchor='end')
s.text(px0 - 12, py0 + 5, '0', 19, fill=SLATE, anchor='end')
for tk in [0, 4, 8]:
    tx = px0 + (tk / 8.0) * (px1 - px0)
    s.line(tx, py0, tx, py0 + 6, color=SLATE, width=1.4)
    s.text(tx, py0 + 26, str(tk), 19, fill=SLATE, anchor='middle')
s.text((px0 + px1) / 2, py0 + 54, '标度时间 {i:t} / {i:r}（半衰率点 {i:t} = {i:r}）', 19, fill=SLATE, anchor='middle')

for rate_c in [0.35, 2.2]:
    pts = [(px0 + (i / 80.0) * (px1 - px0), py0 - math.exp(-rate_c * (i / 10.0)) * (py0 - py1)) for i in range(81)]
    s.polyline(pts, color=HAIR, width=1.6, dash=True)
pts_exp = [(px0 + (i / 80.0) * (px1 - px0), py0 - math.exp(-(i / 10.0)) * (py0 - py1)) for i in range(81)]
s.polyline(pts_exp, color=GOLD, width=2.2, dash=True)
pts_pow = [(px0 + (i / 80.0) * (px1 - px0), py0 - ((1.0 + i / 10.0) ** (-1.0)) * (py0 - py1)) for i in range(81)]
s.polyline(pts_pow, color=DEEP, width=3.2)

t_mark = 2.4
xm = px0 + (t_mark / 8.0) * (px1 - px0)
ym_pow = py0 - ((1.0 + t_mark) ** (-1.0)) * (py0 - py1)
ym_exp = py0 - math.exp(-t_mark) * (py0 - py1)
s.line(xm, ym_exp, xm, ym_pow, color=VERMILION, width=2.8)
s.point(xm, ym_pow, '', VERMILION, r=5.5)
s.point(xm, ym_exp, '', GOLD, r=5.0)
s.text(xm + 14, ym_pow - 14, '移位幂律 (1 + {i:t} / {i:r}){sup:−α}', 19, fill=DEEP, bold=True)
s.text(xm + 14, 326, '长尾储备', 19, fill=VERMILION)
s.line(px0 + 140, py1 + 24, px0 + 176, py1 + 24, color=GOLD, width=2.4, dash=True)
s.text(px0 + 184, py1 + 31, '同均值单指数 {i:e}{sup:−αt/r}', 19, fill=GOLD)
s.line(px0 + 140, py1 + 56, px0 + 176, py1 + 56, color=HAIR, width=1.8, dash=True)
s.text(px0 + 184, py1 + 63, '异质单通道指数分量', 19, fill=SLATE)
s.text(580, 434, 'Gamma 期望 = (1 + {i:t} / {i:r}){sup:−α}', 20)
s.text(580, 472, '时间全阶完全单调：(−1){sup:n} {i:Ψ}{sup:(n)}({i:t}) > 0', 19.5, fill=VERMILION, bold=True)
names.append(s.save('05-parity-forgetting'))

# 6. Accent: continuous dual-rail capacitor voltage handoff (no reset) and packet capacity failure threshold.
s = SVG(520, '图6 无重置物理测量闭环与固定记录包容量失真下界',
        '左：十路驱动的合法包经RLC、ADC与共享AIG生成反馈，RLC先切换，随后在下一ADC快照接续接收器电容电压。右：定长包的归一化时间失真下界及容差交点。')
s.text(40, 40, 'RLC 反馈与接收器电容续接', 22, bold=True)
s.text(580, 40, '有限记录包的物理时距失真界', 22, bold=True)
s.line(545, 20, 545, 500, color=HAIR, width=1)

s.rect(40, 68, 136, 64, fill=WASH, stroke=SLATE)
s.text(108, 95, '10 路驱动', 19, anchor='middle', bold=True)
s.text(108, 121, 'RLC 回路', 19, fill=SLATE, anchor='middle')
s.line(176, 100, 202, 100, arrow=True)

s.rect(204, 68, 134, 64, fill='none', stroke=DEEP, width=1.8)
s.text(271, 95, '60 词 ADC', 19, fill=DEEP, anchor='middle', bold=True)
s.text(271, 121, '1024 数字像', 19, fill=SLATE, anchor='middle')
s.line(338, 100, 364, 100, arrow=True)

s.rect(366, 68, 158, 64, fill='none', stroke=DEEP, width=1.8)
s.text(445, 95, '128 位门算术', 19, fill=DEEP, anchor='middle', bold=True)
s.text(445, 121, '11 输出 AIG', 19, fill=SLATE, anchor='middle')
s.polyline([(445, 132), (445, 160), (108, 160)], color=SLATE, width=1.6)
s.line(108, 160, 108, 134, color=SLATE, width=1.6, arrow=True)
s.text(276, 152, '判决后切换 RLC', 19, fill=SLATE, anchor='middle')

s.text(40, 204, '接收器存储电容电压（示意）', 20, bold=True)
wx0, wx1, wy0, wy1 = 86, 510, 365, 232
s.line(wx0, wy0, wx1, wy0, color=SLATE, width=1.5)
s.line(wx0, wy0, wx0, wy1, color=SLATE, width=1.5)
s.text(wx0 - 10, wy1 + 14, '电压', 19, fill=SLATE, anchor='end')
s.text(wx1, wy0 - 10, '时间 {i:t}', 19, fill=SLATE, anchor='end')
wmid = 296
s.line(wmid, wy1 - 6, wmid, wy0 + 8, color=VERMILION, width=1.8, dash=True)
wave1 = [(wx0 + i * 4.2, wy0 - (38 + 66 * (1.0 - math.exp(-i / 16.0)))) for i in range(51)]
y_handoff = wave1[-1][1]
wave2 = [(wmid + i * 4.2, y_handoff + 42 * (1.0 - math.exp(-i / 18.0))) for i in range(51)]
s.polyline(wave1, color=DEEP, width=3.0)
s.polyline(wave2, color=DEEP, width=3.0)
s.line(wmid, y_handoff, wmid, wy0, color=MUTE, width=1.6, dash=True)
s.point(wmid, y_handoff, '', VERMILION, r=7.5)
s.text(188, wy0 + 30, '旧包驱动', 19, fill=SLATE, anchor='middle')
s.text(406, wy0 + 30, '新包驱动', 19, fill=SLATE, anchor='middle')
s.text(wmid + 14, y_handoff - 14, '下一 ADC 快照', 19, fill=VERMILION, bold=True)
s.text(40, 438, '{i:V}{sub:next}({i:v}, ±; 0) = {i:V}{sub:old}({i:v}, ±; {i:t}{sub:end})', 20, fill=VERMILION, bold=True)
s.text(40, 474, '回路切换间隔 ≥ τ > 0', 20)

s.text(580, 76, '纵轴：归一化失真 Risk / τ{sup:2}', 19, fill=SLATE)
qx0, qx1, qy0, qy1 = 635, 1055, 345, 104
s.line(qx0, qy0, qx1, qy0, color=SLATE, width=1.6)
s.line(qx0, qy0, qx0, qy1, color=SLATE, width=1.6)
for uk in [0, 1, 2, 3, 4]:
    ux = qx0 + (uk / 4.0) * (qx1 - qx0)
    s.line(ux, qy0, ux, qy0 + 6, color=SLATE, width=1.4)
    s.text(ux, qy0 + 26, str(uk), 19, fill=SLATE, anchor='middle')
s.text((qx0 + qx1) / 2, qy0 + 54, '历史规模比 {i:n} / {i:M}（{i:M} = 2{sup:B}）', 19, fill=SLATE, anchor='middle')
s.text(qx0 - 12, qy0 + 5, '0', 19, fill=SLATE, anchor='end')
s.text(qx0 - 12, qy1 + 8, '1.25', 19, fill=SLATE, anchor='end')

x_cap = qx0 + 0.25 * (qx1 - qx0)
s.line(x_cap, qy1, x_cap, qy0, color=MUTE, width=1.5, dash=True)
s.text((qx0 + x_cap) / 2, qy0 - 18, '{i:n} ≤ {i:M}', 19, fill=SLATE, anchor='middle')
curve_q = [(qx0 + (i / 80.0) * (qx1 - qx0),
            qy0 - (max(0.0, ((i / 20.0) ** 2 - 1.0) / 12.0) / 1.25) * (qy0 - qy1))
           for i in range(20, 81)]
poly_q = [(x_cap, qy1)] + curve_q + [(qx1, qy1)]
s.polygon(poly_q, fill=WASH)
s.polyline([(qx0, qy0), (x_cap, qy0)] + curve_q, color=DEEP, width=3.2)

eps_val = 0.5
y_eps = qy0 - (eps_val / 1.25) * (qy0 - qy1)
u_hit = math.sqrt(12.0 * eps_val + 1.0)
x_hit = qx0 + (u_hit / 4.0) * (qx1 - qx0)
s.line(qx0, y_eps, qx1, y_eps, color=VERMILION, width=1.8, dash=True)
s.point(x_hit, y_eps, '', VERMILION, r=6.5)
s.text(qx0 + 12, y_eps - 12, '容差阈值 ε{sup:2} / τ{sup:2}', 19, fill=VERMILION)
s.text(x_hit + 14, y_eps + 28, '下界等于容差', 19, fill=VERMILION, bold=True)
s.text(580, 468, 'Risk ≥ (τ{sup:2} / 12) [({i:n} / {i:M}){sup:2} − 1]', 21, fill=DEEP, bold=True)
names.append(s.save('06-no-reset-circuit'))

if __name__ == '__main__':
    import cairosvg
    register_cjk_for_cairo()
    out = ROOT / 'previews'; out.mkdir(exist_ok=True)
    for name in names:
        cairosvg.svg2png(url=str(ROOT / (name + '.svg')), write_to=str(out / (name + '.png')), output_width=int(W * 1.5))
    print(json.dumps({'svg': names, 'png_previews': len(names)}, ensure_ascii=False))
