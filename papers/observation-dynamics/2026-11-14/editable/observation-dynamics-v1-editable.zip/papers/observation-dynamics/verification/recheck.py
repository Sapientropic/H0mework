#!/usr/bin/env python3
"""Exact rational checks for displayed examples and algorithms, not theorem proving."""
from fractions import Fraction as Q
from pathlib import Path
from collections import defaultdict
import json
ROOT=Path(__file__).resolve().parent
counts=defaultdict(int)
def eq(a,b,group):
    assert a==b, (group,a,b)
    counts[group]+=1
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def scale(a,t): return tuple(x*t for x in a)
def norm2(a): return sum(x*x for x in a)
def mean(vs): return tuple(sum(v[j] for v in vs)/Q(len(vs)) for j in range(len(vs[0])))
def response(h,m,c,a,n,t):
    return tuple(h.get(a*(j+1)-1-t,Q(0))+m+a*(j+1)*(c+t*m) for j in range(n))
def send(row,a):
    n=len(row);s1=sum(range(1,n+1));s2=sum(k*k for k in range(1,n+1))
    d=(n+1)*(1+a*a*s2)-a*a*s1*s1
    assert d>0
    b0=sum(row);b1=sum((j+1)*r for j,r in enumerate(row))
    m0=((1+a*a*s2)*b0-a*a*s1*b1)/d
    m1=((n+1)*b1-s1*b0)/d
    x=tuple(r-m0-a*a*(j+1)*m1 for j,r in enumerate(row))
    back=tuple(sum((Q(j==k)+1+a*a*(j+1)*(k+1))*x[k] for k in range(n)) for j in range(n))
    eq(back,row,'rational_sender')
    return x,back
for a in range(2,7):
    for n in range(a,a+3):
        for test in range(n*a+3):
            h={test:Q(1)} if test<n*a else {}
            m=Q(test==n*a); c=Q(test==n*a+1)
            if test==n*a+2:h={n*a+5:Q(3,7)}
            rows=[send(response(h,m,c,a,n,t),a)[1] for t in range(a+1)]
            dm=(rows[a][1]-rows[0][0]-rows[a][0])/(a*a-1)
            dc=(rows[a][0]-dm)/a-a*dm
            eq((dm,dc),(m,c),'window_axes')
            recovered=[]
            for k in range(n*a):
                j=k//a;t=a*(j+1)-1-k
                recovered.append(rows[t][j]-dm-a*(j+1)*(dc+t*dm))
            eq(tuple(recovered),tuple(h.get(k,Q(0)) for k in range(n*a)),'window_space')
row=response({2:Q(1)},Q(1),Q(3),2,2,0)
eq(row,(Q(7),Q(13)),'opening')
eq(send(row,2)[0],(Q(1,3),Q(5,9)),'opening')
eq(response({2:Q(1)},Q(1),Q(3),2,2,1),(Q(9),Q(18)),'opening')
eq(response({2:Q(1)},Q(1),Q(3),2,2,2),(Q(11),Q(21)),'opening')
# Explicit two-frame zero-readout collision witness v_* in Section 3.3 (a=n=2, ell=1).
h_star={0:Q(-3),1:Q(-1),2:Q(-5),3:Q(-1)}
eq(response(h_star,Q(1),Q(0),2,2,0),(Q(0),Q(0)),'two_frame_collision_witness')
eq(response(h_star,Q(1),Q(0),2,2,1),(Q(0),Q(0)),'two_frame_collision_witness')
eq(response(h_star,Q(1),Q(0),2,2,2),(Q(5),Q(8)),'two_frame_collision_witness')
# Original full task: v_i=(e_(i+1),1,i+2), then copy scale 2.
def acted(i,n,a=2):
    d=a*(n+2)+3; h=[Q(0)]*d;h[a*(i+2)-1]=Q(1)
    return tuple(h+[Q(1),Q(a*(i+2))])
def risk(vs,keys):
    groups={k:[v for v,q in zip(vs,keys) if q==k] for k in set(keys)}
    ms={k:mean(v) for k,v in groups.items()}
    return sum(norm2(sub(v,ms[k])) for v,k in zip(vs,keys))/len(vs),ms
vs=[acted(i,5) for i in range(5)]
fine,mf=risk(vs,[i%2 for i in range(5)]);coarse,mc=risk(vs,[0]*5)
gap=sum(norm2(sub(mf[i%2],mc[0])) for i in range(5))/5
eq(coarse,fine+gap,'same_task_identity');eq(gap,Q(1,5),'displayed_gap');eq(mf[0][-1],Q(8),'clock_conditional_means');eq(mf[1][-1],Q(8),'clock_conditional_means')
# A zero clock increment does not imply zero clock risk.
clock_fine,_=risk([v[-1:] for v in vs],[i%2 for i in range(5)])
clock_coarse,_=risk([v[-1:] for v in vs],[0]*5)
space_fine,_=risk([v[:-2] for v in vs],[i%2 for i in range(5)])
space_coarse,_=risk([v[:-2] for v in vs],[0]*5)
mass_fine,_=risk([v[-2:-1] for v in vs],[i%2 for i in range(5)])
mass_coarse,_=risk([v[-2:-1] for v in vs],[0]*5)
eq(clock_fine,Q(8),'clock_total_risk')
eq(clock_coarse,Q(8),'clock_total_risk')
eq(clock_coarse-clock_fine,Q(0),'clock_increment_only')
eq((space_fine,space_coarse),(Q(3,5),Q(4,5)),'space_total_risk')
eq((mass_fine,mass_coarse),(Q(0),Q(0)),'mass_total_risk')
eq(fine,Q(43,5),'complete_total_risk')
eq(coarse,Q(44,5),'complete_total_risk')
eq(fine,space_fine+mass_fine+clock_fine,'component_account')
eq(coarse,space_coarse+mass_coarse+clock_coarse,'component_account')
eq(coarse-fine,Q(1,5),'complete_increment')
r4,_=risk([acted(i,4) for i in range(4)],[0]*4)
r5,_=risk([acted(i,5) for i in range(5)],[0]*5)
eq(r4,Q(23,4),'cross_tick');eq(r5,Q(44,5),'cross_tick');eq(5*r5,4*r4+Q(4,5)*Q(105,4),'cross_tick')
# The three-actor pulse and the independent two-actor pulse.
eq(sum((Q(i)-1)**2 for i in range(3))/3,Q(2,3),'pulse')
eq(Q(1,6)+Q(1,2),Q(2,3),'pulse')
eq(sum((Q(i)-Q(1,2))**2 for i in range(2))/2,Q(1,4),'pulse')
for N in range(1,10):
    eq(Q(N+2)**2-Q(N+1)**2,Q(2*N+3),'native_noise_growth')
mass_error, clock_error = Q(1), Q(-1)
before = norm2((mass_error, clock_error))
after = norm2((mass_error, clock_error + mass_error))
eq((before, after), (Q(2), Q(1)), 'signed_clock_error')
# Counted raw moments. Dimension is fixed only for this finite exact check.
dim=23
zero=tuple(Q(0) for _ in range(dim))
def actor(i):
    v=list(zero);v[i+1]=Q(1);v[-2]=Q(1);v[-1]=Q(i+2);return tuple(v)
def merge(table):
    out={}
    for key,(c,moment) in table.items():
        k=key%2;oldc,oldm=out.get(k,(0,zero));out[k]=(oldc+c,add(oldm,moment))
    return out
def step(table,key,v):
    out=dict(table);c,m=out.get(key,(0,zero));out[key]=(c+1,add(m,v));return out
def error(table,actors,keys):
    return sum(norm2(sub(v,scale(table[k][1],Q(1,table[k][0])))) for v,k in zip(actors,keys))/len(actors)
table={}
for i in range(4):table=step(table,i%3,actor(i))
for k,(c,m) in list(table.items()):
    eps=tuple(Q((-1)**(k+j),200) for j in range(dim))
    table[k]=(c,add(m,scale(eps,c)))
initial_residual={k:sub(m,tuple(sum(actor(i)[j] for i in range(4) if i%3==k) for j in range(dim))) for k,(c,m) in table.items()}
for N in range(3,13):
    actors=[actor(i) for i in range(N+1)];coarsetable=merge(table);keys=[(i%3)%2 for i in range(N+1)]
    for k,(c,m) in table.items():
        restored={i for i in range(N+1) if m[i+1]>Q(1,2)}
        eq(restored,{i for i in range(N+1) if i%3==k},'continued_fine_posterior')
        source=tuple(sum(actor(i)[j] for i in range(N+1) if i%3==k) for j in range(dim))
        eq(sub(m,source),initial_residual.get(k,zero),'counted_residual')
    for k,(c,m) in coarsetable.items():
        eq({i for i in range(N+1) if m[i+1]>Q(1,2)},{i for i in range(N+1) if (i%3)%2==k},'continued_coarse_posterior')
    vari,means=risk(actors,keys)
    residual_cost=sum(Q(c,N+1)*norm2(sub(scale(m,Q(1,c)),means[k])) for k,(c,m) in coarsetable.items())
    err=error(coarsetable,actors,keys);eq(err,vari+residual_cost,'field_error_identity')
    born=actor(N+1);finekey=(N+1)%3;coarsekey=finekey%2
    newtable=step(table,finekey,born);newcoarse=merge(newtable)
    eq(newcoarse,step(coarsetable,coarsekey,born),'merge_update_complete_moment')
    c,m=coarsetable.get(coarsekey,(0,zero));mu=means.get(coarsekey,zero)
    eps=sub(scale(m,Q(1,c)),mu) if c else zero
    innovation=Q(c,c+1)*norm2(sub(born,mu))
    next_error=error(newcoarse,actors+[born],keys+[coarsekey])
    eq((N+2)*next_error,(N+1)*err+innovation-Q(c,c+1)*norm2(eps),'exact_error_update')
    next_actors = actors + [born]
    fine_keys = [i % 3 for i in range(N + 2)]
    coarse_keys = keys + [coarsekey]
    fine_risk, fine_means = risk(next_actors, fine_keys)
    coarse_risk, coarse_means = risk(next_actors, coarse_keys)
    increment = sum(
        norm2(sub(fine_means[y], coarse_means[z]))
        for y, z in zip(fine_keys, coarse_keys)
    ) / len(next_actors)
    eq(coarse_risk, fine_risk + increment, 'counted_coarsening_risk')
    table=newtable
u=(Q(1,3),Q(-2,5),Q(4,7))
eq(norm2(scale(add(u,scale(u,-1)),Q(1,2))),Q(0),'mixed_residual_control')
eq(norm2(scale(add(u,u),Q(1,2))),norm2(u),'mixed_residual_control')
# Terminating partition refinement and incremental readout equivalence (Theorem 2.9 and Example 1.2(b)).
def settle_pairs(states, actions, reads, init_pairs=None):
    pairs = set(init_pairs) if init_pairs is not None else {
        (x, y) for x in states for y in states if all(r(x) == r(y) for r in reads)
    }
    fuel = len(pairs)
    for _ in range(fuel + 1):
        nxt = {(x, y) for (x, y) in pairs if all((a(x), a(y)) in pairs for a in actions)}
        if nxt == pairs:
            return pairs
        assert len(nxt) < len(pairs)
        pairs = nxt
    raise AssertionError('fuel exhausted')
states4 = [0, 1, 2, 3]
act_ex = [lambda s: {0: 1, 1: 2, 2: 2, 3: 0}[s]]
read_ex = [lambda s: {0: 0, 1: 0, 2: 1, 3: 0}[s]]
eq(settle_pairs(states4, act_ex, read_ex), {(i, i) for i in states4}, 'partition_refinement')
act_ex2 = [lambda s: {0: 1, 1: 1, 2: 3, 3: 3}[s]]
o1_ex2 = lambda s: 0
o2_ex2 = lambda s: {0: 0, 1: 0, 2: 0, 3: 1}[s]
k_old4 = settle_pairs(states4, act_ex2, [o1_ex2])
k_inc4 = settle_pairs(states4, act_ex2, [o1_ex2, o2_ex2], {(x, y) for (x, y) in k_old4 if o2_ex2(x) == o2_ex2(y)})
k_rec4 = settle_pairs(states4, act_ex2, [o1_ex2, o2_ex2])
eq(k_inc4, {(0, 0), (0, 1), (1, 0), (1, 1), (2, 2), (3, 3)}, 'partition_refinement')
eq(k_inc4, k_rec4, 'incremental_refinement_exact')
states6 = list(range(6))
acts6 = [lambda s: (s + 1) % 6, lambda s: {0: 2, 1: 3, 2: 4, 3: 5, 4: 0, 5: 1}[s]]
reads_base = [lambda s: s % 2]
r_new = lambda s: 1 if s in (1, 4) else 0
k_base = settle_pairs(states6, acts6, reads_base)
k_recomputed = settle_pairs(states6, acts6, reads_base + [r_new])
k_incremental = settle_pairs(states6, acts6, reads_base + [r_new], {(x, y) for (x, y) in k_base if r_new(x) == r_new(y)})
eq(k_incremental, k_recomputed, 'incremental_refinement_exact')
# Theorem 2.11: the two gate visits increment only the address.
def c3_clocks(visit):
    ordinary = visit - sum(gate < visit for gate in (55, 58))
    return (visit, 100 * ordinary, 1000 * ordinary)

eq(c3_clocks(4), (4, 400, 4000), 'c3_anchor')
for visit in (54, 55, 56, 57, 58, 59):
    elapsed = sub(c3_clocks(visit + 1), c3_clocks(visit))
    expected = (1, 0, 0) if visit in (55, 58) else (1, 100, 1000)
    eq(elapsed, expected, 'c3_gate_clock')
eq((256 * 55).to_bytes(8, 'little'), b'\x00\x37\x00\x00\x00\x00\x00\x00', 'c3_success_key')
# Prime saturation shortest window cut(p)+1 and short-window escape (Theorem 3.6).
for p, expected_cut in [(2, 0), (3, 0), (5, 1), (7, 2), (11, 4), (13, 5)]:
    cut_p = max(0, p - 3) // 2
    eq(cut_p, expected_cut, 'prime_cut_formula')
    for s_idx in range(8):
        eq(int(2 * (s_idx + 2) >= p), int(s_idx >= cut_p), 'prime_threshold_equiv')
    for b in range(cut_p):
        s_star = cut_p - b - 1
        prefix_reads = tuple(int(s_star + j >= cut_p) for j in range(b + 1))
        next_read = int(s_star + (b + 1) >= cut_p)
        eq(prefix_reads, tuple(0 for _ in range(b + 1)), 'prime_short_escape')
        eq(next_read, 1, 'prime_short_escape')
# Alternating birth-parity recovery law (Theorem 6.6).
for d in range(1, 10):
    n_act = d + 2
    old_factor = (d + 2) % 2
    new_factor = (d + 3) % 2
    q_old = [(old_factor * ((i + 1) % 2)) % 2 for i in range(n_act)]
    q_new = [(new_factor * ((i + 1) % 2)) % 2 for i in range(n_act)]
    if d % 2 == 0:
        eq((old_factor, new_factor), (0, 1), 'birth_parity_even')
        vs_new = [acted(i, n_act, d + 3) for i in range(n_act)]
        r_old, _ = risk(vs_new, q_old)
        r_new, _ = risk(vs_new, q_new)
        sp_old, _ = risk([v[:-2] for v in vs_new], q_old)
        eq(sp_old, Q(d + 1, d + 2), 'birth_parity_even')
        assert r_old > Q(d + 1, d + 2) and r_old > r_new
        counts['birth_parity_even'] += 1
    else:
        eq((old_factor, new_factor), (1, 0), 'birth_parity_odd')
        vs_old = [acted(i, n_act, d + 2) for i in range(n_act)]
        r_old, _ = risk(vs_old, q_old)
        r_new, _ = risk(vs_old, q_new)
        sp_new, _ = risk([v[:-2] for v in vs_old], q_new)
        eq(sp_new, Q(d + 1, d + 2), 'birth_parity_odd')
        assert r_new > Q(d + 1, d + 2) and r_new > r_old
        counts['birth_parity_odd'] += 1
# Affine constant-subtraction birth normalization (-effect, effect) (Theorem 6.8(3)).
for old_val in range(-3, 4):
    for eff_val in range(-3, 4):
        total = old_val + eff_val
        norm_pair = (old_val - total, eff_val)
        eq(norm_pair, (-eff_val, eff_val), 'birth_affine_pair')
        eq(norm_pair[0] + norm_pair[1], 0, 'birth_affine_pair')
# Rising/falling Pochhammer sign, time-pullback derivative, and t=r half-rate (Theorem 6.9).
for alpha in [Q(1, 2), Q(1, 1), Q(3, 2), Q(7, 3)]:
    for r_rate in [Q(1, 2), Q(2, 1)]:
        lam0 = (alpha / r_rate) / (1 + Q(0) / r_rate)
        lam_half = (alpha / r_rate) / (1 + r_rate / r_rate)
        eq(lam_half, lam0 / 2, 'forgetting_half_rate')
    for n_ord in range(7):
        rising = Q(1, 1)
        falling_neg = Q(1, 1)
        for k_idx in range(n_ord):
            rising *= (alpha + k_idx)
            falling_neg *= (-alpha - k_idx)
        eq(falling_neg, ((-1) ** n_ord) * rising, 'forgetting_pochhammer')
        assert (((-1) ** n_ord) * falling_neg) > 0
        counts['forgetting_pochhammer'] += 1
# 1024 digital capacity, 128-bit RL energy non-overflow, and time-squared distortion (Theorems 7.1, 7.2, 7.5, 7.6).
eq(2 ** 10, 1024, 'adc_digital_capacity')
eq(10 * 2 * 3, 60, 'adc_digital_capacity')
assert 2 ** 9 < 1024
word_min, word_max = -16_000_000, 16_000_000
max_diff = word_max - word_min
max_sq = max_diff ** 2
max_quartic = max_sq * max_sq
max_scaled = 4 * (max_quartic + max_quartic)
assert max_scaled > 2 ** 64 and max_scaled < 2 ** 128 and (2 ** 102 < max_scaled < 2 ** 103)
counts['adc_128bit_no_overflow'] += 1
for m_fib in range(1, 9):
    pair_step2 = sum((Q(2 * u - 2 * v)) ** 2 for u in range(m_fib) for v in range(m_fib))
    eq(pair_step2, Q(2, 3) * (m_fib ** 2) * (m_fib ** 2 - 1), 'drive_time_distortion')
    pair_step1 = sum((Q(u - v)) ** 2 for u in range(m_fib) for v in range(m_fib))
    eq(pair_step1, Q(1, 6) * (m_fib ** 2) * (m_fib ** 2 - 1), 'packet_time_distortion')
report={'status':'passed','arithmetic':'fractions.Fraction; no floating point tolerances','scope':'displayed numbers, finite basis/window cases, and ten counted update steps; not a replacement for source proofs or a Lean certification','checks':dict(counts),'total_assertions':sum(counts.values()),'displayed_risk_account':{'actors':5,'copy_scale':2,'weight':'1/5','fine_keys':[0,1,0,1,0],'coarse_keys':[0,0,0,0,0],'clock_values':[str(v[-1]) for v in vs],'fine_clock_means':[str(mf[k][-1]) for k in sorted(mf)],'clock_risk':{'fine':str(clock_fine),'coarse':str(clock_coarse),'increment':str(clock_coarse-clock_fine)},'space_risk':{'fine':str(space_fine),'coarse':str(space_coarse)},'full_risk':{'fine':str(fine),'coarse':str(coarse),'increment':str(gap)}}}
(ROOT/'numeric-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
