# Autonomous Observation Dynamics, Minimal All-Future Realizations, and Provenance Information Loss: From Terminating Quotient Refinement and Optimal Windows to Non-Resetting Physical Circuits

The archive contains the reading manuscript, bibliography and vector figures.

From the extracted root, rebuild the PDF with Python 3, Pandoc, XeLaTeX, xeCJK and Noto CJK SC fonts.

    python3 shared/scripts/build_pdf.py papers/observation-dynamics/manuscript.md
    python3 papers/observation-dynamics/verification/recheck.py

Fixed Lean source, claim map, and replay commands are documented in [H0mework](https://github.com/Sapientropic/H0mework/blob/5e115b4637d39f52e8064759abdfe8237597934a/docs/observation-dynamics-reproduction.md).
The manuscript and original figures use CC BY 4.0. Lean source follows the H0mework Apache-2.0 license.
