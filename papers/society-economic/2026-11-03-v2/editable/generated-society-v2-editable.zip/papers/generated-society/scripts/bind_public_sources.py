#!/usr/bin/env python3
"""Bind the paper's original sources to one committed H0 proof selection.

Reads fixed Git objects and recorded acceptance. It neither builds Lean nor
changes H0. The protocol binding follows its explicit certified-epoch contract;
equal root bytes alone do not identify dependency environments.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from functools import lru_cache
import gzip
import hashlib
import json
from pathlib import Path
import subprocess


PAPER = Path(__file__).resolve().parents[1]
COMMIT = "2d6fbc96e33b7c4c3cfd91104fda74e3caeda045"
REPOSITORY = "https://github.com/Sapientropic/H0mework"
MAP = "docs/generated-society-map.json"
SELECTION = "checks/generated-society-selection.json"
ACCEPTANCE = "evidence/generated-society/acceptance/final-manuscript"
INDEPENDENT = "evidence/economic-constitution/acceptance/initial-intake/independent-acceptance.json"
ROLES = ("producers", "direct_consumers", "resources")
C13_ORIGINAL_NOTE = (
    "PT15原入口e0b980ffb69e638c9f1e000932f6bb14f778dcdc；本稿读df固定blob；"
    "历史receipt-window/v1未恢复，3条协议import边界另列source-availability.md。"
)
C13_BOUND_NOTE = (
    "早期H0 48dc9ad13ffa79d9c2e9a93a8bc755a2388320bc观察的历史核读状态："
    + C13_ORIGINAL_NOTE
    + "当前e0b980ffb69e638c9f1e000932f6bb14f778dcdc认证源与原window回执已恢复，"
    "实际完整imports、原回执状态及H0验收由本行h0_binding固定。"
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def normalize_protocol_assembly_note(row):
    """Keep the generator's old observation at its historical scope."""
    if (row.get("claims"), row.get("supplement"), row.get("main")) != (
        "PT15 independent", "C.5.4", None
    ):
        return row
    require(row.get("assembly_note") in (C13_ORIGINAL_NOTE, C13_BOUND_NOTE),
            "C.13 provenance note changed; review its historical scope before binding")
    return {**row, "assembly_note": C13_BOUND_NOTE}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--h0-repo", type=Path, required=True)
    parser.add_argument("--h0-commit", default=COMMIT)
    parser.add_argument("--check", action="store_true", help="compare without writing")
    args = parser.parse_args()
    commit = subprocess.check_output(
        ["git", "-C", str(args.h0_repo), "rev-parse", args.h0_commit + "^{commit}"],
        text=True,
    ).strip()
    require(commit == COMMIT, "This binding fixes the reviewed H0 snapshot " + COMMIT)

    @lru_cache(maxsize=None)
    def git_bytes(path):
        return subprocess.check_output(["git", "-C", str(args.h0_repo), "show", commit + ":" + path])

    def reference(path):
        return {"path": path, "sha256": sha(git_bytes(path))}

    def receipt(ref):
        raw = git_bytes(ref["path"])
        require(sha(raw) == ref["sha256"], "Artifact digest differs: " + ref["path"])
        payload = gzip.decompress(raw) if ref.get("compression") == "gzip" else raw
        if ref.get("payload_sha256"):
            require(sha(payload) == ref["payload_sha256"], "Payload digest differs: " + ref["path"])
        return json.loads(payload)

    data = json.loads(git_bytes(MAP))
    summary = json.loads(git_bytes(ACCEPTANCE + "/summary.json"))
    ready = json.loads(git_bytes(ACCEPTANCE + "/entry.json"))
    acceptance = data["acceptance"]
    require(acceptance["status"] == summary["status"] == ready["status"] == "passed", "H0 acceptance is not passed")
    require(summary["claim_map_sha256"] == ready["claim_map_sha256"] == sha(git_bytes(MAP)), "Final map digest differs")
    require(summary["selection_sha256"] == ready["selection_sha256"] == sha(git_bytes(SELECTION)), "Selection digest differs")
    require(summary["remote_CI_run"] is False, "Availability statement needs a new review")
    types = receipt(acceptance["declaration_types"])
    builds = receipt(acceptance["build"])
    trust = receipt(acceptance["trust"])
    original_input = receipt(acceptance["execution_map"])
    def selected_proofs(document):
        result = []
        for claim in document["claims"]:
            for role in ROLES:
                for entry in claim[role]:
                    item = {k: deepcopy(entry[k]) for k in
                            ("source_commit", "source_path", "source_sha256", "original_git_source_sha256", "source_origin", "public") if k in entry}
                    if entry.get("declarations"):
                        item["declarations"] = [{k: v for k, v in d.items() if k != "complete_type"} for d in entry["declarations"]]
                        item["proof_package"] = entry["verification"]["proof_package"]
                    result.append((claim["id"], role, item))
        return result
    require(selected_proofs(original_input) == selected_proofs(data), "Finalization changed selected source/declarations")
    for label, result in (("build", builds), ("trust", trust), ("types", types)):
        require(result.get("ok", result.get("status") == "passed") is True, label + " did not pass")
        require(result["inputs_unchanged"] is True and result["input_identity"] == result["input_identity_after"], label + " inputs differ")
        require(result["input_identity"]["sha256"]["claim_map"] == acceptance["execution_map"]["payload_sha256"], label + " used another input map")
    require(len(types["declarations"]) == summary["complete_declaration_types"] == 1012, "Complete type inventory differs")
    require(len(data["proof_packages"]) == summary["packages"] == 7, "Proof package inventory differs")
    require({c["id"] for c in data["claims"]} == {"G2a", *("G" + str(i) for i in range(28))}, "Claim inventory differs")
    require(all(next(c for c in data["claims"] if c["id"] == n)["interface_only"] for n in ("G10", "G11", "G12")), "Interface scope differs")
    independent = json.loads(git_bytes(INDEPENDENT))
    require(independent["status"] == "passed", "Independent receipt review did not pass")

    type_inventory = []
    for index, row in enumerate(types["declarations"]):
        require(row["kernel_equivalent"] is True and row["unsafe"] is False and row["partial"] is False, "Unchecked or unsafe type")
        require(set(row["axioms"]) <= {"propext", "Quot.sound", "Classical.choice"}, "Nonstandard axiom")
        type_inventory.append({"index": index, **{k: row[k] for k in ("package", "module", "qualified_name", "kind", "universe_parameters")}, "type_sha256": sha(row["type"].encode())})

    entries = []
    proof_entries = []
    covered_types = set()

    def bound_entry(entry, pointer, identity, *, claim=None, role=None, package=None):
        public = entry["public"]
        require(sha(git_bytes(public["path"])) == public["sha256"], "Public source/resource differs: " + public["path"])
        result = {"id": identity, "map_pointer": pointer}
        if claim:
            result.update(claim=claim, role=role)
        for key in ("source_commit", "source_path", "source_sha256", "original_git_source_sha256", "source_origin", "evidence_role", "original_execution"):
            if key in entry:
                result[key] = deepcopy(entry[key])
        result["public"] = deepcopy(public)
        if entry.get("declarations"):
            package = package or entry["verification"]["proof_package"]
            result["proof_package"] = package
            result["declarations"] = []
            for i, decl in enumerate(entry["declarations"]):
                ref = decl["complete_type"]
                row = type_inventory[ref["declaration_index"]]
                name = decl.get("public_name", decl["qualified_name"])
                require((row["package"], row["module"], row["qualified_name"], row["type_sha256"]) ==
                        (package, public["module"], name, ref["type_sha256"]), "Declaration/type binding differs: " + name)
                item = {"qualified_name": name, "complete_type_index": row["index"], "type_sha256": row["type_sha256"]}
                for key in ("source_name", "kind", "source_line"):
                    if key in decl:
                        item[key] = decl[key]
                if "source_signature" in decl:
                    item["original_complete_signature"] = {"map_pointer": pointer + "/declarations/" + str(i) + "/source_signature", "sha256": sha(decl["source_signature"].encode())}
                result["declarations"].append(item)
                covered_types.add(row["index"])
            proof_entries.append((entry, result))
        return result

    claims = []
    for ci, claim in enumerate(data["claims"]):
        c = {k: deepcopy(claim[k]) for k in ("id", "title", "statement_scope", "interface_only", "cited_interface_contracts") if k in claim}
        c["map_pointer"] = "/claims/" + str(ci)
        for role in ROLES:
            c[role] = []
            for ei, entry in enumerate(claim[role]):
                identity = claim["id"] + "/" + role + "/" + str(ei)
                c[role].append(identity)
                entries.append(bound_entry(entry, c["map_pointer"] + "/" + role + "/" + str(ei), identity, claim=claim["id"], role=role))
        claims.append(c)
    controls = []
    for pi, package in enumerate(data["proof_packages"]):
        for ei, entry in enumerate(package.get("controls", [])):
            controls.append(bound_entry(entry, "/proof_packages/" + str(pi) + "/controls/" + str(ei), package["id"] + "/controls/" + str(ei), package=package["id"]))
    require(covered_types == set(range(1012)), "Map and controls do not bind every actual type")
    require(len(entries) == 539, "Mapped entry inventory differs")

    correspondence_path = PAPER / "records/theorem-correspondence.json"
    correspondence = json.loads(correspondence_path.read_text())
    correspondence["rows"] = [normalize_protocol_assembly_note(row) for row in correspondence["rows"]]
    correspondence.pop("public_source_binding", None)
    for row in correspondence["rows"]:
        row.pop("h0_binding", None)
        for source in row["sources"]:
            source.pop("h0_binding", None)
    paper_projection_sha = sha(encoded(correspondence))
    contracts = [c for c in claims if c["id"] == "G12"][0]["cited_interface_contracts"]
    paper_bindings = []
    for ri, row in enumerate(correspondence["rows"]):
        row_binding = {"row": ri, "main": row["main"], "title": row["title"], "claims": row["claims"], "supplement": row["supplement"], "sources": []}
        for si, source in enumerate(row["sources"]):
            def matches(entry):
                return entry["source_path"] == source["path"] and entry.get("original_git_source_sha256", entry["source_sha256"]) == source["sha256"]
            candidates = [(e, b) for e, b in proof_entries if matches(e) and e["source_commit"] == source["commit"]]
            mode = "exact-map-source-selection"
            if not candidates:
                contract = next((c for c in contracts if source["commit"] == c["paper_collection_commit"] and source["path"] in c["source_roots"]), None)
                require(contract is not None, "No explicit source selection for " + source["path"])
                candidates = [(e, b) for e, b in proof_entries if matches(e) and e["source_commit"] == contract["actual_source_commit"] and b["proof_package"] == contract["proof_package"]]
                mode = "explicit-certified-epoch-selection"
            found = []
            for entry, bound in candidates:
                for decl in bound["declarations"]:
                    name = decl.get("source_name", decl["qualified_name"])
                    if name == source["declaration"] or name.endswith("." + source["declaration"]):
                        found.append({"entry": bound["id"], "qualified_name": decl["qualified_name"], "complete_type_index": decl["complete_type_index"], "type_sha256": decl["type_sha256"]})
            require(found, "Original declaration has no checked public binding: " + source["path"] + " :: " + source["declaration"])
            source_binding = {"source": si, "selection_mode": mode, "paper_read_epoch": source["commit"], "actual_selected_epoch": sorted({e["source_commit"] for e, b in candidates}), "original_root_sha256": source["sha256"], "bindings": found}
            if mode == "explicit-certified-epoch-selection":
                source_binding["environment"] = "The explicit e0b certified-epoch selection supplies the complete imports. Equal DF root bytes record the paper reading only; they do not identify the DF dependency environment with e0b."
            row_binding["sources"].append(source_binding)
            source["h0_binding"] = {"record": "public-source-binding.json", "pointer": "/paper_correspondence/" + str(ri) + "/sources/" + str(si), "selection_mode": mode}
        row["h0_binding"] = {"record": "public-source-binding.json", "pointer": "/paper_correspondence/" + str(ri)}
        paper_bindings.append(row_binding)
    correspondence["public_source_binding"] = {"record": "public-source-binding.json", "repository": REPOSITORY, "commit": commit, "map_path": MAP, "map_sha256": sha(git_bytes(MAP)), "scope": "Original source fields and claims retained; bindings use exact selected declarations and recorded complete types."}
    require(sum(len(r["sources"]) for r in paper_bindings) == 299, "Main-text source inventory differs")

    binding = {
        "schema": "publish/generated-society-public-source-binding@1",
        "paper_id": "generated-society",
        "repository": {"url": REPOSITORY, "commit": commit, "availability": "Fixed committed proof snapshot; publication availability is recorded by the release register. Original local proof acceptance and later remote CI retain their respective execution identities."},
        "scope": {"claims": 29, "mapped_entries": 539, "proof_role_entries": 320, "resource_references": 219, "complete_types_including_controls": 1012, "proof_packages": 7, "paper_correspondence_rows": 37, "paper_source_references": 299, "proof_owners_recovered": ready["complete_proof_owners_recovered"], "public_resource_identities": ready["resources_verified"], "G10_G12": "interface_only"},
        "h0_references": {"map": reference(MAP), "selection": reference(SELECTION), "summary": reference(ACCEPTANCE + "/summary.json"), "entry": reference(ACCEPTANCE + "/entry.json"), "independent_acceptance": reference(INDEPENDENT), "build": acceptance["build"], "trust": acceptance["trust"], "types": acceptance["declaration_types"], "executed_input_map": acceptance["execution_map"], "reproduction": reference("docs/generated-society-reproduction.md"), "readiness": reference("docs/generated-society-readiness.md")},
        "execution": {"status": "passed", "kind": "actual local complete build, trust and complete types; independently reviewed recorded results", "working_tree_execution": True, "executed_input_map_sha256": acceptance["execution_map"]["payload_sha256"], "final_map_binds_receipts_without_changing_selected_proofs": True, "remote_CI": "not run for this selection", "axioms": summary["axioms"], "unsafe": 0, "partial": 0},
        "paper_source_projection_sha256": paper_projection_sha,
        "proof_packages": [{k: deepcopy(p[k]) for k in ("id", "lean_target", "source_commit", "accepted_source_scope_sha256", "accepted_source_modules", "interface_only") if k in p} for p in data["proof_packages"]],
        "claims": claims,
        "entries": entries,
        "package_controls": controls,
        "complete_type_inventory": type_inventory,
        "paper_correspondence": paper_bindings,
        "source_providers": data["source_providers"],
        "build_adaptations": data["build_adaptations"],
        "historical_status": {"original_certifications": "Retained at their actual epochs and execution identities, separately from H0 acceptance.", "failed_H0_attempts": [acceptance["first_failed_attempt"], acceptance["failed_feedback_defaults_attempt"]], "older_availability_observation": "records/economic-expansion-h0-source-map.json and its gzip detail remain the unchanged historical observation at H0 48dc9ad13ffa79d9c2e9a93a8bc755a2388320bc."},
    }
    outputs = {PAPER / "records/public-source-binding.json": encoded(binding), correspondence_path: encoded(correspondence)}
    for path, raw in outputs.items():
        require(b"/Users/" not in raw and b"/Volumes/" not in raw and b"file://" not in raw, "Private machine path in public binding")
        if args.check:
            require(path.read_bytes() == raw, "Binding output is stale: " + path.name)
        else:
            path.write_bytes(raw)
    print(json.dumps({"status": "passed", "h0_commit": commit, **binding["scope"], "mode": "check" if args.check else "write"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
