#!/usr/bin/env python3
"""Build the four reading PDFs with publish's shared typography.

Run from any directory. --only selects a language/part for a targeted rebuild.
This script never builds Lean or alters Homework/H0mework.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import re
import subprocess
import sys
from datetime import datetime, timezone

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
sys.path.insert(0, str(PUBLISH / "shared" / "scripts"))
import build_pdf


# Paper-local layout guards; the shared style and builder stay unchanged.
_original_latin_title = build_pdf.latin_title
_original_compile_tex = build_pdf.compile_tex

def _latin_title_without_abstract(line):
    if re.fullmatch(r"#{1,2}\s+Abstract(?:\s*\(English\))?", line.strip()):
        return None
    return _original_latin_title(line)


def _tex_words(phrase):
    """Match prose across Pandoc's source-line wrapping, without changing it."""
    return r"\s+".join(re.escape(word) for word in phrase.split())


def _guard_main_paragraph(text, opening, lines, required_fragment=None):
    matches = list(re.finditer(r"(?m)^" + _tex_words(opening), text))
    assert len(matches) == 1, f"Expected one paragraph beginning {opening!r}"
    start = matches[0].start()
    end = text.find("\n\n", start)
    assert end > start, f"Expected a paragraph boundary after {opening!r}"
    paragraph = text[start:end]
    if required_fragment:
        assert re.search(_tex_words(required_fragment), paragraph), (
            f"Expected {required_fragment!r} in the selected paragraph")
    guard = (rf"\Needspace{{{lines}\baselineskip}}" + "\n"
             r"\begingroup\clubpenalty=10000\widowpenalty=10000"
             r"\displaywidowpenalty=10000" + "\n")
    return (text[:start] + guard + paragraph
            + r"\par\endgroup" + text[end:])


def _reflow_main_table(text, header_cells, widths):
    """Change only the two declared widths of one identified longtable.

    The observed Pandoc form has two \\real coefficients in the column
    declaration and two header minipages of width \\linewidth. Match only
    the first header (before its first \\midrule), never nearby prose.
    """
    candidates = []
    for match in re.finditer(
            r"\\begin\{longtable\}.*?\\end\{longtable\}", text, re.S):
        table = match[0]
        top = table.find(r"\toprule")
        mid = table.find(r"\midrule", top)
        if top < 0 or mid < 0:
            continue
        header = table[top:mid]
        if all(re.search(_tex_words(cell), header) for cell in header_cells):
            candidates.append((match, top, header))
    assert len(candidates) == 1, (
        f"Expected one two-column longtable with headers {header_cells!r}")
    match, top, header = candidates[0]
    table = match[0]
    minipages = re.findall(
        r"\\begin\{minipage\}(?:\[[^\]]*\])?\{([^{}]*)\}", header)
    assert minipages == [r"\linewidth", r"\linewidth"], (
        f"Unexpected header-width form for {header_cells!r}")
    declaration = table[:top]
    assert len(re.findall(r"\\real\{[0-9.]+\}", declaration)) == 2, (
        f"Expected exactly two column-width coefficients for {header_cells!r}")
    width_iter = iter(widths)
    declaration = re.sub(
        r"\\real\{[0-9.]+\}",
        lambda _: r"\real{" + next(width_iter) + "}", declaration)
    table = declaration + table[top:]
    return text[:match.start()] + table + text[match.end():]


def _keep_main_table(text, header_cells, lines):
    """Reserve room for one short comparison table, using its actual header."""
    matches = []
    for match in re.finditer(
            r"\\begin\{longtable\}.*?\\end\{longtable\}", text, re.S):
        table = match[0]
        top = table.find(r"\toprule")
        mid = table.find(r"\midrule", top)
        if top >= 0 and mid >= 0:
            header = table[top:mid]
            if all(re.search(_tex_words(cell), header) for cell in header_cells):
                matches.append(match)
    assert len(matches) == 1, f"Expected one comparison table: {header_cells!r}"
    match = matches[0]
    return (text[:match.start()] + rf"\Needspace{{{lines}\baselineskip}}"
            + "\n" + text[match.start():])


def _apply_main_layout_corrections(text):
    """Finite, paper-local fixes selected by the November visual review."""
    marker = "% generated-society sharp-revision layout corrections"
    if marker in text:
        return text
    zh_main = bool(re.search(r"\\textbf\{定理\s+2\.2", text))
    en_main = bool(re.search(
        r"\\section\{10\s+Literature\s+in\s+dialogue:", text))
    if not (zh_main or en_main):
        return text
    assert not (zh_main and en_main), "Expected one main-text language"

    if zh_main:
        for number, title in (
                ("2.2", "主体生成与规范商"),
                ("4.2", "根法处置闭包与写入判据")):
            pattern = (r"\\textbf\{定理\s+" + re.escape(number)
                       + "（" + re.escape(title) + "）。" + r"\}")
            text, count = re.subn(
                pattern,
                lambda m: r"\Needspace{13\baselineskip}" + "\n" + m[0],
                text)
            assert count == 1, f"Expected one Chinese Theorem {number}"
        tables = (
            (("阶段", "在该发生中取得的实际内容"), ("0.1600", "0.8400")),
            (("共同结论", "同一完整支付所保留的内容"), ("0.2800", "0.7200")),
        )
    else:
        heading_34 = (
            r"(\\subsection\{3\.4\s+Uncertainty\s+and\s+theoretical\s+"
            r"judgments\s+also\s+need\s+sources\})")
        text, count = re.subn(
            heading_34,
            lambda m: r"\Needspace{12\baselineskip}" + "\n" + m[0], text)
        assert count == 1, "Expected one English Section 3.4 heading"
        text = _guard_main_paragraph(
            text, "Raising capacity to one leaves another question open.", 5)
        text = _guard_main_paragraph(
            text,
            "An institution may observe a result while needing to assess the events",
            8, required_fragment="undefined value")
        text = _guard_main_paragraph(
            text, "An institution can retain this memory under different names and encodings.", 8)
        # Observed dark-twin p36: keep the new social interpretation from
        # starting with a single line at the foot of the preceding proof page.
        text = _guard_main_paragraph(
            text,
            "The first part proves that a route requires its own actual source.",
            5, required_fragment="capacity for arbitrary interference")
        heading = (
            r"(\\section\{10\s+Literature\s+in\s+dialogue:\s+exit,\s+power,)"
            r"\s+(and\s+sustainable\s+institutional\s+responsibility)(\})")
        text, count = re.subn(
            heading,
            lambda m: (m[1] + r"\texorpdfstring{\\}{ }" + m[2] + m[3]),
            text)
        assert count == 1, "Expected one English Section 10 heading"
        tables = (
            (("Stage", "Actual content obtained at this occurrence"),
             ("0.1600", "0.8400")),
            (("Joint conclusion", "Content retained by the same complete payment"),
             ("0.2800", "0.7200")),
        )
    for header_cells, widths in tables:
        text = _reflow_main_table(text, header_cells, widths)
    # Short tables compare objects side by side. Reserve sufficient room so
    # the second source, sixth guarantee, or final termination locus cannot
    # become an isolated row on the next page. Final sizes are visually checked.
    comparisons = (
        (("实际源", "完整组合"), 10),
        (("共同结论", "同一完整支付所保留的内容"), 24),
        (("位置", "实际内容"), 18),
        (("检查内容", "全捕获搜索场景"), 19),
    ) if zh_main else (
        (("Actual source", "Complete portfolio"), 13),
        (("Joint conclusion", "Content retained by the same complete payment"), 33),
        (("Locus", "Actual content"), 14),
        (("Content checked", "Total-capture search scenario"), 32),
    )
    for header_cells, lines in comparisons:
        text = _keep_main_table(text, header_cells, lines)
    assert text.count(r"\begin{document}") == 1
    return text.replace(r"\begin{document}",
                        marker + "\n" + r"\begin{document}", 1)


def _compile_with_heading_guards(tex):
    text = tex.read_text()
    marker = "% generated-society heading guards"
    if marker not in text:
        guards = (marker + "\n"
                  r"\AtBeginDocument{\pretocmd{\subsection}{\Needspace{7\baselineskip}}{}{}}" + "\n"
                  r"\AtBeginDocument{\pretocmd{\subsubsection}{\Needspace{6\baselineskip}}{}{}}" + "\n")
        text = text.replace(r"\begin{document}", guards + r"\begin{document}", 1)
        # Keep a major heading with its opening question in the revised main text.
        # Detailed pagination is verified from the rendered PDFs.
        text = re.sub(r"(\\section\{[1-9][^}]*\})",
                      lambda m: r"\Needspace{9\baselineskip}" + "\n" + m[0], text)
        # Observed prose revision pp. 16–17: keep the repair conclusion
        # together instead of leaving its final line above Section 5.3.
        repair = "The installed repair program reads"
        if repair in text:
            assert text.count(repair) == 1
            text = text.replace(repair,
                                r"\Needspace{5\baselineskip}" + "\n" + repair, 1)
        # Two observed Appendix D issues: retain the revision paragraph and
        # give the original identifiers enough width without shrinking text.
        d_revision = r"\textbf{Same-source law revision.}"
        if d_revision in text:
            text = text.replace(d_revision,
                                r"\Needspace{9\baselineskip}" + "\n" + d_revision, 1)
            item = text.rfind("AnySourceBackedPaymentOccurrence")
            start = text.rfind(r"\begin{longtable}", 0, item)
            end = text.index(r"\toprule", start)
            assert 0 < start < item and end < item
            header = text[start:end]
            widths = iter(("0.3200", "0.4000", "0.2800"))
            header, count = re.subn(r"\\real\{[0-9.]+\}",
                                    lambda m: r"\real{" + next(widths) + "}", header)
            assert count == 3, "Expected the three-column Appendix D glossary"
            text = text[:start] + header + text[end:]
        # Observed economic-expansion supplement pages: keep this paragraph
        # opening and the E.10 parent heading with sufficient following text.
        lifecycle = "The target lifecycle also carries its original capture"
        if lifecycle in text:
            assert text.count(lifecycle) == 1
            text = text.replace(lifecycle,
                                r"\Needspace{4\baselineskip}" + "\n" + lifecycle, 1)
        if "风险拆分、完整行动路径与外部责任" in text:
            text, count = re.subn(
                r"(\\subsection\{E\.10\s+风险拆分、完整行动路径与外部责任\})",
                lambda m: r"\Needspace{12\baselineskip}" + "\n" + m[0], text)
            assert count == 1, "Expected one observed Chinese E.10 heading"
        # Observed English supplement F.9.1: prevent a one-line paragraph start.
        receipt = "The action receipt also retains"
        if receipt in text:
            assert text.count(receipt) == 1
            text = text.replace(receipt,
                                r"\Needspace{4\baselineskip}" + "\n" + receipt, 1)
        # Observed F.4.2 after identifier reflow: keep at least two paragraph
        # lines on either side of a page boundary, without changing the prose.
        for paragraph_start in (r"原时间访问 \(v_d\)", "槽等式比较各自单槽表示的序号"):
            if paragraph_start in text:
                assert text.count(paragraph_start) == 1
                start = text.index(paragraph_start)
                end = text.index("\n\n", start)
                paragraph = text[start:end]
                text = (text[:start]
                        + r"\begingroup\clubpenalty=10000\widowpenalty=10000" + "\n"
                        + paragraph + r"\par\endgroup" + text[end:])
    text = _apply_main_layout_corrections(text)
    tex.write_text(text)
    return _original_compile_tex(tex)

build_pdf.latin_title = _latin_title_without_abstract
build_pdf.compile_tex = _compile_with_heading_guards
# The English supplement had two short spill pages before forced appendix starts.
# Reuse the shared builder's continuous-appendix profile for this document only.
build_pdf.CONTINUOUS_APPENDICES.add("papers/generated-society/supplement-en.md")

TARGETS = {
    "zh": ("manuscript.md", "generated-society", "典范社会总定理", "高健"),
    "en": ("manuscript-en.md", "generated-society", "The Canonical Society Theorem", "Jian Gao"),
    "supplement-zh": ("supplement.md", "generated-society-supplement", "典范社会总定理：技术附录", "高健"),
    "supplement-en": ("supplement-en.md", "generated-society-supplement", "Canonical Society: Technical Supplement", "Jian Gao"),
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", nargs="+", choices=list(TARGETS))
    parser.add_argument("--figures", action="store_true")
    args = parser.parse_args()
    if args.figures:
        subprocess.run([sys.executable, str(PAPER/"figures"/"make_figures.py")], check=True)
    output = PAPER / "build" / "reading"
    output.mkdir(parents=True, exist_ok=True)
    record = PAPER / "records" / "reading-build.json"
    data = json.loads(record.read_text()) if record.exists() else {"artifacts": {}}
    selected = args.only or list(TARGETS)
    for key in selected:
        filename, paperid, left, right = TARGETS[key]
        rel = str((PAPER / filename).relative_to(PUBLISH))
        build_pdf.EXPLICIT_RUNHEADS[rel] = (paperid, left, right)
        report = build_pdf.build(rel, toc=filename.startswith("supplement"), output_dir=output)
        pdf = PUBLISH / report["pdf"]
        report.update({"source_sha256": sha(PAPER/filename),
                       "pdf_sha256": sha(pdf),
                       "build_script_sha256": sha(Path(__file__).resolve()),
                       "built_at_utc": datetime.now(timezone.utc).isoformat()})
        data["artifacts"][key] = report
        record.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n")
        print(json.dumps(report, ensure_ascii=False), flush=True)
    dependencies = [PUBLISH/"shared"/"scripts"/"build_pdf.py",
                    PUBLISH/"shared"/"scripts"/"byline.py",
                    PUBLISH/"shared"/"styles"/"article-header.tex",
                    PUBLISH/"shared"/"styles"/"article-header-en.tex",
                    PUBLISH/"shared"/"styles"/"article-filter.lua",
                    PAPER/"figures"/"make_figures.py", Path(__file__).resolve()]
    data["build_dependencies"] = [
        {"path": str(p.relative_to(PUBLISH)), "sha256": sha(p)} for p in dependencies
    ]
    data["python"] = platform.python_version()
    data["scope"] = "Document rendering only; no Lean compilation or source-repository mutation."
    record.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n")
    if any(data["artifacts"][k]["missing_characters"] for k in selected):
        raise SystemExit("Missing characters: inspect reading-build.json and the TeX logs.")

if __name__ == "__main__":
    main()
