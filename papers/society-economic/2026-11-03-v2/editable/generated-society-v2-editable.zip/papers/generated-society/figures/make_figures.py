#!/usr/bin/env python3
"""Bilingual editable plates for The Canonical Society Theorem.

Redesign of 2026-10-31. Published-family typography and geometry, with an
explicit object-specific construction for each plate. The launch-kit
sources in source/ are historical inputs and are deliberately not edited.

Run with python3 (the published family figure environment). Both languages use one layout source.
PDFs are 464 pt wide. SVG text remains editable; raster files in .review/
are temporary views only. No mathematical or institutional data are inferred
from the diagram geometry.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from html import escape
from pathlib import Path

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH
import svg_text
from svg_text import line, text_width, register_cjk_for_cairo
svg_text.OPS.update("∼≅∧⇔≡∅∞′⊊")
W = 1440
PRINT_WIDTH = 464
MIN_SIZE = 24
LANG = "zh"
PARTS, BOXES, SHAPES = [], [], []
MANIFEST = []
CHECK_ONLY = False
BASELINE = "4703fc761e63566c3b11604e8823d6a5f82ba89a"

def L(zh, en):
    return zh if LANG == "zh" else en

def start(height, title, description):
    PARTS.clear(); BOXES.clear(); SHAPES.clear()
    PARTS.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" viewBox="0 0 {W} {height}" role="img">')
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append("<defs>" + "".join(
        f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>'
        for n, c in [("ink", SLATE), ("deep", DEEP), ("acc", VERMILION)]) + "</defs>")
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height

from functools import lru_cache

@lru_cache(maxsize=None)
def weighted_metrics(cls, weight):
    """STIX Two Text is variable: measure the actual rendered weight.

    Kept local to this paper. The shared helper's regular-width anchors are
    retained for other papers; this plate passes a measured start anchor.
    """
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont
    font_path=svg_text._FONT_FILES[cls]
    if cls=="zh" and weight>=600:
        suffix="Bold" if weight>=700 else "SemiBold"
        font_path=Path.home()/"Library/Fonts"/f"NotoSerifCJKsc-{suffix}.otf"
    font=TTFont(str(font_path))
    if "fvar" in font:
        font=instantiateVariableFont(font,{"wght":weight},inplace=True)
    return font.getBestCmap(),font["hmtx"].metrics,font["head"].unitsPerEm

def weighted_width(text,size,weight=400):
    total=0
    for piece,tag in svg_text._pieces(str(text)):
        actual_size=svg_text._script(size,MIN_SIZE) if tag in ("sub","isub","sup") else size
        actual_weight=700 if tag=="b" else weight
        for ch in piece:
            cls="en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i","isub") and cls=="en": cls="it"
            cmap,metrics,upm=weighted_metrics(cls,actual_weight)
            glyph=cmap.get(ord(ch))
            assert glyph in metrics,("missing font glyph",ch,cls)
            total+=metrics[glyph][0]*actual_size/upm
    return total

def txt(x, y, text, size=28, color=INK, weight=400, anchor="start", max_width=None):
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = weighted_width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, tw, max_width)
    x0 = x - {"start": 0, "middle": tw / 2, "end": tw}[anchor]
    BOXES.append({"box": [x0, y - .82 * size, x0 + tw, y + .26 * size],
                  "text": text, "font_px": size})
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))

def text_lines(x, y, lines, size=28, color=INK, weight=400, anchor="start", gap=39, max_width=None):
    for i, label in enumerate(lines):
        txt(x, y + i * gap, label, size, color, weight, anchor, max_width)

def rect(x, y, w, h, stroke=HAIR, fill="none", width=1.6, radius=4, dashed=False):
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"{dash}/>')
    SHAPES.append([x, y, x+w, y+h])

def circle(x, y, r, stroke=DEEP, fill="white", width=2.2):
    PARTS.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')
    SHAPES.append([x-r, y-r, x+r, y+r])

def path(d, color=SLATE, width=2.2, marker=None, dashed=False):
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    end = f' marker-end="url(#arrow-{marker})"' if marker else ""
    PARTS.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round"{dash}{end}/>')

def arrow(x1, y1, x2, y2, color=SLATE, marker="ink", dashed=False, width=2.2):
    path(f"M {x1} {y1} L {x2} {y2}", color, width, marker, dashed)

def rule(y, x1=40, x2=1400):
    path(f"M {x1} {y} L {x2} {y}", HAIR, 1.5)

def cross(x, y, size=13):
    path(f"M {x-size} {y-size} L {x+size} {y+size} M {x-size} {y+size} L {x+size} {y-size}", VERMILION, 4)

def dot(x, y, r=5, color=DEEP):
    circle(x, y, r, color, color, 1)

def panel(x, y, letter, zh, en):
    txt(x, y, letter, 27, SLATE, 600)
    txt(x+42, y, L(zh, en), 28, INK, 600)

def save(stem, height, semantics):
    for i, item in enumerate(BOXES):
        a=item["box"]
        assert a[0] >= 16 and a[2] <= W-16 and a[1] >= 5 and a[3] <= height-6, ("outside canvas", item)
        for other in BOXES[i+1:]:
            b=other["box"]
            if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                raise AssertionError(("text overlap", item["text"], other["text"]))
    for s in SHAPES:
        assert min(s[:2]) >= 0 and s[2] <= W and s[3] <= height, ("shape outside", s)
    if CHECK_ONLY:
        MANIFEST.append({"stem":stem,"language":LANG,"layout":"pass"})
        return
    svg="\n".join(PARTS+["</svg>"])+"\n"
    name=stem+("-en" if LANG=="en" else "")
    (OUT/(name+".svg")).write_text(svg, encoding="utf-8")
    import subprocess
    import pymupdf
    preview=OUT/".review"; preview.mkdir(exist_ok=True)
    page=preview/(name+".html")
    hp=height/W*PRINT_WIDTH
    page.write_text('<!doctype html><html><head><meta charset="utf-8"><style>'
      + f'@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}'
      + f'img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>'
      + f'<body><img src="{(OUT/(name+".svg")).as_uri()}"></body></html>')
    result=subprocess.run(["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "--headless=new","--disable-gpu","--no-pdf-header-footer","--allow-file-access-from-files",
      f"--user-data-dir={preview/'chrome-profile'}",
      f"--print-to-pdf={OUT/(name+'.pdf')}",page.as_uri()],capture_output=True,text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:]+result.stderr[-2000:])
    pdf=pymupdf.open(OUT/(name+".pdf"))
    assert len(pdf)==1
    assert abs(pdf[0].rect.width-PRINT_WIDTH)<1
    assert "\ufffd" not in pdf[0].get_text()
    pix=pdf[0].get_pixmap(matrix=pymupdf.Matrix(W/pdf[0].rect.width,W/pdf[0].rect.width),alpha=False)
    pix.save(preview/(name+".png"))
    entry={"stem":name,"language":LANG,"canvas_px":[W,height],
           "printed_pt":[PRINT_WIDTH,height/W*PRINT_WIDTH],
           "minimum_text_px":MIN_SIZE,"minimum_printed_pt":MIN_SIZE/W*PRINT_WIDTH,
           "text_layout_check":"pass","semantics":semantics,"files":{}}
    for ext in ["svg","pdf"]:
        f=OUT/(name+"."+ext)
        entry["files"][ext]={"path":f.name,"sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"bytes":f.stat().st_size}
    entry["labels"]=list(BOXES)
    MANIFEST.append(entry)

def exit_case():
    h=start(840,L("同一退出关系与三种零容量","One exit relation and three zero capacities"),
      L("上部以同一劳动者、完整支付事件、继续行动、路径和实际服务给出退出关系。控制者是关系位置，不是预设的服务提供者。下部是保留同一支付、劳动者和利益、分别改变一项关系的三个比较构造。",
        "The upper relation keeps the worker, complete payment event, continuing action, route and actual service together. The controller is a position in that relation, not an assumed service provider. The lower rows are three comparison constructions retaining the payment, worker and interest while changing one relation each."))
    panel(40,44,"A", "一次可行的退出关系", "A feasible exit relation")
    circle(100,165,33)
    txt(100,176,L("甲","A"),34,DEEP,600,"middle")
    txt(100,237,L("承担者","worker A"),26,SLATE,anchor="middle")
    arrow(142,165,337,165,DEEP,"deep")
    txt(240,138,L("继续行动","continues"),27,SLATE,anchor="middle")
    rect(345,94,310,143,DEEP,width=2.2)
    txt(500,136,L("继续行动 {i:c}","continuing action {i:c}"),29,DEEP,600,"middle",282)
    txt(500,178,L("原岗位之外","outside the old role"),27,SLATE,anchor="middle")
    txt(500,215,L("非闲置","non-idle"),26,SLATE,anchor="middle")
    arrow(663,165,1022,165,DEEP,"deep")
    txt(840,137,L("通路 {i:π}","route {i:π}"),28,DEEP,anchor="middle")
    rect(1030,94,365,143,DEEP,width=2.2)
    txt(1212,143,L("实际服务 {i:s}{isub:j}","actual service {i:s}{isub:j}"),30,DEEP,600,"middle",337)
    txt(1212,187,L("由服务程序提供","provided by the program"),27,SLATE,anchor="middle",max_width=337)
    rect(345,307,310,88,SLATE)
    txt(500,342,L("完整支付 {i:p}","complete payment {i:p}"),28,INK,600,"middle",286)
    txt(500,379,L("事件与收据","event and receipt"),26,SLATE,anchor="middle")
    arrow(500,298,500,246,DEEP,"deep")
    txt(535,277,L("支付关联","payment incidence"),26,SLATE)
    path("M 840 307 L 840 292 L 785 292 L 785 215 L 655 215",MUTE,2,None,True)
    dot(655,215,4,DEEP)
    circle(840,340,28,SLATE)
    txt(840,350,L("乙","B"),30,INK,600,"middle")
    txt(885,347,L("控制者乙","controller B"),27,SLATE)
    txt(810,262,L("非捕获","non-capture"),27,DEEP)
    rule(427)
    panel(40,471,"B", "保留甲、支付与利益，分别改变一项", "Retain A, the payment and the interest; vary one relation")
    ys=[550,654,758]
    causes=[("payment","支付关联缺失","payment link absent"),("route","路径关联缺失","route link absent"),("captured","继续被捕获","continuation captured")]
    for y,(kind,zh,en) in zip(ys,causes):
        txt(55,y+8,L(zh,en),28,INK,600,max_width=330)
        arrow(477,y,701,y,MUTE if kind=="payment" else DEEP,"ink" if kind=="payment" else "deep",kind=="payment")
        arrow(779,y,1040,y,MUTE if kind=="route" else DEEP,"ink" if kind=="route" else "deep",kind=="route")
        circle(445,y,29)
        txt(445,y+10,"{i:p}",30,DEEP,anchor="middle")
        circle(740,y,31,VERMILION if kind=="captured" else DEEP,width=3.4 if kind=="captured" else 2.2)
        txt(740,y+10,"{i:c}",30,DEEP,anchor="middle")
        circle(1080,y,34)
        txt(1080,y+10,"{i:s}{isub:j}",29,DEEP,anchor="middle")
        if kind=="captured":
            rect(697,y-43,86,86,VERMILION,width=2.2,radius=0)
            txt(850,y-31,L("乙控制继续","B controls c"),25,VERMILION,anchor="middle")
        if kind=="payment": cross(587,y)
        if kind=="route": cross(910,y)
        txt(1305,y+10,"{i:K} = 0",31,INK,600,"middle")
    save("01-exit-case",h,{"focus":"three different missing relations; one scalar reading",
      "caseIdentity":["worker A","complete payment p","interest"],"comparisonNotRuntimeBranch":True,
      "controllerNotAssumedProvider":True,"proofLocation":"main exit theorem; supplement B.4–B.5"})


def generation():
    h=start(920,L("主体生成与制度位置","Actor generation and institutional positions"),
      L("上部画出同一发生轨迹准入的多枚种子；谱系值相同的种子生成同一主体。下部单独展开同源制度装配的角色、服务与责任行，区分承担者、控制者和受益者的位置，不把装配关系虚构为串行经历。",
        "The upper panel shows several admitted seeds from one occurrence trace; equal lineage values generate one actor. The lower panel separately displays roles, service and a responsibility row in the same-source institutional assembly, distinguishing bearer, controller and beneficiary without inventing a serial life history."))
    panel(40,44,"A","轨迹中的种子，经谱系像生成主体","Trace seeds generate actors through the lineage image")
    arrow(75,132,565,132,DEEP,"deep")
    for x,label in [(130,"{i:x}{sub:0}"),(280,"{i:x}{sub:1}"),(440,"{i:x}{sub:2}")]:
        dot(x,132,8)
        txt(x,102,label,29,DEEP,anchor="middle")
    txt(75,187,L("同一发生的轨迹","occurrence trace"),27,SLATE,max_width=190)
    rect(225,253,270,94,HAIR,radius=47,dashed=True)
    arrow(280,145,280,263,DEEP,"deep")
    arrow(440,145,440,263,DEEP,"deep")
    txt(336,230,L("准入见证","admission"),26,SLATE,anchor="middle")
    for x,label in [(280,"{i:s}"),(440,"{i:t}")]:
        circle(x,299,29)
        txt(x,309,label,30,DEEP,anchor="middle")
    path("M 495 299 C 650 299, 790 255, 958 255",DEEP,2.2,"deep")
    txt(735,205,L("谱系值相同","equal lineage"),28,SLATE,anchor="middle")
    txt(360,379,L("同谱系类","one lineage class"),26,SLATE,anchor="middle")
    txt(735,379,"ℓ({i:s}) = ℓ({i:t})",31,DEEP,anchor="middle")
    circle(1024,255,58,DEEP,width=2.6)
    txt(1024,267,"ℓ({i:s})",31,DEEP,600,"middle")
    txt(1173,254,L("一个主体","one actor"),30,DEEP,600)
    txt(1173,296,L("多枚种子","several seeds"),27,SLATE)
    txt(720,436,"{i:U}{sub:ω} / ∼{sub:ℓ} ≅ {i:A}{sub:ω}",33,DEEP,anchor="middle")
    txt(720,480,L("每个主体都有轨迹内的源种子；谱系值决定哪些种子合并",
      "Every actor has a trace seed; lineage decides which seeds are identified"),27,INK,anchor="middle")
    rule(511)
    panel(40,561,"B","制度位置保留各自的关系与来源","Institutional positions retain their relations and sources")
    rect(50,604,310,170,DEEP,width=2.2)
    txt(205,647,L("同源的已安装程序","same-source program"),28,DEEP,600,"middle",280)
    txt(205,693,L("角色 {i:r} 与实际服务 {i:s}{isub:j}","role {i:r} · actual service {i:s}{isub:j}"),26,SLATE,anchor="middle",max_width=280)
    txt(205,738,L("各有发生见证","occurrence witnesses"),26,SLATE,anchor="middle",max_width=280)
    arrow(369,691,466,691,DEEP,"deep")
    rect(475,604,915,170,HAIR,radius=0)
    path("M 475 666 L 1390 666",HAIR,1.6)
    for x in [615,870,1125]:
        path(f"M {x} 604 L {x} 774",HAIR,1.6)
    txt(545,647,L("责任行","row"),27,SLATE,600,"middle")
    txt(742,647,L("承担者","bearer"),27,SLATE,600,"middle")
    txt(997,647,L("控制者","controller"),27,SLATE,600,"middle")
    txt(1257,647,L("受益者","beneficiary"),27,SLATE,600,"middle")
    txt(545,723,"{i:δ}",34,DEEP,600,"middle")
    txt(742,723,L("该行承担者","bearer of row"),30,DEEP,600,"middle",230)
    txt(997,723,L("乙","controller B"),30,DEEP,600,"middle")
    txt(1257,723,L("相应主体","relevant actor"),28,INK,anchor="middle")
    txt(720,836,L("主体可占多个位置；每项权力和责任都须保留自己的来源",
      "An actor may occupy several positions; each power and responsibility keeps its source"),27,INK,anchor="middle")
    save("02-generation",h,{"focus":"lineage quotient and distinct institutional positions",
      "multipleSeedsPerActor":True,"relation":"ell(s)=ell(t) iff s~_ell t; U_omega/~_ell is canonically bijective with A_omega",
      "lowerPanel":"same-source assembly, not a new serial execution","bearerSource":"original responsibility row; not identified with requester A","proofLocation":"supplement A.1; foundation C.1"})

def root_law():
    h=start(900,L("四类处置及写入界限","Four dispositions and the boundary of writing"),
      L("对同一完整已安装程序的生成执行逐构造分类。呈现与拒绝没有写入；行动和精确失败修订各自携带完整写入与实际后继。行动包含顺序与新责任准入两叶。修订仍取决于已安装的精确失败路线。",
        "Constructor analysis of one generated execution of a fully installed program. Presentation and refusal have no write; action and exact-failure revision each carry a complete write and actual successor. Action includes both sequential action and debt admission. Revision depends on the installed exact-failure route."))
    rect(220,32,1000,82,DEEP,width=2.2)
    txt(720,84,L("给定完整已安装程序、准确访问与其生成执行",
      "A fully installed program, its exact visit and its generated execution"),30,DEEP,600,"middle",960)
    path("M 720 114 L 720 146 M 350 146 L 1090 146",SLATE,2.2)
    arrow(350,146,350,170,SLATE,"ink")
    arrow(1090,146,1090,170,SLATE,"ink")
    rect(40,178,620,532,HAIR,radius=0)
    rect(780,178,620,532,VERMILION,width=2.5,radius=0)
    txt(350,220,L("呈现与拒绝","Presentation and refusal"),29,SLATE,600,"middle")
    txt(350,256,L("只读处置；没有世界写入","read-only dispositions; no world write"),25,SLATE,anchor="middle",max_width=560)
    txt(1090,220,L("行动与修订","Action and revision"),29,VERMILION,600,"middle")
    txt(1090,256,L("各有写入与实际后继","writing and actual successors"),25,INK,anchor="middle",max_width=560)

    def leaf(x,y,title,tag,lines,accent=False):
        rect(x,y,560,180,HAIR)
        txt(x+30,y+44,title,30,DEEP,600,max_width=300)
        txt(x+530,y+43,tag,25,VERMILION if accent else SLATE,600,"end",max_width=230)
        text_lines(x+30,y+88,lines,26,INK,gap=38,max_width=500)

    leaf(70,286,L("呈现","Presentation"),L("无写入","no write"),[
      L("实际呈现或既定回答","actual presentation or installed answer"),
      L("保留对应的呈现见证","its presentation witness is retained")])
    leaf(70,494,L("拒绝","Refusal"),L("无写入","no write"),[
      L("精确拒绝及处置等式","exact refusal and disposition equation"),
      L("残差承担对象：被拒提交自身","residual bearer: the refused submission")])
    leaf(810,286,L("行动","Action"),L("完整写入","complete write"),[
      L("顺序行动 ／ 新责任准入","sequential action / debt admission"),
      L("源行动与安装输出相符","source action matches installed output"),
      L("准入新责任在同次整账中首写","admission enters the same whole first write")],True)
    leaf(810,494,L("修订","Revision"),L("首次完整写入","first complete write"),[
      L("精确失败与同一责任行修订核","exact failure; revision core on the same row"),
      L("既有修法路线与安装输出相符","revision route matches installed output"),
      L("旧行、新行各有后续处理","old and new rows: subsequent processing")],True)
    rule(742)
    txt(720,804,L("四类穷尽公共处置；写入 ⇔ 行动或修订",
      "Four exhaustive dispositions; write iff action or revision"),28,INK,600,"middle")
    txt(720,850,L("两类写入互斥；没有第五种账外写入权限",
      "Disjoint writing leaves; no fifth writing authority"),28,INK,600,"middle")
    save("03-root-law",h,{"focus":"the precise boundary of world writing","exhaustiveClasses":4,
      "actionLeaves":["sequential","debtAdmission"],"refusalBearer":"original generated submission",
      "revisionConditional":True,"classificationNotInhabitation":True,"proofLocation":"supplement A.2–A.4; B.1–B.2"})


def refusal():
    h=start(880,L("拒绝与节点支付上的继续","Refusal and continuation on the node’s payment"),
      L("外部错投的真实支付被拒绝，接受及消费者为空；拒绝不产生写入。另一区域在同一拒绝节点读取既有支付与典范立法，分别给出普通修复和修订后继。两种后继不同；同源事件只通过合法的依赖类型运输联系。",
        "A genuine payment submitted to a different node is refused; acceptance and its consumer are empty, with no write. A separate region reads the payment and canonical legislation already present at the same refusal node, yielding ordinary repair and a revised successor. The successors differ; source identity is used only through lawful dependent-type transport."))
    panel(40,44,"A","外部提交的处置","Disposition of the external submission")
    rect(50,80,470,132,HAIR)
    txt(285,129,L("另一节点的真实支付","genuine payment, wrong node"),28,INK,600,"middle",440)
    txt(285,174,L("源真实，本节点不接受","genuine source; not accepted here"),26,SLATE,anchor="middle",max_width=440)
    arrow(529,146,641,146,SLATE,"ink")
    path("M 653 116 L 653 176",VERMILION,5)
    txt(711,131,L("拒绝：接受与独立处理均为空","Refusal: no acceptance or independent processing"),29,VERMILION,600,max_width=670)
    txt(711,177,L("被拒提交保留；没有世界写入","Refused submission retained; no world write"),27,INK,max_width=670)
    rule(247)
    panel(40,299,"B","同一拒绝节点，读取已存在的来源","At that refusal node, read the sources already present")
    rect(50,356,350,142,DEEP,width=2.2)
    txt(225,402,L("节点支付 {i:q}{isub:r}","node payment {i:q}{isub:r}"),28,DEEP,600,"middle",322)
    txt(225,446,L("该节点已有的发生","already present at this node"),26,SLATE,anchor="middle",max_width=322)
    arrow(408,427,492,427,DEEP,"deep")
    rect(500,356,462,142,HAIR)
    txt(731,402,L("同一支付上的普通修复","ordinary repair on that payment"),28,DEEP,600,"middle",432)
    txt(731,446,L("甲、责任行 {i:δ} 与后续处理保留","A, row {i:δ} and later processing remain"),26,INK,anchor="middle",max_width=432)
    arrow(970,427,1042,427,DEEP,"deep")
    rect(1050,356,340,142,DEEP,width=2.2)
    txt(1220,402,L("普通实际后继","ordinary successor"),28,DEEP,600,"middle",312)
    txt(1220,446,L("修复前的法保留","old law retained"),27,SLATE,anchor="middle")
    txt(1220,565,"≠",43,INK,600,"middle")
    rect(50,616,350,142,DEEP,width=2.2)
    txt(225,661,L("该节点的典范立法","canonical legislation"),28,DEEP,600,"middle",322)
    txt(225,705,L("节点提案仍被接受","proposal remains accepted"),26,SLATE,anchor="middle",max_width=322)
    arrow(408,687,492,687,DEEP,"deep")
    rect(500,616,462,142,HAIR)
    txt(731,661,L("既有的同源修法路线","existing same-source law revision"),28,DEEP,600,"middle",432)
    txt(731,705,L("精确失败、首写与后续处理","exact failure and first write"),26,INK,anchor="middle",max_width=432)
    arrow(970,687,1042,687,DEEP,"deep")
    rect(1050,616,340,142,DEEP,width=2.2)
    txt(1220,661,L("修订后的实际后继","actual revised successor"),28,DEEP,600,"middle",312)
    txt(1220,705,L("由该节点的典范立法产生","from canonical legislation"),26,SLATE,anchor="middle",max_width=312)
    txt(720,825,L("同源事件经合法运输连接；节点支付为修复提供来源",
      "Lawful transport connects the source; the node’s payment supports repair"),27,INK,anchor="middle")
    save("04-refusal",h,{"focus":"empty external acceptance; original sources continue separately",
      "noArrowFromRefusalToAuthority":True,"ordinaryAndRevisedNextDistinct":True,
      "paymentBridge":"same source event with lawful transport, not equality of occurrences",
      "proofLocation":"supplement A.5.1–A.5.3"})

def regeneration():
    h=start(930,L("任意深度的同发生续生","Same-occurrence regeneration at every depth"),
      L("任意深度的同一完整支付共同生成六项续生内容。本次实际下一访问恰为下一深度入口；责任后态与访问保留各自类型，下一支付仍是新的事件。两列六条支线是共同投影，不是六个先后步骤。",
        "One complete payment at every depth jointly generates six continuation contents. Its actual next constitutional visit is the next depth's entry; responsibility post-states remain distinct from visits, and the following payment is a new event. The six branches in two columns are joint projections, not six sequential steps."))
    rect(40,40,270,130,VERMILION,fill=WASH,width=2.7,radius=0)
    txt(175,77,L("完整支付","complete payment"),29,VERMILION,600,"middle",244)
    txt(175,117,"{i:p}{isub:d}",38,VERMILION,600,"middle")
    txt(175,153,L("任意深度 {i:d}","at every depth {i:d}"),27,SLATE,anchor="middle",max_width=244)
    txt(635,82,L("同一支付，共同投影","one payment, joint projections"),25,SLATE,anchor="middle")
    path("M 310 105 L 910 105",VERMILION,2.5)
    arrow(360,105,360,160,VERMILION,"acc")
    arrow(910,105,910,160,VERMILION,"acc")
    path("M 360 160 L 360 690 M 910 160 L 910 690",VERMILION,2.5)
    rows=[
      (190,400,"既有法与谱系续接","Law and lineage continue",
       ["既有法与责任谱系","一并保留"],["Existing law and responsibility lineage","are jointly retained."]),
      (190,950,"普通退出不收缩","Ordinary exit does not contract",
       ["原有的可行继续","在后继中仍有见证"],["Every original feasible continuation","retains a successor witness."]),
      (370,400,"捕获纤维得到修复","The captured fibre is repaired",
       ["精确原因决定","它自己的修复"],["The exact cause determines","its own repair."]),
      (370,950,"残差承担者与后续处理保留","Residual bearer and processing",
       ["该责任行继续进入","实际处置"],["The row and later processing","reach actual disposition."]),
      (550,400,"后继仍有修法能力","Revision capacity continues",
       ["下一深度保留已安装的","同源修法路线"],["Installed same-source revision route","is retained at the next depth."]),
      (550,950,"跨主体责任继续归属","Responsibility stays assigned",
       ["该支付承担者与对方的","归属关系保留"],["The payment’s bearer–counterparty","relation is retained."]),
    ]
    for y,x,zh,en,zlines,elines in rows:
        rect(x,y,450,140,HAIR)
        bus=360 if x==400 else 910
        dot(bus,y+70,4,VERMILION)
        arrow(bus+10,y+70,x-10,y+70,DEEP,"deep")
        txt(x+25,y+40,L(zh,en),27,DEEP,600,max_width=400)
        text_lines(x+25,y+80,[L(a,b) for a,b in zip(zlines,elines)],24,INK,gap=34,max_width=400)
    path("M 360 690 L 360 730 L 530 730 M 910 690 L 910 730 L 530 730",DEEP,2.4)
    arrow(530,730,530,760,DEEP,"deep")
    rect(330,770,400,110,DEEP,width=2.2)
    txt(530,813,L("实际下一访问","actual next visit"),27,DEEP,600,"middle",360)
    txt(530,861,"{i:v}{sup:+}({i:g}) = {i:v}{isub:d+1}",32,DEEP,600,"middle",360)
    arrow(740,825,930,825,DEEP,"deep")
    txt(835,797,L("下一发生","next event"),25,SLATE,anchor="middle")
    rect(950,770,400,110,HAIR)
    txt(1150,813,L("下一完整支付","next complete payment"),28,INK,600,"middle",360)
    txt(1150,861,"{i:p}{isub:d+1}",32,DEEP,600,"middle")
    save("05-regeneration",h,{"focus":"one actual payment at arbitrary depth jointly generates all six contents",
      "parallelProjections":6,"actualNext":"v^+(g)=v_(d+1)","actualNextType":"constitutional visit; responsibility post-state remains distinct","paymentsNotEquated":["p_d","p_(d+1)"],
      "revisionRouteNotRevisionAtEveryStep":True,"proofLocation":"supplement B.6–B.8"})

def theory():
    h=start(800,L("理论采用与旧责任的后来清算","Theory adoption and later settlement of inherited responsibility"),
      L("上部区分实际理论采用的普通后继和同源母法的精确失败路线，不画出采用导致失败的因果箭头。下部追踪同一责任行：修订首写保留其谱系并使其仍活跃，后来的实际履行才将它归档清算。",
        "The upper panel distinguishes the ordinary successor of actual theory adoption from the same-source exact failure route, with no causal arrow from adoption to failure. The lower panel tracks one responsibility row: it remains live with its lineage at the first revised write; a later actual fulfilment archives and settles it."))
    rect(40,44,398,204,DEEP,width=2.2)
    txt(239,89,L("理论 {i:T} 的实际采用","actual adoption of theory {i:T}"),28,DEEP,600,"middle",370)
    text_lines(239,136,[L("分类与政策进入程序","classification and policy"),
      L("产生实际效应","an actual effect is produced")],26,INK,anchor="middle",gap=42,max_width=370)
    arrow(447,146,524,146,DEEP,"deep")
    rect(534,44,382,204,HAIR)
    txt(725,89,L("普通实际后继","ordinary actual successor"),28,DEEP,600,"middle",354)
    txt(725,141,L("已采用理论 {i:T} 保留","the adopted theory {i:T} remains"),27,INK,anchor="middle",max_width=354)
    txt(725,183,L("实际采用有自己的效应","the actual effect of adoption"),26,SLATE,anchor="middle",max_width=354)
    rect(1036,44,362,204,HAIR)
    txt(1217,89,L("同源母法的精确失败","exact failure of the law"),28,DEEP,600,"middle",334)
    text_lines(1217,136,[L("审查给出修订方向","same source; audited failure"),
      L("旧责任进入修订","revision direction generated")],26,INK,anchor="middle",gap=42,max_width=334)
    path("M 1217 258 L 1217 312 L 725 312 L 725 412",SLATE,2.2,"ink")
    txt(40,372,L("同一责任行的迁移与履行","Migration and fulfilment of the same responsibility"),28,INK,600)
    # The three row containers, rather than a generic causal chain, carry identity.
    rect(40,427,398,316,HAIR,radius=0)
    rect(534,427,382,316,VERMILION,width=2.7,radius=0)
    rect(1036,427,362,316,DEEP,width=2.2,radius=0)
    for x,w in [(40,398),(534,382),(1036,362)]:
        path(f"M {x} 504 L {x+w} 504",HAIR,1.6)
    txt(239,475,L("修订前的责任","responsibility before revision"),28,INK,600,"middle",370)
    txt(725,475,L("修订的首次写入","first revised write"),29,VERMILION,600,"middle",354)
    txt(1217,475,L("后来实际履行","later actual fulfilment"),28,DEEP,600,"middle",334)
    txt(239,562,"{i:δ}",40,DEEP,600,"middle")
    txt(725,562,"{i:i}({i:δ})",40,DEEP,600,"middle")
    txt(1217,562,"{i:i}({i:δ})",40,DEEP,600,"middle")
    arrow(446,559,526,559,DEEP,"deep")
    arrow(924,559,1028,559,DEEP,"deep")
    txt(486,611,L("迁移","migrate"),25,SLATE,anchor="middle")
    txt(978,611,L("履行","fulfil"),25,SLATE,anchor="middle")
    text_lines(239,629,[L("有来源与承担者","source and bearer retained"),
      L("尚有待履行的责任","an outstanding responsibility")],27,INK,anchor="middle",gap=45,max_width=370)
    text_lines(725,629,[L("责任谱系仍在","same lineage retained"),
      L("仍活跃，尚未结清","still live; not yet settled")],27,VERMILION,600,"middle",gap=45,max_width=354)
    text_lines(1217,629,[L("后续处理完成实际履行","later processing fulfils it"),
      L("归档并进入清算后继","archive; actual successor")],26,INK,anchor="middle",gap=45,max_width=334)
    save("06-theory",h,{"focus":"the migrated old row remains live at the first revised write",
      "adoptionAndFailureNotCausalSerialClaim":True,
      "claimLifecycle":["original row","migrated live row at first write","later actual fulfilment and archive"],
      "proofLocation":"supplement C.4"})

def paid_frontier():
    h=start(750,L("已付前沿的严格增长与不变的瞬时容量","Strict growth of the paid frontier with unchanged instantaneous capacity"),
      L("上部表示同一支付周期实际已付发生的权威像。下一付款步骤保留全部旧像，并在真实目标产生一个像外发生。下部单列当前容量可以保持为一的读出；图形大小不表示福利或服务数量。下一目标拥有自己的原生付款，前后发生保持不同身份。",
        "The upper panel shows authority images of actual paid occurrences in one payment cycle. The next paid step retains the entire old image and produces an outside occurrence at its actual target. The lower panel separately shows current capacity able to remain one. Geometry measures neither welfare nor a service count. The target has its own native payment; the occurrences remain distinct."))
    panel(40,46,"A","已实现的发生：旧像保留，目标产生新项","Realized occurrences: the old image remains and the target adds a new item")
    rect(60,108,480,280,DEEP,width=2.3,radius=0)
    txt(300,153,L("当前已付前沿","current paid frontier"),29,DEEP,600,"middle",452)
    txt(300,192,"{i:A}{isub:i}",35,DEEP,600,"middle")
    for x in [164,300,436]:
        dot(x,264,10,DEEP)
    txt(300,333,L("每一点保留各自发生身份","each point retains occurrence identity"),24,SLATE,anchor="middle",max_width=452)
    path("M 556 229 C 700 229, 760 216, 900 216 L 1280 216 L 1280 236",DEEP,2.4,"deep")
    txt(669,184,L("同一付款边","one paid edge"),27,DEEP,600,"middle",220)
    txt(669,282,L("实际目标","actual target"),26,SLATE,anchor="middle")
    rect(800,108,580,280,VERMILION,width=2.3,radius=0)
    txt(1090,153,L("下一已付前沿","next paid frontier"),29,VERMILION,600,"middle",552)
    txt(1090,192,"{i:A}{isub:i+1}",35,VERMILION,600,"middle")
    rect(828,230,364,73,DEEP,width=1.8,radius=0)
    for x in [886,1010,1134]:
        dot(x,264,10,DEEP)
    circle(1280,264,24,VERMILION,fill="white",width=2.8)
    dot(1280,264,7,VERMILION)
    txt(1010,333,L("旧像完整保留","old image retained"),24,INK,600,"middle",320)
    txt(1010,367,L("各发生身份不变","occurrence identities retained"),24,SLATE,anchor="middle",max_width=320)
    txt(1280,333,L("像外的新发生","new occurrence"),24,VERMILION,600,"middle",200)
    txt(1280,367,L("目标原生付款","native payment"),24,SLATE,anchor="middle",max_width=200)
    txt(720,443,"{i:A}{isub:i} ⊊ {i:A}{isub:i+1}",31,DEEP,600,"middle")
    rule(480)
    panel(40,526,"B","相邻时点的能力读数可以保持不变","Capacity can remain unchanged at adjacent times")
    txt(720,620,"{i:K}{isub:i} = {i:K}{isub:i+1} = 1",38,DEEP,600,"middle")
    txt(720,690,L("严格增加的是已兑现的发生像；容量读取当前可同时实现的退出",
      "Realized history grows; capacity counts exits realizable concurrently now"),27,INK,anchor="middle",max_width=1350)
    save("07-paid-frontier",h,{"focus":"entire paid authority image strictly grows while current scalar exit capacity may remain one",
      "sourceClaims":["G13","G14"],"sameOriginalPaidEdge":True,"directTargetArrow":True,
      "currentAndTargetNativePaymentsDistinct":True,
      "notInstantaneousOptionCountOrWelfareMeasure":True,
      "proofLocation":"main Theorems 1.2–1.3; supplement E.1–E.2"})

FIGURES=[("01-exit-case",exit_case),("02-generation",generation),("03-root-law",root_law),
         ("04-refusal",refusal),("05-regeneration",regeneration),("06-theory",theory),("07-paid-frontier",paid_frontier)]

def main():
    global LANG, CHECK_ONLY
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only",choices=[x[0] for x in FIGURES])
    ap.add_argument("--language",choices=["zh","en","both"],default="both")
    ap.add_argument("--check-only",action="store_true")
    args=ap.parse_args()
    CHECK_ONLY=args.check_only
    register_cjk_for_cairo()
    for LANG in (["zh","en"] if args.language=="both" else [args.language]):
        for name,fun in FIGURES:
            if not args.only or args.only==name:
                fun()
    report={"paperId":"generated-society","redesignDate":"2026-10-31",
      "referencePublishCommit":BASELINE,"generator":"make_figures.py",
      "historicalLaunchKit":"source/ retains its fixed bytes; see records/figure-source-provenance.json",
      "printedWidthPt":PRINT_WIDTH,"figures":MANIFEST}
    (OUT/".review").mkdir(exist_ok=True)
    target=".review/layout-report.json" if CHECK_ONLY else ("manifest.json" if not args.only and args.language=="both" else ".review/partial-manifest.json")
    (OUT/target).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"rendered":len(MANIFEST),"manifest":target,
      "outputs":[x["stem"] for x in MANIFEST]},ensure_ascii=False))

if __name__=="__main__":
    main()
