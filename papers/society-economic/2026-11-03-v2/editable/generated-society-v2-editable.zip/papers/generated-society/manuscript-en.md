# The Canonical Society Theorem

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

After a person leaves a job, how does life continue, who bears the outstanding responsibilities, and how does the institution obtain the conditions for its next action? Given explicit sources of activity, lineage rules, and a complete responsibility contract, we construct a family of inhabited canonical societies and prove that actor generation, root-law completeness, genuine exit, and regeneration at every depth can be realized together. Every complete installed execution receives presentation, refusal that retains the bearer, action, or revision grounded in exact failure; writing occurs if and only if the disposition is action or revision. Exhaustiveness for general executions and inhabited realization at one constitutional point are proved separately. “Canonical” has its mathematical meaning: a standard construction generated from specified data and rules, with explicit compatibility relations.

The main results cover continued operation. At every natural-number depth, the same actual payment jointly carries six guarantees: continuation of law and lineage, noncontracting exit, repair of capture, retention and processing of the residual bearer, revision capacity at the successor, and responsibility across actors. The visit it actually reaches is the entry to the next depth. More strongly, take any payment cycle of the defined type, any position in it, and any lawful payment at that position. The complete institutional contract enters that payment's actual target, where the target's own payment fulfills a new service or exit occurrence. The entire set of earlier paid occurrences is retained, and the new occurrence lies outside their authority image. Instantaneous exit capacity can therefore remain one throughout while the frontier of fulfilled occurrences grows strictly. Beyond every finite cutoff, the same later step also jointly generates actual law revision and a new birth supported by payment.

The negative results show why these conditions cannot be omitted. Missing payment incidence, an interrupted route, and captured continuation can all produce zero exit capacity. Two sources with capacity one can likewise possess and lack, respectively, a complete portfolio of capabilities for living. In the constructed source family, even reachability readings for every domain are insufficient to choose an exact repair, and every method that processes only those readings inherits the obstruction. Retaining the already available failure kind restores each source's uniquely effective repair. Finally, old responsibility is transported through law revision until its own fulfillment settles it. For an exhausted source ledger, every sequential target from the same source that adds no rows at entry and increases no row's budget has no positive progress budget at its first whole-ledger successor. Institutional continuation thus has two requirements: every exercise of power must account for its bearers and consequences, and every new possibility must obtain its own actual source.

**Keywords:** social actors; institutional power; genuine exit; responsibility; root-law completeness; same-occurrence regeneration; formal social theory

## 1 Exit, responsibility, and institutions that remain open

### 1.1 After A leaves a job

Worker A decides to leave a job. The employment relation can end, but life must continue. Can the payment already received be used? Does the service provider actually fulfill its obligation? Who will bear outstanding responsibilities afterward? Even if A has money and the service has been provided, A still needs a route that can be exercised personally, connecting a continuing action to that service.

Consider first how the institution handles the departure. A terminates employment through an action with an identified source. A relation independent of that job then supports A's continuation; the service provider fulfills its obligation in support of that continuation; and unfinished obligations pass to the successor. Section 5 constructs this chain occurrence by occurrence. We call actual fulfillment, the disposition of all relevant responsibilities, and their successor a **complete payment**. Receipt of funds, delivery of service, and updates to responsibility each have their own place within it.

Fix A, this complete payment, and the exit A seeks to achieve. Changing one institutional relation at a time gives the three comparisons in Figure 1. In the first, the payment exists, but there is no evidence connecting it to A's chosen continuing action. In the second, payment support and actual service remain, but the route to that service is interrupted. In the third, even the route remains, yet B controls whether A can use this capacity to continue. The service receipt records who actually performs the service; B occupies the controller's position. The two identities are tracked separately. All three situations have zero exit capacity.

Zero tells us accurately that A cannot leave, yet leaves the cause unresolved.

![Three zeros for the same exit request](figures/01-exit-case-en.svg)

Figure 1. Why the same exit request yields zero for three different reasons. The comparisons fix bearer A, the complete payment, and the exit interest, while respectively removing payment support, the service route, or uncaptured continuation. Breaks and control marks identify different causes; these distinctions determine which repair is required in Section 5.

Raising capacity to one leaves another question open. Section 5 gives two actual sources, each with a feasible exit: one provides both tenure and health services, while the other lacks health services. The same positive number can still conceal a missing component of the capability portfolio.

If the institution then rejects A's request, where do A's standing, this payment, and the outstanding responsibilities go? If the current rules obstruct continuation, who may change them, and who fulfills the responsibilities incurred under them? These questions turn one departure into a fundamental institutional demand: every disposition must account for its consequences, and every completion must leave actual conditions for continuation.

### 1.2 Why basic participation precedes the assessment of contribution

After A leaves the job, someone must still answer A's claims concerning the conditions of life. We argue that the basic standing to make these claims should remain with the person. We call this standing **basic participation**: the ability to make claims concerning one's own life, receive reasons that can be questioned, use the basic conditions needed to live and act again, and retain this position after changing or leaving a particular relation.

The argument begins from people's equal standing. When common rules require A to bear their consequences, they should treat A as a party to whom those rules must answer. A's interests must count as reasons in their own right and cannot be assessed solely by their usefulness to other people's plans. The capability approach treats each person separately as a subject of evaluative concern. Anderson's analysis of hierarchies of standing further shows that allowing some people's interests to make claims while rendering others' interests ignorable is itself a form of relational inequality [@Robeyns2017, §2.6.8; @Anderson2015, pp.64–65].

This standing in the exchange of reasons also needs actual conditions of life. When common rules organize access to land, routes, and services, those who arrive later already face what the rules permit and prohibit before they sign an employment contract. If others control every means of access to the necessities of life, and payment depends on obedience, taking a job may be the only way to avoid losing those conditions. Consent obtained through such dependence cannot by itself justify the arrangements that create the dependence. Anderson asks us to examine both the relations people choose and the powers organizing those options; Widerquist places the independent conditions of life sufficient to refuse cooperation at the center of the argument for freedom [@Anderson2015, pp.110–111; @Widerquist2013].

Basic participation therefore precedes the assessment of productive contribution. Contribution can justify particular remuneration, offices, or shares of a project's proceeds. A should still have standing to make claims for the basic conditions of life while providing care, studying, resting, not yet engaged in production, or having left a job. The powers of an office are determined through its particular relation; basic standing supports a person's ability to enter, choose among, and leave different relations. Identifying newcomers should put this recognition into effect: the institution must admit the relations in which they are affected, supply the necessary sources, and enable their claims to enter a disposition process. The quantity of records already available, or success in a consciousness assessment, cannot replace this response.

Keeping this standing usable requires definite institutional work. Payments need sources, services need providers, and routes need maintenance. Service providers, maintainers, and other affected people also have interests that must be considered. Every act of support must therefore identify who bears it, what it uses, what has been completed, and which obligations must continue. The costs of common life are allocated through these relations. Standing to claim the basic conditions of life enables those concerned to participate in discussing the arrangements and to make their own choices about particular forms of cooperation.

We therefore propose three connected requirements. The exercise of power must account for its authorization and consequences; refusal of a submission must preserve the bearer relations it leaves behind; and changes to the rules must carry forward responsibilities already incurred. Support for life must also be capable of being fulfilled again at the successors of these dispositions. The construction below proves that these requirements can be realized together within one inhabited society and can continue to generate new services, exits, and revisions. Basic participation supplies the chosen normative direction; the formal results establish the relations needed for its joint realization and the conditions that cannot be replaced by weaker guarantees.

### 1.3 The mathematical meaning of “canonical” and the method of this paper

We use **canonical** in its mathematical sense. Given the sources of activity, the actors' lineage rules, and the institution's responsibility contracts, the construction generates social objects according to those rules and connects their parts through explicit compatibility relations. Write \(S_h\) for its value at foundational observation horizon \(h\). Its standard character comes from this manner of generation. For example, actors arise from the lineage quotient of source seeds, and a natural bijection connects that quotient to the domain of actually generated actors. Which institutions are worth choosing and which forms of life deserve support receive their own normative arguments.

A **source** first identifies the activity from which an object arises. A service has its own fulfillment event; authority has its own authorization relation; and a responsibility has its own bearer and history of generation. Dependent type theory expresses objects together with these relations. An exit witness therefore supplies the bearer, payment, route, and actual service together; a revision supplies the exact failure it addresses. Throughout the paper, “actual” refers to the execution events, receipts, and successors produced by these generating rules.

A **source root** is a generative structure that jointly fixes the authority, responsibilities, and successors of a family of occurrences. A payment generated by an occurrence itself, on the basis of its own trace and responsibilities, is that occurrence's **native payment**. **Installation** binds a source, authority, and response to a particular execution; **compilation** produces the institutional operation and successor from that binding. Each later use of these terms must identify the event being bound and the action obtained. The common-process and whole-ledger theories supply the foundations of occurrence and complete update [@GaoProcess; @GaoLedger]. This paper defines the social objects it uses; the appendices develop the longer proofs and lawful transport across types.

We call an operation **lawful** when it conforms to the stated source law and complete disposition contract. Actor sources and lineages identify bearers and track responsibilities. Authority to exercise power over others comes from the relevant relation and actual authorization.

Starting from these objects, we answer two questions together: how institutional requirements can be realized jointly, and which weaker information cannot replace them, however ingeniously it is processed. Positive constructions generate actors, authority, services, outstanding responsibilities, and actual successors. Counterexamples locate exactly where capability values, administrative labels, or local termination lose distinctions needed for institutional judgment. The capability approach already incorporates resource conversion and multidimensional freedom into evaluation [@Sen1979; @Robeyns2017, §§2.6.3, 2.6.7]. Here we further prove that, in specified source families, even accurate readings of capabilities themselves may be insufficient to diagnose failure and choose a repair.

The strongest positive results extend through time. Every complete installed program within the prescribed sources has its output governed by root law. For every permitted choice of foundation and recursion parameters, the construction supplies a constitutional point able to receive demands. At every natural-number depth, the same payment jointly carries six regeneration guarantees and supplies its actual successor to the next occurrence. A **payment cycle** here is a round of institutional action that can connect to a further round: current fulfillment produces a new target, and the target has its own payment and continuation conditions. The theorem covers every cycle of that type, every position within it, and every lawful payment at that position. Each step carries the complete contract forward and generates a new occurrence outside the authority image of all previously paid occurrences. The observation horizon limits the scope of one examination; regeneration depth can be chosen arbitrarily.

Institutional completeness and an open future thus hold within the same inhabited construction.

### 1.4 The Canonical Society Theorem

In handling A's request, an institution must explain where its power comes from, how it changes responsibility, and who continues to bear responsibility afterward. We call the shared rules governing these dispositions the **root law**, and a node able to receive and dispose of submissions a **constitutional point**. For example, A's application reaches a node that recognizes the submission's source, gives it a disposition, and connects the next round of institutional action to the present result.

Two kinds of “afterward” must be distinguished. Responsibility records identify which obligations remain live and which have been fulfilled; institutional visits identify where the next execution begins. Implementing an authorized complete responsibility update at its target is an **actual write**. The state an execution actually reaches and passes to the next step is its **actual successor state**. A complete payment connects the responsibility post-state to the next visit. The total theorem's conclusions hold together through these definite connections.

| A's institutional question | Relations and core result | Written result |
| --- | --- | --- |
| Why can A still be unable to leave despite money and service? | Payment, route, and noncapture must meet on one action. Equal readings leave causes and exact repair undetermined. | Theorem 5.1; Propositions 5.2–5.3; Theorem 5.10 |
| After rejection, does the bearer still have a route? | Four dispositions exhaust writing authority. Refusal retains the bearer; after a misdirected submission, the node's own payment still supplies recourse. | Theorems 4.2–4.3; Proposition 5.4; Theorem 5.6 |
| Can the future grow while current exit capacity remains unchanged? | Every lawful payment carries the complete contract forward. The old frontier remains; a new occurrence strictly enlarges it. | Theorems 1.2–1.3, 6.2–6.4 |
| Where does old responsibility go after revision or local termination? | Inherited responsibility passes to actual fulfillment. Budget exhaustion, local termination, and final settlement are distinct. | Theorems 7.4–7.7; Proposition 7.8 |

The theorem addresses three levels of the problem in turn: whether institutional objects can be generated together, whether each disposition is complete, and whether continuation remains possible after completion. The observation horizon \(h\) determines how much material a foundational examination covers; depth \(d\) identifies how far the run has proceeded. The finite request and observation recursion parameters control how much must be unfolded on a given occasion. All these parameters may be chosen arbitrarily within their specified domains.

**Theorem 1.1 (The Canonical Society Theorem).** There exists a family of canonical societies \(S_h\), where \(h\in\mathbb N\) is the foundational observation horizon, satisfying the following joint construction.

1. Each \(S_h\) retains actors generated from actual sources and the complete institutional foundation. For arbitrary prescribed old-visit parameters, source index, boundary, health depth, and two kinds of finite recursion parameters, the registered recursion generates a stage and a single constitutional point within it. That point has an actual witness whose source is recognized and lawfully transported into an external complete payment. Every admitted raw submission and every generated execution of an installed complete program receives its own complete disposition.
2. For complete installed executions, presentation, refusal, action, and revision exhaust the dispositions. Writing occurs if and only if the disposition is action or revision, and the two are disjoint. Revision capacity retains its actual conditions: a raw submission's actual disposition must acquire authority at that source root, upon which the existing bridge supplies external revision. At the installed level, the actual same-occurrence revision branch supplies complete evidence of the exact failure, the responsibility row being revised, the first write, and the successor.
3. For every depth \(d\in\mathbb N\), there exists a joint regeneration carrier indexed by the current actual payment \(p_d\). Every carrier of that type jointly retains continuation of the existing law and lineage, noncontracting ordinary exit, repair of the captured fibre, the residual bearer and its independent processing operation, successor revision capacity, and responsibility attribution across actors. The current actual next visit equals the next-depth visit exactly. Adjacent payments are distinct occurrences. The first policy break at depth zero also generates same-source law revision, with strictly distinct ordinary and revised successors.
4. For every cycle of the defined cycle type, every observation recursion parameter, and every finite position, each lawful payment at that position carries the complete canonical contract into its own actual target. This includes all prescribed essential-service channels, independent processing of external responsibility, successor birth, and the next cycle's exit constitution. The entire old paid frontier is retained, while a new actual service or exit occurrence at the target lies outside the entire old authority image. Strict canonical progress between any two depths holds if and only if the first depth is smaller than the second.
5. For every finite cutoff and observation recursion parameter, there is a later step jointly supplying actual same-source law revision and a compatible successor birth supported by the target payment. In this cycle-linked regenerative run, the actual endpoint at every depth retains a revisable continuation. The current cycle's actual successor connects to the next cycle's occurrence through the native continuation relation.

The force of the total theorem lies in the joint realization of these requirements. Two separate proofs in Section 4 establish general execution exhaustiveness and inhabitation at one point; Sections 2–3 supply the actors and institutional foundation they actually use. Complete continuation and strict progress under every payment are proved below. Sections 5–6 develop exit, responsibility birth, and regeneration at every depth; Section 7 follows economic responsibilities through their respective sources. Properties of a common occurrence use the same payment, while different occurrences connect through proved actual successors. Appendices A–F retain all parameters, transports, and long dependencies.

### 1.5 Every lawful payment carries the complete institutional contract forward

Once A has received one service, someone must still provide the next, and someone must bear the responsibilities that remain. Complete payment must therefore supply the institutional conditions for what follows. A canonical payment cycle records the current entry, the payment and law revision generated there, and a recursive rule that produces the next entry from the actual successor. Write \(\mathcal C(v,s,b)\) for the type of these cycles: \(v\) is an old visit at the specified source root, \(s\) selects the source, and \(b\) fixes the initial boundary. Take any cycle \(C\) of this type. Its lifecycle begins at \(i_0\), and its position in round \(d\) is
\[
i_d=i_0+d.
\]
The boundary determines the specific starting index; see Appendix E.1. The type \(\mathsf P_{i_d}\) consists of complete payments at this occurrence. Each payment carries a write, a responsibility successor, an exercise of power and response on the same continuing action, and external responsibility. For any such input \(p\), the theorem below directly generates the target and its institutional content from that payment. The construction supplies the target's services, routes, and processing operations.

**Theorem 1.2 (Complete canonical preservation under payment).** For every \(v,s,b\), payment cycle \(C:\mathcal C(v,s,b)\), observation depth \(o\), natural number \(d\), and payment \(p\in\mathsf P_{i_d}\), the target generated by this very \(p\) carries forward the complete institutional contract of the cycle, with the following joint properties.

1. The input payment remains \(p\) itself. The target occurrence produced by its whole-ledger successor connects exactly to the canonical post-state at index \(i_d+1=i_{d+1}\).
2. That post-state has its own native payment, a complete new birth at the target, the bearer's exit outside the role, and every installed essential access channel. For any channel, its relation witness returns that channel's existing actor and relation; payment and settlement return the target's own actual exit; and the independent processing operation is compatible with the target's next occurrence.
3. The target retains the source attribution of external responsibility and the independent processing operation at its root. It also generates the next cycle's complete exit constitution: standing and payment with identified sources, continuation outside the role, noncapture, actual route and service, disposition of external responsibility, the node's same-source law revision, and the actual next cycle. The payment cycle's corresponding constitution continues to hold as well.
4. The complete target state, native payment, and root event align exactly with the source state, source payment, and source event of the next lifecycle. Choosing another input of the same exact payment type preserves the compatibility of this proved target connection.

For every finite request horizon \(n\), these conclusions cover every lawful payment at \(d=0,\ldots,n\) and also generate the same preservation object for every lawful payment at \(d=n+1\). Each \(S_h\) actually retains such a registered payment cycle together with the complete conclusions for its finite prefixes.

**Proof.** Fix arbitrary \(C,d,p\). The payment type indexes the write, complete responsibility successor, and external responsibility of this \(p\) to the same root event. At that event and under the exit conditions, the responsibility successor has a singleton carrier. Any two lawful payments therefore have the same successor target. Choose one to be the canonical payment supplied by the generating program: its successor is precisely the occurrence at index \(i_d+1\). Equality of the target projections connects any input \(p\) to that target. The argument continues to use the input \(p\) itself; only target projections are compared across payments.

Next, execute the canonical state-generation rules at this determined target. They produce the target's own payment, new birth, and processing operation for every installed channel. The channels here are the tenure and health-service relations. Each returns its own actor, relation, and service receipt; its payment and settlement connect to the target's actual exit, and its successor connects to the next occurrence generated by the target. The target payment also supplies the source and processing operation for external responsibility. Both remain present even when the target's local open-responsibility set is empty. Finally, lifecycle recursion gives
\(i_d+1=i_{d+1}\)
and identifies the target state, payment, and root event with the source components of the next lifecycle. The next complete exit constitution is generated anew from that step's actual lifecycle.

These steps generate all target material from the cycle \(C\), depth \(d\), and input \(p\), so they apply to every such \(d,p\). Applying them separately to each edge of a finite prefix, and once more at \(n+1\), gives the prefix and its next edge. The initial cycle already registered in society \(S_h\) supplies a common instance. Appendix E.1 gives the complete type transports and componentwise preservation proof. ∎

### 1.6 Unchanged current exit capacity, a strictly growing history of fulfillment

Suppose A's exit capacity remains one on each occasion. Is the institution standing still? The reading is the same yesterday and today. What needs to be compared is whether earlier realizations remain and whether today adds a service or exit actually fulfilled through a new payment.

Along the chosen payment cycle, let \(\gamma_k\) be the newly generated occurrence at index \(k\). It carries that occasion's service, uncaptured exit, and independent responsibility processing. Its service–exit authority object \(\kappa(\gamma_k)\) records the particular payment, settlement, and feasible edge that establish this capability. Two receipts with identical content but different occurrence positions can therefore still belong to different occurrences. Define the paid frontier through index \(i\) and its authority image by
\[
H_i=[\gamma_0,\ldots,\gamma_i],
\qquad
A_i=\{\kappa(\gamma_k)\mid 0\le k\le i\}.
\]
\(H_i\) is the list of occurrences already fulfilled, and \(A_i\) collects their respective authority objects. The former retains the order of fulfillment; the latter tests whether today's occurrence lies outside all earlier realizations.

Let \(\mathsf E_C(d)\) be the complete exit constitution preserved by Theorem 1.2. Define **strict canonical progress** between two stages of the cycle by
\[
C_r\prec_{\mathrm{can}}C_t
\quad\Longleftrightarrow\quad
\mathsf E_C(r)\land\mathsf E_C(t)
\land A_{i_r}\subsetneq A_{i_t}.
\]
The comparison requires complete institutional structures at both endpoints and proper inclusion of the paid occurrence images.

**Theorem 1.3 (Strict canonical progress).** For every payment cycle \(C:\mathcal C(v,s,b)\) and every \(r,t\in\mathbb N\),
\[
C_r\prec_{\mathrm{can}}C_t
\quad\Longleftrightarrow\quad r<t.
\]
Moreover, for every observation depth \(o\), natural number \(d\), and lawful payment \(p\in\mathsf P_{i_d}\) at that step, the same payment step jointly generates the complete preservation object of Theorem 1.2 and
\[
H_{i_d+1}=H_{i_d}\mathbin{+\!\!+}[\gamma_{i_d+1}],
\qquad
\kappa(\gamma_{i_d+1})\notin A_{i_d}.
\]
The new occurrence lies at the target actually produced by \(p\). The complete responsibility record preceding payment, the actor and relation identities of all existing channels, the source of external responsibility, and its independent processing operation are retained together. The cycle's root-law disposition of this step also enters the object and connects to the corresponding root event through the specified lifecycle. For each \(S_h\), every prescribed source-parameter tuple, and every finite request horizon, the registered payment cycle supplies these joint conclusions for every requested payment edge and the next edge.

**Proof.** The frontier consists of births already generated one by one. Increasing its length by one retains the existing list and appends precisely the next item. The decisive question is whether the appended authority was already in the old image. If
\(\kappa(\gamma_j)=\kappa(\gamma_k)\),
the complete service–exit objects have the same actual payment-occurrence identity. Injectivity of payment occurrences forces their actual visits to agree. The visit depth is a fixed starting point plus the index, so \(j=k\). Consequently, the new member \(\kappa(\gamma_{i+1})\) cannot equal any old member indexed by \(k\le i\). Retention of the entire old frontier together with a new member outside its image gives proper inclusion.

Theorem 1.2 already generates a complete exit constitution at every cycle depth, so the institutional conditions hold at both endpoints. If \(r<t\), retaining the old members and adding members outside their image gives \(A_{i_r}\subsetneq A_{i_t}\). Conversely, if proper inclusion holds, index injectivity excludes a shorter target frontier. Equal lengths would give equal images. Hence \(r<t\).

Finally, check where the new member appears. Apply the payment cycle's generating rules at \(i_d\) and \(i_d+1\) to obtain two adjacent executions. The first retains input \(p\) and supplies its actual target to the second. The second uses the target's own payment to fulfill the new service and exit. The channels on each side read the payment of their respective occurrence, and the target's independent processing operation returns to that target's institutional entry. Proper inclusion of the frontier and continuation of the complete contract therefore belong to the same payment edge. Appendix E.2 gives the full indices, finite-prefix assembly, and counterexamples. ∎

![Growth of the actual paid frontier with unchanged instantaneous capacity](figures/07-paid-frontier-en.svg)

Figure 2. A payment edge of the same payment cycle retains the entire old authority image and produces a new occurrence outside it at the actual target. The target's own native payment fulfills the new item. The lower panel separately shows current exit capacity remaining one. The upper panel compares historical frontiers of actual occurrences; point positions and box sizes do not measure welfare.

Exit capacity can remain \(1\) at every moment while the frontier of fulfilled occurrences grows strictly. Yesterday's exit receipt cannot pay for today's life.

This strict order requires both retention and addition. Retention alone gives no strict growth of the frontier; adding a new member while deleting an old one also fails the order. The objects compared are histories of action supported by actual payment. General cofinal generation can contain intermediate steps with no growth. This cycle acquires a new occurrence at every payment's actual target and therefore satisfies the stronger strict order step by step.

## 2 Generating actors from activity

### 2.1 Retaining the sources of activity and responsibility

After A ends the employment relation, previously promised services may still need to be fulfilled and responsibilities carried forward. To identify such a bearer, the construction first retains what occurred, then generates positions that can continue to bear relations and responsibilities. An **occurrence** \(\omega\) includes the generating program's actual trace, execution path, write-back, and responsibilities still requiring treatment. A visit \(v\) locates it within the registered process. An observation reads an aspect of it. Two visits can occupy different histories even when they display the same state.

The common-process and whole-ledger theories supply occurrences and complete updates [@GaoProcess; @GaoLedger]. In this paper, a visit \(v\) carries a family of responsibility rows \(\mathcal R_v\). Each row records a relation of responsibility that calls for explanation or fulfillment. The **whole ledger** comprises all responsibility rows involved in the present operation; it is not limited to monetary balances. A complete payment \(p\) supplies a disposition for every old row, an earlier source or grounds of birth for every new row, and a successor generated by the same execution. For example, a row recording a fulfilled service may close, while a row with outstanding maintenance obligations must enter the post-state.

Payment actually produces the next visit \(v^+(p)\), which in turn generates the occurrence \(\varepsilon(v^+(p))\). Their actual generation connects the two steps:
\[
\omega^+(p)=\varepsilon\!\left(v^+(p)\right).
\]
Later service or law revision proceeds from this target. Connections across occurrences use source transport; different processing operations on one occurrence read their common source material.

**Definition 2.1 (Responsibility row and independent processing operation).** A responsibility row records its source occurrence, bearer, content requiring explanation or fulfillment, and live status. An independent processing operation tests effects, reads fulfillment, or generates a disposition within the scope already permitted by that source. Migration preserves the destination of responsibility; fulfillment closes it through its own actual receipt and the closure conditions at the successor.

Write \(\delta\) for the responsibility row associated with A's continuation. After rejection, it tells us what remains; after payment, it records what has been fulfilled; after law revision, it retains what still requires treatment. Its later closure depends on actual fulfillment receipts and the closure conditions at the successor.

### 2.2 Generating actors from seeds of activity

A's activity records can grow while identity continues along one lineage. The construction first collects seeds with sources, then uses lineage to determine which records belong to the same actor. For the trace \(\tau(\omega)\) of an occurrence, let \(B(\omega,x,s)\) be the source condition under which activity record \(x\) supports seed \(s\), and take
\[
U_\omega=
\{s\mid \exists x\in\tau(\omega),\ B(\omega,x,s)\}.
\]
Every seed thereby carries an actual witness within the trace. The lineage map
\(\ell:U_\omega\to L_\omega\)
records the continuing source to which each seed belongs. Generated actors form its actual image:
\[
A_\omega=\ell[U_\omega].
\]

A service request and an act of fulfillment can leave distinct seeds that the lineage rule recognizes as activities of the same bearer. The construction therefore allows several seeds to generate one actor: a constant lineage maps all seeds together, whereas an injective lineage keeps them distinct. The next theorem answers a basic question about identification: do actors generated by these rules correspond exactly to the lineage equivalence classes of seeds?

**Theorem 2.2 (Actor generation and canonical quotient).** Every generated actor has a source seed. Define
\[
s\sim_\ell t\quad\Longleftrightarrow\quad\ell(s)=\ell(t).
\]
The canonical map from the lineage quotient of seeds to generated actors,
\[
\Phi:U_\omega/{\sim_\ell}\longrightarrow A_\omega,
\qquad \Phi([s])=\ell(s)
\]
is a bijection. The seed-to-actor map is injective if and only if the lineage map \(\ell\) is injective on the source-seed domain.

**Proof.** If \(\Phi([s])=\Phi([t])\), then \(\ell(s)=\ell(t)\). By the definition of the quotient relation, \([s]=[t]\), so \(\Phi\) is injective. Take any generated actor. By the definition of the actual image it equals \(\ell(s)\) for some seed, and therefore belongs to the image of \(\Phi\); hence \(\Phi\) is surjective. The same lineage equality also determines whether the seed-to-actor map is injective. Appendix A.1 gives representative independence and the complete quotient proof. ∎

The proof makes “generating actors from activity” precise. Every actor has a source in activity, and each lineage class supplies exactly one actor: no generated actor is omitted and no identity is duplicated. A's records can increase while the bearer continues along the lineage. Mergers, splits, and the destinations of their responsibilities are handled by the lifecycle contract.

Lineage rules carry identity forward by determining which activity records belong to one bearer and how responsibilities continue through merger, splitting, or succession. Basic participation determines whose claims concerning life the institution should answer. Registering affected relations as traceable sources is a step in providing that response. When the available material is insufficient, the institution must still address identification and admission.

### 2.3 What must remain when A changes roles

A role depends on the actor, relation, and stage. Leaving the former job terminates that role, while A's lineage, this payment, and outstanding responsibilities may enter another relation. The construction separately records the actor's continuity and changes of role, allowing services and responsibilities to follow the bearer.

Actors themselves may also change. The general lifecycle handles birth, persistence, merger, splitting, exit, and succession through source actors, target actors, and occurrence relations. Persistence retains lineage; merger retains incoming sources; splitting supplies child sources and responsibility destinations; succession sends responsibilities that must continue to the actual successor. Lifecycle exit concerns a source actor leaving the relevant domain and receiving its native disposition, under its own conditions. A's termination of a job role is judged through that role relation.

Economic, biological, multi-actor, and Go instances each recover actor sources from their traces. The actual general lifecycle construction supplies the six kinds of change and their responsibility dispositions. Appendices A.1 and C.1 give the detailed sources and inverse recovery. With these objects in place, we can ask which relations give A access to service and which prevent A from leaving the former job.

## 3 How payment becomes usable institutional capacity

### 3.1 Relational positions and control

A can occupy different roles in the former job and the service relation. Relations themselves arise from activity seeds and lineages, and roles change with the relation's actual stage. The foundation gives an actual construction in which one actor enters different relations and acquires different target roles. Having identified A, we must also ask which relation A occupies and what that position permits.

Hohfeld distinguishes a claim that another person perform a duty from a power to alter legal relations; the correlative of a power is the other party's susceptibility to that alteration [@Hohfeld1913, “Powers and Liabilities”]. The distinction matters directly to A's exit. A may have a power to terminate the relation, while B holds another power to alter it. A's ability to continue outside it also depends on services and routes. We construct these positions separately and track whose continuation conditions an actual exercise of power changes.

Power concerns control over another party's possible continuations. Each relational position retains finite future actions and their actual continuation conditions. An exercise of power records the controller's source event and how those conditions change. B's control over whether A can continue must therefore leave an actual change in A's continuation conditions. The capture construction supplies situations in which the affected party loses possible continuations and identifies the actual controller through the sources. Even a nonempty set of future codes may contain only idling; capacity for action also requires a non-idle action that can continue.

Relational differences may also resist reduction to individual scores. Consider three actors connected in a directed cycle. If every relational difference were the endpoint actor's score minus the starting actor's score, summing around the cycle would cancel each person's score and necessarily give zero. Yet the three-actor cycle generated from traces in the foundation has relational phases summing to \(2\). No set of global individual scores can therefore recover these relational differences. The phase is a structural reading of the relation; Appendix C.1 gives its full definition and construction. It retains relational information that is lost when only individuals are observed.

### 3.2 Payment, price, and outstanding responsibility

A's payment connects to definite responsibility and actual fulfillment. A finite exchange in the foundation jointly generates both actors, the relation, source event, bearer, and protected interest for each transaction leg. The actual four-leg exchange allows the parties' responsibilities to be traced separately. Stable responsibility slots retain live responsibilities or closed archives. Bearer exit, replacement of authorization, and reopening of responsibility each leave their own sources.

What object supports a price? Let \(e\) be an exact settlement, \(\mathcal O(e)\) its type of open settlement, and \(\mathcal P(e)\) its type of price observation. The actual construction gives
\[
\mathcal P(e)\simeq\mathcal O(e).
\]
This correspondence first determines whether there is an object for which a price can be quoted. Whenever the settlement has open content, there is a corresponding price observation; the quoted value then tells us what that observation reads. A zero quote can therefore belong to an unsettled responsibility. After complete fulfillment, the open object to be priced disappears, and the domain of price observation is empty.

To determine the status of responsibility \(\delta\), the program reads that row's live slot and fulfillment receipts, executes the next event at the slot, and extends the history to the event's actual target. The row's source and actual fulfillment jointly determine its qualification for settlement. Section 7 uses this operation to explain how common clearing and credit support handle the parties' responsibilities.

### 3.3 Authorization, service, and maintenance of the route

For A to use the service, authorization, payment acceptance, maintenance of the relation, and responsibility renewal must connect. An actual election in the foundation updates the lineage of authorization; payment acceptance updates purchasing-power standing; relational maintenance distinguishes permission from the flow of debt; and an artificial actor generated within the trace enters responsibility renewal. These four aspects are jointly installed at one source root. The relevant programs read the complete update and actual successor of the same visit.

Service also depends on the queue of requests and actual capacity. In the construction, capacity is \(2\). Queue prefixes of lengths \(1,2,3\) respectively produce stable, critical, and overloaded states. The critical queue has a complete actual debit. The overloaded queue cannot obtain a certificate that all service was completed.

At capacity two, the third request leaves its own record of not having been served. Even if its visible content is identical to the first request's, it occupies a different place in the queue. The first receipt proves completion only of the first request. To check the treatment of A's own claim, A needs the service receipt and queue position belonging to that request.

Fulfilling a service also uses routes. The spatial construction binds position, route, resource debit, and affected responsibilities to the same crossing. The maintenance program reads the receipt for that debit and retains the maintenance obligations in the post-state. One boundary instance has \(2\) settled services and \(3\) maintenance debts. The former records completed service; the latter records maintenance still due. These quantities answer different questions. The route is usable, and maintenance still has a bearer.

Participants' choices of action also enter the foundation. Lawful source code generates finite strategic games; conversely, every finite strategic game has an isomorphic generated representation. This representation result connects strategic analysis to the generation of actors and relations. Yet two objects with the same image of strategies and payoffs may carry different authority to process residual responsibilities. Determining who may dispose of unfinished responsibilities still requires reading the source of that authority.

### 3.4 Uncertainty and theoretical judgments also need sources

An institution may observe a result while needing to assess the events behind it. Write \(z\) for the observation value. The source objects whose observation is \(z\) form the fibre \(X_z\), with source weights \(w(x)\geq0\) assigning mass to them. For the event \(A\) in question, probability takes values in \([0,1]\) together with an undefined value \(\bot\):
\[
P(A\mid z)=
\begin{cases}
\dfrac{\sum_{x\in X_z,\ x\in A}w(x)}
{\sum_{x\in X_z}w(x)},&\sum_{x\in X_z}w(x)>0,\\
\bot,&\sum_{x\in X_z}w(x)=0.
\end{cases}
\]
This distinction determines what the institution can answer. On a fibre with positive mass, an event with no members yields a defined zero. If the entire observation fibre has zero mass, there is no usable denominator for normalization, and the result is undefined. An installed instance in the foundation gives \(1/3\) and a below-one-half classification, connecting this judgment to the complete update and successor of boundary maintenance. Section 5.11 will explicitly list two sources under the same observation: their coarse reading is \(1/2\), while retaining the failure kind gives \(1\) and \(0\), respectively.

Theories also participate in action. The theory-generating program produces classifications, policies, and actual effects. An independent processing operation reads the effect, and an adoption action installs the theory in the relation in which it was proposed. The ordinary successor retains the old theory. The corresponding revision proceeds from actual failure of the old law and the required authority. Section 7 follows one earlier responsibility: revision's first write transports it while keeping it live; a later fulfillment beginning at that exact target finally closes it.

### 3.5 Assembling the complete foundation

For A to turn payment into a capability for living, the institution must be able to use the material generated above. The bearer identified by a service must be traceable to that person's activity sources. The receipt read by maintenance must belong to the resource debit in question. A theoretical judgment must supply the effect it actually produces. The next action must start from the state actually reached on this occasion. Joint assembly checks whether these connections can exist together with actors, relations, payments, and services.

The preceding four subsections each supply objects and evidence of their sources. The actor quotient determines which activities belong to one continuing identity, and the lifecycle specifies how identity and responsibility enter later relations. Settlement records identify which responsibility remains live and which service has been fulfilled. The spatial and capacity constructions supply actual routes and debits; the probability and theory constructions retain the sources and effects used in judgment. Programs that must execute jointly also supply installation equalities: they read the same visit, use the same complete update, and lead to the same actual successor.

Let \(\mathcal F_h\) be the dependent product of this material and its compatibility evidence. **Dependence** means that a proof always belongs to the particular material it establishes: a maintenance receipt connects to the debit that produced it, a processing operation to the responsibility it handles, and a successor equality to the present execution. Different sources in the foundation retain their own occurrences; jointly installed parts retain the exact connections just described.

**Proposition 3.1 (Inhabitation of the complete foundation).** For every \(h\in\mathbb N\), the complete foundation \(\mathcal F_h\) exists and is actually retained by the canonical society.

**Construction and proof.** First obtain actors from seeds within traces and their lineage quotient, retaining inverse recovery for four classes of source: economic, biological, multi-actor, and Go. The general lifecycle supplies actual relations and responsibility destinations for birth, persistence, merger, splitting, exit, and succession. The relational construction then supplies roles, powers, and relational differences that cannot be recovered from differences of individual potentials.

Next take finite exchanges, stable responsibility slots, and fulfillment by each transaction leg. These supply settlement objects through which services and outstanding responsibilities can actually be read. The finite-strategy construction retains recovery of the material in lawful source code and a generated representation of every finite strategic game. Observation of authority retains actual witnesses to the impossibility of reconstructing sources from readings. Elections, purchasing power, relational maintenance, and artificial-actor renewal are jointly installed at one source root. Reform, revision, and capacity debits each supply their actual operation and successor.

The spatial construction connects crossings, debits, and maintenance responsibilities. The probability construction generates readings from source weights and observation fibres; its joint installation instance shares write-back and successor with boundary maintenance. Theory adoption supplies actual effects, independent processing operations, responsibility migration through revision, and later fulfillment. Placing these objects, their respective sources, and the proved installation equalities into the dependent product gives \(\mathcal F_h\). The canonical society retains this complete construction and generates the next section's constitutional point upon it. Appendix C.1 gives the full factors and componentwise compatibility relations. ∎

![Generation of actors, relations, and institutional capacity](figures/02-generation-en.svg)

Figure 3. A's activity sources generate a continuing actor, who enters roles, control relations, and responsibility. Seeds in one lineage class generate the same actor; roles, actual services, and responsibility rows retain their respective sources. Connections indicate construction dependencies and established joint installations.

### 3.6 How institutions remember their own choices

A will choose essential services again. When handling the next choice, the institution needs to know which relation the previous action actually established and to carry existing responsibilities into the new arrangement. Memory here begins with a write and a subsequent read.

Fix an old visit, source index, boundary, and initial payment cycle permitted by this choice interface, and take the single choice run they generate. For every \(n\in\mathbb N\), the program performs the \(n\)th relation action across representations at time \(t_n\), reads the choice produced by that action at \(t_n+1\), and enters the next action at \(t_n+2\). Thus
\[
t_{n+1}=t_n+2.
\]
The run's specified finite prefix determines the initial time; Appendix F.9 gives the exact indices. The action's target initial state retains the entire existing history through an embedding. The first whole-ledger write generates a new relation root upon it, and the next stage takes this target root directly as its source. The existing independent processing operation for the basic-income responsibility is retained through every step's actual action receipt.

This supplies a memory instance that can be calculated directly. Take any three adjacent relation actions. Their service relations generate three distinct target roles: the tenure role, the health role, and the platform provider's role. Each action edge writes its own target role; the next node reads whether the role it recognizes has appeared. Before the write, the reading is \(0\); after the write, it is \(1\). Each edge therefore actually changes a later observation, and the total difference along the three selected edges is \(3\). Injectivity of target roles also determines all nine read/write phases: the three entries following this cycle are \(1\), and the others are \(0\). The phase sum around the cycle is nonzero, so it cannot be represented by differences of individual point potentials.

After three steps, the seed and lineage identities return to their starting point, but actual occurrences continue forward: every action and its retention step extends the history. What the institution records is which action wrote which role and how that write changed a subsequent reading.

Write this read/write process as the query \(q=(r,w)\). Here \(w\) writes the target role generated by the actual edge, \(r\) is the downstream reading that recognizes that role, and \(x\) is the downstream source state before the write. The symbol \(\star\) denotes just one specific content: “observation changed.” Its canonical memory is defined by
\[
M_q(x,\star)\quad\Longleftrightarrow\quad r(w(x))\ne r(x).
\]
The actual phase calculation above already supplies a witness of the left side for every selected edge, since the right side is exactly \(1\ne0\).

An institution can retain this memory under different names and encodings. For a representation, let \(C(x)\) be the encoding and \(D(C(x),\star)\) the reading of “observation changed” from that encoding. **Soundness** requires this reading to correspond to an actual read/write difference; **completeness** requires every such actual difference to be readable. Representations satisfying both requirements exist: take \(M_q(x,-)\) itself as the encoding and decode it according to its content.

For any two type universes, any representation types in them, and any representations \((C_1,D_1)\), \((C_2,D_2)\) that are sound and complete for the same query, it follows that
\[
D_1(C_1(x),\star)
\ \Longleftrightarrow\
M_q(x,\star)
\ \Longleftrightarrow\
D_2(C_2(x),\star).
\]
The first equivalence follows from the soundness and completeness of the first representation, and the second from those of the second representation. Together they retain the observation change actually generated above. Encoding types and names may be chosen independently; what is determined is the decoded content left by the same action. Appendix F.9 first proves repeated choice at every depth of the same run, then calculates all phases, and finally proves this representation result over arbitrary universes.

Actors and institutional relations now have actual content that remains available to subsequent readings. Handling A's request also requires a complete set of disposition rules and an institutional node that can actually execute them.

## 4 Closure of institutional dispositions and their inhabited realization

### 4.1 When a request acquires authority for an institutional write

By bringing a demand to an institution, A places the conditions of continued life within an exercise of power. The institution may present facts, refuse a submission, update responsibility, or revise the law on grounds of its exact failure. Every disposition must identify the source of its authority, how responsibility changes, and who bears it afterward. Root law subjects these acts to common constraints, giving each write checkable grounds and a destination.

Institutional grammar already requires a rule to specify whom it addresses, what it permits or requires, when it applies, and who imposes sanctions for violations under which rules [@CrawfordOstrom1995, pp. 583–586]. Root law follows a particular disposition into its consequences: what authorizes its write, whose bearer relation survives refusal, and where revision sends the old responsibilities. A complete execution must supply these connections themselves.

Give the request to a complete installed institutional program, and write \(r\) for the result it generates on this occasion. With the source root, recognition rule, current visit, and scenario fixed, the program binds the submission, response, and effect together. The representation types of visible content, response, and claimed effect may each be chosen arbitrarily. The response used in execution must be exactly the one already generated by the program.

**Definition 4.1 (Four complete dispositions).** The four dispositions retain the following content:

- **Presentation \(\mathrm P(r)\):** a lawful observation, or an answer already supplied by the old law and its review. An answer with a source may serve only to explain.
- **Refusal \(\mathrm J(r)\):** the exact refusal and a residual bearer object retained as the generated submission itself; its source, complete responsibility record, and subsequent decomposition remain available.
- **Action \(\mathrm A(r)\):** the action authority granted by the current source root, a complete responsibility write-back, and the actual successor state generated by that write-back. This includes sequential action that carries forward old responsibilities and the admission of new responsibility in Section 6.1.
- **Revision \(\mathrm U(r)\):** the old law's exact failure, revision authority on the same responsibility row, the revision's first write, and the successor relation jointly constrained by the old and new rows.

Let \(\mathrm W(r)\) mean that the result has an actual write: it implements the authorized complete responsibility update at its actual target.

**Theorem 4.2 (Root-law closure and the criterion for writing).** For every source root, recognition installation, visit, scenario, three independently and arbitrarily chosen representation types, complete program, and generated execution specified above,
\[
\mathrm P(r)\lor\mathrm J(r)\lor\mathrm A(r)\lor\mathrm U(r).
\]
Moreover,
\[
\mathrm W(r)\quad\Longleftrightarrow\quad
\mathrm A(r)\lor\mathrm U(r),\qquad
\neg\bigl(\mathrm A(r)\land\mathrm U(r)\bigr).
\]
Presentation and refusal do not write. If the branch for same-source law revision of this actual result is inhabited, that same result retains the exact failure, the same responsibility row, the revision's first write, and the complete successor package for the old and new rows. There is no fifth authority to write outside the responsibility record.

**Proof.** The program first reads the submission's actual disposition. Presentation supplies a lawful presentation. Refusal supplies both the exact refusal and the refused submission's residual bearer object. Writing authority is empty for both constructors.

A submission carrying authority from this root must also read the response already bound by the program. A direct answer, an answer obtained after obstruction review, and an answer in the old language remain presentations. Sequential action reads the old row's complete update and successor. Responsibility admission reads the new row's source, first complete write, and first-write successor. Both belong to action. Revision generated by an exact failure carries the failure grounds, revision authority on the same row, the first write, and the two rows' successors, and therefore belongs to revision.

Every result carrying root authority retains a response installation equality: the response it uses is the response already generated by the complete program. A candidate using a different response would require both equality and inequality, and so cannot exist. The classification therefore exhausts this execution's results. Writing holds exactly in the action and revision constructors. These constructors are distinct, so one result cannot belong to both; this gives the writing equivalence and disjointness. Reading the complete revision package from a witness of the actual branch for same-source law revision then gives conditional revision availability. All public dispositions have been covered, so there is no fifth writing authority. ∎

![Four institutional dispositions and responsibility birth within action](figures/03-root-law-en.svg)

Figure 4. Root law governs the use of writing authority in every complete execution. Action includes updates of old responsibility and admission of new responsibility; revision takes its grounds from exact failure on the same responsibility row. Refusal preserves the bearer object of the refused submission, while action and revision each generate an actual successor.

### 4.2 How a submission with a source enters actual execution

Theorem 4.2 constrains the execution of every complete program. To make these rules usable by A, we must also construct a constitutional point that can receive a demand and obtain a complete disposition. This existence proof begins with the submission's source.

First distinguish two institutional locations: where the submission obtains recognition, and where the responsibility update is actually executed. A raw submission need only have been generated by its source program. A complete locally installed program must additionally carry an open responsibility row at the current root and the authority attached to that row, using them as the basis for inquiry and a complete update.

In the canonical construction, the root receiving raw submissions has already generated a submission carrying authority from this root, yet its set of local open responsibilities is empty. A complete local program, if one existed, would therefore supply a local open responsibility row, contradicting that emptiness. The types of complete local programs and their action channels are thus empty. A submission with a source still retains its recognition authority and obtains its disposition through an external channel already registered by that source.

This channel is an actually generated transport span. Given the old visit, source index, and boundary, the source program takes the generated replay of actual payment and supplies from it an external complete payment, authority on a responsibility row, revision grounds, and an actual successor. For any rooted submission \(g\), its source event and the source-end submission of the transport \(T\) satisfy
\[
\operatorname{event}(g)
=\operatorname{event}(T.\operatorname{sourceSubmission}).
\]
This equality identifies the current submission's event as the source event of the existing channel. After transport reaches the target, the target's legislation, revision on the same responsibility row, and independent processing operation all read that external complete payment. The exact failure used for revision is also supplied by this existing source.

Each end thus has an actual connection. The source end proves that the submission being processed is this rooted submission; the target end proves that legislation, responsibility, and the successor belong to this same payment. The submission occurrence and target-payment occurrence retain their respective types and are connected by transport. Appendix A.3 expands all indices and compatibility equations and proves that the transported independent processing operation actually executes the target's complete write-back and actual successor.

The next section places this constructed execution channel and the general root law at one constitutional point. The payment A submits must also match the receiving node. Section 5.4 uses a genuine payment sent to the wrong adjacent node to show how the node refuses that submission while its own payment preserves the bearer's route to continuation.

### 4.3 Inhabited completion at one constitutional point

We now install the external payment channel and the general root law at one institutional node, so that an actual disposition witness and the universal disposition rules can be used together.

For each foundational observation horizon \(h\), take the canonical society \(S_h\) constructed in Section 3. Choose arbitrary prescribed old-visit parameters, source index, boundary, health depth, request recursion parameter \(f\), and observation recursion parameter \(o\). The recursion already registered in the society generates a stage from the initial object and a constitutional point \(c_m\) at that stage.

Call \(c_m\) **root-law complete** when the following three properties belong to this point. An external complete disposition carrying authority from this root has an actual witness. For every visit index, scenario, and independently and arbitrarily chosen content, response, and effect types, every source-generated raw submission has a complete raw disposition. Under the same quantifiers, the generated execution of every complete installed program satisfies Theorem 4.2.

Revision availability retains two different conditions. When a raw submission's actual disposition carries authority from this root, that submission and its existing authority obtain a complete external revision package through the existing transport of the preceding section. When the actual branch for same-source law revision of a complete installed program is inhabited, that same generated result retains the exact failure, the same responsibility row, the first write, and the two-row successor package.

**Theorem 4.3 (An inhabited canonical society and root law at the same point).** For every choice of all the parameters above, the registered recursion of \(S_h\) generates a stage \(m\) and one constitutional point \(c_m\) such that
\[
\operatorname{Complete}(c_m)\ \land\
\operatorname{RevAvailable}(c_m).
\]
The first conjunct is the root-law completeness just defined; the second is the two layers' respective conditional revision capabilities. The witness of inhabitation, universal raw-submission classification, universal complete-installed-program classification, and conditional revision all belong to this same \(c_m\).

**Proof.** Take the initial object and recursion from the complete foundation already retained by \(S_h\). Unfold it for the given request and choose \(m=f+1\). Thus \(f<m\), and \(c_m\) is obtained at this stage. The source selects the point's actual scenario, and the recognition rule then generates a submission carrying authority from this root. The existing transport in the preceding section connects it to a complete external payment, giving a witness of inhabitation at the same point.

Next take an arbitrary visit index, scenario, three representation types each chosen arbitrarily, and source-generated raw submission. Its actual disposition is presentation, refusal, or root authority. The first two retain their nonwriting raw dispositions; the third obtains the existing external revision package. Local action is excluded by the empty local responsibility stock. Now take any complete installed program at that visit and apply Theorem 4.2 to its generated execution. Both arbitrary choices range over the full parameter domain of the current fixed recognition root, yielding the two universal conclusions.

Finally retain the two revision conditions separately. At the raw layer, actual root authority enters the existing external bridge. At the installed layer, an inhabited actual branch for same-source law revision supplies the complete revision package for that same result. Place these objects and propositions at the one \(c_m\) already generated. This gives the required conjunction. ∎

Theorem 4.2 gives an exhaustive account of writing authority for complete executions; Theorem 4.3 makes these rules work at an actual node. The witness of inhabitation comes from an external complete disposition with a source, while the local action fibre remains empty. A thus faces an institutional node that can receive demands and must account for responsibility in every disposition.

### 4.4 Joint realization of actual disposition and failure review

This root law also has a concrete social grammar. It checks eight kinds of institutional content at the same source occurrence and applies them to an actual scenario and a total-capture search scenario. Here “search” tests which requirement fails when continuing action is wholly captured, while retaining the payment and service material. Each combination of scenario and kind of content appears exactly once in a single unfolding, giving sixteen points with sources.

| Content checked | Actual scenario | Total-capture search scenario |
| --- | --- | --- |
| Complete responsibility update | The current whole-ledger evolution passes | Retains the same whole-ledger material |
| Actual service exit | This occurrence's actual exit passes | Retains the actual-exit material |
| Newborn bearer's exit | Obtained from the same actual exit | Retains this bearer's material |
| Bearer's power-exercise response | The power-exercise response for the same exit passes | Retains this response material |
| Execution of the bearer's departure | The departure execution for the same exit passes | Retains this execution material |
| Bearer's continuation outside the role | Actionable continuation passes | Actionable continuation fails under total capture |
| Tenure access | This relation and the actual exit pass jointly | Retains the same access material |
| Health-service access | This relation and the actual exit pass jointly | Retains the same access material |

Each point's source, payload, and review result are generated by this occurrence. Collecting them through the unfolding, one item at a time, gives passes for all eight checks in the actual scenario; the search scenario returns the exact failure package for continuation outside the role. That package still retains the bearer acted upon, the payment source, the independent responsibility-processing operation, and the corresponding disposition. Failure cuts off actionable continuation under total capture; the payment, service, and bearer relations that have already occurred remain individually available for reading.

Every installed projection that the program reads from this root is also covered either by one of these eight kinds of content or by the container projection carrying the entire grammar. The item for continuation outside the role in the actual list of passes is exactly equal to the continuation root facet read by the complete exit lifecycle in Section 5.5. That lifecycle retains both membership in this list and the equality of the readings. The grammar's passing item thus connects to the bearer's exit and later life.

Actual execution and search use the same recognition item and the same visit, so they read the same root event, complete ledger, and actual next state. Writing authority additionally requires the actual scenario specified by this installation. The total-capture search scenario differs from that actual scenario and has an empty type of writing authority; the search review applies the identity disposition to the ledger it reads. Sharing a complete record can therefore support accurate diagnosis, while actual writing remains grounded in the authorization for that execution.

This realization covers every cycle and every depth. Take any cycle \(C\) from Section 1.5, and write \(Q_C\) for a complete constitutional proof for that cycle. It retains source identity, renewal of power and service, the residual bearer and its independent processing, the distinction between observation and actual authority, root-law completeness, and an ongoing revision run. The cycle-generating program supplies such a proof for every \(C\); what follows holds for every \(Q_C\) of the same type.

For every observation parameter \(o\) and depth \(d\), a single grammar realization point jointly supplies the root-law transition from this step to the next, the total-capture search failure described above, actual same-source law revision at this step, and successor equalities under which both actual and search grammars read the current state of the next root law. The cycle's next entry satisfies exactly
\[
C_{d+1}=\operatorname{nextCycle}(\operatorname{step}(C,d)).
\]
The grammar is installed at positions in the complete exit lifecycle. If the lifecycle parameter is \(i_d\), the grammar's actual occurrence is at \(i_d+2\), and its actual successor is at \(i_d+3\). These positions belong to adjacent root laws; source and target retain their own occurrence identities.

For every pair of finite request parameters \(f,o\), \(Q_C\) first supplies a request constitutional point at some depth \(m\). Take the grammar realization point at that same \(m\) to obtain
\[
\forall f,o\ \exists m:\quad
\operatorname{Nonempty}\bigl(
\mathsf{Req}_{C,f,o,m}\times
\mathsf{Joint}_{Q_C,o,m}\bigr).
\]
Here \(\mathsf{Req}\) is a constitutional point satisfying that finite request, and \(\mathsf{Joint}\) is a realization point jointly retaining actual root law, search failure, actual law revision, and the successor connection at that depth. The absence of search writing authority and the existence of actual law revision hold together here.

The key to the proof is exhaustive coverage of items from the same source. Projecting each point in the sixteen-point list onto its scenario and checked content recovers its coordinates, so the list has no repetitions and is exhaustive. Actual compilation and search compilation are both generated from this unfolding, item by item. For every \(Q_C,o,d\), the root-law transition and actual revision are obtained from the all-depth fields of \(Q_C\), while the grammar for search failure is, by definition, that same source law. Its next state equals the successor read by the actual grammar, which in turn equals the current state of the next root law. Finally, assembling both sets of material at the same \(m\) supplied by the request proof gives the joint point above. Appendix F.6 gives the complete fold, the classification of observation uses in arbitrary output universes, and all type transports.

## 5 Realising exit and diagnostic impossibility

### 5.1 What makes A's exit practicable

Hirschman places exit and voice within the interaction through which organisations respond to decline; Widerquist makes the means of living needed to refuse cooperation central to freedom [@Hirschman1970, pp. 3–4, 81–82; @Widerquist2013]. A's problem lies at their intersection: can he actually leave, and what enables him to continue afterwards?

A's former employment relation has ended. A remains the person requesting service and the bearer of an outstanding responsibility. Making this request into a practicable exit requires connecting one of A's continuing actions, the payment supporting it, and an actual service.

At depth \(d\) of the canonical society \(S_h\), A first takes a continuing action \(c\) from the finite set \(C_d\) supplied by the source program. Let \(R_d(c)\) mean that this action can continue in an exit relation distinct from the former employment relation, \(I_d(c)\) denote idleness, and \(H_d(c)\) capture. The action A needs must permit continuation, be nonidle, and remain uncaptured.

We must also see how payment and service support this action. Write \(p_d\) for the complete payment and \(\delta\) for the responsibility row associated with A's continuation. Let \(P_d(c)\) mean that this payment has the required payment-incidence evidence for \(c\). Service must come from the actual run indexed by this payment: \(J_d\) is the set of positions in this occurrence's actual served sequence, and \(j\in J_d\) points to the service \(s_j\) already provided. A also needs a route \(\pi\) connecting the same action \(c\) to that service, with the corresponding route-incidence evidence. Let \(T_d(c,j)\) mean that this incidence holds. Define a feasible edge between the action and service by
\[
E_d(c,j)\quad\Longleftrightarrow\quad
R_d(c)\land\neg I_d(c)\land\neg H_d(c)
\land P_d(c)\land T_d(c,j).
\]
Capture can occur even when the route and service are present: the capacity to continue is still not independently available to A. B denotes the position controlling A's continuing action or its conditions. The service provider's identity is determined separately by the source of the actual service.

These relations form a bipartite graph. On the left are the continuing actions A can choose; on the right are the service positions actually fulfilled in this occurrence. An edge exists only when all five conditions hold for the same pair \(c,j\). Finding the conditions separately in different places does not yet enable A to obtain service along this edge.

**Theorem 5.1 (Necessary and sufficient conditions for genuine exit).** For every \(h,d\), the source program can generate a genuine exit continuation for A outside the role that has ended if and only if
\[
\exists c\in C_d,\ \exists j\in J_d,\quad E_d(c,j).
\]
Relational continuation, nonidleness, noncapture, payment incidence, and route incidence must all use the same \(c,j\). Actual service must also come from the actual run indexed by \(p_d\).

**Proof.** From a genuine exit continuation, take its action \(c\), service position \(j\), and feasible edge. This edge retains continuation outside the role, nonidleness, noncapture, payment incidence, and route incidence. The position \(j\) belongs to this settlement's sequence of services actually provided. These give the right-hand side.

Conversely, take the same \(c,j\) satisfying the right-hand side. This settlement connects position \(j\) in the service sequence to the event at the same ordinal in the actual run and supplies that event's service receipt. Combine this receipt with the incidence evidence for this payment, route \(\pi\), continuation outside the role, and noncapture. This gives a complete feasible edge, from which the exit-generating rule generates actual continuation. Both directions use the same action, service position, and occurrence index throughout. ∎

The feasible edges also determine exit capacity \(K_d\), the maximum matching size of the finite bipartite graph \(E_d\). A matching uses each action and service position once, so it counts exits that can receive independent support simultaneously. A feasible edge forms a singleton matching, while every matching of positive size contains an edge. Thus
\[
K_d>0\quad\Longleftrightarrow\quad
\text{genuine exit continuation is inhabited}.
\]

The canonical instance has three queued service items, two units of service capacity, and two actually served items. Only one nonidle action can form the exit. Pairing it with an existing service position gives a matching of size one. Every feasible edge has that action as its left endpoint, giving the upper bound one. Hence \(K_d=1\). Two served items thus support one genuine exit while one service item remains unfinished.

This instance divides life after leaving a job into three tasks that can each be checked. Periodic payment supports purchasing power outside the role; services and routes connect that purchasing power to actual fulfilment; and a new job offers work in another role. Whether A can independently refuse that job still depends on whether the exit relation is captured.

The conditions are also independently necessary. At every depth, the route-outage construction retains actual payment, service, responsibility row, whole-ledger successor, and seven other installed renewal operations, while the source route-receipt type is empty. The entire remaining carrier still cannot construct that receipt. Actual repair produces a route only at the next visit generated by payment, where capacity becomes one.

Alignment between service and bearer also requires its own evidence. At one post-settlement occurrence, the tenure channel's first service receipt agrees literally with the receipt of A, the exit bearer. The health channel retains a genuine service, the same payment and settlement, independent processing, and the actual successor, but its registered relation actor differs from that exit bearer. Its health service exists while exact alignment to this bearer remains empty. Any reconstruction of alignment from one of the retained materials, applied to the actual object, would inhabit that empty type. Appendix F.10 proves both independent-necessity results in full: institutions must provide services and connect them accurately to the people affected.

### 5.2 Three zeros and two ones: why exact measurement is insufficient for diagnosis

At zero capacity, A's exit is blocked. Fixing this complete payment, A, and A's exit interest, construct three comparison branches to examine which relation blocks continuation. Each branch retains its own source identity.

Let \(z_{\mathrm c}\) denote full capture, \(z_{\mathrm p}\) missing payment incidence, and \(z_{\mathrm r}\) missing route incidence. Under capture, payment incidence, the route, and actual service remain, but A's capacity to continue is captured. Under missing payment incidence, the underlying complete payment still exists; what is absent is the evidence connecting it to the action in question. Under missing route incidence, payment and actual service remain; the missing element connects this action to that service.

**Proposition 5.2 (Capacity readouts cannot identify source or completeness).** For every \(d\), the three source-bearing objects above belong to \(Z_d\), are pairwise distinct, and satisfy
\[
K(z_{\mathrm c})=K(z_{\mathrm p})=K(z_{\mathrm r})=0.
\]
There is no \(g:\mathbb N\to Z_d\) such that \(g(K(z))=z\) for every \(z\in Z_d\).

**Proof.** Full capture excludes every noncaptured feasible action. Missing payment incidence deprives every candidate edge of required payment evidence. Missing route incidence deprives every candidate edge of required route evidence. Each case therefore has no feasible edge and has capacity zero. The three cases retain distinct source constructions, so they are pairwise unequal. If \(g\) recovered the source from capacity, then
\[
z_{\mathrm c}=g(0)=z_{\mathrm p},
\]
contradicting their distinctness. ∎

**Completeness at positive capacity.** The problem also arises when exit is already feasible. Consider the tenure and health domains in the canonical construction: each requires a source actor, relation, actual service, route, and feasible continuation. Call the dependent product of these domain-specific objects a **complete capability portfolio**. Completeness here concerns these two installed domains.

Proposition 5.2 has the following strengthening. At every depth \(d\), the generating program supplies a full source \(x_d\) and a one-service source \(y_d\). They retain the same root occurrence, the same payment occurrence, and the same payment and route rules. Both capacities equal \(1\), but their complete capability portfolios are inhabited and empty respectively.

| Actual source | Tenure service | Health service | Exit capacity | Complete portfolio |
| --- | --- | --- | --- | --- |
| \(x_d\) | Fulfilled | Fulfilled | \(1\) | Inhabited |
| \(y_d\) | Fulfilled | No corresponding service occurrence | \(1\) | Empty |

No capacity-only reconstruction of sources has a left-inverse property. More strongly, no \(q:\mathbb N\to\mathrm{Prop}\) correctly classifies the existence of a complete portfolio on both sources.

**Proof.** The full source obtains two distinct paid service positions in the generated queue prefix. The one-service source executes only the first maintenance event in the queue, with \(0\) as its sole served slot. The installed rule assigns health to another queue position, so no health-service witness can be obtained. Both sources have only one surviving nonidle action and each has an actual feasible edge; their maximum matching capacities are therefore both one. Two actual witnesses generate the complete portfolio in \(x_d\), while a portfolio in \(y_d\) would require the missing health witness.

If \(q\) classified correctly, the full source would give \(q(1)\); correctness for the one-service source would then produce its complete portfolio, contradicting emptiness. A source-reconstruction left inverse would likewise identify the two different prefixes. Appendix F.1 gives the full construction of domains, service ordinals, actual payment, and four independent controls. ∎

Capacity one is exact in both cases: each side has a feasible exit. What the number omits is whether health service has actually been delivered. To judge A's conditions of life after leaving, the institution must retain each domain's actual support and identify whose relation the service reaches.

Capacity still correctly counts exits that can be realised simultaneously. Choosing a repair also requires the operations' actual effects. Take two further installed failure dispositions: capture failure \(f_{\mathrm c}\) and an uncaptured route bottleneck \(f_{\mathrm r}\). In a repair language containing only removal of capture and restoration of the route, each operation changes its target condition while preserving the same payment, bearer, exit interest, and actual service. Applying them to the two failures gives
\[
\begin{array}{c|cc}
 & \text{remove capture} & \text{restore route}\\ \hline
f_{\mathrm c} & 1 & 0\\
f_{\mathrm r} & 0 & 1
\end{array}.
\]

**Proposition 5.3 (Impossibility of exact repair selection from capacity).** At every depth \(d\), within the two failures and two repairs above, no repair-selection function that reads only the capacities of these two failures is effective for both sources. Nor can a function recover each source's canonical repair from capacity.

**Proof.** Removing capture returns \(f_{\mathrm c}\) to the uncaptured geometry of the preceding section, with capacity one. Restoring only the route leaves full capture in place, so capacity remains zero. For \(f_{\mathrm r}\), removing capture does not supply the missing route, so capacity remains zero. Restoring the route supplies a complete feasible edge and capacity one. Each row of the matrix therefore has exactly one effective repair.

Both failures have capacity zero, so a selector must return the same result for both. If it returns removal of capture, the route bottleneck remains. If it returns route restoration, capture remains. These two operations exhaust this repair language, so no selector is effective for both sources. Each canonical repair is also the unique effective operation in its row. They differ and cannot both be recovered from the same \(g(0)\). ∎

The obstruction arises where information is merged: the same zero is asked to determine two different actions. Once the source of failure is retained, the installed repair program can select the corresponding unique effective operation and carry the restored capacity into an actual successor. A obtains a complete path from cause to action and then to continued life.

### 5.3 The different responsibilities of ordinary repair and same-source law revision

Restoring a route or removing capture can restore A's continuation under the current law. Ordinary repair preserves the law in force before repair, responsibility lineage, and inherited responsibilities, produces complete write-back, and makes the following run actually use the target program supplied by this disposition.

Same-source law revision performs a different task: it obtains grounds from within this failure and revises the old law that has precisely failed. It requires failure on the same responsibility row, installed revision authority, a new expressive form, and the revision's first write. Outstanding responsibility must also enter the revised arrangement. Zero capacity cannot supply these grounds by itself.

The policy rupture at depth zero supplies two existing processing coordinates. The ordinary coordinate reads the installed disposition and generates ordinary repair with its successor. The revision coordinate reads this inquiry's exact-failure resolution and generates same-source law revision with its successor. The two constructions share the rupture's source and each retains its own output. Section 6.3 proves the difference between the results from the successor structures themselves.

### 5.4 Refusing a submission while retaining a way forward for its bearer

A genuine payment can also be submitted to a processing node to which it does not belong. Suppose each node in a finite sequence receives a candidate payment \(a_i\), while node \(i\) generates and recognises its own payment \(q_i\). Acceptance requires an exact match. Now submit node one's genuine payment to node zero. The two payments have different boundary identities, so \(q_0\ne q_1\), and the submission should be refused. After refusal, we must still check whether node zero's own payment, service, and responsibility relations can continue.

Refusal applies to the external candidate submitted to the wrong node. The node also has its own generated payment, together with the bearer's standing and service associated with it. Continuing along these existing relations preserves both source recognition and A's capacity to continue.

**Proposition 5.4 (First refusal and recourse through the node's payment).** For every initial source cycle and finite external proposal sequence, if the set of failing nodes is nonempty, its least element \(r\) is the unique first refusal. Extensions preserving that prefix retain the same first refusal. External acceptance at \(r\), and processing operations dependent on it, are empty. The node's canonical execution and actual successor nevertheless exist, and earlier effects are preserved. The payment already present at the same node generates ordinary repair, preserving that node's bearer's standing and producing an actual successor enabling genuine exit. This successor differs from the successor of that node's canonical revising legislation. At every finite recursion depth, submission of an adjacent node's payment supplies such an actual refusal and recourse.

**Proof.** A finite nonempty failure set has a least element \(r\). If two nodes were first failures, their minimality would constrain their order in both directions, so they would be equal. First failure depends only on earlier matches and the current mismatch; preserving the prefix preserves this conclusion. Once external acceptance is empty, any processing operation that must first obtain a witness of that acceptance is empty as well.

The node's execution uses its own generated \(q_r\), independently of the mismatching external candidate. Acceptance of \(q_r\), complete legislation, and the actual successor therefore still exist. The registered recurrence preserves generated effects node by node, so refusal of an external proposal cannot retroactively change the paid prefix.

Next take the actual service authority from the replay already present at node \(r\), and let that authority determine the repair depth \(d_r\). Lawful transport already connects the node payment to the periodic payment at this depth while retaining the source identity of its root event. The ordinary-repair program supplies an exit continuation at depth \(d_r\); the lawful transport above connects it to the node payment. Its responsibility entry comes from that node's bearer's existing institutional standing; no bearer is selected anew. The repair and independent processing operation jointly supply complete write-back, an actual successor enabling genuine exit of capacity one, and the following visit \(v_{d_r+1}\).

The existing construction also distinguishes the two successors. The current-state carrier of ordinary repair is a singleton type, whereas that of that node's revising legislation is the type of natural numbers. Equality of the complete successors would require equality of these carriers, contradicting the fact that one has one element and the other is infinite. Appendix A.5 gives the common packaging of both ends and the complete type transport. The adjacent-payment mismatch first fails at zero, and the construction above applies at every finite recursion depth. ∎

Refusal identifies which submission failed; the node's own payment determines how A can still continue. Ordinary repair obtains its source from the payment and service already present at that node, preserving A's standing in relation to this responsibility and actually carrying him towards the next exit.

![First refusal and continuation through the node's payment](figures/04-refusal-en.svg)

Figure 5. A payment submitted to the wrong node can be genuine without matching the current node. Empty external acceptance, continued execution at the receiving node, and ordinary repair generated from the node's payment can hold at that same node. Recourse obtains its source from that node's execution and payment.

### 5.5 How a bearer's exit becomes an actual course of life

For A actually to leave, the institution must connect three questions across time: who authorises A's action at this occurrence; whether that action changes the employment relation; and which services A can use afterwards, with whom continuing to handle the outstanding responsibility. The exit conditions established above now enter an actual execution chain.

Write \(o\) for the old-visit parameter, \(a\) for the source index, and \(i\) for the beginning of this lifecycle. Let \(e_0,e_1,e_2,e_3\) be the four occurrences generated by the lifecycle program at \(i,i+1,i+2,i+3\), and let \(p_0,p_1,p_2\) be the complete payments belonging to the first three occurrences. These subscripts denote lifecycle stages. Each stage has its own provenance, whole-ledger update, and actual service occurrence. The stages do the following work.

| Stage | Actual content obtained at this occurrence |
| --- | --- |
| \(e_0\) | A's exit action has the payment's own root read and source authority; the payment generates the next occurrence. |
| \(e_1\) | The new occurrence reauthorizes the same leave action. A executes it, the employment relation changes from employed to released, and the work option in that job is lost. |
| \(e_2\) | The executed payment's successor supplies continuation outside the role. The continuation action remains usable, with every essential-service channel, external responsibility's provenance, and its independent processing operation. |
| \(e_3\) | The payment used by that continuation generates a further occurrence, whose services, responsibility, and successor retain their actual sources. |

**Theorem 5.5 (The complete lifecycle of actual exit).** For every old-visit parameter \(o\), source index \(a\), and lifecycle starting index \(i\), the four-stage object and its three payment edges exist, with
\[
 \operatorname{next}(p_0)\simeq e_1,\qquad
 \operatorname{next}(p_1)\simeq e_2,\qquad
 \operatorname{next}(p_2)\simeq e_3.
 \tag{5.5a}
\]
Here \(\simeq\) denotes exact dependent equality in the respective occurrence types. The first stage's target payment is the second stage's executed payment; that payment's successor is the source occurrence of continuation outside the role. The next payment continues to use that occurrence's own responsibility, services, and whole-ledger update.

The lifecycle satisfies an exact characterization. Let \(R_i(c)\) be the contract fixing this temporal chain, the bearer's actual action, continuation outside the role, external responsibility, and all service successors at the same action code \(c\). Let \(S_i(c,j)\) require that \(c\) belongs to this occurrence's action inventory, has continuation outside the role, is nonidle and uncaptured, and has a payment from the same source and a route to the lifecycle program's \(j\)-th actual service. Then
\[
 \text{complete exit lifecycle}(o,a,i)
 \quad\Longleftrightarrow\quad
 \exists c,j\; S_i(c,j)\land R_i(c).
 \tag{5.5b}
\]
The contract \(R_i(c)\) contains all three actual payment edges; it is not a promise to supply them later. Appendix E.3 expands every component and the reconstruction in both directions.

All four stages have the same leave-action readout. Yet both the map from stages to outer authority occurrences and the map from stages to actual service occurrences are injective. The action code therefore cannot recover the occurrence at which it acquired authority. Replacing the capture condition by full capture preserves the chain's payments, actual employment loss, exit interest, bare future outside the role, external responsibility, and service successors, while making actionable exit renewal empty.

**Proof.** The current payment first generates the target at \(i+1\). That target reads A's action authority anew from its own root occurrence and executes the action as the bearer's own power to leave. Its relation role changes from employed to released, so this step effects an actual change in the relation. The executed payment's actual successor reaches \(i+2\). The relation here is already independent of employment: both source and target roles are independent, the phase is zero, and the leave code has a witnessed continuation that is nonidle and uncaptured. This new relation supplies continuation; the employment loss remains in the preceding execution.

At \(i+2\), the complete execution at this stage uses the payment write belonging to this occurrence. The write supplies source ownership, an independent root processing operation, actual settlement, and the next occurrence together. Each installed service channel uses a service witness from this same payment. Taking the write's successor produces \(e_3\), establishing the three interfaces in (5.5a).

Given the complete lifecycle, take the feasible edge in its actual exit renewal. This yields the service, route, and payment conditions for the same \(c,j\); together with the retained temporal contract, these give the right-hand side. Conversely, assemble the given service, route, nonidle, and noncapture conditions into that actual edge to obtain exit renewal, then combine it with \(R_i(c)\). This reconstruction uses the supplied material directly and does not invoke a lifecycle object already assumed to succeed.

The root occurrence's actual position increases with \(i+s\). Equal authority at two stages would yield equal positions and hence equal stages. Injectivity of actual service occurrences gives the second result. The constant leave code consequently has no left inverse recovering stages. The full-capture branch retains this chain's temporal contract but rules out its only usable leave code outside the role: the idle code fails the nonidle condition, and the work code has no continuation in the independent relation. Hence no feasible exit edge remains. ∎

Exit thus acquires a complete temporal structure: A changes the old relation, obtains continuation in a new one, and leaves the outstanding responsibility traceable across that change. By preserving these connections at each stage, an institution turns an authorized departure into a life that can continue.

### 5.6 How a response preserves independent action after refusal

After A refuses to continue the employment relation, keeping a service on a list is insufficient. The institutional response to that action must leave A able to use the continuation independently. The lifecycle program therefore installs the response directly in the target payment. The response is indexed by A's own leave action, obtains its bearer from the payment's root read, and retains proof that the action is uncaptured. The formal content of “after refusal” here is this structural response to the indexed action; Theorem 5.5 establishes actual execution of the exit and the life that follows.

**Theorem 5.6 (Structural anti-retaliation).** For every \(o,a,i\), the renewed target payment generates a response with fixed provenance. Its action is exactly A's already selected leave action, and it retains all of the following:

1. The respective sources of the bearer's power to leave and a separate controller's power to terminate, the actual employment loss, and the distinction between controller and worker.
2. Actual fulfilment on every installed essential-service channel, that channel's independent processing operation, and the actual successor of the same payment.
3. Source ownership and the independent root processing operation for external responsibility, together with the payment's own continuing generation of the next occurrence.

For this same leave action, capacity is \(1\) under the uncaptured geometry and \(0\) under full capture. Four exact retypings that retain that target payment and response but report its action as captured—policy, service, administrative, and employment retypings—are empty. For every Boolean administrative labelling of this lifecycle's occurrence domain, the label readout can recover neither the occurrence nor the corresponding actual-service authority.

**Proof.** The target payment's response projection first supplies a root read. The bearer is obtained from this read, and the leave action from that bearer. All three projections belong to this target payment. The response action therefore equals the payment's exercise action, and its noncapture proof applies directly to that action. Each service channel's processing operation likewise reads the target payment's actual exit and returns its actual successor to the payment's successor. External responsibility is supplied by the same payment's source ownership and root processing operation. A replacement service list or administrative judgment cannot substitute for these connections established by the same payment.

Each of the four anti-retaliation proofs retains the positive response above and adds the assertion that this same response action is captured. The response's noncapture proof immediately contradicts that assertion. The full-capture comparison branch does capture the leave action, and its capacity is accordingly zero. It exhibits the institutional condition on which the protection depends.

For administrative labels, compare the source and target occurrences. Whatever labelling function is chosen, the old administrative restriction readout is the same, while the authority positions and actual service occurrences are strictly different. A left inverse recovering occurrences, or a factorization recovering authority from the label readout, would require the same readout to recover two different authorities. This is impossible. ∎

The structural anti-retaliation test locates protection in the connections between that payment, action, and services. Once the same response retains evidence that A's action is uncaptured, policy, service, administrative, and employment retypings must preserve that fact.

### 5.7 Tenure and mandate have their own exits

Employment is one case of exit from a relation. Loss of standing in a tenure relation and termination of a mandate have their own sources, roles, and responsibilities already undertaken. For A to continue living across these changes, the required bridge is a common bearer generated by the source: the subjects in different relations connect through this bearer to payment, services, and exit, while their role changes remain determined by their respective relations.

**Proposition 5.7 (Two nonemployment relation exits).** For every payment-cycle entry, observer parameter, and depth \(d\), the relation-generating program supplies the following two complete instances.

**Tenure.** The relation's source seed generates its power of action, nonzero phase, and loss of the relevant entitlement; the payment purpose identifies this relation. Its subject and the exit worker have the same source bearer. The actual root law admits the relation's coordinate exactly once. The finite exit constitution at the same depth supplies, for one action and one service slot, continuation outside the role, a source-backed payment, an actual route, external responsibility, services, and a future. Full capture retains the nominal transfer but makes exit renewal empty.

**Mandate.** The previously restored power, renewal phase, and held role generate the source of the next actual action. A fixed sequential action executes from this source, producing lost power, the exit phase, and the exited role at its target; the responsibility already borne by the mandate relation enters a terminal archive. The action's source occurrence connects exactly to the root occurrence of the payment embedded in the depth-\(d+1\) constitution, and its occurrence presentation transports it into the restriction specified by the target payment. The target performs the first whole-ledger write and generates both its first-write successor and the macro successor actually adopted. It also retains the depth-\(d+1\) exit material, root-law transition, same-source law revision, and compatible future birth.

**Proof.** The two bearer provenances in the tenure instance both lead to the shared parent bearer: one through the tenure relation's payment counterparty, the other through A, the exiting worker. Their equality yields the common-bearer equation. Eliminating the operational incidence of the same finite constitution then supplies one action and one service slot, with service, route, payment, responsibility, and future obtained together. Exact-once coverage in the actual scenario of the root law supplies the relation's admission point.

For the mandate instance, first take the next visit generated by the held standing. It is dependently equal, in their respective types, to the root occurrence of the next-depth constitution payment. The sequential action's occurrence presentation then sends it to the target payment. This bridge thus contains an actual source continuation and a lawful target transport. The action receipt retains the trace of the period of holding the mandate and gives, component by component, lost power, exit, the exited role, and the terminal position of the mandate responsibility. The target's complete execution generates the first-write successor, and the same target's response and successor generate the macro successor. Reporting the target as restored, renewed, or held would respectively identify lost with restored, exit with renewal, or exited with held. Each identification is impossible. ∎

The common bearer carries continued life across a change of relation while retaining the responsibility borne before exit. Tenure and mandate each complete exit through their own roles, responsibilities, and actual actions; their source bearer supplies the connection between relations.

The mandate exit above also generates a definite later occurrence. The next institutional visit actually reached by the exit action retains the mandate responsibility's terminal status and has its own complete payment. A second actual action starts at precisely this visit, records the exit history that has already occurred in the succession history, and generates a new controller from the maximum-controller fold of that history. The office relation persists while its controller and responsibility change.

More precisely, for every payment cycle and all the parameters of Proposition 5.7, the old responsibility remains terminal at the post-exit visit, while the successor acquires restored power, a renewal phase, and a held role. The same one-slot ordinal contains the old and new responsibilities in their respective representations, but the responsibilities are distinct: the new one enters a live state through admission, and the terminal archive has no reopening event. The succession action also supplies its own target complete payment, first whole-ledger write, and exact actual successor, together with services, routes, continuation outside the role, external responsibility processing, and joint regeneration at depth $d+2$ of the next payment cycle.

The proof generates the successor from the old history. Let $m$ be the largest controller seed in this actual history. The new seed is $m+1$, so it differs from every earlier controller in that history. Uniqueness of the maximum fold ensures that every evaluator satisfying the same occurrence recursion yields this result. If the old and new responsibilities were equal, their bearers would also be equal, contradicting the new seed's position beyond the old history. The exit action's actual successor is exactly the source of the succession action. Lawful presentation transports supply the connection from payment to post-exit payment and the connection from the post-exit occurrence to the succession target payment. The first-write successor and the next institutional visit retain their respective types. Appendix F.7 lists the values of the respective source seeds and gives the complete continuation proof.

The construction allows continuity of the relation, personal exit, and admission of new responsibility to coexist. The office continues, the old bearer's terminal responsibility retains its place in history, and the successor assumes a new responsibility from its own source.

### 5.8 What basic income, public services, and paid jobs each provide

A ends the employment relation and then requests support for life after leaving. Processing this request requires separate checks: how the former job's powers and obligations end, how basic purchasing power continues, where the required services are provided, and how A can reach and use them. Basic income, basic public services, and paid jobs accordingly perform three connected tasks.

Basic income renews purchasing power outside the role, enabling A to continue making payments while waiting, moving, and reorganising life. Basic public services must turn service capacity into specific fulfilment: accepting A's need, connecting it to available capacity and a definite service position, supplying a service receipt, and establishing a route A can actually use. If A subsequently chooses a new job, that job is established through its own relation, authorisation, labour, and remuneration. All three arrangements can serve A, but each has its own result to deliver.

The actual construction in this section makes the continuation of services particularly concrete. The served sequence indexed by the current payment has exactly two positions, occupied by the tenure and health channels. If these two fulfilled services are to be retained, a third material service requires another position; there is no such third position among the two existing ones. This is what it means below for the fibre of third material admission into the existing two slots to be empty. Neither positive exit nor a new job can produce a third service from those two occupied positions.

The later service is generated by the next actual occurrence in the platform lineage. Through a three-step relation cycle, this occurrence returns to the same relational seed and bearer, but the action itself has a new occurrence identity. It first admits a maintenance responsibility. One maintenance step then reduces its own service budget from \(1\) to \(0\), preserving the same responsibility and bearer. A native fulfilment event subsequently records the slot in a fulfilled archive. The action's own complete receipt supplies its actual successor, while the old tenure and health services are retained. The new service thereby acquires its own admission, maintenance, fulfilment, and subsequent occurrence; it still cannot be folded back into a third position among the old two slots. Appendix E.11 gives the full sources of these objects.

**Proposition 5.8 (Actual separation of income, services, and jobs).** For every payment-cycle entry and both finite observation and recursion parameters, there is a later constitutional point where positive exit outside the role, fulfilled material service, and job standing in a new role coexist. Job standing in the ended employment is empty. New-role job standing can coexist both with positive exit and with zero exit caused by capture. The new material service has its own occurrence, budget debit, and fulfilment, while the old paid slots are retained.

The fibre of third material admission into the existing two slots remains empty. Neither positive exit nor new job standing alone can therefore construct an object in that old fibre. The new material service and new job standing already obtained likewise cannot alone construct exit in the captured geometry.

**Proof.** Take the constitutional point generated by Theorem 4.3 and the full platform admission of the same payment cycle. The former supplies positive exit, emptiness of captured exit, ended employment, and new job standing. The latter supplies the new material service, that service's own budget debit, fulfilment, and preservation of the old slots. Together they form the stated object. Each non-substitution result has an actually inhabited source and an exact empty target: applying a putative substitution function to the constructed source object would inhabit the empty target, a contradiction. Appendix E.11 gives all the types and their joint assembly. ∎

Once processing is complete, the institution must also check what A has actually obtained. If the money has arrived but the route remains under the former employer's control, A still cannot use the conditions of life independently. If the route is open but service has not occurred, fulfilment of the service remains outstanding. The platform-service construction shows how this latter task is actually completed: a new occurrence undertakes maintenance, fulfils the service, and supplies its own successor. Old service receipts continue to establish that the old services were completed; later needs acquire grounds in later actual fulfilment. Through their distinct, explicit results, income, services, and jobs jointly support A's continuation.

“Unconditional” first specifies how basic standing is renewed. A need not retain the former job, prove poverty, or obtain a conduct score to retain the standing to make basic claims on the conditions of life. Institutions must still identify the bearer, arrange services, and account for costs. Removing these obedience requirements keeps the decision whether to continue a particular cooperation in A's hands. A job guarantee makes paid work accessible to those who wish to participate; income and public services jointly support their ability to leave, wait, or make other arrangements. Obligations to service providers and maintainers continue to be handled according to their respective sources.

### 5.9 From shortest actual recovery to viable continuation

After obtaining repair authorisation, A still needs to complete the process of recovering a viable life. Which actions must actually be performed to reach a viable state from this failure? Once there, how does the next continuation connect? This section answers both questions within one action graph: it first supplies a shortest repair path, then generates viable continuation of any requested length from the state that path actually reaches.

We use the complete domain portfolio defined in §5.2. Viability requires a complete portfolio, an uncaptured leaving action, and a viable disposition generated by the economic occurrence at that depth and compatible with that portfolio. At every depth $d$, the source program supplies two failed configurations. $M_d$ retains one service and positive exit capacity but lacks health service; $C_d$ retains the complete services but subjects the leaving action to full capture. Their respective actual repairs reach $V_d$, the complete, uncaptured configuration at actual visit depth $d+1$. Recovery time below counts actual operation edges.

**Theorem 5.9 (Shortest recovery, literal prefixes, and viable continuation).** For every canonical foundation parameter $h$, starting depth $d$, and requested finite number $n$ of continuation steps, the recovery program generates a service-restoration edge $a_d:M_d\to V_d$, a capture-removal edge $b_d:C_d\to V_d$, and a renewal edge $r_d:V_d\to V_{d+1}$. The authorities of these three operations are pairwise distinct. Each repair edge has length $1$ and is no longer than any legal candidate path from its respective source carrying a viable target. Their minimal recovery times are equal, but the time readout has no left inverse recovering these two repair operations.

From the first recovery target, the renewal program generates a path $\rho_{d,n}:V_d\to V_{d+n}$. Prefixing either repair edge gives a path in the same actual action graph, with
\[
 |\rho_{d,n}|=n,\qquad
 |a_d\cdot\rho_{d,n}|=|b_d\cdot\rho_{d,n}|=n+1.
 \tag{5.9a}
\]
For every $k\leq n$, there is an exact suffix $\sigma_{d,k,n}$ such that
\[
 \rho_{d,k}\cdot\sigma_{d,k,n}=\rho_{d,n},
 \qquad \operatorname{Viable}(V_{d+k})\ne\varnothing.
 \tag{5.9b}
\]
This is equality of actual paths: the continuation generated for the shorter request is literally a prefix of the continuation generated for the longer request.

The structural rent capture generated by the tenure relation also enters this result. It retains payment, routes, actual services, the unsettled responsibility, and its independent processing operation, while making the feasible exit-edge fibre of every existing essential domain empty. Its actual capture-removal edge $b_d$ reaches the same minimal recovery target and composes with viable continuation of every requested finite length.

**Proof.** A complete portfolio at $M_d$ would supply a health component, contradicting the empty health-service fibre. A viable object at $C_d$ would require the leaving action to be both captured and uncaptured. Both sources are therefore nonviable. A candidate path of length zero identifies its target with its source, contradicting the target viability carried by the candidate. Every legal candidate has at least one edge. The edges $a_d,b_d$ are generated from the existing repair receipts and each has exactly one edge, so each attains the lower bound over all candidates.

The two edges have different sources and operational authority. Service restoration uses the actually installed health-service operation; capture removal uses the actually installed exit repair. Their selected responsibility rows both commute with the current whole-ledger update and reach the same successor under the existing law. The two operations belong to different summands of the repair-action sum type and are therefore distinct. A left inverse of the time readout would turn their common value $1$ into equality of the operations, a contradiction.

Now construct $\rho_{d,n}$ recursively from the actual renewal edges. At zero steps take the empty path; to add one step, append $r_{d+n}$ to the endpoint already generated. The renewal receipt joins the current viable portfolio's payment occurrence to the actual service occurrence of the next update and supplies the next viable target and exact root successor. The length formulas follow by recursion. Fixing $k$ and inducting on $n\geq k$, append the same final edge to the suffix at each step; this gives the literal equality in (5.9b). Domainwise emptiness under structural rent capture also has a direct proof: a feasible edge in any domain would provide an independently exercisable leaving action, contradicting full capture. The bearer, settlement, and independent processing operation in that capture responsibility are then retained by the same capture-removal receipt. Appendix F.2 gives the complete parameters and occurrence joins. $\square$

Minimality therefore compares all legal candidates in this action graph starting from the same failure, while viable continuation holds for any requested number of steps. The shorter course of life remains literally within the longer one, and every intermediate point has a complete portfolio and an uncaptured continuation. The result supplies an executable, extensible path, going beyond the claim that a viable state exists somewhere in the future.

### 5.10 Full-domain readout and source-generated repair

A shortest recovery path tells us how to continue; diagnosis must also identify which repair the present failure requires. Expanding an exit-capacity number to include reachability in every existing domain can still leave this question unresolved.

Let \(\mathcal D\) be the essential-access relation authorities already generated by the source program, including the witnesses for tenure and health-service relations. At depth \(d\), the failure-source type \(\Omega_d\) contains capture through control of a tenure relation and an uncaptured route interruption. For a source \(x\), read its exit capacity together with its entire domain-reachability set:
\[
\rho_d(x)=
\bigl(K_d(x),\{D\in\mathcal D\mid
\text{source }x\text{ in }D\text{ has an actually feasible exit edge}\}\bigr).
\]
Write \(r_d(x)\) for the canonical repair generated from this source by the installed repair rule. The two sources both read as \((0,\varnothing)\), although the former requires capture removal and the latter route restoration.

There is also a stricter requirement of fairness. If only the names of the two sources are exchanged, a reconstruction rule should exchange its selected source accordingly, without favouring either label. This is called “naturality” with respect to source symmetry. The following result rules out both correct recovery in general and recovery compatible with such lawful renaming.

**Theorem 5.10 (Diagnostic impossibility for full-domain readouts and recovery from sources).** For every \(d\in\mathbb N\), \(\rho_d\) has an exact source kernel with distinct sources, the same visible readout, and different canonical repairs. There is also a reversible symmetry of the whole of \(\Omega_d\) that preserves \(\rho_d\) and exchanges the two repair values without fixing either. Consequently, canonical repair does not factor through \(\rho_d\); no left inverse recovers every such source; and no faithful authority reconstruction, natural section, or natural authority reconstruction exists with respect to the admissible symmetries of this source family.

The conclusion also covers all further processing of the coarse readout. The output can be any type of report, indicator, or encoding: for every output universe, every output type \(Y\), and every readout \(q:\Omega_d\to Y\), if a function \(f\) satisfies
\[
q=f\circ\rho_d,
\]
there is no decoder \(g:Y\to\operatorname{Repair}\) satisfying
\(g(q(x))=r_d(x)\) for every such source.

Read the existing failure kind \(\phi(x)\) from the source. This is an input the installed repair rule already obtains before issuing a repair. The refined readout
\[
\widehat\rho_d(x)=(\rho_d(x),\phi(x))
\]
preserves the coarse observation, is injective on \(\Omega_d\), and allows the installed rule \(R_d\) to realise
\[
r_d(x)=R_d(\phi(x)).
\]
Thus authority factorization exists after refinement. Every such source also generates a proof-carrying geometric plan for its canonical repair: the resulting capacity is \(1\), and, within the candidate-repair type of this section, a repair is effective if and only if it equals that canonical repair.

**Proof.** At the capture source, the same capture relation blocks exit edges in every domain. At the route-interruption source, the route receipt required in each domain is empty. Both full-domain sets are therefore empty, and both capacities are zero. The installed repair rule produces capture removal and route restoration respectively, which are distinct. If \(f\) and \(g\) existed as above, equal \(\rho_d\)-values would give equal \(q\)-values through \(f\), then equal repairs through \(g\), contradicting the different repairs. A left inverse recovering sources would likewise equate the two distinct sources.

Exchanging the two source constructors and their source proofs gives an involution of the entire source type. Canonical repair is exchanged while the coarse observation is preserved. If a natural section chose a source over the reachable common visible value, naturality would require that source to be fixed by the exchange. Its repair changes under the exchange, so it cannot be fixed.

For the positive refinement, equal \(\widehat\rho_d\)-values give equal failure kinds, hence the same source constructor. Their proof payloads agree, so the two sources are equal. The installed repair rule directly uses this failure kind, yielding the required factorization from the source rule. Evaluating the two repairs on the two source constructors gives capacity \(1\) for the canonical choice and \(0\) for the other choice, establishing the proof-carrying plan and the exact effectiveness criterion. Appendix F.3 supplies the full types, the naturality contradiction, and the direct processing operation. ∎

Even listing every domain can make two failures appear to be the same. What makes repair identifiable again is the failure kind retained in the source. It separates objects conflated by the coarse observation and is used directly by the installed repair program to supply the canonical choice and its effectiveness. The next section obtains witnesses for both kinds of source from actual execution.

### 5.11 How actual support produces probability readouts

The two failure sources in the preceding section each have an actual execution witness. At every depth, the basic-payment disposition generates the capture-removal branch, and the independent route disposition generates the route-restoration branch. We now place these two executions in one finite observation and calculate the probability of the event ‘capture removal is required’. Denote their occurrences, carrying complete sources, by \(a_d^{\mathrm c}\) and \(a_d^{\mathrm r}\). They share the exact root event, source entry, whole-ledger write-back, and actual next state, while retaining distinct projections, their branch-specific processing operations, and different repairs.

**Theorem 5.11 (Actual support, finite traces, and refined probability).** At every depth \(d\), each source in \(\Omega_d\) has its actual installed witness; actual support therefore equals all of \(\Omega_d\). Both endpoints of the same-visible/different-repair kernel belong to this support jointly. Route restoration cannot be retyped as an actual repair of the capture-removal coordinate, and the converse retyping is also impossible.

For every finite horizon \(h\), the generating program supplies a dependent trace \(T_h\) containing each canonical occurrence \(a_d^{\mathrm c},a_d^{\mathrm r}\) exactly when \(d<h\). This trace has no duplicates and has length \(2h\). Its root-event readout stamped with the failure kind retained in the source also has no duplicates, whereas the bare root-event readout has a collision at every positive horizon \(h>0\). The unit counting measure generated from \(T_h\) assigns each actual member weight \(1\) and has total mass \(2h\).

Let \(E\) be the event that the installed repair is capture removal. Fix any \(d\), and take the fold of the actual occurrence table specialised to that depth, whose horizon is \(h=d+1\). Let \(e_d\) be the exact root occurrence carrying the current visit, and query the common coarse readout
\[
y_d=\bigl(e_d,(0,\varnothing)\bigr)
\]
The coarse observation fibre is exactly
\([a_d^{\mathrm c},a_d^{\mathrm r}]\), and its event fibre is exactly
\([a_d^{\mathrm c}]\), so the readout is the defined value \(1/2\). This shared probability readout still cannot completely recover repair authority.

After adding the failure kind from the same source, the two query fibres become singletons, the installed repair rule again factors repair authority, and
\[
\widehat P_d(E\mid \widehat y_d^{\mathrm c})=1,
\qquad
\widehat P_d(E\mid \widehat y_d^{\mathrm r})=0.
\]
At horizon zero, the observation contains no occurrences. Every query has an empty fibre, and probability returns the undefined value \(\mathrm{none}\).

**Proof.** For each of the two constructors of this source type, take its installed actual branch. Their roots, ledgers, and next states come from the complete execution at the same source root, giving equality of these three readouts. Processing operations and actions retain their respective branch types, and repairs differ. Thus every such source has an actual witness.

Map \(0,\ldots,h-1\) to the actual occurrences of the capture branch and append the corresponding route-branch occurrences to obtain \(T_h\). Within each branch, projection to depth proves injectivity; across branches, the failure kinds differ. The resulting list has length \(2h\) and no duplicates. Forgetting failure kind identifies the exact root events of the two endpoints at the same depth; retaining the kind separates this collision.

Unit weights make an event's mass equal to the length of its filtered list. The exact-root coordinate in \(y_d\) excludes all other depths, while the full-domain readout retains both endpoints at depth \(d\). Only the capture branch belongs to \(E\). The fibre mass is therefore \(2\), its event mass is \(1\), and normalisation yields \(1/2\). After refinement each fibre has mass \(1\), with event masses \(1\) and \(0\). The zero horizon contains no actual members, hence has no positive fibre mass to normalise and returns \(\mathrm{none}\). Appendix F.4 proves the counting, provenance preservation, and fold identities in full. ∎

The value \(1/2\) comes exactly from unit counting of the two actual members at the specified root event. Adding the failure kind leaves the measure, the queried event, and the repair program unchanged. What changes is the information retained by the observation: each member returns to its own singleton fibre, making repair authority distinguishable again.

### 5.12 Dark twins: the institution keeps running, yet A cannot leave

The transfer has arrived, services have actually been provided, and someone continues to handle the responsibilities. Can such an institution still trap A? The preceding constructions answer yes. More troublingly, an institution may retain the complete ledger and actual next state yet choose the wrong repair from a readout that has lost the source of failure. Keeping a procedure running and enabling those subject to it to refuse the relationship that subjects them to control are two requirements that must each be realised.

We call a comparison that preserves a common source and the other specified conditions, while making one load-bearing condition fail, a **dark twin**. It tests necessity: the payment remains this payment, the bearer remains A, and the outstanding responsibilities and their handling remain in place. What can still be missing that prevents A from leaving? Another comparison tests diagnosis: two actual branches leave the same coarse record but require different dispositions. The following three results each fix their own common material.

**Proposition 5.12 (Institutional obstructions from missing conditions and coarse observation).** The preceding constructions have the following counterexamples.

1. **The other institutional operations do not supply a missing route.** For every depth \(d\), the complete route-deletion type \(B_d\) has an actual inhabitant. At the same root occurrence, the construction retains actual payment, payment standing, the tenure relation, noncapture, actual service, the current responsibility row, whole-ledger write-back, independent handling, and the actual successor, together with the other seven installed renewal operations. The source-route type \(T_d\) that must be restored is empty, as is the source type of actionable exit. Hence
   \[
   B_d\ne\varnothing,
   \qquad T_d=\varnothing,
   \qquad (B_d\to T_d)=\varnothing.
   \]
   Route repair generates a target route at the next visit; the source and target visits are strictly distinct.
2. **Payment and a role-external future do not supply uncaptured exit.** For every visit of the fixed source root, source index, and lifecycle index, the actual paid-exit lifecycle has a full-capture counterpart. It preserves the same payment chain, purchasing power standing, actual departure from employment, employment loss, exit interest, a bare role-external future and its relation-level actionability, external responsibility and its handling, services, and the actual successor, while the type of actionable exit renewal is empty.
3. **A common root, ledger, and successor do not determine a common repair.** For every depth \(d\), the two actual branches in §5.11 share the exact root occurrence; their source entries and whole-ledger write-backs agree in the precise sense required by their respective dependent types, and their actual next states are equal. Their projections and repairs differ. Both branches have the full-domain readout value \((0,\varnothing)\). For any output universe, output type \(Y\), and function \(f\), put \(q=f\circ\rho_d\). There is no decoder \(g:Y\to\operatorname{Repair}\) satisfying
   \[
   g(q(x))=r_d(x),
   \]
   for every source of this type \(x\in\Omega_d\).

**Proof.** For the first part, take the actual route-restoration source of §5.1. From depth \(d\), it generates a complete object \(b_d:B_d\) and separately regenerates seven operations at that same visit: proof-carrying renewal, basic payment, recognition witness, mandate, essential service, common clearing, and clearing backstop. Each has its own actual answer and successor factorization, while the source-route receipt remains absent. If a reconstruction \(u:B_d\to T_d\) existed, \(u(b_d)\) would inhabit the empty type, a contradiction. Any actionable exit at the source would also have to supply that route and is therefore impossible. The target route comes from the repaired visit \(d+1\). If the two visits were equal, reading their depths would give \(d=d+1\), a contradiction. Using its receipt for the next continuation is precisely what the repair accomplishes. Appendix F.10 gives the complete preserved fields and direct handling.

For the second part, take the positive lifecycle of §5.5 and its full-capture counterpart. The counterpart retains, component by component, the source objects used for payment, employment, interest, external responsibility, and services. Suppose there were an actionable exit renewal, and take its role-external continuation action. This future relation together with the non-idleness condition forces that action to be “leave.” Full capture captures that very action, whereas actionability requires it to be uncaptured: a contradiction. Actual payment and responsibility can therefore coexist with an empty exit-renewal type. Appendix E.3 gives the complete lifecycle and this counterpart.

For the third part, take the actual remove-capture branch and the independently installed route-restoration branch. Both obtain their source entry, whole-ledger write-back, and next state from the complete execution of the same root. Their installed operations still require, respectively, removal of capture and restoration of the route. Capture empties the independent exit edges in every domain; route outage empties the route receipts required in every domain. Their \(\rho_d\) values are therefore equal. Every \(f\) sends equal inputs to equal outputs, and every \(g\) must assign the same repair to that output. It cannot equal two distinct values of \(r_d\). Both endpoints here lack exit and require different repairs; they are distinct actual coordinates on one root. Appendices F.3–F.4 give the source kernel, actual support, and complete transport. ∎

The first part proves that a route requires its own actual source. The second locates the difference made by power in a continuation action that already exists. A has actually left the former job, yet B can still control A’s use of the conditions of life. Payment and services remain real; A’s ability to refuse B has not been secured. Pettit locates domination in a capacity for arbitrary interference, while Anderson asks how private power organises workers’ lives [@Pettit1997; @Anderson2015]. The formal contribution here is a counterpart that preserves the other actual material: when B captures this continuation action, actionable exit renewal becomes empty; once capture is removed, repair connects to viable life.

A needs to be able to use the service that has already been paid for.

The third part turns to how an institution understands its own failure. The two branches share a root, ledger, and successor. If the institution reads only capacity and the reachable set across all domains, it still merges removal of control and restoration of a route into a single problem. The proposition quantifies over every subsequent operation that factors through this coarse observation. Changing the report format, adding indicators calculated from the same readout, or applying more elaborate computation all inherit the merger. Sen distinguishes possession of resources from actual capability. Here we further distinguish an accurate capability readout from the source information needed to identify failure and choose a repair [@Sen1979].

Source refinement identifies the way out. The failure kind in the source is already present in the inputs to the two actual operations. Retaining it separates the sources, and the installed repair rule again yields the uniquely effective choice for each. An institution that repairs failure must therefore preserve distinctions that matter for responsibility and bring them into actual action. The respective sources of the bearer, the control relation, and the service route supply the material such judgment needs.

Section 7.8 brings the same question to progress budgets. After recognising responsibility and revising the rules, can an institution recover progress capacity merely by rearranging the old ledger? Proposition 7.8 quantifies over every conservative sequential target of the exhausted source ledger. With no new row at admission and no increase in any row’s budget, every row of the first successor satisfies \(0\le B'\le0\). The actual revision has already preserved a bearer and an answer for the residual; new positive progress still requires a source that supports it. Recognising responsibility and restoring its capacity for strict progress each require their own actual grounds.

These obstructions explain why the total theorem jointly undertakes generation, disposition, exit, and regeneration. Root law makes each write account for authority and responsibility. The exit contract enables A to refuse the relation that subjects A to control in practice. Retaining sources enables the institution to identify the correct repair. Theorem 1.2 quantifies over every cycle of the defined cycle type, every position, and every lawful payment there: the complete contract passes with that payment into its actual target. Theorem 6.2 actually generates a joint regeneration object at every depth and proves that every object of that type retains six guarantees on the same payment. Theorem 6.3 makes that step’s actual successor precisely the entry at the next depth. Dark twins expose the gaps left by weaker guarantees, while the positive construction gives a way to realise the requirements together in one nonempty society.

## 6 Responsibility birth and same-occurrence regeneration at every depth

### 6.1 How continuing activity generates new responsibility

As A continues to act, new relations can generate obligations that did not exist before. An additional service commitment, for example, needs its own bearer, fulfilment conditions, and first payment, and must enter the future together with existing obligations. A complete institutional program therefore distinguishes two kinds of action: sequential action transports old responsibilities, while responsibility admission brings a new responsibility into the complete ledger.

Sequential action sends old open responsibilities into the target's initial responsibility set. Every initial target row has an old source, and distinct old rows retain distinct images. Responsibility admission expands the responsibility domain to
\[
R\sqcup D,
\]
whose left side preserves the existing responsibilities and whose right side carries new responsibility. The new component is initially inactive and therefore has no new open row. Once activated, state \(s\) determines the new row natively. An actual step from the same source,
\[
s\longrightarrow t,\qquad B(t)<B(s)
\]
supplies its first payment. Here \(B\) is the natural-number budget for strict progress permitted to the responsibility row. The inequality \(B(t)<B(s)\) establishes that this step actually spends some remaining capacity to advance, so \(B(s)>0\) at its source. Whether the responsibility remains live, whether service has actually been paid, and the size of this budget are recorded in separate fields. We will follow the same responsibility to examine how all three change.

**Proposition 6.1 (The complete first write of actual responsibility birth).** For every fully installed program containing the actual admission step above, its generated execution produces a new responsibility row, its first payment, the successor after the first complete responsibility write, and the actual following visit generated by that successor. The old rows, existing responsibility content, and established result projections are preserved. Every item in the target's initial open responsibility set either comes from an old row or is this birth row. The execution remains in the action class of Theorem 4.2.

**Proof.** The inactive new component has no witness of openness, while the old and new components occupy opposite sides of a disjoint sum. The new row therefore cannot find an old row with the same source in the complete old ledger that could serve as its predecessor. This also shows why ordinary transport, which requires every target row to have an old source, cannot accomplish responsibility birth by itself.

The activated state \(s\) supplies a witness that the new row is open. The actual step takes it toward \(t\), with strict budget decrease supplying the first payment. Every old row simultaneously obtains a transition receipt from the prescribed evolution. Transport of all the old rows and the new row's first write together form this complete write-back.

Call the successor produced by this first complete write the **first-write successor**. Its common carrier combines the successor support already generated by the source root with the new state \(t\). It retains both sides' write-back and the destination of each row. The embedding of old rows is injective, and returning to the old observations yields that operation's established result. The action's actual following visit is precisely the visit generated by this first-write successor. Finally, distinguish whether an initial row belongs to the old or new component. This exhausts the target's initial open responsibility set. The program binds this admission result as its action output, so new responsibility is born within the action class of root law, without adding a fifth kind of root-law authority. ∎

In the actual run, admission of new responsibility can proceed as reform under the law in force, preserving the existing observation types, observed values, and responsibility projections. Law revision is identified by an actually generated revision disposition, according to the branch the run uses.

### 6.2 How six guarantees belong jointly to this payment

After A leaves, services must continue, someone must bear the old responsibilities, and the counterparty's interests must also receive a disposition. For these requirements actually to hold together, ordinary repair, capture responsibility, and the repaired successor must use the same payment \(p_d\); the repair on which each of the latter two rests must be exactly the former. The following joint construction uses these two shared relations to connect six guarantees within one execution.

Let \(\Gamma_d\) be the following object type. Its three components belong respectively to the ordinary-repair carrier, complete capture-responsibility carrier, and actual repaired-successor carrier prescribed by the installed programs, and satisfy the two exact shared-repair relations above. The generating function accepts only \(d\) and constructs these objects from that occurrence's payment, relations, actual service, and successor program. Appendix B.8 gives the full definition.

The joint construction retains successors of two different types. A **responsibility post-state** gives the state of a responsibility after this fulfilment; it belongs to the complete payment and its independent processing operation. The **following constitutional visit** gives the actual starting point of the subsequent run; it belongs to the source root's temporal progression. The factorization installing this payment in the source root connects them.

Within this common object, ordinary repair supplies how to change the arrangement; capture responsibility retains who is affected and who continues to bear responsibility; and the repaired successor supplies where the next step starts. The two shared-repair equalities identify the repair in each of the latter two components with the very same repair supplied by the first. Thus, for any \(g\in\Gamma_d\), all six conclusions below can be obtained from that object itself.

| Joint conclusion | Content retained by the same complete payment |
| --- | --- |
| Continuation of old law and responsibility lineage | The old law, responsibility lineage, and inherited responsibilities are preserved; the repair's actual successor agrees with its target program |
| Ordinary exit does not contract | Both the current uncaptured ordinary continuation and the following actual occurrence have an exit; in this construction \(K_d=K_{d+1}=1\) |
| Repair of the captured relation | The captured configuration's exit type is empty; the repair's target program is actually installed at the following visit and restores genuine exit |
| Retention of the residual bearer and processing operation | This payment's residual and bearer remain; the activated operation's responsibility post-state equals this payment's responsibility post-state; the repaired successor also has its own root responsibility processing operation |
| Capacity for law revision at the successor | The successor retains the faithful route for law revision already constructed, together with the actual receipt that this joint run used the same revision core at depth zero |
| Responsibility across actors | The protected interest of the actual counterparty actor, distinct from A, enters the disposition; settlement identity and the responsibility incidence at this payment's source are preserved |

**Theorem 6.2 (Same-occurrence regeneration at every depth).** For every \(d\in\mathbb N\), there is a \(g_d\in\Gamma_d\). For every \(g\in\Gamma_d\), all six conclusions in the table hold jointly. For every foundational observation horizon \(h\) and every \(d\), the canonical society \(S_h\) actually retains and exports this joint certificate. The foundation horizon \(h\) does not restrict regeneration depth to values at most \(h\).

**Proof.** Given \(d\), the regeneration program generates ordinary repair, complete capture responsibility, and the actual repaired successor from the payment at that depth. The two shared-repair relations hold by construction, giving \(g_d\in\Gamma_d\). Now take any \(g\in\Gamma_d\). It retains the same shared-repair relations, and all six conclusions below are read from this one joint object.

Ordinary repair uses the selected row \(\delta\) associated with this continuation in this payment's complete responsibility record. Row evolution preserves the law in force before repair, responsibility lineage, and inherited responsibilities, and generates the exact successor and target program. This gives the first conclusion. The current uncaptured exit geometry has only one nonidle action that can be paired with actual service, so its capacity is one. The actual occurrence following repair has its own service geometry and also has capacity one. Both ends therefore have genuine exit and satisfy \(K_d\le K_{d+1}\), proving the second conclusion. The current captured configuration removes the feasible exit relation. Repair installs the target program from this same disposition at the following visit, proving the third.

The capture settlement is exactly the settlement already opened by this payment. Projecting its residual and bearer preserves both corresponding objects of this payment. The existing purchasing-power standing also retains an activated independent processing operation whose responsibility post-state equals that of this payment. This payment's installation factorization from the same source and bounded update give the following constitutional visit. The repaired successor has its own root responsibility processing operation as well, proving the fourth conclusion.

The repaired successor retains the faithful map already constructed by the revision interface, together with the receipt that this joint run actually used the same revision core at depth zero. This gives the fifth conclusion. Finally, this payment's counterparty acceptance evidence determines the protected interest and opposing obligation. The counterparty's source identity differs from A's, and the residual responsibility incidence belongs to this payment's source. This proves the sixth conclusion.

Every \(g\) obtains these six conclusions through its own relations of shared source. The construction of \(S_h\) actually invokes this joint processing operation and stores its result. The same certificate can thus be exported for every \(h,d\). ∎

### 6.3 The actual successor connects to the following occurrence

The successor produced by repair should become the actual starting point of the following run. For every pair of adjacent depths, we now check this connection: is the visit reached by one step precisely the entry through which the next step generates its occurrence?

Let \(v_d\) be the regeneration source root's visit at depth \(d\), and \(v^+(g)\) the following constitutional visit of regeneration object \(g\). Let \(e_R(v)\) be the occurrence generated by that root at visit \(v\), and \(e(g')\) the root occurrence of the following regeneration object. The payment itself is indexed by its visit. Retain the visit together with its payment in a common carrier of occurrences, writing \(\widehat p_d=(v_d,p_d)\), so that the payment's complete occurrence identity is preserved.

**Theorem 6.3 (Exact continuation and the first policy rupture).** For every \(d\), every \(g\in\Gamma_d\), and every \(g'\in\Gamma_{d+1}\),
\[
v^+(g)=v_{d+1},\qquad
e(g')=e_R\bigl(v^+(g)\bigr).
\]
At the same time, \(\widehat p_d\ne\widehat p_{d+1}\): adjacent payments have different occurrence identities in the common carrier. The policy rupture at depth zero also actually generates same-source law revision. The ordinary-repair successor and the law-revision successor sharing that rupture's source both exist and are distinct.

**Proof.** The root's temporal recurrence supplies \(v_{d+1}\). The target visit of ordinary repair is precisely this visit under the same generating rule, proving the first equality. Every regeneration object at depth \(d+1\) generates its root occurrence from that visit. Substitution of the first equality gives the second. If the adjacent payment occurrences in the common carrier were equal, projecting their visits and then taking causal depth would give \(d=d+1\), a contradiction.

At depth zero, the actual policy rupture retains the same payment, two actual service positions, and the comparison between uncaptured capacity one and captured capacity zero. Review under the mother law in force connects this rupture to the exact-failure interface already installed at the same visit. Revision thereby obtains the same responsibility row specified by that failure interface and its existing authority. The joint run actually uses this revision core. The revision's first write and migration of inherited responsibility also come from that same core.

Ordinary repair continues on the old root's support. The law-revision successor uses support expanded by an actual new direction. The old support has only two points. The revised support contains two distinct old positions and a position supplied by a new direction. If the complete successors were equal, these three distinct points could be injected into the old support, contradicting the impossibility of injecting three points into two. Appendix B.7 gives the three points and the required type transport. Finally, this policy revision at depth zero and the joint regeneration object retain the same ordinary repair and the same rupture occurrence. Actual law revision and the six regeneration conclusions therefore really are connected here. ∎

The regeneration recurrence thus generates a regeneration object at every prescribed finite depth and carries the source and responsibilities retained by one step into the next step's actual entry. Each step has its own occurrence identity. The exact successor equality lets these distinct occurrences continue using the same chain of responsibility.

![Six regeneration conclusions on one payment and the entry to the following depth](figures/05-regeneration-en.svg)

Figure 6. The six guarantees use this complete payment jointly. The relation at the bottom connects repair's actual successor visit to the following depth. The following occurrence is generated by that visit and remains distinct from the current occurrence. Continuing capacity for revision and the same-source law revision actually performed at depth zero retain their respective witnesses.

### 6.4 Law revision and birth occur together beyond every finite stage

Regeneration at every depth has established that one actual payment can carry six guarantees jointly and pass its successor to the next occurrence. We now follow another generated periodic run. At every tick it actually revises the law and generates a new usable future at the payment's target. The connection to be proved is that the source used by the next tick really comes from the target supplied by the preceding tick.

We first introduce the objects used in this run. A **paid replay** is a complete execution of the given source program at an actual visit, retaining that occurrence's payment, services, responsibility, and authority. Each replay has its own occurrence identity. A cycle entry carries a source span connecting adjacent replays. A processing step consumes the span's morphism and payment evidence, generating law revision and the next entry.

Let the initial entry be \(c_0\), its boundary \(b\), and the entry at tick \(d\) be \(c_d\). The current right replay at this tick has lifecycle index \(i_d=i_0+d\), and its payment actually generates the target at index \(i_d+1\). The next replay pair uses these two objects directly: the current right replay becomes the next pair's left member, and the current payment's target becomes its right member. Thus
\[
i_d=i_0+d,\qquad
c_{d+1}
=\operatorname{nextCycle}(\operatorname{step}(c_d)).
\tag{6.4a}
\]
The entry and boundary determine the starting point \(i_0\); Appendix E.6 gives its exact value. The next tick reads a new source, authority, and morphism from this output entry and then generates its own payment evidence.

A joint step at one tick connects three components. Actual law revision uses the exact failure and revision core generated by that entry. The current payment's target acquires a compatible new future, whose services and continuation are fulfilled through the target's own native payment. Root law proceeds along the same lifecycle from its own current occurrence to the next root-law occurrence. Its current position is \(i_d+2\), and its actual payment edge is \(i_d+2\to i_d+3\). The three generated lifecycle payment edges connect these positions.

“Within the same tick” therefore preserves the exact positions of the respective occurrences. The next revision payment generated at this tick has the same occurrence identity as the payment used by the target future, while this tick's source and target payments are two adjacent occurrences. **Cofinality** means that beyond every finite cutoff there is a step at which law revision, root-law continuation, and a new future are all supplied together.

**Theorem 6.4 (Cofinal law revision, birth, and an open run).** Fix any old-visit parameter, source index, boundary, and payment-cycle entry.

First, for every observer parameter \(h\) and depth \(d\), tick \(d\) generates a joint step. For every finite cutoff \(n\) and observer parameter \(h\), there is one and the same \(m>n\) at which actual same-source law revision, compatible future generation, and the complete root-law transition hold jointly:
\[
\forall n,h\ \exists m>n:\quad
\text{revision occurrence}(m)\land
\text{compatible future}(h,m)\land
\text{root-law transition}(h,m).
\tag{6.4b}
\]
One may take \(m=n+1\). Its next entry is exactly \(c_{m+1}\). The occurrence identity of this tick's next payment is dependently equal to the actual payment of the target future, while the tick's source and target payments have different occurrence identities. At every depth, the “unrevisable terminal constitution” object that retains the current constitution but deletes the already generated target root law, target constitution, and its lifecycle evidence is empty.

Second, full platform admission and this cofinal process meet at the admission's actual replay occurrence. Beyond every finite cutoff, there is therefore an actual point retaining the admission's source, the complete root law, revision, and a compatible future. For every finite representation cutoff, the construction also generates two later occurrences with the same visible readout but different actual paths and service authorities. This pair's own two-slot representation requirement produces an exact failure, same-source revision, a first write, and a common successor. Within that same local runtime, every positive finite depth has an actual query, actual response, and next visit; authoritative visits at different depths are distinct.

**Proof.** Fix the current entry \(c_d\). Its actual morphism generates payment continuation, supplying the current payment's target. By their sources, the current right replay equals the next pair's left replay, and this payment target equals the next pair's right replay. The target root occurrence and target payment equal, respectively, the occurrence and payment used by the next source submission. The next source's own authority, morphism, exact failure, and revision core can therefore actually be used. Passing this output to the next step gives (6.4a).

The lifecycle checks every connection further. The preceding tick's second stage and the following tick's first stage come from the same generating process. Their root occurrences, payment occurrences, authorities, and actual service occurrences agree respectively. The target future is obtained from that target payment, so it connects exactly to the next revision payment. The current root-law occurrence is at the stage of continuation outside the role in this same lifecycle; its own payment carries it to the next current root-law state. Injectivity of the payment indices strictly separates the occurrence identities of the current and next payments.

The construction holds for every \(h,d\). Given any \(n,h\), take the same joint object at \(m=n+1\) to obtain all three conclusions of (6.4b). Its actual successor continues to supply \(c_{m+1}\). A claim that the target root law, target constitution, or lifecycle evidence generated by a step is empty is contradicted by the corresponding object that step actually supplies. A claim that no joint step exists beyond some finite cutoff is likewise contradicted by the joint object at \(n+1\).

The actual paid replay used by full platform admission is precisely the left member of the first successor replay pair in the cofinal process. Connecting its admission material to the later steps above therefore gives the cofinal point in the second part. This connection retains the paid source and its actual identity.

Finite representation failure also has its own actual content. Given a finite representation cutoff, take the two occurrences beyond it. Let their common visible value be \(z\), with actual responsibility positions \(u_0<u_1\). A program \(f\) in the old language can answer only from the visible value, so its outputs at the two positions are
\[
(f(z),f(z)),
\]
whereas the actual requirement is \((u_0,u_1)\); the two pairs cannot be equal. If the first slot's requirement is deleted, the constant function \(u_1\) realises the remaining requirement. If the second is deleted, the constant function \(u_0\) realises what remains. Failure therefore lies exactly in expressing both actual requirements together.

The local sequential action carries forward all three responsibilities at its entry and installs this intent and failure at the same active visit. An existing responsibility row at that visit supplies the bearer and revision authority. From this failure, the minimal extension generates new content with no preimage in the old language and a new row, retains the old rows, and produces the first write. The revision branch selected by the actual run consumes this very core; old and new rows enter its actual successor together.

The first tick of this local run enters visit \(2\) of the revised root. Each subsequent positive runtime depth uses the current visit's own query, response, and processing operation before moving to the next visit. Induction gives revised visit \(k+1\) at positive runtime depth \(k\). History depth therefore strictly increases, and any two distinct positive depths have distinct authoritative visits. This is continued response after revision at the local run's first tick; the periodic run above generates its own actual law revision anew at every tick. Each result has its own source, and the exact connection from the existing revision first write to the local sequential action joins them. Appendix E.6 gives the complete construction and type transports. ∎

Root law fully specifies the disposition at each execution, while the actual generating chain continues to supply new rules and bearer relations. Beyond every finite stopping point, the construction supplies a later joint step: law revision actually occurs, and new futures acquire their sources through actual payment.

### 6.5 Rich birth and new futures after settlement

Once a new responsibility enters an institution, its existing bearer must still be able to continue living. In A's exit problem, adding a traceable responsibility row is only a beginning: who bears it, who can process it, whether its bearer can obtain an actual service outside the former job, and whether action can continue after settlement must be connected through occurrences.

A **rich responsibility birth** retains a proof that the new responsibility has no preimage in the old ledger, its first generated row, native admission, bearer, and independent processing operation. A subsequently generated **compatible new future** also contains the present complete payment, the exact disposition of unsettled responsibility, actual service, and a feasible continuation for that same bearer outside the former job. “New” concerns two different objects here: the first revision generates a new responsibility row; subsequent payments generate their respective future witnesses.

**Theorem 6.5 (Rich birth and new futures across settlement).** For every visit \(v\) of the fixed source root, the revision target generated by capacity failure has a complete three-row responsibility set: two inherited rows and one new residual \(\rho\). Both inherited rows have old origins. Relative to the embedded pre-revision responsibility set, \(\rho\) has no preimage and receives rich birth admission. Its bearer \(b_\star\) is the previously registered bearer of the parent responsibility.

For every source index \(s\) and every \(n\in\mathbb N\), local state \(n+1\) of the reopening root generates a compatible new future. The residual \(\rho\) continues with its responsibility content and lineage, retaining its independent processing operation. The present payment supplies actual service and connects purchasing-power standing to \(b_\star\)'s continuation outside the former role. In the constructed geometry, this continuation has capacity \(1\); the control that fully captures it has capacity \(0\).

The actual macro path subsequently passes through residual settlement, joint settlement of the two inherited responsibilities, and post-settlement payment. At every post-settlement index \(n\), a compatible new future \(\beta_n\) exists. Writing its current coordinate as \(c_n=c_0(s)+n\), the actual successor of its complete payment is exactly the occurrence at \(c_n+1\). For every finite bound \(m\), some \(n\) satisfies \(c_n>m\). Any finite collection of \(h\) consecutive such futures has no repetitions and has count \(h\). This count cannot reconstruct occurrence identity, actual service authority, or the generated successor.

**Proof.** First enumerate the revision target completely. The old contribution and obstruction rows come from the old-ledger embedding. The third row uses the new direction generated by the exact failure. A preimage of that row in the old ledger would send its new responsibility content back into the old representation, contradicting the no-preimage property that generated the direction. The new-direction component has no open witness on the embedded old ledger either, excluding the remaining form of a preimage in the old ledger. The reverse index recovers every target row and proves exhaustiveness. By comparison, the first target write of ordinary joint settlement transports old rows individually, so every row there has an old origin.

Admission of the new residual reads the content, lineage, and budget of its first generated row; its bearer is taken directly from the registered parent responsibility. Initial causal authority and the independent processing operation come from the same occurrence as that row. After reopening, every positive-index payment carries the complete continuation of all three rows. The residual continues with budget \(0\to0\) and retains its processing operation. The work continuation in the former employment relation has disappeared, while a separate independent relation supplies a nonidle leave continuation. The counterparty of purchasing-power standing is precisely the existing actor to whom that continuation belongs, and that actor's bearer equals \(b_\star\). Payment, route, and actual service receipts form a feasible edge in one geometry. Its unique surviving action gives capacity \(1\); the full-capture control removes that action and has capacity \(0\).

The cross-settlement seam uses the payment at reopening local state \(3\). It equals the source payment of the residual-settlement action, whose generated successor enters the three-row settlement root. The residual's terminal receipt eliminates its successor same-debt fibre. The two inherited rows enter the successor root with their respective sources and later each receive a terminal receipt in joint settlement. Native post-settlement payment again supplies service, bearer continuation, and external responsibility processing. The successor occurrence produced by its execution is exactly the occurrence at the following coordinate.

Finally, choose \(n=m+1\); then \(c_0(s)+n>m\). The finite sequence's index map is injective, so its length and count both equal \(h\). Adjacent singleton futures both have count \(1\), but their actual service occurrences have different indices and therefore different occurrence identities and service authorities. Two count-\(1\) futures on opposite sides of settlement also have different actual root successors. If the count recovered these objects, the same value \(1\) would have to recover two different objects, a contradiction. Appendix E.7 gives the complete index transports and the separation of successors across roots. ∎

Rich birth thus carries requirements of provenance, responsibility, and continuing action together. What is generated here is a new responsibility borne by an existing bearer and its feasible futures. The institutional recognition and normative reasons required for human birth standing are developed separately in Section 6.6.

### 6.6 Standing for arrivals and a future people can use freely

An actual birth expands the domain to which an institution must respond. Theorem 6.5 gives new responsibility a source, initial authority, admitted standing, and independent processing, and connects a paid continuation to later settlement. The existing inventory can thus acquire a new entry, and the existing bearer gains a traceable connection to the new responsibility. An actual construction explains how birth enters the responsibility domain.

For human birth, migration, or renewed membership in society, we further argue that basic standing should be recognized through the life relations affected by institutions. Once an institution acts upon a person, it has reason to explain how services, continuation, and remedy are open to them. Productive contribution may determine particular remuneration; basic standing enables a person to make claims before contributing, while caring for others, or during an absence from production. This normative argument supplies the content an institution chooses to undertake; the finite responsibility-birth construction shows how new content can be written while complete disposition is retained.

After leaving the job, A may care for a relative, study, rest, participate in shared activities, or later enter another kind of work. These futures require time, space, services, and participation that can be withdrawn. When institutions connect these conditions to usable continuation, art, play, celebration, and exploration without a predetermined outcome have an institutional place of their own. People can choose how to use them.

The strict progress theorem guarantees that new actual occurrences can arise; joint revision and birth beyond every finite cutoff keep the run open. Participants still determine what those occurrences mean for their lives. Institutions should provide accessible, exitable conditions that carry their consequences, leaving that choice with the participants.

## 7 How responsibility continues after payment

After A has paid, whose obligation has ended, and who still owes a further performance? A payment can complete the immediate service while carrying credit risk and other source-generated responsibilities into its successor. Joint settlement must therefore examine each obligation until each transaction leg has its own fulfilment. When an institution ends a local program, responsibilities inherited across roots must still have bearers. This section follows the respective actual sources of clearing, credit, representation, and theory adoption to prove how these distinctions enter a single update or a lawful continuation.

### 7.1 Common clearing: what has each party fulfilled?

Once A has fulfilled an obligation, the counterparty still has to provide any service it owes. Clearing the transaction requires tracing every transaction responsibility to its termination. We call the part that one party must fulfill a **transaction leg**, allowing fulfilment to be checked leg by leg.

Let \(I\) be the finite set of transaction legs, with counterparty map \(\sigma:I\to I\) satisfying \(\sigma^2=\mathrm{id}\). For leg \(i\), this transaction generates a bearer \(a_i\), a responsibility \(q_i\), and a responsibility slot \(j_i\). In the construction used here, counterparties have distinct actors and slots:
\[
a_i\ne a_{\sigma(i)},\qquad j_i\ne j_{\sigma(i)}.
\]
Moreover, \(i\mapsto j_i\) is injective, and the leg list is exhaustive and contains no repetitions. Each leg's fulfilment event can update its responsibility slot only through its own source.

**Proposition 7.1 (Common clearing and unilateral fulfilment).** After all native fulfilment events have been executed along this finite enumeration, every transaction leg is fulfilled and no open settlement remains. A run that fulfils only one leg leaves its counterparty's responsibility open.

**Proof.** Induct on the executed prefix. When the fulfilment of leg \(i\) is added, its source incidence and actual receipt write a fulfilled terminal archive at \(j_i\). Injectivity of the slot map ensures that this update preserves the terminal archives of earlier legs. This enumeration exhausts the transaction legs, so every transaction slot is terminal at the end. Any remaining open settlement would belong to a transaction leg, contradicting that slot's terminal state. A unilateral run updates only \(j_i\); the distinct counterparty slot \(j_{\sigma(i)}\) retains its still-live responsibility. ∎

The actual four-leg clearing is also installed in a periodic root. At every depth \(d\), legislative selection, operational authority, the complete ledger write, and the actual next visit use the installation coordinates at that depth. These coordinates connect local clearing to the temporal root, whose next visit is \(d+1\); distinct depths remain distinct occurrences (Appendix C.2.1). Each leg ends through its own fulfilment, and the ledger in which these obligations have cleared becomes the starting point of the next institutional execution.

### 7.2 Credit support: who still bears the risk after payment?

Credit gives an unsettled relation purchasing power for continued action. To determine what this support resolves for A, we need to identify three positions: who obtains credit support, who accepts repayment, and who bears the outstanding obligation.

The actual credit construction starts from a partially cleared state: leg \(a\) is fulfilled while leg \(b\) remains open. Credit support supplies an actual repayment submission carrying the source of that transaction event; the counterparty supplies a receipt for accepted assumption. Together they generate purchasing-power standing. Borrower \(t_1\) comes from \(b\)'s relational seed, and creditor \(t_0\) from its counterparty leg. They are distinct actors. The risk bearer is read from the still-open responsibility \(q_b\). The following result holds at every depth of this periodic source.

**Proposition 7.2 (The allocation of credit responsibility and its actual successor).** At every depth, credit support from the same source and the purchasing-power standing above generate a credit object whose risk bearer is precisely the existing bearer of \(q_b\). Its actual successor appends \(b\)'s own native fulfilment event, placing its responsibility slot in a fulfilled archive. The root responsibility content and responsibility lineage are preserved; the root progress budget in this instance is \(2\to2\).

**Proof.** The transaction's counterparty relation determines the borrower and creditor. Identifying the creditor with this seed's borrower would force the same target identifier to equal the distinct \(t_0\) and \(t_1\), a contradiction. The repayment submission and acceptance receipt confer purchasing-power standing, while the still-open \(q_b\) continues to determine the risk bearer.

The generated successor appends exactly \(b\)'s fulfilment event, making \(b\)'s responsibility slot terminal. A live responsibility at that slot would contradict the terminal equality. This is precisely the slot left open by the run in Proposition 7.1 that fulfils only \(a\). The root update carries this responsibility forward, preserving its content and lineage, with both source and target budgets equal to \(2\). ∎

Leg \(b\)'s exchange obligation is now settled; the continuing responsibility at the root level still has a bearer. We can therefore check separately which obligation credit support has fulfilled and who remains responsible in the next action (Appendix C.2.2).

### 7.3 Institutional records must distinguish control and accessibility

A and controller B can appear in the same payment record while having different rights of admission and bearing different consequences. If the record shows only that this payment exists, the institution still cannot determine from it who can obtain service. Completeness of a representation is therefore always relative to the operations it must support. To answer who controls admission, who is affected, and whether a route is usable, it must preserve enough information to make those distinctions.

Let \(X\) be a source-generated domain, and let \(c_i\) be a registered family of independent processing operations that can read provenance and handle its consequences. Completeness of an old representation \(F:X\to\mathcal A\) means
\[
F(x)=F(y)\iff\forall i,\ c_i(x)=c_i(y).
\]
It preserves exactly the distinctions available to this family. Given a new observation \(r:X\to\mathcal B\), set \(F^+(x)=(F(x),r(x))\).

**Lemma 7.3 (An exact extension preserving the old content).** Equality of the new representation corresponds exactly to equality under all old operations and under \(r\). The quotient by this relation is naturally bijective with the actual image of \(F^+\), and each registered operation factors uniquely through the new representation on that image. If \(F(x)=F(y)\) but \(r(x)\ne r(y)\), the new observation cannot be recovered from the old representation.

Recovery fails because this pair has equal old records but different new observations. If \(r=g\circ F\), then \(F(x)=F(y)\) immediately forces \(r(x)=r(y)\), contradicting the actual difference. Adding \(r\) preserves both the old content and the new distinction. Appendix C.3.1 proves the full kernel, quotient, and unique-factorization statements. The following three actual extensions show what the additional observations contribute to institutional action.

**Sources of admission.** The previously installed channels include tenure and health services; platform admission is added after revision. Each of the three channels has its own relational seed, bearer, target role, and material service. The existing cultural representation maps tenure and platform admission to the same content, while the added coordinate records channel kind, relational seed, admission, and service. People entering the institution through the same cultural record can therefore still receive different actual operations according to their respective relations. The platform channel uses the grounds for admission supplied by the already-paid revision, and lawful transport connects the payment successor to the material action's successor.

**Control and bearing responsibility.** At the same actual complete payment following the first refusal, the controller and the affected party share the relational event and complete refusal record, but their source-generated actors differ. The observation “is the actual paying counterparty” is false and true for them, respectively. The price position also retains admission, service provision, open price, capture, and the existing residual. The same payment and refusal record thus correspond to different positions of control and responsibility. The new representation records these positions together with their sources, preserving the distinction between A's and B's roles.

**Spatial accessibility.** Consider again the same payment root after refusal and the same crossing position. The existing representation already records the content at the level of artistic production, but reads the blocked and repaired routes as the same. The new accessibility observation checks the route directly: the blocked route has no exit path, while the repaired route has an actual receipt leading to the service position at the next depth, with capacity \(1\). All the old content is retained, and the new distinction—whether A can reach the service—enters both the record and actual execution.

All three extensions preserve the old projections and obtain actual reading positions and successors at their source roots. Distinctions in social position and spatial accessibility thereby enter actual execution. Appendix C.3.2–C.3.3 gives the installations and transport between roots.

### 7.4 Theory adoption must account for inherited responsibilities

When a theory participates in classification, policy selection, or institutional admission, adopting it produces consequences that require an account. In A's exit problem, theoretical judgments adopted by an institution may affect which actions receive recognition and which outcomes are registered as complete. Adoption must supply an inspectable actual effect; revision must retain an account of where old responsibilities go.

Fix an old theory \(T\), a source trajectory seed \(s\), and a feedback generation process. They generate a classification \(\chi(s)\), a policy choice \(\varpi(s)\), and an actual effect \(e_s:E(s)\), together with an independent processing operation
\[
K(s,e_s).
\]
In the adoption instance of this section, both classification and policy judgments are true, while the actual effect is a generated lifecycle. The adoption program connects causal recognition at a definite position in this joint run, retains the operation of the treatment relation, and generates the complete ledger, visit, selected responsibility row, and successor of this adoption. Ordinary execution continues to use theory \(T\); whether revision is needed must be determined by a failure review directed at this responsibility.

The independent processing operation provides a way to check effects. If \(K(s,e)\) is empty for a candidate effect \(e\), while the actual \(K(s,e_s)\) is inhabited, then \(e\ne e_s\): otherwise, transporting the actual operation along equality would produce an inhabitant of the empty type. Classification and policy judgments must therefore be checked together with their actual effects and the operations on those effects.

Failure within the scope of this theory's mother law in force has a further set of definite materials. The applicable scope supplies a responsibility row \(r\) involved in this adoption and an obstruction directed at its responsibility content. The installed failure face points to the same row, which also has causal authority and an actual successor. Revision thereby addresses the failure this institution actually bears.

**Theorem 7.4 (Theory revision, responsibility migration, and later clearing).** The actual mother-law failure above generates same-source law revision, a minimal revision face, and the revision first write. The old authorisation is superseded; the inherited responsibility remains live at the first write's target visit \(1\), preserving its lineage and source anchor. A subsequent native fulfilment event at revised visit \(1\) archives this responsibility and generates its clearing successor. The ordinary and revised successors are strictly different.

**Proof.** The equality targeting \(r\) and the failure face's entry equality fix the failure to the same responsibility row. That row's causal authority and successor supply a rooted failure. In executing this exact revision, the same source materials determine the revision first write and the successors of the old and new rows.

Write \(q\) for the old responsibility and \(q'\) for the inherited one; Figure 7 depicts this inheritance through the pre-revision responsibility row \(\delta\) and its transported row \(i(\delta)\). The revision's disposition rule records the old authorisation as superseded and writes live \(q'\) into the inherited slot. Its content and bearer are read from the old row targeted by revision, while the same migration preserves lineage and source anchor. The first write's target visit is not closed: if it were, the same slot would contain a live responsibility and be a terminal archive, a contradiction. Revision has replaced the authorisation; \(q'\) still requires fulfilment.

The later run starts from this exact target visit \(1\), reads its own native fulfilment event, and writes a fulfilled archive into the same inherited slot. Before the run, that slot has a live responsibility. The terminal equality after the update excludes every live candidate at that slot, so the responsibility ends through this fulfilment. Equality between the first write's target and the later source visit ensures that the update acts on the actual ledger produced by migration. The support types of the ordinary and revised successors have, respectively, only two points and at least three, which strictly separates the successors. Appendix C.4 gives the complete argument. ∎

![Theory adoption and responsibility clearing](figures/06-theory-en.svg)

Figure 7. Theory adoption has an actual effect handled by an independent processing operation. The ordinary successor retains the old theory; an exact mother-law failure separately generates revision. The first write inherits a live responsibility, and later clearing reads its own actual fulfilment event. The arrow from first write to clearing denotes the proved continuation of visits.

The theory's institutional position has changed, while responsibility for its prior effects remains traceable through the first write and later fulfilment. Reclassification, replacement of authorisation, and actual fulfilment in A's request can accordingly be checked as distinct acts.

### 7.5 Renewal capacity, local termination, and debt settlement

Continued payment does not guarantee that every old responsibility can still renew in the same way. After A obtains an actual service, the institution must still distinguish the responsibility that has exhausted its strict-renewal budget, the root that has ended local execution, and the debt that has actually settled through a terminal receipt.

This section follows a definite history of economic responsibility. Risk is first divided between two bearers; the two contributions are then merged; and an action in the merge target spends the remaining progress budget. Capacity failure subsequently triggers revision, the new residual is handled, and inherited responsibilities pass through a handoff and finally enter joint settlement. Section 7.7 and Appendix F.8 give the complete connections for risk splitting and merging. We first follow the same contribution responsibility through this history to distinguish three termination loci.

For the responsibility of this fixed lineage, a **strict renewal payment** requires the present complete payment, an exact old origin, the evolution of the same debt selected by the whole-ledger disposition, and a strict decrease in the progress budget. The budget measures how much strict progress the responsibility still permits. Its live state records whether it still awaits disposition, and service payment records whether fulfilment actually occurs in this payment. Each of the three fields is checked separately.

**Theorem 7.5 (Three strictly distinct termination loci).** In the actual history of the canonical contribution responsibility, the following three loci occur separately.

| Locus | Actual content |
| --- | --- |
| Observer-runtime depth \(3\) | After the preceding strict debit \(1\to0\), the first write of same-source law revision still inherits the responsibility; its strict-renewal fibre is empty for the first time |
| Observer-runtime depth \(9\) | The three-row root receives a complete faithful-terminal receipt and its local successor type is empty; the same contribution debt still passes through a legitimate handoff to the inherited root at depth \(10\) |
| The later joint-settlement endpoint \(A_{14}\) | Both inherited responsibilities receive exact terminal receipts, and the successor's local responsibility set is empty; this contribution responsibility finally settles here |

From the first revision write onward, this old responsibility has no strict renewal payment supported by that responsibility's whole-ledger disposition at any index of the capacity-revision root, reopening root, or inherited root. These loci may still have their own actual service payments. At the first empty locus, the root-local coordinate is \(0\), actual service depth is \(2\), and observer-runtime depth is \(3\).

**Proof.** The depth-\(2\) action completely handles the two rows at its entry. The contribution row strictly decreases from \(1\) to \(0\), while the obstruction row continues with \(0\to0\). Its actual successor is the entry to same-source law revision at depth \(3\). The revision first write retains the old contribution row's origin, content, and lineage. The new residual occupies a separate row; the inherited contribution neither receives a new birth nor regains budget.

At every subsequent capacity-revision write, both the selected old row and its target have budget \(0\). If a strict renewal payment existed, its exact disposition equality would reduce the required decrease to \(0<0\), a contradiction. The first reopening action, all subsequent complete payments, and the settlement ingress transport this same responsibility and keep its budget zero, so the same argument applies at each stage. It also applies at every inherited-root index. Actual service payments come from the respective native occurrences and can therefore coexist with the emptiness of this old debt's renewal fibre.

Faithful termination at depth \(9\) gives all three rows local terminal receipts and makes the local successor type empty. Yet the native handoff preserves the contribution row's same-debt content and lineage, explicitly generating its target at depth \(10\). A final settlement receipt at depth \(9\) would have to prove that the successor same-debt fibre was empty, contradicting this target. At \(A_{14}\), both inherited rows receive terminal receipts, and the local open-responsibility type after handoff is empty. The required no-successor-same-debt condition then holds. These different actual receipts and successor relations separate the three loci. Appendix E.8 gives the full-history parameters and proofs at each stage. ∎

This distinction allows an institution to continue providing services while recording the old responsibility accurately. After strict-renewal capacity is exhausted, the responsibility can await exact settlement. When a local program has already terminated, inheritance across roots can still preserve that responsibility.

### 7.6 Publication enters execution: target recomputation and continuing payment

Once a judgment about termination enters institutional execution, it must also account for its consequences. The responsibility state on which publication rests, the ensuing complete payment, and recomputation after that payment together form the process to be examined.

Follow this responsibility history to the two-row inherited root before joint settlement. To publish how many edges remain before this local termination, the institution first reads the current and next sections: both current rows still have continuations, while both rows in the next section have terminal receipts. The generating program installs this finite publication demand at the current occurrence. Recursive evaluation assigns zero at termination and adds one for the preceding edge, giving the present readout exactly \(1\).

**Theorem 7.6 (Actual publication, target recomputation, and paid continuation).** For every visit \(v\) of the fixed source root and source index \(s\), the installed publication demand has finite two-section readout \((\mathrm{false},\mathrm{true})\). Its minimal-locus readout, compatible with the occurrence construction, is uniquely \(1\). This demand occurs at the actual inherited root before joint settlement; Appendix E.9 gives the exact coordinate.

That same source occurrence generates a complete publication payment containing its own actual service payment, the complete evolutions of both source responsibilities, the actual joint-settlement action, and that action's receipt. The action's actual successor is \(A_{14}\). Recalculation at this target finds both responsibilities terminal and no local successor, so the relative termination locus is \(0\). The fixed-point fibre requiring equal pre-publication and post-publication loci is therefore empty, while the actual non-fixed-point payment and response are both inhabited. The terminal handoff from \(A_{14}\) enters \(A_{15}\), whose own native payment then generates the occurrence at \(A_{16}\).

**Proof.** A native local query generates the finite readout by reading the current Boolean value and writing true. Its occurrence unfolding consists of a nonterminal node and a terminal child. The fold returns \(0\) at the terminal node and adds one to the child result at the nonterminal node, giving \(1\). Any evaluator compatible with these occurrence constructors obeys the same recursive equations and therefore gives the same result. Initially both rows in the complete set continue and neither terminates; at the next section both terminate. Thus this is also the minimal locus.

Publication payment obtains actual service from the source occurrence's native payment witness. It retains each responsibility's evolution in the present execution and reads the already generated action's receipt and first successor. All these materials are indexed by this one source occurrence. Its actual target is the terminal root. Both target rows already have terminal receipts, so recomputation immediately returns \(0\). A fixed point would require \(1=0\), a contradiction. The actual payment construction remains inhabited and generates this target response.

The terminal receipt also connects exactly to the first post-settlement root visit. The successor generated by that visit's own payment is heterogeneously equal to the following visit's native occurrence, giving the actual continuation \(A_{15}\to A_{16}\). Appendix E.9 proves uniqueness of the finite readout, whole-ledger coverage, target recomputation, and both successor equalities. ∎

At publication, the endpoint lies one local edge ahead; after execution reaches the target, zero edges remain. The change \(1\to0\) records this actual movement. An institution that simply carries the pre-publication readout over into its post-state judgment would overlook the operation it has already completed. The actual response here reads the target anew and carries the terminal handoff to \(A_{15}\), whose own payment then produces \(A_{16}\).

### 7.7 Risk splitting and external responsibility after an empty ledger

Which responsibilities settlement resolves depends on the scope it actually handles. After A leaves the former job, credit support can pay for the present service, and old risk can be redistributed between different bearers. Even when one local responsibility set is empty, responsibilities at the service's source retain their own bearers and processing operations.

**Theorem 7.7 (Source-grounded risk splitting and external responsibility after settlement).** At every periodic depth \(d\), credit materials and exact failure at the same visit of the source root generate a risk split. The parent and its two children preserve the same responsibility identifier, responsibility content, and the parent's responsibility lineage. The children use the distinct bearers supplied by the two source exchange legs. Each child branch has a strict structural-budget decrease \(2\to1\); the obstruction responsibility separately undergoes a legitimate \(0\to0\) transport. The first complete source set has exactly two rows, parent and obstruction. The target has exactly three, the two children and obstruction continuation. Each child has an independent processing operation grounded in that split receipt.

The split at each periodic depth is generated from that depth's own source visit. At depth zero, it is additionally connected to the first revision and actual successor of the existing canonical run. Along the subsequent actual actions, risk splitting connects to contribution merge, capacity debit, same-source law revision, residual processing, two settlements, and post-settlement payment.

For every visit \(v\) of the fixed source root, source index \(s\), and post-settlement index \(n\), the current occurrence \(e_n\) has an empty local open-responsibility set but still generates source-grounded external liability \(\Lambda_n\). This object retains the source ownership of this responsibility's bearer, the source payment's trace, independent root processing operation, actual service settlement, and provenance across roots. It enters the actual successor with this complete payment. Root occurrences, payment occurrences, and actual service occurrences are each injective in \(n\). Any actual service payment witnesses obtained from these occurrences are likewise locked to their own indices.

**Proof.** The risk material obtains the parent responsibility, purchasing-power standing, and bearers of the source exchange legs from the existing clearing failure and credit-support activation seed. The first complete write sends the parent to two child rows, each with a proof of \(1<2\). It attaches a non-increasing transport across supports to the obstruction row. The reverse index exhausts the three target rows. The children's responsibility sources agree; the obstruction's source differs.

The children listed in the split receipt are exactly these two target rows. Child membership recovers source ownership, descendant incidence, source-anchor transport, same-debt lineage, and preservation of local discharge conditions. These materials give two independent processing operations. The children differ because they retain distinct source exchange legs and bearers while sharing responsibility content. At each periodic depth, the construction uses the source visit at that depth. The depth-zero actual-runtime receipt connects it to the subsequent contribution merge. The exact successors of the existing actions then continue to the post-settlement payment chain. At the joint-settlement entry, the search answer and actual action at the same root and visit have different compilations; the payment chain uses the latter's action receipt.

Now fix any \(v,s,n\). The post-settlement occurrence's support equality gives an empty local open-responsibility set, while the same occurrence carries an actual service existence witness. The payment obtained from that witness retains responsibility provenance at the source root, its activation trace, processing operation, and actual settlement. These materials constitute \(\Lambda_n\). Their source root connects to the post-settlement root through the existing legitimate provenance relation. Local emptiness and \(\Lambda_n\) therefore coexist in this one post-settlement occurrence.

If two such root, payment, or actual service occurrences were equal, projecting their temporal visits would give \(c_0(s)+n=c_0(s)+m\); cancelling the common initial coordinate gives \(n=m\). The same argument applies when any service payment witness is retained together with its dependent visit in a common carrier. Finally, the complete payment reads the successor produced by the present complete execution and yields exactly the occurrence at \(c_n+1\). Appendix E.10 gives the complete split table, external liability type, and index-locking proofs. ∎

This chain makes settlement a locatable institutional fact. A specified responsibility terminates through its own receipt, other responsibilities at the source remain with their bearers, and later services are supported by later actual payments.

After risk allocation, the responsibilities of two bearers can become a common contribution. The merge must still establish who owns each parent row, which rows enter the common result, and which row continues separately. The actual construction first admits the entire generated three-row risk ledger. Write its two contribution child rows as $a,b$ and its obstruction-continuity row as $o$. The first whole-ledger write produces two rows $m,o'$ through three actual transports:
\[
a:1\longrightarrow m:1,\qquad
b:1\longrightarrow m:1,\qquad
o:0\longrightarrow o':0.
\]
The two rows $a,b$ already have the same responsibility content and protected interest; they enter the merge receipt as distinct parents. Row $m$ retains the existing bearer of leg $a$, while $o'$ retains the source parent row’s bearer. The receipt's parent list is exactly $[a,b]$: every parent is owned by the exact source event of this merge, and the obstruction row remains at its separate destination. The entire initial ledger comes from the three-row ledger after the split, before the merged result is installed.

The merge lies within three successive ticks of the existing run. Same-source law revision first generates the revised root; the merge then uses the already determined actual event at that root; the following tick starts from the merge target and spends the common contribution's remaining capacity. Each step takes the preceding step's actual successor as its source, and the merge retains exact evidence of the action selected by this execution. Appendix F.8 gives the tick numbers and visit indices. The two contribution rows have the same destination. The selected origins of the two target rows are $a$ and $o$, which are distinct, so the origin map of this write is injective. Any simultaneous split receipt claiming distinct target rows with the same source row would contradict that injectivity. Appendix F.8 establishes the parent list, source and destination coverage, and the three-tick execution in full.

### 7.8 After legal recognition, how can the capacity to advance be restored?

After A's request receives a legal answer, the responsibility already undertaken still requires further handling through its own source. To restore its capacity for strict progress, the institution must specify where the progress budget comes from. Every conservative successor is subject to the same constraint. The actual action has spent the contribution row's progress budget from $1$ to $0$. The resulting revised root recognises a new residual and assigns it to the existing parent bearer. Its complete ledger has exactly three rows—inherited contribution, inherited obstruction, and generated residual—and all three budgets are zero. The new residual already has an operation that handles its actual answer.

The targets considered below may use their own representation types and target roots. Their common constraints concern only the complete source relations of this exhausted ledger: every row at the target entry has a source row, every row after the first write has an origin at that entry, and neither level of transport increases the row's progress budget.

**Proposition 7.8 (Conservative closure of exhausted progress budgets).** For every visit of the fixed source root and every visit index of the revised root, take any source responsibility row at that visit, its native authority, and the exact source event. Every source-native sequential action target generated from these inputs, with no fresh row at ingress and non-increasing row budgets, has no positive-progress-budget row in its first whole-ledger successor.

**Proof.** Let $L$ be the complete source ledger, $L_0'$ the target's initial ledger, and $L_1'$ its first whole-ledger successor. Write $B$ for a row's progress budget. For any $e\in L_1'$, the complete write supplies an actual origin $a'\in L_0'$. No-fresh ingress supplies $a\in L$ whose lawful transport is $a'$. The two levels of conservativity give
\[
0\le B(e)\le B(a')\le B(a)=0.
\]
Every row $e$ therefore has budget zero, and the positive-budget fibre is empty. Exhaustive classification of the source ledger reduces each of its three row forms to budget $0$, so the argument applies to all the stated inputs and all such action targets. $\square$

Revision has already accomplished something substantive: the actual residual has acquired expression, a bearer, and an actual answer. Restoring a positive progress budget also requires a source that can support it. As long as a target satisfies the two conditions—no new row at ingress and no increase in row budgets—however the responsibilities within the exhausted ledger are organised, the budgets in the first successor remain bounded between zero and zero. Appendix F.5 gives the general closure lemma in any type universe and its complete instance at this three-row revised root.

## 8 An economic constitution: returning collectively created capacities to those who continue living

A's exit brings a wider set of economic relations into view. Where does income come from? Who maintains public services? How are surpluses and deficits adjusted in clearing? Who can use the labour that has been saved? Who bears the ecological and social costs left by former relations? The preceding theorems supply conditions that can be checked individually. This section develops institutional principles on that basis and identifies the formal results on which each argument draws.

### 8.1 Wealth includes the capacity to wait, refuse, and start again

A's account balance can record purchasing power, but cannot by itself record how long A can wait, whether A can refuse an unwanted job, care for others, move elsewhere, or find a place to start again. The same balance can connect to different services, spaces, and relations of control. The three zeros in §5 provide exact finite counterexamples: an identical capability reading merges different institutional causes, and a more discriminating judgment requires their sources.

We therefore understand wealth relevant to economic freedom as a set of relations supporting actual continuation. For each continuation, the bearer, required services, usable routes, and conditions of control must be identified. For its maintenance costs, the institution must specify who still owes performance. Cash, public facilities, shared knowledge, and disposable time perform different tasks within these relations. Before combining them into a single score, institutions must preserve the routes by which people can use them.

Strict canonical progress adds a temporal dimension. A service A actually receives today cannot meet tomorrow's need. Current exit capacity can remain one while the history of actually paid occurrences grows strictly: Theorem 1.3 retains the entire old frontier and generates a new occurrence at every step. The continuing support that wealth provides thus includes the capacity for services to be realised again and for bearers to begin again.

### 8.2 Common clearing and the renewal of clearing authority

The 1943 International Clearing Union proposal placed surplus and deficit within one institutional relationship. Bancor was to record credit and debit positions, excessive balances on either side would incur charges, and persistent large creditors would also have to participate in discussions of adjustment. The proposal required arrangements to discharge debit balances upon withdrawal and provided procedures for proposals at an annual assembly and reconsideration of the rules [@Keynes1943, §§I.4, II.6(7),(9),(16),(18)]. How common settlement supports each party's continuation, how participants can withdraw, and how rules can be reconsidered thus become connected constitutional questions.

Proposition 7.1 supplies a formal foundation for clearing every leg. The joint terminal state requires every transaction responsibility in the finite list of legs to have its own actual performance and its own responsibility slot updated. Section 7.7 further explains how risk is split among distinct bearers and how external responsibility continues to receive independent processing after the local inventory is empty. Common clearing accordingly requires each party to retain its source and its standing to make a claim.

We propose two institutional requirements on this basis. First, persistent surpluses and persistent deficits should both enter a common adjustment process. Its rules should explain how the capacity to accumulate and the costs of financing respectively affect other members' continuation. Second, the authority that supplies final clearing capacity should itself have procedures for authorization, renewal, exit, and revision. If one participant monopolizes others' access to liquidity, it can control their continuation by withholding clearing. The principles of exit outside the former role and non-capture therefore apply to clearing authorities as well.

The termination theorem for all transaction legs proves the discharge of responsibilities. Two-sided adjustment and the organization of clearing authority are the economic-constitutional choices proposed here. Their implementation calls for concrete quotas, deadlines, and adjustment rules. The formal foundation makes those rules answerable for each party's actual services, outstanding responsibilities, and conditions of further participation.

### 8.3 Shared production gains and disposable time

A new method ordinarily draws on existing knowledge, tools, public facilities, care work, and current inputs. Determining what gain is available for distribution requires first tracing those inputs, then accounting for added usable capacity, and finally considering allocation. Each question has its own bearers and evidence.

The public-production interface in §9 supplies a concrete application. Reusing a method already paid for saves one unit of labour, preserves the executability of every previously lawful finite action word, and leaves exactly that same additional unit of labour in the resulting state. The saving is therefore a usable resource in the actual successor. Maintenance, subsistence, and financial responsibilities remain covered by the production contract. This result shows how one can prove that the gain from an improvement has been realised.

Applied to shared production, this approach calls for calculating net gain after fulfilling existing service commitments, maintaining equipment, meeting care and ecological responsibilities, and retaining the capacity to continue. The next question is whether to use the additional resources to shorten necessary labour, expand public services, replenish common reserves, or support new activities. How a gain arose supplies reasons relevant to its distribution; particular shares require a public account of the parties' contributions, needs, and costs.

A's capacity to leave the former job becomes one criterion for assessing a productive improvement: does it increase A's ability to choose work, care, rest, and a new start? If output rises while participants become less able to refuse their former roles, the institution must examine where the gains go and how control is organized. Disposable time should connect to actual continuation free from capture, allowing people to choose how to use the new space in their lives.

### 8.4 Property, mandate, and the maintenance of shared space

Using housing, land, tools, or infrastructure involves distinct relations of access, exclusion, maintenance, transfer, and exit. Proposition 5.7 proves in its non-employment tenure and mandate constructions that the bearer of a relation can retain their payment, route, and actual service when that relation ends. Section 7.7 traces independent processing after responsibilities from the same source are allocated to different bearers. We can therefore ask, item by item, what a property right actually grants and what obligations it leaves.

We argue that use rights should be specified together with maintenance, the continuation of affected parties, and responsibility after the relation ends. A party holding a route who can close every entrance to another person's basic living conditions thereby controls that person's continuation. Institutions should subject this control to accountable authority and conditions for exit. Debt should likewise be traced through its source, bearer, and disposition, with exact occurrences for discharge, reopening, splitting, and termination, while a person's basic standing persists through changes of relation.

Shared spaces also have earlier and later arrivals. Prior arrival records the sources of actual occupation, labour, and maintenance; continued exclusion of others requires a further account of authorization, public conditions, and renewal. Applied to public domains yet to be entered, including future common activity in outer space, this distinction yields a constitutional requirement: any lasting control must continue to answer to other affected parties and preserve routes by which later arrivals can enter and participate in revision.

### 8.5 Ecological responsibility, later arrivals, and distributed checking

Discharge of monetary responsibility and repair in the material world each require their corresponding actual performance. A payment can discharge a specified debt; restoring soil and water, maintaining a route, or providing outstanding long-term care requires its own receipts in the relevant occurrences. The external-responsibility result in §7.7 supplies a firm structural constraint: after the local inventory is emptied, the external bearers generated from the source, the payment traces, and the independent processing operations remain.

Ecological costs should accordingly leave responsibilities that can continue to be processed where their effects occur. Successor institutions need to receive maintenance capacity, revision authority, and unfinished obligations. Affected parties should also be able to check dispositions from their own positions as bearers. Institutions for later arrivals can preserve resources, open routes, and limit present irrevocable control through these relations of inheritance. Upon arrival, new participants obtain their own voice and standing to make claims through their actual relations.

This checking is distributed among different bearers and processing programs. The complete contract requires declared responsibilities to have sources and dispositions, with exact evidence for settlement and inheritance. Each independent processing operation retains the part it can examine. Institutions can thus admit newly affected parties and new responsibilities while continuing to require evidence from those who exercise power.

The exercise of power is the first thing that must carry proof. People who bear institutional effects have reason to request explanations; an institution that changes their conditions must supply its source, authority, and consequences. Canonical society brings this requirement into actual payments, rule revision, and successor birth, so that collectively created capacities can continue to return to people as they carry on with their lives.

## 9 Open interfaces: preserving the conditions of new social processes

Services after A leaves the job also involve productive admission, public responsibilities, material provision, and communication. Four independent interfaces each supply their own source law, inputs, and run, connecting completion to existing responsibilities and actual successors. Appendix C.5 gives the full conditions and proofs.

**Capital relations.** A permission law specifies who may enter at a given production state and port. Production seeds, responsibility content, and finite history record how capital relations form and regenerate. For every such law, absence of capital holds if and only if, at every state and port, permission for the controller implies permission for every subject. Uniformly closing admission also satisfies this condition; when technology, ports, and subjects have instances, that law is nevertheless not fully open. After eliminating the controller's privileged access, one must therefore still check whether A's needs have received actual payment (Proposition C9).

**Public functions.** Given an inventory, authorization, a responsibility packet, and an input word specifying a sequence of actions, the public-function program generates a response and a complete responsibility successor. Every input row and input slot is terminal if and only if there is a complete termination receipt; any live responsibility forces the response to continue. After a previous authorization is withdrawn and the current task is completed, live responsibilities still require disposition. Any finite number of continuations preserves the history prefix that has already occurred and the financial responsibilities. Menu success supplies actual payment for that same action word; failure identifies the particular item and shortage (Proposition C10).

**Public production.** Under the specified conditions on production addresses, public and improved technology, sufficient quantities of six material resources, and nonnegative inventories at the child unit generate actual replication. The child unit's subsistence and maintenance are paid within that action word, the complete financial responsibility matrix is unchanged, and the parent unit's net labour cost is \(2\). A separate reuse of an already paid method saves \(1\) unit of labour and preserves every previously lawful finite action word, whose resulting state contains exactly that same additional unit of labour. The saving thus becomes a resource available in the actual successor: work that was previously executable remains executable, and the saved unit remains available (Proposition C11 and Lemma C12).

**Protocol fulfilment.** Each of two sites responds using its own queue, the current signal, previous sends, and actual deliveries. For every adaptive callback, if all actual inputs satisfy the specified communication admission conditions, the \(24\)-tick program completes all input services and send readbacks and empties its final queue. The same actual history enters the root's whole-ledger successor. An existing compliant callback makes the premise nonempty, and service has an actual path from arrival through activation to a valid reply (Proposition C13).

## 10 Literature in dialogue: exit, power, and sustainable institutional responsibility

Exit theory asks how people leave or change organizations; the capability approach asks how resources become usable freedoms. The analysis of legal relations and institutional grammar asks how power organizes action, while monetary theory asks how promises acquire force in payment and settlement. We bring these questions into an institutional operation with a source, a bearer, and a successor. The comparisons below turn on specific questions: how exit is enacted, what capability readings can determine, which responsibility a payment ends, and who still owes performance after the rules change.

### 10.1 Exit and the standing of participants

Hirschman examines exit as part of organizational feedback. Departure changes who remains to exercise voice, while a credible threat of departure influences how the organization responds to voice [@Hirschman1970, pp.3–4, 35–36, 81–82]. This analysis requires us to ask, before A leaves, whether A really has a usable route out. We specify what must hold for exit to be realised, identify its sources, and trace its temporal structure: payment, route, service, and non-capture must support the same action. A then personally exercises the power to leave, and continuation outside the former role begins from the successor actually reached by that action.

Anderson places a further demand on the justification of these relations. Even when people can enter or leave a relation, the available set of relations and the powers exercised within them still require justification. Her analysis of private government concerns authorities that can command and sanction people without granting those subject to them standing to demand consideration of their interests [@Anderson2015, pp.99–100, 110–111]. This brings exit and the root law into the paper together. During participation, every write must have a source, authority, and an account of where responsibilities go; after departure, basic standing must remain connected to actual living conditions. A person who can leave still has standing to demand reasons from the authority currently exercised over them.

Pettit's focus on the capacity for arbitrary interference makes relations of control an object of examination in their own right [@Pettit1997]. Our capture contrast applies that examination to an already existing continuation action. Payment, service, and the relation outside the former role are retained, while the relation controlling the action can render the exit type empty. Structural non-retaliation makes non-capture part of the target payment's own response. Assessing protection therefore requires tracing how this action is supported, who controls it, and what successor it produces.

Widerquist supplies a material argument for this independence: refusing unwanted cooperation requires independent access to resources sufficient for basic living [@Widerquist2013]. We connect this requirement to the respective operations of income, services, and employment. Purchasing power must be realised in usable services; public services need capacity and routes; a new paid job needs a relation from which the participant can withdraw. Together, the three support a person's choices and make the question of life after saying no an institutional responsibility that can be checked item by item.

### 10.2 From capability evaluation to the identification of repair

Sen calls for evaluating the effect of resources in terms of what people can actually do. Robeyns places personal, social, and environmental conversion factors at the core of capability analysis. She explicitly argues that identifying resources and conversion factors helps locate possible interventions, and includes the moral requirements governing processes of realisation within value pluralism [@Sen1979; @Robeyns2017, §§2.6.3, 2.6.7]. This tradition already sets demanding informational requirements for institutional diagnosis. We pursue a further question: when an institution must use that information to choose an exact repair, which readings suffice for the task?

The task is defined by the actual effect of repair. Two failures with identical reachability can require, respectively, removal of control and restoration of a route. Theorem 5.10 proves that, across the specified complete source family, exit capacity together with the set of reachable domains among all those installed still merges these two sources. The resulting limitation covers every further encoding through that reading and every candidate for correct decoding: inputs already merged cannot determine two different canonical repairs. Alongside the outcomes retained by multidimensional evaluation, diagnosis must identify the institutional relation that enables or obstructs them.

Positive refinement makes this requirement executable. The source supplies the failure kind before repair is issued. Retaining that input lets the installed rule recover the corresponding repair and prove, within the candidate repair type of Theorem 5.10, that a repair is effective if and only if it equals that selected repair. Theorem 5.11 supplies actual installed witnesses for both sides of the source kernel. We thus turn the diagnostic requirement concerning conversion factors into a precise question of identifiability: which observation loses a distinction needed for action, and which source information suffices to restore it to the execution program?

This also imposes a concrete requirement on institutional records. A distinction to be preserved should come with an account of how it affects disposition, and the affected party should be able to use it to question why a repair applies to them. Capability evaluation, failure diagnosis, and authority to act each perform their own task and connect through a common source.

### 10.3 The constitution of money and the location of responsibility's termination

Desan understands money as an institutional practice that continually organizes common resources. How contributions acquire tokens, who accepts those tokens, and how money is created and renewed all allocate costs, benefits, and authority [@Desan2013, pp.1–3, 28–29, 36–37; @Desan2014, pp.6–8]. The force of payment must therefore be understood through the relations that constitute it. Who accepts A's funds and who fulfils A's request for service are the concrete points at which this institutional force takes effect in daily life.

Mehrling further argues that final settlement is relative to a monetary hierarchy: a means of payment at one level may be a promise still to be honoured by the level above. Consolidation removes offsetting entries from the aggregate balance sheet, while issuers, holders, and their positions in the hierarchy remain relevant to monetary operations [@Mehrling2013, §§I–IV]. We follow this question of position through each responsibility. Who gains purchasing power through acceptance? Which transaction leg is closed by performance? Who continues to bear the same debt after a handoff across roots? The proof of common clearing leg by leg, and external responsibility within a locally empty ledger, give these questions checkable conditions of completion.

Responsibility also has a temporal structure of its own. Exhaustion of the budget for strict renewal payments, termination of a local procedure, and final settlement of the debt occur at different positions in the constructed history. An institution must therefore identify the work it declares complete and keep inherited responsibilities traceable. Proposition 7.8 extends this requirement to every same-source sequential target satisfying the conservative conditions: if no new row enters initially and no row budget increases, the exhausted source ledger's first whole-ledger successor has no row with a positive progress budget. Legal recognition has already made a residual expressible and given it a bearer and an answer. Restoring a responsibility's capacity for strict progress requires a source for that capacity.

These results carry the constitutional question of money to the clearing authority itself. When an acceptance or settlement arrangement determines how participants can continue, the authority providing it must also account for its authorization, responsibilities, and avenues for revision. The 1943 International Clearing Union proposal brought excessive credit and debit balances within adjustment arrangements and provided procedures for member withdrawal and reconsideration of rules [@Keynes1943, §§II.6(7),(9),(16),(18)]. Section 8 proposes principles of common adjustment and renewal of clearing authority on this basis. Performance by each leg, inheritance of old responsibilities, and genuine exit make these organizational choices answerable to the consequences participants actually bear.

### 10.4 From the structure of rules to complete execution and revision

Hohfeld distinguishes the power to alter legal relations from the right to demand another party's performance [@Hohfeld1913]. This relational analysis helps distinguish A's power to end employment, the service provider's obligations, and the standing A retains after departure. We further trace the source and successor of each change in a relation. When a job or office changes, particular authorizations, bearers, and responsibilities already incurred retain their respective positions.

Crawford and Ostrom's institutional grammar already incorporates execution into rule analysis. A sanction must be supported by another rule or norm; monitors must have corresponding tasks and authority; and rules must be formed in an arena that can establish them and arrange their enforcement. The authors also emphasize that grammar and a theory of action must jointly explain institutional operations [@CrawfordOstrom1995, pp.583–586]. We construct complete execution along these lines. The submission, adopted response, writeback, and actual successor must be bound together; refusal must preserve the bearer object; revision must carry the exact failure of the same responsibility row. The general root law imposes these constraints on every complete installed execution in its stated domain, and the nonempty construction places usable dispositions at one and the same constitutional point.

Proof-carrying execution supplies a technical dialogue for this checking. Necula has code carry a proof that it satisfies the receiver's safety policy. Catala organizes legal computation through rules and exceptions and proves preservation properties for a central compilation step [@Necula1997, pp.106–109; @MerigouxChataingProtzenko2021, §4.5]. We require authority to execute to carry institutional consequences with it. A program authorized to write supplies a complete responsibility update; a submission that is not accepted retains its bearer object. The checking obligation thus extends to how affected parties can continue.

AGM's study of theory change includes the derogation and amendment of norms from its opening discussion, and characterizes acceptable forms of change through partial meet contraction and a representation theorem [@AGM1985, §§1–2]. Pursuing this question of rule change, we take responsibilities already incurred as objects that must remain traceable. Theorem 7.4 carries the same old responsibility on which failure arose into the first write under the new law. Authorization has been replaced, while the inherited row remains live; only a subsequent act of performance starting from that exact target takes the row into a terminal archive. Rule change and the fulfilment of an obligation thus have their respective evidence.

Complete disposition and continuing revision can consequently hold together. Existing rules constrain each exercise of power, exact failure enables rules to change, and old responsibilities retain bearers through writes and successors. All-depth regeneration and cofinal law revision preserve these relations through what follows. As an institution continues to generate new occurrences, it must still answer to those it has already affected and for the commitments it has made.

### 10.5 The force of universal theorems: joint realisation and what cannot substitute for it

These dialogues converge on one question: how can an institution account together for who acts, who is affected, who remains responsible, and what supports the next continuation? Each tradition illuminates an important part of the problem. We connect these requirements through a common source, complete disposition, and an actual successor, making their relations mathematically checkable.

The generation theorem first establishes joint realisation. Subjects, powers, services, clearing, and theory adoption each have a source and belong to one nonempty institutional foundation. The universal root-law result then constrains every complete installed program in its stated domain: every execution must receive a complete disposition, and every write must arise through action or revision. For any prescribed foundation and recursive parameters, a separate existence construction supplies actual witnesses at the same constitutional point. Exhaustiveness constrains power; nonemptiness enables the institution to operate.

Diagnostic impossibility changes what information can be used for. Proposition 5.3 excludes every correct repair-selection function based only on capacity within the two-operation candidate repair language. Theorem 5.10 allows any output universe and any encoding: as long as the encoding factors through the coarse observation that merges source distinctions, it cannot recover exact repair. More elaborate computation cannot by itself recover a distinction already lost from its input. Source refinement gives a positive answer. Retaining the failure kind from the source distinguishes the objects and lets the installed rule choose the uniquely effective repair.

Regeneration takes joint realisation to every depth. The result both generates an object at each depth and proves six joint guarantees for every object of that type. The guarantees share the current payment, and the visit actually reached by one step is exactly the next step's entry. The complete-payment theorem further allows an arbitrary payment cycle of the defined type, an arbitrary position within it, and an arbitrary lawful payment there: the complete contract and an occurrence outside the old authority image come from that same payment step. Strict progress compares every pair of depths and holds exactly when the depths are strictly ordered. Beyond every finite cutoff, the cofinal theorem supplies one and the same later step with both actual law revision and payment-supported birth.

Preserving responsibility and opening the future can therefore occur together. Refusal retains the bearer; law revision transports old obligations; clearing ends a specified responsibility through actual performance. New services and exits acquire their own occurrence identities in the successor. The results retain their respective source families and proofs, while proved relations within a common occurrence, lawful transport, and actual successors assemble them. Together they establish an institutional completeness that can be examined item by item: how is the present disposed of, and what supports continuation?

## 11 Complete disposition, another beginning

A's exit brings institutional judgment back from a number to a set of relations. The three zeros fail at payment incidence, route incidence, and non-capture, respectively; the two ones separate feasible exit from complete support across the two installed domains of life. Counting can be entirely correct while diagnosis still has to trace the source. Preserving this distinction tells a repair program what it must change.

The positive construction supplies the other half of the answer. Activities generate continuing bearers, the root law constrains every complete execution, and nonempty constitutional points give these rules an actual place to work. An institution can refuse a submission while preserving the bearer's continuation through the node's payment. It can also change the rules and carry old responsibilities into the new arrangement until their own performance settles them. Legal recognition, local termination, and restoration of the capacity to advance each perform their respective work; actual execution determines where responsibilities go.

The stronger universal conclusions extend through what follows. At every depth, one payment jointly supplies six regeneration guarantees. For every lawful payment in any cycle of the defined cycle type, the complete contract enters that payment's actual target, and a new occurrence is generated there beyond the entire old authority image. Current exit capacity may remain unchanged while the realised history grows strictly. Beyond any finite stage, one and the same later step also jointly produces law revision and new birth supported by payment.

“Canonical” names a mathematical object generated from explicit sources and rules. Its social force lies in actually constructing institutional requirements that can hold together and identifying the information and operations that cannot substitute for them. A person's life continues after a relation ends. An institution that has completed its disposition must still supply the conditions for another actual beginning.

## References

[GaoProcess] Gao, Jian. *The State Is Not the History, the Source Is: Identity, Responsibility, and Minimal Revision in Processes*. Version 2, 2026. [doi:10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175).

[GaoLedger] Gao, Jian. *Book-Balancing Magic Has Nowhere to Hide: Source-Native Accounting and Actual Continuation*. Version 1, 2026. [doi:10.5281/zenodo.23437454](https://doi.org/10.5281/zenodo.23437454).

[Sen1979] Sen, Amartya. “[Equality of What?](https://ophi.org.uk/sites/default/files/Sen-1979_Equality-of-What.pdf)” The Tanner Lecture on Human Values, delivered at Stanford University, 22 May 1979, pp. 197–220.

[Desan2013] Desan, Christine. *[Creation Stories: Myths About the Origins of Money](https://dash.harvard.edu/bitstreams/7312037c-f89a-6bd4-e053-0100007fdf3b/download)*. Harvard Public Law Working Paper No. 13-20, revised 30 July 2013.

[Necula1997] Necula, George C. “Proof-Carrying Code.” *Proceedings of the 24th ACM SIGPLAN-SIGACT Symposium on Principles of Programming Languages*, 1997, pp. 106–119. [doi:10.1145/263699.263712](https://doi.org/10.1145/263699.263712).

[Keynes1943] Great Britain, Treasury. *[Proposals for an International Clearing Union](https://fraser.stlouisfed.org/title/federal-reserve-bulletin-62/june-1943-21058/fulltext)*. Cmd. 6437, April 1943. Reprinted in the *Federal Reserve Bulletin*, June 1943.

[Hirschman1970] Hirschman, Albert O. *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Harvard University Press, 1970.

[Pettit1997] Pettit, Philip. “[Republicanism: A Propositional Summary](https://liberalarts.tamu.edu/pols/wp-content/uploads/sites/20/2021/04/Pettit-Republicanism.pdf).” In *Republicanism: A Theory of Freedom and Government*. Clarendon Press, 1997.

[Anderson2015] Anderson, Elizabeth. “[Liberty, Equality, and Private Government](https://tannerlectures.utah.edu/_resources/documents/a-to-z/a/Anderson%20manuscript.pdf).” *The Tanner Lectures in Human Values*, delivered at Princeton University, 4–5 March 2015.

[Widerquist2013] Widerquist, Karl. *Independence, Propertylessness, and Basic Income: A Theory of Freedom as the Power to Say No*. Palgrave Macmillan, 2013. [doi:10.1057/9781137313096](https://doi.org/10.1057/9781137313096).

[Robeyns2017] Robeyns, Ingrid. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Open Book Publishers, 2017. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[Hohfeld1913] Hohfeld, Wesley Newcomb. “Some Fundamental Legal Conceptions as Applied in Judicial Reasoning.” *The Yale Law Journal* 23(1), 1913, pp. 16–59. [doi:10.2307/785533](https://doi.org/10.2307/785533).

[CrawfordOstrom1995] Crawford, Sue E. S., and Elinor Ostrom. “A Grammar of Institutions.” *American Political Science Review* 89(3), 1995, pp. 582–600. [doi:10.2307/2082975](https://doi.org/10.2307/2082975).

[Desan2014] Desan, Christine. *Making Money: Coin, Currency, and the Coming of Capitalism*. Oxford University Press, 2014. [doi:10.1093/acprof:oso/9780198709572.001.0001](https://doi.org/10.1093/acprof:oso/9780198709572.001.0001).

[Mehrling2013] Mehrling, Perry. “The Inherent Hierarchy of Money.” In Lance Taylor, Armon Rezai, and Thomas Michl (eds.), *Social Fairness and Economics: Economic Essays in the Spirit of Duncan Foley*. Routledge, 2013, pp. 394–404.

[AGM1985] Alchourrón, Carlos E., Peter Gärdenfors, and David Makinson. “On the Logic of Theory Change: Partial Meet Contraction and Revision Functions.” *The Journal of Symbolic Logic* 50(2), 1985, pp. 510–530. [doi:10.2307/2274239](https://doi.org/10.2307/2274239).

[MerigouxChataingProtzenko2021] Merigoux, Denis, Nicolas Chataing, and Jonathan Protzenko. “Catala: A Programming Language for the Law.” *Proceedings of the ACM on Programming Languages* 5(ICFP), Article 77, 2021, pp. 1–29. [doi:10.1145/3473582](https://doi.org/10.1145/3473582).
