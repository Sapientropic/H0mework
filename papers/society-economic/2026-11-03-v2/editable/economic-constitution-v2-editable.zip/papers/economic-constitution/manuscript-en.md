# An Economic Constitution of Possibility

## Producing Real Freedom, Settling Contributions, and Renewing Authority

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

What kind of life an income can buy depends on whether services exist, whether routes of access are open, and whether people can refuse the controls that providers attach to them. Taking the results on real exit, the settlement of responsibilities, and continuing renewal in *The Canonical Society Theorem*, together with its normative argument, as its starting point, this paper extends constitutional scrutiny to all public and private control that affects other people's feasible futures. It develops four institutional entitlements, each requiring separate justification: basic participation rests on human needs and equal standing; contribution claims rest on undertakings accepted in advance; the use of scarce resources is subject to actual budgets and public allocation rules; and governance powers rest on continuing authorization. Beneficiaries, service providers, and those responsible for budgets may be different people. Basic participation therefore requires no prior contribution, while provision must still be delivered through real resources. Eight principles connect capability evaluation, innovation finance, public production, and revocable governance: identical capability readouts may require different repairs; two rounds of exploration under uncertainty can each pay their costs while preserving an old debt; cumulative receipts for one contribution cannot regenerate through transfer; reusing a method can save labor while preserving every previously legal action; and public responsibilities can continue while an existing term of office ends on schedule. Within the given menu and evaluation scope, policy comparison covers every permitted adaptive response: when an acceptable candidate exists, it returns a deployable choice that is no worse across the full responsibility profile; otherwise, it retains the reasons for rejecting each candidate. The actual work of search and verification is charged item by item. The paper thus develops the economic constitution through institutional relationships that can be checked: who pays, who receives a share, who can leave, and who may decide the next rules. Debates in the capability approach, constitutional economics, and polycentric governance are carried forward through these concrete relationships.

**Keywords:** real freedom; economic constitution; basic participation; contribution settlement; public production; autonomous time; revocable power

## 1 How People Can Continue

After leaving a job, can a person still find a place to live, obtain medical care, care for relatives, and learn another trade? When a community replaces its managers, who maintains the equipment, who delivers unfinished services, and do earlier commitments still count? When a new technology saves labor, who gains time, and who instead must spend more time on call, caring for others, and cleaning up?

These questions share an object: **the paths along which people can actually continue.** Money, equipment, knowledge, and organizations can expand those paths or become instruments for closing them. An economic constitution specifies the conditions under which these paths are produced and entered, how their costs are assigned, and who may change the rules. Wealth must therefore pass a concrete test: for a particular person, in a particular relationship and at a particular time, which futures does it make attainable, usable, open to exit, and possible to continue?

*The Canonical Society Theorem* has already established a formal foundation for this question and, in its §8, set out the normative direction of an economic constitution: real exit must connect to actual services; responsibilities already fulfilled must be distinguished from those still open; and institutional renewal must carry the past forward while allowing new participation and changes to the rules. This paper continues that argument. It organizes its distinctions among basic standing, returns on contributions, settlement responsibilities, and the renewal of powers into four institutional entitlements requiring separate justification. It then develops them into a full argument about economic institutions through models of innovation, public production, public functions, and planning. [@Gao2026Society, §§6.6, 8–9]

The four entitlements answer different questions. Basic participation concerns a person's grounds for having the conditions of life and entry into society. Contribution claims concern which costs already borne should be repaid, and by whom. Scarce-resource requests concern whether resources are available to meet a particular use, and the rules under which competing requests receive shares. Governance powers concern who may determine the conditions of other people's actions. They can support one another, but cannot turn into one another automatically: having provided funding does not automatically confer permanent jurisdiction; holding a debt claim does not automatically authorize closing off every part of the debtor's life; and receiving basic services does not imply unlimited use of scarce resources.

The meaning of “payment” throughout this paper needs to be clear from the outset. A service is paid when its supporting resources, actual performance, and updates to responsibility can be matched to one another. This may involve monetary settlement, but also the delivery of labor, materials, or services. **Beneficiaries, providers, and those responsible for budgets may be different people.** A person may, for example, receive basic care without first making a labor contribution. A common budget pays the provider for the resources that care requires, and the providing institution is responsible for delivery. Basic entitlement is detached from the person's own income, while institutional arrangements bear the real costs. Later checks of “actual payment” ask precisely whether that undertaking has been fulfilled.

The formal results in this paper perform three kinds of work in sequence. Counterexamples identify what an apparently adequate indicator leaves out. Constructions show that requirements often regarded as conflicting can hold together. Preservation theorems show that the relationship continues to hold after further action. The key to reading them is to ask which people, resources, responsibilities, and authorizations are preserved together. Each section first explains an institutional difficulty, then states the result and its reasoning; complete conditions and proof locations are provided in the appendices.

**Guide to the Paper: Eight Principles and Their Formal Supports**

| Constitutional principle | Core institutional requirement | Formal support and proof location |
| --- | --- | --- |
| I · Complete paths of action (§2) | Check the conditions of exit, combinations of life conditions, and effective repair | Results 1–2; Appendices A.1–A.3 |
| II · Basic participation (§3) | Participation precedes contribution, and provision continues after a role ends | Appendices A.4 and B.4 |
| III · Contribution and control (§4) | Pay for exploration, bound cumulative claims for the same contribution, and authorize control separately | Results 3–4; Appendices B.1–B.3 |
| IV · Results and settlement (§5) | Open results to use, provide budgets for scarce resources, and settle each party's obligations separately | Result 5; Appendix A.5 |
| V · Time dividends (§6) | Preserve existing capabilities, calculate net balances, and determine who receives the surplus | Result 6; Appendix B.4 |
| VI · Public powers (§7) | Prepare successors, preserve responsibilities, end terms of office, and pay for planning work | Result 7; Appendices C.1–C.4 |
| VII · Future members (§8) | Preserve responsibilities outside the accounts and the conditions of action for those who come later | Appendix A.4; normative development in §8 |
| VIII · Continuing renewal (§9) | Carry earlier commitments forward, and support continued participation and rule changes through new performance | Result 8; Appendices A.6–A.7 |

These principles follow an economic process. They first ask what constitutes freedom, then who produces and pays for those conditions, then who receives the results and savings, and finally how providers and rules can be replaced.

## 2 The Unit of Wealth: Complete Paths of Action

### 2.1 From Resources to Practicable Lives

Sen's question “equality of what?” changed the object of economic evaluation. The same commodities do not give everyone the same life: bodily conditions, social relations, and the environment affect people's ability to turn resources into action. Robeyns further develops an account of conversion factors, structural constraints, and dynamic interdependence; she also explicitly discusses how policies can change conversion conditions. Production and institutions have always been part of the capability approach's concerns. [@Sen1980; @Robeyns2017, pp. 46–47, 65–66, 81–86] This paper advances a more specific question: **how much of the information needed for action does a capability readout actually retain?**

Suppose a person is preparing to leave a job. Cash can buy housing only if a home is available, the person has a right of entry, the home can be reached, and its use does not depend on continued obedience to the employer. To examine these relationships, the exit model connects “an act through which a person continues” to “a service actually delivered.” Let \(c\) denote the continuing action and \(j\) the slot of a delivered service. A qualifying exit connection requires:
\[
E(c,j)=
R(c)\land\neg I(c)\land\neg H(c)
\land P(c)\land T(c,j).
\tag{1}
\]
Here \(R\) means that the action takes place outside the role being exited; \(I\) means idle action; \(H\) means continued control by that role; \(P\) means that there is a witness to actual payment and performance; and \(T\) connects this action to this service. All five conditions must hold for the same action–service relationship. Someone else's room, a payment from an earlier period, or an unfulfilled promise cannot supply the missing connection.

The model's exit capacity \(K\) is the maximum number of pairs that can be formed simultaneously along these qualifying connections. It counts exit actions that can connect to services, rather than account balances or the total volume of services an organization claims to provide.

**Result 1 (Exit must connect to services).** For this finite exit structure, real exit exists if and only if the maximum matching capacity \(K>0\). One concrete instance contains three requests, two served slots, and one real path of exit. Service congestion can therefore coexist with positive exit capacity, and the existence of services does not guarantee a path of exit for every request. [@Gao2026Society, Theorem 5.1] (see also Appendix A.1 below)

This result takes the statement of a right to leave through to actual delivery. It leaves a further question: is positive capacity enough to establish that a life is complete?

### 2.2 Why a Positive Number Is Not Enough

Begin with two registered domains: rights retention, the relation in which a holder retains their rights, and health, the relation in which health services are received. Each domain requires its own actual service and beneficiary. These requirements must be met in both domains for the “complete combination” at issue here. Two institutional arrangements share the same exit action, together with the payment and path supporting that action, and both have an exit capacity of one. They differ in that Arrangement A actually delivers the services required in both domains, whereas Arrangement B completes only the service in the rights-retention domain. Evaluating one person's complete life additionally requires identifying each domain's beneficiary with that person. The comparison thus moves from the number of paths to combinations of services and to whom those combinations belong.

| Comparison | Arrangement A | Arrangement B |
| --- | --- | --- |
| Exit action and the payment supporting it | The same | The same |
| Exit capacity \(K\) | \(1\) | \(1\) |
| Complete service combination across the two registered domains | Practicable | Not practicable |
| Can \(K\) alone identify the difference? | No | No |

**Result 2 (The same capability readout cannot determine complete combinations or effective repair).** The two arrangements above have the same positive capacity but give different answers about the complete combination. No function reading only \(K\) can therefore decide correctly in both cases. Further, even when reachability readouts for all established domains are retained, two instances—“control capture” and a “broken path”—can yield the same readout while each has a different, uniquely effective repair. No rule that makes decisions solely through this shared readout can choose the correct repair in both cases. Restoring the cause that generated the failure recovers the distinction. [@Gao2026Society, Proposition 5.2, Theorem 5.10] (see also Appendices A.2–A.3 below)

The difficulty in the proof is information loss. A decision rule that compresses two situations into the same input must give them the same output; if the correct repairs differ, it must be wrong at least once. Aggregating these identical readouts into a total score still cannot recover the causes that were removed. A housing shortage calls for more available housing; housing that already exists but whose access is withheld by a controller calls for changes in admission and power relations. This example helps explain why the same “unreachability” can require different interventions; the model above supplies the specific counterexamples.

This gives the paper's contribution to the capability approach a precise place. Sen and Robeyns require serious attention to people's actual opportunities and conversion conditions. The results here identify which information cannot be compressed away when that evaluation becomes institutional action. If institutions publish only capability indicators while deleting who made a particular refusal, which part of a path broke, or which resource remains undelivered, those responsible for governance may know that people are unfree without knowing how to change their situation.

**Principle 1: Wealth should be evaluated in terms of complete paths of action that are practicable and can be repaired.** Institutions must record not only “whether it exists,” but also “why it exists, why it does not, and who can change it.” Causes that can be explained make capability evaluation a basis for action.

### 2.3 Whose Power Does an Economic Constitution Constrain?

Buchanan's constitutional political economy distinguishes constitutional choices that determine rights and rules from exchange and collective action within established rules. He also asks directly why people who did not participate in the initial contract should be bound by it, and evaluates existing rules in terms of a current and continuously negotiated contract. The status quo is the starting point for change, not thereby an object of moral endorsement. [@Buchanan1975, pp. 46–47, 92–101] The disagreement thus takes a more specific form: does an arrangement's acceptability in current renegotiation suffice to complete its evaluation? This paper additionally requires that everyone have basic participation and paths of exit that can actually be followed. Even when bargaining produces an acceptable agreement, the dependencies of life and conditions of exit on which the agreement rests must still be examined. Basic participation and actual exit thus become institutional conditions that the agreement itself must also satisfy.

In the German ordoliberal tradition, Böhm directly treats private economic power as a problem; Böhm, Eucken, and Großmann-Doerth argue that an integrated legal and economic order should organize competition, rather than allowing private power to determine market rules. [@Bohm1928; @BohmEtAl1936] That critique is close to this paper's argument. The difference concerns how constitutional scrutiny is completed: competition and legal rights must also face the test of complete paths of action. If leaving a job means losing necessary care, the nominal presence of several employers does not, by itself, establish effective exit. Nor does the existence of a private party's valid debt claim, by itself, justify every form of control exercised in its name.

The paper therefore extends scrutiny to **powers that continually determine other people's feasible futures**. Public levies and administrative interventions require legitimate authorization; private admission rules, debt enforcement, and control over the means of production must likewise justify their boundaries. Claims to payment arising from past contributions should be settled according to the commitments under which they arose. Any control they assert over today's services, those who come later, and the next rules must separately establish its task, duration, and authorization by those affected. Section 4 gives the bounds on receipts for contributions; §7 gives a structure in which responsibilities can continue while terms of office end. The “constitution” in the title consists in establishing these boundaries before the powers arising from transactions and organizations can expand on their own.

## 3 Participation Requires No Prior Contribution

### 3.1 A Person's Standing and Eligibility for a Role

**Principle 2: Basic living conditions and social participation must not be conditional on prior contribution.** People need nutrition, health, care, learning, social relationships, and accessible spaces before they can develop their capacities to contribute. Reserving these conditions as rewards for those who have already contributed asks people to accomplish in advance what those conditions are meant to help them accomplish. This circular requirement first excludes children, people who are ill, caregivers, and those who have not yet gained access to opportunities. It also turns the loss of work into grounds for losing the conditions of life.

Basic participation is also not conditional on the ability to give back to the community in the future. Even someone who cannot produce measurable output at any point in their life still needs care, social relationships, and an autonomous life, and still bears the consequences of institutional decisions. Excluding these needs from common provision would give those who evaluate contributions the power to withdraw the conditions of other people's lives. This paper grounds basic entitlement in needs and equal standing: contributions can give rise to additional returns, while a person's basic standing does not depend on others' assessments of their usefulness.

Equal basic standing does not require everyone to receive the same quantity of every good. Some people need more care; others need accessible routes. Different provision according to need can serve the same entitlement to participation. A person's entry into society and eligibility for a particular professional position belong to different levels. Medical qualifications, permission to operate equipment, and positions in particular projects may have task requirements and time limits. The end of a role should not cancel the person's basic standing along with it.

The earlier paper already distinguishes basic standing from contribution rewards and tests exit through actual continuation outside a role. [@Gao2026Society, §6.6] This paper draws from that distinction a responsibility for provision: when a community recognizes a basic entitlement, it should also identify the party obliged to provide the service, the resource budget, and a path of remedy if delivery fails. A right cannot remain attached to the beneficiary while responsibility for provision is left to no one.

### 3.2 Who Pays for Basic Participation?

Basic care, for example, requires at least four connected steps: the person who needs care acquires an entitlement; a providing institution commits to a service; a common budget secures personnel, materials, and facilities; and the actual provider receives remuneration and completes delivery. The person's lack of income from contributions does not invalidate the first two steps. A budget shortfall is a gap that the system of provision must address openly, rather than reinterpret as the person's unworthiness to receive care.

Basic income, basic services, and a voluntary job guarantee change different parts of this relationship. Van Parijs argues for an unconditional income from the standpoint of those with the least real freedom. His analysis of employment rents asks on what grounds the holders of scarce good jobs may monopolize advantages jointly produced by social conditions. Unconditionality thus concerns resource shares and bargaining positions; it cannot be judged solely by recipients' willingness to work. [@VanParijs1991, pp. 124–130] This paper agrees that the ability to leave a job requires resources under the person's own control. At the same time, cash purchasing power depends on whether housing, care, and routes of access actually exist.

Coote places this question of provision at the center. Basic services require clear responsibilities for provision, funding, standards, and guarantees of access; her proposal accommodates local participation and multiple forms of provision. She also identifies a real fiscal disagreement: universally paying everyone an income near subsistence level may crowd out the budgets that public services require. She therefore favors basic services combined with guaranteed income support. [@Coote2021, pp. 35, 43–44] The disagreement concerns the allocation of the common budget: under given resource conditions, how much is committed to common provision, how much is retained as personally disposable income, and how that combination changes the actual choices of those in the weakest positions.

Tcherneva's job guarantee answers a further question: how can people willing to do paid work obtain work suited to their circumstances? She designs it as a voluntary employment option, publicly funded and locally organized, while explicitly stating that it does not replace existing protections and non-wage support. [@Tcherneva2018, pp. 5–8] Guaranteed employment can therefore strengthen people's bargaining power to refuse poor private-sector jobs, but cannot require everyone to take a guaranteed job in exchange for basic living conditions. The right to choose a job and the right to leave it should enter the design together.

| Institutional tool | What it changes directly | What this paper requires it to answer further |
| --- | --- | --- |
| Unconditional income | Resources under the person's control and the material conditions for refusing work | Can cash buy the necessary provision, and can providers use scarcity to close access again? |
| Basic services | The production of necessary services, access to them, and their continuous provision | Who bears the budget, and how can services be chosen, challenged, and replaced? |
| Voluntary job guarantee | Opportunities for paid participation and the conditions of labor bargaining | How are basic living conditions sustained after a person refuses or leaves a position? |
| Returns on contributions | Remuneration for recognized labor, exploration, and risk | How are the amount, duration, and responsibilities of returns established, and do they carry control requiring separate authorization? |

These tools should share a common test: whether life can continue after exit. Lehner's randomized survey of unemployed people in Austria shows that respondents' preferences for income guarantees and job guarantees vary with the conditions of the proposals. [@Lehner2026] Policy comparisons must therefore state whether support is unconditional, what participation is required, and what arrangements apply after refusal, so that those affected can express choices about concrete proposals. Records of preferences show what people are willing to accept; service records show what they actually obtain. Fiscal mixes must be compared in terms of the needs of the same people, the available resources, and the same time window.

### 3.3 Exit Must Extend into What Comes After

Treating departure from a job as a single moment overlooks the part most likely to fail. Once the paperwork for leaving is signed, how are housing or care entitlements formerly tied to the position converted? Who pays for the next period's service? What happens to debts already incurred and other people's claims? A complete path of exit should pass in sequence through the effective acceptance of exit, actual service outside the role, and continued performance in the next stage.

The four-stage structure in the earlier paper connects admission and standing, actual exit, service outside the role, and subsequent payment. Three payment links each identify the stage they actually support, while preserving external responsibilities already established. [@Gao2026Society, Theorem 5.5] (see also Appendix A.4 below) “Free exit” therefore neither requires every past relationship to be deleted nor allows a historical receipt to cover every subsequent period of life.

The public-production model further exhibits a concrete process. A participant exits, and another person also refuses the corresponding role. Even when a common audit is technically legal and affordable, the system does not automatically assign it to them. The person who exited subsequently produces outside the role, pays for subsistence and maintenance, and then personally chooses to contribute labor to re-enter. Section 6 develops the complete 25-step trace and its costs. Its crucial contribution here is that **refusing a common role and retaining the capacity to produce can hold together in the same continuing process.** Exit is thus both a right and a task that institutions must support through arrangements for provision.

## 4 Contribution claims can be settled; control must be renewed

### 4.1 Innovation needs rewards; how do those rewards acquire limits?

**Principle 3: Actual contributions should be rewarded under responsibilities accepted in advance; continuing control over the future requires separate authorization.** Both parts must hold together. Requiring knowledge to be open while leaving researchers, carers, and maintainers to bear its costs alone consumes the conditions needed to produce freedom. Recognizing those costs does not, in turn, authorize funders to determine later participants’ access indefinitely.

Knight distinguishes measurable risk from uncertainty that cannot be adequately described by given probabilities, and argues that business judgment cannot be reduced to a known lottery. [@Knight1921, part III, chs. VII–IX] Contracts for exploration therefore need to specify who bears failure, waiting, and errors of judgment. Someone’s decision to incur an expense does not automatically place everyone else in debt. Entitlement to compensation arises from a common budget, a commission, insurance, or another allocation of responsibility that can be explained in advance. Such rules can pay for risk and opportunity costs; they cannot retrospectively rename every private loss as a debt owed by society.

Arrow makes the tension in innovation more specific. Once knowledge exists, widespread use can increase social benefits and provide inputs for further research. Producing that knowledge, however, requires finance and entails failure, while recovering costs through exclusion can restrict its use. He had already proposed separating rewards for innovation from the use of knowledge, and discussed the selection and organizational problems facing public or nonprofit finance. [@Arrow1962, pp. 614–619, 623–625] The question therefore becomes **how one arrangement can pay for innovation, keep its use open, and carry existing responsibilities forward**: what is promised when finance is raised, what is delivered when a discovery occurs, and on what grounds does the next exploration obtain resources?

Pistor’s account of legal coding takes the issue further. Priority, durability, and effects against third parties are powers that law confers on assets; they cannot be inferred from the physical existence of an input alone. [@Pistor2019] An investment can create an agreed claim to repayment. Setting access conditions for people who never joined that transaction, or maintaining exclusion over the next generation of production methods, involves further institutional arrangements. This paper examines these arrangements separately. Contribution claims ask “how much is owed, to whom, and how is it to be discharged?” Governance powers ask “on what grounds may someone determine another person’s actions now?”

![Figure 1: Four kinds of entitlement, each with its own grounds. Basic participation rests on need and equal standing; contribution claims on recognized commitments; scarce-resource requests are constrained by actual budgets and public allocation rules; governance powers rest on continuing authorization. Each has its own conditions of validity.](figures/01-four-claims-en.pdf)

### 4.2 How two rounds of exploration each pay their costs

One success does not establish that innovation can continue. A second round must obtain resources afresh, rather than use investment already spent in the first. It must produce its own evidence, rather than treat a result left over from the preceding round as the present discovery. It must also pay for the people currently participating, rather than use future success to conceal unmet subsistence needs today.

The model of two rounds of financing and trials separates the scenarios used to quote financing terms from the events that subsequently occur. A finite “quoted menu” lists the scenarios and declared weights used in the financing calculation. The reward for success is set to compensate for weighted failure losses, an outside option, and an additional reward. The actual input accepts events in the model’s request domain, including discoveries omitted from the menu. Financing arrangements, action rules, and methods of handling events are thus fixed in advance, while new discoveries can still enter those rules.

During execution, participants may act only on their own signals already obtained, and observation must consume actual resources. Gains from success and losses from failure are settled according to the events that occur. For each event, the rules check financing, evidence, and execution conditions, producing success or the corresponding failure. After success, release of the next round requires a further check that the current period’s subsistence and maintenance have actually been paid for every person. Quoted expectations, execution of the current trial, and release of the next trial each have their own grounds.

**Result 3 (Open events and two successive rounds of paid exploration).** Under this mechanism’s public-access interpretation, the rules are fixed before the unknown event, every actual event receives a complete disposition, and unmet conditions return their corresponding failures. A concrete instance of the same open-access mechanism succeeds in two successive rounds, with the second discovery outside both rounds’ quoted menus. Each round actually pays for material investment, evidence acquisition, and subsistence and maintenance for all participants. The second also preserves prior debt and begins afresh with its own financing and an empty evidence state. The next trial is released only after subsistence and maintenance have actually been paid in the current period. See Appendix B.2.

Figure 2 gives the accounts of this successful instance. Technology advances from state 0 to 1 and then to 2. Each round separately spends 3 units of material and 3 units of message resources consumed by production and observation, including an observation charge of 1 unit. One unit of prior debt persists across both rounds. The values 3 and 1 belong to this instance; material, message resources, and debt are accounted for in their respective units.

![Figure 2: Two innovations, each with its own financing, evidence acquisition, and payment. The numbers 0, 1, and 2 denote the technological states of this instance; 3 and 1 denote quantities in the respective resource or debt units. Investment, evidence acquisition, subsistence, and maintenance occur separately in each round, while prior debt is retained.](figures/02-paid-renewal-en.pdf)

Two failure comparisons sharpen the result. Remove the second financing and the trial fails as unfunded. Remove the second charged observation and the mechanism cannot obtain its own paid signal: even if technology in the material state has changed, that change cannot be passed off as evidence obtained. In another comparison, a feasible payment plan exists for the next period and the current trial is accepted, yet current subsistence and maintenance remain unpaid, so continuation is still not released. A feasible future promise cannot replace performance today.

This construction takes up the organizational problem Arrow identified: open access, innovation rewards, responsibility for failure, and renewed payment can each be implemented. It also raises the next question. Once exploration costs create claims with definite identities, how can those claims remain the same commitments through transfers and continued operation?

### 4.3 The same contribution cannot be reissued through transfer

Let \(Q\) be the quantity issued for a recognized contribution claim. When accepting the contribution, the institution should specify which inputs, risks, waiting, and rewards it covers, and who is obliged to perform. \(Q\) may include an agreed reward for risk; its fair amount must be determined through those reasons and procedures. The theorem below has a different task: to make the agreed quantity a limit that execution cannot quietly overrun.

The account gives each claim a distinct position, recording its issuance event, holder, balance, and payments already made. An actual payment satisfies:
\[
\begin{aligned}
&\text{principal remaining after payment}+\text{actual payment}\\
&\qquad=\text{principal remaining before payment}.
\end{aligned}
\tag{2}
\]
Changing the holder changes who receives payment. Waiting or entering a new institutional phase does not automatically create a new contribution either. Summing receipts from the same issuance over all subsequent account positions gives:
\[
\sum_{\text{all subsequent positions of the same issuance}}
\text{cumulative actual receipts}\ \le Q.
\tag{3}
\]

**Result 4 (A bound on cumulative receipts from the same issuance).** For any finite continuation of the account’s actual execution, and any finite sequence of public inputs appended after an actual prefix, cumulative receipts from the same issuance across all live and archived account positions at the endpoint do not exceed the issued quantity. The conclusion also applies to the complete execution that includes innovation events. Each issuance’s unique identity is generated from inventory position and occurrence order, and is preserved through transfers, phase changes, and the carrying forward of earlier accounts. Duplicating account positions therefore cannot evade the aggregate bound. See Appendix B.3.

The proof has two steps. Repeated use of (2) cancels intermediate balances, bounding cumulative payment by the initial principal. It then proves that the same issuance event is not counted more than once, turning a local balance bound into an aggregate bound covering every receiving position. The second step is crucial. If the same claim could be freely registered twice, two separately conserved accounts would still create duplicate claims to payment. The generating procedure rules out that route.

This boundary respects claims while limiting their expansion. Established obligations remain enforceable; transfers remain possible; new services, risks, and inputs can create new claims. When repayment is completed depends on performance arrangements and available resources. But the mere passage of time cannot turn one finite commitment into unbounded additional receipts.

Its implications for control follow from the distinction among the four entitlements. Compensation concerns what was contributed in the past; jurisdiction determines who can enter today, who can refuse, and what later participants must bear. Even while a debt remains unsettled, its enforcement should preserve basic participation and actual exit. Even after a contributor has been amply rewarded, that person may still be authorized to perform a new governance task, but the authorization must be established in relation to the current task. Repaying the past and authorizing the future each require their own grounds.

### 4.4 Open access still needs productive conditions

The model of capital relations calls an entry point for initiating a kind of action a “port.” It gives an exact condition for excluding access asymmetry: in every state and at every port, if the controller is admitted, then every participant is admitted. Within the model’s legal structure, this condition is necessary and sufficient for the absence of the corresponding private access advantages and relations of control and appropriation. The earlier paper already included this interface. [@Gao2026Society, Appendix C.5.1, Proposition C9] See Appendix B.1 of this paper.

The condition tests who can impose a gate. It also holds if every port is closed, although no service is thereby produced. Removing differential access is therefore only part of producing freedom; materials, methods, maintenance, and work that can be paid for are also needed. Result 3 exhibits actual payment and continued innovation under public access. Result 4 bounds cumulative receipts from the same issuance. The next section asks how everyday provision is organized once methods are open.

## 5 Shared outputs, scarce-resource requests, and clearing

### 5.1 Once methods are open, who sustains production?

**Principle 4: Shared results should remain available for continued use, scarce uses should have budgets for the occasion, and the established obligations of each party should be performed separately.** A second person can use a method without taking it away from the first. Two people seeking the same machine or the same period of care work may, however, come into conflict. Open knowledge addresses access to a method; resource allocation addresses its implementation.

Benkler explains why some production can rely on cooperation outside markets and firms. Participants choose tasks using dispersed information, while modularity and work of different granularities make it possible to combine contributions. Peer integration, platform technologies, social norms, and limited hierarchical or market arrangements provide quality control and assembly. [@Benkler2002, pp. 375–379, 435–436] This shows that exclusion through property rights and organizational command are not necessary forms for coordinating all knowledge production. This paper takes the organizational question into continuing provision: when maintainers leave or providers change, how do these mechanisms continue together with budgets and unfinished responsibilities? Methods can be copied; maintainers’ time cannot be copied at no cost.

The paper therefore frames the commons as two connected commitments. Reusable methods produced by paid exploration should be available under open terms that allow their transfer to other settings. Materials, energy, care, and maintenance needed for each actual production should be borne by identifiable budgets. Explorers can be rewarded through public research budgets, cooperative funding, or contribution claims agreed in advance. When a maintainer leaves, the method should be transferable to a successor, together with the budget and unfinished responsibilities. The institutional force of open results lies in others’ ability to carry on the work without being forced to buy the same paid exploration again or submit to the same permanent provider.

### 5.2 How performance on both sides enters the same ledger

Suppose A promises to deliver equipment and B promises agreed maintenance. Once A delivers the equipment, A’s obligation is fulfilled, but B’s maintenance obligation remains. B’s acknowledgment of the debt, or delivery of a credit instrument, can establish the claim; it cannot turn maintenance that has not occurred into maintenance already performed. Reliable clearing must identify the two responsibilities separately and discharge only the obligation that each delivery actually fulfills.

The clearing model generalizes this relationship to any finite set of paired obligations. Each is a “transaction leg.” A pairing relation identifies its counterparty, and applying the pairing twice returns to the initial leg. Different legs enter different responsibility positions. This separation prevents a single payment from cancelling the unpaid obligations of both sides, while allowing completion to be checked for all participants together.

**Result 5 (Common clearing and one-sided noncompletion).** In this finite paired structure, actual performance of every leg closes all responsibilities; performance on one side cannot close the other. Credit commitments also have their own requirements for later payment. Acknowledging a debt and fulfilling it remain distinct within the same responsibility history. [@Gao2026Society, Propositions 7.1–7.2] See Appendix A.5.

Keynes’s clearing union proposal also brings the creditor side within institutional adjustment. It charges both debit and credit balances above specified thresholds and requires discussion of adjustment by countries with large surpluses; surplus adjustment has its own conditions and decision rights. [@Keynes1943, II.7, II.9, III.7] This raises a further question for common clearing: what obligations should creditors bear by virtue of their institutional position? Public rules must establish those obligations. Once established, they too require evidence of their own performance and cannot be discharged by a debtor’s payment. The unit of account, liquidity, loss sharing, and adjustment powers determine how the macroeconomic institution operates. Clearing each obligation separately makes it possible to trace what each party has undertaken through to actual completion.

### 5.3 Linking claims to the resources they call upon

Generative money here means a design that connects transferable claims to specific commitments: each claim states where it arises, its unit, who must fulfill it, and which actual resources it calls upon. This first requires distinguishing three grounds. Claims to basic services arise from supply obligations already undertaken by the community; contribution rewards arise from recognized inputs and risks; additional scarce uses require corresponding budgets and allocation rules. Having no contribution income does not remove the grounds for the first kind of claim.

A budget specifies how much can be delivered; allocation rules specify how those resources become each person’s actual share. When two eligible requests compete for the same care period, the institution must also state which is fulfilled first and how the other waits or receives an alternative. The priority of necessary services, rules for additional uses, responsibility for delays, and routes of appeal should be public in advance. Deferred obligations remain outstanding, and the institution responsible for provision must address resource shortages. A valid contribution claim can demand the agreed repayment, but cannot by itself confer control over resources needed for another person’s basic life.

In this design, issuance registers a commitment and its quantity, transfer changes its holder, and actual delivery updates the balance and responsibility. Transfer cannot regenerate the allowance for the same issuance. The design links monetary use to verifiable performance relationships, while leaving conversion, liquidity, and interinstitutional settlement rules to be specified. Appendix D presents these interfaces as institutional designs. The established clearing and cumulative-bound results respectively constrain them through separation of responsibilities and prevention of duplicate claims to payment.

Common accounts thus serve two purposes: they enable people to receive promised services, and they allow those responsible to end an obligation once it has actually been fulfilled. The ability to settle is what keeps each act of cooperation from becoming a relationship that can never be left.

## 6 Who gains time from production savings?

### 6.1 How a technical saving becomes a real resource gain

**Principle 5: Production gains must first pass through complete cost accounting, then have their uses determined by those affected, and finally become conditions that people can actually use.** Moving from “a little less labor is used” to “a person has a little more freedom” requires at least three steps: a technical saving, calculation of the net resources available, and a distributive decision. If any step is omitted, the saving can disappear into new tasks, transferred costs, or continuing demands to remain on call.

The public production model addresses the first step. Its production units can establish new production units. The initial unit, called the “mother cell,” holds labor resources available for auditing and production operations. Labor has already been paid for an audit of a method. Later producers reuse that method while checking afresh whether current materials are sufficient. Comparing the runs with and without reuse requires checking the labor saved alongside other stocks, claims, technology, and subsequent actions. How the labor remainder becomes shorter working hours and autonomous time for people is then determined through the complete accounting and distribution discussed in §§6.2–6.3.

**Result 6 (Labor savings preserve every previously lawful action sequence).** In the self-replicating public production model, reuse of a paid method leaves the complete terminal state with exactly one additional unit of labor at the initial production unit. All other stocks across participants and goods, financial claims, technology, and the clock match between the two states. More strongly, every finite action sequence that is lawful step by step at the terminal state without the saving can be executed at the terminal state with the saving, and the complete state after execution still contains exactly that additional unit of labor. [@Gao2026Society, Appendix C.5.3, Lemma C12] See Appendix B.4 of this paper.

This preservation result explains the force of the saving. Spending one unit less, retaining one unit more at the endpoint, and still retaining one unit more after any previously lawful action sequence are three views of the same resource. They cannot be added into three gains. The proof first checks that adding labor does not invalidate the conditions for a single action and that execution is compatible with the increment; it then proceeds by induction over any finite sequence. The additional resource is therefore not obtained by cancelling existing commitments or reducing the range of feasible action.

Will the community immediately requisition the labor that has been saved? The same production model connects a person’s exit, another person’s refusal to take a role, production outside the role, and voluntary return in one 25-step trace. The upper panel below checks the labor remainder; the lower panel shows continued production after refusal of a common role, followed by return at the person’s own choice.

![Figure 3: How one labor dividend is retained. The three views above inspect expenditure, the complete terminal state, and subsequent action, tracking the same unit of labor. Below is a 25-step public production trace covering entry, exit, and return. The numbers 21, 22, and 24 are execution steps counted from zero; box 25 is the final state, and the dashed line omits step 23.](figures/03-time-dividend-en.pdf)

In this trace, the shared audit is lawful and affordable, yet actual assignment remains empty after exit and refusal. The person who exited subsequently produces outside the role, pays for subsistence and maintenance, and then pays labor to return. Accounting event by event and replaying the ledger separately check the same trace, recovering the same stocks and labor dividend, as well as the discharge of the new production units’ subsistence and maintenance responsibilities. See Appendix B.4.

This process connects the participation principle in §3 to the time dividend. Being able to perform a task does not mean having consented to be assigned it. For a resource gain to become autonomous time, the beneficiary must also have effective standing to refuse additional tasks.

### 6.2 From technical savings to net resources for distribution

The second step is complete accounting. Production that uses less labor may consume more electricity, require more equipment maintenance, or shift care and cleanup to households. This is the contradiction Fraser identifies: economic activity depends on the care that sustains life and social relations, yet the pressures of accumulation can undermine those conditions. [@Fraser2016] If necessary care is left outside the accounts, “higher productivity” may mean only that an organization has moved work elsewhere.

Net resources available for distribution should therefore take the form of a set of balances with units. Comparing two production arrangements requires accounting for subsistence, care, maintenance, unsuccessful exploration, ecological restoration, established debts, and necessary reserves. Labor hours, water, electricity, and equipment time are accounted for separately. Financial payments can change who bears these costs, but the same physical consumption cannot be deducted again in both the payment and resource accounts. An aggregate figure is warranted only when a common valuation and fixed prices have been explicitly adopted.

Complete accounting must still ask who has the power to move costs outside their own boundary. Carers, service users, and those affected by environmental consequences should be able to identify work and harm previously omitted. Otherwise, more detailed accounts may merely calculate boundaries set by the powerful more accurately. The principle requires preserving service floors and involving those who bear the costs in determining the net amount available.

### 6.3 From net resources to time a person can use

The third step is distribution. A labor saving can shorten working hours, improve services, discharge earlier obligations, restore ecosystems, or increase reserves. Determining who receives the benefits of technology requires first preserving basic provision already promised, and then having actual workers, service users, and others bearing costs discuss these uses. If shorter hours are chosen, schedules, replacement arrangements, and limits on being recalled at any time must be implemented. If services are expanded, the additional burdens, their bearers, and their remuneration must be specified.

Acemoglu and Restrepo show why technology’s effects on labor cannot be judged solely by the direction of productivity change. Automation transfers tasks to capital, producing a displacement effect; new tasks may bring labor back into production. [@AcemogluRestrepo2019] The distinction means that “more total output” does not itself determine workers’ incomes, bargaining power, or time. This paper accordingly separates technical relationships from distributive choices, then requires institutions to reconnect them: which tasks are retained, who performs them, and how savings are allocated must all remain open to discussion and change.

The study by Fan and colleagues provides concrete evidence about gains in time. Participating organizations first reorganized work and then reduced working time for six months while maintaining pay. The study covered 2,896 employees in 141 organizations, with 12 control organizations, and observed improvements in burnout, job satisfaction, and self-reported mental and physical health. Organizations participated voluntarily and assignment was nonrandom, so the findings must be understood in light of that design. [@FanEtAl2025] They point to an institutional possibility worth testing: reorganizing work and reducing hours can change people’s lives, while evaluation must also examine whether services continue, whether care burdens shift, and whether workers in different jobs share the gains.

Autonomous time ultimately needs conditions that make it usable. Someone who gains half a day but lacks care arrangements, transport, or accessible spaces, or must remain available for recall at any moment, has acquired only a blank space in the schedule. A dividend that actually enters life is time to rest, meet others, learn, and create—and to decide for oneself how to use it.

## 7 Services Can Continue as Providers Change

### 7.1 Building Handoffs into Public Functions

**Principle 6: Necessary functions should be capable of sustained performance, while providers and governance powers remain replaceable.** Society's need for water, care, and dispute resolution does not give any one organization a permanent entitlement to provide those services and determine all their rules. The difficult work lies in the handoff: someone must take over existing commitments, the resources needed for performance must be transferable, the new provider must receive valid authorization, and those leaving office must be able to finish their terms on time.

Ostrom already distinguished decisions about public service provision from the actual production of services. Small communities can purchase services from larger organizations and change contracts when dissatisfied; access, use, management, exclusion, and transfer can also belong to distinct rights, rather than having to form a single ownership bundle. Her analysis of rule levels further distinguishes the participants and powers involved in everyday operations, collective choice, and constitutional decisions. [@Ostrom2009, pp. 411–414, 419–422] This paper builds on those distinctions to ask how a replacement is completed within the full history of responsibilities.

Consider a change of care provider. Services still owed by the departing institution cannot disappear from the accounts when its contract expires. The incoming institution needs methods, staffing arrangements, and a budget before it can undertake delivery; the authorizing party must confirm the new scope and term. If the conditions for taking over are not yet met, the service must remain explicitly recorded as incomplete and enter a process of remedy. Preserving a responsibility does not mean that provision has been completed; ending the old term does not cancel the service obligation. A handoff must address both.

Authorization itself also needs an explicit procedure. When service users, those doing the work, and budget bearers disagree, rules published in advance should state who may propose candidates, who makes the decision, how disagreements are handled, and who reviews it. Those affected can demand reasons, raise objections, and propose alternatives. Taking on a role requires the person's own consent and the possibility of exit, while common budgets are allocated through a public procedure that can reach decisions and be reviewed. Each authorization must specify the task, resources, term, and conditions for removal or replacement, and explain how basic services, unsettled responsibilities, and appeals will be carried forward.

The public function model retains three actual states in this process: a refusal that has not been repaired, a repair that has occurred, and service that passes review after repair. Every change of state corresponds to the current request, responsibility, and payment. The model can therefore check the stage a service has reached, instead of treating a change of institutional name as a successful handoff.

**Result 7 (Full continuity of responsibility; the original term cannot revive itself).** From any actual running state of this model, throughout any finite subsequent interval on the same actual path, the complete catalogue of functions, accepted comparison baselines, responsibility identities, prior histories, all actual operations, and financial receipts are preserved. Each step distinguishes unrepaired refusal, actual repair, and reviewed service. While the original responsibility remains unsettled, no actual continuation from the actual successor state of the corresponding response can restore the authority of the terminated term. See Appendices C.1–C.2. The earlier paper established a complete termination check and an interface for residual responses; the continuing-operation result used here further constrains actual continuations after the term ends. [@Gao2026Society, Appendix C.5.2, Proposition C10]

This result separates two forms of continuity that are often bundled together: what remains owed must still be resolved, but the old authority cannot automatically renew itself on that basis. A departing officeholder who needs to continue working can receive fresh authorization; the new task, term, and affected parties then enter the judgment anew. The need for the service is met through continued provision, and the provider's standing rests on renewable authorization.

### 7.2 What Replacing a Provider Actually Costs

Replacement requires alternatives that can be carried out. A cheaper provider listed in a catalogue cannot yet be fairly compared with the current arrangement if the person has no power to choose it, if it has not paid the costs of its services, or if the transition leaves existing commitments unfulfilled. Conversely, an incumbent cannot lump every inconvenience into “switching costs” while deleting the actual gains from an alternative.

Fix a bearer, a comparison window, and a valuation. Let \(b\) denote the current actual arrangement, and \(a\) an alternative whose required signatures and consent are under the person's control. Candidates come from the finite menu actually generated by the model. Before entering the comparison, both paths must be lawful, deliver their respective promised services item by item, and reach the same time window. Lower payment therefore cannot arise merely from doing less of what was owed.

Select from the complete financial account one source of charges to examine—for example, a payment claim attached to a controlled service—and denote its net financial burden by \(F_s\). All remaining financial consequences are accounted for separately and in full. Replacement also changes service responsibilities, feasible capabilities, time use, and dynamic production shortfalls. List the signed differences in these other consequences item by item: positive differences make up \(B(a;b)\), and actual differential gains make up \(G(a;b)\). Both use the same valuation, and the selected \(F_s\) is not counted again among the other financial items.

When the actual comparison finds no strict improvement in the menu, every candidate that passes these checks satisfies:
\[
\boxed{F_s(b)-F_s(a)\le B(a;b)-G(a;b).}
\tag{4}
\]
See Appendix C.3.

In other words, as long as no alternative offers a strict improvement, the additional net financial burden of continuing with the incumbent cannot exceed the complete net cost of replacing it: positive differential costs minus actual differential gains. “Complete” here includes other financial burdens, services, capabilities, time, and new production responsibilities. It cannot mean counting only transaction fees, or discussing costs after removing the gains.

The comparison itself explains how the bound works. If replacement saves more of the selected burden than the combined net cost of all its other consequences, it constitutes a strict improvement. If no such improvement exists, equation (4) is an accounting boundary that must hold. The model's total decision also retains two other cases: the current service has not been paid for, or a strict improvement has been found that the person can execute and for which both paths have actually paid. It does not declare the status quo stable in advance; actual computation distinguishes stability, improvement, and nonperformance.

This constraint holds for the specified menu and valuation. To make replacement more feasible, institutions must also admit new candidates, lower unnecessary barriers to handoff, and let those affected challenge omitted costs and gains. Otherwise, accurate computation may only compare an artificially restricted menu accurately.

### 7.3 Public Planning Also Takes Work

Who constructs these candidates, gathers information, and completes the comparison? Treating planning as a free, omniscient judge hides the hardest organizational work outside the model.

Hayek located the problem of coordination in dispersed and continually changing local knowledge: actors possess information about particular times and places, and prices allow them to adjust resource use without knowing every cause of change. [@Hayek1945, §§III–VI] Public planning must therefore explain how local judgments enter the candidates, who undertakes discovery and trial and error, and how those affected can object. Compressed information suited to everyday coordination may also be insufficient to adjudicate responsibility or select a repair; the results in §2 require a separate demonstration of informational sufficiency for those latter tasks.

Computational advances can perform part of this work. Dütting and colleagues use deep learning to search for auction mechanisms, optimizing objectives and constraining incentives to deviate within a specified environment. [@DuttingEtAl2019] Such research shows that searching over rules can become a concrete computational task, while making its objectives, information, and conditions of verification more explicit. Which objectives are selected, which reports are accepted, and who may participate remain constitutive parts of the mechanism.

The planning model used here first fixes the basis of comparison. For the given source menu and evaluation horizons, subject to the corresponding bounds on remaining steps, reference and candidate policies are compared from the same initial point before payment. Each candidate's own payment, current actions, future recovery, and financing consequences all enter its evaluation. The opponent may adapt its responses to the actual queries, but the two candidates face the same opponent: an identical query cannot receive a different answer merely to favor one policy.

The model expands these responses into finite joint tables, covering queries from the common starting point and the states reached after each candidate's payment. Any permitted adaptive opponent can be restricted to one such table while preserving each candidate's full consequences. A comparison relation therefore holds on every joint table if and only if it holds for every permitted adaptive opponent. This gives the finite computation complete coverage of the comparison domain.

Within this domain, a returned policy is deployable and is no worse than the reference policy across the full responsibility profile under every permitted response; no other policy in the domain strictly dominates it across that profile. If a strict improvement is available in the domain, the selected policy realizes a strict improvement as well. Strict improvement here requires being no worse under every permitted response, with a strict difference in real benefits under at least one permitted response. If no acceptable candidate exists, the system retains a specific failed condition for each intent. The actual execution window of the selected policy is exactly its own full window in the comparison, including the prefix it has already paid for. See Appendix C.4.

Producing this comparison result must itself be paid for. Payment of the candidate construction fee first generates the actual catalogue. Payment of the comparison and selection fee, measured against that catalogue, then releases the search. Forecasting, recovery from failure, and result caching are likewise charged item by item. Every actual work event occupies a distinct accounting position on a successful payment receipt; the total work allowance used across the stages plus the remaining work allowance equals the original work budget. Resuming after a pause must also carry forward the process's own progress and responsibilities.

Planning's output can then be evaluated: how much work it consumed, which executable candidates it produced, which judgments failed, and how many resources recovery used. A search already performed can be reused; an invoice for future work cannot turn work that has not occurred into completed work. Public planning thus enters the same relations of responsibility as other production, subject to challenge, replacement, and continuing authorization.

### 7.4 Verifying Public Commitments while Preserving Private Autonomy

Handoffs and comparisons need evidence, but demands for evidence cannot expand without limit. Verifying the completion of a public service does not automatically confer a right to disclose all of its beneficiaries' health, family, and personal records.

Nissenbaum understands privacy through the appropriateness of information and the norms governing its flow within a context: who transmits which information to whom, within what relationship, and under what conditions. She also allows existing norms to be criticized in light of contextual purposes and social, political, and moral values, rather than treating the status quo as its own justification. [@Nissenbaum2004, pp. 138–146, 151–154] This framework lets auditing pose more precise questions: what information is needed to establish performance, which recipients may obtain it, how long it may be kept, and whether it may be put to another use.

This paper accordingly proposes bounded auditing. Each verification specifies the claim, time window, necessary evidence, purpose of use, and access permissions. Its conclusion distinguishes a verified claim, a claim refuted by evidence, and a claim for which evidence is insufficient. After an auditor is replaced, the same claim can be independently checked using lawful evidence. Independent acceptance of the same public production trace through event-by-event checks and ledger replay provides a concrete computational basis; more general interfaces for privacy and auditor replacement appear in Appendix D.

Auditing makes public commitments open to verification. It must also state its own authority and allow those being audited to challenge demands for information beyond what the claim requires. Public accountability and private autonomy can then each acquire their proper boundaries within the same institution.

## 8 Later Arrivals Cannot Be Left out of the Accounts

### 8.1 Responsibilities Can Remain after Financial Settlement

**Principle 7: Settlement among present participants must neither erase external responsibilities nor exhaust the conditions for later members to participate.** An institution can pay all its wages and equipment bills while leaving pollution, gaps in care, or facilities that cannot be maintained. Reducing the claims recorded in an account to zero and restoring the affected world to a sustainable condition are two distinct facts.

The earlier paper incorporates this distinction into the structure of responsibility: even when the set of open responsibilities in a local account is empty, external responsibilities can remain and persist through subsequent operation. [@Gao2026Society, Theorem 7.7] (see also Appendix A.4 below) This structure prevents “this account is settled” from automatically meaning “all consequences have disappeared.” Responsibilities concerning ecosystems, other regions, and future members thereby retain a place where they can continue to be traced.

Rockström and colleagues' research on safe and just Earth system boundaries considers both system stability and the avoidance of significant harm. It also makes clear that avoiding significant harm does not exhaust the requirements of minimum access, distributive fairness, and procedural justice. [@RockstromEtAl2023] Economic institutions must therefore answer two questions at once: how much more physical processes can bear, and who should use the remaining space. Monetary payment cannot answer the first question, and a single physical threshold cannot settle the second.

This paper accordingly argues that resource consumption, ecological maintenance, and repair should remain ongoing obligations measured in their respective units. Future members cannot yet take part in all of today's transactions; their conditions of participation cannot depend entirely on whether incumbents choose to restrain themselves. Decisions about irreversible appropriation and long-term risks should preserve traceable bearers of responsibility, necessary reserves, and room for later arrivals to change the rules.

For later arrivals who cannot yet be present, incumbents bear a limited duty of stewardship. Current users receive powers with a defined scope and term, while assuming obligations to maintain, repair, retain information, and hold necessary reserves. These decisions are open to challenge by those currently affected; later arrivals then participate anew in decisions about use and rules. Irreversible decisions, in particular, require prior comparison of which conditions for subsequent action would be permanently closed off. Trustees cannot invoke a future opportunity to vote again in place of a present judgment about losses that cannot be recovered.

### 8.2 Earlier Contributions Cannot Bind Everyone Who Follows

Taking this question to its furthest reach reveals a structure already present in everyday economic life. Those who first arrive on a tract of land, establish a network, or develop a technology do bear the costs of exploration and construction. Whether those costs suffice to determine the conditions of entry for everyone who follows still requires further argument. Increasing the scale does not close the distance between returns to contribution and permanent gatekeeping.

Outer space provides a vivid example. The *Outer Space Treaty* prohibits national appropriation through claims of sovereignty, use, occupation, or other means; requires authorization and continuing supervision of nongovernmental activities; preserves jurisdiction and ownership over launched objects; and requires due regard for the corresponding interests of other states. [@OuterSpace1967, arts. II, VI, VIII, IX] These distinctions show that investing in facilities, undertaking missions, owning objects, and possessing an area of space are separate matters of right.

An economic constitution should bring the same distinctions back to Earth. Reproducible methods, congested routes, exhaustible resources, and continuously operating facilities need different rules of use and maintenance. Explorers should receive the returns that have been recognized, and later arrivals should have standing to enter, object, and participate in changing the rules. Here, the stars begin with the unfolding of human possibilities: care, art, research, friendship, and forms of life not yet named by existing occupations all need institutions that leave room for them.

## 9 Every Renewal Must Establish Its Standing Anew

### 9.1 How Continuing Performance Accommodates New Participation

**Principle 8: Institutional renewal should carry forward existing commitments and support continued participation and changes of rules through new actual performance.** An institution cannot erase what it owes by announcing a new period, nor can it require later arrivals to obey its first arrangement forever. Renewal must make inheritance and change possible together.

Consider continuing care. Services already delivered today should leave a record of performance, and commitments still unfulfilled must be carried forward. Tomorrow's care needs tomorrow's own resources and delivery. Continuing to provide services to the same person also requires new actual performance to occur. Institutional continuation must preserve both: the past is not erased, and the next stage of life receives new support.

The earlier paper's main theorem expresses this continuation as an ongoing run: each stage contains responsibilities being borne, payments that actually occur, and the next stage generated by them. A cycle specifies how stages connect, and continuation depth records how many continuations have occurred. A payment has more than a quantity. It must identify which occurrence of performance it records and which responsibility it fulfills, while carrying the conditions of benefit and unsettled obligations forward. [@Gao2026Society, Theorems 1.2–1.3]

**Result 8 (Complete inheritance of commitments, with new performance producing strict continuation).** For every cycle specified by the canonical society model, at every permitted observation setting and every continuation depth, the continuation process preserves each legal input payment at that point and follows that payment's actual target into the next lifecycle. The complete exit conditions, all installed channels, external responsibilities, and the payment structure of the continuation stage itself are preserved together. The concrete construction further generates a strictly growing history of completed performance and keeps subsequent amendments and compatible new acts reachable. See Appendices A.6–A.7.

Strict growth is carried by the occurrence identity of each performance. Index occurrences from zero in the order in which they take place. Let \(H_n\) be the history of the first \(n\) paid occurrences, \(A_n\) the set of service–exit objects it generates, and \(\gamma_n\) the occurrence record of the new payment. Then
\[
H_{n+1}=H_n\mathbin{+\!\!+}[\gamma_n],
\qquad A_n\subsetneq A_{n+1}.
\tag{5}
\]
Old objects enter the next stage through a structure-preserving map; the new object arises from a new actual payment, at an occurrence position distinct from all the old objects. The construction thus establishes a correspondence between a strict increase in stage depth and this strict continuation.

Equation (5) records performance actually completed at different times: yesterday's receipt and today's service have their own occurrence positions. Instantaneous exit capacity \(K\) counts actions that can be connected to services simultaneously at the present time. In the example of continuing care for the same person, it can remain one throughout, while every period still requires new actual service. Strict growth here establishes that continuing fulfillment keeps producing new paid occurrences. The kinds of life simultaneously available in any period, and changes in welfare, must be assessed separately using the actual provision in that period.

An open future has a second requirement: can people propose different rules, and can later arrivals enter? The concrete renewal construction guarantees that, from any depth, the run can continue to a later stage where an actual amendment occurs and new acts executable in the continuation stage are accommodated. The two occur together, rather than merely listing “change is possible in the future” in a catalogue. [@Gao2026Society, Theorems 1.1 and 6.4] This paper's normative requirements further determine who should participate in that amendment: those affected acquire standing to object and authorize, new members obtain the conditions of basic participation, and existing commitments continue to be carried through the change. Actual performance keeps the institution from idling; continuing amendment keeps an arrangement at any one moment from closing off everything that follows.

### 9.2 Ending an Institution without Ending a Person's Life

Different endings require their own conditions. Completing a task means delivering the work agreed upon; settling a contribution means fulfilling the corresponding claim; expiry of a term ends that period of jurisdiction; leaving a role means ceasing to hold that position. None automatically ends a person's basic participation, and none can stand in for the others.

Progress in performance must also be traced to its own source. The earlier paper examines the model's nonnegative progress allowances, registered by responsibility row. If all current rows have zero allowance, every row at the continuation entry is inherited from an existing row, every row in the first writeback in turn comes from an entry row, and neither step increases the corresponding allowance, then every such entry and first writeback still has zero allowance in every row. [@Gao2026Society, Proposition 7.8] (see also Appendix A.7 below) Under these inheritance conditions, changing stages does not restore a positive responsibility progress allowance. New provision or admission that is to change this constraint must have its own source and actual update. Whether sufficient physical resources are available is checked against the corresponding resource budget.

Allowing institutions to end is therefore compatible with requiring life to continue. Old organizations can be dissolved, old authority can lapse, and contribution claims can be settled; obligations to provide basic services should be explicitly carried forward through these changes. What is inherited is the commitment that must be fulfilled. What is renewed is the organization and the rules under which it is fulfilled.

### 9.3 From Principles to Checkable Implementation

These principles can enter trials in specific service domains. In care or public maintenance, for example, first identify the services to be guaranteed, their actual providers, and the common budget, then record each delivery and its responsibility. Feasible alternative providers, the reuse of methods, and changes in time use can then be compared. The sequence of the trial should follow the argument of the paper: first establish that services have actually been received, then check the savings, and finally decide how to distribute them and expand the scope.

| Institutional relationship to be checked | Actual objects that can be verified |
| --- | --- |
| Life can continue after exit | Services outside the role, the institution responsible for provision, and the next period's budget |
| Contributions receive defined returns | Recognized inputs, the quantity issued, risk agreements, and cumulative receipts |
| Shared results remain available for continued use | Methods, materials, maintenance budgets, and the conditions under which successors can enter |
| Savings enter a complete net account | Inputs and outputs with their units, care and ecological burdens, and existing service floors |
| Providers can be replaced | Executable candidates, resources for handoff, unsettled responsibilities, and new authorization |
| Expiry of a term does not erase responsibility | The term of authority and the separately preserved history of performance |
| Renewal accommodates later arrivals | New provision, new participation, and actual changes of rules |
| Auditing is bounded and replaceable | The claim being verified, the scope of evidence, the time window, and independent review |

Failures should also be located along these relationships. A shortage of services may require more provision, a broken route may require a change in access, and capture by control may require replacing authority. The same low readout should not always trigger the same subsidy or administrative command. Empirical evaluation can thereby test whether people's lives improve and identify which institutional connection remains unfulfilled.

## 10 Conclusion: Let Results Endure and Futures Remain Open

Return to the three questions at the beginning. For a person to leave a job and continue living, basic standing must have provision and a budget independent of that position. For a community to change its managers and continue to perform its commitments, responsibilities must survive the handoff, while unsettled responsibilities must not automatically extend the term of office. For a technology that saves labor to increase freedom, its complete net surplus must be established, those bearing costs and receiving services must take part in deciding its use, and time must actually return to the people who will use it.

Together, these three processes constitute the economic constitution developed here. Basic participation protects a person's standing to acquire the conditions for action. Contribution claims recognize undertakings already accepted and allow commitments to be settled. Budgets and allocation rules for scarce resources make the share allocated to each use deliverable. Continuing authorization makes powers that affect others' futures open to challenge, termination, and replacement. Each form of standing can support cooperation, and each has reasons it must supply.

*The Canonical Society Theorem* establishes the formal foundations of actual exit, clearing, and continuing renewal. Following its normative direction, this paper connects those results to innovation finance, public production, and revocable governance. Capability readouts must preserve the causes needed for repair; open results need arrangements that pay for exploration and maintenance; paid contributions need settlement boundaries that transfer cannot erase; and necessary services must be able to span changes of providers and terms of office. These institutional requirements enable people to produce conditions together, fulfill commitments, and decide the rules anew.

Freedom has to be produced. Institutions that produce freedom must also remain answerable to the continuing judgment of free people.

## Sources and Proofs

This paper builds on the formal results and the normative discussion in §8 of Jian Gao's *The Canonical Society Theorem*, developing them into eight principles for an economic constitution. [@Gao2026Society] Results from the earlier paper are identified by theorem or section in the main text. The models of innovation, contribution settlement, public production, public functions, and planning are used according to their respective proof sources; distinct models are not spliced into a single shared run.

Appendix A explains the social and clearing results; B covers capital, innovation, and public production; C covers public functions and independent planning; and D specifies the design interfaces for generative money and bounded auditing. Appendix E binds the proven results to a fixed public proof snapshot and provides a locator and verification entry for each item. The main text retains the institutional meaning and necessary quantifiers, while the appendices and source register carry the precise declarations, versions, and records of their use.

## References

[AcemogluRestrepo2019] Acemoglu, Daron, and Pascual Restrepo. 2019. “Automation and New Tasks: How Technology Displaces and Reinstates Labor.” *Journal of Economic Perspectives* 33(2): 3–30. [doi:10.1257/jep.33.2.3](https://doi.org/10.1257/jep.33.2.3).

[Arrow1962] Arrow, Kenneth J. 1962. “[Economic Welfare and the Allocation of Resources for Invention](https://www.nber.org/system/files/chapters/c2144/c2144.pdf).” In *The Rate and Direction of Inventive Activity: Economic and Social Factors*, 609–626. Princeton University Press for NBER.

[Benkler2002] Benkler, Yochai. 2002. “[Coase's Penguin, or, Linux and the Nature of the Firm](https://yalelawjournal.org/article/coases-penguin-or-linux-and-the-nature-of-the-firm).” *Yale Law Journal* 112: 369–446.

[Bohm1928] Böhm, Franz. 2008 [1928]. “[Das Problem der privaten Macht. Ein Beitrag zur Monopolfrage](https://api.pageplace.de/preview/DT0400.9783161514760_A27134534/preview-9783161514760_A27134534.pdf#page=59).” In *Grundtexte zur Freiburger Tradition der Ordnungsökonomik*, edited by Nils Goldschmidt and Michael Wohlgemuth, 49–67. Tübingen: Mohr Siebeck.

[BohmEtAl1936] Böhm, Franz, Walter Eucken, and Hans Großmann-Doerth. 2008 [1936]. “[Unsere Aufgabe](https://api.pageplace.de/preview/DT0400.9783161514760_A27134534/preview-9783161514760_A27134534.pdf#page=37).” In *Grundtexte zur Freiburger Tradition der Ordnungsökonomik*, edited by Nils Goldschmidt and Michael Wohlgemuth, 27–37. Tübingen: Mohr Siebeck.

[Buchanan1975] Buchanan, James M. 2000 [1975]. *[The Limits of Liberty: Between Anarchy and Leviathan](https://oll-resources.s3.us-east-2.amazonaws.com/oll3/store/titles/1827/0102-07_LFeBk.pdf)*. The Collected Works of James M. Buchanan, vol. 7. Indianapolis: Liberty Fund.

[Coote2021] Coote, Anna. 2021. “Universal Basic Services and Sustainable Consumption.” *Sustainability: Science, Practice and Policy* 17(1): 32–46. [doi:10.1080/15487733.2020.1843854](https://doi.org/10.1080/15487733.2020.1843854).

[DuttingEtAl2019] Dütting, Paul, Zhe Feng, Harikrishna Narasimhan, David C. Parkes, and Sai Srivatsa Ravindranath. 2019. “[Optimal Auctions through Deep Learning](https://proceedings.mlr.press/v97/duetting19a.html).” *Proceedings of Machine Learning Research* 97: 1706–1715.

[FanEtAl2025] Fan, Wen, Juliet B. Schor, Orla Kelly, and Guolin Gu. 2025. “Work Time Reduction via a 4-Day Workweek Finds Improvements in Workers' Well-Being.” *Nature Human Behaviour* 9: 2153–2168. [doi:10.1038/s41562-025-02259-6](https://doi.org/10.1038/s41562-025-02259-6).

[Fraser2016] Fraser, Nancy. 2016. “[Contradictions of Capital and Care](https://newleftreview.org/issues/ii100/articles/nancy-fraser-contradictions-of-capital-and-care).” *New Left Review* 100: 99–117.

[Gao2026Society] Gao, Jian. 2026. *The Canonical Society Theorem [典范社会总定理]*. Version v1. Preprint. Zenodo. [doi:10.5281/zenodo.23892126](https://doi.org/10.5281/zenodo.23892126).

[Hayek1945] Hayek, F. A. 1945. “[The Use of Knowledge in Society](https://www.econlib.org/library/Essays/hykKnw.html).” *American Economic Review* 35(4): 519–530.

[Keynes1943] United Kingdom. 1943. *[Proposals for an International Clearing Union](https://fraser.stlouisfed.org/title/federal-reserve-bulletin-62/june-1943-21058/fulltext)*. Cmd. 6437. London: HMSO. April.

[Knight1921] Knight, Frank H. 1921. *[Risk, Uncertainty, and Profit](https://www.econlib.org/library/Knight/knRUP.html?chapter_num=9)*. Boston and New York: Houghton Mifflin.

[Lehner2026] Lehner, Lukas. 2026. “[What Do Unemployed Workers Want: Guaranteed Jobs or Guaranteed Income](https://www.levyinstitute.org/publications/what-do-unemployed-workers-want/).” Working Paper No. 1125. Levy Economics Institute of Bard College. July 31.

[Nissenbaum2004] Nissenbaum, Helen. 2004. “[Privacy as Contextual Integrity](https://nissenbaum.tech.cornell.edu/papers/H.%20Nissenbaum%2C%20_Privacy%20as%20Contextual%20Integrity.pdf).” *Washington Law Review* 79: 119–158.

[Ostrom2009] Ostrom, Elinor. 2009. “[Beyond Markets and States: Polycentric Governance of Complex Economic Systems](https://www.nobelprize.org/uploads/2018/06/ostrom_lecture.pdf).” Nobel Prize Lecture, December 8.

[OuterSpace1967] *[Treaty on Principles Governing the Activities of States in the Exploration and Use of Outer Space, including the Moon and Other Celestial Bodies](https://www.nasa.gov/history/SP-4225/documentation/cooperation/treaty.htm)*. 1967. *United Nations Treaty Series* 610: 205, No. 8843.

[Pistor2019] Pistor, Katharina. 2019. “Coding Capital for the Globe.” *Stanford Social Innovation Review*, September 4. Authorized excerpt from *The Code of Capital*. [doi:10.48558/GYV7-NE54](https://doi.org/10.48558/GYV7-NE54).

[Robeyns2017] Robeyns, Ingrid. 2017. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Cambridge: Open Book Publishers. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[RockstromEtAl2023] Rockström, Johan, Joyeeta Gupta, Dahe Qin, et al. 2023. “Safe and Just Earth System Boundaries.” *Nature* 619: 102–111. [doi:10.1038/s41586-023-06083-8](https://doi.org/10.1038/s41586-023-06083-8).

[Sen1980] Sen, Amartya. 1980. “[Equality of What?](https://tannerlectures.org/documents/sen80/)” In *The Tanner Lectures on Human Values*, vol. 1, edited by Sterling M. McMurrin, 197–220. Cambridge University Press. Lecture delivered on May 22, 1979.

[Tcherneva2018] Tcherneva, Pavlina R. 2018. *[The Job Guarantee: Design, Jobs, and Implementation](https://www.levyinstitute.org/wp-content/uploads/2024/02/wp_902.pdf)*. Working Paper No. 902. Levy Economics Institute of Bard College. April.

[VanParijs1991] Van Parijs, Philippe. 1991. “[Why Surfers Should Be Fed: The Liberal Case for an Unconditional Basic Income](https://research.dial.uclouvain.be/entities/publication/534c7134-40b6-4992-a63e-62348da4af63).” *Philosophy & Public Affairs* 20(2): 101–131.
