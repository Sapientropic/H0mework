#!/usr/bin/env python3
"""Editable bilingual figures for The Economic Constitution of Possibility.

Run with python3.
Shared fonts and colors are read-only dependencies. No manuscript text is changed.
SVG text stays editable; PDFs contain text and vector paths, never preview pixels.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from html import escape
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys
import unicodedata

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION
import svg_text
from svg_text import line
svg_text.OPS.update("∅")
W, PRINT_WIDTH, MIN_SIZE = 1440, 464, 24
LANG = "zh"
CHECK_ONLY = False
PARTS, BOXES, SHAPES, MANIFEST = [], [], [], []
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

def L(zh, en):
    return zh if LANG == "zh" else en

@lru_cache(maxsize=None)
def metrics(cls, weight):
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont
    font_path = svg_text._FONT_FILES[cls]
    if cls == "zh" and weight >= 600:
        suffix = "Bold" if weight >= 700 else "SemiBold"
        font_path = Path.home() / "Library/Fonts" / ("NotoSerifCJKsc-" + suffix + ".otf")
    font = TTFont(str(font_path))
    if "fvar" in font:
        font = instantiateVariableFont(font, {"wght": weight}, inplace=True)
    return font.getBestCmap(), font["hmtx"].metrics, font["head"].unitsPerEm

def width(text, size, weight):
    total = 0
    for piece, tag in svg_text._pieces(str(text)):
        actual_size = svg_text._script(size, MIN_SIZE) if tag in ("sub", "sup", "isub") else size
        actual_weight = 700 if tag == "b" else weight
        for ch in piece:
            cls = "en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i", "isub") and cls == "en":
                cls = "it"
            cmap, hmtx, upm = metrics(cls, actual_weight)
            glyph = cmap.get(ord(ch))
            assert glyph in hmtx, ("missing glyph", ch, cls, actual_weight)
            total += hmtx[glyph][0] * actual_size / upm
    return total

def start(height, title, description):
    PARTS.clear(); BOXES.clear(); SHAPES.clear()
    PARTS.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" viewBox="0 0 {W} {height}" role="img">')
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append(f'<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="{DEEP}"/></marker></defs>')
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height

def txt(x, y, text, size=28, color=INK, weight=400, anchor="start", max_width=None):
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, tw, max_width)
    x0 = x - {"start": 0, "middle": tw/2, "end": tw}[anchor]
    BOXES.append({"box": [x0, y-.90*size, x0+tw, y+.28*size],
                  "text": text, "font_px": size})
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))

def lines(x, y, labels, size=28, color=INK, weight=400, anchor="start", gap=39, max_width=None):
    for i, label in enumerate(labels):
        txt(x, y+i*gap, label, size, color, weight, anchor, max_width)

def path(d, bounds, color=HAIR, stroke=1.8, arrow=False, dashed=False):
    marker = ' marker-end="url(#arrow)"' if arrow else ""
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round"{marker}{dash}/>')
    SHAPES.append(bounds)

def segment(x1, y1, x2, y2, color=HAIR, stroke=1.8, arrow=False, dashed=False):
    path(f"M {x1} {y1} L {x2} {y2}",
         [min(x1,x2), min(y1,y2), max(x1,x2), max(y1,y2)],
         color, stroke, arrow, dashed)

def rect(x, y, w, h, stroke=HAIR, fill="white", sw=1.8):
    PARTS.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    SHAPES.append([x,y,x+w,y+h])

def circle(x, y, r, color=DEEP, fill="white", sw=2.4):
    PARTS.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="{sw}"/>')
    SHAPES.append([x-r,y-r,x+r,y+r])

def rule(y):
    segment(48,y,1392,y,HAIR,1.5)

def normalized(text):
    return "".join(unicodedata.normalize("NFKC", text).split())

def repair_pdf_text_mapping(pdf, expected):
    """Preserve source characters when Chrome chooses a same-glyph radical alias.

    Only aliases sharing the exact font glyph with a unique source character
    are changed. Vector glyphs and geometry are untouched.
    """
    import pymupdf
    cmap = metrics("zh", 400)[0]
    glyph_sources = {}
    for ch in set(expected):
        if 0x3400 <= ord(ch) <= 0x9fff and ord(ch) in cmap:
            glyph_sources.setdefault(cmap[ord(ch)], set()).add(ch)
    aliases = {}
    for cp, glyph in cmap.items():
        choices = glyph_sources.get(glyph, set())
        if 0x2e80 <= cp <= 0x2fff and len(choices) == 1:
            aliases[chr(cp)] = next(iter(choices))
    repairs = {}
    temporary = pdf.with_suffix(".unicode.pdf")
    with pymupdf.open(pdf) as doc:
        changed = False
        for xref in range(1, doc.xref_length()):
            if not doc.xref_is_stream(xref):
                continue
            stream = doc.xref_stream(xref)
            if b"begincmap" not in stream:
                continue
            def replace(match):
                original = chr(int(match[2], 16))
                replacement = aliases.get(original)
                if replacement is None:
                    return match[0]
                repairs[original] = replacement
                return match[1] + ("<%04X>" % ord(replacement)).encode()
            repaired = re.sub(rb"(<[0-9A-Fa-f]+>\s+)<([0-9A-Fa-f]{4})>", replace, stream)
            if repaired != stream:
                doc.update_stream(xref, repaired)
                changed = True
        if changed:
            doc.save(temporary, garbage=4, deflate=True)
    if repairs:
        temporary.replace(pdf)
    return repairs

def save(stem, height, semantics):
    for i, item in enumerate(BOXES):
        a=item["box"]
        assert a[0]>=16 and a[2]<=W-16 and a[1]>=8 and a[3]<=height-8, ("outside canvas",item)
        for other in BOXES[i+1:]:
            b=other["box"]
            assert not (a[0]<b[2] and b[0]<a[2] and a[1]<b[3] and b[1]<a[3]), ("text overlap",item["text"],other["text"])
    for s in SHAPES:
        assert min(s[:2])>=8 and s[2]<=W-8 and s[3]<=height-8, ("shape outside",s)
    name=stem+("-en" if LANG=="en" else "")
    entry={"stem":name,"language":LANG,"canvas_px":[W,height],"print_width_pt":PRINT_WIDTH,
           "minimum_text_px":MIN_SIZE,"glyph_coverage":"pass","text_geometry":"pass",
           "shape_bounds":"pass","semantics":semantics,"labels":list(BOXES)}
    if CHECK_ONLY:
        MANIFEST.append(entry)
        return
    svg=OUT/(name+".svg")
    svg.write_text("\n".join(PARTS+["</svg>"])+"\n",encoding="utf-8")
    preview=OUT/".review"
    preview.mkdir(exist_ok=True)
    page=preview/(name+".html")
    hp=height/W*PRINT_WIDTH
    page.write_text('<!doctype html><html><head><meta charset="utf-8"><style>'
        +f'@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}'
        +f'img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>'
        +f'<body><img src="{svg.as_uri()}"></body></html>')
    pdf=OUT/(name+".pdf")
    result=subprocess.run([CHROME,"--headless=new","--disable-gpu","--no-pdf-header-footer",
        "--no-first-run","--allow-file-access-from-files",
        f"--user-data-dir={preview/'chrome-profile'}",f"--print-to-pdf={pdf}",page.as_uri()],
        capture_output=True,text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:]+result.stderr[-2000:])
    import pymupdf
    expected="".join(piece for b in BOXES for piece,_ in svg_text._pieces(b["text"]))
    text_repairs=repair_pdf_text_mapping(pdf,expected)
    with pymupdf.open(pdf) as doc:
        assert len(doc)==1, ("page count",name,len(doc))
        p=doc[0]
        assert abs(p.rect.width-PRINT_WIDTH)<1 and abs(p.rect.height-hp)<1
        assert not p.get_images(full=True), ("raster image in vector PDF",name)
        pdf_text=p.get_text()
        assert "\ufffd" not in pdf_text, ("replacement character",name)
        expected="".join(piece for b in BOXES for piece,_ in svg_text._pieces(b["text"]))
        missing=Counter(normalized(expected))-Counter(normalized(pdf_text))
        assert not missing, ("text missing from PDF",name,dict(missing))
        span_count=0
        for block in p.get_text("dict")["blocks"]:
            for ln in block.get("lines",[]):
                for span in ln["spans"]:
                    span_count+=1
                    x0,y0,x1,y1=span["bbox"]
                    assert x0>=-1 and y0>=-1 and x1<=p.rect.width+1 and y1<=p.rect.height+1, ("PDF text outside",name,span)
                    assert span["size"]>=MIN_SIZE/W*PRINT_WIDTH*.95, ("PDF type below floor",name,span)
        assert span_count>0 and p.get_drawings(), ("empty PDF",name)
        fonts=sorted({font[3] for font in p.get_fonts(full=True)})
        p.get_pixmap(matrix=pymupdf.Matrix(W/p.rect.width,W/p.rect.width),alpha=False).save(preview/(name+".png"))
        entry["pdf_checks"]={"pages":1,"raster_images":0,"editable_text_spans":span_count,
                             "glyph_text_preserved":True,"all_text_in_page":True,"fonts":fonts,
                             "font_types":sorted({f[2] for f in p.get_fonts(full=True)}),
                             "source_character_mapping_repairs":text_repairs}
    entry["files"]={}
    for ext in ("svg","pdf"):
        f=OUT/(name+"."+ext)
        entry["files"][ext]={"path":f.name,"bytes":f.stat().st_size,
                             "sha256":hashlib.sha256(f.read_bytes()).hexdigest()}
    MANIFEST.append(entry)

def four_claims():
    h=start(700,L("四种资格，四种制度依据","Four claims, four institutional grounds"),
        L("四条独立的水平资格线。基础参与、贡献索偿、稀缺请求和治理权限各有来源，彼此不能自动升级；本图没有因果流程。",
          "Four independent entitlement rows. Basic standing, contribution claims, scarce-resource requests and governance powers have distinct grounds. No causal flow or automatic conversion is implied."))
    txt(48,54,L("资格","CLAIM"),25,SLATE,600)
    txt(430,54,L("成立依据与规则","GROUND AND RULE"),25,SLATE,600)
    txt(1286,54,L("边界","BOUNDARY"),25,SLATE,600,"middle")
    rule(78)
    rows=[
      ("基础参与","Basic participation","作为参与者的地位","Standing as a participant",
       "不以贡献为门槛","No contribution threshold","资格保留","standing"),
      ("贡献索偿","Contribution claims","约定发行与受领义务","Agreed issuance and payment",
       "依约定承诺结算","Settle the agreed obligation","索偿边界","settlement"),
      ("稀缺请求","Scarce-resource requests","实际预算与分配规则","Resources and allocation rules",
       "按公开规则配置当次资源","Allocate by the published rules","预算边界","budget"),
      ("治理权限","Governance powers","明确的公共授权","An explicit public authorization",
       "期限、挑战与撤换","Term, challenge and removal","授权窗口","term"),
    ]
    for i,row in enumerate(rows):
        zh,en,zg,eg,zr,er,zb,eb=row
        y=158+i*132
        txt(48,y,L(zh,en),34 if i!=2 or LANG=="zh" else 31,DEEP,600,max_width=350)
        txt(430,y,L(zg,eg),31,DEEP,600,max_width=700)
        txt(430,y+40,L(zr,er),28,INK,max_width=700)
        segment(430,y+66,1138,y+66,HAIR,1.5)
        cx,cy=1286,y-8
        if i==0:
            path(f"M {cx-44} {cy+13} C {cx-44} {cy-48} {cx+44} {cy-48} {cx+44} {cy+13}",
                 [cx-44,cy-48,cx+44,cy+13],DEEP,2.5)
        elif i==1:
            path(f"M {cx-42} {cy-28} L {cx-56} {cy-28} L {cx-56} {cy+21} L {cx-42} {cy+21} M {cx+42} {cy-28} L {cx+56} {cy-28} L {cx+56} {cy+21} L {cx+42} {cy+21}",
                 [cx-56,cy-28,cx+56,cy+21],DEEP,2.5)
            segment(cx-26,cy-4,cx+26,cy-4,DEEP,2.5)
        elif i==2:
            segment(cx-51,cy,cx+51,cy,DEEP,3)
            segment(cx-51,cy-20,cx-51,cy+20,DEEP,3)
            segment(cx+51,cy-20,cx+51,cy+20,DEEP,3)
        else:
            rect(cx-52,cy-29,104,52,DEEP,sw=2.4)
            segment(cx+34,cy-42,cx+58,cy-18,DEEP,2.8)
            segment(cx+34,cy-18,cx+58,cy-42,DEEP,2.8)
        txt(cx,y+50,L(zb,eb),24,SLATE,anchor="middle",max_width=190)
    txt(720,668,L("各项资格分别成立，不能自动升级","Distinct grounds; no automatic upgrade from one claim to another"),
        29,VERMILION,600,"middle",1330)
    save("01-four-claims",h,{"structure":"four independent horizontal entitlements",
        "no_causal_flow":True,"no_automatic_upgrade":True,
        "grounds":["basic standing","original issuance and acceptance","current real resources and public allocation rules","authorization with term, challenge and removal"]})

def paid_renewal():
    h=start(830,L("创新必须再付一次","Innovation has to pay again"),
        L("同一构造性见证中的真实创新源从0到1到2，两轮各付物量投资3和消息资源总消耗3，后者含观察收费1消息单位；全员生活和维护分别付。第二次发现不在两轮报价菜单。旧债1贯穿；不同单位不相加。本图各数值属于这一见证。",
          "One actual innovation source in a constructive witness moves from 0 to 1 to 2. Each round pays material investment 3 and total message resource consumption 3, including observation fee 1 message unit; everyone's living and maintenance are separately paid. The second discovery is absent from both quoted menus. The same old debt 1 persists. Units are distinct and are not summed. All displayed values belong to this witness."))
    for x,n,label in [(110,0,L("初始状态","Initial state")),(720,1,L("第一次发现","First discovery")),(1310,2,L("第二次发现","Second discovery"))]:
        col=VERMILION if n==2 else DEEP
        circle(x,120,40,col,sw=2.8)
        txt(x,135,str(n),48,col,600,"middle")
        txt(x,197,label,27,col,600,"middle",220)
    segment(161,120,665,120,DEEP,2.8,arrow=True)
    segment(771,120,1255,120,DEEP,2.8,arrow=True)
    txt(415,52,L("第一轮","Round 1"),30,DEEP,600,"middle")
    txt(1025,52,L("第二轮","Round 2"),30,DEEP,600,"middle")
    for x,round_no,round_zh in [(80,1,"第一"),(790,2,"第二")]:
        rect(x,240,570,260,HAIR,sw=1.5)
        txt(x+24,284,L(f"{round_zh}轮：实际付款",f"Round {round_no}: actual payment"),29,DEEP,600,max_width=522)
        txt(x+24,340,L("物量投资","Material investment"),28,max_width=310)
        txt(x+546,340,L("3 物量单位","3 physical units"),28,DEEP,600,"end",max_width=240)
        txt(x+24,395,L("消息资源总消耗","Message resource spent"),28,max_width=330)
        txt(x+546,395,L("3 消息单位","3 message units"),28,DEEP,600,"end",max_width=240)
        txt(x+24,438,L("含观察收费：1 消息单位","Observation fee included: 1 message unit"),24,SLATE,max_width=522)
        txt(x+24,482,L("全员生活、维护分别实付","For all: living and maintenance paid separately"),26,INK,max_width=522)
    txt(720,574,L("第二次发现不在任何一轮的报价菜单中","Discovery 2 appears in neither round's quoted menu"),
        30,VERMILION,600,"middle",1320)
    txt(48,654,L("同一旧债：1 债务单位，贯穿两轮","Same old debt: 1 debt unit, carried through both rounds"),27,DEEP)
    segment(110,692,1310,692,DEEP,2.2)
    for x in (110,720,1310):
        segment(x,679,x,705,DEEP,2.2)
        circle(x,692,5,DEEP,DEEP,1)
    txt(720,782,L("物量、消息资源与债务各有单位，数值不相加","Material, message and debt units are distinct; these numbers are not added"),
        26,SLATE,anchor="middle",max_width=1340)
    save("02-paid-renewal",h,{"evidence_kind":"constructive_witness","displayed_values_scope":"this_witness_only",
        "same_actual_source":[0,1,2],"rounds":2,"separate_payment_events":[1,2],
        "physical_investment_each_round":3,"message_resource_consumption_each_round":3,"observation_fee_included_message_units":1,
        "living_and_maintenance_separately_paid_for_all":True,
        "second_discovery_absent_from_both_quoted_menus":True,
        "same_old_debt_persists":1,"units_not_additive":True})

def time_dividend():
    h=start(910,L("同一劳动余量，三层读面","One labor remainder, three readings"),
        L("上部三层是同一公共生产中同一劳动1的等价读面：当次支出少1，完整末库存多1，任意既有合法序列后仍多同一1，不能累加。下部隔开显示同一公共生产的25步形式轨迹中的执行步骤21、22、24。初态为边界状态0，执行步骤从0到24，末态为边界状态25；步骤18退出后到达状态19，步骤19另一人拒绝后到达状态20；步骤21实际派工为空，步骤22退出者在角色外实际生产，步骤24实付重返后到达末态25。步骤编号不是状态编号；步骤21不是退出动作。自主时间的规范分配由正文论证。",
          "The upper readings describe the same one unit of labor: one less spent now, one more in complete terminal stock, and the same extra unit after any previously lawful action sequence. They are not additive. The separate lower panel shows execution steps 21, 22 and 24 in one verified 25-step public-production trace. Boundary state 0 is initial; steps run from 0 through 24 and finish at boundary state 25. Exit at step 18 leads to state 19; another actor refuses at step 19, leading to state 20. Actual assignment is empty at step 21, the exited actor produces outside the role at step 22, and paid re-entry at step 24 leads to final state 25. Step indices and boundary-state indices are distinct; step 21 is not the exit event. Distribution as autonomous time is argued in the text."))
    txt(48,54,L("A  同一劳动余量的三个读面","A  One labor remainder, three readings"),30,DEEP,600,max_width=850)
    txt(1392,54,L("复用方法相对于重复审计","method reuse vs. repeated audit"),25,SLATE,anchor="end",max_width=500)
    circle(175,280,78,VERMILION,sw=3)
    txt(175,311,"1",100,VERMILION,600,"middle")
    txt(175,408,L("同一单位劳动","one labor unit"),28,VERMILION,600,"middle",300)
    segment(280,280,330,280,HAIR,2)
    path("M 365 165 L 330 165 L 330 395 L 365 395",[330,165,365,395],HAIR,2)
    for y in (165,280,395):
        segment(330,y,396,y,HAIR,2)
    readouts=[
      (165,"当次劳动支出","Labor spent in this run","少 1","1 less"),
      (280,"完整末库存","Complete terminal stock","多劳动 1","1 extra labor unit"),
      (395,"任意既有合法序列后","After any previously lawful sequence","仍多同一劳动 1","the same extra unit remains"),
    ]
    for y,zh,en,zr,er in readouts:
        txt(426,y,L(zh,en),30 if LANG=="en" and y==395 else 32,DEEP,600,max_width=545)
        txt(1370,y,L(zr,er),31,VERMILION,600,"end",max_width=440)
    txt(720,474,L("三层读的是同一份收益，不累计","Three readings of one gain; they are not cumulative"),29,INK,600,"middle",1310)
    rule(520)
    txt(48,580,L("B  同一25步公共生产轨迹：退出后的生产与实付重返",
        "B  Production after exit and paid re-entry in the same 25-step trace"),30,DEEP,600,max_width=1330)
    txt(720,642,L("初始边界态0；执行步序从0起：18退出，19另一人拒绝；24完成后到达边界态25。",
        "Initial boundary state 0; zero-based steps: exit 18, another actor refuses 19; step 24 reaches boundary state 25."),
        25,SLATE,anchor="middle",max_width=1335)
    xs=(210,600,1030)
    state_x=1340
    segment(xs[0]+36,750,xs[1]-42,750,DEEP,2.5,arrow=True)
    segment(xs[1]+36,750,xs[2]-42,750,DEEP,2.3,arrow=True,dashed=True)
    segment(xs[2]+36,750,state_x-52,750,DEEP,2.5,arrow=True)
    txt(815,698,L("23 未展开","23 not shown"),24,SLATE,anchor="middle",max_width=220)
    for x,t in zip(xs,(21,22,24)):
        circle(x,750,32,DEEP,sw=2.3)
        txt(x,761,str(t),34,DEEP,600,"middle")
    rect(state_x-32,718,64,64,DEEP,sw=2.3)
    txt(state_x,761,"25",34,DEEP,600,"middle")
    txt(state_x,698,L("边界状态","boundary state"),24,SLATE,anchor="middle",max_width=220)
    labels=[
      (["已退出或拒绝","实际派工为空"],["Already exited / refused","Actual assignment is empty"]),
      (["退出者实际生产","角色外，实际付款"],["The exited actor produces","Outside the role; actually paid"]),
      (["实付重返","重新支付后进入"],["Paid re-entry","Entry after a new payment"]),
    ]
    for x,(zh,en) in zip(xs,labels):
        lines(x,830,L(zh,en),28,INK,600,"middle",gap=43,max_width=465)
    save("03-time-dividend",h,{"three_readings_of_one_gain":True,
        "current_labor_spending_difference":-1,"terminal_labor_stock_difference":1,
        "difference_after_every_old_legal_word":1,"not_additive":True,
        "normative_autonomous_time_not_automatically_delivered":True,
        "separate_trace_same_original_public_production":{
          "execution_step_count":25,"execution_step_indices":{"first":0,"last":24},
          "initial_boundary_state":0,"terminal_boundary_state":25,
          "boundary_state_after_step":"step index + 1","unexpanded_execution_steps":[23],
          "steps":{"18":{"action":"exit","resulting_boundary_state":19},
            "19":{"action":"another actor refuses","resulting_boundary_state":20},
            "21":{"action":"already exited/refused; actual assignment empty"},
            "22":{"action":"exited actor actually produces with actual payment outside the old role"},
            "24":{"action":"paid re-entry","resulting_boundary_state":25}}},
        "step21_is_not_the_exit_action":True,
        "execution_steps_and_boundary_states_use_distinct_shapes":True})

FIGURES=[("01-four-claims",four_claims),("02-paid-renewal",paid_renewal),("03-time-dividend",time_dividend)]

def main():
    global LANG,CHECK_ONLY
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only",choices=[x[0] for x in FIGURES])
    ap.add_argument("--language",choices=["zh","en","both"],default="both")
    ap.add_argument("--check-only",action="store_true")
    args=ap.parse_args()
    CHECK_ONLY=args.check_only
    for LANG in (["zh","en"] if args.language=="both" else [args.language]):
        for name,draw in FIGURES:
            if args.only is None or args.only==name:
                draw()
    report={"paper":"economic-constitution","created_utc":datetime.now(timezone.utc).isoformat(),
            "generator":"make_figures.py","shared_dependencies_read_only":True,
            "fonts":["Noto Serif CJK SC","STIX Two Text","STIX Two Math"],
            "colors":{"navy":DEEP,"vermilion":VERMILION,"hairline":HAIR},
            "checks":"Glyph maps, measured label boxes, pairwise label overlap, shape extents, PDF vector/text/bounds.",
            "visual_inspection":"Recorded separately after actual display; this script does not claim visual approval.",
            "figures":MANIFEST}
    (OUT/".review").mkdir(exist_ok=True)
    target=OUT/(".review/layout-report.json" if CHECK_ONLY else
                ("manifest.json" if args.only is None and args.language=="both" else ".review/partial-manifest.json"))
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"count":len(MANIFEST),"report":str(target),
                      "outputs":[x["stem"] for x in MANIFEST]},ensure_ascii=False))

if __name__=="__main__":
    main()
