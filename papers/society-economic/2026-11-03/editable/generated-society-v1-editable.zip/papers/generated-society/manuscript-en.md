# The Canonical Society Theorem

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

Under specified source laws and complete responsibility contracts, we construct a family of inhabited canonical societies and prove that actor generation, root-law completeness, real exit, and all-depth regeneration can hold together. Actors arise from the sources and lineages of activity. Every complete installed institutional execution receives presentation, refusal retaining the bearer, action, or revision grounded in exact failure; actual writing occurs precisely in the last two cases. General exhaustiveness and inhabitation at one constitutional point are proved separately. At every natural-number depth, the same actual payment jointly generates six regeneration guarantees, and its actual successor is the entry to the next depth. More strongly, at every position in every cycle of the original type, each lawful payment carries the complete canonical contract into its actual target and generates there a new service or exit occurrence outside the entire old authority image. Even when instantaneous exit capacity remains one throughout, the frontier of fulfilled occurrences grows strictly with depth. Beyond every finite stage, actual revision and a paid successor birth also occur together. “Canonical” has its mathematical meaning: a standard construction generated from specified sources and rules, with its parts connected by compatibility relations.

These positive results and a family of impossibility results jointly characterize what institutions can accomplish. A worker's inability to exit may arise from missing payment incidence, an interrupted route, or captured continuation; all three yield zero capacity. Two actual sources with capacity one can likewise have, respectively, an inhabited and an empty complete capability portfolio. Accurate capability counts are therefore insufficient to identify failure sources, determine domain completeness, or select exact repair. In the constructed source families, this obstruction persists even when all domain-reachability readings are retained; two actual branches even share a root event, whole-ledger write-back, and next state while requiring different repairs. Conversely, the failure kind retained in the source suffices to recover canonical repair and its validity. The economic runs further separate legal recognition, settlement of old debt, and continuing payment. Original responsibility passes through revision to actual performance; for an exhausted source ledger, every same-source sequential target that adds no initial rows and increases no row's budget has zero progress budget at its first whole-ledger successor. Institutions must thus account for the bearer and consequences of every exercise of power, and supply actual sources for further continuation.

**Keywords:** social actors; institutional power; genuine exit; responsibility; root-law completeness; same-occurrence regeneration; formal social theory

## 1 Exit, responsibility, and institutions that remain open

### 1.1 After A leaves the position

Worker A decides to leave a job. A still needs to live. Payment has already been received, services have been promised, and responsibility remains unsettled. Once the employment relation ends, can A obtain the needed service along a route that can actually be taken?

Receiving funds is the beginning of the question. Payment must support A's continuation outside the former role, the service must actually have been provided, and A must be able to reach and use it. A “complete payment” in this paper includes actual performance and the complete update of the responsibilities concerned; it is broader than a transfer of money. We follow one exit request to see how these conditions connect.

Keep the original payment, A, and A's exit interest fixed, and change one institutional relation at a time. Figure 1 gives three comparisons. The first lacks the source-supported connection allowing this payment to support A's continuation. The second has payment incidence and an actual service, but lacks a route connecting the continuation to that service. The third retains the route and service, but B controls whether A can continue, leaving A unable to use that capability independently. B marks the controller's position here; the original service receipt identifies the provider. All three have zero exit capacity.

Zero tells us accurately that A cannot leave, yet leaves the cause unresolved.

![Three zeros for the same exit request](figures/01-exit-case-en.svg)

Figure 1. The three comparisons preserve the original payment, bearer A, and exit interest while changing payment incidence, route incidence, or capture. Each configuration has no feasible exit edge. Breaks and control marks identify its particular cause of failure. Section 5 proves how these causes affect actual repair.

Raising capacity to one leaves another question open. Section 5 gives two actual sources, each with a feasible exit: one provides both tenure and health services, while the other lacks health services. The same positive number can still conceal a missing component of the capability portfolio.

If the institution then rejects A's request, where do A's standing, original payment, and unsettled responsibility go? If the current rules obstruct continuation, who may change them, and who performs the responsibility incurred under them? These questions turn one departure into a fundamental institutional demand: every disposition must account for its consequences, and every completion must leave actual conditions for continuation.

### 1.2 The mathematical meaning of “canonical” and the method of this paper

We use **canonical** in its mathematical sense. Given the sources of activity, the actors' lineage rules, and the institution's responsibility contracts, the construction generates social objects according to those rules and connects their parts through explicit compatibility relations. Write \(S_h\) for its value at foundation horizon \(h\). Its standard character comes from this manner of generation. For example, actors arise from the lineage quotient of source seeds, and a natural bijection connects that quotient to the domain of actually generated actors. Which institutions are worth choosing and which forms of life deserve support receive their own normative arguments.

We use dependent type theory to express objects and their evidence. An exit witness must be supplied together with the bearer, payment, route, and service on which it depends; a revision must carry the exact failure it addresses. A “source program” or “source construction” below is a mathematical generation process defined in this way. “Installation” binds its source, authority, and response to a specific execution; “compilation” turns that binding into a complete institutional operation and successor. The common-process and whole-ledger theories supply the foundations of occurrence and complete update [@GaoProcess; @GaoLedger]. This paper defines the social objects it uses, while the appendices develop the generating rules, long proofs, and type transports.

Starting from these objects, we answer two questions together: how institutional requirements can be realized jointly, and which weaker information cannot replace them, however ingeniously it is processed. Positive constructions generate actors, authority, services, unsettled responsibilities, and actual successors. Counterexamples locate exactly where capability values, administrative labels, or local termination lose distinctions needed for institutional judgment. The capability approach already incorporates resource conversion and multidimensional freedom into evaluation [@Sen1979; @Robeyns2017, §§2.6.3, 2.6.7]. Here we further prove that, in specified source families, even accurate readings of capabilities themselves may be insufficient to diagnose failure and choose a repair.

The strongest positive results extend through time. Take any complete installed program within the prescribed sources: its actual output is governed by the root law. Take any prescribed foundation and recursion parameters: the construction supplies a constitutional point that can actually receive demands. At every natural-number depth, the same payment jointly carries six regeneration guarantees and supplies its actual successor to the next occurrence. Every cycle of the original type satisfies a stronger payment theorem: every lawful payment at every position carries the complete original contract forward and generates a new occurrence outside the entire old authority image. The foundation horizon is finite; the regeneration depth can be chosen arbitrarily.

Institutional completeness and an open future thus hold within the same inhabited construction.

### 1.3 The Canonical Society Theorem

In handling A's request, an institutional program must explain where its power comes from, how it changes responsibility, and who continues to bear responsibility afterward. The shared rules governing these dispositions form the **root law**. A node that can actually receive and dispose of submissions is a **constitutional point**. A program performs an **actual write** by implementing an authorized complete responsibility update at its target. The state it actually reaches and the next step adopts is its **actual successor state**. The subsequent responsibility state and the next visit of the institutional process have their own types; actual payment connects them.

| A's institutional question | Relations and core result | Written result |
| --- | --- | --- |
| Why can A still be unable to leave despite money and service? | Payment, route, and noncapture must meet on one action. Equal readings leave causes and exact repair undetermined. | Theorem 5.1; Propositions 5.2–5.3; Theorem 5.10 |
| After rejection, does the bearer still have a route? | Four dispositions exhaust writing authority. Refusal retains the bearer; after a misdirected submission, the original payment still supplies recourse. | Theorems 4.2–4.3; Proposition 5.4; Theorem 5.6 |
| Can the future grow while current exit capacity remains unchanged? | Every lawful payment carries the complete contract forward. The old frontier remains; a new occurrence strictly enlarges it. | Theorems 1.2–1.3, 6.2–6.4 |
| Where does old responsibility go after revision or local termination? | Inherited responsibility passes to actual performance. Budget exhaustion, local termination, and final settlement are distinct. | Theorems 7.4–7.7; Proposition 7.8 |

**Theorem 1.1 (The Canonical Society Theorem).** There exists a family of canonical societies \(S_h\), with foundation horizon \(h\in\mathbb N\), satisfying the following joint construction.

1. Each \(S_h\) retains source-generated actors and the complete institutional foundation. For arbitrary prescribed old-visit parameters, source index, boundary, health depth, and two finite recursion parameters, the registered recursion generates a stage and a single constitutional point within it. That point has an actual witness whose source is recognized and lawfully transported into an external complete payment. Every admitted raw submission and every generated execution of a fully installed complete program receives its own complete disposition.
2. For fully installed complete executions, presentation, refusal, action, and revision exhaust the dispositions. Writing occurs if and only if the disposition is action or revision, and the two are disjoint. Revision capacity retains its actual conditions: a raw submission's actual disposition must acquire authority at that source root, upon which the existing bridge supplies external revision; at the installed level, the actual same-occurrence revision branch supplies the exact failure, original responsibility row, first write, and actual successor.
3. For every depth \(d\in\mathbb N\), there exists a joint regeneration carrier indexed by the current actual payment \(p_d\). Every carrier of that type jointly retains law and lineage continuation, noncontracting ordinary exit, repair of the captured fibre, the residual bearer and its independent processing operation, successor revision capacity, and cross-actor responsibility attribution. The current actual next visit equals the next-depth visit exactly. Adjacent payments are distinct occurrences. The first policy break at depth zero also generates same-source law revision, with strictly distinct ordinary and revised successors.
4. For any cycle of the original type, arbitrary observer recursion parameter, and arbitrary finite position, every lawful payment carries the complete canonical contract to its own actual target, including every prescribed essential-service channel, independent operations processing external responsibility, successor birth, and the next cycle's exit constitution. The entire old paid frontier is retained, while a new actual service or exit occurrence at the target lies outside the entire old authority image. Strict canonical progress between any two depths holds if and only if the earlier depth is smaller than the later one.
5. For every finite cutoff and observer recursion parameter, there is a later step jointly supplying actual same-source law revision and a compatible successor birth supported by the target payment. In this cycle-linked regenerative run, the actual endpoint at every depth retains a revisable continuation; the current cycle's actual successor connects to the next cycle's occurrence through the native continuation relation.

The force of the total theorem lies in the joint realization of these requirements. Two separate proofs in Section 4 establish general execution exhaustiveness and inhabitation at one point; Sections 2–3 supply the actors and institutional foundation they actually use. Complete continuation and strict progress under every payment are proved below. Sections 5–6 develop exit, responsibility birth, and all-depth regeneration; Section 7 follows economic responsibilities through their respective sources. Properties of a common occurrence use the same payment, while different occurrences connect through proved actual successors. Appendices A–F retain all parameters, transports, and long dependencies.

### 1.4 Every lawful payment carries the complete institutional contract forward

Once A has received one service, someone must still provide the next, and someone must bear the responsibilities that remain. Complete payment must therefore supply the institutional conditions for what follows. Take any canonical payment cycle \(C:\mathcal C(v,s,b)\) of the source system, where \(v\) specifies the old visit, \(s\) the source, and \(b\) the boundary. Let \(i_0\) be the lifecycle starting index determined by this cycle, and put

\[
i_d=i_0+d.
\]
Appendix E.1 gives the starting index in the original encoding. Write \(\mathsf P_{i_d}\) for the type of payments satisfying the complete contract at that occurrence. For any \(p\in\mathsf P_{i_d}\), the target must be actually produced by that payment.

**Theorem 1.2 (Complete canonical preservation under payment).** For every \(v,s,b\), every original cycle \(C:\mathcal C(v,s,b)\), every observation depth \(o\), every \(d\in\mathbb N\), and every \(p\in\mathsf P_{i_d}\), the target generated by this very \(p\) carries forward the complete institutional contract of the cycle, with the following joint properties.

1. The input payment remains \(p\) itself. The target occurrence produced by its whole-ledger successor connects exactly to the canonical target at index \(i_d+1=i_{d+1}\).
2. This target has its own native payment, complete target future birth, the bearer’s exit outside the former role, and all originally installed essential access channels. For every channel, the returned relation witness recovers the original actor and relation; payment and settlement recover the target’s own actual exit; and the independent processing operation agrees with the target’s next occurrence.
3. The target retains the source ownership of external responsibility and the independent processing operation at its root. It also generates the next cycle’s complete exit constitution: sourced standing and payment, continuation outside the role, noncapture, actual route and service, external-responsibility disposition, the node’s same-source law revision, and the actual next cycle. The corresponding constitution of the source cycle holds as well.
4. The complete target state, native payment, and root event align exactly with the source state, source payment, and source event of the next lifecycle. Replacing the input by another element of the same exact payment type preserves this proved target connection.

For every finite request \(n\), these conclusions cover every legal original payment at depths \(d=0,\ldots,n\), and generate the same preservation object for every legal original payment at \(d=n+1\). Each \(S_h\) actually carries such a registered initial cycle and its complete finite-prefix certificate.

**Proof.** Fix arbitrary \(C,d,p\). The original payment type indexes the write, complete responsibility successor, and external responsibility of \(p\) to the same root event. That event’s original whole-ledger update determines the successor’s target. Compare \(p\) with the canonical payment at the occurrence. Original successor coherence gives equality of their \(\operatorname{next}\) projections; the input itself remains \(p\). The canonical payment’s next occurrence is precisely the root event at index \(i_d+1\), so every \(p\) reaches this target.

Apply the original canonical-state construction at that target. It generates the target’s own payment, complete future birth, and actual processing operation for every installed channel. The channel operations read the original actor, relation, payment, and actual settlement, and return to the next occurrence generated by this target. External responsibility is obtained from the target payment. Its external source and processing operation remain present even when the local responsibility inventory is empty. Finally, the original lifecycle recursion gives \(i_d+1=i_{d+1}\), identifies target state, payment, and root event with the corresponding source components of the next lifecycle, and regenerates the next complete exit constitution from that lifecycle.

The construction uses only the original cycle, depth, and input \(p\); it requires no supplied target or preservation proof. It therefore applies to every \(d\) and every \(p\). Apply it separately to each requested finite-prefix edge and once more at \(n+1\). The registered construction retained by \(S_h\) provides an actual initial cycle, so these universal results have a common inhabited instance. Appendix E.1 gives the complete type transports and componentwise preservation proof. ∎

### 1.5 Unchanged current exit capacity, a strictly growing history of realisation

Suppose A’s current exit capacity remains one on each occasion. Is the institution standing still? The capacity reading is the same yesterday and today. The decisive comparison asks whether earlier realizations remain and whether today adds an actual service or exit fulfilled through a new payment.

Along the same original payment source, let \(\gamma_k\) denote the completely generated future-birth occurrence at index \(k\). It carries actual service, uncaptured exit, and independent responsibility processing. Let \(\kappa(\gamma_k)\) be its service–exit authority object, retaining complete occurrence identity. Define the paid frontier through index \(i\) and its actual image by
\[
H_i=[\gamma_0,\ldots,\gamma_i],
\qquad
A_i=\{\kappa(\gamma_k)\mid 0\le k\le i\}.
\]
\(H_i\) records occurrences already generated and fulfilled by the original program. Even when two services have the same visible content, each retains its own original payment, service, and root-visit identity.

Let \(\mathsf E_C(d)\) be the complete exit constitution preserved by Theorem 1.2. Define **strict canonical progress** between two stages of the cycle by
\[
C_r\prec_{\mathrm{can}}C_t
\quad\Longleftrightarrow\quad
\mathsf E_C(r)\land\mathsf E_C(t)
\land A_{i_r}\subsetneq A_{i_t}.
\]
The comparison requires both complete endpoint institutions and proper inclusion of the paid occurrence images.

**Theorem 1.3 (Strict canonical progress).** For every original cycle \(C:\mathcal C(v,s,b)\) and every \(r,t\in\mathbb N\),
\[
C_r\prec_{\mathrm{can}}C_t
\quad\Longleftrightarrow\quad r<t.
\]
Moreover, for every observation depth \(o\), every \(d\in\mathbb N\), and every legal original payment \(p\in\mathsf P_{i_d}\), the same paid step jointly generates the complete preservation object of Theorem 1.2 and
\[
H_{i_d+1}=H_{i_d}\mathbin{+\!\!+}[\gamma_{i_d+1}],
\qquad
\kappa(\gamma_{i_d+1})\notin A_{i_d}.
\]
The new occurrence lies at the target actually produced by \(p\). The original whole ledger, the actor and relation identities of all original channels, the external-responsibility source, and its independent processing operation are retained together. The original root law’s complete disposition of this step also enters the object and connects to the corresponding root event through the specified lifecycle. For each \(S_h\), every prescribed source-parameter tuple, and every finite request, the original registered cycle supplies these joint conclusions for all requested paid edges and the next edge.

**Proof.** The original frontier is the list of fully generated future births. Increasing its length by one therefore retains the whole old list and appends precisely the next occurrence. The decisive question is whether the appended authority was already in the old image. If \(\kappa(\gamma_j)=\kappa(\gamma_k)\), the complete service–exit objects have the same actual payment-occurrence identity. Injectivity of the original occurrences forces their actual visits to agree. The visit depth is a fixed initial value plus the index, so \(j=k\). Consequently, \(\kappa(\gamma_{i+1})\) cannot equal any old member indexed by \(k\le i\). Retention of the full old frontier and a new member outside its image give proper inclusion.

The original construction supplies complete exit constitutions at every cycle depth. Thus \(r<t\) gives \(A_{i_r}\subsetneq A_{i_t}\). Conversely, proper inclusion and index injectivity exclude a shorter target frontier. Equal lengths give equal images. Hence proper inclusion implies \(r<t\).

Finally, place the comparison of new occurrences back on the same paid edge. The source construction’s two adjacent replays occur at \(i_d\) and \(i_d+1\). The first retains input \(p\), and its actual target is the second replay’s root occurrence; the second uses its own native payment to fulfill the new service and exit. The channels on each side read their own payment, and the target’s independent processing operation returns to its own institutional entry. The same payment step therefore jointly witnesses proper inclusion and complete continuation. Appendix E.2 gives the full indices of the adjacent replays, finite-prefix assembly, and counterexamples. ∎

Exit capacity can remain \(1\) at every moment while the frontier of fulfilled occurrences grows strictly. Yesterday’s exit receipt cannot pay for today’s life.

This strict order requires both retention and addition. Retention alone gives no strict growth of the frontier; adding a new member while deleting an old one also fails the order. The objects compared are histories of action supported by actual payment. General cofinal generation can contain intermediate ticks with no growth. This cycle acquires a new occurrence at every payment’s actual target and therefore satisfies the stronger strict order step by step.

### 1.6 Those affected by institutions should have a place to continue

We choose three interconnected institutional requirements. Those who exercise power should explain their authority and its consequences, so that affected people can question the source of a decision. Rejecting a submission should preserve the bearer relations it leaves behind. Changing the rules must give a destination to responsibility already incurred under the old rules. The construction tests whether these requirements can be realized together and continue to hold in actual operation.

“Lawful” here means conformity to the stated source law and complete disposition contract. The value of income distributions, service priorities, and ways of life is assessed through their respective normative arguments. Social standing rests on activity sources, effects borne, responsibility, and routes of continuation, without requiring passage of a consciousness test. Authority to exercise power over others comes from the relevant relation and actual authorization.

A and the exit request run throughout the paper. The three zeros compare three institutional configurations; recourse after rejection returns to the original payment through lawful source transport. Clearing, credit, and theory adoption each have their own generative sources. Their joint properties are proved through common installation; connections across occurrences are proved through actual successors and lawful transports. We can thus follow one social question while checking the grounds of each conclusion.

## 2 Generating actors from activity

### 2.1 Retaining the sources of activity and responsibility

After A ends the employment relation, service may still need to be performed and responsibility taken forward. To identify such a bearer, the construction first retains what occurred, then generates positions that can continue to bear relations and responsibility. An **occurrence** \(\omega\) includes the generating program's actual trace, execution path, write-back, and responsibilities still requiring treatment. A visit \(v\) locates it within the registered process. An observation reads an aspect of it. Two visits can occupy different histories even when they display the same state.

The common-process and whole-ledger theories supply the occurrence and actual-update objects used here [@GaoProcess; @GaoLedger]. The objects required in this paper are as follows. A visit \(v\) carries a complete family of responsibility rows \(\mathcal R_v\). A complete payment \(p\) supplies an authorized disposition for every earlier row, an earlier source or actual birth source for every new row, and a successor generated by that same execution. A service program must therefore update performed responsibilities while retaining original rows that still require treatment.

Payment actually produces the next visit \(v^+(p)\), which in turn generates the occurrence \(\varepsilon(v^+(p))\). Their actual generation connects the two steps:
\[
\omega^+(p)=\varepsilon\!\left(v^+(p)\right).
\]
Later service or revision proceeds from this target. Connections across occurrences use source transports; different operations on one occurrence read their common original material.

**Definition 2.1 (Responsibility row and independent processing operation).** A responsibility row records its source occurrence, bearer, content requiring explanation or performance, and live status. An independent processing operation tests effects, reads performance, or generates a disposition within the scope already permitted by that source. Migration preserves the destination of responsibility; performance closes it through its own actual receipt and the closure conditions at the successor.

Write \(\delta\) for the original responsibility row associated with A's continuation. After rejection, it tells us what remains; after payment, it records what has been performed; after revision, it retains what still requires treatment. Actual performance receipts and the closure conditions at the successor determine how it can later be closed.

### 2.2 Generating actors from seeds of activity

A's activity records can grow while identity continues along one lineage. The construction first collects seeds with sources, then uses lineage to determine which records belong to the same actor. For the trace \(\tau(\omega)\) of an occurrence, let \(B(\omega,x,s)\) state that activity record \(x\) supports seed \(s\), and take
\[
U_\omega=
\{s\mid \exists x\in\tau(\omega),\ B(\omega,x,s)\}.
\]
Every seed thereby carries an actual witness within the trace. The lineage map
\(\ell:U_\omega\to L_\omega\)
records its continuing source. Generated actors form its actual image:
\[
A_\omega=\ell[U_\omega].
\]

One lineage may collect several seeds. A constant lineage gives a strict example: different seeds generate the same actor. A faithful lineage retains the distinction between different seeds. Together these cases pose a precise question: what relation between actor identity and seeds survives?

**Theorem 2.2 (Actor generation and canonical quotient).** Every generated actor has a source seed. Define
\[
s\sim_\ell t\quad\Longleftrightarrow\quad\ell(s)=\ell(t).
\]
The canonical map from the lineage quotient of seeds to generated actors,
\[
\Phi:U_\omega/{\sim_\ell}\longrightarrow A_\omega,
\qquad \Phi([s])=\ell(s)
\]
is a bijection. The seed-to-actor map is injective if and only if the lineage map \(\ell\) is injective on the source-seed domain.

**Proof.** If \(\Phi([s])=\Phi([t])\), then \(\ell(s)=\ell(t)\). By the definition of the quotient relation, \([s]=[t]\), so \(\Phi\) is injective. Take any generated actor. By the definition of the actual image it equals \(\ell(s)\) for some seed, and therefore belongs to the image of \(\Phi\); hence \(\Phi\) is surjective. The same lineage equality also determines whether the seed-to-actor map is injective. Appendix A.1 gives representative independence and the complete quotient proof. ∎

Lineage carries an actor's continuity while activity records continue to grow. Each of A's new activities can still be traced back to the sources supporting that identity. The original lineage and lifecycle contract determine which mergers or separations are admissible.

### 2.3 What must remain when A changes roles

A role depends on the actor, relation, and stage. Leaving the former position terminates that role, while A's lineage, original payment, and unsettled responsibility may enter another relation. The construction separately records the actor's continuity and changes of role, allowing service and responsibility to follow the bearer.

Actors themselves may also change. The general lifecycle treats birth, persistence, merger, splitting, exit, and succession through source actors, target actors, and occurrence relations. Persistence retains lineage; merger retains incoming sources; splitting supplies child sources and responsibility destinations; succession sends responsibilities that must continue to the actual successor. Lifecycle exit concerns a source actor leaving the relevant domain and receiving its native disposition, under its own conditions. A ending a position role is judged through that role relation.

Economic, biological, multi-actor, and Go instances each recover actor sources from their traces. The actual general lifecycle construction supplies the six kinds of change and their responsibility dispositions. Appendices A.1 and C.1 give the detailed sources and inverse recovery. With these objects in place, we can ask which relations give A access to service and which prevent A from leaving the former position.

## 3 How payment becomes usable institutional capacity

### 3.1 Relational positions and control

A can occupy different roles in the former position and the service relation. Relations themselves arise from activity seeds and lineages, and roles change with the relation's actual stage. The foundation gives an actual construction in which one actor enters different relations and acquires different target roles. Having identified A, we must also ask which relation A occupies and what that position permits.

Hohfeld distinguishes a claim that another person perform a duty from a power to alter legal relations; the correlative of a power is the other party's susceptibility to that alteration [@Hohfeld1913, “Powers and Liabilities”]. The distinction matters directly to A's exit. A may have a power to terminate the relation, while B holds another power to alter it; A's ability to continue outside it also depends on services and routes. We construct these positions separately and track whose continuation conditions an actual exercise of power changes.

Power concerns control over another party's continuable futures. Each relational position retains finite future actions and their actual continuation conditions. A power operation records the controller's source event and how those conditions change. B's control over whether A can continue must therefore leave an actual change in A's continuation conditions. The capture construction supplies a situation in which the affected party loses continuable futures and identifies the actual controller through the sources. Even a nonempty future-code set may contain only idling; capacity for action also requires a continuable non-idle action.

Relational structure can also exceed what individual scores express. A three-actor cycle in the foundation is generated from traces, and its relational phases sum to \(2\). Any cycle given by differences of global individual potentials would sum to zero. This nonzero obstruction rules out a representation recovering all the relational differences by subtracting personal scores. Appendix C.1 gives the full construction and invariant.

### 3.2 Payment, price, and outstanding responsibility

A's payment connects to definite responsibility and actual performance. A finite exchange in the foundation jointly generates both actors, the relation, source event, bearer, and protected interest for each transaction leg. The actual four-leg exchange allows the parties' responsibilities to be traced separately. Stable responsibility slots retain live responsibilities or closed archives. Bearer exit, replacement of authority, and reopening of responsibility each leave their own sources.

What object supports a price? Let \(e\) be an exact settlement, \(\mathcal O(e)\) its type of open settlement, and \(\mathcal P(e)\) its type of price observation. The actual construction gives
\[
\mathcal P(e)\simeq\mathcal O(e).
\]
Whenever the exact settlement has open content, there is a corresponding price observation. An unsettled responsibility can have a defined quote of zero. After complete performance, the price-observation domain is empty.

To determine the status of this responsibility row \(\delta\), the program reads the original live slot and performance receipts, executes the next event at that slot, and extends the history to the event's real target. The original source and actual performance jointly determine standing for settlement. Section 7 uses this operation to explain how common clearing and credit support handle the parties' responsibilities.

### 3.3 Authorization, service, and maintenance of the route

For A to use the service, authorization, payment acceptance, maintenance of the relation, and responsibility renewal must connect. An actual election in the foundation updates the lineage of authorization; payment acceptance updates purchasing-power standing; relational maintenance distinguishes permission from the flow of debt; an artificial actor generated within the trace enters responsibility renewal. These four aspects are jointly installed at one source root. The relevant programs read the complete update and actual successor of the same visit.

Service also depends on the original queue and its actual capacity. In the construction, capacity is \(2\). Exact prefixes of the original queue with lengths \(1,2,3\) respectively produce stable, critical, and overloaded states. The critical queue has a complete actual debit run. The overloaded queue cannot obtain a certificate that all service was completed.

The unserved third item is a definite occurrence in the original queue. Even if it displays the same state as an earlier item, its position and lack of service remain. A therefore needs a service receipt and its position in the original queue.

The spatial construction connects position, path, resource debit, and affected responsibility to the same actual crossing. The maintenance program uses the original debit receipt and retains maintenance responsibility in the subsequent state. One actual boundary construction in the foundation has \(2\) settled services and maintenance debt \(3\). These responsibilities have their own sources and cannot cancel one another. The route is usable, and maintenance still has a bearer.

Strategic relations also have a complete generation result: the foundation generates finite strategic games from lawful source code, and every finite strategic game has an isomorphic generated representation. Yet two objects with the same visible game image may retain different residual authority. Strategies and payoffs describe one aspect of their interaction; authority over existing responsibility must still be traced through the original sources.

### 3.4 Uncertainty and theoretical judgments also need sources

An institution may observe a result while needing to assess the events behind it. Write \(z\) for the observation value. The source objects whose observation is \(z\) form the fibre \(X_z\), with source weights \(w(x)\geq0\) assigning mass to them. For the event \(A\) in question, probability takes values in \([0,1]\) together with an undefined value \(\bot\):
\[
P(A\mid z)=
\begin{cases}
\dfrac{\sum_{x\in X_z,\ x\in A}w(x)}
{\sum_{x\in X_z}w(x)},&\sum_{x\in X_z}w(x)>0,\\
\bot,&\sum_{x\in X_z}w(x)=0.
\end{cases}
\]
On a positive-mass fibre, an empty event yields a defined zero; a nonempty fibre of zero total mass yields an undefined value. An actual installed instance produces \(1/3\) and a below-one-half classification, sharing the complete update and successor with boundary maintenance. For every observation horizon \(h\), the foundation also retains source-generated probability evidence at that horizon.

Theories participate in action as well. The original program generates classifications, policies, and actual effects; an independent processing operation reads that effect, and adoption installs the theory in the original relation. The ordinary successor retains the old theory. The corresponding revision proceeds from actual failure of the old law and the required authority. Section 7 follows one earlier responsibility: revision's first write transports it while keeping it live; a later performance beginning at the exact target then closes it.

### 3.5 Assembling the complete foundation

For A to turn payment into a capability for living, service, maintenance, and judgment must connect in actual execution. Service programs read existing responsibilities and receipts; maintenance uses actual debits; theory adoption handles effects already produced; the next action starts from the state actually reached on this occasion. Let \(\mathcal F_h\) be the dependent product of these objects, sources, actual operations, and compatibility relations. The successor each item can use depends on earlier sources and responsibilities. Jointly installed aspects also retain equalities of visits and updates.

**Proposition 3.1 (Inhabitation of the complete foundation).** For every \(h\in\mathbb N\), the complete foundation \(\mathcal F_h\) exists and is actually retained by the canonical society.

**Construction and proof.** Inverse seed sources within traces and the actor quotient supply identity; lifecycle and relational generation supply roles, power, and responsibility destinations. Finite exchange, stable slots, and performance by each leg supply settlement objects. Generation and representation of finite strategies, observation of authority, four-aspect joint renewal, actual reform and revision, and capacity debits supply the corresponding institutional operations.

Spatial and probabilistic constructions add crossings, maintenance, boundary residuals, source weights, and observation. The theory construction adds adoption and responsibility migration. Taking the dependent product of these actually generated objects and their inheritance relations yields \(\mathcal F_h\). Each construction's actual processing operation supplies the compatibility equations; joint installations retain the same complete update and successor. The canonical society stores this complete product and generates the next section's constitutional point upon it. Appendix C.1 gives the full factors, original constructions, and installation equations. ∎

![Generation of actors, relations, and institutional capacity](figures/02-generation-en.svg)

Figure 2. A's activity sources generate a continuing actor, who enters roles, control relations, and responsibility. Seeds in one lineage class generate the same actor; roles, actual services, and responsibility rows retain their respective sources. Connections indicate construction dependencies and established joint installations.

Essential services will be chosen again, and the institution must remember what the previous choice actually did. The canonical selection program gives the same rhythm for every $n\in\mathbb N$: the $n$th relation action across representations executes at time $t_n$, the choice generated by that action is read at $t_n+1$, and the next action begins at $t_n+2$, so $t_{n+1}=t_n+2$. The initial time is determined by this specified run; Appendix F.9 gives the concrete indices. The target's initial state embeds the entire existing history. The first whole-ledger write generates a new relation root, while the independent processing operation for the UBI responsibility is retained through the same action receipt. The next depth therefore begins at the target root actually produced at the present depth.

This connection also identifies a source of institutional memory. Take any three consecutive relation actions. Three service relations supply three distinct target roles; each edge writes its target role, and the downstream read recognizes that edge's result. The downstream read is therefore $0$ before the action and $1$ after it. The total difference around the three actual relation edges is $3$, and every edge generates the reflexive memory atom “observation changed.” Its source is the actual role write and subsequent read. When the seed returns to its original identity after three steps, the occurrences themselves continue forward along a strictly growing history.

Sound and complete representations may give this memory different names, but their decoded content must agree. Specifically, for the read/write query $q$ of each actual edge and its downstream source state $x$, take representations $(C_1,D_1)$ and $(C_2,D_2)$ in any two type universes. If each is sound and complete for the memory content of that query, then
\[
D_1(C_1(x),\star)
\ \Longleftrightarrow\
M_q(x,\star)
\ \Longleftrightarrow\
D_2(C_2(x),\star),
\qquad
M_q(x,\star)\equiv r(w(x))\ne r(x).
\]
Here $\star$ denotes “observation changed.” The representation types, names, and encodings are arbitrary; the common constraint comes from the actual read/write relation. The proof has two decisive steps: actual successors re-enter the same selection runtime every two ticks, and injectivity of target roles makes the complete read/write phase agree pointwise with the generated three-cycle phase. Appendix F.9 proves the depth induction, the full phase calculation, and presentation uniqueness.



Actors and institutional relations now have actual content. Handling A's request also requires a complete set of disposition rules and an institutional node that can actually execute them.

## 4 Closure of institutional dispositions and their inhabited realization

### 4.1 When a request acquires authority for an institutional write

By bringing a demand to an institution, A places the conditions of continued life within an exercise of power. The institution may present facts, reject a submission, update responsibility, or revise the law on grounds of its exact failure. Every disposition must identify the source of its authority, how responsibility changes, and who bears it afterward. Root law subjects these acts to common constraints, giving each write checkable grounds and a destination.

An institutional grammar already asks whom a rule addresses, what it permits or requires, under which conditions it applies, and which further rules authorize and organize sanctions [@CrawfordOstrom1995, pp. 583–586]. Root law follows a particular disposition into its consequences: what authorizes its write, whose bearer relation survives refusal, and where revision sends the old responsibilities. A complete execution must supply these connections themselves.

Give the request to a complete installed institutional program, and write \(r\) for the result it generates on this occasion. With the source root, recognition rule, current visit, and scenario fixed, the program binds the submission, response, and effect together. The representation types of visible content, the response, and the claimed effect are each chosen arbitrarily. The response used in execution must be exactly the one already generated by the program.

**Definition 4.1 (Four complete dispositions).** The four dispositions retain the following content:

- **Presentation \(\mathrm P(r)\):** a lawful observation, or an answer already supplied by the old law or its review. An answer with a source may serve only to present information.
- **Rejection \(\mathrm J(r)\):** the exact rejection and a residual-bearing object that retains the original generated submission itself, together with its source, complete responsibility record, and successor decomposition.
- **Action \(\mathrm A(r)\):** the original root's action authority, complete responsibility write-back, and the actual successor generated by that write-back. It includes sequential action on inherited responsibilities and the admission of new responsibility in Section 6.1.
- **Revision \(\mathrm U(r)\):** the old law's exact failure, revision authority on the same responsibility row, the revision's first write, and the successor relations jointly constrained by the old and new rows.

Let \(\mathrm W(r)\) mean that the result has an actual write: it implements an authorized complete responsibility update at its actual target.

**Theorem 4.2 (Root-law closure and the criterion for writing).** For every source root, recognition installation, visit, scenario, three independently chosen representation types, complete program, and generated execution specified above,
\[
\mathrm P(r)\lor\mathrm J(r)\lor\mathrm A(r)\lor\mathrm U(r).
\]
Moreover,
\[
\mathrm W(r)\quad\Longleftrightarrow\quad
\mathrm A(r)\lor\mathrm U(r),\qquad
\neg\bigl(\mathrm A(r)\land\mathrm U(r)\bigr).
\]
Presentation and rejection do not write. If the branch for same-source law revision of this actual result is inhabited, that same result retains the complete package of exact failure, the same responsibility row, the revision's first write, and the successors of the old and new rows. There is no fifth authority to write outside the responsibility record.

**Proof.** The program first reads the submission's actual disposition. Presentation supplies a lawful presentation. Rejection supplies both the exact rejection and the original submission's residual-bearing object. Writing authority is empty for both constructors.

A submission carrying authority from this root must also read the response already bound by the program. A direct answer, an answer obtained after obstruction review, and an answer in the old language remain presentations. Sequential action reads the complete update and successor of the original rows. Responsibility admission reads the new row's source, first complete write, and first-write successor. Both belong to action. Revision generated by an exact failure carries the failure grounds, revision authority on the same row, the first write, and the two rows' successors, and therefore belongs to revision.

Every result carrying root authority retains an installation equality: the response it uses is the response already generated by the complete program. A candidate using another response would require both equality and inequality, and so cannot exist. The classification therefore exhausts this execution's results. Writing holds exactly in the action and revision constructors. These constructors are distinct, so one result cannot belong to both; this gives the writing equivalence and disjointness. Reading the complete package from a witness of the actual branch for same-source law revision then gives conditional revision availability. All public dispositions have been covered, so there is no fifth writing authority. ∎

![Four institutional dispositions and responsibility birth within action](figures/03-root-law-en.svg)

Figure 3. Root law governs the use of writing authority in every complete execution. Action includes updates of old responsibility and admission of new responsibility; revision takes its grounds from exact failure on the same responsibility row. Refusal preserves the bearer object of the original submission, while action and revision each generate an actual successor.

### 4.2 How a submission with a source enters actual execution

Theorem 4.2 constrains the execution of every complete program. Providing A with a usable institutional route also requires constructing a constitutional point that can receive and dispose of submissions. This existence proof begins with raw submissions.

A raw submission is generated by its source; a complete installed program must additionally carry an open responsibility row at the current root. The canonical raw-submission root already has submissions carrying its authority, but its local open responsibility stock is empty. Any proposed complete local program would supply a nonexistent open row. The entire local legislative route is therefore empty.

The source program has already generated transport from these rooted submissions to an external complete payment. Its existing construction determines the target payment, revision grounds, and successor. The original submission and the transport's source end retain an exact event equality. At the target, legislation, authority on a responsibility row, revision, and an independent processing operation all read that target payment.

The source-event equality and the shared target payment each establish their own connection. The raw-submission occurrence and the target-payment occurrence retain distinct type positions; lawful transport cannot be rewritten as equality across these occurrences. Appendix A.3 gives the equalities at both ends and the full transport dependent on their indices.

The payment A submits must also match the receiving node. Section 5.4 follows a genuine payment submitted to the wrong adjacent node and shows how refusal preserves A's original capacity to continue.

### 4.3 Inhabited completion at one constitutional point

We now install the external payment route and the general root law at one institutional node, so that an actual disposition witness and the universal disposition rules can be used together.

For each foundational observation horizon \(h\), take the canonical society \(S_h\) constructed in Section 3. Prescribe an arbitrary old-visit parameter, source index, boundary, health depth, request recursion parameter \(f\), and observation recursion parameter \(o\). The recurrence registered by the original program generates a stage from its initial object and a constitutional point \(c_m\) at that stage.

Call \(c_m\) **root-law complete** when the following three properties belong to this point. An external complete disposition carrying authority from this root has an actual inhabitant. For every visit index, scenario, and independently chosen content, response, and effect types, every source-generated raw submission has a complete raw disposition. Under the same quantifiers, the generated execution of every fully installed program satisfies Theorem 4.2.

Revision availability retains two different conditions. When a raw submission's actual disposition carries authority from this root, that submission and its existing authority obtain a complete external revision package through the transport of the preceding section. When the actual branch for same-source law revision of a fully installed program is inhabited, that same generated result retains the exact-failure, same-row, first-write, and two-row-successor package.

**Theorem 4.3 (An inhabited canonical society and root law at the same point).** For every choice of all the parameters above, the registered recurrence of \(S_h\) generates a stage \(m\) and one constitutional point \(c_m\) such that
\[
\operatorname{Complete}(c_m)\ \land\
\operatorname{RevAvailable}(c_m).
\]
The first conjunct is the root-law completeness just defined; the second is the two layers' respective conditional revision capabilities. The inhabitant, universal raw-submission classification, universal complete-installed-program classification, and conditional revision all belong to this same \(c_m\).

**Proof.** Take the initial object and recurrence from the complete foundation already retained by \(S_h\). Expand the recurrence for the given request and choose \(m=f+1\). Thus \(f<m\), and \(c_m\) is obtained at this stage. The source selects the point's actual scenario, and recognition then generates a submission carrying authority from this root. The existing transport in the preceding section connects it to a complete external payment, giving an inhabitant at the same point.

Next take an arbitrary visit index, scenario, three representation types each chosen arbitrarily, and source-generated raw submission. Its actual disposition is presentation, rejection, or root authority. The first two retain their nonwriting raw dispositions; the third obtains the existing external revision package. Local action is excluded by the empty local responsibility stock. Now take any fully installed program at that visit and apply Theorem 4.2 to its generated execution. Both arbitrary choices range over the full parameter domain of the current fixed recognition root, yielding the two universal conclusions.

Finally retain the two revision conditions separately. At the raw layer, actual root authority enters the existing external bridge. At the installed layer, an inhabited actual branch for same-source law revision supplies the complete revision package for that same result. Place these objects and propositions at the one \(c_m\) already generated. This gives the required conjunction. ∎

Theorem 4.2 gives an exhaustive account of writing authority for complete executions; Theorem 4.3 makes these rules work at an actual node. The inhabitation witness comes from a sourced external complete disposition, while the local action fibre retains its emptiness. A thus faces an institutional node that can receive demands and must account for responsibility in every disposition.

## 5 Realising exit and diagnostic impossibility

### 5.1 What makes A's exit practicable

Hirschman places exit and voice within the interaction through which organisations respond to decline; Widerquist makes the means of living needed to refuse cooperation central to freedom [@Hirschman1970, pp. 3–4, 81–82; @Widerquist2013]. A's problem lies at their intersection: can he actually leave, and what enables him to continue afterwards?

A's former employment relation has ended. A remains the person requesting service and the bearer of the original responsibility. Making this request into a practicable exit requires connecting one of A's continuing actions, the payment supporting it, and an actual service.

At depth \(d\) of the canonical society \(S_h\), A first takes a continuing action \(c\) from the finite set \(C_d\) supplied by the source program. Let \(R_d(c)\) mean that this action can continue in an exit relation distinct from the original employment relation, \(I_d(c)\) denote idleness, and \(H_d(c)\) capture. The action A needs must permit continuation, be nonidle, and remain uncaptured.

We must also see how payment and service support this action. Write \(p_d\) for the complete payment and \(\delta\) for the original responsibility row associated with A's continuation. Let \(P_d(c)\) mean that the original payment has the required payment-incidence evidence for \(c\). Service must come from the original run indexed by this payment: \(J_d\) is the set of positions in this occurrence's actual served sequence, and \(j\in J_d\) points to the service \(s_j\) already provided. A also needs a route \(\pi\) connecting the same action \(c\) to that service, with the corresponding route-incidence evidence. Let \(T_d(c,j)\) mean that this incidence holds. Define a feasible edge between the action and service by
\[
E_d(c,j)\quad\Longleftrightarrow\quad
R_d(c)\land\neg I_d(c)\land\neg H_d(c)
\land P_d(c)\land T_d(c,j).
\]
Capture can occur even when the route and service are present: the capacity to continue is still not independently available to A. B denotes the position controlling A's continuing action or its conditions. The service provider's identity is determined separately by the source of the actual service.

**Theorem 5.1 (Necessary and sufficient conditions for genuine exit).** For every \(h,d\), the source program can generate a genuine exit continuation for A outside the former role if and only if
\[
\exists c\in C_d,\ \exists j\in J_d,\quad E_d(c,j).
\]
Relational continuation, nonidleness, noncapture, payment incidence, and route incidence must all use the same \(c,j\). Actual service must also come from the original run indexed by \(p_d\).

**Proof.** From a genuine exit continuation, take its action \(c\), service position \(j\), and feasible edge. This edge retains continuation outside the role, nonidleness, noncapture, payment incidence, and route incidence. The position \(j\) belongs to the original settlement's sequence of services actually provided. These give the right-hand side.

Conversely, take the same \(c,j\) satisfying the right-hand side. The original settlement connects position \(j\) in the service sequence to the event at the same ordinal in the actual run and supplies that event's service receipt. Combine this receipt with the original payment incidence, route \(\pi\), continuation outside the role, and noncapture. This gives a complete feasible edge, from which the original exit construction generates actual continuation. Both directions use the same action, service position, and occurrence index throughout. ∎

The feasible edges also determine exit capacity \(K_d\), the maximum matching size of the finite bipartite graph \(E_d\). A matching uses each action and service position once, so it counts exits that can receive independent support simultaneously. A feasible edge forms a singleton matching, while every matching of positive size contains an edge. Thus
\[
K_d>0\quad\Longleftrightarrow\quad
\text{genuine exit continuation is inhabited}.
\]

The canonical instance has three queued service items, two units of service capacity, and two actually served items. Only one nonidle action can form the exit. Pairing it with an existing service position gives a matching of size one. Every feasible edge has that action as its left endpoint, giving the upper bound one. Hence \(K_d=1\). Two served items thus support one genuine exit while one service item remains unfinished.

In this construction, periodic payment supplies purchasing-power standing outside the original role. Actual service and the route make that standing usable, while a new job supplies continuation in another role. The new job does not replace the exit conditions: even when another job exists, capture can still prevent A from independently using a continuation outside the original role.

The conditions are also independently necessary. At every depth, the original route-outage construction retains actual payment, service, responsibility row, whole-ledger successor, and seven other installed renewal operations, while the source route-receipt type is empty. The entire remaining carrier still cannot construct that receipt. Actual repair produces a route only at the next visit generated by payment, where capacity becomes one.

Alignment between service and bearer also requires its own evidence. At one post-settlement occurrence, the tenure channel's first service receipt agrees literally with the original exit bearer's receipt. The health channel retains a genuine service, the same payment and settlement, independent processing, and the actual successor, but its registered relation actor differs from that exit bearer. Its health service exists while exact alignment to this bearer remains empty. Any reconstruction of alignment from one of the retained materials, applied to the actual object, would inhabit that empty type. Appendix F.10 proves both independent-necessity results in full: institutions must provide services and connect them accurately to the people affected.

### 5.2 Three zeros and two ones: why exact measurement is insufficient for diagnosis

At zero capacity, A's exit is blocked. Keeping the original complete payment, A, and A's exit interest, construct three comparison branches to examine which relation blocks continuation. Each branch retains its own source identity.

Let \(z_{\mathrm c}\) denote full capture, \(z_{\mathrm p}\) missing payment incidence, and \(z_{\mathrm r}\) missing route incidence. Under capture, payment incidence, the route, and actual service remain, but A's capacity to continue is captured. Under missing payment incidence, the underlying complete payment still exists; what is absent is the evidence connecting it to the action in question. Under missing route incidence, payment and actual service remain; the missing element connects this action to that service.

**Proposition 5.2 (Capacity readouts cannot identify source or completeness).** For every \(d\), the three source-bearing objects above belong to \(Z_d\), are pairwise distinct, and satisfy
\[
K(z_{\mathrm c})=K(z_{\mathrm p})=K(z_{\mathrm r})=0.
\]
There is no \(g:\mathbb N\to Z_d\) such that \(g(K(z))=z\) for every \(z\in Z_d\).

**Proof.** Full capture excludes every noncaptured feasible action. Missing payment incidence deprives every candidate edge of required payment evidence. Missing route incidence deprives every candidate edge of required route evidence. Each case therefore has no feasible edge and has capacity zero. The three cases retain distinct source constructions, so they are pairwise unequal. If \(g\) recovered the source from capacity, then
\[
z_{\mathrm c}=g(0)=z_{\mathrm p},
\]
contradicting their distinctness. ∎

**Completeness at positive capacity.** The problem also arises when exit is already feasible. Consider the original institution's tenure and health domains: each requires a source actor, relation, actual service, route, and feasible continuation. Call the dependent product of these domain-specific objects a **complete capability portfolio**. Completeness here concerns these two installed domains.

Proposition 5.2 has the following strengthening. At every depth \(d\), the original construction supplies a full source \(x_d\) and a one-service source \(y_d\). They retain the same root occurrence, the same payment occurrence, and the same payment and route rules. Both capacities equal \(1\), but their complete capability portfolios are inhabited and empty respectively.

| Actual source | Tenure service | Health service | Exit capacity | Complete portfolio |
| --- | --- | --- | --- | --- |
| \(x_d\) | Fulfilled | Fulfilled | \(1\) | Inhabited |
| \(y_d\) | Fulfilled | No corresponding service occurrence | \(1\) | Empty |

No capacity-only reconstruction of sources has a left-inverse property. More strongly, no \(q:\mathbb N\to\mathrm{Prop}\) correctly classifies the existence of a complete portfolio on both sources.

**Proof.** The full source obtains two distinct paid service positions in the original queue prefix. The one-service source executes only the original first maintenance event, with \(0\) as its sole served slot. The original rule assigns health to another queue position, so no health-service witness can be obtained. Both sources have only one surviving non-idle action and each has an actual feasible edge; their maximum matching capacities are therefore both one. Two actual witnesses generate the complete portfolio in \(x_d\), while a portfolio in \(y_d\) would require the missing health witness.

If \(q\) classified correctly, the full source would give \(q(1)\); correctness for the one-service source would then produce its complete portfolio, contradicting emptiness. A source-reconstruction left inverse would likewise identify the two different prefixes. Appendix F.1 gives the full construction of domains, service ordinals, actual payment, and four independent controls. ∎

Capacity one is exact in both cases: each side has a feasible exit. What the number omits is whether health service has actually been delivered. To judge A's conditions of life after leaving, the institution must retain each domain's actual support and identify whose relation the service reaches.

Capacity still correctly counts exits that can be realized simultaneously. Choosing a repair also requires the operations' actual effects. Take two further installed failure dispositions: capture failure \(f_{\mathrm c}\) and an uncaptured route bottleneck \(f_{\mathrm r}\). In a repair language containing only removal of capture and restoration of the route, each operation changes its target condition while preserving the original payment, bearer, exit interest, and actual service. Applying them to the two failures gives
\[
\begin{array}{c|cc}
 & \text{remove capture} & \text{restore route}\\ \hline
f_{\mathrm c} & 1 & 0\\
f_{\mathrm r} & 0 & 1
\end{array}.
\]

**Proposition 5.3 (Impossibility of exact repair selection from capacity).** At every depth \(d\), within the two failures and two repairs above, no repair-selection function that reads only the original failure capacity is effective for both sources. Nor can a function recover each source's canonical repair from capacity.

**Proof.** Removing capture returns \(f_{\mathrm c}\) to the uncaptured geometry of the preceding section, with capacity one. Restoring only the route leaves full capture in place, so capacity remains zero. For \(f_{\mathrm r}\), removing capture does not supply the missing route, so capacity remains zero. Restoring the route supplies a complete feasible edge and capacity one. Each row of the matrix therefore has exactly one effective repair.

Both failures have original capacity zero, so a selector must return the same result for both. If it returns removal of capture, the route bottleneck remains. If it returns route restoration, capture remains. These two operations exhaust this repair language, so no selector is effective for both sources. Each canonical repair is also the unique effective operation in its row. They differ and cannot both be recovered from the same \(g(0)\). ∎

The obstruction arises where information is merged: the same zero is asked to determine two different actions. Once the source of failure is retained, the installed repair program can select the corresponding unique effective operation and carry the restored capacity into an actual successor. A obtains a complete path from cause to action and then to continued life.

### 5.3 The different responsibilities of ordinary repair and same-source law revision

Restoring a route or removing capture can restore A's continuation under the current law. Ordinary repair preserves the old law, responsibility lineage, and inherited responsibilities, produces complete write-back, and makes the following run actually use the target program supplied by this disposition.

Same-source law revision performs a different task: it obtains grounds from within this failure and revises the old law that has precisely failed. It requires failure on the same responsibility row, installed revision authority, a new expressive form, and the revision's first write. The original responsibility must also enter the revised arrangement. Zero capacity cannot supply these grounds by itself.

The policy rupture at depth zero supplies two existing processing coordinates. The ordinary coordinate reads the original installed disposition and generates ordinary repair with its successor. The revision coordinate reads the original inquiry's exact-failure resolution and generates same-source law revision with its successor. The two constructions share the rupture's source and each retains its own output. Section 6.3 proves the difference between the results from the successor structures themselves.

### 5.4 Refusing a submission while retaining a way forward for its bearer

Institutions also encounter authentic submissions that belong to the wrong source position. Consider a finite external proposal sequence supplying a candidate complete payment \(a_i\) to each node \(i\), while the node recognizes its own original payment \(q_i\). Acceptance requires an exact match between \(a_i\) and \(q_i\). Submitting node one's real payment to node zero gives a definite failure: adjacent payments have different actual boundary identities, so \(q_0\ne q_1\).

Refusal applies to the external candidate submitted to the wrong node. The node also has its own generated payment, together with the bearer's standing and service associated with it. Continuing along these original relations preserves both source recognition and A's capacity to continue.

**Proposition 5.4 (First refusal and recourse through the original payment).** For every initial source cycle and finite external proposal sequence, if the set of failing nodes is nonempty, its least element \(r\) is the unique first refusal. Extensions preserving that prefix retain the same first refusal. External acceptance at \(r\), and processing operations dependent on it, are empty. The node's original canonical execution and actual successor nevertheless exist, and earlier effects are preserved. The original payment already present at the same node generates ordinary repair, preserving the original bearer's standing and producing an actual successor enabling genuine exit. This successor differs from the successor of the original canonical revising legislation. At every finite recursion depth, submission of an adjacent node's payment supplies such an actual refusal and recourse.

**Proof.** A finite nonempty failure set has a least element \(r\). If two nodes were first failures, their minimality would constrain their order in both directions, so they would be equal. First failure depends only on earlier matches and the current mismatch; preserving the prefix preserves this conclusion. Once external acceptance is empty, any processing operation that must first obtain a witness of that acceptance is empty as well.

The node's original execution uses its own generated \(q_r\), independently of the mismatching external candidate. Acceptance of \(q_r\), complete legislation, and the actual successor therefore still exist. The original recurrence preserves generated effects node by node, so refusal of an external proposal cannot retroactively change the paid prefix.

Next take the actual service authority from the replay already present at node \(r\), and let that authority determine the repair depth \(d_r\). Lawful transport already connects the original payment to the periodic payment at this depth while retaining the source identity of its root event. The original repair program supplies an exit continuation at depth \(d_r\); the lawful transport above connects it to the original payment. Its responsibility entry comes from the original bearer's existing institutional standing; no bearer is selected anew. The repair and independent processing operation jointly supply complete write-back, an actual successor enabling genuine exit of capacity one, and the following visit \(v_{d_r+1}\).

The existing construction also distinguishes the two successors. The current-state carrier of ordinary repair is a singleton type, whereas that of the original revising legislation is the type of natural numbers. Equality of the complete successors would require equality of these carriers, contradicting the fact that one has one element and the other is infinite. Appendix A.5 gives the common packaging of both ends and the complete type transport. The adjacent-payment mismatch first fails at zero, and the construction above applies at every finite recursion depth. ∎

Refusal identifies which submission failed; the original payment determines how A can still continue. Ordinary repair obtains its source from the payment and service already present at that node, preserving A's standing in relation to the original responsibility and actually carrying him towards the next exit.

![First refusal and continuation through the original payment](figures/04-refusal-en.svg)

Figure 4. A payment submitted to the wrong node can be real without matching the current node. Empty external acceptance, continuing execution at the original node, and ordinary repair generated from the original payment can hold at the same node. Recourse obtains its source from the original execution and payment.

### 5.5 How a bearer's exit becomes an actual course of life

For worker A actually to leave, the institution must connect three questions across time: who authorizes A's action at this occurrence; whether the action changes the original relation; and which services A can use afterward, with whom continuing to handle the original responsibility. The exit conditions established above now enter an actual execution chain.

Write \(o\) for the old-visit parameter, \(a\) for the source index, and \(i\) for the beginning of this lifecycle. Let \(e_0,e_1,e_2,e_3\) be the four occurrences generated by the original program at \(i,i+1,i+2,i+3\), and let \(p_0,p_1,p_2\) be the complete payments belonging to the first three occurrences. These subscripts denote lifecycle stages. Each stage has its own provenance, whole-ledger update, and actual service occurrence. The stages do the following work.

| Stage | Actual content obtained at this occurrence |
| --- | --- |
| \(e_0\) | A's exit action has the payment's own root read and source authority; the payment generates the next occurrence. |
| \(e_1\) | The new occurrence reauthorizes the same leave action. A executes it, the original employment relation changes from employed to released, and the original work option is lost. |
| \(e_2\) | The executed payment's successor supplies continuation outside the role. The continuation action remains usable, with every essential-service channel, external responsibility's provenance, and its independent processing operation. |
| \(e_3\) | The payment used by that continuation generates a further occurrence, whose services, responsibility, and successor retain their actual sources. |

**Theorem 5.5 (The complete lifecycle of actual exit).** For every old-visit parameter \(o\), source index \(a\), and lifecycle starting index \(i\), the four-stage object and its three payment edges exist, with
\[
 \operatorname{next}(p_0)\simeq e_1,\qquad
 \operatorname{next}(p_1)\simeq e_2,\qquad
 \operatorname{next}(p_2)\simeq e_3.
 \tag{5.5a}
\]
Here \(\simeq\) denotes exact dependent equality in the original occurrence types. The first stage's target payment is the second stage's executed payment; that payment's successor is the source occurrence of continuation outside the role. The next payment continues to use that occurrence's own responsibility, services, and whole-ledger update.

The lifecycle satisfies an exact characterization. Let \(R_i(c)\) be the contract fixing this temporal chain, the bearer's actual action, continuation outside the role, external responsibility, and all service successors at the same action code \(c\). Let \(S_i(c,j)\) require that \(c\) belongs to the original action inventory, has continuation outside the role, is nonidle and uncaptured, and has a payment from the same source and a route to the original program's \(j\)-th actual service. Then
\[
 \text{complete exit lifecycle}(o,a,i)
 \quad\Longleftrightarrow\quad
 \exists c,j\; S_i(c,j)\land R_i(c).
 \tag{5.5b}
\]
The contract \(R_i(c)\) contains all three actual payment edges; it is not a promise to supply them later. Appendix E.3 expands every component and the reconstruction in both directions.

All four stages have the same leave-action readout. Yet both the map from stages to outer authority occurrences and the map from stages to actual service occurrences are injective. The action code therefore cannot recover the occurrence at which it acquired authority. Replacing the capture condition by full capture preserves the chain's payments, actual employment loss, exit interest, bare future outside the role, external responsibility, and service successors, while making actionable exit renewal empty.

*Proof.* The original payment first generates the target at \(i+1\). That target reads A's action authority anew from its own root occurrence and executes the action as the bearer's own power to leave. Its relation role changes from employed to released, so this step effects an actual change in the relation. The executed payment's actual successor reaches \(i+2\). The relation here is already independent of employment: both source and target roles are independent, the phase is zero, and the leave code has a witnessed continuation that is nonidle and uncaptured. This new relation supplies continuation; the original employment loss remains in the preceding execution.

At \(i+2\), the complete execution at this stage uses the payment write belonging to this occurrence. The write supplies source ownership, an independent root processing operation, actual settlement, and the next occurrence together. Each original service channel uses a service witness from this same payment. Taking the write's successor produces \(e_3\), establishing the three interfaces in (5.5a).

Given the complete lifecycle, take the feasible edge in its actual exit renewal. This yields the service, route, and payment conditions for the same \(c,j\); together with the retained temporal contract, these give the right-hand side. Conversely, assemble the given service, route, nonidle, and noncapture conditions into that actual edge to obtain exit renewal, then combine it with \(R_i(c)\). This reconstruction uses the supplied material directly and does not invoke a lifecycle object already assumed to succeed.

The original root occurrence's actual position increases with \(i+s\). Equal authority at two stages would yield equal positions and hence equal stages. The original injectivity of actual service occurrences gives the second result. The constant leave code consequently has no left inverse recovering stages. The full-capture branch retains the temporal contract but rules out its only usable leave code outside the role: the idle code fails the nonidle condition, and the work code has no continuation in the independent relation. Hence no feasible exit edge remains. This proves the theorem.

Exit thus acquires a complete temporal structure: A changes the old relation, obtains continuation in a new one, and leaves the original responsibility traceable across that change. By preserving these connections at each stage, an institution turns an authorized departure into a life that can continue.

### 5.6 How a response preserves independent action after refusal

After A refuses to continue the old relation, keeping a service on a list is insufficient. The institutional response to that action must leave A able to use the continuation independently. The original program therefore installs the response directly in the target payment. The response is indexed by A's own leave action, obtains its bearer from the payment's root read, and retains proof that the action is uncaptured. The formal content of “after refusal” here is this structural response to the indexed action; Theorem 5.5 establishes actual execution of the exit and the life that follows.

**Theorem 5.6 (Structural anti-retaliation).** For every \(o,a,i\), the renewed target payment generates a response with fixed provenance. Its action is exactly A's original leave action, and it retains all of the following:

1. The respective sources of the bearer's power to leave and a separate controller's power to terminate, the actual employment loss, and the distinction between controller and worker.
2. Actual fulfillment on every original essential-service channel, that channel's independent processing operation, and the actual successor of the same payment.
3. Source ownership and the independent root processing operation for external responsibility, together with the payment's own continuing generation of the next occurrence.

For this same leave action, capacity is \(1\) under the original noncapture geometry and \(0\) under full capture. Four exact retypings that retain the original target payment and response but report its action as captured—policy, service, administrative, and employment retypings—are empty. For every Boolean administrative labeling of the original occurrence domain, the label readout can recover neither the occurrence nor the corresponding actual-service authority.

*Proof.* The target payment's response projection first supplies a root read. The bearer is obtained from this read, and the leave action from that bearer. All three projections belong to this target payment. The response action therefore equals the payment's exercise action, and its noncapture proof applies directly to that action. Each service channel's processing operation likewise reads the target payment's actual exit and returns its actual successor to the payment's successor. External responsibility is supplied by the same payment's source ownership and root processing operation. A replacement service list or administrative judgment cannot substitute for these connections established by the same payment.

Each of the four anti-retaliation counterproofs retains the original positive response and adds the assertion that this same response action is captured. The response's noncapture proof immediately contradicts that assertion. The full-capture comparison branch does capture the leave action, and its original capacity calculation gives zero. It exhibits the institutional condition on which the protection depends.

For administrative labels, compare the source and target occurrences. Whatever labeling function is chosen, the old administrative restriction readout is the same, while the authority positions and actual service occurrences are strictly different. A left inverse recovering occurrences, or a factorization recovering authority from the label readout, would require the same readout to recover two different authorities. This is impossible. The theorem follows.

The structural anti-retaliation test locates protection in the connections between the original payment, action, and services. Once the same response retains evidence that A's action is uncaptured, policy, service, administrative, and employment retypings must preserve that fact.

### 5.7 Tenure and mandate have their own exits

Employment is one case of exit from a relation. Loss of standing in a tenure relation and termination of a mandate have their own sources, roles, and original responsibilities. For A to continue living across these changes, the required bridge is a common bearer generated by the source: the subjects in different relations connect through this bearer to payment, services, and exit, while their role changes remain determined by their original relations.

**Proposition 5.7 (Two nonemployment relation exits).** For every original cycle input, observer parameter, and depth \(d\), the original constructions supply the following two complete instances.

**Tenure.** The original relation seed generates the relation's action power, nonzero phase, and loss of the relevant entitlement; the original payment purpose identifies this relation. Its subject and the exit worker have the same source bearer. The actual root law admits the relation's coordinate exactly once. The finite exit constitution at the same depth supplies, for one action and one service slot, continuation outside the role, a source-backed payment, an actual route, external responsibility, services, and a future. Full capture retains the nominal transfer but makes exit renewal empty.

**Mandate.** The original restored power, renewal phase, and held role generate the source of the next actual action. A fixed sequential action executes from this source, producing lost power, the exit phase, and the exited role at its target; the original mandate responsibility enters a terminal archive. The action's source occurrence connects exactly to the root occurrence of the payment embedded in the depth-\(d+1\) constitution, and its occurrence presentation transports it into the target's original payment restriction. The target performs the first whole-ledger write and generates both its first-write successor and the macro successor actually adopted. It also retains the depth-\(d+1\) exit material, root-law transition, same-source law revision, and compatible future birth.

*Proof.* The two bearer provenances in the tenure instance both lead to the original parent bearer: one through the tenure relation's original payment counterparty, the other through the original exit worker. Their equality yields the common-bearer equation. Eliminating the operational incidence of the same finite constitution then supplies one action and one service slot, with service, route, payment, responsibility, and future obtained together. Exact-once coverage in the actual scenario of the root law supplies the relation's admission point.

For the mandate instance, first take the next visit generated by the original held standing. It is dependently equal to the root occurrence of the next-depth constitution payment. The sequential action's occurrence presentation then sends it to the target payment. This bridge thus contains an actual source continuation and a lawful target transport. The action receipt retains the prior standing trace and gives, component by component, lost power, exit, the exited role, and the terminal position of the original responsibility. The target's complete execution generates the first-write successor, and the same target's response and successor generate the macro successor. Reporting the target as restored, renewed, or held would respectively identify lost with restored, exit with renewal, or exited with held. Each identification is impossible. This proves the proposition.

The common bearer carries continued life across a change of relation while retaining the original relation's responsibility. Tenure and mandate each complete exit through their own roles, responsibilities, and actual actions; their source bearer supplies the connection between relations.

The original mandate exit also generates a definite later occurrence. The next institutional visit actually reached by the exit action retains the old responsibility's terminal status and has its own complete payment. A second actual action starts at precisely this visit, retains the exit history in the successor history, and generates a new controller from the maximum-controller fold of that history. The office relation persists while its controller and responsibility change.

More precisely, for every original cycle and all the parameters of Proposition 5.7, the old responsibility remains terminal at the post-exit visit, while the successor acquires restored power, a renewal phase, and a held role. The same one-slot ordinal contains the old and new responsibilities in their respective representations, but the responsibilities are distinct: the new one enters a live state through admission, and the original terminal archive has no reopening event. The succession action also supplies its own target complete payment, first whole-ledger write, and exact actual successor, together with services, routes, continuation outside the role, external responsibility processing, and joint regeneration at depth $d+2$ of the next original cycle.

The proof generates the successor from the old history. Let $m$ be the largest controller seed in this actual history. The new seed is $m+1$, so it differs from every earlier controller in that history. Uniqueness of the maximum fold ensures that every evaluator satisfying the same occurrence recursion yields this result. If the old and new responsibilities were equal, their bearers would also be equal, contradicting the new seed's position beyond the old history. The exit action's actual successor is exactly the source of the succession action. Lawful presentation transports supply the connection from payment to post-exit payment and the connection from the post-exit occurrence to the succession target payment. The first-write successor and the next institutional visit retain their respective types. Appendix F.7 lists the original seed values and gives the complete continuation proof.

The construction allows continuity of the relation, personal exit, and admission of new responsibility to coexist. The office continues, the old bearer's terminal responsibility retains its place in history, and the successor assumes a new responsibility from its own source.

### 5.8 What basic income, public services, and paid jobs each provide

A needs income and services that can actually be used; A may also choose to keep working in a job. These arrangements perform different tasks in the exit contract. Basic income supports renewal of purchasing-power standing outside the former role. Basic public services provide actual service positions, capacity, and routes. Paid jobs organize labour and remuneration within particular relations. All three may serve the same person, while each retains its own institutional task.

**Proposition 5.8 (Actual separation of income, services, and jobs).** For every original cycle entry and both prescribed finite observation and recursion parameters, there is a later constitutional point where positive role-external exit, fulfilled material service, and job standing in a new role coexist. Job standing in the ended employment is empty. New-role job standing coexists both with positive exit and with zero exit under capture. The new material service has its own occurrence, budget debit, and fulfilment, while the old paid slots are retained.

The original two-slot material-admission fibre remains empty. Neither positive exit nor new-role job standing alone therefore constructs an object in that old fibre; the new material service and new-role job standing likewise cannot alone construct exit in the captured geometry.

**Proof.** Take the constitutional point generated by Theorem 4.3 and the full platform admission of the same original cycle. The former supplies positive exit, emptiness of captured exit, ended employment, and new job standing. The latter supplies the new material service, original budget debit, fulfilment, and preservation of old slots. Together they form the stated object. Every non-substitution result has an actually inhabited source and an exact empty target: a putative substitution function applied to the constructed source object would inhabit the empty target, a contradiction. Appendix E.11 gives all types and their joint assembly. ∎

If money arrives but the only route remains under the former employer's control, A still faces the third zero. If the route is open but no actual service is available, payment has yet to become this usable capability. Conversely, when public services are already provided, A may still need purchasing power to wait, move, or start again. Theorem 5.1 therefore connects these arrangements to the same bearer, the same continuation, and the same actual service position. Theorem 5.5 then traces how A actually exercises exit and continues paying outside the role.

“Unconditional” has an explicit institutional direction here: basic standing and continued access to life should be renewed without requiring retention of the old job, proof of poverty, or a moral-worth score. The institution still has to identify the bearer, provide services, and allocate costs. We choose to remove those eligibility gates because, when basic life becomes a means by which the former controller can withdraw continuation, nominal departure is again subject to the old relation.

A job guarantee can offer paid participation; an exit guarantee gives participants the capacity to end that relation. Proposition 5.7 extends the issue to tenure and mandate: the relation can end while the bearer and original payment retain an actual continuation. Institutional design must therefore explain both how to make participation worth choosing and how participants can continue living after they leave.

### 5.9 From shortest actual recovery to viable continuation

A repair authorization alone does not provide worker A with a life after repair. The institution must answer two connected questions: which actual operations lead from this failure to a viable state, and whether another continuation remains available once that state has been reached. The first requires an actual repair path; the second requires paths that compose.

We use the complete domain portfolio defined in §5.2. Viability requires a complete portfolio, an uncaptured leaving action, and a viable disposition generated by the original economic occurrence and compatible with that portfolio. At every depth $d$, the original construction supplies two failed configurations. $M_d$ retains one service and positive exit capacity but lacks health service; $C_d$ retains the complete services but subjects the leaving action to full capture. Their respective actual repairs reach $V_d$, the complete, uncaptured configuration at actual visit depth $d+1$. Recovery time below counts actual operation edges.

**Theorem 5.9 (Shortest recovery, literal prefixes, and viable continuation).** For every canonical foundation parameter $h$, original depth $d$, and requested finite number $n$ of continuation steps, the original program generates a service-restoration edge $a_d:M_d\to V_d$, a capture-removal edge $b_d:C_d\to V_d$, and a renewal edge $r_d:V_d\to V_{d+1}$. The authorities of these three operations are pairwise distinct. Each repair edge has length $1$ and is no longer than any legal candidate path from its respective source carrying a viable target. Their minimal recovery times are equal, but the time readout has no left inverse recovering the original repair operation.

From the first recovery target, the original program generates a path $\rho_{d,n}:V_d\to V_{d+n}$. Prefixing either repair edge gives a path in the same actual action graph, with
\[
 |\rho_{d,n}|=n,\qquad
 |a_d\cdot\rho_{d,n}|=|b_d\cdot\rho_{d,n}|=n+1.
 \tag{5.9a}
\]
For every $k\leq n$, there is an exact suffix $\sigma_{d,k,n}$ such that
\[
 \rho_{d,k}\cdot\sigma_{d,k,n}=\rho_{d,n},
 \qquad \operatorname{Viable}(V_{d+k})\ne\varnothing.
 \tag{5.9b}
\]
This is equality of actual paths: the continuation generated for the shorter request is literally a prefix of the continuation generated for the longer request.

The structural rent capture generated by the original tenure relation also enters this result. It retains payment, routes, actual services, the unsettled responsibility, and its independent processing operation, while making the feasible exit-edge fibre of every existing essential domain empty. Its actual capture-removal edge $b_d$ reaches the same minimal recovery target and composes with viable continuation of every requested finite length.

**Proof.** A complete portfolio at $M_d$ would supply a health component, contradicting the original empty health-service fibre. A viable object at $C_d$ would require the leaving action to be both captured and uncaptured. Both sources are therefore nonviable. A candidate path of length zero identifies its target with its source, contradicting the target viability carried by the candidate. Every legal candidate has at least one edge. The edges $a_d,b_d$ are generated from the existing repair receipts and each has exactly one edge, so each attains the lower bound over all candidates.

The two edges have different sources and operational authority. Service restoration uses the actually installed health-service operation; capture removal uses the actually installed exit repair. Their selected responsibility rows both commute with the original whole ledger and reach the same successor under the existing law. The two operations belong to different summands of the repair-action sum type and are therefore distinct. A left inverse of the time readout would turn their common value $1$ into equality of the operations, a contradiction.

Now construct $\rho_{d,n}$ recursively from the actual renewal edges. At zero steps take the empty path; to add one step, append $r_{d+n}$ to the endpoint already generated. The renewal receipt joins the current viable portfolio's payment occurrence to the actual service occurrence of the next update and supplies the next viable target and exact root successor. The length formulas follow by recursion. Fixing $k$ and inducting on $n\geq k$, append the same final edge to the suffix at each step; this gives the literal equality in (5.9b). Domainwise emptiness under structural rent capture also has a direct proof: a feasible edge in any domain would provide an independently exercisable leaving action, contradicting full capture. The bearer, settlement, and independent processing operation in the original capture responsibility are then retained by the same capture-removal receipt. Appendix F.2 gives the complete parameters and occurrence joins. $\square$

Repairability thus acquires a checkable temporal structure: the institution supplies a shortest actual action reaching viability and continues to generate viable life for every finite request. The quantifiers cover all legal candidates in the original action graph. That graph records service restoration, capture removal, and viable renewal, with the two given failed configurations as the respective starting points.

### 5.10 Full-domain readout and source-generated repair

A shortest recovery path tells us how to continue; diagnosis must also identify which repair the present failure requires. Expanding an exit-capacity number to include reachability in every existing domain can still leave this question unresolved.

Let \(\mathcal D\) be the essential-access relation authorities already generated by the original program, including the witnesses for tenure and health-service relations. At depth \(d\), the original failure-source type \(\Omega_d\) contains capture through control of a tenure relation and an uncaptured route interruption. For a source \(x\), read its exit capacity together with its entire domain-reachability set:
\[
\rho_d(x)=
\bigl(K_d(x),\{D\in\mathcal D\mid
\text{source }x\text{ has an actually feasible exit edge in }D\}\bigr).
\]
Write \(r_d(x)\) for the canonical repair generated from this source by the original installed repair rule. The two original sources both read as \((0,\varnothing)\), although the former requires capture removal and the latter route restoration.

**Theorem 5.10 (Diagnostic impossibility for full-domain readouts and recovery from sources).** For every \(d\in\mathbb N\), \(\rho_d\) has an exact source kernel with distinct sources, the same visible readout, and different canonical repairs. There is also a reversible symmetry of the whole of \(\Omega_d\) that preserves \(\rho_d\) and exchanges the two repair values without fixing either. Consequently, canonical repair does not factor through \(\rho_d\); no left inverse recovers every original source; and no faithful authority reconstruction, natural section, or natural authority reconstruction exists with respect to the original admissible symmetries.

More generally, for every output universe, every output type \(Y\), and every readout \(q:\Omega_d\to Y\), if a function \(f\) satisfies
\[
q=f\circ\rho_d,
\]
there is no decoder \(g:Y\to\operatorname{Repair}\) satisfying
\(g(q(x))=r_d(x)\) for every original source.

Read the existing failure kind \(\phi(x)\) from the source. This is an input the original repair rule already obtains before issuing a repair. The refined readout
\[
\widehat\rho_d(x)=(\rho_d(x),\phi(x))
\]
preserves the coarse observation, is injective on \(\Omega_d\), and allows the original installed rule \(R_d\) to realize
\[
r_d(x)=R_d(\phi(x)).
\]
Thus authority factorization exists after refinement. Every original source also generates a proof-carrying geometric plan for its canonical repair: the resulting capacity is \(1\), and, within the original candidate-repair type, a repair is effective if and only if it equals that canonical repair.

**Proof.** At the capture source, the same capture relation blocks exit edges in every domain. At the route-interruption source, the route receipt required in each domain is empty. Both full-domain sets are therefore empty, and both capacities are zero. The original repair rule produces capture removal and route restoration respectively, which are distinct. If \(f\) and \(g\) existed as above, equal \(\rho_d\)-values would give equal \(q\)-values through \(f\), then equal repairs through \(g\), contradicting the different original repairs. A left inverse recovering sources would likewise equate the two distinct sources.

Exchanging the two source constructors and their original proofs gives an involution of the entire source type. Canonical repair is exchanged while the coarse observation is preserved. If a natural section chose a source over the reachable common visible value, naturality would require that source to be fixed by the exchange. Its repair changes under the exchange, so it cannot be fixed.

For the positive refinement, equal \(\widehat\rho_d\)-values give equal failure kinds, hence the same source constructor. Proof irrelevance identifies its proof payloads, so the sources are equal. The installed repair rule directly uses this failure kind, yielding the required factorization from the source rule. Evaluating the two repairs on the two source constructors gives capacity \(1\) for the canonical choice and \(0\) for the other choice, establishing the proof-carrying plan and the exact effectiveness criterion. Appendix F.3 supplies the full types, the naturality contradiction, and the direct processing operation. ∎

Even listing every domain can make two failures appear to be the same. What makes repair identifiable again is the failure kind retained in the source. It separates objects conflated by the coarse observation and is used directly by the original repair program to supply the canonical choice and its effectiveness. The next section obtains witnesses for both kinds of source from actual execution.

### 5.11 How actual support produces probability readouts

The kernel above consists of more than two abstract labels. At every depth the original program generates two actual materials: capture removal at the UBI coordinate and route restoration at an independent route coordinate. Denote their dependent occurrences by \(a_d^{\mathrm c}\) and \(a_d^{\mathrm r}\). They share the exact root event, source entry, whole-ledger write-back, and actual next state, while retaining distinct projections, their branch-specific processing operations, and different repairs.

**Theorem 5.11 (Actual support, finite traces, and refined probability).** At every depth \(d\), each source in \(\Omega_d\) has its actual installed witness; actual support therefore equals all of \(\Omega_d\). Both endpoints of the same-visible/different-repair kernel belong to this support jointly. Route restoration cannot be retyped as an actual repair of the capture-removal coordinate, and the converse retyping is also impossible.

For every finite horizon \(h\), the original construction generates a dependent trace \(T_h\) containing each canonical occurrence \(a_d^{\mathrm c},a_d^{\mathrm r}\) exactly when \(d<h\). This trace has no duplicates and has length \(2h\). Its root-event readout stamped with the original failure kind also has no duplicates, whereas the bare root-event readout has a collision at every positive horizon \(h>0\). The unit counting measure generated from \(T_h\) assigns each actual member weight \(1\) and has total mass \(2h\).

Let \(E\) be the event that the original installed repair is capture removal. Fix any \(d\), and take the fold originally constructed for that depth, whose horizon is \(h=d+1\). Let \(e_d\) be the exact root occurrence carrying its original visit, and query the common coarse readout
\[
y_d=\bigl(e_d,(0,\varnothing)\bigr).
\]
The coarse observation fibre is exactly
\([a_d^{\mathrm c},a_d^{\mathrm r}]\), and its event fibre is exactly
\([a_d^{\mathrm c}]\), so the readout is the defined value \(1/2\). This shared probability readout still cannot completely recover repair authority.

After adding the same original failure kind, the two query fibres become singletons, the original repair rule again factors repair authority, and
\[
\widehat P_d(E\mid \widehat y_d^{\mathrm c})=1,
\qquad
\widehat P_d(E\mid \widehat y_d^{\mathrm r})=0.
\]
The original zero-horizon coarse fold returns the undefined value \(\mathrm{none}\) for every query, since its fibre is empty.

**Proof.** For each of the two original source constructors, take its originally installed actual branch. Their roots, ledgers, and next states come from the complete execution at the same source root, giving equality of these three readouts. Processing operations and actions retain their respective branch types, and repairs differ. Thus every original source has an actual witness.

Map \(0,\ldots,h-1\) to the actual occurrences of the capture branch and append the corresponding route-branch occurrences to obtain \(T_h\). Within each branch, projection to depth proves injectivity; across branches, the failure kinds differ. The resulting list has length \(2h\) and no duplicates. Forgetting failure kind identifies the exact root events of the two endpoints at the same depth; retaining the kind separates this collision.

Unit weights make an event's mass equal to the length of its filtered list. The exact-root coordinate in \(y_d\) excludes all other depths, while the original full-domain readout retains both endpoints at depth \(d\). Only the capture branch belongs to \(E\). The fibre mass is therefore \(2\), its event mass is \(1\), and normalization yields \(1/2\). After refinement each fibre has mass \(1\), with event masses \(1\) and \(0\). The zero horizon contains no actual members, hence has no positive fibre mass to normalize and returns \(\mathrm{none}\). Appendix F.4 proves the counting, provenance preservation, and fold identities in full. ∎

The value \(1/2\) comes exactly from unit counting of the two actual members at the specified root event. Adding the failure kind leaves the measure, the queried event, and the repair program unchanged. What changes is the information retained by the observation: each member returns to its own singleton fibre, making repair authority distinguishable again.

### 5.12 Dark twins: the institution keeps running, yet A cannot leave

The transfer has arrived, services have actually been provided, and someone continues to handle the responsibilities. Can such an institution still trap A? The preceding constructions answer yes. More troublingly, an institution may retain the complete ledger and actual next state yet choose the wrong repair from a readout that has lost the source of failure. Keeping a procedure running and enabling those subject to it to refuse the former relationship are two requirements that must each be realized.

We call a comparison that preserves a common source and the other specified conditions, while making one load-bearing condition fail, a **dark twin**. It tests necessity: the payment remains this payment, the bearer remains A, and the original responsibilities and their handling remain in place. What can still be missing that prevents A from leaving? Another comparison tests diagnosis: two actual branches leave the same coarse record but require different dispositions. The following three results each fix their own common material.

**Proposition 5.12 (Institutional obstructions from missing conditions and coarse observation).** The source construction has the following counterexamples.

1. **The other institutional operations do not supply a missing route.** For every depth \(d\), the complete route-deletion type \(B_d\) has an actual inhabitant. At the same root occurrence, the construction retains actual payment, payment standing, the tenure relation, noncapture, actual service, the original responsibility row, whole-ledger write-back, independent handling, and the actual successor, together with the other seven installed renewal operations. The source-route type \(T_d\) that must be restored is empty, as is the source type of actionable exit. Hence
   \[
   B_d\ne\varnothing,
   \qquad T_d=\varnothing,
   \qquad (B_d\to T_d)=\varnothing.
   \]
   The original repair generates a target route at the next visit; the source and target visits are strictly distinct.
2. **Payment and a role-external future do not supply uncaptured exit.** For every original visit, source index, and lifecycle index, the actual paid-exit lifecycle has a full-capture counterpart. It preserves the original payment chain, purchasing power standing, actual departure from employment, employment loss, exit interest, a bare role-external future and its relation-level actionability, external responsibility and its handling, services, and the actual successor, while the type of actionable exit renewal is empty.
3. **A common root, ledger, and successor do not determine a common repair.** For every depth \(d\), the two actual branches in §5.11 share the exact root occurrence; their source entries and whole-ledger write-backs agree in the precise sense required by their original dependent types, and their actual next states are equal. Their projections and repairs differ. Both branches have the full-domain readout value \((0,\varnothing)\). For any output universe, output type \(Y\), and function \(f\), put \(q=f\circ\rho_d\). There is no decoder \(g:Y\to\operatorname{Repair}\) satisfying
   \[
   g(q(x))=r_d(x)
   \]
   for every original source \(x\in\Omega_d\).

**Proof.** For the first part, take the actual route-restoration source of §5.1. From depth \(d\), it generates a complete object \(b_d:B_d\) and separately regenerates seven operations at that same visit: proof-carrying renewal, basic payment, recognition witness, mandate, essential service, common clearing, and clearing backstop. Each has its own actual answer and successor factorization, while the source-route receipt remains absent. If a reconstruction \(u:B_d\to T_d\) existed, \(u(b_d)\) would inhabit the empty type, a contradiction. Any actionable exit at the source would also have to supply that route and is therefore impossible. The target route comes from the repaired visit \(d+1\). If the two visits were equal, reading their depths would give \(d=d+1\), a contradiction. Using its receipt for the next continuation is precisely what the repair accomplishes. Appendix F.10 gives the complete preserved fields and direct handling.

For the second part, take the positive lifecycle of §5.5 and its full-capture counterpart. The counterpart retains, component by component, the original objects used for payment, employment, interest, external responsibility, and services. Suppose there were an actionable exit renewal, and take its role-external continuation action. The original future relation together with the non-idleness condition forces that action to be “leave.” Full capture captures that very action, whereas actionability requires it to be uncaptured: a contradiction. Actual payment and responsibility can therefore coexist with an empty exit-renewal type. Appendix E.3 gives the complete lifecycle and this counterpart.

For the third part, take the actual remove-capture branch and the independently installed route-restoration branch. Both obtain their source entry, whole-ledger write-back, and next state from the complete execution of the same root. Their installed operations still require, respectively, removal of capture and restoration of the route. Capture empties the independent exit edges in every domain; route outage empties the route receipts required in every domain. Their \(\rho_d\) values are therefore equal. Every \(f\) sends equal inputs to equal outputs, and every \(g\) must assign the same repair to that output. It cannot equal two distinct values of \(r_d\). Both endpoints here lack exit and require different repairs; they are distinct actual coordinates on one root. Appendices F.3–F.4 give the source kernel, actual support, and complete transport. ∎

The first part proves that a route requires its own actual source. The second locates the difference made by power in a continuation action that already exists. A has actually left the former job, yet B can still control A’s use of the conditions of life. Payment and services remain real; A’s ability to refuse B has not been secured. Pettit locates domination in a capacity for arbitrary interference, while Anderson asks how private power organizes workers’ lives [@Pettit1997; @Anderson2015]. The formal contribution here is a counterpart that preserves the other actual material: when B captures this continuation action, actionable exit renewal becomes empty; once capture is removed, the original repair connects to viable life.

A needs to be able to use the service that has already been paid for.

The third part turns to how an institution understands its own failure. The two branches share a root, ledger, and successor. If the institution reads only capacity and the reachable set across all domains, it still merges removal of control and restoration of a route into a single problem. The proposition quantifies over every subsequent operation that factors through this coarse observation. Changing the report format, adding indicators calculated from the same readout, or applying more elaborate computation all inherit the merger. Sen distinguishes possession of resources from actual capability. Here we further distinguish an accurate capability readout from the source information needed to identify failure and choose a repair [@Sen1979].

Source refinement identifies the way out. The original failure kind is already present in the inputs to the two actual operations. Retaining it separates the sources, and the original repair rule again yields the uniquely effective choice for each. An institution that repairs failure must therefore preserve distinctions that matter for responsibility and bring them into actual action. The respective sources of the bearer, the control relation, and the service route supply the material such judgment needs.

Section 7.8 brings the same question to progress budgets. After recognizing responsibility and revising the rules, can an institution recover progress capacity merely by rearranging the old ledger? Proposition 7.8 quantifies over every conservative sequential target of the exhausted source ledger. With no new row at admission and no increase in any row’s budget, every row of the first successor satisfies \(0\le B'\le0\). The actual revision has already preserved a bearer and an answer for the residual; new positive progress still requires a source that supports it. Recognizing responsibility and restoring its capacity for strict progress each require their own actual grounds.

These obstructions explain why the total theorem jointly undertakes generation, disposition, exit, and regeneration. Root law makes each write account for authority and responsibility. The exit contract enables A to refuse the former relation of control in practice. Retaining sources enables the institution to identify the correct repair. Theorem 1.2 quantifies over every cycle of the original type, every position, and every lawful payment there: the complete contract passes with that payment into its actual target. Theorem 6.2 actually generates a joint regeneration object at every depth and proves that every object of that type retains six guarantees on the same payment. Theorem 6.3 makes that step’s actual successor precisely the entry at the next depth. Dark twins expose the gaps left by weaker guarantees, while the positive construction gives a way to realize the requirements together in one nonempty society.

## 6 Responsibility birth and same-occurrence regeneration at every depth

### 6.1 How continuing activity generates new responsibility

A's continuing activity raises the question of responsibility birth: how can a responsibility that did not previously exist acquire a source and a first payment, and enter a successor together with inherited responsibilities? A complete institutional program distinguishes sequential action from responsibility admission for this purpose.

Sequential action sends old open responsibilities into the target's initial responsibility set. Every initial target row has an old source, and distinct old rows retain distinct images. Responsibility admission expands the responsibility domain to
\[
R\sqcup D,
\]
whose left side preserves the original responsibilities and whose right side carries new responsibility. The new component is initially inactive and therefore has no new open row. Once activated, state \(s\) determines the new row natively. An actual step from the same source,
\[
s\longrightarrow t,\qquad B(t)<B(s),
\]
supplies its first payment. Here \(B\) is this new responsibility's own natural-number budget, so \(B(s)>0\) as well.

**Proposition 6.1 (The complete first write of actual responsibility birth).** For every fully installed program containing the actual admission step above, its generated execution produces a new responsibility row, its first payment, the successor after the first complete responsibility write, and the actual following visit generated by that successor. The original rows, responsibility content, and result projections are preserved. Every item in the target's initial open responsibility set either comes from an original row or is this birth row. The execution remains in the action class of Theorem 4.2.

**Proof.** The inactive new component has no witness of openness, while the old and new components occupy opposite sides of a disjoint sum. The new row therefore cannot find an original row in the complete old responsibility record that could serve as its predecessor. This also shows why ordinary transport, which requires every target row to have an old source, cannot accomplish responsibility birth by itself.

The activated state \(s\) supplies a witness that the new row is open. The actual step takes it toward \(t\), with strict budget decrease supplying the first payment. Every old row simultaneously obtains a transition receipt from the original evolution. Transport of all the old rows and the new row's first write together form this complete write-back.

Call the successor produced by this first complete write the **first-write successor**. Its common carrier combines the successor support already generated by the original root with the new state \(t\). It retains both sides' write-back and the destination of each row. The embedding of old rows is injective, and returning to the old observations yields the original result. The action's actual following visit is precisely the visit generated by this first-write successor. Finally, distinguish whether an initial row belongs to the old or new component. This exhausts the target's initial open responsibility set. The program binds this admission result as its action output, so new responsibility is born within the original action class, without adding a fifth kind of root-law authority. ∎

In the actual run, admission of new responsibility can proceed as reform under the original law, preserving the original observation types, observed values, and responsibility projections. Law revision is identified by an actually generated revision disposition, according to the branch the run uses.

### 6.2 How six guarantees belong jointly to this payment

After A leaves, services must continue, someone must bear the old responsibilities, and the counterparty's interests must also receive a disposition. For these requirements actually to hold together, ordinary repair, capture responsibility, and the repaired successor must use the same payment \(p_d\); the repair on which each of the latter two rests must be exactly the former. The following joint construction uses these two shared relations to connect six guarantees within one execution.

Let \(\Gamma_d\) be the following object type. Its three components belong respectively to the ordinary-repair carrier, complete capture-responsibility carrier, and actual repaired-successor carrier prescribed by the original installed constructions, and satisfy the two exact shared-repair relations above. The generating function accepts only \(d\) and constructs these objects from the original payment, relations, actual service, and successor program. Appendix B.8 gives the full definition.

The joint construction retains successors of two different types. A **responsibility post-state** gives the state of a responsibility after this fulfillment; it belongs to the complete payment and its independent processing operation. The **following constitutional visit** gives the actual starting point of the subsequent run; it belongs to the source root's temporal progression. The factorization installing this payment in the original root connects them.

For \(g\in\Gamma_d\), the six joint conclusions are as follows.

| Joint conclusion | Content retained by the same complete payment |
| --- | --- |
| Continuation of old law and responsibility lineage | The old law, responsibility lineage, and inherited responsibilities are preserved; the repair's actual successor agrees with its target program |
| Ordinary exit does not contract | Both the current uncaptured ordinary continuation and the following actual occurrence have an exit; in this construction \(K_d=K_{d+1}=1\) |
| Repair of the captured relation | The captured configuration's exit type is empty; the repair's target program is actually installed at the following visit and restores genuine exit |
| Retention of the residual bearer and processing operation | The original residual and bearer remain; the activated operation's responsibility post-state equals the original payment's responsibility post-state; the repaired successor also has its own root responsibility processing operation |
| Capacity for law revision at the successor | The successor retains the faithful route for law revision already constructed, together with the actual receipt that the original joint run used the same revision core at depth zero |
| Responsibility across actors | The protected interest of the actual counterparty actor, distinct from A, enters the disposition; settlement identity and the original source's responsibility incidence are preserved |

**Theorem 6.2 (Same-occurrence regeneration at every depth).** For every \(d\in\mathbb N\), there is a \(g_d\in\Gamma_d\). For every \(g\in\Gamma_d\), all six conclusions in the table hold jointly. For every foundational observation horizon \(h\) and every \(d\), the canonical society \(S_h\) actually retains and exports this joint certificate. The foundation horizon \(h\) does not restrict regeneration depth to values at most \(h\).

**Proof.** Given \(d\), the original program generates ordinary repair, complete capture responsibility, and the actual repaired successor from the payment at that depth. The two shared-repair relations hold by construction, giving \(g_d\in\Gamma_d\). Now take any \(g\in\Gamma_d\). It retains the same shared-repair relations, and all six conclusions below are read from this one joint object.

Ordinary repair uses the selected row \(\delta\) associated with this continuation in the original complete responsibility record. Row evolution preserves the old law, responsibility lineage, and inherited responsibilities, and generates the exact successor and target program. This gives the first conclusion. The current uncaptured exit geometry has only one nonidle action that can be paired with actual service, so its capacity is one. The actual occurrence following repair has its own service geometry and also has capacity one. Both ends therefore have genuine exit and satisfy \(K_d\le K_{d+1}\), proving the second conclusion. The current captured configuration removes the feasible exit relation. Repair installs the target program from this same disposition at the following visit, proving the third.

The capture settlement is exactly the settlement already opened by the original payment. Projecting its residual and bearer preserves both original objects. The original purchasing-power standing also retains an activated independent processing operation whose responsibility post-state equals that of the original payment. This payment's installation factorization from the same source and bounded update give the following constitutional visit. The repaired successor has its own root responsibility processing operation as well, proving the fourth conclusion.

The repaired successor retains the faithful map already constructed by the original revision gate, together with the receipt that the original joint run actually used the same revision core at depth zero. This gives the fifth conclusion. Finally, the original payment's counterparty acceptance evidence determines the protected interest and opposing obligation. The counterparty's source identity differs from A's, and the residual responsibility incidence belongs to the original source. This proves the sixth conclusion.

Every \(g\) obtains these six conclusions through its own relations of shared source. The construction of \(S_h\) actually invokes this joint processing operation and stores its result. The same certificate can thus be exported for every \(h,d\). ∎

### 6.3 The actual successor connects to the following occurrence

The successor produced by repair should become the actual starting point of the following run. For every pair of adjacent depths, we now check this connection: is the visit reached by one step precisely the entry through which the next step generates its occurrence?

Let \(v_d\) be the original root's visit at depth \(d\), and \(v^+(g)\) the following constitutional visit of regeneration object \(g\). Let \(e_R(v)\) be the occurrence generated by the original root at visit \(v\), and \(e(g')\) the root occurrence of the following regeneration object. The payment itself is indexed by its visit. Retain the visit together with its payment in a common carrier of occurrences, writing \(\widehat p_d=(v_d,p_d)\), so that the payment's complete occurrence identity is preserved.

**Theorem 6.3 (Exact continuation and the first policy rupture).** For every \(d\), every \(g\in\Gamma_d\), and every \(g'\in\Gamma_{d+1}\),
\[
v^+(g)=v_{d+1},\qquad
e(g')=e_R\bigl(v^+(g)\bigr).
\]
At the same time, \(\widehat p_d\ne\widehat p_{d+1}\): adjacent payments have different occurrence identities in the common carrier. The original policy rupture at depth zero also actually generates same-source law revision. The ordinary-repair successor and the law-revision successor sharing that rupture's source both exist and are distinct.

**Proof.** The original temporal recurrence supplies \(v_{d+1}\). The target visit of ordinary repair is precisely this visit under the same generating rule, proving the first equality. Every regeneration object at depth \(d+1\) generates its root occurrence from that visit. Substitution of the first equality gives the second. If the adjacent payment occurrences in the common carrier were equal, projecting their visits and then taking causal depth would give \(d=d+1\), a contradiction.

At depth zero, the actual policy rupture retains the same original payment, two actual service positions, and the comparison between uncaptured capacity one and captured capacity zero. Review under the original mother law connects this rupture to the exact-failure interface already installed at the same visit. Revision thereby obtains the same responsibility row specified by that failure interface and its existing authority. The original run actually uses this revision core. The revision's first write and migration of inherited responsibility also come from that same core.

Ordinary repair continues on the old root's support. The law-revision successor uses support expanded by an actual new direction. The old support has only two points. The revised support contains two distinct old positions and a position supplied by a new direction. If the complete successors were equal, these three distinct points could be injected into the old support, contradicting the impossibility of injecting three points into two. Appendix B.7 gives the three points and the required type transport. Finally, this policy revision at depth zero and the joint regeneration object retain the same ordinary repair and the same rupture occurrence. Actual law revision and the six regeneration conclusions therefore really are connected here. ∎

The original recurrence thus generates a regeneration object at every prescribed finite depth and carries the source and responsibilities retained by one step into the next step's actual entry. Each step has its own occurrence identity. The exact successor equality lets these distinct occurrences continue using the same chain of responsibility.

![Six regeneration conclusions on one payment and the entry to the following depth](figures/05-regeneration-en.svg)

Figure 5. The six guarantees use this complete payment jointly. The relation at the bottom connects repair's actual successor visit to the following depth. The following occurrence is generated by that visit and remains distinct from the current occurrence. Continuing capacity for revision and the same-source law revision actually performed at depth zero retain their respective witnesses.

### 6.4 Law revision and birth occur together beyond every finite stage

The preceding all-depth result preserves the six obligations carried by one actual payment. We now ask whether new law revisions and new usable futures continue to arise as we follow the successors actually generated. A recursive process answers this question. Step \(d+1\) uses the complete successor input output by step \(d\), regenerating payment evidence, revision, and the next step from that input rather than selecting a value from a separately prepared future table.

Let \(c_0\) be the original cycle input, \(b\) its boundary, and \(c_d\) the input at step \(d\). The input and boundary determine the lifecycle's starting index $i_0$. This step's index and the following input satisfy
\[
 i_d=i_0+d,\qquad
 c_{d+1}=\operatorname{nextCycle}(\operatorname{step}(c_d)).
 \tag{6.4a}
\]
**Cofinality** means that such a later point exists beyond every finite bound. A **joint step** consists of actual same-source law revision, continuation of the complete root law from source to target, and a compatible future generated by this payment at its target. The future's payment identity is supplied by this step's next payment; the step's source and target payments remain two adjacent occurrences.

**Theorem 6.4 (Cofinal law revision, birth, and an open run).** Fix any old-visit parameter, source index, boundary, and original cycle input.

First, for every observer parameter \(h\) and depth \(d\), step \(d\) generates a joint step. For every finite bound \(n\) and observer parameter \(h\), there is one and the same \(m>n\) at which actual same-source law revision, compatible future birth, and the complete root-law transition hold together:
\[
 \forall n,h\ \exists m>n:\quad
 \text{revision occurrence}(m)\land
 \text{compatible future}(h,m)\land
 \text{root-law transition}(h,m).
 \tag{6.4b}
\]
One may take \(m=n+1\). Its next input is exactly \(c_{m+1}\). The occurrence identity of the step's next payment is dependently equal to the actual payment of the target future, while the step's source and target payment occurrences are distinct. At every depth, the “unrevisable terminal constitution” object that retains the current constitution but deletes the already generated target root law, target constitution, and its lifecycle evidence is empty.

Second, the original full platform admission meets this cofinal process at its actual replay occurrence. Beyond every finite bound, there is therefore an actual point retaining that admission's provenance, the complete root law, revision, and compatible future. For every finite representation boundary, the original construction also generates two later occurrences with the same visible readout but different actual paths and service authorities. Their own two-slot representation requirement generates an exact failure, a same-source revision, a first write, and a shared successor. Within its same local runtime, every positive finite depth has an actual query, actual answer, and next visit; authoritative visits at different depths are distinct.

*Proof.* The one-step construction first reads the actual morphism and payment evidence retained by the current input. In its next generated replay pair, the current right replay becomes the left member, and this payment's actual target becomes the right member. That target's occurrence and payment respectively equal the next source submission's occurrence and payment. The next source's own authority, revision, first write, and successor can therefore be consumed in actual execution. The recursion passes precisely this output to the next step, giving (6.4a).

The payment renewal carried by the same input and the first stage of the lifecycle come from one original producer. The preceding lifecycle's second stage equals the following lifecycle's first stage; the interfaces for occurrence, payment, authority, and actual service occurrence all agree. The target future is obtained from that target payment, so the next revision payment connects exactly to the target future's payment. Injectivity of the original payment indices strictly separates the current and next occurrence identities. For arbitrary \(n,h\), take this same joint object at \(n+1\), proving (6.4b). If all later joint steps were deleted, the object at \(n+1\) would contradict the deletion. If a step's target root law were deleted, that step's already generated target root law would immediately provide a counterexample. The observer parameter neither bounds depth nor selects the recursive successor.

The platform interface reuses the right replay carried by its actual admission material. That replay is precisely the left member of the next pair used by the cofinal process's first recursive step. The original occurrence therefore supplies the connection between admission and later joint steps; no reconstruction of runtime authority from a platform label is involved.

Finally, consider the two occurrences beyond a finite representation boundary. Suppose both visible values are \(v\), while their actual responsibility positions satisfy \(u_0<u_1\). Every program \(f\) taking only the visible value produces
\[
 (f(v),f(v)),
\]
whereas the requirement to be expressed is \((u_0,u_1)\). These pairs differ. Deleting either slot's requirement leaves an explicit realization: the constant function with the other slot's actual position. The failure therefore lies exactly in retaining both actual requirements together. A sequential action installs this failure at one local visit while retaining its original bearer. The minimal extension generated from the failure adds responsibility content and a row with no preimage in the old language; its first write retains the old rows and gives old and new rows the same actual successor. The local runtime consumes this revision on its first tick and enters the revised root's second visit. Thereafter its \(k\)-th positive runtime depth is at revised visit \(k+1\); each tick uses that visit's own answer to advance once more. The history depth strictly increases, so repeated surface labels cannot produce a finite period. Appendix E.6 gives the complete construction, its lawful continuation from the existing external revision, and the strict separation between their successor types. This proves the theorem.

Root law fully specifies how each execution is disposed of, while this generating chain continues to supply the run with new rules and bearer relations. Beyond every finite stopping point, the construction provides a later joint step: rules change, and new futures acquire their sources through actual payment.

### 6.5 Rich birth and new futures after settlement

Once a new responsibility enters an institution, its original bearer must still be able to continue living. In A's exit problem, adding a traceable responsibility row is only a beginning: who bears it, who can process it, whether its bearer can obtain an actual service outside the former job, and whether action can continue after settlement must be connected through occurrences.

A **rich responsibility birth** retains a proof that the new responsibility has no preimage in the old ledger, its first generated row, native admission, bearer, and independent processing operation. A subsequently generated **compatible new future** also contains the present complete payment, the exact disposition of unsettled responsibility, actual service, and a feasible continuation for that same bearer outside the former job. “New” concerns two different objects here: the first revision generates a new responsibility row; subsequent payments generate their respective future witnesses.

**Theorem 6.5 (Rich birth and new futures across settlement).** For every original root visit \(v\), the revision generated by capacity failure has a complete three-row responsibility set: two inherited rows and one new residual \(\rho\). Both inherited rows have old origins. Relative to the embedded pre-revision responsibility set, \(\rho\) has no preimage and receives rich birth admission. Its bearer \(b_\star\) is the previously registered bearer of the parent responsibility.

For every source index \(s\) and every \(n\in\mathbb N\), local state \(n+1\) of the reopening root generates a compatible new future. The residual \(\rho\) continues with its original responsibility content and lineage, retaining its independent processing operation. The present payment supplies actual service and connects purchasing-power standing to \(b_\star\)'s continuation outside the former role. In the constructed geometry, this continuation has capacity \(1\); the control that fully captures it has capacity \(0\).

The actual macro path subsequently passes through residual settlement, joint settlement of the two inherited responsibilities, and post-settlement payment. At every post-settlement index \(n\), a compatible new future \(\beta_n\) exists. Writing its current coordinate as \(c_n=c_0(s)+n\), the actual successor of its complete payment is exactly the occurrence at \(c_n+1\). For every finite bound \(m\), some \(n\) satisfies \(c_n>m\). Any finite collection of \(h\) consecutive such futures has no repetitions and has count \(h\). This count cannot reconstruct occurrence identity, actual service authority, or the generated successor.

**Proof.** First enumerate the revision target completely. The old contribution and obstruction rows come from the old-ledger embedding. The third row uses the new direction generated by the exact failure. A preimage of that row in the old ledger would send its new responsibility content back into the old representation, contradicting the no-preimage property that generated the direction. The new-direction component has no open witness on the embedded old ledger either, excluding the remaining form of a preimage in the old ledger. The reverse index recovers every target row and proves exhaustiveness. By comparison, the first target write of ordinary joint settlement transports original rows individually, so every row there has an old origin.

Admission of the new residual reads the content, lineage, and budget of its first generated row; its bearer is taken directly from the original parent responsibility. Initial causal authority and the independent processing operation come from the same occurrence as that row. After reopening, every positive-index payment carries the complete continuation of all three rows. The residual continues with budget \(0\to0\) and retains its processing operation. The work continuation in the former employment relation has disappeared, while a separate independent relation supplies a nonidle leave continuation. The counterparty of purchasing-power standing is precisely the existing actor to whom that continuation belongs, and that actor's bearer equals \(b_\star\). Payment, route, and actual service receipts form a feasible edge in one geometry. Its unique surviving action gives capacity \(1\); the full-capture control removes that action and has capacity \(0\).

The cross-settlement seam uses the payment at reopening local state \(3\). It equals the source payment of the residual-settlement action, whose generated successor enters the three-row settlement root. The residual's terminal receipt eliminates its successor same-debt fibre. The two inherited rows enter the successor root with their original provenance and later each receive a terminal receipt in joint settlement. Native post-settlement payment again supplies service, bearer continuation, and external responsibility processing. The successor occurrence produced by its execution is exactly the occurrence at the following coordinate.

Finally, choose \(n=m+1\); then \(c_0(s)+n>m\). The finite sequence's index map is injective, so its length and count both equal \(h\). Adjacent singleton futures both have count \(1\), but their actual service occurrences have different indices and therefore different occurrence identities and service authorities. Two count-\(1\) futures on opposite sides of settlement also have different actual root successors. If the count recovered these objects, the same value \(1\) would have to recover two different objects, a contradiction. Appendix E.7 gives the complete index transports and the separation of successors across roots. ∎

Rich birth thus carries requirements of provenance, responsibility, and continuing action together. What is generated here is a new responsibility borne by an existing bearer and its feasible futures. The institutional recognition and normative reasons required for human birth standing are developed separately in Section 6.6.

### 6.6 Standing for arrivals and a future people can use freely

An actual birth expands the domain to which an institution must respond. Theorem 6.5 gives new responsibility a source, initial authority, admitted standing, and independent processing, and connects a paid continuation to later settlement. The original inventory can thus acquire a new entry, and the original bearer gains a traceable connection to the new responsibility. An actual construction explains how birth enters the responsibility domain.

For human birth, migration, or renewed membership in society, we further argue that basic standing should be recognized through the life relations affected by institutions. Once an institution acts upon a person, it has reason to explain how services, continuation, and remedy are open to them. Productive contribution may determine particular remuneration; basic standing enables a person to make claims before contributing, while caring for others, or during an absence from production. This normative argument supplies the content an institution chooses to undertake; the finite responsibility-birth construction shows how new content can be written while complete disposition is retained.

After leaving the job, A may care for a relative, study, rest, participate in shared activities, or later enter another kind of work. These futures require time, space, services, and participation that can be withdrawn. When institutions connect these conditions to usable continuation, art, play, celebration, and exploration without a predetermined outcome have an institutional place of their own. People can choose how to use them.

Strict progress guarantees that new actual occurrences can arise; joint revision and birth beyond every finite cutoff keep the run open. Participants still determine what those occurrences mean for their lives. Institutions should provide accessible, exitable conditions that carry their consequences, leaving that choice with the participants.

## 7 Responsibility after complete payment

After A has paid, whose obligation has ended, and who still owes a further performance? A payment can complete the immediate service while carrying credit risk and other source-generated responsibilities into its successor. Joint settlement must therefore examine every original obligation until each transaction leg has its own fulfillment. When an institution ends a local program, responsibilities inherited across roots must still have bearers. This section follows the respective actual sources of clearing, credit, representation, and theory adoption to prove how these distinctions enter a single update or a lawful continuation.

### 7.1 Common clearing: what has each party fulfilled?

Once A has fulfilled an obligation, the counterparty still has to provide any service it owes. Clearing the transaction requires tracing every original responsibility to its termination. We call the part that one party must fulfill a **transaction leg**, allowing fulfillment to be checked leg by leg.

Let \(I\) be the finite set of transaction legs, with counterparty map \(\sigma:I\to I\) satisfying \(\sigma^2=\mathrm{id}\). For leg \(i\), the original transaction generates a bearer \(a_i\), a responsibility \(q_i\), and a responsibility slot \(j_i\). In the construction used here, counterparties have distinct actors and slots:
\[
a_i\ne a_{\sigma(i)},\qquad j_i\ne j_{\sigma(i)}.
\]
Moreover, \(i\mapsto j_i\) is injective, and the original leg list is exhaustive and contains no repetitions. Each leg's fulfillment event can update its responsibility slot only through its own source.

**Proposition 7.1 (Common clearing and unilateral fulfillment).** After all native fulfillment events have been executed along the original finite enumeration, every transaction leg is fulfilled and no open settlement remains. A run that fulfills only one leg leaves its counterparty's responsibility open.

**Proof.** Induct on the executed prefix. When the fulfillment of leg \(i\) is added, its source incidence and actual receipt write a fulfilled terminal archive at \(j_i\). Injectivity of the slot map ensures that this update preserves the terminal archives of earlier legs. The original enumeration exhausts the transaction legs, so every original slot is terminal at the end. Any remaining open settlement would belong to an original leg, contradicting that slot's terminal state. A unilateral run updates only \(j_i\); the distinct counterparty slot \(j_{\sigma(i)}\) retains its original live responsibility. ∎

The actual four-leg clearing is also installed in a periodic root. At every depth \(d\), legislative selection, operational authority, the complete ledger write, and the actual next visit use that depth's original installation coordinates. These coordinates connect local clearing to the temporal root, whose next visit is \(d+1\); distinct depths remain distinct occurrences (Appendix C.2.1). Each leg ends through its own fulfillment, and the ledger in which these obligations have cleared becomes the starting point of the next institutional execution.

### 7.2 Credit support: who still bears the risk after payment?

Credit gives an unsettled relation purchasing power for continued action. To determine what this support resolves for A, we need to identify three positions: who obtains credit support, who accepts repayment, and who bears the outstanding obligation.

The actual credit construction starts from a partially cleared state: leg \(a\) is fulfilled while leg \(b\) remains open. Credit support supplies an actual repayment submission bearing an original source event; the counterparty supplies a receipt for accepted assumption. Together they generate purchasing-power standing. Borrower \(t_1\) comes from \(b\)'s relational seed, and creditor \(t_0\) from its counterparty leg. They are distinct actors. The downside bearer is read from the still-open responsibility \(q_b\). The following result holds at every depth of this periodic source.

**Proposition 7.2 (The allocation of credit responsibility and its actual successor).** At every depth, credit support from the same source and the purchasing-power standing above generate a credit object whose downside bearer is precisely the original bearer of \(q_b\). Its actual successor appends \(b\)'s own native fulfillment event, placing its original slot in a fulfilled archive. The root responsibility content and responsibility lineage are preserved; the root progress budget in this instance is \(2\to2\).

**Proof.** The original counterparty relation determines the borrower and creditor. Identifying the creditor with this seed's borrower would force the same target identifier to equal the distinct \(t_0\) and \(t_1\), a contradiction. The repayment submission and acceptance receipt confer purchasing-power standing, while the still-open \(q_b\) continues to determine the downside bearer.

The generated successor appends exactly \(b\)'s fulfillment event, making \(b\)'s original slot terminal. A live responsibility at that slot would contradict the terminal equality. This is precisely the slot left open by the run in Proposition 7.1 that fulfills only \(a\). The root update carries the original responsibility forward, preserving its content and lineage, with both source and target budgets equal to \(2\). ∎

Leg \(b\)'s exchange obligation is now settled; the continuing responsibility at the root level still has a bearer. We can therefore check separately which obligation credit support has fulfilled and who remains responsible in the next action (Appendix C.2.2).

### 7.3 Institutional records must distinguish control and accessibility

A and controller B occupy different institutional positions when facing the same payment. Determining whether A can obtain the service requires distinguishing who controls admission, who is affected, and whether a route is actually available. A record is complete for these questions if it preserves the distinctions needed to answer them.

Let \(X\) be a source-generated domain, and let \(c_i\) be a registered family of independent processing operations that can read provenance and handle its consequences. Completeness of an old representation \(F:X\to\mathcal A\) means
\[
F(x)=F(y)\iff\forall i,\ c_i(x)=c_i(y).
\]
It preserves exactly the distinctions available to this family. Given a new observation \(r:X\to\mathcal B\), set \(F^+(x)=(F(x),r(x))\).

**Lemma 7.3 (An exact extension preserving the old content).** Equality of the new representation corresponds exactly to equality under all old operations and under \(r\). The quotient by this relation is naturally bijective with the actual image of \(F^+\), and each registered operation factors uniquely through the new representation on that image. If \(F(x)=F(y)\) but \(r(x)\ne r(y)\), the new observation cannot be recovered from the old representation.

Recovery fails because this pair has equal old records but different new observations. If \(r=g\circ F\), then \(F(x)=F(y)\) immediately forces \(r(x)=r(y)\), contradicting the actual difference. Adding \(r\) preserves both the old content and the new distinction. Appendix C.3.1 proves the full kernel, quotient, and unique-factorization statements. The following three actual extensions show what the additional observations contribute to institutional action.

**Sources of admission.** Existing admission, health services, and new platform admission each have their own relational seed, bearer, target role, and material service. Existing and platform admission can share the old cultural representation while having different actual sources. The new institutional coordinates retain their respective admission and service materials and connect the successor of the complete payment root to that of the material action. The platform direction uses an already-paid revision and its admission evidence, bringing the additional source distinction into actual action.

**Control and bearing responsibility.** At the same actual complete payment following the first refusal, the controller and the affected party share the relational event and complete refusal record, but their source-generated actors differ. The observation “is the actual paying counterparty” is false and true for them, respectively. The price position also retains admission, service provision, open price, capture, and the original residual. The same payment and refusal record thus correspond to different positions of control and responsibility. The new representation records these positions together with their sources, preserving the distinction between A's and B's roles.

**Spatial accessibility.** At the same complete payment root after refusal and the same crossing, blocked and restored routes share the old art-production representation. The blocked route has an empty exit-route fibre. The restored route carries a receipt leading to an actual served slot at the next depth, with capacity \(1\). The new observation reads “no route-capacity value” and “actual capacity \(1\),” respectively. A feasible route supports the latter reading, making it possible to check whether A's request can connect to a service already provided.

All three extensions preserve the old projections and obtain actual reading positions and successors at their original roots. Distinctions in social position and spatial accessibility thereby enter actual execution. Appendix C.3.2–C.3.3 gives the installations and transport between roots.

### 7.4 Theory adoption must account for inherited responsibilities

When a theory participates in classification, policy selection, or institutional admission, adopting it produces consequences that require an account. In A's exit problem, theoretical judgments adopted by an institution may affect which actions receive recognition and which outcomes are registered as complete. Adoption must supply an inspectable actual effect; revision must retain an account of where old responsibilities go.

Fix an old theory \(T\), a source trajectory seed \(s\), and a feedback generation process. They generate a classification \(\chi(s)\), a policy choice \(\varpi(s)\), and an actual effect \(e_s:E(s)\), together with an independent processing operation
\[
K(s,e_s).
\]
In the actual construction used here, both classification and policy judgments are true, and the effect is the original lifecycle. Theory adoption adds causal recognition at a definite splice in the existing joint run, retains the original relational operation, and obtains its own complete ledger, visit, selected row, and actual successor. The ordinary successor still uses \(T\).

The independent processing operation provides a way to check effects. If \(K(s,e)\) is empty for a candidate effect \(e\), while the actual \(K(s,e_s)\) is inhabited, then \(e\ne e_s\): otherwise, transporting the actual operation along equality would produce an inhabitant of the empty type. Classification and policy judgments must therefore be checked together with their actual effects and the operations on those effects.

Failure within the original law's scope has a separate set of definite materials. The active scope supplies an original responsibility row \(r\) and an obstruction targeting its responsibility content. The installed failure face points to the same row, which also has causal authority and an actual successor. Revision thereby addresses the failure actually borne by the original institution.

**Theorem 7.4 (Theory revision, responsibility migration, and later clearing).** The actual mother-law failure above generates same-source law revision, a minimal revision face, and the revision first write. The old authorization is superseded; the inherited responsibility remains live at the first write's target visit \(1\), preserving its lineage and source anchor. A subsequent native fulfillment event at revised visit \(1\) archives this responsibility and generates its clearing successor. The ordinary and revised successors are strictly different.

**Proof.** The equality targeting \(r\) and the failure face's entry equality fix the failure to the same original row. That row's causal authority and successor supply a rooted failure. In executing this exact revision, the same source materials determine the revision first write and the successors of the old and new rows.

Write \(q\) for the old responsibility and \(q'\) for the inherited one; Figure 6 depicts this inheritance through the original responsibility row \(\delta\) and its transported row \(i(\delta)\). The original disposition rule records the old authorization as superseded and writes live \(q'\) into the inherited slot. Its content and bearer are read from the revised original row, while the same migration preserves lineage and source anchor. The first write's target visit is not closed: if it were, the same slot would contain a live responsibility and be a terminal archive, a contradiction. Revision has replaced the authorization; \(q'\) still requires fulfillment.

The later run starts from this exact target visit \(1\), reads its own native fulfillment event, and writes a fulfilled archive into the same inherited slot. Before the run, that slot has a live responsibility. The terminal equality after the update excludes every live candidate at that slot, so the responsibility ends through this fulfillment. Equality between the first write's target and the later source visit ensures that the update acts on the actual ledger produced by migration. The support types of the ordinary and revised successors have, respectively, only two points and at least three, which strictly separates the successors. Appendix C.4 gives the complete argument. ∎

![Theory adoption and responsibility clearing](figures/06-theory-en.svg)

Figure 6. Theory adoption has an actual effect handled by an independent processing operation. The ordinary successor retains the old theory; an exact mother-law failure separately generates revision. The first write inherits a live responsibility, and later clearing reads its own actual fulfillment event. The arrow from first write to clearing denotes the proved continuation of visits.

The theory's institutional position has changed, while responsibility for its prior effects remains traceable through the first write and later fulfillment. Reclassification, replacement of authorization, and actual fulfillment in A's request can accordingly be checked as distinct acts.

### 7.5 Renewal capacity, local termination, and debt settlement

Continued payment does not guarantee that every old responsibility can still renew in the same way. After A obtains an actual service, the institution must still distinguish the responsibility that has exhausted its strict-renewal budget, the root that has ended local execution, and the debt that has actually settled through a terminal receipt.

For a responsibility with fixed lineage, a **strict renewal payment** requires four materials jointly: the present actual complete payment, an exact old origin, a same-debt evolution selected by that payment's whole-ledger disposition, and a strict decrease in the responsibility budget. These conditions allow continuing service and the paid renewal of a particular old debt to be checked separately.

**Theorem 7.5 (Three strictly distinct termination loci).** In the actual history of the canonical contribution responsibility, the following three loci occur separately.

| Locus | Actual content |
| --- | --- |
| Observer-runtime depth \(3\) | After the preceding strict debit \(1\to0\), the first write of same-source law revision still inherits the responsibility; its strict-renewal fibre is empty for the first time |
| Observer-runtime depth \(9\) | The three-row root receives a complete faithful-terminal receipt and its local successor type is empty; the same contribution debt still passes through a legitimate handoff to the inherited root at depth \(10\) |
| The later joint-settlement endpoint \(A_{14}\) | Both inherited responsibilities receive exact terminal receipts, and the successor's local responsibility set is empty; the original contribution responsibility finally settles here |

From the first revision write onward, this old responsibility has no strict renewal payment supported by the original whole-ledger disposition at any index of the capacity-revision root, reopening root, or inherited root. These loci may still have their own actual service payments. At the first empty locus, the root-local coordinate is \(0\), actual service depth is \(2\), and observer-runtime depth is \(3\).

**Proof.** The depth-\(2\) action completely handles the two original rows. The contribution row strictly decreases from \(1\) to \(0\), while the obstruction row continues with \(0\to0\). Its actual successor is the entry to same-source law revision at depth \(3\). The revision first write retains the old contribution row's origin, content, and lineage. The new residual occupies a separate row; the inherited contribution neither receives a new birth nor regains budget.

At every subsequent capacity-revision write, both the selected old row and its target have budget \(0\). If a strict renewal payment existed, its exact disposition equality would reduce the required decrease to \(0<0\), a contradiction. The first reopening action, all subsequent complete payments, and the settlement ingress transport this same responsibility and keep its budget zero, so the same argument applies at each stage. It also applies at every inherited-root index. Actual service payments come from the respective native occurrences and can therefore coexist with the emptiness of this old debt's renewal fibre.

Faithful termination at depth \(9\) gives all three rows local terminal receipts and makes the local successor type empty. Yet the native handoff preserves the contribution row's same-debt content and lineage, explicitly generating its target at depth \(10\). A final settlement receipt at depth \(9\) would have to prove that the successor same-debt fibre was empty, contradicting this target. At \(A_{14}\), both inherited rows receive terminal receipts, and the local open-responsibility type after handoff is empty. The required no-successor-same-debt condition then holds. These different actual receipts and successor relations separate the three loci. Appendix E.8 gives the full-history parameters and proofs at each stage. ∎

This distinction allows an institution to continue providing services while recording the old responsibility accurately. After strict-renewal capacity is exhausted, the responsibility can await exact settlement. When a local program has already terminated, inheritance across roots can still preserve that responsibility.

### 7.6 Publication enters execution: target recomputation and continuing payment

Once a judgment about termination enters institutional execution, it must also account for its consequences. The responsibility state on which publication rests, the ensuing complete payment, and recomputation after that payment together form the process to be examined.

In the two-row inherited root above, the source occurrence has a finite publication demand installed in advance. It reads two local sections: the present complete responsibility set still has continuations, and both rows in the next section have terminal receipts. In coordinates counting the edges remaining to this local termination, its unique fold reads \(1\).

**Theorem 7.6 (Actual publication, target recomputation, and paid continuation).** For every original visit \(v\) and source index \(s\), the installed publication demand has finite two-section readout \((\mathrm{false},\mathrm{true})\). Its minimal-locus readout, compatible with the occurrence construction, is uniquely \(1\). This demand occurs at the actual inherited root before joint settlement; Appendix E.9 gives the exact coordinate.

That same source occurrence generates a complete publication payment containing its own actual service payment, the complete evolutions of both source responsibilities, the actual joint-settlement action, and that action's receipt. The action's actual successor is \(A_{14}\). Recalculation at this target finds both responsibilities terminal and no local successor, so the relative termination locus is \(0\). The fixed-point fibre requiring equal pre-publication and post-publication loci is therefore empty, while the actual non-fixed-point payment and response are both inhabited. The terminal handoff from \(A_{14}\) enters \(A_{15}\), whose own native payment then generates the occurrence at \(A_{16}\).

**Proof.** A native local query generates the finite readout by reading the current Boolean value and writing true. Its occurrence unfolding consists of a nonterminal node and a terminal child. The fold returns \(0\) at the terminal node and adds one to the child result at the nonterminal node, giving \(1\). Any evaluator compatible with these occurrence constructors obeys the same recursive equations and therefore gives the same result. Initially both rows in the complete set continue and neither terminates; at the next section both terminate. Thus this is also the minimal locus.

Publication payment obtains actual service from the source occurrence's native payment witness. It retains each responsibility's evolution in the present execution and reads the already generated action's receipt and first successor. All these materials are indexed by this one source occurrence. Its actual target is the terminal root. Both target rows already have terminal receipts, so recomputation immediately returns \(0\). A fixed point would require \(1=0\), a contradiction. The actual payment construction remains inhabited and generates this target response.

The terminal receipt also connects exactly to the first post-settlement root visit. The successor generated by that visit's own payment is heterogeneously equal to the following visit's native occurrence, giving the actual continuation \(A_{15}\to A_{16}\). Appendix E.9 proves uniqueness of the finite readout, whole-ledger coverage, target recomputation, and both successor equalities. ∎

At publication, the endpoint lies one local edge ahead; after execution reaches the target, zero edges remain. The change \(1\to0\) is precisely the recomputed result of this actual movement. To respond correctly to the consequences of its own execution, an institution must assess the situation again at the target and continue payment from there.

### 7.7 Risk splitting and external responsibility after an empty ledger

Which responsibilities settlement resolves depends on the scope it actually handles. After A leaves the former job, credit support can pay for the present service, and old risk can be redistributed between different bearers. Even when one local responsibility set is empty, responsibilities at the service's source retain their own bearers and processing operations.

**Theorem 7.7 (Source-grounded risk splitting and external responsibility after settlement).** At every periodic depth \(d\), credit materials and exact failure at the same original root visit generate a risk split. The parent and its two children preserve the same responsibility identifier, responsibility content, and original lineage. The children use the distinct bearers supplied by the two original exchange legs. Each child branch has a strict structural-budget decrease \(2\to1\); the obstruction responsibility separately undergoes a legitimate \(0\to0\) transport. The first complete source set has exactly two rows, parent and obstruction. The target has exactly three, the two children and obstruction continuation. Each child has an independent processing operation grounded in that split receipt.

The split at each periodic depth is generated from that depth's own source visit. At depth zero, it is additionally connected to the first revision and actual successor of the existing canonical run. Along the subsequent actual actions, risk splitting connects to contribution merge, capacity debit, same-source law revision, residual processing, two settlements, and post-settlement payment.

For every original visit \(v\), source index \(s\), and post-settlement index \(n\), the current occurrence \(e_n\) has an empty local open-responsibility set but still generates source-grounded external liability \(\Lambda_n\). This object retains the original bearer's source ownership, original payment trace, independent root processing operation, actual service settlement, and provenance across roots. It enters the actual successor with this complete payment. Root occurrences, payment occurrences, and actual service occurrences are each injective in \(n\). Any actual service payment witnesses obtained from these occurrences are likewise locked to their own indices.

**Proof.** The risk material obtains the parent responsibility, purchasing-power standing, and bearers of the original exchange legs from the existing clearing failure and credit-support activation seed. The first complete write sends the parent to two child rows, each with a proof of \(1<2\). It attaches a non-increasing transport across supports to the obstruction row. The reverse index exhausts the three target rows. The children's original sources agree; the obstruction's source differs.

The children listed in the split receipt are exactly these two target rows. Child membership recovers source ownership, descendant incidence, source-anchor transport, same-debt lineage, and preservation of local discharge conditions. These materials give two independent processing operations. The children differ because they retain distinct original exchange legs and bearers while sharing responsibility content. At each periodic depth, the construction uses that depth's original visit. The depth-zero actual-runtime receipt connects it to the subsequent contribution merge. The exact successors of the existing actions then continue to the post-settlement payment chain. At the joint-settlement entry, the search answer and actual action at the same root and visit have different compilations; the payment chain uses the latter's action receipt.

Now fix any \(v,s,n\). The post-settlement occurrence's support equality gives an empty local open-responsibility set, while the same occurrence carries an actual service existence witness. The payment obtained from that witness retains responsibility provenance at the original root, its activation trace, processing operation, and actual settlement. These materials constitute \(\Lambda_n\). Their original root connects to the post-settlement root through the existing legitimate provenance relation. Local emptiness and \(\Lambda_n\) therefore coexist in this one post-settlement occurrence.

If two such root, payment, or actual service occurrences were equal, projecting their temporal visits would give \(c_0(s)+n=c_0(s)+m\); cancelling the common initial coordinate gives \(n=m\). The same argument applies when any service payment witness is retained together with its dependent visit in a common carrier. Finally, the complete payment reads the successor produced by the present complete execution and yields exactly the occurrence at \(c_n+1\). Appendix E.10 gives the complete split table, external liability type, and index-locking proofs. ∎

This chain makes settlement a locatable institutional fact. A specified responsibility terminates through its own receipt, other responsibilities at the source remain with their bearers, and later services are supported by later actual payments.

After risk allocation, the responsibilities of two bearers can become a common contribution. The merge must still establish who owns each parent row, which rows enter the common result, and which row continues separately. The actual construction first admits the entire generated three-row risk ledger. Write its two contribution child rows as $a,b$ and its obstruction-continuity row as $o$. The first whole-ledger write produces two rows $m,o'$ through three actual transports:
\[
a:1\longrightarrow m:1,\qquad
b:1\longrightarrow m:1,\qquad
o:0\longrightarrow o':0.
\]
The two rows $a,b$ already have the same responsibility content and protected interest; they enter the merge receipt as distinct parents. Row $m$ retains the existing bearer of leg $a$, while $o'$ retains the original parent bearer. The receipt's parent list is exactly $[a,b]$: every parent is owned by the exact source event of this merge, and the obstruction row remains at its separate destination. The entire initial ledger comes from the original three rows, before the merged result is installed.

The merge lies within three successive ticks of the existing run. Same-source law revision first generates the revised root; the merge then uses the already determined actual event at that root; the following tick starts from the merge target and spends the common contribution's remaining capacity. Each step takes the preceding step's actual successor as its source, and the merge retains exact evidence of the action selected by this execution. Appendix F.8 gives the tick numbers and visit indices. The two contribution rows have the same destination. The selected origins of the two target rows are $a$ and $o$, which are distinct, so the origin map of this write is injective. Any simultaneous split receipt claiming distinct target rows with the same original row would contradict that injectivity. Appendix F.8 establishes the parent list, source and destination coverage, and the three-tick execution in full.

### 7.8 After legal recognition, how can the capacity to advance be restored?

After A's request receives a legal answer, the original responsibility still requires further handling through its own source. To restore its capacity for strict progress, the institution must specify where the progress budget comes from. Every conservative successor is subject to the same constraint. The actual action has spent the contribution row's progress budget from $1$ to $0$. The resulting revised root recognizes a new residual and assigns it to the existing parent bearer. Its complete ledger has exactly three rows—inherited contribution, inherited obstruction, and generated residual—and all three budgets are zero. The new residual already has an operation that handles its actual answer.

**Proposition 7.8 (Conservative closure of exhausted progress budgets).** For every old visit and every visit index of the revised root, take any source responsibility row, its source-native authority, and the exact source event. Every source-native sequential action target generated from these inputs, with no fresh row at ingress and non-increasing row budgets, has no positive-progress-budget row in its first whole-ledger successor.

**Proof.** Let $L$ be the complete source ledger, $L_0'$ the target's initial ledger, and $L_1'$ its first whole-ledger successor. Write $B$ for a row's progress budget. For any $e\in L_1'$, the complete write supplies an actual origin $a'\in L_0'$. No-fresh ingress supplies $a\in L$ whose lawful transport is $a'$. The two levels of conservativity give
\[
0\le B(e)\le B(a')\le B(a)=0.
\]
Every row $e$ therefore has budget zero, and the positive-budget fibre is empty. Exhaustive classification of the source ledger reduces each of its three row forms to budget $0$, so the argument applies to all the stated inputs and all such action targets. $\square$

Revision has already accomplished something substantive: the actual residual has acquired expression, a bearer, and an actual answer. Restoring a positive progress budget also requires a source that can support it. As long as a target satisfies the two conditions—no new row at ingress and no increase in row budgets—however the responsibilities within the exhausted ledger are organized, the budgets in the first successor remain bounded between zero and zero. Appendix F.5 gives the general closure lemma in any type universe and its complete instance at this three-row revised root.

## 8 An economic constitution for those who continue living

A's exit brings a wider set of economic relations into view. Where does income come from? Who maintains public services? How are surpluses and deficits adjusted in clearing? Who can use labour that has been saved? Who bears the ecological and social costs left by old relations? The preceding theorems supply conditions that can be checked individually. This section develops institutional principles from those conditions and identifies the formal result supporting each argument.

### 8.1 Wealth includes the capacity to wait, refuse, and start again

A's balance may record purchasing power without recording how long A can wait, whether an unwanted job can be refused, whether care can be provided to others, whether moving is possible, or where a new start can be made. The same balance may connect to different services, spaces, and relations of control. The three zeros in §5 already give strict finite counterexamples: the same capability reading merges institutional causes, so a more discriminating judgment must recover the sources.

We therefore understand wealth relevant to economic freedom as a set of actually supported continuation relations. For each continuation, the bearer, required services, usable routes, and control conditions must be identified. For the costs of maintaining it, the institution must specify who still has work to fulfil. Cash, public facilities, shared knowledge, and disposable time perform different tasks within these relations. Before combining them into a score, institutions must preserve the routes by which people can use them.

Strict canonical progress adds a temporal dimension. A service A actually receives today does not fulfil tomorrow's need. Current exit capacity can remain one while the history of actually paid occurrences strictly grows: Theorem 1.3 retains the entire old frontier and generates a new occurrence at every step. Continuing economic support thus includes the capacity for services to be realized again and for bearers to begin again.


![Growth of the actual paid frontier with unchanged instantaneous capacity](figures/07-paid-frontier-en.svg)

Figure 7. A paid edge of the same original cycle retains the entire old authority image and produces a new occurrence outside it at the actual target; the target's own native payment realizes that item. The lower panel separately shows current exit capacity remaining one. The upper panel compares historical frontiers of actual occurrences; point positions and box sizes do not measure welfare.

### 8.2 Common clearing and the renewal of clearing authority

The 1943 International Clearing Union proposal placed surplus and deficit within one institutional relationship: bancor recorded credit and debit positions, excessive balances on either side incurred charges, and persistent large creditors were also required to discuss adjustment. The proposal required members to arrange for the discharge of a debit balance upon withdrawal and provided procedures for proposals at an annual assembly and reconsideration of the rules [@Keynes1943, §§I.4, II.6(7),(9),(16),(18)]. How common settlement supports continued participation, how participants can withdraw, and how the rules can be reconsidered thus become connected constitutional questions.

Proposition 7.1 supplies a formal foundation for clearing every leg. Each original responsibility in the finite leg inventory enters the joint terminal state only through its own actual fulfilment and update of its original slot. Section 7.7 further explains how risk is split between distinct bearers and how external liability retains independent processing after the local inventory is empty. Common clearing accordingly requires each party to retain its source and position from which to make a claim.

We derive two institutional requirements. First, persistent surpluses and deficits should both enter a common adjustment process, whose rules explain separately how accumulation capacity and financing costs affect other members' continuation. Second, the authority that provides final clearing capacity should itself have procedures for authorization, renewal, exit, and revision. If one participant monopolizes others' liquidity entry, it can control their continuation by withholding clearing. Role-external exit and non-capture therefore also apply to the clearing authority.

The all-leg termination theorem proves discharge of responsibility. Two-sided adjustment and the organization of clearing authority are economic-constitutional choices proposed here. Their realization still calls for concrete quotas, deadlines, and adjustment rules. The formal foundation makes those rules answerable for every party's actual services, outstanding responsibilities, and conditions of further participation.

### 8.3 Shared production gains and disposable time

A new method ordinarily draws on existing knowledge, tools, public facilities, care work, and current inputs. Determining its distributable gain requires first tracing the inputs, then accounting for added usable capacity, and finally considering allocation. Each question has its own bearers and evidence.

The public-production interface in §9 supplies a concrete application. Reusing an already paid method saves one unit of labour, preserves every old lawful finite action word, and leaves exactly that same unit of labour additionally available at the target. The saving is therefore a usable resource in the actual successor. Maintenance, subsistence, and financial responsibilities remain covered by the original contract. This result exhibits how a realized gain from an improvement can be proved.

Applied to shared production, the approach calls for calculating net gain after providing the original services, maintaining equipment, meeting care and ecological responsibilities, and retaining successor capacity. The next question is whether to use the additional resources to shorten necessary labour, expand public services, replenish common reserves, or support new activities. How a gain arose gives reasons relevant to its allocation; particular shares require public justification in terms of contributions, needs, and costs borne.

A's capacity to leave the old job becomes one measure for assessing productive improvements: does the improvement make it easier to choose work, care, rest, and a new start? If output rises while participants become less able to refuse the old role, institutions must examine where gains go and how control changes. Disposable time should connect to actual continuation free from capture, so that people can choose how to use the space newly available in their lives.

### 8.4 Property, mandate, and the maintenance of shared space

Using housing, land, tools, or infrastructure involves distinct relations of access, exclusion, maintenance, transfer, and exit. Proposition 5.7 proves in non-employment tenure and mandate constructions that, when a relation ends, the original bearer can retain the original payment, route, and actual service. Section 7.7 traces independent processing after same-source responsibility is allocated to different bearers. We can therefore ask individually what a property right actually authorizes and what obligations it leaves.

We argue that use rights should be specified together with maintenance, affected people's continuation, and responsibility after the relation ends. A route holder who can close every entrance to another person's basic life thereby controls that person's continuation; institutions should make this control answerable through explicit authority and exit conditions. Debt should likewise be traced through its source, bearer, and disposition, with exact occurrences for discharge, reopening, splitting, and termination, while basic standing can persist across changing relations.

Shared spaces also have earlier and later arrivals. First arrival records the sources of occupation, labour, and maintenance. Continuing exclusion of others calls for a further account of authorization, public conditions, and renewal. Applied to public domains yet to be entered, including future common activity in space, this distinction yields a constitutional requirement: long-term control must continue to answer to other affected parties and preserve routes by which later arrivals can enter and participate in revision.

### 8.5 Ecological responsibility, later arrivals, and distributed checking

Discharge of monetary responsibility and repair in the material world each require their corresponding actual fulfilment. A payment can discharge a specified debt. Restoring soil and water, maintaining routes, or providing long-term care requires its own receipts in the relevant occurrences. The external-liability result in §7.7 supplies a firm structural constraint: after the local inventory is emptied, source-generated external bearers, payment traces, and independent processing still exist.

Ecological costs should accordingly leave responsibilities that can continue to be processed where their effects occur. Successor institutions need to receive maintenance capacity, revision authority, and unfinished obligations; affected parties should also be able to check dispositions from their own positions as bearers. Institutions for later arrivals can preserve resources, keep routes open, and limit present irrevocable control through these relations of inheritance. Upon arrival, new participants obtain a voice and a claim position through their actual relations.

Checking is distributed among different bearers and processing programs. The complete contract requires each declared responsibility to have a source and a disposition, with exact evidence for settlement or continuation; independent processing retains the part it can examine. Institutions can thus admit newly affected parties and new responsibilities while continuing to require evidence from those who exercise power.

The exercise of power is what must carry proof. People subjected to institutional effects have reason to request an explanation; an institution changing their conditions must specify its source, authority, and consequences. Canonical society brings that requirement into actual payment, rule revision, and successor birth, allowing commonly formed capacities to keep returning to those who continue living.

## 9 Open interfaces: preserving the conditions of new social processes

Services after A leaves the job also involve productive admission, public responsibilities, material provision, and communication. Four independent interfaces each supply their own source law, inputs, and run, connecting completion to original responsibilities and actual successors. Appendix C.5 gives the full conditions and proofs.

**Capital relations.** An original permission law, production seeds, responsibility content, and finite history make it possible to trace capital formation and regeneration. For any original law, there is no capital if and only if, at every original state and port, admission of the controller implies admission of every actor. Uniformly closing admission also satisfies this condition; when technology, ports, and actors are inhabited, that law is nevertheless not fully open. Absence of capital is therefore insufficient to establish that A's needs have actually been paid (Proposition C9).

**Public functions.** Original inventories, authorizations, responsibility packets, and input words generate actual responses and whole-ledger successors. Every original row and slot is terminal if and only if a complete termination receipt exists; any live responsibility forces the response to continue. Original live responsibilities still require disposition after a past authorization is withdrawn and the current task is completed. Any finite number of continuations preserves the original history prefix and financial responsibilities. Menu success supplies actual payment of the same word; failure returns the particular item and shortage (Proposition C10).

**Public production.** Under the original address conditions, public and improved technology, sufficient amounts of the six material resources, and nonnegative child inventories generate actual replication. The child's subsistence and maintenance are paid within the original action word, the complete financial responsibility matrix is unchanged, and the parent's net labor cost is \(2\). A separate reuse of an already-paid method saves \(1\) unit of labor and preserves every previously legal finite word, whose resulting state has exactly that same additional unit of labor. The saved labor remains available for the original actions (Proposition C11 and Lemma C12).

**Protocol fulfillment.** The two-site local rule reads its own queue, current signal, original sends, and actual deliveries. For every adaptive callback whose actual inputs all satisfy the original communication admissibility conditions, this \(24\)-tick program completes every original service and send readback and empties its final queue. The same actual history enters the root's whole-ledger successor. An actual compliant callback inhabits the premise, and an actual path carries service from arrival through activation to a valid reply (Proposition C13).

## 10 Literature in dialogue: exit, power, and sustainable institutional responsibility

Exit theory asks how people can leave or change organisations; the capability approach asks how resources become usable freedom; legal relations and institutional grammar ask how power organises action; and monetary theory asks how promises acquire force in payment and settlement. We bring these questions into an institutional effect with a source, a bearer, and a successor. The comparisons concern specific points of disagreement: how exit is exercised, what capability readouts can decide, which responsibility a payment ends, and who must still perform after the rules change.

### 10.1 How exit becomes independent standing

Hirschman examines how exit and voice induce organisations to respond to decline. He exposes a tension between them: exit can remove the members most likely to speak, while a credible threat of exit can strengthen the voice of those who remain [@Hirschman1970, pp. 3–4, 35–36, 81–82]. This question brings us to A’s position before he leaves. If departure is only a nominal option, independence premised on exit lacks a reliable basis. Theorem 5.1 asks which relations must hold together for A actually to have a way out.

The answer connects authority to the means of living. One continuation action must be available to A outside his former role, supported by this payment, connected by an actual route to a service already delivered, and independent of capture by the specified controller. Every condition must concern the same action and service position. Theorem 5.5 then has A exercise the power to leave, ending the old relationship and obtaining continuation outside the role and the next payment from the occurrence that this action actually reaches. Exit acquires checkable conditions, an execution, and a life afterwards.

Pettit locates non-domination in the absence of another’s capacity for arbitrary interference. Anderson asks whether people subject to orders and sanctions have standing to require that authority respond to their interests [@Pettit1997; @Anderson2015]. We select one concrete institutional requirement in this family: after leaving the former relationship, A can still independently exercise his continuation action. Theorem 5.6 places this requirement inside the institutional response. If the original payment and its uncaptured response remain, reclassifying that same action as captured contradicts the response. The protection concerns the action A can exercise, its services, and its successor; controller and bearer retain their distinct sources.

Refusal tests another aspect of standing. Root law permits an institution to reject a submission while retaining the bearer object it leaves. The misdirected-submission instance of Proposition 5.4 further distinguishes the external candidate that fails acceptance from the lawful payment already native to the node: the source check rejects the former, while the latter still generates ordinary repair and effective exit for the original bearer. An institution can therefore refuse decisively and continue to answer who remains and what that person can do. Complete disposition and the person’s continuation belong to the same institutional construction.

Widerquist’s account of independence gives such continuation material content: the ability to refuse cooperation requires unconditional access to sufficient resources for core wellbeing [@Widerquist2013]. Proposition 5.8 separately tracks purchasing power, in-kind services, and employment. The constructions exhibit a new job under capture, payment without a route, and an available exit without the health service required for complete support. Employment organises labour, income supports purchasing power, and services support living through their own capacity, routes, and delivery. Their tasks remain distinct when they work together. A’s right to refuse thus connects to conditions of living that can be examined individually.

### 10.2 From capability evaluation to institutional diagnosis

Sen redirects evaluation from resource holdings to what people can actually do. Robeyns distinguishes personal, social, and environmental conversion factors and insists on the multidimensional character of capability evaluation [@Sen1979; @Robeyns2017, §§2.6.3, 2.6.7]. We pursue this informational requirement further: after capability has been measured exactly, do we know which institutional relation must change?

Three zeros make the answer precise. Exit capacity correctly reports that no feasible exit exists, yet a missing payment connection, a broken route, and capture yield the same number. Two ones carry the problem into a setting where a way out is already available: a complete two-domain source and a source lacking health service both have capacity one. Positive capacity therefore cannot decide the existence of a complete capability portfolio. The difficulty arises after correct measurement. The indicator has performed its counting task, while distinctions between sources have been merged.

Repair gives that information loss a definite consequence. Among the two original failures and two repairs in Proposition 5.3, removing capture and restoring the route are respectively the unique effective operations. A choice function receiving only the shared capacity must return the same result for both failures and must therefore fail on at least one. Theorem 5.10 further shows that expanding the observation to the reachable set across all installed domains can still collapse different canonical repairs to one value. Every subsequent encoding, into any output type, inherits this obstruction if it factors through that coarse observation.

A richer table of outcomes still needs to retain how the outcomes arose. Refinement by failure kind returns the source to the installed repair rule. Canonical repair becomes recoverable, and effectiveness is equivalent to equality with that repair. Theorem 5.11 then connects these sources to actual occurrences and finite traces. Conditions for realising capability, identification of failure, and authority to execute repair become three connected questions. The proofs locate exactly where information is lost and construct from the sources information sufficient for the original task.

Capability across time requires a further comparison. Theorem 1.3 permits instantaneous exit capacity to remain one, yet proves that each lawful payment generates a new service or exit occurrence outside the old paid frontier while retaining that frontier in full. Yesterday’s realised opportunity has its own identity; today’s need receives today’s actual support. The history of realisation thereby grows strictly. Recording current exit capacity separately from successive realisations reveals how an institution with unchanged capacity can continue to meet new demands of living.

### 10.3 The institutional force of money and responsibility after settlement

What makes a payment able to obtain a service, and what makes it count as performance? Desan returns these questions to the constitution of money: communities organize resources through contributions, tokens, and rules of acceptance, while the institutional design of money creation and circulation distributes costs, benefits, and authority. Money helps constitute market relations [@Desan2013, pp.1–3, 28–29, 36–37; @Desan2014, pp.6–8]. We pursue the question beyond the acquisition of institutional force: whose obligation has a payment discharged, and what has it passed on to those who follow?

Mehrling's account of monetary hierarchy sharpens the issue. The money in which one level of institutions settles may be credit still payable by the level above; consolidating balance sheets can cancel reciprocal entries while concealing the positions of responsibility. Credit can expand alongside a constraint imposed by higher-level settlement assets [@Mehrling2013, §§I–IV]. Desan asks how rules of acceptance constitute money; Mehrling asks what ultimately settles a promise. The questions meet in a payment. Institutional force, particular performance, and the termination of responsibility each require an identifiable occurrence.

We make these positions precise as relations of responsibility that can be checked one by one. Proposition 7.1 quantifies over every original obligation in a finite table of transaction legs: each leg updates its own slot through its own performance, and joint settlement requires the termination of every original leg. Proposition 7.2 allows credit support to produce purchasing-power standing while retaining the original bearer of the still-open obligation. A discharged exchange obligation and a continuing root responsibility can occupy the same successor. Joint settlement thus becomes a proposition about all the relevant obligations, and credit a relation that identifies who still bears the risk of performance.

The temporal distinctions are equally exact. Theorem 7.5 separates the exhaustion of strict repayment capacity, termination of a local program, and final settlement of the same debt; Theorem 7.7 makes a locally empty ledger coexist with external responsibility that still receives independent treatment. An institution can end a stretch of execution. Whether a responsibility has ended is established by that responsibility's own performance and handoff. For A, leaving the job, obtaining a service, and settling the costs of the former relationship each have their own conditions of completion.

Proposition 7.8 draws a further boundary in the reverse direction. Fix an exhausted complete source ledger. For **every** same-source sequential target that introduces no new initial row and increases no row budget, the first successor still has no row with a positive progress budget. The universal quantifier covers the choice and representation of the target; every such target must supply complete provenance row by row. Revision can acknowledge a residual, assign its bearer, and produce an actual answer. Restoring this responsibility's capacity for strict progress also requires a source that supports it. Legal recognition and capacity restoration thereby carry distinct obligations, while the positive regeneration theorems construct the actual production of new occurrences.

The 1943 International Clearing Union proposal already placed adjustment pressure on excessive creditor and debtor balances and connected withdrawal with arrangements to discharge a debit balance [@Keynes1943, §§II.6(7),(9),(16)]. Section 8 takes up the institutional question: how can common settlement sustain participation, and how can the clearing authority itself be subject to renewal, exit, and revision? Performance by every leg, inheritance of old responsibilities, and genuine exit supply requirements against which a proposal can be checked. The allocation of quotas, deadlines, and adjustment powers calls for institutional reasons of its own. The constitutional question of money therefore extends through acceptance, performance, settlement, and renewed participation.

### 10.4 Institutional grammar, revision, and proof-carrying execution

Precise analysis of legal relations begins by distinguishing several ways of “having a right.” Hohfeld separates claims, privileges, powers, and immunities, and explains how a legal power changes another party's legal relations [@Hohfeld1913]. A's power to terminate employment authorizes a change in that relation; food, shelter, and care after departure require further institutional relations to deliver. We retain this relational analysis and give each change a source, an actual effect, and a successor. Exit and succession in Proposition 5.7 show why these distinctions matter. A function can continue while the former bearer's responsibility reaches its own terminal position and a successor assumes a new responsibility from a new source. A later person occupies the position, and each person's historical responsibilities remain separately traceable.

Crawford and Ostrom's institutional grammar further distinguishes the addressee, deontic operator, aim, conditions, and sanction of a rule. Sanctions themselves require authorization, monitoring, and a rule-making arena; the authors explicitly connect this grammar to a theory of action [@CrawfordOstrom1995, pp. 583–586]. At this level we add checkable requirements on execution. Root-law completeness quantifies over every complete installed program in its stated domain: every actual write comes from an action or a revision grounded in exact failure, while refusal retains the bearer object of the original submission. A separate inhabitation theorem constructs an actual channel. The first theorem constrains how power is exercised in every execution; the second proves that the requirements can be realized together.

Proofs of execution eligibility also have a clear technical lineage. Necula has the code producer supply evidence of compliance with the receiver's safety policy. Catala organizes executable legal specifications around general rules and exceptions, and proves type and evaluation-result preservation for a central compilation step [@Necula1997, pp. 106–109; @MerigouxChataingProtzenko2021, §4.5]. We carry the checking obligation forward to affected parties and institutional successors. After rejecting a candidate payment submitted to the wrong node, the node retains its own original payment, through which the bearer can still obtain ordinary repair and real exit. The analysis thus tracks both which submission is eligible for execution and what this disposition leaves available to the original bearer.

When the policy itself changes, Alchourrón, Gärdenfors, and Makinson already supply postulates for contraction and revision and a representation theorem using partial meet contraction; their opening discussion explicitly includes the derogation and amendment of norms [@AGM1985, §§1–2]. Same-origin revision here carries a further substantive obligation: the very responsibility on which failure arose must enter the new law's first complete write. Theorem 7.4 follows it into a later act of performance. Authority has changed, but the inherited row remains live; a subsequent performance receipt takes that row into a terminal archive. Proposition 7.8 adds a constraint on progress budgets: for every same-source sequential target that adds no initial row and increases no row budget, the first successor of an exhausted ledger has no row with a positive progress budget. Rules can recognize a new responsibility; restoring that responsibility's capacity to advance still requires a supporting source.

Legality consequently addresses both origin and continuation. Power must supply its grounds, refusal must preserve bearer relations, and revision must carry forward outstanding obligations. All-depth regeneration takes these requirements into each actual successor, while cofinal revision proves that complete rules of disposition can coexist with the continuing emergence of new occurrences. Institutions can rewrite their rules, and every rewrite must still answer the same question: how can the people already affected continue afterwards?

### 10.5 The force of universal theorems: joint realisation and what cannot substitute for it

These dialogues converge on one question: how can an institution account together for who acts, who is affected, who remains responsible, and what supports the next continuation? Each tradition illuminates an important part of the problem. We connect these requirements through a common source, complete disposition, and an actual successor, making their relations mathematically checkable.

The generation theorem first establishes joint realisation. Subjects, powers, services, settlement, and theory adoption each have a source and belong to one nonempty institutional foundation. The universal root-law result then constrains every complete installed program in its stated domain: every execution must receive a complete disposition, and every write must arise through action or revision. For any prescribed foundation and recursive parameters, a separate existence construction supplies actual witnesses at the same constitutional point. Exhaustiveness constrains power; inhabitation enables the institution to operate.

Diagnostic impossibility changes what information can be used for. Proposition 5.3 excludes every correct repair-selection function based only on capacity within the original two-operation repair language. Theorem 5.10 allows any output universe and any encoding: as long as the encoding factors through the coarse observation that merges the source distinction, it cannot recover exact repair. More elaborate computation cannot by itself recover a distinction already lost from its input. Source refinement gives a positive answer. Retaining the original failure kind distinguishes the objects and lets the installed rule choose the uniquely effective repair.

Regeneration takes joint realisation to every depth. The result both generates an object at each depth and proves six joint guarantees for every object of that type. The guarantees share the current payment, and the visit actually reached by one step is exactly the next step's entry. The complete-payment theorem further allows any original cycle, any position within it, and any lawful payment there: the complete contract and an occurrence outside the old image come from that same payment step. Strict progress compares every pair of depths and holds exactly when the depths are strictly ordered. Beyond every finite cutoff, the cofinal theorem supplies one and the same later step with both actual law revision and payment-supported birth.

Preserving responsibility and opening the future can therefore occur together. Refusal retains the bearer; revision transports old obligations; settlement ends a specified responsibility through actual performance. New services and exits acquire their own occurrence identities in the successor. The results retain their respective source families and proofs, while proved same-occurrence relations, lawful transport, and actual successors assemble them. Together they establish an institutional completeness that can be examined obligation by obligation: how is the present disposed of, and what makes continuation possible?

## 11 Complete disposition, another beginning

A's exit brings institutional judgment back from a number to a set of relations. The three zeros fail at payment incidence, route incidence, and non-capture, respectively; the two ones separate feasible exit from complete support across the two installed domains. Counting can be entirely correct while diagnosis still has to reach back to the source. Preserving that distinction tells a repair procedure what it must change.

The positive construction supplies the other half of the answer. Activities generate continuing bearers, the root law governs every complete execution, and inhabited constitutional points give these rules an actual place to work. An institution can refuse a submission while retaining the bearer's continuation on the original payment. It can also change the rules and carry old responsibilities into the new arrangement until their own fulfillment settles them. Legal recognition, local termination, and resource restoration each perform their respective work; actual execution determines where responsibilities go.

The stronger universal conclusions extend through what follows. At every depth, one payment jointly supplies six regeneration guarantees. For every lawful payment in any cycle of the original type, the complete contract enters the actual target with it, and a new occurrence is generated there beyond the entire old authority image. Current exit capacity may remain unchanged while the realised history grows strictly. Beyond any finite stage, one and the same later step also jointly produces law revision and new birth supported by payment.

“Canonical” names a mathematical object generated from explicit sources and rules. Its social force lies in actually constructing institutional requirements that can hold together and identifying the information and operations that cannot substitute for them. A person's life continues after a relation ends. An institution that has completed its disposition must still supply the conditions for another actual beginning.

## References

[GaoProcess] Gao, Jian. *The State Is Not the History, the Source Is: Identity, Responsibility, and Minimal Revision in Processes*. Version 2, 2026. [doi:10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175).

[GaoLedger] Gao, Jian. *Book-Balancing Magic Has Nowhere to Hide: Source-Native Accounting and Actual Continuation*. Version 1, 2026. [doi:10.5281/zenodo.23437454](https://doi.org/10.5281/zenodo.23437454).

[Sen1979] Sen, Amartya. “[Equality of What?](https://ophi.org.uk/sites/default/files/Sen-1979_Equality-of-What.pdf)” The Tanner Lecture on Human Values, delivered at Stanford University, 22 May 1979, pp. 197–220.

[Desan2013] Desan, Christine. *[Creation Stories: Myths About the Origins of Money](https://dash.harvard.edu/bitstreams/7312037c-f89a-6bd4-e053-0100007fdf3b/download)*. Harvard Public Law Working Paper No. 13-20, revised 30 July 2013.

[Necula1997] Necula, George C. “Proof-Carrying Code.” *Proceedings of the 24th ACM SIGPLAN-SIGACT Symposium on Principles of Programming Languages*, 1997, pp. 106–119. [doi:10.1145/263699.263712](https://doi.org/10.1145/263699.263712).

[Keynes1943] Great Britain, Treasury. *[Proposals for an International Clearing Union](https://fraser.stlouisfed.org/title/federal-reserve-bulletin-62/june-1943-21058/fulltext)*. Cmd. 6437, April 1943. Reprinted in the *Federal Reserve Bulletin*, June 1943.

[Hirschman1970] Hirschman, Albert O. *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Harvard University Press, 1970.

[Pettit1997] Pettit, Philip. “[Republicanism: A Propositional Summary](https://liberalarts.tamu.edu/pols/wp-content/uploads/sites/20/2021/04/Pettit-Republicanism.pdf).” In *Republicanism: A Theory of Freedom and Government*. Clarendon Press, 1997.

[Anderson2015] Anderson, Elizabeth. “[Liberty, Equality, and Private Government](https://tannerlectures.utah.edu/_resources/documents/a-to-z/a/Anderson%20manuscript.pdf).” *The Tanner Lectures in Human Values*, delivered at Princeton University, 4–5 March 2015.

[Widerquist2013] Widerquist, Karl. *Independence, Propertylessness, and Basic Income: A Theory of Freedom as the Power to Say No*. Palgrave Macmillan, 2013. [doi:10.1057/9781137313096](https://doi.org/10.1057/9781137313096).

[Robeyns2017] Robeyns, Ingrid. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Open Book Publishers, 2017. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[Hohfeld1913] Hohfeld, Wesley Newcomb. “Some Fundamental Legal Conceptions as Applied in Judicial Reasoning.” *The Yale Law Journal* 23(1), 1913, pp. 16–59. [doi:10.2307/785533](https://doi.org/10.2307/785533).

[CrawfordOstrom1995] Crawford, Sue E. S., and Elinor Ostrom. “A Grammar of Institutions.” *American Political Science Review* 89(3), 1995, pp. 582–600. [doi:10.2307/2082975](https://doi.org/10.2307/2082975).

[Desan2014] Desan, Christine. *Making Money: Coin, Currency, and the Coming of Capitalism*. Oxford University Press, 2014. [doi:10.1093/acprof:oso/9780198709572.001.0001](https://doi.org/10.1093/acprof:oso/9780198709572.001.0001).

[Mehrling2013] Mehrling, Perry. “The Inherent Hierarchy of Money.” In Lance Taylor, Armon Rezai, and Thomas Michl (eds.), *Social Fairness and Economics: Economic Essays in the Spirit of Duncan Foley*. Routledge, 2013, pp. 394–404.

[AGM1985] Alchourrón, Carlos E., Peter Gärdenfors, and David Makinson. “On the Logic of Theory Change: Partial Meet Contraction and Revision Functions.” *The Journal of Symbolic Logic* 50(2), 1985, pp. 510–530. [doi:10.2307/2274239](https://doi.org/10.2307/2274239).

[MerigouxChataingProtzenko2021] Merigoux, Denis, Nicolas Chataing, and Jonathan Protzenko. “Catala: A Programming Language for the Law.” *Proceedings of the ACM on Programming Languages* 5(ICFP), Article 77, 2021, pp. 1–29. [doi:10.1145/3473582](https://doi.org/10.1145/3473582).
