# An Economic Constitution of Possibility

## Producing Real Freedom, Settling Contributions, and Renewing Authority

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

Whether a person who receives an income can actually leave, rest, care for others, create, and begin again depends on services, routes of access, maintenance, and relations of power beyond income itself. This paper takes practically actionable futures as the distributive object of an economic constitution and distinguishes four institutional entitlements, each requiring its own grounds: basic participation, contribution claims, claims on scarce resources, and governance authority. Its central principle is that participation does not require a prior contribution; contributions earn returns that can be settled; claims on scarcity bear the costs of their present use; and continuing control requires continuing authorization. The paper connects this normative argument to established formal results. Equal positive exit capacities can support different complete combinations of life conditions; even a readout covering all domains can lose the provenance needed for effective repair; two successive rounds of innovation can each pay for investment, evidence, subsistence, and maintenance; cumulative receipts attributed to one contribution source, summed over all successor slots, are bounded by its original issuance; labor saved by a public method preserves every previously legal continuation; and the replacement of public services, the inheritance of responsibilities, and arbitrary finite continuation can hold together. These results connect basic provision, a knowledge commons, joint clearing, self-directed time, polycentric governance, and ecological responsibility through a set of institutional arrangements that can be checked. The capability approach identifies what should be evaluated; this paper further asks how capabilities are produced, who pays for them, and who may determine the next rules. The technical appendices supply complete proofs, conditions, and correspondences to the original declarations. New interfaces for generative money and bounded auditing are presented as explicit designs.

**Keywords:** real freedom; economic constitution; basic participation; contribution settlement; public production; self-directed time; revocable power

## 1 How People Can Continue

After leaving a job, can a person still secure a home, obtain medical care, care for relatives, and learn another trade? When a community replaces its managers, who maintains the equipment, who delivers unfinished services, and do earlier commitments still count? When a new technology saves labor, who gains time, and who instead takes on more standby work, care, and cleaning?

These questions share an object: **the paths along which people can actually continue.** Money, equipment, knowledge, and organization can extend these paths; they can also become instruments for closing them. An economic constitution specifies how such paths are produced, how people enter them, where their costs fall, and who may change the rules. Wealth here has a precise institutional meaning: for a particular person, in a particular relationship and at a particular time, which futures does it open that are affordable, accessible, usable, open to exit, and capable of continuation?

The argument can be stated directly. Basic subsistence and social participation should follow from a person's arrival, needs, and exposure to institutional rules. Labor, exploration, risk, and maintenance already undertaken should receive explicit returns. The use of scarce resources requires a budget that can be honored on that occasion. Continuing control over others requires authorization that can be challenged, terminated, and replaced. These four entitlements are connected, but their grounds differ. Merely continuing to hold a claim based on a past contribution cannot automatically entitle its holder to place permanent gates before those who arrive later.

A set of strong, concrete formal results supports this argument. First, for the same actual payment and the same exit action, two sources with capacity one can provide, respectively, a complete combination of rights retention and health, and an incomplete combination providing only rights retention. Second, two rounds of innovation in the original mechanism each actually pay for investment, evidence, subsistence, and maintenance; the second discovery also lies outside both quoted menus. Third, the bound on contribution receipts tracks the original source of issuance and sums over all successor slots: transfer, a change of slot, and waiting do not reissue it. Fourth, public production can preserve the reuse of a paid method as additional labor in the complete inventory while retaining every previously legal finite continuation. Fifth, service can continue and old responsibilities can remain even as the original term of jurisdiction expires. Appendices A–C give the conditions, proofs, and actual consumers of these results.

These constructions change how several familiar questions can be posed. Basic income, basic services, and a voluntary job guarantee can serve choice, provision, and paid participation, respectively. Open public knowledge can coexist with payment for those who explore. The necessity of a service can coexist with the replaceability of its provider. Higher productivity can become self-directed time. Connecting these possibilities requires tying each commitment to real costs, actual performance, and the next authorization.

The eight principles and their formal supports are set out below. Normative reasons explain why institutions should be arranged in these ways, formal results establish specific structural relations, and empirical research tests their effects on life under real conditions.

**Roadmap: eight principles and their formal supports**

| Constitutional principle | Core institutional requirement | Formal support |
| --- | --- | --- |
| I. Complete paths (§2) | Check real exit, complete portfolios, and repairable provenance | Results 1–2; S1–S3 |
| II. Basic participation (§3) | Participation precedes contribution; people can continue after a role ends | S4, PP3 |
| III. Contribution and control (§4) | Pay real costs, bound cumulative receipts, and authorize control separately | Results 3–4; CF1–CF4 |
| IV. Shared results and clearing (§5) | Open results, budget scarce uses, and actually discharge each party's obligations | Result 5; S5 |
| V. The time dividend (§6) | Preserve old capabilities in the net surplus; those affected decide its use | Result 6; PP1–PP4 |
| VI. Public authority (§7) | Keep providers replaceable, preserve responsibilities, let authority expire, and pay for planning | Result 7; PF1–PF4, PL1–PL3 |
| VII. Future members (§8) | Preserve external responsibilities beyond local settlement and retain conditions for later arrivals | S4 (external responsibilities) |
| VIII. Continuing renewal (§9) | Retain earlier commitments and provide real sources for new possibilities | Result 8; S6–S7 |

Source abbreviations: S covers social relations and clearing; CF, capital and innovation; PP, public production; PF, public functions; and PL, public planning. Conditions, proofs, and original declarations appear in Appendices A–C.

## 2 The Unit of Wealth: Complete Paths of Action

### 2.1 From Resources to Lives People Can Lead

Sen shifted the evaluative space of equality from goods and satisfaction to what people can do and become, while explicitly recognizing the difficulties of weighting and indexing capability bundles. Robeyns further distinguishes personal, social, and environmental conversion factors. [@Sen1980; @Robeyns2017] This paper takes that starting point into production and governance. Why does an option actually exist? Who supplies the resources, knowledge, care, and access? Does using it still depend on the permission of the original controller?

In what follows, the “source” of a service, payment, or subsequent action means the specific rules and events that generate it. Requiring the same source ties the commitments recorded in an account to the particular performance that actually occurred.

Consider a person preparing to leave a job. Giving them money does not automatically provide a home to rent. An empty home does not automatically confer lawful entry and continued use. An available service window does not automatically connect that window to the person's payment, identity, and action. An actual path of exit can be expressed through five conditions that must hold together:
\[
E(c,j)=
R(c)\land\neg I(c)\land\neg H(c)
\land P(c)\land T(c,j).
\tag{1}
\]
Here, $c$ is a continuing action generated by the original source, and $j$ is a service slot actually delivered on this occasion. $R$ denotes continuation outside the role; $I$ denotes idling without action; $H$ denotes capture of the action by the original relationship; $P$ is the payment witness for that action; and $T$ is the route witness connecting it to the actual service. All five must concern the same action, payment, and service occurrence.

**Result 1 (Necessary and sufficient conditions for actual exit).** In the original finite exit program, an actual exit exists if and only if a pair $(c,j)$ satisfies equation (1). Its maximum feasible matching size $K$ is positive if and only if an actual exit exists. The original canonical instance also has three requests, two served slots, and one actual exit, so congestion can coexist with positive exit capacity. See Appendix A.1 for the proof; source [S1].

This criterion makes “having a choice” a relation that can be checked. It also explains why a zero readout needs an explanation. Continuing control, failure to associate payment with the action, or failure to connect a route to a delivered service can each make $K=0$. Repair must address the particular link at which the path fails.

### 2.2 Why a Positive Number Is Still Not Enough

The original construction provides a stronger comparison. Fix the same original occurrence, payment, payment association, and route, and take rights retention and health, the two service domains explicitly provided by the model, as the complete action portfolio. The complete source supplies both services; the incomplete source preserves only rights retention. Both have maximum matching size one.

| Check on the same exit action | Complete source | Incomplete source |
| --- | --- | --- |
| Actionable exit capacity | $K=1$ | $K=1$ |
| Rights retention service | Reachable | Reachable |
| Health service | Reachable | Unreachable |
| Complete rights retention–health portfolio | Inhabited | Uninhabited |

**Result 2 (Equal capacity does not determine a complete action portfolio).** No discriminator that reads only $K$ can correctly determine the feasibility of the complete action portfolio for both original sources. If it classifies the number one as “feasible,” it misclassifies the incomplete source; if it classifies it as “infeasible,” it misclassifies the complete source. Appendix A.2 gives an independent definition of the portfolio and the complete proof; source [S2].

Publishing the capacities and feasible combinations of every domain still leaves another possible loss. In the original construction, “captured by control” and “route broken” can have the same readout across all installed domains, while each has a different unique effective repair. Any decision function that first factors through this shared readout, however large its output space, cannot recover their original repair authority. Adding the failure kind already held by the source before output refines the readout enough to choose the correct repair. What is missing is the cause of the outcome; another welfare weight cannot supply it. See Appendix A.3; source [S3].

**Principle One: Distribute by complete conditions of action and preserve the provenance through which failures can be repaired.**

Income, service counts, and capability indicators all have uses. A constitution must also ask whether they connect into a sustainable combination of life conditions for the particular person concerned. Rights retention and health are the explicitly installed domains of the original proof. Institutional applications must add food, care, transport, education, expression, and movement as the circumstances require, and bear the costs of their respective shortfalls.

### 2.3 Whose Power Does an Economic Constitution Constrain?

Economic institutions distribute at least five kinds of things: material resources; opportunities and capabilities; risks and external costs; attention and expression; and the power to change rules. The first three determine whether people can act and what they must bear. The last two determine which needs enter the agenda, which costs become visible, and who can alter the thresholds. If balances are redistributed while existing powers over entry, agendas, and rules remain, new wealth may still flow back to old centers of control.

This also explains the term “constitution.” It concerns the basic commitments that can reliably be made, fulfilled, challenged, and revised in economic life: who qualifies, who bears responsibility, what evidence can justify restricting another person, and which powers must expire. It includes both resource arrangements and the procedures through which those arrangements are decided.

Buchanan distinguishes the choice of rules from choices within rules and includes the definition of property rights and constitutional renegotiation in his analysis; Eucken, Böhm, and their collaborators seek to constrain private power through a competitive order, while Böhm also requires economic coercion to be subject to public authorization, withdrawal, and legal redress. [@Buchanan1975, chs. 3–5; @BohmEtAl1936, pp. 35–37; @Bohm1928, p. 66] The present argument subjects consent and the competitive order themselves to continuing tests of practical effect: basic participation requires actual provision without a contribution threshold, exit requires actionable continuation outside the role, and governance powers require terms, challenge, and replacement. Past contributions should be settled under their original commitments, with cumulative receipts checked along their provenance; continuing control over later arrivals and shared methods must separately derive its justification from current responsibilities, executable continuations, and valid authorization.

## 3 Participation Need Not Be Earned in Advance

### 3.1 The Standing of Persons and the Standing of Roles

**Principle Two: Place basic participation before contribution accounting.**

When people enter a shared world, its rules already affect them, and they already need subsistence, relationships, and the capacity to act. Requiring them to prove useful before obtaining the conditions for sustaining themselves and developing capabilities turns the prerequisites of capability formation into rewards for its completion. Illness, disability, care, exploration, and temporary failure are especially vulnerable to this circle.

Equal basic standing does not require identical material allocations. Equal participation may require different amounts of care, accessibility, and recovery time. Concrete needs determine the intensity of services; contributions already undertaken determine additional claims; particular tasks determine the corresponding professional authority. None of these distinctions should be reversed into a hierarchy of persons.

Social roles arise from actual relationships. A person can become a carer, researcher, tenant, or community member, and can also end those roles. In the formal constructions, “birth” strictly means a new responsibility or institutional occurrence generated from existing bearers and an actual source. The person's basic standing rests on the normative reasons just given. Connecting the two levels yields a direct requirement: institutions that generate new roles must also preserve paths for the person after an old role ends.

### 3.2 Basic Income, Basic Services, and a Voluntary Job Guarantee

Unconditional income provides purchasing power with which to leave a particular buyer or organization. Public basic services make essential provision less dependent on individual payment. A voluntary job guarantee offers income, activity, and shared participation to those who wish to work. Their strengths differ. Van Parijs argues for unconditional income through real freedom and employment rents; Coote connects universal services to sustainable consumption and plural provision; Tcherneva explicitly designs the job guarantee as voluntary while retaining existing benefits. [@VanParijs1991; @Coote2021; @Tcherneva2018]

This paper subjects all three to a further common test: **after a person refuses a job, leaves an organization, or challenges a manager, which conditions of life remain theirs to use?** The efficacy of cash depends on supply and prices; that of services on accessibility and replaceable provision; that of a job on voluntary participation and a floor outside the role. The three can be combined. None of their names substitutes for checking these conditions.

| Arrangement | Capability directly increased | Conditions of continuation still to be secured |
| --- | --- | --- |
| Unconditional basic income | Purchasing power whose use the person decides | Supply, prices, access routes, and actual services |
| Universal basic services | Essential provision such as housing and health | Access, quality, challenge, and alternative providers |
| Voluntary job guarantee | Paid work and social participation | Basic protection after refusal and exit |
| Settlement by actual contribution | Returns for added labor, exploration, and maintenance | Original provenance, payment rules, and receipt bounds |

In a 2026 working paper, Lehner uses a randomized experiment within a representative survey of unemployed workers in Austria to study support for the two proposals and willingness to participate. A majority support both the job guarantee and basic income; support is higher for the former, and the generosity of the proposals also affects choices. [@Lehner2026] This preference finding further suggests that policies can be combined according to the different capabilities they offer. Actual provision and exit conditions still have to be secured individually.

### 3.3 Exit Must Extend into What Comes After

The original exit lifecycle contains four distinct occurrences: the formation of authorization and standing; the person's actual departure; continuation and service outside the role; and a further continuation generated by a later payment. Three payment edges connect to their respective actual targets. The old employment relationship can end while the person continues to receive service through the original rights retention and health channels, with old external responsibilities preserved. Even when the action's content is the same, authorization, execution, and later service retain their own occurrence identities. An administrative label saying “exit permitted” cannot replace this chain. See Appendix A.4; source [S4].

The original public production trace offers another concrete realization. After a participant leaves a shared role, an audit task remains lawful and affordable, yet the actual dispatch is empty. The person then actually produces outside the role and later pays the cost of returning. This sequence makes refusal part of the production institution. [PP3] Rights retention and delegation outside employment also have their own exit interfaces. The successor to a delegation is generated from the actual history after exit, while old service responsibilities continue along the original slots; succession does not reopen the old control.

Institutional applications should accordingly extend the exit test to housing, health care, debt, platforms, administration, and family dependence. Refusing a particular duty may affect the consideration owed for that duty. Without a separate justification, it cannot cut off the person's conditions for living, challenging decisions, and participating again. Work can then become a relationship that people can choose and settle.

## 4 Contributions Can Be Settled; Control Must Be Renewed

### 4.1 Paying for Actual Contributions

**Principle Three: Recognize the full real costs of contribution while examining returns and control separately.**

Research and development require inputs; failure consumes time and materials; waiting ties up resources; maintenance makes a system usable again. Knight's analysis of uncertainty and Arrow's treatment of invention finance, indivisibility, and knowledge externalities require institutions to take these costs seriously. [@Knight1921, ch. VII; @Arrow1962]

Contribution also extends beyond the successful product. Knowledge gained from failure and later actually used, evidence that eliminates mistaken paths, long-term maintenance, and risk bearing can all receive returns proportionate to their effects. The essential questions are which contribution generates the claim, which prior rules recognize it, who actually benefits, who bears the risk, and how receipts accumulate.

Pistor's account of capital's legal structure supplies another important insight. Property, collateral, corporate, trust, contract, and bankruptcy rules together confer priority and durability on assets. [@Pistor2019] Claims to income, the use of assets, the exclusion of others, and the power to change rules are therefore not naturally an indivisible bundle. Compensation for supplying equipment has its grounds. Whether that contribution also confers lasting authority to decide if later arrivals may use shared methods or establish alternative services requires further grounds.

![Figure 1. Four entitlements, each with its own grounds. Basic participation, contribution claims, scarce-resource claims, and governance authority are tested against need, provenance, budget, and authorization, respectively. One entitlement cannot automatically become another.](figures/01-four-claims-en.pdf)

### 4.2 Innovation Can Continue without Permanent Gates

Successive innovation can preserve old responsibilities, pay the costs of each round, and produce discoveries outside the ex ante menus. The following construction gives a complete instance.

**Result 3 (Two rounds of innovation with actual payment).** In a constructive witness within the established original mechanism, the rules are fixed before the unknown event; the technology states are successively 0, 1, and 2. The second discovery appears in neither round's quoted menu. Each round pays a material investment of 3 units, incurs total message-resource consumption of 3 units, including an observation fee of 1 unit, and pays the subsistence and maintenance of every original participant. The old debt of 1 unit is preserved throughout. The second round starts with its own financing and empty evidence packets. Actual release of the next trial also checks that the current round's payments have been completed. See Appendix B.2; sources [CF2–CF3].

![Figure 2. Two innovation payments in a constructive witness. Technology states 0, 1, and 2 and the numerical amounts belong to this instance. Investment, evidence, subsistence, and maintenance occur in each round, and the old debt is preserved. Different resource units are measured separately.](figures/02-paid-renewal-en.pdf)

The result supplies a concrete institution capable of continuing exploration. Ex ante quotations can use declared beliefs and finite risk terms, while actual events may still fall outside the menu. An unpaid current period does not count as completed merely because the next proposal appears affordable. New discoveries can occur; new payments must still occur; and the promise of innovation does not erase old responsibilities.

Payment for innovation can therefore be tied to actual inputs, risks, and the use of results. Whether permanent exclusion is necessary should be asked after these functions have each been met. Collapsing exploratory finance, organizational judgment, actual risk, and lasting control into a single indivisible term allows the need for any one of them to underwrite all the powers associated with the others.

### 4.3 The Cumulative Receipt Bound for an Original Contribution

Let $Q$ be the quantity of claims issued for an original contribution. The original account preserves the provenance of each actual payment so that
\[
\text{remaining principal}+\text{actual payment}
=\text{previous principal}.
\tag{2}
\]
Induction over an actual finite run telescopes these equalities. Uniqueness generated by the original source then allows summation over every final-state slot with the same issuance origin, giving
\[
\sum_{\text{all final slots with the same original source}}
\text{cumulative actual receipts}\le Q.
\tag{3}
\]

**Result 4 (The cumulative bound for the entire source).** Equation (3) applies to continuations of the original actual cursor, arbitrary public suffixes of the complete account, and public suffixes generated by the original innovation engine. The required uniqueness of provenance is generated by the original inventory and occurrence order. See Appendix B.3; source [CF4].

An issued contribution claim may therefore be transferred or held over time. However the final account expands, aggregation by the same source still yields only that one issuance total. New services, gifts, and income supporting basic participation need their own sources; they cannot be recorded as reissuance of an old contribution. Equation (3) bounds the cumulative amount. When full repayment actually occurs still depends on payment conditions and institutional operation.

This supports a clear normative choice: contribution returns should have intelligible settlement boundaries, and continuing governance should have boundaries of continuing authorization. Arranging them separately can respect both costs already borne and the freedom of later arrivals. Institutional transition must accordingly carry real old debts, reasonable expectations, and maintenance obligations. Declaring openness cannot simply shift the costs of transition onto those who previously bore them.

### 4.4 The Absence of Capital Control and the Capacity to Produce

The absence of capital control under the original law has a precise criterion: at every original state and resource entry point, whenever the controller is admitted, everyone else is admitted as well. The original theorem proves that this condition is exactly equivalent to excluding the forms of control, appropriation, and historical continuation that depend on a private advantage in access under that law; the complete five-part contract is set out in Appendix B.1. [CF1] The original theorem also includes the case in which all ports are closed to everyone. Eliminating permission asymmetry must therefore be joined by actual service and an executable successor if an institution is to gain a positive capacity to produce.

Public production has three tasks that must be met together: removing exclusion that lacks present justification, paying real costs, and preserving the conditions under which each person can continue. Only when all three are connected does a reduction in control expand what people can do with their lives.

## 5 Shared Results, Scarce Claims, and Clearing

### 5.1 Knowledge Can Be Shared; Implementation Still Has to Be Paid For

**Principle Four: Open shared results, make scarce uses bear their own costs, and clear old obligations along their provenance.**

Once proofs, methods, software, and designs can be copied, one more person's understanding need not diminish anyone else's use. Equipment time, computing capacity, electricity, materials, review, and care each have their own limits. Treating both kinds of things as a single “asset” can reopen gates through implementation bottlenecks after knowledge has been made public. It can also mistake public knowledge for production without costs.

Benkler explains how peer production uses dispersed knowledge and diverse motivations, while identifying modularity, task granularity, and integration costs as key conditions. [@Benkler2002] This paper adds the requirement that shared methods connect to actual implementation budgets: who maintains versions, who bears failure, who performs safety checks, how users obtain tools, and who succeeds the original maintainer after departure. Open results need provision that can continue.

Capacity for basic participation and additional contribution income should therefore be accounted for separately. The former enables people to begin; the latter settles the effects they actually add. A failure can consume a public exploration budget. If knowledge from that failure is later used independently and actually saves search or repair costs, it can become grounds for a new contribution. Repeatedly submitting the same result or renaming an existing failure cannot generate extra claims on scarcity merely by increasing the number of registrations.

### 5.2 Every Leg of a Transaction Must Actually Be Performed

Let $I$ be a finite set of transaction legs, and let $\sigma$ map each leg to its counterparty leg, with $\sigma^2=\mathrm{id}$. Each leg has its own bearer, responsibility, and actual account slot; the map from distinct legs to slots is injective. The originally authorized performance events settle their corresponding slots one by one. After the complete enumeration, no settlement remains open. Performing only one side preserves the counterparty's open responsibility, because updating one's own slot does not update the other.

**Result 5 (Complete clearing and an unsettled counterparty).** In the finite transactions generated by this source, actual performance of all original legs gives complete clearing. One side's performance cannot stand in for the counterparty's. Source-generated credit separately produces a risk bearer from a still-open responsibility and settles the original slot through its own later payment. See Appendix A.5; source [S5].

This simple result supplies a firm basis for joint clearing. Agreement, issuance of a witness, acknowledgment of a claim, and actual delivery are distinct occurrences within a relationship. Credit can organize time, but it still has to identify who bears the side that remains incomplete. Risk sharing, insurance, or restructuring may change that burden; the change itself needs new authorization, resources, and responsibility records.

Keynes's 1943 clearing union proposal subjected excess debit and credit balances alike to charges and discussion of imbalance adjustment. It also left large creditors the final decision over further adjustment, rather than imposing a fully symmetrical enforcement mechanism. [@Keynes1943, II(7), II(9), III(7)] What matters for this paper is bringing the creditor side within the shared system's responsibility for adjustment. Clearing between states and contribution accounts within a community are different institutions. Applying this idea to the latter requires separate rules for the clearing unit, liquidity, exit, loss sharing, and the clearing authority.

More concretely, a creditor can require performance or lawful disposition of a real commitment. Holding a claim alone cannot confer the power to define the debtor's personhood, possess their life permanently, or unilaterally veto the liquidity of the whole system. The clearing institution itself must be open to supervision and replacement; otherwise, its operator becomes an unavoidable point of control in every relationship.

### 5.3 An Institutional Interface for Generative Money

The paper accordingly proposes a monetary interface that remains to be implemented. Every new claim on scarce resources should identify its original source of effect, unit of measurement, applicable resources, issuance conditions, cumulative receipts, actual redemption, and remaining responsibilities. Transfer may change the recipient without erasing provenance. Copying a result does not automatically copy its allowance. Credit promises and settled, usable capacity should be shown separately. Where resources differ, conversion rules must disclose their valuations and constraints; a single score cannot conceal material, labor, time, and ecological conditions.

This interface admits several technical implementations. The protocol must prevent duplicate issuance from the same source, execute actual spending, handle challenges, constrain collusion and identity splitting, and carry responsibilities after clearing fails. Existing formal results separately provide provenance tracking, actual payment, cumulative bounds, and successor preservation. Connecting them into a dedicated monetary carrier and issuance and spending protocol remains new implementation work. Appendix D presents related pilots as designs, without claims of field issuance or operational results.

The purpose of this layer is to specify what money should represent: claims with provenance and limits that can actually be honored. Transferability can help coordination. The quantity held should not automatically confer greater personal standing, a greater basic right to speak, or indefinitely extended authority over rules.

## 6 Whose Time Does Productive Slack Become?

### 6.1 Savings Must Hold across the Whole System

**Principle Five: Meet the full responsibilities of production before those affected decide where the net surplus goes.**

If a step saves labor by shifting costs to carers, maintenance workers, other regions, or later arrivals, the whole has not yet gained the corresponding dividend. Fraser's analysis of capital and care brings social reproduction back from an ostensibly free background into the conditions of production. [@Fraser2016] We must therefore examine both whose account records the gain and whose account has lost sight of the cost.

**Result 6 (A labor dividend that preserves every old action).** In the original public production source, an audit method is first generated through an actual labor payment, and its reuse still checks the materials available on that occasion. At completion, the entire state retains exactly one additional unit of labor for the original production unit relative to the comparison state (the model calls the initial production unit the “mother cell”; this is its available labor resource); all other resources, financial claims, technology, and clock satisfy the corresponding equalities. Every finite action word legal in the old final state remains legal in the new final state, and the complete state after execution still contains that same additional unit of labor. See Appendix B.4; sources [PP1–PP2].

![Figure 3. Three readouts of one labor dividend. One less unit spent, one more unit in final inventory, and one more unit after every previously legal continuation all track the same resource. Below: selected steps from a 25-step formal public-production trace covering joining, exit, and return. The numbers 21, 22, and 24 are zero-based execution steps, showing dispatch after exit, production outside the role, and voluntary return.](figures/03-time-dividend-en.pdf)

The strength of Result 6 lies in its completeness. It calculates the present saving and proves that the saving has not quietly taken away an old capability. The proof proceeds by induction over finite action words: the additional nonnegative labor preserves the legality of every original request, and each execution step is compatible with retaining that labor, so it remains after the entire word. Expenditure, inventory, and continuation are three readouts of the same gain. This unit can enter subsequent allocation; the three readouts in the figure track the same labor and cannot be added together.

The same formal public-production trace advances the program 25 times, from initial state 0 to final state 25, covering actual joining, refusal for lack of materials, maintenance, exit, refusal of assignment, production outside the role, and return. The numbers in Figure 3 identify execution steps: exit occurs at step 18, another person refuses assignment at step 19, and paid return at step 24 reaches final state 25. The raw-event route and the responsibility-ledger route each replay the trace and obtain complete acceptance; the newly generated subsistence and maintenance responsibilities are also fulfilled within the original trace. [PP3–PP4] This offers a concrete basis for trust in public production: people can leave, while the institution can still account for how life is sustained, production continues, and responsibilities are archived.

### 6.2 Net Surplus Is a Set of Balances with Units

Distributable surplus must arise through actual measurement. For each resource $g$, its net surplus is what remains of the available amount already obtained after subtracting the corresponding resources committed to subsistence, care, maintenance, failed exploration, ecological repair, old obligations, and necessary reserves. An item already paid and included in costs is not subtracted again; the same financial transfer cannot also count as new physical provision.

Labor hours, electricity, water, equipment life, and monetary claims retain their own units. When heterogeneous proposals must be compared, valuations and priority constraints should be explicit. Irreplaceable minimum services and ecological limits do not disappear merely because an aggregate score is higher. The net cost bound for public functions includes all signed costs and deducts actual gains under a fixed valuation in the same unit, providing a precise accounting model; see §7.2. Actual allocation must still address the public legitimacy of the valuations themselves.

Net surplus can shorten necessary labor, improve services, repair ecosystems, replenish reserves, or support new activities. These uses require choices. Research on automation and new tasks already distinguishes technological displacement from the reinstatement of labor; productivity growth does not automatically determine what happens to labor income. [@AcemogluRestrepo2019] Job counts should therefore be assessed alongside living conditions, self-directed time, and continuing services.

### 6.3 Making Time a Usable Freedom

Fan and colleagues' 2025 study documents benefits from reducing work time without reducing pay. In a six-month trial following work reorganization, 2,896 employees in 141 organizations improved on burnout, job satisfaction, and self-reported mental and physical health, a pattern not observed in 12 control companies. The study used a nonrandomized design with voluntary organizational participation, and its outcomes included self-reports. [@FanEtAl2025] The finding offers a concrete empirical reason to pursue self-directed time, while sharpening the next questions: which workers gain time, does provision continue, and have unpaid burdens shifted elsewhere?

The institutional value of time depends on the conditions for using it. Secure housing, shared spaces, health, transport, care arrangements, and protection from being summoned back at any moment determine whether “one hour less at work” becomes an hour under the person's own control. Care, art, play, friendship, celebration, and exploration can therefore be institutional ends in themselves. They need not first prove that they will increase output in the next period to be allowed a place.

A society that allows people to rest and begin again should also allow them to choose demanding work. The constitution protects effective personal control over the rhythm of life, together with fair conditions for undertaking necessary shared labor. It need not turn joy, enthusiasm, or creativity into a new uniform assessment score.

## 7 Services Can Continue as Providers Change

### 7.1 Public Functions and Terms of Office Have Separate Accounts

**Principle Six: Give public functions replaceable conditions of production and public powers revocable authorization.**

A service's importance can justify resources, organizational coordination, and professional authority. These grounds must take the form of specific tasks, scope, duration, and responsibilities. An unfinished task cannot automatically extend a particular provider's authority forever.

Ostrom's work on polycentric governance reveals institutional capacities beyond the market–state dichotomy and emphasizes rules, scale, information, and context. [@Ostrom2009] The specific question advanced here is how other centers take over services and unsettled responsibilities when one center fails or withdraws. Replacements need access to the necessary methods, resources, and evidence of scope. Those affected need rights to challenge, initiate replacement, and inspect the handoff.

**Result 7 (Continuity of responsibility and expiry of original authority).** In the original public-function source, for any actual current state and any finite starting index and length, continuation is generated along the same actual path. It preserves the complete request directory, every received basis, original responsibility identities and histories, complete native runs, and financial receipts. Each step fully distinguishes unrepaired refusal, actual repair, and reviewed service. When the original responsibility is unsettled, no actual suffix starting from the original response's actual successor can restore effective jurisdiction under the original term. See Appendices C.1–C.2; sources [PF1–PF3].

The proof of expiry is direct. The original successor advances the clock beyond the authorization's deadline, and legal suffixes preserve that fact. Continued validity of the original authorization would simultaneously require the clock not to exceed the deadline. The provenance and history of responsibilities are nevertheless preserved along the path. Old responsibilities can therefore continue while old authority ends. New tasks can still receive new authorization, which must have its own actual occurrence.

Professional coordination and emergency command fit this structure as well. The need for a captain can generate clear command authority; it does not justify lifelong rule. Difficulties of succession should become public tasks of method transfer, training, reserves, and recovery, rather than privileges of exemption from succession.

### 7.2 How Complete Costs Bound the Avoidable Net Burden of Capture

The original public-function construction also provides a precise net capture bound. Let $b$ be the actual baseline and $a$ a lawful alternative in the original generated finite menu whose required signature and consent remain under the person's control. The baseline and alternative paths must each pass slot-by-slot actual-payment checks and be compared within the same window. All items are valued at fixed prices. Write $F_s$ for the net financial burden of the selected controlled or financing lineage, $B(a;b)$ for the sum of all positive differential costs, and $G(a;b)$ for the sum of all actual differential gains. If computation over the original menu finds no strict improvement within the same window, then
\[
F_s(b)-F_s(a)\le B(a;b)-G(a;b).
\tag{4}
\]

The bound has a direct reading: among these checked alternatives, if none is strictly better than the status quo, the reduction in this part of the net financial burden achieved by switching cannot exceed the net cost of all other consequences—all additional costs included, all actual gains deducted. If the burden saved exceeds that net cost, the alternative already constitutes a strict improvement.

The costs in equation (4) include the complete complementary net financial account, nonfinancial responsibilities, capabilities, time, and dynamic original production losses. Actual compensation and gains are counted once. The bound is an exact rearrangement of the same utility difference: the positive part minus the negative part equals the sum of all signed costs. The original total decision also explicitly retains two other outcomes: the baseline has not actually paid, or an actual improvement exists. See Appendix C.3; source [PF4].

This result makes the claim that “we cannot do without this provider” open to investigation. Comparisons must include alternatives the person can actually execute; costs must include transition, maintenance, and failure; and the benefits of existing arrangements must also be acknowledged. If an alternative is already better, an appeal to stability cannot conceal it. If the alternative still incurs real net costs, reform must budget for them. Expanding only the upper bound on charges while deleting actual gains would hide capture inside the accounts again.

### 7.3 Public Planning Also Has Work to Do

Hayek's knowledge problem concerns dispersed and changing judgments about particular times, places, and circumstances. Optimizing after all the data have been obtained is not the same as obtaining them. [@Hayek1945] Advances in computation have expanded the tools for searching over rules. Dütting and colleagues use neural networks to learn auction mechanisms, demonstrating computational advances in revenue optimization and incentive constraints with low regret, while specifying the objectives, distributions, and approximation conditions. [@DuttingEtAl2019] Public planning should build on these developments and pay for the information, search, and verification it uses.

The existing independent planning implementation compares each candidate's own complete chain of payment and action from the same unpaid initial cut, connecting the comparison, within the original finite scope, to the same adaptive opponent. The source generates the budget; payment of the candidate-construction fee (the first invoice) precedes generation of the actual candidate catalogue. Payment of the comparison-and-selection fee (the second invoice), measured against that catalogue, then releases actual search. Forecasting, recovery, and result caching are also charged item by item. Every actual work event occupies a distinct position on the original successful ticket, and the sum of work units used across the phases and the remaining work allowance equals the original allowance. Pausing preserves the actual cursor and unsettled responsibilities. See Appendix C.4; sources [PL1–PL3].

This gives an executable principle of responsibility: obtaining data, constructing candidates, comparing, verifying, recovering from failure, and executing are all part of producing the plan itself. Costs are measured in the work events defined by the original source. Real systems also need distinct interfaces for data truthfulness, delay, privacy, strategic reporting, and physical delivery. Who chooses the objective of optimization is itself a question about the distribution of power over rules.

### 7.4 Public Verification and Private Autonomy

Public resources and their consequences require sufficient evidence, while private life needs boundaries of autonomy. Nissenbaum's contextual integrity account treats privacy as a matter of appropriate information flows; the presence of information in a public setting does not license unlimited aggregation and repurposing. [@Nissenbaum2004] An audit should therefore be bounded by specific claims: which service, which time window, whose original responsibility, and which evidence is sufficient for the conclusion?

The new design proposed here distinguishes verified, evidentially refuted, and insufficiently evidenced claims. Refusal of additional access does not automatically establish fraud, and the absence of a payment record does not automatically prove that delivery never occurred. Auditors obtain evidence only for the agreed purposes and within the agreed scope; they remain subject to challenge, revocation, and replacement. Handoffs preserve lawful evidence, old responsibilities, new costs, and the actual successor. Revocation constrains future access; information already learned must be handled in accordance with its actual state.

These contracts for bounded disclosure, three-valued verification, and actual auditor handoff remain to be implemented. Existing independent acceptance through two routes on the same trace, provenance receipts, and constructions of original authorization and revocation provide foundations. Appendix D specifies the checks the new contracts must pass. Public verifiability can then serve private freedom while the auditing institution remains within relations of accountability.

## 8 Later Arrivals Cannot Be Hidden outside the Accounts

### 8.1 Financial Settlement Can Leave Responsibilities Outstanding

**Principle Seven: Bring external consequences and future members within the bounds of present commitments.**

The original social construction establishes a sharp fact: even when no local responsibility remains open, the same payment can carry an external source responsibility and an independent handling effect. The local account and responsibilities across sources are different objects, so emptiness of the former does not imply disappearance of the latter. See Appendix A.4; source [S4].

In economic applications, paying a contract can end a financial claim without automatically purifying water, restoring soil, making up for lost care, or rebuilding damaged conditions of life. These consequences require the relevant physical repair, continuing service, or constraints concerning irreversible effects. Rockström and colleagues include the avoidance of significant harm among the requirements for safe and just Earth system boundaries, while making clear that minimum resource access and distributive and procedural fairness need additional arrangements. [@RockstromEtAl2023] Ecological boundaries and the floor of participation must be realized together; neither can become a pretext for canceling the other.

Future members have not yet arrived, and unlimited surrender cannot be signed in their name in advance. Present institutions can preserve necessary resources, maintenance capacities, room for recovery, and channels for changing rules, while imposing stronger requirements of justification and procedure on irreversible decisions. When future members arrive, they should enter institutions through their own needs, relationships, and judgments, rather than merely inherit roles already prescribed by those who came first.

### 8.2 The Stars Begin with People

“The stars” points first to people: more people gaining the conditions to understand, express, create, meet, and begin again. Many centers can form their own ways of life and cooperation while remaining connected through services, knowledge, clearing, and responsibility. The value of polycentricity depends on whether people can participate, move, challenge, and establish alternatives, and on whether centers retain responsibility for their shared consequences.

Activity beyond Earth takes the same question to an extreme. Arriving first, building facilities, and bearing risks can generate specific use rights and contribution claims. Do they also generate the power to exclude later arrivals permanently and determine every rule? The Outer Space Treaty already treats national appropriation, international responsibility, due regard, and ownership of launched objects separately. Article II restricts national appropriation; Article VI requires authorization and continuing supervision of nongovernmental activity; Article VIII preserves ownership of objects; and Article IX addresses due regard and potentially harmful interference. [@OuterSpace1967] These distinctions provide institutional precedents for this paper. Its requirement of renewed authorization in relation to future members is further argued from the principles of participation and power.

Shared resources need concrete governance. Shared knowledge is not depleted through use in the way a quantity of water is, whereas orbits, habitats, minerals, and energy have capacities and externalities. Open access, limited use, contribution compensation, environmental maintenance, and common rules should each be arranged on their own grounds. A shared world can accommodate private activity and specific property while preserving room for later arrivals to propose new ways of living.

## 9 Every Renewal Must Establish Its Standing Anew

### 9.1 Complete Rules and Open-Ended Operation

**Principle Eight: Preserve responsibilities through institutional renewal and provide fresh sources for new possibilities.**

Original rules can specify completely how a disposition occurs while operation continues to generate new tasks, roles, and payments. Complete rules can coexist with an open future.

Each new occurrence in which payment is completed carries verifiable witnesses of service and exit. The question here is whether these complete objects can preserve what is already there while adding new actual occurrences.

**Result 8 (Complete preservation and a new frontier for every original payment).** For every cycle of the original registered type, every observation parameter, every depth, and every legal original payment at that point, the established construction preserves the input payment and connects its actual target to the next lifecycle. The target carries the complete exit constitution, every originally installed channel, external responsibilities, and its own native payment. Within this original cycle, let $H_i$ be the list of paid occurrences and $A_i$ the set of complete service–exit objects bearing their original occurrence identities. The source calls these objects authorities, referring specifically to the attached qualifications for service, exit, and continuation. Then
\[
H_{i+1}=H_i\mathbin{+\!\!+}[\gamma_{i+1}],
\qquad
A_i\subsetneq A_{i+1}.
\tag{5}
\]
The original input payment generates the target; the target's own new payment delivers the new service. See Appendix A.6; source [S6].

Strictness is carried by the identities of actual occurrences. If the added authority equaled an old authority, projecting the payment occurrence and applying injectivity of the original visits would identify the new index with a strictly smaller one. Strict inclusion between these sets of complete paid objects therefore corresponds exactly to the strict order in depth of the two complete constitutions. Instantaneous exit capacity can nevertheless remain one throughout. Equation (5) records new actual paid occurrences; it does not use the length of history as a score for total social welfare.

The same actual recursion also jointly produces later amendments and compatible futures beyond every given depth. The next entry is obtained from the preceding step's actual output, and service is still delivered through a new payment. Institutions can thus be required to remember the past while leaving rule revision and new participation open to those who come later. No present arrangement needs to be sealed as the last legitimate order.

### 9.2 Institutions Can End while People Continue

Completion of a task, expiry of original authority, settlement of contribution receipts, exit from a local role, and final performance of a responsibility are different endings. Accounting for them separately allows an arrangement to end without taking a person's whole life as collateral.

The original formal source also supplies a conservation constraint. If every progress budget in the complete source ledger is zero, the target entry contains no row from a new source, and neither transport nor the first write increases any row's budget, then no first successor contains a positive-budget row. See Appendix A.7; source [S7]. Here the budget is a structural quantity in responsibility operation. New real provision still requires its own evidence of resource production and payment. A response, a new name, or a reformulation cannot on its own serve as a new source.

Institutional renewal must therefore answer two sets of questions. Who continues to bear old commitments, and which have actually been settled? From which resources, labor, and authorization do new capabilities arise, and how do those affected take part in deciding? Institutions are allowed to end so that people can continue.

### 9.3 From Principles to Checkable Implementation

A limited pilot can begin with one necessary service: identify bearers and beneficiaries; record actual resources, the baseline, and unsettled responsibilities; preserve personal routes of refusal and exit; prepare methods and budgets for replacing providers; and allow auditors to check independently within a defined scope. Income, services, additional contributions, and authority are registered separately, with success criteria fixed before the pilot begins.

| Commitment to be tested | Observable acceptance conditions |
| --- | --- |
| Participation does not depend on a particular role | Basic services and appeals remain actually usable after refusal and exit |
| Results are open and production continues | A replacement obtains the method, actually pays for maintenance, and delivers service |
| Contributions can be settled | Additions, transfers, actual payments, and residuals connect item by item to the same source |
| Net surplus actually reaches people | Service is not reduced, burdens are not shifted elsewhere, and the person actually receives the time or resources |
| Authority is revocable and responsibilities are preserved | Original authority stops, succession has new authorization, and old responsibilities have a complete handoff |
| Auditing is bounded and replaceable | Claims, time windows, evidence permissions, and a new auditor's independent conclusions can be checked |

These checks leave room for policy choice and make failures locatable. A service shortage may require expanded provision; a broken route may require different admission rules; capture by control may require replacing authority. The same zero readout should not trigger only the same cash subsidy or administrative command. A pilot first tests whether commitments have been honored, then decides whether to expand its scope and reallocate costs.

## 10 Conclusion: Let Results Endure and Futures Remain Open

The basic division of work within an economic constitution is now visible. Basic participation protects people's beginnings; contribution settlement respects costs already borne; budgets for scarcity constrain present use; and renewed governance authorization limits continuing control over others. Joint clearing enables commitments to end. Public production enables services to continue. Self-directed time brings the surplus of technology into life. Ecological responsibility and responsibility to future members ensure that today's freedom is not obtained by closing the paths of those who arrive later.

The formal results establish key links in this division of work. Complete action portfolios preserve conditions of life that a single capacity omits, and refined provenance preserves reasons for repair. Two rounds of innovation demonstrate exploration and renewed payment, while the cumulative receipt bound prevents indefinite reissuance of an old contribution. Public methods preserve every previously legal continuation. Public functions preserve responsibilities through arbitrary finite continuation while allowing original authority to expire. Together, these results support a practical institutional direction: achievements can pass to more people, responsibilities can be traced to their original sources, services can change providers, and people can leave and begin again.

Freedom has to be produced. Institutions that produce freedom must also remain answerable to the continuing judgment of free people.

## Sources and Proofs

The eight institutional principles are the author's normative argument; Results 1–8 use constructions already proved in the existing sources. Technical Appendix A presents the social and clearing results; B covers capital, innovation, and public production; C covers public functions and independent planning; and D presents the monetary and bounded-audit contracts still to be implemented. Each section preserves the original quantifiers, provenance, actual consumers, and version identity. Exact mappings for source keys [S1–S7], [CF1–CF5], [PP1–PP4], [PF1–PF4], and [PL1–PL3] appear in the appendices and the paper's source register. Public functions use the completed current-frame source, while independent planning retains its own version; the two are not spliced into a shared run. The actual availability of public proof targets is recorded separately in the source-availability statement.

## References

[AcemogluRestrepo2019] Acemoglu, Daron, and Pascual Restrepo. 2019. “Automation and New Tasks: How Technology Displaces and Reinstates Labor.” *Journal of Economic Perspectives* 33(2): 3–30. [doi:10.1257/jep.33.2.3](https://doi.org/10.1257/jep.33.2.3).

[Arrow1962] Arrow, Kenneth J. 1962. “[Economic Welfare and the Allocation of Resources for Invention](https://www.nber.org/system/files/chapters/c2144/c2144.pdf).” In *The Rate and Direction of Inventive Activity: Economic and Social Factors*, 609–626. Princeton University Press for NBER.

[Benkler2002] Benkler, Yochai. 2002. “[Coase's Penguin, or, Linux and the Nature of the Firm](https://yalelawjournal.org/article/coases-penguin-or-linux-and-the-nature-of-the-firm).” *Yale Law Journal* 112: 369–446.

[Bohm1928] Böhm, Franz. 2008 [1928]. “[Das Problem der privaten Macht. Ein Beitrag zur Monopolfrage](https://api.pageplace.de/preview/DT0400.9783161514760_A27134534/preview-9783161514760_A27134534.pdf#page=59).” In *Grundtexte zur Freiburger Tradition der Ordnungsökonomik*, edited by Nils Goldschmidt and Michael Wohlgemuth, 49–67. Tübingen: Mohr Siebeck.

[BohmEtAl1936] Böhm, Franz, Walter Eucken, and Hans Großmann-Doerth. 2008 [1936]. “[Unsere Aufgabe](https://api.pageplace.de/preview/DT0400.9783161514760_A27134534/preview-9783161514760_A27134534.pdf#page=37).” In *Grundtexte zur Freiburger Tradition der Ordnungsökonomik*, edited by Nils Goldschmidt and Michael Wohlgemuth, 27–37. Tübingen: Mohr Siebeck.

[Buchanan1975] Buchanan, James M. 2000 [1975]. *[The Limits of Liberty: Between Anarchy and Leviathan](https://oll-resources.s3.us-east-2.amazonaws.com/oll3/store/titles/1827/0102-07_LFeBk.pdf)*. The Collected Works of James M. Buchanan, vol. 7. Indianapolis: Liberty Fund.

[Coote2021] Coote, Anna. 2021. “Universal Basic Services and Sustainable Consumption.” *Sustainability: Science, Practice and Policy* 17(1): 32–46. [doi:10.1080/15487733.2020.1843854](https://doi.org/10.1080/15487733.2020.1843854).

[DuttingEtAl2019] Dütting, Paul, Zhe Feng, Harikrishna Narasimhan, David C. Parkes, and Sai Srivatsa Ravindranath. 2019. “[Optimal Auctions through Deep Learning](https://proceedings.mlr.press/v97/duetting19a.html).” *Proceedings of Machine Learning Research* 97: 1706–1715.

[FanEtAl2025] Fan, Wen, Juliet B. Schor, Orla Kelly, and Guolin Gu. 2025. “Work Time Reduction via a 4-Day Workweek Finds Improvements in Workers' Well-Being.” *Nature Human Behaviour* 9: 2153–2168. [doi:10.1038/s41562-025-02259-6](https://doi.org/10.1038/s41562-025-02259-6).

[Fraser2016] Fraser, Nancy. 2016. “[Contradictions of Capital and Care](https://newleftreview.org/issues/ii100/articles/nancy-fraser-contradictions-of-capital-and-care).” *New Left Review* 100: 99–117.

[Hayek1945] Hayek, F. A. 1945. “[The Use of Knowledge in Society](https://www.econlib.org/library/Essays/hykKnw.html).” *American Economic Review* 35(4): 519–530.

[Keynes1943] United Kingdom. 1943. *[Proposals for an International Clearing Union](https://fraser.stlouisfed.org/title/federal-reserve-bulletin-62/june-1943-21058/fulltext)*. Cmd. 6437. London: HMSO. April.

[Knight1921] Knight, Frank H. 1921. *[Risk, Uncertainty, and Profit](https://www.econlib.org/library/Knight/knRUP.html?chapter_num=9)*. Boston and New York: Houghton Mifflin.

[Lehner2026] Lehner, Lukas. 2026. “[What Do Unemployed Workers Want: Guaranteed Jobs or Guaranteed Income](https://www.levyinstitute.org/publications/what-do-unemployed-workers-want/).” Working Paper No. 1125. Levy Economics Institute of Bard College. July 31.

[Nissenbaum2004] Nissenbaum, Helen. 2004. “[Privacy as Contextual Integrity](https://nissenbaum.tech.cornell.edu/papers/H.%20Nissenbaum%2C%20_Privacy%20as%20Contextual%20Integrity.pdf).” *Washington Law Review* 79: 119–158.

[Ostrom2009] Ostrom, Elinor. 2009. “[Beyond Markets and States: Polycentric Governance of Complex Economic Systems](https://www.nobelprize.org/uploads/2018/06/ostrom_lecture.pdf).” Nobel Prize Lecture, December 8.

[OuterSpace1967] *[Treaty on Principles Governing the Activities of States in the Exploration and Use of Outer Space, including the Moon and Other Celestial Bodies](https://www.nasa.gov/history/SP-4225/documentation/cooperation/treaty.htm)*. 1967. *United Nations Treaty Series* 610: 205, No. 8843.

[Pistor2019] Pistor, Katharina. 2019. “Coding Capital for the Globe.” *Stanford Social Innovation Review*, September 4. Authorized excerpt from *The Code of Capital*. [doi:10.48558/GYV7-NE54](https://doi.org/10.48558/GYV7-NE54).

[Robeyns2017] Robeyns, Ingrid. 2017. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Cambridge: Open Book Publishers. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[RockstromEtAl2023] Rockström, Johan, Joyeeta Gupta, Dahe Qin, et al. 2023. “Safe and Just Earth System Boundaries.” *Nature* 619: 102–111. [doi:10.1038/s41586-023-06083-8](https://doi.org/10.1038/s41586-023-06083-8).

[Sen1980] Sen, Amartya. 1980. “[Equality of What?](https://tannerlectures.org/documents/sen80/)” In *The Tanner Lectures on Human Values*, vol. 1, edited by Sterling M. McMurrin, 197–220. Cambridge University Press. Lecture delivered on May 22, 1979.

[Tcherneva2018] Tcherneva, Pavlina R. 2018. *[The Job Guarantee: Design, Jobs, and Implementation](https://www.levyinstitute.org/wp-content/uploads/2024/02/wp_902.pdf)*. Working Paper No. 902. Levy Economics Institute of Bard College. April.

[VanParijs1991] Van Parijs, Philippe. 1991. “[Why Surfers Should Be Fed: The Liberal Case for an Unconditional Basic Income](https://research.dial.uclouvain.be/entities/publication/534c7134-40b6-4992-a63e-62348da4af63).” *Philosophy & Public Affairs* 20(2): 101–131.
