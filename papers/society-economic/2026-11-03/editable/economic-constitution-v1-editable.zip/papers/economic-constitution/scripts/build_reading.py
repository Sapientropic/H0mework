#!/usr/bin/env python3
"""Build four separate reading PDFs with the read-only shared PDF builder.

Examples:
  python3 papers/economic-constitution/scripts/build_reading.py
  python3 papers/economic-constitution/scripts/build_reading.py --language zh
  python3 papers/economic-constitution/scripts/build_reading.py --language en --part main

Only targets, running heads, continuous appendix layout, reference spacing
and subsection keep-space are configured here. No prose, formula or citation is rewritten
by this paper's wrapper.
"""
from __future__ import annotations
import argparse
from functools import partial
import importlib.util
import json
from pathlib import Path
import re
import sys

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
SHARED = PUBLISH / "shared" / "scripts"
sys.dont_write_bytecode = True
sys.path.insert(0, str(SHARED))
spec = importlib.util.spec_from_file_location("economic_constitution_shared_pdf", SHARED / "build_pdf.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
REL = PAPER.relative_to(PUBLISH).as_posix()
TARGETS = {
    ("main", "zh"): (f"{REL}/manuscript.md",
        ("economic-constitution", "可能性的经济宪法", "生产、清算与续约")),
    ("main", "en"): (f"{REL}/manuscript-en.md",
        ("economic-constitution", "The Economic Constitution of Possibility", "Production, clearing and renewal")),
    ("supplement", "zh"): (f"{REL}/supplement.md",
        ("economic-constitution-supplement", "可能性的经济宪法 · 技术附录", "构造、证明与实物账")),
    ("supplement", "en"): (f"{REL}/supplement-en.md",
        ("economic-constitution-supplement", "Economic Constitution · Technical Supplement", "Constructions, proofs and physical accounts")),
}
for rel, heads in TARGETS.values():
    builder.EXPLICIT_RUNHEADS[rel] = heads
    builder.CONTINUOUS_APPENDICES.add(rel)

_shared_prepare = builder.prepare

def prepare_with_breakable_references(source, toc, profile, *, reference_parskip=None, keep_subsections=False, group_parent_child=False):
    """Remove only the shared builder's whole-bibliography minipage.

    A long bibliography must be able to break across pages. Abstract blocks
    retain the shared layout. Reference text and numbering remain untouched.
    """
    title, subtitle, body = _shared_prepare(source, toc, profile)
    ref = re.search("(?m)" + builder.REFERENCES, body)
    if ref is not None:
        opening = "```{=latex}\n\\noindent\\begin{minipage}{\\linewidth}\n```\n\n"
        prefix = body[:ref.start()]
        if not prefix.endswith(opening):
            raise RuntimeError("Shared bibliography layout changed; inspect the local adapter.")
        body = prefix[:-len(opening)] + body[ref.start():]
        closing = "\\endgroup\\end{minipage}\\par"
        end = body.rfind(closing)
        if end < 0:
            raise RuntimeError("Shared bibliography closing block is missing.")
        body = body[:end] + "\\endgroup\\par" + body[end+len(closing):]
        if reference_parskip is not None:
            # Keep the shared type size and leading; adjust inter-entry space only.
            heading = re.search("(?m)" + builder.REFERENCES, body)
            prefix, bibliography = body[:heading.start()], body[heading.start():]
            old_spacing = "\\setlength{\\parskip}{0.45em}"
            if bibliography.count(old_spacing) != 1:
                raise RuntimeError("Shared bibliography spacing changed; inspect the local adapter.")
            bibliography = bibliography.replace(old_spacing,
                "\\setlength{\\parskip}{" + reference_parskip + "}", 1)
            body = prefix + bibliography
    if keep_subsections:
        # Source H3 headings become H2 here. Reserve space before a heading
        # or a directly adjacent parent/child group, never inside that group.
        lines = body.splitlines(keepends=True)
        kept = []
        inside_fence = False
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.lstrip().startswith("```"):
                inside_fence = not inside_fence
                kept.append(line)
                i += 1
                continue
            if not inside_fence and group_parent_child and re.match(r"^# ", line):
                j = i + 1
                while j < len(lines) and not lines[j].strip():
                    j += 1
                if j < len(lines) and re.match(r"^## ", lines[j]):
                    kept.append("```{=latex}\n\\Needspace{16\\baselineskip}\n```\n\n")
                    kept.extend(lines[i:j+1])
                    i = j + 1
                    continue
            if not inside_fence and re.match(r"^## ", line):
                kept.append("```{=latex}\n\\Needspace{11\\baselineskip}\n```\n\n")
            kept.append(line)
            i += 1
        body = "".join(kept)
    return title, subtitle, body

builder.prepare = prepare_with_breakable_references

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--language", choices=["zh", "en", "both"], default="both")
    ap.add_argument("--part", choices=["main", "supplement", "all"], default="all")
    ap.add_argument("--no-toc", action="store_true")
    ap.add_argument("--output-dir", type=Path, default=PAPER / "build")
    args = ap.parse_args()
    langs = ["zh", "en"] if args.language == "both" else [args.language]
    parts = ["main", "supplement"] if args.part == "all" else [args.part]
    selected = [(part,lang) for part in parts for lang in langs]
    missing = [str(PUBLISH / TARGETS[key][0]) for key in selected
               if not (PUBLISH / TARGETS[key][0]).is_file()]
    if missing:
        raise FileNotFoundError("Manuscripts are not ready: " + ", ".join(missing))
    reports = []
    for key in selected:
        rel, _ = TARGETS[key]
        print(json.dumps({"building": rel}, ensure_ascii=False), flush=True)
        builder.prepare = partial(prepare_with_breakable_references,
            reference_parskip={("main", "zh"): "0.15em", ("main", "en"): "0.30em"}.get(key),
            keep_subsections=key in {("main", "en"), ("supplement", "zh")},
            group_parent_child=key == ("main", "en"))
        report = builder.build(rel, toc=not args.no_toc, output_dir=args.output_dir)
        reports.append(report)
        print(json.dumps(report, ensure_ascii=False), flush=True)
    if any(r["missing_characters"] or r["overfull_boxes"] for r in reports):
        raise SystemExit("Rendered output needs layout inspection; see build-report.json.")

if __name__ == "__main__":
    main()
