#!/usr/bin/env python3
"""Bind the frozen paper interfaces to accepted, alias-aware H0 source records."""
from pathlib import Path
import argparse
import copy
import gzip
import hashlib
import json
import re
import sys

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
COMMIT = "2d6fbc96e33b7c4c3cfd91104fda74e3caeda045"
REPOSITORY = "https://github.com/Sapientropic/H0mework"
MAP = "docs/economic-constitution-map.json"
SELECTION = "checks/economic-constitution-selection.json"
ACCEPTANCE = "evidence/economic-constitution/acceptance/initial-intake/"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def core(records):
    return [{k: row.get(k) for k in ("key", "epoch", "path", "sha256", "declarations", "direct_consumers")} for row in records]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--h0-repository", type=Path, default=PUBLISH.parents[1] / "H0mework")
    parser.add_argument("--h0-commit", default=COMMIT)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-f]{40}", args.h0_commit):
        raise ValueError("An exact H0 commit is required")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(args.h0_repository / "tools"))
    import source_view as sv
    from whole_ledger_export import FixedGit

    git = FixedGit(args.h0_repository)
    try:
        read = lambda path: git.read(args.h0_commit, path)
        registry_path = PAPER / "records/source-correspondence.json"
        previous = json.loads(registry_path.read_bytes())
        records = copy.deepcopy(previous["source_records"])
        original_core = core(records)
        assert len(records) == 90 and len({(r["epoch"], r["path"]) for r in records}) == 76
        assert sum(len(r["declarations"]) for r in records) == 172
        mapping_raw, export_raw, selection_raw = read(MAP), read("tools/export-map.json"), read(SELECTION)
        mapping, exported = json.loads(mapping_raw), json.loads(export_raw)
        assert mapping["acceptance"]["status"] == "passed"
        assert mapping["acceptance"]["selection_sha256"] == sha(selection_raw)
        summary = json.loads(read(ACCEPTANCE + "summary.json"))
        assert summary["status"] == "passed" and summary["claim_map_sha256"] == sha(mapping_raw)
        receipts = {}
        for kind in ("build", "trust", "declaration_types"):
            ref = mapping["acceptance"][kind]
            raw = read(ref["path"])
            assert sha(raw) == ref["sha256"]
            payload = gzip.decompress(raw) if ref.get("compression") == "gzip" else raw
            assert sha(payload) == ref["payload_sha256"]
            receipt = json.loads(payload)
            assert receipt["inputs_unchanged"] is True and receipt["input_identity"] == receipt["input_identity_after"]
            assert receipt.get("ok", receipt.get("status") == "passed") is True
            receipts[kind] = receipt
        type_rows = receipts["declaration_types"]["declarations"]
        assert len(type_rows) == 3313
        rows = {row["target"]: row for row in exported["modules"]}
        entries = [(c["id"], role, e) for c in mapping["claims"] for role in ("producers", "direct_consumers") for e in c[role]]
        resources = [e for c in mapping["claims"] for e in c["resources"]]
        packages = {p["id"]: p for p in mapping["proof_packages"]}
        assert len(packages) == 16
        source_cache, layouts = {}, {}

        def module(target):
            if target not in source_cache:
                row = rows[target]
                raw = read(row["path"])
                assert sha(raw) == row["target_sha256"]
                source_cache[target] = (raw, [n for _, _, n in sv.import_tokens(raw.decode())])
            return source_cache[target]

        def layout(target):
            todo, active = [(target, False)], set()
            while todo:
                current, expanded = todo.pop()
                if current in layouts:
                    continue
                children = [n for n in module(current)[1] if n in rows]
                if expanded:
                    active.remove(current)
                    row = rows[current]
                    layouts[current] = sv.layout_identity(row["source_path"], row["source_sha256"], row.get("source_origin"), [layouts[c] for c in children])
                else:
                    assert current not in active, "Public import cycle"
                    active.add(current)
                    todo.append((current, True))
                    todo.extend((c, False) for c in children if c not in layouts)
            return layouts[target]

        declarations, modules = {}, {}

        def bind(entry, declaration):
            public, verification = entry["public"], entry["verification"]
            owner = rows[public["module"]]
            assert (owner["path"], owner["target_sha256"]) == (public["path"], public["sha256"])
            record = sv.source_record(owner, entry["source_path"], entry["source_commit"])
            assert record is not None and sv.row_at(record, entry["source_commit"])
            assert record["source_sha256"] == entry["source_sha256"] and record.get("source_origin") == entry.get("source_origin")
            assert verification["kernel"] == "passed"
            package = verification["proof_package"]
            assert verification["source_scope_sha256"] == packages[package]["accepted_source_scope_sha256"]
            ref, name = declaration["complete_type"], declaration["qualified_name"]
            checked = type_rows[ref["declaration_index"]]
            assert (checked["module"], checked["qualified_name"], checked["package"]) == (owner["target"], name, package)
            assert sha(checked["type"].encode()) == ref["type_sha256"]
            assert checked["kernel_equivalent"] is True and not checked["unsafe"] and not checked["partial"]
            assert set(checked["axioms"]) <= {"propext", "Classical.choice", "Quot.sound"}
            identifier = "d-" + sha((package + ":" + owner["target"] + ":" + name).encode())[:16]
            if identifier not in declarations:
                declarations[identifier] = {"qualified_name": name, "public_module": owner["target"], "proof_package": package,
                    "source_commit": entry["source_commit"], "source_path": entry["source_path"], "source_sha256": entry["source_sha256"],
                    "source_origin": record.get("source_origin"),
                    "source_line": declaration.get("source_line"), "source_signature": declaration.get("source_signature"),
                    "original_kind": declaration.get("original_kind", declaration.get("kind")), "source_name": declaration.get("source_name"),
                    "complete_type": {**ref, "receipt": "declaration_types", "format": checked["type_format"], "kernel_equivalent": True},
                    "axioms": checked["axioms"], "unsafe": False, "partial": False}
            if owner["target"] not in modules:
                modules[owner["target"]] = {"module": owner["target"], "path": owner["path"], "target_sha256": owner["target_sha256"],
                    "source_view_recursive_layout_sha256": layout(owner["target"]), "actual_imports": module(owner["target"])[1]}
            return identifier

        def find(epoch, path, name=None):
            return [(e, d) for _, _, e in entries if e["source_commit"] == epoch and (path is None or e["source_path"] == path)
                    for d in e["declarations"] if name is None or d.get("source_name", d["qualified_name"]) == name
                    or d.get("source_name", d["qualified_name"]).endswith("." + name)]

        def ids(matches):
            return sorted({bind(e, d) for e, d in matches})

        def consumers(row):
            original = row.get("direct_consumers") or []
            if isinstance(original, str):
                named = re.findall(r"(Lean/[^;\n]*?\.lean)\s*::\s*([^;\n]+)", original)
                original = ([{"path": p, "declaration": n.strip()} for p, n in named] if named else
                    [{"path": p} for p in re.findall(r"Lean/[^;\n]*?\.lean", original)] or [{"description": original}])
            result = []
            for reference in original:
                epoch = reference.get("epoch", reference.get("commit", row["epoch"]))
                path, name = reference.get("path"), reference.get("declaration")
                accepted = find(epoch, path, name) if path else []
                if not accepted and name:
                    accepted = find(epoch, None, name)
                item = {"original_reference": reference}
                if accepted:
                    item.update(kind="accepted-declaration-observation", declaration_ids=ids(accepted))
                else:
                    artifacts = [e for e in resources if e["source_commit"] == epoch and e["source_path"] == path]
                    if artifacts:
                        artifact = artifacts[0]
                        assert sha(read(artifact["public"]["path"])) == artifact["public"]["sha256"]
                        item.update(kind="preserved-original-program", public=artifact["public"], source_sha256=artifact["source_sha256"], fresh_H0_actual_execution=False)
                    else:
                        item["kind"] = "original-reference"
                    suffixes = (["selection_compares_every_same_future_adaptive_opponent", "Receipt.review_accepts_its_generated_result"] if row["key"] == "PL1" else
                                ["Micro.Cursor.move_core", "Micro.Session.completed_full_work"] if row["key"] == "PL2" else [])
                    item["accepted_consumer_ids"] = ids([match for n in suffixes for match in find(epoch, None, n)])
                    if path and path.endswith("public-source-owned-iteration-consumer.lean"):
                        item["accepted_contract_package"] = "economic-constitution-consumer-public-source-owned-iteration-contract-6c245933"
                result.append(item)
            return result

        named_ids = set()
        for number, row in enumerate(records, 1):
            row["record_id"] = f"r{number:03d}"
            matched, names = [], []
            for name in row["declarations"]:
                found = find(row["epoch"], row["path"], name)
                bound = ids(found)
                assert len(bound) == 1, (row["key"], row["path"], name, bound)
                named_ids.add(bound[0])
                observed = declarations[bound[0]]
                names.append({"original_name": name, "declaration_id": bound[0],
                    "qualified_name": observed["qualified_name"], "public_module": observed["public_module"],
                    "source_line": observed["source_line"], "complete_type": observed["complete_type"]})
                matched.extend(found)
            row["public_targets"] = []
            for target in sorted({e["public"]["module"] for e, _ in matched}):
                owner = rows[target]
                record = sv.source_record(owner, row["path"], row["epoch"])
                assert record and record["source_sha256"] == row["sha256"] and sv.row_at(record, row["epoch"])
                row["public_targets"].append({"path": owner["path"], "module": target, "source_revision": record["source_revision"],
                    "source_revisions": record["source_revisions"], "source_origin": record.get("source_origin"),
                    "target_sha256_expected": owner["target_sha256"], "target_sha256_actual": sha(module(target)[0]),
                    "target_bytes_match": True, "selected_epoch_declared": True, "source_view_recursive_layout_sha256": layout(target)})
            row.update(public_status="mapped-and-locally-accepted", public_declarations=names, public_consumer_bindings=consumers(row))
        assert core(records) == original_core

        program_rows, observation_ids = [], set()
        for program in mapping["original_consumer_programs"]:
            package = packages[program["package"]]
            target = package["lean_target"]
            owner, observations = rows[target], []
            for rule in owner["anonymous_consumer_names"]:
                found = [(e, d) for _, _, e in entries if e["public"]["module"] == target for d in e["declarations"] if d["qualified_name"] == rule["target_name"]]
                bound = ids(found)
                assert len(bound) == 1 and rule["target_name"] == sv.anonymous_consumer_name(target, rule["ordinal"])
                assert rule["target_name"].split(".").count("H0mework") == 1
                observation_ids.add(bound[0])
                observations.append({"original_ordinal": rule["ordinal"], "declaration_id": bound[0], "original_kind": "anonymous-example", "instance_reducible": rule.get("instance_reducible", False)})
            assert len(observations) == program["original_contract_count"]
            source = sv.source_record(owner, program["source_path"], program["source_commit"])
            assert source and sv.row_at(source, program["source_commit"]) and source["source_sha256"] == program["source_sha256"]
            program_rows.append({"package": package["id"], "source_commit": program["source_commit"], "source_path": program["source_path"],
                "source_sha256": program["source_sha256"], "public_module": target, "public_path": owner["path"], "status": "passed",
                "scientific_registration_context": program["source_commit"], "source_origin": source.get("source_origin"),
                "source_scope_sha256": package["accepted_source_scope_sha256"], "observations": observations})
        assert len(program_rows) == 11 and len(observation_ids) == 201
        main_packages = [{"id": p["id"], "source_commit": p["source_commit"], "module": p["lean_target"],
            "path": "Lean/" + p["lean_target"].replace(".", "/") + ".lean",
            "target_sha256": sha(read("Lean/" + p["lean_target"].replace(".", "/") + ".lean")),
            "source_scope_sha256": p["accepted_source_scope_sha256"]} for p in list(packages.values())[:5]]
        module_ids = {name: f"m{i:03d}" for i, name in enumerate(sorted(modules), 1)}
        for name, row in modules.items():
            row["id"] = module_ids[name]
        for declaration in declarations.values():
            declaration["module_id"] = module_ids[declaration["public_module"]]
        snapshot = {"repository": REPOSITORY, "commit": args.h0_commit, "map": {"path": MAP, "sha256": sha(mapping_raw)},
            "selection": {"path": SELECTION, "sha256": sha(selection_raw)}, "export_map": {"path": "tools/export-map.json", "sha256": sha(export_raw)},
            "reproduction": "docs/economic-constitution-reproduction.md", "readiness": "docs/economic-constitution-readiness.md",
            "acceptance_summary": ACCEPTANCE + "summary.json", "receipts": mapping["acceptance"], "cache_report": ACCEPTANCE + "cache/current-report.json"}
        binding = {"schema": "economic-constitution/public-source-binding@1", "snapshot": snapshot,
            "identity_method": "Accepted paper map chooses the owner. source_view.source_record selects its exact source alias at the original epoch; target bytes, recursive actual imports, accepted package scope and complete-type index are checked. No path/SHA-only owner matching.",
            "original_interfaces_sha256": sha(encode(original_core)),
            "summary": {"source_keys": 23, "source_records": 90, "epoch_file_identities": 76, "named_adoptions": 172, "named_adoption_identities": len(named_ids),
                "accepted_packages": 16, "complete_types_in_H0_receipt": 3313, "original_anonymous_observations": 201, "local_acceptance": "passed", "remote_CI_run": False},
            "main_packages": main_packages, "consumer_programs": program_rows, "modules": sorted(modules.values(), key=lambda x: x["id"]),
            "declarations": dict(sorted(declarations.items())),
            "by_key": {key: [{"record_id": r["record_id"], "declaration_ids": [d["declaration_id"] for d in r["public_declarations"]], "consumer_bindings": r["public_consumer_bindings"]}
                for r in records if r["key"] == key] for key in dict.fromkeys(r["key"] for r in records)}}
        current = copy.deepcopy(previous)
        original_observation = current.pop("observed_at_utc", None)
        current.setdefault("original_source_inspection", {"observed_at_utc": original_observation,
            "scope": "Original fixed-source inspection; the accepted H0 snapshot and receipts are identified separately."})
        current.update(source_repository=exported["source_repository"], public_head=args.h0_commit, public_export_map_sha256=sha(export_raw), source_records=records,
            public_binding={"path": "records/public-source-binding.json", "sha256": sha(encode(binding)), "snapshot": snapshot})
        current["summary"].update(unique_public_targets_checked=len({t["module"] for r in records for t in r["public_targets"]}), public_identity_status={"mapped-and-locally-accepted": 76},
            accepted_named_adoptions=172, accepted_anonymous_observations=201, accepted_packages=16, complete_types_in_H0_receipt=3313)
        lines = ["# 原声明、消费者与实际源码绑定", "", f"源码快照：[{REPOSITORY}]({REPOSITORY})，提交 `{args.h0_commit}`。路径均相对于该仓库；可得性见[统一说明](source-availability.md)。", "",
            "本表保留23个来源键、90行接口、76个原版本／文件身份和172次声明采用。完整限定名、原声明头、实际 owner、递归环境与逐项完整类型索引见[机器绑定](records/public-source-binding.json)。`Tn` 表示该快照验收类型回执的第 n 项（从0计）；原匿名例另以201个可逆观测名登记。", "",
            "原认证与原 actual 程序保留历史身份；当前本地验收由十六个独立包承担，原引用与实际验收入口分别列出。", ""]
        for key in binding["by_key"]:
            lines.extend(["## " + key, ""])
            for r in records:
                if r["key"] != key:
                    continue
                lines.extend(["### " + r["record_id"], "", f"- 原来源：`{r['epoch']}` · `{r['path']}`。", "- 原 SHA256：`" + r["sha256"] + "`。"])
                for name in r["public_declarations"]:
                    d = declarations[name["declaration_id"]]
                    lines.append(f"- `{name['original_name']}` → `{d['module_id']}` · `T{d['complete_type']['declaration_index']}`；完整名与类型绑定：`{name['declaration_id']}`。")
                lines.append("- 原消费者及当前验收对应：本行 `public_consumer_bindings`；原 actual 程序、匿名合同与旁引按实际类别保留。" if r["public_consumer_bindings"] else "- 本行是采用接口；实际下游与整包检查由H0逐主张映射及包入口给出。")
                lines.append("")
        lines.extend(["## 模块登记", "", "以下名称为实际完整 Lean 模块；文件路径与字节、递归环境哈希见机器绑定同号条目。", ""])
        for item in binding["modules"]:
            lines.extend([f"- `{item['id']}`：`{item['module']}`。", ""])
        outputs = {registry_path: encode(current), PAPER / "records/public-source-binding.json": encode(binding), PAPER / "source-correspondence.md": ("\n".join(lines) + "\n").encode()}
        for path, raw in outputs.items():
            assert not re.search(rb"/(?:Users|Volumes|home)/", raw), "Private local path in public binding"
            if args.check:
                assert path.read_bytes() == raw, "Generated source binding is stale: " + str(path.relative_to(PUBLISH))
            else:
                path.write_bytes(raw)
        print(json.dumps({"status": "passed", **binding["summary"], "checked_recursive_public_modules": len(layouts), "generated_files": {str(p.relative_to(PUBLISH)): sha(raw) for p, raw in outputs.items()},
            "original_source_projection_unchanged": core(records) == original_core, "new_Lean_execution": False}, ensure_ascii=False, indent=2))
    finally:
        git.close()


if __name__ == "__main__":
    main()
