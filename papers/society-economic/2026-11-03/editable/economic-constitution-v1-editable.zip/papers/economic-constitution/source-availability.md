# 来源、原认证与源码可得性

## 固定源码快照

本稿形式证明绑定 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) 提交 `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`。本文以固定提交链接和仓库相对路径定位材料。所列验收回执记录完整本地执行；远端CI状态按该提交的实际运行另记。

当前快照已准确绑定本文23个来源键、90行接口、76个原版本／文件身份及172项具名采用。它们的实际公共模块、完整限定名、原声明头、原消费者、来源别名和完整类型位置见[逐键对应](source-correspondence.md)、[原接口索引](records/source-correspondence.json)及[机器源码绑定](records/public-source-binding.json)。原路径的相同字节不单独决定owner：绑定先使用已验收逐主张映射，再核对该epoch的source alias、实际递归导入环境和验收包身份。

## 选集、入口与实际验收

以下路径均相对于上述H0mework快照。

| 材料 | 固定路径 |
| --- | --- |
| 完整有限选集 | `checks/economic-constitution-selection.json` |
| 逐主张与完整类型映射 | `docs/economic-constitution-map.json` |
| 复现命令 | `docs/economic-constitution-reproduction.md` |
| 验收状态 | `docs/economic-constitution-readiness.md` |
| 实际验收汇总 | `evidence/economic-constitution/acceptance/initial-intake/summary.json` |

五个主包与十一份独立原消费者的实际Lean入口列在双语附录E，并在机器源码绑定中逐一保存模块、文件及源范围哈希。完整本地构建、trust与3313项完整类型均通过，执行前后输入稳定；公理为`propext`、`Classical.choice`、`Quot.sound`，unsafe=0、partial=0。完整类型以Lean表达式DAG保存，逐项绑定回执哈希、索引、类型哈希和kernel等价结果。

十一份程序中的201个原匿名例具有可逆检查观测名，保留原类型、值与原序号；这些名称不是杜撰的原声明名。原两轮actual程序及其历史回执另作保全，不与这201个本地合同观测混同。两条未作为独立类型根采用的具名历史旁引保留为original-reference，并给出当前实际已验收消费者，不补造类型索引。

## 原证明与科学认证身份

| 来源 | 采用身份 | 原认证处理 |
| --- | --- | --- |
| 社会、资本、公共生产 | df421ff600085cbc290a7ae946193961bed7c83b为收稿上限；旧结果保原e60、fde5、1d等epoch | 原T1／strict与本次H0完整验收分别记账 |
| 公共功能 | 6c24593364cd7763e3cdccf8f3654996a6dc8b5f，current-frame | 1200份原源码与58份原证据保原SHA；原54份strict、75项合同、七路两轮12/12及续行17项合同保原判决 |
| 原净俘获负担结果 | 由6c包采用实际声明 | 原科学epoch46179f5a71befa335f40ece16ca0b839b4ba835b保留 |
| 独立公共规划 | 59df7e39d81e8698f3cf8507e64b93829bb1cac3 | 保独立初始切口、目录、会话与实际票据；不与current-frame拼成一次运行 |

原认证与材料身份见[历史证据](https://github.com/Sapientropic/H0mework/blob/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045/docs/economic-constitution-map.json)。资本CF1的23个owned模块保原T1身份；CF2—CF5不补造独立认证日期。公共生产的原SharedAudit、Participation与ArtifactZero记录各保其范围；原科学执行不因本地证明验收而重算。必要辅助源的固定补充与可逆构建适配由H0映射的source record记录，原失败源及失败回执保持原状态。

原`48dc9ad13ffa79d9c2e9a93a8bc755a2388320bc`的缺项观察仍可从[历史诊断](https://github.com/Sapientropic/H0mework/blob/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045/docs/economic-constitution-readiness.md)复核，其版本不代表当前固定快照的映射状态。

## English availability note

The formal proof materials are bound to [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045), commit `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`. References use the fixed commit link and repository-relative paths. The acceptance receipts record complete local execution; remote CI is reported separately through the actual run for that commit.

All 23 source keys, 90 interface rows, 76 original epoch/file identities, and 172 named adoptions have exact current bindings. The accepted claim map, source aliases, recursive import environments, actual owners, complete type indices, and original consumers are recorded in the registers linked above. The sixteen independent packages passed complete local build, trust, and 3313 complete-type checks with stable inputs, the three standard axioms, and no unsafe or partial declarations. Their 201 original anonymous cases retain their original types and values under reversible observation names. Original scientific runs and certifications keep their own epochs and verdicts, separately from this H0 acceptance.
