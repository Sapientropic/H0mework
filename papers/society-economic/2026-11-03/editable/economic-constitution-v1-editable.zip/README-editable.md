# economic-constitution · editable v1

The four bilingual Markdown texts, all referenced editable SVG and vector PDF
figures, figure source, original bibliography entries, metadata, current source
correspondence and public proof bindings retain their publish-relative layout.
The bibliography is part of the manuscripts. No research repository, private
prompt material, raw internal record, font binary or build cache is included.

Verify the extracted inputs before generating additional files:

```sh
python3 verify-inputs.py
```

Run these commands from this extracted root to build the two main PDFs and two
technical appendices separately:

```sh
python3 papers/economic-constitution/scripts/build_reading.py --language zh --part main
python3 papers/economic-constitution/scripts/build_reading.py --language en --part main
python3 papers/economic-constitution/scripts/build_reading.py --language zh --part supplement
python3 papers/economic-constitution/scripts/build_reading.py --language en --part supplement
```

Requirements: Python 3, Pandoc 3, XeLaTeX with xeCJK and unicode-math, and Noto
Serif/Sans CJK SC plus STIX Two fonts. The accepted pipeline uses macOS font
locations. Vector figure regeneration additionally uses fontTools, CairoSVG
and the existing macOS Cairo/CoreText font registration; the economic figures
use Google Chrome for SVG-to-PDF conversion. The shipped figure PDFs already
provide the document builder's vector inputs; no external image is downloaded.

Regenerate the bilingual figures with:

```sh
python3 papers/economic-constitution/figures/make_figures.py
```

## Fixed formal proofs and acceptance

Proof repository: https://github.com/Sapientropic/H0mework
Fixed proof commit: `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`.
`papers/economic-constitution/release-selection.json` is the exact Git byte stream of
`checks/economic-constitution-selection.json` at that commit. Its original path and SHA-256
are recorded in `editable-inputs.json`. Source epochs, consumers, actual owner
environments and complete-type references remain in the included public
binding and correspondence records.

Clone that repository and set `H0_REPO` to its root. Check out the fixed commit
before running the included source-binding check:

```sh
python3 papers/economic-constitution/scripts/build_source_index.py --h0-repository "$H0_REPO" --check
```

In the fixed H0 repository, use its dependency and cache mechanisms, then run:

```sh
make bootstrap
python3 tools/edition_release.py --edition economic-constitution verify-map
python3 tools/edition_release.py --edition economic-constitution build --output .local/reproduction/economic-constitution/build
python3 tools/edition_release.py --edition economic-constitution trust --output .local/reproduction/economic-constitution/trust
python3 tools/economic_constitution.py types --output .local/reproduction/economic-constitution/types
python3 tools/economic_constitution.py entry --require-ready --output .local/reproduction/economic-constitution/entry
```

`docs/economic-constitution-reproduction.md`, `docs/economic-constitution-readiness.md` and
`docs/economic-constitution-map.json` in that fixed repository give the full instructions and
recorded receipts. The complete local acceptance passed for 16 independent
packages and 3313 complete types, with the standard three axioms and zero
unsafe or partial declarations. Original scientific certifications and local
H0 proof acceptance retain separate epochs and execution scopes. Remote CI is
reported by its actual run; this package does not claim a new remote CI result.

The input manifest records each copied input's original and public hashes.
The economic figure-environment docstring is made portable, and its two
internal historical navigation links point to the fixed public contract.
These publication-view changes leave mathematical texts, source signatures,
JSON type strings and figure algorithms unchanged. Private original fragments
are identified by byte range and hash rather than reproduced in this archive.

Paper text and original figures: CC BY 4.0. Code and formalization: Apache-2.0.
This ZIP is an editable companion to the v1 preprint; it performs no upload or
scientific recalculation. Metadata is in `papers/economic-constitution/zenodo-metadata.json`.
