# From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory

**从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成**

**Author: Jian Gao (高健)**\
Independent Researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

> *I have heard of thee by the hearing of the ear: but now mine eye seeth thee.*
>
> — Job 42:5 (King James Version)

**Formal verification and independent audit.** The proofs and consumer modules in the first- and second-edition public selections have passed strict Lean 4 kernel verification. The independent audits cover the full dependency closure of declaration types, proof terms, and inductive and recursive metadata. The universal authority kernel governing occurrence registration, whole-ledger accounting, query compilation, recourse succession, and macro-evolution is a **zero-axiom constructive kernel** (T0, empty axiom list), while the full dependency closure of the four-dimensional continuum analysis and field-theoretic instantiation is strictly confined to the three standard Lean axioms (propositional extensionality, classical choice, and quotient soundness; T1) without back-contaminating the zero-axiom T0 kernel, and with zero research axioms or unfinished placeholders anywhere. Positive consumer chains and negative controls pass under their pre-registered contracts. The [first-release proof acceptance](https://github.com/Sapientropic/H0mework/blob/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/evidence/first-release/acceptance/proof-20261007/receipt.json), [second-edition source binding](https://github.com/Sapientropic/H0mework/blob/e9734c69f38cf03b79859a1108ae23a5663a0495/docs/assets/paper-source-binding-b9d66048.json), Appendix D, and Code and Data Availability record the audited declarations, fixed revisions, and reproduction entry points. Appendix D.9 identifies the fixed original sources of the new proofs.

## Abstract

Conventional unification and quantum field theories posit a spacetime manifold and gauge-breaking ansatz first, then adjoin complex Hilbert spaces, canonical (anti)commutation relations, the Born probability rule, and measurement collapse as external postulates. Working over a zero-axiom constructive occurrence and whole-ledger kernel (T0) from a single positive-source occurrence with zero observation-fitted parameters, we enforce an **Anti-Magic Pruning Law**—forbidding pre-supplied metric, Hilbert/Fock, global-Hamiltonian, Born, or collapse shells—to complete an end-to-end **Stage 1–10 continuous–quantum unified field closure**: four-dimensional $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ continuum geometry and field equations on one side, and noncommutative quantum kinematics, operator dynamics, and open-instrument readouts on the other, are proved to be **compatible dependent projections generated on demand from the same root occurrence**. On the continuum face, vacuity counterexamples and dual-axis gates exclude trivial shortcuts; the fixed source generates the coframe, connections, the Standard Model subalgebra $\mathfrak h_{\rm SM}=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$ selected bijectively by spectral commutation plus block trace laws, and 252-complex-dimensional chiral exterior-power matter free of cubic and five mixed anomalies. The first-order common action with an independent linear dual $\chi$ is nonseparable ($\Delta_{\rm mix}=9$); across arbitrary smooth nondegenerate configurations, four-leg gravitational stationarity is equivalent to simplicity $B=\mathrm{II}^+(e)$, the unique reaction multiplier, explicit Einstein–Cartan balance, and matter-coupled torsion–spin. The fixed synchronized configuration has a pair-exchange defect of $5/8$, with a nonzero compatibility residual throughout its $\mathrm{Spin}^+(1,3)$ orbit. An explicit six-sector nine-field solution is unique under lawful weak history recovery, while on the fixed Cauchy background weighted mother-action weak zeros match Volterra fixed points with full-measure $L^2$ uniqueness and derivative-loss-free all-order symmetric-hyperbolic energy closure.

On the quantum-projection and full-field-return face, without wavefunction or Fock priors, the designated solution yields across all $A\in\operatorname{End}_{\mathbb C}(\mathbb C^{252})$ the exact nonperturbative identity $\chi(A\psi)=4\sqrt2\langle v,R(A)v\rangle=4\sqrt2\langle I(v),\mathrm{d}\Gamma(R(A))I(v)\rangle$, and via a four-sector Legendre map and three-stabilizer section derives the common generator $H=H_0+Y$ over 61 scalar CCR pairs and a 504-mode two-branch CAR algebra, an all-order quantum clock, bounded self-adjoint energy tail $R$, unit CAR created state preserving joint charge characters and twelve-direction temporal normalization, and the full Ward identity. The mother Fréchet second variation reproduces $H_{289}$ entry by entry; the nonlinear constant-field Noether half-axis is $C^2$ with full-field derivative $\Pi_{\rm st}$, rendering regular feedback equivalent to the original response plus the nine-constraint Schur system $Sc=b$; occupation grading yields $z^4\Pi_{\rm st}(0,z)\to G_{4,d}(0)$ and $z^6\Pi_{\rm st}(0,z)\to0$ at zero transfer, while a 192/97 bivariate Schur fraction cancels determinant $X^2$ against Noether $X^3$ on a joint cone. Same-density electromagnetic contraction retains 72 gauge curvatures and yields the emergent $1/(4\pi|x-y|)$ kernel between moving currents; the 504-mode CAR generates a charge-$\pm1$, spin-$1/2$ colour-singlet three-fermion positive spectrum with an identically zero neutral channel; and compactly supported gauge variations of the total closure generate four-dimensional Schwartz curvature strong integrals preserving $\operatorname{Dom}(H_{\rm time})$ with positive-semidefinite word Gram matrices.

On the all-time, open-measurement, and root-seal face, every real impulse generates a unique all-real-time nonlinear gauge–Dirac orbit attaining $2\sqrt2$ without empirical input; deterministic simplex Kraus amplitudes derive a Born measure of exact mass $\|x\|^2$, an $L^2$ field-state isometry, and all-order trace duality for open recycling density flows—consumed across the public optical joint 95% domain, all 20,403 Munich prefixes, and the complete 120 ns gate ($1.30\times10^{-21}$ primal/adjoint agreement). The **Stage 10 physical root seal** reduces post-Yang–Mills whole-field assembly to four open differential coordinates and proves unique same-row canonical recourse, **zero unregistered physical authority**, and a **complete nine-field premise fold**, eliminating all tunable knobs so that $|Q_e|=1$, native propagation speeds, and the standard physical-return light-speed and pole-coupling expressions are locked as parameter-free deductive readouts; finally, the primitive-event-generated mother source $S_\star$ universally forms every admitted world, complete inquiry, and evolving process across any relation network, vocabulary, and authority root, excluding magic bits and any independent second source.

**Keywords**: continuous–quantum unified field; root-native ten-stage closure; anti-magic pruning; Spin×SU(7) theory; Einstein–Cartan–torsion variational equivalence; postulate-free quantum generation; matrix infrared return; formal verification

### 摘要

传统统一场论与量子场论通常先外置假定时空流形与规范破缺结构，再另行附加复 Hilbert 空间、正则对易代数、Born 概率规则与测量坍缩公设。本文在零公理通用发生与整账内核（T0）上，从零观测拟合参数的单一正源发生出发，按严禁预供度规、Hilbert/Fock 空间、全局哈密顿量、Born 规则与坍缩开关的**反魔法裁剪律**，完成第一至第十阶（Stage 1–10）连续—量子统一场贯通闭合：证明四维 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 连续几何与场方程，以及非交换量子运动学、算符动力学与开放测量读出，是**同一根发生在直接消费者需求下按需生成的两张相容依赖投影面**。在连续几何面，反空真反例与双轴门禁排除零场捷径；固定正源生成标架、联络、经谱序参量对易加分块迹方程双向唯一选出的标准模型子代数 $\mathfrak h_{\rm SM}=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$，以及三次与五条混合反常全消的 252 复维手征外幂物质。含独立线性对偶 $\chi$ 的一阶共同作用量不可加法分离（混合差分 $\Delta_{\rm mix}=9$）；对任意光滑非退化构型，引力四腿驻定充要于简单性 $B=\mathrm{II}^+(e)$、唯一反应乘子、显式 Einstein–Cartan 平衡与物质挠率—自旋方程。历史同步构型的乘子对交换分量差为 $5/8$，相容残差在整个 $\mathrm{Spin}^+(1,3)$ 轨道上非零。显式构造的六部门非零九场解在原完整历史的合法弱恢复下唯一；在固定 Cauchy 背景上，加权母作用弱零点等价于源生 Volterra 不动点并满测度唯一确定空间 $L^2$ 场，对称双曲全阶空间射流强迫在同阶能量内无导数损失闭合。

在量子投影与全场返回面，同一发生在指定解与任意 $A\in\operatorname{End}_{\mathbb C}(\mathbb C^{252})$ 处无需波函数或 Fock 先验直接导出非微扰恒等式 $\chi(A\psi)=4\sqrt2\langle v,R(A)v\rangle=4\sqrt2\langle I(v),\mathrm{d}\Gamma(R(A))I(v)\rangle$，并经四部门 Legendre 变换与三稳定子截面导出 61 对标量 CCR 与 504 模双支 CAR 上的共同生成元 $H=H_0+Y$、全阶非交换量子时钟、有界自伴能量尾 $R$、保持联合荷字符与十二时间方向统一归一的 CAR 创建单位外态及完整荷—电流 Ward 恒等式。母作用 Fréchet 二阶变分逐项认回 $H_{289}$；常场非线性 Noether 正半轴在源邻域内为 $C^2$ 且全场导数等于 $\Pi_{\rm st}$，正则量子反馈等价于原响应与九约束 Schur 方程 $Sc=b$；粒子数分级使零外转移处 $z^4\Pi_{\rm st}(0,z)$ 全纯返回有限完整矩阵且 $z^6\Pi_{\rm st}(0,z)\to0$，192/97 二变量 Schur 分式在联合锥上精确对消行列式 $X^2$ 与 Noether 分子 $X^3$。同密度电磁收缩保留 72 个规范曲率并在两条运动荷流间涌现出 $1/(4\pi|x-y|)$ 长程核；504 模 CAR 自产电荷 $\pm1$、自旋 $1/2$ 色单态三费米子复合正谱与中性严格零道；总闭合对象的紧支规范变分生成保持自伴时间生成元定义域 $\operatorname{Dom}(H_{\rm time})$ 的四维 Schwartz 曲率强积分与半正定词 Gram。

在全时动力学、开放测量与根封印面，任意实冲量生成唯一全实时间规范—Dirac 非线性轨道并无经验输入达到 Tsirelson 界 $2\sqrt2$；源 Kraus 全词与时间单形展开零先验导出精确质量 $\|x\|^2$ 的 Born 测度、$L^2$ 场态等距及开放循环密度全阶迹对偶，在公开光学联合 95% 域、Munich 全前缀域及 120 ns 全门前向／伴随 $1.30\times10^{-21}$ 双路吻合恢复中直接消费。Stage 10 物理根封印将后 Yang–Mills 全场缝合压为四条开放微分残差，证明非零残差同账唯一触发正则追索、**零未登记物理权威**与**九场实坐标全前提折叠**，清空全部可调旋钮，使电子荷单位 $|Q_e|=1$、原生传播速率以及标准物理返回分支上的光速与极点耦合商等唯象量锁定为无参数演绎读出；原始事件生成的同一母源 $S_\star$ 普遍形成原准入接口上任意关系网络、词汇与权威根的全部合法世界、完整查询与完整演化过程，并以全实在性排除魔法比特与独立第二来源。

**关键词**：连续—量子统一场；根原生十阶闭合；反魔法裁剪；Spin×SU(7) 理论；Einstein–Cartan—挠率变分等价；无先验量子生成；矩阵红外返回；形式化验证

---

## 1 Introduction: From Hearing to Seeing

### 1.1 The Anti-Magic Pruning Law, Compatible Projections of One Occurrence, and the Ten-Stage Spine

Foundational physics over the past century has remained split across three assembly seams. The first divides spacetime geometry from internal quantum numbers: general relativity and chiral Standard Model gauge theories rest on disjoint geometric substrates, typically bridged only by positing extra spatial dimensions, one-dimensional string worldsheets, or vast candidate vacuum landscapes. The second divides continuum classical fields from quantum postulates: standard model-building writes a classical Lagrangian first and then adjoins complex Hilbert spaces, canonical (anti)commutation brackets, a global Hamiltonian, the Born probability rule, and measurement collapse from outside—one hears via the correspondence principle that the two sides meet asymptotically, yet cannot exhibit within one postulate-free generative mechanism how state spaces, probability measures, and exact finite-$\hbar$ matching coefficients arise. The third divides mathematical structure from low-energy phenomenology: coupling tables, symmetry-breaking directions, vacuum choices, and renormalization counterterms import unconstrained parameters tuned retrospectively to empirical data.

All three seams share one root cause: tolerance of **magic**—a real difference that alters observable outcomes while no registered occurrence mechanism inside the theory determines it. A coupling dial tuned after the fact is magic: change the number and the formal derivation still runs. Pre-supplying wavefunction probability shells or collapse switches at the outset is magic: it imports as free axioms the very quantum behaviour to be explained. Opening a separate underlying source specifically to host a new class of processes is likewise magic: swap that source and the rest of the theory scarcely notices.

Working over a **zero-axiom constructive occurrence and whole-ledger kernel (T0)**, this paper closes all three seams simultaneously under a strict **Anti-Magic Pruning Law**: the primitive input forbids pre-supplied four-dimensional Lorentzian metrics, Standard Model breaking subgroups, complex-amplitude axioms, Hilbert/GNS/Fock spaces, global Hamiltonians, Born probability rules, or collapse booleans; both smooth differential-geometric fields and noncommutative quantum algebras are generated strictly on demand as dependent readouts when direct consumers require them to discharge concrete physical obligations. Under this discipline we complete and machine-verify an end-to-end **Stage 1–10 root-native closure** $\mathcal U_{1\text{--}10}$, establishing our central thesis: **neither four-dimensional continuum classical fields nor noncommutative quantum mechanics is a primitive external shell—both are compatible dependent projections of a single parameter-free root occurrence; moreover, the physical root seal eliminates all unregistered authority and tunable knobs so that downstream phenomenological observables are locked at the root as purely deductive readouts, while the same mother source universally forms every admitted world state, inquiry, and evolving process on the original interface.**

The ten-stage root-native spine from the single occurrence root through full-field return is summarized below (numbered tables begin at Table 1):

| Stage | Core physical and generative obligation discharged | Section & proof |
| --- | --- | --- |
| **Stages 1–3** Non-vacuity & dual-axis gates | Vacuity counterexamples exclude inhabited-type zero-field shortcuts; metric/Hodge variational interfaces and internal–geometry dual-axis projections fix minimal entry gates into 4D physics | §2.1, §9.2; App. D.1 |
| **Stages 4–5** Lorentzian geometry & nonseparable gravity–gauge | Global nondegenerate coframe and simplicity sector $\mathrm{II}^+(e)$; common action nonseparability ($\Delta_{\rm mix}=9\ne0$) and general four-leg stationarity $\iff$ Einstein–Cartan balance + torsion–spin ($5/8$ Plebański defect) | §2.1, §3.1–§3.3; App. B.8 |
| **Stages 6–8** Spectral selection, anomaly cancellation & mass | Single $\mathrm{SU}(7)$ mother connection selects $\mathfrak h_{\rm SM}$ bijectively via spectral commutator + trace laws; 252-dim chiral exterior matter cancels cubic and 5 mixed anomalies; unique scalar vacuum yields Yukawa masses, early-stage bridge, and nonzero current | §2.2–§2.4; Apps. A, B.7 |
| **Stage 9** Anti-magic continuous–quantum closure & S9-CU uniqueness | Zero quantum-postulate priors yield simultaneously: the **unique** weak-history 6-sector nine-field actual (S9-CU) with Volterra / derivative-loss-free PDE closure, and $4\sqrt2$ pairing plus the 61 CCR + 504 CAR generator $H=H_0+Y$ commuting on shared readouts | §4–§6; Supp. S1–S4, S11, S16 |
| **Stage 10** Five-position root seal, premise fold & zero authority leak | Five-position root history and whole-spacetime operator reduce post-YM assembly to 4 open differential coordinates; nonzero residuals trigger unique same-row canonical recourse; zero unregistered authority, 9-field premise fold, and 5-point lock | §8–§9.2; Apps. C.8, D.9 |
| **Full-field return, open measurement & universal formation** | Mother Hessian $=H_{289}$, nonlinear derivative $=\Pi_{\rm st}$, $z^4\Pi_{\rm st}$ & 192/97 IR return, emergent $1/(4\pi r)$ kernel & 3-fermion positive spectrum; postulate-free whole-word Born measure & open trace duality ($10^{-21}$ 120 ns recovery); $\forall R$ universal formation & zero-knob phenomenology | §7, §9.3–§10; Supp. S5–S15, S17–S18 |

Focusing this ten-stage spine onto one concrete physical witness singles out the **gauge current** and the **boundary of the source itself**: the gauge current appears classically as the first variation of the common action, quantum-mechanically as a compressed expectation in a positive normalized occupation state, and many-body-wise as a 504-mode CAR operator feeding back onto all 289 field directions through the mother action's own Fréchet Hessian Green function—their exact finite-$\hbar$ identity witnesses directly that classical fields and quantum states are two faces of one occurrence, while at the foundational boundary the same mother source $S_\star$ seals off-ledger physical freedom and forms every admitted world and evolving process across arbitrary authority roots $R$.

### 1.2 A Three-Minute Hand-Calculation Anchor

Before entering the general formalism, the reader can verify three elementary algebraic numbers in three minutes with pen and paper. They use only four fundamental constants generated directly by the fixed positive source (full geometric definitions appear in §2.1 and Appendix A):

$$\sigma=\tfrac12,\qquad k=\sqrt2,\qquad a=\frac{3k}{5}=\frac{3\sqrt2}{5},\qquad N=\sqrt{\frac{54}{125}} .$$

**Example 1.1 (Three-minute hand check).**

**(a) Source-generated phase frequency.** The precession frequency of the matter phase is fixed by the coframe lapse $N$, spin-connection scale $k$, and gauge amplitude $a$ as $\omega=3N(k-a)/2$. Since $k-a=2\sqrt2/5$, we have $\omega=3Nk/5$, whose square is

$$\omega^2=\frac{9N^2k^2}{25}=9\cdot\frac{54}{125}\cdot\frac{2}{25}=\frac{972}{3125}=\frac{2^2\cdot 3^5}{5^5}.$$

Nothing is fitted here: the ratio $a/k=3/5$ and the cubic balance law $a^3=2\sigma N^2k=N^2k$ are locked by stationarity of the common action at the nine-field solution, and lengthy variational residuals will repeatedly collapse to zero by virtue of this identity.

**(b) Classical variation and quantum expectation read the same gauge current.** On the colour doublet, take the three anti-Hermitian Pauli generators $\tau_g=(i/2)\sigma_{g+1}$ ($g=0,1,2$; block embedding in §2.2 and Appendix A.1). For the second generator $\tau_1$,

$$\tau_1=\begin{pmatrix}0&\tfrac12\\[2pt]-\tfrac12&0\end{pmatrix},\qquad
\tau_1^2=\begin{pmatrix}-\tfrac14&0\\[2pt]0&-\tfrac14\end{pmatrix}=-\tfrac14 I_2 .$$

With the gauge Lie pairing $\langle X,Y\rangle=-\mathrm{Re}\,\mathrm{tr}(XY)$, we have $\langle\tau_1,\tau_1\rangle=\tfrac12$ and generally $\langle\tau_g,\tau_h\rangle=\tfrac12\,\delta_{gh}$. On our nine-field solution, the classical current read from varying the common action along spatial direction $2$ in the Lie direction $\tau_1$ is (Theorem 6.3; superscripts denote spatial indices)

$$J^2(\tau_1)\;=\;4Nk\cdot\langle\tau_1,\tau_1\rangle\;=\;4\sqrt{\tfrac{54}{125}}\cdot\sqrt2\cdot\frac12\;=\;\frac{12\sqrt{15}}{25}\;\approx\;1.8590 .$$

On the quantum side, the expectation of the compressed observable in the normalized eight-dimensional occupation state $v$ is $4Nk\cdot\langle v,O_2(\tau_1)v\rangle$; Theorem 6.3 proves $\langle v,O_{g+1}(\tau_h)v\rangle=\tfrac12\,\delta_{gh}$. Both sides yield the exact same algebraic number $12\sqrt{15}/25$, without semiclassical expansion or renormalization tuning.

**(c) Five coherence ticks and the dark-moment counterexample.** Let $t^*=\pi/(2\omega)$ be the first dark time and $u=t/t^*$ the dimensionless time. At the five equidistant ticks $u=0,\tfrac12,1,\tfrac32,2$,

$$\cos^2\!\Big(\frac{u\pi}{2}\Big):\qquad 1,\;\tfrac12,\;0,\;\tfrac12,\;1 .$$

Section 8 proves that the source-generated quantum coherence weight follows this exact curve, whereas the classical exclusive-path benchmark (which erases cross-phases) stays identically at $\tfrac12$, producing parameter-free separations of $1$ vs. $\tfrac12$ at $u=0$ and $0$ vs. $\tfrac12$ at the dark moment $u=1$. Moreover, §6.2 (Example 6.6) exhibits a sharp structural negative control: if one omits the Dirac upper–lower block swap $S$ dictated by the independent linear dual when compressing the observable, the current reading at $u=0$ still accidentally equals $+\tfrac12$, yet plunges to $-\tfrac12$ at the dark moment $u=1$—missing the conserved truth by a full unit. Operator-level correspondence cannot be faked by a single-time check.

### 1.3 Overview of the Four Main Pillars and Three Matter Carriers

Following the Stage 1–10 spine above, the paper establishes four interlocking groups of theorems:

1. **Spectral selection, four-leg Einstein–Cartan–torsion critical equivalence, and constructive PDE closure (§2–§5).** We prove that commutation with the positive-source spectral order parameter together with three block trace conditions uniquely selects the Standard Model gauge subalgebra $\mathfrak h_{\rm SM}\subset\mathfrak{su}(7)$ in both directions (Theorem 2.2), that the 252-complex-dimensional chiral exterior-power matter cancels cubic and all five mixed gauge/gravitational anomalies (Proposition 2.3), and that the common first-order action is not additively separable into pure gravity and pure gauge pieces (Proposition 3.2). For an arbitrary smooth nondegenerate configuration, four-leg gravitational stationarity is proved equivalent to simplicity, the unique action-derived reaction multiplier, explicit Einstein–Cartan coframe balance, and the matter-coupled torsion–spin equation, while an exact $(3,4)$ pair-exchange defect of $5/8$ demarcates jurisdiction from nonchiral quadratic Plebański pure-reaction models (Theorem 3.3). We construct the unique classical world solution with six nonzero physical sectors and compact-domain all-order derivative bounds (Theorems 4.2–4.5), and on the fixed Cauchy background prove equivalence between weighted mother-action weak zeros and Volterra integral fixed points with common full-measure $L^2$ uniqueness, together with derivative-loss-free all-order symmetric-hyperbolic energy closure (Theorems 4.6–4.7).
2. **Postulate-free generation of quantum state spaces and operator algebras: from $4\sqrt2$ pairing to the 504-mode common $H=H_0+Y$ (§6).** Importing neither wavefunction axioms nor external quantization postulates, on the designated solution the full matter field $\psi\in\mathbb C^{252}$ and independent linear dual $\chi$ directly generate the eight-dimensional normalized occupation state $v$ and 256-dimensional Fock one-particle embedding $I(v)$ satisfying, for every $A\in\operatorname{End}_{\mathbb C}(\mathbb C^{252})$,
   $$\chi(A\psi)\;=\;4k\,\langle v,\,R(A)\,v\rangle\;=\;4k\,\langle I(v),\,\mathrm{d}\Gamma(R(A))\,I(v)\rangle,\qquad k=\sqrt2 ,$$
   with compression $R(A)=SPAE$ (Theorems 6.2–6.5; Table 1 and Figure 1). Via a four-sector Legendre map and three-stabilizer section, the same common action then derives over a 100-dimensional configuration manifold, 61 scalar CCR pairs, and a 504-mode two-branch CAR algebra the common generator $H=H_0+Y$, configuration coupling $4W(q)$, all-order noncommutative quantum clock, fixed bounded self-adjoint energy tail $R=E_{\rm tail}-C_{\rm src}$, and 11-field source preparation (Theorems 6.7–6.8). Explicit CAR creation produces a unit external state preserving joint Standard Model charge characters and unified phase-inverse normalization across all twelve temporal directions, while the full Ward identity identifies the one-particle sector as the exact locus where the quartic pair current $J_{\rm pair}$ vanishes (Theorems 6.9–6.11).
3. **Mother-action Hessian recovery, nonlinear full-field feedback, matrix infrared return, and emergent interactions (§7).** We prove that the 1650-term Fréchet second variation of the mother action at the designated solution equals the $289\times289$ response matrix $H_{289}(p)$ entry by entry (Theorem 7.1). For $\operatorname{Re}\lambda>0$, the genuinely nonlinear constant-field Noether half-axis is $C^2$ on a source neighbourhood and its derivative along all 289 real field directions equals $\Pi_{\rm st}$ (Theorem 7.3); feeding the half-axis polarization into the same mother Green function makes regular feedback equivalent to the original response and the nine-constraint Schur equation $Sc=b$ (Theorems 7.4–7.5). Occupation grading lowers five-factor kernel growth to cubic order in time so that $z^4\Pi_{\rm st}(0,z)$ returns holomorphically to a finite full matrix at zero transfer while $z^6\Pi_{\rm st}(0,z)\to0$ (Theorem 7.6). Along unit spatial directions, a 192-dimensional inactive two-sided inverse yields a bivariate 97-dimensional Schur fraction whose electromagnetic temporal row forces $E_A^{\mathsf T}Q_{97}=X^2 R_{97}^{\mathsf T}$, cancelling $X^2$ against $X^3$ on a source-generated joint cone (Theorem 7.8). Same-density electromagnetic contraction preserves all 72 gauge curvatures and yields the emergent $1/(4\pi|x-y|)$ Coulomb/Newton kernel between moving quantum currents after cutoff removal (Theorem 7.9); the 504-mode CAR generates a charge-$\pm1$, spin-$1/2$ (Casimir $3/4$) colour-singlet three-fermion composite with strictly positive real-transfer spectrum and identically vanishing neutral output (Theorem 7.11); and compactly supported gauge variations of the total closure $\mathcal U_{1\text{--}10}$ generate four-dimensional Schwartz curvature strong integrals preserving $\operatorname{Dom}(H_{\rm time})$ with positive-semidefinite word Gram matrices (Theorem 7.12).
4. **Five-position physical root seal, postulate-free whole-word Born open dynamics, zero-knob phenomenological rigidity, and universal formation (§8–§10).** Every real impulse on the fixed coframe background generates a unique all-real-time nonlinear orbit whose Legendre energy is read back from the quantum time derivative, and parameter-free Bell predictions attain $2\sqrt2$ (Theorem 8.1–Proposition 8.4). Across its five-position physical root history and whole-spacetime operator, the Stage 10 physical root seal reduces post-Yang–Mills whole-field assembly to four open differential coordinates and proves unique same-row canonical recourse succession, all-visit zero unregistered physical authority, and a complete nine-field premise fold (Theorem 9.3), eliminating all tunable knobs so that downstream phenomenological constants are locked as deductive readouts; the primitive-event-generated mother source $S_\star$ universally forms—via pointwise completion of its finite-program image—every admitted world state, complete inquiry, and complete evolving process on the original interface, recovering states, rules, and finite-depth histories while excluding magic bits via total reality (Theorem 9.4–Corollary 9.5). At the open-instrument interface, without prior probability or collapse postulates, whole-word Kraus expansions derive an exact-mass Born measure, $L^2$ field-state isometry, and open recycling density trace duality (Theorem 10.1), directly consumed across the public optical joint 95% domain, the Munich full-prefix readout domain, and the complete 120 ns gate where primal and adjoint curves agree within $1.30\times10^{-21}$ (Propositions 10.2–10.5). Appendices A–D record representation conventions, the complete four-leg variational proof, universal formation mechanisms, and fixed commit indices; Supplement S0–S18 supplies complete self-contained written proofs for all theorems of §4.3, §6.3–§7.5, and §10.1–§10.2.

**Table 1 Three finite-dimensional matter carriers at the one-particle pairing stage (for the full 504-mode infinite-dimensional configuration carrier see §6.3).**

| Carrier | Dimension | Input objects | Direct outputs |
| --- | --- | --- | --- |
| Mother matter carrier $(\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7)^{\oplus4}$ | 252 complex | Full matter field $\psi$, independent dual $\chi$, arbitrary linear operator $A$ | Variational gauge current, 16 kinetic loads, Yukawa pairing |
| Occupation carrier (Dirac 4-spinor $\times$ colour doublet) | 8 complex | Projected normalized state $v$, compressed response $R(A)=SPAE$ | Positive-state expectations, five-point coherence weights, bilateral Bell probabilities |
| Eight-mode fermionic Fock space $\Lambda^*\mathbb C^8$ | 256 complex | One-particle embedding $I(v)$, second-quantized lift $\mathrm{d}\Gamma(O)$ | Exact many-body preservation of all one-particle matrix elements |

![Figure 1 Mother pairing, occupation response and Fock one-particle embedding](figures/vector/fig1-trinity-lens-system-en.png)

**Figure 1｜Three finite-dimensional representations of the same pairing.** The current identity of Example 1.1(b) unfolds into three exact maps. Left: the 252-complex-dimensional mother matter carrier $\mathcal M$. Middle: the 8-complex-dimensional occupation carrier $\mathcal E=\mathbb C^8$; $E$ is the isometric embedding, $P=E^*$ the orthogonal projection, and $S$ swaps upper and lower Dirac two-spinors, giving $R(A)=SPAE$ (neither necessarily unitary nor self-adjoint for general $A$). Right: the 256-dimensional fermionic Fock space $\mathcal F_-(\mathcal E)=\bigoplus_{n=0}^8\Lambda^n\mathcal E$, with $I(v)$ in the $n=1$ sector. Bottom inset (Example 6.6): retaining the dual-induced swap $S$ keeps the co-axial gauge current identically at $+1/2$, whereas omitting $S$ yields $\cos(2\theta)/2$, which coincides at $\theta=0$ but drops to $-1/2$ at the dark moment $\theta=\pi/2$—a discrepancy of $1$.

---

## 2 Source Data, Spectral Selection, and Global Spin×SU(7) Geometry

### 2.1 Occurrence-Source Material and Its Structural Provenance

Conventional field-theoretic Lagrangians import the spacetime metric, gauge-breaking subgroup, matter multiplets, and coupling constants as an external specification list. Here we push all of those ingredients back to a single starting point: primitive occurrence material consisting of finite discrete labels and explicit geometric initial data. The “source” here is neither an external classical current added to the right-hand side of a field equation nor an empirical cosmological initial hypersurface, but the generative datum from which geometry, connections, matter representations, the common action, and subsequent field configurations are constructed.

**Definition 2.1 (Source datum and smooth unified source).** A **base source** comprises six primitive fields: a source-root label, a material-path shift, integer-valued potentials on two source phase loops, a natural-number $\sigma$-seed, a natural-number colour scale, and $4\times4\times4$ real linear coframe coefficients. A **smooth unified source** adjoins one real continuous contact residual, giving $64+1=65$ continuous real coordinates in total. Our **fixed positive source** $S_0$ takes root label $(5,7)$ (energy level $8$), zero shift, phase-loop readings $(0,1,3)$ and $(2,5,9)$, seed $0$, colour scale $1$, a single nonzero shear entry $1$ at $(\text{direction},\text{internal},\text{coordinate})=(2,0,1)$, and contact residual $2\pi$.

The provenance and direct geometric reading of each primitive field are summarized below:

| Primitive field | Value in $S_0$ | Generative provenance and direct geometric reading |
| --- | --- | --- |
| Source-root label | $(5,7)$, level $8$ | Depth-zero readout of the $A_6$ root-lattice observation trajectory |
| Material-path shift | $0$ | Reads the base label at zero shift (nonzero shifts generate neighbouring sources) |
| Two phase potentials | $(0,1,3)$ and $(2,5,9)$ | Depth-zero integer potentials on the dual phase loops; first edge difference $1-0=1$ sets unit phase amplitude |
| $\sigma$-seed | $0$ | Origin of the scale family $\sigma_n=1/(n+2)$, directly generating squared coupling $\sigma=\tfrac12$ |
| Colour scale | $1$ | Unit calibration on the internal gauge fibre |
| Linear coframe entries | $1$ at $(2,0,1)$, $0$ elsewhere | Primitive shear coframe $e^0=dx^0+x^2dx^1,\,e^i=dx^i$: pointwise $\det e=1$ and $de^0=dx^2\wedge dx^1\ne0$ |
| Contact residual | $2\pi$ | Primitive periodic reading of the imaginary hypercharge diagonal; contact rate $\sigma\cdot 2\pi=\pi$ |

Construction flows strictly downstream from these seven fields: representation dimensions, anomaly cancellation, the unbroken gauge subalgebra, the symmetry-breaking scalar vacuum, Yukawa mass maps, matter state vectors, and gauge currents are **never** stored inside the source record, but generated deterministically from it. Crucially, this mechanism is not tailored to a single parameter point: §9.1 (Theorems 9.1–9.2) proves that the identical construction covers **every** member of the 65-dimensional smooth unified source family (with all six classical physical sectors nonzero if and only if the source's own integer phase amplitude is nonzero) and executes any finite sequence of sources along a single lawful history.

Before detailing the geometry, Table 2 lists the nine fundamental fields carrying all variational channels. Together they form a **holonomic configuration**: gravitational curvature is computed from $\mathrm d\varpi+\varpi\wedge\varpi$, gauge curvature from $F_{\mu\nu}=\partial_\mu A_\nu-\partial_\nu A_\mu+[A_\mu,A_\nu]$, and covariant derivatives from the same connections—curvatures and derivatives arise by genuine differentiation of underlying potentials rather than as independent variables.

**Table 2 The nine fundamental fields and their variational roles.**

| Field | Symbol | Physical and geometric identity | Designated solution (Construction 4.1) | Variational channel |
| --- | --- | --- | --- | --- |
| Coframe | $e$ | Orthonormal spacetime tetrad, $g=e^{\mathsf T}\eta e$ | $\mathrm{diag}(N,1,1,1)$ | Algebraic (inverse-tetrad coupling) |
| Spin connection | $\varpi$ | $\mathrm{Spin}^+(1,3)$ principal connection $1$-form | Nonzero constant-torsion Cartan solution | Differential (1st-order exterior covariant derivative) |
| Gravitational auxiliary | $B$ | Internal bivector-valued $2$-form, gravitational BF wing | $\mathrm{II}^+(e)=J(e\wedge e)$ | Algebraic |
| Simplicity multiplier | $\lambda$ | Bivector $2$-form enforcing simplicity | $\mathrm{diag}(-NI_3,\,(k^2-1)I_3)$ | Algebraic |
| Gauge connection | $A$ | $\mathfrak h_{\rm SM}$-valued $1$-form | $(0,\,a\tau_0,\,a\tau_1,\,a\tau_2)$ | Differential |
| Gauge auxiliary | $B_A$ | $\mathfrak h_{\rm SM}$-valued $2$-form, gauge BF wing | $K_e^{-1}F_A=-\sigma^{-1}\star_e F_A$ | Algebraic constitutive |
| Dynamical scalar | $\varphi$ | $\Lambda^4\mathbb C^7$-valued symmetry-breaking scalar | Generated vacuum $\varphi_0$ | Differential (2nd-order covariant derivative) |
| Matter spinor | $\psi$ | 252-complex-dim chiral exterior-power Dirac field | $\Psi[e^{i\omega t},e^{-i\omega t}]$ | Differential (1st-order Dirac operator) |
| Independent matter dual | $\chi$ | Independent $\mathbb C$-linear dual functional of $\psi$ | $\Xi[\sqrt2 e^{i\omega t},\sqrt2 e^{-i\omega t}]$ | Algebraic (generates forward Dirac equation) |

### 2.2 Bidirectional Spectral Selection of the Standard Model Subalgebra

The mother gauge group is $\mathrm{SU}(7)$, whose Lie algebra $\mathfrak{su}(7)$ consists of $7\times7$ anti-Hermitian traceless complex matrices (real dimension $48$). Why does low-energy gauge dynamics live on the twelve-dimensional Standard Model subalgebra $\mathfrak h_{\rm SM}=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$ rather than an ad hoc block ansatz? We prove that for every positive-scale source ($\sigma>0$), $\mathfrak h_{\rm SM}$ is **uniquely selected in both directions** by commutation with a source-generated adjoint spectral order parameter together with three block trace equations.

Partition the indices of the seven-dimensional fundamental representation as $3+2+1+1$ into colour indices $\{c_0,c_1,c_2\}$, weak indices $\{w_0,w_1\}$, and positive/negative hypercharge singlets $\{h_+,h_-\}$, assigning the four distinct spectral levels $(-1,0,1,2)$ whose weighted trace vanishes: $3(-1)+2(0)+1(1)+1(2)=0$. Define the source-generated self-adjoint traceless adjoint order parameter

$$\mathcal O_{\rm br}(s)=\sigma(s)\,\operatorname{diag}(-1,-1,-1,\,0,0,\,1,\,2),\qquad \sigma(s)>0.$$

For any Standard Model Lie triple $(C,W,y)\in\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus i\mathbb R$, set $\iota_{\rm SM}(C,W,y)=\operatorname{diag}(C,W,y,-y)\in\mathfrak{su}(7)$, with group-level embedding $\operatorname{diag}(U_3,U_2,z,z^{-1})\in\mathrm{SU}(7)$ ($|z|=1$).

**Theorem 2.2 (Bidirectional spectral selection of the Standard Model subalgebra).** For every base source $s$ with $\sigma(s)>0$ and every mother Lie-algebra matrix $M\in\mathfrak{su}(7)$, $M$ belongs to the Standard Model block image $\operatorname{im}\iota_{\rm SM}$ **if and only if** $M$ satisfies the source-breaking selection equations

$$[M,\,\mathcal O_{\rm br}(s)]=0,\qquad \operatorname{tr}(M_{\rm col})=0,\qquad \operatorname{tr}(M_{\rm weak})=0,\qquad M_{h_+h_+}+M_{h_-h_-}=0.$$

When these hold, the block readout $(M_{\rm col},M_{\rm weak},M_{h_+h_+})\in\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus i\mathbb R$ forms the exact two-sided inverse to $\iota_{\rm SM}$ onto the selected subspace, reconstructing $\iota_{\rm SM}(M_{\rm col},M_{\rm weak},M_{h_+h_+})=M$.

**Proof.** The forward direction is immediate: block-diagonal matrices commute with the block-scalar matrix $\mathcal O_{\rm br}(s)$, and $C\in\mathfrak{su}(3)$, $W\in\mathfrak{su}(2)$, and $y+(-y)=0$ satisfy the three trace equations. Conversely, let $M\in\mathfrak{su}(7)$ satisfy the four equations and take any index pair $(r,c)$ belonging to distinct spectral levels, $\ell_r\ne\ell_c$. Reading entry $(r,c)$ of $M\mathcal O_{\rm br}(s)=\mathcal O_{\rm br}(s)M$ gives $\sigma(s)(\ell_c-\ell_r)M_{rc}=0$; since $\sigma(s)>0$ and $\ell_r\ne\ell_c$, we obtain $M_{rc}=0$. Thus **every off-diagonal cross-block entry between distinct spectral levels vanishes identically** (note that $\sigma(s)>0$ is essential: at $\sigma=0$ the order parameter collapses to zero and loses all selective power). Anti-Hermiticity $M^*=-M$ restricts to each diagonal block, and combining $\operatorname{tr}(M_{\rm col})=0$, $\operatorname{tr}(M_{\rm weak})=0$, and $M_{h_-h_-}=-M_{h_+h_+}$ uniquely reconstructs $M=\iota_{\rm SM}(M_{\rm col},M_{\rm weak},M_{h_+h_+})$. ∎

Theorem 2.2 shows that the mother carrier stores no auxiliary “subgroup certificate”: the commutator $[M,\mathcal O_{\rm br}]=0$ projects $\mathfrak{su}(7)$ onto the centralizer $\mathfrak s(\mathfrak u(3)\oplus\mathfrak u(2)\oplus\mathfrak u(1)\oplus\mathfrak u(1))$, and the three trace equations remove the two redundant Abelian centres, leaving $\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$ with nothing left over. This contrasts directly with Georgi–Glashow single-group unification [16], where symmetry-breaking directions rely on external multi-Higgs potentials, and with the Chamseddine–Connes spectral action [20], which specifies the gauge algebra through a pre-assigned finite spectral triple in Euclidean signature (see §10.3).

### 2.3 Chiral Exterior-Power Matter and Anomaly Cancellation

On $V=\mathbb C^7$, the $d$-th exterior power $\Lambda^d V$ has orthonormal basis $e_{i_1}\wedge\cdots\wedge e_{i_d}$ ($i_1<\cdots<i_d$). Ever since the discovery of axial-vector chiral anomalies [17,18] and the anomaly-cancellation criterion for electroweak gauge models [19], conventional grand unified theories have assembled inequivalent representations by hand across generations to cancel cubic and mixed anomalies [16]; rather than piecing chiral fermions together from unrelated representations, our matter sector takes directly the three even/upper exterior layers $\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7$ of dimensions $\binom76=7$, $\binom72=21$, and $\binom74=35$, totalling $7+21+35=63$ internal degrees of freedom. Tensoring with four-component Dirac spinors yields the full mother matter carrier

$$\mathcal M=\mathbb C^4\otimes\big(\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7\big),\qquad \dim_{\mathbb C}\mathcal M=4\times 63=252 .$$

The dynamical scalar $\varphi$ takes values in $\Lambda^4\mathbb C^7\simeq\mathbb C^{35}$, and the Yukawa coupling is generated canonically by exterior wedge multiplication $\Lambda^2\mathbb C^7\otimes\Lambda^4\mathbb C^7\to\Lambda^6\mathbb C^7$ with zero free Yukawa parameters. Along the hypercharge generator $\operatorname{diag}(0_3,0_2,y,-y)$, each basis wedge acquires hypercharge weight $-1,0,+1$ according to the count difference of $h_+$ and $h_-$.

**Proposition 2.3 (Chiral exterior-power matter structure and full anomaly cancellation).** On the $63$-dimensional internal exterior-power carrier generated by the fixed source:

1. **Hypercharge multiplicities**: total multiplicities of weights $-1,0,+1$ are $16,31,16$ (layer by layer: $1,5,1$ on $\Lambda^6$; $5,11,5$ on $\Lambda^2$; $10,15,10$ on $\Lambda^4$), exhibiting genuine chiral asymmetry;
2. **Cubic and mixed anomaly cancellation**: the $\mathrm{SU}(7)$ cubic anomaly index under generator labels $(1,3,2,-2,-3,-1)$ sums to zero across the $(6,2,4)$ combination ($A(\Lambda^6)+A(\Lambda^2)+A(\Lambda^4)=(-1)+3+(-2)=0$), and all five residual cubic, mixed gauge, and mixed gravitational–gauge anomaly traces on $\mathfrak h_{\rm SM}$ vanish identically;
3. **Global parity condition and Weyl one-loop coefficients**: the total count of $\mathrm{SU}(2)$ weak doublets is $16$ (even, satisfying Witten's global $\mathrm{SU}(2)$ anomaly condition), and the one-loop gauge running coefficients $b_0$ of the pure exterior-power Weyl fermion inventory are $\mathrm{SU}(7):61/3$, $\mathrm{SU}(3):17/3$, $\mathrm{SU}(2):2$, and $\mathrm{U}(1):-64/3$.

**Proof.** Weight distributions and doublet counts follow by combinatorial basis enumeration; cubic and mixed anomaly traces vanish by exact representation-theoretic character identities checked in the Lean kernel as finite exact equalities; the pure Weyl one-loop coefficients sum quadratic Dynkin indices. ∎

### 2.4 Global Bundle Descent, Unique Vacuum, and Early Finite-Layer Recovery

Local gauge potentials and matter sections patch across chart overlaps via transition functions $g(x)$ obeying the standard non-Abelian cocycle law $A_{(\beta)}=\mathrm{Ad}(g)A_{(\alpha)}-(dg)g^{-1}$; the source-generated temporal hypercharge shift commutes with $\mathfrak h_{\rm SM}$ and preserves transition compatibility.

**Proposition 2.4 (Global bundle descent, all-parameter background transport, and nontrivial holonomy).** The fixed source generates a principal $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ bundle and associated exterior-power matter bundle satisfying: (i) the matter section $\psi$ descends globally across all charts while the independent dual $\chi$ descends under the contragredient representation with closed overlap cocycles; (ii) mother connection potentials satisfy the non-Abelian patching identity, rendering local density and integrated action readings chart-independent; (iii) for every smooth unified source, coordinate axis, and real length/time parameter, the source background connection explicitly satisfies the parallel-transport ODE and group-flow composition law, with non-identity closed-loop rectangular holonomy and nontrivial unitary evolution on $S_0$; (iv) the actual nine-field solution uses its own gauge connection and satisfies the same global patching law across all charts and spacetime points.

**Proof.** Descent of sections and duals follows from triple-overlap cocycle closure; chart invariance of the density follows from adjoint equivariance of wedge products and fibre pairings. For (iii), rather than relying on merely local ODE existence, the formal proof constructs explicit analytic transport flows, verifies the differential equation, initial condition, and global $\mathbb R$-flow law, and evaluates a non-identity holonomy matrix around an explicit closed rectangle on $S_0$. ∎

**Proposition 2.5 (Unique scalar vacuum minimum and 35-coordinate proper stabilizer).** On every chart and spacetime point, the source-generated scalar potential $U_s(\varphi)$ has the generated vacuum vector $\varphi_{{\rm vac},s}\in\Lambda^4\mathbb C^7$ as its unique global minimum: $U_s(\varphi)\ge 0=U_s(\varphi_{{\rm vac},s})$, with equality if and only if $\varphi=\varphi_{{\rm vac},s}$. Its mother-group stabilizer $\{g\in\mathrm{SU}(7):\rho_4(g)\varphi_{{\rm vac},s}=\varphi_{{\rm vac},s}\}$, characterized by equality across all $35$ four-form basis coordinates, is a proper subgroup of $\mathrm{SU}(7)$ that intersects the embedded hypercharge circle solely at the identity.

**Proof.** In the orthonormal four-form basis, $U_s(\varphi)=\sum_{|I|=4}|\varphi_I-(\varphi_{{\rm vac},s})_I|^2$, giving nonnegativity and a unique zero immediately. Properness of the stabilizer and triviality of its intersection with the hypercharge circle are verified directly by acting with explicit group elements on the $35$ basis coordinates. ∎

**Proposition 2.6 (Exact recovery of early finite-layer structures on the continuum configuration).** On the complete Stage 1–10 closure interface, at every spacetime point, mother Lie-algebra element, and spinor component: the internal representation action, all-point broken-scalar readout, full Yukawa mass map, and finite $2\times2$ mixing matrix generated at the early finite stages agree entry for entry with the corresponding readouts on the current continuum nine-field configuration, and the identical recovery identities persist on the native successor configuration.

**Proof.** Composing early joint credentials with the continuum configuration projections through `StageOneThroughTenClosure` (Appendix D.2) checks representation and mass-mixing equalities componentwise and transports them across the native Cartan update step. ∎

---

## 3 Common First-Order Action, Four-Leg Critical Equivalence, and Auxiliary Elimination

### 3.1 Nonseparable Common Local Density and the Independent Matter Dual

We now assemble all nine fields into a single four-form Lagrangian density. In a first-order BF framework, gravitational curvature pairs with a bivector $2$-form $B$ and gauge curvature pairs with a Lie-algebra-valued $2$-form $B_A$. What determines the physics is how a single coframe $e$ simultaneously governs the gravitational simplicity target, the gauge Hodge constitutive operator, and chiral matter covariant derivatives—and why the matter sector employs an independent linear dual $\chi$.

There are three concrete physical reasons for retaining an **independent $\mathbb C$-linear dual** $\chi\in\mathcal M^*=\operatorname{Hom}_{\mathbb C}(\mathcal M,\mathbb C)$ in Lorentzian signature: first, in the presence of the unidirectional chiral wedge Yukawa coupling $Y_R(\varphi):\Lambda^2\to\Lambda^6$, tying $\bar\psi=\psi^\dagger\gamma^0$ mixes holomorphic and antiholomorphic variations across chiralities, whereas varying $\chi$ and $\psi$ independently yields cleanly decoupled forward Dirac and contragredient adjoint Euler channels; second, upon canonical quantization (§6.3), the real and imaginary parts of $(\psi,\chi)$ form a complete real phase space whose single complexification produces a redundancy-free **504-mode two-branch standard CAR algebra**, representing the unidirectional Yukawa term faithfully as a closable formal adjoint pair $(H_0+Y,\,H_0+Y^\dagger)$; third, on the classical solution, the field-equation-locked amplitude ratio $\sqrt2$ and Dirac block swap $S$ between $\chi$ and $\psi$ supply precisely half of the parameter-free classical–quantum pairing constant $4\sqrt2$ (Theorem 6.2).

Fix notation on the origin chart (other charts descend identically by Proposition 3.5): spacetime indices $\mu,\nu\in\{0,1,2,3\}$, internal Lorentz indices $a,b\in\{0,1,2,3\}$, Minkowski metric $\eta=\operatorname{diag}(-1,1,1,1)$, $\nu_e=|\det e|$, and $g_{\mu\nu}=e^a{}_\mu\eta_{ab}e^b{}_\nu$. Order both internal antisymmetric bivector indices $I$ and spacetime $2$-form indices $p$ along the six-element list

$$\mathcal P=(01,02,03,23,31,12),\qquad p^c=(3,4,5,0,1,2),\qquad \epsilon_I=(-1,-1,-1,1,1,1)_I.$$

Although internal bivectors and spacetime $2$-forms are both six-dimensional, their transformation groups are distinct: the internal Hodge dual $J$ acts solely on $I$ (independently of $e$), whereas the spacetime Hodge star $\star_e$ acts on $p$ (depending explicitly on $e$). Define the oriented four-form wedge pairings, simplicity target $\mathrm{II}^+(e)$, and index-raised curvature by

$$W_\beta(X,Y)=\sum_{p\in\mathcal P}\beta(X_p,Y_{p^c}),\qquad
W_{\rm top}(B,C)=\sum_{I,p}\epsilon_I B_{Ip}C_{I,p^c},$$

$$J=\begin{pmatrix}0&I_3\\-I_3&0\end{pmatrix},\quad
(\Sigma_e)_{Ip}=e^{a_I}_{\mu_p}e^{b_I}_{\nu_p}-e^{a_I}_{\nu_p}e^{b_I}_{\mu_p},\quad
\mathrm{II}^+(e)=J\Sigma_e,\quad
\widehat F_{\varpi,Ip}=\epsilon_I F_{\varpi,Ip}^{\rm raw}.$$

On a diagonal coframe $e=\operatorname{diag}(N,1,1,1)$, $\star_e(f_0,\ldots,f_5)=(N^{-1}f_3,N^{-1}f_4,N^{-1}f_5,\allowbreak -Nf_0,-Nf_1,-Nf_2)$, obeying the Lorentzian identity $\star_e^2=-1$. On the gauge fibre, $\mathfrak{su}(3)$ and $\mathfrak{su}(2)$ use $-\operatorname{Re}\operatorname{Tr}(XY)$ and imaginary hypercharge uses $-\operatorname{Re}(yz)$.

**Definition 3.1 (Common first-order local density).** Let $\gamma_e^\mu=(e^{-1})^\mu{}_a\gamma^a$ and $\Omega_\mu=\frac14\varpi_{\mu ab}\gamma^a\gamma^b$ (summed over all ordered pairs $a,b$), with covariant derivatives and chiral exterior Yukawa map

$$D_\mu\psi=\partial_\mu\psi+(\Omega_\mu+\rho_{\mathcal M}(A_\mu))\psi,\qquad
D_\mu\varphi=\partial_\mu\varphi+\rho_4(A_\mu)\varphi,$$

$$Y_R(\varphi)=T_\varphi P_R,\qquad P_R=\operatorname{diag}(0,0,1,1),\qquad
T_\varphi(w_6,w_2,w_4)=(w_2\wedge\varphi,0,0).$$

For any smooth unified source $s$ (with generated squared gauge couplings $g_j^2=\alpha_j(s)>0$, all equal to $\sigma=1/2$ on $S_0$), the common nine-field four-form density coefficient is

$$\begin{aligned}
L_s={}&W_{\rm top}(B,\widehat F_\varpi)-\tfrac12W_{\rm top}(B,JB)
+W_{\rm top}(\lambda,B-J\Sigma_e)\\
&+\sum_{j=3,2,1}\left[W_j(B_{A,j},F_{A,j})-
\tfrac12W_j(B_{A,j},g_j^2\star_e B_{A,j})\right]\\
&+\nu_e\left[\tfrac12g^{\mu\nu}\operatorname{Re}\langle D_\mu\varphi,D_\nu\varphi\rangle
-U_s(\varphi)+\operatorname{Re}\chi\!\left(i\gamma_e^\mu D_\mu\psi+Y_R(\varphi)\psi\right)\right].
\end{aligned}\tag{3.1}$$

Varying (3.1) independently with respect to all nine fields (Appendix B.1) immediately yields the three algebraic residuals

$$\mathcal E_\lambda=B-J\Sigma_e,\qquad
\mathcal E_B=\widehat F_\varpi-JB+\lambda,\qquad
\mathcal E_{B_A}=F_A-K_e B_A\quad(K_{e,j}=g_j^2\star_e).\tag{3.2}$$

Writing gravity and gauge terms under one integral sign does not by itself establish genuine unification: if the action split into $S_{\rm grav}(q_{\rm grav})+S_{\rm gauge}(q_{\rm gauge})$, the two sectors would merely sit side by side. Two exact kernel certificates rule out additive separability.

**Proposition 3.2 (Exact source-geometry admission and nonseparability of gravity and gauge sectors).** For the gravity–gauge master action $S_{\rm master}$ of any base source $s$:

1. **Rejection of mismatched coframes**: exact source-geometry admission requires the dynamical coframe, three-block gauge curvatures, and auxiliary fields to arise from the same source; replacing the coframe by a temporal-modulus probe coframe $e_{\rm probe}(s)$ of identical carrier type but distinct volume element strictly falsifies admission;
2. **Nonzero mixed finite difference and nonseparability**: evaluated across the $2\times2$ rectangle formed by the source coframe $e_0(s)$, probe coframe $e_{\rm probe}(s)$, source gauge background $G_0(s)$, and strong-block stress probe $G_{\rm stress}(s)$, the master action takes values $0,0,\tfrac32,\tfrac{21}2$, giving the mixed gravity–gauge second difference
   $$\begin{aligned}
   \Delta_{\rm mix}(s)&=S_{\rm master}(e_{\rm probe},G_{\rm stress})-S_{\rm master}(e_{\rm probe},G_0)-S_{\rm master}(e_0,G_{\rm stress})+S_{\rm master}(e_0,G_0)\\
   &=\frac{21}{2}-0-\frac{3}{2}+0=9\ne 0.
   \end{aligned}\tag{3.3}$$
   Consequently, there exist no functionals $(S_{\rm grav},S_{\rm gauge})$ satisfying $S_{\rm master}(q)=S_{\rm grav}(q_{\rm grav})+S_{\rm gauge}(q_{\rm gauge})$ for all configurations.

**Proof.** Any additively separable sum cancels pairwise across the four corners of (3.3) to give $\Delta_{\rm mix}(s)=0$, contradicting the exact value $9$. Rejection of $e_{\rm probe}$ follows directly from inequality of the dynamical gauge volume elements. ∎

This also resolves an immediate classical question: **why does gravity–gauge nonseparability in Proposition 3.2 not violate the Coleman–Mandula no-go theorem [24]?** The Coleman–Mandula theorem constrains **asymptotic $S$-matrix symmetry Lie algebras over a fixed four-dimensional Minkowski metric background** assuming analyticity and nontrivial scattering, forbidding non-direct-product Lie brackets between Poincaré and internal generators; in our construction, the principal bundle group remains the strict algebraic direct product $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ (introducing no pathological higher-spin spacetime–internal Lie mixing), while the nonadditivity $\Delta_{\rm mix}=9\ne0$ of (3.3) arises entirely at the **pre-metric first-order coframe constitutive wedge level**—where the dynamical coframe $e$ simultaneously governs the simplicity target $\mathrm{II}^+(e)$ and the gauge constitutive operator $K_e(B_A)=g^2\star_e B_A$ prior to any fixed asymptotic Minkowski background.

### 3.2 General Four-Leg Gravitational Critical Equivalence and the Plebański `5/8` Criterion

Before solving for any particular configuration, a foundational formulation question must be settled: on an **arbitrary** smooth configuration carrying an independent matter dual, dynamical scalar, and non-Abelian gauge fields, what exact field equations are selected by joint stationarity of the four first-order BF gravitational legs $(\lambda,B,e,\varpi)$ in (3.1), and how does this locus relate to first-order Einstein–Cartan–torsion gravity founded by Kibble [21] and Sciama [22], the Holst generalized first-order action [23], and quadratic Plebański models [3,7]?

**Theorem 3.3 (General four-leg gravitational critical-locus equivalence and Plebański `5/8` jurisdiction criterion).**

1. **General four-leg critical equivalence**: for every smooth unified source $s$ and every smooth, Lorentz-admissible, everywhere coframe-nondegenerate nine-field configuration $\mathcal C$ with integrable local density on the origin chart, the common action (3.1) is jointly stationary along the four gravitational channels $(\lambda,B,e,\varpi)$ **if and only if** the following four pointwise geometric–matter equations hold simultaneously on $\mathcal C$:
   $$\begin{aligned}
   &\text{(i) Geometric simplicity:}\quad B=\mathrm{II}^+(e)=J\Sigma_e\text{;}\\
   &\text{(ii) Unique source-generated reaction multiplier:}\quad \lambda=JB-\widehat F_\varpi\text{;}\\
   &\text{(iii) Explicit Einstein–Cartan coframe balance:}\quad \mathcal E_e^{\rm EC}(s,\mathcal C)=0\text{;}\\
   &\text{(iv) Matter-coupled torsion–spin equation:}\quad D_\varpi\bigl(\mathrm{II}^+(e)\bigr)+j_{\rm spin}(\mathcal C)=0.
   \end{aligned}\tag{3.4}$$
2. **Plebański `5/8` pair-exchange defect and jurisdiction exclusion**: on the fixed positive source's historical synchronized configuration, reconstructing a candidate quadratic multiplier matrix $\Phi_{\rm cand}=\mathcal R_{\rm tot}\cdot B_0^{-1}\in\mathbb R^{6\times6}$ from the unit-coframe simplicity bivector $B_0=\mathrm{II}^+(I)$ and the total gravitational reaction balancing all non-gravitational coframe loads yields an exact antisymmetric pair-exchange defect at internal bivector indices $(3,4)$ (the $23$–$31$ pair in the $0$-based ordering of §3.1) equal to the non-gravitational coframe stress along $E_{03}$:
   $$\operatorname{defect}_{3,4}(\Phi_{\rm cand}):=(\Phi_{\rm cand})_{4,3}-(\Phi_{\rm cand})_{3,4}=\frac{5}{8}=T_{\rm non\text{-}grav}(E_{03})\ne 0.\tag{3.5}$$
   Hence $\Phi_{\rm cand}$ lies outside the standard nonchiral quadratic Plebański multiplier space, defined by pair-exchange symmetry and zero $\varepsilon$-trace; moreover, for every $g\in\mathrm{Spin}^+(1,3)$, transforming $B_0$ and the reaction simultaneously under the internal bivector representation leaves the standard Plebański compatibility residual strictly nonzero.

**Proof.** Part 1 proceeds by a two-stage bidirectional reduction (complete derivation in Appendix B.8): first, testing against compactly supported smooth bivectors shows that $(\lambda,B)$-stationarity is equivalent to $B=\mathrm{II}^+(e)$ and $\lambda=JB-\widehat F_\varpi$; second, on the simplicity locus, varying the reduced action $S(\pi_{\mathrm{II}^+}(\mathcal C))$ with respect to $(e,\varpi)$ agrees identically direction by direction with the partial $(e,\varpi)$-variations of the full nine-field action plus the reaction multiplier term, turning $\varpi$-stationarity into $D_\varpi(\mathrm{II}^+(e))+j_{\rm spin}=0$ and $e$-stationarity into explicit Einstein–Cartan coframe stress balance. Part 2 evaluates the rational difference between entries $(4,3)$ and $(3,4)$ of $\Phi_{\rm cand}$ to $5/8$, identifies it with the matter–gauge coframe stress along $E_{03}$, and transports nonvanishing across $\mathrm{Spin}^+(1,3)$ by the invertible pullback on both bivector indices. ∎

The first part characterizes four-leg stationarity on general nondegenerate configurations. The fixed synchronized configuration and its Spin orbit supply an exact counterexample to representing the full reaction by a pure symmetric quadratic multiplier.

### 3.3 Exact Signed Elimination of the Gauge Auxiliary Field and Geometric Invariances

Unlike the linear simplicity multiplier $\lambda$, the gauge auxiliary $B_A$ enters (3.1) quadratically through $-\tfrac12 W_j(B_{A,j},g_j^2\star_e B_{A,j})$, whose Lorentzian signature ($\star_e^2=-1$) makes the quadratic form indefinite. Eliminating $B_A$ must preserve exact Lorentzian signs.

**Theorem 3.4 (Exact signed elimination of the gauge auxiliary field and bidirectional coordinate splitting).** For every smooth unified source $s$, everywhere coframe-nondegenerate nine-field configuration, chart, and spacetime point, let $F_A$ be the gauge curvature and $\alpha_j=g_j^2(s)>0$. Then $K_{e,j}=\alpha_j\star_e$ is invertible, the constitutive equation $K_e(B_A)=F_A$ has the unique algebraic solution

$$B_{A,j}^{*}=K_{e,j}^{-1}F_{A,j}=-\alpha_j^{-1}\star_e F_{A,j} ,$$

and the full local density satisfies the exact signed completion-of-squares identity

$$L_s(B_A)\;=\;L_s(B_A^{*})-\tfrac12\,W\big(B_A-B_A^{*},\,K_e(B_A-B_A^{*})\big) .$$

Moreover, the full nine-field configuration space decomposes bijectively—without requiring nondegeneracy—into $(\text{constitutive-centre configuration})\oplus(\text{auxiliary residual }\delta B_A=B_A-B_A^*)$, and full field recovery together with this signed quadratic identity is preserved across any finite sequence of source constitutive writes.

**Proof.** Using wedge symmetry $W(X,\star_e Y)=W(Y,\star_e X)$ and $\star_e^2=-1$, substituting $B_A=B_A^*+\delta B_A$ into $W(B_A,F_A)-\tfrac12 W(B_A,K_e B_A)$ cancels the linear cross-terms via $K_e B_A^*=F_A$ and leaves $-\tfrac12 W(\delta B_A,K_e\delta B_A)$. Bijectivity of the centre–residual split follows from idempotence and additive invertibility of the constitutive replacement map. ∎

**Proposition 3.5 (Chart-descent consistency, local Spin invariance, and moving-frame representation law).** For the fixed source and designated configuration: (i) on every chart and spacetime point, the local density transported across overlap transitions equals the original density; (ii) under any smooth local $\mathrm{Spin}^+(1,3)$ gauge transformation, the integrated action reading of the full configuration is invariant; (iii) in the full moving-frame representation, for every frame $f$, frame transformation $g$, and field section $\Phi$, pointwise reduction satisfies $\mathrm{reduce}(gf,g\cdot\Phi)=\mathrm{reduce}(f,\Phi)$ with identical action readings.

**Proof.** Part (i) follows from global patching (Proposition 2.4) and invariance of fibre pairings; (ii) substitutes smoothness, nondegeneracy, and Lorentz admissibility into the local Spin-covariant variation identity; (iii) follows from pointwise equivariance of frame-adjoint reduction (Appendices B.5–B.6). ∎

---

## 4 Unique Classical World Solution and Continuum Analytic Closure

Theorem 3.3 characterizes what the field equations mean geometrically, yet does not by itself guarantee that the solution space is nonempty. Delivering a concrete theory requires two further steps: first, constructing an explicit nontrivial smooth nine-field configuration that annihilates all nine variational residuals pointwise and is unique under lawful history recovery; second, proving at the dynamical PDE level that weighted mother-action weak zeros are equivalent to source-generated Volterra integral fixed points with common full-measure spatial $L^2$ uniqueness, and that all-order spatial commutators close in symmetric-hyperbolic energy without derivative loss.

### 4.1 Explicit Nine-Field Configuration and Simultaneous Vanishing of All Nine Channels

Retain the constants generated by the fixed positive source $S_0$ in Example 1.1:

$$\sigma=\tfrac12,\qquad k=\sqrt2,\qquad a=\frac{3k}{5},\qquad
N=\sqrt{\frac{54}{125}},\qquad \omega=\frac{3N}{2}(k-a).\tag{4.1}$$

Denote the orthonormal basis of $\mathbb C^7$ by $c_0,c_1,c_2,w_0,w_1,h_+,h_-$, and write $E_I$ for the unit exterior basis wedge indexed by $I$. Select the two $2$-form matter basis elements wedging the first two colours with $h_+$,

$$q_s=(0,c_s\wedge h_+,0)\in\Lambda^6\oplus\Lambda^2\oplus\Lambda^4\quad(s=0,1),$$

with dual coordinate functionals $q_s^*$. The source-generated symmetry-breaking vacuum vector is the sum of four unit $4$-forms:

$$\varphi_0=E_{\{c_0,c_1,c_2,h_-\}}+E_{\{c_0,c_1,c_2,w_1\}}
+E_{\{c_0,c_1,h_+,h_-\}}+E_{\{c_0,c_1,w_1,h_+\}}.\tag{4.2}$$

For complex pairs $(u,v)$, define the $4\times2$ spinor–colour coefficient matrix, full matter field, and purely $\mathbb C$-linear independent dual functional (with no implicit complex conjugation):

$$C(u,v)=\begin{pmatrix}0&u\\-u&0\\0&v\\-v&0\end{pmatrix},\qquad
\Psi[u,v]_r=\sum_{s=0}^1C(u,v)_{rs}q_s,\qquad
\Xi[p,q](w)=\sum_{r=0}^3\sum_{s=0}^1 C(p,q)_{rs}q_s^*(w_r).\tag{4.3}$$

Set $u=e^{i\omega t}$ and $v=e^{-i\omega t}$ ($uv=1$, $t=x^0$). Place the three anti-Hermitian gauge generators on the first two colour indices,

$$\tau_0=\frac12\begin{pmatrix}0&i\\i&0\end{pmatrix},\qquad
\tau_1=\frac12\begin{pmatrix}0&1\\-1&0\end{pmatrix},\qquad
\tau_2=\frac12\begin{pmatrix}i&0\\0&-i\end{pmatrix},\tag{4.4}$$

with zeros on all remaining blocks, so $[\tau_0,\tau_1]=-\tau_2$ (cyclically) and $-\operatorname{Re}\operatorname{Tr}(\tau_i\tau_j)=\tfrac12\delta_{ij}$.

**Construction 4.1 (Explicit nine-field configuration).** At every spacetime point $x\in\mathbb R^4$, set

$$e=\operatorname{diag}(N,1,1,1),\quad
A=(0,a\tau_0,a\tau_1,a\tau_2),\quad
\varphi=\varphi_0,\quad \psi=\Psi[u,v],\quad \chi=\Xi[ku,kv].\tag{4.5}$$

Define the index-lowered spin-connection matrix $C_{\mu I}=\varpi_{\mu a_Ib_I}$ by

$$C_{\mu I}=\begin{pmatrix}
0&0&0&0&0&0\\
0&0&0&k&0&0\\
0&0&0&0&k&0\\
0&0&0&0&0&k
\end{pmatrix},\tag{4.6}$$

determining $\varpi_\mu{}^a{}_b$ via $\varpi_{\mu ba}=-\varpi_{\mu ab}$ and $\eta$. In the internal-row / spacetime-column ordering of §3.1, set the three algebraic channels to

$$\begin{aligned}
B&=\begin{pmatrix}0&I_3\\-NI_3&0\end{pmatrix},
&\lambda&=\operatorname{diag}(-N,-N,-N,k^2-1,k^2-1,k^2-1),\\
B_A&=\frac{a^2}{\sigma N}(\tau_0,\tau_1,\tau_2,0,0,0).
\end{aligned}\tag{4.7}$$

While the torsion-free Levi–Civita connection of a constant diagonal tetrad vanishes, (4.6) carries nonzero spatial torsion whose quadratic wedge generates nonzero gravitational and non-Abelian gauge curvatures:

$$\widehat F_\varpi=F_\varpi^{\rm raw}
=\operatorname{diag}(0,0,0,-k^2,-k^2,-k^2),\qquad
F_A=(0,0,0,-a^2\tau_0,-a^2\tau_1,-a^2\tau_2).\tag{4.8}$$

With $\rho=a/k=3/5$, $a^3=2\sigma N^2k=N^2k$, and $k^2=2$, we have $N^2=2\rho^3=54/125$ and $\omega=\rho Nk$, while the Lorentzian constitutive inverse $B_A=-\sigma^{-1}\star_e F_A$ maps purely magnetic spatial curvature into a purely electric auxiliary field.

**Theorem 4.2 (Joint zero fibre across all nine Euler–Lagrange channels).** Construction 4.1 annihilates all nine Euler–Lagrange variational residuals of the common action (3.1) pointwise at every $x\in\mathbb R^4$ (Appendices B.3–B.4).

**Proof.** We verify the four coupled cancellations channel by channel:

1. **Algebraic channels and torsion–spin balance.** Equations (4.7)–(4.8) immediately give $B=J\Sigma_e$, $\lambda=JB-\widehat F_\varpi$, and $K_e B_A=F_A$, annihilating (3.2). Along the spin-connection channel, substituting $p=ku,q=kv$ into (4.3) and using the phase-independent cross invariant
   $$pv=qu=k\tag{4.9}$$
   together with the Dirac matrices of Appendix A.2 evaluates the matter spin density across all $4\times6=24$ directions:
   $$\operatorname{Re}\frac{i}{2}\Xi[p,q]\bigl(\gamma^\mu\gamma^{a_I}\gamma^{b_I}\Psi[u,v]\bigr)
   =\begin{cases}-2k,&(\mu,I)=(1,3),(2,4),(3,5),\\0,&\text{all other 21 directions,}\end{cases}\tag{4.10}$$
   which multiplies by $\nu_e=N$ to give $-2Nk$ in the three active slots. Conversely, (4.6) produces spatial torsion $T^1_{23}=T^2_{31}=T^3_{12}=-2k$ (zero elsewhere), giving $D_\varpi B=+2Nk$ in the exact same slots so that $D_\varpi B+j_{\rm spin}=0$ componentwise.
2. **Forward Dirac and contragredient adjoint equations.** Write $\mathcal R_1=\gamma^2\gamma^3,\mathcal R_2=\gamma^3\gamma^1,\mathcal R_3=\gamma^1\gamma^2$. Along the three spatial axes, $\rho_{\mathcal M}(\tau_i)\Psi[u,v]=-\tfrac12\mathcal R_i\Psi[u,v]$, hence $D_{i+1}\psi=\tfrac{k-a}{2}\mathcal R_i\psi$ and $\gamma^{i+1}\mathcal R_i\Psi[u,v]=i\Psi[v,u]$, while temporally $D_0\psi=\Psi[i\omega u,-i\omega v]$ and $\gamma_e^0=\gamma^0/N$. Summing gives
   $$i\gamma_e^\mu D_\mu\psi=\left(\frac{\omega}{N}-3\frac{k-a}{2}\right)\Psi[v,u]=0.\tag{4.11}$$
   Since every term of $\varphi_0$ contains $c_0\wedge c_1$, its wedge with $q_s$ vanishes identically, giving $Y_R(\varphi_0)\psi=0$ and $\mathcal E_\chi=0$. Varying $\psi$ along an arbitrary $w\in\mathcal M$ yields spatial algebraic load and temporal momentum divergence
   $$Q_\psi[w]=-\omega\operatorname{Re}\Xi[q,p](w),\qquad
   \partial_\mu P_\psi^\mu[w]=\partial_0\operatorname{Re}\Xi[p,q](i\gamma^0w)=-\omega\operatorname{Re}\Xi[q,p](w),\tag{4.12}$$
   and since $\Xi$ reads only $\Lambda^2$ while $Y_R(\varphi)w\in\Lambda^6$, $\chi(Y_R(\varphi)w)=0$ for all $\varphi,w$, giving $Q_\psi-\partial_\mu P_\psi^\mu=0$ and $\mathcal E_\psi=0$.
3. **Non-Abelian gauge current and scalar channel.** Set $\beta=a^2/(\sigma N)$. Ordered along $3$-form basis $(012,013,023,123)$, the exterior covariant derivative and matter gauge current read
   $$D_A B_A=(2a\beta\tau_2,-2a\beta\tau_1,2a\beta\tau_0,0),\qquad
   j_A=(-4Nk\tau_2,4Nk\tau_1,-4Nk\tau_0,0).\tag{4.13}$$
   By the cubic balance law $a^3=2\sigma N^2k$, $2a\beta=4Nk$, hence $D_A B_A+j_A=0$. For any Lie direction $X\in\mathfrak h_{\rm SM}$, the vector current components are
   $$J^0(X)=0,\qquad J^{i+1}(X)=4Nk\,\langle\tau_i,X\rangle_{\mathfrak h_{\rm SM}},\tag{4.14}$$
   reproducing $2Nk=12\sqrt{15}/25$ at $i=1,X=\tau_1$ in Example 1.1(b). Constant $\varphi_0$ satisfies $\rho_4(\tau_i)\varphi_0=0$, $dU_s(\varphi_0)=0$, and $\chi(Y_R(h)\psi)=0$, giving $\mathcal E_\varphi=0$.
4. **All sixteen real matrix directions of the coframe.** Holding the other eight fields fixed, the matter kinetic tensor is
   $$T_{a\mu}=\operatorname{Re}\chi(i\gamma^aD_\mu\psi)
   =\operatorname{diag}\bigl(4k\omega,-2k(k-a),-2k(k-a),-2k(k-a)\bigr)_{a\mu}.\tag{4.15}$$
   Although the trace $(e^{-1})^\mu{}_a T_{a\mu}=0$ annihilates the determinant-volume variation on shell, differentiating the inverse tetrad $D(f^{-1})[H]=-f^{-1}Hf^{-1}$ along an arbitrary $H\in\mathbb R^{4\times4}$ contributes
   $$\mathcal E_e^{\rm mat}[H]=-6k(k-a)H_{00}+2Nk(k-a)(H_{11}+H_{22}+H_{33}),\tag{4.16}$$
   while the gauge constitutive and gravitational simplicity reactions contribute
   $$\begin{aligned}
   \mathcal E_e^{\rm gauge}[H]&=\frac{a^4}{4\sigma N^2}[3H_{00}-N(H_{11}+H_{22}+H_{33})],\\
   \mathcal E_e^{\rm grav}[H]&=-(3-3k^2)H_{00}-N(3-k^2)(H_{11}+H_{22}+H_{33}).
   \end{aligned}\tag{4.17}$$
   Substituting $k^2=2$, $a/k=3/5$, and $a^4/(4\sigma N^2)=3/5$ cancels all sixteen standard matrix directions identically:

| Coframe variation direction | Gravitational reaction | Gauge constitutive | Matter kinetic load | Total residual |
|---|---:|---:|---:|---:|
| Temporal diagonal $H_{00}=1$ | $+3$ | $+9/5$ | $-24/5$ | $0$ |
| Spatial diagonals $H_{ii}=1$ ($i=1,2,3$) | $-N$ | $-3N/5$ | $+8N/5$ | $0$ |
| Remaining 12 off-diagonal slots | $0$ | $0$ | $0$ | $0$ |

All nine variational channels vanish pointwise. ∎

### 4.2 Six Nonzero Physical Sectors, Unique Recovery, and Compact-Domain All-Order Bounds

Trivial vacua or pure-gauge configurations cannot host genuine matter–geometry coupling. Beyond smoothness, global coframe nondegeneracy, Lorentz admissibility, the nine-channel zero fibre, and scalar origin contact, **Classical World Acceptance** explicitly requires six core physical sectors to be simultaneously nonzero.

**Proposition 4.3 (Simultaneous nonvanishing of six physical sectors).** Construction 4.1 simultaneously satisfies: (1) nonzero gravitational curvature; (2) nonzero Standard Model gauge curvature; (3) nonzero symmetry-breaking scalar vacuum; (4) nonzero Yukawa mass map; (5) nonzero matter gauge current; and (6) nonzero coframe matter stress and spin-torsion source.

**Proof.** Equation (4.8) gives gravitational curvature $-k^2=-2\ne0$ and non-Abelian gauge curvature $-a^2\tau_i\ne0$; (4.2) gives a nonzero vacuum and nonzero exterior-wedge mass map; (4.14), (4.10), and (4.16) give nonzero gauge current $2Nk$, spin-torsion source $-2Nk$, and coframe matter stress. ∎

**Theorem 4.4 (Unique classical world solution).** Under the fixed positive source, there exists a **unique** nine-field configuration simultaneously satisfying: (i) **lawful classical actuality**—its compactly supported coordinate readout equals the weak cluster-point density of some strictly increasing visit subsequence of the original complete occurrence history on the compactly supported $L^2$ coordinate carrier; and (ii) all clauses of Classical World Acceptance. That unique configuration is Construction 4.1.

**Proof.** In the original complete occurrence history, every field coordinate readout stabilizes from visit index $7$ onward at Construction 4.1, supplying an immediate weak cluster witness; conversely, any strictly increasing subsequence converges weakly to the same compact coordinate readout by injectivity of coordinate projections, which pins down the smooth configuration uniquely by point separation. ∎

**Theorem 4.5 (All-order compact-domain derivative bounds across the full history and all lawfully recovered fields).** For every derivative order $m\in\mathbb N$ and compact set $K\subset\mathbb R^4$, there exists an a priori constant $C(K,m)\ge0$ bounding $\|D^m(\text{field readout})(x)\|\le C(K,m)$ across **every** visit index of the original history, **all** real coordinates of the nine fields, and every $x\in K$; the identical constant $C(K,m)$ uniformly bounds every smooth configuration lawfully recovered from weak-admission densities, independently of the chosen subsequence.

**Proof.** Coordinate readouts stabilize from visit $7$ onward, reducing the infinite visit family on $K$ to the finite union of the first eight smooth configurations; lawfully recovered configurations coincide with the stabilized smooth field by Theorem 4.4 and inherit the same bounds. ∎

### 4.3 Source-Generated Volterra Uniqueness and Derivative-Loss-Free All-Order Energy Closure

Theorems 4.4–4.5 exploit stabilization of the explicit homogeneous history. For PDE analysts, a deeper question arises in general spatially inhomogeneous evolution: can the first-order variational structure of the mother action itself characterize weak solutions, uniquely identify the spatial $L^2$ field, and close arbitrary-order spatial derivative estimates without derivative loss? The next two theorems answer affirmatively on the source-generated noncharacteristic Cauchy-safe background (complete proofs in Supplement S16).

Fix a positive time horizon $[0,T]$ ($T>0$), compact spatial box $Q=[a,b]\subset\mathbb R^3$ ($a\le b$), and countable dense basis $\{\phi_n\}_{n\in\mathbb N}$ of the spatial test carrier. For the source-generated whole-time $L^2$ output $u_{\rm src}:[0,T]\to L^2(Q)$, denote the $n$-th mother-mass inner-product readout by $m_n(t)=\langle\phi_n,M(t)u_{\rm src}(t)\rangle_{L^2(Q)}$, the mother-action spatial Green rate readout by $g_n(t)$, and the source-lifted initial readout by $m_{n,0}$.

**Theorem 4.6 (Equivalence of weighted mother-action weak zeros and Volterra fixed points with common full-measure $L^2$ uniqueness).** For every $T>0$, spatial box $a\le b$, and test index $n\in\mathbb N$:

1. **Weak-action / Volterra equivalence**: $m_n$ and $g_n$ are interval-integrable on $[0,T]$; across all smooth temporal weights $w\in C^1([0,T])$ vanishing at the upper endpoint $w(T)=0$, the weighted mother-action weak-zero equation is strictly equivalent to the initial-value Volterra integral fixed-point equation, and $u_{\rm src}$ satisfies both:
   $$\begin{aligned}
   &\forall w\in C^1([0,T])\ (w(T)=0),\quad\int_0^T\!\bigl(w(t)g_n(t)+w'(t)m_n(t)\bigr)\,dt + w(0)m_{n,0}=0\\
   &\qquad\Longleftrightarrow\quad m_n(t)=m_{n,0}+\int_0^t g_n(s)\,ds\quad(\text{a.e. }t\in[0,T]).
   \end{aligned}\tag{4.18}$$
2. **Spatial $L^2$ uniqueness on a single common full-measure time set**: there exists a single full-measure subset $\Omega_{T,Q}\subseteq[0,T]$ (common to all $n\in\mathbb N$ and nonempty) such that for every $t\in\Omega_{T,Q}$ and candidate spatial field $v\in L^2(Q)$, matching all countable dense mass readouts against the continuous Volterra representatives forces $v=u_{\rm src}(t)$ in $L^2(Q)$.

**Proof sketch.** Part 1 integrates the absolutely continuous product $w(t)G_n(t)$ by parts using $w(T)=0$ and recovers the converse via primitives $w_\varphi(t)=-\int_t^T\varphi(s)\,ds$ of arbitrary $\varphi\in C_c^\infty((0,T))$ (free at $t=0$). Part 2 intersects the countably many full-measure sets $\Omega_n$ to obtain a common full-measure set $\Omega_{T,Q}$ (of measure $T>0$, hence nonempty), where injectivity of the positive-definite mother-mass pairing against the dense span $\{\phi_n\}$ pins down $v=u_{\rm src}(t)$ (Supplement S16.1–S16.2). ∎

Turning to higher regularity, differentiating a variable-coefficient first-order system $\mathcal L_{\rm mat}=A^0(x)\partial_t+\sum_{i=1}^3 A^i(x)\partial_i+B_0(x)$ (with symmetric positive-definite $A^0(x)$ and symmetric $A^i(x)$) normally risks losing one derivative through commutator terms. Here we prove that the mother action recursively generates bounded spatial-jet forcing operators that absorb all commutators into the **same** derivative order.

**Theorem 4.7 (All-order spatial-jet forcing operators and derivative-loss-free symmetric-hyperbolic energy closure).** For every compact spacetime box $I\times Q=[t_0,t_1]\times[a,b]$ ($t_0\le t_1,a\le b$) and spatial derivative order $r\in\mathbb N$:

1. **All-order source-generated jet forcing operators**: for every spatial word $w\in\{1,2,3\}^*$ ($|w|\le r$), the source coefficients explicitly and recursively construct smooth bounded linear operators $\mathcal J_w(x)\in\mathcal L(J_{\rm sp}^{|w|},\mathcal V)$—depending solely on pure spatial jets $j_{\rm sp}^{|w|}u(x)$ of order $\le|w|$ with no target field or on-shell hypothesis in their definition—such that for **every** smooth solution $u\in C^\infty(\mathbb R^4,\mathcal V)$ of $\mathcal L_{\rm mat}u=0$, one has pointwise $\mathcal J_w(x)(j_{\rm sp}^{|w|}u(x))=[\partial^w,\mathcal L_{\rm mat}]u(x)$ (where mixed $\partial_t$ commutators are eliminated via $\partial_t u=-(A^0)^{-1}(\sum_i A^i\partial_i u+B_0 u)$);
2. **Same-order energy absorption prior to all fields**: there exist constants $\kappa>0$ and $L,K\ge 0$ determined solely by the source coefficients and compact box $I\times Q$ (**quantified prior to all fields $u$**) such that for every smooth solution of $\mathcal L_{\rm mat}u=0$ and every $(t,\mathbf x)\in I\times Q$, with $r$-th order pointwise energy $\mathcal E_r[u]=\sum_{|w|\le r}\langle\partial^w u,A^0\partial^w u\rangle$, commuted forcing budget $\mathcal F_r[u]=\sum_{|w|\le r}\|(A^0)^{-1}[\partial^w,\mathcal L_{\rm mat}]u\|^2$, and energy-rate magnitude $\mathcal R_r[u]$,
   $$\kappa\,\mathcal F_r[u](t,\mathbf x)\;\le\;L\,\mathcal E_r[u](t,\mathbf x),\qquad
   \kappa\,\mathcal R_r[u](t,\mathbf x)\;\le\;K\,\mathcal E_r[u](t,\mathbf x).\tag{4.19}$$
   Only the $r$-th order spatial energy $\mathcal E_r[u]$ appears on the right-hand side; no $(r+1)$-st derivative occurs.

**Proof sketch.** Inducting on $w=i\cdot\tilde w$, differentiating $\mathcal J_{\tilde w}(x)(j_{\rm sp}^{|\tilde w|}u)$ along $x^i$ produces a $(|\tilde w|+1)$-jet shift, spatial derivatives of $\mathcal J_{\tilde w}$, and $[\partial_i,\mathcal L_{\rm mat}]\partial^{\tilde w}u$; eliminating $\partial_t\partial^{\tilde w}u$ via $\mathcal L_{\rm mat}(\partial^{\tilde w}u)=-\mathcal J_{\tilde w}(j_{\rm sp}^{|\tilde w|}u)$ confines all terms strictly within $J_{\rm sp}^{|w|}$. Uniform operator norms and coercivity of $A^0$ on $I\times Q$ sum wordwise to yield (4.19) (Supplement S16.3–S16.4). ∎

---

## 5 Nonlinear Clock–Auxiliary Coupling and Gravitational Recoil

### 5.1 Finite-Amplitude Stretching: The Two-Parameter Clock–B Section

Theorem 4.2 sits at an equilibrium point; to see how the sectors inside (3.1) constrain one another, we apply a **finite-amplitude** deformation (with no infinitesimal linearization): holding spacetime coordinates fixed, rescale the temporal column of the coframe by $(1+u)$ (altering proper-time lapse) and the gauge auxiliary field $B_A$ by $(1+b)$, while freezing the remaining seven fields—in particular the gravitational bivector $B$—at Construction 4.1.

**Construction 5.1 (Two-parameter Clock–B configuration family).** On the origin chart and parameter domain $u>-1,b\in\mathbb R$, define $\mathrm{clock}(u,b)$ as the nine-field configuration obtained from Construction 4.1 by setting $e^0\mapsto(1+u)e^0$, $B_A\mapsto(1+b)B_A$, and holding the other seven fields fixed; $(u,b)=(0,0)$ recovers the equilibrium solution.

### 5.2 Exact Cubic Normal Form, Saddle Hessian, and Conditional Minimum

Substituting $\mathrm{clock}(u,b)$ into the full nonlinear density (3.1) collapses all higher-order dependencies into an exact cubic polynomial.

**Theorem 5.2 (Exact cubic normal form and mixed Hessian).** On $u>-1,b\in\mathbb R$, the full local density at the origin equals

$$L(u,b)=L_0+\kappa\,\big(b^2+2ub+ub^2\big),\qquad \kappa=\frac{9N}{5}>0 ,\qquad L_0=L(0,0).$$

At equilibrium $(0,0)$, the mixed second-derivative Hessian and its determinant are

$$H=2\kappa\begin{pmatrix}0&1\\[2pt]1&1\end{pmatrix},\qquad \det H=-4\kappa^2<0 .$$

**Proof.** Evaluating (3.1) sector by sector: (1) Gravity: rank-one stretching of the temporal column generates no new spatial bivector wedges, so simplicity is strictly affine in $u$, contributing $+3Nu$; (2) Gauge: the spacetime Hodge star $\star_e$ carries factor $(1+u)$ on electric $2$-form slots, so the constitutive term contributes $\kappa\bigl((1+u)(1+b)^2-2(1+b)+1\bigr)$, generating both the $b^2$ stiffness and the $ub,ub^2$ couplings from the same $(1+u)$ factor; (3) Matter: rescaling the inverse temporal tetrad contributes purely linearly $-6Nuk(k-a)=-(24/5)Nu$. The three linear $u$-coefficients sum to $(3+\tfrac95-\tfrac{24}5)Nu=0$—reproducing the temporal coframe balance of Theorem 4.2 across finite stretches. Thus pure $u$ cancels identically, leaving $\kappa(b^2+2ub+ub^2)$, whose Hessian $H$ has characteristic polynomial $x^2-x-1=0$ (principal slopes at the golden ratio $\phi_g=(1+\sqrt5)/2$ and $-1/\phi_g$). ∎

**Theorem 5.3 (Unique conditional auxiliary valley and effective action).** For every clock stretch $u$ with $1+u>0$, $b\mapsto L(u,b)$ is strictly convex and attains its unique global minimum at

$$b^{*}(u)=-\frac{u}{1+u},\qquad L_{\mathrm{eff}}(u)=L_0-\frac{\kappa\,u^2}{1+u},$$

with exact completion of squares $L(u,b)=L_{\mathrm{eff}}(u)+\kappa(1+u)\bigl(b-b^*(u)\bigr)^2$; applying the source constitutive write of Theorem 3.4 to $\mathrm{clock}(u,b)$ outputs $\mathrm{clock}(u,b^*(u))$ identically.

**Proof.** Solving $\partial_b L=2\kappa(1+u)b+2\kappa u=0$ for $1+u>0$ gives $b^*(u)=-u/(1+u)$. At the source seed $u=\sigma=1/2$, constitutive relaxation lands at $b^*=-1/3$ and lowers the effective density by $\Delta L=3N/10$. ∎

### 5.3 Stress Transmission: The `-N/2` Gravitational Recoil and Off-Family Successor

Under gauge constitutive elimination alone, the configuration remains inside the two-dimensional slice $\mathrm{clock}(u,b^*(u))$. Executing the **complete source update** of the common action transmits the stretched coframe through simplicity $B=\mathrm{II}^+(e)$ onto the gravitational bivector $B$, propelling the successor strictly outside the initial family.

**Theorem 5.4 (Nonzero gravitational recoil and off-family successor).** Executing the complete source write at the seed $u=\sigma=\tfrac12$ (where $B_A$ relaxes to $b^*=-1/3$) yields: (i) an exact nonzero jump $\Delta B_{3,0}=-N/2$ in the $(3,0)$ gravitational bivector component at the origin ($-uN$ for general $u$); and (ii) a full nine-field successor strictly outside the two-parameter family—for all $(u',b')$, the successor $\ne\mathrm{clock}(u',b')$.

**Proof.** Every member of the frozen-gravity family $\mathrm{clock}(u',b')$ has $B_{3,0}=-N$. The full source write rebuilds $B=\mathrm{II}^+(e)=J(e\wedge e)$ from $\operatorname{diag}((1+u)N,1,1,1)$, updating $B_{3,0}$ to $-(1+u)N=-3N/2$ (a shift of $-N/2\ne0$), which differs from every $\mathrm{clock}(u',b')$ in that coordinate. ∎

![Figure 2 Nine-field balance, mixed density and off-family successor](figures/vector/fig2-nine-field-balance-en.png)

**Figure 2｜Nine-field balance network, Clock–B cubic density landscape, and off-family gravitational recoil.** Top: mutual locking of the nine fields in Construction 4.1, Dirac phase balance (4.11), and temporal/spatial coframe balance (4.17). Bottom: contours of the exact dimensionless density $\ell=(L-L_0)/\kappa=b^2+2ub+ub^2$; the thick solid curve $b^*=-u/(1+u)$ marks the conditional gauge valley for $u>-1$, long dashed lines show the golden-ratio principal axes of the saddle Hessian at $(0,0)$, and dotted contours denote negative levels. Right inset: under the full source write at $(1/2,-1/3)$, $B_{3,0}$ updates from $-N$ to $-3N/2$ (net recoil $-N/2$), exiting the frozen two-parameter section.

---

## 6 Postulate-Free Generation of Quantum State Spaces and Operator Algebras: From $4\sqrt2$ Pairing to the 504-Mode Common $H$

Under the Anti-Magic Pruning Law (§1.1), without pre-supplied quantum shells, how do quantum kinematics and dynamics grow directly out of the common action (3.1) as a dependent projection of the same occurrence? We proceed in two steps: §6.1–§6.2 first derive from the classical independent dual $\chi$ and on-shell matter field $\psi$ the normalized eight-dimensional inner-product state, 256-dimensional one-particle Fock embedding, and exact nonperturbative pairing constant $4\sqrt2$, verifying the dark-moment structural counterexample; §6.3–§6.5 then remove the fixed-background, one-particle restriction altogether, using a four-sector Legendre map to gather all 252 matter modes, 252 independent dual modes, scalars, gauge potentials, and coframe degrees of freedom into a single infinite-dimensional constrained configuration carrier carrying 61 CCR pairs and the 504-mode two-branch CAR generator $H=H_0+Y$, all-order quantum clock, fixed self-adjoint remainder $R$, actual CAR created unit state, and complete multiparticle Ward identity.

### 6.1 Eight-Dimensional Occupation State, Classical–Quantum Pairing, and the $4\sqrt2$ Coefficient

Projecting an arbitrary 252-complex-dimensional matter field onto 8 dimensions necessarily loses information; on Construction 4.1, however, $\psi$ is supported entirely on the eight-dimensional occupation subspace $\mathcal E=\mathbb C^8$ spanned by $(\text{Dirac 4-spinor})\times(\text{first two colour modes})$, where $\chi$ exhibits a field-equation-locked conjugate block-swap relation.

**Definition 6.1 (Normalized eight-dimensional occupation state).** Let $E:\mathbb C^8\to\mathcal M$ be the isometric embedding into basis elements $q_0,q_1$ of (4.3) across the four spinor components, with orthogonal projection $P=E^*:\mathcal M\to\mathbb C^8$ ($PE=I_8$). For $\psi$ of Construction 4.1, define the **occupation state** $v=\tfrac12 P\psi$. At $x$ ($\theta=\omega x^0$), in lexicographic (spinor, colour) order,

$$v=\tfrac12\big(0,\,e^{i\theta};\;-e^{i\theta},\,0;\;0,\,e^{-i\theta};\;-e^{-i\theta},\,0\big),\qquad \langle v,v\rangle=4\times\tfrac14=1,\qquad \psi=2Ev.$$

Time translation by $\Delta$ acts on $\mathbb C^8$ via the unitary matrix $\operatorname{diag}(e^{i\omega\Delta},e^{i\omega\Delta},e^{-i\omega\Delta},e^{-i\omega\Delta})\otimes I_2$.

**Theorem 6.2 (Classical–quantum pairing identity).** Fix $S_0$ and Construction 4.1. Let $S\in\operatorname{End}_{\mathbb C}(\mathbb C^8)$ be the self-adjoint unitary involution swapping upper and lower Dirac two-spinors ($0\leftrightarrow2,1\leftrightarrow3$, colour unchanged), and define the compressed response map $R:\operatorname{End}_{\mathbb C}(\mathcal M)\to\operatorname{End}_{\mathbb C}(\mathbb C^8)$ by $R(A)=SPAE$. At every spacetime point and for **every** complex-linear operator $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$ (neither necessarily self-adjoint nor preserving $\mathcal E$),

$$\chi\big(A\psi\big)\;=\;4k\,\big\langle v,\,R(A)\,v\big\rangle,\qquad k=\sqrt2\quad(\text{inner product conjugate-linear in its first slot}).$$

**Proof.** Write $u=e^{i\theta},v_-=e^{-i\theta}$. Applying $S$ to $v$, taking componentwise complex conjugation, and multiplying by $2k$ gives

$$2k\,\overline{Sv}=k(0,u;\,-u,0;\,0,v_-;\,-v_-,0),\tag{6.1}$$

which equals the linear coefficients of $\chi=\Xi[ku,kv_-]$ in (4.5) on the eight occupation modes, while $\chi$ vanishes on all $244$ orthogonal mother modes. Hence $\chi(w)=2k\langle Sv,Pw\rangle$ for every $w\in\mathcal M$. Setting $w=A\psi=2AEv$ and using $S^*=S$ gives in three lines:

$$\chi(A\psi)=2k\langle Sv,PA(2Ev)\rangle=4k\langle Sv,PAEv\rangle=4k\langle v,SPAEv\rangle.\tag{6.2}$$

Both factors have transparent origins: $2$ comes from the classical amplitude $\|\psi\|=2$, and $2k=2\sqrt2$ comes from the field-equation amplitude of the independent dual $\chi$, multiplying to the parameter-free constant $4\sqrt2$. Unlike Born's collision probability postulate [28] or Gleason's trace-measure theorem [29]—which presupposes the lattice of closed subspaces of a Hilbert space of dimension $\ge3$ together with frame-measure additivity—this positive normalized inner-product expectation is not an external quantum axiom, but an exact rewriting of the classical independent dual $\chi$ on the same occurrence. ∎

Specializing $A$ to gauge generators, covariant kinetic operators, and exterior Yukawa maps converts classical variations into quantum expectations term by term:

**Theorem 6.3 (Term-by-term identity of gauge currents, sixteen kinetic loads, and mass readings).** On the fixed source and designated solution:

1. **Gauge-current identity**: at every spacetime point and for every variation in $\mathfrak h_{\rm SM}$, the classical variational current and quantum expectation agree term by term under the common $4Nk$ normalization; on the colour-doublet generators, $\langle v,O_{g+1}(\tau_h)v\rangle=\tfrac12\delta_{gh}$, yielding $J^{g+1}(\tau_h)=2Nk\delta_{gh}$ (time-independently $2Nk$ on axis and $0$ off axis);
2. **Sixteen kinetic-load identities**: all $4\times4$ (spacetime $\times$ internal Lorentz) quantum kinetic-load expectations are Hermitian and equal entry by entry to $\operatorname{diag}\bigl(4k\omega,-2k(k-a),-2k(k-a),-2k(k-a)\bigr)$ in (4.15);
3. **Mass and occupation Yukawa readings**: the full 252-dimensional exterior mass map and all four $2\times2$ mixing entries are nonzero, while the on-shell occupation Yukawa expectation vanishes identically alongside the classical reading.

**Proof.** Part (1) reduces the $8\times8$ inner product via Dirac traces and colour orthogonality to $\langle\tau_g,\tau_h\rangle=\tfrac12\delta_{gh}$; (2)–(3) substitute the corresponding mother operators directly into (6.2) and (4.15). ∎

**Proposition 6.4 (Unitary connection transport, exterior-power jet remainders, and moving-frame commutation).** On the fixed source and designated solution: (1) the actual gauge generator $G$ on $\mathbb C^7$ is skew-adjoint, $U(t)=\exp(tG)$ is unitary for all $t\in\mathbb R$ with first-order jet $1+tG$ at $t=0$, and $\|\exp(tG)-(1+tG)\|\le\|G\|^2 t^2$ for $t\ge0$; (2) for **every** exterior degree $d\in\mathbb N$, vector $w\in\Lambda^d\mathbb C^7$, and basis coordinate $j$, $|[\Lambda^d U(t)w-\Lambda^d(1+tG)w]_j|\le C_{d,w,j}(t)\,t^2$ ($t\ge0$; explicit scale in Appendix B.4); (3) for every basepoint-equivalent $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ moving-frame transformation, exterior transport commutes identically with frame change.

**Proof.** Part (1) bounds the exponential series tail; (2) telescopes the $d$-fold wedge difference factor by factor, absorbing intermediate unitary norms into $(1+t\|G\|)^{d-1}$; (3) follows from adjoint equivariance and exterior functoriality. ∎

### 6.2 Standard Fock Lifting and the Dark-Moment Negative Control

Lifting $\mathbb C^8$ to the $2^8=256$-dimensional fermionic Fock space $\mathcal F_-(\mathbb C^8)=\bigoplus_{n=0}^8\Lambda^n\mathbb C^8$ (sector dimensions $1,8,28,56,70,56,28,8,1$) second-quantizes any one-body matrix $O$ to $\mathrm d\Gamma(O)=\sum_{i,j}O_{ij}c_i^\dagger c_j$.

**Theorem 6.5 (Preservation of one-particle matrix elements on the 256-dimensional Fock space).** For any finite linearly ordered mode set and complex matrix $O$ (not necessarily self-adjoint), explicit fermionic creation and annihilation operators satisfy $\mathrm d\Gamma(O)I(v)=I(Ov)$ and $\langle I(v),\mathrm d\Gamma(O)I(w)\rangle=\langle v,Ow\rangle$. Applied to the eight-mode occupation carrier, at every spacetime point and for every $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$, the classical dual pairing, variational gauge current, and sixteen kinetic loads are preserved identically by $4\sqrt2\langle I(v),\mathrm d\Gamma(R(A))I(v)\rangle$ at both the current and next runtime ticks.

**Proof.** On $\Lambda^1$, Jordan–Wigner occupation signs $(-1)^{\#}$ square to $+1$ under same-slot annihilation–creation composition, reducing $\mathrm d\Gamma(O)$ to exact matrix multiplication; substituting Theorems 6.2–6.3 yields full physical preservation (independently cross-checked across 812 evaluations on $\mathbb C^{256}$ to max residual $8.88\times10^{-16}$, Appendix D.3). ∎

**Example 6.6 (Dark-moment counterexample: bare compression omitting the dual swap $S$ fails).** Omitting the dual-induced Dirac swap $S$ and evaluating the bare compression $R_{\rm raw}(A)=PAE$ on spatial direction $1$, generator $\tau_0$, gives

$$\langle v,R_{\rm raw}(O_1(\tau_0))v\rangle=\frac{e^{-2i\theta}+e^{2i\theta}}{4}=\frac{\cos 2\theta}{2}=\cos^2\theta-\tfrac12 .$$

At $\theta=0$, $R_{\rm raw}$ outputs $+\tfrac12$, matching the true conserved current $+\tfrac12$; yet at $\theta=\pi/4$ it drops to $0$, and at the dark moment $\theta=\pi/2$ it flips sign to $-\tfrac12$, missing the truth $+\tfrac12$ by $1$ (Figure 1 inset). Checking correspondence at $t=0$ alone is illusory: only the full operator bridge $S$ dictated by $\chi$ in (6.1) sustains identity across all time.

### 6.3 Four-Sector Legendre Map and the 504-Mode Common Quantum Hamiltonian

One-particle Fock embedding touches only 8 modes on a fixed background. Full quantum field theory requires bringing all 252 modes of $\psi$, 252 modes of $\chi$, 35 complex (70 real) scalar coordinates of $\varphi$, gauge potentials, and coframe components into a single canonical phase space, resolving degenerate primary and Gauss constraints, and constructing a parameter-free common Hamiltonian on one weighted Hilbert space. In canonical quantum gravity, applying singular Legendre mechanics [14] to temporal reparametrization constraints ordinarily leads to the timeless Wheeler–DeWitt frozen-state equation [25] or requires positing an external relational conditional clock [26]; in Theorems 6.7–6.8 below, the four temporal constraints of our first-order common action recursively solve via an invertible principal Jacobian block for an all-order noncommutative quantum clock and common generator $H=H_0+Y$ without freezing evolution or importing relational clock postulates (complete proofs in Supplement S1–S2).

**Theorem 6.7 (Common quantum Hamiltonian and action-kernel identification).** On the connected noncharacteristic configuration neighbourhood of the fixed source, starting from the common action (3.1):

1. **Common canonical carrier (61 CCR pairs and 504-mode two-branch CAR)**: a rank-six coframe six-velocity right inverse (carrying ten primary temporal–Lorentz constraints), scalar map, spatial gauge map, and dual-retaining matter $1$-form $\operatorname{Re}(ip\,\delta\psi)$ assemble a common canonical $1$-form. Pulling back along a transverse real basis of the nine non-stabilizer Gauss directions yields **61 scalar canonical commutation relations (CCR)**, while complexifying the real canonical coordinates of $(\psi,\chi)$ in **one single CAR quantization** yields the $252+252=504$-mode standard two-branch fermionic algebra. Summing the four sector energies on $C_c^\infty(\mathscr U_{103})\otimes\mathcal F_{504}$ and descending along the three stabilizer gauge pivots (source orbit determinant $-54\sqrt2/125\ne0$) produces the **100-dimensional configuration manifold** $\mathscr U_{100}$; normal-momentum integration across the nine second-class scalar constraints cancels the second-class determinant to exact unity, defining with section weight $\rho_3>0$ and occupation-dependent volume weight $v^{m+2}$ the positive weighted Hilbert space $\mathscr H=\bigoplus_{|w|=m}L^2(\mathscr U_{100},\rho_3 v^{m+2}dz)$ and unitary half-density map.
2. **Formal adjoint pair and four-time Weyl equations of motion**: on the dense invariant core $\mathscr D_{100}$, the non-Yukawa energy $H_0$ is formally symmetric, while the unidirectional chiral Yukawa operator $Y$ is nonzero and nonsymmetric ($\|Y|144,396\rangle\|^2=216/125\ne0$); $H=H_0+Y$ and $H^\sharp=H_0+Y^\dagger$ form a closable formal adjoint pair with single-valued minimal graph closures (reducing to a symmetric operator on the 392-mode two-sided Yukawa kernel). Under the half-density isometry, $H$ admits a unique quadratic-momentum four-time Weyl symbol generating Heisenberg equations for all 100 CCR pairs and 504 normal-ordered CAR modes.
3. **Configuration coupling identification**: the action–force coupling is the scalar-Gram-generated configuration function $4W(q)$ ($W(q)\ge1$, not an external constant). Across all four-complex momenta $p$, the actual kernel $K(p)$ satisfies slot by slot
   $$S_{\rm phys}(p)+Y=S_{\rm nat}+S_{\rm cf}+K(p)-K_{\rm ret},\tag{6.3}$$
   where the native sector $S_{\rm nat}$, coframe sector $S_{\rm cf}$, and retained kernel $K_{\rm ret}$ are determined directly from the symbol dictionary of (3.1).

**Key proof elements.** Three structural hurdles are resolved in Supplement S1: (i) proving exact commutation between the three stabilizer generators and the four-sector energy on $\mathscr U_{103}$ (Lemma S1.1); (ii) establishing the exact second-class measure cancellation $\tfrac1{256}\cdot\tfrac{256}{|\det D_9|}\cdot|\det D_9|=1$ (Eq. (S1.4)) alongside adjoint closure of coframe momentum integration by parts under weight $v^{m+2}$; and (iii) proving graph closability of $H$ and $H^\sharp$ from dense adjoint pairing $\langle f,Hg\rangle=\langle H^\sharp f,g\rangle$ (Lemma S1.2). ∎

### 6.4 All-Order Quantum Clock, Fixed Energy Remainder `R`, and Actual CAR Created State

In a first-order gravity–gauge system with four temporal constraints, neither the clock nor the high-order energy tail may drift with preparation tolerances, and scattering/polarization external states must be constructed inside $\mathscr H$ by the action itself.

**Theorem 6.8 (All-order quantum clock, fixed bounded self-adjoint remainder $R$, and common source preparation).** On the Hilbert carrier $\mathscr H$ of Theorem 6.7:

1. **All-order noncommutative clock recursion**: the $4\times4$ principal temporal Jacobian $J_4$ is invertible on the source support cone; a clock engine over 42 order-slot functions, ordered Moyal words, and 13 temporal leaves solves $C_{k+1}=-J_4^{-1}R_{k+1}$ at every order $k\ge0$, annihilating all four successor temporal forces on the closed support while preserving all lower-order slots and the 100-variable derivative budget.
2. **Complete fixed energy remainder $R$**: shifted Fourier kernels of the $k\ge2$ energy tail satisfy two-sided Schur integrability bounds, yielding via Riesz representation minus the source composition term $C_{\rm src}$ a bounded self-adjoint operator $R=E_{\rm tail}-C_{\rm src}$; for all scalar test functions $f,g$, $\langle Af,Ag\rangle+\langle f,Rg\rangle$ equals the full $B_1^2+E_{\rm tail}$ Weyl energy form, with $R$, $\mathcal T$, and $E$ strictly independent of tolerance $\varepsilon$.
3. **Common preparation and simultaneous vanishing of dual residuals**: for every $\varepsilon>0$, the shifted positive resolvent $B=(\mathcal T+1+\|R\|)^{-1}$ at spectral endpoint $E=\|B\|^{-1}-(1+\|R\|)$ produces in one source factory call a domain point $x_\varepsilon$ carrying unit background $\|v_\varepsilon\|=1$, near-spectral bound $\|\mathcal Tx_\varepsilon-Ex_\varepsilon\|<\varepsilon$, weak-form identity, native Yukawa charge $-1$, eight controlled external legs, and exponential cutoff bound $\|Y_{\rm closed}v_\varepsilon-\mathrm{cut}_n(v_\varepsilon)\|\le(915/916)^{n+1}\cdot916b$; along $\varepsilon_n=1/(n+1)$, both near-spectral and full-Yukawa residuals for the fixed triple $(\mathcal T,R,E)$ converge simultaneously to zero (Supplement S2).

Acting on the unit background $v_\epsilon$ ($\epsilon>0$) with the actual scalar–matter CAR creation channel $\mathcal A_{10}^\dagger$, the $(1,2)$ scalar coordinate satisfies $|c_{12}(z)|\ge 1/2$ inside the source box; probing from the left with the unoccupied colour annihilation mode $a_{02}$ ($\|a_{02}\|\le1$) gives $a_{02}\mathcal A_{10}^\dagger v_\epsilon=\overline{c_{12}}\,v_\epsilon$ and the explicit lower bound

$$\|v_\epsilon\|^2\;\le\;4\,\|\mathcal A_{10}^\dagger v_\epsilon\|^2.\tag{6.4}$$

**Theorem 6.9 (Same-profile nonzero CAR created unit state and joint Standard Model charge characters).** For every $\epsilon>0$, (6.4) guarantees that $g_\epsilon=(i/2)\mathcal A_{10}^\dagger v_\epsilon$ is strictly nonzero ($\|g_\epsilon\|\ge 1/4$); normalizing in Hilbert norm gives $u_\epsilon=g_\epsilon/\|g_\epsilon\|$ with $\|u_\epsilon\|=1$ over the identical configuration profile $v_\epsilon$. Moreover, for **every** Standard Model subalgebra element $a=(A_3,A_2,y_a)\in\mathfrak h_{\rm SM}$ ($y_a\in i\mathbb R$), the joint dressed variation transforming the scalar field and 504-mode matter simultaneously obeys the exact character law

$$\delta_a^{\rm joint}\mathcal A^\dagger=-y_a\,\mathcal A^\dagger,\qquad \delta_a^{\rm joint}\mathcal A=+y_a\,\mathcal A.$$

Specifically, the phase generator ($y_{\rm ph}=-i/2$) carries creation/annihilation characters $+i/2$ and $-i/2$; native hypercharge ($y_Y=i$) carries $-i$ and $+i$; and across all colour and weak generators ($y_a=0$), contragredient scalar and fermionic variations cancel identically. These character identities hold both on the dense core and on the completed preparation profile (Supplement S11.1–S11.2).

### 6.5 Complete Charge–Current Ward Identity and Unified Normalization of Twelve Temporal Directions

Having traversed $\mathbb C^8$ and $\Lambda^1\mathbb C^8$ in §6.1–§6.2, the gauge current of Example 1.1 now reveals its full many-body structure on the 504-mode CAR algebra.

**Theorem 6.10 (Complete 504-mode charge–current Ward identity).** On the carrier and common source preparation of Theorems 6.7–6.8:

1. **Decomposition into one-body and quartic pair currents**: for every quantum test state, momentum $k$, and Lie element $a$, the product of momentum action $P(k)$ and charge operator $Q_a$ decomposes identically as
   $$P(k)\,Q_a=J_{\rm sp}(k,a)+J_{\rm pair}(k,a),\qquad J_{\rm pair}(k,a)=\sum_{i,j,u,v}(P_k)_{ij}\,(Q_a)_{uv}\;c_i^\dagger c_u^\dagger a_v a_j .\tag{6.5}$$
   Here $J_{\rm sp}$ is the one-body spatial current, while the four-fermion pair current $J_{\rm pair}$ commutes with every occupation-number weight and satisfies $J_{\rm pair}=0$ identically on the one-particle sector.
2. **Two-propagator full Ward identity**: the unprojected commutator $[Q_a,H_{\rm full}]$ retains all four channels (configuration torque, one-body spatial current, quartic pair current, and Yukawa torque); finite-truncation compression defects and $Y_n-Y$ vanish along the cofinal filter limit, so the two-resolvent amplitude $\langle x,R_{\rm full}(p+k,z)Q_a R_{\rm full}(p,w)y\rangle$ equals the exact sum of analytic channels read through the eight external legs and 36 curvature ports of $x_\varepsilon$.
3. **Global temporal charge and retained-term balance**: the twelve temporal gauge directions generate a global bounded charge $Q$; along varying field curves, the $-rQ$ drifts of the bare Hamiltonian and retained kernel cancel identically, and the 106-dimensional joint orbit map yields the closed weighted momentum identity $\sum_i P_i^\dagger(c_i f)=-Q$ (Supplement S4).

Finally, the action weights of the twelve temporal gauge directions are unified by a single canonical phase inverse of the mother temporal matrix:

**Theorem 6.11 (Unified phase-inverse normalization across all twelve temporal directions and weighted creation current).** Across all twelve temporal gauge directions $a\in\{0,\ldots,11\}$, every noncharacteristic action state $s$, and every matter momentum, the first-order matrix of temporal column $f_a$ satisfies

$$B_{\rm raw}(f_a;s)=\mathsf w_t(s)C_a,\qquad M_{\rm ph}(s)\,[\mathsf a\,B_{\rm raw}(f_a;s)]=C_a,\tag{6.6}$$

where $\mathsf w_t(s)$ is the full $504\times504$ temporal weight matrix, $M_{\rm ph}(s)$ its canonical phase inverse ($M_{\rm ph}(s)[\mathsf a\mathsf w_t(s)]=I_{504}$), and $\mathsf a$ the generated action scale. Under single CAR quantization,

$$Q(C_a)=Q(M_{\rm ph})\,Q(\mathsf a B_{\rm raw})-\operatorname{Pair}(M_{\rm ph},\mathsf a B_{\rm raw}),\tag{6.7}$$

retaining the full two-body operator $\operatorname{Pair}$. Acting on the seed state $q$ with actual creation $A^\dagger$, the action-weighted charge operator satisfies

$$Q_a^{\rm raw}A^\dagger q=A^\dagger Q_a^{\rm raw}q+iA_{a,\rm sc}^\dagger q+i y_a A_{\mathsf w}^\dagger q,\tag{6.8}$$

with contragredient scalar creation $A_{a,\rm sc}^\dagger$ and action-weighted creation $A_{\mathsf w}^\dagger$: the final coefficient equals $+1/2$ for phase, $-1$ for hypercharge, and reduces purely to scalar compensation on colour and weak generators ($y_a=0$; Supplement S11.2).

---

## 7 Nonlinear Full-Field Quantum Feedback, Matrix Infrared Return, and Emergent Interactions

Section 6 completed the forward path from the common action to the 504-mode quantum current; the return half of the physical circuit lets that current **drive all 289 classical–quantum field directions** and extracts emergent spatial long-range forces, a charged colour-singlet composite positive spectrum, and four-dimensional continuum curvature operators. We organize this return into five clean stages with strictly separated domains.

### 7.1 Mother-Action Hessian Recovery of `H_289` and Varying-Field Cutoff Exchange

Field propagation is governed by a $289\times289$ matrix $H_{289}(p)$ over all $289$ real field directions and four-complex momenta $p\in\mathbb C^4$ (given by a 3071-entry polynomial dictionary over $\mathbb Q(\sqrt2,\sqrt{15})$). Our first task is to prove that $H_{289}(p)$ is no external propagator ansatz, but the **exact Fréchet second variation** of the common action (3.1) at the designated solution.

**Theorem 7.1 (Mother-action Fréchet second variation recovers $H_{289}$ and five-block Legendre readback).** Fix $S_0$, the common action (3.1), and Construction 4.1:

1. **True Fréchet Hessian and 3071-entry dictionary identity**: embedding all 289 real field directions and four spacetime gradients around Construction 4.1 (keeping $\chi$ as an independent slot), the local density is smooth with symmetric bilinear Fréchet second derivative decomposing into 1650 quadratic monomials across gravity (234), gauge (406), scalar (220), and Dirac–dual (790); for every $p\in\mathbb C^4$, combining like terms among its 3300 signed two-leg Fourier contributions reproduces the 3071-entry dictionary of $H_{289}(p)$ **entry for entry**.
2. **289-direction Euler pullback and spin-connection Legendre readback**: pulling back the nine mother residuals along all 289 unit real directions matches the holonomic Euler readings slot by slot (184 derivative-free slots have zero momentum/divergence, while 9 scalar, 24 matter, and 72 connection slots satisfy value-minus-divergence). On any nondegenerate coframe, the spin-connection quadratic form $\tfrac12\omega^{\mathsf T}\mathcal H\omega$ has an explicit two-sided inverse $K$; substituting $\Omega=-KJ$ alongside the 16 coframe momenta, 10 primary constraints, and 8 Clifford CAR normal-ordered contractions cancels $\mathrm{Number}^2$ cross-terms and recovers all five blocks of the §6.3 coframe quantum energy: kinetic, current, spin-squared, occupation shift $-\tfrac{9\,\mathrm{lapse}}{8V}\mathrm{Number}$, and volume potential (Supplement S5).

Meanwhile, along genuinely varying field curves where configuration measures, half-density ratios, and graded projections move with the field, truncated responses commute cleanly with cutoff removal:

**Theorem 7.2 (Genuinely varying field response, spectral measure, and 0/1/2-jet cutoff exchange).** On the carrier and preparation of Theorems 6.7–6.8: (1) the 106-dimensional inverse together with native, coframe, and retained sectors transports up to second derivatives of the Gauss measure $Jv^{m+2}$ and half-density ratio while preserving $\sum_g P_g P_F H_{\rm phys}P_F P_g$, generating the 289-component field response, 36 curvature readouts, first-order $-RJR$, and full second-order contact jets; (2) for $\gamma>0$, Laplace responses on a source neighbourhood admit explicit derivatives with $O(|r|^2)$ remainders; (3) for every finite frame $F$, nonreal spectral point $z$, and local field neighbourhood, because the retained term acts on a finite set at fixed $(F,p)$, **0-, 1-, and 2-jets of the literal Yukawa cutoff stabilize pointwise to the uncut operator**, so values, first derivatives, and second derivatives of prepared responses and all 36 curvature readouts commute with removing the cutoff; (4) for $H_0$, every core input $g$ generates a positive spectral measure of mass $\|g\|^2$, and bounded-insertion retarded amplitudes lie in $L^1(\mathbb R)$ in frequency with uniform inverse-Fourier convergence across all real times (Supplement S3).

![Figure 3 Complete quantum construction and full-field return](figures/vector/fig6-quantum-construction-v3-en.png)

**Figure 3｜Closed circuit from the common action to 504-mode quantization, full-field feedback, and emergent interactions.** Structural diagram (zero external parameter inputs). Top row: the common action (3.1) yields 61 CCR pairs, the 504-mode two-branch CAR, and $H=H_0+Y$ (Theorem 6.7); temporal constraint recursion generates the all-order clock, self-adjoint remainder $R$, 11-field preparation, and unit CAR created state $u_\epsilon$ (Theorems 6.8–6.9); 0-, 1-, and 2-jets commute with cutoff removal (Theorem 7.2). Middle row: the full Ward identity $P(k)Q_a=J_{\rm sp}+J_{\rm pair}$ reduces on the one-particle sector ($J_{\rm pair}=0$) to the $4\sqrt2$ pairing of §6.1–§6.2 (Theorems 6.10–6.11). Bottom row: the mother Fréchet Hessian recovers $H_{289}$ (Theorem 7.1); the nonlinear half-axis derivative yields $\Pi_{\rm st}$, returning across 289 directions via nine-constraint Schur feedback and $z^4\Pi_{\rm st}$ holomorphic infrared return (Theorems 7.3–7.7), and delivering the 192/97 electromagnetic fraction, emergent $1/(4\pi|x-y|)$ potential, charged colour-singlet three-fermion positive spectrum, and four-dimensional Schwartz curvature strong integrals preserving $\operatorname{Dom}(H_{\rm time})$ (Theorems 7.8–7.12).

### 7.2 Genuinely Nonlinear Constant-Field Noether Half-Axis Derivative and Full Half-Axis Return

To integrate nonlinear histories out to $t\to\infty$, fix an actual response event $d=(\epsilon,p,F,m,\zeta)$ and external momentum transfer $k$. From the created unit state $u_\epsilon$ and background $v_\epsilon$ of Theorem 6.9, define the difference functional

$$\ell_d(A)=-\langle u_\epsilon,A u_\epsilon\rangle+\langle v_\epsilon,A v_\epsilon\rangle,\qquad\|\ell_d\|\le 2.\tag{7.1}$$

For a constant real field perturbation $h\in\mathbb R^{289}$, with perturbed matter resolvents $R_\pm(h)$, $i$-th Noether current port $N_i(h)$, and perturbed two-leg time evolution $\mathcal T_h(t)$, define the **genuinely nonlinear constant-field Noether half-axis integral**

$$\mathcal J_d(h;\lambda)_i=\int_0^\infty e^{-\lambda t}\,\ell_d\!\left[
\mathcal T_h(t)\bigl\{R_+(h)N_i(h)R_-(h)\bigr\}\right]dt.\tag{7.2}$$

**Theorem 7.3 ($C^2$ full-field derivative of the nonlinear half-axis and nonautonomous window residual).** Fix any event $d$, transfer $k$, and Laplace parameter $\lambda$ with $\operatorname{Re}\lambda>0$. The source generates an open neighbourhood of $0\in\mathbb R^{289}$ on which (7.2) converges absolutely and defines a $C^2$ map whose Fréchet derivative along **every** real field direction $f\in\mathbb R^{289}$ equals the complete $289\times289$ static polarization matrix:

$$D_h\mathcal J_d(0;\lambda)[f]=\Pi_d^{\rm st}(k,\lambda)\,f\qquad\bigl(\text{or }\lambda\Pi_d^{\rm st}(k,\lambda)f\text{ with constant-input Laplace factor }\lambda\bigr).\tag{7.3}$$

For every $h$ in that neighbourhood, the finite-window truncation $[0,T]$ obeys the explicit exponential tail bound

$$\bigl|\mathcal J_d(h;\lambda)_i-\mathcal J_{d,T}(h;\lambda)_i\bigr|\;\le\;\frac{4}{\operatorname{Re}\lambda}\,
\|R_+(h)N_i(h)R_-(h)\|\,\mathcal B_d(\operatorname{Re}\lambda/4)\,e^{-\operatorname{Re}\lambda\,T/2},\tag{7.4}$$

where $\mathcal B_d$ is the source polynomial two-leg bound. For arbitrarily time-varying coupled nonlinear signals on the generated positive window $0\le T<\tau(d,k,P,a)$, the first amplitude derivative of the coupled quadrature residual satisfies

$$\int_0^T e^{-\lambda t}\,\partial_r\mathcal E_d(r,t)\big|_{r=0}\,dt
=\bigl[W_T(P,\lambda)H_{289}(P)-\Pi_{d,T}(P,\lambda)\bigr]a,\qquad W_T(P,\lambda)=\int_0^T e^{(P_0-\lambda)t}\,dt\tag{7.5}$$

(with $W_T=T$ at synchronous clock $\lambda=P_0$).

**Proof sketch.** Rather than linearizing naively under the integral sign, Duhamel–Gronwall exponential control identifies (7.2) on the source neighbourhood with the exact two-sided inverse $\mathcal P_\lambda(h)^{-1}[R_+(h)N_i(h)R_-(h)]$ of the perturbed two-leg propagation pencil; differentiating this smooth operator inverse at $h=0$ produces two $-RJR$ matter legs, the central Noether contact derivative, and two time-ordered pencil legs whose five-term sum reproduces $\Pi_d^{\rm st}$ column by column (Supplement S12.1). ∎

With $K_F(p)=C_F(p)+A_F$ ($C_F$ preserving $\Lambda^6$ grading and $A_F$ nilpotent at order $57$), the five-factor kernel $\mathcal K(t)=e^{itK_F(p+k)}R_{p+k}(z)J R_p(w)e^{-itK_F(p)}$ returns through the mother Green function as follows:

**Theorem 7.4 (Five-factor half-axis return, imaginary-axis spectrum, and causal feedback two-sided inverse).** In the setting of Theorems 6.7–7.2:

1. **Mother Green decomposition and positive half-axis**: on the nonempty regular domain where the 103-dimensional active determinant is nonzero, $G=\Xi(D^{-1}+P_a K_{\rm ext}^{-1})\Xi(-p)^{\mathsf T}$ satisfies $H_{289}G=I-\Xi(-p)^{-\mathsf T}P_{\rm null}\Xi(-p)^{\mathsf T}$ (retaining the nine-dimensional null projector $P_{\rm null}$). Nilpotency of $A_F$ at degree $57$ bounds time growth polynomially, so for all $\operatorname{Re}\lambda>0$ the half-axis forced response satisfies $\Xi(-\lambda)^{\mathsf T}\Phi^+=\Sigma^++B_0$ with $O(e^{-\operatorname{Re}\lambda T/2})$ finite-window convergence.
2. **Two-sided inverses and purely imaginary spectrum**: right- and left-half-plane Bochner integrals invert the two-leg pencil on both sides, confining its spectrum to $\operatorname{Re}\lambda=0$; at zero transfer the identity lies in the kernel on a nontrivial carrier, certifying $\lambda=0$ as a genuine spectral point.
3. **Nonautonomous $C^1$ histories and causal fixed point**: Picard iteration constructs nonautonomous two-leg evolution for arbitrary $C^1$ histories on $[0,T_*)$, returning through $G$ and 36 curvature ports; wherever $\det(I-\mathcal U)\ne0$, causal feedback admits a two-sided inverse and unique fixed point, with $\|\mathcal U\|\le 3/16<1$ and inverse norm $\le 16/13$ at the generated anchor $\lambda_0=3-g$ (Supplement S6).

### 7.3 Nine-Constraint Schur Equivalence and Fourth-Order Holomorphic Matrix Infrared Return

Gauge and diffeomorphism symmetries endow $H_{289}(P)$ with a nine-dimensional kernel $N(P):\mathbb C^9\to\mathbb C^{289}$ and cokernel projection $C(P)=N(-P)^{\mathsf T}:\mathbb C^{289}\to\mathbb C^9$ ($HN=0,CH=0$, $GH=I-ND,HG=I-LC,DN=CL=I_9$). Feeding quantum polarization back into the full-field equation therefore requires tracking all nine initial-value moduli alongside nine compatibility equations.

**Theorem 7.5 (If-and-only-if equivalence between full-field quantum feedback and the nine-constraint Schur equation).** Set $Q_d(P,\lambda)=(\lambda-P_0)\Pi_d^\infty(P,\lambda)$ for $\operatorname{Re}\lambda>\max(0,\operatorname{Re}P_0)$ ($\lambda\Pi_d^{\rm st}$ at $P_0=0$). On the regular domain of $G(P)$ with $\det(I-G Q_d)\ne 0$, put

$$B=I-GQ_d,\quad A=B^{-1},\quad x(c)=A(Gf+Nc),\quad S=CQ_dAN\in\mathbb C^{9\times9},\quad b=-C(f+Q_dAGf).\tag{7.6}$$

Then for **every** external source $f\in\mathbb C^{289}$ and candidate vector $x\in\mathbb C^{289}$ (with **no** invertibility assumption on the $9\times9$ matrix $S$), the full forced quantum feedback equation holds **if and only if** there exists $c\in\mathbb C^9$ solving the nine-constraint Schur system:

$$\bigl[H_{289}(P)-Q_d(P,\lambda)\bigr]x=f\quad\Longleftrightarrow\quad\exists c\in\mathbb C^9:\;x=x(c)\ \text{and}\ Sc=b.\tag{7.7}$$

Moreover, the source generates a finite-window anchor with $\|T^{-1}G_*\Pi_T\|\le 1/16$ and $\|A_T\|\le 16/15$, and on the synchronous window the derivative of $S_T(z)=C(z)\Pi_T(z)A_T(z)N(z)$ retains all four moving factors:

$$S_T'=C'\Pi_T A_TN+C\Pi_T'A_TN+C\Pi_T A_T'N+C\Pi_T A_TN',\qquad A_T'=-A_TB_T'A_T.\tag{7.8}$$

**Proof.** Forward: left-multiplying $x(c)=Nc+G(f+Q_d x(c))$ by $H_{289}$ via $HN=0$ and $HG=I-LC$ gives $[H_{289}-Q_d]x(c)=f-LC(f+Q_d x(c))$; injectivity of $L$ ($CL=I_9$) makes vanishing equivalent to $C(f+Q_d x(c))=Sc-b=0$. Converse: if $[H_{289}-Q_d]x=f$, setting $c=Dx$ and multiplying by $G$ via $GH=I-ND$ yields $(I-GQ_d)x=Gf+Nc$, i.e. $x=x(c)$, while $CH=0$ gives $C(f+Q_d x)=CHx=0$, i.e. $Sc=b$ (Supplement S13). ∎

Now examine the zero-damping infrared limit $\lambda\to 0$. Worst-case Fock degree bounds (degree 56 per leg) would severely overestimate infrared growth; however, the physical external states sit in low occupation layers—$u_\epsilon$ in the two-particle sector (at most quadratic Yukawa climb), $v_\epsilon$ in the one-particle sector (at most linear), and the left free-kernel projection kills the left climb—compressing five-factor time growth to **cubic** order.

**Theorem 7.6 (Occupation-graded cubic time bound and full-matrix $z^4\Pi_{\rm st}$ holomorphic infrared return).** For every fixed event $d$, matter parameters $(p,F)$, and zero external momentum transfer $k=0$, the source generates nonnegative matrix bounds $K_{ij}(d)\ge0$ such that $|\mathscr D_{ij}(t)|\le K_{ij}(d)(1+|t|)^3$ for all $t\in\mathbb R$, implying across all $0<\sigma\le 1$ and all $289\times289$ entries

$$\sigma^4\,\bigl|\Pi_d^{\rm st}(0,\sigma)_{ij}\bigr|\;\le\;56\,K_{ij}(d).\tag{7.9}$$

Furthermore, using the minimal polynomial $p_d(z)=z^{m_d}d_d(z)$ ($d_d(0)\ne0$) of the two-leg generator to form $R_d(z)=z^{2m_d}\Pi_d^{\rm st}(0,z)$—holomorphic near $z=0$—the real-axis quartic bound (7.9) forces vanishing order at least $\max(0,2m_d-4)$ at $z=0$. Consequently, across **every** pole-order branch $m_d\in\mathbb N$, the source constructs a holomorphic $289\times289$ matrix function $G_{4,d}(z)$ around $0$ satisfying on the punctured right-half-plane neighbourhood

$$z^4\,\Pi_d^{\rm st}(0,z)=G_{4,d}(z).\tag{7.10}$$

Hence both complex limits ($\operatorname{Re}z>0,z\to0$) and real limits ($\sigma\downarrow0$) return uniformly to the finite full matrix $G_{4,d}(0)$, while sextic weighting vanishes:

$$z^6\,\Pi_d^{\rm st}(0,z)\;\longrightarrow\;0\qquad(z\to 0,\ \operatorname{Re}z>0).\tag{7.11}$$

**Proof.** When $2m_d\ge4$, if $R_d(z)$ vanished to order $n<2m_d-4$, writing $R_d(z)=z^n g(z)$ ($g(0)\ne0$) would give $\|g(s)\|\le C_d s^{2m_d-4-n}\to 0$ as $s\downarrow0$ by (7.9), contradicting continuity of $g$ with $g(0)\ne0$. Factoring out $z^{2m_d-4}$ yields holomorphic $G_{4,d}(z)$ (for $2m_d<4$, set $G_{4,d}(z)=z^{4-2m_d}R_d(z)$; Supplement S12.4). ∎

![Figure 4 Regular feedback domain versus zero-transfer analytic infrared domain](figures/vector/fig7-two-domains-v3-en.png)

**Figure 4｜Two distinct source-generated domains and return mechanisms (Theorems 7.3, 7.5, 7.6, 7.8).** Fixed original action, actual event $d$, and prepared/created states. Branch A (left): the genuinely nonlinear constant-field Noether half-axis is $C^2$ for $\operatorname{Re}\lambda>0$ with full-field derivative $\Pi_{\rm st}$; on the linearized clock-safe regular domain $\operatorname{Re}\lambda>\gamma_{\rm clk},\det(I-GQ_d)\ne0$, full-field feedback is equivalent to the original response plus $Sc=b$. Branch B (right): at zero transfer, graded cubic time bounds and the minimal polynomial yield $z^4\Pi_{\rm st}(0,z)=G_{4,d}(z)\to G_{4,d}(0)$ and $z^6\Pi_{\rm st}\to0$; along unit spatial directions, 192/97 elimination and electromagnetic Ward cancellation further deliver a bivariate rational fraction on a joint cone. Neither domain substitutes for the other.

### 7.4 Static Poles, 192/97 In-Source Schur Fraction, and Emergent $1/(4\pi|x-y|)$ Long-Range Kernel

Opening nonzero momentum transfer ($k\ne 0$) exposes the static and long-range spatial geometry induced by the quantum current.

**Theorem 7.7 (Common moving carrier, momentum continuity, and native static residue).** In the setting of Theorem 7.4: (1) the overlap $U(p)$ between positive/negative chiral eight-state bases at three-momentum $p$ and rest is unitary, with $M(p_L,p_R)[A]=U(p_L)^\dagger M(0,0)[A]U(p_R)$; (2) $C_F(p)=C_F(0)+v_F(p)$ is real-affine in $p$ with momentum-invariant retained set, giving uniform continuity of two-leg resolvents, evolutions, and 289-dimensional windows in $(p_L,p_R)$; (3) along $(0,i\kappa,0,0)$ on the punctured static domain, the uncleared 289-dimensional mother Green splits into contact terms, a $(-\kappa^2)^{-1}$ five-direction native Schur pole, and a 98-dimensional regular complement; the static residue of the window-driven field is $-\kappa^2\varphi(\kappa)\to E_0\bigl(-\tfrac{9}{125}\sqrt{30}\mathfrak w,-\tfrac{67}{72}\sqrt{30}\mathfrak w,0,0,0\bigr)$, where $\mathfrak w=\tfrac{3\sqrt2}{10}(J_{21}-J_{34})=-c_{114}(0,T)=\kappa_{\rm ct}-\delta_{\rm cf}$ is minus the 114th colour-constraint cosource, $|\mathfrak w-\kappa_{\rm ct}|\le\|D_0F\||T|/(|\operatorname{Im}z||\operatorname{Im}w|)$, and $H_{289}\varphi=w_{\rm win}$ holds iff all nine null cosources vanish (Supplement S7).

Moreover, over the bivariate polynomial ring $(\mathbb C[\varepsilon])[X]$ along a unit spatial direction $n$ ($|n|^2=1$) with scale $0<\varepsilon\le 1/2$ and clock variable $X\mapsto\sigma>0$, exact algebraic elimination compresses the $289\times289$ coupled pencil into 97 active directions with **exact electromagnetic Ward clock-factor cancellation**:

**Theorem 7.8 (192/97 in-source Schur reduction, electromagnetic Ward clock cancellation, and bivariate joint cone).** Fix a dressed event $d$ and unit spatial direction $n$ ($|n|^2=1$):

1. **192-dimensional inactive two-sided inverse and 97-dimensional fraction**: on $0<\varepsilon\le 1/2$, the 192 inactive field directions admit an explicit polynomial two-sided inverse; retaining all $97\leftrightarrow 192$ quantum cross-columns reduces the full system equivalently to a 97-dimensional Schur complement $S_{97}$ ($\det_{\rm corr}\ne0\iff\det S_{97}\ne0$) and uniquely reconstructs all 192 inactive components. Clearing denominator $d_{\rm nat}$ produces $Q_{97}\in M_{97}((\mathbb C[\varepsilon])[X])$ such that $\varepsilon^4 T_{00}(\varepsilon,\sigma)=\mathrm{eval}_{\varepsilon,\sigma}(N_{97})/\mathrm{eval}_{\varepsilon,\sigma}(\det Q_{97})$ at every regular point.
2. **Exact cancellation of Ward $X^2$ against Noether $X^3$**: the physical electromagnetic temporal forcing vector $E_A$ equals $-1/2$ at the 15th active pivot and vanishes across all 192 inactive slots; combined with inactive right reconstruction, $Q_{97}$ obeys the polynomial row identity
   $$E_A^{\mathsf T}\,Q_{97}=X^2\,R_{97}^{\mathsf T}.\tag{7.12}$$
   Elementary row replacement on row 15 yields $\det Q_{97}=X^2\,D_{\rm W}$, while the auxiliary clock column yields $N_{97}=X^3\,N_{\rm W}$. At every point with $\sigma>0$, $0<\varepsilon\le 1/2$, and $\det_{\rm corr}\ne0$, the quadratic clock factor cancels identically:
   $$\varepsilon^4\,T_{00}(\varepsilon,\sigma)=\sigma\,\frac{\mathrm{eval}_{\varepsilon,\sigma}(N_{\rm W})}{\mathrm{eval}_{\varepsilon,\sigma}(D_{\rm W})},\tag{7.13}$$
   with exact trailing-degree shifts $\operatorname{ord}_X(N_{97})=3+\operatorname{ord}_X(N_{\rm W})$ and $\operatorname{ord}_X(\det Q_{97})=2+\operatorname{ord}_X(D_{\rm W})$ whenever nonzero.
3. **Single-seed bivariate regular joint cone**: set $A=N_{97}$ and $B=\det Q_{97}$; for each $P\in\{A,B\}$, factor its $X$-trailing order $k_P=\operatorname{ord}_X(P)$ to extract the leading spatial coefficient $p_0(\varepsilon)=\varepsilon^{\ell_P}(c_P+\varepsilon\tilde p(\varepsilon))$ (with $k_P=\ell_P=0,c_P=0$ when $P=0$). Given one regular seed $(\varepsilon_0,\sigma_0)$ with $0<\varepsilon_0\le 1/2,\sigma_0>0$ and $\det_{\rm corr}(\varepsilon_0,\sigma_0)\ne0$, one has $B\ne0$ and $c_B\ne0$; define the spatial rescaling weight $w_{\rm sp}(\varepsilon)=\varepsilon^{\ell_B-\ell_A}$ and the explicit nonnegative slope constant $S_{\rm ratio}\ge0$ from the coefficient-modulus sums of $\tilde a,\tilde b$ on $[0,1/2]$ (explicit formula in Supplement S17.3). The bivariate polynomial supports then explicitly construct $\rho_{\rm sp}>0$ and $\rho_{\rm clk}(\varepsilon)>0$ ($\forall 0<\varepsilon\le\rho_{\rm sp}$) on whose joint cone $\{(\varepsilon,\sigma):0<\varepsilon\le\rho_{\rm sp},\,0<\sigma\le\rho_{\rm clk}(\varepsilon)\}$ one has $\det_{\rm corr}(\varepsilon,\sigma)\ne0$ everywhere alongside the uniform linear error bound against $c_A/c_B$:
   $$\Bigl\|w_{\rm sp}(\varepsilon)\,\sigma^{\operatorname{ord}_X(\det Q_{97})-\operatorname{ord}_X(N_{97})}\,\varepsilon^4 T_{00}(\varepsilon,\sigma)-\frac{c_A}{c_B}\Bigr\|\;\le\;\bigl(1+S_{\rm ratio}\bigr)\,\varepsilon.\tag{7.14}$$

**Proof.** Block multiplication $E_A^{\mathsf T}(d_{\rm nat}P_{AA}-P_{AI}N_{\rm inv}P_{IA})$ extracts the common $X^2$ factor in (7.12); replacing row 15 via pivot $(E_A)_{15}=-1/2$ gives $(-1/2)\det Q_{97}=X^2\det(\mathrm{updateRow}_{15}Q_{97})$, multiplying by $-2$ to prove $X^2\mid\det Q_{97}$. Joint-cone radii and the two-step triangle inequality for (7.14) are proved in Supplement S17.1–S17.3. ∎

Replacing native colour insertion by the literal **physical electromagnetic insertion $E$** of the same density and pairing two uncut moving quantum currents across the 289-dimensional mother Green function yields the classical $1/(4\pi r)$ potential in three-dimensional space:

**Theorem 7.9 (Same-density physical electromagnetic residue, 72 gauge curvatures, and emergent $1/(4\pi|x-y|)$ spatial kernel).**

1. **Frequency-pole idempotence and 72-curvature readback**: for the physical electromagnetic contraction $E^{\mathsf T}GE$ of the Theorem 7.1 Hessian, the residue $R_\omega=\lim_{\omega\to\omega_*}(\omega-\omega_*)G(\omega)$ at the simple pole $\omega_*$ satisfies the scale-invariant idempotence law
   $$R_\omega\,K'(\omega_*)\,R_\omega=R_\omega\qquad\bigl(\text{invariant under }t'=ct,\ c>0\bigr).\tag{7.15}$$
   Classical window forcing vanishes at the pole, leaving the connected created-minus-background residue $R_\omega J_d$ read out continuously across all $6\times12=72$ gauge curvature components including $[\bar A_\mu,a_\nu]$.
2. **Emergent $1/(4\pi|x-y|)$ Coulomb/Newton kernel between moving quantum currents**: for any two independent actual events $d_D,d_S$ with uncut currents $J_D^{\rm uncut},J_S^{\rm uncut}$ (Theorem 7.2) paired across the full 289-dimensional mother Green on $0<a|k|<\rho_{DS}$ ($k=2\pi\xi$) and any Schwartz test function $\phi\in\mathcal S(\mathbb R^3)$, the scale limit $a\downarrow 0$ converges to
   $$\lim_{a\downarrow 0}\int_{\mathbb R^3} e^{2\pi i\xi\cdot x}\,\phi(\xi)\,
   J_D^{\rm uncut}(-ak)^{\mathsf T}\,a^2 G(0,iak)\,J_S^{\rm uncut}(ak)\,d\xi
   \;=\;\mathcal N_\phi(x)\,C_{DS},\tag{7.16}$$
   where the spatial potential convolution and static five-channel coupling constant ($S_{\rm st}$ denoting the five-direction native static block of Theorem 7.7(3)) are
   $$\mathcal N_\phi(x)=\int_{\mathbb R^3}\frac{(\mathcal F^{-1}\phi)(x-y)}{4\pi|y|}\,dy,\qquad
   C_{DS}=-\bigl(J_D^{(5)}(0)\bigr)^{\mathsf T}S_{\rm st}^{-1}J_S^{(5)}(0).\tag{7.17}$$
   On the normalized three-fermion charged states of §7.5 (with at least one formal-adjoint ($H^\sharp$) external leg at both source and detector), the multi-body Born dressing factor equals the four-leg overlap product $Z=\prod_{j=1}^4 z_j\in(0,1]$ over base constant $9/125+67/72=9023/9000$ (Supplement S11.3–S11.6).

### 7.5 Charged Colour-Singlet Spin-`1/2` Three-Fermion Positive Spectrum and 4D Curvature Strong Integration

Can the 504-mode mother CAR algebra generate—without external hadron models—a composite multi-fermion state carrying realistic baryon/lepton quantum numbers (colour singlet, integer charge $\pm1$, spin $1/2$) with strictly positive dynamic spectral density, while the ten-stage total closure $\mathcal U_{1\text{--}10}$ generates continuum non-Abelian curvature operators preserving the self-adjoint time-generator domain $\operatorname{Dom}(H_{\rm time})$ on $\mathbb R^4$? Our final three theorems of §7 close both questions affirmatively.

**Theorem 7.10 (Composite-clock matched whole-word budget and renormalized second-Green $L^1(\mathbb R)$ common tail).** On the native generator $H_0=C_F+d_F$ with composite source clock $\varphi$ and damping $\sigma=\mu>0$: (1) matched column $C_3=UD+3iD_cU$ and literal retarded word $R_3$ satisfy $J_3\ge\tfrac{3N}{8}\|C_3w\|^2+\tfrac{5N}{2}\mathsf{sc}(Uw)+10N\mathrm{sh}_{40}(w)+\tfrac{3N}{4}\mathsf{cf}(Uw)+18N\|w\|^2$; (2) for every $\varepsilon>0,\mu>0$, seeds $g,k$, and both generator branches $(H,H^\sharp)$, there exists $N_0$ prior to $m,\ell$ and cofinal $F$ such that $C_{\rm J}\le\varepsilon+48M_\mu(k)P_\rho\frac{\mu}{20N}\int R_3^+$; (3) the pole-subtracted renormalized second-Green endpoint $\mathcal E=\operatorname{Re}\langle k,(H_0-\operatorname{Re}z)Aw\rangle-\|k\|^2\operatorname{Re}(1/z)$ has a **common whole-line $L^1(\mathbb R)$ vanishing tail** across both forward and retarded causal ports: $\int_{\mathbb R}|\mathcal E(\omega)|\,d\omega\le\varepsilon$ for all $m\ge N_0,\ell\ge m$ and cofinal $F$, with $R_3=\mathcal E/\sigma^2-D_{\rm ren}/(2\sigma^2)+R_{\rm df}$ ($L(1)=0,L(V)=18$, positive-semidefinite noise kernel; Supplement S8).

Now on each branch $d\in\{0,1\}$ of the 504-mode CAR algebra, couple two colour–hypercharge wedges to one colour–weak wedge via $\epsilon_{abc}$ to form $q_d^{(3)}=\tfrac13[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)]$: Kronecker determinants give $\|q_d^{(3)}\|^2=(6+12)/9=2$, so $q_d^{(3)}/\sqrt2$ has **unit norm, exact $\mathfrak{su}(3)$ colour-singlet invariance ($\operatorname{tr}A=0$), literal electric charge $(-1)^d=\pm1$, and Dirac spin-squared eigenvalue $\mathsf S^2=\tfrac34$ (spin $1/2$)**, with $Yq_d^{(3)}\ne0$. Summing the Contact ($\mathcal B_0$), 79-dim canonical ($\mathcal B_1$), 24-dim independent-dual ($\mathcal B_2$), and 61-dim scalar ($\mathcal B_3$) channels **coherently** into $\mathcal B=\sum_{b=0}^3\mathcal B_b$ before taking the squared norm defines the spectral measure

$$d\nu(\omega)=\|\mathcal B r_F(\omega)\|^2\,d\omega
=\operatorname{Re}\sum_{a,b=0}^3\langle\mathcal B_a r_F(\omega),\,\mathcal B_b r_F(\omega)\rangle\,d\omega.\tag{7.18}$$

**Theorem 7.11 (Common real-transfer positive spectrum and exact neutral zero channel for the charged colour-singlet spin-`1/2` three-fermion state).** Fix the source-generated punctured radius $\delta>0$ and smooth compactly supported profile $f$ ($f(z_*)=1$) **prior to** both dual branches, all finite frames $F$, both generator branches $(H,H^\sharp)$, both causal ports, and all $\mu>0$. For every nonzero real transfer $0<|x|<\delta$ at four-transfer $(x,0,0,0)$ and rest matter momenta:

1. **Strictly positive total spectrum, causal time mass, and Yukawa excess**: all 17 propagator denominators are pole-free on $0<|x|<\delta$, the coherent four-channel amplitude is nonzero on both branches, and the dynamic response has finite strictly positive spectral mass, high-frequency density, and causal time mass obeying Parseval's identity
   $$\nu(\mathbb R)=2\pi\int_{\mathbb R}\|\mathcal B w_F(t)\|^2\,dt\;>\;0,\tag{7.19}$$
   while the unforced integrated Yukawa excess $\int_{\mathbb R}\|\mathrm{corr}_{Y,F}(\omega)\|^2d\omega>0$ is strictly positive across all $(F,c,\mu>0)$ (with the two-resolvent Sylvester identity and signed pressure–scalar energy balance of $C_F$ closed alongside).
2. **Exact whole-frequency and whole-time neutral zero channel**: because $\mathcal B$ commutes coefficientwise with signed occupation $Q_s$ while $q_d^{(3)}$ carries definite signed occupation $\pm3$, every net-neutral projected state on the cofinal saturated carrier produces **identically zero** output at every real frequency, real time, and Borel band (Supplement S14).

**Proof sketch.** At the purely imaginary anchor $x=i$, the coherent sum of the four channels evaluates to $\sqrt{30}\times\frac{1502925864947895702084635234454041}{3859115104366170163070540928506250}\ne0$. By the identity theorem for meromorphic functions across the 33 numerators and 17 denominators, a common pole- and zero-free punctured real interval $0<|x|<\delta$ exists, where high-frequency asymptotics $z\mathcal B r_F(z)\to-\mathcal B(q_d^{(3)}f)\ne0$ forces strict positivity (Supplement S14.1–S14.3). ∎

Finally, in contrast to continuum gauge reconstructions relying on lattice discretization [6] or Euclidean Green-function analytic-continuation axioms [27], perturbing the Standard Model connection $A_{\rm cl}$ of the ten-stage total closure $\mathcal U_{1\text{--}10}$ by an arbitrary compactly supported smooth $1$-form $A_{\rm cl}+t\eta$ ($\eta\in C_c^\infty(\mathbb R^4,\Omega^1(\mathfrak h_{\rm SM}))$, $t\in\mathbb R$)—and denoting by $H_{\rm time}$ the self-adjoint generator of the strongly continuous unitary clock group $U_{\rm time}(s)=e^{-isH_{\rm time}}$ on the 252-dimensional matter response space and common carrier $\mathcal H_{\rm com}$ (strictly distinct from the nonsymmetric 504-mode CAR generator $H=H_0+Y$ of §6.3)—constructs continuum quantum curvature operators preserving $\operatorname{Dom}(H_{\rm time})$ directly in real Lorentzian time:

**Theorem 7.12 (Four-dimensional curvature strong integration and $\operatorname{Dom}(H_{\rm time})$ word Gram for compactly supported gauge variations of the total closure).** For every $\eta\in C_c^\infty(\mathbb R^4,\Omega^1(\mathfrak h_{\rm SM}))$ on $\mathcal U_{1\text{--}10}$, amplitude $t\in\mathbb R$, same-point ordered curvature polynomial $P$, and Schwartz test function $f\in\mathcal S(\mathbb R^4)$:

1. **4D strong integration, time covariance, and $\operatorname{Dom}(H_{\rm time})$ preservation**: exact quadratic curvature variations generate a bounded strongly continuous operator seed on spatial projection $\pi_{\rm sp}(p)=p-(p_0,0,0,0)$, whose unitary time-group conjugate integral defines the bounded operator
   $$\Phi_{\eta,t,P}(f)v=\int_{\mathbb R^4} f(p)\,U_{\rm time}(-p_0)\,\mathrm{seed}_{\eta,t,P}\bigl(\pi_{\rm sp}(p)\bigr)\,U_{\rm time}(p_0)v\,dp,\tag{7.20}$$
   continuous and linear in $f$, obeying $U_{\rm time}(s)\Phi_{\eta,t,P}(f)v=\Phi_{\eta,t,P}(\tau_s f)U_{\rm time}(s)v$ and $\frac{d}{ds}\big|_{s=0}\bigl(U_{\rm time}(s)\Phi_{\eta,t,P}(f)U_{\rm time}(-s)\bigr)=\Phi_{\eta,t,P}(\partial_0 f)$; consequently every $\Phi_{\eta,t,P}(f)$ and every finite mixed word $W(w)=\prod_{\ell}\Phi_{l_\ell}$ preserves $\operatorname{Dom}(H_{\rm time})$, reducing at $t=0$ to the origin-embedded curvature word $\Phi_{\eta,0,P}(f)=\Phi_{\rm orig}(\iota_0(P),f)$.
2. **Common-carrier realization and positive-semidefinite word Gram**: pulled back via surjective isometry to $\mathcal H_{\rm com}$, all finite mixed curvature words act compatibly on the prepared state $\psi_{\rm com}(x)$ and yield via Theorem 6.2 the Hermitian positive-semidefinite matrix $\mathrm{Gram}_x(w_i,w_j)=\langle W(w_i)\psi_{\rm prep}(x),W(w_j)\psi_{\rm prep}(x)\rangle$ (Supplement S17.4).

---

## 8 All-Time Nonlinear Orbits and Parameter-Free Analytic Predictions

### 8.1 All-Real-Time Gauge–Dirac Coupled Orbits and Legendre Energy Recovery from Quantum Derivatives

Holding the coframe and spin-connection geometry of Construction 4.1 fixed, release the gauge amplitude $r(t)$, conjugate momentum $p(t)$, and matter phase angle $\theta(t)$ to evolve nonlinearly under the coupled equations of the common action.

**Theorem 8.1 (Unique all-real-time nonlinear gauge–Dirac orbit).** On $\mathbb R^3=\{(r,p,\theta)\}$, for **every** real initial impulse $p_0\in\mathbb R$, there exists a unique smooth global orbit defined on the entire real time axis $t\in\mathbb R$ with initial state $(a,p_0,0)$ satisfying at all times

$$\dot r=\frac{p}{m},\qquad \dot p=-V'(r),\qquad \dot\theta=\frac{3N}{2}\,(k-r),\qquad
V(r)=\frac{3}{4\sigma N}\,r^4-6Nk\,r,\quad m=\frac{3N}{2\sigma}=3N .$$

At every point along the orbit, the background gauge Euler $3$-form together with both primal and adjoint matter Euler residuals vanish identically; total energy $E=p^2/(2m)+V(r)$ is conserved, bounding $p(t)^2\le p_0^2$ and $5N(r(t)-a)^2\le p_0^2/(2m)$ uniformly; and whenever $p_0\ne0$, the quintic gauge helicity invariant $Q(t)=3r(t)^5$ has nonzero initial velocity $\dot Q(0)=15a^4 p_0/m\ne0$.

**Proof.** Using $a^3=2\sigma N^2k=N^2k$ ($V'(a)=0$), complete the relative potential without approximation: $V(r)-V(a)=5N(r-a)^2+\frac{3}{2N}(r-a)^2(r+a)^2\ge 5N(r-a)^2$. Energy conservation $E-V(a)=p_0^2/(2m)$ confines $(r(t),p(t))$ a priori to a compact ball, ruling out finite-time blowup; solving a smoothly cut-off vector field globally and verifying that the trajectory remains inside the cutoff-one ball yields global existence and uniqueness on $\mathbb R$. ∎

Conversely, without any external classical meter measuring $r(t)$ or $p(t)$, reading the time derivative of the 252-dimensional quantum matter state along the orbit reconstructs the classical phase-space trajectory and quartic Legendre energy losslessly:

**Theorem 8.2 (Exact recovery of nonlinear orbits and Legendre energy from quantum time derivatives).** For every $p_0\in\mathbb R$, its global orbit, and every $t\in\mathbb R$, let $z_t=\tfrac12\mathrm{naturalCoordinates}(\psi_{\rm orbit}(t))\in\mathbb C^{252}$ ($\|z_t\|=1$) and $\mathsf V=\operatorname{diag}(i\omega,i\omega,-i\omega,-i\omega)\otimes I_{63}$. From the quantum spinor rate readout

$$q(t)=\frac{\operatorname{Re}\langle \mathsf Vz_t,\,z_t'\rangle}{\omega},$$

one recovers identically $r(t)=k-\frac{2}{3N}q(t)$ and $p(t)=-\frac{2m}{3N}q'(t)$, and the relative Legendre energy equals

$$E_{\mathrm{Legendre}}=\frac{p(t)^2}{2m}+c\,(r(t)-a)^2+\frac{3\,(r(t)-a)^2(r(t)+a)^2}{4\sigma N},\qquad c=\frac{3a^2}{2\sigma N}=5N ,$$

where $m=3N$, $c=5N$, and $3/(4\sigma N)=3/(2N)$ are all generated directly by the fixed source, with the nonnegative quartic term contributing $2c(r-a)^2+O((r-a)^3)$ near equilibrium (total harmonic stiffness $3c=15N$).

**Proof.** Differentiating along the orbit gives $z_t'=\frac{3N(k-r(t))}{2\omega}\mathsf Vz_t$; using $\|\mathsf Vz_t\|^2=\omega^2$ yields $q(t)=\frac{3N}{2}(k-r(t))$, differentiating again via $\dot r=p/m$ recovers $p(t)$, and substituting into $V(r)-V(a)$ gives $E_{\mathrm{Legendre}}$. ∎

![Figure 5 All-real-time orbits and Legendre relative energy](figures/vector/fig4-global-orbit-energy-en.png)

**Figure 5｜All-real-time coupled phase-plane contours and quartic coercive potential decomposition.** Plotted directly from the exact analytic expressions of Theorems 8.1–8.2 with zero fitted parameters. Left: closed global phase orbits $p=\pm\sqrt{2m(E_{\mathrm{rel}}-[V(r)-V(a)])}$ for $p_0=0.6,1.2,1.8,2.4$, with vertical dotted lines marking exact turning radii at $p_0=1.2$ and $2.4$. Right: full potential difference $V(r)-V(a)$, global quadratic coercive lower bound $c(r-a)^2$, and nonnegative quartic piece $3(r-a)^2(r+a)^2/(2N)$, aligned horizontally with the turning radii on the left.

### 8.2 Five-Point Coherence Law and Zero-Input Bilateral Bell Probability Family

**Theorem 8.3 (All-time coherence law and parameter-free five-point locking).** On the fixed positive source and actual configuration: (1) the single-arm interferometric coherence reading at every spacetime point equals $\cos^2(\omega x^0)$ with $\omega^2=972/3125$; (2) at the first dark time $t^*=\pi/(2\omega)$ it vanishes identically (destructive amplitude cancellation, not pure-state decoherence) and revives to $1$ at $2t^*$; (3) across the five dimensionless ticks $u=t/t^*=0,\tfrac12,1,\tfrac32,2$, both the current and next runtime ticks lock onto $(1,\tfrac12,0,\tfrac12,1)$, whereas the classical exclusive-path benchmark stays identically at $\tfrac12$ (Table 3, Figure 6), excluding exclusive-path models inside the total closure.

**Table 3 Source-generated coherence readings versus the exclusive-path benchmark across five dimensionless ticks.**

| $u=t/t^*$ | $0$ | $1/2$ | $1$ | $3/2$ | $2$ |
| --- | :---: | :---: | :---: | :---: | :---: |
| Source-generated coherence weight $\cos^2(u\pi/2)$ | $1$ | $1/2$ | $0$ | $1/2$ | $1$ |
| Classical exclusive-path benchmark | $1/2$ | $1/2$ | $1/2$ | $1/2$ | $1/2$ |

![Figure 6 Five-point coherence readings and designated exclusive-path comparison](figures/vector/fig3-five-point-quantum-clock-en.png)

**Figure 6｜Coherence extinction and revival across five dimensionless ticks.** Horizontal axis $u=t/t^*$; solid curve $\cos^2(u\pi/2)$, dashed line exclusive-path constant $1/2$, background luminance linearly encoding the same coherence weight. Bottom row: five unit circles aligned with the ticks display upper/lower spinor amplitudes $e^{\pm i\theta}$ and their coherent real mean $\cos\theta$ (vermilion bar, whose squared length is the reading above): extinction at $u=1$ arises from exact antipodal cancellation, enabling lossless revival to $1$ at $u=2$.

**Proposition 8.4 (Zero-empirical-input bilateral Bell probability family and deterministic $\Phi^+$ preparation).** On the fixed source and actual configuration, at every spacetime point, for arbitrary unit XZ measurement axes $a=(a_x,a_z),b=(b_x,b_z)$ and Boolean outcomes $x,y\in\{\text{true},\text{false}\}$ (signs $\pm1$), the bilateral Born probability at both current and next ticks equals

$$P(a,b;x,y)=\frac{1-\,\mathrm{sign}(x)\,\mathrm{sign}(y)\,\big(a_xb_x+a_zb_z\big)}{4},$$

with uniform marginals $1/2$ and normalized nonnegative outcomes. Applying the fixed colour-$Z$ gate followed by colour-$X$ swap deterministically (with zero postselection) prepares $\Phi^+$ with joint $(+,+)$ probability $(1+a_xb_x+a_zb_z)/4$ and correlator $E(a,b)=a_xb_x+a_zb_z$, attaining the quantum Tsirelson bound $2\sqrt2$ on orthogonal and bisecting axes with zero empirical or device parameters (Proposition 10.2(1)).

---

## 9 Ten-Stage Physical Root Seal, Zero Unregistered Authority, and Universal Formation from the Same Mother Source

One fixed source datum has now generated geometry, the unique nine-field solution, postulate-free 504-mode quantum dynamics, full-field infrared return, and bilateral Bell correlations. We now establish the root seal and foundational boundary theorems governing the entire theory: **how is this continuous–quantum unified structure anchored onto the zero-axiom occurrence and whole-ledger kernel, can any off-ledger knob or silently absorbed residual enter mid-evolution, and would varying source parameters—or confronting an arbitrary admitted world state, complete inquiry system, or evolving process—ever require opening a second underlying source?**

### 9.1 Realization Across the Smooth Unified Source Family, Ordered Paths, and Autonomous Programmes

Release all seven fields of $S_0$ to range over the entire 65-dimensional continuous-plus-discrete **smooth unified source family**.

**Theorem 9.1 (Nine-field realization and Classical World Acceptance criterion across arbitrary smooth unified sources).** The identical generation mechanism constructs for **every** smooth unified source $s$ its own nine-field configuration $\mathcal C(s)$ satisfying smoothness, global coframe nondegeneracy, Lorentz admissibility, the nine-channel zero fibre, and scalar origin contact for $s$; moreover, $\mathcal C(s)$ satisfies six-sector-nonzero Classical World Acceptance **if and only if** the integer phase amplitude of $s$ is nonzero. Across every centre point, finite write generation, spacetime point, and $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$, full source writes, nine-field balance, relative-action invariance, and normalized quantum response hold jointly in a single statement, specializing at $S_0$ to Construction 4.1.

**Proof.** From the scale and phase parameters of $s$, construct the homogeneous diagonal tetrad, constitutive auxiliary solution, and Cartan torsion write, checking all nine residuals channel by channel. Since both the broken scalar vacuum and exterior Yukawa map scale linearly with the integer phase amplitude of $s$, simultaneous nonvanishing of the six sectors is equivalent to nonvanishing of that integer amplitude (zero-amplitude members remain smooth nondegenerate solutions on the zero-amplitude branch). ∎

**Theorem 9.2 (Arbitrary finite source paths and autonomous rational programmes on the same mother history).** On the fixed mother occurrence history:

1. **Arbitrary finite continuous source paths**: for every finite target sequence $\{(s_k,r_k)\}_{k=1}^m$ (each carrying a smooth unified source $s_k$ and all $195=65\times3$ real spatial remainders), there exists a lawful finite complete-event path on the **same original mother history** realizing the targets in order as an exact subsequence of post-state readouts while preserving full event recovery, native history, and physical presence at every intermediate step;
2. **Autonomous rational programme execution**: for every finite rational programme list (discrete material plus $260=65\times4$ rational coordinates per entry), a single autonomous round chosen prior to all physical queries forms and executes the entire list, preserving every word, coordinate, strictly earlier parent pair, and birth-site physical action (moreover, geometric $2^{-(n+1)}$ folding across the 65 continuous slots converges at explicit tail rate $\le 2^{-n}$ to deliver full classical–quantum admission; Appendices C.3–C.4).

### 9.2 The Stage 1–10 Closure Seal, Five-Position Whole-Spacetime Assembly, and Zero Unregistered Physical Authority

Having verified smooth transport across the source family, we seal the entire Stage 1–10 generative chain inside the five-position historical root closure $\mathcal C_{\rm root}^{(0)}$, the Stage 10 physical root seal $\mathcal C_{\rm seal}=\mathcal U_{1\text{--}10}.\mathsf{final}$ (carrying $\mathcal C_{\rm root}^{(0)}$ together with Stage 9's unified credential and authority receipt), and the end-to-end ten-stage closure $\mathcal U_{1\text{--}10}$ (where Stages 1–3 fix non-vacuity and constitutive entry gates via vacuity counterexamples, metric/Hodge variational interfaces, and internal–geometry dual-axis projections, while the geometry, nonseparable coupling, $\mathfrak h_{\rm SM}$ spectral selection, anomaly cancellation, and mass/mixing of Stages 4–8 enter the same total object without promoting any retired gate; formal module and declaration correspondences appear in Appendices C.8 and D.9). The following theorem proves that physical evolution seals off unregistered authority across whole-spacetime assembly, causal whole-ledger accounting, premise folding, and complete descriptions.

**Theorem 9.3 (Five-position whole-spacetime assembly, zero unregistered physical authority, complete premise fold, and Stage 1–10 recovery).** On the five-position historical root closure $\mathcal C_{\rm root}^{(0)}$, Stage 10 physical root seal $\mathcal C_{\rm seal}$, and ten-stage closure $\mathcal U_{1\text{--}10}$:

1. **Five-position physical root history, whole-spacetime operator, and post-Yang–Mills four-open-coordinate assembly criterion**: the fixed positive source generates a five-position physical root history $\mathsf{Pos}=\{\mathsf{boundary},\mathsf{coface},\mathsf{gravity},\mathsf{assembly},\mathsf{postAssembly}\}$ in which every exact temporal causal root event equals the fixed compiler's native image and $\mathcal C_{\rm root}^{(0)}$ is unique in its type (embedded as the historical foundation of $\mathcal C_{\rm seal}$). At the fourth position $\mathsf{assembly}$, smoothness, coframe nondegeneracy, and all three algebraic constitutive residual sections (gravitational simplicity multiplier, gravitational auxiliary field, and gauge auxiliary field) vanish identically across spacetime as consequences of the sealed trace; the source-generated whole-spacetime operator $\mathcal W_{\rm ws}$ writes the complete assembly residual into $\mathsf{postAssembly}$ with definitional reverse faithfulness. The registered action jet remains contact-unchanged across spacetime **if and only if** the four open differential residual coordinates vanish pointwise across $\mathbb R^4$:
   $$\mathcal R_{\rm open}(x)=\Bigl(\mathcal R_{F_\varpi}(x),\;\mathcal R_{D_\varpi B}(x),\;\mathcal R_{\nabla\Pi_\varphi}(x),\;\mathcal R_{\nabla\Pi_\psi}(x)\Bigr)=0\qquad(\forall x\in\mathbb R^4),$$
   corresponding respectively to gravitational curvature, exterior covariant derivative of the gravitational auxiliary field, scalar differential momentum divergence, and matter differential momentum divergence; any nonzero assembly residual at any $x\in\mathbb R^4$ observably alters the registered target action jet and generates on the **same live ledger row** a native recourse demand together with the unique canonical answer-and-next step, forbidding silent residual absorption or successor forking.
2. **All-visit zero unregistered physical authority and T0/T1 two-tier axiom kernel**: for **every** temporal visit $\nu$ of the living root, **every** primitive occurrence event $e$ at $\nu$, and **every** installed physical projection $\pi$, the primitive occurrence coincides identically with the generated temporal occurrence ($e=e_{\rm gen}(\nu)$); whole-ledger writebacks, living-ledger rows, and projected readouts factor uniquely through that generated occurrence, and every obstruction residual generates a native recourse demand through the same row, leaving zero off-ledger physical events or external authority inputs; moreover, the universal authority kernel governing occurrences, whole ledgers, compilation, recourse, and macro-succession is a zero-axiom constructive kernel (T0), while continuum field instances invoke the three standard mathematical axioms solely at tier T1 without altering the T0 kernel's zero-axiom identity.
3. **Complete nine-field real-coordinate premise fold**: the ingress transition is locked natively as $\mathsf{next}(\mathsf{ingress})=\mathsf{running}(s_0)$; for **any** two physical current states $c_1,c_2$ (covering both ingress and running branches), equality of their running-state boolean tags together with pointwise equality of all real coordinates of their nine-field configurations (including the independent linear dual $\chi$) across $\mathbb R^4$ forces **unconditional identity** of the full states, native next steps, generated trajectories, and all installed projections (denoting heterogeneous equality across dependent fibres by $\doteq$):
   $$\begin{aligned}
   &\Bigl(\mathsf{isRunning}(c_1)=\mathsf{isRunning}(c_2)\ \wedge\ \forall\alpha,\forall x\in\mathbb R^4,\;\Phi_\alpha(c_1)(x)=\Phi_\alpha(c_2)(x)\Bigr)\\
   &\qquad\Longrightarrow\;c_1=c_2\ \wedge\ \mathsf{next}(c_1)=\mathsf{next}(c_2)\ \wedge\ \mathsf{evol}(c_1)\doteq\mathsf{evol}(c_2)\ \wedge\ \forall\pi,\,\mathsf{proj}_\pi(c_1)\doteq\mathsf{proj}_\pi(c_2),
   \end{aligned}\tag{9.1}$$
   where on the running branch the actual evolution step unfolds identically to the parameter-free Cartan update of the fixed source.
4. **Complete-description isomorphism, Stage 1–10 recovery, and all-depth macro-succession**: a unique structure-preserving isomorphism links pointwise real-coordinate and compactly supported $L^2$ descriptions, preserving and reflecting relations of all arities, transporting all stream operations, and endowing every co-kernel complete description with a unique source-generated next step; the primitive event algebra (states, event families, initial state, emission, update) generates the authority root internally, recovers via $\mathcal U_{1\text{--}10}$ at the 10th mother visit the whole-spacetime operator $\mathcal W_{\rm ws}$, whole ledger, Stage 4–8 scalar/mass/mixing/anomaly-cancellation credentials (coinciding across both current and native-successor configurations; Proposition 2.6), nine-field actual, $4\sqrt2$ pairing (Theorem 6.2), and five-point coherence lock (Theorem 8.3), and preserves generative living law across **all** macro-steps $n\in\mathbb N$.

**Proof.** Part 1 eliminates equality witnesses across the five sealed positions to prove uniqueness of $\mathcal C_{\rm root}^{(0)}$, reads the three algebraic zero sections from the $\mathsf{assembly}$ whole-ledger entry, and combines the jet writeback identity of $\mathcal W_{\rm ws}$ with living-root answer uniqueness on nonzero residuals. Part 2 checks single-valued support generation and whole-ledger writeback visit by visit. Part 3 splits by constructors: two ingress states coincide immediately with shared successor $\mathsf{running}(s_0)$, while two running states yield all four conjuncts from injectivity of nine-field real coordinate recovery plus proof irrelevance (`Prop`) of all non-field slots. Part 4 composes the universal consumer-quotient comparison theorem of the companion process-core paper with primitive-event realization and ten-stage recovery (exact declarations in Appendices C.8, D.1, D.9). ∎

### 9.3 Universal Formation from the Same Mother Source, Complete Recovery, and No Magic Bit

Finally, widen the lens from this specific $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ process to **every** world state, inquiry, and evolving process expressible on the original admission interface. Denote by $S_\star$ the original occurrence-ledger root of our physical construction (the SpinPair living authority root), called henceforth the **mother source**. Both $S_\star$ and its finite evaluator $\mathsf{finiteLaw}_{S_\star}$ remain strictly fixed across all target objects.

Let $\mathbb S=\mathbb R^{\mathbb N}$ be the space of real streams. At material rank $r$, write $X_r$ for the input carrier and $\mathcal A_r$ for its point-separating observation addresses. A finite mother programme consists of finitely many addresses $(a_0,\ldots,a_{n-1})\in\mathcal A_r^n$ together with a lawful visit $\nu\in\mathsf{Visit}(S_\star)$, zero-padding observed inputs into $\mathbb S$ for evaluation by $\mathsf{finiteLaw}_{S_\star}$; completing the programme image $\mathcal R_r$ in the pointwise-input, finite-output-prefix uniform structure defines $\mathcal M_r=\widehat{\mathcal R_r}$:

$$\begin{aligned}
\mathsf{Prog}_r&=\coprod_{n\in\mathbb N}\mathcal A_r^{\,n}\times\mathsf{Visit}(S_\star),\qquad
L_r\bigl((a_0,\ldots,a_{n-1};\nu),x\bigr)=\mathsf{finiteLaw}_{S_\star}\!\bigl(\nu,\operatorname{pad}_n(\operatorname{obs}_r(a_i,x))_{i<n}\bigr),\\
\mathcal R_r&=\operatorname{im}L_r,\qquad \mathcal M_r=\widehat{\mathcal R_r},\qquad \overline{\iota_r(\mathcal R_r)}=\mathcal M_r .
\end{aligned}\tag{9.2}$$

The original admission interface (at base universe `Type 0`) comprises three classes of complete objects: **admitted world states** $(N,V,R,w)$ (a lawful history visit $w$ over any relation network $N$, vocabulary $V$, and authority root $R$); **complete inquiry states** $(N,V,q)$ (carrying living root, visit, readable question types, responsibilities, authorities, and compiled programmes); and **complete macro-processes** $P$ (carrying state space, per-state inquiry nodes, initial state, and living-law-preserving query successor).

**Theorem 9.4 (Universal formation from the same mother source, complete recovery, and no magic bit).** Fix the single mother source $S_\star$. On the original admission interface, all three universal statements hold simultaneously under one realization witness (with material ranks and separating addresses constructed internally, importing zero external representability hypotheses):

1. **Every admitted world and no magic bit**: for **every** relation network $N$, vocabulary $V$, authority root $R$, and admitted world state $w$, there exist rank $r$ and completed material $m\in\mathcal M_r$ from which the state factory forms and field-by-field recovers $(N,V,R,w)$ together with its occurrences, authority evolution, forward dispositions, history/current patches, whole ledger, next values, and advance operations, with restriction a left inverse to material embedding. Moreover, every formed world satisfies **Total Reality**: any real difference between distinct lawful visits of the same root is located at a distinct registered occurrence, formally excluding unlocated real differences (**no magic bit**).
2. **Every complete inquiry**: for **every** $N,V$ and complete inquiry state $q$, combined completed material recovers the inquiry world and all programme clauses; across every query of $q$ and exact causal event at that visit, formed compilation equals original compilation identically across answer, action, revision, and routing branches.
3. **Every complete evolving process and all-depth runtime history**: for **every** native query-engine process $P$, there exists completed material $m$ forming $P_m$ with exact full-process recovery
   $$\mathcal F_{\rm proc}(m)=\operatorname{some}(P_m),\qquad \mathcal R_{\rm proc}(P_m)=P,\tag{9.3}$$
   simultaneously recovering state space, per-state inquiry nodes, initial state, successor map, any designated activation outcome, and the whole activation law. Along every runtime trajectory $\{s_n,\tau_n\}_{n\in\mathbb N}$ of $P$, the generated runtime $\{\tilde s_n,\tilde\tau_n\}_{n\in\mathbb N}$ satisfies at **every depth $n\in\mathbb N$** ($T_m$ denoting state transport along (9.3))
   $$\tilde s_n=T_m(s_n),\qquad \tilde\tau_n\doteq\tau_n,\qquad \mathsf{next}(\tilde\tau_n)=T_m\bigl(\mathsf{next}(\tau_n)\bigr),\tag{9.4}$$
   while parent restriction of combined high/low-rank material is an exact left inverse across the entire product space:
   $$\mathcal R_{\rm parents}\circ\mathcal C_{\rm combine}=\operatorname{id}_{(\prod_i\mathcal M_i^{\rm high})\times(\prod_j\mathcal M_j^{\rm low})}.\tag{9.5}$$

**Proof.** Given any finite subset $F\subset X_r$, prefix length $b\in\mathbb N$, and $\varepsilon>0$, point separation selects a finite address table distinguishing $F$, and the mother evaluator at visit $10+c$ approximates any target map on $F\times\{0,\ldots,b-1\}$ within $\varepsilon$, proving uniform density of $\mathcal R_r$; since a uniform completion embedding has closed image containing a dense set, $\mathsf{read}_r:\mathcal M_r\xrightarrow{\sim}(X_r\to\mathbb S)$ is bijective. Assembling states and dependent queries of $P$ into the disjoint union $\mathcal U_P$ generates faithful addresses internally, combines branch materials via left inverse (9.5), and feeds the registered factory to yield (9.3) and all-depth transport (9.4), while Total Reality and no-magic-bit transfer directly from the root registration kernel (three-step proof in Appendix C.9). ∎

Notice what the universal quantifier $\forall R$ in Theorem 9.4(1) entails ontologically: **there is no independent second source**—any authority root $R$ proposed as an alternative underlying source on the original interface is already, together with all its admitted world states, an exact readout of completed material from $S_\star$, while $S_\star$ itself is generated internally by the primitive event algebra of Theorem 9.3(4) and recovered inside Theorem 9.4 by the following corollary:

**Corollary 9.5 (Same-source preservation of the original physical activation, whole law, and runtime history).** Specializing Theorem 9.4(3) to our $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ physical query process, the formation witness of $S_\star$ recovers the designated physical seal activation, next engine, and whole activation law, satisfying at runtime step $16\to 17$ (the 10th physical occurrence visit) and every finite depth $n\in\mathbb N$

$$\tilde\tau_{\rm phys}(16)\doteq\tau_{\rm phys}(16),\qquad \mathsf{next}\bigl(\tilde\tau_{\rm phys}(16)\bigr)=T_m\bigl(s_{\rm phys}(17)\bigr),\tag{9.6}$$

preserving the nine-field configuration, the gauge current $12\sqrt{15}/25$ of Example 1.1, and all quantum responses (Appendix C.8).

![Figure 7 Forming objects from the same source and recovering their original operations](figures/vector/fig5-fixed-mother-realization-en.png)

**Figure 7｜Universal formation from the single mother source $S_\star$, full-space left inverse, and preservation of the physical runtime (Theorem 9.4–Corollary 9.5).** Top: $S_\star$ and its single finite evaluator stay fixed across all targets, generating completed material via finite observation addresses and pointwise uniform completion. Middle commutative square: the registered factory forms $P_m$ and restriction recovers $P$ identically, preserving query compilation, whole ledgers, and all successors; parent restriction is a full-space left inverse. Bottom: specializing to the original physical process recovers the seal activation, step $16\to17$, and all finite-depth histories.

---

## 10 Open-Quantum Instrument Contact, Unified Theoretical Coordinates, and No-Magic Phenomenological Rigidity

Confronting real atomic and optical Bell records requires going beyond closed pure-state vectors: real instruments exhibit multi-emission spontaneous recycling, collection losses, dark counts, finite gate truncations, and unknown local readout scales. Absorbing open dynamics into phenomenological mean-value fits—or ad-hoc collapse postulates—would violate our Anti-Magic Pruning Law. We therefore first derive directly from source operator amplitudes, with zero prior probability or collapse assumptions, **whole-word Kraus–Born isometry and open recycling density trace duality** (Theorem 10.1), turning both the Born rule and open trace-nonincreasing positive semigroups into theorems; next report forward full-gate recovery, maximal identifiability quotients, and nominal negative controls on public loophole-free Bell archives (Propositions 10.2–10.5); and conclude in §10.3–§10.4 with unified theoretical coordinates and **zero-knob deductive phenomenological rigidity**.

### 10.1 Postulate-Free Generation of the Born Measure and Open Master Flows: Whole-Word Kraus–Born Isometry and Trace Duality

Let $E$ be the atomic complex Hilbert space (an arbitrary separable complex Hilbert space in Theorem 10.1(1), specialized to a finite-dimensional atomic Hilbert space in Theorem 10.1(2)) with bounded operator algebra $\mathcal L(E)$. On a source Kraus window $[t_L,t_R]$ with finite channel set $\mathcal I$, for each word length $n\in\mathbb N$, channel word $w\in\mathcal I^n$, and ordered emission simplex $\Delta_n(t_0,t_R)=\{t_0\le s_1\le\cdots\le s_n\le t_R\}$, continuous time-dependent dissipative drift and jump operators generate exact operator amplitudes $\mathcal A_{n,w}(t_0;\mathbf s)\in\mathcal L(E)$ (importing zero probability or semigroup priors under §1.1 [28–32]). Endow the disjoint word-history space $\mathscr W(\mathcal I)=\bigsqcup_{n\in\mathbb N}\bigsqcup_{w\in\mathcal I^n}\Delta_n(t_0,t_R)$ with the countable direct-sum simplex Lebesgue measure $\mu_{\rm base}(t_0)$.

**Theorem 10.1 (Whole-word Kraus–Born isometry and all-order trace identity for open recycling density evolution).** For every start time $t_0\in[t_L,t_R]$:

1. **Exact-mass Born measure and $L^2$ field-state isometry**: for every initial vector $x\in E$, the history amplitude $\Psi_{t_0}(x)(h)=\mathcal A_{n,w}(t_0;\mathbf s)x$ is strongly measurable and square-integrable; its squared-norm Born measure $\mu_{\rm Born}(t_0,x)$ has total mass over $\mathscr W(\mathcal I)$ equal to $\|x\|^2$ (automatically a probability measure for $\|x\|=1$), and $x\mapsto\Psi_{t_0}(x)$ is a **complex-linear isometric embedding** from atomic initial states into whole-word field states:
   $$\mu_{\rm Born}(t_0,x)\bigl(\mathscr W(\mathcal I)\bigr)=\int_{\mathscr W(\mathcal I)}\|\Psi_{t_0}(x)(h)\|^2\,d\mu_{\rm base}(h)=\|x\|^2,\qquad
   \|\Psi_{t_0}(x)\|_{L^2(\mu_{\rm base};E)}=\|x\|.\tag{10.1}$$
2. **Exact trace duality between whole-word series and open recycling density IVP**: fix any hidden (unregistered recycling) channel subset $\mathcal H\subseteq\mathcal I$. Defining the endpoint effect $\mathcal E_{\rm end}^{\mathcal H}(t_0;A)=\sum_{n=0}^\infty\mathcal E_{n}^{\mathcal H}(t_0;A)$ by adjoint pullback over $\mathcal H^*$ and the forward open density flow $\Phi_{t_0\to t_R}^{\mathcal H}(\rho)$ on the operator algebra $\mathcal L(E)$ of the finite-dimensional atomic Hilbert space $E$ from dissipative drift plus $\mathcal H$-recycling jumps, for **every** (neither necessarily normalized nor self-adjoint) initial operator $\rho$ and observable $A$, the infinite word series converges to the terminal density trace pairing:
   $$\sum_{n=0}^{\infty}\operatorname{Tr}\!\bigl(\rho\,\mathcal E_n^{\mathcal H}(t_0;A)\bigr)
   =\operatorname{Tr}\!\bigl(\rho\,\mathcal E_{\rm end}^{\mathcal H}(t_0;A)\bigr)
   =\operatorname{Tr}\!\bigl(\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\,A\bigr).\tag{10.2}$$
   Moreover, $\rho\ge0\implies\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\ge0$ and $\operatorname{Re}\operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\le\operatorname{Re}\operatorname{Tr}\rho$, while for the full bath $\mathcal H=\mathcal I$, $\operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal I}(\rho)=\operatorname{Tr}\rho$ holds identically for every $\rho$.

**Proof sketch.** Part 1 decomposes the countable direct-sum integral via Tonelli's theorem into finite word sums over simplices and applies simplex mass conservation $\sum_{n=0}^\infty M_n(t_0,x)=\|x\|^2$. Part 2 differentiates $F(t)=\operatorname{Tr}\bigl(\Phi_{t_0\to t}^{\mathcal H}(\rho)\,\mathcal C_{t\to t_R}^{\mathcal H}(A)\bigr)$ against the backward Heisenberg flow $\mathcal C$: cyclic trace cancellation gives $F'(t)\equiv 0$ on $[t_0,t_R]$, equating $F(t_R)=F(t_0)$, while Duhamel simplex iteration identifies $\mathcal C_{t_0\to t_R}^{\mathcal H}(A)$ with $\sum_{n=0}^\infty\mathcal E_n^{\mathcal H}(t_0;A)$ and rank-one spectral decomposition proves positivity and trace non-increase (Supplement S18). ∎

### 10.2 Forward Dynamic Recovery, Identifiability Quotients, and Nominal Negative Controls on Public Bell Records

Building on Theorem 10.1 and Proposition 8.4, we consume three public loophole-free Bell archives while strictly separating formal theorems, dual-implementation numerical verifications, and pre-registered anytime-valid statistical contracts (Supplement S9, S15; Appendices D.4, D.8):

**Proposition 10.2 (Zero-parameter Tsirelson lock, full atomic readout domain, and maximal equal-law quotient).** For the event-ready entangled-atom Bell test of Rosenfeld et al. [11]:

1. **Zero-input prediction lock** (formal theorem): our source bounds $|S_{\rm CHSH}|\le 2\sqrt2$ across all lawful XZ axes (general quantum bound due to Cirel'son [15]) and generates a parameter-free 32-cell table attaining $2\sqrt2$ on orthogonal/bisecting axes;
2. **Bidirectional characterization of the full readout domain** (formal theorem): arbitrary lawful binary readout channels (including zero or negative gain) correspond bijectively with XZ axes to compact effect vectors $(\mu,u,z)$, forming a 12-dimensional four-setting effect domain;
3. **Original-order passage across all Munich prefixes** (statistical contract): over $10,201+10,202=20,403$ valid trials in original order ($\alpha=1/20$ joint anytime budget), the zero-error ideal point crosses threshold $40$ at April trial 3974 (peak $E\approx494.85$), whereas the full readout domain contains exact witnesses keeping **all 20,403 prefixes** strictly below $40$ (April peak $1$, June peak $\approx1.3387$);
4. **Maximal equal-law quotient and effective gain floor** (formal theorem + dual verification): two lawful setting families generate identical joint laws **iff** their four biases and two $X/Z$ product matrices coincide (related on the regular locus by a unique nonzero inverse scale $(s,t)$); across the confidence domain, effective gain is uniformly $\ge 0.36579$ and canonical error rates are $<0.37916$ (Supplement S9.3).

**Proposition 10.3 (Two-probe unique hardware inverse, detector fibre, and 12-state pulse realization).** On the atomic readout domain of Proposition 10.2:

1. **Joint gain bounds and two-probe unique inverse** (dual verification + formal theorem): full-prefix domains certify max gain $>0.67020$ in April (one-sided $>0.44918$) and $>0.66386$ in June ($>0.44071$); on any identified regular law, signed responses to two source-known independent Bloch probes with nonzero identification determinant invert on both sides to **uniquely recover all hardware effect coordinates**;
2. **Microscopic detector fibre and 12-state ionization image** (formal theorem + dual numerical verification): positive-gain effects $E_{\rm click}=dI+(1-d)\eta J$ are characterized by $0\le d\le m,\,M-d\le k\le 1-d$ with unique inverse atomic effect; finite rectangular pulse realizability is equivalent to $(u^2+z^2)(b+d)^2\le(1-\mu)^2\gamma^2$ and $(u^2+z^2)(2-b-d)^2\le(1+\mu)^2\gamma^2$ bounded by dimensionless Rabi area; on Garthoff's 12-state ionization master equation (18 natural transitions + 7 ionization channels [12,13]), four named pulses realize all 32 role domains and exhibit **six explicit equal-law / distinct-spectrum pairs**;
3. **41,673 local records and dual-clock history preservation** (formal theorem + dual verification): visit 10 and runtime step $16\to17$ preserve all installed history outputs, and two independent parsers recover all nine fields of the $41,673$ public local records, $867$ unpaired entries, and clock-gap distributions identically (Supplement S9.4).

**Proposition 10.4 (First-registration probability on the complete 120 ns gate and $10^{-21}$ primal/adjoint recovery).** On Munich's complete $120\text{ ns}$ gate, ten-factor trace-preserving free bath, and 45 registration labels retaining all natural recycling, losses, and cross-arm coherences:

1. **Four-port late adjoint integration**: across 60 $1\text{ ns}$ slices and $4,915,200$ Gaussian-integer coefficients, the four-port late adjoint passes the $10^{-10}$ gate (max operator error $8.42744\times10^{-12}$);
2. **Three no-count preimages and adjoint interval**: the any-first-herald event decomposes via $1_{\rm first}=1-n_\perp-n_\parallel+n_\perp n_\parallel$ into three no-count preimages; six $120\text{ ns}$ adjoint flows pass the $10^{-8}$ gate, and source activity $\kappa\le0.0037409145$ contracts the initial-state approximation error once across the whole event, certifying $[3.17845500810,\,3.17846466595]\times10^{-6}$ (error $4.82892\times10^{-12}$);
3. **Thirty independent primal curves**: solving 30 independent $120\text{ ns}$ trace-nonincreasing primal curves (3600 slices) recovers $[3.17845717771,\,3.17846249634]\times10^{-6}$ (error $2.65931\times10^{-12}$), **with primal and adjoint centres differing by only $1.301828\times10^{-21}$**; all seven priority queries and 140 activation programmes issue from the same source, and the successor unique-identifier domain is consumed by the event-ready gate (Supplement S15).

**Proposition 10.5 (Full optical source domain, all-order Born closed form, and strictly positive CH across the joint 95% domain).** On the public photon-counting data of Shalm et al. [10]:

1. **Optical source domain and all-order Born probability** (formal theorem): common sign invariants, quadratic bounds, and training slabs hold iff a lawful phase exists; the $\mathrm{Pol}\otimes\mathrm{Env}$ six-port model yields the exact all-order matched Born closed form $1/\bigl[1+nV(T_A+T_B-T_AT_B)\bigr]$;
2. **Held-out envelope, angular gain, and strictly positive joint-95% CH** (dual verification + statistical contract): 69 seamless source slices trained on cells 00 and 11 place their held-out 01 and 10 envelopes strictly inside the published confidence intervals, shifting Bob's angles by $-0.01^\circ$ on $\pm0.05^\circ$ boxes yields CH gain $>1.69\times10^{-9}$, and under the pre-registered $1/20$ joint budget the nonempty joint 95% acceptance domain (containing 8 explicit $\Gamma/\text{Fock}$ witnesses and a continuum cover) satisfies **$\mathrm{CH}_{N5}>1.3790180504\times10^{-6}$ at every accepted source**; 24 public spacelike source-signature tests satisfy familywise bound $\approx0.002416$ at $\alpha=0.05$ (Supplement S9.1–S9.2).

**Honest negative controls of a zero-knob theory: why uncalibrated nominal locks must alarm.** Alongside the open-instrument domains above, we preserve two **negative controls on uncalibrated ideal nominal device maps** (protocols and hashes in Appendix D.4): first, on the first $100,000$ raw trials of Storz et al. [8,9], pairing Proposition 8.4 rigidly with an uncalibrated nominal pulse table is decisively rejected at $\alpha=0.025$ ($\log E=46803.62$ at zero radius, $p_{\rm any}\approx2.78\times10^{-20327}$)—and post-hoc audit reveals that the same nominal angle table evaluates to $S=0$ under the experimenters' own CHSH sign convention, exposing an unclosed phase/frame bridge; second, in a nominal two-mode optimization replay of NIST 2015 under the published $\pm0.3\%$ efficiency half-width, all five documented nominal parameters fall outside the predeclared optimal band. These negative records exemplify the falsifiability of a zero-parameter framework: with no internal fitting dials, any misspecified nominal bridge triggers immediate quantitative rejection, whereas incorporating true open losses, recycling, and readout fibres via Theorem 10.1 and Propositions 10.2–10.5 closes the public archives cleanly under the same source.

### 10.3 Unified Theoretical Coordinates: Entry Assumptions and Discharged Obligations Across Five Foundational Programmes

Placing our closed ten-stage generative chain onto the broader map of modern theoretical physics permits direct, verifiable comparisons against five foundational programmes:

1. **First-order BF gravity–gauge unification, spin–torsion, and the Coleman–Mandula boundary**. Ever since the Yang–Mills non-Abelian gauge principle [1], Deser's self-coupling mechanism [2], and the first-order spin–torsion (Einstein–Cartan) gravity of Kibble [21] and Sciama [22], the closest precedents writing gravity and gauge fields inside a common first-order differential-form action are Plebański's constrained BF formulation [3], Holst's generalized first-order action [23], and Smolin's extended Plebański model [7]. With symmetric zero-form multiplier $\Phi_{IJ}$ and coupling $\zeta$, Smolin [7, §2, Eq. (4)] writes
   $$S_{\rm Smolin}=\frac1G\int\left[B^I\wedge F_I-\frac12\Phi_{IJ}B^I\wedge B^J+\frac{\zeta}{2}\Phi^{KL}\Phi_{KL}B^I\wedge B_I\right].$$
   Smolin begins from an Euclidean $\mathrm{SO}(4)$-containing semisimple group with a chosen breaking ansatz, eliminates the symmetric quadratic multiplier $\Phi_{IJ}$ prior to expanding effective Yang–Mills and topological terms, leaves chiral fermions to qualitative future work, and constructs no constrained Hilbert space. By contrast, our theory works directly in Lorentzian signature on a direct-product bundle $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ respecting Coleman–Mandula [24] while achieving $\Delta_{\rm mix}=9\ne0$ through pre-metric coframe wedge coupling (Proposition 3.2) and selecting $\mathfrak h_{\rm SM}$ bijectively via the source spectral order parameter plus trace laws (Theorem 2.2); locks $B=J\Sigma_e$ linearly via $2$-form $\lambda$ so that general four-leg stationarity is equivalent to explicit Einstein–Cartan balance plus torsion–spin and excludes a pure symmetric quadratic multiplier for the same full reaction on the fixed synchronized configuration and its $\mathrm{Spin}^+(1,3)$ orbit (Theorem 3.3); and closes 252-dimensional anomaly-free chiral matter alongside postulate-free 61 CCR + 504 CAR quantization and full-field infrared return (Theorems 4.2–7.12).
2. **Single-group Grand Unification (GUT) and noncommutative spectral geometry**. Georgi and Glashow's $\mathrm{SU}(5)$ model [16] pioneered embedding the Standard Model into a simple Lie group, yet satisfying axial-vector and electroweak chiral anomaly cancellation [17–19] required combining inequivalent representations (such as $\bar{\mathbf 5}\oplus\mathbf{10}$) by hand while introducing external multi-Higgs potentials to select breaking directions; the Chamseddine–Connes spectral action principle [20] constrains gauge–Higgs geometry via a finite noncommutative spectral triple, yet works in Euclidean signature and takes fermion Yukawa matrices as input parameters of the finite Dirac operator. Working directly in Lorentzian signature, our Theorem 2.2 selects $\mathfrak h_{\rm SM}$ bijectively via commutation with the source spectral order parameter plus three trace laws, while the single fundamental representation's $(6,2,4)$ exterior layers automatically cancel all cubic and mixed anomalies and generate Yukawa couplings with zero free parameters via exterior wedge multiplication $\Lambda^2\otimes\Lambda^4\to\Lambda^6$.
3. **The canonical quantum-gravity “problem of time” and continuum gauge reconstruction**. Applying Dirac's singular Hamiltonian mechanics [14] to gravity, DeWitt's canonical theory [25] confronts timeless frozen-state constraints ($H\Psi=0$) and operator-ordering ambiguities, while the Page–Wootters mechanism [26] adjoins an external relational conditional-clock hypothesis; in mathematical gauge theory, Wilson's lattice formulation [6] and Osterwalder–Schrader Euclidean axioms [27] construct continuum operators via spacetime discretization or Euclidean analytic continuation (for standard second quantization see Tasaki [4]). Here Theorems 6.7–6.8 solve the four temporal constraints of the first-order common action recursively via an invertible principal Jacobian $J_4$ to produce an all-order noncommutative quantum clock, fixed bounded self-adjoint tail $R$, and common 100-coordinate + 504-CAR generator $H=H_0+Y$, while Theorem 7.12 constructs four-dimensional Schwartz curvature strong integrals preserving $\operatorname{Dom}(H_{\rm time})$ with positive-semidefinite word Gram matrices directly in real Lorentzian time.
4. **Origin of the Born probability postulate and open dynamical semigroups**. Following Born's collision probability rule [28], Gleason's theorem [29] proved that any nonnegative additive frame measure on the closed subspaces of a separable Hilbert space of dimension $\ge3$ arises from a density trace, while Kraus [30], Gorini–Kossakowski–Sudarshan [31] (for finite-dimensional $N$-level systems), and Lindblad [32] (for norm-continuous semigroups with bounded generators) characterized generators of completely positive trace-preserving semigroups on density operators (for Bell correlation frameworks see CHSH [5] and Cirel'son [15]). Every one of those theorems, however, takes **pre-supplied subspace-measure additivity or completely positive semigroup postulates** as its starting point. In our construction, §6.1 derives normalized inner-product expectations and the $4\sqrt2$ pairing from the classical independent dual $\chi$, while Theorem 10.1 derives from continuous time-dependent non-autonomous source operator amplitudes a whole-word Born measure of exact mass $\|x\|^2$ and $L^2$ field-state isometry on any separable Hilbert space $E$, alongside all-order trace duality, positivity preservation, and trace non-increase for open recycling flows on any sub-bath $\mathcal H\subseteq\mathcal I$—turning measurement and master-equation postulates into source-derived theorems.
5. **String/matrix dualities, holographic microstates, amplitude bootstraps, and landscape initial priors**. Primary sources clarify both the exact achievements and the unredeemed entry assumptions of higher-dimensional and worldsheet programmes: Witten's strong–weak duality synthesis [33] and the BFSS infinite-momentum-frame matrix model [38] link pre-selected ten- and eleven-dimensional superstring / $M$-theory regimes nonperturbatively; Strominger and Vafa counted BPS microstates of five-dimensional extremal supersymmetric black holes at fixed charges [39], and Maldacena's AdS/CFT correspondence [40] formulated a holographic dictionary between bulk string theory on asymptotically anti-de Sitter spaces and boundary conformal field theories—yet each operates after positing supersymmetric background asymptotics and compactification data rather than selecting a four-dimensional Lorentzian background, chiral $(6,2,4)$ matter inventory, or actual initial state. On the tree-level bootstrap side, Cheung, Remmen, Sciotti, and Tarquini [34, Eqs. (5), (11)] supplement Lorentz invariance, unitarity, crossing, and meromorphic poles with explicit negative-$t$ Regge ultra-softness and minimal-zero selection (noting explicitly that *“extra zeros are not inconsistent”*), establishing conditional uniqueness rather than unconditional necessity from consistency alone; on the landscape side, KKLT [35, Eqs. (12)–(14)] constructs metastable candidate vacua relative to chosen compactifications, integer fluxes, and nonperturbative ingredients, Susskind [36] distinguishes candidate counting from historical entry, and Bousso's holographic eternal-inflation measure [37, Eqs. (2)–(4), Fig. 1] eliminates initial weights only on irreducible non-terminal cycles (Eq. (4))—whenever terminal vacua are present, Eq. (2), $(1-\eta)P=\eta P^{(0)}$, retains explicit dependence on the initial distribution $P^{(0)}$, shifting the first vacuum's normalized weight in Fig. 1 of [37] from $1/4$ to $1/3$ (a gap of $1/12$) when switching from initial state A to B.

The entry assumptions of these five foundational traditions and their resolution within our ten-stage root-native closure are summarized below:

| Foundational tradition & primary sources | Entry assumptions & unredeemed inputs in prior routes | Resolution in the present Stage 1–10 root-native closure |
| --- | --- | --- |
| Single-group GUTs & spectral geometry [16–20] | Hand-assembled chiral multiplets, external multi-Higgs potentials, or Euclidean finite Dirac/Yukawa input matrices | Lorentzian positive-source spectral commutator + trace laws select $\mathfrak h_{\rm SM}$ bijectively (Thm. 2.2); $(6,2,4)$ exterior powers cancel all anomalies and generate parameter-free wedge Yukawa couplings (Prop. 2.3) |
| Spin–torsion & extended Plebański [3,7,21–24] | Pure-gravity torsion coupling, or Euclidean group-breaking ansätze with symmetric quadratic multipliers $\Phi_{IJ}$ | Direct-product bundle respects Coleman–Mandula [24] while coframe constitutive wedges give $\Delta_{\rm mix}=9$ (Prop. 3.2); general four-leg stationarity $\iff$ EC + torsion–spin with $5/8$ defect excluding pure quadratic $\Phi_{IJ}$ (Thm. 3.3) |
| Canonical quantum-gravity time & Euclidean QFT [6,14,25–27] | Frozen Wheeler–DeWitt states $H\Psi=0$, posited relational conditional clocks, or lattice / Euclidean continuation axioms | Invertible $J_4$ solves the 4 temporal constraints for an all-order quantum clock and 61 CCR + 504 CAR common $H=H_0+Y$ (Thms. 6.7–6.8); real-time Lorentzian 4D curvature strong integrals preserve $\operatorname{Dom}(H_{\rm time})$ (Thm. 7.12) |
| Born postulate & open GKLS semigroups [28–32] | Pre-supplied $\dim\ge3$ subspace-measure additivity or autonomous bounded completely positive semigroup axioms | Zero probability/collapse priors: independent dual $\chi$ and time-dependent simplex amplitudes derive $4\sqrt2$ pairing, exact-mass $\|x\|^2$ Born measure on separable $E$, and positive trace-nonincreasing open flows (Thms. 6.2, 10.1) |
| String/matrix dualities, holography, bootstraps & landscape [33–40] | 10D/11D supersymmetric or AdS boundary backgrounds [33,38–40], negative-$t$ ultra-softness & zero filters [34], flux inputs [35], and terminal-landscape initial priors $P^{(0)}$ [37] | Purely 4D zero-parameter closure of continuum fields, chiral matter, quantum feedback & $1/(4\pi r)$ kernel; primitive events generate $S_\star$, and Theorem 9.4's $\forall R$ formation + Total Reality foreclose initial-prior arbitrariness at the root |

### 10.4 Evidence Stratification, No-Magic Phenomenological Rigidity, and Deductive Division of Labour

Table 4 stratifies all verification credentials of this paper into four disjoint categories.

**Table 4 Stratification of verification credentials across the paper.**

| Evidence category | Verification definition and axiom boundary | Coverage in this paper |
| --- | --- | --- |
| Lean 4 formal theorem | Strict kernel check (`--trust=0`): universal occurrence/whole-ledger authority kernel uses **zero axioms** (T0), while continuum analysis instantiation uses at most the 3 standard Lean axioms (T1) | All theorems/propositions of §2–§6.2, §8–§9; Thms. 4.6–4.7 (S16); Thms. 6.7(3), 6.8–6.11, 7.1–7.12 (S1–S8, S11–S14, S17); Thm. 10.1 (S18); mathematical clauses of Props. 10.2–10.5 (S9, S15) |
| Fixed exact source program + independent recomputation | Exact symbolic/algebraic programs at fixed commits paired with independent zero-shared-code recomputations | Finite-dimensional orbit sections, 944 cross-terms, and Weyl symbol coefficients in Theorem 6.7(1)(2) (Table in S1) |
| Dual-implementation numerical verification | Primary and independent implementations produce frozen receipts cross-checked bit by bit with explicit rational or outward-rounded bounds | 812 evaluations on 256-dim Fock space (D.3); 501 nine-field core identity checks (D.5); 12-state ionization forward image, NIST slices, and 120 ns primal/adjoint gates (Props. 10.3–10.5; S9, S15) |
| Pre-registered anytime statistical contract | Criteria, mappings, and joint $\alpha$-budgets (e.g. $\alpha=1/20$) frozen prior to execution via nonnegative supermartingales | Munich 20,403 full-prefix passage, NIST joint-95% strictly positive CH, and two historical ideal-nominal negative controls (§10.2, D.4, D.8) |

**Deductive phenomenological rigidity under the no-magic discipline: why downstream phenomenology is pure deduction rather than parameter fitting.** In conventional unification models, deferring low-energy phenomenology to follow-up papers ordinarily signals dozens of undetermined coupling constants, symmetry-breaking angles, renormalization counterterms, or initial-state choices awaiting retrospective empirical fits. Under our closed ten-stage unification object $\mathcal U_{1\text{--}10}$, Theorem 9.3(2)(3) (zero unregistered physical authority and the complete nine-field premise fold) together with Theorem 9.4(1) ($\forall R$ universal formation and no magic bit) foreclose that escape route mathematically: outside the fixed mother occurrence (10th visit, runtime step $16\to17$), every non-field runtime slot is pure proposition (`Prop`) incapable of carrying hidden bits; **the entire physical theory possesses strictly zero tunable physical knobs**.

Every observable-sensitive low-energy quantity is therefore already uniquely determined by the closed object as a definite mathematical constant or operator integral: within verified source electromagnetic and unit-bridge modules (fixed commit `df4`; exact declarations in Appendix D.9), the source phase gauge Lie algebra and actual charged created state unconditionally establish the unit electron charge $|Q_e|=1$, native two-branch propagation speeds $v_{\rm src}\in\{\sqrt{594/1675},\,\sqrt{18/25}\}>0$, and phase momentum factor $p_{\rm ph}>0$; furthermore, on the standard physical-return branch of the 11-branch electromagnetic disposition (where the static temporal electric and spatial magnetic Noether coefficients $c_{\rm temp},c_{\rm sp}$ are nonzero with $-\operatorname{Re}(c_{\rm temp}/c_{\rm sp})>0$), transverse Maxwell-cone phase speed locks onto the parameter-free source expression $c_{\rm phys}:=\sqrt{-\operatorname{Re}(c_{\rm temp}/c_{\rm sp})}>0$, and the single-$4\pi$ Coulomb coupling at the actual three-fermion pole ($C_{\rm EM}=c_{\rm temp}/(4\pi)$) locks onto the parameter-free quotient $C_{\rm EM}/(p_{\rm ph}c_{\rm phys})$ (certified numerical verification of the positive `.standard` branch at the dressed event and interval tightening of $\alpha(0)$ belong to companion Case 3). This establishes a sharp methodological boundary: **downstream phenomenological companions neither can nor may introduce a single new coupling constant, unit dial, or counterterm; their sole task is certified rational-ball numerical evaluation of the definite high-dimensional integrals and rational fractions already uniquely locked by this paper's total closure, paired with a pre-registered three-tier knob-free calibration bridge (dimensionless source core $\to$ explicit instrument calibration record $\to$ zero-parameter independent prediction)**—so that any post-calibration empirical discrepancy cannot be absorbed by parameter tuning, but must by Theorem 9.3(1)(2) register as an actual obstruction residual triggering canonical same-row recourse revision.

**Self-contained scope of this paper and deductive division of labour.** Every numbered theorem of this paper carries a complete self-contained written proof inside the main text, appendices, or Supplement S0–S18, delegating zero decisive steps to unpublished manuscripts:

1. **Published foundational companions**: Theorem 9.3(4) invokes the universal consumer-quotient comparison theorem of *Process Identity, Responsibility Taking, and Minimal Revision*; standalone developments of whole-ledger accounting and positive no-magic criteria appear in *Source-Generated Whole-Ledger Accounting* and *1 Bit Is All You Need*.
2. **Pre-state constrained operator Euler equations and moving composite budgets (Cases 5A / 5B / 5C)**: Theorem 6.8(3) proves dual-residual vanishing at fixed $(\mathcal T,R,E)$ rather than state-vector convergence; the 1500-variable analytic constraint data and state-independent 350-slot differential CAR operator Euler equations belong to *From the Common Action to Constrained Quantum Dynamics* (Case 5A); the 202-row moving-frame current cancellation and signed positive decay credits belong to *Dynamics and Retarded Response of a Composite Carrier* (Case 5B); and standalone noncommutative clock reductions belong to *A Source-Generated Quantum Clock and Graded Balance* (Case 5C).
3. **Parameter-free four-coordinate unit matching and numerical ball tightening (Cases 1–4 / Case 6)**: Proposition 2.3's one-loop $b_0$ table covers the pure exterior Weyl fermion inventory (excluding dynamical scalars), and Theorems 8.1–8.2 fix the coframe/spin-connection background without dynamically coupled metric evolution or SI unit calibration. While the verified source modules above fix $|Q_e|=1$, $v_{\rm src}$, and the exact standard-branch expressions of $c_{\rm phys}$ and the pole coupling quotient, numerical verification of standard-branch positivity at the dressed event, four-coordinate parameter-free unit left-inversion, the 108-channel heavy-minus-light width law, and certified numerical interval tightening of the Thomson $\alpha(0)$ source fraction belong to *Source-Generated Units and Four-Coordinate Parameter-Free Matching* (Case 3; no completed numerical point value for $\alpha(0)$ is claimed in the present paper); 158-vertex Fock selection rules belong to Case 4; and combined unit, baryon/lepton, and open-channel particle-spectrum and proton-lifetime numerical tightening reside in result-triggered Case 6.
4. **Continuum gauge spectrum and quantum-optical metrology**: Theorem 7.12 establishes 4D Schwartz curvature strong integrals on $\operatorname{Dom}(H_{\rm time})$ for the total closure $\mathcal U_{1\text{--}10}$; lattice reflection positivity, dynamic GNS reconstruction, and pure-gauge mass-gap terminals for arbitrary compact simple groups belong to *Positive Energy of the Wilson Action and Gauge-Field Reconstruction* and *Curvature Response and Spectral Bottom of the Same Hamiltonian*, while unknown-loss optical inverse calibration and Bell instrument fibres are developed in *Inverse Calibration and Feedback of a Full-Fock Light Source* and *Identifiability and Instrument Fibers of Bell Readout*.

### 10.5 Conclusion: Seeing the Continuous–Quantum Unified Field from One Occurrence Source

Returning to the three century-old seams confronted at the outset—between spacetime geometry and internal symmetries, between continuum classical fields and noncommutative quantum mechanics, and between mathematical equations and knob-free phenomenology—this Stage 1–10 root-native $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ unified field theory delivers a definite answer: unification needs no external assembly magic. Over a zero-axiom occurrence and whole-ledger kernel (T0), one fixed positive source generates four-dimensional Lorentzian geometry and the Standard Model gauge subalgebra on demand, cancels all chiral exterior-power anomalies, equates general four-leg gravitational stationarity with Einstein–Cartan balance plus torsion–spin, and computes the exact $4\sqrt2$ pairing and common quantum generator $H=H_0+Y$ directly from the original action and independent dual.

Across the closed return loop, a single gauge current links microscopic many-body algebra to macroscopic long-range forces and real open instruments: returning through the mother action's own Fréchet Hessian Green function, nonlinear half-axis derivative, nine-constraint Schur feedback, $z^4\Pi_{\rm st}$ holomorphic infrared return, and 192/97 electromagnetic Ward cancellation to yield the emergent $1/(4\pi|x-y|)$ spatial potential and charged colour-singlet three-fermion positive spectrum, while deriving without prior probability axioms the whole-word Born measure and open density trace duality to recover first-registration probabilities across Munich's complete 120 ns gate within $1.30\times10^{-21}$. Underneath the entire unified field, the five-position physical root seal and nine-field premise fold eliminate off-ledger physical authority and tunable parameters altogether, and the single mother source $S_\star$ universally forms every admitted world, inquiry, and evolving process on the original interface, anchoring every real difference in registered occurrences. What unification and correspondence once promised by ear is here seen in full from one parameter-free occurrence source.

---

## Appendix A Mother Representation, Generators, and Source Constants

**A.0 Core Notation Glossary.**

| Symbol | Mathematical and physical meaning | Defined in |
| --- | --- | --- |
| $e,\ \varpi,\ B,\ \lambda$ | Coframe, $\mathrm{Spin}^+(1,3)$ spin connection, gravitational auxiliary bivector, simplicity multiplier | Table 2, §3.1 |
| $A,\ B_A,\ \varphi$ | $\mathfrak h_{\rm SM}$ gauge connection, gauge auxiliary $2$-form, $\Lambda^4\mathbb C^7$ dynamical scalar | §2.2, §3.1 |
| $\psi,\ \chi$ | 252-complex-dim chiral exterior-power matter spinor, independent $\mathbb C$-linear dual | §2.3, §3.1 |
| $\mathcal O_{\rm br},\ \iota_{\rm SM}$ | Adjoint spectral order parameter $\sigma\,\mathrm{diag}(-1,-1,-1,0,0,1,2)$, SM block embedding | §2.2 |
| $J,\ \star_e,\ \mathrm{II}^+(e)$ | Internal Lorentz bivector dual, spacetime Hodge star ($\star_e^2=-1$), simplicity target $J\Sigma_e$ | §3.1 |
| $v,\ E,\ P,\ S,\ R(A)$ | 8-dim occupation state, embedding, projection, Dirac block swap, compressed response $SPAE$ (distinct from tail $R$) | §6.1–§6.2 |
| $H=H_0+Y,\ H^\sharp,\ R$ | 504-mode CAR + 61 CCR common generator, formal adjoint $H_0+Y^\dagger$, fixed self-adjoint tail | §6.3–§6.4 |
| $u_\epsilon,\ v_\epsilon,\ \ell_d$ | Unit CAR created external state, unit configuration background, difference functional ($\|\ell_d\|\le2$) | §6.4, §7.2 |
| $H_{289}(p),\ G,\ \Pi_d^{\rm st}$ | Mother 289-dim second-variation matrix (3071 entries), mother Green function, static polarization | §7.1–§7.2 |
| $Q_{97},\ D_{\rm W},\ N_{\rm W}$ | 192/97 bivariate Schur polynomial matrix, $X^2$-factored Ward determinant, $X^3$-factored numerator | §7.4 |
| $H_{\rm time},\ \mathcal H_{\rm com}$ | Self-adjoint generator of $U_{\rm time}(s)=e^{-isH_{\rm time}}$ on 252-dim matter / common carrier (distinct from $H=H_0+Y$) and common carrier | §7.5 |
| $\mathcal C_{\rm root}^{(0)},\ \mathcal C_{\rm seal},\ \mathcal U_{1\text{--}10},\ \mathcal W_{\rm ws}$ | Five-position historical root closure, Stage 10 physical root seal, ten-stage closure, and whole-spacetime assembly operator | §1.1, §9.2 |
| $S_\star,\ \mathcal M_r$ | Physical occurrence-ledger mother source, rank-$r$ pointwise completed programme carrier | §9.3 |
| $\mathscr W(\mathcal I),\ \Phi_{t_0\to t_R}^{\mathcal H}$ | Simplex whole-word history space, open recycling density IVP flow on sub-bath $\mathcal H\subseteq\mathcal I$ | §10.1 |

**A.1 Standard Model Block Embedding and Colour-Doublet Generators.** On the $3+2+1+1$ partition (`Proposition286.lean` and `SU7MotherLieAlgebra.lean`), the group-level embedding is $\operatorname{diag}(U_3,U_2,z,z^{-1})\in\mathrm{SU}(7)$ ($U_3\in\mathrm{SU}(3),U_2\in\mathrm{SU}(2),|z|=1$), whose Lie differential is $\iota_{\rm SM}(C,W,y)=\operatorname{diag}(C,W,y,-y)$ selected bijectively in Theorem 2.2. On the first two colour modes, the three anti-Hermitian Pauli generators $\tau_g=(i/2)\sigma_{g+1}$ read

$$\tau_0=\begin{pmatrix}0&i/2\\ i/2&0\end{pmatrix},\qquad \tau_1=\begin{pmatrix}0&1/2\\ -1/2&0\end{pmatrix},\qquad \tau_2=\begin{pmatrix}i/2&0\\ 0&-i/2\end{pmatrix},$$

satisfying $\tau_g^2=-\tfrac14 I_2$ and $\langle\tau_g,\tau_h\rangle=-\mathrm{Re}\,\mathrm{tr}(\tau_g\tau_h)=\tfrac12\,\delta_{gh}$.

**A.2 Dirac Matrix Conventions.** Four-spinor indices use the symmetric chiral block basis ($(\gamma^0)^2=-I_4$, $(\gamma^i)^2=+I_4$, $i=1,2,3$):

$$\gamma^0=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\quad \gamma^i=\begin{pmatrix}0&\sigma_i\\ \sigma_i&0\end{pmatrix},\quad
\sigma_1=\begin{pmatrix}0&1\\1&0\end{pmatrix},\quad \sigma_2=\begin{pmatrix}0&-i\\i&0\end{pmatrix},\quad \sigma_3=\mathrm{diag}(1,-1).$$

The velocity probe on $\mathbb C^{252}$ is $\mathsf V=\mathrm{diag}(i\omega,i\omega,-i\omega,-i\omega)\otimes I_{63}$, restricting on $\mathbb C^8$ to the same diagonal tensored with $I_2$.

**A.3 Hypercharge Decomposition Across Exterior-Power Layers.**

**Table A1 Dimensions and hypercharge multiplicities of the exterior-power matter layers.**

| Exterior-power layer | Complex dim. | Hypercharge $-1$ | Hypercharge $0$ | Hypercharge $+1$ |
| --- | :---: | :---: | :---: | :---: |
| $\Lambda^6\mathbb C^7$ | $7$ | $1$ | $5$ | $1$ |
| $\Lambda^2\mathbb C^7$ | $21$ | $5$ | $11$ | $5$ |
| $\Lambda^4\mathbb C^7$ | $35$ | $10$ | $15$ | $10$ |
| Total (per Dirac component) | $63$ | $16$ | $31$ | $16$ |

**A.4 Summary Table of Constants Derived from the Fixed Positive Source.**

**Table A2 Source-generated algebraic constants and locking identities.**

| Constant | Exact closed form | Decimal approx. | Generative origin and locking identity |
| --- | --- | --- | --- |
| $\sigma$ | $1/2$ | $0.50000$ | Origin readout of $\sigma_n=1/(n+2)$ at seed $n=0$; $g_j^2=\sigma$ |
| $k$ | $\sqrt2$ | $1.41421$ | Spatial spin-connection torsion scale, $k^2=2$ |
| $a$ | $3\sqrt2/5=3k/5$ | $0.84853$ | Spatial gauge-connection amplitude, $\rho=a/k=3/5$ |
| $N$ | $\sqrt{54/125}$ | $0.65727$ | Coframe temporal lapse, $N^2=2\rho^3=54/125$, $a^3=N^2k$ |
| $\omega$ | $3N(k-a)/2=3Nk/5$ | $0.55771$ | Dirac phase frequency, $\omega^2=972/3125$ |
| $\kappa$ | $9N/5=3\rho N$ | $1.18308$ | Clock–B mixed stiffness (Theorem 5.2) |
| $m,\ c$ | $3N,\ 5N$ | $1.97180,\ 3.28634$ | Global orbit inertia and quadratic stiffness, $c/m=1/\rho=5/3$ (Theorems 8.1–8.2) |
| $t^*$ | $\pi/(2\omega)$ | $2.81651$ | First dark time (Theorem 8.3) |

## Appendix B Variational Channels, Four-Leg Critical Reduction, and Elimination Formulas

**B.1 The Nine Euler–Lagrange Variational Residuals.** On the origin chart (descending globally via Proposition 3.5), set $L_\mu=\Omega_\mu+\rho_{\mathcal M}(A_\mu)$ and $\mathscr D\psi=i\gamma_e^\mu D_\mu\psi+Y_R(\varphi)\psi$. Oriented $1$-form / $3$-form wedge pairing along $(012,013,023,123)$ reads

$$W_{13}(\alpha,Z)=\langle\alpha_0,Z_{123}\rangle-\langle\alpha_1,Z_{023}\rangle+\langle\alpha_2,Z_{013}\rangle-\langle\alpha_3,Z_{012}\rangle.\tag{B.1}$$

The matter spin-current $3$-form $j_{\rm spin}$ and gauge-current $3$-form $j_A$ are determined uniquely by varying (3.1):

$$\begin{aligned}
W_{13}(\delta\varpi,j_{\rm spin})&=\nu_e\operatorname{Re}\chi(i\gamma_e^\mu\delta\Omega_\mu\psi),\\
W_{13}(\alpha,j_A)&=\nu_e\left[g^{\mu\nu}\operatorname{Re}\langle\rho_4(\alpha_\mu)\varphi,D_\nu\varphi\rangle+\operatorname{Re}\chi(i\gamma_e^\mu\rho_{\mathcal M}(\alpha_\mu)\psi)\right].
\end{aligned}\tag{B.2}$$

The five algebraic and connection differential residuals are

$$\mathcal E_\lambda=B-J\Sigma_e,\quad
\mathcal E_B=\widehat F_\varpi-JB+\lambda,\quad
\mathcal E_{B_A}=F_A-K_eB_A,\quad
\mathcal E_\varpi=D_\varpi B+j_{\rm spin},\quad
\mathcal E_A=D_A B_A+j_A,\tag{B.3}$$

and the directional residuals for scalar, matter, independent dual, and coframe (along constant $h\in\Lambda^4\mathbb C^7$, $w\in\mathcal M$, $\zeta\in\mathcal M^*$, $H\in\mathbb R^{4\times4}$) are

$$\begin{aligned}
\mathcal E_\varphi[h]&=\nu_e\left[g^{\mu\nu}\operatorname{Re}\langle\rho_4(A_\mu)h,D_\nu\varphi\rangle-2\operatorname{Re}\langle h,\varphi-\varphi_{{\rm vac},s}\rangle+\operatorname{Re}\chi(Y_R(h)\psi)\right]-\partial_\mu\left[\nu_e g^{\mu\nu}\operatorname{Re}\langle h,D_\nu\varphi\rangle\right],\\
\mathcal E_\psi[w]&=\nu_e\operatorname{Re}\chi\bigl(i\gamma_e^\mu L_\mu w+Y_R(\varphi)w\bigr)-\partial_\mu\left[\nu_e\operatorname{Re}\chi(i\gamma_e^\mu w)\right],\\
\mathcal E_\chi[\zeta]&=\nu_e\operatorname{Re}\zeta(\mathscr D\psi),\\
\mathcal E_e[H]&=-W_{\rm top}(\lambda,J\,D\Sigma_e[H])+D_e\bigl(L_{\rm gauge}+L_{\rm scalar}+L_{\rm Dirac\text{-}dual}\bigr)[H].
\end{aligned}\tag{B.4}$$

Under smoothness, Lorentz admissibility, and nondegeneracy, the first variation of (3.1) along any compactly supported smooth perturbation equals the integral pairing against (B.3)–(B.4).

**B.2–B.6 Constitutive Inverse, Two Duals, Exterior Error Scale, Formal Integrals, and Moving Frames.**
- **B.2 Constitutive inverse**: $K_{e,j}=\alpha_j\star_e$ with $\star_e^2=-1\implies K_{e,j}^{-1}=-\alpha_j^{-1}\star_e$; expanding $B_A=B_A^*+\delta B_A$ proves Theorem 3.4.
- **B.3 Two duals**: $\star_e$ acts on spacetime $2$-form indices (mapping magnetic curvature to electric $B_A$), whereas $J$ acts on internal bivectors, giving $\mathrm{II}^+(\mathrm{diag}(\nu,1,1,1))_{3,0}=-\nu$ and the $-uN$ recoil of Theorem 5.4.
- **B.4 Explicit exterior error scale**: for skew-adjoint $G$ on $\mathbb C^7$, tuple $w=(w_1,\ldots,w_d)$, and $T_w(M)=(Mw_1,\ldots,Mw_d)$, Proposition 6.4(2) uses $C_{w,j}(t)=\|\omega_{d,j}\|\,d[\|T_w\|(1+t\|G\|)]^{d-1}\|T_w\|\|G\|^2$ and $C_{d,v,j}(t)=\sum_I|v_I|C_{w^I,j}(t)$.
- **B.5–B.6 Relative action and moving frames**: compactly supported relative actions integrate density differences; `actualAction` and `nativeActionInFrame` satisfy representation invariance under pointwise density equality (without claiming absolute integrability of nonzero constants over $\mathbb R^4$), with $\mathrm{reduce}(gf,g\cdot\Phi)=\mathrm{reduce}(f,\Phi)$ pointwise.

**B.7 Formal Declaration Correspondence for Core Classical Results (relative to `Lean/SaturationMonoid/PhysicsCore/`, revision H).**

| Formula / Theorem | Core producer module and declarations | Direct consumers |
|---|---|---|
| Theorem 2.2 Spectral selection | `SU7MotherLieAlgebra.lean`: `selected_entry_zero_of_breakingLevel_ne`, `selectedBySourceBreaking_iff_p286LieBlockImage` | `Stage10/Recovery/Source.lean`, `SU7GravityGaugeMatterJointCredential.lean` |
| Proposition 3.2 Nonseparability | `NonseparableSourceCoframeRegression.lean`: `gravityGaugeMixedDifference_eq_nine`, `nonseparableMasterAction_not_additively_separable` | `NonseparablePhysicalUnifiedAdmissionCredential.lean` (Stage 5 credential) |
| Eqs. (3.1), (B.3)–(B.4) | `StageNineDiracDualFormNativeMotherAction.lean`, `StageNineDiracDualFormNativeJointResidualCarrier.lean` | `Stage9G/Foundation/NativeAction.lean`, `Stage9C/Material/SpinPair/Acceptance.lean` |
| Theorem 3.3 Four-leg & $5/8$ defect | `StageNineDiracDualFormNativeFourLegCriticalLocusCorrespondence.lean`, `StageNineDiracDualFormNativeIIPlusTorsionSpinCriticalLocus.lean`, `StageNineDiracDualFormNativeIIPlusCoframePointwiseEquation.lean`, `StageNinePlebanskiExistingGravityMultiplierCompatibility.lean` | `StageNineDiracDualFormNativeIIPlusCoframePointwiseEquationRegression.lean`, `StageNinePlebanskiExistingGravityMultiplierCompatibility.lean` (`fullSynchronizedCompatibilityResidual_spin_nonzero`) |
| Eqs. (4.2)–(4.17) Nine-field solution | `SU7ExteriorYukawaMassSpectrum.lean`, `Stage9C/Material/SpinPair/{Actual,DiracActual,AdjointActual,GaugeEquation,Coframe}.lean`, `Stage9C/Dynamics/Homogeneous/{CartanActual,GaugeBalance}.lean` | `Stage9C/Material/SpinPair/Acceptance.lean` `actual_jointZeroFiber`, `actual_classicalWorldAcceptance`, `Stage9DEF/Compatibility/Current.lean` |

**B.8 Complete Written Proof of Theorem 3.3 (General Four-Leg Critical Equivalence and Plebański `5/8` Defect).**

*Part 1: General four-leg critical equivalence (Eq. (3.4)).* Fix any smooth unified source $s$ and smooth, Lorentz-admissible, everywhere coframe-nondegenerate nine-field configuration $\mathcal C=(e,\varpi,B,\lambda,A,B_A,\varphi,\psi,\chi)$ with integrable local density on the origin chart. Denote by $\pi_{\mathrm{II}^+}(\mathcal C)$ the configuration keeping the other **eight** fields (including $\lambda$) unchanged while replacing $B$ by $\mathrm{II}^+(e)=J\Sigma_e$, and denote the unique action-derived reaction field by $\lambda_{\rm react}(\mathcal C):=JB-\widehat F_\varpi$ ($J^2=-I_6$, so on $B=\mathrm{II}^+(e)$ one has $\mathcal E_B=\widehat F_\varpi-JB+\lambda=0\iff\lambda=\lambda_{\rm react}(\mathcal C)=-\Sigma_e-\widehat F_\varpi$). Plainly $\pi_{\mathrm{II}^+}(\mathcal C)=\mathcal C$ iff (3.4)(i) holds, and $\pi_{\mathrm{II}^+}(\mathcal C+s\delta\varpi)=\pi_{\mathrm{II}^+}(\mathcal C)+s\delta\varpi$ holds field by field.

1. **Algebraic two-leg elimination**: in (3.1), $\lambda$ enters linearly through $W_{\rm top}(\lambda,B-J\Sigma_e)$, so vanishing against all compactly supported smooth $\delta\lambda$ is equivalent to $B=J\Sigma_e$ pointwise; given $B=J\Sigma_e$, vanishing against all compactly supported $\delta B$ is equivalent to $\widehat F_\varpi-JB+\lambda=0$, i.e. $\lambda=\lambda_{\rm react}(\mathcal C)$.
2. **Identity bridge between reduced and partial full variations**: define the $\mathrm{II}^+$-reduced action $S_{\rm red}(\mathcal C):=S\bigl(\pi_{\mathrm{II}^+}(\mathcal C)\bigr)$, whose gravitational block reduces to the first-order Einstein–Cartan density $W_{\rm top}(\mathrm{II}^+(e),\widehat F_\varpi)-\tfrac12 W_{\rm top}(\mathrm{II}^+(e),J\,\mathrm{II}^+(e))=W_{\rm top}(J\Sigma_e,\widehat F_\varpi)+\tfrac12 W_{\rm top}(\Sigma_e,J\Sigma_e)$. Varying $\varpi$ along any compactly supported $1$-form $\delta\varpi$ ($s\mapsto\mathcal C+s\delta\varpi$), since $\mathrm{II}^+(e)$ is independent of $\varpi$ and the simplicity term vanishes identically on $B=\mathrm{II}^+(e)$,
   $$\left.\frac{d}{ds}\right|_{s=0}S_{\rm red}(\mathcal C+s\delta\varpi)
   =\left.\frac{d}{ds}\right|_{s=0}S\bigl(\pi_{\mathrm{II}^+}(\mathcal C)+s\delta\varpi\bigr)
   =\int W_{13}\bigl(\delta\varpi,\,D_\varpi(\mathrm{II}^+(e))+j_{\rm spin}(\mathcal C)\bigr).\tag{B.5}$$
   Whenever (3.4)(i) holds, $\pi_{\mathrm{II}^+}(\mathcal C)=\mathcal C$, identifying the left-hand side of (B.5) with the full $\varpi$-variation; nondegeneracy of $W_{13}$ renders stationarity equivalent to $D_\varpi(\mathrm{II}^+(e))+j_{\rm spin}(\mathcal C)=0$ (Eq. (3.4)(iv)).
3. **Coframe channel and explicit EC balance**: varying $e_\varepsilon=e+\varepsilon H$ along compactly supported $H$, in $S_{\rm red}$ the auxiliary $B(\varepsilon)=J\Sigma_{e_\varepsilon}$ moves with $e_\varepsilon$, so the chain rule yields
   $$\left.\frac{d}{d\varepsilon}\right|_{\varepsilon=0}L_{\rm red}(e_\varepsilon)
   =W_{\rm top}\bigl(\widehat F_\varpi-J\,\mathrm{II}^+(e),\,J\,D\Sigma_e[H]\bigr)+D_e\bigl(L_{\rm gauge}+L_{\rm scalar}+L_{\rm Dirac\text{-}dual}\bigr)[H].$$
   On configurations obeying (i)–(ii), $\widehat F_\varpi-J\,\mathrm{II}^+(e)=-\lambda_{\rm react}(\mathcal C)=-\lambda$, making the first term $-W_{\rm top}(\lambda,J\,D\Sigma_e[H])$, **pointwise identical** to $\mathcal E_e[H]$ in (B.4). Coframe nondegeneracy then identifies integral stationarity bijectively with pointwise explicit Einstein–Cartan balance $\mathcal E_e^{\rm EC}(s,\mathcal C)=0$ (Eq. (3.4)(iii)), completing the bidirectional equivalence (`diracDualFormNative_fourLegCriticalLocus_iff_EC_coframeBalance_and_torsionSpin`).

*Part 2. Plebański `5/8` pair-exchange defect and Spin-invariant exclusion (Eq. (3.5)).* We use the $\Lambda=0$ multiplier space of the nonchiral Plebański constraint reviewed by Smolin [7, §2, Eqs. (1)–(3)]. In the term $-\tfrac12\Phi_{IJ}B^I\wedge B^J$, the multiplier has pair-exchange symmetry and zero $\varepsilon$-trace. Smolin's extension [7, §2, Eqs. (4), (8)] also uses a pair-symmetric multiplier, with its own trace equation. At the fixed positive source's historical synchronized configuration, set $e=I_4$ and $B_0=\mathrm{II}^+(I_4)$. Reconstructing $\Phi_{\rm cand}=\mathcal R_{\rm tot}B_0^{-1}$ from the full reaction gives entries $5/16$ at $(4,3)$ and $-5/16$ at $(3,4)$. The $(3,0)$ component of the historical coframe response is $5/16$, so the linear principal term in direction $E_{03}$ is $\mathcal P_{\rm lin}(E_{03})=-2(5/16)$. The reaction cancels this term, giving

$$(\Phi_{\rm cand})_{4,3}-(\Phi_{\rm cand})_{3,4}=\frac{5}{8}=T_{\rm non\text{-}grav}(E_{03})=-\mathcal P_{\rm lin}(E_{03})\ne 0.\tag{B.6}$$

Equation (B.6) gives a nonzero compatibility residual. Let $M_g$ be the internal bivector matrix for $g\in\mathrm{Spin}^+(1,3)$. The joint transformation gives $B_g=M_g B_0$ and $\mathcal R_g=(M_g^{-1})^{\mathsf T}\mathcal R_{\rm tot}$, so the reconstructed multiplier is $\Phi_g=(M_g^{-1})^{\mathsf T}\Phi_{\rm cand}M_g^{-1}$. The pullback on both indices and its inverse preserve pair-exchange symmetry and zero $\varepsilon$-trace. Thus $\Phi_g$ lies in the standard multiplier space exactly when $\Phi_{\rm cand}$ does, and the compatibility residual stays nonzero throughout the orbit. ∎

## Appendix C Source Family, Law Formation, and Process Representation Details

**C.1–C.4 Pointwise Completion Carrier, Four Source-Family Contracts, Paths, and Joint Real Limit.**
- **C.1 Completion carrier**: finite mother laws complete via Cauchy filters in the pointwise-input, finite-output-prefix uniform structure; physical inputs take $(\text{10-slot Cauchy state}\times\text{independent clock})\times\mathbb S$ (nine fields plus scalar velocity).
- **C.2 Four source-family contracts**: (i) a single mother law prior to all sources, states, and centres recovers inputs and outputs the next Cartan state while preserving relative actions; (ii) a universal law compiles as the native write; (iii) a universal law equates occurrence targets to Cartan targets; (iv) evolution generates ledger successors and recovers targets for every law, material, and lawful occurrence.
- **C.3–C.4 Paths and 65-slot geometric convergence**: finite real target sequences ($195=65\times3$ spatial remainders) are realized as exact post-state subsequences; finite rational programmes ($260=65\times4$ rational coordinates) form and execute autonomously in one round prior to queries; and geometric folding $w_n=2^{-(n+1)}$ of $q^2/(1+q^2)$ across all 65 continuous slots satisfies $\|\text{limit}-f_n\|_\infty\le 2^{-n}$, recovering the original source at step zero with full classical–quantum admission.

**C.5–C.7 Complete Matter Operators, Joint Compilation, and Closed Polish Embeddings.**

**Theorem C.1 (Mother-material formation of the 252-dimensional matter operator algebra).** Normalized mother curvature rate generates $i$, and canonical completion over $127,008=2\times252^2$ rational history coordinates forms the full algebra $\operatorname{End}_{\mathbb C}(\mathcal M)$: for **every** $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$ there exists a **unique** completed value $v$ with $\mathrm{operator}(v)=A$, recovering all entries and vector actions bidirectionally from past samples of the same visit jointly with arbitrary-source nine-field balance and $8\times8$ quantum responses.

**Proposition C.2 (Joint carrier formation and physical query compilation).** Over the integer $\Omega$-orbit span of joint inputs, two mother laws chosen prior to all joint values form material and native lifted actions preserving nonzero feedback directions, and two universal compilation laws return $(\text{query},\operatorname{some}\text{value},\operatorname{some}\text{lifted value})$ while preserving every query's own answer.

**Proposition C.3 (General law completion and closed embedding of continuous Polish processes).** (1) Every map $f:\mathbb S\to\mathbb S$ and every regularity-free physical map $f:\mathrm{Input}\to\mathbb S$ is evaluated pointwise by a unique completed mother law; (2) for any dynamics whose state space $S$ and dependent event space $\sum_{s\in S}\mathrm{EventAt}(s)$ are Polish spaces with continuous emission and update maps, there exist a mother law, initial state, and injective closed embedding recovering all states and lawful events inside and outside the emission image while commuting with initial values, emission, updates, finite histories, whole ledgers, and native successors.

**C.8 Formal Declarations for §9 and Appendix C (relative to `Lean/SaturationMonoid/PhysicsCore/`; Theorem 9.4–Corollary 9.5 at revision F, others at H).**

| Result | Core producer modules and declarations | Direct consumers and preserved content |
|---|---|---|
| Theorem 9.1, App. C.2 | `Stage10/SourceUniqueness/Formation/General/{Consumer,Acceptance}.lean`; `Declarations/AllSourceOrigin/Consumer.lean` | `General/Evolution/Consumer.lean` (all-source nine fields, relative action, quantum response) |
| Thm. 9.2, Thm. C.1, Props. C.2–C.3 | `Formation/Paths/Consumer.lean`, `Programmes/Autonomous/Consumer.lean`, `Matter/Action/Matrix.lean`, `Declarations/JointCarrierFormation/Coverage.lean`, `Laws/{Pointwise/Completion,Restriction/Process}.lean` | Intermediate micro-steps, past-sample monotonicity, `NativePhysicalQuery/Inquiry.lean`, `regular_process_map` |
| Stages 1–3 Non-vacuity & dual-axis gates | `ConstitutiveHardGateVacuityBoundary.lean`, `SourceConstitutiveHardGateAdapter.lean`, `SU7AdmittedRicherDualAxisCredential.lean` | `Stage10/Recovery/Source.lean`, `Stage10/Recovery/Consumer.lean` |
| Theorem 9.3 Five-pos. seal, authority & repr. | `StageTenPhysicalRootClosure.lean`; `Stage10/{Authority,Seal,RawSourceRealization,Realization,Description/Consumer}.lean` | `Stage10/Runtime/Activation.lean`, `Stage10/Recovery/Consumer.lean` (`stageOneThroughTenClosed`) |
| Theorem 9.4 Universal formation (F) | `Formation/Declarations/Cumulative/FixedMother/{Formation,CompleteRealization}.lean` (`root_admission_fixed_mother_complete_realization`); `LivingLawTotalRealityKernel.lean` (`TotalRealityAt.noMagicBit`) | `WorldRealization`, `InquiryRealization`, `ProcessRealization`, Total Reality transfer |
| Corollary 9.5 Physical runtime (F) | `Lean/docs/audits/physics/source-uniqueness/MotherFixedSourceRealizationConsumer.lean` | `original_physical_seal_and_whole_law`, `original_physical_tick_and_history` (step $16\to17$ & all depths) |

### C.9 Three-Step Proof Mechanism of Theorem 9.4 (Universal Formation and Complete Recovery)

1. **Finite separating observations and pointwise uniform density**: for any finite subset $F\subset X_r$, choosing one separating address per distinct pair in $F$ makes zero-padded observation injective on $F$. Given any $f:X_r\to\mathbb S$, prefix $b\in\mathbb N$, and $\varepsilon>0$, the mother finite-evaluation theorem at visit $10+c$ produces $p\in\mathsf{Prog}_r$ satisfying
   $$\bigl|L_r(p,x)(j)-f(x)(j)\bigr|<\varepsilon\qquad(\forall x\in F,\ 0\le j<b).\tag{C.1}$$
   Since $(F,b,\varepsilon)$ parametrizes basic uniform neighbourhoods, $\mathcal R_r$ is dense in $(X_r\to\mathbb S)$. The uniform completion extension
   $$\mathsf{read}_r:\mathcal M_r\longrightarrow(X_r\to\mathbb S),\qquad \mathsf{read}_r(\iota_r(L_r(p)))=L_r(p)\tag{C.2}$$
   is a closed uniform embedding with dense range, hence bijective (using indicator observations $\mathbf1_{\{a\}}$ at base rank and $(\text{base key}\times\text{output index})$ at higher rank, importing zero continuity hypotheses on $f$).
2. **Internal rank sizing via process disjoint union and full-space left inverse**: for any native macro-process $P$, form the disjoint union
   $$\mathcal U_P=\operatorname{State}(P)\ \sqcup\ \coprod_{s\in\operatorname{State}(P)}\operatorname{Query}\bigl(P.\mathsf{stateAt}(s)\bigr),\tag{C.3}$$
   generating faithful addresses internally across all states (including unvisited or observationally coincident states), five-branch query compilations, initial state, and successor graph; stream pairing and projection yield the full-space left inverse (9.5).
3. **Registered factory reconstruction and all-depth transport**: feeding combined material into the process factory constructs $P_m$ with $\mathcal R_{\rm proc}(P_m)=P$ (Eq. (9.3)), whose state bijection $T_m$ transports designated activations, whole laws, and every runtime step $(s_n,\tau_n,\mathsf{next}(\tau_n))$ across all $n\in\mathbb N$ (Eq. (9.4)).

## Appendix D Fixed Revisions, Verification Credentials, and Empirical Protocols

**D.1–D.3 and D.5–D.6 Foundational Revisions, Kernel Certifications, Fock, and Matrix Receipts.**

- **Revisions H and F**: §2–§6.2, §8–§9.2, Theorem 3.3, and Theorems 4.6–4.7 are fixed at Homework **H** = `e60a86058abcb74b7f2225f2383c182be8343785` (Lean `v4.33.0`, Mathlib `db584cd6d46c92f209a44c0f1c829460d327499d`); Theorem 9.4–Corollary 9.5 are fixed at **F** = `cde4b910929d9bc57554aa56f6ade116bc3b8675` (byte-identical across all 72 shared physics files).
- **Strict kernel certifications**: H preserves `--trust=0 -DwarningAsError=true` builds and three-axiom closures across Stage 1–10, Stage 9G, Stage 9DEF, Stage 10 Bell, and global gauge spectrum; F preserves `MotherFixedSourceRealization.certification.json` (64 own declarations, 5 zero-bypass consumers, 329 unchanged production modules, positive/negative controls).
- **256-dim Fock and core matrix cross-checks (D.3, D.5; former D.6 credential stratification promoted to Table 4 in §10.4)**: `quantization-current` passes 4 modules (86 declarations, 3 standard axioms) and 812 numerical evaluations across 40 families on $\mathbb C^{256}$ (max residual $8.882\times10^{-16}$, dark-moment $+0.5$ vs. $-0.5$ hit); `check_core_identities.py` passes 501 checks across 20 groups (max residual $1.554\times10^{-15}$, `core-identity-checks.json`).

### D.4 Reproducible Protocols and Frozen Data for Historical Nominal Device Controls

1. **ETH superconducting Bell archive and frozen lock**: `Bell_Test_ETHZ_2023_rawData` [8,9] (DOI `10.3929/ethz-b-000624026`, archive SHA-256 `2d39d1b6898480d3de0134e2d55ac3faee87af32c8db5bc6fdf6fa6997296909`, main event file SHA-256 `5881b901b0d4a148104b14eadabe80c4f742026e2a120397af23013c2113a848`), first $100,000$ raw trials (rows 4–100003, zero filtering). The historical nominal lock (`5d32d1576`) pairs ideal $\psi^+$ with $\theta_{\rm geo}=-\pi/4$:
   $$q_{ab}(x,y)=\frac{1+xy\,C_{ab}}4,\qquad C_{ab}=\cos\!\left(\theta_{\rm geo}+(b-a)\frac\pi2\right),\qquad (C_{ab})=\frac1{\sqrt2}\begin{pmatrix}1&1\\-1&1\end{pmatrix}.\tag{D.1}$$
2. **Anytime supermartingale and six-radius outcomes**: across $\varepsilon\in\{0,0.01,0.02,0.05,0.1,0.2\}$, with $u_{\varepsilon,c}(o)=\min\{1,q_c(o)+\varepsilon\}$ and seven-component equal-weight mixture of $v\in\{0,\tfrac14,\tfrac12,\tfrac34,0.9,1\}$ plus Krichevsky–Trofimov predictor,
   $$E_{\varepsilon,t}=\frac17\sum_{j=1}^7\prod_{n=1}^{t}\frac{r_{j,n,c_n}(o_n)}{u_{\varepsilon,c_n}(o_n)},\qquad p_{{\rm any},\varepsilon}(t)=\min\!\left\{1,\frac1{\max_{0\le s\le t}E_{\varepsilon,s}}\right\}.\tag{D.2}$$
   Independent 80-bit recomputation across all $100,001$ prefixes (max $\log E$ discrepancy $5.59\times10^{-10}$) rejects $\varepsilon=0,0.01,0.02,0.05$ at $\alpha=0.025$ ($\log E=46803.6234$, $p_{\rm any}\approx2.7838\times10^{-20327}$ at $\varepsilon=0$), while $\varepsilon=0.1,0.2$ are not rejected (setting totals $(0,0):25222$, $(0,1):24878$, $(1,0):24888$, $(1,1):25012$). Post-hoc `bridge-review` confirms that the authors' $S=E_{00}-E_{01}+E_{10}+E_{11}=2(\cos\delta+\sin\delta)$ evaluates to $S=0$ at $\gamma=0,\theta_{\rm geo}=-\pi/4$.
3. **NIST 2015 nominal two-mode replay**: fixed at AB under `Verification/physics/stage10/independent-bell/nist-real/nominal-replay/` (`criterion-r0003.md`, efficiency half-width $0.003$): around $(r,\theta_0,\theta_1)=(0.315463895,4.954737358^\circ,-27.232869633^\circ)$ plus 16 corners, all five published nominal parameters fall outside the predeclared band (`REPLAY_DEVIATION_EXCEEDS_PREDECLARED_BAND`; the earlier $0.0003$-half-width `replay.json` is retained as historical record).

**D.7 Declaration Index for v1/v2 Quantum Construction and Full-Field Return.** Fixed commit aliases: **AB** = `fde5c14df36b6064c87064acd20830d3df0500bb`, **AC** = `b67aa48c75b3cd7738766ed40093bb3f7c1d7a1a`, **AD** = `aef0ad2a26199d9fd6da9bc9e7ec1a65636ef63f`, **AE** = `26b91feb6b507fdc3f43be9c429edb63fb9395ef`, **CAP** = `59409a512c435cad5c5113fdedc91a451af88883`, **71e** = `71e94e8261d67cf4849a05eb14ac95aa2f7dcbb9`, **9c73** = `9c73a630ce05bea062ec889b188f5105c0afb796` (with Theorem 6.7(1)(2) carrier programs at `85cb5386ca132818f74d90470d87a252e4a27ea7`, `f9b733928fb5078ac82430b164dabb8696542e64`, `6726f385356cb327e7c158687e6e37f5f086fe71`, `eec031c489f37459742e62a59a26b9866a21caed`, geometric time-budget module at `fa15016c967e1ea50c1fdc3d8e7bf1ec8f7128a6`, and serialized source hashes locked in `canonical_preparation_serialized_source_certification.json`). Paths relative to `Verification/physics/low-energy-phenomenology/` (`A/` = `alpha-source/`, `V/` = `external-composite-decay/`):

| v3 Theorem | Commits | Core producer modules | Proof |
| --- | --- | --- | --- |
| Theorem 6.7 Common $H$ | Early 4, AB | Programs/modules in S1 table; `A/CanonicalPreparationActionCoreDecomposition.lean` (`physical_action_decomposition`) | S1 |
| Theorem 6.8 Clock, $R$, prep. | AB | `A/CanonicalPreparation{EngineProgram,EngineCancellationForces,FullEnergyForm,SourceRemainder,SourcePreparedState,SourceBoundarySequence}.lean` | S2 |
| Theorems 6.9, 6.11 Creation & norm. | 71e, 9c73 | `A/em-identification/{ActualDressedSourcePreparation,PhysicalDressedP286Character,ActualDressedTemporalNormalization,PhysicalDressedWeightedCreation}.lean` | S11.1–S11.2 |
| Theorem 6.10 Full Ward | AB | `A/CanonicalPreparationElectric{PairCurrent,CoreWard,WeightedGraph,PreparedWard}.lean`, `CanonicalPreparationTemporalGlobalCharge.lean` | S4 |
| Theorem 7.1 Mother $H_{289}$ | AD | `A/CanonicalSourcePropagation{OriginalHessianReturn,PreparedMotherEulerReturn}.lean` | S5 |
| Theorem 7.2 Varying field & jets | AB, AC | `A/CanonicalPreparation{SourceNonlinearState,YukawaObservedLimit,HalfDensityCompressionFeed,SpatialFullFormFeed,JointMixedResponse,RawJointFiveTerms}.lean`; `V/Source{HamiltonianSpectralMeasure,BoundedInsertionTime}.lean` | S3 |
| Theorems 7.3, 7.6 Nonlinear & $z^4\Pi$ | 71e, 9c73 | `A/em-identification/ActualDressed{NoetherHalfIntegral,NonlinearPolarization,SignalPencil,GradedSlopePrice,CubicNoetherPrice,CubicStaticPrice,CubicIRFactor,CubicIRReturn}.lean` | S12 |
| Theorem 7.4 Half-axis & inverse | AC, AD, AE | `A/CanonicalPreparation{OriginalPreparedGreen,PhysicalFullHalfAxis,SourceHalfAxisCurrentOperator,SourceCurrentFeedbackAdjugate}.lean`, `CanonicalSourcePropagation{SourceSpectralInverse,ActualNativeHistoryReturn}.lean` | S6 |
| Theorem 7.5 Nine-constraint Schur | 9c73 | `A/em-identification/{ActualEMDressedSchur,ActualDressedFullSchurFlux,ActualDressedHalfSchur,ActualDressedRationalFourier}.lean` | S13 |
| Theorem 7.7 Moving carrier & residue | AE, CAP | `A/CanonicalPreparationSource{MovingCarrier,MomentumContinuation,StaticActualPole,ConstraintRead,NativePoleBalance,NativePolePrice}.lean` | S7 |
| Theorem 7.9 EM & $1/(4\pi r)$ kernel | 71e, 9c73 | `A/em-identification/{ActualEMGaugeCurvature,ActualEMDressedGaugePole,ActualDressedUncutMovingCoulomb,ActualCompositeCoulombDressing}.lean` | S11.3–S11.6 |
| Theorem 7.10 Matched word & tail | AE | `V/SourceClockPhi{NativeMatchedSource,NativeMatchedGammaBudget,RenormalizedSecondGreenTail,MatchedDiffusionSource}.lean` | S8 |
| Theorem 7.11 3-fermion spectrum | 71e, 9c73 | `V/{MixedSpectatorYukawaNonzero,SourceYukawaPositiveCorrection}.lean`, `V/SourceActualFourBlock{HilbertOperator,RealTransferPositive,SignedSector}.lean`; `Lean/scratch/LowEnergyRetardedCouncil/ActualFourBlockResponse/SourceActual*.lean` | S14 |

**D.8 Revisions and Evidence Entry Points for Public Bell Consumers (Propositions 10.2–10.5).** `B/` = `Lean/SaturationMonoid/PhysicsCore/Stage10/Bell/`, `N/` = `Verification/physics/stage10/independent-bell/nist-real/`, `M/` = `Verification/physics/stage10/independent-bell/munich/`:
- **Propositions 10.2–10.3** (AD, AE): `B/{TheoryBlind,ReadoutEffects,ReadoutIdentification,ReadoutResponseBounds,ReadoutAnchors,ReadoutDetectorFiber,ReadoutPulseRealization,SourceHistory}.lean`; `M/criterion-mu0001.1.md` and dual receipts under `M/readout-domain/`.
- **Proposition 10.4** (71e, 9c73 and frozen scientific commits in S15.5): `M/readout-domain/{LateRegisteredAdjoint,FirstReceiptZeroCount,FirstReceiptQuantumFlux,NoCountQuantumGenerator}.lean` and `late-adjoint-bank-first-rha0038.1.json`, `first-receipt-probability-first-rha0039.1.json`, `primal-zero-count-bank-first-rha0041.1.json`, `zero-count-quantum-program-bank-first-rha0042.json`.
- **Proposition 10.5** (AB, AC, AD): `N/observable-closure/` (`PhaseFiber.lean`, `MatchedSource.lean`, `EnvironmentSource.lean`, `criterion-ef0002.md`); `N/nominal-replay/public-review/source-compression/NormalizedSourceBet.lean` and `source-compression-verification.json`.

**D.9 Fixed Revisions and Producer Declarations for New Self-Contained v3 Theorems.** Additional fixed commit aliases: **df4** = Homework `df421ff600085cbc290a7ae946193961bed7c83b` (containing byte-identical modules from `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`), **7e4** = Homework `7e4da746f300b3796b8b18afb26cb0765c29afcb`, **B291** = Homework `fa2085ee1fda4f01f8ff6c50a2a6a5f91fe3cbf5`, and **B300** = Homework `1357a4e92d11d4896f5dcf97206d4f575c35b436`.

| New v3 Result | Commit | Producer modules and core declarations | Written proof |
| --- | --- | --- | --- |
| Theorem 2.2, Prop. 3.2, Theorem 3.3 | H | `PhysicsCore/` producer modules listed in Appendix B.7 | §2.2, §3.1–3.2, App. B.8 |
| Theorem 4.6 Volterra & full-measure $L^2$ | H | `PhysicsCore/StageNineDiracDualFormNativeFixedP506CauchySafeMatterCanonicalAffineVolterra{Recognition,Actualization}.lean` (`canonicalAffinePhysicalTimeL2Output_weakActionZero_iff_fixedPoint`, `CanonicalAffineVolterraDenseReadOccurrence.physicalField_unique`) | S16.1–S16.2 |
| Theorem 4.7 All-order energy closure | H | `PhysicsCore/StageNineDiracDualFormNativeFixedP506CauchySafeMatterSymmetricHyperbolicAllOrder{JetProlongation,EnergyClosure}.lean` (`fixedMatterAllOrderForcingJetCLM_apply_of_actionZero`, `exists_fixedMatterAllOrderClosedPointwiseRateBoundOnBox`) | S16.3–S16.4 |
| Theorem 7.8 192/97 Schur, Ward & cone | df4 | `Verification/physics/low-energy-phenomenology/alpha-source/em-identification/ActualSourcePrepared{InactiveSchurReturn,Schur97NoetherFraction,Schur97WardSchur,Schur97WardDeterminant,Schur97WardFactor,Schur97JointCone}.lean` (`actual_source_prepared_em_enclosure_certification.json`) | S17.1–S17.3 |
| Theorem 7.12 4D curvature & $\operatorname{Dom}(H_{\rm time})$ Gram | 7e4 | `Lean/SaturationMonoid/PhysicsCore/YangMills/SourceQuantum/Curvature/Spatial/{Seed,Field,Words,Original}.lean`, `Continuum/Spacetime/Strong/Spatial/{Field,Time}.lean` (`Verification/physics/yang-mills/source-quantum/source_spatial_curvature_receipt.json`) | S17.4 |
| Theorem 9.3(1)–(4) Root seal, authority & fold | H | `Lean/SaturationMonoid/PhysicsCore/StageTenPhysicalRootClosure.lean`, `Stage10/{Authority,Seal,Recovery/Consumer}.lean` (`stageTenPhysicalRootClosure`, `zeroUnregisteredPhysicalAuthorityReceipt`, `completePremiseFold`, `stageOneThroughTenClosed`; §10.4 source unit & coupling bridges in df4: `alpha-source/SourceElectronThomsonIdentity.lean` and `alpha-source/em-identification/{PhysicalNativeEMChargeBridge,ActualDressedEMStandardLongRange,PhysicalN3PoleCoulombPacket}.lean`) | §9.2 |
| Theorem 10.1 Kraus–Born & trace duality | B291, B300 | `Verification/physics/stage10/independent-bell/munich/readout-domain/evidence/source-kraus-word-wave-rha0291/source-r0004/SourceKrausWordWave291.lean` (`sourceIsometry`), `source-endpoint-recycling-rha0300/density-source-r0001/SourceEndpointDensity300.lean` (`whole_word_trace_hasSum`, `densityFlow_positive`, `densityFlow_trace_nonincreasing`) | S18.1–S18.2 |

Direct consumers for §10.4 also include `sourceThomsonMatching_return` in `SourceThomsonMatchingConsumer.lean`, `actual_full_root_coupling_balance` in `ActualDressedEMCorrectedRootFluxConsumer.lean`, and the original action-current and complete-contact checks in `PhysicalN3PoleCurrentAudit.lean`. The public selection records the original compile dependencies by group. The common electromagnetic base is fixed at `2cccd55f330ed2465ba8d43779e6f75e42274e37`.

<!-- code-availability:begin -->
## Code and data availability

The third-edition proof selection is fixed at H0mework commit `a5e774a4cdef1c5bedc7426efedab7ba20a417ac`. The [claim map](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-map.json) and [source selection](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/checks/physics-third-edition-selection.json) bind the full declaration types, direct consumers and original receipts for P45–P47. The [acceptance record](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-readiness.md) and [reproduction guide](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-reproduction.md) record the build and trust audit for this edition.

Proofs and consumers inherited from the first edition are fixed at H0mework commit `234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a`; the [first-release map](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/docs/first-release-map.json) and [first-release reproduction guide](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/docs/first-release-reproduction.md) retain their original scope.

Second-edition additions are registered at H0mework commit `b9d66048342b1a5aeac3e112d920ed85401bb20a`; per-claim provenance and public archive bindings are recorded in the [second-edition map](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/second-edition-map.json), [readiness report](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/second-edition-readiness.md), and [published source-binding manifest](https://github.com/Sapientropic/H0mework/blob/e9734c69f38cf03b79859a1108ae23a5663a0495/docs/assets/paper-source-binding-b9d66048.json) (source cap Homework `9c73a630ce05bea062ec889b188f5105c0afb796`). Third-edition (v3) theorems on spectral selection, gravity–gauge nonseparability, four-leg critical equivalence, Volterra / all-order energy closure, and zero unregistered physical authority come from the fixed Homework commit H used for the first edition (`e60a86058abcb74b7f2225f2383c182be8343785`); the 192/97 electromagnetic fraction uses the collected sources at Homework `df421ff600085cbc290a7ae946193961bed7c83b` with the dependency versions of the original certification. Whole-word Kraus–Born isometry and open recycling density trace duality are fixed at B291 and B300 respectively, and four-dimensional continuum curvature strong integration is fixed at Homework `7e4da746f300b3796b8b18afb26cb0765c29afcb` (Appendices B.7, D.9, and Supplement S16–S18).

The toolchain and reproduction commands for the second-edition selection are documented in the [edition reproduction guide](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/edition-reproduction.md): run `python3 tools/edition_release.py --edition second verify-map` to verify map identities, and use the `build` and `trust` subcommands for package builds and full dependency-closure audits. The H0mework proof material is licensed under Apache-2.0; third-party attributions and reversible public transformations are documented in [NOTICE](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/NOTICE) and [evidence publication](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/evidence-publication.md).
<!-- code-availability:end -->

## References

1. C. N. Yang, R. L. Mills. Conservation of Isotopic Spin and Isotopic Gauge Invariance. *Physical Review*, 96(1):191–195, 1954. DOI: 10.1103/PhysRev.96.191.
2. S. Deser. Self-interaction and gauge invariance. *General Relativity and Gravitation*, 1:9–18, 1970. DOI: 10.1007/BF00759198. Author reprint: arXiv:gr-qc/0411023.
3. J. F. Plebański. On the separation of Einsteinian substructures. *Journal of Mathematical Physics*, 18(12):2511–2520, 1977. DOI: 10.1063/1.523215.
4. H. Tasaki. *Introduction to the “second quantization” formalism for non-relativistic quantum mechanics: A possible substitution for Sections 6.7 and 6.8 of Feynman’s “Statistical Mechanics”*. arXiv:1812.10732, 2018; v5, 2023.
5. J. F. Clauser, M. A. Horne, A. Shimony, R. A. Holt. Proposed Experiment to Test Local Hidden-Variable Theories. *Physical Review Letters*, 23(15):880–884, 1969. DOI: 10.1103/PhysRevLett.23.880.
6. K. G. Wilson. Confinement of quarks. *Physical Review D*, 10(8):2445–2459, 1974. DOI: 10.1103/PhysRevD.10.2445.
7. L. Smolin. The Plebanski action extended to a unification of gravity and Yang–Mills theory. *Physical Review D*, 80:124017, 2009. DOI: 10.1103/PhysRevD.80.124017. arXiv:0712.0977, v2, 2008; compared here with §2, Eqs. (4), (26), (31)–(35).
8. S. Storz et al. Loophole-free Bell inequality violation with superconducting circuits. *Nature*, 617:265–270, 2023. DOI: 10.1038/s41586-023-05885-0.
9. S. Storz. *Loophole-free Bell inequality violation with superconducting circuits* [Dataset]. ETH Research Collection, 2023-07-26. DOI: [10.3929/ethz-b-000624026](https://doi.org/10.3929/ethz-b-000624026). Fixed custody hashes and measurement-semantics record in Appendix D.4.
10. L. K. Shalm et al. Strong Loophole-Free Test of Local Realism. *Physical Review Letters*, 115:250402, 2015. DOI: 10.1103/PhysRevLett.115.250402. Public apparatus documentation and Supplemental Material Table S-II used here.
11. W. Rosenfeld et al. Event-Ready Bell Test Using Entangled Atoms Simultaneously Closing Detection and Locality Loopholes. *Physical Review Letters*, 119:010402, 2017. DOI: 10.1103/PhysRevLett.119.010402. Official archive of complete trials: Zenodo record 22936124.
12. R. S. Garthoff. *Optimierte Erzeugung und Nachweis von Atom-Photon-Zuständen zur Verschränkung Räumlich Getrennter Atome*. Masterarbeit, Ludwig–Maximilians–Universität München, 2015. Source: https://xqp.physik.uni-muenchen.de/publications/files/theses_master/master_garthoff.pdf.
13. R. S. Garthoff. *Efficient Single Photon Collection for Single Atom Quantum Nodes*. Dissertation, Ludwig–Maximilians–Universität München, 2021. DOI: [10.5282/edoc.28956](https://doi.org/10.5282/edoc.28956).
14. P. A. M. Dirac. Generalized Hamiltonian Dynamics. *Canadian Journal of Mathematics*, 2:129–148, 1950. DOI: 10.4153/CJM-1950-012-1.
15. B. S. Cirel'son. Quantum generalizations of Bell's inequality. *Letters in Mathematical Physics*, 4:93–100, 1980. DOI: 10.1007/BF00417500.
16. H. Georgi, S. L. Glashow. Unity of All Elementary-Particle Forces. *Physical Review Letters*, 32(8):438–441, 1974. DOI: 10.1103/PhysRevLett.32.438.
17. S. L. Adler. Axial-Vector Vertex in Spinor Electrodynamics. *Physical Review*, 177(5):2426–2438, 1969. DOI: 10.1103/PhysRev.177.2426.
18. J. S. Bell, R. Jackiw. A PCAC puzzle: $\pi^0\to\gamma\gamma$ in the $\sigma$-model. *Il Nuovo Cimento A*, 60(1):47–61, 1969. DOI: 10.1007/BF02823296.
19. C. Bouchiat, J. Iliopoulos, Ph. Meyer. An anomaly-free version of Weinberg's model. *Physics Letters B*, 38(7):519–523, 1972. DOI: 10.1016/0370-2693(72)90532-1.
20. A. H. Chamseddine, A. Connes. The Spectral Action Principle. *Communications in Mathematical Physics*, 186(3):731–750, 1997. DOI: 10.1007/s002200050126. arXiv:hep-th/9606001.
21. T. W. B. Kibble. Lorentz Invariance and the Gravitational Field. *Journal of Mathematical Physics*, 2(2):212–221, 1961. DOI: 10.1063/1.1703702.
22. D. W. Sciama. The Physical Structure of General Relativity. *Reviews of Modern Physics*, 36(1):463–469, 1964 (Erratum: 36:1103, 1964). DOI: 10.1103/RevModPhys.36.463.
23. S. Holst. Barbero's Hamiltonian derived from a generalized Hilbert–Palatini action. *Physical Review D*, 53(10):5966–5969, 1996. DOI: 10.1103/PhysRevD.53.5966. arXiv:gr-qc/9511026.
24. S. Coleman, J. Mandula. All Possible Symmetries of the $S$ Matrix. *Physical Review*, 159(5):1251–1256, 1967. DOI: 10.1103/PhysRev.159.1251.
25. B. S. DeWitt. Quantum Theory of Gravity. I. The Canonical Theory. *Physical Review*, 160(5):1113–1148, 1967. DOI: 10.1103/PhysRev.160.1113.
26. D. N. Page, W. K. Wootters. Evolution without evolution: Dynamics described by stationary observables. *Physical Review D*, 27(12):2885–2892, 1983. DOI: 10.1103/PhysRevD.27.2885.
27. K. Osterwalder, R. Schrader. Axioms for Euclidean Green's functions. *Communications in Mathematical Physics*, 31(2):83–112, 1973; II, *ibid.*, 42(3):281–305, 1975. DOI: 10.1007/BF01645738, 10.1007/BF01608978.
28. M. Born. Zur Quantenmechanik der Stoßvorgänge. *Zeitschrift für Physik*, 37(12):863–867, 1926. DOI: 10.1007/BF01397477.
29. A. M. Gleason. Measures on the Closed Subspaces of a Hilbert Space. *Journal of Mathematics and Mechanics*, 6(6):885–893, 1957. DOI: 10.1512/iumj.1957.6.56050.
30. K. Kraus. General state changes in quantum theory. *Annals of Physics*, 64(2):311–335, 1971. DOI: 10.1016/0003-4916(71)90108-4.
31. V. Gorini, A. Kossakowski, E. C. G. Sudarshan. Completely positive dynamical semigroups of $N$-level systems. *Journal of Mathematical Physics*, 17(5):821–825, 1976. DOI: 10.1063/1.522979.
32. G. Lindblad. On the generators of quantum dynamical semigroups. *Communications in Mathematical Physics*, 48(2):119–130, 1976. DOI: 10.1007/BF01608499.
33. E. Witten. String theory dynamics in various dimensions. *Nuclear Physics B*, 443(1–2):85–126, 1995. DOI: 10.1016/0550-3213(95)00158-O. arXiv:hep-th/9503124.
34. C. Cheung, G. N. Remmen, F. Sciotti, M. Tarquini. Strings from Almost Nothing. *Physical Review Letters*, 136(25):251601, 2026. DOI: 10.1103/cw4p-cqh7. arXiv:2508.09246v2; compared here with Introduction, post-Eq. (5) zero conditions, and Eq. (11).
35. S. Kachru, R. Kallosh, A. Linde, S. P. Trivedi. De Sitter vacua in string theory. *Physical Review D*, 68(4):046005, 2003. DOI: 10.1103/PhysRevD.68.046005. arXiv:hep-th/0301240; compared here with §IIA–C and Eqs. (12)–(14).
36. L. Susskind. The Anthropic Landscape of String Theory. arXiv:hep-th/0302219, 2003 (reprinted in B. Carr, ed., *Universe or Multiverse?*, Cambridge University Press, 2007, pp. 247–266; compared here with §§5–6 of the preprint).
37. R. Bousso. Holographic probabilities in eternal inflation. *Physical Review Letters*, 97(19):191302, 2006. DOI: 10.1103/PhysRevLett.97.191302. arXiv:hep-th/0605263; compared here with Eqs. (2)–(4) and the terminal-vacuum example of Fig. 1.
38. T. Banks, W. Fischler, S. H. Shenker, L. Susskind. $M$ theory as a matrix model: A conjecture. *Physical Review D*, 55(8):5112–5128, 1997. DOI: 10.1103/PhysRevD.55.5112. arXiv:hep-th/9610043.
39. A. Strominger, C. Vafa. Microscopic origin of the Bekenstein–Hawking entropy. *Physics Letters B*, 379(1–4):99–104, 1996. DOI: 10.1016/0370-2693(96)00345-0. arXiv:hep-th/9601029.
40. J. M. Maldacena. The Large-$N$ Limit of Superconformal Field Theories and Supergravity. *Advances in Theoretical and Mathematical Physics*, 2(2):231–252, 1998. DOI: 10.4310/atmp.1998.v2.n2.a1. arXiv:hep-th/9711200.
