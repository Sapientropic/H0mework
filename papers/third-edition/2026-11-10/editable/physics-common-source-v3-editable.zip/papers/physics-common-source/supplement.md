# 补充材料：完整证明

**《从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成》**

**作者：高健（Jian Gao）**

本补充材料给出正文 §4.3（定理 4.6–4.7）、§6.3–§6.5（定理 6.7–6.11）、§7.1–§7.5（定理 7.1–7.12）及 §10.1–§10.2（定理 10.1、命题 10.2–10.5）的完整自足书面证明与核验说明。S1–S9 承载第一版完整量子构造与公开实验证明，S11–S15 承载第二版实际创建外态、非线性半轴微分、九约束 Schur 反馈、四次解析红外返回、涌现长程势、三费米子复合正谱与 120 ns 全门恢复证明，S16–S18 承载第三版（v3）源生 Volterra 唯一认回与对称双曲全阶无导数损失闭合、192/97 电磁消因子分式与四维曲率强积分、以及全词 Kraus–Born 等距与开放循环密度迹对偶的完整书面证明；S10 给出三版命题与证明位置的精确对照。正文 §2–§4.2、§5、§6.1–§6.2、§8–§9 的证明已在正文与附录 A–C（含附录 B.8 的定理 3.3 完整证明与附录 C.9 的定理 9.4 证明机制）中完整给出，此处不重复。

每节末的“形式对应”列出承载该结果的 Lean 4 声明或冻结回执；所在固定提交、完整路径与回执身份见正文附录 B.7、C.8 与 D.7–D.9，公开复现入口见正文“代码与数据可得性”。固定提交别名 **H**、**F**、**AB**、**AC**、**AD**、**AE**、**CAP**、**71e**、**9c73**、**df4**、**7e4**、**B291**、**B300** 的完整 SHA-1 定义见正文附录 D.1、D.7 与 D.9。所有编号定理均在本篇内独立完成决定性推导，不委托给任何未发表同系列稿件。

第三版的完整声明类型、直接消费者与原回执见[固定证明映射](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-map.json)。

证据身份按五类逐条标注：**形式定理**（Lean 4 严格内核验证的声明）、**有限精确计算**（在证明核中逐项判定的有限恒等式，如实说明判定手段）、**固定精确源程序及其独立重算**（固定提交中的精确符号／代数计算程序，各配同一提交下互不共享实现的独立重算）、**双实现数值核验**（两套独立实现各自产生的冻结回执及其误差界）、**统计合同**（带预先登记错误率的随时有效检验）。

---

## S0 共同记号与工具

**S0.1 配置与测试空间。** 固定正源与满足非特征条件的共同作用量 (3.1)：$v_e>0$、$\det h\ne0$、$g_{00}\ne0$、$h^{00}\ne0$、$\det D_9\ne0$ 及四阶时间—电块 $\det\mathscr M\ne0$ 的含源连通分支记为 $\mathscr U_{103}=\mathscr U_q\times\mathscr U_x\times\mathbb R^{36}$，三稳定子截面记为 $\mathscr U_{100}$（S1）。$\mathcal I=\{+,-\}\times\{0,1,2,3\}\times(\Lambda^6\sqcup\Lambda^2\sqcup\Lambda^4)$ 为 504 个 CAR 模式指标，$\mathcal F_{504}=\Lambda^*\mathbb C^{504}$。配置 Hilbert 空间 $\mathscr H$ 由式 (S1.5) 的加权 $L^2$ 直和给出，紧支撑光滑量子测试空间 $\mathcal Q=C_c^\infty(\mathscr U_{100};\mathcal F_{504})$ 在其中稠密。

**S0.2 截断压缩与保留项。** 对有限帧截断指标 $F$（Gauss 酉历史的有限指标），$C_F(p)$ 表示完整原生 Hamiltonian $H_0$ 在动量 $p$ 处对 $F$ 的自伴压缩，$A_F$ 为未截断 Yukawa 算符的保留项，$K_F(p)=C_F(p)+A_F$ 为实际生成元。$C_F$ 保持 $\Lambda^6$ 占据分级，$A_F$ 升一级。记 $T_p(t)=e^{-itK_F(p)}$，$R_p(z)=(K_F(p)-z)^{-1}$（$\operatorname{Im}z\ne0$）。截断指标集按包含关系定向；“对共尾的 $F$ 成立”指沿源滤子在某个终段指标之上的全体 $F$ 成立。

**S0.3 响应点与五因子核。** 一个**响应点** $q$ 携带截断指标 $F$、左／右物质动量 $p_L,p_R$、两个非实谱参数 $z,w$（$\operatorname{Im}z\ne0,\operatorname{Im}w\ne0$）、准备精度 $\varepsilon>0$、有限时间窗 $T$ 及源场曲线。电流读口 $J$ 为母作用一阶变分的量子化，五因子核为

$$\mathcal K_q(t)=T_{p_R}(-t)\,R_{p_R}(z)\,J\,R_{p_L}(w)\,T_{p_L}(t).\tag{S0.1}$$

$\mathbb C^{289}$ 为九组场实变分方向的复化空间，$H_{289}(p)$ 为四复动量 $p$ 处的二阶变分矩阵（S5）。

**S0.4 预解式与 Duhamel 工具。** 自伴算子 $A$ 的预解式满足 $\|(A-z)^{-1}\|\le|\operatorname{Im}z|^{-1}$ 及差公式 $R_p-R_k=R_p(C_F(k)-C_F(p))R_k$；算子范数下的 Duhamel 公式为 $e^{-itB}-e^{-itA}=-i\int_0^t e^{-i(t-s)B}(B-A)e^{-isA}ds$；双腿演化 $\Phi_t(X)=T_{p+k}(-t)XT_p(t)$ 的拉普拉斯 Bochner 积分 $\int_0^\infty e^{-\lambda t}\Phi_t\,dt$ 在多项式增长控制下对一切 $\operatorname{Re}\lambda>0$ 绝对收敛。

**S0.5–S0.6 有限精确恒等式与数据型声明的核查约定。** 文中诸如 $H_{289}$ 的 3071 项字典（系数在 $\mathbb Q(\sqrt2,\sqrt{15})$）、576 项多项式矩阵乘积逆与 289 维矩阵恒等式，均在 Lean 4 证明核中通过典范化表相等（`decide +kernel`）、代数数域标量环运算（`ring`、`norm_num`、`field_simp`、`linear_combination`）与有限指标展开（`fin_cases`）作为严格数学定理判定，不含任何浮点近似。双实现数值款与统计合同款则由互不共享前向计算的两套独立程序在预冻结判据下生成首回执并交叉比对（S9、S15）。

---

## S1 定理 6.7：共同量子 Hamiltonian

**对象与定义域。** 固定正源与满足非特征条件的共同作用量 (3.1)（见 S0.1）。物质配置由完整 252 维旋量—外幂场 $\psi$ 与独立线性对偶 $\chi$ 组成；维数 $61,504,103,100,392$ 均由源表示结构唯一确定。

**(1) 正则载体（61 对 CCR 与 504 模双支 CAR）。**
- *四部门 Legendre 图*：空间度规 $h=e_{\rm sp}^{\mathsf T}\eta e_{\rm sp}$ 在 $\det h\ne0$ 时由显式秩六右逆给出余标架六速度映射
  $$\Pi_e=M_e\dot e+b_e,\qquad Z^{\mathsf T}(\Pi_e-b_e)=0,\qquad \dot e=Q_e(\Pi_e-b_e)+Z\lambda,\tag{S1.1}$$
  其中 $M_e=D_h^{\mathsf T}B_hD_h$，$B_h=(4v_e)^{-1}\operatorname{Hess}_h\det h$，$Q_e=R_hB_h^{-1}R_h^{\mathsf T}$，$Z$ 的十列编码四条时间约束与六条内部 Lorentz 主约束。标量动量为 $\Pi_\phi=h^{00}(\dot\phi+\rho^{70}_{A_0}\phi)+b_\phi$（$h^{00}\ne0$）；规范空间动量逆为 $K_E^{-1}=-\tfrac{\sigma v_e}{g_{00}}(g^{-1})_{\rm sp}$（十二个时间分量动量为零）；物质共轭动量为 $p=-i\chi E$（$E=v_e(e^{-1})^0{}_a i\gamma^a\otimes I_{63}$，不预先令 $\chi=\psi^\dagger$）。共同正则一形式为
  $$\Theta=\Pi_e\cdot\delta e+\Pi_\phi\cdot\delta\phi+\sum_i\Pi_A^i\cdot\delta A_i+\operatorname{Re}(ip\,\delta\psi),\tag{S1.2}$$
  共同十二维 Gauss 约束为 $\mathcal G=\mathcal G_A+\Pi_\phi^{\mathsf T}\rho^{70}\phi+\operatorname{Re}(ip\,\rho^{252}\psi)$。
- *61 对标量 CCR*：规范—标量轨道矩阵 $O\in\mathbb R^{70\times12}$ 的秩为 $9$（源点 $D_9=O_b^{\mathsf T}O_b$ 行列式为 $256$）；取 $\ker O^{\mathsf T}$ 的正交实基 $R\in\mathbb R^{70\times61}$，写 $\phi=v+Rx$、$\Pi_\phi=R^\vee\pi+O_b\zeta$（$R^\vee=R(R^{\mathsf T}R)^{-1}$），因 $O_b^{\mathsf T}R=0$，$\Theta$ 的标量部分精确拉回为 $\pi\cdot\delta x$，直接给出 61 对标准 CCR $[x_j,-i\partial_{x_k}]=i\delta_{jk}$。
- *504 模双支整体 CAR*：物质一形式 $\operatorname{Re}(ip\,\delta\psi)$ 的实正则坐标 $(\operatorname{Re}\psi,\operatorname{Im}\psi)$ 与共轭动量 $(-\operatorname{Im}p,-\operatorname{Re}p)$ 构成两个独立实支，整体复化后在指标集 $\mathcal I$（$|\mathcal I|=504$）上一次量子化为标准 CAR 代数；双支规范流矩阵为 $Q_a=\operatorname{diag}(i\rho_a^{252},i\overline{\rho_a^{252}})$，物质 Hamiltonian 矩阵 $M$ 实现为 $\operatorname{diag}(M,-\overline M)$。
- *103 维共同能量域*：余标架、标量切向与规范空间势共 $6+61+36=103$ 个玻色坐标，四部门能量在稠密核
  $$\mathscr D_{103}=C_c^\infty(\mathscr U_{103};\mathbb C)\otimes\mathcal F_{504}\tag{S1.3}$$
  上良定相加并保持任意有限次有序复合（含 944 个非零交叉主部条目与 61 个 Yukawa 力方向）。

**(2) 三稳定子截面、第二类测度相消与共同 Hamiltonian。**

> **引理 S1.1（核稳定子对易律）。** 张成 $\ker O$ 的三个稳定子生成元 $S_a$（满足 $[S_a,S_b]=-2\epsilon_{abc}S_c$）在 $\mathscr D_{103}$ 上生成的算符 $\widehat G_a$ 满足 $[\widehat G_a,\widehat H]=0$，其共同零核非零且对四部门能量的任意有限有序复合不变。

*证明。* 由协变恒等式 $V_aD_9=-C_a^{\mathsf T}D_9-D_9C_a$ 推出逆导数律 $V_a F=C_a F+FC_a^{\mathsf T}$（$F=D_9^{-\mathsf T}$），代入有序动量平方展开后法向系数变分与流矩阵变分逐槽抵消；规范与余标架部分由原 Gram 不变性及旋量—外幂通约性给出；稳定占据态 $|(7,259)\rangle$ 乘紧支撑函数给出非零核见证。∎

在源点处，三个规范枢轴的局部轨道矩阵行列式为 $\det M_*=-54\sqrt2/125\ne0$，逆函数定理给出 100 维局部开截面 $\mathscr U_{100}$，延拓 $\mathcal E$ 与限制 $\mathcal R$ 满足 $\mathcal R\mathcal E=I$ 及 $\widehat H\mathcal E=\mathcal E H_{100}$。轨道 Jacobian 给出正截面权 $\rho_3(z)=8a_1^2a_{12}>0$（源点值 $54\sqrt2/125$）；九个第二类标量约束的基体积、法向动量高斯积分与第二类行列式三因子乘积精确相消：

$$\frac1{256}\cdot\frac{256}{|\det D_9|}\cdot|\det D_9|=1,\tag{S1.4}$$

故约化配置测度恰为 $\rho_3$。赋予占据数 $m$ 扇区体积权 $v^{m+2}$ 后，配置 Hilbert 空间定义为

$$\langle f,g\rangle=\sum_{w\subset\mathcal I}\int_{\mathscr U_{100}}\overline{f_w(z)}\,g_w(z)\,\rho_3(z)v(z)^{m+2}\,dz,\qquad \mathscr H=\bigoplus_{w\subset\mathcal I}L^2\bigl(\mathscr U_{100},\rho_3 v^{|w|+2}dz\bigr),\tag{S1.5}$$

半密度映射 $(Uf)_w=\rho_3^{1/2}v^{1+m/2}f_w$ 为到平坦 Lebesgue 测度的满射等距。

> **引理 S1.2（形式伴随对与最小闭图）。** 在稠密不变核 $\mathscr D_{100}$ 上，非 Yukawa 能量 $H_0$ 形式对称；完整 $H=H_0+Y$ 与独立伴随 $H^\sharp=H_0+Y^\dagger$ 满足 $\langle f,Hg\rangle=\langle H^\sharp f,g\rangle$，二者均可闭且各自拥有单值最小图闭包；双支共 $196\times2=392$ 模共同双侧 Yukawa 零核子空间约化 $H_0$ 并使限制算符对称。

*证明。* 逐项分部积分核实 $H_0$ 对称性（余标架动量与正规积在权 $v^{m+2}$ 下精确自伴配对）；只有单向 $Y$ 在取伴随时变为 $Y^\dagger$（在双粒子态 $|144,396\rangle$ 上源点 $\|Y|144,396\rangle\|^2=4N^2=216/125\ne0$）。若 $f_n\to0$ 且 $Hf_n\to g$，则对任意 $h\in\mathscr D_{100}$ 有 $\langle h,g\rangle=\lim_n\langle H^\sharp h,f_n\rangle=0$，由 $\mathscr D_{100}$ 稠密得 $g=0$，证得 $H$（同理 $H^\sharp$）可闭。经半密度变换 $UHU^{-1}=\operatorname{Op}_W(\sigma_0+Y)$（余标架散度修正与半密度势合并为 $N(3\mathrm{Number}^2+18\mathrm{Number}+20)/(16v)$），生成全部 100 对 CCR 与 504 对 CAR 正规积运动。∎

**(3) 配置耦合作用认回。** 原作用—力系数为标量 Gram 生成的 $4W(q)\ge4$，实际核 $K(p)$ 在 $\mathbb C^{289}$ 符号字典上逐槽满足

$$S_{\rm phys}(p)+Y=S_{\rm nat}+S_{\rm cf}+K(p)-K_{\rm ret},\tag{S1.6}$$

即正文式 (6.3)。

**形式对应。** 定理 6.7(1)(2) 的子结论固定于约束局部量子化较早四提交（`ecd/` = `Verification/physics/low-energy-phenomenology/external-composite-decay/`，完整提交哈希见正文附录 D.7）：

| 子结论 | 固定提交 | 生产口与独立核验 | 证据类别 |
| --- | --- | --- | --- |
| 61 对 CCR、103 维共同域、504 模双支 CAR | `85cb5386...` | `ecd/source_{scalar_gauss_reduction,joint_local_quantum}.py` 及同名 `independent_*.py` | 固定精确源程序＋独立重算 |
| 三稳定子对易律（引理 S1.1）与相空间枢轴 | `f9b73392...` | `ecd/source_{quantum_stabilizer,stabilizer_phase_reduction}.py` 及 `independent_*.py` | 固定精确源程序＋独立重算 |
| 量子截面、第二类相消 (S1.4)、半密度 $\mathscr H$、伴随闭图（引理 S1.2）与 Weyl 表示 | `6726f385...` | `ecd/{SecondClassReduction,SourceQuantumConfigurationHilbert,SourceQuantumHalfDensityHilbert,FockFilteredWords,SymmetricGraphClosure,AntiunitaryDefectPair}.lean`；`ecd/source_{quantum_gauss_section,gauss_section_measure,full_gauss_section,yukawa_reducing_carrier,common_weyl_symbol}.py` 及 `independent_*.py` | Lean 形式定理＋固定精确源程序及独立重算 |
| 100 对 CCR 与 504 对 CAR 正则运动端口 | `eec031c4...` | `ecd/JointCCRCarPorts.lean`；`ecd/source_joint_ccr_car_ports.py` 及 `independent_*.py` | Lean 形式定理＋固定精确源程序及独立重算 |

定理 6.7(3) 作用认回：`alpha-source/CanonicalPreparationActionCoreDecomposition.lean`（`physical_action_decomposition`）及 `CanonicalPreparationFieldQuantization{Symbols,Core,Contacts}.lean`（Lean 形式定理，提交 AB）。

---

## S2 定理 6.8：全阶时钟、完整固定 $R$ 与同一源准备

**对象与定义域。** 定理 6.7 的载体 $\mathscr H$、稠密域 $\mathscr D_{100}$、$H=H_0+Y$，以及源支撑正锥上可逆的四阶时间主力 Jacobi 矩阵 $J_4$。

**(1) 全阶时钟递推。** 第 $k$ 阶时钟为四时间方向、长 $k+1$ 槽的符号族，零阶取源时钟初值，递推步定义为

$$C_{k+1}(a,\mathrm{last})=-\sum_b (J_4^{-1})_{ab}\,R_{k+1,b},\tag{S2.1}$$

其中 $R_{k+1,b}$ 由已付低阶的 42 个阶槽函数、有序 Moyal 词与 13 个时间叶组成。

> **引理 S2.1（力消去与低阶保持）。** 对每个 $k\ge0$，$C_{k+1}$ 在前 $k+1$ 个槽上与 $C_k$ 恒等，且第 $k+1$ 阶四个后继力在源支撑闭集上满足 $r+J_4(-J_4^{-1}r)=0$，同时生成全部 100 个方向的有限阶导数预算。∎

**(2) 完整固定 $R$。** 在 Schwartz 输入上，完整能量二次型分解为主部加可积高阶尾：

$$\mathcal E_B(g,f)=\mathcal E_{\rm prin}(g,f)+\mathcal E_{\rm tail}(B;g,f),\qquad R=E_{\rm tail}-C_{\rm src}.\tag{S2.2}$$

> **引理 S2.2（$R$ 的有界自伴性与 Weyl 回读）。** 能量尾平移核 $k(x,y)$ 满足行、列绝对积分有限界 $S_1,S_2$，由 Schur 检验给出 $\|E_{\rm tail}\|\le\sqrt{S_1S_2}$，故 $R$ 有界自伴且 $\|R\|\le\|E_{\rm tail}\|+\|C_{\rm src}\|$；对一切标量测试函数 $g,f$，闭主部因子 $A$ 满足
> $$\langle Ag,Af\rangle+\langle g,Rf\rangle=\mathcal E_B(\check g,\check f),\tag{S2.3}$$
> 且 $R$、增广源算子 $\mathcal T$ 与源能量 $E$ 均不依赖准备精度 $\varepsilon$。∎

**(3) 同一源准备与双残差归零。** 令有界正单射预解式为 $B=(\mathcal T+1+\|R\|)^{-1}$，由于 $\|B\|\in\sigma(B)$，定源能量为

$$E=\|B\|^{-1}-\bigl(1+\|R\|\bigr).\tag{S2.4}$$

> **引理 S2.3（11 字段同一准备点）。** 对每个 $\varepsilon>0$，由 $B$ 在谱端点 $\|B\|$ 处的近似本征向量经 $B^{-1}$ 还原得到定义域点 $x_\varepsilon$，同时满足单位背景 $\|v_\varepsilon\|=1$、近谱界 $\|\mathcal Tx_\varepsilon-Ex_\varepsilon\|<\varepsilon$、弱形式恒等式、原生 Yukawa 荷 $-1$、八条受控外腿、双时—频率收敛及几何截断界
> $$\|Y_{\rm closed}v_\varepsilon-\mathrm{cut}_n(v_\varepsilon)\|\le(915/916)^{n+1}\cdot 916\cdot b.\tag{S2.5}$$
> 取 $\varepsilon_n=1/(n+1)$ 时，固定 $(\mathcal T,R,E)$ 下的近谱残差与全 Yukawa 截断残差沿同一序列 $\{x_{\varepsilon_n}\}$ 同步趋于零。∎

**形式对应。** `alpha-source/CanonicalPreparationEngineProgram.lean`（`sourceEngine_generated`、`sourceEngine_preserves`）、`CanonicalPreparationEngineCancellationForces.lean`（`sourceEngineForces_successor_zero`）、`CanonicalPreparationFullEnergyForm.lean`（`actual_closed_form_complete_energy`）、`CanonicalPreparationSourceRemainder.lean`（`sourceRemainder_selfAdjoint`、`sourceRemainder_readback`）、`CanonicalPreparationSource{PreparedState,BoundarySequence,CausalState,NonlinearState}.lean`（`sourcePreparation_exists`、`preparationSequence_residual`、`preparationSequence_yukawa_residual`）。提交 AB。

---

## S3 定理 7.2：真变场响应、谱测度与 0/1/2 阶射流截断交换

**对象与定义域。** 定理 6.7–6.8 的载体、固定 $R$、准备序列 $x_\varepsilon$ 及经源坐标切片参数化的光滑场曲线。

> **引理 S3.1（有限保留集与截断射流逐点终站）。** 对每个固定场曲线、动量 $p$、有限帧 $F$、非实谱点 $z$ 与实参数 $r$，保留项作用仅落在依赖 $(F,p)$ 的有限保留指标集上；故存在阈值 $N$，当截断阶 $n\ge N$ 时，第 $n$ 阶 Yukawa 射流 $Y_n$ 与未截断 $Y_\infty$ 作为有限维算子精确相等，预解式、电流、接触、插入与逆接触五项的 0、1、2 阶射流随之在范数拓扑下收敛至对应未截断算子。∎

> **引理 S3.2（准备态读回与射流极限交换）。** 完成外腿与截断预解式的内积联合连续性将引理 S3.1 的收敛传递至准备态响应及全部 36 个曲率读数的值、一阶导数与二阶导数，使求导与 $n\to\infty$ 撤去截断极限精确交换。∎

**决定性推导。**（1）106 维逆沿场曲线输运 Gauss 密度 $Jv^{m+2}$ 与半密度比前两阶导数，保持分级压缩 $\sum_g P_g P_F H_{\rm phys}P_F P_g$，给出 289 维场响应向量与一阶 $-RJR$、二阶接触射流；移动纤维积分中的密度导数由同一输运恒等式精确消去。（2）对阻尼 $\gamma>0$，源生非线性半径 $r_*$ 内的拉普拉斯响应满足显式二阶泰勒余项
$$\bigl\|\Phi(r)-\Phi(0)-r\Phi'(0)\bigr\|\le L^2\,s(f,g,\psi,p,n,\gamma)\,m(\gamma)\,|r|^2\,\|u\|^2.\tag{S3.1}$$
（3）由引理 S3.1–S3.2 合取得证。（4）对自由生成元 $H_0$ 与核输入 $g$，源滤子各有限级的通道平方范数和恒为 $\|g\|^2$，投影相容性生成唯一正有限谱测度 $\mu_g$（同时读取非实预解二次振幅与偶阶能量矩）；对任意有界插入 $A$ 与 $\mu>0$，复迟滞振幅在实频轴上 $L^1$ 收敛，逆 Fourier 变换给出全实时间一致收敛。

**形式对应。** AB：`alpha-source/CanonicalPreparationSourceNonlinearState.lean`、`CanonicalPreparationYukawaObservedLimit.lean`（`observed_{first,second}_exchange`、`curvature_{first,second}_exchange`）、`CanonicalPreparationHalfDensityCompressionFeed.lean`；`external-composite-decay/Source{HamiltonianSpectralMeasure,BoundedInsertionTime}.lean`。AC：`CanonicalPreparation{SpatialFullFormFeed,JointMixedResponse,RawJointFiveTerms,OriginalPreparedGreen,PhysicalFeedbackField}.lean`。

---

## S4 定理 6.10：完整荷—电流 Ward 恒等式与同一准备

**关键引理。**

> **引理 S4.1（单次 CAR 正规序的对纤维展开）。** 对任意模式维数上的复矩阵 $A,B$，二次量子化映射 $Q(A)=\sum_{i,j}A_{ij}c_i^\dagger c_j$ 满足
> $$Q(A)Q(B)=Q(AB)+\Pi(A,B),\qquad \Pi(A,B)=\sum_{i,j,k,l}A_{ij}B_{kl}\,c_i^\dagger c_k^\dagger c_l c_j,\tag{S4.1}$$
> 且四算符对纤维项 $\Pi(A,B)$ 与一切粒子数权重算符对易，在单粒子扇区上因两个湮灭算符连乘恒为零而满足 $\Pi(A,B)\big|_{N=1}=0$。

*证明。* 展开 $c_j c_k^\dagger=\delta_{jk}-c_k^\dagger c_j$ 与 $c_j c_l=-c_l c_j$ 直接重排即得。∎

**决定性推导。**（1）在每个配置点纤维上对动量矩阵 $P_k(z)$ 与荷矩阵 $Q_a$ 应用引理 S4.1，立得正文式 (6.5) $P(k)Q_a=J_{\rm sp}(k,a)+J_{\rm pair}(k,a)$ 及单粒子扇区 $J_{\rm pair}=0$。（2）未投影全交换子精确保留四通道：
$$[Q_a,H_{\rm full}]=J_{\rm cfg}(a)+J_{\rm sp}(a)+J_{\rm pair}(a)+J_Y(a),\tag{S4.2}$$
在有限截断 $(n,F)$ 上显式保留 $\Delta_n^Y(Q_a f)-Q_a\Delta_n^Y(f)$ 与压缩缺陷，共尾 $F$ 上压缩缺陷归零，双腿预解响应由同一准备点 $x_\varepsilon$ 的八条外腿与 36 个曲率读口读取，满足一致范数界
$$\|\mathrm{resp}\|\le\|x\|\bigl(c_a b_n(w)+b_n(z)c_a+|z-w|v_a(n,z,w)\bigr)\|y\|.\tag{S4.3}$$
（3）十二个时间方向生成有界全局荷 $Q$，裸生成元与保留核沿场曲线的 $-rQ$ 变化精确抵消，106 维原生轨道联合闭图给出 $\sum_i P_i^\dagger(c_i f)=-Q$。

**形式对应。** `alpha-source/CanonicalPreparationElectric{PairCurrent,CoreWard,WeightedGraph,PreparedWard}.lean`、`CanonicalPreparationTemporalGlobalCharge.lean`。提交 AB。

---

## S5 定理 7.1：母作用的二阶变分认回同一 $H_{289}$

> **引理 S5.1（光滑性与四部门二阶密度分解）。** 母局部密度由十二个源支撑节点在指定解处光滑生成，其 Fréchet 二阶变分为对称双线性型，按引力（234 项）、规范（406 项）、标量（220 项）与 Dirac—独立对偶（790 项）分解为 1650 个二阶密度单项式，全部 95 个常量回归原源系数。

> **引理 S5.2（3300 个双腿 Fourier 贡献归并为 3071 项字典）。** 每个二阶单项式经 Fourier 变换产生两个带符号双腿贡献（共 3300 项），按典范序合并同类项后在系数域 $\mathbb Q(\sqrt2,\sqrt{15})$ 中逐项精确等于原 $H_{289}(p)$ 的 3071 项字典（证明核通过 `decide +kernel` 与代数环恒等式精确判定）。

> **引理 S5.3–S5.4（289 槽全 Euler 拉回与自旋联络 Legendre 五块回读）。** 九组母残差沿全部 289 个实场单位方向的拉回逐槽等于值偏导减动量散度；自旋联络二次型 $\tfrac12\omega^{\mathsf T}\mathcal H\omega$ 在任意非退化标架上的双侧逆 $K$ 由 576 个多项式矩阵乘积验证，代入唯一驻点 $\Omega=-KJ$ 并结合余标架 Legendre 变换与八方向 Clifford CAR 正规序收缩，$\mathrm{Number}^2$ 项精确抵消，逐块恢复动能、电流、自旋平方、粒子数移位 $-\tfrac{9\,\mathrm{lapse}}{8V}\mathrm{Number}$ 与体积势。∎

**形式对应。** `alpha-source/CanonicalSourcePropagation{OriginalHessianReturn,PreparedMotherEulerReturn}.lean`（`nativeActionFourierHessian_original`、`nativeJacobi_original`、`nativeHolonomicEuler_raw`）。提交 AD。

---

## S6 定理 7.4：五因子实电流半轴返回、虚轴谱与因果双侧逆

**对象与母 Green 方程。** 双腿传播束定义为 $\mathcal P_q(\lambda)X=\lambda X+\mathcal A_L X-X\mathcal A_R$（$\mathcal A_L=-iK_F(p+k),\mathcal A_R=-iK_F(p)$）。在活跃 103 维块行列式非零的源生正则域（非空性由源有理点显式右逆矩阵经 `decide +kernel` 证得）上，母 Green 函数满足

$$G=\Xi\,\bigl(D^{-1}+P_a K_{\rm ext}^{-1}\bigr)\,\Xi(-p)^{\mathsf T},\qquad H_{289}\,G=I-\Xi(-p)^{-\mathsf T}P_{\rm null}\Xi(-p)^{\mathsf T}.\tag{S6.1}$$

**(1)–(2) 有限窗分部积分与 57 项多项式半轴。** 五因子核导数展开与加权分部积分给出有限窗恒等式 $\Xi(-\lambda,-ik)^{\mathsf T}\cdot\mathrm{forcing}=\int(\text{时间射流})dt-(\text{终值}-\text{初值})$。因 $C_F$ 保分级而 $A_F$ 升一级，57 次纯升级恒为零，Duhamel 级数精确截断于 56 阶：

$$\|T_p(t)\|\le\sum_{n=0}^{56}\bigl(|t|\cdot\|A_F\|\bigr)^n.\tag{S6.2}$$

对任意 $\operatorname{Re}\lambda>0$，取指数余隙 $\eta=\operatorname{Re}\lambda/8$，正半轴积分绝对收敛且满足 $\Xi(-\lambda)^{\mathsf T}\Phi^+=\Sigma^++B_0$，有限窗误差受控于

$$\bigl\|\Phi^+-\Phi_T^+\bigr\|\le\frac{2}{\operatorname{Re}\lambda}\,c\,e^{-(\operatorname{Re}\lambda)T/2}.\tag{S6.3}$$

**(3) 双半平面逆与虚轴谱。** 正半轴积分 $R^+(\lambda)=\int_0^\infty e^{-\lambda t}\Phi_t\,dt$（$\operatorname{Re}\lambda>0$）与负半轴积分（$\operatorname{Re}\lambda<0$）由分部积分给出 $\mathcal P_q(\lambda)$ 的双侧有界逆，故谱必落在虚轴 $\operatorname{Re}\lambda=0$ 上；零动量转移时恒等算符位于核内且准备态单位范数保证空间非零，故 $0\in\sigma(\mathcal P_q)$。

**(4)–(5) 非自治 Picard 演化与 $3/16$ 因果锚点。** 对源时窗 $[0,T_*)$ 内任意 $C^1$ 历史，Picard 迭代与常数变易积分

$$\partial_a U\big|_{a=0}=T_p(t)\int_0^t T_p(-s)\,\partial_a\mathcal G_a\big|_0(s)\,T_p(s)\,ds\tag{S6.4}$$

给出有序历史源返回。在源生锚点（初值预算 $B\ge0$，读隙 $g=1/[8(1+B)]$，时钟 $\lambda_0=3-g$，读频 $3$）处，更新算子拆为拉普拉斯电流块（$\le 1/16$）与初值块（$\le 1/8$），得

$$\|\mathcal U\|\le\tfrac1{16}+\tfrac18=\tfrac3{16}<1,\qquad \|(I-\mathcal U)^{-1}\|\le\tfrac{16}{13},\tag{S6.5}$$

故 $\det(I-\mathcal U)\ne0$，响应方程拥有唯一不动点。

**形式对应。** AC：`CanonicalPreparation{OriginalPreparedGreen,PhysicalFeedbackField}.lean`；AD：`CanonicalPhysicalLaplace.lean`、`CanonicalPreparationPhysical{FullHalfAxis,ControlledFieldTail}.lean`、`CanonicalSourcePropagation{AxisReadback,SourceSpectralInverse,ActualNativeHistoryReturn}.lean`；AE：`CanonicalPreparationSource{HalfAxisCurrentOperator,NativeFourierHistory,CurrentFeedbackAdjugate,AnalyticRegularPoint}.lean`。

---

## S7 定理 7.7：共同运动载体、动量连续性与原生静态留数

1. **运动八态重叠酉性**：动量 $p$ 处正负手征八态基与静止八态基的重叠阵满足 $U(p)^\dagger U(p)=I_8$（有限维中双侧酉，$U(0)=I_8$），任意 Gauss 算符读出张量满足 $M(p_L,p_R)[A]=U(p_L)^\dagger M(0,0)[A]U(p_R)$。
2. **动量仿射连续性**：$C_F(p)=C_F(0)+v_F(p)$（$v_F$ 连续实线性），预解差满足 $\|R_p(z)-R_k(z)\|\le|\operatorname{Im}z|^{-2}\|v_F\|\|p-k\|$；因有限保留集不含 $p$，$A_F$ 跨动量不变，全部 289 读口与有限拉普拉斯窗一致连续。
3. **穿孔静态域极点与第 114 号色共源**：在 $p_\kappa=(0,i\kappa,0,0)$ 上，$H_{289}$ 的含 $\kappa$ 项领头为 $-\kappa^2 S$；扩展静态块显式可逆给出非空穿孔域，其上未清分母 Green 分解为
   $$G(\kappa)f=\text{接触项}+(-\kappa^2)^{-1}V_0S^{-1}V_0^{\mathsf T}f+\text{98 维正则补空间}.\tag{S7.1}$$
   对实际窗口转移电流，极限 $-\kappa^2\varphi(\kappa)\to E_0\bigl(-\tfrac9{125}\sqrt{30}\mathfrak w,-\tfrac{67}{72}\sqrt{30}\mathfrak w,0,0,0\bigr)$，其中原点权重与带拉普拉斯权的色 Ward 边界满足
   $$\mathfrak w=\tfrac{3\sqrt2}{10}(J_{21}-J_{34})=\kappa_{\rm ct}-\delta_{\rm cf}=-c_{114}(0,T),\qquad |\delta_{\rm cf}|\le\frac{\|D_0F\|\,|T|}{|\operatorname{Im}z|\,|\operatorname{Im}w|},\tag{S7.2}$$
   且由 $R_bL=I_9$ 得 $H_{289}\varphi=w_{\rm win}\iff$ 九维轴零共源为零。

**形式对应。** AE 与 CAP：`alpha-source/CanonicalPreparationSource{StaticPoleDomain,StaticOriginalGreen,StaticActualPole,ModeCurrent,ConstraintRead,ColorBoundaryWard,N1NormalWard,MovingCarrier,MomentumContinuation,FullPoleTensor,ModeContactRead,NativePoleBalance,NativePolePrice,AxisCompatibility}.lean` 及五份 `AuditCanonicalPreparation*.lean`。

---

## S8 定理 7.10：匹配整词预算与重整化端点全频共同尾

记 $H_0=C_F+d_F$，阻尼 $\sigma=\mu>0$，余标架时间尺度 $n=\sqrt{54/125}$，匹配列 $C_3=UD+3iD_cU$。

1. **匹配正源与相位吸收**：由逆扩张对易式 $D_cU-UD_c=2iU$ 展开得 $J_3=R_3+6\sigma\operatorname{Im}\langle C_3w,w\rangle$ 及正文五项正槽下界（且原生压力项满足 $P_3(w)\le 4J_3$）。利用 Cauchy–Schwarz 与 $\tfrac{3n}{8}\|C_3w\|^2\le J_3$ 槽取 $\eta=1/2$，得 $J_3-2R_3\le(96\sigma^2/n)\|w\|^2$，从而正部积分 $\int_{\mathbb R}(J_3-2R_3)_+dt\le\varepsilon$ 在共同指标 $N_0$ 上成立；结合半径分解 $\|v_\varphi\|^2\le(1+\tfrac2{25}\|\mathrm{vac}\|^2)\|w\|^2+J_3/(20n)$，汇总给出系数 $4\times6\times2=48$ 的闭合联合预算界。
2. **重整化第二 Green 全频绝对 $L^1$ 共同尾与扩散分解**：端点 $\mathcal E=\operatorname{Re}\langle k,(H_0-\operatorname{Re}z)Aw\rangle-\|k\|^2\operatorname{Re}(1/z)$ 在共尾 $F$ 上仅读取固定 $H_0^2 g_i$ 输入，利用洛伦兹核积分 $\int_{\mathbb R}(t^2+\mu^2)^{-1}dt=\pi/\mu$（取 $\eta=\varepsilon\mu/(8\pi)$）及 Ritt 三、四阶梯度常数（32、256），证得前向与迟滞两因果口上的 $\int_{\mathbb R}|\mathcal E|d\omega\le\varepsilon$。扩散生成元 $\Gamma_L(X)=\mathcal D^{\mathsf T}X+X\mathcal D-2AXA$ 满足 $\Gamma_L(1)=0,\Gamma_L(V)=18$、噪声核半正定及完整交叉 $\Gamma_L(H_0^2)-\Gamma_L(H_0)H_0-H_0\Gamma_L(H_0)=2\|[A,C_F]f+[A,d_F]f\|^2$，给出精确分解 $R_3=\mathcal E/\sigma^2-D_{\rm ren}/(2\sigma^2)+R_{\rm df}$。

**形式对应。** AE（及 `fa15016c...` 几何体预算）：`external-composite-decay/SourceClockPhi{NativeMatchedSource,NativeMatchedGammaBudget,RenormalizedSecondGreenTail,MatchedDiffusionSource,FixedSourceJets,RittHigherGradient}.lean`。

---

## S9 命题 10.2–10.3、10.5 与 §10.2 的公开实验证据

### S9.1 命题 10.5：公开光学完整源域与联合 95% 严格正 CH

1. **完整光学源域与无限阶 Born 概率闭式（数学定理）**：在双偏振双模压缩真空与共同实 Jones 框架参数 $(m,z,x,r,e)$ 下，共同符号常数 $k=(1-2\lambda)T$、平方界与六个训练区间成立，当且仅当存在合法相位 $\lambda=(1-k/T)/2$ 与恢复快照（相位纤维双向消元定理）；四个单侧均值由显式非奇异线性映射唯一恢复协方差坐标，单侧区间充要于八个半空间的交；$\mathrm{Pol}\otimes\mathrm{Env}$ 六端口对任意透射率 $T_H,T_V\in[0,1]$ 与 $|\xi|\le1$ 生成全光子数效果 $\Gamma_n=O^\dagger X^{\otimes n}O$，匹配情形按占有数对几何级数求和即得精确闭式
   $$Q_{AB}=\frac{1}{1+n_V\,(T_A+T_B-T_AT_B)}.\tag{S9.1}$$
2. **覆盖树、留出越界反证与联合 95% 严格正 CH（双实现核验＋统计合同）**：主、独立两棵覆盖树各重算 $81,922$ 个节点，产生 141 个满足全部六训练置信区间而越出留出区间的实际 Born 反证成员；全十二区间交集上各有 64 个物理源成员（41 正、23 负 CH）。在 $1/20$ 联合随时预算内引入归一化源支持函数
   $$h=\ell\cdot\mathrm{CH}-\varepsilon(1-\varepsilon)\min(c^{A}_{01},c^{B}_{10},c_{11}),\qquad \log E_k=W_{\rm obs}\log a_k+L_{\rm obs}\log b_k-T\log(1+2^{-k}h),\tag{S9.2}$$
   内核定理（`NormalizedSourceBet.lean`）证明 $1+2^{-k}h>0$ 与单步期望界，交叉核查 576 个新区间与 $23,040$ 个条件方向赌注，确认联合 95% 接受域非空（含 8 个显式 $\Gamma/\text{Fock}$ 成员与连续外覆盖），且全体接受源满足严格下界
   $$\mathrm{CH}_{N5}>1.3790180504\times10^{-6}.\tag{S9.3}$$

### S9.2 §10.2 的留出切片、角度有限更新与名义模型反控

1. **两格训练生成切片与 Bob 双角更新**：仅从 00、11 两格取四个单侧中心与 joint00 中心（joint11 取原置信区间，01、10 两整格留出），双独立算法各生成无缝 69 段划分（32 段全合法、35 段排除、2 段边界），留出格完整预测包络落在原置信区间内：
   $$\text{01}:\,[0.00015821397237,\,0.00015855716089],\qquad \text{10}:\,[0.00015026944774,\,0.00015053199993].\tag{S9.4}$$
   四角 $\pm0.05^\circ$ 完整舍入盒上 Bob 双角同减 $0.01^\circ$ 给出双实现严格正增益下界（$>1.99\times10^{-9}$ 与 $>1.69\times10^{-9}$，独立 Fock 端点增益 $3.8493\times10^{-9}$）。
2. **两项历史名义反控**：ETH 超导名义锁零半径拒绝及相位约定缺口见正文附录 D.4；NIST 2015 名义双模重放（概率效率半宽 $0.003$）的预声明最优带为
   $$r\in[0.30515678,0.32571200],\;\; \theta_0\in[4.727559^\circ,5.179646^\circ],\;\; \theta_1\in[-27.552834^\circ,-26.900901^\circ],\tag{S9.5}$$
   文档公布的五个名义值全部落在带外（双实现同判 `REPLAY_DEVIATION_EXCEEDS_PREDECLARED_BAND`）。

### S9.3 命题 10.2：零参 Tsirelson 预测锁、完整读出域与最大同律商

1. **预测锁与 Cauchy–Schwarz 上界**：将 $S_{\rm CHSH}$ 写为四维向量 $u=(\pm a_0^x,a_0^z,a_1^x,\pm a_1^z)$ 与 $v=(b_0^x+b_1^x,b_0^z+b_1^z,b_0^x-b_1^x,b_0^z-b_1^z)$ 的内积，由单位轴条件得 $\|u\|^2=2,\|v\|^2=4$，故 $|S_{\rm CHSH}|\le\sqrt{8}=2\sqrt2$，并在对角轴 $\pm1/\sqrt2$ 上零器件输入达到 $2\sqrt2$。
2. **完整效果双射、全前缀统计通过与最大观测商**：二元读出通道 Bloch 分解与源锥重构给出 12 维紧效果域往返双射；Munich 两次运行共 $20,403$ 条有效试次原序流在联合 $1/20$ 预算下全前缀严格低于阈值 $40$（理想零误差面在 April 第 3974 条越界被拒）；概率律逐项相等迫使四个偏置与两组 $X/Z$ 乘积矩阵全等，秩一因子化证明正则范围内同律族恰由唯一非零反向尺度对 $(s,t)$ 参数化；全置信域有效增益 $\ge0.36579$。

### S9.4 命题 10.3：两探针唯一逆、探测器纤维与 12 态脉冲像

1. **两探针唯一逆与探测器微观纤维**：非零识别行列式下由克莱默法则给出双探针线性响应的双侧逆，唯一恢复全部效果族坐标；正增益探测器效果 $E_{\rm click}=dI+(1-d)\eta J$ 的合法微观对 $(d,k)$ 精确由谱端不等式
   $$0\le d\le m,\qquad M-d\le k\le 1-d\qquad\bigl(m=(1-\mu-g)/2,\ M=(1-\mu+g)/2\bigr)\tag{S9.6}$$
   刻画，逆原子唯一且 $\eta\lambda_{\max}(J)\ge 2g/(1+\mu+g)$。
2. **脉冲可实现充要不等式、Rabi 面积上限与 12 态双实现前向**：亮暗率 $(b,d)$（谱隙 $\gamma=b-d>0$）矩形脉冲可实现当且仅当
   $$(u^2+z^2)(b+d)^2\le(1-\mu)^2\gamma^2,\qquad (u^2+z^2)(2-b-d)^2\le(1+\mu)^2\gamma^2;\tag{S9.7}$$
   在前向不等式 $p_{\max}^{\rm at}\le 7\mathcal A^2/4$ 下，源内定理给出增益上限
   $$g\le\min\Bigl(1,\ \frac{(1+B)\,\eta_{\rm up}\,\bar a}{2-\eta_{\rm up}\,\bar a}\Bigr),\qquad \bar a=\min\Bigl(1,\frac{7A_{\rm up}}4\Bigr),\tag{S9.8}$$
   而 Garthoff 12 态主方程的双实现数值前向核实前向不等式及 32 个角色域脉冲可实现性，并给出六组同律异谱实例；双解析器精确恢复 $41,673$ 条本地记录与双时钟历史保持。

**形式对应（S9.1–S9.4）。** 提交 AB、AC、AD、AE：完整路径与回执见正文附录 D.8。

---

## S10 三版主张与证明位置对照表

为方便对照已发布的 Zenodo 第一版（`phys.P1-P36`）、第二版（新增 `phys.P37-P40`）与当前第三版（v3，消除 `a/b` 补丁号并补入七项核心自足定理），下表列出全部主张在当前正文、附录与本补充材料中的精确位置：

| 选集／命题组 | 第一、二版编号 | 第三版（v3）正文位置 | 本篇完整书面证明 | 固定提交 |
| --- | --- | --- | --- | --- |
| `phys.P1-P2, P19` 九场解、唯一性与历史界 | 原 §4 (4.1–4.5) | 构造 4.1，定理 4.2–4.5（§4.1–4.2） | 正文 §4.1–4.2；附录 B.1–B.7 | H |
| **v3 新增** 谱序参量双向选出 $\mathfrak h_{\rm SM}$ | （仅作块设定提及） | **定理 2.2**（§2.2） | 正文 §2.2；附录 A.1、B.7 | H |
| `phys.P3, P13-P14` 外幂、总丛、真空、消元 | 原 §2–3 (2.2–2.5, 3.2–3.3) | 命题 2.3–2.6、3.5，定理 3.4 | 正文 §2.3–2.4、§3.3；附录 A.3、B.2–B.6 | H |
| **v3 新增** 引力—规范不可分与四腿临界／`5/8` 缺陷 | （未入正文） | **命题 3.2、定理 3.3**（§3.1–3.2） | 正文 §3.1–3.2；**附录 B.8** | H |
| **v3 新增** 源生 Volterra 唯一认回与全阶无导数损失闭合 | （未入正文） | **定理 4.6–4.7**（§4.3） | **补充材料 S16.1–S16.4** | H |
| `phys.P15` Clock–B 耦合与引力反冲 | 原 §5 (5.1–5.4) | 构造 5.1，定理 5.2–5.4（§5） | 正文 §5.1–5.3 | H |
| `phys.P4-P5, P16` $4\sqrt2$ 配对与 256 维 Fock | 原 §6 (6.1–6.6) | 定义 6.1，定理 6.2–6.5，例 6.6（§6.1–6.2） | 正文 §6.1–6.2；附录 B.4、D.3 | H |
| `phys.P26` 共同 $H$、时钟 $R$、真变场与完整 Ward | 原 §6 (6.7–6.10) | 定理 6.7–6.8、6.10、7.2（§6.3–6.5、§7.1） | S1–S4 | 较早四提交、AB、AC |
| `phys.P37` 创建单位态、十二时间归一与 $1/(4\pi r)$ 核 | 二版 6.8a, 6.10a, 6.13b | **定理 6.9、6.11、7.9**（§6.4–6.5、§7.4） | S11.1–S11.6 | 71e、9c73 |
| `phys.P27, P29-P30, P33, P36` $H_{289}$、半轴与原生留数 | 原 §6 (6.11–6.13) | **定理 7.1、7.4、7.7**（§7.1–7.2、§7.4） | S5–S7 | AC、AD、AE、CAP |
| `phys.P38` 非线性半轴微分、九 Schur 与 $z^4\Pi_{\rm st}$ | 二版 6.9a, 6.12a, 6.13a | **定理 7.3、7.5、7.6**（§7.2–7.3） | S12.1、S12.4、S13 | 71e、9c73 |
| **v3 新增** 192/97 分式、钟因子消去、联合锥与四维曲率强积分 | （未入正文） | **定理 7.8、7.12**（§7.4–7.5） | **补充材料 S17.1–S17.4** | df4、7e4 |
| `phys.P34, P39` 匹配整词尾与带电色单态三费米子正谱 | 原 6.14，二版 6.15 | **定理 7.10、7.11**（§7.5） | S8、S14.1、S14.3 | AE、71e、9c73 |
| `phys.P7-P8, P12` 全时轨道、能量恢复、五点相干与 Bell 族 | 原 §7 (7.1–7.4) | **定理 8.1–8.3，命题 8.4**（§8） | 正文 §8.1–8.2 | H |
| `phys.P6, P9-P11, P17-P18, P20` 源族、十阶根封印与表示 | 原 §8 (8.1–8.3)，附录 C | **定理 9.1–9.3**（升级含五位置全时空缝合、零未登记权威与全前提折叠），附录 C | 正文 §9.1–9.2；附录 C.1–C.8 | H |
| `phys.P22` 固定母源普遍形成与无魔法比特 | 原 §8.4 (8.4–8.5) | **定理 9.4，推论 9.5**（§9.3） | 正文 §9.3；附录 C.9 | F |
| **v3 新增** 全词 Kraus–Born 等距与开放循环密度迹对偶 | （未入正文） | **定理 10.1**（§10.1） | **补充材料 S18.1–S18.2** | B291、B300 |
| `phys.P24-P25, P28, P31-P32, P35, P40` 公开实验与 120 ns 门 | 原 §9.2 (9.1–9.3)，二版 9.4 | **命题 10.2–10.5**，§10.2，附录 D.4 | S9.1–S9.4、S15、S15.5 | AB、AC、AD、AE、71e、9c73 |

---

## S11 定理 6.9、6.11 与 7.9：实际创建外态、十二时间列归一与涌现长程势

### S11.1 非零 CAR 创建下界与单位外态

令 $c_{12}(z)$ 为实际标量场第 $(1,2)$ 坐标：源真空处值为 $1$，源闭盒内扰动坐标范数严格小于 $1/2$，三角不等式给出 $|c_{12}(z)|\ge 1/2$。未占据色湮灭模式 $a_{02}$（$\|a_{02}\|\le1$）与其余两色创建算符反对易并湮灭种子态，同色反对易子为 $1$，故逐配置有

$$a_{02}\,\mathcal A_{10}^\dagger f=\overline{c_{12}}\,f,\qquad
\int\|f(z)\|^2\rho(z)\,dz\;\le\;4\int\|\mathcal A_{10}^\dagger f(z)\|^2\rho(z)\,dz.\tag{S11.1}$$

由稠密性延拓至定理 6.8 的单位背景 $v_\epsilon$，得 $\|\mathcal A_{10}^\dagger v_\epsilon\|\ge 1/2$，乘相位因子 $i/2$ 后 $\|g_\epsilon\|\ge 1/4>0$；除以正实范数即得单位创建态 $u_\epsilon=g_\epsilon/\|g_\epsilon\|$，差值泛函满足 $\|\ell_d\|\le\|u_\epsilon\|^2+\|v_\epsilon\|^2=2$。

### S11.2 标准模型联合荷字符、十二时间方向归一与加权创建电流

对任意标准模型子代数元素 $a=(A_3,A_2,y_a)$（$A_3^*=-A_3,\overline{y_a}=-y_a$），四外幂基上的标量创建系数与 504 模母矩阵 $L_a$ 的 CAR 对易子分别为

$$c_r(a\Phi)=-\sum_s(A_3)_{sr}c_s(\Phi),\qquad [Q(L_a),a_{s,r}^\dagger]=\sum_v(A_3)_{vr}a_{s,v}^\dagger+y_a a_{s,r}^\dagger.\tag{S11.2}$$

将两式代入联合变分 $\delta_a^{\rm joint}\mathcal A^\dagger=\mathcal A^\dagger(a\Phi)-[Q(L_a),\mathcal A^\dagger(\Phi)]$，利用 $\overline{(A_3)_{rs}}=-(A_3)_{sr}$，两个颜色求和精确抵消，只剩 $-y_a\mathcal A^\dagger$（湮灭算符同理得 $+y_a\mathcal A$），在加权测试核及连续完备剖面上一致保持。

在十二个时间规范方向上，非特征条件保证时间权矩阵 $\mathsf w_t(s)$ 的正典相位逆满足

$$M_{\rm ph}(s)\,[\mathsf a\,\mathsf w_t(s)]=I_{504},\tag{S11.3}$$

右乘 $C_a$ 并应用引理 S4.1 的正规序展开即得正文式 (6.6)–(6.7)。对任意 $504\times504$ 权重矩阵 $W$，记 $A_W^\dagger=[Q(W),\mathcal A^\dagger(\Phi)]$、$A_{a,\rm sc,W}^\dagger=[Q(W),\mathcal A^\dagger(a\Phi)]$，利用 $[Q(M),a_j^\dagger]=\sum_i M_{ij}a_i^\dagger$ 与式 (S11.2) 代换颜色列，得精确算符恒等式

$$[Q(WC_a),\mathcal A^\dagger(\Phi)]=iA_{a,\rm sc,W}^\dagger+i y_a A_W^\dagger,\tag{S11.4}$$

代入配置作用权 $W=\mathsf w_{\rm source}(z)$ 并在种子态 $q$ 上求值即证正文式 (6.8)。

### S11.3 完整时间场读口匹配与双侧截断预解尾

完整时间场读口 $J_a$ 与固定正则动量 Noether 读口 $N_a$ 满足精确补偿恒等式 $J_a=-N_a+C_a^{\rm comp}$（$C_a^{\rm comp}$ 汇合原生与余标架一阶射流、配置密度纤维导数、负保留纤维射流、时间权偏差及负正规荷对项）。记截断与未截断左右预解逆为 $L_c,R_c,L_u,R_u$，差值与保留泄漏之和为 $D_L,D_R$，由 $L_c=L_u+L_cD_LL_u$ 与 $R_c=R_u+R_cD_RR_u$ 展开夹心积得

$$L_c J_a R_c=-L_u N_a R_u+L_c C_a^{\rm comp}R_c-L_c D_L L_u N_a R_c-L_u N_a R_c D_R R_u.\tag{S11.5}$$

在相同保留空间上，未截断右逆保持 $u_\epsilon,v_\epsilon$ 所在子空间使右泄漏为零，固定有限帧 $F$ 上的逐点终站性使全部 289 个读口双线性收敛。

### S11.4 同密度物理电磁极点幂等律与 72 规范曲率

沿物理频率 $\omega$ 记 $K(\omega),G(\omega)$，源生简单极点 $\omega_*$ 处 $(\omega-\omega_*)G(\omega)\to R_\omega$。由两侧方程 $KG=I-Q_s,GK=I-Q_f$ 乘 $\omega-\omega_*$ 取极限得 $K_*R_\omega=R_\omega K_*=0$；结合实际读口正交性 $R_\omega Q_s(\omega_*)=0$，差商恒等式给出

$$R_\omega\,\frac{K(\omega)-K_*}{\omega-\omega_*}\,\bigl[(\omega-\omega_*)G(\omega)\bigr]=R_\omega\bigl[I-Q_s(\omega)\bigr]\;\longrightarrow\;R_\omega,\tag{S11.6}$$

左端极限即为 $R_\omega K'(\omega_*)R_\omega=R_\omega$（正文式 (7.15)）。经典窗口强迫形如 $K\cdot\text{场}$，被 $R_\omega K_*=0$ 精确消去，只留连通量子流留数 $R_\omega J_d$。规范一阶变分 $a$ 的非阿贝尔曲率读口

$$\mathcal F_{\mu\nu}(P;a)=P_\mu a_\nu-P_\nu a_\mu+[\bar A_\mu,a_\nu]+[a_\mu,\bar A_\nu]\tag{S11.7}$$

涵盖全部 $6\times12=72$ 个分量且对 $(P,a)$ 连续，故同步消费同一极点留数。

### S11.5 未截断相反转移的 $1/(4\pi|x-y|)$ 空间核

由 S7 五方向静态逆 $S_{\rm st}^{-1}$ 与嵌入 $F_0$ 记 $S_0=-F_0S_{\rm st}^{-1}F_0^{\mathsf T}$。在全体单位方向 $n$ 上，完整 Schur 分解 $r^2 G(0,irn)=r^2 A(0,irn)-F(0,irn)B(r,n)^{-1}F(0,-irn)^{\mathsf T}$ 以线性误差一致收敛于 $S_0$。撤去两端截断后，$L(k,M)=J_D^{\rm uncut}(-k)^{\mathsf T}M J_S^{\rm uncut}(k)$ 联合连续，源自身生成正红外半径 $\rho_{DS}>0$ 与控制界 $B_{DS}=1+|L(0,S_0)|$，使窗内 $0<a|k|<\rho_{DS}$ 满足

$$\bigl|L(ak,a^2G(0,iak))\bigr|\le B_{DS}|k|^{-2},\qquad \lim_{a\downarrow0}L(ak,a^2G(0,iak))=|k|^{-2}L(0,S_0).\tag{S11.8}$$

因三维 $|k|^{-2}$ 局部可积且 $\phi\in\mathcal S(\mathbb R^3)$ 速降，$B_{DS}|\phi(\xi)|/|2\pi\xi|^2$ 给出共同可积支配，控制收敛定理与高斯热核恒等式

$$\frac{1}{|k|^2+d^2}=\int_0^\infty e^{-t(|k|^2+d^2)}dt,\qquad \mathcal F^{-1}\!\bigl(e^{-t|2\pi\xi|^2}\bigr)(y)=(4\pi t)^{-3/2}e^{-|y|^2/(4t)}\tag{S11.9}$$

在 $d\downarrow0$ 时精确积分出 $1/(4\pi|y|)$，证得正文式 (7.16)–(7.17)。

### S11.6 三费米子外态的 Born 重叠修饰

对 S14.1 的三费米子态 $q$（粒子数为 $3$，$Y$ 升一级故 $(-R_{0,F}Y)^4 b=0$），完整响应正交分解为 $r=\sum_{j=0}^3(-R_{0,F}Y)^j b$，底层重叠比 $z=\|b\|/\|r\|\in(0,1]$；当源与探测各含至少一条形式伴随支（$H^\sharp$，$z=1$）外腿时，保分级纯规范作用使完整分子等于底层分子，四腿乘积 $Z=\prod_{j=1}^4 z_j$ 给出 $C_{\rm full}=Z C_{\rm base}$（基础收缩常数 $9/125+67/72=9023/9000$）。

**形式对应。** 提交 71e 与 9c73：`Verification/physics/low-energy-phenomenology/alpha-source/em-identification/` 下 `ActualDressed{SourcePreparation,TemporalNormalization,ReaderMatching,UncutMovingCoulomb}.lean`、`PhysicalDressed{P286Character,WeightedCreation}.lean`、`ActualEM{GaugeCurvature,DressedGaugePole}.lean`、`ActualCompositeCoulombDressing.lean`。

---

## S12 定理 7.3 与 7.6：常场非线性半轴微分与整矩阵四次解析红外返回

### S12.1–S12.3 常场非线性积分认回同场逆与 $C^2$ 全场 Fréchet 微分

对常实场微扰 $h\in\mathbb R^{289}$，记 $I_i(h)=R_+(h)N_i(h)R_-(h)$，受扰双腿传播束为 $\mathcal P_\lambda(h)X=\lambda X+A_+(h)X-XA_-(h)$（$A_\pm=-iK_\pm(h)$）。在 $h=0$ 处，$\operatorname{Re}\lambda>0$ 上存在有界双侧逆 $\mathcal I_\lambda$；由系数 $C^2$ 连续性与 Duhamel–Gronwall 估计（取 $\eta=\operatorname{Re}\lambda/4$），源自身生成原点正半径开邻域，在其上同时满足 $\|\mathcal I_\lambda[\mathcal P_\lambda(h)-\mathcal P_\lambda(0)]\|<1/2$ 与指数衰减

$$\|e^{-\lambda t}\mathcal T_h(t)\|\;\le\;\mathcal B_d(\operatorname{Re}\lambda/4)\,e^{-(\operatorname{Re}\lambda)t/2}\qquad(\forall t\ge0).\tag{S12.1}$$

对加权演化方程分部积分（末端由式 (S12.1) 归零），证得非线性半轴积分精确等于同场算子逆作用：

$$\int_0^\infty e^{-\lambda t}\mathcal T_h(t)\,dt=\mathcal P_\lambda(h)^{-1},\qquad
\mathcal J_d(h;\lambda)_i=\ell_d\bigl\{\mathcal P_\lambda(h)^{-1}I_i(h)\bigr\}.\tag{S12.2}$$

由于可逆算子开集上的求逆映射为 $C^2$，式 (S12.2) 右端在 $h=0$ 处为 $C^2$；沿任意实场方向 $f\in\mathbb R^{289}$ 用逆算子导数律 $D_h\mathcal P_\lambda^{-1}(0)[f]=\mathcal I_\lambda\mathcal D_f\mathcal I_\lambda$ 与三因子乘积导数展开得

$$D_h\mathcal J_d(0;\lambda)[f]_i=\ell_d\,\mathcal I_\lambda\bigl\{I_{i,f}^N-J_L[f]\mathcal I_\lambda I_i(0)+\bigl[\mathcal I_\lambda I_i(0)\bigr]J_R[f]\bigr\},\tag{S12.3}$$

与常历史五项线性化半轴逐列恒等，证得正文式 (7.3)；尾积分给出式 (7.4)。非自治 $C^1$ 信号在两条历史最小存在时窗 $\tau(d,k,P,a)>0$ 上的五项导数积分给出正文式 (7.5)。

### S12.4–S12.5 粒子数分级三次时间界与全分支 $z^4\Pi_{\rm st}$ 解析返回

在完整场生成元下，$C_F(h)$ 保分级而 $Y_F(h)$ 升一级：二粒子创建单位态 $u_\epsilon$ 至多升级两次，单粒子背景 $v_\epsilon$ 至多升级一次，且全场流算子不降分级。分级 Duhamel 三段积分给出二粒子态导数的三次多项式时间界：

$$\|\partial_f T_F(t)v\|\;\le\;|t|j\bigl(1+2a|t|+3a^2|t|^2\bigr)\|v\|\;\le\;3j(1+a)^2(1+|t|)^3\|v\|.\tag{S12.4}$$

进一步，记零分级正交投影为 $P$（满足 $Pu_\epsilon=u_\epsilon,Pv_\epsilon=v_\epsilon$、$[P,C_F(h)]=0$ 及 $PY_F(h)=0$）：初值唯一性与预解代数立得 $PT_{\rm full}(h,t)=PT_C(h,t)$ 及 $PR_{\rm full}(h,z)=PR_C(h,z)$。将自伴投影 $P$ 移过内积左槽，五因子核的左时间腿与左预解逆精确退回自由核（范数不随时长膨胀），从而完整五项射流逐格受三次界 $|\mathscr D_{ij}(t)|\le K_{ij}(d)(1+|t|)^3$ 控制。拉普拉斯积分 $\int_0^\infty e^{-\sigma t}(1+t)^3dt=\sigma^{-1}+3\sigma^{-2}+6\sigma^{-3}+6\sigma^{-4}$ 在 $0<\sigma\le1$ 上由常数 $1+3+6+6\le 56$（含双态系数）一致控制为 $\sigma^4|\Pi_d^{\rm st}(0,\sigma)_{ij}|\le 56 K_{ij}(d)$（正文式 (7.9)）。

在零外动量转移处，将双腿生成元源最小多项式 $p_d(z)=z^{m_d}d_d(z)$（$d_d(0)\ne0$）给出的预解表示 $\mathcal I_z=z^{-m_d}T_d(z)$（$T_d$ 在 $z=0$ 全纯）代入式 (S12.3)，定义全纯矩阵函数

$$R_d(z)=z^{2m_d}\Pi_d^{\rm st}(0,z)\qquad(\operatorname{Re}z>0).\tag{S12.5}$$

当 $2m_d\ge4$ 时，正实轴界 $\|R_d(s)\|\le C_d s^{2m_d-4}$ 结合全纯函数幂级数首项唯一性迫使 $R_d(z)=z^{2m_d-4}G_{4,d}(z)$（$G_{4,d}$ 在零点邻域全纯）；当 $2m_d<4$ 时直接置 $G_{4,d}(z)=z^{4-2m_d}R_d(z)$。两分支在右半平面穿孔邻域上均给出 $z^4\Pi_d^{\rm st}(0,z)=G_{4,d}(z)\to G_{4,d}(0)$ 及 $z^6\Pi_d^{\rm st}(0,z)=z^2G_{4,d}(z)\to0$。

**形式对应。** 提交 71e 与 9c73：`alpha-source/em-identification/ActualDressed{NoetherHalfIntegral,NonlinearPolarization,SignalPencil,FieldTimeFull,GradedSlopePrice,CubicNoetherPrice,CubicStaticPrice,IRAnalytic,CubicIRFactor,CubicIRReturn}.lean`。

---

## S13 定理 7.5：全场量子反馈、九约束 Schur 等价与双时钟通量

记九坐标注入 $J_9:\mathbb C^9\to\mathbb C^{289}$（落入第 112–120 槽，$r_9J_9=I_9$），由变量代换矩阵 $F(P)$ 定义零场初值提升 $N(P)=F(P)J_9$、初值读出 $D(P)=r_9F(P)^{-1}$、零源约束余核 $C(P)=r_9F(-P)^{\mathsf T}=N(-P)^{\mathsf T}$ 与余核提升 $L(P)=F(-P)^{-\mathsf T}J_9$。因子零行列给出 $HN=0,CH=0,DN=CL=I_9$，两侧母 Green 满足

$$GH=I-ND,\qquad HG=I-LC,\qquad DG=0.\tag{S13.1}$$

1. **半轴九约束 Schur 充要等价**：在 $\det(I-GQ_d)\ne0$ 上置 $A=(I-GQ_d)^{-1}$、$x(c)=A(Gf+Nc)$。则 $(I-GQ_d)x(c)=Gf+Nc$，即 $x(c)=Nc+G(f+Q_dx(c))$ 且 $Dx(c)=c$。左乘 $H$ 并用式 (S13.1) 得 $[H-Q_d]x(c)=f-LC(f+Q_dx(c))$；因 $CL=I_9$，残差为零当且仅当 $C(f+Q_dx(c))=CQ_dANc+C(I+Q_dAG)f=Sc-b=0$。反之若 $[H-Q_d]x=f$，左乘 $G$ 得 $(I-GQ_d)x=Gf+NDx$，故 $x=x(Dx)$，且 $C(f+Q_dx)=CHx=0\implies S(Dx)=b$，无需假设 $S$ 可逆。
2. **源生有限窗锚点 $16/15$ 逆界与四因子同步时钟导数**：对给定事件 $d$，由 289 个读口的线性与常值时间预算构造非实物质频率半径 $r_d\ge 4(1+G_*^{\rm price}B_d^{\rm win})>0$，在同步时钟 $z=3$ 与 $0<T\le1$ 上得 $\|T^{-1}G_*\Pi_T\|\le G_*^{\rm price}B_d^{\rm win}/r_d^2\le 1/16$，从而双侧逆 $A_T=(I-T^{-1}G_*\Pi_T)^{-1}$ 存在且 $\|A_T\|\le 16/15$。对同步有限窗约化矩阵 $S_T(z)=C(z)\Pi_T(z)A_T(z)N(z)$ 求导，利用 $B_T(z)=T^{-1}G(z)(TH(z)-\Pi_T(z))+N(z)D(z)$ 与 $A_T'=-A_TB_T'A_T$，乘积法则逐项给出正文式 (7.8)。此外，一般输入时钟 $c=P_0$ 与观测时钟 $\lambda$ 的半轴响应由最小多项式通分为分子除以 $p_d(\lambda)p_d(\lambda-c)$，且准备态时间 Ward 余额以 $O(\epsilon)$ 随 $\epsilon_n\downarrow0$ 归零。

**形式对应。** 提交 9c73：`alpha-source/em-identification/{ActualEMDressedSourceAnchor,ActualEMDressedSchur,ActualDressedConstraintHistory,ActualDressedRationalFourier,ActualDressedTemporalQuantumResidual,ActualDressedFullSchurFlux,ActualDressedHalfSchur}.lean`。

---

## S14 定理 7.11：带电色单态自旋 `1/2` 三费米子态与四通道正谱

### S14.1–S14.2 三费米子态的精确量子数与四通道有界合成

在每个独立对偶支 $d\in\{0,1\}$ 上，令 $a^\dagger_{d,(s,c,h)}$ 标记旋量 $s\in\{0,1,2,3\}$、色 $c\in\{0,1,2\}$ 及外幂楔类型 $h\in\{0,1\}$（$h=0$ 为色—正超荷，$h=1$ 为色—弱零分量），定义全反对称三色态

$$\epsilon_d(s_0,s_1,s_2)=\sum_{\pi\in S_3}\operatorname{sgn}(\pi)\,
a^\dagger_{d,(s_0,\pi_0,0)}a^\dagger_{d,(s_1,\pi_1,0)}a^\dagger_{d,(s_2,\pi_2,1)}\Omega_d,\qquad
q_d^{(3)}=\tfrac13\bigl[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)\bigr].\tag{S14.1}$$

第一项含 $6$ 个正交单位词（模方 $6$），第二项因前两旋量指标重合使对换合并为 $3$ 个系数为 $2$ 的正交词（模方 $12$），两项正交故 $\|q_d^{(3)}\|^2=(6+12)/9=2$。任意 $A\in\mathfrak{su}(3)$ 在三色全反对称楔积上作用为 $\operatorname{tr}A=0$（完全色单态）；两个正超荷模式加一个弱模式给出字面电磁荷 $(-1)^d=\pm1$；四维 Clifford 自旋生成元三位置和满足 $\sum_{j=1}^3(s_j^{(1)}+s_j^{(2)}+s_j^{(3)})^2 q_d^{(3)}=\tfrac34 q_d^{(3)}$（自旋 $1/2$），且在源真空点单向 Yukawa 作用严格非零 $Yq_d^{(3)}\ne0$。

接触通道 $\mathcal B_0$、79 维正典逆通道 $\mathcal B_1$、24 维独立对偶逆通道 $\mathcal B_2$ 与 61 维标量逆通道 $\mathcal B_3$ 均保持粒子数，与体积权 $v^{m+2}$ 对易，故在全加权 Hilbert 空间 $\mathscr H$ 上延拓为有界算符 $\mathcal B=\sum_{b=0}^3\mathcal B_b$；57 项多项式时间界保证因果响应 $w_F(t)$ 属于 $L^1\cap L^2$，Hilbert 值 Parseval 定理给出正文式 (7.19) $\nu(\mathbb R)=2\pi\int_{\mathbb R}\|\mathcal B w_F(t)\|^2dt$。

### S14.3–S14.5 纯虚非零代数见证、亚纯实转移窗、中性零道与双预解恒等式

在纯虚动量转移 $x=i$（$k=p_L=p_R=0$）处，固定三费米子检验态在四个通道上的精确代数读数依次为

$$\sqrt{30}\left(-\frac1{25},\quad
\frac{50304430064141165448074104830433}{97699116566232156027102301987500},\quad
-\frac{27}{316},\quad 0\right),\tag{S14.2}$$

四项相干代数和为

$$\sqrt{30}\,\frac{1502925864947895702084635234454041}{3859115104366170163070540928506250}\;\ne\;0.\tag{S14.3}$$

全部 33 组分子与 17 个分母均为复平面上的亚纯函数且在 $x=i$ 解析非零；由亚纯恒等定理及零极点孤立性，取有限个局部 Laurent 无零无极点半径的最小值即得**先于全部 $(F,\mu,\text{伴随},\text{因果})$ 的共同穿孔实区间 $0<|x|<\delta$**。在其上由 $f(z_*)=1$ 得 $\mathcal B(q_d^{(3)}f)\ne0$，结合高频预解返回 $z\mathcal B r_F(z)\to-\mathcal B(q_d^{(3)}f)\ne0$ 与连续性即证总谱有限且严格为正。正交分级分解 $\int\|r_F(\omega)\|^2d\omega=(\pi/\mu)\|q_d^{(3)}f\|^2+\int\|\mathrm{corr}_{Y,F}(\omega)\|^2d\omega$ 结合 $B_Y(q_d^{(3)}f)\ne0$ 证得严格正积分 Yukawa 余量；而 $\mathcal B$ 与带号占据算符 $Q_s$ 对易，三费米子态满足 $Q_s=\pm3$，故对任意 $Q_s e_w=0$ 的中性态恒有 $\langle e_w,\mathcal B r\rangle=(\pm3)^{-1}\langle Q_s e_w,\mathcal B r\rangle=0$，全频全时严格为零。

最后，在固定正阻尼 $\mu_*>0$ 上，压缩算子完备谱分解 $C_F=\sum_a e_a P_a$ 的 Sylvester 解 $\mathcal L(D)=\sum_{a,b}[2\mu_*-i\operatorname{dir}(c)(e_a-e_b)]^{-1}P_a D P_b$ 经四极点留数积分 $K_4(a,b;a,d)=\overline{l_{ab}}l_{ad}[\pi/\mu_*+K_2(b,d)]$ 给出精确双预解恒等式

$$\int_{\mathbb R}\|R_F(\omega)DR_F(\omega)g\|^2d\omega=\frac\pi{\mu_*}\|\mathcal L(D)g\|^2+\int_{\mathbb R}\|\mathcal L(D)R_F(\omega)g\|^2d\omega,\tag{S14.4}$$

并闭合有符号原始频率收支、径向压力尾及标量能量恒等式（其中原生标量增益 $3c_\sharp/(16\mu_*)$ 与场方分解恢复项 $15c_\sharp/(16\mu_*)$ 相加精确给出 $9c_\sharp/(8\mu_*)$）。

**形式对应。** 提交 71e 与 9c73：`external-composite-decay/{MixedSpectatorYukawaNonzero,SourceYukawaPositiveCorrection}.lean`、`SourceActualFourBlock{Retarded,HilbertOperator,SharpCausalMass,RealTransferPositive,SignedSector}.lean` 及 `Lean/scratch/LowEnergyRetardedCouncil/ActualFourBlockResponse/SourceActual{TwoResolventSylvester,ExactSylvesterRawFrequencyBalance,BalancedPressureMomentPayment,ScalarFieldDebitPayment}.lean`。

---

## S15 命题 10.4：120 ns 完整时间门第一登记概率与前向／伴随恢复

1. **（S15.1–S15.2）自由保迹传播库、第一强迫与阶乘尾界**：原子—光场自然耗散生成元 $\mathcal L_{\rm nat}(\rho)=K\rho+\rho K^\dagger+\sum_j J_j\rho J_j^\dagger$（保留同臂与跨臂再循环及成对厄米复交叉项）生成自由保迹传播 $\mathcal U_0(t,0)$，登记跃迁差 $\mathcal R(t)$ 给出 Volterra 展开 $\rho(t)=\mathcal U_0(t,0)\rho(0)+\int_0^t\mathcal U_0(t,s)\mathcal R(s)\rho(s)ds$；活动度 $a<N+2$ 时高阶单形尾和满足几何上界 $\sum_{k\ge0}a^{N+1+k}/(N+1+k)!\le\frac{a^{N+1}}{(N+1)!(1-a/(N+2))}$。十因子自由传播库通过 $10^{-8}$ 相对门（新增联合一致误差 $2.41\times10^{-14}$），40 个局域算子与 328 条带符号行构成完整首登记强迫有向无环图。
2. **（S15.3）四端口晚段伴随积分**：晚段伴随效应 $E_r^{\rm late}=\int_{I_{\rm late}}\mathcal U_0(t,0)^*(\mathcal J_r^*I)dt$ 在 60 个 $1\text{ ns}$ 片、64 次多项式正求积节点上对 $4,915,200$ 个复整数系数作任意精度复整数矩阵核查，最大算子误差 $8.427437\times10^{-12}<10^{-10}$，完整保留自然再循环。
3. **（S15.4）三无计数共像、一次性初态误差收缩与前向／伴随 $10^{-21}$ 吻合**：由布尔恒等式 $1_{\rm first}=1-n_\perp-n_\parallel+n_\perp n_\parallel$，禁止集合 $Q$ 的无计数生成元为 $\mathcal L_Q^{\rm nc}=\mathcal L_{\rm nat}-\sum_{j\in Q}\mathcal J_j$；迹循环恒等式 $\operatorname{tr}[E(K\rho+\rho K^\dagger)]=\operatorname{tr}[(K^\dagger E+EK)\rho]$ 与 $\operatorname{tr}[E(L\rho R)]=\operatorname{tr}[(REL)\rho]$ 使前向流 $\rho_Q'=\mathcal L_Q^{\rm nc}\rho_Q$ 与反向伴随流满足 $\frac{d}{dt}\operatorname{tr}(E_Q\rho_Q)=0$。源首登记活动度给出总效应范数上界 $\|E_{\rm first}\|\le\kappa\le0.003740914455$，故初态近似误差 $E_0$ 在合成整事件上只乘一次：$|P_{\rm first}-\widehat P_{\rm first}|\le\kappa E_0+E_{\rm new}$。六条伴随流给出区间 $[3.17845500810,3.17846466595]\times10^{-6}$（误差 $4.82892\times10^{-12}$），独立 30 条前向曲线（3600 片）给出区间 $[3.17845717771,3.17846249634]\times10^{-6}$（误差 $2.65931\times10^{-12}$），两中心差仅 $1.301828\times10^{-21}$。

### S15.5 冻结科学回执与固定提交

| 核验模块 | 冻结科学提交 | 核验内容与精度门 |
| --- | --- | --- |
| 四端口晚段伴随积分 `rha0038.1` | `a165b04a26febd0bc4e7ed1f33d4668b564a6e4f` | 60 片／$4,915,200$ 复整数系数，通过 $10^{-10}$ 门 |
| 三无计数共像伴随流 `rha0039` | `425ed6ed406b2a96f044dafd1c39b3587a9f14f0` | 六条完整 $120\text{ ns}$ 伴随流，通过 $10^{-8}$ 门 |
| 整事件一次性活动度收缩 `rha0039.1` | `87f9b1234441783f945727408b06ede72af9683d` | $\kappa\le0.0037409145$ 及伴随概率区间 |
| 30 条前向曲线与恢复 `rha0041.1` | 科学 `065399a21dcf...`；消费 `f7a5ee523ac8...` | 3600 片／90 独立有理片，前向区间及 $1.30\times10^{-21}$ 中心差 |
| 七查询量子程序库 `rha0042` | `7c9423057a2ee8f594b7502172e1a37105490829` | 全部七查询／140 个激活与标量合成程序 |

**形式对应。** `munich/readout-domain/` 下 `RegisteredDuhamelTail.lean`、`RegisteredTensorAction.lean`、`LateRegisteredAdjoint.lean`、`FirstReceiptZeroCount.lean`、`FirstReceiptQuantumFlux.lean`、`NoCountQuantumGenerator.lean` 及对应独立检查器。

---

## S16 定理 4.6–4.7：源生 Volterra 唯一认回与对称双曲全阶无导数损失闭合

### S16.1 加权母作用弱零点与源初值 Volterra 不动点的双向等价

设 $T>0$，空间盒 $Q=[a,b]\subset\mathbb R^3$（$a\le b$），固定第 $n\in\mathbb N$ 号稠密空间测试元 $\phi_n$。由源生整时间 $L^2$ 演化轨迹的连续性与有界算子配对，母质量内积读数 $m_n(t)=\langle\phi_n,M(t)u_{\rm src}(t)\rangle_{L^2(Q)}$ 与母作用诱导的空间 Green 变化率读数 $g_n(t)$ 均在 $[0,T]$ 上区间可积。记 $G_n(t)=m_{n,0}+\int_0^t g_n(s)\,ds$，则 $G_n$ 在 $[0,T]$ 上绝对连续（从而连续），且对几乎处处 $t\in[0,T]$ 有 $G_n'(t)=g_n(t)$。

对任意满足末端消失条件 $w(T)=0$ 的光滑时间权重 $w\in C^1([0,T])$，对绝对连续乘积 $w(t)G_n(t)$ 应用微积分基本定理（分部积分）：

$$\int_0^T\bigl(w(t)g_n(t)+w'(t)G_n(t)\bigr)\,dt
=\bigl[w(t)G_n(t)\bigr]_0^T
=0-w(0)m_{n,0}=-w(0)m_{n,0}.\tag{S16.1}$$

- **Volterra 不动点 $\Longrightarrow$ 加权弱作用零点**：若在 $[0,T]$ 上几乎处处有 $m_n(t)=G_n(t)$，则 $\int_0^T w'(t)m_n(t)\,dt=\int_0^T w'(t)G_n(t)\,dt$，代入式 (S16.1) 立得对一切 $w\in C^1([0,T])$（$w(T)=0$）有 $\int_0^T(wg_n+w'm_n)\,dt+w(0)m_{n,0}=0$。
- **加权弱作用零点 $\Longrightarrow$ Volterra 不动点**：反之，若加权弱作用零点成立，将其与式 (S16.1) 相减，得可积差函数 $\Delta_n(t)=m_n(t)-G_n(t)$ 满足
  $$\forall w\in C^1([0,T])\ (w(T)=0),\qquad \int_0^T w'(t)\,\Delta_n(t)\,dt=0.\tag{S16.2}$$
  对任意紧支撑光滑导数测试函数 $\varphi\in C_c^\infty((0,T))$，取右端点归零的原函数 $w_\varphi(t)=-\int_t^T\varphi(s)\,ds$，则 $w_\varphi\in C^1([0,T])$、$w_\varphi(T)=0$ 且 $w_\varphi'(t)=\varphi(t)$。式 (S16.2) 给出对一切 $\varphi\in C_c^\infty((0,T))$ 有 $\int_0^T\varphi(t)\Delta_n(t)\,dt=0$（任意测试函数不必积分为零，因为右端点固定为 $w_\varphi(T)=0$ 而左端点 $w_\varphi(0)$ 完全自由）。由 Lebesgue 积分在紧支撑光滑函数稠密性下的基本引理，立得 $\Delta_n(t)=0$ 在 $(0,T)$（从而在 $[0,T]$）上几乎处处成立，即 $m_n(t)=m_{n,0}+\int_0^t g_n(s)\,ds$（a.e. $t\in[0,T]$）。源生输出 $u_{\rm src}$ 满足分部积分恒等式，故同时满足弱作用零点与 Volterra 不动点，证毕定理 4.6(1)。

### S16.2 可数稠密测试的共同满测度集与空间 $L^2(Q)$ 场值唯一认回

对每个自然数 $n\in\mathbb N$，令

$$\Omega_n=\bigl\{t\in[0,T]:\;m_n(t)=G_n(t)\bigr\},\qquad
\Omega_{T,Q}=\bigcap_{n\in\mathbb N}\Omega_n\subseteq[0,T].\tag{S16.3}$$

由 S16.1，每个余集 $[0,T]\setminus\Omega_n$ 的一维限制 Lebesgue 测度为零；可数个零测集之并仍为零测集，故 $\Omega_{T,Q}$ 在 $[0,T]$ 上具有满测度。由于 $T>0$，区间 $[0,T]$ 的总测度为 $T>0$，因此 $\Omega_{T,Q}$ 必非空。

现固定任意时刻 $t\in\Omega_{T,Q}$ 及任意候选空间场 $v\in L^2(Q)$。若对一切 $n\in\mathbb N$ 均有 $\langle\phi_n,M(t)v\rangle_{L^2(Q)}=G_n(t)$，则由于 $t\in\Omega_n$（$\forall n$），有 $G_n(t)=m_n(t)=\langle\phi_n,M(t)u_{\rm src}(t)\rangle_{L^2(Q)}$，从而差向量 $w=v-u_{\rm src}(t)\in L^2(Q)$ 对全部 $n\in\mathbb N$ 满足 $\langle\phi_n,M(t)w\rangle_{L^2(Q)}=0$。因 $\{\phi_n\}_{n\in\mathbb N}$ 张成 $L^2(Q)$ 的稠密线性子空间，连续性给出 $M(t)w=0$；而在固定非特征 Cauchy 安全背景上，母质量算子 $M(t):L^2(Q)\to L^2(Q)$ 对称正定可逆（特别地单射），故 $w=0$，即 $v=u_{\rm src}(t)$，证毕定理 4.6(2)。

### S16.3 任意阶空间导数词的递归射流延拓与无在壳污染换位强迫

记时空点 $x=(t,\mathbf x)$ 处的一阶对称双曲母算子为 $\mathcal L_{\rm mat}u=A^0(x)\partial_t u+\sum_{j=1}^3 A^j(x)\partial_j u+B_0(x)u$，其中时间主部 $A^0(x)$ 光滑可逆，在壳方程等价改写时间导数为纯空间一阶射流算子：

$$\mathcal L_{\rm mat}u=0\quad\Longrightarrow\quad
\partial_t u=\mathcal T(x)(j_{\rm sp}^1 u)\equiv -(A^0(x))^{-1}\Bigl(\sum_{j=1}^3 A^j(x)\partial_j u+B_0(x)u\Bigr).\tag{S16.4}$$

对空间方向词 $w\in\{1,2,3\}^*$ 的长度 $|w|$ 作归纳，纯粹由源系数（不输入任何目标场 $u$）递归定义有界线性射流算子 $\mathcal J_w(x)\in\mathcal L(J_{\rm sp}^{|w|},\mathcal V)$：

1. **零阶基例** $w=\varnothing$：取 $\mathcal J_\varnothing(x)\equiv 0$，显然 $[\partial^\varnothing,\mathcal L_{\rm mat}]u=[I,\mathcal L_{\rm mat}]u=0=\mathcal J_\varnothing(x)(j_{\rm sp}^0 u)$。
2. **词长归纳步** $w=i\cdot\tilde w$（$i\in\{1,2,3\}$，$|\tilde w|=k$，$|w|=k+1$）：对任意光滑在壳场 $\mathcal L_{\rm mat}u=0$，先展开一次导数换位恒等式
   $$[\partial_i\partial^{\tilde w},\mathcal L_{\rm mat}]u
   =\partial_i\bigl([\partial^{\tilde w},\mathcal L_{\rm mat}]u\bigr)
   +[\partial_i,\mathcal L_{\rm mat}](\partial^{\tilde w}u).\tag{S16.5}$$
   由归纳假设，$[\partial^{\tilde w},\mathcal L_{\rm mat}]u=\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)$。对其沿第 $i$ 个空间坐标求链式导数，得到系数空间导数与射流升一阶算子（仅依赖 $j_{\rm sp}^{k+1}u$）：
   $$\partial_i\bigl(\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)\bigr)
   =(\partial_i\mathcal J_{\tilde w})(x)(j_{\rm sp}^k u)+\mathcal J_{\tilde w}(x)\bigl(\mathsf S_i^{(k)}(j_{\rm sp}^{k+1}u)\bigr),\tag{S16.6}$$
   其中射流升阶线性映射 $\mathsf S_i^{(k)}$ 将 $k+1$ 阶纯空间射流的词分量 $\partial^{i\cdot v}u$（$|v|\le k$）读入 $k$ 阶槽位。另一方面，式 (S16.5) 右端第二项为一阶系数空间导数换位：
   $$[\partial_i,\mathcal L_{\rm mat}](\partial^{\tilde w}u)
   =(\partial_i A^0)(x)\,\partial_t\partial^{\tilde w}u
   +\sum_{j=1}^3(\partial_i A^j)(x)\,\partial_j\partial^{\tilde w}u
   +(\partial_i B_0)(x)\,\partial^{\tilde w}u.\tag{S16.7}$$
   表面上看，式 (S16.7) 第一项含有混合时空导数 $\partial_t\partial^{\tilde w}u$；然而对在壳方程 $\mathcal L_{\rm mat}u=0$ 作用 $\partial^{\tilde w}$，立得 $\mathcal L_{\rm mat}(\partial^{\tilde w}u)=-[\partial^{\tilde w},\mathcal L_{\rm mat}]u=-\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)$，左乘 $(A^0(x))^{-1}$ 解出混合导数：
   $$\partial_t\partial^{\tilde w}u
   =-(A^0(x))^{-1}\Bigl(\sum_{j=1}^3 A^j(x)\,\partial_{j\cdot\tilde w}u+B_0(x)\,\partial^{\tilde w}u+\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)\Bigr).\tag{S16.8}$$
   将式 (S16.8) 代回式 (S16.7)，再与式 (S16.6) 相加，右端出现的最高导数恰好只是词长为 $k+1=|w|$ 的纯空间导数 $\partial_{j\cdot\tilde w}u$。因此定义
   $$\begin{aligned}
   \mathcal J_{i\cdot\tilde w}(x)(J)
   &=(\partial_i\mathcal J_{\tilde w})(x)(\pi_k J)+\mathcal J_{\tilde w}(x)(\mathsf S_i^{(k)}J)+\sum_{j=1}^3(\partial_i A^j)(x)J_{j\cdot\tilde w}+(\partial_i B_0)(x)J_{\tilde w}\\
   &\quad-(\partial_i A^0)(x)(A^0(x))^{-1}\Bigl(\sum_{j=1}^3 A^j(x)J_{j\cdot\tilde w}+B_0(x)J_{\tilde w}+\mathcal J_{\tilde w}(x)(\pi_k J)\Bigr),
   \end{aligned}\tag{S16.9}$$
   则 $\mathcal J_{i\cdot\tilde w}(x)\in\mathcal L(J_{\rm sp}^{k+1},\mathcal V)$ 完全由源系数光滑构造，且对一切满足 $\mathcal L_{\rm mat}u=0$ 的光滑场逐点恒有 $\mathcal J_w(x)(j_{\rm sp}^{|w|}u(x))=[\partial^w,\mathcal L_{\rm mat}]u(x)$，证毕定理 4.7(1)。

### S16.4 紧盒强制性、逐词平方吸收与无导数损失能量变化率闭合

固定紧盒 $I\times Q=[t_0,t_1]\times[a,b]$ 与阶数 $r\in\mathbb N$。

1. **点态强制性**：源时间主部 $A^0(t,\mathbf x)$ 对每个坐标纤维正定且关于 $(t,\mathbf x)$ 连续；在紧集 $I\times Q$ 与纤维单位球面的紧乘积上取极小值，存在严格正数 $\kappa>0$，使对盒内一切 $(t,\mathbf x)$ 与任意纤维向量 $\xi$ 有 $\kappa\|\xi\|^2\le\langle\xi,A^0(t,\mathbf x)\xi\rangle$。赋予纯空间射流空间上确界词范数 $\|j_{\rm sp}^r u(x)\|=\max_{|w|\le r}\|\partial^w u(x)\|$，则因最大词平方不超过全体词能量之和，对盒内每一点恒有
   $$\kappa\,\|j_{\rm sp}^r u(t,\mathbf x)\|^2
   \;\le\;\sum_{|w|\le r}\langle\partial^w u(t,\mathbf x),A^0(t,\mathbf x)\partial^w u(t,\mathbf x)\rangle
   =\mathcal E_r[u](t,\mathbf x).\tag{S16.10}$$
2. **先于全部场的预算吸收**：在紧集 $I\times Q$ 上，光滑逆主部算子范数受常数 $M_{\rm inv}=\sup_{I\times Q}\|(A^0)^{-1}\|<\infty$ 控制，有限词集 $\{w:|w|\le r\}$（基数记为 $N_r=\sum_{k=0}^r 3^k$）上的光滑射流算子范数受常数 $M_{\rm jet}=\max_{|w|\le r}\sup_{I\times Q}\|\mathcal J_w\|<\infty$ 控制。取先于全部场 $u$ 的非负常数 $L=N_r(M_{\rm inv}M_{\rm jet})^2\ge0$。对任意光滑在壳场 $\mathcal L_{\rm mat}u=0$ 与任意词 $|w|\le r$，利用射流范数单调性 $\|j_{\rm sp}^{|w|}u\|\le\|j_{\rm sp}^r u\|$ 及定理 4.7(1) 得
   $$\bigl\|(A^0)^{-1}[\partial^w,\mathcal L_{\rm mat}]u\bigr\|
   =\bigl\|(A^0)^{-1}\mathcal J_w(j_{\rm sp}^{|w|}u)\bigr\|
   \le M_{\rm inv}M_{\rm jet}\|j_{\rm sp}^r u\|.\tag{S16.11}$$
   两边平方并对全部 $N_r$ 个词求和，再乘 $\kappa>0$ 并代入式 (S16.10)，立即得到无导数损失吸收不等式
   $$\kappa\,\mathcal F_r[u](t,\mathbf x)
   \le \kappa\,N_r(M_{\rm inv}M_{\rm jet})^2\|j_{\rm sp}^r u(t,\mathbf x)\|^2
   \le L\,\mathcal E_r[u](t,\mathbf x).\tag{S16.12}$$
3. **同阶能量变化率闭合**：对每个词 $|w|\le r$，将对称双曲点态恒等式作用于 $\partial^w u$：时间主部导数项 $(\partial_t A^0)$、空间对称通量散度余项 $\sum_j(\partial_j A^j)$、零阶对称部 $-(B_0+B_0^{\mathsf T})$ 与换位强迫内积 $2\langle\partial^w u,[\partial^w,\mathcal L_{\rm mat}]u\rangle$ 经 Cauchy–Schwarz 不等式全部被 $\|j_{\rm sp}^r u\|^2$ 与 $\mathcal F_r[u]$ 线性控制。将紧盒系数导数上界与式 (S16.10)、(S16.12) 合并为单一非负常数 $K\ge0$（只依赖 $r$ 与紧盒 $I\times Q$），即对一切光滑在壳场同时得到 $\kappa\,\mathcal R_r[u](t,\mathbf x)\le K\,\mathcal E_r[u](t,\mathbf x)$，右端完全不含 $r+1$ 阶导数，证毕定理 4.7(2)。

**形式对应。** 提交 H：`Lean/SaturationMonoid/PhysicsCore/StageNineDiracDualFormNativeFixedP506CauchySafeMatterCanonicalAffineVolterra{Recognition,Actualization}.lean`（`weakVolterraActionZero_iff_fixedPoint`、`canonicalAffinePhysicalTimeL2Output_weakActionZero_iff_fixedPoint`、`CanonicalAffineVolterraDenseReadOccurrence.physicalField_unique`）与 `StageNineDiracDualFormNativeFixedP506CauchySafeMatterSymmetricHyperbolicAllOrder{JetProlongation,EnergyClosure}.lean`（`fixedMatterAllOrderForcingJetCLM_apply_of_actionZero`、`exists_fixedMatterAllOrderPointwiseForcingBudgetAbsorptionOnBox`、`exists_fixedMatterAllOrderClosedPointwiseRateBoundOnBox`）。

---

## S17 定理 7.8 与定理 7.12：192/97 电磁消因子分式、联合锥与四维曲率强积分

### S17.1 192 维非活跃双侧逆与 97 维二变量 Schur 有理分式

在修饰事件 $d$、单位空间动量方向 $n$（$|n|^2=1$）、空间尺度 $0<\varepsilon\le 1/2$ 与正阻尼 $\sigma>0$ 上，将 289 个复化场方向按源内非活跃／活跃指标集精确直和分解为 $289=192+97$：其中 192 个非活跃方向在其自身块上不受活跃物质量子极化污染，修正全场束矩阵分块写为

$$P_{\rm corr}(\varepsilon,\sigma)=\begin{pmatrix}P_{II}(\varepsilon,\sigma)&P_{IA}(\varepsilon,\sigma)\\ P_{AI}(\varepsilon,\sigma)&P_{AA}(\varepsilon,\sigma)\end{pmatrix},\qquad P_{II}\in M_{192}(\mathbb C),\quad P_{AA}\in M_{97}(\mathbb C).\tag{S17.1}$$

在 $0<\varepsilon\le 1/2,\sigma>0$ 上，$P_{II}$ 具有显式有理双侧逆 $P_{II}^{-1}=d_{\rm nat}(\varepsilon,\sigma)^{-1}N_{\rm inv}(\varepsilon,\sigma)$（其中清分母多项式 $d_{\rm nat}\in(\mathbb C[\varepsilon])[X]$ 在正域上恒非零）。分块 Gauss 消元给出行列式乘法公式 $\det P_{\rm corr}=\det P_{II}\cdot\det S_{97}$，其中 97 维 Schur 补为 $S_{97}=P_{AA}-P_{AI}P_{II}^{-1}P_{IA}$（保留全部 $97\times192$ 与 $192\times97$ 量子交叉耦合列），且任意非活跃分量由活跃解唯一重构为 $x_I=-P_{II}^{-1}(P_{IA}x_A-f_I)$。因 $\det P_{II}\ne0$，全场正则条件 $\det_{\rm corr}(\varepsilon,\sigma)\ne0$ 充要于 $\det S_{97}(\varepsilon,\sigma)\ne0$。

乘清分母多项式 $d_{\rm nat}$ 消去分式后，得到整系数二变量多项式矩阵

$$Q_{97}(\varepsilon,X)=d_{\rm nat}(\varepsilon,X)P_{AA}(\varepsilon,X)-P_{AI}(\varepsilon,X)N_{\rm inv}(\varepsilon,X)P_{IA}(\varepsilon,X)\in M_{97}\bigl((\mathbb C[\varepsilon])[X]\bigr).\tag{S17.2}$$

利用伴随矩阵恒等式 $Q_{97}\operatorname{adj}(Q_{97})=(\det Q_{97})I_{97}$ 将 $\varepsilon^4$ 加权时间电磁响应收缩展开为多项式分子 $N_{97}\in(\mathbb C[\varepsilon])[X]$ 与分母 $\det Q_{97}\in(\mathbb C[\varepsilon])[X]$，即在一切正则点上成立精确分式等式 $\varepsilon^4 T_{00}(\varepsilon,\sigma)=\mathrm{eval}_{\varepsilon,\sigma}(N_{97})/\mathrm{eval}_{\varepsilon,\sigma}(\det Q_{97})$，证毕定理 7.8(1)。

### S17.2 电磁第 15 号枢轴行初等更新与 $X^2/X^3$ 钟因子消去

由同一母密度导出的物理电磁时间强迫向量在非活跃块上恒为零（$E_I=0\in\mathbb C^{192}$），在 97 维活跃指标集 $\mathcal I_{97}\subset\{0,\ldots,288\}$ 上的向量 $E_A\in\mathbb C^{97}$ 在第 15 号活跃枢轴坐标处取精确非零有理常数 $(E_A)_{15}=-1/2$。用 $E_A^{\mathsf T}$ 左乘式 (S17.2) 的两项：由于时间方向电磁 Ward 恒等式使 $E_A^{\mathsf T}P_{AA}$ 与交叉重构项 $E_A^{\mathsf T}P_{AI}N_{\rm inv}P_{IA}$ 各自的低阶 $X^0,X^1$ 项精确为零，整行具有公共二次时钟因子

$$E_A^{\mathsf T}\,Q_{97}=X^2\,R_{97}^{\mathsf T},\qquad R_{97}\in\bigl((\mathbb C[\varepsilon])[X]\bigr)^{97}.\tag{S17.3}$$

将矩阵 $Q_{97}$ 在第 15 号枢轴处的行替换为线性组合行 $E_A^{\mathsf T}Q_{97}=\sum_{j\in\mathcal I_{97}}(E_A)_j(Q_{97})_{j,\bullet}$，记所得矩阵为 $\widetilde Q_{97}$。由行列式对单行更新的多重线性与其余行交错消去性质，有

$$-\frac12\,\det Q_{97}=(E_A)_{15}\det Q_{97}=\det\widetilde Q_{97}=\det\bigl(\text{第 15 行为 }X^2 R_{97}^{\mathsf T}\text{ 的矩阵}\bigr)=X^2\,\det\widehat Q_{97},\tag{S17.4}$$

其中 $\widehat Q_{97}$ 为将第 15 行直接替换为 $R_{97}^{\mathsf T}$ 所得多项式矩阵。两边同乘 $-2$，令 $D_{\rm W}=-2\det\widehat Q_{97}\in(\mathbb C[\varepsilon])[X]$，即在不做任何分式除法的情况下证明整环分解 $\det Q_{97}=X^2 D_{\rm W}$；与此同时，Noether 伴随收缩中的时钟辅助列直接提供三次因子 $N_{97}=X^3 N_{\rm W}$。对任意实阻尼 $\sigma>0$（故复嵌入 $\sigma\ne0,\sigma^2\ne0$），求值环同态给出

$$\frac{\mathrm{eval}_{\varepsilon,\sigma}(N_{97})}{\mathrm{eval}_{\varepsilon,\sigma}(\det Q_{97})}
=\frac{\sigma^3\,\mathrm{eval}_{\varepsilon,\sigma}(N_{\rm W})}{\sigma^2\,\mathrm{eval}_{\varepsilon,\sigma}(D_{\rm W})}
=\sigma\,\frac{\mathrm{eval}_{\varepsilon,\sigma}(N_{\rm W})}{\mathrm{eval}_{\varepsilon,\sigma}(D_{\rm W})}.\tag{S17.5}$$

在整环 $(\mathbb C[\varepsilon])[X]$ 中，$X^m\ne0$ 无零因子，故对任意非零多项式 $P=X^m W$ 必有 $W\ne0$ 且尾次数满足 $\operatorname{ord}_X(P)=m+\operatorname{ord}_X(W)$，分别取 $m=3,2$ 即得两条精确尾阶平移律，证毕定理 7.8(2)。

### S17.3 二变量首系数非零传递与单种子生成的联合正则锥

设存在一个正则种子 $(\varepsilon_0,\sigma_0)$（$0<\varepsilon_0\le 1/2,\sigma_0>0$）使 $\det_{\rm corr}(\varepsilon_0,\sigma_0)\ne0$，则分母多项式 $B=\det Q_{97}\in(\mathbb C[\varepsilon])[X]$ 非零（否则在 $(\varepsilon_0,\sigma_0)$ 求值为零，矛盾），记分子为 $A=N_{97}\in(\mathbb C[\varepsilon])[X]$。对任意二变量多项式 $P\in\{A,B\}$，按外层时钟变量 $X$ 的尾阶 $k_P=\operatorname{ord}_X(P)$ 提出首时钟空间系数 $p_0(\varepsilon)\in\mathbb C[\varepsilon]$（约定零多项式时 $k_P=0,p_0\equiv0$）：

$$P(\varepsilon,X)=X^{k_P}\Bigl(p_0(\varepsilon)+X\,P_{\rm tail}(\varepsilon,X)\Bigr).\tag{S17.6}$$

再对 $p_0(\varepsilon)$（对应 $a_0(\varepsilon),b_0(\varepsilon)$）按 $\varepsilon=0$ 处的尾阶 $\ell_P=\operatorname{ord}_\varepsilon(p_0)$ 写 $p_0(\varepsilon)=\varepsilon^{\ell_P}(c_P+\varepsilon\tilde p(\varepsilon))$（当 $A=0$ 时取 $k_A=\ell_A=0,a_0\equiv0,c_A=0$）。因 $B\ne0$，有 $b_0(\varepsilon)\ne0$ 且首复常数 $c_B\ne0$。令空间重标权为 $w_{\rm sp}(\varepsilon)=\varepsilon^{\ell_B-\ell_A}$，记 $\tilde a,\tilde b$ 在区间 $[0,1/2]$ 上的有限多项式系数绝对值之和分别为 $M_{\tilde a},M_{\tilde b}\ge0$，定义显式非负空间斜率常数 $S_{\rm ratio}:=2|c_B|^{-1}\bigl(M_{\tilde a}+|c_A||c_B|^{-1}M_{\tilde b}\bigr)\ge0$。由一变量多项式有限系数界显式选取正空间半径 $\rho_{\rm sp}\in(0,1/2]$，使得对一切 $0<\varepsilon\le\rho_{\rm sp}$ 有 $|\varepsilon\tilde b(\varepsilon)|\le\tfrac12|c_B|$（从而 $|b_0(\varepsilon)|\ge\tfrac12|c_B|\varepsilon^{\ell_B}>0$）。接着对每个固定的 $0<\varepsilon\le\rho_{\rm sp}$，根据 $|b_0(\varepsilon)|>0$ 与 $(A,B)$ 双方的时钟尾系数上界，显式定义严格正时钟半径 $\rho_{\rm clk}(\varepsilon)>0$，使对一切 $0<\sigma\le\rho_{\rm clk}(\varepsilon)$ 同时满足：

1. $|\sigma\,B_{\rm tail}(\varepsilon,\sigma)|\le\tfrac12|b_0(\varepsilon)|$，故 $|B(\varepsilon,\sigma)|\ge\tfrac12\sigma^{k_B}|b_0(\varepsilon)|>0$，保证整个联合锥上 $\det_{\rm corr}(\varepsilon,\sigma)\ne0$；
2. 时钟余项对固定 $\varepsilon$ 的比值偏差满足 $\bigl|\widetilde R(\varepsilon,\sigma)-a_0(\varepsilon)/b_0(\varepsilon)\bigr|\cdot|w_{\rm sp}(\varepsilon)|\le\varepsilon$（其中重标分式为 $\widetilde R(\varepsilon,\sigma)=\sigma^{k_B-k_A}\varepsilon^4 T_{00}(\varepsilon,\sigma)$）。

最后在 $0<\varepsilon\le\rho_{\rm sp}$ 上，由 $|c_B+\varepsilon\tilde b|\ge\tfrac12|c_B|$ 直接算得空间首系数比值偏差 $\bigl|w_{\rm sp}(\varepsilon)a_0(\varepsilon)/b_0(\varepsilon)-c_A/c_B\bigr|=\varepsilon\bigl|(\tilde a\,c_B-c_A\tilde b)/[c_B(c_B+\varepsilon\tilde b)]\bigr|\le S_{\rm ratio}\,\varepsilon$；由两步三角不等式相加立得式 (7.14) 的线性一致误差界 $\le(1+S_{\rm ratio})\varepsilon$，证毕定理 7.8(3)。

### S17.4 原总闭合对象紧支规范变分的四维曲率强积分与 $\operatorname{Dom}(H_{\rm time})$ 词 Gram

设 $\mathcal U_{1\text{--}10}$ 为固定源十阶总闭合对象，$A_{\rm cl}$ 为其标准模型联络，$\eta\in C_c^\infty(\mathbb R^4,\Omega^1(\mathfrak h_{\rm SM}))$ 为紧支撑光滑联络变分，$t\in\mathbb R$；记 252 维母物质响应空间（及等距拉回的共同物质载体 $\mathcal H_{\rm com}$）上源生强连续酉时钟群 $U_{\rm time}(s)=e^{-isH_{\rm time}}$ 的自伴生成元为 $H_{\rm time}$（与 §6.3 在 504 模 CAR 配置空间上的非对称生成元 $H=H_0+Y$ 区分）。

1. **空间曲率种子与四维强 Bochner 积分**：变分联络 $A_{\rm cl}+t\eta$ 的精确非阿贝尔曲率为 $F(A_{\rm cl}+t\eta)=F(A_{\rm cl})+t\,D_{A_{\rm cl}}\eta+\tfrac{t^2}{2}[\eta\wedge\eta]$。在空间切片投影 $\pi_{\rm sp}(p)=(0,\mathbf p)$ 上，同点有序曲率多项式 $P$ 通过源生有界规范表示映射给出有界算子函数 $p\mapsto\mathrm{seed}_{\eta,t,P}(\pi_{\rm sp}(p))$，范数在 $\mathbb R^4$ 上一致有界且关于 $p$ 强连续。对任意四维 Schwartz 测试函数 $f\in\mathcal S(\mathbb R^4)$（满足 $f\in L^1(\mathbb R^4)$）与任意态矢 $v$，被积函数 $p\mapsto f(p)U_{\rm time}(-p_0)\mathrm{seed}_{\eta,t,P}(\pi_{\rm sp}(p))U_{\rm time}(p_0)v$ 强可测且范数受 $|f(p)|\cdot\|\mathrm{seed}\|_\infty\|v\|\in L^1(\mathbb R^4)$ 控制，故式 (7.20) 的四维 Bochner 积分良定并给出有界线性算符 $\|\Phi_{\eta,t,P}(f)\|\le\|f\|_{L^1}\|\mathrm{seed}\|_\infty$。当 $t=0$ 时，曲率变分项消失，常曲率背景使任意基点的原历史种子恒等于原点嵌入 $\iota_0(P)$ 的原规范种子，积分恒等给出 $\Phi_{\eta,0,P}(f)=\Phi_{\rm orig}(\iota_0(P),f)$。
2. **时间平移协变、海森堡导数与 $\operatorname{Dom}(H_{\rm time})$ 保持**：利用酉群律 $U_{\rm time}(s)U_{\rm time}(-p_0)=U_{\rm time}(-(p_0-s))$ 及空间投影对第一坐标的不变性 $\pi_{\rm sp}(p_0-s,\mathbf p)=(0,\mathbf p)=\pi_{\rm sp}(p)$，作时间平移换元 $q_0=p_0-s$（$\tau_s f(q_0,\mathbf p)=f(q_0+s,\mathbf p)$），立即证得精确协变恒等式
   $$U_{\rm time}(s)\,\Phi_{\eta,t,P}(f)\,U_{\rm time}(-s)v=\Phi_{\eta,t,P}(\tau_s f)v.\tag{S17.7}$$
   因 $f\in\mathcal S(\mathbb R^4)$，时间差商 $s^{-1}(\tau_s f-f)$ 在 $L^1(\mathbb R^4)$ 范数下于 $s\to0$ 收敛到 $\partial_0 f\in\mathcal S(\mathbb R^4)$，由算子对 $L^1$ 范数的连续线性立得算子范数导数 $\frac{d}{ds}\big|_{s=0}(U_{\rm time}(s)\Phi_{\eta,t,P}(f)U_{\rm time}(-s))=\Phi_{\eta,t,P}(\partial_0 f)$。现设 $v\in\operatorname{Dom}(H_{\rm time})$（即强极限 $\lim_{s\to0}\frac{i}{s}(U_{\rm time}(s)v-v)=H_{\rm time}v$ 存在），对乘积展开差商：
   $$\frac{U_{\rm time}(s)\Phi(f)v-\Phi(f)v}{s}
   =\frac{\bigl(U_{\rm time}(s)\Phi(f)U_{\rm time}(-s)-\Phi(f)\bigr)}{s}U_{\rm time}(s)v
   +\Phi(f)\frac{U_{\rm time}(s)v-v}{s}.\tag{S17.8}$$
   当 $s\to0$ 时，第一项由算子范数可微性与 $U_{\rm time}(s)v\to v$ 强收敛到 $\Phi(\partial_0 f)v$，第二项由 $\Phi(f)$ 有界性收敛到 $-i\Phi(f)H_{\rm time}v$。故 $\Phi_{\eta,t,P}(f)v\in\operatorname{Dom}(H_{\rm time})$ 且 $H_{\rm time}\Phi_{\eta,t,P}(f)v=\Phi_{\eta,t,P}(i\partial_0 f)v+\Phi_{\eta,t,P}(f)H_{\rm time}v$；对词长归纳立得任意有限混合词 $W(w)$ 保持 $\operatorname{Dom}(H_{\rm time})$。
3. **共同载体与正半定词 Gram**：经满射酉等距 $I_{\rm com}:\mathcal H_{\rm com}\xrightarrow{\sim}\mathcal H_{\rm src}$ 共轭拉回，词作用保持全部代数与定义域性质；由定理 6.2 的归一化 $4\sqrt2$ 配对恒等式，运行拍回答态在基点 $x$ 对自伴投影／混合词对 $(w_i,w_j)$ 的母响应精确等于内积 $\mathrm{Gram}_x(w_i,w_j)=\langle W(w_i)\psi_{\rm prep}(x),W(w_j)\psi_{\rm prep}(x)\rangle$，故对任意复系数向量 $(c_i)_{i\in I}$ 有 $\sum_{i,j}\overline{c_i}c_j\mathrm{Gram}_x(w_i,w_j)=\bigl\|\sum_i c_i W(w_i)\psi_{\rm prep}(x)\bigr\|^2\ge 0$，证毕定理 7.12。

**形式对应。** 提交 df4：`Verification/physics/low-energy-phenomenology/alpha-source/em-identification/ActualSourcePrepared{InactiveSchurReturn,Schur97NoetherFraction,Schur97WardSchur,Schur97WardDeterminant,Schur97WardFactor,Schur97JointCone}.lean` 及回执 `actual_source_prepared_em_enclosure_certification.json`。提交 7e4：`Lean/SaturationMonoid/PhysicsCore/YangMills/SourceQuantum/Curvature/Spatial/{Seed,Field,Words,Original}.lean`、`Continuum/Spacetime/Strong/Spatial/{Field,Time}.lean` 及回执 `Verification/physics/yang-mills/source-quantum/source_spatial_curvature_receipt.json`。

---

## S18 定理 10.1：全词 Kraus–Born 等距与开放循环密度迹对偶

### S18.1 单形直和测度上的精确总质量与 $L^2$ 场态等距嵌入

设演化窗为 $[t_L,t_R]$，起始时刻 $t_0\in[t_L,t_R]$，有限跃迁通道集为 $\mathcal I$。对每个词长 $n\in\mathbb N$ 与通道词 $w=(j_1,\ldots,j_n)\in\mathcal I^n$，有序时间单形 $\Delta_n(t_0,t_R)=\{t_0\le s_1\le\cdots\le s_n\le t_R\}$ 上的源生 Kraus 词振幅为

$$\mathcal A_{n,w}(t_0;\mathbf s)=U_{\rm eff}(t_R,s_n)J_{j_n}U_{\rm eff}(s_n,s_{n-1})\cdots J_{j_1}U_{\rm eff}(s_1,t_0)\in\mathcal L(E),\tag{S18.1}$$

其中非厄米有效收缩传播子满足 $\frac{d}{dt}U_{\rm eff}(t,s)=K(t)U_{\rm eff}(t,s)$，耗散生成元满足标准微分守恒律 $K(t)^*+K(t)+\sum_{j\in\mathcal I}J_j(t)^*J_j(t)=0$。对任意 $x\in E$，逐词分部积分单形恒等式与耗散率上界给出单形积分级数收敛

$$\sum_{n=0}^{\infty}\sum_{w\in\mathcal I^n}\int_{\Delta_n(t_0,t_R)}\bigl\|\mathcal A_{n,w}(t_0;\mathbf s)x\bigr\|^2\,d\mathbf s=\|x\|^2.\tag{S18.2}$$

在不交并空间 $\mathscr W(\mathcal I)=\bigsqcup_{n\in\mathbb N}\bigsqcup_{w\in\mathcal I^n}\Delta_n(t_0,t_R)$ 上赋予可数直和测度 $\mu_{\rm base}(t_0)$。对每个分量 $(n,w)$，连续映射 $\mathbf s\mapsto\mathcal A_{n,w}(t_0;\mathbf s)x$ 在紧单形 $\Delta_n(t_0,t_R)$ 上强可测且有界；由可数不交并上的逐片可测粘贴引理，全词场态 $\Psi_{t_0}(x)$ 强可测。用 Tonelli 单调收敛定理将 $\mathscr W(\mathcal I)$ 上的非负 Lebesgue 积分逐层展开为 $\sum_{n=0}^\infty\sum_{w\in\mathcal I^n}\int_{\Delta_n}\|\mathcal A_{n,w}x\|^2d\mathbf s$，代入式 (S18.2) 立即证得精确总质量恒等式 $\mu_{\rm Born}(t_0,x)(\mathscr W(\mathcal I))=\int_{\mathscr W}\|\Psi_{t_0}(x)\|^2d\mu_{\rm base}=\|x\|^2<\infty$。因此 $\Psi_{t_0}(x)\in L^2(\mu_{\rm base}(t_0);E)$，映射 $x\mapsto\Psi_{t_0}(x)$ 关于 $x$ 复线性且满足 $\|\Psi_{t_0}(x)\|_{L^2}^2=\|x\|^2$，开平方即得复线性等距嵌入，证毕定理 10.1(1)。

### S18.2 反向伴随流时间导数归零与开放循环密度全阶迹恒等式

任取隐藏（未登记但物理再循环）通道子集 $\mathcal H\subseteq\mathcal I$。在有限维原子 Hilbert 空间 $E$ 的算符代数 $\mathcal L(E)$ 上同时考虑前向开放密度演化方程与反向伴随（Heisenberg）效应演化方程（$t\in[t_0,t_R]$）：

$$\left\{\begin{aligned}
\frac{d}{dt}\Phi_{t_0\to t}^{\mathcal H}(\rho)&=K(t)\Phi_{t_0\to t}^{\mathcal H}(\rho)+\Phi_{t_0\to t}^{\mathcal H}(\rho)K(t)^*+\sum_{j\in\mathcal H}J_j(t)\Phi_{t_0\to t}^{\mathcal H}(\rho)J_j(t)^*,\quad \Phi_{t_0\to t_0}^{\mathcal H}(\rho)=\rho,\\
-\frac{d}{dt}\mathcal C_{t\to t_R}^{\mathcal H}(A)&=K(t)^*\mathcal C_{t\to t_R}^{\mathcal H}(A)+\mathcal C_{t\to t_R}^{\mathcal H}(A)K(t)+\sum_{j\in\mathcal H}J_j(t)^*\mathcal C_{t\to t_R}^{\mathcal H}(A)J_j(t),\quad \mathcal C_{t_R\to t_R}^{\mathcal H}(A)=A.
\end{aligned}\right.\tag{S18.3}$$

1. **双线性迹配对守恒与全词展开**：对任意（无需自伴或归一）算符 $\rho,A\in\mathcal L(E)$，定义光滑时间函数 $F(t)=\operatorname{Tr}\bigl(\Phi_{t_0\to t}^{\mathcal H}(\rho)\,\mathcal C_{t\to t_R}^{\mathcal H}(A)\bigr)$。利用有限维迹的循环性 $\operatorname{Tr}((KX+XK^*)Y)=\operatorname{Tr}(X(K^*Y+YK))$ 与 $\operatorname{Tr}((J_jXJ_j^*)Y)=\operatorname{Tr}(X(J_j^*YJ_j))$，式 (S18.3) 上下两式在求导时逐项精确抵消：
   $$F'(t)=\operatorname{Tr}\!\left(\frac{d\Phi}{dt}\,\mathcal C+\Phi\,\frac{d\mathcal C}{dt}\right)=0\qquad\forall t\in[t_0,t_R],\tag{S18.4}$$
   故端点恒等 $\operatorname{Tr}\bigl(\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\,A\bigr)=F(t_R)=F(t_0)=\operatorname{Tr}\bigl(\rho\,\mathcal C_{t_0\to t_R}^{\mathcal H}(A)\bigr)$。另一方面，将反向伴随方程沿有效传播子 $U_{\rm eff}$ 作迭代 Duhamel 展开，第 $n$ 阶单形积分恰为全词波限制在 $\mathcal H^n$ 上的伴随效应 $\mathcal E_n^{\mathcal H}(t_0;A)=\sum_{w\in\mathcal H^n}\int_{\Delta_n}\mathcal A_{n,w}(t_0;\mathbf s)^*A\,\mathcal A_{n,w}(t_0;\mathbf s)\,d\mathbf s$，且阶乘余项以算子范数指数收敛于零，故 $\mathcal C_{t_0\to t_R}^{\mathcal H}(A)=\sum_{n=0}^\infty\mathcal E_n^{\mathcal H}(t_0;A)=\mathcal E_{\rm end}^{\mathcal H}(t_0;A)$。由迹泛函连续线性立得式 (10.2) 的全阶收敛恒等式。
2. **保正性、迹单调不增与全浴严格保迹**：若 $\rho\ge0$ 与 $A\ge0$ 均为正半定算符，将 $\rho$ 谱分解为秩一正投影之和 $\rho=\sum_\alpha|x_\alpha\rangle\langle x_\alpha|$；对每个 $n,w,\mathbf s$ 有 $\langle x_\alpha|\mathcal A_{n,w}^*A\mathcal A_{n,w}|x_\alpha\rangle=\langle\mathcal A_{n,w}x_\alpha,A\mathcal A_{n,w}x_\alpha\rangle\ge0$，级数求和结合式 (10.2) 给出对一切正算符 $A\ge0$ 有 $\operatorname{Tr}(\Phi_{t_0\to t_R}^{\mathcal H}(\rho)A)\ge0$（特别取秩一投影 $A=|y\rangle\langle y|$ 得 $\langle y,\Phi_{t_0\to t_R}^{\mathcal H}(\rho)y\rangle\ge0$，$\forall y\in E$），且自伴性由各项共轭对称给出，证得 $\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\ge0$。进一步在式 (10.2) 中取 $A=I$：
   - 当 $\rho\ge0$ 且 $\mathcal H\subseteq\mathcal I$ 时，由于 $\mathcal H^n\subseteq\mathcal I^n$ 且单形被积项非负，由 S18.1 式 (S18.2) 有
     $$\begin{aligned}
     \operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal H}(\rho)&=\sum_\alpha\sum_{n=0}^\infty\sum_{w\in\mathcal H^n}\int_{\Delta_n}\|\mathcal A_{n,w}x_\alpha\|^2d\mathbf s\\
     &\le\sum_\alpha\sum_{n=0}^\infty\sum_{w\in\mathcal I^n}\int_{\Delta_n}\|\mathcal A_{n,w}x_\alpha\|^2d\mathbf s=\sum_\alpha\|x_\alpha\|^2=\operatorname{Tr}\rho;
     \end{aligned}$$
   - 当 $\mathcal H=\mathcal I$（全部跃迁通道均归入未观测再循环浴）时，上式对一切秩一基元 $|x\rangle\langle y|$（通过极化恒等式线性张成全体 $\mathcal L(E)$）直接取等号（或直接由式 (S18.3) 中 $\mathcal C_{t\to t_R}^{\mathcal I}(I)\equiv I$，因 $K^*+K+\sum_{j\in\mathcal I}J_j^*J_j=0$），故对任意算符 $\rho\in\mathcal L(E)$ 恒有 $\operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal I}(\rho)=\operatorname{Tr}\rho$，证毕定理 10.1(2)。

**形式对应。** 提交 B291 和 B300 分别对应 `Verification/physics/stage10/independent-bell/munich/readout-domain/evidence/source-kraus-word-wave-rha0291/source-r0004/SourceKrausWordWave291.lean`（`wordFunction_measurable`、`lintegral_bornDensity`、`bornMeasure_univ`、`sourceIsometry`）与 `source-endpoint-recycling-rha0300/density-source-r0001/SourceEndpointDensity300.lean`（`whole_word_trace_hasSum`、`whole_word_trace_eq_recycling_IVP`、`densityFlow_positive`、`densityFlow_trace_nonincreasing`、`whole_bath_trace_identity`）。
