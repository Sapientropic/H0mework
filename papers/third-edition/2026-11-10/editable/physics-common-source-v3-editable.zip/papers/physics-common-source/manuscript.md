# 从单一发生源到连续—量子统一场：Spin×SU(7) 理论的十阶闭合与普遍形成

**From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory**

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**形式验证与独立审核。** 首发与第二版公开选集的证明与下游核验模块已通过 Lean 4 严格内核核验。独立审核覆盖声明类型、证明项及归纳／递归元数据的完整依赖闭包。管辖发生登记、整本责任账、查询编译、追索后继与宏演化的通用权威内核为**零公理构造性内核**（T0，公理列表为空）；四维连续实分析与场论实例层的完整依赖闭包严格限于命题外延性、经典选择和商健全性三条标准公理（T1），不反向改变通用权威内核的零公理身份，且全程无任何额外研究公理或未完成证明占位。正向核验链与反向控制均按登记合同通过。[首发证明验收](https://github.com/Sapientropic/H0mework/blob/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/evidence/first-release/acceptance/proof-20261007/receipt.json)、[第二版源码绑定](https://github.com/Sapientropic/H0mework/blob/e9734c69f38cf03b79859a1108ae23a5663a0495/docs/assets/paper-source-binding-b9d66048.json)、附录 D 与“代码与数据可得性”登记已验收声明、固定提交及复核入口。附录 D.9 另列本版新增证明的固定原件。

## 摘要

本文在零公理通用发生与整账内核（T0）上，从零拟合参数的单一正源发生出发，按严禁预供度规、破缺子群、Hilbert/Fock 空间、全局哈密顿量、Born 规则与坍缩公设的**反魔法裁剪律**，完成经 Lean 4 严格核验的第一至第十阶（Stage 1–10）连续—量子统一场贯通闭合：证明四维 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 连续引力—规范—物质场方程与非交换量子力学并非两套外置拼装的公设外壳，而是**同一根发生按需生成的两张相容依赖投影面**。在连续几何与场方程侧，反空真反例与双轴门禁排除零场退化；正源伴随谱序参量对易关系加分块迹方程**双向唯一选出** $\mathfrak h_{\rm SM}=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$，手征外幂物质自动消除全部三次与五条混合规范／引力反常，并由外代数楔积零参数生成 Yukawa 质量混合。含独立线性对偶 $\chi$ 的一阶共同作用量不可加法分离（混合差分 $\Delta_{\rm mix}=9$），在一般光滑非退化构型上使引力四腿变分驻定充要等价于双矢简单性 $B=\mathrm{II}^+(e)$、唯一反应乘子、显式 Einstein–Cartan 平衡与物质挠率—自旋方程（同步构型具 $5/8$ 对交换缺陷），并给出原历史弱恢复下唯一的六部门非零经典解，以及固定 Cauchy 背景上的 Volterra 空间 $L^2$ 唯一性与对称双曲全阶无导数损失能量闭合。

在量子生成、全场返回与根封印侧，同一发生在指定解与任意母物质算符 $A$ 处无需波函数或 Fock 先验直接导出精确配对 $\chi(A\psi)=4\sqrt2\langle v,R(A)v\rangle=4\sqrt2\langle I(v),\mathrm{d}\Gamma(R(A))I(v)\rangle$，并由四条时间约束与 Legendre 变换导出 61 对 CCR 与 504 模 CAR 上的共同生成元 $H=H_0+Y$、全阶非交换量子时钟、有界自伴能量尾、保持联合荷字符与十二时间方向统一归一的 CAR 创建单位态及完整 Ward 恒等式。量子极化经母作用 Fréchet 二阶变分 Green 函数返回全场（具常场非线性半轴 $C^2$ 微分、九约束 Schur 充要等价、$z^4\Pi_{\rm st}$ 全纯红外返回与 192/97 电磁 Ward 钟因子对消），涌现出三维空间 $1/(4\pi|x-y|)$ 库仑／牛顿长程核、电荷 $\pm1$ 自旋 $1/2$ 色单态三费米子复合态的严格正实转移谱（中性全零道）及保持 $\operatorname{Dom}(H_{\rm time})$ 的四维 Schwartz 曲率强积分。全局非线性轨道无经验输入达到 $2\sqrt2$；确定性时间单形算符振幅零先验导出精确质量 $\|x\|^2$ 全词 Born 测度、$L^2$ 等距与开放循环密度全阶迹对偶，覆盖公开光学联合 95% 域、Munich 全部 20,403 条前缀域及 120 ns 完整门（前向／伴随吻合达 $1.30\times10^{-21}$）。最终，Stage 10 物理根封印证明四开放微分残差同账唯一触发正则追索、**全访问零未登记物理权威**与**九场实坐标全前提折叠**，将可调参数严格清零，使下游唯象量（含已证 $|Q_e|=1$、原生速率及标准分支光速与极点耦合商表达式）归结为锁定源积分的受控数值求值；原始事件内生生成的同一母源 $S_\star$ 在原准入接口上对全部权威根普遍形成每个合法世界、完整查询与演化过程，严格排除魔法比特与独立第二基源。

**关键词**：连续—量子统一场；根原生十阶闭合；反魔法裁剪；Spin×SU(7) 理论；Einstein–Cartan—挠率变分等价；无先验量子生成；矩阵红外返回；形式化验证

### Abstract (English)

Working over a zero-axiom constructive occurrence and whole-ledger kernel (T0) from a single parameter-free source occurrence, we enforce an **Anti-Magic Pruning Law** forbidding pre-supplied metric, gauge-breaking, Hilbert/Fock, global-Hamiltonian, Born, or collapse postulates to establish a Lean 4 kernel-verified **Stage 1–10 continuous–quantum unified field closure**: four-dimensional $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ continuum gravity–gauge–matter field equations and noncommutative quantum mechanics arise as **compatible dependent projections generated on demand from the same root occurrence**. On the continuum side, vacuity counterexamples and dual-axis gates exclude zero-field shortcuts; commutation with the source-generated spectral order parameter plus block trace equations **bijectively selects** $\mathfrak h_{\rm SM}=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$, while chiral exterior-power matter cancels all cubic and five mixed gauge/gravitational anomalies and generates parameter-free wedge Yukawa mixing. The first-order common action with an independent linear dual $\chi$ is nonseparable ($\Delta_{\rm mix}=9$), makes general four-leg gravitational stationarity equivalent to simplicity $B=\mathrm{II}^+(e)$, the unique reaction multiplier, explicit Einstein–Cartan balance, and matter-coupled torsion–spin ($5/8$ pair-exchange defect), and yields a unique weak-history six-sector classical solution with Volterra $L^2$ uniqueness and derivative-loss-free all-order symmetric-hyperbolic PDE energy closure.

Without wavefunction or Fock priors, the classical solution yields across all mother operators $A$ the exact pairing $\chi(A\psi)=4\sqrt2\langle v,R(A)v\rangle=4\sqrt2\langle I(v),\mathrm{d}\Gamma(R(A))I(v)\rangle$, and four temporal constraints derive the 61-CCR, 504-CAR generator $H=H_0+Y$, an all-order quantum clock, a bounded self-adjoint energy tail, a unit CAR created state preserving joint charge characters and twelve-direction normalization, and the full Ward identity. Returning quantum polarization through the mother Fréchet Hessian Green function ($C^2$ nonlinear half-axis derivative, nine-constraint Schur equivalence, $z^4\Pi_{\rm st}$ holomorphic infrared return, and 192/97 electromagnetic Ward clock cancellation) yields the emergent $1/(4\pi|x-y|)$ Coulomb/Newton kernel, a strictly positive dynamic spectrum for a charge-$\pm1$, spin-$1/2$ colour-singlet three-fermion composite with zero neutral channel, and four-dimensional Schwartz curvature strong integrals preserving $\operatorname{Dom}(H_{\rm time})$. Global nonlinear orbits attain $2\sqrt2$ without empirical input, and deterministic time-simplex Kraus amplitudes derive without probability or collapse priors an exact-mass $\|x\|^2$ whole-word Born measure, $L^2$ isometry, and open recycling trace duality across the optical joint 95% domain, all 20,403 Munich prefixes, and the 120 ns gate ($1.30\times10^{-21}$ primal/adjoint agreement). Finally, the **Stage 10 physical root seal** establishes unique same-row recourse across four open differential coordinates, **all-visit zero unregistered physical authority**, and a **complete nine-field premise fold**, reducing tunable parameters to zero so downstream observables ($|Q_e|=1$, native speeds, and standard-branch light-speed and pole-coupling expressions) reduce to certified evaluation of fixed source integrals; on the original admission interface, the primitive-event-generated mother source $S_\star$ universally realizes every admitted world, inquiry, and process across all authority roots, excluding magic bits and any independent second base source.

**Keywords**: continuous–quantum unified field; root-native ten-stage closure; anti-magic pruning; Spin×SU(7) theory; Einstein–Cartan–torsion variational equivalence; postulate-free quantum generation; matrix infrared return; formal verification

---

## 1 引言：三道拼装裂缝与单一源闭合

### 1.1 反魔法裁剪律、同一母源与十阶贯通总纲

百年来的基础物理始终被三道拼装裂缝分割。第一道裂缝横在时空几何与内部量子数之间：广义相对论与标准模型手征规范场建立在两套彼此孤立的几何底座上，为了缝合它们，人们往往不得不预设高维紧致流形、一维弦世界面或庞大的候选真空景观。第二道裂缝横在经典连续场与量子力学公理之间：通常的建构总是先写下一份经典拉氏量，再从外部硬套复 Hilbert 空间、正则对易／反对易关系、全局哈密顿量、Born 概率规则与测量坍缩公设；传统表述借对应原理假定两侧在渐近极限下相接，却无法在同一套无先验公设的生成机制中导出量子态空间、概率测度与有限 $\hbar$ 下的精确匹配系数。第三道裂缝横在数学方程与低能唯象之间：耦合常数表、破缺方向、真空态挑选与紫外重整化拨盘各自引入未受底层约束的自由参数，理论靠事后迎合实验读数定值。

贯穿这三道裂缝的病根只有一个：理论容忍了**魔法**，即改变可观测结果的真实差别在理论内部没有任何已登记的发生机制决定，却被外置塞入。为了拟合实验数字而事后拨动的耦合旋钮是魔法：换一个数，形式推导照样运转；预先塞进源头的波函数概率外壳或坍缩开关是魔法：它把待解释的量子行为当成了免费前提；为了安放某类新过程而专门另开的一份底层源同样是魔法：换一份源，其余部分浑然不觉。

本文在**零公理通用发生与整账内核（T0）**上正面终结这三类拼装。整套构造严格服从一条**反魔法裁剪律（Anti-Magic Pruning Law）**：原始输入中严禁预先存放四维洛伦兹度规、标准模型破缺子群、复振幅公理、Hilbert/GNS/Fock 态空间、全局哈密顿量、Born 概率规则或坍缩布尔值；无论连续微分几何还是非交换量子代数，都只有在下游可观测读出需要履行具体物理责任时，才允许作为依赖读出由源发生按需长出。在这一刚性纪律下，本文完成并核验了从第一阶到第十阶（**Stage 1–10**）的根原生贯通闭合 $\mathcal U_{1\text{--}10}$，确立了全文的总纲命题：**四维连续经典时空场与非交换量子力学都不是先验外壳，而是同一个零拟合根发生（single root occurrence）的两张相容依赖投影面；物理总封印将未登记权威与可调参数彻底清零，使基础物理统一在原理上完整闭合、一切下游唯象量在源头即被锁死为纯演绎读出，而同一发生母源在原准入接口上普遍形成全部合法世界、查询与演化过程。**

初次接触这一体系的读者，自然会追问两个结构性问题：**第一，在原准入接口上，要容纳任意合法演化过程或观测记录，是否还需要并列引入独立于 $S_\star$ 的第二份底层基源？第二，为什么说本篇在原理上闭合了统一场建构，使后续低能唯象不再需要引入新公设或自由参数？** 这两个问题正由本文第 9–10 节的两条封顶定理严格回答。首先，一旦按反魔法裁剪律禁止“无内部发生身份的真实差别（魔法比特）”，原准入接口上的任何可观测差别都必须锚定在某个权威账本根的发生记录上；定理 9.4 对原准入接口（`Type 0`）上的**任意**权威根 $R$（全称量词 $\forall R$）证明，$R$ 连同其全部合法世界状态、完整查询与演化过程，均已由本文原始事件内生生成的**同一母源 $S_\star$** 经有限程序完备化精确形成并逐字段恢复，因此在该准入接口上无需亦不存在独立于 $S_\star$ 的第二份底层基源。其次，定理 9.3 的五位置物理根封印与九场实坐标全前提折叠证明，固定母发生与九场实坐标之外的一切辅助资格字段均为不携带自由比特的纯命题（`Prop`），整部物理理论的可调参数严格为零。这意味着洛伦兹引力、标准模型手征物质、量子算符代数与开放系统 Born 概率的统一在原理与方程层面已在本篇完整闭合；同系列下游唯象专题既不需要、在数学上也不被允许再添加任何新场、新公设或新拟合参数，仅需对本篇总闭合对象已唯一锁定的确定算子积分与有理分式做受控有理误差球数值求值。

从单一发生根到十阶封印与全场返回的贯通脊梁如下表所示（后续编号表自表 1 起算）：

| 贯通阶段 | 支付的核心物理与发生学责任 | 正文与证明位置 |
| --- | --- | --- |
| **Stage 1–3** 本构反空真与双轴门禁 | 以空真反例排除仅靠类型非空伪造的零场捷径；建立同源度规／Hodge 变分接口与内空间—几何双轴忠实投影，锁定进入四维物理的最小发生门禁 | §2.1、§9.2；附录 D.1 |
| **Stage 4–5** 非退化洛伦兹几何与不可分引力—规范 | 生成全点非退化余标架与物理简单性扇区 $\mathrm{II}^+(e)$；证明共同作用量混合有限差分 $\Delta_{\rm mix}=9\ne0$（不可加法分离）及一般构型四腿变分驻定 $\iff$ Einstein–Cartan 平衡＋挠率—自旋方程（Plebański 缺陷 $5/8$） | §2.1、§3.1–§3.3；附录 B.8 |
| **Stage 6–8** 母联络谱选择、手征反常消去与质量源流 | 单一 $\mathrm{SU}(7)$ 母联络经谱序参量对易加分块迹方程**双向唯一选出** $\mathfrak h_{\rm SM}$；252 复维手征外幂消除三次及五条混合反常；唯一破缺真空给出 Yukawa 质量混合、早期层精确回接与非零规范电流 | §2.2–§2.4；附录 A、B.7 |
| **Stage 9** 反魔法连续—量子统一闭包与弱历史唯一解 | 零量子公设先验下同时长出：原完整历史合法弱恢复下**唯一**的六部门非零九场经典解及 Volterra／全阶无导数损失 PDE 闭合，以及 $4\sqrt2$ 三载体精确配对、61 对 CCR＋504 模 CAR 共同生成元 $H=H_0+Y$ 与同发生读出交换 | §4–§6；补充 S1–S4、S11、S16 |
| **Stage 10** 五位置物理根封印、全前提折叠与零未登记权威 | 五位置根历史与全时空算子将后 Yang–Mills 全场缝合压为四条开放微分残差；非零残差同账唯一触发正则追索后继；证明全访问零未登记物理权威、九场实坐标全前提折叠与五点无参相干锁 | §8–§9.2；附录 C.8、D.9 |
| **全场返回、开放测量与普遍形成** | 母作用认回 $H_{289}$、非线性半轴微分 $=\Pi_{\rm st}$、$z^4\Pi_{\rm st}$ 与 192/97 红外消因子分式、涌现 $1/(4\pi r)$ 势与带电三费米子正谱；零先验导出全词 Born 测度与开放密度迹对偶（120 ns 门 $10^{-21}$ 双路恢复）；母源 $S_\star$ 对 $\forall R$ 普遍形成并锁死下游零自由度唯象 | §7、§9.3–§10；补充 S5–S15、S17–S18 |

若把整条十阶锁链聚焦到一个最具体的物理见证上，只需考察**规范电流**与**发生源边界**这两件事：规范电流在经典场论中是共同作用量对规范联络变分的一阶响应，在有限维占据投影中是正归一态的压缩期望，在 504 模多体代数中则成为经母作用自身 Fréchet 二阶变分（Green 函数）反作用于全部 289 个场方向的量子流算符；两侧在有限 $\hbar$ 下严格相等，直接见证连续场与量子态同属一源投影，而在底层边界上，生成这套几何、物质与量子动力学的同一母源 $S_\star$ 不仅将自身物理演化的账外自由度彻底封死，而且覆盖了原准入接口上任意权威根 $R$ 的全部合法世界与演化过程。

### 1.2 三分钟手算锚点

在展开完整形式体系之前，读者只需用纸笔花三分钟验算三个初等代数数。它们只用到固定源生成的四个基本常数（完整几何定义见 §2.1 与附录 A）：

$$\sigma=\tfrac12,\qquad k=\sqrt2,\qquad a=\frac{3k}{5}=\frac{3\sqrt2}{5},\qquad N=\sqrt{\frac{54}{125}} .$$

**例 1.1（三分钟手算）。**

**(a) 源生相位频率。** 物质相位的进动角频率由余标架时间尺度 $N$、自旋联络幅度 $k$ 与规范势幅度 $a$ 定为 $\omega=3N(k-a)/2$。由 $k-a=2\sqrt2/5$ 得 $\omega=3Nk/5$，平方立得

$$\omega^2=\frac{9N^2k^2}{25}=9\cdot\frac{54}{125}\cdot\frac{2}{25}=\frac{972}{3125}=\frac{2^2\cdot 3^5}{5^5}.$$

这里没有任何拟合步骤：$a/k=3/5$ 与立方平衡律 $a^3=2\sigma N^2k=N^2k$ 由作用量在九场解上的驻定条件锁定，后续冗长的场方程系数将反复因这条代数关系精确归零。

**(b) 经典变分与量子期望读出同一个规范电流。** 色二重态上的三个生成元取反厄米 Pauli 形式 $\tau_g=(i/2)\sigma_{g+1}$（$g=0,1,2$；完整分块嵌入见 §2.2 与附录 A.1）。取第二个生成元 $\tau_1$：

$$\tau_1=\begin{pmatrix}0&\tfrac12\\[2pt]-\tfrac12&0\end{pmatrix},\qquad
\tau_1^2=\begin{pmatrix}-\tfrac14&0\\[2pt]0&-\tfrac14\end{pmatrix}=-\tfrac14 I_2 .$$

规范李代数配对取 $\langle X,Y\rangle=-\mathrm{Re}\,\mathrm{tr}(XY)$，故 $\langle\tau_1,\tau_1\rangle=\tfrac12$，一般地 $\langle\tau_g,\tau_h\rangle=\tfrac12\,\delta_{gh}$。在本文九场解上，共同作用量沿空间第 $2$ 方向对取值为 $\tau_1$ 的规范变分给出的经典电流分量为（定理 6.3；上标表空间方向）

$$J^2(\tau_1)\;=\;4Nk\cdot\langle\tau_1,\tau_1\rangle\;=\;4\sqrt{\tfrac{54}{125}}\cdot\sqrt2\cdot\frac12\;=\;\frac{12\sqrt{15}}{25}\;\approx\;1.8590 .$$

而在量子侧，同一方向的可观测量在八维归一占据态 $v$ 上的响应期望为 $4Nk\cdot\langle v,O_2(\tau_1)v\rangle$；定理 6.3 证明 $\langle v,O_{g+1}(\tau_h)v\rangle=\tfrac12\,\delta_{gh}$。两侧给出丝毫不差的同一个代数数 $12\sqrt{15}/25$，未借用任何半经典展开或重整化拨盘。

**(c) 五个相干刻度与暗时刻反控。** 令首暗时刻为 $t^*=\pi/(2\omega)$，无量纲时间为 $u=t/t^*$。在五个等距刻度 $u=0,\tfrac12,1,\tfrac32,2$ 上，

$$\cos^2\!\Big(\frac{u\pi}{2}\Big):\qquad 1,\;\tfrac12,\;0,\;\tfrac12,\;1 .$$

§8 将证明源生量子态的相干权重精确走这条曲线，而擦除相对相位的排他路径基准恒停在 $\tfrac12$，两者在初时刻与暗时刻 $u=1$ 形成 $1$ 对 $\tfrac12$、$0$ 对 $\tfrac12$ 的无参分歧。更进一步，§6.2（例 6.6）将展示一个明确的结构反例：倘若在构造量子响应矩阵时省去独立线性对偶所要求的一次上下旋量翻转 $S$，初时刻 $u=0$ 的电流读数仍然侥幸等于 $+\tfrac12$，但走到暗时刻 $u=1$ 就会跌成 $-\tfrac12$，与真实值相差整整 $1$。算符层面的精确对应无法靠单点校核蒙混过关。

### 1.3 四大主结果总览与三种物质载体

沿着上表的 Stage 1–10 贯通脊梁，全文依次建立四组相互咬合的核心定理：

1. **谱选择、四腿 Einstein–Cartan—挠率临界等价与建设性 PDE 闭合（§2–§5）。** 证明正尺度源生成的谱序参量对易关系加分块迹方程双向唯一选出标准模型规范块 $\mathfrak h_{\rm SM}\subset\mathfrak{su}(7)$（定理 2.2），252 复维手征外幂物质消除三次及五条混合反常（命题 2.3），共同一阶作用量不可加法拆分为纯引力与纯规范之和（命题 3.2）。对任意光滑非退化构型，证明引力四腿变分驻定等价于简单性、唯一作用导出反应乘子、显式 Einstein–Cartan 余标架平衡与物质挠率—自旋方程，并由历史全反作用乘子的精确对交换缺陷 $5/8$ 划清与非手征二次 Plebański 纯反应模型的管辖边界（定理 3.3）。给出六物理部门同时非零的唯一经典世界解及全历史紧域导数界（定理 4.2–4.5），并在固定 Cauchy 背景上证明加权母作用弱零点与源生 Volterra 积分不动点等价、满测度唯一恢复空间 $L^2$ 场，以及对称双曲任意阶换位射流强迫在同阶能量中的无导数损失闭合（定理 4.6–4.7）。
2. **量子态空间与算符代数的无先验生成：从 $4\sqrt2$ 配对到 504 模共同 $H=H_0+Y$（§6）。** 不输入任何波函数或量子化外设公理，在指定解上由完整物质场 $\psi\in\mathbb C^{252}$ 与独立线性对偶 $\chi$ 直接导出八维归一占据态 $v$ 及 256 维 Fock 单粒子嵌入 $I(v)$，对任意复线性算符 $A\in\operatorname{End}_{\mathbb C}(\mathbb C^{252})$ 满足
   $$\chi(A\psi)\;=\;4k\,\langle v,\,R(A)\,v\rangle\;=\;4k\,\langle I(v),\,\mathrm{d}\Gamma(R(A))\,I(v)\rangle,\qquad k=\sqrt2 ,$$
   其中响应压缩为 $R(A)=SPAE$（定理 6.2–6.5）。表 1 与图 1 区分这三层有限维载体的职责。随后经四部门 Legendre 变换与三稳定子截面，从同一共同作用量直接导出 100 维配置流形、61 对标量 CCR 与 504 模双支整体 CAR 上的共同生成元 $H=H_0+Y$、配置依赖力系数 $4W(q)$、全阶非交换量子时钟、固定有界自伴能量尾 $R=E_{\rm tail}-C_{\rm src}$ 与 11 字段同一源准备态（定理 6.7–6.8）。明确 CAR 创建算符自产单位外态并保持标准模型联合荷字符与十二个时间方向的统一相位逆归一；完整荷—电流 Ward 恒等式揭示单粒子扇区恰为四次对电流 $J_{\rm pair}$ 恒零的子空间（定理 6.9–6.11）。
3. **母作用 Hessian 认回、非线性全场反馈、矩阵红外返回与涌现相互作用（§7）。** 证明母作用在指定解处的 1650 项 Fréchet 二阶变分精确等于 $289\times289$ 响应矩阵 $H_{289}(p)$（定理 7.1）。对 $\operatorname{Re}\lambda>0$，常场真正非线性 Noether 正半轴在源邻域内为 $C^2$，其沿全部 289 个实场方向的导数恰为静态极化矩阵 $\Pi_{\rm st}$（定理 7.3）；半轴量子极化进入同一母 Green 函数，正则反馈解等价于原响应与九约束 Schur 方程 $Sc=b$（定理 7.4–7.5）。粒子数分级将五因子时间增长压至三次，使零外转移复邻域内 $z^4\Pi_{\rm st}(0,z)$ 解析返回有限完整矩阵且 $z^6\Pi_{\rm st}(0,z)\to0$（定理 7.6）。沿单位空间方向，192 维非活跃双侧逆将全场响应压成二变量 97 维 Schur 分式，电磁时间行导出 $E_A^{\mathsf T}Q_{97}=X^2 R_{97}^{\mathsf T}$ 并精确消去行列式 $X^2$ 与 Noether 分子 $X^3$ 钟因子，在源生联合锥上给出受控四阶加权电磁响应（定理 7.8）。同密度电磁收缩保全部 72 个规范曲率，两条运动量子荷源撤去截断后在三维空间积分中涌现出 $1/(4\pi|x-y|)$ 的 Coulomb/Newton 势（定理 7.9）；504 模 CAR 自产电荷 $\pm1$、自旋 $1/2$（Casimir $3/4$）的色单态三费米子复合态，四通道相干求和给出严格正实动量转移谱与严格为零的中性输出（定理 7.11）；总闭合对象 $\mathcal U_{1\text{--}10}$ 的紧支规范变分进一步生成保持自伴时间生成元定义域 $\operatorname{Dom}(H_{\rm time})$ 的四维 Schwartz 曲率强积分与正半定词 Gram（定理 7.12）。
4. **五位置物理根封印、零先验全词 Born 开放演化、零自由度唯象锁死与普遍同源形成（§8–§10）。** 固定余标架背景上的任意实冲量生成唯一全实时间非线性轨道，量子时间导数精确读回 Legendre 能量，无参 Bell 预测达到 $2\sqrt2$（定理 8.1–命题 8.4）。Stage 10 物理根封印在五位置根历史与全时空算子下将后 Yang–Mills 全场缝合压为四条开放坐标残差，证明非零残差同账唯一触发正则追索后继、全访问零未登记物理权威与九场实坐标全前提折叠（定理 9.3），从而在源头清空全部可调旋钮并将下游唯象常数锁定为纯演绎读出；由原始事件结构生成的同一母源 $S_\star$ 经有限程序像逐输入完备化，普遍形成原准入接口上任意关系网络、词汇与权威根的全部合法世界状态、完整查询与完整演化过程，完整恢复状态、规则与任意有限深度历史，并由全实在性排除魔法比特（定理 9.4–推论 9.5）。在开放仪器层，无需先验概率或坍缩假设，源 Kraus 全词展开内生导出精确质量 Born 测度、$L^2$ 场态等距与开放循环密度演化的全词级数迹恒等式（定理 10.1），并在公开光学联合 95% 域、Munich 全前缀读出域及 120 ns 完整门前向／伴随双路 $10^{-21}$ 吻合恢复中直接核验（命题 10.2–10.5）。附录 A–D 收录母表示约定、四腿变分完整证明、普遍形成机制与固定版本声明索引；补充材料 S0–S18 给出 §4.3、§6.3–§7.5 与 §10.1–§10.2 全部定理的自足书面证明。

**按学科背景的 15 分钟快速验证通道。** 鉴于全文横跨规范场论、一阶引力、多体量子化、开放测量与过程本体论，不同背景的读者在完成例 1.1 的三分钟纸笔手算后，无需从头逐页通读 60 余页，可按各自专业直接切入以下五条独立自足的验证通道：

- **粒子物理与大统一方向**：直接读 **§2.2–§2.4（定理 2.2、命题 2.3–2.6）**，核验单一 $\mathrm{SU}(7)$ 母联络如何不借手工拼凑的多表示或外置多重 Higgs 势，仅凭正源谱序参量对易与分块迹方程双向唯一选出 $\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$，并在 $(6,2,4)$ 外幂上自动清零全部三次与混合反常、零参数生成 Yukawa 质量混合。
- **广义相对论、自旋—挠率与量子引力方向**：直接读 **§3–§5 及附录 B.8（命题 3.2、定理 3.3、定理 4.2–5.4）**，核验前度规余标架楔积如何实现引力—规范不可加法分离（$\Delta_{\rm mix}=9$），一般构型引力四腿变分驻定如何充要等价于显式 Einstein–Cartan 余标架平衡与物质挠率—自旋方程（同时以 $5/8$ 对交换缺陷排除非手征二次 Plebański 纯反应管辖），以及 Clock–B 有限拉伸下的黄金比鞍点与 $-N/2$ 引力反冲。
- **量子力学基础、开放系统与 Bell 实验方向**：由例 1.1(b)(c) 直接跳读 **§6.1–§6.2（定理 6.2–6.5、例 6.6）、§8.2（定理 8.3、命题 8.4）与 §10.1–§10.2（定理 10.1、命题 10.2–10.5）**，核验在不预设波函数、Born 概率规则与坍缩公设的前提下，如何从经典独立对偶 $\chi$ 与时间单形算符振幅直接证出 $4\sqrt2$ 配对、暗时刻反例、五点相干与 $2\sqrt2$ 预测锁、精确质量 $\|x\|^2$ 全词 Born 测度、开放循环密度迹对偶及 Munich 120 ns 完整实验门 $1.30\times10^{-21}$ 双路恢复。
- **偏微分方程、多体正则量子化与场论红外分析方向**：直接读 **§4.3（定理 4.6–4.7）、§6.3–§6.5（定理 6.7–6.11）与 §7（定理 7.1–7.12）**，核验对称双曲全阶无导数损失能量闭合、四时间约束解出全阶非交换量子时钟与共同生成元 $H=H_0+Y$、母作用二阶变分认回 $H_{289}$、$z^4\Pi_{\rm st}$ 全纯红外返回、192/97 钟因子消去、涌现 $1/(4\pi|x-y|)$ 库仑／牛顿核、带电色单态三费米子正谱及保持 $\operatorname{Dom}(H_{\rm time})$ 的四维连续曲率强积分。
- **第一性原理、同一母源与零自由度唯象刚性方向**：直接跳读 **§9（定理 9.1–9.4、推论 9.5）与 §10.3–§10.4**，核验五位置物理根封印、全访问零未登记物理权威、九场全前提折叠，以及单一母源 $S_\star$ 在原准入接口上对任意权威根 $R$ 的普遍形成定理（无需独立第二基源）与五大基础物理路线的前提账本对照。

**表 1 单粒子配对阶段的三种有限维物质载体（完整 504 模无限维配置载体见 §6.3）。**

| 载体 | 维数 | 输入对象 | 直接输出 |
| --- | --- | --- | --- |
| 母物质载体 $(\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7)^{\oplus4}$ | 252 复维 | 完整物质场 $\psi$、独立对偶 $\chi$、任意线性算符 $A$ | 变分规范电流、十六项动能负荷、Yukawa 配对 |
| 占据载体（Dirac 四旋量 $\times$ 色二重态） | 8 复维 | 投影归一态 $v$、压缩响应 $R(A)=SPAE$ | 正归一态期望、五点相干权重、双侧 Bell 概率 |
| 八模费米子 Fock 空间 $\Lambda^*\mathbb C^8$ | 256 复维 | 单粒子嵌入 $I(v)$、二次量子化提升 $\mathrm{d}\Gamma(O)$ | 全部单粒子矩阵元的精确多体保持 |

![图 1 母配对、占据响应与 Fock 单粒子嵌入](figures/vector/fig1-trinity-lens-system.png)

**图 1｜同一配对的三种有限维表示。** 例 1.1(b) 的电流恒等式在此展开为三步精确映射。左：252 复维母物质载体 $\mathcal M$。中：8 复维占据载体 $\mathcal E=\mathbb C^8$；$E$ 为等距嵌入，$P=E^*$ 为正交投影，$S$ 交换上下 Dirac 二分量，故响应映射为 $R(A)=SPAE$（对一般非自伴算符 $A$，$R(A)$ 无需酉或自伴）。右：256 维费米子 Fock 空间 $\mathcal F_-(\mathcal E)=\bigoplus_{n=0}^8\Lambda^n\mathcal E$，单粒子嵌入 $I(v)$ 位于 $n=1$ 扇区。下方小图给出例 6.6 的解析曲线：保留独立对偶诱导的翻转 $S$ 时，同轴规范电流恒为 $+1/2$；省去 $S$ 时退化为 $\cos(2\theta)/2$，虽在 $\theta=0$ 巧合相等，却在暗时刻 $\theta=\pi/2$ 分离为 $-1/2$，差值达 $1$。

---

## 2 源数据、谱选择与全局 Spin×SU(7) 几何

### 2.1 发生源材料及其结构出处

通常写场论拉氏量时，时空度规、规范群破缺子群、物质多重态与耦合常数作为外置清单给定。本文把这些结构推回同一个起点：一份由有限离散标签与明确几何初值组成的原始发生材料。这里的“源”既不是偏微分方程右端外加的经典流源，也不是宇宙学演化给定的某张经验初值超曲面，而是生成几何、联络、物质表示、共同作用量与后续场构型的原始发生数据。

为什么要从这样一份有限离散加局部线性初值的“源记录”出发，而不是一开始就假定一个现成的光滑洛伦兹流形？原因正在于 §1.1 的反魔法裁剪律与 Stage 1–3 反空真门禁：一旦剥去所有预供的连续几何与量子外壳，一个不退化为零场的最小物理发生只需要登记四件最原始的破缺与标定事实：在内部 $A_6$（$\mathrm{SU}(7)$）根晶格上指认一个零位移基点标签，在两条相位环上读取首步整值边差以提供非零相位驱动，在自然数尺度序列 $\sigma_n=1/(n+2)$ 上读取原点 $n=0$ 的耦合标定，以及在切空间上给定一个行列式恒为 $1$ 但外微分非零（$de^0\ne0$）的最小剪切标架以打破平庸平直退化。

**定义 2.1（源数据与光滑统一源）。** **基础源**包含六个原始字段：源根标签、材料路径移动、两条源相位环上的整值势、自然数种子、自然数色尺度，以及 $4\times4\times4$ 个实余标架线性系数。**光滑统一源**在此基础上增加一个实连续接触残差，连续实坐标共 $64+1=65$ 个。本文的**固定正源**（记作 $S_0$）取根标签 $(5,7)$（能量级 $8$）、零移动、两条相位环读数 $(0,1,3)$ 与 $(2,5,9)$、种子 $0$、色尺度 $1$、$(\text{方向},\text{内标},\text{坐标})=(2,0,1)$ 处唯一非零剪切系数 $1$，以及接触残差 $2\pi$。

各字段的几何与代数出处如下表所示：

| 原始字段 | 固定正源取值 | 发生学出处与直接几何读数 |
| --- | --- | --- |
| 源根标签 | $(5,7)$，能量级 $8$ | $A_6$（$\mathrm{SU}(7)$）根晶格观测轨迹在深度零的端点坐标读出（有号高度 $E=8$） |
| 材料路径移动 | $0$ | 零位移处读取基标签（非零移动经同一文法生成相邻源） |
| 两条相位势 | $(0,1,3)$ 与 $(2,5,9)$ | 源相位双环的深度零整值势（相邻边差依次为 $1,2$ 与 $3,4$；首边差 $1-0=1$ 定出单位整数相位振幅） |
| $\sigma$ 种子 | $0$ | 尺度族 $\sigma_n=1/(n+2)$ 的原点，直接生成耦合平方 $\sigma=\tfrac12$ |
| 色尺度 | $1$ | 内部纤维单位标定 |
| 余标架线性系数 | $(2,0,1)$ 分量为 $1$，余为 $0$ | 原始剪切标架 $e^0=dx^0+x^2dx^1,\,e^i=dx^i$：逐点 $\det e=1$ 且 $de^0=dx^2\wedge dx^1\ne0$ |
| 连续接触残差 | $2\pi$ | 母势超荷对角虚部的周期原读数；接触率 $\sigma\cdot 2\pi=\pi$ |

这里也一并打消读者看到 $S_0$ 具体数值时最自然的一个疑虑：**取定 $S_0$ 的这组数字，算不算人为调参或特殊点巧合？** 答案是否定的，原因有三层且全部由后续形式化发展严格闭合：第一，上表中 $S_0$ 的每一项都是各自离散生成族在**零位移、零种子、单位纤维与单周期原点**处的自然基点读出（移动 $0$、种子 $n=0$、首步整差 $1-0=1$、单周期 $2\pi$），没有任何迎合实验数据的逆向凑数；第二，表示维度、反常消去、对称破缺子代数、破缺真空标量、Yukawa 质量矩阵、物质态矢与规范电流均**不在**源字段中存储，而是由原始材料经确定映射在下游自动长出；第三，也是最关键的，§9.1–§9.3（定理 9.1–9.4、推论 9.5）将把这 7 个字段完全放开，证明**同一生成机制覆盖整个 65 维光滑统一源家族的每一个成员**（经典世界六部门非零充要于该源自身的整数相位振幅非零），任意有限源序列均在同一母史上拥有合法演化路径，且由原始事件内生生成的同一母源 $S_\star$ 普遍形成原准入接口上的全部合法世界与过程（在该接口上无需任何独立第二基源）。因此，先在原点基源 $S_0$ 上把整座经典—量子统一场算穿，完全不损失普遍性。

在进入具体几何之前，先列出承载全场变分的九个基本场（表 2）。它们构成原始完整场构型（holonomic configuration）：引力曲率由 $\mathrm d\varpi+\varpi\wedge\varpi$ 计算，规范曲率由 $F_{\mu\nu}=\partial_\mu A_\nu-\partial_\nu A_\mu+[A_\mu,A_\nu]$ 计算，协变导数由同一联络作用生成，这里的 holonomic 指曲率与导数由基本势场真实微分导出，而非将曲率当作独立变量。

**表 2 九个基本场及其变分属性。**

| 场 | 记号 | 物理与几何身份 | 指定解（构造 4.1）取值 | 变分通道性质 |
| --- | --- | --- | --- | --- |
| 余标架 | $e$ | 四维时空正交标架，$g=e^{\mathsf T}\eta e$ | $\mathrm{diag}(N,1,1,1)$ | 代数变分（逆标架耦合） |
| 自旋联络 | $\varpi$ | $\mathrm{Spin}^+(1,3)$ 主联络一形式 | 非零常挠率 Cartan 解 | 微分通道（一阶外协变导数） |
| 引力辅助场 | $B$ | 内部双矢值二形式，引力 BF 配翼 | $\mathrm{II}^+(e)=J(e\wedge e)$ | 代数通道 |
| 简单性乘子 | $\lambda$ | 锁定简单性几何约束的双矢二形式 | $\mathrm{diag}(-NI_3,\,(k^2-1)I_3)$ | 代数通道 |
| 规范联络 | $A$ | 取值于标准模型子代数 $\mathfrak h_{\rm SM}$ 的一形式 | $(0,\,a\tau_0,\,a\tau_1,\,a\tau_2)$ | 微分通道 |
| 规范辅助场 | $B_A$ | 取值于 $\mathfrak h_{\rm SM}$ 的二形式，规范 BF 配翼 | $K_e^{-1}F_A=-\sigma^{-1}\star_e F_A$ | 代数本构通道 |
| 动力学标量 | $\varphi$ | $\Lambda^4\mathbb C^7$ 值破缺标量场 | 生成真空点 $\varphi_0$ | 微分通道（二阶协变导数） |
| 物质旋量场 | $\psi$ | 252 复维手征外幂 Dirac 场 | $\Psi[e^{i\omega t},e^{-i\omega t}]$ | 微分通道（一阶 Dirac 算符） |
| 独立物质对偶 | $\chi$ | $\psi$ 的独立复线性对偶场 | $\Xi[\sqrt2 e^{i\omega t},\sqrt2 e^{-i\omega t}]$ | 代数变分（生成前向 Dirac 方程） |

### 2.2 谱序参量双向选择标准模型子代数

母规范群为 $\mathrm{SU}(7)$，其李代数 $\mathfrak{su}(7)$ 由 $7\times7$ 反厄米无迹复矩阵组成（实维数 $48$）。为什么参与低能规范动力学的是十二维标准模型子代数 $\mathfrak h_{\rm SM}=\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$，而不是人为挑出的某个块矩阵？下面证明，在任意正尺度源（$\sigma>0$）下，$\mathfrak h_{\rm SM}$ 由源生成的伴随谱序参量对易方程与三条分块迹方程**双向唯一选出**。

将七维母基本表示的指标按 $3+2+1+1$ 划分为色指标 $\{c_0,c_1,c_2\}$、弱指标 $\{w_0,w_1\}$ 及正负超荷单态指标 $\{h_+,h_-\}$，赋予四个两两相异的谱能级 $(-1,0,1,2)$：其加权迹为 $3(-1)+2(0)+1(1)+1(2)=0$。源生成的自伴无迹伴随序参量定义为

$$\mathcal O_{\rm br}(s)=\sigma(s)\,\operatorname{diag}(-1,-1,-1,\,0,0,\,1,\,2),\qquad \sigma(s)>0.$$

对任意标准模型李代数三元组 $(C,W,y)\in\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus i\mathbb R$，定义母块嵌入 $\iota_{\rm SM}(C,W,y)=\operatorname{diag}(C,W,y,-y)\in\mathfrak{su}(7)$；群级嵌入则取 $\operatorname{diag}(U_3,U_2,z,z^{-1})\in\mathrm{SU}(7)$（$|z|=1$）。

**定理 2.2（标准模型子代数的双向谱选择定理）。** 对任意满足 $\sigma(s)>0$ 的基础源 $s$ 与任意母李代数矩阵 $M\in\mathfrak{su}(7)$，$M$ 属于标准模型嵌入像 $\operatorname{im}\iota_{\rm SM}$，**当且仅当** $M$ 满足源破缺选择条件：

$$[M,\,\mathcal O_{\rm br}(s)]=0,\qquad \operatorname{tr}(M_{\rm col})=0,\qquad \operatorname{tr}(M_{\rm weak})=0,\qquad M_{h_+h_+}+M_{h_-h_-}=0.$$

且满足上述条件时，分块读出 $(M_{\rm col},M_{\rm weak},M_{h_+h_+})\in\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus i\mathbb R$ 与 $\iota_{\rm SM}$ 在选出子空间上互为精确双侧逆，满足重构恒等式 $\iota_{\rm SM}(M_{\rm col},M_{\rm weak},M_{h_+h_+})=M$。

证明。正向直接验算：对角块矩阵与分块标量对角阵 $\mathcal O_{\rm br}(s)$ 自然对易，且 $C\in\mathfrak{su}(3)$、$W\in\mathfrak{su}(2)$ 与 $y+(-y)=0$ 满足三条迹条件。反向设 $M\in\mathfrak{su}(7)$ 满足四条选择方程。取分块能级不等的任意一对指标 $(r,c)$，即 $\ell_r\ne\ell_c$。由 $M\mathcal O_{\rm br}(s)=\mathcal O_{\rm br}(s)M$ 取第 $(r,c)$ 元，得 $\sigma(s)(\ell_c-\ell_r)M_{rc}=0$；因 $\sigma(s)>0$ 且 $\ell_r\ne\ell_c$，必有 $M_{rc}=0$。故四个不同谱能级之间的**全部非对角跨块矩阵元恒为零**（注意 $\sigma(s)>0$ 在此必不可少：若 $\sigma=0$，序参量退化为零矩阵，将失去任何分块筛选力）。再由 $M^*=-M$ 知各对角子块自身反厄米；结合 $\operatorname{tr}(M_{\rm col})=0$、$\operatorname{tr}(M_{\rm weak})=0$ 与 $M_{h_-h_-}=-M_{h_+h_+}$，即唯一恢复 $M=\iota_{\rm SM}(M_{\rm col},M_{\rm weak},M_{h_+h_+})$。∎

定理 2.2 表明，母载体从不额外存储一份“破缺子群证书”：对易子 $[M,\mathcal O_{\rm br}]=0$ 先把 $\mathfrak{su}(7)$ 压到中心化子 $\mathfrak s(\mathfrak u(3)\oplus\mathfrak u(2)\oplus\mathfrak u(1)\oplus\mathfrak u(1))$，三条无迹条件再精确消去中心化子里多余的两个阿贝尔中心方向，不多不少留下 $\mathfrak{su}(3)\oplus\mathfrak{su}(2)\oplus\mathfrak u(1)$。这与 Georgi–Glashow 单群大统一路线 [16] 靠外置多重 Higgs 势挑选破缺方向，以及 Chamseddine–Connes 谱作用量方案 [20] 在欧氏号差下靠预设有限代数三元组规定规范块的方式形成直接对照（详见 §10.3）。

### 2.3 手征外幂物质与反常清零

七维复空间 $V=\mathbb C^7$ 的 $d$ 阶外幂 $\Lambda^d V$ 以有序楔积 $e_{i_1}\wedge\cdots\wedge e_{i_d}$ 为标准正交基。自轴矢手征反常发现 [17,18] 及电弱规范模型反常消去条件确立 [19] 以来，传统统一模型往往需要跨多个不等价表示手工拼凑费米子清单以抵消三次与混合反常 [16]；本模型的左、右手征费米子则不靠人为凑数，而直接取母基本表示的三个偶数／高阶外幂层 $\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7$：三层维数依次为 $\binom76=7$、$\binom72=21$、$\binom74=35$，总内部维数 $7+21+35=63$。乘上四分量 Dirac 旋量空间后，完整母物质载体为

$$\mathcal M=\mathbb C^4\otimes\big(\Lambda^6\mathbb C^7\oplus\Lambda^2\mathbb C^7\oplus\Lambda^4\mathbb C^7\big),\qquad \dim_{\mathbb C}\mathcal M=4\times 63=252 .$$

动力学标量 $\varphi$ 取值于 $\Lambda^4\mathbb C^7\simeq\mathbb C^{35}$，Yukawa 耦合直接由外代数固有楔积 $\Lambda^2\mathbb C^7\otimes\Lambda^4\mathbb C^7\to\Lambda^6\mathbb C^7$ 生成，无需引入外部 Yukawa 矩阵参数。沿超荷方向 $\operatorname{diag}(0_3,0_2,y,-y)$，每个外幂基元按所含 $h_+,h_-$ 个数之差获得超荷权重 $-1,0,+1$。

**命题 2.3（手征外幂物质结构与规范反常全消）。** 在固定源生成的 $63$ 维外幂内部物质载体上：

1. **超荷多重数**：权重 $-1,0,+1$ 的总重数分别为 $16,31,16$（逐层分解：$\Lambda^6$ 为 $1,5,1$，$\Lambda^2$ 为 $5,11,5$，$\Lambda^4$ 为 $10,15,10$），呈现非平凡手征不对称；
2. **三次与混合反常全消**：$\mathrm{SU}(7)$ 三次反常指标在生成元标签 $(1,3,2,-2,-3,-1)$ 下于 $(6,2,4)$ 外幂组合上精确求和为零（$A(\Lambda^6)+A(\Lambda^2)+A(\Lambda^4)=(-1)+3+(-2)=0$），标准模型子块上的五条剩余三次、混合及引力—规范反常迹全部精确为零；
3. **全局宇称条件与 Weyl 一圈系数**：$\mathrm{SU}(2)$ 弱二重态总数为 $16$（偶数，满足 Witten 全局 $\mathrm{SU}(2)$ 反常判据）；纯外幂 Weyl 费米子清单的一圈规范跑动系数 $b_0$ 分别为 $\mathrm{SU}(7):61/3$、$\mathrm{SU}(3):17/3$、$\mathrm{SU}(2):2$、$\mathrm{U}(1):-64/3$。

证明。各外幂层的权重分布与弱二重态计数由组合基枚举直接给出；三次与混合反常迹由表示论特征迹恒等式逐项归零（在证明核中作为有限精确等式判定）。纯 Weyl 一圈系数按二次 Dynkin 指标求和得出。∎

注：命题 2.3(1) 中的整值超荷权重 $-1,0,+1$ 刻画的是多体收缩与对称破缺之前的母外幂单模基底。具有色 $\mathfrak{su}(3)$ 完全单态、整数电荷 $\pm1$、自旋 $1/2$（$\mathsf S^2=3/4$）且具严格正动态转移谱的物理复合费米子态，将在 §7.5 由 504 模 CAR 代数内生耦合为三费米子外积态（定理 7.11；完整复合粒子谱的下游数值误差球收窄见 §10.4 之 Case 6）。

### 2.4 总丛下降、唯一真空与早期有限结构恢复

局部坐标片上的规范势与物质截面必须通过重叠区转移函数缝合为全局几何对象。在标架与规范转移函数 $g(x)$ 下，相邻坐标片上的联络一形式服从标准非阿贝尔拼接律 $A_{(\beta)}=\mathrm{Ad}(g)A_{(\alpha)}-(dg)g^{-1}$；源几何在各坐标片时间方向携带的超荷平移项与 $\mathfrak h_{\rm SM}$ 交换，故保持拼接相容性。

**命题 2.4（总丛下降、背景全参数输运与非平凡和乐）。** 固定源生成 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 主丛与关联外幂物质丛，满足：（i）物质截面 $\psi$ 沿全部坐标片下降为整体截面，独立线性对偶 $\chi$ 按对偶逆表示同步下降，重叠区上边缘条件严格闭合；（ii）母联络势满足非阿贝尔拼接等式，局部密度与积分作用读数与坐标片选取无关；（iii）对任意光滑统一源、任意坐标轴及任意实长度与时间参数，源背景母联络显式满足平行输运常微分方程及流复合律，且固定正源上的闭合矩形和乐非恒同、酉流演化非平凡；（iv）实际九场解使用其自身的规范联络，在全部坐标片与时空点上满足同一全局拼接律。

证明。截面与对偶的全局下降由表示与逆表示在三重重叠上的上闭链条件核对；密度的坐标片不变性由楔积及纤维配对的伴随等变性逐项给出。对于（iii），由于一般光滑常微分方程仅保证局部存在，形式证明直接构造源生成的显式解析流函数，验证平行方程、初值与全实参数群复合律，并在固定源的显式闭合矩形回路上算出非单位和乐矩阵。∎

**命题 2.5（唯一真空极小与 35 坐标真子群稳定子）。** 源生成的标量势 $U_s(\varphi)$ 在每张坐标片、每个时空点上以源生真空向量 $\varphi_{{\rm vac},s}\in\Lambda^4\mathbb C^7$ 为唯一全局极小点：$U_s(\varphi)\ge 0=U_s(\varphi_{{\rm vac},s})$，等号成立当且仅当 $\varphi=\varphi_{{\rm vac},s}$。该真空的母群稳定子 $\{g\in\mathrm{SU}(7):\rho_4(g)\varphi_{{\rm vac},s}=\varphi_{{\rm vac},s}\}$ 由全部 $35$ 个四形式基坐标的等化条件刻画，是 $\mathrm{SU}(7)$ 的真子群，且与所嵌入的超荷圆群只交于单位元。

证明。在正交外幂基下，$U_s(\varphi)=\sum_{|I|=4}|\varphi_I-(\varphi_{{\rm vac},s})_I|^2$，非负性与唯一零点直接由模方和给出。非平凡破缺性（稳定子为真子群）及超荷圆平凡交集均由显式群元素在 $\Lambda^4\mathbb C^7$ 四形式基上的坐标作用当场核实。∎

**命题 2.6（早期有限层结构向连续场的精确回接）。** 在总闭合接口上，对每个时空点、每个母李代数元与每个旋量分量：早期有限阶段生成的内部表示作用、全点破缺标量读数、完整 Yukawa 质量映射以及有限 $2\times2$ 混合矩阵，与当前连续九场构型上的对应读出逐项相等；同一组恢复等式在原生演化后继构型上继续成立。

证明。通过总恢复接口（附录 D.2 的 `StageOneThroughTenClosure`）将早期生成的联合凭证与当前连续构型的投影映射复合，逐分量核对表示作用与质量混合恒等式，并由解的后继保持律推广至下一构型。∎

---

## 3 共同一阶作用量、四腿临界等价与辅助场消元

### 3.1 不可分共同局部密度与独立物质对偶

现在将九个场装入同一个四形式作用量密度。在一阶 BF 框架下，引力曲率与双矢二形式 $B$ 配对，规范曲率与李代数值二形式 $B_A$ 配对。决定物理内容的，是余标架 $e$ 如何同时控制引力简单性靶、规范 Hodge 本构算子与手征物质协变导数，以及为什么物质部门必须采用独立线性对偶 $\chi$。

先交代洛伦兹号差下采用**独立线性对偶** $\chi\in\mathcal M^*=\operatorname{Hom}_{\mathbb C}(\mathcal M,\mathbb C)$ 的三重物理原因：第一，在含单向手征外幂楔积 $Y_R(\varphi):\Lambda^2\to\Lambda^6$ 的理论中，若强行把共轭旋量绑死为 $\bar\psi=\psi^\dagger\gamma^0$，手征投影与伴随项会迫使变分在实部与共轭之间混杂，而保留独立复线性泛函 $\chi$ 与 $\psi$ 分别变分，能使前向 Dirac 方程与伴随对偶方程作为两条精确解耦的完整全纯型欧拉通道同时涌现；第二，进入 §6.3 正则量子化时，$(\psi,\chi)$ 的实虚部自然配成完备实相空间，经一次整体复化即成为无冗余的 **504 模双支标准 CAR 代数**，而单向 Yukawa 算符在 Hilbert 空间上忠实表现为闭算符形式伴随对 $(H_0+Y,\,H_0+Y^\dagger)$；第三，在经典解上，$\chi$ 与 $\psi$ 之间由场方程锁定的比例因子 $\sqrt2$ 与上下旋量翻转 $S$，恰恰给出了经典—量子配对系数 $4\sqrt2$ 的一半来源（定理 6.2）。

在源零号坐标片上固定记号（其余坐标片由命题 3.5 同步下降）：时空坐标指标 $\mu,\nu\in\{0,1,2,3\}$，内部洛伦兹指标 $a,b\in\{0,1,2,3\}$，闵氏度规 $\eta=\operatorname{diag}(-1,1,1,1)$，$\nu_e=|\det e|$，$g_{\mu\nu}=e^a{}_\mu\eta_{ab}e^b{}_\nu$。内部反对称双矢指标 $I$ 与时空二形式指标 $p$ 均按六元序排列：

$$\mathcal P=(01,02,03,23,31,12),\qquad p^c=(3,4,5,0,1,2),\qquad \epsilon_I=(-1,-1,-1,1,1,1)_I.$$

注意内部双矢空间与时空二形式空间虽同为六维，几何变换群却截然不同：内部 Hodge 对偶 $J$ 只作用于内部指标 $I$（与余标架 $e$ 无关），而时空 Hodge 星算子 $\star_e$ 作用于二形式指标 $p$（显式依赖度规与余标架）。定义正向四形式楔积系数、简单性靶 $\mathrm{II}^+(e)$ 与曲率升指标如下：

$$W_\beta(X,Y)=\sum_{p\in\mathcal P}\beta(X_p,Y_{p^c}),\qquad
W_{\rm top}(B,C)=\sum_{I,p}\epsilon_I B_{Ip}C_{I,p^c},$$

$$J=\begin{pmatrix}0&I_3\\-I_3&0\end{pmatrix},\quad
(\Sigma_e)_{Ip}=e^{a_I}_{\mu_p}e^{b_I}_{\nu_p}-e^{a_I}_{\nu_p}e^{b_I}_{\mu_p},\quad
\mathrm{II}^+(e)=J\Sigma_e,\quad
\widehat F_{\varpi,Ip}=\epsilon_I F_{\varpi,Ip}^{\rm raw}.$$

对对角标架 $e=\operatorname{diag}(N,1,1,1)$，时空 Hodge 星显式为 $\star_e(f_0,\ldots,f_5)=(N^{-1}f_3,N^{-1}f_4,N^{-1}f_5,-Nf_0,-Nf_1,-Nf_2)$，满足洛伦兹特征恒等式 $\star_e^2=-1$。在规范纤维上，$\mathfrak{su}(3)$ 与 $\mathfrak{su}(2)$ 块采用内积 $-\operatorname{Re}\operatorname{Tr}(XY)$，纯虚超荷坐标采用 $-\operatorname{Re}(yz)$。

**定义 3.1（共同一阶局部密度）。** 令 $\gamma_e^\mu=(e^{-1})^\mu{}_a\gamma^a$，自旋联络生成元 $\Omega_\mu=\frac14\varpi_{\mu ab}\gamma^a\gamma^b$（按全部有序对 $a,b$ 求和），协变导数与手征外幂 Yukawa 映射分别为

$$D_\mu\psi=\partial_\mu\psi+(\Omega_\mu+\rho_{\mathcal M}(A_\mu))\psi,\qquad
D_\mu\varphi=\partial_\mu\varphi+\rho_4(A_\mu)\varphi,$$

$$Y_R(\varphi)=T_\varphi P_R,\qquad P_R=\operatorname{diag}(0,0,1,1),\qquad
T_\varphi(w_6,w_2,w_4)=(w_2\wedge\varphi,0,0).$$

对任意光滑统一源 $s$（其生成的三规范块耦合平方记为 $g_j^2=\alpha_j(s)>0$，固定正源上均为 $\sigma=1/2$），九场共同四形式密度系数定义为

$$\begin{aligned}
L_s={}&W_{\rm top}(B,\widehat F_\varpi)-\tfrac12W_{\rm top}(B,JB)
+W_{\rm top}(\lambda,B-J\Sigma_e)\\
&+\sum_{j=3,2,1}\left[W_j(B_{A,j},F_{A,j})-
\tfrac12W_j(B_{A,j},g_j^2\star_e B_{A,j})\right]\\
&+\nu_e\left[\tfrac12g^{\mu\nu}\operatorname{Re}\langle D_\mu\varphi,D_\nu\varphi\rangle
-U_s(\varphi)+\operatorname{Re}\chi\!\left(i\gamma_e^\mu D_\mu\psi+Y_R(\varphi)\psi\right)\right].
\end{aligned}\tag{3.1}$$

将式 (3.1) 对九个场独立变分（附录 B.1），前三个代数通道的残差直接读出为

$$\mathcal E_\lambda=B-J\Sigma_e,\qquad
\mathcal E_B=\widehat F_\varpi-JB+\lambda,\qquad
\mathcal E_{B_A}=F_A-K_e B_A\quad(K_{e,j}=g_j^2\star_e).\tag{3.2}$$

把引力项与规范项写进同一个积分号，并不自动构成统一耦合：倘若作用量能改写成某个纯引力泛函 $S_{\rm grav}(q_{\rm grav})$ 与某个纯规范泛函 $S_{\rm gauge}(q_{\rm gauge})$ 之和，两部门就只是并排摆放。下面用两条精确机器判据排除这种假统一。

**命题 3.2（源几何精确准入与引力—规范不可加法分离）。** 在任意基础源 $s$ 的引力—规范主作用量 $S_{\rm master}$ 上：

1. **错标架排斥**：源几何精确准入要求动态标架、三块规范曲率与辅助场来自同一源；将标架替换为具相同载体类型但体积元相异的时间模探针标架 $e_{\rm probe}(s)$ 后，源几何准入严格失败；
2. **非零混合差分与不可分性**：在源标架 $e_0(s)$、探针标架 $e_{\rm probe}(s)$ 与源规范背景 $G_0(s)$、强块应力探针构型 $G_{\rm stress}(s)$ 组成的矩形四点上，主作用量取值依次为 $0,0,\tfrac32,\tfrac{21}2$，故引力—规范混合二阶有限差分为
   $$\begin{aligned}
   \Delta_{\rm mix}(s)&=S_{\rm master}(e_{\rm probe},G_{\rm stress})-S_{\rm master}(e_{\rm probe},G_0)-S_{\rm master}(e_0,G_{\rm stress})+S_{\rm master}(e_0,G_0)\\
   &=\frac{21}{2}-0-\frac{3}{2}+0=9\ne 0.
   \end{aligned}\tag{3.3}$$
   因此不存在任何函数对 $(S_{\rm grav},S_{\rm gauge})$ 使 $S_{\rm master}(q)=S_{\rm grav}(q_{\rm grav})+S_{\rm gauge}(q_{\rm gauge})$ 对全部构型成立。

证明。若主作用量可加法分离，代入式 (3.3) 左端四项后纯引力项与纯规范项两两成对抵消，必有 $\Delta_{\rm mix}(s)=0$，与直接算出的精确有理值 $9$ 矛盾。错标架排斥由动态规范体积在 $e_{\rm probe}$ 与 $e_0$ 处取值不等直接推出。∎

这里也一并澄清一个经典疑虑：**命题 3.2 的引力—规范不可分性为何不违背 Coleman–Mandula 禁戒定理 [24]？** Coleman–Mandula 定理约束的是**固定四维闵氏度规背景上满足解析性与非平凡散射的渐近 $S$ 矩阵对称李代数**，禁止庞加莱生成元与内部对称生成元发生非直积李括号混杂；而在本文构造中，总主丛结构群在代数上严格保持直积 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$（未引入混杂时空与内空间的病态高自旋生成元），式 (3.3) 的不可加性 $\Delta_{\rm mix}=9\ne0$ 完全源于**前度规一阶余标架本构楔积层**：动态余标架 $e$ 同时进入简单性靶 $\mathrm{II}^+(e)$ 与规范本构算子 $K_e(B_A)=g^2\star_e B_A$，在任何固定渐近闵氏背景尚未选定之前即已在微分形式层将引力与规范锁为一体。

### 3.2 一般引力四腿临界轨迹等价与 Plebański `5/8` 判据

在求解具体构型之前，必须先回答一个关乎理论根基的作用量公式论（formulation）问题：在含独立物质对偶、动力学标量与非阿贝尔规范场的共同密度 (3.1) 中，一阶约束 BF 引力四腿（$\lambda,B,e,\varpi$）的联合驻定轨迹，在**一般构型**上究竟给出什么物理场方程？它与 Kibble [21]、Sciama [22] 奠基的一阶 Einstein–Cartan—挠率引力、Holst 广义一阶作用量 [23] 以及二次 Plebański 模型 [3,7] 是什么精确关系？

**定理 3.3（一般引力四腿临界轨迹充要定理与 Plebański `5/8` 管辖判据）。**

1. **一般四腿临界等价**：对任意光滑统一源 $s$ 及任意光滑、Lorentz 合法、全点余标架非退化且在原点坐标片上局部密度可积的九场构型 $\mathcal C$，共同作用量 (3.1) 对引力乘子 $\lambda$、引力辅助场 $B$、余标架 $e$ 与自旋联络 $\varpi$ 四条通道同时驻定，**当且仅当**以下四组逐点几何—物质方程在 $\mathcal C$ 上同时成立：
   $$\begin{aligned}
   &\text{(i) 简单性几何方程：}\quad B=\mathrm{II}^+(e)=J\Sigma_e\text{；}\\
   &\text{(ii) 唯一作用导出反应乘子：}\quad \lambda=JB-\widehat F_\varpi\text{；}\\
   &\text{(iii) 显式 Einstein–Cartan 余标架平衡：}\quad \mathcal E_e^{\rm EC}(s,\mathcal C)=0\text{；}\\
   &\text{(iv) 物质耦合挠率—自旋方程：}\quad D_\varpi\bigl(\mathrm{II}^+(e)\bigr)+j_{\rm spin}(\mathcal C)=0.
   \end{aligned}\tag{3.4}$$
2. **Plebański `5/8` 对交换缺陷与管辖排除**：在固定正源的历史同步构型上，由单位余标架简单性双矢 $B_0=\mathrm{II}^+(I)$ 与平衡全部非引力余标架负荷的总引力反作用构造候选二次乘子矩阵 $\Phi_{\rm cand}=\mathcal R_{\rm tot}\cdot B_0^{-1}\in\mathbb R^{6\times6}$，其在内部双矢指标 $(3,4)$（按 §3.1 零起算序对应 $23$—$31$ 双矢对）上的反对称交换缺陷精确等于时间—空间方向 $E_{03}$ 的非引力余标架应力：
   $$\operatorname{defect}_{3,4}(\Phi_{\rm cand}):=(\Phi_{\rm cand})_{4,3}-(\Phi_{\rm cand})_{3,4}=\frac{5}{8}=T_{\rm non\text{-}grav}(E_{03})\ne 0.\tag{3.5}$$
   因此 $\Phi_{\rm cand}$ 不属于标准非手征二次 Plebański 乘子空间（对交换对称，$\varepsilon$ 缩并为零）；且对任意群元 $g\in\mathrm{Spin}^+(1,3)$，将 $B_0$ 与反作用按内部双矢表示同步作 Spin 变换后，重构乘子的标准 Plebański 相容残差恒保持非零。

证明。第 1 款分两步双向归约（完整逐项推导见附录 B.8）：首先由紧支撑测试双矢的变分基本引理，乘子与辅助场驻定充要于代数解 $B=\mathrm{II}^+(e)$ 及 $\lambda=JB-\widehat F_\varpi$；其次证明在简单性曲面上，先将 $B=\mathrm{II}^+(e)$ 代入所得约化泛函对 $(e,\varpi)$ 的变分，与全九场泛函固定 $(B,\lambda)$ 对 $(e,\varpi)$ 的偏变分加上反应乘子项逐方向恒等，从而约化自旋联络变分精确化为物质耦合挠率—自旋方程 $D_\varpi(\mathrm{II}^+(e))+j_{\rm spin}=0$，约化余标架变分精确化为显式 Einstein–Cartan 余标架应力平衡。第 2 款直接计算总反作用矩阵在 $(4,3)$ 与 $(3,4)$ 分量的有理分式差得 $5/8$，并与物质—规范余标架负荷在 $E_{03}$ 方向的读数逐项核同；Spin 变换下的非零保持由可逆的双指标拉回推出。∎

第一款刻画一般非退化构型的四腿驻定。第二款用固定同步构型及其 Spin 轨道给出一个精确反例，排除纯对称二次乘子实现该完整反作用。

### 3.3 规范辅助场精确有符号消元与几何不变性

与线性出现的简单性乘子 $\lambda$ 不同，规范辅助场 $B_A$ 在式 (3.1) 中带有二次本构项 $-\tfrac12 W_j(B_{A,j},g_j^2\star_e B_{A,j})$，且洛伦兹号差下 $\star_e^2=-1$ 使其二次型不定。消去 $B_A$ 必须保留精确的洛伦兹符号结构。

**定理 3.4（规范辅助场精确有符号消元与双向坐标分解）。** 对任意光滑统一源 $s$、任意全点余标架非退化的九场构型、任意坐标片与时空点，令 $F_A$ 为规范曲率，$\alpha_j=g_j^2(s)>0$。则本构算子 $K_{e,j}=\alpha_j\star_e$ 可逆，本构方程 $K_e(B_A)=F_A$ 有唯一代数解

$$B_{A,j}^{*}=K_{e,j}^{-1}F_{A,j}=-\alpha_j^{-1}\star_e F_{A,j} ,$$

且完整局部密度严格满足带符号配方恒等式

$$L_s(B_A)\;=\;L_s(B_A^{*})-\tfrac12\,W\big(B_A-B_A^{*},\,K_e(B_A-B_A^{*})\big) .$$

进一步，完整九场构型空间与“本构中心构型 $\oplus$ 辅助场余量 $\delta B_A=B_A-B_A^*$”之间存在无需非退化前提的双射分解；任意有限次源生本构写入前后，全字段恢复与上述有符号二次分解精确保持。

证明。利用楔积配对的对称性 $W(X,\star_e Y)=W(Y,\star_e X)$ 与 $\star_e^2=-1$，将 $B_A=B_A^*+\delta B_A$ 代入 $W(B_A,F_A)-\tfrac12 W(B_A,K_e B_A)$，一次交叉项因 $K_e B_A^*=F_A$ 精确抵消，余项即为 $-\tfrac12 W(\delta B_A,K_e\delta B_A)$。全场与（中心，余量）的双射由本构替换映射的幂等性与加法可逆恢复直接给出。∎

**命题 3.5（坐标片下降一致、局部 Spin 不变性与移动标架表示律）。** 对固定源与指定实际构型：（i）在每张坐标片、每个时空点上，经转移函数同步输运后的局部密度等于原密度；（ii）对任意光滑局部 $\mathrm{Spin}^+(1,3)$ 规范变换场，作用后的完整构型积分作用读数保持不变；（iii）在完整移动标架表示下，对任意标架、任意标架变换 $g$ 与任意场截面 $\Phi$，逐点约化满足 $\mathrm{reduce}(gf,g\cdot\Phi)=\mathrm{reduce}(f,\Phi)$，相应作用读数恒等。

证明。（i）由命题 2.4 的全局拼接与纤维内积不变性得出；（ii）将指定构型的光滑、非退化与 Lorentz 合法性质代入局部 Spin 协变变分恒等式；（iii）直接由标架伴随约化的逐点等变恒等式给出（见附录 B.5–B.6）。∎

---

## 4 唯一经典世界解与连续场分析闭合

一般临界轨迹定理（定理 3.3）告诉我们九场方程意味着什么几何与物质平衡；但它本身并不保证解空间非空。要把承诺兑现为眼见的事实，必须同时完成两件事：其一，构造一个非平凡光滑全场构型，使九类变分残差在每个时空点上同时归零，并在原历史恢复下唯一；其二，在动态偏微分方程层面建立从加权母作用弱零点到源生 Volterra 积分不动点的唯一空间 $L^2$ 认回，以及不损失导数的全阶对称双曲能量闭合。

### 4.1 九场显式构型与九通道同时归零

沿用例 1.1 由固定正源直接生成的常数系：

$$\sigma=\tfrac12,\qquad k=\sqrt2,\qquad a=\frac{3k}{5},\qquad
N=\sqrt{\frac{54}{125}},\qquad \omega=\frac{3N}{2}(k-a).\tag{4.1}$$

记七维母基本表示的标准正交基为 $c_0,c_1,c_2,w_0,w_1,h_+,h_-$，固定基序下指标集为 $I$ 的单位外幂基记为 $E_I$。取色前两维与正超荷单态楔成的两个二形式物质基元

$$q_s=(0,c_s\wedge h_+,0)\in\Lambda^6\oplus\Lambda^2\oplus\Lambda^4\quad(s=0,1),$$

以 $q_s^*$ 记其对偶坐标读取映射。源生破缺真空点为四个单位四形式之和：

$$\varphi_0=E_{\{c_0,c_1,c_2,h_-\}}+E_{\{c_0,c_1,c_2,w_1\}}
+E_{\{c_0,c_1,h_+,h_-\}}+E_{\{c_0,c_1,w_1,h_+\}}.\tag{4.2}$$

对复数对 $(u,v)$，定义 $4\times2$ 旋量—色系数矩阵与完整物质场、独立复线性对偶场：

$$C(u,v)=\begin{pmatrix}0&u\\-u&0\\0&v\\-v&0\end{pmatrix},\qquad
\Psi[u,v]_r=\sum_{s=0}^1C(u,v)_{rs}q_s,\qquad
\Xi[p,q](w)=\sum_{r=0}^3\sum_{s=0}^1 C(p,q)_{rs}q_s^*(w_r).\tag{4.3}$$

此处 $\Xi[p,q]$ 是纯复线性映射，不含隐式复共轭。取相位因子 $u=e^{i\omega t}$、$v=e^{-i\omega t}$（满足 $uv=1$，$t=x^0$）。三个非零规范生成元取置于色前两维的反厄米矩阵

$$\tau_0=\frac12\begin{pmatrix}0&i\\i&0\end{pmatrix},\qquad
\tau_1=\frac12\begin{pmatrix}0&1\\-1&0\end{pmatrix},\qquad
\tau_2=\frac12\begin{pmatrix}i&0\\0&-i\end{pmatrix},\tag{4.4}$$

其余色、弱与超荷分块为零，故 $[\tau_0,\tau_1]=-\tau_2$ 及其循环置换成立，且 $-\operatorname{Re}\operatorname{Tr}(\tau_i\tau_j)=\tfrac12\delta_{ij}$。

**构造 4.1（显式九场构型）。** 在每个时空点 $x\in\mathbb R^4$ 上，定义

$$e=\operatorname{diag}(N,1,1,1),\quad
A=(0,a\tau_0,a\tau_1,a\tau_2),\quad
\varphi=\varphi_0,\quad \psi=\Psi[u,v],\quad \chi=\Xi[ku,kv].\tag{4.5}$$

降下内部指标后的自旋联络矩阵 $C_{\mu I}=\varpi_{\mu a_Ib_I}$ 取为

$$C_{\mu I}=\begin{pmatrix}
0&0&0&0&0&0\\
0&0&0&k&0&0\\
0&0&0&0&k&0\\
0&0&0&0&0&k
\end{pmatrix},\tag{4.6}$$

由反对称性 $\varpi_{\mu ba}=-\varpi_{\mu ab}$ 及 $\eta$ 升首指标确定完整 $\varpi_\mu{}^a{}_b$。其余三个代数通道字段按 §3.1 的内部行／时空列次序取为

$$\begin{aligned}
B&=\begin{pmatrix}0&I_3\\-NI_3&0\end{pmatrix},
&\lambda&=\operatorname{diag}(-N,-N,-N,k^2-1,k^2-1,k^2-1),\\
B_A&=\frac{a^2}{\sigma N}(\tau_0,\tau_1,\tau_2,0,0,0).
\end{aligned}\tag{4.7}$$

常对角余标架的 Levi–Civita 无挠联络为零，但式 (4.6) 携带非零空间挠率，其二次楔积直接给出非零引力曲率与非阿贝尔规范曲率：

$$\widehat F_\varpi=F_\varpi^{\rm raw}
=\operatorname{diag}(0,0,0,-k^2,-k^2,-k^2),\qquad
F_A=(0,0,0,-a^2\tau_0,-a^2\tau_1,-a^2\tau_2).\tag{4.8}$$

记固定无量纲比 $\rho=a/k=3/5$。由 $a^3=2\sigma N^2k=N^2k$ 与 $k^2=2$ 立得 $N^2=2\rho^3=54/125$、$\omega=\rho Nk$，纯空间磁曲率经洛伦兹本构逆 $B_A=-\sigma^{-1}\star_e F_A$ 自动转换为纯电型规范辅助场。

**定理 4.2（九通道联合零纤维）。** 构造 4.1 在每个时空点 $x\in\mathbb R^4$ 上精确消去共同作用量 (3.1) 的全部九类 Euler–Lagrange 变分残差（附录 B.3–B.4）。

证明。逐通道验算四组关键相消：

1. **代数通道与挠率—自旋平衡。** 式 (4.7)–(4.8) 直接给出 $B=J\Sigma_e$、$\lambda=JB-\widehat F_\varpi$ 与 $K_e B_A=F_A$，消去式 (3.2) 的三类代数残差。对自旋联络通道，将 $p=ku,q=kv$ 代入式 (4.3)，利用交叉不变量
   $$pv=qu=k\tag{4.9}$$
   与附录 A.2 的 Dirac 矩阵计算全部 $4\times6=24$ 个方向上的物质自旋密度，得
   $$\operatorname{Re}\frac{i}{2}\Xi[p,q]\bigl(\gamma^\mu\gamma^{a_I}\gamma^{b_I}\Psi[u,v]\bigr)
   =\begin{cases}-2k,&(\mu,I)=(1,3),(2,4),(3,5),\\0,&\text{其余 21 个方向，}\end{cases}\tag{4.10}$$
   乘体积元 $\nu_e=N$ 后三个非零分量为 $-2Nk$。另一方面，式 (4.6) 给出空间挠率 $T^1_{23}=T^2_{31}=T^3_{12}=-2k$（余为零），使 $D_\varpi B$ 在同一组方向上恰为 $+2Nk$，故 $D_\varpi B+j_{\rm spin}=0$ 逐分量成立。
2. **前向 Dirac 方程与独立伴随对偶方程。** 记空间自旋双矢 $\mathcal R_1=\gamma^2\gamma^3,\mathcal R_2=\gamma^3\gamma^1,\mathcal R_3=\gamma^1\gamma^2$。在三个空间方向上，$\rho_{\mathcal M}(\tau_i)\Psi[u,v]=-\tfrac12\mathcal R_i\Psi[u,v]$，故 $D_{i+1}\psi=\tfrac{k-a}{2}\mathcal R_i\psi$，且 $\gamma^{i+1}\mathcal R_i\Psi[u,v]=i\Psi[v,u]$；时间方向 $D_0\psi=\Psi[i\omega u,-i\omega v]$，$\gamma_e^0=\gamma^0/N$。三项空间贡献与时间导数相加得
   $$i\gamma_e^\mu D_\mu\psi=\left(\frac{\omega}{N}-3\frac{k-a}{2}\right)\Psi[v,u]=0.\tag{4.11}$$
   又因 $\varphi_0$ 每一项均含 $c_0\wedge c_1$，与 $q_s$ 的楔积恒为零，故 $Y_R(\varphi_0)\psi=0$，消去对 $\chi$ 变分的前向残差 $\mathcal E_\chi$。对 $\psi$ 沿任意母方向 $w\in\mathcal M$ 独立变分时，空间代数负荷与时间动量散度分别为
   $$Q_\psi[w]=-\omega\operatorname{Re}\Xi[q,p](w),\qquad
   \partial_\mu P_\psi^\mu[w]=\partial_0\operatorname{Re}\Xi[p,q](i\gamma^0w)=-\omega\operatorname{Re}\Xi[q,p](w),\tag{4.12}$$
   且 $\Xi$ 只读取 $\Lambda^2$ 分量而 $Y_R(\varphi)w\in\Lambda^6$，故 $\chi(Y_R(\varphi)w)=0$ 对任意 $\varphi,w$ 恒成立，从而 $Q_\psi-\partial_\mu P_\psi^\mu=0$，消去伴随残差 $\mathcal E_\psi$。
3. **非阿贝尔规范电流与标量通道。** 令 $\beta=a^2/(\sigma N)$。按三形式基序 $(012,013,023,123)$ 展开外协变导数与物质规范流：
   $$D_A B_A=(2a\beta\tau_2,-2a\beta\tau_1,2a\beta\tau_0,0),\qquad
   j_A=(-4Nk\tau_2,4Nk\tau_1,-4Nk\tau_0,0).\tag{4.13}$$
   由 $2a\beta=4a^3/(2\sigma N)=4Nk$（即立方平衡律 $a^3=2\sigma N^2k$），得 $D_A B_A+j_A=0$。对任意规范方向 $X\in\mathfrak h_{\rm SM}$，其向量电流读数为
   $$J^0(X)=0,\qquad J^{i+1}(X)=4Nk\,\langle\tau_i,X\rangle_{\mathfrak h_{\rm SM}},\tag{4.14}$$
   取 $i=1,X=\tau_1$ 即回到例 1.1(b) 手算出的 $2Nk=12\sqrt{15}/25$。标量场 $\varphi_0$ 常值且满足 $\rho_4(\tau_i)\varphi_0=0$、$dU_s(\varphi_0)=0$ 及 $\chi(Y_R(h)\psi)=0$，故标量残差 $\mathcal E_\varphi=0$。
4. **余标架全部十六个实矩阵方向。** 固定其余八场，物质动能张量为
   $$T_{a\mu}=\operatorname{Re}\chi(i\gamma^aD_\mu\psi)
   =\operatorname{diag}\bigl(4k\omega,-2k(k-a),-2k(k-a),-2k(k-a)\bigr)_{a\mu}.\tag{4.15}$$
   在解上虽有标量收缩 $(e^{-1})^\mu{}_a T_{a\mu}=0$（故行列式体积元变分项为零），但逆标架微分 $D(f^{-1})[H]=-f^{-1}Hf^{-1}$ 对任意 $4\times4$ 变分矩阵 $H$ 产生非零负荷：
   $$\mathcal E_e^{\rm mat}[H]=-6k(k-a)H_{00}+2Nk(k-a)(H_{11}+H_{22}+H_{33}).\tag{4.16}$$
   规范 Hodge 本构项与引力简单性反应项则分别贡献
   $$\begin{aligned}
   \mathcal E_e^{\rm gauge}[H]&=\frac{a^4}{4\sigma N^2}[3H_{00}-N(H_{11}+H_{22}+H_{33})],\\
   \mathcal E_e^{\rm grav}[H]&=-(3-3k^2)H_{00}-N(3-k^2)(H_{11}+H_{22}+H_{33}).
   \end{aligned}\tag{4.17}$$
   代入参数值 $k^2=2$、$a/k=3/5$、$a^4/(4\sigma N^2)=3/5$，十六个标准基方向的引力、规范与物质三项负荷精确对消如下表所示：

| 余标架变分方向 | 引力反应 | 规范本构 | 物质动能负荷 | 总残差 |
|---|---:|---:|---:|---:|
| 时间对角 $H_{00}=1$ | $+3$ | $+9/5$ | $-24/5$ | $0$ |
| 空间对角 $H_{ii}=1$（$i=1,2,3$） | $-N$ | $-3N/5$ | $+8N/5$ | $0$ |
| 其余十二个非对角方向 | $0$ | $0$ | $0$ | $0$ |

九类变分残差至此逐点全部为零。∎

### 4.2 六物理部门非零、唯一恢复与全阶紧域界

平凡真空或退化纯规范解无法承载非平凡的物质—几何耦合。固定源的**经典世界准入**（Classical World Acceptance）除光滑、全点余标架非退化、Lorentz 合法、九通道联合零纤维及原点标量接触条件外，明确要求六个核心物理部门同时非零。

**命题 4.3（六物理部门同时非零）。** 构造 4.1 的九场解同时满足：（1）引力曲率非零；（2）标准模型规范曲率非零；（3）破缺真空基非零；（4）Yukawa 质量映射非零；（5）物质规范电流非零；（6）余标架物质应力与自旋源非零。

证明。式 (4.8) 直接给出 $-k^2=-2\ne0$ 的引力曲率与 $-a^2\tau_i\ne0$ 的非阿贝尔规范曲率；式 (4.2) 给出非零真空与非零外幂楔积质量映射；式 (4.14)、(4.10) 与 (4.16) 分别给出非零规范电流 $2Nk$、非零自旋挠率源 $-2Nk$ 与非零余标架物质应力。∎

**定理 4.4（唯一经典世界解）。** 固定正源下，存在**唯一**九场构型同时满足：（i）**合法经典实际**：其紧支撑坐标读出等于原完整发生历史某个严格递增子列在紧支撑 $L^2$ 坐标载体上的弱聚点密度；且（ii）经典世界准入的全部条款。该唯一构型即构造 4.1。

证明。在原完整发生历史中，每个场坐标读出从第 $7$ 次访问起即稳定为构造 4.1 的场值，故稳定后缀直接给出合法弱聚点见证；反之，任意严格递增子列的弱极限密度由逐坐标投影单射性唯一落回同一紧坐标读出，结合光滑构型的点值分离性即得构型唯一。∎

**定理 4.5（原历史与全部合法恢复场的全阶紧域导数界）。** 对任意导数阶数 $m\in\mathbb N$ 与任意紧集 $K\subset\mathbb R^4$，存在先验常数 $C(K,m)\ge0$，使得对原完整历史的**每一个**访问指标、九个场的**全部**实坐标及每个点 $x\in K$，均有 $\|D^m(\text{场读数})(x)\|\le C(K,m)$；且同一常数 $C(K,m)$ 同时一致控制全部由合法弱准入密度恢复的光滑构型，不依赖具体候选子列。

证明。原完整历史的坐标读出自指标 $7$ 起恒定，故无穷指标族在紧集 $K$ 上的 $m$ 阶时空偏导数集归结为前 $8$ 项光滑构型的有限并集；合法弱恢复构型由定理 4.4 的密度等式落回同一首写光滑场，故共享同一族紧域界。∎

### 4.3 固定 Cauchy 背景的源生 Volterra 唯一认回与全阶无导数损失闭合

定理 4.4–4.5 利用了显式齐次历史的首写稳定性。对于研究偏微分方程的读者，更深一层的分析问题是：在一般空间非齐次的动态演化中，母作用的一阶变分结构本身能否不借外力地给出弱解积分刻画、空间 $L^2$ 场唯一识别，以及任意高阶空间导数的无导数损失能量控制？下面两条定理在源生固定非特征 Cauchy 背景上正面给出肯定回答（完整证明见补充材料 S16）。

设时间区间为 $[0,T]$（$T>0$），空间紧盒为 $Q=[a,b]\subset\mathbb R^3$（$a\le b$），$\{\phi_n\}_{n\in\mathbb N}$ 为源生空间测试载体上的可数稠密基。对源生整时间 $L^2$ 演化输出 $u_{\rm src}:[0,T]\to L^2(Q)$，记第 $n$ 号稠密测试下的母质量内积读数为 $m_n(t)=\langle\phi_n,M(t)u_{\rm src}(t)\rangle_{L^2(Q)}$，母作用生成的空间 Green 变化率读数为 $g_n(t)$，零时刻源提升初值读数为 $m_{n,0}$。

**定理 4.6（加权母作用弱零点与 Volterra 不动点等价及满测度空间 $L^2$ 唯一认回）。** 对任意 $T>0$、任意空间盒 $a\le b$ 及每个测试指标 $n\in\mathbb N$：

1. **弱作用—Volterra 等价**：函数 $m_n,g_n$ 在 $[0,T]$ 上可积；对全部满足 $w(T)=0$ 的光滑时间权重 $w\in C^1([0,T])$，加权母作用弱零点方程与源初值 Volterra 积分不动点方程严格等价，且源生输出 $u_{\rm src}$ 同时满足两者：
   $$\begin{aligned}
   &\forall w\in C^1([0,T])\ (w(T)=0),\quad\int_0^T\!\bigl(w(t)g_n(t)+w'(t)m_n(t)\bigr)\,dt + w(0)m_{n,0}=0\\
   &\qquad\Longleftrightarrow\quad m_n(t)=m_{n,0}+\int_0^t g_n(s)\,ds\quad(\text{a.e. }t\in[0,T]).
   \end{aligned}\tag{4.18}$$
2. **共同满测度集上的空间 $L^2$ 唯一识别**：存在 $[0,T]$ 上的单一满测度时间集 $\Omega_{T,Q}$（对全体 $n\in\mathbb N$ 共同成立且非空），使得对任意时刻 $t\in\Omega_{T,Q}$ 与任意候选空间场 $v\in L^2(Q)$，只要 $v$ 在全部可数稠密质量读数上等于上述连续 Volterra 代表元的值，就有 $v=u_{\rm src}(t)$（作为 $L^2(Q)$ 元素精确相等）。

证明思路。第 1 款通过带末端消失条件 $w(T)=0$ 的绝对连续积分分部恒等式与基本引理双向互推，无需外供弱解存在性假设。第 2 款利用可数个全测度集的交集仍具满测度（在 $T>0$ 时 Lebesgue 测度严格正从而非空），将无穷多条测试读数锁定在同一确切时刻 $t\in\Omega_{T,Q}$ 上，再由正定母质量算子诱导的稠密测试配对单射性唯一钉死空间 $L^2(Q)$ 场值。完整推导见补充材料 S16.1–S16.2。∎

进一步考察高阶正则性。一阶变系数耦合方程组在做高阶空间导数估计时，最常见的障碍是系数导数与场导数换位产生的误差出现更高一阶导数（导数损失）。对于本文非特征光滑 Cauchy 背景上的母作用一阶算子 $\mathcal L_{\rm mat}=A^0(x)\partial_t+\sum_{i=1}^3 A^i(x)\partial_i+B_0(x)$（其中时间主部 $A^0(x)$ 对称正定可逆，空间主部对称），我们证明母作用自身递归生成任意阶空间导数词的精确换位强迫有界算子，并被同阶能量完整吸收。

**定理 4.7（对称双曲母作用的任意阶射流强迫算子与无导数损失能量闭合）。** 对任意时空紧盒 $I\times Q=[t_0,t_1]\times[a,b]$（$t_0\le t_1,a\le b$）与任意有限空间导数阶数 $r\in\mathbb N$：

1. **任意阶源生射流强迫算子**：对每个空间方向词 $w\in\{1,2,3\}^*$（$|w|\le r$），母作用系数显式递归构造光滑有界线性算子族 $\mathcal J_w(x)\in\mathcal L(J_{\rm sp}^{|w|},\mathcal V)$（仅依赖阶数不超过 $|w|$ 的纯空间射流 $j_{\rm sp}^{|w|}u(x)$，定义中不输入目标场或在壳条件），使得对**每一个**满足 $\mathcal L_{\rm mat}u=0$ 的光滑场 $u\in C^\infty(\mathbb R^4,\mathcal V)$，均有逐点精确恒等式 $\mathcal J_w(x)(j_{\rm sp}^{|w|}u(x))=[\partial^w,\mathcal L_{\rm mat}]u(x)$（其中时间导数换位项已利用在壳方程 $\partial_t u=-(A^0)^{-1}(\sum_i A^i\partial_i u+B_0 u)$ 精确消去）；
2. **先于全部场的同阶能量闭合**：存在仅由源系数与紧盒 $I\times Q$ 确定的常数 $\kappa>0$ 与 $L,K\ge 0$（**量词先于全部场 $u$**），使得对一切满足 $\mathcal L_{\rm mat}u=0$ 的光滑场 $u$ 及盒内每一点 $(t,\mathbf x)\in I\times Q$，记 $r$ 阶点态对称双曲能量为 $\mathcal E_r[u](t,\mathbf x)=\sum_{|w|\le r}\langle\partial^w u,A^0\partial^w u\rangle$、换位强迫总预算为 $\mathcal F_r[u]=\sum_{|w|\le r}\|(A^0)^{-1}[\partial^w,\mathcal L_{\rm mat}]u\|^2$、能量变化率幅值为 $\mathcal R_r[u]$，则同时成立
   $$\kappa\,\mathcal F_r[u](t,\mathbf x)\;\le\;L\,\mathcal E_r[u](t,\mathbf x),\qquad
   \kappa\,\mathcal R_r[u](t,\mathbf x)\;\le\;K\,\mathcal E_r[u](t,\mathbf x).\tag{4.19}$$
   不等式右端只出现同阶空间能量 $\mathcal E_r[u]$，不出现任何 $r+1$ 阶导数。

证明思路。归纳核心在于词长递推 $w=i\cdot\tilde w$：对归纳假设 $\mathcal J_{\tilde w}(x)(j_{\rm sp}^{|\tilde w|}u(x))$ 沿空间方向 $x^{i}$ 求导，产生射流升一阶项、算子系数空间导数项，以及一次新换位项 $[\partial_i,\mathcal L_{\rm mat}]\partial^{\tilde w}u$；利用在壳条件把其中唯一的 $\partial_t\partial^{\tilde w}u$ 改写回空间一阶导数与已生成的 $\mathcal J_{\tilde w}$，即将全部强迫严格关进 $|w|$ 阶纯空间射流内。紧盒上光滑算子范数的有限求和给出统一界，再结合 $A^0$ 在紧盒上的正定强制性，将 $\mathcal F_r[u]$ 逐词平方控制到 $\mathcal E_r[u]$，闭合率不等式 (4.19)。完整归纳证明见补充材料 S16.3–S16.4。∎

---

## 5 时钟—辅助场非线性耦合与引力反冲

### 5.1 有限幅度拉伸：Clock–B 两参数截面

定理 4.2 的解是平衡点；要看清共同作用量内部各部门如何互相牵制，最直接的方法是对它施加**有限幅度**（无需无穷小线性近似）的大变形：保持时空坐标不动，将余标架的时间列乘以 $(1+u)$（改变物理流逝率），同时将规范辅助场 $B_A$ 乘以 $(1+b)$，其余七个场（特别是引力辅助双矢 $B$）暂时冻结在指定解原值。

**构造 5.1（Clock–B 两参数构型族）。** 在原点坐标片与参数域 $u>-1,b\in\mathbb R$ 上，定义构型 $\mathrm{clock}(u,b)$ 为构造 4.1 中余标架时间列 $e^0\mapsto(1+u)e^0$、规范辅助场 $B_A\mapsto(1+b)B_A$、其余七个字段保持不变所得的九场构型；$(u,b)=(0,0)$ 即原平衡解。

### 5.2 精确三次正规形、鞍点 Hessian 与条件极小

将 $\mathrm{clock}(u,b)$ 代入完整的非线性密度 (3.1)，所有高阶依赖精确坍缩为一个简洁的三次多项式。

**定理 5.2（精确三次正规形与混合 Hessian）。** 在 $u>-1,b\in\mathbb R$ 上，完整局部密度在原点精确等于

$$L(u,b)=L_0+\kappa\,\big(b^2+2ub+ub^2\big),\qquad \kappa=\frac{9N}{5}>0 ,\qquad L_0=L(0,0).$$

在平衡点 $(0,0)$ 处，二阶混合 Hessian 矩阵及其行列式为

$$H=2\kappa\begin{pmatrix}0&1\\[2pt]1&1\end{pmatrix},\qquad \det H=-4\kappa^2<0 .$$

证明。逐部门代入式 (3.1)：（1）引力块：时间列的秩一拉伸不产生新的内部空间双矢楔积，简单性项对 $u$ 严格仿射，贡献 $+3Nu$；（2）规范块：时空 Hodge 星 $\star_e$ 在时间—空间二形式分量携带整体因子 $(1+u)$，故本构项给出相对增量 $\kappa\bigl((1+u)(1+b)^2-2(1+b)+1\bigr)$，同一个因子 $(1+u)$ 同时生成 $b^2$ 刚度与 $ub,ub^2$ 耦合；（3）物质块：逆标架时间分量缩放产生纯线性贡献 $-6Nuk(k-a)=-(24/5)Nu$。三项纯 $u$ 一阶系数之和恰为 $(3+\tfrac95-\tfrac{24}5)Nu=0$，这正是定理 4.2 余标架时间列平衡在有限拉伸族上的精确重现。于是纯 $u$ 项恒消，只剩 $\kappa(b^2+2ub+ub^2)$。二阶求导立得 $H$（特征多项式 $x^2-x-1=0$，主轴斜率为黄金比 $\phi_g=(1+\sqrt5)/2$ 与 $-1/\phi_g$）。∎

**定理 5.3（辅助场条件唯一谷底与有效作用）。** 对每个满足 $1+u>0$ 的时钟拉伸参数 $u$，$b\mapsto L(u,b)$ 严格凸并在

$$b^{*}(u)=-\frac{u}{1+u},\qquad L_{\mathrm{eff}}(u)=L_0-\frac{\kappa\,u^2}{1+u}$$

处取得唯一全局极小，满足精确配方 $L(u,b)=L_{\mathrm{eff}}(u)+\kappa(1+u)\bigl(b-b^*(u)\bigr)^2$；对 $\mathrm{clock}(u,b)$ 施加定理 3.4 的源生本构写映射，输出恰为谷底构型 $\mathrm{clock}(u,b^*(u))$。

证明。由 $\partial_b L=2\kappa(1+u)b+2\kappa u=0$ 与 $1+u>0$ 解得唯一驻点 $b^*(u)=-u/(1+u)$，代入配方即得。取源生种子 $u=\sigma=1/2$ 时，本构平衡点落于 $b^*=-1/3$，有效密度下降 $\Delta L=3N/10$。∎

### 5.3 应力传导：$-N/2$ 引力反冲与族外后继

仅做规范本构消元时，构型仍停留在二维截面 $\mathrm{clock}(u,b^*(u))$ 内。一旦执行共同作用量的**完整源生更新**，已拉伸的余标架便通过简单性几何方程传导至引力辅助双矢 $B$，将后继构型直接推出二维初始族。

**定理 5.4（非零引力反冲与族外后继）。** 对源生时钟种子 $u=\sigma=\tfrac12$ 执行完整源生写入（规范辅助场自动落于 $b^*=-1/3$），则：（i）引力辅助场在原点的 $(3,0)$ 分量发生精确非零跃变 $\Delta B_{3,0}=-N/2$（一般 $u$ 下为 $-uN$）；（ii）更新后的完整九场后继构型不属于整个两参数族：对一切 $(u',b')$，后继构型 $\ne\mathrm{clock}(u',b')$。

证明。在冻结引力辅助场的 $\mathrm{clock}(u',b')$ 族中，每个成员的原引力分量恒为 $B_{3,0}=-N$。完整源生写入按拉伸后的标架 $\operatorname{diag}((1+u)N,1,1,1)$ 重建 $B=\mathrm{II}^+(e)=J(e\wedge e)$，使该分量更新为 $-(1+u)N=-3N/2$，差值为 $-N/2\ne 0$，故与任意 $\mathrm{clock}(u',b')$ 在该坐标上严格不等。∎

![图 2 九场依赖、混合密度与族外后继](figures/vector/fig2-nine-field-balance.png)

**图 2｜九场平衡网络、Clock–B 三次密度截面与族外引力反冲。** 上部展示构造 4.1 中九个场的相互锁定关系、Dirac 相位平衡 (4.11) 与余标架时间／空间平衡 (4.17)。下部等高线由精确无量纲密度 $\ell=(L-L_0)/\kappa=b^2+2ub+ub^2$ 直接绘制：实粗曲线 $b^*=-u/(1+u)$ 为固定 $u>-1$ 时的规范本构极小谷底，长虚线标出原点鞍点 Hessian 的两条黄金比特征方向，点线为负值等高线。右侧独立框标示种子点 $(1/2,-1/3)$ 经完整源生写入后，引力辅助分量 $B_{3,0}$ 从 $-N$ 更新至 $-3N/2$（净变 $-N/2$），跃出二维冻结截面。

---

## 6 量子态空间与算符代数的无先验生成：从 $4\sqrt2$ 配对到 504 模共同 $H$

按 §1.1 反魔法裁剪律，在不预供任何量子外壳的前提下，整套量子运动学与动力学怎样作为同一根发生的依赖投影面，直接从共同作用量 (3.1) 内部一砖一瓦长出来？本节分两步推进：§6.1–§6.2 先由经典独立对偶 $\chi$ 与在壳物质场 $\psi$ 内生导出八维归一内积态、256 维单粒子 Fock 嵌入与非微扰精确配对系数 $4\sqrt2$，并验证暗时刻结构反例；§6.3–§6.5 随即撤去“固定背景、单粒子扇区”的限制，经四部门 Legendre 变换把全部 252 维物质与独立对偶、标量、规范及余标架收束进同一个无限维约束量子配置载体，导出 61 对 CCR 与 504 模双支 CAR 上的共同生成元 $H=H_0+Y$、全阶量子时钟、固定自伴能量尾 $R$、实际 CAR 创建单位外态与完整多粒子荷—电流 Ward 恒等式。

### 6.1 八维占据态、经典—量子配对与 $4\sqrt2$ 系数

一般的 252 复维物质场投影到 8 维子空间必然丢失信息；但在构造 4.1 的解上，物质场 $\psi$ 恰好完整支撑在“四分量 Dirac 旋量 $\times$ 色前两维二重态”张成的八维占据子空间 $\mathcal E=\mathbb C^8$ 上，且独立线性对偶 $\chi$ 在同一子空间上具有由场方程锁定的共轭翻转结构。

**定义 6.1（八维归一占据态）。** 令 $E:\mathbb C^8\to\mathcal M$ 为将每个旋量分量的两个复坐标嵌入式 (4.3) 基元 $q_0,q_1$ 的等距嵌入，$P=E^*:\mathcal M\to\mathbb C^8$ 为正交投影（满足 $PE=I_8$）。对构造 4.1 的物质场 $\psi$，定义**占据态**为 $v=\tfrac12 P\psi$。在时空点 $x$（$\theta=\omega x^0$）上，按（旋量，色）字典序排列有

$$v=\tfrac12\big(0,\,e^{i\theta};\;-e^{i\theta},\,0;\;0,\,e^{-i\theta};\;-e^{-i\theta},\,0\big),\qquad \langle v,v\rangle=4\times\tfrac14=1,\qquad \psi=2Ev.$$

时间平移 $\Delta$ 在占据载体上由酉阵 $\operatorname{diag}(e^{i\omega\Delta},e^{i\omega\Delta},e^{-i\omega\Delta},e^{-i\omega\Delta})\otimes I_2$ 执行。

**定理 6.2（经典—量子配对等式）。** 固定正源与构造 4.1 的实际解。记 $S\in\operatorname{End}_{\mathbb C}(\mathbb C^8)$ 为交换上下 Dirac 二分量（$0\leftrightarrow2,1\leftrightarrow3$，色指标不变）的自伴酉对合，定义压缩响应映射 $R:\operatorname{End}_{\mathbb C}(\mathcal M)\to\operatorname{End}_{\mathbb C}(\mathbb C^8)$ 为 $R(A)=SPAE$。则对每个时空点与母物质空间上的**任意**复线性算符 $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$（无需自伴，也无需保持占据子空间），恒有

$$\chi\big(A\psi\big)\;=\;4k\,\big\langle v,\,R(A)\,v\big\rangle,\qquad k=\sqrt2\quad(\text{内积第一分量共轭}).$$

证明。记 $u=e^{i\theta},v_-=e^{-i\theta}$。将 $v$ 经 $S$ 上下翻转再取逐分量复共轭，乘以 $2k$ 得

$$2k\,\overline{Sv}=k(0,u;\,-u,0;\,0,v_-;\,-v_-,0),\tag{6.1}$$

右端恰好是式 (4.5) 独立对偶 $\chi=\Xi[ku,kv_-]$ 在八个占据基上的线性系数，而 $\chi$ 在其余 $244$ 个正交母基上的系数全为零。故对任意 $w\in\mathcal M$，恒有 $\chi(w)=2k\langle Sv,Pw\rangle$。代入 $w=A\psi=2AEv$ 并用 $S^*=S$，三步线性代数即得

$$\chi(A\psi)=2k\langle Sv,PA(2Ev)\rangle=4k\langle Sv,PAEv\rangle=4k\langle v,SPAEv\rangle.\tag{6.2}$$

两个因子来源分明：因子 $2$ 来自经典解幅度 $\|\psi\|=2$，因子 $2k=2\sqrt2$ 来自独立对偶 $\chi$ 的场方程振幅，相乘即得零拟合常数 $4\sqrt2$。不同于 Born 原始碰撞概率公设 [28] 或 Gleason 在预设三维以上 Hilbert 闭子空间格与框架可加性前提下证明的迹测度定理 [29]，这里的正归一内积期望并非外置量子公理，而是经典独立对偶 $\chi$ 在同一发生下的精确重写。∎

将任意母算符 $A$ 具体取为规范流生成元、协变导数动能算符与外幂 Yukawa 算符，定理 6.2 立即将经典变分读数逐项转化为量子期望值：

**定理 6.3（规范电流、十六项动能负荷与质量读数的逐项恒等）。** 在固定源与指定解上：

1. **规范电流恒等**：对每个时空点与标准模型子代数 $\mathfrak h_{\rm SM}$ 中的任意规范变分，经典变分电流与量子期望值按同一 $4Nk$ 归一化逐项相等；在色二重态生成元上，$\langle v,O_{g+1}(\tau_h)v\rangle=\tfrac12\delta_{gh}$，故 $J^{g+1}(\tau_h)=2Nk\delta_{gh}$（同轴恒为 $2Nk$，异轴恒为 $0$，与时刻无关）；
2. **十六项动能负荷恒等**：全部 $4\times4$（时空方向 $\times$ 内部洛伦兹指标）量子动能负荷矩阵元为厄米读数，且逐项等于经典解动能张量 (4.15) 的 $\operatorname{diag}\bigl(4k\omega,-2k(k-a),-2k(k-a),-2k(k-a)\bigr)$；
3. **质量与占据 Yukawa 读数**：完整 252 维外幂质量映射非零、四个 $2\times2$ 混合元全部非零，而在壳占据态上的 Yukawa 期望值与经典解一样精确为零。

证明。（1）由 Dirac 矩阵迹与色二重态正交性，将 $8\times8$ 占据内积精确约化为 $2\times2$ 李代数迹 $\langle\tau_g,\tau_h\rangle=\tfrac12\delta_{gh}$；（2）（3）直接将相应母算符代入式 (6.2) 与式 (4.15) 核对。∎

**命题 6.4（联络酉输运、外幂射流余项与移动标架交换律）。** 在固定源与指定解上：（1）母基本表示上的实际规范联络生成元 $G$ 反自伴，$U(t)=\exp(tG)$ 对全体 $t\in\mathbb R$ 为 $7\times7$ 酉矩阵，在 $t=0$ 一阶射流为 $1+tG$，且对 $t\ge0$ 有 $\|\exp(tG)-(1+tG)\|\le\|G\|^2 t^2$；（2）对**任意**外幂阶数 $d\in\mathbb N$、任意向量 $w\in\Lambda^d\mathbb C^7$ 与任意外幂基坐标 $j$，有显式二阶误差界 $|[\Lambda^d U(t)w-\Lambda^d(1+tG)w]_j|\le C_{d,w,j}(t)\,t^2$（$t\ge0$，显式尺度公式见附录 B.4）；（3）对任意基点等价的完整 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 移动标架变换，外幂输运与标架更换在同点读数上精确交换。

证明。（1）由反自伴指数级数余项给出；（2）将 $d$ 重楔积差按多线性望远镜和逐因子展开，以 $(1+t\|G\|)^{d-1}$ 吸收中间酉因子范数；（3）由伴随表示与外幂函子性直接得出。∎

### 6.2 标准 Fock 提升与暗时刻反控

将八维占据空间 $\mathbb C^8$ 提升为 $2^8=256$ 维费米子 Fock 空间 $\mathcal F_-(\mathbb C^8)=\bigoplus_{n=0}^8\Lambda^n\mathbb C^8$（粒子数扇区维数依次为 $1,8,28,56,70,56,28,8,1$），单粒子算符 $O$ 二次量子化为 $\mathrm d\Gamma(O)=\sum_{i,j}O_{ij}c_i^\dagger c_j$。

**定理 6.5（256 维标准 Fock 单粒子矩阵元保持）。** 对任意有限线序模式集与任意复矩阵 $O$（无需自伴），显式费米子产生／湮灭算符满足 $\mathrm d\Gamma(O)I(v)=I(Ov)$ 及 $\langle I(v),\mathrm d\Gamma(O)I(w)\rangle=\langle v,Ow\rangle$。应用于本模型八模占据载体时，对每个时空点与每个母算符 $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$，经典独立对偶配对、规范变分电流与十六项动能负荷全部由 Fock 矩阵元 $4\sqrt2\langle I(v),\mathrm d\Gamma(R(A))I(v)\rangle$ 精确保持，且在当前演化步与后继演化步上同值。

证明。在单粒子扇区 $\Lambda^1$ 上，费米子 Jordan–Wigner 计数符号 $(-1)^{\#}$ 在湮灭与产生同位复合时完全平方抵消，退化为精确矩阵乘法；将定理 6.2–6.3 代入即得全部物理读数的保持（另有 256 维全 Fock 空间 812 项独立数值复核，最大残差 $8.88\times10^{-16}$，见附录 D.3）。∎

**例 6.6（暗时刻反例：省去对偶翻转 $S$ 的裸压缩必然败诉）。** 若忽略独立对偶诱导的上下旋量交换 $S$，改用裸压缩 $R_{\rm raw}(A)=PAE$ 读取第一空间方向、生成元 $\tau_0$ 的电流，直接计算得

$$\langle v,R_{\rm raw}(O_1(\tau_0))v\rangle=\frac{e^{-2i\theta}+e^{2i\theta}}{4}=\frac{\cos 2\theta}{2}=\cos^2\theta-\tfrac12 .$$

在初时刻 $\theta=0$，裸压缩给出 $+\tfrac12$，与真实电流 $+\tfrac12$ 毫无二致；但在 $\theta=\pi/4$ 时裸读数跌至 $0$，到暗时刻 $\theta=\pi/2$ 更反转成 $-\tfrac12$，与守恒真值 $+\tfrac12$ 相差整整 $1$（图 1 下方小图）。这直观表明：只在 $t=0$ 核对一次数值无法保证经典—量子对应；唯有保留式 (6.1) 由独立对偶给出的完整算符桥 $S$，等式才能在全时间成立。

### 6.3 四部门 Legendre 图与 504 模共同量子 Hamiltonian

单粒子 Fock 嵌入只触及了 252 维物质中的 8 个模式，背景几何与规范场还是固定的。真正的量子场论构造要求把完整 252 维物质 $\psi$、252 维独立对偶 $\chi$、35 复维（70 实维）标量 $\varphi$、规范势与余标架全部送入正则相空间，处理退化主约束与 Gauss 规范约束，并在同一个加权 Hilbert 空间上建立无外援参数的共同 Hamiltonian。在正则量子引力传统中，奇异 Legendre 变换 [14] 下的时间重参数化约束往往导致全局 Wheeler–DeWitt 冻结态方程 [25]，或迫使人们额外引入关系条件时钟公设 [26]；而在下述定理 6.7–6.8 中，共同作用量自身的四条时间约束通过可逆主 Jacobi 块递归解出全阶非交换量子时钟与共同生成元 $H=H_0+Y$，无需冻结演化或外设时钟假说（完整证明见补充材料 S1–S2）。

**定理 6.7（共同量子 Hamiltonian 与作用认回）。** 在包含固定源点的共同非特征配置开域上，由共同作用量 (3.1) 出发：

1. **共同正则载体（61 对 CCR 与 504 模双支 CAR）**：余标架六速度秩六右逆图（含十条初级时间—Lorentz 约束）、标量图、规范空间图与保留独立对偶的物质一形式 $\operatorname{Re}(ip\,\delta\psi)$ 合成共同正则一形式。沿九个非稳定 Gauss 方向的横截实基拉回产生 **61 对标量正则对易关系（CCR，70 个实标量坐标减 9，即 $70-9=61$）**；物质与独立对偶的实正则坐标整体复化，经**单次 CAR 量子化**产生 $252+252=504$ 模标准双支费米子代数。四部门能量先在 103 维玻色配置域 $C_c^\infty(\mathscr U_{103})\otimes\mathcal F_{504}$（余标架 6＋标量 61＋规范空间 36，即 $6+61+36=103$）上相加，再沿核稳定子的三个规范枢轴截面（源点轨道行列式 $-54\sqrt2/125\ne0$）下降至 **100 维配置空间** $\mathscr U_{100}$（$103-3=100$）；九个第二类标量约束的法向动量积分与第二类行列式乘积精确等于 $1$，由截面权重 $\rho_3>0$ 与依赖占据数 $m$ 的体积权 $v^{m+2}$ 定出正定加权 Hilbert 空间 $\mathscr H=\bigoplus_{|w|=m}L^2(\mathscr U_{100},\rho_3 v^{m+2}dz)$ 及等距半密度变换。
2. **形式伴随对与四时间 Weyl 运动**：在稠密不变域 $\mathscr D_{100}$ 上，非 Yukawa 总能量 $H_0$ 形式对称，单向手征 Yukawa 项 $Y$ 非零且非对称（两粒子态上 $\|Y|144,396\rangle\|^2=216/125\ne0$）；完整生成元 $H=H_0+Y$ 与独立形式伴随 $H^\sharp=H_0+Y^\dagger$ 构成可闭形式伴随对，各自拥有单值最小图闭包（在 392 模双侧 Yukawa 零核子空间上约化为对称算符）。经半密度变换后，$H$ 具有唯一二次动量四时间 Weyl 符号表示，生成全部 100 对配置 CCR 与 504 对正规积 CAR 的海森堡运动方程。
3. **配置耦合认回**：原作用—力系数为标量 Gram 生成的配置函数 $4W(q)$（$W(q)\ge1$，非外设常数）。含全 Yukawa、配置物质、保留时间—自旋项与物理动量的实际核 $K(p)$ 对任意四复动量 $p$ 满足精确恒等式
   $$S_{\rm phys}(p)+Y=S_{\rm nat}+S_{\rm cf}+K(p)-K_{\rm ret},\tag{6.3}$$
   其中原生部门 $S_{\rm nat}$、余标架部门 $S_{\rm cf}$ 与保留核 $K_{\rm ret}$ 均由式 (3.1) 自身符号字典逐分量确定。

证明要点。核心难点有三处，均在补充材料 S1 逐项解决：第一，证明三稳定子生成元在 103 维域上与四部门总能量精确对易（引理 S1.1），使规范枢轴截面保持任意有限次算符复合；第二，发现第二类标量约束体积因子 $\tfrac1{256}\cdot\tfrac{256}{|\det D_9|}\cdot|\det D_9|=1$ 的精确抵消（式 (S1.4)）及占据数依赖权 $v^{m+2}$ 对余标架动量分部积分的伴随闭合作用；第三，利用稠密域上的伴随配对 $\langle f,Hg\rangle=\langle H^\sharp f,g\rangle$ 证明 $H$ 与 $H^\sharp$ 图可闭（引理 S1.2）。∎

### 6.4 全阶量子时钟、固定能量尾 $R$ 与实际 CAR 创建外态

在含四条时间约束的一阶引力—规范系统里，时间演化参数不能从外部硬塞，高阶能量展开尾也不能做成随准备精度漂移的临时补丁；同时，用于散射与极化读出的量子外态必须由原作用在 Hilbert 空间 $\mathscr H$ 中亲手造出来。

**定理 6.8（全阶量子时钟、固定有界自伴尾 $R$ 与同一源准备）。** 在定理 6.7 的 Hilbert 载体 $\mathscr H$ 上：

1. **全阶非交换时钟递推**：源支撑正锥上的四阶时间主 Jacobi 矩阵 $J_4$ 可逆；由 42 个阶次系数函数、有序 Moyal 词与 13 个时间基项组成的递推构造对每个阶数 $k\ge0$ 以 $C_{k+1}=-J_4^{-1}R_{k+1}$ 递推解出新阶时钟，使四个后继时间力在源支撑闭集上恒为零，且任意高阶递推严格保持已生成的全部低阶系数与 100 维导数预算。
2. **完整固定能量尾 $R$**：全部 $k\ge2$ 阶能量尾的平移 Fourier 核满足双侧 Schur 可积界，经 Riesz 表示减去源原生组成项 $C_{\rm src}$ 后给出有界自伴算子 $R=E_{\rm tail}-C_{\rm src}$；对一切标量测试函数 $f,g$，闭主部因子 $A$ 与 $R$ 组成的二次型 $\langle Af,Ag\rangle+\langle f,Rg\rangle$ 精确等于完整 $B_1^2+E_{\rm tail}$ 的 Weyl 能量形式，且 $R$、源算子 $\mathcal T$ 与源能量 $E$ 均独立于准备精度 $\varepsilon$。
3. **同一源准备与双残差同步归零**：对每个 $\varepsilon>0$，增广正有界预解式 $B=(\mathcal T+1+\|R\|)^{-1}$ 在谱端点 $E=\|B\|^{-1}-(1+\|R\|)$ 处由同一预解算子构造一次性给出定义域点 $x_\varepsilon$，同时携带单位背景范数 $\|v_\varepsilon\|=1$、近谱界 $\|\mathcal Tx_\varepsilon-Ex_\varepsilon\|<\varepsilon$、弱形式恒等式、原生 Yukawa 荷 $-1$、八条受控外腿及指数截断界 $\|Y_{\rm closed}v_\varepsilon-\mathrm{cut}_n(v_\varepsilon)\|\le(915/916)^{n+1}\cdot916b$；取 $\varepsilon_n=1/(n+1)$ 时，固定 $(\mathcal T,R,E)$ 下的近谱残差与全 Yukawa 截断残差沿同一序列同步趋于零（补充材料 S2）。

有了单位配置背景 $v_\epsilon$（$\epsilon>0$），再用 504 模 CAR 的实际标量—物质耦合创建通道 $\mathcal A_{10}^\dagger$ 作用其上。在源闭盒内，标量第 $(1,2)$ 坐标满足 $|c_{12}(z)|\ge 1/2$；用未占据色模式的湮灭算符 $a_{02}$（$\|a_{02}\|\le1$）从左端探测，由反对易关系 $a_{02}\mathcal A_{10}^\dagger v_\epsilon=\overline{c_{12}}\,v_\epsilon$ 立得显式范数下界

$$\|v_\epsilon\|^2\;\le\;4\,\|\mathcal A_{10}^\dagger v_\epsilon\|^2.\tag{6.4}$$

**定理 6.9（同剖面非零 CAR 创建单位态与标准模型联合荷字符）。** 对每个准备精度 $\epsilon>0$，式 (6.4) 保证创建向量 $g_\epsilon=(i/2)\mathcal A_{10}^\dagger v_\epsilon$ 严格非零（$\|g_\epsilon\|\ge 1/4$）；按真实 Hilbert 范数归一得到 $u_\epsilon=g_\epsilon/\|g_\epsilon\|$，则 $\|u_\epsilon\|=1$ 且共享同一配置背景 $v_\epsilon$。进一步，对标准模型子代数 $\mathfrak h_{\rm SM}$ 中的**任意**元素 $a=(A_3,A_2,y_a)$（$y_a\in i\mathbb R$ 为纯虚超荷坐标），将标量场与 504 模物质同时变动的联合修饰创建／湮灭变分满足精确本征字符律：

$$\delta_a^{\rm joint}\mathcal A^\dagger=-y_a\,\mathcal A^\dagger,\qquad \delta_a^{\rm joint}\mathcal A=+y_a\,\mathcal A.$$

特别地，相位方向（$y_{\rm ph}=-i/2$）给出创建字符 $+i/2$、湮灭字符 $-i/2$；原生超荷方向（$y_Y=i$）给出创建字符 $-i$、湮灭字符 $+i$；而在全体色与弱方向（$y_a=0$）上，标量反变动与物质颜色列精确抵消，联合变分为零。上述字符律在稠密测试核与同一完成准备剖面上均成立（补充材料 S11.1–S11.2）。

### 6.5 完整荷—电流 Ward 恒等式与十二时间方向统一归一

例 1.1 的规范电流在 §6.1–§6.2 中走过了 8 维占据空间与 256 维单粒子扇区；现在它在 504 模双支 CAR 上展现完整的多体面貌。

**定理 6.10（完整 504 模荷—电流 Ward 恒等式）。** 在定理 6.7–6.8 的载体与同一源准备之上：

1. **单粒子流与四次对电流分解**：对每个量子测试态、每个动量 $k$ 与每个李代数元 $a$，动量作用 $P(k)$ 与荷算符 $Q_a$ 的乘积精确分解为
   $$P(k)\,Q_a=J_{\rm sp}(k,a)+J_{\rm pair}(k,a),\qquad J_{\rm pair}(k,a)=\sum_{i,j,u,v}(P_k)_{ij}\,(Q_a)_{uv}\;c_i^\dagger c_u^\dagger a_v a_j .\tag{6.5}$$
   其中 $J_{\rm sp}$ 为单体空间电流，四算符对电流 $J_{\rm pair}$ 与一切粒子数权重算符对易，且在单粒子投影扇区上恒有 $J_{\rm pair}=0$。
2. **双传播子完整 Ward 恒等式**：未投影全生成元 $[Q_a,H_{\rm full}]$ 完整保留配置力矩、单体空间电流、四次对电流与 Yukawa 力矩四个通道；任意有限截断 $(n,F)$ 的压缩缺陷与 $Y_n-Y$ 显式保留并在共尾滤子极限下归零，双预解响应 $\langle x,R_{\rm full}(p+k,z)Q_a R_{\rm full}(p,w)y\rangle$ 精确等于各解析通道之和，并由同一准备点 $x_\varepsilon$ 的八条外腿与 36 个曲率读口直接读取。
3. **全局时间荷与保留项平衡**：十二个时间规范方向生成全局有界荷算符 $Q$；沿场曲线变动时，裸 Hamiltonian 与保留核的 $-rQ$ 漂移精确抵消，106 维原生轨道联合图给出闭算符加权动量表示 $\sum_i P_i^\dagger(c_i f)=-Q$（补充材料 S4）。

最后，十二个时间规范方向在配置积分中的作用权重并非十二个各自待定的标量，而是由母作用的时间矩阵一次性统一归一：

**定理 6.11（十二时间方向的统一相位逆归一与加权创建电流）。** 对全部十二个时间规范方向 $a\in\{0,\ldots,11\}$、每个非特征原作用态 $s$ 与任意物质动量，时间场列 $f_a$ 的一阶矩阵满足

$$B_{\rm raw}(f_a;s)=\mathsf w_t(s)C_a,\qquad M_{\rm ph}(s)\,[\mathsf a\,B_{\rm raw}(f_a;s)]=C_a,\tag{6.6}$$

其中 $\mathsf w_t(s)$ 为完整 $504\times504$ 时间权矩阵，$M_{\rm ph}(s)$ 为其正典相位逆（满足 $M_{\rm ph}(s)[\mathsf a\mathsf w_t(s)]=I_{504}$），$\mathsf a$ 为源生作用尺度。经单次完整 CAR 量子化后，

$$Q(C_a)=Q(M_{\rm ph})\,Q(\mathsf a B_{\rm raw})-\operatorname{Pair}(M_{\rm ph},\mathsf a B_{\rm raw}),\tag{6.7}$$

完整双粒子对算子项 $\operatorname{Pair}$ 原样保留。对源种子态 $q$ 与实际创建 $A^\dagger$，带配置作用权的原始荷算符满足精确交换恒等式

$$Q_a^{\rm raw}A^\dagger q=A^\dagger Q_a^{\rm raw}q+iA_{a,\rm sc}^\dagger q+i y_a A_{\mathsf w}^\dagger q,\tag{6.8}$$

其中 $A_{a,\rm sc}^\dagger$ 为标量反变动创建，$A_{\mathsf w}^\dagger$ 为作用权加权创建：相位方向末项系数为 $+1/2$，超荷方向为 $-1$，色与弱方向（$y_a=0$）精确归结为标量反变动补偿（补充材料 S11.2）。

---

## 7 全场非线性量子反馈、矩阵红外返回与涌现相互作用

§6 完成了从共同作用量到 504 模量子电流与十二时间方向归一的正向通道；物理闭环的下半程，是让这条量子电流**返回并驱动全部经典—量子场方向**，并从中读出真正的空间长程力、带电色单态复合粒子正谱与四维连续曲率算符。本节将这一下半程梳理为五步严密推进，不再混用不同时间域或不同矩阵约化的记号。

### 7.1 母作用二阶变分认回 $H_{289}$ 与真变场截断交换

场的响应传播由一枚作用在九组场全部 $289$ 个实方向与四个复动量 $p\in\mathbb C^4$ 上的 $289\times289$ 矩阵 $H_{289}(p)$ 支配（其展开为系数在代数数域 $\mathbb Q(\sqrt2,\sqrt{15})$ 中的 3071 项显式多项式字典）。第一道门槛是证明：这枚驱动 Green 函数的矩阵绝非外加的传播子模型，而是共同作用量 (3.1) 在指定解处的**精确 Fréchet 二阶变分**。

**定理 7.1（母作用 Fréchet 二阶变分认回同一 $H_{289}$ 与 Legendre 五块回读）。** 固定正源、共同作用量 (3.1) 与构造 4.1 的指定解：

1. **真 Fréchet Hessian 与 3071 项字典恒等**：将九组场的 289 个实变分方向与四个时空梯度嵌入指定解处的完整场构型（独立对偶 $\chi$ 保持为独立变分分量），局部密度光滑且其 Fréchet 二阶导数为对称双线性型，按引力（234 项）、规范（406 项）、标量（220 项）与 Dirac—对偶（790 项）分解为 1650 个二阶密度单项式；对任意四复动量 $p\in\mathbb C^4$，其 Fourier 变换产生的 3300 个带符号双腿贡献经合并同类项后，**逐项精确等于**原 $H_{289}(p)$ 的 3071 项字典。
2. **289 方向全 Euler 拉回与自旋联络消元回读**：九组母变分残差沿全部 289 个实单位方向的拉回逐分量等于 holonomic Euler 读数（184 个无导数分量动量与散度为零，标量 9 分量、物质 24 分量与联络 72 分量满足值减散度恒等式，合计 $184+9+24+72=289$）。在任意非退化余标架上，自旋联络二次型 $\tfrac12\omega^{\mathsf T}\mathcal H\omega$ 具显式双侧逆 $K$，代入唯一驻点 $\Omega=-KJ$ 并结合余标架十六动量、十主约束 Legendre 变换与八个 Clifford 方向的 CAR 正规序收缩后，$\mathrm{Number}^2$ 交叉项精确抵消，逐块恢复 §6.3 余标架量子能量的全部五项：动能、电流、自旋平方、粒子数移位 $-\tfrac{9\,\mathrm{lapse}}{8V}\mathrm{Number}$ 与体积势（补充材料 S5）。

与此同时，当场沿真实曲线变动时，配置空间测度、半密度比与分级投影均随场移动，有限截断响应必须能无损过渡到未截断极限：

**定理 7.2（真变场响应、谱测度与 0/1/2 阶射流截断交换）。** 在定理 6.7–6.8 的载体与准备态之上：（1）106 维逆与原生、余标架及保留项沿真实场曲线输运 Gauss 密度 $Jv^{m+2}$ 与半密度比的前两阶导数，保持分级压缩 $\sum_g P_g P_F H_{\rm phys}P_F P_g$，生成真正的 289 维场响应向量、36 个曲率读数及一阶 $-RJR$、二阶完整接触射流；（2）对任意阻尼 $\gamma>0$，源生非线性邻域上的 Laplace 响应具显式参数导数与 $O(|r|^2)$ 余项界；（3）对每个有限帧指标 $F$、每个非实谱参数 $z$ 与局部场邻域，由于保留项在固定 $(F,p)$ 上仅作用于有限保留集，字面 Yukawa 截断的 **0、1、2 阶射流逐点终站并收敛至未截断算子**，准备态响应及全部 36 个曲率读数的值、一阶导数与二阶导数均与撤去截断极限精确交换；（4）对自由生成元 $H_0$，每个核输入 $g$ 生成总质量 $\|g\|^2$ 的正有限谱测度，且任意有界算符插入的复迟滞振幅在整条实频轴上 $L^1$ 收敛、经逆 Fourier 变换对全部实时间一致收敛（补充材料 S3）。

![图 3 从共同作用量到完整量子构造与全场返回](figures/vector/fig6-quantum-construction-v3.png)

**图 3｜从共同作用量到 504 模量子化、全场反馈与涌现相互作用的闭合回路。** 结构示意（无外供参数框）。上行：共同作用量 (3.1) 经四部门 Legendre 图与三稳定子截面生成 61 对 CCR、504 模双支 CAR 与共同生成元 $H=H_0+Y$（定理 6.7）；时间约束递推生成全阶时钟、固定自伴尾 $R$、11 字段准备态及非零 CAR 创建单位外态 $u_\epsilon$（定理 6.8–6.9）；真变场 0、1、2 阶射流与撤去截断交换（定理 7.2）。中行：完整荷—电流恒等式 $P(k)Q_a=J_{\rm sp}+J_{\rm pair}$ 在单粒子扇区退回 §6.1–§6.2 的 $4\sqrt2$ 配对（$J_{\rm pair}=0$，定理 6.10–6.11）。下行：母作用二阶变分认回同一 $H_{289}$（定理 7.1）；常场非线性半轴微分给出 $\Pi_{\rm st}$，经九约束 Schur 相容与 $z^4\Pi_{\rm st}$ 解析红外返回回到 289 场方向（定理 7.3–7.7）；右侧与下方出口进一步交出 192/97 电磁消因子分式、涌现 $1/(4\pi|x-y|)$ 长程核、带电色单态三费米子正谱及落入 $\operatorname{Dom}(H_{\rm time})$ 的四维 Schwartz 曲率强积分（定理 7.8–7.12）。

### 7.2 常场真正非线性 Noether 半轴微分与完整半轴返回

要把非线性历史积分到无穷远时间 $t\to\infty$，我们先固定实际响应事件 $d=(\epsilon,p,F,m,\zeta)$（含准备精度 $\epsilon>0$、物质动量 $p$、有限帧 $F$、截断阶 $m$ 与非实物质谱点 $\zeta$）及独立外动量转移 $k$。由定理 6.9 的创建单位态 $u_\epsilon$ 与单位背景 $v_\epsilon$ 定义差值观察泛函

$$\ell_d(A)=-\langle u_\epsilon,A u_\epsilon\rangle+\langle v_\epsilon,A v_\epsilon\rangle,\qquad\|\ell_d\|\le 2.\tag{7.1}$$

对原场的任意常值实微扰 $h\in\mathbb R^{289}$，记 $R_\pm(h)$ 为受扰双物质预解逆，$N_i(h)$ 为固定正则动量的第 $i$ 个 Noether 电流读口，$\mathcal T_h(t)$ 为受扰同场双腿时间演化算子，定义**常场真正非线性 Noether 半轴积分**：

$$\mathcal J_d(h;\lambda)_i=\int_0^\infty e^{-\lambda t}\,\ell_d\!\left[
\mathcal T_h(t)\bigl\{R_+(h)N_i(h)R_-(h)\bigr\}\right]dt.\tag{7.2}$$

**定理 7.3（常场非线性半轴的 $C^2$ 全场微分与非自治窗口残差）。** 固定任意事件 $d$、外转移 $k$ 与满足 $\operatorname{Re}\lambda>0$ 的拉普拉斯参数 $\lambda$。源自身在 $\mathbb R^{289}$ 原点周围生成开邻域，使得式 (7.2) 的非线性无穷半轴积分绝对收敛且在原点为 $C^2$ 映射，其对**任意**实场方向 $f\in\mathbb R^{289}$ 的 Fréchet 导数精确等于完整 $289\times289$ 静态量子极化矩阵：

$$D_h\mathcal J_d(0;\lambda)[f]=\Pi_d^{\rm st}(k,\lambda)\,f\qquad\bigl(\text{乘常输入拉普拉斯归一因子 }\lambda\text{ 后为 }\lambda\Pi_d^{\rm st}(k,\lambda)f\bigr).\tag{7.3}$$

对邻域内任意 $h$，有限时间窗 $[0,T]$ 积分与无穷半轴之差满足显式指数尾界

$$\bigl|\mathcal J_d(h;\lambda)_i-\mathcal J_{d,T}(h;\lambda)_i\bigr|\;\le\;\frac{4}{\operatorname{Re}\lambda}\,
\|R_+(h)N_i(h)R_-(h)\|\,\mathcal B_d(\operatorname{Re}\lambda/4)\,e^{-\operatorname{Re}\lambda\,T/2},\tag{7.4}$$

其中 $\mathcal B_d$ 为双腿演化的源生多项式时间上界。对于随时间任意变动的耦合非线性信号，在源生正共同时窗 $0\le T<\tau(d,k,P,a)$ 上，含双正交相位的复幅度耦合母残差一阶导数积分精确满足

$$\int_0^T e^{-\lambda t}\,\partial_r\mathcal E_d(r,t)\big|_{r=0}\,dt
=\bigl[W_T(P,\lambda)H_{289}(P)-\Pi_{d,T}(P,\lambda)\bigr]a,\qquad W_T(P,\lambda)=\int_0^T e^{(P_0-\lambda)t}\,dt\tag{7.5}$$

（同步时钟 $\lambda=P_0$ 时 $W_T=T$）。

证明思路。式 (7.3) 的转折点不是在积分号下硬做逐点线性近似，而是先在源生小邻域内利用 Duhamel–Gronwall 指数控制证明非线性积分等于同场双腿传播束（pencil）的精确双侧逆 $\mathcal P_\lambda(h)^{-1}[R_+(h)N_i(h)R_-(h)]$，再对这一光滑算子逆在 $h=0$ 处求导：两个物质逆贡献 $-RJR$，中央贡献完整 Noether 接触导数，双腿传播逆贡献两条有序时间腿，五项之和逐列认回 $\Pi_d^{\rm st}$。完整推导见补充材料 S12.1。∎

记截断生成元为 $K_F(p)=C_F(p)+A_F$（$C_F$ 保持 $\Lambda^6$ 分级，$A_F$ 升一级，57 次升级后恒零），五因子时间核为 $\mathcal K(t)=e^{itK_F(p+k)}R_{p+k}(z)J R_p(w)e^{-itK_F(p)}$。其在完整时间轴与母 Green 函数中的返回性质总结如下：

**定理 7.4（五因子实电流半轴返回、虚轴谱与因果反馈双侧逆）。** 在定理 6.7–7.2 的设置中：

1. **母 Green 分解与完整正半轴**：在活跃 103 维块行列式非零的源生非空正则域上，母 Green 函数 $G=\Xi(D^{-1}+P_a K_{\rm ext}^{-1})\Xi(-p)^{\mathsf T}$ 满足 $H_{289}G=I-\Xi(-p)^{-\mathsf T}P_{\rm null}\Xi(-p)^{\mathsf T}$（保留九维零方向投影 $P_{\rm null}$）。因 $K_F$ 的 57 项有限分级截断给出多项式时间界，对一切 $\operatorname{Re}\lambda>0$，正半轴强迫响应 $\Phi^+$ 满足 $\Xi(-\lambda)^{\mathsf T}\Phi^+=\Sigma^++B_0$，有限窗在算子范数下以 $O(e^{-\operatorname{Re}\lambda T/2})$ 收敛至半轴算子。
2. **双侧逆与纯虚谱轴**：正、负半平面上的双腿 Bochner 积分给出传播束的两侧逆，迫使双腿谱完全落在虚轴 $\operatorname{Re}\lambda=0$ 上；零动量转移时恒等算符落入核内且准备态保证空间非平凡，故 $\lambda=0$ 为真实谱点。
3. **非自治 $C^1$ 背景与因果不动点**：对源时间窗 $[0,T_*)$ 内任意 $C^1$ 场历史，Picard 迭代给出非自治双腿演化并经同一 Green 与 36 曲率读口返回原场；在 $\det(I-\mathcal U)\ne0$ 的频率上因果反馈具备双侧逆与唯一不动点，且在源生基准点 $\lambda_0=3-g$ 处更新范数 $\|\mathcal U\|\le 3/16<1$，逆算子范数不超过 $16/13$（补充材料 S6）。

### 7.3 九约束 Schur 充要反馈与整矩阵四次解析红外返回

由于规范与微分同胚对称性，$H_{289}(P)$ 带有九维核与九维余核：记零场初值嵌入为 $N(P):\mathbb C^9\to\mathbb C^{289}$，零源约束余核投影为 $C(P)=N(-P)^{\mathsf T}:\mathbb C^{289}\to\mathbb C^9$（满足 $HN=0,CH=0$，且母 Green 满足 $GH=I-ND,HG=I-LC,DN=CL=I_9$）。因此量子极化写回全场方程时，绝不能只写一个盲目求逆，而必须同时追踪九个初值自由度与九条相容约束。

**定理 7.5（全场量子反馈与九约束 Schur 方程的充要等价）。** 令归一量子半轴矩阵为 $Q_d(P,\lambda)=(\lambda-P_0)\Pi_d^\infty(P,\lambda)$（在 $\operatorname{Re}\lambda>\max(0,\operatorname{Re}P_0)$ 上定义；$P_0=0$ 时即为 $\lambda\Pi_d^{\rm st}$）。在 $G(P)$ 的正则域及反馈可逆条件 $\det(I-G Q_d)\ne 0$ 下，置

$$B=I-GQ_d,\quad A=B^{-1},\quad x(c)=A(Gf+Nc),\quad S=CQ_dAN\in\mathbb C^{9\times9},\quad b=-C(f+Q_dAGf).\tag{7.6}$$

则对**任意**外源 $f\in\mathbb C^{289}$ 与候选全场向量 $x\in\mathbb C^{289}$（无需预先假设 $9\times9$ 矩阵 $S$ 可逆），完整受迫量子反馈方程成立，**当且仅当**存在零模初值 $c\in\mathbb C^9$ 满足九约束 Schur 方程：

$$\bigl[H_{289}(P)-Q_d(P,\lambda)\bigr]x=f\quad\Longleftrightarrow\quad\exists c\in\mathbb C^9:\;x=x(c)\ \text{且}\ Sc=b.\tag{7.7}$$

此外，源自身生成有限窗正则锚点使 $\|T^{-1}G_*\Pi_T\|\le 1/16$、两侧逆范数 $\|A_T\|\le 16/15$；在同步时钟有限窗上，有效九维约化矩阵 $S_T(z)=C(z)\Pi_T(z)A_T(z)N(z)$ 对频率参数的全导数精确保留全部四个动因子的变率：

$$S_T'=C'\Pi_T A_TN+C\Pi_T'A_TN+C\Pi_T A_T'N+C\Pi_T A_TN',\qquad A_T'=-A_TB_T'A_T.\tag{7.8}$$

证明。正向将 $x(c)=Nc+G(f+Q_d x(c))$ 左乘 $H_{289}$，用 $HN=0$ 与 $HG=I-LC$ 得 $[H_{289}-Q_d]x(c)=f-LC(f+Q_d x(c))$；因 $CL=I_9$，$L$ 单射，故残差为零充要于 $C(f+Q_d x(c))=Sc-b=0$。反向若 $[H_{289}-Q_d]x=f$，令 $c=Dx$，左乘 $G$ 并用 $GH=I-ND$ 得 $(I-GQ_d)x=Gf+Nc$，左乘 $A$ 得 $x=x(c)$，再由 $CH=0$ 得 $C(f+Q_d x)=CHx=0$ 即 $Sc=b$。完整细节与双时钟有理分式表达见补充材料 S13。∎

接下来考察零阻尼红外极限 $\lambda\to 0$。若对五因子核的每条腿粗暴使用全 Fock 空间最坏多项式界（56 次），积分将在 $\lambda\to 0$ 发散至极高阶。然而物理输入态具有确定的低粒子数：创建单位态 $u_\epsilon$ 位于二粒子层（Yukawa 升级至多二次），背景 $v_\epsilon$ 位于单粒子层（升级至多一次），且左自由核投影消去了左腿升级。这一精细分级结构将五因子核的时间增长精准压低到**三次**。

**定理 7.6（粒子数分级三次时间界与整矩阵 $z^4\Pi_{\rm st}$ 四次解析红外返回）。** 对每个固定实际事件 $d$、物质参数 $(p,F)$ 及零外动量转移 $k=0$，源生成非负矩阵界 $K_{ij}(d)\ge0$，使完整五项 Noether 射流对一切 $t\in\mathbb R$ 满足 $|\mathscr D_{ij}(t)|\le K_{ij}(d)(1+|t|)^3$。由此对全部实阻尼 $0<\sigma\le 1$ 及全部 $289\times289$ 个矩阵元，有

$$\sigma^4\,\bigl|\Pi_d^{\rm st}(0,\sigma)_{ij}\bigr|\;\le\;56\,K_{ij}(d).\tag{7.9}$$

进一步，由双腿传播生成元的源最小多项式 $p_d(z)=z^{m_d}d_d(z)$（$d_d(0)\ne0$）构造整矩阵正则化 $R_d(z)=z^{2m_d}\Pi_d^{\rm st}(0,z)$，它在 $z=0$ 邻域全纯；式 (7.9) 的正实轴四次界迫使其在零点的解析消失阶至少为 $\max(0,2m_d-4)$，从而对**一切**极点阶分支 $m_d\in\mathbb N$，源自身给出原点邻域上的全纯 $289\times289$ 矩阵函数 $G_{4,d}(z)$，在右半平面零点穿孔邻域上恒有

$$z^4\,\Pi_d^{\rm st}(0,z)=G_{4,d}(z).\tag{7.10}$$

故复阻尼沿 $\operatorname{Re}z>0$ 趋于 $0$ 与实阻尼 $\sigma\downarrow 0$ 均一致返回同一有限完整矩阵 $G_{4,d}(0)$，且六次加权极限严格归零：

$$z^6\,\Pi_d^{\rm st}(0,z)\;\longrightarrow\;0\qquad(z\to 0,\ \operatorname{Re}z>0).\tag{7.11}$$

证明。当 $2m_d\ge4$ 时，若全纯矩阵函数 $R_d(z)$ 在 $z=0$ 的消失阶 $n<2m_d-4$，写 $R_d(z)=z^n g(z)$（$g(0)\ne0$），则在正实轴 $s\downarrow0$ 上由式 (7.9) 得 $\|g(s)\|\le C_d s^{2m_d-4-n}\to 0$，与 $g$ 连续且 $g(0)\ne0$ 矛盾。故可精确除掉 $z^{2m_d-4}$ 得全纯 $G_{4,d}(z)$；当 $2m_d<4$ 时直接取 $G_{4,d}(z)=z^{4-2m_d}R_d(z)$。完整分级斜率估计与解析分解见补充材料 S12.4。∎

![图 4 正则反馈域与零转移解析红外域的双域对照](figures/vector/fig7-two-domains-v3.png)

**图 4｜同一源生成的两类独立定义域与返回机制（定理 7.3、7.5、7.6、7.8）。** 固定同一原作用、实际事件 $d$ 与准备态。左支（A）：常场真正非线性 Noether 半轴在 $\operatorname{Re}\lambda>0$ 的源生场邻域内为 $C^2$，全场导数给出 $\Pi_{\rm st}$；在线性化正则域 $\operatorname{Re}\lambda>\gamma_{\rm clk}$ 且 $\det(I-GQ_d)\ne0$ 上，全场反馈等价于原响应与九约束 Schur 方程 $Sc=b$。右支（B）：零外动量转移下，粒子数分级三次时间界与源最小多项式给出右半平面邻域全纯恒等式 $z^4\Pi_{\rm st}(0,z)=G_{4,d}(z)\to G_{4,d}(0)$ 及 $z^6\Pi_{\rm st}\to0$；在单位空间方向上，192/97 源内消元与电磁 Ward 钟因子消去进一步给出二变量联合锥上的有理分式返回。两支各有精确前提与用途，互不冒用。

### 7.4 静态极点、192/97 源内 Schur 分式与涌现 $1/(4\pi|x-y|)$ 长程核

现在把动量转移打开（$k\ne 0$），看量子电流在静态与空间观测中留下怎样的真实长程物理几何。

**定理 7.7（共同运动载体、动量连续性与原生静态留数）。** 在定理 7.4 的设置中：（1）任意三动量 $p$ 处的正负手征八态基与静止基之间的重叠矩阵 $U(p)$ 为酉阵，任意 Gauss 算符 $A$ 的读出张量满足 $M(p_L,p_R)[A]=U(p_L)^\dagger M(0,0)[A]U(p_R)$；（2）压缩生成元 $C_F(p)=C_F(0)+v_F(p)$ 对动量实仿射连续，保留集跨动量不变，双腿预解、时间演化与 289 维五因子窗口对 $(p_L,p_R)$ 一致连续；（3）沿静态虚动量路径 $(0,i\kappa,0,0)$（$\kappa$ 位于源生穿孔静态域），未清分母的 289 维母 Green 分解为接触项、$(-\kappa^2)^{-1}$ 五方向原生 Schur 极点与 98 维正则补空间（连同 5 个极点方向共还原 103 维活跃块，$5+98=103$）之和；实际窗口电流驱动场的静态留数为 $-\kappa^2\varphi(\kappa)\to E_0\bigl(-\tfrac{9}{125}\sqrt{30}\mathfrak w,-\tfrac{67}{72}\sqrt{30}\mathfrak w,0,0,0\bigr)$，其中原点权重 $\mathfrak w=\tfrac{3\sqrt2}{10}(J_{21}-J_{34})=-c_{114}(0,T)=\kappa_{\rm ct}-\delta_{\rm cf}$ 恰为第 114 号色约束共源的相反数，偏离窗满足显式先验界 $|\mathfrak w-\kappa_{\rm ct}|\le\|D_0F\||T|/(|\operatorname{Im}z||\operatorname{Im}w|)$，且 $H_{289}\varphi=w_{\rm win}$ 成立当且仅当九维零方向共源为零（补充材料 S7）。

进一步，在单位空间方向 $n$（$|n|^2=1$）、空间尺度参数 $0<\varepsilon\le 1/2$ 与正阻尼时钟参数 $\sigma>0$ 组成的二变量有理多项式环 $(\mathbb C[\varepsilon])[X]$（外层不定元 $X$ 代入 $\sigma$）上，完整的 $289\times289$ 物质—时钟耦合束可以通过精确代数消元压入 97 维活跃空间，并展现漂亮的**电磁 Ward 钟因子精确消去**：

**定理 7.8（192/97 源内 Schur 约化、电磁 Ward 钟因子消去与源生联合锥）。** 固定修饰事件 $d$ 与单位空间动量方向 $n$（$|n|^2=1$）：

1. **192 维非活跃双侧逆与 97 维分式表示**：在 $0<\varepsilon\le 1/2$ 上，192 个源非活跃场方向具有显式多项式双侧逆，保留全部 $97\leftrightarrow 192$ 量子交叉列将全场方程等价压成 97 维 Schur 系统 $S_{97}$（$289=192+97$；修正全场行列式非零 $\det_{\rm corr}\ne0\iff\det S_{97}\ne0$），并唯一重构全部 192 个非活跃场分量；乘清分母多项式 $d_{\rm nat}$ 后得到二变量多项式矩阵 $Q_{97}\in M_{97}((\mathbb C[\varepsilon])[X])$，使正则点上的四阶加权时间电磁系数精确表为有理分式 $\varepsilon^4 T_{00}(\varepsilon,\sigma)=\mathrm{eval}_{\varepsilon,\sigma}(N_{97})/\mathrm{eval}_{\varepsilon,\sigma}(\det Q_{97})$。
2. **电磁 Ward 行 $X^2$ 与 Noether 分子 $X^3$ 精确消因子**：物理电磁时间强迫向量 $E_A$ 在第 15 号活跃枢轴坐标处取精确非零有理值 $-1/2$，在全部 192 个非活跃坐标处为零；结合非活跃右重构，97 维多项式矩阵满足整系数行恒等式
   $$E_A^{\mathsf T}\,Q_{97}=X^2\,R_{97}^{\mathsf T},\tag{7.12}$$
   由第 15 行的初等行更新立得首一多项式 $X^2$ 整除分解 $\det Q_{97}=X^2\,D_{\rm W}$，同时辅助时钟因子给出 $N_{97}=X^3\,N_{\rm W}$。因此在任意 $\sigma>0$、$0<\varepsilon\le 1/2$ 且 $\det_{\rm corr}\ne0$ 的点上，二次钟因子精确对消为
   $$\varepsilon^4\,T_{00}(\varepsilon,\sigma)=\sigma\,\frac{\mathrm{eval}_{\varepsilon,\sigma}(N_{\rm W})}{\mathrm{eval}_{\varepsilon,\sigma}(D_{\rm W})},\tag{7.13}$$
   且非零多项式时双方的 $X$-尾阶严格满足 $\operatorname{ord}_X(N_{97})=3+\operatorname{ord}_X(N_{\rm W})$、$\operatorname{ord}_X(\det Q_{97})=2+\operatorname{ord}_X(D_{\rm W})$。
3. **单种子生成的二变量联合正则锥**：记 $A=N_{97}$、$B=\det Q_{97}$；对每个 $P\in\{A,B\}$，按 $X$-尾阶 $k_P=\operatorname{ord}_X(P)$ 提出首时钟空间系数 $p_0(\varepsilon)=\varepsilon^{\ell_P}(c_P+\varepsilon\tilde p(\varepsilon))$（约定 $P=0$ 时 $k_P=\ell_P=0,c_P=0$）。只要存在一个满足 $0<\varepsilon_0\le 1/2,\sigma_0>0$ 的正则种子使 $\det_{\rm corr}(\varepsilon_0,\sigma_0)\ne0$，则 $B\ne0$ 且 $c_B\ne0$；记空间重标权为 $w_{\rm sp}(\varepsilon)=\varepsilon^{\ell_B-\ell_A}$，并由 $\tilde a,\tilde b$ 在 $[0,1/2]$ 上的有限多项式系数模和显式定出非负斜率常数 $S_{\rm ratio}\ge0$（显式公式见补充材料 S17.3）。二变量多项式系数随之显式生成正空间半径 $\rho_{\rm sp}>0$ 及对每个 $0<\varepsilon\le\rho_{\rm sp}$ 严格为正的时钟上限 $\rho_{\rm clk}(\varepsilon)>0$，使整个联合锥 $\{(\varepsilon,\sigma):0<\varepsilon\le\rho_{\rm sp},\,0<\sigma\le\rho_{\rm clk}(\varepsilon)\}$ 上恒有 $\det_{\rm corr}(\varepsilon,\sigma)\ne0$，且剥去双方首阶幂次后的重标分式与首系数常数比 $c_A/c_B$ 满足线性一致误差界
   $$\Bigl\|w_{\rm sp}(\varepsilon)\,\sigma^{\operatorname{ord}_X(\det Q_{97})-\operatorname{ord}_X(N_{97})}\,\varepsilon^4 T_{00}(\varepsilon,\sigma)-\frac{c_A}{c_B}\Bigr\|\;\le\;\bigl(1+S_{\rm ratio}\bigr)\,\varepsilon.\tag{7.14}$$

证明。式 (7.12) 由分块 Schur 乘法 $E_A^{\mathsf T}(d_{\rm nat}P_{AA}-P_{AI}N_{\rm inv}P_{IA})$ 将两块共同的 $X^2$ 时间因子提出；利用枢轴元 $(E_A)_{15}=-1/2$（逆为 $-2$）把第 15 行替换为组合行 $E_A^{\mathsf T}Q_{97}=X^2 R_{97}^{\mathsf T}$，立得 $(-1/2)\det Q_{97}=X^2\det(\mathrm{updateRow}_{15}Q_{97})$，乘 $-2$ 即证 $X^2\mid\det Q_{97}$。联合锥半径与式 (7.14) 的两步三角不等式推导见补充材料 S17.1–S17.3。∎

定理 7.7 关注的是原生色约束留数；若改用同一母作用密度下的字面**物理电磁插入 $E$**，并让两个独立量子事件在撤去截断后通过完整 289 维母 Green 函数相互作用，三维空间中便直接涌现出经典的 $1/(4\pi r)$ 长程势：

**定理 7.9（同密度物理电磁留数、72 规范曲率与涌现 $1/(4\pi|x-y|)$ 长程空间核）。**

1. **物理频率极点幂等律与 72 曲率同步返回**：由定理 7.1 同一母密度 Hessian 给出的物理电磁收缩 $E^{\mathsf T}GE$ 在源生简单频率极点 $\omega_*$ 处的留数算子 $R_\omega=\lim_{\omega\to\omega_*}(\omega-\omega_*)G(\omega)$ 满足幂等规范关系
   $$R_\omega\,K'(\omega_*)\,R_\omega=R_\omega\qquad\bigl(\text{正时间重标 }t'=ct\text{ 下保持不变}\bigr).\tag{7.15}$$
   经典窗口场强迫在极点处精确归零，创建态减背景的连通量子 Noether 强迫留下全场极点留数 $R_\omega J_d$，并由含背景非阿贝尔对易子 $[\bar A_\mu,a_\nu]$ 的全部 $6\times12=72$ 个规范曲率分量同步连续读出。
2. **两运动量子荷源涌现 $1/(4\pi|x-y|)$ Coulomb/Newton 空间核**：任取两个独立实际事件 $d_D,d_S$，先按定理 7.2 撤去各自物质 Yukawa 截断得到未截断流 $J_D^{\rm uncut},J_S^{\rm uncut}$，再在共同三维动量 $k=2\pi\xi$ 的源生红外窗 $0<a|k|<\rho_{DS}$ 内通过完整 289 维母 Green 函数配对。则对每个三维 Schwartz 测试函数 $\phi\in\mathcal S(\mathbb R^3)$，尺度极限 $a\downarrow 0$ 严格收敛为三维 Coulomb/Newton 位势积分与完整五方向静态逆系数的乘积：
   $$\lim_{a\downarrow 0}\int_{\mathbb R^3} e^{2\pi i\xi\cdot x}\,\phi(\xi)\,
   J_D^{\rm uncut}(-ak)^{\mathsf T}\,a^2 G(0,iak)\,J_S^{\rm uncut}(ak)\,d\xi
   \;=\;\mathcal N_\phi(x)\,C_{DS},\tag{7.16}$$
   其中空间位势卷积与静态耦合常数（$S_{\rm st}$ 为定理 7.7(3) 的五方向原生静态块）分别为
   $$\mathcal N_\phi(x)=\int_{\mathbb R^3}\frac{(\mathcal F^{-1}\phi)(x-y)}{4\pi|y|}\,dy,\qquad
   C_{DS}=-\bigl(J_D^{(5)}(0)\bigr)^{\mathsf T}S_{\rm st}^{-1}J_S^{(5)}(0).\tag{7.17}$$
   进一步，对第 7.5 节的归一化三费米子带荷外态，当源端与探测端各含至少一条形式伴随支（$H^\sharp$）外腿时，完整多体响应相对底层单通道系数的 Born 修饰因子精确等于四腿重叠乘积 $Z=\prod_{j=1}^4 z_j\in(0,1]$，其中单腿基础收缩常数为 $9/125+67/72=9023/9000$（补充材料 S11.3–S11.6）。

### 7.5 带电色单态自旋 `1/2` 三粒子复合正谱与四维连续曲率强积分

完整量子理论不仅要处理真空极化与两体库仑核，还必须回答：**504 模母 CAR 代数能否不借外部强子模型，自己生成具有真实重子／轻子型量子数（色单态、整数电荷 $\pm1$、自旋 $1/2$）的复合多费米子态，并给出严格正的动态响应谱与精确重整化尾？同时，十阶总闭合对象 $\mathcal U_{1\text{--}10}$ 能否在四维连续闵氏时空上直接生成保持自伴时间生成元定义域 $\operatorname{Dom}(H_{\rm time})$ 的非阿贝尔曲率场算符？**最后三条定理正面闭合这两个问题。

**定理 7.10（复合源时钟匹配整词预算与重整化第二 Green 全频共同尾）。** 在完整原生历史生成元 $H_0=C_F+d_F$ 与复合源时钟 $\varphi$ 上，对阻尼 $\sigma=\mu>0$：（1）匹配列 $C_3=UD+3iD_cU$ 与字面延迟整词 $R_3$ 满足严格下界 $J_3\ge\tfrac{3N}{8}\|C_3w\|^2+\tfrac{5N}{2}\mathsf{sc}(Uw)+10N\mathrm{sh}_{40}(w)+\tfrac{3N}{4}\mathsf{cf}(Uw)+18N\|w\|^2$；（2）对任意 $\varepsilon>0,\mu>0$、核种子 $g,k$ 及前向与形式伴随两支 $(H,H^\sharp)$，存在先于全部 $m,\ell$ 与共尾有限帧 $F$ 的共同指标 $N_0$，使闭合联合预算受正部积分控制 $C_{\rm J}\le\varepsilon+48M_\mu(k)P_\rho\frac{\mu}{20N}\int R_3^+$；（3）第二 Green 函数的极点扣项重整化端点 $\mathcal E=\operatorname{Re}\langle k,(H_0-\operatorname{Re}z)Aw\rangle-\|k\|^2\operatorname{Re}(1/z)$ 在前向与迟滞两个因果口上具有**全实频轴绝对 $L^1$ 共同零尾**：对任意 $\varepsilon>0$，存在共同 $N_0$ 使全部 $m\ge N_0,\ell\ge m$ 与共尾 $F$ 满足 $\int_{\mathbb R}|\mathcal E(\omega)|\,d\omega\le\varepsilon$，且 $R_3=\mathcal E/\sigma^2-D_{\rm ren}/(2\sigma^2)+R_{\rm df}$（其中体积扩散生成元满足 $L(1)=0,L(V)=18$ 且噪声核半正定；补充材料 S8）。

现在在 504 模双支 CAR 的每个分支 $d\in\{0,1\}$ 上，利用三色全反对称张量 $\epsilon_{abc}$ 将两个色—正超荷楔模式与一个色—弱楔模式耦合，显式构造三费米子态 $q_d^{(3)}=\tfrac13[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)]$：Kronecker 行列式给出 $\|q_d^{(3)}\|^2=(6+12)/9=2$，故 $q_d^{(3)}/\sqrt2$ 精确具有**单位范数、色 $\mathfrak{su}(3)$ 完全单态（$\operatorname{tr}A=0$ 消去）、字面电磁荷 $(-1)^d=\pm1$，以及四维 Dirac 自旋平方本征值 $\mathsf S^2=\tfrac34$（自旋 $1/2$）**，且单向 Yukawa 算符在其上严格非零 $Yq_d^{(3)}\ne0$。将接触通道（$\mathcal B_0$）、79 维正典逆通道（$\mathcal B_1$）、24 维独立对偶逆通道（$\mathcal B_2$）与 61 维标量逆通道（$\mathcal B_3$）在全加权 Hilbert 空间上**先相干相加**为有界总读出算符 $\mathcal B=\sum_{b=0}^3\mathcal B_b$，再取响应模方谱测度：

$$d\nu(\omega)=\|\mathcal B r_F(\omega)\|^2\,d\omega
=\operatorname{Re}\sum_{a,b=0}^3\langle\mathcal B_a r_F(\omega),\,\mathcal B_b r_F(\omega)\rangle\,d\omega.\tag{7.18}$$

**定理 7.11（带电色单态自旋 `1/2` 三费米子态的共同实转移正谱与中性严格零道）。** 固定源生成实穿孔半径 $\delta>0$ 与光滑紧支撑配置剖面 $f$（满足 $f(z_*)=1$），其选取**先于**两个独立对偶支、全部有限帧 $F$、前向与形式伴随两支 $(H,H^\sharp)$、两个因果口及全体正阻尼 $\mu>0$。对任意非零实动量转移 $0<|x|<\delta$（取四动量转移 $(x,0,0,0)$，物质初末动量为零）：

1. **严格正总谱、正时间质量与正 Yukawa 余量**：全部 17 个传播分母在该实区间上无极点，完整四通道相干振幅对两个对偶支均非零；由同一剖面 $f$ 生成的三费米子动态响应具有有限且严格正的总谱质量、高频邻域严格正谱密度及严格正因果时间质量，满足 Parseval 恒等式
   $$\nu(\mathbb R)=2\pi\int_{\mathbb R}\|\mathcal B w_F(t)\|^2\,dt\;>\;0,\tag{7.19}$$
   且未受迫完整 Yukawa 响应相对底层的积分修正余量 $\int_{\mathbb R}\|\mathrm{corr}_{Y,F}(\omega)\|^2d\omega>0$ 对一切 $(F,c,\mu>0)$ 严格为正（同一压缩算子 $C_F$ 的双预解 Sylvester 恒等式与有符号压力—标量能量恒等式一并闭合）。
2. **中性扇区全频全时严格零道**：由于完整四通道算符 $\mathcal B$ 与带号占据数算符 $Q_s$ 逐系数对易，而三费米子输入态携带确定带号占据值 $\pm3$，在共尾饱和载体上，任何净占据为零的中性投影态在**每一个实频率、每一个实时刻与每一个 Borel 频带**上的响应输出恒等于零（补充材料 S14）。

证明思路。在纯虚参考点 $x=i$ 处，四个通道的精确代数读数之和等于 $\sqrt{30}\times\frac{1502925864947895702084635234454041}{3859115104366170163070540928506250}\ne0$。由于全部 33 组分子与 17 个分母均为复平面上的亚纯函数且在 $x=i$ 解析非零，亚纯恒等定理保证它们在原点两侧必有共同实穿孔无零无极点区间 $0<|x|<\delta$，再结合高频预解渐近 $z\mathcal B r_F(z)\to-\mathcal B(q_d^{(3)}f)\ne0$ 即得严格正谱（S14.1–S14.3）。∎

最后，不同于依赖格点离散化 [6] 或欧氏 Green 函数解析延拓公理 [27] 的传统重构路径，我们将十阶总闭合对象 $\mathcal U_{1\text{--}10}$ 自身的标准模型规范联络 $A_{\rm cl}$ 施加任意紧支撑光滑变分 $A_{\rm cl}+t\eta$（$\eta\in C_c^\infty(\mathbb R^4,\Omega^1(\mathfrak h_{\rm SM}))$，$t\in\mathbb R$）；记 252 维物质响应空间（及共同物质载体 $\mathcal H_{\rm com}$）上源生强连续酉时间群 $U_{\rm time}(s)=e^{-isH_{\rm time}}$ 的自伴生成元为 $H_{\rm time}$（与 §6.3 在 504 模 CAR 配置空间上的非对称生成元 $H=H_0+Y$ 严格区分），直接在实时间洛伦兹框架上构造保持 $\operatorname{Dom}(H_{\rm time})$ 的四维连续量子曲率场算符：

**定理 7.12（原总闭合对象紧支规范变分的四维曲率强积分与 $\operatorname{Dom}(H_{\rm time})$ 词 Gram）。** 对十阶总闭合对象 $\mathcal U_{1\text{--}10}$ 的任意紧支撑光滑标准模型联络变分 $\eta$、任意实幅度 $t\in\mathbb R$、任意同点有序曲率多项式 $P$ 及任意四维 Schwartz 测试函数 $f\in\mathcal S(\mathbb R^4)$：

1. **四维强积分、时间协变与 $\operatorname{Dom}(H_{\rm time})$ 保持**：二次精确曲率变分在空间切片投影 $\pi_{\rm sp}(p)=p-(p_0,0,0,0)$ 上生成有界强连续算子种子，经源生酉时间群 $U_{\rm time}(s)$ 共轭平移积分得到有界场算符
   $$\Phi_{\eta,t,P}(f)v=\int_{\mathbb R^4} f(p)\,U_{\rm time}(-p_0)\,\mathrm{seed}_{\eta,t,P}\bigl(\pi_{\rm sp}(p)\bigr)\,U_{\rm time}(p_0)v\,dp,\tag{7.20}$$
   它对测试函数 $f$ 连续线性，满足精确时间平移协变律 $U_{\rm time}(s)\Phi_{\eta,t,P}(f)v=\Phi_{\eta,t,P}(\tau_s f)U_{\rm time}(s)v$ 与海森堡共轭导数 $\frac{d}{ds}\big|_{s=0}\bigl(U_{\rm time}(s)\Phi_{\eta,t,P}(f)U_{\rm time}(-s)\bigr)=\Phi_{\eta,t,P}(\partial_0 f)$；因此每个 $\Phi_{\eta,t,P}(f)$ 及其任意有限长度混合乘积词 $W(w)=\prod_{\ell}\Phi_{l_\ell}$ 均严格保持时间生成元定义域 $\operatorname{Dom}(H_{\rm time})$，且在零变分 $t=0$ 时精确退回原点嵌入 $\iota_0(P)$ 的原规范词场 $\Phi_{\eta,0,P}(f)=\Phi_{\rm orig}(\iota_0(P),f)$。
2. **共同载体实现与正半定词 Gram**：经满射等距映射拉回至共同物质载体空间 $\mathcal H_{\rm com}$ 后，全部有限混合曲率词作用与原载体准备态 $\psi_{\rm com}(x)$ 精确相容；在任意时空基点 $x$ 与任意有限词族 $\{w_i\}_{i\in I}$ 上，由当前演化步回答态与定理 6.2 响应矩阵给出的母配对读数恒等于 Hilbert 内积 $\mathrm{Gram}_x(w_i,w_j)=\langle W(w_i)\psi_{\rm prep}(x),W(w_j)\psi_{\rm prep}(x)\rangle$，构成半正定 Hermitian 矩阵（补充材料 S17.4）。

---

## 8 全时非线性轨道与无参解析预测

### 8.1 全时规范—Dirac 耦合轨道与量子时间导数能量恢复

在固定构造 4.1 的余标架与自旋联络几何背景后，放开规范场幅度 $r(t)$、共轭动量 $p(t)$ 与物质相位角 $\theta(t)$，让它们沿共同作用量导出的非线性耦合方程自由演化。

**定理 8.1（唯一全实时间规范—Dirac 非线性轨道）。** 在相空间 $\mathbb R^3=\{(r,p,\theta)\}$ 上，对**每一个**实初始冲量 $p_0\in\mathbb R$，存在唯一定义在整条实时间轴 $t\in\mathbb R$ 上的光滑全局轨道，初值为 $(a,p_0,0)$，全时满足耦合 Hamilton 方程

$$\dot r=\frac{p}{m},\qquad \dot p=-V'(r),\qquad \dot\theta=\frac{3N}{2}\,(k-r),\qquad
V(r)=\frac{3}{4\sigma N}\,r^4-6Nk\,r,\quad m=\frac{3N}{2\sigma}=3N .$$

沿整条轨道，每一点上的背景规范 Euler 三形式以及原始、伴随两条物质 Euler 方向残差恒为零；总能量 $E=p^2/(2m)+V(r)$ 严格守恒，动量与振幅一致受控于 $p(t)^2\le p_0^2$ 及 $5N(r(t)-a)^2\le p_0^2/(2m)$；当 $p_0\ne0$ 时，五次规范螺旋不变量 $Q(t)=3r(t)^5$ 具有非零初速度 $\dot Q(0)=15a^4 p_0/m\ne0$。

证明。利用平衡条件 $a^3=2\sigma N^2k=N^2k$（等价于 $V'(a)=0$），将相对势能作无近似精确配方：$V(r)-V(a)=5N(r-a)^2+\frac{3}{2N}(r-a)^2(r+a)^2\ge 5N(r-a)^2$。守恒能量 $E-V(a)=p_0^2/(2m)$ 先验封死 $|p(t)|$ 与 $|r(t)-a|$ 的有界闭球，排除有限时间爆破；先在光滑截断向量场上取全局解，再验证解始终留在截断恒等于 $1$ 的球内，由局部唯一性延拓得全实时间唯一轨道。∎

反过来，给定这条非线性轨道，无需外部经典仪表测量 $r(t)$ 和 $p(t)$：直接读取该轨道所载 252 维量子物质特征态的时间导数，即可无损重建全部经典相空间坐标与四次非线性 Legendre 能量：

**定理 8.2（由量子时间导数精确恢复非线性轨道与 Legendre 能量）。** 对每个实冲量 $p_0$、相应全局轨道及任意时刻 $t\in\mathbb R$，令 $z_t=\tfrac12\mathrm{naturalCoordinates}(\psi_{\rm orbit}(t))\in\mathbb C^{252}$ 为归一母物质特征态（$\|z_t\|=1$），记固定时钟速度探针算符为 $\mathsf V=\operatorname{diag}(i\omega,i\omega,-i\omega,-i\omega)\otimes I_{63}$。由量子旋量速率读数

$$q(t)=\frac{\operatorname{Re}\langle \mathsf Vz_t,\,z_t'\rangle}{\omega}$$

精确恢复轨道振幅 $r(t)=k-\frac{2}{3N}q(t)$ 与动量 $p(t)=-\frac{2m}{3N}q'(t)$；且轨道的相对 Legendre 能量精确等于

$$E_{\mathrm{Legendre}}=\frac{p(t)^2}{2m}+c\,(r(t)-a)^2+\frac{3\,(r(t)-a)^2(r(t)+a)^2}{4\sigma N},\qquad c=\frac{3a^2}{2\sigma N}=5N ,$$

其中全部系数 $m=3N$、$c=5N$、$3/(4\sigma N)=3/(2N)$ 均由固定源直接给出，末项处处非负并在平衡点附近贡献局部二阶曲率 $2c(r-a)^2+O((r-a)^3)$（总局部谐振曲率为 $3c=15N$）。

证明。沿轨道求导有 $z_t'=\frac{3N(k-r(t))}{2\omega}\mathsf Vz_t$，利用 $\|\mathsf Vz_t\|^2=\omega^2$ 代入内积立得 $q(t)=\frac{3N}{2}(k-r(t))$，再次求导并用 $\dot r=p/m$ 即恢复 $p(t)$；将恢复出的 $(r,p)$ 代入 $V(r)-V(a)$ 的四次精确因式分解即得 $E_{\mathrm{Legendre}}$。∎

![图 5 全实时间轨道与 Legendre 相对能量](figures/vector/fig4-global-orbit-energy.png)

**图 5｜全实时间耦合相平面等能轨道与四次强制势分解。** 由定理 8.1–8.2 精确解析式直接绘制，无拟合参数。左：四个初始冲量 $p_0=0.6,1.2,1.8,2.4$ 的闭合全局相轨道 $p=\pm\sqrt{2m(E_{\mathrm{rel}}-[V(r)-V(a)])}$，竖直点线标出 $p_0=1.2$ 与 $2.4$ 的精确转向半径。右：完整势差 $V(r)-V(a)$、全局二次强制下界 $c(r-a)^2$ 与非负四次项 $3(r-a)^2(r+a)^2/(2N)$；两条水平线标出对应相对能量，与势差曲线的交点精确对齐左图转向半径。

### 8.2 五点相干律与零经验输入双侧 Bell 概率族

**定理 8.3（全时间相干律与五点无参锁定）。** 在固定正源与实际构型上：（1）每个时空点的单侧干涉相干读数恒为 $\cos^2(\omega x^0)$，其中 $\omega^2=972/3125$；（2）首暗时刻 $t^*=\pi/(2\omega)$ 处相干读数精确为零（振幅相消而非纯态退相干），$2t^*$ 处恢复为 $1$；（3）在无量纲时间 $u=t/t^*$ 的五个刻度 $u=0,\tfrac12,1,\tfrac32,2$ 上，当前拍与下一拍的量子读数联合锁定为 $(1,\tfrac12,0,\tfrac12,1)$，而擦除交叉相位的经典排他路径基准在全部刻度上恒为 $\tfrac12$（表 3、图 6），在总闭合中直接排除排他路径模型。

**表 3 五个无量纲时间刻度上的源生相干读数与排他路径对照。**

| $u=t/t^*$ | $0$ | $1/2$ | $1$ | $3/2$ | $2$ |
| --- | :---: | :---: | :---: | :---: | :---: |
| 源生量子相干权重 $\cos^2(u\pi/2)$ | $1$ | $1/2$ | $0$ | $1/2$ | $1$ |
| 经典排他路径基准 | $1/2$ | $1/2$ | $1/2$ | $1/2$ | $1/2$ |

![图 6 五点相干读数与指定排他对照](figures/vector/fig3-five-point-quantum-clock.png)

**图 6｜五个刻度上的相干熄灭与复燃。** 横轴为 $u=t/t^*$，实线为 $\cos^2(u\pi/2)$，虚线为排他路径常值 $1/2$，背景明度随同一相干权重线性编码。下方五个单位圆与横轴刻度逐列对齐，画出上下旋量相位振幅 $e^{\pm i\theta}$ 及其相干实平均 $\cos\theta$（朱红短杆，其长度平方即上方读数）：$u=1$ 暗时刻源于两条相干振幅反向抵消，因此到 $u=2$ 能够无损复燃至 $1$。

**命题 8.4（零经验输入双侧 Bell 概率族与确定性准备）。** 在固定源与实际构型上，对每个时空点、双方任意单位 XZ 测量轴 $a=(a_x,a_z),b=(b_x,b_z)$ 及四个布尔结局 $x,y\in\{\text{true},\text{false}\}$（符号取 $\pm1$），当前拍与下一拍的双侧联合 Born 概率恒为

$$P(a,b;x,y)=\frac{1-\,\mathrm{sign}(x)\,\mathrm{sign}(y)\,\big(a_xb_x+a_zb_z\big)}{4},$$

每侧边缘概率恒为 $1/2$，四结局非负归一。对同一演化态矢依次施加固定色 $Z$ 门与色 $X$ 交换所得确定性 $\Phi^+$ 准备（无随机后选择），双正结局联合概率为 $(1+a_xb_x+a_zb_z)/4$，关联函数为 $E(a,b)=a_xb_x+a_zb_z$；取标准正交轴与角平分轴时，无需任何经验或器件参数即精确达到量子 Tsirelson 极值 $2\sqrt2$（命题 10.2(1)）。

---

## 9 十阶物理根封印、零未登记权威与同一母源的普遍形成

至此，一份固定源材料已经完成了从几何生成、唯一九场解、无先验 504 模量子动力学、全场红外返回到双侧关联预测的构造。现在正面亮出统摄整部理论的根封印与发生源边界定理：**这套连续—量子统一结构究竟怎样锚定在零公理发生与整账内核之上？演化中途是否容许任何账外旋钮或静默吃掉的场方程残差？如果放开源参数，或者面对原准入接口上的任意合法世界状态、完整查询体系乃至整个演化过程，是否还需要引入第二份底层基源？**

### 9.1 光滑统一源家族实现、有序路径与自主有理程序

首先把固定正源 $S_0$ 的七个字段放开，让源遍历整个 65 维连续加离散的**光滑统一源家族**。

**定理 9.1（任意光滑统一源的九场实现与准入充要判据）。** 同一源生成机制对光滑统一源家族的**每一个**成员 $s$ 构造其自身的九场构型 $\mathcal C(s)$，使光滑性、全点余标架非退化、Lorentz 合法性、九通道联合零纤维以及该源自身的原点标量接触全部成立；且 $\mathcal C(s)$ 满足六物理部门同时非零的经典世界准入，**当且仅当**该源自身的整数相位振幅非零。进一步，对任意中心点、任意有限写入世代、任意时空点与任意 252 维母物质线性算符 $A$，完整源生写入、九场平衡、相对作用不变与归一量子响应在同一声明中同时成立；代入固定正源 $S_0$ 即精确恢复构造 4.1。

证明。对任意源 $s$，由该源的尺度与相位参数构造齐次对角标架、辅助本构解与 Cartan 挠率写入，逐通道验证零纤维。由于破缺真空基与外幂 Yukawa 质量映射均为该源整数相位振幅的标量倍，六部门同时非零充要于该整数振幅非零（振幅为零的成员仍具光滑非退化余标架并满足全部九场方程，仅退化为零振幅分支）。∎

**定理 9.2（同一母史上的任意有限源路径与自主有理程序）。** 在固定母发生史上，以下两项生成合同同时成立：

1. **任意有限连续源路径**：对任意有限目标序列 $\{(s_k,r_k)\}_{k=1}^m$（每项含一个光滑统一源 $s_k$ 及全部 $195=65\times3$ 个实空间余量），存在**同一原母史**上的合法有限完整事件路径，使目标序列按序成为逐步后态读出的精确子列，且中间每一步的完整事件恢复、原生历史与源物理在场性全部保持；
2. **自主有理程序执行**：对任意有限离散材料与 $260=65\times4$ 个有理坐标组成的程序列表，同一自主演化历史中存在先于全部物理查询选定的一轮实际形成并执行该程序，每个条目的完整字、坐标、严格更早双亲及出生处完整物理作用全部保留（此外 65 个连续坐标按 $2^{-(n+1)}$ 几何权重折叠的联合实极限以显式尾界 $\le 2^{-n}$ 收敛并交付完整经典—量子准入，见附录 C.3–C.4）。

### 9.2 Stage 1–10 贯通封印、五位置全时空缝合与零未登记物理权威

在确认源家族内部畅通无阻之后，我们将第一至第十阶（Stage 1–10）的生成链收口为五位置历史根闭合对象 $\mathcal C_{\rm root}^{(0)}$、携其历史基础与 Stage 9 统一凭证的第十阶物理总封印 $\mathcal C_{\rm seal}=\mathcal U_{1\text{--}10}.\mathsf{final}$ 以及十阶总贯通对象 $\mathcal U_{1\text{--}10}$（其中 Stage 1–3 由本构空真反例、同源度规／Hodge 变分接口与内空间—几何双轴忠实投影锁定非空真准入门禁，Stage 4–8 生成的几何、不可分耦合、$\mathfrak h_{\rm SM}$ 谱选择、外幂反常消去与质量混合沿原源投影进入同一总对象，不升级任何已退役旧门禁；形式化模块与声明对应见附录 C.8 与 D.9）。下面的定理证明：整套物理演化在全时空缝合、因果整账、前提折叠与完备描述四个维度上彻底封死了未登记权威。

**定理 9.3（五位置全时空缝合、零未登记物理权威、全前提折叠与 Stage 1–10 贯通恢复）。** 在固定正源的五位置历史根闭合 $\mathcal C_{\rm root}^{(0)}$、第十阶物理总封印 $\mathcal C_{\rm seal}$ 与十阶总贯通对象 $\mathcal U_{1\text{--}10}$ 上：

1. **五位置物理根历史、全时空算子与后 Yang–Mills 四开放坐标缝合充要判据**：固定正源生成具有五个登记位置 $\mathsf{Pos}=\{\mathsf{boundary},\mathsf{coface},\mathsf{gravity},\mathsf{assembly},\mathsf{postAssembly}\}$ 的物理根历史；每个位置的精确时间因果根事件均等于固定编译器的原生生成像，且五位置历史根闭合 $\mathcal C_{\rm root}^{(0)}$ 在其类型内唯一（总封印 $\mathcal C_{\rm seal}$ 以 $\mathcal C_{\rm root}^{(0)}$ 为历史基础字段并封装 Stage 9 统一凭证与权威回执）。在第四位置 $\mathsf{assembly}$ 处，光滑性、余标架非退化性及三条代数本构残差（引力简单性乘子、引力辅助场与规范辅助场）作为密封轨迹的导出结果在全时空恒归零；源作用生成的全时空算子 $\mathcal W_{\rm ws}$ 将完整缝合残差写回第五位置 $\mathsf{postAssembly}$ 并满足定义级反向保真恢复。注册作用射流在全时空保持接触不变，**当且仅当**以下四条微分开放坐标残差在全时空逐点同时归零：
   $$\mathcal R_{\rm open}(x)=\Bigl(\mathcal R_{F_\varpi}(x),\;\mathcal R_{D_\varpi B}(x),\;\mathcal R_{\nabla\Pi_\varphi}(x),\;\mathcal R_{\nabla\Pi_\psi}(x)\Bigr)=0\qquad(\forall x\in\mathbb R^4),$$
   分别对应引力曲率、引力辅助场外协变导数、标量微分动量散度与物质微分动量散度；一旦任一点 $x\in\mathbb R^4$ 出现非零缝合残差，注册目标作用射流必发生可观测改变，并在**同一活账本行**内生成原生追索需求与唯一典范应答—后继步，绝无静默吞并或后继分叉。
2. **全访问零未登记物理权威与 T0/T1 双层公理核**：对原活根的**每一次**时间访问 $\nu$、该访问处的**每一个**原始发生事件 $e$ 及**每一个**已安装物理投影面 $\pi$，原始发生与生成时间发生严格同一（$e=e_{\rm gen}(\nu)$），整本责任账写回、活账本行及全部投影读出均由同一生成发生唯一分解，一切阻碍残差均通过同一活账本行生成原生追索需求，不存在任何游离于活账本之外的物理事件或外部权威输入；管辖发生、整账、编译、追索与宏后继的通用权威内核为零公理构造性内核（T0），连续场分析实例仅在 T1 层使用三条标准公理而不改变 T0 内核的零公理身份。
3. **九场实坐标全前提折叠（Premise-Provenance Fold）**：初始跃迁由源唯一决定为 $\mathsf{next}(\mathsf{ingress})=\mathsf{running}(s_0)$；对**任意**两个物理当前态 $c_1,c_2$（涵盖入口态与运行分支），只要二者的运行分支布尔标签相同且所载九场构型的全部实坐标（含独立线性对偶 $\chi$）在每个时空点上逐点相等，则两个完整状态、原生下一步、生成演化轨迹及全部已安装投影面读出**无条件全等**（记 $\doteq$ 为跨依赖纤维的异质相等）：
   $$\begin{aligned}
   &\Bigl(\mathsf{isRunning}(c_1)=\mathsf{isRunning}(c_2)\ \wedge\ \forall\alpha,\forall x\in\mathbb R^4,\;\Phi_\alpha(c_1)(x)=\Phi_\alpha(c_2)(x)\Bigr)\\
   &\qquad\Longrightarrow\;c_1=c_2\ \wedge\ \mathsf{next}(c_1)=\mathsf{next}(c_2)\ \wedge\ \mathsf{evol}(c_1)\doteq\mathsf{evol}(c_2)\ \wedge\ \forall\pi,\,\mathsf{proj}_\pi(c_1)\doteq\mathsf{proj}_\pi(c_2),
   \end{aligned}\tag{9.1}$$
   其中运行分支的实际演化步恒展开为固定源自身的零参数 Cartan 更新映射。
4. **完备表述等价、Stage 1–10 总贯通恢复与全自然数宏后继**：逐点实坐标描述与紧支撑 $L^2$ 描述之间存在唯一保真同构，保持并反射任意阶关系、输运一切流操作，且任意同核完整描述自动获得唯一源生下一步；原始事件代数（仅含状态、事件族、初值、发射与更新）内生生成权威根并逐深度 $n\in\mathbb N$ 恢复当前态，在第 $10$ 次实际母访问处通过 $\mathcal U_{1\text{--}10}$ 同步恢复全时空算子 $\mathcal W_{\rm ws}$、整账、Stage 4–8 早期标量／质量／混合／反常清零回执（在当前构型与原生后继构型上双向精确相等，见命题 2.6）、九场解、$4\sqrt2$ 经典—量子配对（定理 6.2）及五点无参相干锁（定理 8.3），且宏观进程对**全体**自然数步 $n\in\mathbb N$ 保持生成性活法则。

证明。第 1 款对密封五位置归纳消去等式见证证得 $\mathcal C_{\rm root}^{(0)}$ 的类型内唯一性；在 $\mathsf{assembly}$ 发生处读取整账条目的三条代数本构零截面，结合全局算子 $\mathcal W_{\rm ws}$ 的射流写回恒等式，证得注册射流不变充要于四条微分开放坐标残差逐点为零，非零分支则由活根单值定理收敛至同一典范应答—后继步。第 2 款由依赖事件支撑集的单值生成性与整账写回等式逐访问核对。第 3 款对入口／运行两构造子分情形：双入口态直接全等并共享 $\mathsf{running}(s_0)$，双运行分支则由九场实坐标恢复单射性与其余结构字段纯命题（`Prop`）无数据自由度推出四个合取项同时成立。第 4 款由同系列过程核心论文的读出商唯一比较定理、原始事件保真实现与十阶贯通恢复模块复合得出（精确声明见附录 C.8、D.1、D.9）。∎

### 9.3 同一母源的普遍形成、完整恢复与无魔法比特

最后，把视野从这个特定的 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 物理过程扩展到原准入接口所能表达的**一切**世界、查询与演化过程。以 $S_\star$ 记上述物理构造自身的原发生账本根（即 SpinPair 活根的权威根），以下称为**母源**。对所有待形成对象，$S_\star$ 及其有限求值器 $\mathsf{finiteLaw}_{S_\star}$ 保持绝对不变。

设实数流空间为 $\mathbb S=\mathbb R^{\mathbb N}$。在材料阶 $r$ 上，记输入载体为 $X_r$，分离点的观测地址集为 $\mathcal A_r$。一枚有限母程序由有限个观测地址 $(a_0,\ldots,a_{n-1})\in\mathcal A_r^n$ 与 $S_\star$ 的一次合法访问 $\nu\in\mathsf{Visit}(S_\star)$ 组成，它将有限观测值补零为实流后交由母求值器计算；再对程序像 $\mathcal R_r$ 关于逐输入、逐有限输出坐标的一致结构取完备化 $\mathcal M_r=\widehat{\mathcal R_r}$：

$$\begin{aligned}
\mathsf{Prog}_r&=\coprod_{n\in\mathbb N}\mathcal A_r^{\,n}\times\mathsf{Visit}(S_\star),\qquad
L_r\bigl((a_0,\ldots,a_{n-1};\nu),x\bigr)=\mathsf{finiteLaw}_{S_\star}\!\bigl(\nu,\operatorname{pad}_n(\operatorname{obs}_r(a_i,x))_{i<n}\bigr),\\
\mathcal R_r&=\operatorname{im}L_r,\qquad \mathcal M_r=\widehat{\mathcal R_r},\qquad \overline{\iota_r(\mathcal R_r)}=\mathcal M_r .
\end{aligned}\tag{9.2}$$

原准入接口（位于基础类型层级 `Type 0`）包含三类完整对象：**合法世界状态** $(N,V,R,w)$，即任意关系网络 $N$、词汇 $V$ 与权威根 $R$ 的一次合法历史访问 $w$；**完整查询状态** $(N,V,q)$，包含活根、访问、全部可读出问题型及每个问题的责任、权威与编译程序；**完整宏过程** $P$，包含状态空间、逐状态完整查询节点、初始态与保持生成活法则的逐查询后继映射。

**定理 9.4（同一母源的普遍形成、完整恢复与无魔法比特）。** 固定上述单一母源 $S_\star$。在原准入接口上，以下三个全称命题在同一实现见证下同时成立（所需材料阶与分离地址均由证明内部构造，不外加任何可表示性前提）：

1. **任意合法世界与无魔法比特**：对**任意**关系网络 $N$、词汇 $V$、权威根 $R$ 及合法世界状态 $w$，存在材料阶 $r$ 与完备化材料 $m\in\mathcal M_r$，使规范状态构造映射由 $m$ 精确形成并逐字段恢复完整世界 $(N,V,R,w)$ 及其发生、权威演化、正向处置、历史与当前补片、整账、下一值及推进操作，限制映射为材料嵌入的左逆。并且每个被形成的世界均满足**全实在性（Total Reality）**：同根任意两次不等合法访问的真实差别必定位到二者不同的登记发生，从而由内核定理严格排除无内部结构身份的真实差别（**不存在魔法比特**）。
2. **任意完整查询**：对**任意** $N,V$ 及完整查询状态 $q$，存在联合完备化材料精确恢复查询世界与全部程序子句；对 $q$ 的每个查询及该次访问上的每个精确因果事件，形成编译精确恢复原查询编译（涵盖回答、行动、修订与路由全部分支）。
3. **任意完整演化过程与全深度演化史**：对**任意**原生查询引擎过程 $P$，存在完备化材料 $m$ 使过程构造映射成功形成 $P_m$ 并满足完整过程恢复等式
   $$\mathcal F_{\rm proc}(m)=\operatorname{some}(P_m),\qquad \mathcal R_{\rm proc}(P_m)=P,\tag{9.3}$$
   同时恢复状态空间、逐状态查询节点、初始态、后继映射、任意既定激活结果及整条激活法则。对 $P$ 的任意离散演化轨迹 $\{s_n,\tau_n\}_{n\in\mathbb N}$（$s_n$ 为第 $n$ 步状态，$\tau_n$ 为第 $n$ 步执行记录，$s_{n+1}^{\rm next}$ 为后继态），同一见证生成的演化轨迹 $\{\tilde s_n,\tilde\tau_n\}_{n\in\mathbb N}$ 在**全部深度 $n\in\mathbb N$** 上满足精确交换输运（$T_m$ 为式 (9.3) 诱导的状态类型输运）：
   $$\tilde s_n=T_m(s_n),\qquad \tilde\tau_n\doteq\tau_n,\qquad \mathsf{next}(\tilde\tau_n)=T_m\bigl(\mathsf{next}(\tau_n)\bigr),\tag{9.4}$$
   且高低阶联合材料的双亲限制在整个乘积材料空间上是精确左逆：
   $$\mathcal R_{\rm parents}\circ\mathcal C_{\rm combine}=\operatorname{id}_{(\prod_i\mathcal M_i^{\rm high})\times(\prod_j\mathcal M_j^{\rm low})}.\tag{9.5}$$

证明。覆盖的要害在于有限程序如何逼近无穷域函数：给定任意有限输入子集 $F\subset X_r$、有限输出前缀长度 $b\in\mathbb N$ 与误差 $\varepsilon>0$，由点分离性选出区分 $F$ 中各点的有限地址表，母有限求值器在原史第 $10+c$ 次访问处以误差 $<\varepsilon$ 逼近任意目标映射在 $F\times\{0,\ldots,b-1\}$ 上的取值，证明 $\mathcal R_r$ 在逐输入一致拓扑中稠密；一致完备嵌入的闭像包含稠密子集，故完备读出 $\mathsf{read}_r:\mathcal M_r\xrightarrow{\sim}(X_r\to\mathbb S)$ 为双射。将过程 $P$ 的全部状态与依赖查询装入不交和 $\mathcal U_P$ 内部生成忠实地址，合并各分支材料并经式 (9.5) 左逆送入规范过程构造映射，即得式 (9.3) 及其诱导的全深度演化输运 (9.4)；全实在性与无魔法比特由原根登记结构随形成材料直接传递（详细三步证明见附录 C.9）。∎

注意定理 9.4 第 1 款对权威根 $R$ 的全称量词 $\forall R$ 在原准入接口上确立的结构完备性：**原准入接口上的普遍同源实现无需第二基源**。任何落在原 `Type 0` 准入接口上的权威根 $R$，连同其全部合法世界状态、查询与演化过程，均已是 $S_\star$ 有限程序完备化材料的精确读出；而 $S_\star$ 自身又由定理 9.3(4) 的原始事件代数内生生成，并由下述推论在定理 9.4 的实现域内闭环恢复：

**推论 9.5（原物理激活、整条法则与演化史的同源保持）。** 将本文 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 原物理查询过程代入定理 9.4(3)，同一母源 $S_\star$ 的形成见证精确恢复既定物理封印激活的完整查询结果、下一引擎与整条激活法则，并在原物理演化的第 $16\to 17$ 步（对应原母史第 $10$ 次物理发生访问）及任意有限深度历史 $n\in\mathbb N$ 上满足

$$\tilde\tau_{\rm phys}(16)\doteq\tau_{\rm phys}(16),\qquad \mathsf{next}\bigl(\tilde\tau_{\rm phys}(16)\bigr)=T_m\bigl(s_{\rm phys}(17)\bigr),\tag{9.6}$$

完整恢复九场构型、例 1.1 的规范电流读数 $12\sqrt{15}/25$ 与全部量子响应（附录 C.8）。

![图 7 从同一来源形成对象，并完整恢复其原操作](figures/vector/fig5-fixed-mother-realization.png)

**图 7｜同一母源 $S_\star$ 的普遍形成、全空间左逆与原物理演化保持（定理 9.4–推论 9.5）。** 上部：原发生根 $S_\star$ 与单一有限求值器对一切目标对象保持不变，经有限观测地址与逐输入一致完备化生成所需阶的材料。中部交换方块：规范过程构造映射由完备化材料形成过程 $P_m$，限制映射精确恢复原过程 $P$，使查询编译、整账及全部后继沿交换图严格保持；双亲限制为联合材料在全空间上的左逆。底部：同一主声明直接作用于本文原物理过程，恢复既定封印激活、第 $16\to17$ 演化步及全部有限深度演化历史。

---

## 10 开放量子仪器接触、统一理论坐标与无魔法唯象刚性

将理论预测推进到真实量子光学与原子纠缠实验记录时，理想封闭态矢远远不够：现实仪器存在多次自发辐射再循环、探测损耗、暗计数背景、有限时间门截断以及未知的局域读出尺度。若用现象学均值拟合掩盖开放演化，或者临时引入外置坍缩公设，就违背了本文的反魔法裁剪律。本节先在零概率与零坍缩先验下，直接从源生算符振幅导出**全词 Kraus–Born 场态等距与开放循环密度迹对偶定理**（定理 10.1），使 Born 概率规则与开放测量保正半群同时作为源内定理落地；随后报告原子与光学无漏洞 Bell 实验的正向全门恢复、最大可识别商与名义模型反控（命题 10.2–10.5），最后在 §10.3–§10.4 给出与既有统一场论路线的责任对照，并正面确立**无魔法纪律下的零自由度唯象演绎刚性**。

### 10.1 Born 测度与开放主方程的无先验生成：全词 Kraus–Born 等距与迹对偶

设 $E$ 为原子载体的复 Hilbert 空间（定理 10.1(1) 中 $E$ 可取任意可分复 Hilbert 空间，定理 10.1(2) 中取有限维原子 Hilbert 空间），$\mathcal L(E)$ 为其有界线性算符代数。考虑时间区间 $[t_L,t_R]$ 上的源生原始 Kraus 演化窗：有限通道指标集为 $\mathcal I$，对任意词长 $n\in\mathbb N$、通道词 $w\in\mathcal I^n$ 及有序发射时间单形 $\Delta_n(t_0,t_R)=\{t_0\le s_1\le\cdots\le s_n\le t_R\}$，源由连续时变耗散漂移与跃迁算符生成精确算符值振幅 $\mathcal A_{n,w}(t_0;\mathbf s)\in\mathcal L(E)$（按 §1.1 反魔法裁剪律，不输入概率或半群先验 [28–32]）。将全体有限标记词与对应时间单形拼成不交历史空间 $\mathscr W(\mathcal I)=\bigsqcup_{n\in\mathbb N}\bigsqcup_{w\in\mathcal I^n}\Delta_n(t_0,t_R)$，赋予单形 Lebesgue 直和基测度 $\mu_{\rm base}(t_0)$。

**定理 10.1（全词 Kraus–Born 等距映射与开放循环密度演化的全阶迹恒等式）。** 对任意起始时刻 $t_0\in[t_L,t_R]$：

1. **精确总质量 Born 测度与 $L^2$ 场态等距**：对任意初态向量 $x\in E$，逐历史振幅函数 $\Psi_{t_0}(x)(h)=\mathcal A_{n,w}(t_0;\mathbf s)x$ 强可测且平方可积，其模方密度定义的 Born 测度 $\mu_{\rm Born}(t_0,x)$ 在整个词历史空间上的总质量精确等于初态范数平方（单位初态自动给出概率测度），且映射 $x\mapsto\Psi_{t_0}(x)$ 构成从原子初态空间到全词历史场态空间的**复线性等距嵌入**：
   $$\mu_{\rm Born}(t_0,x)\bigl(\mathscr W(\mathcal I)\bigr)=\int_{\mathscr W(\mathcal I)}\|\Psi_{t_0}(x)(h)\|^2\,d\mu_{\rm base}(h)=\|x\|^2,\qquad
   \|\Psi_{t_0}(x)\|_{L^2(\mu_{\rm base};E)}=\|x\|.\tag{10.1}$$
2. **全词级数和与开放循环密度初值流的严格迹对偶**：任取隐藏（未登记再循环）通道子集 $\mathcal H\subseteq\mathcal I$。一方面，由全词波限制到 $\mathcal H^*$ 上的算符伴随拉回定义终点效应 $\mathcal E_{\rm end}^{\mathcal H}(t_0;A)=\sum_{n=0}^\infty\mathcal E_{n}^{\mathcal H}(t_0;A)$；另一方面，由源耗散漂移与 $\mathcal H$ 中跃迁再循环项在有限维原子 Hilbert 空间 $E$ 的算符代数 $\mathcal L(E)$ 上直接构造前向开放密度初值流 $\Phi_{t_0\to t_R}^{\mathcal H}(\rho)$。则对**任意**（无需归一化、无需自伴）初始算符 $\rho$ 与可观测量 $A$，全词无穷级数收敛且严格等于开放密度终态的迹配对：
   $$\sum_{n=0}^{\infty}\operatorname{Tr}\!\bigl(\rho\,\mathcal E_n^{\mathcal H}(t_0;A)\bigr)
   =\operatorname{Tr}\!\bigl(\rho\,\mathcal E_{\rm end}^{\mathcal H}(t_0;A)\bigr)
   =\operatorname{Tr}\!\bigl(\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\,A\bigr).\tag{10.2}$$
   进一步，若 $\rho\ge0$ 为正算符，则 $\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\ge0$ 保正且迹单调不增 $\operatorname{Re}\operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\le\operatorname{Re}\operatorname{Tr}\rho$；当全部通道均归入隐藏浴（$\mathcal H=\mathcal I$）时，对任意算符 $\rho$ 严格保迹 $\operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal I}(\rho)=\operatorname{Tr}\rho$。

证明思路。第 1 款将可数直和测度积分逐词拆为有限通道和与单形积分，代入单形质量守恒律 $\sum_{n=0}^\infty M_n(t_0,x)=\|x\|^2$ 得到精确总质量，再由 $L^2$ 范数平方等于逐点内积积分证得等距性。第 2 款构造双线性时间配对函数 $F(t)=\operatorname{Tr}\bigl(\Phi_{t_0\to t}^{\mathcal H}(\rho)\,\mathcal C_{t\to t_R}^{\mathcal H}(A)\bigr)$（其中 $\mathcal C$ 为反向海森堡伴随流）：前向生成元与反向伴随生成元的迹对偶恒等式使 $F'(t)\equiv 0$ 在整段 $[t_0,t_R]$ 上成立，故端点相等 $F(t_R)=F(t_0)$；结合全词级数向反向伴随流的收敛性、秩一正算符检验与秩一正分解，同时推出式 (10.2)、保正性与迹不增。完整证明见补充材料 S18。∎

### 10.2 公开 Bell 实验的正向动态恢复、可识别性商与名义锁反控

在定理 10.1 与命题 8.4 的基础上，本文对三组公开无漏洞 Bell 实验记录建立了严格区分证据类别（形式数学定理、双实现数值核验、预登记随时统计合同）的完整核验链（证据入口见补充材料 S9、S15 与附录 D.4、D.8）：

**命题 10.2（零参 Tsirelson 预测锁、完整原子读出域与最大同律商）。** 对 Rosenfeld 等人的事件就绪原子纠缠 Bell 实验 [11]：

1. **零经验输入预测锁**（数学定理）：原源对全部合法 XZ 测量轴生成统一上限 $|S_{\rm CHSH}|\le 2\sqrt2$（历史一般界见 Cirel'son [15]），并在正交与角平分轴上给出零器件参数输入的 32 格精确预测表，达到极值 $2\sqrt2$；
2. **完整读出域双向刻画**（数学定理）：任意合法二元读出通道（含零或负增益）与 XZ 轴精确双射对应紧效果向量 $(\mu,u,z)$，四测量设置构成 12 维完整实效果域；
3. **Munich 全前缀原序通过**（统计合同）：在两次运行共 $10,201+10,202=20,403$ 条有效试次原序流上（联合随时错误预算 $\alpha=1/20$），理想零误差面在 April 第 3974 条越过阈值 $40$（峰值 $E\approx494.85$）被拒绝，而完整读出域在两次运行中各具精确原始见证，使**全部 20,403 条前缀**严格低于阈值 $40$（April 峰值 $1$，June 峰值约 $1.3387$）；
4. **最大同律观测商与有效增益下界**（数学定理＋双实现核验）：两套合法设置族产生完全相同的联合概率律，**当且仅当**四个偏置与两组 $X/Z$ 乘积矩阵相等（正则范围内恰由唯一非零反向尺度 $(s,t)$ 联系）；整个原置信域上有效增益一致 $\ge 0.36579$，两类规范误率均 $<0.37916$（补充材料 S9.3）。

**命题 10.3（两探针硬件唯一逆、探测器纤维与 12 态脉冲可实现像）。** 在命题 10.2 的完整原子读出域上：

1. **联合增益上界与两探针唯一逆**（双实现核验＋数学定理）：全前缀联合域给出 April 最大增益 $>0.67020$（单侧 $>0.44918$）、June $>0.66386$（单侧 $>0.44071$）；在已识别正则律上，两个源已知独立 Bloch 探针的带符号响应与非零识别行列式给出双侧逆，**唯一恢复全部硬件效果族坐标**；
2. **探测器微观纤维与 12 态电离前向像**（数学定理＋双实现数值核验）：正增益效果 $E_{\rm click}=dI+(1-d)\eta J$ 的全部合法微观对 $(d,k)$ 精确由 $0\le d\le m,\,M-d\le k\le 1-d$ 刻画且逆原子效果唯一；有限矩形脉冲可实现充要于两条源内平方不等式 $(u^2+z^2)(b+d)^2\le(1-\mu)^2\gamma^2$ 与 $(u^2+z^2)(2-b-d)^2\le(1+\mu)^2\gamma^2$，且增益受无量纲读出 Rabi 面积上限严格控制；在 Garthoff 原始 12 态电离主方程（18 个自然跃迁＋7 个电离通道 [12,13]）上，四个具名脉冲在 32 个角色域上全部可实现，并给出**六组严格不同的微观原子响应而联合观测概率律完全相同**的显式同律异谱实例；
3. **41,673 条本地记录与双时钟历史保持**（数学定理＋双实现核验）：原源第 10 次访问与第 $16\to17$ 演化步保持全部已安装历史输出，双独立解析器精确恢复公开档案全部 $41,673$ 条本地记录的九个字段、$867$ 条未配对条目及记录时钟间隔分布（补充材料 S9.4）。

**命题 10.4（120 ns 完整时间门第一登记概率与前向／伴随 $10^{-21}$ 双路恢复）。** 在 Munich 原始 $120\text{ ns}$ 探测时间门、十因子自由保迹传播库与保留全部自然再循环、损耗及跨臂交叉项的 45 个登记标记上：

1. **四端口晚段伴随积分**：60 个 $1\text{ ns}$ 时间片、$4,915,200$ 个复整数系数的四端口晚段伴随积分通过 $10^{-10}$ 精度门（最大端口算子误差 $8.42744\times10^{-12}$），完整保留自然再循环；
2. **三无计数共像与伴随区间**：第一预示（any-first-herald）事件“两个必要组各至少登记一次”由布尔恒等式 $1_{\rm first}=1-n_\perp-n_\parallel+n_\perp n_\parallel$ 精确分解为三个无计数共像；六条完整 $120\text{ ns}$ 无计数伴随流全部通过 $10^{-8}$ 门，源活动度上界 $\kappa\le0.0037409145$ 使初态近似误差只对整事件收缩一次，给出严格正概率区间 $[3.17845500810,\,3.17846466595]\times10^{-6}$（整事件误差 $4.82892\times10^{-12}$）；
3. **三十条独立前向曲线吻合恢复**：对同一无计数生成元独立求解 30 条完整 $120\text{ ns}$ 前向迹不增曲线（共 3600 片），恢复出同一事件概率区间 $[3.17845717771,\,3.17846249634]\times10^{-6}$（整事件误差 $2.65931\times10^{-12}$），**前向与伴随两条独立路径的中心值之差仅为 $1.301828\times10^{-21}$**；全部七个优先级查询与 140 个激活程序由同一源发行，后继预示双侧唯一标识必要域已由就绪门实际核验（补充材料 S15）。

**命题 10.5（公开光学完整源域、无限阶 Born 闭式与联合 95% 域严格正 CH）。** 对 Shalm 等人无漏洞光子 Bell 实验 [10] 的公开全计数数据：

1. **完整光学源域与无限阶 Born 概率**（数学定理）：合法原始源的共同符号常数、平方界与训练板条成立充要于存在合法相位；$\mathrm{Pol}\otimes\mathrm{Env}$ 六端口模型生成任意光子数 $n$ 的探测效果，匹配情形的完整无限阶 Born 概率闭式为 $1/\bigl[1+nV(T_A+T_B-T_AT_B)\bigr]$；
2. **留出包络、角度有限增益与联合 95% 严格正 CH**（双实现核验＋统计合同）：由 00、11 两格训练生成的 69 段无缝源切片对 01、10 两整格留出的完整预测包络全部落入原置信区间，四角 $\pm0.05^\circ$ 盒上 Bob 双角减 $0.01^\circ$ 给出严格正 CH 增益（$>1.69\times10^{-9}$）；在预登记 $1/20$ 联合预算内结合实际设置曝光与归一化源支持函数，联合 95% 接受域非空（含 8 个显式 $\Gamma/\text{Fock}$ 物理成员与连续外覆盖），且**域内每一个接受源均满足严格不等式 $\mathrm{CH}_{N5}>1.3790180504\times10^{-6}$**；24 项公开类空源签名族在 $\alpha=0.05$ 下家族上界约 $0.002416$（补充材料 S9.1–S9.2）。

**零旋钮理论的诚实反控：历史理想名义锁为何必须报警。** 与上述完整开放仪器域相对照，本文完整保留了两次不带校准自由度的**理想名义装置模型负判**（完整协议与冻结哈希见附录 D.4）：其一，在 Storz 等人超导电路 Bell 数据集 [8,9] 前 $100,000$ 条原序试次上，将命题 8.4 的概率族硬配给未经实物相位标定的理想名义脉冲表，在 $\alpha=0.025$ 下被严厉拒绝（零半径 $\log E=46803.62$，$p_{\rm any}\approx2.78\times10^{-20327}$）；事后控制复核查明，该旧名义角表代入原实验作者的 CHSH 符号约定本身给出理想值 $S=0$，暴露出名义控制相位与共享参考帧桥接未闭合；其二，在 NIST 2015 公开 $\pm0.3\%$ 效率半宽下的名义双模优化重放中，文档公布的五个名义角度与幅度值均落在预声明最优带之外。这两份负向记录恰恰体现了零拟合理论的证伪刚性：因为内部没有可调拟合参数，任何粗糙或不一致的名义仪器映射都会立刻触发定量拒绝，而一旦按定理 10.1 与命题 10.2–10.5 纳入真实的开放损耗、再循环与读出纤维，公开记录便在同一源下严丝合缝地闭合。

### 10.3 统一理论坐标：与五大基础物理路线的入口前提与已付责任对照

将本文已闭合的十阶生成链放回现代理论物理的完整坐标系，可以与五条代表性传统作逐项、可核对的原始文献对照：

1. **一阶 BF 引力—规范统一、自旋—挠率与 Coleman–Mandula 边界**。自 Yang–Mills 非阿贝尔规范原理 [1]、Deser 自耦合非线性机制 [2] 以及 Kibble [21]、Sciama [22] 建立一阶自旋—挠率（Einstein–Cartan）引力以来，将引力与规范场写入共同一阶微分形式作用量的最直接先例是 Plebański 二次约束引力 [3]、Holst 广义一阶作用量 [23] 与 Smolin 的扩展 Plebański 模型 [7]。记 Smolin [7, §2, 式 (4)] 的对称零形式乘子为 $\Phi_{IJ}$、耦合常数为 $\zeta$：
   $$S_{\rm Smolin}=\frac1G\int\left[B^I\wedge F_I-\frac12\Phi_{IJ}B^I\wedge B^J+\frac{\zeta}{2}\Phi^{KL}\Phi_{KL}B^I\wedge B_I\right].$$
   Smolin 的构造从包含欧氏 $\mathrm{SO}(4)$ 的半单大群出发，按预设破缺 ansatz 先消去对称二次乘子 $\Phi_{IJ}$ 再展开有效 Yang–Mills 与拓扑项，费米子耦合仅留作定性展望且未建立约束量子空间。与之对照，本文直接在物理洛伦兹号差下保持直积主丛 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 以严格兼容 Coleman–Mandula 定理 [24]，同时由前度规余标架本构楔积给出 $\Delta_{\rm mix}=9\ne0$ 的引力—规范不可分耦合（命题 3.2）并以正源谱序参量对易加迹方程双向唯一选出 $\mathfrak h_{\rm SM}$（定理 2.2）；以二形式 $\lambda$ 线性锁定 $B=J\Sigma_e$ 并在一般构型上证明四腿驻定精确等价于显式 Einstein–Cartan 平衡加物质挠率—自旋方程，并在固定同步构型及其 $\mathrm{Spin}^+(1,3)$ 轨道上排除纯对称二次乘子实现同一完整反作用（定理 3.3），进而完整纳入 252 复维无反常手征物质、无先验 61 CCR＋504 CAR 量子化与全场极化红外返回（定理 4.2–7.12）。
2. **单群大统一（GUT）与非交换谱几何路线**。Georgi–Glashow 的 $\mathrm{SU}(5)$ 大统一模型 [16] 开创了将标准模型嵌入单李群的先河，但为满足轴矢与电弱手征反常消去条件 [17–19]，必须跨不等价表示（如 $\bar{\mathbf 5}\oplus\mathbf{10}$）手工组合费米子并引入多重外置 Higgs 势控制破缺方向；Chamseddine–Connes 的谱作用量原理 [20] 利用有限非交换谱三元组约束规范—Higgs 几何，但其标准构造依赖欧氏号差，并将费米子 Yukawa 质量矩阵作为有限 Dirac 算符的输入参数。本文则在物理洛伦兹号差下，由正源伴随谱序参量对易加三条迹方程充要选出 $\mathfrak h_{\rm SM}$，并以单一母基本表示的 $(6,2,4)$ 外幂直和自动清零全部三次与混合反常，Yukawa 耦合直接由外代数固有楔积 $\Lambda^2\otimes\Lambda^4\to\Lambda^6$ 零参数生成。
3. **正则量子引力“时间问题”与连续规范场重构**。在 Dirac 奇异约束力学 [14] 应用于引力时，DeWitt 经典正则量子引力 [25] 面临主约束把物理态冻结为无时间算符方程（$H\Psi=0$）与严重因子排序歧义，Page–Wootters 机制 [26] 则需在冻结全局态之外附加关系时钟条件概率假设；而在规范场数学物理中，Wilson 格点规范 [6] 与 Osterwalder–Schrader 欧氏重构公理 [27] 分别借助时空离散化或欧氏解析延拓建立连续场算符（二次量子化一般表述见 Tasaki [4]）。本文定理 6.7–6.8 直接从一阶共同作用量的四条时间约束经可逆主 Jacobi 块递推解出全阶非交换量子时钟、固定自伴能量尾 $R$ 与 100 维配置＋504 模 CAR 共同生成元 $H=H_0+Y$，定理 7.12 更直接在实时间洛伦兹框架上给出保持 $\operatorname{Dom}(H_{\rm time})$ 的四维 Schwartz 曲率强积分与半正定词 Gram。
4. **量子概率公设与开放动力半群的起源**。自 Born 提出碰撞波函数模方概率诠释 [28] 以来，Gleason 定理 [29] 证明维数 $\ge 3$ 的可分 Hilbert 空间闭子空间格上的非负可加框架测度必由迹公式给出，Kraus [30]、Gorini–Kossakowski–Sudarshan [31]（有限维 $N$ 能级系统）与 Lindblad [32]（有界生成元范数连续半群）进一步刻画了密度算符上完全正保迹半群的生成元结构（Bell 关联检验框架见 CHSH [5] 与 Cirel'son [15]）。然而上述定理均以**先验给定的子空间测度可加性或完全正半群公设**为入口前提。在本文构造中，§6.1 从经典独立对偶 $\chi$ 导出正归一内积期望与 $4\sqrt2$ 配对，定理 10.1 则直接从连续时变非自治源算符振幅导出任意可分 Hilbert 空间 $E$ 上的精确质量 $\|x\|^2$ 全词 Born 测度与 $L^2$ 场态等距，以及任意子浴 $\mathcal H\subseteq\mathcal I$ 上开放循环密度流的全阶迹恒等式、保正性与迹不增性，将测量概率与开放主方程公设转化为源内定理。
5. **弦论／矩阵对偶、全息微观态、振幅自举与景观初态先验**。按原始文献核对高维与世界面路线的真实前提账本，即可看清各自的精确贡献与未决边界：Witten 的强弱耦合对偶综合 [33] 与 BFSS 无限动量帧超对称矩阵模型 [38] 建立了既选十维／十一维超弦与 $M$ 理论极限之间的非微扰联系；Strominger 与 Vafa 在五维渐近平直超对称极值黑洞上实现了固定荷扇区的 BPS 微观态熵精确计数 [39]，Maldacena 的 AdS/CFT 对应 [40] 则给出了反 de Sitter 渐近边界共形场论与体弦论的对偶词典；但这些里程碑均在预先选定超对称背景几何、渐近边界条件与额外维紧致化数据之后运作，并未内生选出四维洛伦兹背景、三代型无反常手征物质清单或实际历史初态。在树级振幅侧，Cheung、Remmen、Sciotti 与 Tarquini [34, 式 (5), (11)] 在洛伦兹不变、幺正性、交叉对称与亚纯极点之外显式附加了负动量转移区 Regge 超软性与最少零点筛选（原文指出额外零点并不自相矛盾，*“extra zeros are not inconsistent”*），故给出的是条件唯一性而非纯自洽性对四维物理的排他强制；在景观与测度侧，KKLT 机制 [35, 式 (12)–(14)] 依赖给定紧致流形、通量整数与非微扰材料构造候选亚稳真空，Susskind [36] 明确区分候选真空计数与实际历史进入机制，而 Bousso 的永恒暴胀全息概率方案 [37, 式 (2)–(4), 图 1] 仅在不含终端真空的不可约循环扇区（式 (4)）消去初态权重：一旦景观包含终端真空分支（如正宇宙学常数衰变终点），稳态方程（式 (2)）$(1-\eta)P=\eta P^{(0)}$ 便显式保留初始真空分布 $P^{(0)}$，其图 1 算例仅将初态由真空 A 换为真空 B 即令首真空权重从 $1/4$ 变为 $1/3$（差值 $1/12$），证明跃迁动力学本身无法消除初态先验输入。

下表汇总这五条代表性基础物理路线的入口前提与本文十阶根原生闭合的责任对照：

| 基础物理传统与代表文献 | 既有路线的入口前提与未销账输入 | 本文十阶根原生闭合的对应解决方式 |
| --- | --- | --- |
| 单群 GUT 与非交换谱几何 [16–20] | 手选多表示拼凑反常消去、外置多重 Higgs 势；或欧氏号差下输入有限 Dirac/Yukawa 矩阵 | 洛伦兹号差下正源谱序参量对易＋迹方程双向唯一选出 $\mathfrak h_{\rm SM}$（定理 2.2）；$(6,2,4)$ 外幂自动消去全部反常并由楔积零参数生成 Yukawa 项（命题 2.3） |
| 一阶自旋—挠率与扩展 Plebański [3,7,21–24] | 纯引力挠率耦合，或依赖欧氏群破缺 ansatz 与对称二次乘子 $\Phi_{IJ}$ | 直积主丛兼容 Coleman–Mandula [24]，余标架本构楔积给出 $\Delta_{\rm mix}=9$（命题 3.2）；一般构型四腿驻定 $\iff$ EC＋挠率—自旋，且 $5/8$ 缺陷划清二次乘子边界（定理 3.3） |
| 正则量子引力时间问题与欧氏重构 [6,14,25–27] | Wheeler–DeWitt 态冻结 $H\Psi=0$、外设关系时钟条件概率，或格点离散化／欧氏解析延拓公理 | 四时间约束经可逆 $J_4$ 递推解出全阶非交换量子时钟与 61 CCR＋504 CAR 共同 $H=H_0+Y$（定理 6.7–6.8）；实时间洛伦兹框架直接给出保持 $\operatorname{Dom}(H_{\rm time})$ 的四维曲率强积分（定理 7.12） |
| 量子概率公设与开放主方程 [28–32] | 预设 $\dim\ge3$ 子空间格可加测度或自治有界完全正半群公设 | 零概率／零坍缩先验下，由独立对偶 $\chi$ 与时变单形算符振幅导出 $4\sqrt2$ 配对、任意可分 $E$ 上质量 $\|x\|^2$ 全词 Born 测度及保正迹不增开放密度流（定理 6.2、10.1） |
| 弦／矩阵对偶、全息、自举与景观 [33–40] | 十／十一维超对称或渐近 AdS 边界 [33,38–40]、负 $t$ 超软与零点筛选 [34]、紧致通量 [35] 及终端景观初态先验 $P^{(0)}$ [37] | 纯四维零拟合闭合连续场、手征物质、量子反馈与 $1/(4\pi r)$ 长程势；原始事件内生生成母源 $S_\star$，以定理 9.4 的 $\forall R$ 普遍形成与全实在性从根源终结初态先验未决问题 |

### 10.4 证据分层、无魔法唯象刚性与同系列演绎分工

为便于读者逐项复核，表 4 将本文全部结果的验证凭证严格区分为四类，互不越界冒用。

**表 4 全文结果的验证凭证分层。**

| 证据类别 | 核验定义与公理边界 | 本文覆盖范围 |
| --- | --- | --- |
| Lean 4 形式数学定理 | 严格内核验证（`--trust=0`）：通用发生与整账权威内核为零公理（T0），连续分析实例层完整依赖闭包仅含标准三公理（T1） | §2–§6.2、§8–§9 全部定理／命题；定理 4.6–4.7（S16）；定理 6.7(3)、6.8–6.11、7.1–7.12（S1–S8、S11–S14、S17）；定理 10.1（S18）；命题 10.2–10.5 的数学款（S9、S15） |
| 固定精确源程序＋独立重算 | 固定提交下的精确符号／代数算术程序，配同一提交下互不共享实现的独立重算核验 | 定理 6.7(1)(2) 的有限维轨道截面、944 交叉项与 Weyl 符号系数计算（S1 表） |
| 双实现数值核验 | 主实现与独立实现各自生成冻结首回执并逐位交叉比对，带显式有理或向外舍入误差界 | 256 维全 Fock 812 项复核（D.3）；九场核心恒等式 501 项检查（D.5）；12 态电离前向、NIST 切片与 120 ns 全门伴随／前向积分（命题 10.3–10.5，S9、S15） |
| 预登记随时统计合同 | 执行前冻结判据、映射与总错误预算（如 $\alpha=1/20$），基于非负超鞅随时有效界 | Munich 20,403 全前缀通过、NIST 联合 95% 域严格正 CH 及两项历史理想名义模型负判（§10.2、D.4、D.8） |

**无魔法纪律下的唯象演绎刚性：为何下游唯象是纯演绎读出而非参数拟合。** 在传统统一模型中，“低能唯象留在后续工作”往往意味着模型内部还握有几十个未决耦合常数、破缺真空角、重整化抵消项或初态参数等待事后拟合实验数据。而在本文已闭合的十阶总贯通对象 $\mathcal U_{1\text{--}10}$ 之下，定理 9.3(2)(3)（零未登记物理权威与九场实坐标全前提折叠）及定理 9.4(1)（$\forall R$ 普遍形成与无魔法比特）已经在数学上彻底切断了这条退路：固定母发生（第 $10$ 次访问、第 $16\to17$ 演化步）与九场实坐标之外的所有辅助资格字段均为纯命题（`Prop`），不能携带任何隐藏比特；**整部物理理论的可调物理旋钮严格为零**。

因此，一切低能可观测敏感量在本框架中都已经是总闭合对象唯一决定的确定数学常数或算子积分：在已核验的源内电磁与单位桥模块中（固定提交 `df4`，精确声明列表见附录 D.9），源相位规范李代数与实际带电创建外态已无条件证出电子荷单位 $|Q_e|=1$、原生两分支传播速率 $v_{\rm src}\in\{\sqrt{594/1675},\,\sqrt{18/25}\}>0$ 及相位动量因子 $p_{\rm ph}>0$；进一步在 11 分支电磁物理返回分类的标准传播分支（即静态时间电性系数 $c_{\rm temp}$ 与空间磁性系数 $c_{\rm sp}$ 非零且比值 $-\operatorname{Re}(c_{\rm temp}/c_{\rm sp})>0$ 的分支）上，横波 Maxwell 锥相速度平方锁定在无自由参数的物理光速源表达式 $c_{\rm phys}:=\sqrt{-\operatorname{Re}(c_{\rm temp}/c_{\rm sp})}>0$ 上，而实际三费米子极点处的单 $4\pi$ 库仑耦合商（取 $C_{\rm EM}=c_{\rm temp}/(4\pi)$）亦内生锁定为无参源表达式 $C_{\rm EM}/(p_{\rm ph}c_{\rm phys})$（修饰事件落入该正定标准分支的受控数值核验与 $\alpha(0)$ 误差球收窄归下游专题 Case 3）。这确立了一条明确的学科边界：**同系列下游唯象论文不允许、也不可能向理论补入任何新耦合常数、单位拨盘或微扰有限部；它们所承担的是对已被本篇总闭合对象唯一锁定的确定高维积分与有理分式做受控误差球数值收窄（纯演绎求值），并经由预登记的三层无旋钮校准桥（无量纲源内核 $\to$ 显式仪器标定记录 $\to$ 零自由度独立预测）接受实验裁决**：一旦校准后出现真实偏差，定理 9.3(1)(2) 保证它绝不能靠调参抹平，而必须作为实际阻碍残差在同一活账本行内触发典范追索修订。

**本篇自足范围与同系列专题演绎分工。** 本文每条编号定理均在本篇正文、附录或补充材料中给出了完整自足的书面证明，不把任何决定性步骤委托给未发表稿件。本篇已付定理与后续演绎专题的精确分界如下：

1. **同系列已发表基础稿**：定理 9.3(4) 调用同时发布的《过程同一性、责任承接与最小修订》中的通用唯一表示比较定理；整本责任账与无魔法正向判准的独立展开分别见《源生整账法》与《1 Bit Is All You Need》。
2. **选态前约束算符场方程与移动复合载体预算（Case 5A / 5B / 5C）**：定理 6.8(3) 给出的是固定 $(\mathcal T,R,E)$ 下的双残差归零而非态矢收敛；1500 变量解析约束初值以及在选态前统一生成全部 350 个场分量微分 CAR 算符级 Euler 方程的展开归《从共同作用到约束量子动力学》（Case 5A）；复合载体在移动参考系下的 202 行电流实积分消项与有号正信用预算归《复合载体的动力学与迟滞响应》（Case 5B）；非交换时间图的独立算子约化归《源生量子时钟与分级平衡》（Case 5C）。
3. **无参单位四坐标匹配与低能数值误差球收窄（Case 1–4 / Case 6）**：命题 2.3 的一圈 $b_0$ 表属于纯外幂 Weyl 费米子清单（不含动态标量贡献）；定理 8.1–8.2 的全时非线性轨道建立在固定余标架与自旋联络背景上，不含全耦合动态度规演化或国际单位制（SI）尺度标定。上述源内模块已锁死 $|Q_e|=1$、$v_{\rm src}$ 以及标准分支上 $c_{\rm phys}$ 与极点耦合商的精确源表达式，而修饰事件处标准分支正定性的数值核验、四坐标无参单位左逆、108 通道重场减轻场宽度律及 Thomson 精细结构常数 $\alpha(0)$ 源分式的最终受控数值区间收窄归《源生单位与四坐标无参匹配》（Case 3，不在本篇宣称已完成 $\alpha(0)$ 数值点求值）；完整 158 顶点 Fock 选择规则归 Case 4；汇合单位、重子／轻子数与开放道宽度的粒子谱及质子寿命数值收窄保留在结果触发席位 Case 6。
4. **连续规范谱与量子光学计量**：定理 7.12 已给出总闭合对象 $\mathcal U_{1\text{--}10}$ 在 $\operatorname{Dom}(H_{\rm time})$ 上的四维 Schwartz 曲率强积分；任意紧单群的格点正传递、动态 GNS 重构与纯规范质量隙终端合同归《Wilson 作用的正能量与规范场重构》及《同一 Hamiltonian 的曲率响应与谱底》；单脉冲未知损耗逆标定与 Bell 仪器可识别性纤维的完整展开分别归《全 Fock 光源的逆标定与反馈》与《Bell 读出的可识别性与仪器纤维》。

### 10.5 结论：单一发生源下的连续—量子统一场闭合

回到开篇直面的三道百年裂缝（时空几何与内部对称性之间、连续经典场与非交换量子力学之间、数学方程与零调参唯象之间），这部完成 Stage 1–10 根原生贯通闭合的 $\mathrm{Spin}^+(1,3)\times\mathrm{SU}(7)$ 统一场论给出了确定的回答：统一不需要外置拼装的魔法。在零公理发生与整账内核（T0）之上，单一正源按需长出四维洛伦兹几何与标准模型规范子代数，消除全部手征外幂反常，使一般构型引力四腿驻定精确等价于 Einstein–Cartan 平衡与挠率—自旋方程，并由原作用与独立对偶直接算出 $4\sqrt2$ 配对及共同量子生成元 $H=H_0+Y$。

同一条规范电流随之贯通微观多体代数、宏观长程相互作用与真实开放测量：经母作用自身的 Fréchet Hessian Green 函数、非线性半轴微分、九约束 Schur 反馈、$z^4\Pi_{\rm st}$ 红外返回与 192/97 电磁消因子分式涌现出三维空间 $1/(4\pi|x-y|)$ 位势与带电色单态三费米子正谱，并在零概率先验下导出全词 Born 测度与开放密度迹对偶，于 120 ns 完整实验门上实现前向与伴随曲线 $10^{-21}$ 量级的吻合恢复。而在整座统一场底层，五位置物理根封印与九场全前提折叠彻底清空了未登记物理权威与可调参数，同一母源 $S_\star$ 普遍形成原准入接口上的全部合法世界、查询与演化过程，将每一个真实差别锚定在登记发生之上。四维连续场方程、非交换量子动力学与开放测量概率由此在同一个零拟合发生源内完整闭合。

---

## 附录A 母表示、生成元与源常数

**A.0 核心符号速查表。**

| 符号 | 数学与物理含义 | 正文定义处 |
| --- | --- | --- |
| $e,\ \varpi,\ B,\ \lambda$ | 余标架、$\mathrm{Spin}^+(1,3)$ 自旋联络、引力辅助双矢、简单性乘子 | 表 2、§3.1 |
| $A,\ B_A,\ \varphi$ | 标准模型子代数 $\mathfrak h_{\rm SM}$ 规范联络、规范辅助二形式、$\Lambda^4\mathbb C^7$ 标量场 | §2.2、§3.1 |
| $\psi,\ \chi$ | 252 复维母外幂物质旋量场、独立复线性对偶场 | §2.3、§3.1 |
| $\mathcal O_{\rm br},\ \iota_{\rm SM}$ | 源生伴随谱序参量 $\sigma\,\mathrm{diag}(-1,-1,-1,0,0,1,2)$、标准模型分块嵌入 | §2.2 |
| $J,\ \star_e,\ \mathrm{II}^+(e)$ | 内部洛伦兹双矢对偶、时空 Hodge 星算子（$\star_e^2=-1$）、简单性靶 $J\Sigma_e$ | §3.1 |
| $v,\ E,\ P,\ S,\ R(A)$ | 8 维占据态、占据嵌入、正交投影、上下旋量交换、压缩响应 $SPAE$（与自伴能量尾 $R$ 区分） | §6.1–§6.2 |
| $H=H_0+Y,\ H^\sharp,\ R$ | 504 模 CAR＋61 对 CCR 共同生成元、形式伴随 $H_0+Y^\dagger$、固定自伴能量尾 | §6.3–§6.4 |
| $u_\epsilon,\ v_\epsilon,\ \ell_d$ | 非零 CAR 创建单位外态、单位配置背景、差值观察泛函（$\|\ell_d\|\le2$） | §6.4、§7.2 |
| $H_{289}(p),\ G,\ \Pi_d^{\rm st}$ | 母作用 289 维二阶变分矩阵（3071 项）、母 Green 函数、静态量子极化矩阵 | §7.1–§7.2 |
| $Q_{97},\ D_{\rm W},\ N_{\rm W}$ | 192/97 约化二变量多项式矩阵、析出 $X^2$ 后 Ward 行列式、析出 $X^3$ 后 Noether 分子 | §7.4 |
| $H_{\rm time},\ \mathcal H_{\rm com}$ | 252 维物质／共同载体上酉时间群 $U_{\rm time}(s)=e^{-isH_{\rm time}}$ 的自伴生成元（与 $H=H_0+Y$ 区分）及共同载体 | §7.5 |
| $\mathcal C_{\rm root}^{(0)},\ \mathcal C_{\rm seal},\ \mathcal U_{1\text{--}10},\ \mathcal W_{\rm ws}$ | 五位置历史根闭合、Stage 10 物理总封印、十阶总贯通对象与全时空缝合算子 | §1.1、§9.2 |
| $S_\star,\ \mathcal M_r$ | 物理原发生账本母源、第 $r$ 阶有限母程序像的逐输入完备化材料载体 | §9.3 |
| $\mathscr W(\mathcal I),\ \Phi_{t_0\to t_R}^{\mathcal H}$ | 单形全词历史空间、隐藏子浴 $\mathcal H\subseteq\mathcal I$ 上的开放循环密度初值流 | §10.1 |

**A.1 标准模型分块嵌入与色二重态生成元。** 群级标准模型块嵌入（源码模块 `Proposition286.lean` 与 `SU7MotherLieAlgebra.lean`）在 $3+2+1+1$ 指标型上取 $\operatorname{diag}(U_3,U_2,z,z^{-1})\in\mathrm{SU}(7)$（$U_3\in\mathrm{SU}(3),U_2\in\mathrm{SU}(2),|z|=1$），无穷小李代数嵌入即定理 2.2 双向选出的 $\iota_{\rm SM}(C,W,y)=\operatorname{diag}(C,W,y,-y)$。色前两维二重态上的三个规范生成元取反厄米 Pauli 形式 $\tau_g=(i/2)\sigma_{g+1}$：

$$\tau_0=\begin{pmatrix}0&i/2\\ i/2&0\end{pmatrix},\qquad \tau_1=\begin{pmatrix}0&1/2\\ -1/2&0\end{pmatrix},\qquad \tau_2=\begin{pmatrix}i/2&0\\ 0&-i/2\end{pmatrix},$$

满足 $\tau_g^2=-\tfrac14 I_2$ 与李配对正交归一性 $\langle\tau_g,\tau_h\rangle=-\mathrm{Re}\,\mathrm{tr}(\tau_g\tau_h)=\tfrac12\,\delta_{gh}$。

**A.2 Dirac 矩阵约定。** 四维旋量指标取对称手征分块形式（$(\gamma^0)^2=-I_4$，$(\gamma^i)^2=+I_4$，$i=1,2,3$）：

$$\gamma^0=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\quad \gamma^i=\begin{pmatrix}0&\sigma_i\\ \sigma_i&0\end{pmatrix},\quad
\sigma_1=\begin{pmatrix}0&1\\1&0\end{pmatrix},\quad \sigma_2=\begin{pmatrix}0&-i\\i&0\end{pmatrix},\quad \sigma_3=\mathrm{diag}(1,-1).$$

时间速度探针算符在 252 维母物质空间上为 $\mathsf V=\mathrm{diag}(i\omega,i\omega,-i\omega,-i\omega)\otimes I_{63}$，限制到 8 维占据空间上为同对角阵与 $I_2$ 的张量积。

**A.3 外幂表示超荷分解表。**

**表 A1 各外幂层的维数与超荷多重数分布。**

| 外幂物质层 | 复维数 | 超荷 $-1$ | 超荷 $0$ | 超荷 $+1$ |
| --- | :---: | :---: | :---: | :---: |
| $\Lambda^6\mathbb C^7$ | $7$ | $1$ | $5$ | $1$ |
| $\Lambda^2\mathbb C^7$ | $21$ | $5$ | $11$ | $5$ |
| $\Lambda^4\mathbb C^7$ | $35$ | $10$ | $15$ | $10$ |
| 合计（每 Dirac 分量） | $63$ | $16$ | $31$ | $16$ |

**A.4 固定正源导出常数总表。**

**表 A2 源生代数常数与精确恒等关系。**

| 常数 | 精确代数闭式 | 近似十进制值 | 发生来源与锁定恒等式 |
| --- | --- | --- | --- |
| $\sigma$ | $1/2$ | $0.50000$ | $\sigma_n=1/(n+2)$ 在种子 $n=0$ 的原点读出；$g_j^2=\sigma$ |
| $k$ | $\sqrt2$ | $1.41421$ | 自旋联络空间挠率尺度，$k^2=2$ |
| $a$ | $3\sqrt2/5=3k/5$ | $0.84853$ | 规范联络空间幅度，$\rho=a/k=3/5$ |
| $N$ | $\sqrt{54/125}$ | $0.65727$ | 余标架时间尺度（lapse），$N^2=2\rho^3=54/125$，$a^3=N^2k$ |
| $\omega$ | $3N(k-a)/2=3Nk/5$ | $0.55771$ | Dirac 相位频率，$\omega^2=972/3125$ |
| $\kappa$ | $9N/5=3\rho N$ | $1.18308$ | Clock–B 混合刚度（定理 5.2） |
| $m,\ c$ | $3N,\ 5N$ | $1.97180,\ 3.28634$ | 全局轨道惯性质量与二次势刚度，$c/m=1/\rho=5/3$（定理 8.1–8.2） |
| $t^*$ | $\pi/(2\omega)$ | $2.81651$ | 首暗时刻（定理 8.3） |

## 附录B 变分、四腿临界归约与消元公式

**B.1 九类 Euler–Lagrange 变分残差。** 在零号坐标片上（其余片由命题 3.5 下降），令 $L_\mu=\Omega_\mu+\rho_{\mathcal M}(A_\mu)$，$\mathscr D\psi=i\gamma_e^\mu D_\mu\psi+Y_R(\varphi)\psi$。一形式 $\alpha$ 与三形式 $Z$（按 $(012,013,023,123)$ 排序）的正向四形式楔配对为

$$W_{13}(\alpha,Z)=\langle\alpha_0,Z_{123}\rangle-\langle\alpha_1,Z_{023}\rangle+\langle\alpha_2,Z_{013}\rangle-\langle\alpha_3,Z_{012}\rangle.\tag{B.1}$$

物质自旋流三形式 $j_{\rm spin}$ 与规范流三形式 $j_A$ 由式 (3.1) 一阶变分唯一确定：

$$\begin{aligned}
W_{13}(\delta\varpi,j_{\rm spin})&=\nu_e\operatorname{Re}\chi(i\gamma_e^\mu\delta\Omega_\mu\psi),\\
W_{13}(\alpha,j_A)&=\nu_e\left[g^{\mu\nu}\operatorname{Re}\langle\rho_4(\alpha_\mu)\varphi,D_\nu\varphi\rangle+\operatorname{Re}\chi(i\gamma_e^\mu\rho_{\mathcal M}(\alpha_\mu)\psi)\right].
\end{aligned}\tag{B.2}$$

前五类代数与规范—联络微分残差为

$$\mathcal E_\lambda=B-J\Sigma_e,\quad
\mathcal E_B=\widehat F_\varpi-JB+\lambda,\quad
\mathcal E_{B_A}=F_A-K_eB_A,\quad
\mathcal E_\varpi=D_\varpi B+j_{\rm spin},\quad
\mathcal E_A=D_A B_A+j_A.\tag{B.3}$$

标量、物质、独立对偶与余标架四类方向残差（对常测试方向 $h\in\Lambda^4\mathbb C^7$、$w\in\mathcal M$、$\zeta\in\mathcal M^*$ 与 $H\in\mathbb R^{4\times4}$）为

$$\begin{aligned}
\mathcal E_\varphi[h]&=\nu_e\left[g^{\mu\nu}\operatorname{Re}\langle\rho_4(A_\mu)h,D_\nu\varphi\rangle-2\operatorname{Re}\langle h,\varphi-\varphi_{{\rm vac},s}\rangle+\operatorname{Re}\chi(Y_R(h)\psi)\right]-\partial_\mu\left[\nu_e g^{\mu\nu}\operatorname{Re}\langle h,D_\nu\varphi\rangle\right],\\
\mathcal E_\psi[w]&=\nu_e\operatorname{Re}\chi\bigl(i\gamma_e^\mu L_\mu w+Y_R(\varphi)w\bigr)-\partial_\mu\left[\nu_e\operatorname{Re}\chi(i\gamma_e^\mu w)\right],\\
\mathcal E_\chi[\zeta]&=\nu_e\operatorname{Re}\zeta(\mathscr D\psi),\\
\mathcal E_e[H]&=-W_{\rm top}(\lambda,J\,D\Sigma_e[H])+D_e\bigl(L_{\rm gauge}+L_{\rm scalar}+L_{\rm Dirac\text{-}dual}\bigr)[H].
\end{aligned}\tag{B.4}$$

在光滑、Lorentz 合法与非退化条件下，式 (3.1) 对任意紧支撑光滑变分的一阶方向导数等于上述残差与测试场的积分配对。

**B.2–B.6 本构逆、两种对偶、外幂误差尺度、形式积分与移动标架。**
- **B.2 本构逆**：$K_{e,j}=\alpha_j\star_e$，$\star_e^2=-1\implies K_{e,j}^{-1}=-\alpha_j^{-1}\star_e$；展开 $B_A=B_A^*+\delta B_A$ 即消去一次项得定理 3.4。
- **B.3 两种对偶**：$\star_e$ 作用于时空二形式指标将纯磁曲率映为纯电辅助场；$J$ 作用于内部洛伦兹双矢指标给出 $\mathrm{II}^+(\mathrm{diag}(\nu,1,1,1))_{3,0}=-\nu$，解释定理 5.4 的 $-uN$ 反冲。
- **B.4 外幂误差显式尺度**：对七维反自伴生成元 $G$、楔输入 $w=(w_1,\ldots,w_d)$ 与多线性重标映射 $T_w(M)=(Mw_1,\ldots,Mw_d)$，命题 6.4(2) 的显式尺度为 $C_{w,j}(t)=\|\omega_{d,j}\|\,d[\|T_w\|(1+t\|G\|)]^{d-1}\|T_w\|\|G\|^2$，对一般向量 $v=\sum_I v_I e_I$ 取 $C_{d,v,j}(t)=\sum_I|v_I|C_{w^I,j}(t)$。
- **B.5–B.6 相对作用与移动标架**：紧支撑相对作用按差值密度积分严格定义；全空间作用泛函 `actualAction` 与 `nativeActionInFrame` 满足逐点密度相等即积分读数相等的表示不变律（不声称常值非零密度在无限体积 $\mathbb R^4$ 上绝对可积）；移动标架下 $\mathrm{reduce}(gf,g\cdot\Phi)=\mathrm{reduce}(f,\Phi)$ 逐点成立。

**B.7 核心经典计算的形式化声明对应（相对 `Lean/SaturationMonoid/PhysicsCore/`，版本 H）。**

| 正文公式／定理 | 核心生产模块与声明 | 直接消费模块 |
|---|---|---|
| 定理 2.2 谱序参量双向选择 | `SU7MotherLieAlgebra.lean`：`selected_entry_zero_of_breakingLevel_ne`、`selectedBySourceBreaking_iff_p286LieBlockImage` | `Stage10/Recovery/Source.lean`、`SU7GravityGaugeMatterJointCredential.lean` |
| 命题 3.2 引力—规范不可分 | `NonseparableSourceCoframeRegression.lean`：`gravityGaugeMixedDifference_eq_nine`、`nonseparableMasterAction_not_additively_separable` | `NonseparablePhysicalUnifiedAdmissionCredential.lean`（Stage 5 凭证） |
| 式 (3.1) 与 (B.3)–(B.4) 密度及残差 | `StageNineDiracDualFormNativeMotherAction.lean`、`StageNineDiracDualFormNativeJointResidualCarrier.lean` | `Stage9G/Foundation/NativeAction.lean`、`Stage9C/Material/SpinPair/Acceptance.lean` |
| 定理 3.3 四腿临界与 $5/8$ 缺陷 | `StageNineDiracDualFormNativeFourLegCriticalLocusCorrespondence.lean`、`StageNineDiracDualFormNativeIIPlusTorsionSpinCriticalLocus.lean`、`StageNineDiracDualFormNativeIIPlusCoframePointwiseEquation.lean`、`StageNinePlebanskiExistingGravityMultiplierCompatibility.lean` | `StageNineDiracDualFormNativeIIPlusCoframePointwiseEquationRegression.lean`、`StageNinePlebanskiExistingGravityMultiplierCompatibility.lean`（`fullSynchronizedCompatibilityResidual_spin_nonzero`） |
| 式 (4.2)–(4.17) 九场解与相消 | `SU7ExteriorYukawaMassSpectrum.lean`、`Stage9C/Material/SpinPair/{Actual,DiracActual,AdjointActual,GaugeEquation,Coframe}.lean`、`Stage9C/Dynamics/Homogeneous/{CartanActual,GaugeBalance}.lean` | `Stage9C/Material/SpinPair/Acceptance.lean` `actual_jointZeroFiber`、`actual_classicalWorldAcceptance`、`Stage9DEF/Compatibility/Current.lean` |

**B.8 定理 3.3（一般四腿临界轨迹等价与 Plebański `5/8` 缺陷）的完整书面证明。**

*第一部分：一般四腿临界轨迹等价（式 (3.4)）。* 固定任意光滑统一源 $s$ 与满足光滑、Lorentz 合法、全点余标架非退化及在原点坐标片上局部密度可积的九场构型 $\mathcal C=(e,\varpi,B,\lambda,A,B_A,\varphi,\psi,\chi)$。记限制投影 $\pi_{\mathrm{II}^+}(\mathcal C)$ 为保持其余**八场**（含乘子 $\lambda$）不变、仅将引力辅助场替换为 $\mathrm{II}^+(e)=J\Sigma_e$ 所得的构型，并记唯一作用导出反应场为 $\lambda_{\rm react}(\mathcal C):=JB-\widehat F_\varpi$（注：$J^2=-I_6$，故在 $B=\mathrm{II}^+(e)$ 上 $\mathcal E_B=\widehat F_\varpi-JB+\lambda=0\iff\lambda=\lambda_{\rm react}(\mathcal C)=-\Sigma_e-\widehat F_\varpi$）。显然 $\pi_{\mathrm{II}^+}(\mathcal C)=\mathcal C$ 当且仅当式 (3.4)(i) 成立，且 $\pi_{\mathrm{II}^+}(\mathcal C+s\delta\varpi)=\pi_{\mathrm{II}^+}(\mathcal C)+s\delta\varpi$ 逐字段成立。

1. **代数两腿消元**：在式 (3.1) 中，$\lambda$ 仅线性出现在 $W_{\rm top}(\lambda,B-J\Sigma_e)$，对全部紧支撑光滑双矢变分 $\delta\lambda$ 积分为零充要于逐点 $B=J\Sigma_e$；在此条件下，对全部紧支撑变分 $\delta B$ 积分为零充要于逐点 $\widehat F_\varpi-JB+\lambda=0$，即 $\lambda=\lambda_{\rm react}(\mathcal C)$。
2. **约化作用与全作用偏变分的恒等桥**：定义 $\mathrm{II}^+$ 约化积分作用为 $S_{\rm red}(\mathcal C):=S\bigl(\pi_{\mathrm{II}^+}(\mathcal C)\bigr)$，其中引力块退化为纯一阶 Einstein–Cartan 项 $W_{\rm top}(\mathrm{II}^+(e),\widehat F_\varpi)-\tfrac12 W_{\rm top}(\mathrm{II}^+(e),J\,\mathrm{II}^+(e))=W_{\rm top}(J\Sigma_e,\widehat F_\varpi)+\tfrac12 W_{\rm top}(\Sigma_e,J\Sigma_e)$。对自旋联络沿任意紧支撑一形式 $\delta\varpi$ 变分 $s\mapsto\mathcal C+s\delta\varpi$：由于 $\mathrm{II}^+(e)$ 不依赖 $\varpi$，而约束项在 $B=\mathrm{II}^+(e)$ 上恒为零，直接求导得
   $$\left.\frac{d}{ds}\right|_{s=0}S_{\rm red}(\mathcal C+s\delta\varpi)
   =\left.\frac{d}{ds}\right|_{s=0}S\bigl(\pi_{\mathrm{II}^+}(\mathcal C)+s\delta\varpi\bigr)
   =\int W_{13}\bigl(\delta\varpi,\,D_\varpi(\mathrm{II}^+(e))+j_{\rm spin}(\mathcal C)\bigr).\tag{B.5}$$
   当式 (3.4)(i) 成立时，$\pi_{\mathrm{II}^+}(\mathcal C)=\mathcal C$，故式 (B.5) 左端等于原全作用对 $\varpi$ 的驻定导数；由一形式—三形式非退化配对的基本变分引理，驻定性双向等价于逐点挠率—自旋方程 $D_\varpi(\mathrm{II}^+(e))+j_{\rm spin}(\mathcal C)=0$（式 (3.4)(iv)）。
3. **余标架通道与显式 EC 平衡**：对余标架沿紧支撑矩阵场 $H$ 变分 $e_\varepsilon=e+\varepsilon H$，在约化作用 $S_{\rm red}$ 中，$B(\varepsilon)=J\Sigma_{e_\varepsilon}$ 随 $e_\varepsilon$ 同步变化，链式法则给出
   $$\left.\frac{d}{d\varepsilon}\right|_{\varepsilon=0}L_{\rm red}(e_\varepsilon)
   =W_{\rm top}\bigl(\widehat F_\varpi-J\,\mathrm{II}^+(e),\,J\,D\Sigma_e[H]\bigr)+D_e\bigl(L_{\rm gauge}+L_{\rm scalar}+L_{\rm Dirac\text{-}dual}\bigr)[H].$$
   在满足 (i)–(ii) 的构型上，$\widehat F_\varpi-J\,\mathrm{II}^+(e)=-\lambda_{\rm react}(\mathcal C)=-\lambda$，右端第一项恰为 $-W_{\rm top}(\lambda,J\,D\Sigma_e[H])$，与式 (B.4) 第四行的原九场偏变分残差 $\mathcal E_e[H]$ **逐点恒等**。再由余标架非退化性将紧支撑积分驻定双向化归为逐点显式 Einstein–Cartan 余标架平衡方程 $\mathcal E_e^{\rm EC}(s,\mathcal C)=0$（式 (3.4)(iii)）。正向与反向两路合取，证毕式 (3.4) 的充要等价（对应源码 `diracDualFormNative_fourLegCriticalLocus_iff_EC_coframeBalance_and_torsionSpin`）。

*第二部分，Plebański `5/8` 对交换缺陷与 Spin 不变排除（式 (3.5)）。* 这里采用 Smolin [7, §2, 式 (1)–(3)] 回顾的非手征 Plebański 约束在 $\Lambda=0$ 时的乘子空间。项 $-\tfrac12\Phi_{IJ}B^I\wedge B^J$ 的乘子具有对交换对称性与零 $\varepsilon$ 缩并。Smolin [7, §2, 式 (4)、(8)] 的扩展乘子也满足对交换对称性，迹条件由其模型方程决定。在固定正源的历史同步构型，取 $e=I_4$ 与 $B_0=\mathrm{II}^+(I_4)$。由完整反作用重构 $\Phi_{\rm cand}=\mathcal R_{\rm tot}B_0^{-1}$，分量 $(4,3)$ 与 $(3,4)$ 分别为 $5/16$ 和 $-5/16$。历史余标架响应的 $(3,0)$ 分量为 $5/16$，所以变分方向 $E_{03}$ 上的线性主部为 $\mathcal P_{\rm lin}(E_{03})=-2(5/16)$。反作用抵消这一主部，给出

$$(\Phi_{\rm cand})_{4,3}-(\Phi_{\rm cand})_{3,4}=\frac{5}{8}=T_{\rm non\text{-}grav}(E_{03})=-\mathcal P_{\rm lin}(E_{03})\ne 0.\tag{B.6}$$

式 (B.6) 使相容残差非零。令 $M_g$ 为 $g\in\mathrm{Spin}^+(1,3)$ 在内部双矢上的矩阵。同步变换给出 $B_g=M_g B_0$ 与 $\mathcal R_g=(M_g^{-1})^{\mathsf T}\mathcal R_{\rm tot}$，故重构乘子为 $\Phi_g=(M_g^{-1})^{\mathsf T}\Phi_{\rm cand}M_g^{-1}$。该双指标拉回及其逆保持对交换对称性和零 $\varepsilon$ 缩并，因此 $\Phi_g$ 属于标准乘子空间当且仅当 $\Phi_{\rm cand}$ 属于该空间。相容残差在整个轨道上非零。∎

## 附录C 源族、法则形成与过程表示细节

**C.1–C.4 逐输入完备化载体、源族四合同、路径与联合实极限。**
- **C.1 完备化载体**：有限母法则在逐输入、逐有限输出坐标一致结构下取 Cauchy 滤子完备化；物理输入域取（原始十分量 Cauchy 状态 $\times$ 独立时钟）$\times$ 旁实流，十分量为九场加标量速度。
- **C.2 源族四合同**：（i）存在先于全部源、状态与中心的单一母法则，恢复完整输入并输出下一 Cartan 态且保持相对作用；（ii）存在先于任意材料与合法发生的法则使编译为原生写入；（iii）存在同一全称范围内的法则使发生目标等于原 Cartan 目标；（iv）对任意法则、材料与合法发生，演化生成账本后继并恢复目标。
- **C.3–C.4 路径与 65 坐标几何收敛**：任意有限实目标序列（含 $195=65\times3$ 空间余量）在原母史上可达为逐步后态子列；任意有限有理程序（$260=65\times4$ 有理坐标）在先于查询选定的一轮中自主形成并执行。65 个连续源坐标按权重 $w_n=2^{-(n+1)}$ 折叠有界响应 $q^2/(1+q^2)$，有限和序列在 $\sup$ 范数下满足 $\|\text{极限}-f_n\|_\infty\le 2^{-n}$，完成源零步恢复原源并交付完整经典—量子准入。

**C.5–C.7 完整物质算子、联合编译与连续过程闭嵌入。**

**定理 C.1（252 维母物质算子空间的母材料形成）。** 母曲率率归一化生成复虚数单位 $i$；母史有理取值域的 $127,008=2\times252^2$ 个实坐标经规范完备化形成完整复矩阵代数 $\operatorname{End}_{\mathbb C}(\mathcal M)$：对**每个** $A\in\operatorname{End}_{\mathbb C}(\mathcal M)$ 存在**唯一**完备值 $v$ 使 $\mathrm{operator}(v)=A$，全部矩阵元与向量作用双向恢复，有限前缀读取仅访问同一母访问的过去样本，并与任意源的完整写入、九通道及 $8\times8$ 量子响应联合成立。

**命题 C.2（联合载体形成与物理查询编译）。** 在原联合输入 $\Omega$-轨道整系数张成空间上，存在先于一切联合值的两枚母法则（形成材料与原生提升作用），保留源生非零反馈方向；并存在先于一切双亲与联合值的两枚共同编译法则，对每个双亲与联合值存在查询使字面编译返回（该查询，$\operatorname{some}$ 该值，$\operatorname{some}$ 原生提升值），同时保持任意查询自身的原回答。

**命题 C.3（一般法则完备化与 Polish 连续过程闭嵌入）。** （1）对任意映射 $f:\mathbb S\to\mathbb S$ 及任意无正则性前提的物理输入映射 $f:\mathrm{Input}\to\mathbb S$，均存在唯一完备母法则逐输入精确求值为 $f$；（2）对任意状态空间 $S$ 与依赖事件总空间 $\sum_{s\in S}\mathrm{EventAt}(s)$ 均为完备可分度量空间（Polish 空间）且发射、更新映射均连续的原动力学，存在母法则、初始态与单射闭嵌入映射，完整恢复发射像内外的全部状态与合法事件，并与初值、发射、更新、全部有限历史、整账及原生后继精确交换。

**C.8 §9 与附录 C 结果的形式化声明入口（相对 `Lean/SaturationMonoid/PhysicsCore/`，定理 9.4–推论 9.5 取版本 F，其余取版本 H）。**

| 正文／附录结果 | 核心生产模块与声明 | 直接消费者与保留内容 |
|---|---|---|
| 定理 9.1、附录 C.2 | `Stage10/SourceUniqueness/Formation/General/{Consumer,Acceptance}.lean`；`Declarations/AllSourceOrigin/Consumer.lean` | `General/Evolution/Consumer.lean`（任意源九场、相对作用与量子响应） |
| 定理 9.2、定理 C.1、命题 C.2–C.3 | `Formation/Paths/Consumer.lean`、`Programmes/Autonomous/Consumer.lean`、`Matter/Action/Matrix.lean`、`Declarations/JointCarrierFormation/Coverage.lean`、`Laws/{Pointwise/Completion,Restriction/Process}.lean` | 全部中间微步、过去样本单调性、`NativePhysicalQuery/Inquiry.lean`、`regular_process_map` |
| Stage 1–3 本构反空真与双轴门禁 | `ConstitutiveHardGateVacuityBoundary.lean`、`SourceConstitutiveHardGateAdapter.lean`、`SU7AdmittedRicherDualAxisCredential.lean` | `Stage10/Recovery/Source.lean`、`Stage10/Recovery/Consumer.lean` |
| 定理 9.3 五位置根封印、零未登记权威与表示 | `StageTenPhysicalRootClosure.lean`；`Stage10/{Authority,Seal,RawSourceRealization,Realization,Description/Consumer}.lean` | `Stage10/Runtime/Activation.lean`、`Stage10/Recovery/Consumer.lean`（`stageOneThroughTenClosed`） |
| 定理 9.4 普遍形成与无魔法比特（F） | `Formation/Declarations/Cumulative/FixedMother/{Formation,CompleteRealization}.lean`（`root_admission_fixed_mother_complete_realization`）；`LivingLawTotalRealityKernel.lean`（`TotalRealityAt.noMagicBit`） | `WorldRealization`、`InquiryRealization`、`ProcessRealization` 及原根全实在性传递 |
| 推论 9.5 原物理激活与运行保持（F） | `Lean/docs/audits/physics/source-uniqueness/MotherFixedSourceRealizationConsumer.lean` | `original_physical_seal_and_whole_law`、`original_physical_tick_and_history`（$16\to17$ 步与全深度历史） |

### C.9 定理 9.4（普遍形成与完整恢复）的三步证明机制

1. **有限分离观测与逐输入一致稠密性**：设地址观测族 $\mathcal A_r$ 分离输入集 $X_r$ 的点。对任意有限子集 $F\subset X_r$，为 $F$ 中每对相异点选取一枚区分地址，拼成有限地址表，使补零流映射在 $F$ 上单射。对任意目标函数 $f:X_r\to\mathbb S$、任意输出前缀长度 $b\in\mathbb N$ 与 $\varepsilon>0$，母有限求值逼近定理在原母史第 $10+c$ 次访问处给出有限程序 $p\in\mathsf{Prog}_r$，使
   $$\bigl|L_r(p,x)(j)-f(x)(j)\bigr|<\varepsilon\qquad(\forall x\in F,\ 0\le j<b).\tag{C.1}$$
   由于逐输入一致结构的基本邻域恰由 $(F,b,\varepsilon)$ 刻画，式 (C.1) 证明程序像 $\mathcal R_r$ 在函数空间 $(X_r\to\mathbb S)$ 中稠密。包含映射的一致完备延拓
   $$\mathsf{read}_r:\mathcal M_r\longrightarrow(X_r\to\mathbb S),\qquad \mathsf{read}_r(\iota_r(L_r(p)))=L_r(p)\tag{C.2}$$
   为一致闭嵌入，闭像含稠密子集故满射且单射（底层用指示观测 $\mathbf1_{\{a\}}$ 分离点，高阶层用“底层键 $\times$ 输出坐标”分离底层完备材料，无需对目标函数施加任何连续性假设）。
2. **过程不交和内部定阶与全空间左逆**：对任意原生宏过程 $P$，构造状态与依赖查询的不交和载体
   $$\mathcal U_P=\operatorname{State}(P)\ \sqcup\ \coprod_{s\in\operatorname{State}(P)}\operatorname{Query}\bigl(P.\mathsf{stateAt}(s)\bigr),\tag{C.3}$$
   由 $\mathcal U_P$ 内部生成充足材料阶与忠实地址，同时形成全部状态节点（含未访问或读数重合的不同状态）、查询编译五分支路由、初始态与后继图；固定流配对合并高低阶材料族并逐分量投影回读，直接给出式 (9.5) 的全乘积材料空间左逆。
3. **规范过程构造与全深度输运**：过程构造映射读取联合材料中的节点族与操作图生成状态重标过程 $P_m$，沿状态双射限制即得完整过程记录等式 $\mathcal R_{\rm proc}(P_m)=P$（式 (9.3)）；依赖类型输运 $T_m$ 随之将既定激活、整条激活法则及任意演化轨迹每一步 $(s_n,\tau_n,\mathsf{next}(\tau_n))$ 在全体 $n\in\mathbb N$ 上无损搬运为式 (9.4)。

## 附录D 固定版本、验证凭证与经验协议

**D.1–D.3 与 D.5–D.6 基础固定版本、内核认证、Fock 与有限矩阵回执。**

- **版本 H 与 F**：§2–§6.2、§8–§9.2、定理 3.3 及定理 4.6–4.7 固定于 Homework 提交 **H** = `e60a86058abcb74b7f2225f2383c182be8343785`（Lean `v4.33.0`，Mathlib `db584cd6d46c92f209a44c0f1c829460d327499d`）；定理 9.4–推论 9.5 固定于 **F** = `cde4b910929d9bc57554aa56f6ade116bc3b8675`（共用 72 份物理源文件逐字节一致）。
- **独立严格认证**：H 保存 Stage 1–10 贯通、Stage 9G、Stage 9DEF、Stage 10 Bell 与全局规范谱的 `--trust=0 -DwarningAsError=true` 独立构建及标准三公理闭包记录；F 保存 `MotherFixedSourceRealization.certification.json`（64 个自身声明、5 个无旁路直接消费者、原 329 个生产模块不变及正反控制通过）。
- **256 维 Fock 与有限矩阵复核（D.3、D.5；原 D.6 证据分层已升入 §10.4 表 4）**：`quantization-current` 审计编译 4 模块全过（86 声明仅标准三公理），256 维全 Fock 空间 40 族 812 次数值评价最大残差 $8.882\times10^{-16}$（暗时刻正负对照 $+0.5$ 对 $-0.5$ 命中）；`scripts/physics/common-source/check_core_identities.py` 执行 20 组 501 次有限矩阵恒等检查，最大残差 $1.554\times10^{-15}$（回执 `evidence/physics/common-source/core-identity-checks.json`）。

### D.4 历史名义装置检验的可复核协议与冻结数据

1. **ETH 超导电路数据集与冻结映射**：数据源为 Storz 等 [8,9] 官方档案 `Bell_Test_ETHZ_2023_rawData`（DOI `10.3929/ethz-b-000624026`，压缩包 SHA-256 `2d39d1b6898480d3de0134e2d55ac3faee87af32c8db5bc6fdf6fa6997296909`，主事件文件 SHA-256 `5881b901b0d4a148104b14eadabe80c4f742026e2a120397af23013c2113a848`），按原始行序读取前 $100,000$ 条试次（物理行 4–100003，无筛选或后选择）。旧名义锁（锁提交 `5d32d1576`）取理想 $\psi^+$ 与轴角 $\theta_{\rm geo}=-\pi/4$，给出条件概率矩阵
   $$q_{ab}(x,y)=\frac{1+xy\,C_{ab}}4,\qquad C_{ab}=\cos\!\left(\theta_{\rm geo}+(b-a)\frac\pi2\right),\qquad (C_{ab})=\frac1{\sqrt2}\begin{pmatrix}1&1\\-1&1\end{pmatrix}.\tag{D.1}$$
2. **随时超鞅统计量与六半径结果**：对预固定逐格概率半径 $\varepsilon\in\{0,0.01,0.02,0.05,0.1,0.2\}$，令上界包络 $u_{\varepsilon,c}(o)=\min\{1,q_c(o)+\varepsilon\}$，取六个固定混合权重 $v\in\{0,\tfrac14,\tfrac12,\tfrac34,0.9,1\}$ 与既往计数 Krichevsky–Trofimov 预测器的七路等权乘积超鞅
   $$E_{\varepsilon,t}=\frac17\sum_{j=1}^7\prod_{n=1}^{t}\frac{r_{j,n,c_n}(o_n)}{u_{\varepsilon,c_n}(o_n)},\qquad p_{{\rm any},\varepsilon}(t)=\min\!\left\{1,\frac1{\max_{0\le s\le t}E_{\varepsilon,s}}\right\}.\tag{D.2}$$
   独立 80 位复算核实全部 $100,001$ 个前缀（最大 $\log E$ 差 $5.59\times10^{-10}$）：$\varepsilon=0,0.01,0.02,0.05$ 在 $\alpha=0.025$ 下均拒绝（$\varepsilon=0$ 时最大 $\log E=46803.6234$，$p_{\rm any}\approx2.7838\times10^{-20327}$），$\varepsilon=0.1,0.2$ 未拒绝。四设置结局计数合计依次为 $(0,0):25222$、$(0,1):24878$、$(1,0):24888$、$(1,1):25012$。控制映射审查（`bridge-review`）表明原作者定义 $S=E_{00}-E_{01}+E_{10}+E_{11}=2(\cos\delta+\sin\delta)$ 在 $\gamma=0,\theta_{\rm geo}=-\pi/4$ 下给出 $S=0$，证实名义相位桥未闭合。
3. **NIST 2015 名义双模重放**：固定于提交 AB，目录 `Verification/physics/stage10/independent-bell/nist-real/nominal-replay/`（预冻结判据 `criterion-r0003.md`，概率效率半宽 $0.003$）：中心 $(r,\theta_0,\theta_1)=(0.315463895,4.954737358^\circ,-27.232869633^\circ)$ 加 16 角点及容差构成预声明最优带，文档五个名义值均在带外（双实现一致判定 `REPLAY_DEVIATION_EXCEEDS_PREDECLARED_BAND`；较早误用窄十倍半宽 $0.0003$ 的 `replay.json` 按历史记录保留）。

**D.7 第一、二版完整量子构造与原场返回声明入口。** 固定提交别名：**AB** = `fde5c14df36b6064c87064acd20830d3df0500bb`，**AC** = `b67aa48c75b3cd7738766ed40093bb3f7c1d7a1a`，**AD** = `aef0ad2a26199d9fd6da9bc9e7ec1a65636ef63f`，**AE** = `26b91feb6b507fdc3f43be9c429edb63fb9395ef`，**CAP** = `59409a512c435cad5c5113fdedc91a451af88883`，**71e** = `71e94e8261d67cf4849a05eb14ac95aa2f7dcbb9`，**9c73** = `9c73a630ce05bea062ec889b188f5105c0afb796`（定理 6.7(1)(2) 载体程序另固定于 `85cb5386ca132818f74d90470d87a252e4a27ea7`、`f9b733928fb5078ac82430b164dabb8696542e64`、`6726f385356cb327e7c158687e6e37f5f086fe71`、`eec031c489f37459742e62a59a26b9866a21caed`，几何体时间预算模块保存于 `fa15016c967e1ea50c1fdc3d8e7bf1ec8f7128a6`，序列化生成模块由各提交 `canonical_preparation_serialized_source_certification.json` 散列锁定）。下表路径相对 `Verification/physics/low-energy-phenomenology/`（`A/` = `alpha-source/`，`V/` = `external-composite-decay/`）：

| v3 正文定理 | 固定提交 | 核心生产声明入口 | 书面证明 |
| --- | --- | --- | --- |
| 定理 6.7 共同量子 $H$ | 较早四提交、AB | S1 表各程序与 Lean 模块；`A/CanonicalPreparationActionCoreDecomposition.lean`（`physical_action_decomposition`） | S1 |
| 定理 6.8 时钟、$R$ 与准备 | AB | `A/CanonicalPreparation{EngineProgram,EngineCancellationForces,FullEnergyForm,SourceRemainder,SourcePreparedState,SourceBoundarySequence}.lean` | S2 |
| 定理 6.9、6.11 创建与归一 | 71e、9c73 | `A/em-identification/{ActualDressedSourcePreparation,PhysicalDressedP286Character,ActualDressedTemporalNormalization,PhysicalDressedWeightedCreation}.lean` | S11.1–S11.2 |
| 定理 6.10 完整 Ward | AB | `A/CanonicalPreparationElectric{PairCurrent,CoreWard,WeightedGraph,PreparedWard}.lean`、`CanonicalPreparationTemporalGlobalCharge.lean` | S4 |
| 定理 7.1 母作用认回 $H_{289}$ | AD | `A/CanonicalSourcePropagation{OriginalHessianReturn,PreparedMotherEulerReturn}.lean` | S5 |
| 定理 7.2 真变场与截断交换 | AB、AC | `A/CanonicalPreparation{SourceNonlinearState,YukawaObservedLimit,HalfDensityCompressionFeed,SpatialFullFormFeed,JointMixedResponse,RawJointFiveTerms}.lean`；`V/Source{HamiltonianSpectralMeasure,BoundedInsertionTime}.lean` | S3 |
| 定理 7.3、7.6 非线性半轴与 $z^4\Pi$ | 71e、9c73 | `A/em-identification/ActualDressed{NoetherHalfIntegral,NonlinearPolarization,SignalPencil,GradedSlopePrice,CubicNoetherPrice,CubicStaticPrice,CubicIRFactor,CubicIRReturn}.lean` | S12 |
| 定理 7.4 半轴与因果双侧逆 | AC、AD、AE | `A/CanonicalPreparation{OriginalPreparedGreen,PhysicalFullHalfAxis,SourceHalfAxisCurrentOperator,SourceCurrentFeedbackAdjugate}.lean`、`CanonicalSourcePropagation{SourceSpectralInverse,ActualNativeHistoryReturn}.lean` | S6 |
| 定理 7.5 九约束 Schur 反馈 | 9c73 | `A/em-identification/{ActualEMDressedSchur,ActualDressedFullSchurFlux,ActualDressedHalfSchur,ActualDressedRationalFourier}.lean` | S13 |
| 定理 7.7 运动载体与原生留数 | AE、CAP | `A/CanonicalPreparationSource{MovingCarrier,MomentumContinuation,StaticActualPole,ConstraintRead,NativePoleBalance,NativePolePrice}.lean` | S7 |
| 定理 7.9 物理 EM 与 $1/(4\pi r)$ 核 | 71e、9c73 | `A/em-identification/{ActualEMGaugeCurvature,ActualEMDressedGaugePole,ActualDressedUncutMovingCoulomb,ActualCompositeCoulombDressing}.lean` | S11.3–S11.6 |
| 定理 7.10 匹配整词与端点尾 | AE | `V/SourceClockPhi{NativeMatchedSource,NativeMatchedGammaBudget,RenormalizedSecondGreenTail,MatchedDiffusionSource}.lean` | S8 |
| 定理 7.11 三费米子正谱与零道 | 71e、9c73 | `V/{MixedSpectatorYukawaNonzero,SourceYukawaPositiveCorrection}.lean`、`V/SourceActualFourBlock{HilbertOperator,RealTransferPositive,SignedSector}.lean`；`Lean/scratch/LowEnergyRetardedCouncil/ActualFourBlockResponse/SourceActual*.lean` | S14 |

**D.8 公开实验消费者（命题 10.2–10.5）的版本与证据入口。** `B/` = `Lean/SaturationMonoid/PhysicsCore/Stage10/Bell/`，`N/` = `Verification/physics/stage10/independent-bell/nist-real/`，`M/` = `Verification/physics/stage10/independent-bell/munich/`：
- **命题 10.2–10.3**（AD、AE）：`B/{TheoryBlind,ReadoutEffects,ReadoutIdentification,ReadoutResponseBounds,ReadoutAnchors,ReadoutDetectorFiber,ReadoutPulseRealization,SourceHistory}.lean`；`M/criterion-mu0001.1.md` 及 `M/readout-domain/` 下全部双实现核验回执。
- **命题 10.4**（71e、9c73 及 S15.5 所列科学冻结提交）：`M/readout-domain/{LateRegisteredAdjoint,FirstReceiptZeroCount,FirstReceiptQuantumFlux,NoCountQuantumGenerator}.lean` 及 `late-adjoint-bank-first-rha0038.1.json`、`first-receipt-probability-first-rha0039.1.json`、`primal-zero-count-bank-first-rha0041.1.json`、`zero-count-quantum-program-bank-first-rha0042.json`。
- **命题 10.5**（AB、AC、AD）：`N/observable-closure/` 下 `PhaseFiber.lean`、`MatchedSource.lean`、`EnvironmentSource.lean`、`criterion-ef0002.md`；`N/nominal-replay/public-review/source-compression/NormalizedSourceBet.lean` 及 `source-compression-verification.json`。

**D.9 第三版（v3）新增自足证明定理的固定版本与生产声明入口。** 新增固定提交别名：**df4** = Homework `df421ff600085cbc290a7ae946193961bed7c83b`（含前序 `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa` 同字节模块），**7e4** = Homework `7e4da746f300b3796b8b18afb26cb0765c29afcb`，**B291** = Homework `fa2085ee1fda4f01f8ff6c50a2a6a5f91fe3cbf5`，**B300** = Homework `1357a4e92d11d4896f5dcf97206d4f575c35b436`。

| v3 新增结果 | 固定提交 | 完整生产模块与核心定理声明 | 本篇书面证明 |
| --- | --- | --- | --- |
| 定理 2.2、命题 3.2、定理 3.3 | H | 见附录 B.7 所列 `PhysicsCore/` 生产模块 | §2.2、§3.1–3.2、附录 B.8 |
| 定理 4.6 Volterra 等价与满测度唯一识别 | H | `PhysicsCore/StageNineDiracDualFormNativeFixedP506CauchySafeMatterCanonicalAffineVolterra{Recognition,Actualization}.lean`（`canonicalAffinePhysicalTimeL2Output_weakActionZero_iff_fixedPoint`、`CanonicalAffineVolterraDenseReadOccurrence.physicalField_unique`） | S16.1–S16.2 |
| 定理 4.7 对称双曲全阶无导数损失闭合 | H | `PhysicsCore/StageNineDiracDualFormNativeFixedP506CauchySafeMatterSymmetricHyperbolicAllOrder{JetProlongation,EnergyClosure}.lean`（`fixedMatterAllOrderForcingJetCLM_apply_of_actionZero`、`exists_fixedMatterAllOrderClosedPointwiseRateBoundOnBox`） | S16.3–S16.4 |
| 定理 7.8 192/97 分式、钟因子消去与联合锥 | df4 | `Verification/physics/low-energy-phenomenology/alpha-source/em-identification/ActualSourcePrepared{InactiveSchurReturn,Schur97NoetherFraction,Schur97WardSchur,Schur97WardDeterminant,Schur97WardFactor,Schur97JointCone}.lean`（回执 `actual_source_prepared_em_enclosure_certification.json`） | S17.1–S17.3 |
| 定理 7.12 四维曲率强积分与 $\operatorname{Dom}(H_{\rm time})$ 词 Gram | 7e4 | `Lean/SaturationMonoid/PhysicsCore/YangMills/SourceQuantum/Curvature/Spatial/{Seed,Field,Words,Original}.lean`、`Continuum/Spacetime/Strong/Spatial/{Field,Time}.lean`（回执 `Verification/physics/yang-mills/source-quantum/source_spatial_curvature_receipt.json`） | S17.4 |
| 定理 9.3(1)–(4) 五位置根封印、零未登记权威与折叠 | H | `Lean/SaturationMonoid/PhysicsCore/StageTenPhysicalRootClosure.lean`、`Stage10/{Authority,Seal,Recovery/Consumer}.lean`（`stageTenPhysicalRootClosure`、`zeroUnregisteredPhysicalAuthorityReceipt`、`completePremiseFold`、`stageOneThroughTenClosed`；§10.4 源内单位与耦合读口见 df4 之 `alpha-source/SourceElectronThomsonIdentity.lean` 及 `alpha-source/em-identification/{PhysicalNativeEMChargeBridge,ActualDressedEMStandardLongRange,PhysicalN3PoleCoulombPacket}.lean`） | §9.2 |
| 定理 10.1 全词 Kraus–Born 等距与开放密度迹恒等 | B291、B300 | `Verification/physics/stage10/independent-bell/munich/readout-domain/evidence/source-kraus-word-wave-rha0291/source-r0004/SourceKrausWordWave291.lean`（`sourceIsometry`）、`source-endpoint-recycling-rha0300/density-source-r0001/SourceEndpointDensity300.lean`（`whole_word_trace_hasSum`、`densityFlow_positive`、`densityFlow_trace_nonincreasing`） | S18.1–S18.2 |

§10.4 的直接消费者另含 `SourceThomsonMatchingConsumer.lean` 的 `sourceThomsonMatching_return`、`ActualDressedEMCorrectedRootFluxConsumer.lean` 的 `actual_full_root_coupling_balance`，以及 `PhysicalN3PoleCurrentAudit.lean` 的原作用电流与完整接触项核对。公开选集逐组登记原编译依赖，电磁公共底层固定在 `2cccd55f330ed2465ba8d43779e6f75e42274e37`。

<!-- code-availability:begin -->
## 代码与数据可得性

第三版公开选集固定于 H0mework 提交 `a5e774a4cdef1c5bedc7426efedab7ba20a417ac`。[逐主张映射](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-map.json)与[固定选集](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/checks/physics-third-edition-selection.json)登记 P45–P47 的完整声明类型、直接消费者和原回执。[验收](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-readiness.md)和[复现指南](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-reproduction.md)记录本版实际构建与信任闭包。

第一版继承条目的证明与消费者采用 H0mework 固定提交 `234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a`；[首发映射](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/docs/first-release-map.json)和[首发复现指南](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/docs/first-release-reproduction.md)保持原范围。

第二版新增材料登记于 H0mework 固定提交 `b9d66048342b1a5aeac3e112d920ed85401bb20a`，逐项来源与公开包对应见[第二版映射](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/second-edition-map.json)、[材料与验收](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/second-edition-readiness.md)及[已发布绑定清单](https://github.com/Sapientropic/H0mework/blob/e9734c69f38cf03b79859a1108ae23a5663a0495/docs/assets/paper-source-binding-b9d66048.json)（源仓上限 Homework `9c73a630ce05bea062ec889b188f5105c0afb796`）。第三版（v3）补入的谱选择、引力—规范不可分、四腿临界等价、Volterra／全阶能量闭合及零未登记权威取自首发使用的源仓固定提交 H（`e60a86058abcb74b7f2225f2383c182be8343785`）；192/97 电磁消因子分式采用 Homework `df421ff600085cbc290a7ae946193961bed7c83b` 的固定收稿源码及原认证的底层依赖，全词 Kraus–Born 等距和开放循环密度迹对偶分别采用 B291 与 B300，四维连续曲率强积分固定于 Homework `7e4da746f300b3796b8b18afb26cb0765c29afcb`（详见附录 B.7、D.9 与补充材料 S16–S18）。

第二版选集的工具链与复现命令见[复现指南](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/edition-reproduction.md)：运行 `python3 tools/edition_release.py --edition second verify-map` 核对映射身份，使用 `build` 与 `trust` 子命令执行包构建与完整声明闭包审核。H0mework 证明材料采用 Apache-2.0 许可；第三方归属及可逆公开变换见 [NOTICE](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/NOTICE) 与[字节合同](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/evidence-publication.md)。
<!-- code-availability:end -->

## 参考文献

1. C. N. Yang, R. L. Mills. Conservation of Isotopic Spin and Isotopic Gauge Invariance. *Physical Review*, 96(1):191–195, 1954. DOI: 10.1103/PhysRev.96.191.
2. S. Deser. Self-interaction and gauge invariance. *General Relativity and Gravitation*, 1:9–18, 1970. DOI: 10.1007/BF00759198. 作者重刊：arXiv:gr-qc/0411023.
3. J. F. Plebański. On the separation of Einsteinian substructures. *Journal of Mathematical Physics*, 18(12):2511–2520, 1977. DOI: 10.1063/1.523215.
4. H. Tasaki. *Introduction to the “second quantization” formalism for non-relativistic quantum mechanics: A possible substitution for Sections 6.7 and 6.8 of Feynman’s “Statistical Mechanics”*. arXiv:1812.10732, 2018; v5, 2023.
5. J. F. Clauser, M. A. Horne, A. Shimony, R. A. Holt. Proposed Experiment to Test Local Hidden-Variable Theories. *Physical Review Letters*, 23(15):880–884, 1969. DOI: 10.1103/PhysRevLett.23.880.
6. K. G. Wilson. Confinement of quarks. *Physical Review D*, 10(8):2445–2459, 1974. DOI: 10.1103/PhysRevD.10.2445.
7. L. Smolin. The Plebanski action extended to a unification of gravity and Yang–Mills theory. *Physical Review D*, 80:124017, 2009. DOI: 10.1103/PhysRevD.80.124017. arXiv:0712.0977, v2, 2008；本文比较其 §2、式 (4)、(26)、(31)–(35)。
8. S. Storz et al. Loophole-free Bell inequality violation with superconducting circuits. *Nature*, 617:265–270, 2023. DOI: 10.1038/s41586-023-05885-0.
9. S. Storz. *Loophole-free Bell inequality violation with superconducting circuits* [数据集]. ETH Research Collection, 2023-07-26. DOI: [10.3929/ethz-b-000624026](https://doi.org/10.3929/ethz-b-000624026). 数据身份及测量语义的固定保管记录见附录 D.4。
10. L. K. Shalm et al. Strong Loophole-Free Test of Local Realism. *Physical Review Letters*, 115:250402, 2015. DOI: 10.1103/PhysRevLett.115.250402. 本文使用其公开装置文档与补充材料 Table S-II。
11. W. Rosenfeld et al. Event-Ready Bell Test Using Entangled Atoms Simultaneously Closing Detection and Locality Loopholes. *Physical Review Letters*, 119:010402, 2017. DOI: 10.1103/PhysRevLett.119.010402. 原完整试次的官方档案：Zenodo record 22936124。
12. R. S. Garthoff. *Optimierte Erzeugung und Nachweis von Atom-Photon-Zuständen zur Verschränkung Räumlich Getrennter Atome*. Masterarbeit, Ludwig–Maximilians–Universität München, 2015. 原件：https://xqp.physik.uni-muenchen.de/publications/files/theses_master/master_garthoff.pdf.
13. R. S. Garthoff. *Efficient Single Photon Collection for Single Atom Quantum Nodes*. Dissertation, Ludwig–Maximilians–Universität München, 2021. DOI: [10.5282/edoc.28956](https://doi.org/10.5282/edoc.28956).
14. P. A. M. Dirac. Generalized Hamiltonian Dynamics. *Canadian Journal of Mathematics*, 2:129–148, 1950. DOI: 10.4153/CJM-1950-012-1.
15. B. S. Cirel'son. Quantum generalizations of Bell's inequality. *Letters in Mathematical Physics*, 4:93–100, 1980. DOI: 10.1007/BF00417500.
16. H. Georgi, S. L. Glashow. Unity of All Elementary-Particle Forces. *Physical Review Letters*, 32(8):438–441, 1974. DOI: 10.1103/PhysRevLett.32.438.
17. S. L. Adler. Axial-Vector Vertex in Spinor Electrodynamics. *Physical Review*, 177(5):2426–2438, 1969. DOI: 10.1103/PhysRev.177.2426.
18. J. S. Bell, R. Jackiw. A PCAC puzzle: $\pi^0\to\gamma\gamma$ in the $\sigma$-model. *Il Nuovo Cimento A*, 60(1):47–61, 1969. DOI: 10.1007/BF02823296.
19. C. Bouchiat, J. Iliopoulos, Ph. Meyer. An anomaly-free version of Weinberg's model. *Physics Letters B*, 38(7):519–523, 1972. DOI: 10.1016/0370-2693(72)90532-1.
20. A. H. Chamseddine, A. Connes. The Spectral Action Principle. *Communications in Mathematical Physics*, 186(3):731–750, 1997. DOI: 10.1007/s002200050126. arXiv:hep-th/9606001.
21. T. W. B. Kibble. Lorentz Invariance and the Gravitational Field. *Journal of Mathematical Physics*, 2(2):212–221, 1961. DOI: 10.1063/1.1703702.
22. D. W. Sciama. The Physical Structure of General Relativity. *Reviews of Modern Physics*, 36(1):463–469, 1964 (Erratum: 36:1103, 1964). DOI: 10.1103/RevModPhys.36.463.
23. S. Holst. Barbero's Hamiltonian derived from a generalized Hilbert–Palatini action. *Physical Review D*, 53(10):5966–5969, 1996. DOI: 10.1103/PhysRevD.53.5966. arXiv:gr-qc/9511026.
24. S. Coleman, J. Mandula. All Possible Symmetries of the $S$ Matrix. *Physical Review*, 159(5):1251–1256, 1967. DOI: 10.1103/PhysRev.159.1251.
25. B. S. DeWitt. Quantum Theory of Gravity. I. The Canonical Theory. *Physical Review*, 160(5):1113–1148, 1967. DOI: 10.1103/PhysRev.160.1113.
26. D. N. Page, W. K. Wootters. Evolution without evolution: Dynamics described by stationary observables. *Physical Review D*, 27(12):2885–2892, 1983. DOI: 10.1103/PhysRevD.27.2885.
27. K. Osterwalder, R. Schrader. Axioms for Euclidean Green's functions. *Communications in Mathematical Physics*, 31(2):83–112, 1973; II, *ibid.*, 42(3):281–305, 1975. DOI: 10.1007/BF01645738, 10.1007/BF01608978.
28. M. Born. Zur Quantenmechanik der Stoßvorgänge. *Zeitschrift für Physik*, 37(12):863–867, 1926. DOI: 10.1007/BF01397477.
29. A. M. Gleason. Measures on the Closed Subspaces of a Hilbert Space. *Journal of Mathematics and Mechanics*, 6(6):885–893, 1957. DOI: 10.1512/iumj.1957.6.56050.
30. K. Kraus. General state changes in quantum theory. *Annals of Physics*, 64(2):311–335, 1971. DOI: 10.1016/0003-4916(71)90108-4.
31. V. Gorini, A. Kossakowski, E. C. G. Sudarshan. Completely positive dynamical semigroups of $N$-level systems. *Journal of Mathematical Physics*, 17(5):821–825, 1976. DOI: 10.1063/1.522979.
32. G. Lindblad. On the generators of quantum dynamical semigroups. *Communications in Mathematical Physics*, 48(2):119–130, 1976. DOI: 10.1007/BF01608499.
33. E. Witten. String theory dynamics in various dimensions. *Nuclear Physics B*, 443(1–2):85–126, 1995. DOI: 10.1016/0550-3213(95)00158-O. arXiv:hep-th/9503124.
34. C. Cheung, G. N. Remmen, F. Sciotti, M. Tarquini. Strings from Almost Nothing. *Physical Review Letters*, 136(25):251601, 2026. DOI: 10.1103/cw4p-cqh7. arXiv:2508.09246v2；本文比较其引言、式 (5) 后零点说明及式 (11)。
35. S. Kachru, R. Kallosh, A. Linde, S. P. Trivedi. De Sitter vacua in string theory. *Physical Review D*, 68(4):046005, 2003. DOI: 10.1103/PhysRevD.68.046005. arXiv:hep-th/0301240；本文比较其 §IIA–C 与式 (12)–(14)。
36. L. Susskind. The Anthropic Landscape of String Theory. arXiv:hep-th/0302219, 2003（收录于 B. Carr 编 *Universe or Multiverse?*, Cambridge University Press, 2007, pp. 247–266；本文比较原稿 §§5–6）。
37. R. Bousso. Holographic probabilities in eternal inflation. *Physical Review Letters*, 97(19):191302, 2006. DOI: 10.1103/PhysRevLett.97.191302. arXiv:hep-th/0605263；本文比较其式 (2)–(4) 与图 1 终端真空算例。
38. T. Banks, W. Fischler, S. H. Shenker, L. Susskind. $M$ theory as a matrix model: A conjecture. *Physical Review D*, 55(8):5112–5128, 1997. DOI: 10.1103/PhysRevD.55.5112. arXiv:hep-th/9610043.
39. A. Strominger, C. Vafa. Microscopic origin of the Bekenstein–Hawking entropy. *Physics Letters B*, 379(1–4):99–104, 1996. DOI: 10.1016/0370-2693(96)00345-0. arXiv:hep-th/9601029.
40. J. M. Maldacena. The Large-$N$ Limit of Superconformal Field Theories and Supergravity. *Advances in Theoretical and Mathematical Physics*, 2(2):231–252, 1998. DOI: 10.4310/atmp.1998.v2.n2.a1. arXiv:hep-th/9711200.
