# Supplement: Complete Proofs

**From a Single Occurrence Source to a Continuous–Quantum Unified Field: Ten-Stage Closure and Universal Formation in a Spin×SU(7) Theory**

**Author: Jian Gao (高健)**

This Supplement provides complete, self-contained written proofs and verification notes for §4.3 (Theorems 4.6–4.7), §6.3–§6.5 (Theorems 6.7–6.11), §7.1–§7.5 (Theorems 7.1–7.12), and §10.1–§10.2 (Theorem 10.1, Propositions 10.2–10.5) of the main text. Sections S1–S9 cover the first-edition quantum construction and public experimental consumers; S11–S15 cover the second-edition CAR created state, nonlinear half-axis differentiability, nine-constraint Schur feedback, fourth-order holomorphic infrared return, emergent long-range potential, charged three-fermion positive spectrum, and 120 ns full-gate recovery; S16–S18 supply complete written proofs for the third-edition (v3) Volterra uniqueness and derivative-loss-free symmetric-hyperbolic all-order energy closure, 192/97 electromagnetic clock-factor cancellation and 4D curvature strong integration, and whole-word Kraus–Born isometry with open recycling density trace duality; S10 gives the three-edition claim and proof-location concordance. Proofs for §2–§4.2, §5, §6.1–§6.2, and §8–§9 appear in full in the main text and Appendices A–C (including Appendix B.8 for Theorem 3.3 and Appendix C.9 for Theorem 9.4).

The “Formal correspondence” note at the end of each section names the Lean 4 declarations or frozen receipts carrying the result; full commits, paths, and public reproduction entry points appear in Appendices B.7, C.8, D.7–D.9, and Code and data availability. Full SHA-1 hashes for fixed commit aliases **H**, **F**, **AB**, **AC**, **AD**, **AE**, **CAP**, **71e**, **9c73**, **df4**, **7e4**, **B291**, and **B300** are given in Appendices D.1, D.7, and D.9. Every numbered theorem is proved decisively within this paper and delegates nothing to unpublished companion manuscripts.

The [fixed third-edition proof map](https://github.com/Sapientropic/H0mework/blob/a5e774a4cdef1c5bedc7426efedab7ba20a417ac/docs/physics-third-edition-map.json) records complete declaration types, direct consumers, and original receipts.

Verification credentials are classified into five explicit types: **formal theorems** (Lean 4 strict-kernel declarations), **finite exact computations** (finite identities decided inside the proof kernel), **fixed exact source programs with independent recomputation** (exact symbolic/algebraic programs paired at the same commit with zero-shared-code recomputations), **dual-implementation numerical verifications** (independent primary and secondary implementations producing frozen receipts with explicit error bounds), and **statistical contracts** (anytime-valid tests under pre-registered $\alpha$-budgets).

---

## S0 Common Notation and Tools

**S0.1 Configuration and test spaces.** Fix $S_0$ and the common action (3.1) on the connected component $\mathscr U_{103}=\mathscr U_q\times\mathscr U_x\times\mathbb R^{36}$ where $v_e>0$, $\det h\ne0$, $g_{00}\ne0$, $h^{00}\ne0$, $\det D_9\ne0$, and the $4\times4$ temporal–electric block $\det\mathscr M\ne0$; write $\mathscr U_{100}$ for the three-stabilizer section (S1). Let $\mathcal I=\{+,-\}\times\{0,1,2,3\}\times(\Lambda^6\sqcup\Lambda^2\sqcup\Lambda^4)$ ($|\mathcal I|=504$) and $\mathcal F_{504}=\Lambda^*\mathbb C^{504}$. The configuration Hilbert space $\mathscr H$ is given by the weighted $L^2$ direct sum (S1.5), in which $\mathcal Q=C_c^\infty(\mathscr U_{100};\mathcal F_{504})$ is dense.

**S0.2 Truncation compressions and retained terms.** For a finite frame index $F$ of the Gauss unitary history, $C_F(p)$ denotes the self-adjoint compression of the native Hamiltonian $H_0$ at momentum $p$, $A_F$ the uncut Yukawa operator on the finite retained set, and $K_F(p)=C_F(p)+A_F$ the truncated generator ($C_F$ preserves $\Lambda^6$ grading; $A_F$ raises it by $1$). Write $T_p(t)=e^{-itK_F(p)}$ and $R_p(z)=(K_F(p)-z)^{-1}$ ($\operatorname{Im}z\ne0$). Truncation indices are directed by inclusion; a property holds “for cofinal $F$” if it holds for all $F$ beyond some index along the source filter.

**S0.3 Response points and the five-factor kernel.** A **response point** $q$ carries $(F,p_L,p_R,z,w,\varepsilon,T)$ ($\operatorname{Im}z\ne0,\operatorname{Im}w\ne0,\varepsilon>0$) and a source field curve. With quantized first-variation current port $J$, the five-factor kernel is

$$\mathcal K_q(t)=T_{p_R}(-t)\,R_{p_R}(z)\,J\,R_{p_L}(w)\,T_{p_L}(t).\tag{S0.1}$$

$\mathbb C^{289}$ is the complexified space of real variations across the nine fields, and $H_{289}(p)$ is the second-variation matrix at four-complex momentum $p$ (S5).

**S0.4 Resolvent and Duhamel identities.** Self-adjoint $A$ satisfies $\|(A-z)^{-1}\|\le|\operatorname{Im}z|^{-1}$ and $R_p-R_k=R_p(C_F(k)-C_F(p))R_k$; operator-norm Duhamel gives $e^{-itB}-e^{-itA}=-i\int_0^t e^{-i(t-s)B}(B-A)e^{-isA}ds$; and for $\Phi_t(X)=T_{p+k}(-t)XT_p(t)$, $\int_0^\infty e^{-\lambda t}\Phi_t\,dt$ converges absolutely in Bochner norm for all $\operatorname{Re}\lambda>0$ under polynomial time growth.

**S0.5–S0.6 Kernel verification of finite exact identities and data-bearing statements.** Finite identities such as the 3071-entry dictionary of $H_{289}$ over $\mathbb Q(\sqrt2,\sqrt{15})$, the 576 polynomial matrix inverse entries, and 289-dimensional matrix identities are proved inside the Lean 4 kernel via canonical table equality (`decide +kernel`), algebraic ring tactics (`ring`, `norm_num`, `field_simp`, `linear_combination`), and `fin_cases`, with zero floating-point approximations. Dual-implementation numerical and statistical clauses cross-check frozen primary and independent receipts under pre-registered criteria (S9, S15).

---

## S1 Theorem 6.7: Common Quantum Hamiltonian

**Objects and domain.** Fix $S_0$ and (3.1) on $\mathscr U_{103}$ (S0.1). Matter consists of the 252-dimensional spinor–exterior field $\psi$ and independent dual $\chi$; dimensions $61,504,103,100,392$ are fixed uniquely by the source representations.

**(1) Canonical carrier (61 CCR pairs and 504-mode two-branch CAR).**
- *Four-sector Legendre map*: when $\det h\ne0$ ($h=e_{\rm sp}^{\mathsf T}\eta e_{\rm sp}$), an explicit rank-six right inverse yields the coframe six-velocity relations
  $$\Pi_e=M_e\dot e+b_e,\qquad Z^{\mathsf T}(\Pi_e-b_e)=0,\qquad \dot e=Q_e(\Pi_e-b_e)+Z\lambda,\tag{S1.1}$$
  where $M_e=D_h^{\mathsf T}B_hD_h$, $B_h=(4v_e)^{-1}\operatorname{Hess}_h\det h$, $Q_e=R_hB_h^{-1}R_h^{\mathsf T}$, and the ten columns of $Z$ encode four temporal and six internal Lorentz primary constraints. Scalar momentum is $\Pi_\phi=h^{00}(\dot\phi+\rho^{70}_{A_0}\phi)+b_\phi$ ($h^{00}\ne0$); spatial gauge momentum inverse is $K_E^{-1}=-\tfrac{\sigma v_e}{g_{00}}(g^{-1})_{\rm sp}$ (twelve temporal momenta vanish); and matter conjugate momentum is $p=-i\chi E$ ($E=v_e(e^{-1})^0{}_a i\gamma^a\otimes I_{63}$, without tying $\chi=\psi^\dagger$). The common canonical $1$-form is
  $$\Theta=\Pi_e\cdot\delta e+\Pi_\phi\cdot\delta\phi+\sum_i\Pi_A^i\cdot\delta A_i+\operatorname{Re}(ip\,\delta\psi),\tag{S1.2}$$
  with twelve-dimensional Gauss constraint $\mathcal G=\mathcal G_A+\Pi_\phi^{\mathsf T}\rho^{70}\phi+\operatorname{Re}(ip\,\rho^{252}\psi)$.
- *61 scalar CCR pairs*: the gauge–scalar orbit matrix $O\in\mathbb R^{70\times12}$ has rank $9$ ($\det D_9=256$ at the source for $D_9=O_b^{\mathsf T}O_b$); choosing an orthogonal basis $R\in\mathbb R^{70\times61}$ of $\ker O^{\mathsf T}$ and setting $\phi=v+Rx$, $\Pi_\phi=R^\vee\pi+O_b\zeta$ ($R^\vee=R(R^{\mathsf T}R)^{-1}$) pulls the scalar part of $\Theta$ back via $O_b^{\mathsf T}R=0$ to $\pi\cdot\delta x$, yielding 61 standard CCR pairs $[x_j,-i\partial_{x_k}]=i\delta_{jk}$.
- *504-mode two-branch CAR*: real coordinates $(\operatorname{Re}\psi,\operatorname{Im}\psi)$ and conjugate momenta $(-\operatorname{Im}p,-\operatorname{Re}p)$ of $\operatorname{Re}(ip\,\delta\psi)$ form two real branches whose single complexification quantizes over $\mathcal I$ ($|\mathcal I|=504$) into one standard CAR algebra, with gauge current $Q_a=\operatorname{diag}(i\rho_a^{252},i\overline{\rho_a^{252}})$ and matter Hamiltonian $\operatorname{diag}(M,-\overline M)$.
- *103-dimensional energy core*: the $6+61+36=103$ bosonic coordinates sum the four sector energies on
  $$\mathscr D_{103}=C_c^\infty(\mathscr U_{103};\mathbb C)\otimes\mathcal F_{504},\tag{S1.3}$$
  preserving arbitrary finite ordered compositions (including 944 nonzero cross-principal entries and 61 Yukawa force directions).

**(2) Three-stabilizer section, second-class measure cancellation, and common Hamiltonian.**

> **Lemma S1.1 (Kernel stabilizer commutation).** The three stabilizer generators $S_a$ spanning $\ker O$ ($[S_a,S_b]=-2\epsilon_{abc}S_c$) generate operators $\widehat G_a$ on $\mathscr D_{103}$ satisfying $[\widehat G_a,\widehat H]=0$, whose joint kernel is nontrivial and invariant under all finite compositions of the four-sector energy.

*Proof.* From $V_aD_9=-C_a^{\mathsf T}D_9-D_9C_a$ one obtains $V_a F=C_a F+FC_a^{\mathsf T}$ ($F=D_9^{-\mathsf T}$), cancelling normal-coefficient and current-matrix variations slot by slot inside ordered squared momenta; gauge and coframe invariance follow from Gram invariance and spinor–exterior commutativity, with $|(7,259)\rangle$ times a bump function witnessing a nonzero kernel state. ∎

At the source point, the three gauge pivots have local orbit determinant $\det M_*=-54\sqrt2/125\ne0$, giving via the inverse function theorem a 100-dimensional open section $\mathscr U_{100}$ with extension $\mathcal E$ and restriction $\mathcal R$ ($\mathcal R\mathcal E=I$, $\widehat H\mathcal E=\mathcal E H_{100}$). The orbit Jacobian supplies positive weight $\rho_3(z)=8a_1^2a_{12}>0$ ($54\sqrt2/125$ at the source), while the base volume, normal Gaussian momentum integral, and second-class determinant across the nine second-class scalar constraints cancel identically:

$$\frac1{256}\cdot\frac{256}{|\det D_9|}\cdot|\det D_9|=1.\tag{S1.4}$$

Assigning volume weight $v^{m+2}$ to the $m$-particle sector defines

$$\langle f,g\rangle=\sum_{w\subset\mathcal I}\int_{\mathscr U_{100}}\overline{f_w(z)}\,g_w(z)\,\rho_3(z)v(z)^{m+2}\,dz,\qquad \mathscr H=\bigoplus_{w\subset\mathcal I}L^2\bigl(\mathscr U_{100},\rho_3 v^{|w|+2}dz\bigr),\tag{S1.5}$$

with surjective half-density isometry $(Uf)_w=\rho_3^{1/2}v^{1+m/2}f_w$ onto flat Lebesgue measure.

> **Lemma S1.2 (Formal adjoint pair and minimal closed graphs).** On the dense invariant core $\mathscr D_{100}$, $H_0$ is formally symmetric, while $H=H_0+Y$ and $H^\sharp=H_0+Y^\dagger$ satisfy $\langle f,Hg\rangle=\langle H^\sharp f,g\rangle$ and are both closable with single-valued minimal graph closures; the $196\times2=392$-mode two-sided Yukawa kernel reduces $H_0$ to a symmetric operator.

*Proof.* Integration by parts verifies symmetry of $H_0$ under $v^{m+2}$; only unidirectional $Y$ conjugates to $Y^\dagger$ ($\|Y|144,396\rangle\|^2=4N^2=216/125\ne0$). If $f_n\to0$ and $Hf_n\to g$, then $\langle h,g\rangle=\lim_n\langle H^\sharp h,f_n\rangle=0$ for all $h\in\mathscr D_{100}$, forcing $g=0$ by density of $\mathscr D_{100}$. Half-density conjugation $UHU^{-1}=\operatorname{Op}_W(\sigma_0+Y)$ (merging coframe divergence and half-density potential into $N(3\mathrm{Number}^2+18\mathrm{Number}+20)/(16v)$) generates all 100 CCR and 504 normal-ordered CAR Heisenberg ports. ∎

**(3) Configuration coupling identification.** Scalar Gram generates $4W(q)\ge4$, and $K(p)$ satisfies slot by slot on $\mathbb C^{289}$

$$S_{\rm phys}(p)+Y=S_{\rm nat}+S_{\rm cf}+K(p)-K_{\rm ret},\tag{S1.6}$$

which is Eq. (6.3) of the main text.

**Formal correspondence.** Sub-results of Theorem 6.7(1)(2) are fixed across four constrained-quantization commits (`ecd/` = `Verification/physics/low-energy-phenomenology/external-composite-decay/`, full hashes in Appendix D.7):

| Sub-result | Commit | Producer and independent verification | Credential |
| --- | --- | --- | --- |
| 61 CCR, 103-dim core, 504-mode CAR | `85cb5386...` | `ecd/source_{scalar_gauss_reduction,joint_local_quantum}.py` & `independent_*.py` | Exact source program + independent recomputation |
| 3-stabilizer commutation (Lemma S1.1) & pivots | `f9b73392...` | `ecd/source_{quantum_stabilizer,stabilizer_phase_reduction}.py` & `independent_*.py` | Exact source program + independent recomputation |
| Section, (S1.4), half-density $\mathscr H$, Lemma S1.2 & Weyl | `6726f385...` | `ecd/{SecondClassReduction,SourceQuantumConfigurationHilbert,SourceQuantumHalfDensityHilbert,FockFilteredWords,SymmetricGraphClosure,AntiunitaryDefectPair}.lean`; `ecd/source_{quantum_gauss_section,gauss_section_measure,full_gauss_section,yukawa_reducing_carrier,common_weyl_symbol}.py` & `independent_*.py` | Lean formal theorem + exact program & recomputation |
| 100 CCR & 504 CAR Heisenberg ports | `eec031c4...` | `ecd/JointCCRCarPorts.lean`; `ecd/source_joint_ccr_car_ports.py` & `independent_*.py` | Lean formal theorem + exact program & recomputation |

Theorem 6.7(3): `alpha-source/CanonicalPreparationActionCoreDecomposition.lean` (`physical_action_decomposition`) and `CanonicalPreparationFieldQuantization{Symbols,Core,Contacts}.lean` (commit AB).

---

## S2 Theorem 6.8: All-Order Clock, Complete Fixed `R`, and Common Source Preparation

**Objects and domain.** $\mathscr H$, $\mathscr D_{100}$, $H=H_0+Y$, and the invertible $4\times4$ temporal Jacobian $J_4$ on the source support cone.

**(1) All-order clock recursion.** The $k$-th order clock symbol over four temporal directions and $k+1$ slots starts from the source seed at $k=0$ and recurses via

$$C_{k+1}(a,\mathrm{last})=-\sum_b (J_4^{-1})_{ab}\,R_{k+1,b},\tag{S2.1}$$

where $R_{k+1,b}$ is built from 42 paid lower-order slot functions, ordered Moyal words, and 13 temporal leaves.

> **Lemma S2.1 (Force cancellation and lower-order preservation).** For every $k\ge0$, $C_{k+1}$ agrees identically with $C_k$ on the first $k+1$ slots, annihilates all four $(k+1)$-st successor forces via $r+J_4(-J_4^{-1}r)=0$ on the closed support, and preserves finite-order derivative budgets across all 100 coordinates. ∎

**(2) Complete fixed `R`.** On Schwartz inputs, the full energy form splits into principal part plus integrable tail:

$$\mathcal E_B(g,f)=\mathcal E_{\rm prin}(g,f)+\mathcal E_{\rm tail}(B;g,f),\qquad R=E_{\rm tail}-C_{\rm src}.\tag{S2.2}$$

> **Lemma S2.2 (Bounded self-adjointness of $R$ and Weyl readback).** Row/column $L^1$ bounds $S_1,S_2$ of the shifted tail kernel give $\|E_{\rm tail}\|\le\sqrt{S_1S_2}$ by Schur's test, so $R$ is bounded self-adjoint ($\|R\|\le\|E_{\rm tail}\|+\|C_{\rm src}\|$), satisfies
> $$\langle Ag,Af\rangle+\langle g,Rf\rangle=\mathcal E_B(\check g,\check f),\tag{S2.3}$$
> and keeps $R$, $\mathcal T$, and $E$ strictly independent of $\varepsilon$. ∎

**(3) Common preparation and dual-residual vanishing.** With $B=(\mathcal T+1+\|R\|)^{-1}$ and $\|B\|\in\sigma(B)$, set

$$E=\|B\|^{-1}-\bigl(1+\|R\|\bigr).\tag{S2.4}$$

> **Lemma S2.3 (11-field common preparation point).** For every $\varepsilon>0$, pulling an approximate endpoint eigenvector of $B$ back by $B^{-1}$ yields $x_\varepsilon$ satisfying $\|v_\varepsilon\|=1$, $\|\mathcal Tx_\varepsilon-Ex_\varepsilon\|<\varepsilon$, the weak-form identity, native Yukawa charge $-1$, eight external legs, two-time/frequency convergence, and geometric cutoff bound
> $$\|Y_{\rm closed}v_\varepsilon-\mathrm{cut}_n(v_\varepsilon)\|\le(915/916)^{n+1}\cdot 916\cdot b.\tag{S2.5}$$
> Along $\varepsilon_n=1/(n+1)$, both near-spectral and full-Yukawa residuals vanish simultaneously at fixed $(\mathcal T,R,E)$. ∎

**Formal correspondence.** `alpha-source/CanonicalPreparationEngineProgram.lean` (`sourceEngine_generated`, `sourceEngine_preserves`), `CanonicalPreparationEngineCancellationForces.lean` (`sourceEngineForces_successor_zero`), `CanonicalPreparationFullEnergyForm.lean` (`actual_closed_form_complete_energy`), `CanonicalPreparationSourceRemainder.lean` (`sourceRemainder_selfAdjoint`, `sourceRemainder_readback`), `CanonicalPreparationSource{PreparedState,BoundarySequence,CausalState,NonlinearState}.lean` (`sourcePreparation_exists`, `preparationSequence_residual`, `preparationSequence_yukawa_residual`). Commit AB.

---

## S3 Theorem 7.2: Varying-Field Response, Spectral Measure, and 0/1/2-Jet Cutoff Exchange

**Objects and domain.** Carrier of Theorems 6.7–6.8, fixed $R$, $x_\varepsilon$, and smooth field curves parametrized by source coordinate slices.

> **Lemma S3.1 (Finite retained set and pointwise stabilization of truncated jets).** At each fixed curve, momentum $p$, finite frame $F$, nonreal $z$, and parameter $r$, the retained term acts solely on a finite index set depending on $(F,p)$; hence for $n\ge N$, $Y_n=Y_\infty$ identically as finite-dimensional operators, and 0-, 1-, and 2-jets of resolvents, currents, contacts, insertions, and inverse contacts converge in norm to their uncut counterparts. ∎

> **Lemma S3.2 (Exchange of prepared readouts with cutoff removal).** Joint inner-product continuity across completed external legs and truncated resolvents transfers Lemma S3.1 to values, first derivatives, and second derivatives of prepared responses and all 36 curvature readouts. ∎

**Decisive derivation.** (1) The 106-dimensional inverse transports $Jv^{m+2}$ and first/second half-density derivatives while preserving $\sum_g P_g P_F H_{\rm phys}P_F P_g$, generating the 289-component field response, $-RJR$, and second-order contact jets while cancelling moving-fibre density derivatives identically. (2) For $\gamma>0$, Laplace responses inside radius $r_*$ obey the quadratic remainder bound
$$\bigl\|\Phi(r)-\Phi(0)-r\Phi'(0)\bigr\|\le L^2\,s(f,g,\psi,p,n,\gamma)\,m(\gamma)\,|r|^2\,\|u\|^2.\tag{S3.1}$$
(3) Follows from Lemmas S3.1–S3.2. (4) For $H_0$ and core $g$, channel squared norms sum to $\|g\|^2$ at every finite filter stage, yielding a unique positive spectral measure $\mu_g$; for bounded $A$ and $\mu>0$, retarded amplitudes lie in $L^1(\mathbb R)$ in frequency and converge uniformly in real time.

**Formal correspondence.** AB: `alpha-source/CanonicalPreparationSourceNonlinearState.lean`, `CanonicalPreparationYukawaObservedLimit.lean` (`observed_{first,second}_exchange`, `curvature_{first,second}_exchange`), `CanonicalPreparationHalfDensityCompressionFeed.lean`; `external-composite-decay/Source{HamiltonianSpectralMeasure,BoundedInsertionTime}.lean`. AC: `CanonicalPreparation{SpatialFullFormFeed,JointMixedResponse,RawJointFiveTerms,OriginalPreparedGreen,PhysicalFeedbackField}.lean`.

---

## S4 Theorem 6.10: Complete Charge–Current Ward Identity and Common Preparation

> **Lemma S4.1 (Pair-fibre normal-ordering expansion on CAR).** For complex matrices $A,B$ of any mode dimension, $Q(A)=\sum_{i,j}A_{ij}c_i^\dagger c_j$ satisfies
> $$Q(A)Q(B)=Q(AB)+\Pi(A,B),\qquad \Pi(A,B)=\sum_{i,j,k,l}A_{ij}B_{kl}\,c_i^\dagger c_k^\dagger c_l c_j,\tag{S4.1}$$
> where $\Pi(A,B)$ commutes with all occupation weights and satisfies $\Pi(A,B)\big|_{N=1}=0$ on the one-particle sector.

*Proof.* Expand $c_j c_k^\dagger=\delta_{jk}-c_k^\dagger c_j$ and $c_j c_l=-c_l c_j$. ∎

**Decisive derivation.** (1) Applying Lemma S4.1 fibrewise to $P_k(z)$ and $Q_a$ yields Eq. (6.5) $P(k)Q_a=J_{\rm sp}(k,a)+J_{\rm pair}(k,a)$ with $J_{\rm pair}=0$ on $\Lambda^1$. (2) Unprojected $[Q_a,H_{\rm full}]$ retains all four channels:
$$[Q_a,H_{\rm full}]=J_{\rm cfg}(a)+J_{\rm sp}(a)+J_{\rm pair}(a)+J_Y(a),\tag{S4.2}$$
with compression defects vanishing on cofinal $F$ and two-resolvent responses read on $x_\varepsilon$ obeying
$$\|\mathrm{resp}\|\le\|x\|\bigl(c_a b_n(w)+b_n(z)c_a+|z-w|v_a(n,z,w)\bigr)\|y\|.\tag{S4.3}$$
(3) Twelve temporal directions generate bounded $Q$, cancelling $-rQ$ drifts between bare generator and retained kernel, with $\sum_i P_i^\dagger(c_i f)=-Q$ on the 106-dimensional orbit graph.

**Formal correspondence.** `alpha-source/CanonicalPreparationElectric{PairCurrent,CoreWard,WeightedGraph,PreparedWard}.lean`, `CanonicalPreparationTemporalGlobalCharge.lean` (commit AB).

---

## S5 Theorem 7.1: Mother-Action Second Variation Recovers `H_289`

> **Lemma S5.1 (Smoothness and four-sector quadratic decomposition).** Generated smoothly by twelve support nodes at Construction 4.1, the Fréchet second variation splits into 1650 quadratic monomials across gravity (234), gauge (406), scalar (220), and Dirac–dual (790), with all 95 constants traced to $S_0$.

> **Lemma S5.2 (3300 two-leg Fourier contributions merge to the 3071-entry dictionary).** Collecting like terms among the 3300 signed Fourier legs over $\mathbb Q(\sqrt2,\sqrt{15})$ matches the 3071-entry dictionary of $H_{289}(p)$ identically (`decide +kernel` and ring identities).

> **Lemmas S5.3–S5.4 (289-slot Euler pullback and five-block Legendre readback).** Pulling back the nine residuals along all 289 unit directions equals value-minus-divergence slot by slot; verifying the two-sided inverse $K$ of $\tfrac12\omega^{\mathsf T}\mathcal H\omega$ across 576 polynomial products and substituting $\Omega=-KJ$ alongside coframe Legendre transformation and 8-direction Clifford CAR normal ordering cancels $\mathrm{Number}^2$ cross-terms to recover kinetic, current, spin-squared, $-\tfrac{9\,\mathrm{lapse}}{8V}\mathrm{Number}$, and volume-potential blocks. ∎

**Formal correspondence.** `alpha-source/CanonicalSourcePropagation{OriginalHessianReturn,PreparedMotherEulerReturn}.lean` (`nativeActionFourierHessian_original`, `nativeJacobi_original`, `nativeHolonomicEuler_raw`). Commit AD.

---

## S6 Theorem 7.4: Five-Factor Half-Axis Return, Imaginary Spectrum, and Causal Inverse

**Objects and mother Green identity.** With $\mathcal P_q(\lambda)X=\lambda X+\mathcal A_L X-X\mathcal A_R$ ($\mathcal A_L=-iK_F(p+k),\mathcal A_R=-iK_F(p)$), on the nonempty 103-dimensional active regular domain (`decide +kernel` rational right inverse),

$$G=\Xi\,\bigl(D^{-1}+P_a K_{\rm ext}^{-1}\bigr)\,\Xi(-p)^{\mathsf T},\qquad H_{289}\,G=I-\Xi(-p)^{-\mathsf T}P_{\rm null}\Xi(-p)^{\mathsf T}.\tag{S6.1}$$

**(1)–(2) Finite-window integration by parts and 57-term polynomial half-axis.** Since $A_F$ raises grading by $1$ and vanishes at power $57$, Duhamel truncates at degree $56$:

$$\|T_p(t)\|\le\sum_{n=0}^{56}\bigl(|t|\cdot\|A_F\|\bigr)^n.\tag{S6.2}$$

For $\operatorname{Re}\lambda>0$ ($\eta=\operatorname{Re}\lambda/8$), $\Xi(-\lambda)^{\mathsf T}\Phi^+=\Sigma^++B_0$ with finite-window error

$$\bigl\|\Phi^+-\Phi_T^+\bigr\|\le\frac{2}{\operatorname{Re}\lambda}\,c\,e^{-(\operatorname{Re}\lambda)T/2}.\tag{S6.3}$$

**(3) Two-half-plane inverses and imaginary spectrum.** Right- and left-half-plane Laplace integrals invert $\mathcal P_q(\lambda)$ on both sides for $\operatorname{Re}\lambda\ne0$, confining $\sigma(\mathcal P_q)\subseteq i\mathbb R$, with $0\in\sigma(\mathcal P_q)$ at zero transfer.

**(4)–(5) Nonautonomous Picard evolution and the `3/16` causal anchor.** Variation of constants on $[0,T_*)$,

$$\partial_a U\big|_{a=0}=T_p(t)\int_0^t T_p(-s)\,\partial_a\mathcal G_a\big|_0(s)\,T_p(s)\,ds,\tag{S6.4}$$

splits at anchor $\lambda_0=3-g$ ($g=1/[8(1+B)]$) into Laplace current ($\le 1/16$) plus initial block ($\le 1/8$), giving

$$\|\mathcal U\|\le\tfrac1{16}+\tfrac18=\tfrac3{16}<1,\qquad \|(I-\mathcal U)^{-1}\|\le\tfrac{16}{13},\tag{S6.5}$$

hence $\det(I-\mathcal U)\ne0$ and a unique fixed point.

**Formal correspondence.** AC: `CanonicalPreparation{OriginalPreparedGreen,PhysicalFeedbackField}.lean`; AD: `CanonicalPhysicalLaplace.lean`, `CanonicalPreparationPhysical{FullHalfAxis,ControlledFieldTail}.lean`, `CanonicalSourcePropagation{AxisReadback,SourceSpectralInverse,ActualNativeHistoryReturn}.lean`; AE: `CanonicalPreparationSource{HalfAxisCurrentOperator,NativeFourierHistory,CurrentFeedbackAdjugate,AnalyticRegularPoint}.lean`.

---

## S7 Theorem 7.7: Common Moving Carrier, Momentum Continuity, and Native Static Residue

1. **Moving eight-state overlap unitarity**: $U(p)^\dagger U(p)=I_8$ ($U(0)=I_8$) and $M(p_L,p_R)[A]=U(p_L)^\dagger M(0,0)[A]U(p_R)$.
2. **Affine momentum continuity**: $C_F(p)=C_F(0)+v_F(p)$ gives $\|R_p(z)-R_k(z)\|\le|\operatorname{Im}z|^{-2}\|v_F\|\|p-k\|$ with $p$-invariant $A_F$.
3. **Punctured static pole and 114th colour cosource**: along $p_\kappa=(0,i\kappa,0,0)$, leading $-\kappa^2 S$ splits the uncleared Green function on the nonempty punctured domain into
   $$G(\kappa)f=\text{contact}+(-\kappa^2)^{-1}V_0S^{-1}V_0^{\mathsf T}f+\text{98-dim regular complement},\tag{S7.1}$$
   with $-\kappa^2\varphi(\kappa)\to E_0\bigl(-\tfrac9{125}\sqrt{30}\mathfrak w,-\tfrac{67}{72}\sqrt{30}\mathfrak w,0,0,0\bigr)$, where
   $$\mathfrak w=\tfrac{3\sqrt2}{10}(J_{21}-J_{34})=\kappa_{\rm ct}-\delta_{\rm cf}=-c_{114}(0,T),\qquad |\delta_{\rm cf}|\le\frac{\|D_0F\|\,|T|}{|\operatorname{Im}z|\,|\operatorname{Im}w|},\tag{S7.2}$$
   and $H_{289}\varphi=w_{\rm win}\iff$ all nine null cosources vanish ($R_bL=I_9$).

**Formal correspondence.** AE, CAP: `alpha-source/CanonicalPreparationSource{StaticPoleDomain,StaticOriginalGreen,StaticActualPole,ModeCurrent,ConstraintRead,ColorBoundaryWard,N1NormalWard,MovingCarrier,MomentumContinuation,FullPoleTensor,ModeContactRead,NativePoleBalance,NativePolePrice,AxisCompatibility}.lean` and five `AuditCanonicalPreparation*.lean` modules.

---

## S8 Theorem 7.10: Matched Whole-Word Budget and Renormalized Endpoint Common Tail

With $H_0=C_F+d_F$, $\sigma=\mu>0$, $n=\sqrt{54/125}$, and $C_3=UD+3iD_cU$:

1. **Matched positive source and phase absorption**: $D_cU-UD_c=2iU$ yields $J_3=R_3+6\sigma\operatorname{Im}\langle C_3w,w\rangle$ and the five-slot lower bound ($P_3(w)\le 4J_3$). Cauchy–Schwarz at $\eta=1/2$ gives $J_3-2R_3\le(96\sigma^2/n)\|w\|^2$, hence $\int_{\mathbb R}(J_3-2R_3)_+dt\le\varepsilon$ beyond $N_0$, closing the $4\times6\times2=48$ joint budget via $\|v_\varphi\|^2\le(1+\tfrac2{25}\|\mathrm{vac}\|^2)\|w\|^2+J_3/(20n)$.
2. **Renormalized second-Green $L^1(\mathbb R)$ common tail and diffusion split**: reading fixed $H_0^2 g_i$ on cofinal $F$ via $\int_{\mathbb R}(t^2+\mu^2)^{-1}dt=\pi/\mu$ ($\eta=\varepsilon\mu/(8\pi)$) and Ritt constants $(32,256)$ bounds $\int_{\mathbb R}|\mathcal E|d\omega\le\varepsilon$ across both causal ports, while $\Gamma_L(X)=\mathcal D^{\mathsf T}X+X\mathcal D-2AXA$ satisfies $\Gamma_L(1)=0,\Gamma_L(V)=18$ and $R_3=\mathcal E/\sigma^2-D_{\rm ren}/(2\sigma^2)+R_{\rm df}$.

**Formal correspondence.** AE (and `fa15016c...`): `external-composite-decay/SourceClockPhi{NativeMatchedSource,NativeMatchedGammaBudget,RenormalizedSecondGreenTail,MatchedDiffusionSource,FixedSourceJets,RittHigherGradient}.lean`.

---

## S9 Public Experimental Credentials for Propositions 10.2–10.3, 10.5, and §10.2

### S9.1 Proposition 10.5: Full Optical Source Domain and Strictly Positive Joint-95% CH

1. **Optical source domain and all-order Born closed form (formal theorem)**: under two-mode squeezed polarization parameters $(m,z,x,r,e)$, sign invariants $k=(1-2\lambda)T$, quadratic bounds, and six training intervals hold iff lawful $\lambda=(1-k/T)/2$ exists; four marginals invert linearly to covariances, and summing $\Gamma_n=O^\dagger X^{\otimes n}O$ geometrically over occupation pairs gives
   $$Q_{AB}=\frac{1}{1+n_V\,(T_A+T_B-T_AT_B)}.\tag{S9.1}$$
2. **Cover trees, held-out counterexamples, and strictly positive joint-95% CH (dual verification + statistical contract)**: primary and independent trees evaluate $81,922$ nodes each (finding 141 training-compatible held-out-violating members and 64 full-12-interval members: 41 positive and 23 negative CH). Under the $1/20$ joint budget, `NormalizedSourceBet.lean` certifies $1+2^{-k}h>0$ for
   $$h=\ell\cdot\mathrm{CH}-\varepsilon(1-\varepsilon)\min(c^{A}_{01},c^{B}_{10},c_{11}),\qquad \log E_k=W_{\rm obs}\log a_k+L_{\rm obs}\log b_k-T\log(1+2^{-k}h),\tag{S9.2}$$
   cross-checking 576 intervals and $23,040$ directional bets to confirm a nonempty joint 95% domain where every accepted source satisfies
   $$\mathrm{CH}_{N5}>1.3790180504\times10^{-6}.\tag{S9.3}$$

### S9.2 Held-Out Slices, Finite Angular Gain, and Nominal Controls of §10.2

1. **Two-cell training slices and Bob's angle shift**: 69 seamless slices trained on 00 and 11 place held-out 01 and 10 envelopes inside the published intervals:
   $$\text{01}:\,[0.00015821397237,\,0.00015855716089],\qquad \text{10}:\,[0.00015026944774,\,0.00015053199993],\tag{S9.4}$$
   while shifting Bob's angles by $-0.01^\circ$ on $\pm0.05^\circ$ boxes yields strictly positive CH gain ($>1.99\times10^{-9}$ and $>1.69\times10^{-9}$; independent Fock endpoint gain $3.8493\times10^{-9}$).
2. **Historical nominal negative controls**: ETH zero-radius rejection appears in Appendix D.4; for NIST 2015 ($0.003$ efficiency half-width), the predeclared optimal band
   $$r\in[0.30515678,0.32571200],\;\; \theta_0\in[4.727559^\circ,5.179646^\circ],\;\; \theta_1\in[-27.552834^\circ,-26.900901^\circ]\tag{S9.5}$$
   excludes all five published nominal parameters (`REPLAY_DEVIATION_EXCEEDS_PREDECLARED_BAND`).

### S9.3 Proposition 10.2: Zero-Input Tsirelson Lock, Readout Domain, and Equal-Law Quotient

1. **Cauchy–Schwarz Tsirelson bound**: writing $S_{\rm CHSH}=\langle u,v\rangle$ on $\mathbb R^4$ with $\|u\|^2=2,\|v\|^2=4$ gives $|S_{\rm CHSH}|\le\sqrt8=2\sqrt2$, attained at $\pm1/\sqrt2$.
2. **12-dim effect bijection, Munich 20,403 passage, and maximal quotient**: Bloch decomposition bijects onto the compact 12-dim domain; all $20,403$ Munich prefixes stay below $40$ under $\alpha=1/20$ (whereas the ideal zero-error point crosses $40$ at April trial 3974); rank-one factorization parameterizes equal-law regular settings by a unique nonzero inverse scale $(s,t)$, with effective gain $\ge0.36579$.

### S9.4 Proposition 10.3: Two-Probe Unique Inverse, Detector Fibre, and 12-State Pulse Image

1. **Two-probe inverse and detector fibre**: Cramer's rule inverts signed two-probe responses uniquely whenever the identification determinant is nonzero; positive-gain click effects $E_{\rm click}=dI+(1-d)\eta J$ are characterized by
   $$0\le d\le m,\qquad M-d\le k\le 1-d\qquad\bigl(m=(1-\mu-g)/2,\ M=(1-\mu+g)/2\bigr),\tag{S9.6}$$
   with unique inverse atomic effect and $\eta\lambda_{\max}(J)\ge 2g/(1+\mu+g)$.
2. **Pulse inequalities, Rabi-area ceiling, and 12-state verification**: rectangular pulse realizability ($\gamma=b-d>0$) holds iff
   $$(u^2+z^2)(b+d)^2\le(1-\mu)^2\gamma^2,\qquad (u^2+z^2)(2-b-d)^2\le(1+\mu)^2\gamma^2;\tag{S9.7}$$
   under $p_{\max}^{\rm at}\le 7\mathcal A^2/4$, gain obeys
   $$g\le\min\Bigl(1,\ \frac{(1+B)\,\eta_{\rm up}\,\bar a}{2-\eta_{\rm up}\,\bar a}\Bigr),\qquad \bar a=\min\Bigl(1,\frac{7A_{\rm up}}4\Bigr),\tag{S9.8}$$
   verified across 32 role domains on Garthoff's 12-state master equation alongside six equal-law / distinct-spectrum pairs and $41,673$ parsed local records.

**Formal correspondence (S9.1–S9.4).** Commits AB, AC, AD, AE: full paths in Appendix D.8.

---

## S10 Three-Edition Claim and Proof-Location Concordance

To facilitate comparison across Zenodo v1 (`phys.P1-P36`), v2 (`phys.P37-P40`), and the present v3 overhaul (eliminating `a/b` patch numbers and adding seven self-contained theorems), the table below maps every claim group to its v3 location and complete proof:

| Claim group | v1 / v2 IDs | Third-edition (v3) main text | Complete written proof | Commits |
| --- | --- | --- | --- | --- |
| `phys.P1-P2, P19` Nine-field solution, uniqueness & bounds | v1: 4.1–4.5 | Construction 4.1, Thms. 4.2–4.5 (§4.1–4.2) | §4.1–4.2; App. B.1–B.7 | H |
| **New in v3** Bidirectional spectral selection of $\mathfrak h_{\rm SM}$ | (Block ansatz only) | **Theorem 2.2** (§2.2) | §2.2; App. A.1, B.7 | H |
| `phys.P3, P13-P14` Exterior matter, bundle, vacuum, $B_A$ | v1: 2.2–2.5, 3.2–3.3 | Props. 2.3–2.6, 3.5; Thm. 3.4 | §2.3–2.4, §3.3; App. A.3, B.2–B.6 | H |
| **New in v3** Nonseparability, four-leg EC & `5/8` defect | (Not in main text) | **Prop. 3.2, Theorem 3.3** (§3.1–3.2) | §3.1–3.2; **Appendix B.8** | H |
| **New in v3** Volterra uniqueness & all-order energy closure | (Not in main text) | **Theorems 4.6–4.7** (§4.3) | **Supplement S16.1–S16.4** | H |
| `phys.P15` Clock–B cubic coupling & recoil | v1: 5.1–5.4 | Construction 5.1, Thms. 5.2–5.4 (§5) | §5.1–5.3 | H |
| `phys.P4-P5, P16` $4\sqrt2$ pairing & 256-dim Fock | v1: 6.1–6.6 | Def. 6.1, Thms. 6.2–6.5, Ex. 6.6 (§6.1–6.2) | §6.1–6.2; App. B.4, D.3 | H |
| `phys.P26` Common $H$, clock $R$, jets & Ward | v1: 6.7–6.10 | Thms. 6.7–6.8, 6.10, 7.2 (§6.3–6.5, §7.1) | S1–S4 | Early 4, AB, AC |
| `phys.P37` Created state, 12-dir norm. & $1/(4\pi r)$ | v2: 6.8a, 6.10a, 6.13b | **Theorems 6.9, 6.11, 7.9** (§6.4–6.5, §7.4) | S11.1–S11.6 | 71e, 9c73 |
| `phys.P27, P29-P30, P33, P36` $H_{289}$, half-axis & residue | v1: 6.11–6.13 | **Theorems 7.1, 7.4, 7.7** (§7.1–7.2, §7.4) | S5–S7 | AC, AD, AE, CAP |
| `phys.P38` Nonlinear derivative, 9-Schur & $z^4\Pi_{\rm st}$ | v2: 6.9a, 6.12a, 6.13a | **Theorems 7.3, 7.5, 7.6** (§7.2–7.3) | S12.1, S12.4, S13 | 71e, 9c73 |
| **New in v3** 192/97 fraction, Ward factor, cone & 4D curvature | (Not in main text) | **Theorems 7.8, 7.12** (§7.4–7.5) | **Supplement S17.1–S17.4** | df4, 7e4 |
| `phys.P34, P39` Matched tail & 3-fermion positive spectrum | v1: 6.14; v2: 6.15 | **Theorems 7.10, 7.11** (§7.5) | S8, S14.1, S14.3 | AE, 71e, 9c73 |
| `phys.P7-P8, P12` Orbits, Legendre, 5-point & Bell | v1: 7.1–7.4 | **Theorems 8.1–8.3, Prop. 8.4** (§8) | §8.1–8.2 | H |
| `phys.P6, P9-P11, P17-P18, P20` Family, 10-stage seal & fold | v1: 8.1–8.3, App. C | **Theorems 9.1–9.3** (upgraded with 5-pos. assembly, zero authority & fold), App. C | §9.1–9.2; App. C.1–C.8 | H |
| `phys.P22` Universal fixed-mother formation & no magic bit | v1: 8.4–8.5 | **Theorem 9.4, Cor. 9.5** (§9.3) | §9.3; App. C.9 | F |
| **New in v3** Whole-word Kraus–Born & open density duality | (Not in main text) | **Theorem 10.1** (§10.1) | **Supplement S18.1–S18.2** | B291, B300 |
| `phys.P24-P25, P28, P31-P32, P35, P40` Public Bell & 120 ns | v1: 9.1–9.3; v2: 9.4 | **Props. 10.2–10.5**, §10.2, App. D.4 | S9.1–S9.4, S15, S15.5 | AB, AC, AD, AE, 71e, 9c73 |

---

## S11 Theorems 6.9, 6.11, and 7.9: Actual Created State, Twelve-Direction Temporal Normalization, and Emergent Long-Range Potential

### S11.1 Nonzero CAR Creation Lower Bound and Unit External State

Let $c_{12}(z)$ denote coordinate $(1,2)$ of the actual scalar field: its value at the source vacuum is $1$, and inside the closed source box perturbation norms are strictly $<1/2$, giving $|c_{12}(z)|\ge 1/2$ by the triangle inequality. The unoccupied colour annihilation mode $a_{02}$ ($\|a_{02}\|\le1$) anticommutes with the other two colour creators, annihilates the seed state, and has unit anticommutator on its own colour, yielding pointwise

$$a_{02}\,\mathcal A_{10}^\dagger f=\overline{c_{12}}\,f,\qquad
\int\|f(z)\|^2\rho(z)\,dz\;\le\;4\int\|\mathcal A_{10}^\dagger f(z)\|^2\rho(z)\,dz.\tag{S11.1}$$

Extending by density to the unit background $v_\epsilon$ of Theorem 6.8 gives $\|\mathcal A_{10}^\dagger v_\epsilon\|\ge 1/2$, hence $\|g_\epsilon\|\ge 1/4>0$ for $g_\epsilon=(i/2)\mathcal A_{10}^\dagger v_\epsilon$; dividing by $\|g_\epsilon\|$ produces the unit state $u_\epsilon=g_\epsilon/\|g_\epsilon\|$ with $\|\ell_d\|\le\|u_\epsilon\|^2+\|v_\epsilon\|^2=2$.

### S11.2 Joint Standard Model Charge Characters, Twelve-Direction Normalization, and Weighted Creation Current

For any $a=(A_3,A_2,y_a)\in\mathfrak h_{\rm SM}$ ($A_3^*=-A_3,\overline{y_a}=-y_a$), the four-form creation coefficients and 504-mode CAR commutator of $L_a$ satisfy

$$c_r(a\Phi)=-\sum_s(A_3)_{sr}c_s(\Phi),\qquad [Q(L_a),a_{s,r}^\dagger]=\sum_v(A_3)_{vr}a_{s,v}^\dagger+y_a a_{s,r}^\dagger.\tag{S11.2}$$

Substituting both into $\delta_a^{\rm joint}\mathcal A^\dagger=\mathcal A^\dagger(a\Phi)-[Q(L_a),\mathcal A^\dagger(\Phi)]$ and using $\overline{(A_3)_{rs}}=-(A_3)_{sr}$ cancels the colour sums identically, leaving $-y_a\mathcal A^\dagger$ (and $+y_a\mathcal A$ for annihilation) on both the dense core and completed profile.

Across all twelve temporal directions, noncharacteristicity guarantees the canonical phase inverse of $\mathsf w_t(s)$,

$$M_{\rm ph}(s)\,[\mathsf a\,\mathsf w_t(s)]=I_{504},\tag{S11.3}$$

which right-multiplies by $C_a$ and expands via Lemma S4.1 to prove Eqs. (6.6)–(6.7). For any $504\times504$ weight $W$, setting $A_W^\dagger=[Q(W),\mathcal A^\dagger(\Phi)]$ and $A_{a,\rm sc,W}^\dagger=[Q(W),\mathcal A^\dagger(a\Phi)]$ and substituting $[Q(M),a_j^\dagger]=\sum_i M_{ij}a_i^\dagger$ with (S11.2) yields

$$[Q(WC_a),\mathcal A^\dagger(\Phi)]=iA_{a,\rm sc,W}^\dagger+i y_a A_W^\dagger,\tag{S11.4}$$

which evaluates at $W=\mathsf w_{\rm source}(z)$ on seed $q$ to give Eq. (6.8).

### S11.3 Temporal Field-Port Matching and Two-Sided Truncated Resolvent Tails

The full temporal field port $J_a$ and fixed-momentum Noether port $N_a$ satisfy $J_a=-N_a+C_a^{\rm comp}$. Writing truncated/uncut left and right inverses as $L_c,R_c,L_u,R_u$ with differences plus retained leaks $D_L,D_R$, expanding $L_c=L_u+L_cD_LL_u$ and $R_c=R_u+R_cD_RR_u$ yields

$$L_c J_a R_c=-L_u N_a R_u+L_c C_a^{\rm comp}R_c-L_c D_L L_u N_a R_c-L_u N_a R_c D_R R_u.\tag{S11.5}$$

Invariance of the $u_\epsilon,v_\epsilon$ subspace under $R_u$ kills the right leak, and finite-frame stabilization gives bilinear convergence across all 289 ports.

### S11.4 Same-Density Electromagnetic Pole Idempotence and 72 Gauge Curvatures

Writing $(\omega-\omega_*)G(\omega)\to R_\omega$ at the simple pole $\omega_*$, multiplying $KG=I-Q_s$ and $GK=I-Q_f$ by $\omega-\omega_*$ gives $K_*R_\omega=R_\omega K_*=0$; together with $R_\omega Q_s(\omega_*)=0$, the difference quotient satisfies

$$R_\omega\,\frac{K(\omega)-K_*}{\omega-\omega_*}\,\bigl[(\omega-\omega_*)G(\omega)\bigr]=R_\omega\bigl[I-Q_s(\omega)\bigr]\;\longrightarrow\;R_\omega,\tag{S11.6}$$

proving $R_\omega K'(\omega_*)R_\omega=R_\omega$ (Eq. (7.15)). Classical window forcing of the form $K\cdot\text{field}$ is annihilated by $R_\omega K_*=0$, leaving $R_\omega J_d$ read out continuously across all $6\times12=72$ non-Abelian curvature components

$$\mathcal F_{\mu\nu}(P;a)=P_\mu a_\nu-P_\nu a_\mu+[\bar A_\mu,a_\nu]+[a_\mu,\bar A_\nu].\tag{S11.7}$$

### S11.5 Emergent $1/(4\pi|x-y|)$ Spatial Kernel

Set $S_0=-F_0S_{\rm st}^{-1}F_0^{\mathsf T}$ from S7. Across all unit directions $n$, $r^2 G(0,irn)=r^2 A(0,irn)-F(0,irn)B(r,n)^{-1}F(0,-irn)^{\mathsf T}$ converges linearly to $S_0$. Joint continuity of uncut $L(k,M)=J_D^{\rm uncut}(-k)^{\mathsf T}M J_S^{\rm uncut}(k)$ generates $\rho_{DS}>0$ and $B_{DS}=1+|L(0,S_0)|$ such that for $0<a|k|<\rho_{DS}$,

$$\bigl|L(ak,a^2G(0,iak))\bigr|\le B_{DS}|k|^{-2},\qquad \lim_{a\downarrow0}L(ak,a^2G(0,iak))=|k|^{-2}L(0,S_0).\tag{S11.8}$$

Local integrability of $|k|^{-2}$ on $\mathbb R^3$ and rapid decay of $\phi\in\mathcal S(\mathbb R^3)$ provide dominated convergence, and the Gaussian heat-kernel identity

$$\frac{1}{|k|^2+d^2}=\int_0^\infty e^{-t(|k|^2+d^2)}dt,\qquad \mathcal F^{-1}\!\bigl(e^{-t|2\pi\xi|^2}\bigr)(y)=(4\pi t)^{-3/2}e^{-|y|^2/(4t)}\tag{S11.9}$$

integrates at $d\downarrow0$ to $1/(4\pi|y|)$, proving Eqs. (7.16)–(7.17).

### S11.6 Born Overlap Dressing for Three-Fermion External States

On the three-fermion state $q$ of S14.1 ($(-R_{0,F}Y)^4 b=0$), orthogonal decomposition $r=\sum_{j=0}^3(-R_{0,F}Y)^j b$ defines $z=\|b\|/\|r\|\in(0,1]$; with at least one formal-adjoint ($H^\sharp$, $z=1$) external leg at both source and detector, grading-preserving gauge action equates full and base numerators, giving $C_{\rm full}=Z C_{\rm base}$ ($Z=\prod_{j=1}^4 z_j$, base constant $9/125+67/72=9023/9000$).

**Formal correspondence.** Commits 71e, 9c73: `Verification/physics/low-energy-phenomenology/alpha-source/em-identification/` (`ActualDressed{SourcePreparation,TemporalNormalization,ReaderMatching,UncutMovingCoulomb}.lean`, `PhysicalDressed{P286Character,WeightedCreation}.lean`, `ActualEM{GaugeCurvature,DressedGaugePole}.lean`, `ActualCompositeCoulombDressing.lean`).

---

## S12 Theorems 7.3 and 7.6: Constant-Field Nonlinear Half-Axis Derivative and Holomorphic Matrix Infrared Return

### S12.1–S12.3 Identification of the Nonlinear Half-Axis with the Perturbed Pencil Inverse and $C^2$ Fréchet Derivative

For $h\in\mathbb R^{289}$, put $I_i(h)=R_+(h)N_i(h)R_-(h)$ and $\mathcal P_\lambda(h)X=\lambda X+A_+(h)X-XA_-(h)$ ($A_\pm=-iK_\pm(h)$). Bounded invertibility of $\mathcal I_\lambda=\mathcal P_\lambda(0)^{-1}$ for $\operatorname{Re}\lambda>0$, $C^2$ continuity, and Duhamel–Gronwall ($\eta=\operatorname{Re}\lambda/4$) generate an open ball around $0$ where $\|\mathcal I_\lambda[\mathcal P_\lambda(h)-\mathcal P_\lambda(0)]\|<1/2$ and

$$\|e^{-\lambda t}\mathcal T_h(t)\|\;\le\;\mathcal B_d(\operatorname{Re}\lambda/4)\,e^{-(\operatorname{Re}\lambda)t/2}\qquad(\forall t\ge0).\tag{S12.1}$$

Integrating by parts (boundary vanishing by (S12.1)) identifies the nonlinear integral with the perturbed operator inverse:

$$\int_0^\infty e^{-\lambda t}\mathcal T_h(t)\,dt=\mathcal P_\lambda(h)^{-1},\qquad
\mathcal J_d(h;\lambda)_i=\ell_d\bigl\{\mathcal P_\lambda(h)^{-1}I_i(h)\bigr\}.\tag{S12.2}$$

Since operator inversion is $C^2$ on the invertible open set, differentiating (S12.2) at $h=0$ along any $f\in\mathbb R^{289}$ via $D_h\mathcal P_\lambda^{-1}(0)[f]=\mathcal I_\lambda\mathcal D_f\mathcal I_\lambda$ yields

$$D_h\mathcal J_d(0;\lambda)[f]_i=\ell_d\,\mathcal I_\lambda\bigl\{I_{i,f}^N-J_L[f]\mathcal I_\lambda I_i(0)+\bigl[\mathcal I_\lambda I_i(0)\bigr]J_R[f]\bigr\},\tag{S12.3}$$

matching $\Pi_d^{\rm st}f$ column by column (Eq. (7.3)), while tail integration gives (7.4) and nonautonomous five-term differentiation on $[0,\tau)$ gives (7.5).

### S12.4–S12.5 Occupation-Graded Cubic Time Bound and All-Branch $z^4\Pi_{\rm st}$ Holomorphic Return

Since $C_F(h)$ preserves grading and $Y_F(h)$ raises it by $1$, two-particle $u_\epsilon$ climbs at most twice and one-particle $v_\epsilon$ at most once, giving the three-stage Duhamel cubic bound

$$\|\partial_f T_F(t)v\|\;\le\;|t|j\bigl(1+2a|t|+3a^2|t|^2\bigr)\|v\|\;\le\;3j(1+a)^2(1+|t|)^3\|v\|.\tag{S12.4}$$

Moreover, the zero-climb projector $P$ ($Pu_\epsilon=u_\epsilon,Pv_\epsilon=v_\epsilon$, $[P,C_F(h)]=0$, $PY_F(h)=0$) satisfies $PT_{\rm full}(h,t)=PT_C(h,t)$ and $PR_{\rm full}(h,z)=PR_C(h,z)$, reducing the left time and resolvent legs of the five-factor kernel to norm-bounded free propagators and proving $|\mathscr D_{ij}(t)|\le K_{ij}(d)(1+|t|)^3$. Integrating $\int_0^\infty e^{-\sigma t}(1+t)^3dt=\sigma^{-1}+3\sigma^{-2}+6\sigma^{-3}+6\sigma^{-4}$ on $0<\sigma\le1$ gives $\sigma^4|\Pi_d^{\rm st}(0,\sigma)_{ij}|\le 56 K_{ij}(d)$ (Eq. (7.9)).

At zero transfer, substituting $\mathcal I_z=z^{-m_d}T_d(z)$ from the minimal polynomial $p_d(z)=z^{m_d}d_d(z)$ ($d_d(0)\ne0$) into (S12.3) defines holomorphic

$$R_d(z)=z^{2m_d}\Pi_d^{\rm st}(0,z)\qquad(\operatorname{Re}z>0).\tag{S12.5}$$

For $2m_d\ge4$, $\|R_d(s)\|\le C_d s^{2m_d-4}$ on $s>0$ forces $R_d(z)=z^{2m_d-4}G_{4,d}(z)$ with $G_{4,d}$ holomorphic near $0$ (for $2m_d<4$, set $G_{4,d}(z)=z^{4-2m_d}R_d(z)$), proving $z^4\Pi_d^{\rm st}(0,z)=G_{4,d}(z)\to G_{4,d}(0)$ and $z^6\Pi_d^{\rm st}(0,z)=z^2G_{4,d}(z)\to0$ across all branches.

**Formal correspondence.** Commits 71e, 9c73: `alpha-source/em-identification/ActualDressed{NoetherHalfIntegral,NonlinearPolarization,SignalPencil,FieldTimeFull,GradedSlopePrice,CubicNoetherPrice,CubicStaticPrice,IRAnalytic,CubicIRFactor,CubicIRReturn}.lean`.

---

## S13 Theorem 7.5: Full-Field Quantum Feedback, Nine-Constraint Schur Equivalence, and Two-Clock Flux

With nine-slot injection $J_9:\mathbb C^9\to\mathbb C^{289}$ (slots 112–120, $r_9J_9=I_9$) and change-of-basis $F(P)$, set $N(P)=F(P)J_9$, $D(P)=r_9F(P)^{-1}$, $C(P)=r_9F(-P)^{\mathsf T}=N(-P)^{\mathsf T}$, and $L(P)=F(-P)^{-\mathsf T}J_9$, so $HN=0,CH=0,DN=CL=I_9$ and

$$GH=I-ND,\qquad HG=I-LC,\qquad DG=0.\tag{S13.1}$$

1. **Half-axis nine-constraint Schur equivalence**: for $\det(I-GQ_d)\ne0$, setting $A=(I-GQ_d)^{-1}$ and $x(c)=A(Gf+Nc)$ gives $x(c)=Nc+G(f+Q_dx(c))$ and $Dx(c)=c$. Left-multiplying by $H$ via (S13.1) yields $[H-Q_d]x(c)=f-LC(f+Q_dx(c))$; since $CL=I_9$, vanishing is equivalent to $C(f+Q_dx(c))=Sc-b=0$. Conversely, $[H-Q_d]x=f$ gives $(I-GQ_d)x=Gf+NDx$, hence $x=x(Dx)$, and $C(f+Q_dx)=CHx=0\implies S(Dx)=b$ without assuming invertibility of $S$.
2. **Anchor bound $16/15$ and four-factor synchronous derivative**: choosing nonreal matter radius $r_d\ge 4(1+G_*^{\rm price}B_d^{\rm win})>0$ gives $\|T^{-1}G_*\Pi_T\|\le 1/16$ and $\|A_T\|\le 16/15$ at $z=3,0<T\le1$; differentiating $S_T(z)=C(z)\Pi_T(z)A_T(z)N(z)$ via $A_T'=-A_TB_T'A_T$ yields Eq. (7.8), while general two-clock half-axis fractions clear denominators by $p_d(\lambda)p_d(\lambda-c)$ and temporal Ward residuals vanish at $O(\epsilon)$.

**Formal correspondence.** Commit 9c73: `alpha-source/em-identification/{ActualEMDressedSourceAnchor,ActualEMDressedSchur,ActualDressedConstraintHistory,ActualDressedRationalFourier,ActualDressedTemporalQuantumResidual,ActualDressedFullSchurFlux,ActualDressedHalfSchur}.lean`.

---

## S14 Theorem 7.11: Charged Colour-Singlet Spin-`1/2` Three-Fermion State and Four-Channel Positive Spectrum

### S14.1–S14.2 Exact Quantum Numbers and Bounded Four-Channel Sum

On each branch $d\in\{0,1\}$, with $a^\dagger_{d,(s,c,h)}$ indexing spinor $s\in\{0,1,2,3\}$, colour $c\in\{0,1,2\}$, and wedge type $h\in\{0,1\}$, set

$$\epsilon_d(s_0,s_1,s_2)=\sum_{\pi\in S_3}\operatorname{sgn}(\pi)\,
a^\dagger_{d,(s_0,\pi_0,0)}a^\dagger_{d,(s_1,\pi_1,0)}a^\dagger_{d,(s_2,\pi_2,1)}\Omega_d,\qquad
q_d^{(3)}=\tfrac13\bigl[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)\bigr].\tag{S14.1}$$

Orthogonality of the $6$ unit words in $\epsilon_d(0,1,2)$ (squared norm $6$) and $3$ weight-$2$ words in $\epsilon_d(0,0,3)$ (squared norm $12$) gives $\|q_d^{(3)}\|^2=(6+12)/9=2$. Every $A\in\mathfrak{su}(3)$ acts on $\epsilon_{abc}$ by $\operatorname{tr}A=0$ (colour singlet); electric charge is $(-1)^d=\pm1$; Clifford spin-squared gives $\sum_{j=1}^3(s_j^{(1)}+s_j^{(2)}+s_j^{(3)})^2 q_d^{(3)}=\tfrac34 q_d^{(3)}$ (spin $1/2$); and $Yq_d^{(3)}\ne0$.

Because $\mathcal B_0,\mathcal B_1,\mathcal B_2,\mathcal B_3$ preserve particle number and commute with $v^{m+2}$, $\mathcal B=\sum_{b=0}^3\mathcal B_b$ is bounded on $\mathscr H$, and the 57-term polynomial bound places $w_F(t)\in L^1\cap L^2$, yielding Parseval's identity (7.19) $\nu(\mathbb R)=2\pi\int_{\mathbb R}\|\mathcal B w_F(t)\|^2dt$.

### S14.3–S14.5 Imaginary Nonvanishing Witness, Meromorphic Real Window, Neutral Zero Channel, and Two-Resolvent Identity

At purely imaginary transfer $x=i$ ($k=p_L=p_R=0$), the four channel amplitudes evaluate exactly to

$$\sqrt{30}\left(-\frac1{25},\quad
\frac{50304430064141165448074104830433}{97699116566232156027102301987500},\quad
-\frac{27}{316},\quad 0\right),\tag{S14.2}$$

whose coherent sum is

$$\sqrt{30}\,\frac{1502925864947895702084635234454041}{3859115104366170163070540928506250}\;\ne\;0.\tag{S14.3}$$

Because all 33 numerators and 17 denominators are meromorphic and nonzero at $x=i$, taking the minimum of their isolated Laurent zero/pole radii yields a **common punctured real interval $0<|x|<\delta$ prior to all $(F,\mu,\text{adjoint},\text{causal})$**, where $z\mathcal B r_F(z)\to-\mathcal B(q_d^{(3)}f)\ne0$ forces strictly positive total spectral and causal time mass. Orthogonal grading $\int\|r_F(\omega)\|^2d\omega=(\pi/\mu)\|q_d^{(3)}f\|^2+\int\|\mathrm{corr}_{Y,F}(\omega)\|^2d\omega$ with $B_Y(q_d^{(3)}f)\ne0$ proves strictly positive integrated Yukawa excess, while $[Q_s,\mathcal B]=0$ and $Q_s q_d^{(3)}=\pm3 q_d^{(3)}$ annihilate $\langle e_w,\mathcal B r\rangle$ identically whenever $Q_s e_w=0$.

Finally, at $\mu_*>0$, the Sylvester solution $\mathcal L(D)=\sum_{a,b}[2\mu_*-i\operatorname{dir}(c)(e_a-e_b)]^{-1}P_a D P_b$ over $C_F=\sum_a e_a P_a$ yields via four-pole contour integration

$$\int_{\mathbb R}\|R_F(\omega)DR_F(\omega)g\|^2d\omega=\frac\pi{\mu_*}\|\mathcal L(D)g\|^2+\int_{\mathbb R}\|\mathcal L(D)R_F(\omega)g\|^2d\omega,\tag{S14.4}$$

closing the signed frequency balance, pressure moment tail, and scalar field energy identity ($3c_\sharp/(16\mu_*)+15c_\sharp/(16\mu_*)=9c_\sharp/(8\mu_*)$).

**Formal correspondence.** Commits 71e, 9c73: `external-composite-decay/{MixedSpectatorYukawaNonzero,SourceYukawaPositiveCorrection}.lean`, `SourceActualFourBlock{Retarded,HilbertOperator,SharpCausalMass,RealTransferPositive,SignedSector}.lean`, and `Lean/scratch/LowEnergyRetardedCouncil/ActualFourBlockResponse/SourceActual{TwoResolventSylvester,ExactSylvesterRawFrequencyBalance,BalancedPressureMomentPayment,ScalarFieldDebitPayment}.lean`.

---

## S15 Proposition 10.4: First-Registration Probability on the Complete 120 ns Gate and Primal/Adjoint Recovery

1. **(S15.1–S15.2) Trace-preserving free bath, first forcing, and factorial tail**: $\mathcal L_{\rm nat}(\rho)=K\rho+\rho K^\dagger+\sum_j J_j\rho J_j^\dagger$ (retaining same-arm and cross-arm recycling plus Hermitian cross-pairs) generates $\mathcal U_0(t,0)$ with Volterra expansion $\rho(t)=\mathcal U_0(t,0)\rho(0)+\int_0^t\mathcal U_0(t,s)\mathcal R(s)\rho(s)ds$ and simplex tail bound $\sum_{k\ge0}a^{N+1+k}/(N+1+k)!\le\frac{a^{N+1}}{(N+1)!(1-a/(N+2))}$ ($a<N+2$). The ten-factor bath passes the $10^{-8}$ gate (joint uniform error $2.41\times10^{-14}$) over 40 local operators and 328 signed DAG rows.
2. **(S15.3) Four-port late adjoint**: $E_r^{\rm late}=\int_{I_{\rm late}}\mathcal U_0(t,0)^*(\mathcal J_r^*I)dt$ across 60 $1\text{ ns}$ slices and $4,915,200$ Gaussian-integer degree-64 quadrature entries satisfies max operator error $8.427437\times10^{-12}<10^{-10}$.
3. **(S15.4) Three no-count preimages, single initial-error contraction, and $10^{-21}$ primal/adjoint agreement**: from $1_{\rm first}=1-n_\perp-n_\parallel+n_\perp n_\parallel$ and $\mathcal L_Q^{\rm nc}=\mathcal L_{\rm nat}-\sum_{j\in Q}\mathcal J_j$, cyclic trace identities enforce $\frac{d}{dt}\operatorname{tr}(E_Q\rho_Q)=0$. Source activity $\|E_{\rm first}\|\le\kappa\le0.003740914455$ contracts initial error once: $|P_{\rm first}-\widehat P_{\rm first}|\le\kappa E_0+E_{\rm new}$. Six adjoint flows certify $[3.17845500810,3.17846466595]\times10^{-6}$ (error $4.82892\times10^{-12}$) and 30 primal curves (3600 slices) certify $[3.17845717771,3.17846249634]\times10^{-6}$ (error $2.65931\times10^{-12}$), with centre difference $1.301828\times10^{-21}$.

### S15.5 Frozen Scientific Receipts and Commits

| Module | Frozen scientific commit | Verified scope and precision gate |
| --- | --- | --- |
| Four-port late adjoint `rha0038.1` | `a165b04a26febd0bc4e7ed1f33d4668b564a6e4f` | 60 slices / $4,915,200$ Gaussian integers; passes $10^{-10}$ gate |
| Three no-count adjoint flows `rha0039` | `425ed6ed406b2a96f044dafd1c39b3587a9f14f0` | Six complete $120\text{ ns}$ adjoint flows; passes $10^{-8}$ gate |
| Single whole-event contraction `rha0039.1` | `87f9b1234441783f945727408b06ede72af9683d` | $\kappa\le0.0037409145$ and adjoint probability interval |
| 30 primal curves & recovery `rha0041.1` | Sci. `065399a21dcf...`; cons. `f7a5ee523ac8...` | 3600 slices / 90 rational slices; primal interval & $1.30\times10^{-21}$ centre match |
| Seven-query program bank `rha0042` | `7c9423057a2ee8f594b7502172e1a37105490829` | All 7 priority queries / 140 activation & scalar synthesis programs |

**Formal correspondence.** `munich/readout-domain/` (`RegisteredDuhamelTail.lean`, `RegisteredTensorAction.lean`, `LateRegisteredAdjoint.lean`, `FirstReceiptZeroCount.lean`, `FirstReceiptQuantumFlux.lean`, `NoCountQuantumGenerator.lean`) and independent checkers.

---

## S16 Theorems 4.6–4.7: Source-Generated Volterra Uniqueness and Derivative-Loss-Free Symmetric-Hyperbolic Closure

### S16.1 Bidirectional Equivalence of Weighted Mother-Action Weak Zeros and Volterra Fixed Points

Fix $T>0$, spatial box $Q=[a,b]\subset\mathbb R^3$ ($a\le b$), and dense spatial test element $\phi_n$ ($n\in\mathbb N$). Continuity of the source-generated whole-time $L^2$ trajectory and bounded operator pairing render $m_n(t)=\langle\phi_n,M(t)u_{\rm src}(t)\rangle_{L^2(Q)}$ and the spatial Green rate $g_n(t)$ interval-integrable on $[0,T]$. Setting $G_n(t)=m_{n,0}+\int_0^t g_n(s)\,ds$, $G_n$ is absolutely continuous on $[0,T]$ with $G_n'(t)=g_n(t)$ for a.e. $t\in[0,T]$.

For any smooth weight $w\in C^1([0,T])$ satisfying $w(T)=0$, integrating the absolutely continuous product $w(t)G_n(t)$ by parts gives

$$\int_0^T\bigl(w(t)g_n(t)+w'(t)G_n(t)\bigr)\,dt
=\bigl[w(t)G_n(t)\bigr]_0^T
=0-w(0)m_{n,0}=-w(0)m_{n,0}.\tag{S16.1}$$

- **Volterra fixed point $\Longrightarrow$ weighted weak-action zero**: if $m_n(t)=G_n(t)$ a.e. on $[0,T]$, then $\int_0^T w'(t)m_n(t)\,dt=\int_0^T w'(t)G_n(t)\,dt$, and (S16.1) yields $\int_0^T(wg_n+w'm_n)\,dt+w(0)m_{n,0}=0$ for every $w\in C^1([0,T])$ with $w(T)=0$.
- **Weighted weak-action zero $\Longrightarrow$ Volterra fixed point**: conversely, subtracting (S16.1) from the weak-action zero identity gives for $\Delta_n(t)=m_n(t)-G_n(t)\in L^1([0,T])$
  $$\forall w\in C^1([0,T])\ (w(T)=0),\qquad \int_0^T w'(t)\,\Delta_n(t)\,dt=0.\tag{S16.2}$$
  For any $\varphi\in C_c^\infty((0,T))$, the right-anchored primitive $w_\varphi(t)=-\int_t^T\varphi(s)\,ds$ belongs to $C^1([0,T])$, satisfies $w_\varphi(T)=0$, and has $w_\varphi'(t)=\varphi(t)$ (with $w_\varphi(0)$ unconstrained). Hence $\int_0^T\varphi(t)\Delta_n(t)\,dt=0$ for all $\varphi\in C_c^\infty((0,T))$, which by the fundamental lemma of the calculus of variations forces $\Delta_n(t)=0$ a.e. on $[0,T]$, proving Theorem 4.6(1).

### S16.2 Common Full-Measure Time Set Across Countable Dense Tests and Spatial $L^2(Q)$ Uniqueness

For each $n\in\mathbb N$, define

$$\Omega_n=\bigl\{t\in[0,T]:\;m_n(t)=G_n(t)\bigr\},\qquad
\Omega_{T,Q}=\bigcap_{n\in\mathbb N}\Omega_n\subseteq[0,T].\tag{S16.3}$$

By S16.1, each complement $[0,T]\setminus\Omega_n$ has Lebesgue measure zero; countable unions of null sets are null, so $\Omega_{T,Q}$ has full measure $T>0$ on $[0,T]$ and is therefore nonempty.

Fix any $t\in\Omega_{T,Q}$ and candidate $v\in L^2(Q)$. If $\langle\phi_n,M(t)v\rangle_{L^2(Q)}=G_n(t)$ for every $n\in\mathbb N$, then $t\in\Omega_n$ gives $G_n(t)=m_n(t)=\langle\phi_n,M(t)u_{\rm src}(t)\rangle_{L^2(Q)}$, so $w=v-u_{\rm src}(t)\in L^2(Q)$ satisfies $\langle\phi_n,M(t)w\rangle_{L^2(Q)}=0$ for all $n\in\mathbb N$. Density of $\operatorname{span}\{\phi_n\}$ implies $M(t)w=0$, and positive-definite invertibility of $M(t)$ on the Cauchy-safe background forces $w=0$, i.e. $v=u_{\rm src}(t)$, proving Theorem 4.6(2).

### S16.3 Recursive Spatial-Jet Prolongation and On-Shell-Clean Commuted Forcing

Write $\mathcal L_{\rm mat}u=A^0(x)\partial_t u+\sum_{j=1}^3 A^j(x)\partial_j u+B_0(x)u$ with smooth invertible $A^0(x)$, so any on-shell field satisfies

$$\mathcal L_{\rm mat}u=0\quad\Longrightarrow\quad
\partial_t u=\mathcal T(x)(j_{\rm sp}^1 u)\equiv -(A^0(x))^{-1}\Bigl(\sum_{j=1}^3 A^j(x)\partial_j u+B_0(x)u\Bigr).\tag{S16.4}$$

Inducting on $|w|$ for $w\in\{1,2,3\}^*$, we construct $\mathcal J_w(x)\in\mathcal L(J_{\rm sp}^{|w|},\mathcal V)$ purely from source coefficients:

1. **Base case** $w=\varnothing$: set $\mathcal J_\varnothing(x)\equiv 0$, so $[\partial^\varnothing,\mathcal L_{\rm mat}]u=0=\mathcal J_\varnothing(x)(j_{\rm sp}^0 u)$.
2. **Inductive step** $w=i\cdot\tilde w$ ($|\tilde w|=k$, $|w|=k+1$): for any smooth solution of $\mathcal L_{\rm mat}u=0$, expand
   $$[\partial_i\partial^{\tilde w},\mathcal L_{\rm mat}]u
   =\partial_i\bigl([\partial^{\tilde w},\mathcal L_{\rm mat}]u\bigr)
   +[\partial_i,\mathcal L_{\rm mat}](\partial^{\tilde w}u).\tag{S16.5}$$
   Differentiating the inductive identity $[\partial^{\tilde w},\mathcal L_{\rm mat}]u=\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)$ along $x^i$ gives
   $$\partial_i\bigl(\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)\bigr)
   =(\partial_i\mathcal J_{\tilde w})(x)(j_{\rm sp}^k u)+\mathcal J_{\tilde w}(x)\bigl(\mathsf S_i^{(k)}(j_{\rm sp}^{k+1}u)\bigr),\tag{S16.6}$$
   where $\mathsf S_i^{(k)}$ reads $\partial^{i\cdot v}u$ ($|v|\le k$) from $j_{\rm sp}^{k+1}u$. Meanwhile, the second term of (S16.5) reads
   $$[\partial_i,\mathcal L_{\rm mat}](\partial^{\tilde w}u)
   =(\partial_i A^0)(x)\,\partial_t\partial^{\tilde w}u
   +\sum_{j=1}^3(\partial_i A^j)(x)\,\partial_j\partial^{\tilde w}u
   +(\partial_i B_0)(x)\,\partial^{\tilde w}u.\tag{S16.7}$$
   Applying $\partial^{\tilde w}$ to $\mathcal L_{\rm mat}u=0$ yields $\mathcal L_{\rm mat}(\partial^{\tilde w}u)=-[\partial^{\tilde w},\mathcal L_{\rm mat}]u=-\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)$, solving for the mixed temporal–spatial derivative strictly in terms of $(k+1)$-st pure spatial jets:
   $$\partial_t\partial^{\tilde w}u
   =-(A^0(x))^{-1}\Bigl(\sum_{j=1}^3 A^j(x)\,\partial_{j\cdot\tilde w}u+B_0(x)\,\partial^{\tilde w}u+\mathcal J_{\tilde w}(x)(j_{\rm sp}^k u)\Bigr).\tag{S16.8}$$
   Substituting (S16.8) into (S16.7) and adding (S16.6) defines purely from source coefficients
   $$\begin{aligned}
   \mathcal J_{i\cdot\tilde w}(x)(J)
   &=(\partial_i\mathcal J_{\tilde w})(x)(\pi_k J)+\mathcal J_{\tilde w}(x)(\mathsf S_i^{(k)}J)+\sum_{j=1}^3(\partial_i A^j)(x)J_{j\cdot\tilde w}+(\partial_i B_0)(x)J_{\tilde w}\\
   &\quad-(\partial_i A^0)(x)(A^0(x))^{-1}\Bigl(\sum_{j=1}^3 A^j(x)J_{j\cdot\tilde w}+B_0(x)J_{\tilde w}+\mathcal J_{\tilde w}(x)(\pi_k J)\Bigr),
   \end{aligned}\tag{S16.9}$$
   which belongs to $\mathcal L(J_{\rm sp}^{k+1},\mathcal V)$ and satisfies $\mathcal J_w(x)(j_{\rm sp}^{|w|}u(x))=[\partial^w,\mathcal L_{\rm mat}]u(x)$ pointwise for all smooth on-shell $u$, proving Theorem 4.7(1).

### S16.4 Compact-Box Coercivity, Wordwise Square Absorption, and Derivative-Loss-Free Rate Closure

Fix $I\times Q=[t_0,t_1]\times[a,b]$ and $r\in\mathbb N$.

1. **Pointwise coercivity**: continuity and fibrewise positive-definiteness of $A^0(t,\mathbf x)$ on the compact product $(I\times Q)\times S(\mathcal V)$ give $\kappa>0$ such that $\kappa\|\xi\|^2\le\langle\xi,A^0(t,\mathbf x)\xi\rangle$. Under the sup-word jet norm $\|j_{\rm sp}^r u(x)\|=\max_{|w|\le r}\|\partial^w u(x)\|$,
   $$\kappa\,\|j_{\rm sp}^r u(t,\mathbf x)\|^2
   \;\le\;\sum_{|w|\le r}\langle\partial^w u(t,\mathbf x),A^0(t,\mathbf x)\partial^w u(t,\mathbf x)\rangle
   =\mathcal E_r[u](t,\mathbf x).\tag{S16.10}$$
2. **Budget absorption prior to all fields**: set $M_{\rm inv}=\sup_{I\times Q}\|(A^0)^{-1}\|<\infty$, $M_{\rm jet}=\max_{|w|\le r}\sup_{I\times Q}\|\mathcal J_w\|<\infty$, $N_r=\sum_{k=0}^r 3^k$, and $L=N_r(M_{\rm inv}M_{\rm jet})^2\ge0$ (prior to all $u$). For any smooth on-shell $u$ and $|w|\le r$, monotonicity $\|j_{\rm sp}^{|w|}u\|\le\|j_{\rm sp}^r u\|$ and Theorem 4.7(1) yield
   $$\bigl\|(A^0)^{-1}[\partial^w,\mathcal L_{\rm mat}]u\bigr\|
   =\bigl\|(A^0)^{-1}\mathcal J_w(j_{\rm sp}^{|w|}u)\bigr\|
   \le M_{\rm inv}M_{\rm jet}\|j_{\rm sp}^r u\|.\tag{S16.11}$$
   Squaring, summing over all $N_r$ words, multiplying by $\kappa$, and applying (S16.10) gives
   $$\kappa\,\mathcal F_r[u](t,\mathbf x)
   \le \kappa\,N_r(M_{\rm inv}M_{\rm jet})^2\|j_{\rm sp}^r u(t,\mathbf x)\|^2
   \le L\,\mathcal E_r[u](t,\mathbf x).\tag{S16.12}$$
3. **Same-order energy-rate closure**: applying the symmetric-hyperbolic pointwise identity to $\partial^w u$ bounds $(\partial_t A^0)$, $\sum_j(\partial_j A^j)$, zero-order symmetric terms $-(B_0+B_0^{\mathsf T})$, and $2\langle\partial^w u,[\partial^w,\mathcal L_{\rm mat}]u\rangle$ linearly in $\|j_{\rm sp}^r u\|^2$ and $\mathcal F_r[u]$; combining compact-box coefficient bounds with (S16.10) and (S16.12) into a single $K\ge0$ yields $\kappa\,\mathcal R_r[u](t,\mathbf x)\le K\,\mathcal E_r[u](t,\mathbf x)$ with zero $(r+1)$-st derivatives, proving Theorem 4.7(2).

**Formal correspondence.** Commit H: `Lean/SaturationMonoid/PhysicsCore/StageNineDiracDualFormNativeFixedP506CauchySafeMatterCanonicalAffineVolterra{Recognition,Actualization}.lean` (`weakVolterraActionZero_iff_fixedPoint`, `canonicalAffinePhysicalTimeL2Output_weakActionZero_iff_fixedPoint`, `CanonicalAffineVolterraDenseReadOccurrence.physicalField_unique`) and `StageNineDiracDualFormNativeFixedP506CauchySafeMatterSymmetricHyperbolicAllOrder{JetProlongation,EnergyClosure}.lean` (`fixedMatterAllOrderForcingJetCLM_apply_of_actionZero`, `exists_fixedMatterAllOrderPointwiseForcingBudgetAbsorptionOnBox`, `exists_fixedMatterAllOrderClosedPointwiseRateBoundOnBox`).

---

## S17 Theorems 7.8 and 7.12: 192/97 Electromagnetic Fraction, Joint Cone, and 4D Curvature Strong Integration

### S17.1 192-Dimensional Inactive Two-Sided Inverse and 97-Dimensional Bivariate Schur Fraction

For dressed event $d$, unit $n$ ($|n|^2=1$), $0<\varepsilon\le 1/2$, and $\sigma>0$, split $289=192+97$ into inactive and active directions:

$$P_{\rm corr}(\varepsilon,\sigma)=\begin{pmatrix}P_{II}(\varepsilon,\sigma)&P_{IA}(\varepsilon,\sigma)\\ P_{AI}(\varepsilon,\sigma)&P_{AA}(\varepsilon,\sigma)\end{pmatrix},\qquad P_{II}\in M_{192}(\mathbb C),\quad P_{AA}\in M_{97}(\mathbb C).\tag{S17.1}$$

On $0<\varepsilon\le 1/2,\sigma>0$, $P_{II}^{-1}=d_{\rm nat}(\varepsilon,\sigma)^{-1}N_{\rm inv}(\varepsilon,\sigma)$ with $d_{\rm nat}\ne0$. Block Gauss elimination gives $\det P_{\rm corr}=\det P_{II}\cdot\det S_{97}$ for $S_{97}=P_{AA}-P_{AI}P_{II}^{-1}P_{IA}$ (retaining all $97\leftrightarrow192$ cross-columns) and reconstructs $x_I=-P_{II}^{-1}(P_{IA}x_A-f_I)$, making $\det_{\rm corr}\ne0\iff\det S_{97}\ne0$.

Clearing $d_{\rm nat}$ defines the bivariate polynomial matrix

$$Q_{97}(\varepsilon,X)=d_{\rm nat}(\varepsilon,X)P_{AA}(\varepsilon,X)-P_{AI}(\varepsilon,X)N_{\rm inv}(\varepsilon,X)P_{IA}(\varepsilon,X)\in M_{97}\bigl((\mathbb C[\varepsilon])[X]\bigr),\tag{S17.2}$$

whose adjugate $Q_{97}\operatorname{adj}(Q_{97})=(\det Q_{97})I_{97}$ expresses $\varepsilon^4 T_{00}(\varepsilon,\sigma)=\mathrm{eval}_{\varepsilon,\sigma}(N_{97})/\mathrm{eval}_{\varepsilon,\sigma}(\det Q_{97})$, proving Theorem 7.8(1).

### S17.2 Elementary Row Update at Electromagnetic Pivot 15 and $X^2 / X^3$ Clock Cancellation

The physical electromagnetic temporal vector vanishes on all 192 inactive slots ($E_I=0$) and on the 97-element active index set $\mathcal I_{97}\subset\{0,\ldots,288\}$ takes exact rational value $(E_A)_{15}=-1/2$ at active pivot 15. Temporal Ward cancellation annihilates the $X^0,X^1$ terms of both $E_A^{\mathsf T}P_{AA}$ and $E_A^{\mathsf T}P_{AI}N_{\rm inv}P_{IA}$, giving

$$E_A^{\mathsf T}\,Q_{97}=X^2\,R_{97}^{\mathsf T},\qquad R_{97}\in\bigl((\mathbb C[\varepsilon])[X]\bigr)^{97}.\tag{S17.3}$$

Replacing the pivot-15 row of $Q_{97}$ by $E_A^{\mathsf T}Q_{97}=\sum_{j\in\mathcal I_{97}}(E_A)_j(Q_{97})_{j,\bullet}$ to form $\widetilde Q_{97}$ gives by row multilinearity and alternating cancellation

$$-\frac12\,\det Q_{97}=(E_A)_{15}\det Q_{97}=\det\widetilde Q_{97}=\det\bigl(\text{row 15 replaced by }X^2 R_{97}^{\mathsf T}\bigr)=X^2\,\det\widehat Q_{97}.\tag{S17.4}$$

Multiplying by $-2$ with $D_{\rm W}=-2\det\widehat Q_{97}\in(\mathbb C[\varepsilon])[X]$ proves $\det Q_{97}=X^2 D_{\rm W}$ inside the polynomial ring without division, while the auxiliary clock column yields $N_{97}=X^3 N_{\rm W}$. For $\sigma>0$, ring evaluation gives

$$\frac{\mathrm{eval}_{\varepsilon,\sigma}(N_{97})}{\mathrm{eval}_{\varepsilon,\sigma}(\det Q_{97})}
=\frac{\sigma^3\,\mathrm{eval}_{\varepsilon,\sigma}(N_{\rm W})}{\sigma^2\,\mathrm{eval}_{\varepsilon,\sigma}(D_{\rm W})}
=\sigma\,\frac{\mathrm{eval}_{\varepsilon,\sigma}(N_{\rm W})}{\mathrm{eval}_{\varepsilon,\sigma}(D_{\rm W})},\tag{S17.5}$$

and domain integrity of $(\mathbb C[\varepsilon])[X]$ yields $\operatorname{ord}_X(P)=m+\operatorname{ord}_X(W)$ for $m=3,2$, proving Theorem 7.8(2).

### S17.3 Bivariate Leading-Coefficient Nonvanishing and Single-Seed Joint Cone

Given one seed $(\varepsilon_0,\sigma_0)$ with $0<\varepsilon_0\le 1/2$, $\sigma_0>0$, and $\det_{\rm corr}(\varepsilon_0,\sigma_0)\ne0$, the denominator $B=\det Q_{97}\in(\mathbb C[\varepsilon])[X]$ is nonzero; write $A=N_{97}\in(\mathbb C[\varepsilon])[X]$. For each $P\in\{A,B\}$, factoring the $X$-trailing order $k_P=\operatorname{ord}_X(P)$ (with convention $k_P=0,p_0\equiv0$ when $P=0$) writes

$$P(\varepsilon,X)=X^{k_P}\Bigl(p_0(\varepsilon)+X\,P_{\rm tail}(\varepsilon,X)\Bigr).\tag{S17.6}$$

Factoring $\ell_P=\operatorname{ord}_\varepsilon(p_0)$ writes $p_0(\varepsilon)=\varepsilon^{\ell_P}(c_P+\varepsilon\tilde p(\varepsilon))$ (setting $k_A=\ell_A=0,a_0\equiv0,c_A=0$ if $A=0$). Since $B\ne0$, $b_0(\varepsilon)\ne0$ and $c_B\ne0$. Define the spatial rescaling weight $w_{\rm sp}(\varepsilon)=\varepsilon^{\ell_B-\ell_A}$ and, denoting by $M_{\tilde a},M_{\tilde b}\ge0$ the sums of coefficient moduli of $\tilde a,\tilde b$ on $[0,1/2]$, set $S_{\rm ratio}:=2|c_B|^{-1}\bigl(M_{\tilde a}+|c_A||c_B|^{-1}M_{\tilde b}\bigr)\ge0$. Finite polynomial coefficient bounds select $\rho_{\rm sp}\in(0,1/2]$ so that $|\varepsilon\tilde b(\varepsilon)|\le\tfrac12|c_B|$ for all $0<\varepsilon\le\rho_{\rm sp}$, and then for each fixed $\varepsilon\in(0,\rho_{\rm sp}]$ select $\rho_{\rm clk}(\varepsilon)>0$ so that for all $0<\sigma\le\rho_{\rm clk}(\varepsilon)$: (1) $|\sigma B_{\rm tail}(\varepsilon,\sigma)|\le\tfrac12|b_0(\varepsilon)|$, certifying $\det_{\rm corr}(\varepsilon,\sigma)\ne0$; and (2) $|\widetilde R(\varepsilon,\sigma)-a_0(\varepsilon)/b_0(\varepsilon)|\cdot|w_{\rm sp}(\varepsilon)|\le\varepsilon$ for $\widetilde R(\varepsilon,\sigma)=\sigma^{k_B-k_A}\varepsilon^4 T_{00}(\varepsilon,\sigma)$. Combining this with $|w_{\rm sp}(\varepsilon)a_0(\varepsilon)/b_0(\varepsilon)-c_A/c_B|=\varepsilon|(\tilde a c_B-c_A\tilde b)/[c_B(c_B+\varepsilon\tilde b)]|\le S_{\rm ratio}\,\varepsilon$ via the triangle inequality yields (7.14), proving Theorem 7.8(3).

### S17.4 Four-Dimensional Curvature Strong Integration and $\operatorname{Dom}(H_{\rm time})$ Word Gram

Let $\mathcal U_{1\text{--}10}$ be the ten-stage total closure object with Standard Model connection $A_{\rm cl}$, let $\eta\in C_c^\infty(\mathbb R^4,\Omega^1(\mathfrak h_{\rm SM}))$ and $t\in\mathbb R$, and denote by $H_{\rm time}$ the self-adjoint generator of the strongly continuous unitary clock group $U_{\rm time}(s)=e^{-isH_{\rm time}}$ on the 252-dimensional matter response space and common carrier $\mathcal H_{\rm com}$ (distinct from the nonsymmetric 504-mode CAR generator $H=H_0+Y$ of §6.3). For $A_{\rm cl}+t\eta$, $F(A_{\rm cl}+t\eta)=F(A_{\rm cl})+t\,D_{A_{\rm cl}}\eta+\tfrac{t^2}{2}[\eta\wedge\eta]$ defines on $\pi_{\rm sp}(p)=(0,\mathbf p)$ a uniformly bounded strongly continuous seed, making the 4D Bochner integral (7.20) well-defined for $f\in\mathcal S(\mathbb R^4)\subset L^1(\mathbb R^4)$ with $\|\Phi_{\eta,t,P}(f)\|\le\|f\|_{L^1}\|\mathrm{seed}\|_\infty$ and, at $t=0$, $\Phi_{\eta,0,P}(f)=\Phi_{\rm orig}(\iota_0(P),f)$ for the origin embedding $\iota_0(P)$ of the same-point curvature polynomial $P$.

Using $U_{\rm time}(s)U_{\rm time}(-p_0)=U_{\rm time}(-(p_0-s))$ and $\pi_{\rm sp}(p_0-s,\mathbf p)=\pi_{\rm sp}(p)$, substituting $q_0=p_0-s$ gives the covariance relation with $\tau_s f(q_0,\mathbf p)=f(q_0+s,\mathbf p)$

$$U_{\rm time}(s)\,\Phi_{\eta,t,P}(f)\,U_{\rm time}(-s)v=\Phi_{\eta,t,P}(\tau_s f)v.\tag{S17.7}$$

Since $s^{-1}(\tau_s f-f)\to\partial_0 f$ in $L^1(\mathbb R^4)$, $\frac{d}{ds}\big|_{s=0}(U_{\rm time}(s)\Phi(f)U_{\rm time}(-s))=\Phi(\partial_0 f)$ in operator norm. For $v\in\operatorname{Dom}(H_{\rm time})$,

$$\frac{U_{\rm time}(s)\Phi(f)v-\Phi(f)v}{s}
=\frac{\bigl(U_{\rm time}(s)\Phi(f)U_{\rm time}(-s)-\Phi(f)\bigr)}{s}U_{\rm time}(s)v
+\Phi(f)\frac{U_{\rm time}(s)v-v}{s}\tag{S17.8}$$

converges strongly as $s\to0$ to $\Phi(\partial_0 f)v-i\Phi(f)H_{\rm time}v$, proving $\Phi_{\eta,t,P}(f)v\in\operatorname{Dom}(H_{\rm time})$ with $H_{\rm time}\Phi_{\eta,t,P}(f)v=\Phi_{\eta,t,P}(i\partial_0 f)v+\Phi_{\eta,t,P}(f)H_{\rm time}v$ (and inductively for all finite mixed words $W(w)$). Pulling back via $I_{\rm com}:\mathcal H_{\rm com}\xrightarrow{\sim}\mathcal H_{\rm src}$ and applying Theorem 6.2 yields $\sum_{i,j}\overline{c_i}c_j\mathrm{Gram}_x(w_i,w_j)=\bigl\|\sum_i c_i W(w_i)\psi_{\rm prep}(x)\bigr\|^2\ge 0$, proving Theorem 7.12.

**Formal correspondence.** Commit df4: `Verification/physics/low-energy-phenomenology/alpha-source/em-identification/ActualSourcePrepared{InactiveSchurReturn,Schur97NoetherFraction,Schur97WardSchur,Schur97WardDeterminant,Schur97WardFactor,Schur97JointCone}.lean` (`actual_source_prepared_em_enclosure_certification.json`). Commit 7e4: `Lean/SaturationMonoid/PhysicsCore/YangMills/SourceQuantum/Curvature/Spatial/{Seed,Field,Words,Original}.lean`, `Continuum/Spacetime/Strong/Spatial/{Field,Time}.lean` (`source_spatial_curvature_receipt.json`).

---

## S18 Theorem 10.1: Whole-Word Kraus–Born Isometry and Open Recycling Density Trace Duality

### S18.1 Exact Total Mass and $L^2$ Field-State Isometric Embedding on Simplex Direct Sums

On $[t_L,t_R]$ ($t_0\in[t_L,t_R]$) with finite channel set $\mathcal I$, for $w=(j_1,\ldots,j_n)\in\mathcal I^n$ and $\Delta_n(t_0,t_R)=\{t_0\le s_1\le\cdots\le s_n\le t_R\}$, the source Kraus word amplitude is

$$\mathcal A_{n,w}(t_0;\mathbf s)=U_{\rm eff}(t_R,s_n)J_{j_n}U_{\rm eff}(s_n,s_{n-1})\cdots J_{j_1}U_{\rm eff}(s_1,t_0)\in\mathcal L(E),\tag{S18.1}$$

where $\frac{d}{dt}U_{\rm eff}(t,s)=K(t)U_{\rm eff}(t,s)$ and $K(t)^*+K(t)+\sum_{j\in\mathcal I}J_j(t)^*J_j(t)=0$. Integration by parts across simplices yields

$$\sum_{n=0}^{\infty}\sum_{w\in\mathcal I^n}\int_{\Delta_n(t_0,t_R)}\bigl\|\mathcal A_{n,w}(t_0;\mathbf s)x\bigr\|^2\,d\mathbf s=\|x\|^2.\tag{S18.2}$$

Piecewise continuity on compact $\Delta_n$ makes $\Psi_{t_0}(x)$ strongly measurable on $\mathscr W(\mathcal I)=\bigsqcup_{n,w}\Delta_n$, and Tonelli's theorem expands $\int_{\mathscr W}\|\Psi_{t_0}(x)\|^2d\mu_{\rm base}$ into (S18.2) to equal $\|x\|^2<\infty$, proving $\|\Psi_{t_0}(x)\|_{L^2}=\|x\|$ and Theorem 10.1(1).

### S18.2 Vanishing Derivative Against the Backward Adjoint Flow and All-Order Open Density Trace Identity

For any $\mathcal H\subseteq\mathcal I$, consider on the operator algebra $\mathcal L(E)$ of the finite-dimensional atomic Hilbert space $E$ the forward open density IVP and backward Heisenberg effect terminal problem ($t\in[t_0,t_R]$):

$$\left\{\begin{aligned}
\frac{d}{dt}\Phi_{t_0\to t}^{\mathcal H}(\rho)&=K(t)\Phi_{t_0\to t}^{\mathcal H}(\rho)+\Phi_{t_0\to t}^{\mathcal H}(\rho)K(t)^*+\sum_{j\in\mathcal H}J_j(t)\Phi_{t_0\to t}^{\mathcal H}(\rho)J_j(t)^*,\quad \Phi_{t_0\to t_0}^{\mathcal H}(\rho)=\rho,\\
-\frac{d}{dt}\mathcal C_{t\to t_R}^{\mathcal H}(A)&=K(t)^*\mathcal C_{t\to t_R}^{\mathcal H}(A)+\mathcal C_{t\to t_R}^{\mathcal H}(A)K(t)+\sum_{j\in\mathcal H}J_j(t)^*\mathcal C_{t\to t_R}^{\mathcal H}(A)J_j(t),\quad \mathcal C_{t_R\to t_R}^{\mathcal H}(A)=A.
\end{aligned}\right.\tag{S18.3}$$

1. **Bilinear trace conservation and whole-word expansion**: for arbitrary $\rho,A\in\mathcal L(E)$, differentiating $F(t)=\operatorname{Tr}\bigl(\Phi_{t_0\to t}^{\mathcal H}(\rho)\,\mathcal C_{t\to t_R}^{\mathcal H}(A)\bigr)$ cancels term by term via trace cyclicity:
   $$F'(t)=\operatorname{Tr}\!\left(\frac{d\Phi}{dt}\,\mathcal C+\Phi\,\frac{d\mathcal C}{dt}\right)=0\qquad\forall t\in[t_0,t_R],\tag{S18.4}$$
   equating $\operatorname{Tr}(\Phi_{t_0\to t_R}^{\mathcal H}(\rho)A)=F(t_R)=F(t_0)=\operatorname{Tr}(\rho\,\mathcal C_{t_0\to t_R}^{\mathcal H}(A))$. Iterating Duhamel along $U_{\rm eff}$ expands $\mathcal C_{t_0\to t_R}^{\mathcal H}(A)=\sum_{n=0}^\infty\mathcal E_n^{\mathcal H}(t_0;A)=\mathcal E_{\rm end}^{\mathcal H}(t_0;A)$ in operator norm, proving (10.2).
2. **Positivity, trace non-increase, and whole-bath trace preservation**: decomposing $\rho=\sum_\alpha|x_\alpha\rangle\langle x_\alpha|\ge0$ gives $\operatorname{Tr}(\Phi_{t_0\to t_R}^{\mathcal H}(\rho)A)\ge0$ for all $A\ge0$, hence $\Phi_{t_0\to t_R}^{\mathcal H}(\rho)\ge0$; setting $A=I$ with $\mathcal H\subseteq\mathcal I$ yields via (S18.2)
   $$\begin{aligned}
   \operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal H}(\rho)&=\sum_\alpha\sum_{n=0}^\infty\sum_{w\in\mathcal H^n}\int_{\Delta_n}\|\mathcal A_{n,w}x_\alpha\|^2d\mathbf s\\
   &\le\sum_\alpha\sum_{n=0}^\infty\sum_{w\in\mathcal I^n}\int_{\Delta_n}\|\mathcal A_{n,w}x_\alpha\|^2d\mathbf s=\sum_\alpha\|x_\alpha\|^2=\operatorname{Tr}\rho;
   \end{aligned}$$
   and at $\mathcal H=\mathcal I$, $\mathcal C_{t\to t_R}^{\mathcal I}(I)\equiv I$ (since $K^*+K+\sum_{j\in\mathcal I}J_j^*J_j=0$) gives $\operatorname{Tr}\Phi_{t_0\to t_R}^{\mathcal I}(\rho)=\operatorname{Tr}\rho$ for all $\rho\in\mathcal L(E)$, proving Theorem 10.1(2).

**Formal correspondence.** Commits B291 and B300 respectively bind `Verification/physics/stage10/independent-bell/munich/readout-domain/evidence/source-kraus-word-wave-rha0291/source-r0004/SourceKrausWordWave291.lean` (`wordFunction_measurable`, `lintegral_bornDensity`, `bornMeasure_univ`, `sourceIsometry`) and `source-endpoint-recycling-rha0300/density-source-r0001/SourceEndpointDensity300.lean` (`whole_word_trace_hasSum`, `whole_word_trace_eq_recycling_IVP`, `densityFlow_positive`, `densityFlow_trace_nonincreasing`, `whole_bath_trace_identity`).
