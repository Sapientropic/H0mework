# Physics Common Source · third edition

Run from `papers/physics-common-source` with Python 3, Pandoc, XeLaTeX, xeCJK and
Noto Serif/Sans CJK SC. The editable SVG and publication figures share their source names.

```sh
python3 scripts/build_pdf.py manuscript.md --output build/physics-common-source.pdf --work-dir build/work-manuscript
python3 scripts/build_pdf.py manuscript-en.md --output build/physics-common-source-en.pdf --work-dir build/work-manuscript-en
python3 scripts/build_pdf.py supplement.md --output build/physics-common-source-supplement.pdf --work-dir build/work-supplement
python3 scripts/build_pdf.py supplement-en.md --output build/physics-common-source-supplement-en.pdf --work-dir build/work-supplement-en
```

The four reading editions, manuscript text and figures are distributed under CC BY 4.0.
The source binding records the fixed proof selection and its separate acceptance.
