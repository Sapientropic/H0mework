# First-Player Non-Negativity and Proof-Carrying Regional DAG Strategy Certificates for Positional-Superko Go

**Author: Jian Gao**\
Independent Researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

## Abstract

Under positional superko (PSK), two occurrences of the same Go board can admit different moves. In Lean 4 we show that the visible position together with the set of all past boards forms a strong bisimulation. This quotient mechanizes Weninger and Hayward's opening-pass proof that Black can force a nonnegative margin on every square board under no-suicide, pass-exempt PSK and double-pass area scoring. For regional play, maximal historical Black footprints give a sufficient test of global freshness. A connected-exterior capacity bound lets a verified checker lift a corner directed acyclic graph (DAG) to a full-board strategy. The terminal geometry allows enemy stones inside vital chambers while preserving every core stone and counting singleton eyes as guaranteed area. On a 12-ply $19\times 19$ position, the checker validated a DAG with $1{,}700{,}986$ nodes and $2{,}007{,}462$ edges and generated a strategy certificate for margin at least $-345$. Its leaves certify at least eight Black area points in the corner. At the 11-ply position, a single execution assembles certificates for all 351 legal non-resigning White replies. It lifts the resulting certificate to the actual 10-ply predecessor through Black’s move at (2,1).

**Keywords**: Go; positional superko; first-player non-negativity; vital chambers; GHI; strategy certificates; Lean 4

---

<a id="sec-1"></a>

## 1 Introduction: Two-Scale Superko History Compression, Main Theorems, and Trusted Computing Base

<a id="sec-1-1"></a>

### 1.1 Why Visible Boards Fail and How Superko History Compresses at Two Scales

Consider two short, legally reachable opening sequences in the upper-left corner of a $19\times 19$ Go board (using $0$-indexed coordinates $(r,j)\in\{0,\dots,18\}^2$, mapped to standard Go columns `ABCDEFGHJKLMNOPQRST[j]` and rows $19-r$, so $(0,0)=\mathtt{A19}$):

- **5-ply sequence $\gamma_1$**: $1.\,\mathtt{B}(1,0),\;2.\,\mathtt{W}(0,2),\;3.\,\mathtt{B}(2,0),\;4.\,\mathtt{W}(1,1),\;5.\,\mathtt{B}(0,1)$;
- **7-ply sequence $\gamma_2$**: $1.\,\mathtt{B}(1,0),\;2.\,\mathtt{W}(0,0),\;3.\,\mathtt{B}(2,0),\;4.\,\mathtt{W}(0,2),\;5.\,\mathtt{B}\,\mathtt{pass},\;6.\,\mathtt{W}(1,1),\;7.\,\mathtt{B}(0,1)$ (where move $7$ captures the corner stone $\mathtt{W}(0,0)$).

Both paths arrive at the exact same visible board position: Black occupies $\{(0,1),(1,0),(2,0)\}$, White occupies $\{(0,2),(1,1)\}$, the consecutive pass counter is $p_{\mathrm{pass}}=0$, White is to move, and Black's stone at $(0,1)$ stands in atari with sole liberty $(0,0)$. Under positional superko (PSK), however, the two positions do not have the same legal continuations: after $\gamma_1$, playing $\mathtt{W}(0,0)$ legally captures $\mathtt{B}(0,1)$, yielding $357$ legal non-resigning moves on $19\times 19$; after $\gamma_2$, capturing at $\mathtt{W}(0,0)$ recreates the exact board position already reached after move $6$ of $\gamma_2$, so superko forbids $\mathtt{W}(0,0)$ and leaves $356$ legal non-resigning moves (Figure 1(a) and Example 2.3; this is a corner basic-ko configuration, and global PSK extends the same prohibition to board cycles of arbitrary length).

Because PSK Go is not a memoryless Markov game on visible boards, two classic lines of reasoning encounter structural obstacles rooted in the same history dependence:

1. **Opening-pass strategy stealing**. Weninger and Hayward [@WeningerHayward2017, Theorem 1] prove first-player non-loss for rectangular PSK Go by letting Black pass and then swapping colours. In Go, an extra stone can remove a liberty, so the monotone placement argument for Hex [@Nash1952; @Gale1979] and other positional games [@Beck2008] is unavailable. With an explicit history list, the opening pass inserts a second empty-board entry and sets the pass count to one. The formal proof identifies the exact quotient in which the reflected continuation can be compared with an immediate Black placement.
2. **Lifting local life-and-death graphs**. Merging local positions in a DAG creates graph-history interaction (GHI) [@Campbell1985; @KishimotoMuller2004; @KishimotoMuller2005]. Exterior moves also change the full history and can change liberties of chains crossing the regional boundary. Fixed-wall solvers [@Muller2001] and relevance-zone solution trees [@ShihEtAl2022RelevanceZones] address different parts of this problem. Here the certificate establishes a full-board area guarantee under PSK.

At full-board scale we use a quotient of legal transitions. At regional scale we retain the exact answers to Black-footprint containment queries.
$$q_{\mathrm{PSK}}(F) := \bigl(V(F),\;\operatorname{set}(H(F))\bigr), \qquad \mathcal{A}_{\mathrm{B}}(H) := \max_{\subseteq}\bigl\{\,S_{\mathrm{B}}(B') \;:\; (B',\cdot)\in H\,\bigr\}.\tag{1.1}$$
At the full-board scale, because no-suicide PSK tests only whether a post-capture board has ever appeared in $H$, the set-valued quotient $q_{\mathrm{PSK}}$—forgetting order, multiplicity, and turn tags—is a strong bisimulation; the duplicate empty board left by an opening `pass` collapses into $\{B_\emptyset\}$, while any winning second-player continuation must place a stone on move $2$, resetting $p_{\mathrm{pass}}\mapsto 0$ and landing in the exact $q_{\mathrm{PSK}}$-class of Black's direct opening placement (Figure 1(b)). On the regional checker path, $\mathcal{A}_{\mathrm{B}}(H)$ represents the downset of historical full-board Black footprints. When the newly produced footprint lies outside that downset, the new board is globally fresh. The linear bound on total occupancy plus rank supplies exterior liberties for White chains in the $312$-point connected exterior.

<a id="sec-1-2"></a>

### 1.2 Main Results

Let $V_n := \{0,\dots,n-1\}^2$ denote the $n\times n$ grid. For a board $B$, let $S_c(B)\subseteq V_n$ be the stone set of colour $c\in\{\mathrm{B},\mathrm{W}\}$, $\operatorname{occ}(B):=S_{\mathrm{B}}(B)\cup S_{\mathrm{W}}(B)$ the occupied set, and $\Delta(B):=\operatorname{Area}(B,\mathrm{B})-\operatorname{Area}(B,\mathrm{W})\in\mathbb{Z}$ the net Tromp–Taylor area margin. We establish three main results (detailed definitions appear in Sections 2–5; Lean 4 module mappings appear in Appendix Table B.1).

<a id="thm-a"></a>

**Theorem A (Mechanized first-player non-loss under positional superko; see Theorem 3.4 and Corollary 3.5).**
Under no-suicide Tromp–Taylor area scoring with pass-exempt positional superko and double-pass termination without dead-stone removal, for every board size $n\in\mathbb{N}$ the initial empty frame $F_0(n)$ satisfies first-player non-negativity (equivalently, Black non-loss at komi $0$): White has no strategy forcing $\Delta(B)\le -1$, and Black possesses a strategy certificate guaranteeing finite termination with $\Delta(B)\ge 0$ against every legal non-resigning White policy. On $19\times 19$, every exact initial margin value $v$ witnessed by matching bilateral strategy certificates satisfies $0 \le v \le 361$.

<a id="thm-b"></a>

**Theorem B (Opponent-occupied vital-chamber life law and typed strategy certificates; see Theorems 4.2, 4.3, and 4.6).**
For every board size $n\in\mathbb{N}$ and colour $c\in\{\mathrm{B},\mathrm{W}\}$:

1. **Eye coalitions and opponent-occupied vital chambers**: Let $C\subseteq S_c(B)$ be a nonempty core stone set and $\mathcal{K}$ a pairwise-disjoint family of nonempty enclosed chambers disjoint from $C$, such that every $4$-connected component of $C$ on the core-mask board is adjacent to every vertex of at least two distinct chambers $K_1,K_2\in\mathcal{K}$. Even when multi-point chambers ($\lvert K\rvert\ge 2$) contain opponent stones, provided each chamber currently contains no $c$-stones and retains at least one empty vertex, $c$ can pass indefinitely against all legal non-resigning opponent moves: $C$ is never captured and every chamber retains at least one empty vertex. Setting the guaranteed area set $P := C \cup \bigcup_{K\in\mathcal{K},\,\lvert K\rvert=1} K$, every double-pass terminal board satisfies the pass-only margin bound (stated for $c=\mathrm{B}$; negated for $c=\mathrm{W}$):
   $$\Delta(B_{\mathrm{end}}) \;\ge\; 2\lvert P\rvert - n^2.\tag{1.2}$$
2. **Typed strategy certificates and quotient reuse**: Inductively typed certificates $\mathcal{D}$—built from single-move choices, universal branches indexed over the rule kernel's full legal expansion, terminal score leaves, and the pass-alive leaves above—compile constructively into executable policies $\pi_{\mathcal{D}}$ guaranteeing the target threshold against all opponents and transporting across $q_{\mathrm{PSK}}$-equivalent histories.

<a id="thm-c"></a>

**Theorem C (Soundness of the regional footprint-antichain DAG checker and $19\times 19$ million-node corner survival; see Theorem 5.6 and Certified Computation 6.3).**
Let $R\subsetneq V_{19}$ be a region with $4$-connected exterior $V_{19}\setminus R$ (instantiated to the upper-left $7\times 7$ corner, $\lvert V_{19}\setminus R\rvert=312$). Whenever an untrusted directed graph passes a single ascending-rank pass ($\operatorname{rank}(s)=2r+\mathbf{1}_{\tau=\mathrm{W}}$) verifying local transitions, maximal Black-footprint antichain freshness, exhaustive coverage of local non-suicidal White plays plus exterior and `pass` moves, and pass-alive leaf geometry, then for any $19\times 19$ frame $F$ matching the root snapshot with linear capacity guard
$$\lvert\operatorname{occ}(B)\rvert + \operatorname{rank}(s) \;<\; \lvert V_{19}\setminus R\rvert = 312,\tag{1.3}$$
the verified checker produces a full-board `Certificate` for $\Delta\ge-345$. Its geometric leaves supply a strategy securing at least eight Black area points in $R$ (Theorem 5.6). At the 12-ply source `W31`, one run checked all $1{,}700{,}986$ nodes and $2{,}007{,}462$ edges of the input DAG. At its 11-ply predecessor $H_{11}$, one execution produces all 351 successor certificates and lifts the assembled certificate through Black’s move $(2,1)$ to the native 10-ply frame (Certified Computation 6.3).

Table 1 pairs the five core invariants behind Theorems A–C with the exact counterexample or failure triggered if each condition is omitted.

**Table 1 Core invariants of two-scale PSK compression and regional DAG lifting, paired with minimal failure counterexamples.**

| Layer & mathematical mechanism | Exact failure if the condition is omitted | Exact invariant used & theorem |
| --- | --- | --- |
| **Full-board opening-pass reflection** | Move-1 `pass` leaves duplicate empty history and $p_{\mathrm{pass}}=1$, differing syntactically from $F_0(n)$ | Set quotient $q_{\mathrm{PSK}}(F)=(V,\operatorname{set}(H))$ collapses duplicates; White's move-2 stone resets $p_{\mathrm{pass}}\mapsto 0$ (Lemma 3.2, Theorem 3.4) |
| **Area scoring in invaded rooms** | The last empty point of the invaded two-point chamber in Example 1.1 is dame. Adding it to $P$ increases $\lvert P\rvert$ by one and the formula $2\lvert P\rvert-n^2$ by two. | Core stones and singleton eyes form the guaranteed set $P$ (Theorem 4.3, Example 4.4). |
| **Boundary-crossing exterior liberties** | If the exterior were full, a chain crossing $\partial R$ that appears alive locally via boundary extension would have zero global liberties and be captured | Connected-exterior pigeonhole guard: $\lvert\operatorname{occ}(B)\rvert<\lvert V_{19}\setminus R\rvert\implies$ boundary chains retain an exterior liberty (Proposition 5.2) |
| **Capture-and-replay PSK freshness** | Virgin-point checks reject valid recaptures (Example 5.4); ignoring history permits global PSK violations | Maximal Black-footprint antichain: if $C'$ lies inside no $M\in\mathcal{H}$, the $19\times 19$ board is globally fresh (Theorem 5.3) |
| **Arbitrary opponent moves on $312$ exterior points** | Expanding exterior points multiplies branching by $312$; ignoring them misses pass resets and stone growth | Single `.environment` port paired with strict rank descent and preservation of the occupancy bound $\lvert\operatorname{occ}(B')\rvert+\operatorname{rank}(s')<312$ (Theorem 5.6) |

![Figure 1 | Reachable PSK history bifurcation and opening-pass bisimulation under $q_{\mathrm{PSK}}$. (a) Two legal paths from the empty board (5-ply $\gamma_1$ and 7-ply $\gamma_2$) reach the exact same visible board, yet corner capture W(0,0) is legal after $\gamma_1$ and PSK-blocked after $\gamma_2$. (b) Quotient $q_{\mathrm{PSK}}$ collapses duplicate empty-board history while stone placement resets $p_{\mathrm{pass}}$, proving arbitrary-$n$ first-player non-loss at komi 0.](figures/fig1-psk-stealing-en.pdf)

<a id="sec-1-3"></a>

### 1.3 Three Pen-and-Paper Examples

Before giving general definitions, three concrete hand-checkable calculations illustrate how Theorems A, B, and C operate.

<a id="ex-1-1"></a>

**Example 1.1 (Pen-and-paper checks of two-scale compression and vital-chamber scoring).**

1. **$1\times 1$ double pass and $n\ge 2$ opening-pass quotient**: On $1\times 1$, the lone vertex $(0,0)$ has no neighbours, so placing at $(0,0)$ leaves zero liberties without capture and is barred by no-suicide. Black must `pass`, White must `pass`, and $\Delta(B_\emptyset)=0$. On $n\ge 2$, suppose toward a contradiction that White forces $\Delta\le -1$ from $F_0(n)$. Let Black play `pass` at move $1$ to reach $F_1$ (history $[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W})]$, $p_{\mathrm{pass}}=1$). If White replies `pass`, the game ends immediately at $\Delta(B_\emptyset)=0\not\le -1$; hence White must play at some vertex $x$ on move $2$ to reach $F_2$, resetting $p_{\mathrm{pass}}=0$ with history set $\{B_\emptyset, W_x\}$. Swapping colours gives $\operatorname{swap}(F_2)$ with White to move, $p_{\mathrm{pass}}=0$, and history set $\{B_\emptyset, B_x\}$, matching $q_{\mathrm{PSK}}(T_1)$ where $T_1$ is reached from $F_0(n)$ by Black playing $x$ directly on move $1$. Thus White forcing $\Delta\le -1$ from $F_2$ reflects into Black forcing $\Delta\ge +1$ from $T_1$, contradicting White's assumed strategy against Black's direct opening move $x$.
2. **A seven-stone core with an invaded two-point chamber**. In the upper-left corner of $19\times 19$, take the connected Black core $C=\{(0,2),\allowbreak(1,0),\allowbreak(1,1),\allowbreak(1,2),\allowbreak(2,1),\allowbreak(3,0),\allowbreak(3,1)\}$, singleton eye $K_1=\{(2,0)\}$ and two-point chamber $K_2=\{(0,0),(0,1)\}$. Place White at $(0,0)$ and leave $(0,1)$ empty. White cannot fill $K_1$: Black retains its other liberty and the placement is suicidal. White also cannot fill $(0,1)$: the resulting White chain borders only the Black core, which still has a liberty in $K_1$. Black can therefore pass and preserve the core and eye. At scoring, they contribute eight points to Black. Disjoint scoring sets bound White's area by $361-8=353$, giving $\Delta\ge-345$. For this particular invaded configuration the last empty point is dame, so a board with maximal White area has 352 White points and $\Delta=-344$ (Example 4.4).
3. **Linear capacity budget at the 12-ply benchmark**: At the 12-ply position `W31` (Section 6), $6$ Black and $6$ White stones occupy the board ($\lvert\operatorname{occ}(B)\rvert=12$) with Black to move ($\tau=\mathrm{B}$, so $\operatorname{rank}(s)=2r$). With remaining budget $r=10$ full rounds ($\operatorname{rank}(s)=20$), we have $\lvert\operatorname{occ}(B)\rvert+\operatorname{rank}(s)=12+20=32<312$: Black's opening reply at move $13$ consumes one round budget ($r:10\mapsto 9$), leaving at most $13$ stones while White's rank drops to $2\cdot 9+1=19$ ($13+19=32<312$), and every subsequent local or exterior move increments stone count by at most $1$ while decrementing rank by $1$, keeping exterior liberties intact throughout the DAG.

<a id="sec-1-4"></a>

### 1.4 Trusted Computing Base, Axiom Footprint, and Reading Routes

Following standard practice in certified proof checking [@CruzFilipe2017LRAT; @TanHeuleMyreen2021CakeLPR], we divide verification responsibilities across three explicit tiers (Figure 4(b)):

1. **Lean kernel** [@deMouraUllrich2021Lean4]. The original axiom audit checks the kernel-level declarations for termination, first-player non-loss, static life, the regional checker, and the incremental evaluator. Its dependencies lie within `propext`, `Classical.choice` and `Quot.sound`. Section 4.3 and Appendix C distinguish theorem proving from executable policy generation.
2. **Lean execution**. The `W31` checker, the `W02`/`W32` corridor producers, the original batch, complete assembly, and finite controls run as Lean programs. The historical `lean --run` receipts rely on Lean's execution path for those programs, including its interpreter and runtime. The theorem that an accepted program produces a certificate is checked by the kernel. The successful concrete executions are recorded as run receipts (Section 6.2).
3. **Outside the TCB and independent script checks**: The C++ search and its emitted graph provide untrusted candidates. The checker verifies the edges and leaves under the Lean rule kernel. Complementarily, the zero-dependency Python script `validation/verify_manuscript.py` independently verifies the hand-checkable small-board and bifurcation examples (5v7-ply $\gamma_1/\gamma_2$, $0\times 0..2\times 2$ minimax values, Example 4.4, and Example 5.4). Sections 2–6 depend only on `RulesKernel` and `mathlib` [@mathlib2020]; only Section 7's incremental bracket state machine interfaces with companion process-state modules [@Gao2026OneBitV2; @Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2].

**Specialist reading routes**: Readers focused on **combinatorial game theory and symmetry** can read **§2 → §3 → §8.1**; readers focused on **computer Go, tsumego life-and-death, and GHI** can read **§2.1 → §4.2 → §5 → §6 → §8.2–8.3**; readers focused on **interactive theorem proving and certifying algorithms** can read **§1.4 → §4.3 → §5.3 → §7 → Appendices B–C**.

---

<a id="sec-2"></a>

## 2 No-Suicide Tromp–Taylor Positional-Superko Kernel and History Bifurcation

<a id="sec-2-1"></a>

### 2.1 Grid Components, Capture, Positional Superko, and Double-Pass Area Scoring

For board size $n\in\mathbb{N}$, let $V_n := \{0,\dots,n-1\}^2$ denote the grid vertices ($V_0=\emptyset$; on $n=19$, $(r,j)$ corresponds to column `ABCDEFGHJKLMNOPQRST[j]` and row $19-r$). Two vertices $x=(r,j)$ and $y=(r',j')$ are $4$-adjacent ($x\sim y$) iff $\lvert r-r'\rvert+\lvert j-j'\rvert=1$. Let colours be $\{\mathrm{B},\mathrm{W}\}$ (represented as `.positive` and `.negative` in `StoneColour`) with involution $\bar{\mathrm{B}}=\mathrm{W}$, $\bar{\mathrm{W}}=\mathrm{B}$. A board is a map $B : V_n \to \{\bot,\mathrm{B},\mathrm{W}\}$ with $\bot$ denoting empty vertices; write $S_c(B):=\{x\in V_n : B(x)=c\}$ and $\operatorname{occ}(B):=S_{\mathrm{B}}(B)\cup S_{\mathrm{W}}(B)$.

For $x\in V_n$, let $\operatorname{Comp}(B,x)\subseteq V_n$ be the maximal $4$-connected component containing $x$ with constant value $B(y)=B(x)$. The liberty set of a stone chain $G=\operatorname{Comp}(B,x)$ ($B(x)\neq\bot$) is $\operatorname{Lib}(B,G):=\{z\in V_n : B(z)=\bot \land \exists y\in G,\, y\sim z\}$.

<a id="def-2-1"></a>

**Definition 2.1 (No-suicide, pass-exempt PSK rule kernel and double-pass area readout, `RulesKernel` / `ScoreReadout`).**
Fix $n\in\mathbb{N}$:

1. **Post-capture board**: Placing colour $c$ at an empty vertex $x$ ($B(x)=\bot$) forms $B_1 := B[x\mapsto c]$, removes the adjacent zero-liberty enemy chains $\operatorname{Cap}_n(B,c,x) := \{y\in V_n : B_1(y)=\bar{c},\; \operatorname{Lib}(B_1,\operatorname{Comp}(B_1,y))=\emptyset,\; \exists v\in\operatorname{Comp}(B_1,y),\; v\sim x\}$, and yields
   $$\operatorname{After}(B,c,x)(z) := \begin{cases} \bot, & z\in \operatorname{Cap}_n(B,c,x), \\ B_1(z), & z\notin \operatorname{Cap}_n(B,c,x). \end{cases}\tag{2.1}$$
2. **Native frame and PSK transition**: A game frame is a quintuple $F=(B,\tau,p_{\mathrm{pass}},\mathrm{st},H)$ with visible quadruple $V(F)=(B,\tau,p_{\mathrm{pass}},\mathrm{st})$, side to move $\tau\in\{\mathrm{B},\mathrm{W}\}$, consecutive pass count $p_{\mathrm{pass}}\in\mathbb{N}$, status $\mathrm{st}\in\{\mathtt{playing},\mathtt{twoPasses},\mathtt{resigned}(c)\}$, and history list $H=[(B_0,\tau_0),\dots,(B_k,\tau_k)]$. The initial frame is $F_0(n):=(B_\emptyset,\mathrm{B},0,\mathtt{playing},[(B_\emptyset,\mathrm{B})])$. Throughout this work we fix `Law.positionalSuperko 0` (forbidding single- and multi-stone suicide, enforcing global PSK on placements, and exempting `pass` from superko—as distinct from multi-stone-suicide Tromp–Taylor variants). When $\mathrm{st}=\mathtt{playing}$, the partial step on scoring moves $m\in\{\mathtt{play}(x):x\in V_n\}\cup\{\mathtt{pass}\}$ is
   $$\operatorname{step}(F,m) := \begin{cases} \bigl(B,\;\bar{\tau},\;p_{\mathrm{pass}}+1,\;\mathrm{st}',\;H\mathbin{\Vert}[(B,\bar{\tau})]\bigr), & m=\mathtt{pass},\\[4pt] \bigl(B',\; \bar{\tau},\; 0,\; \mathtt{playing},\; H\mathbin{\Vert}[(B',\bar{\tau})]\bigr), & m=\mathtt{play}(x),\; B(x)=\bot,\; \operatorname{Lib}(B',\operatorname{Comp}(B',x))\neq\emptyset,\; B'\notin\operatorname{set}(H), \end{cases}\tag{2.2}$$
   where $B':=\operatorname{After}(B,\tau,x)$, $\operatorname{set}(H):=\{B'' : (B'',\cdot)\in H\}$, and $\mathrm{st}'=\mathtt{twoPasses}$ if $p_{\mathrm{pass}}+1\ge 2$ else $\mathtt{playing}$. Let $\operatorname{Expand}(F)$ denote the ordered list of all legal non-resigning (move, next frame) pairs.
3. **Double-pass area readout without dead-stone removal**: An empty component $U=\operatorname{Comp}(B,z)$ ($B(z)=\bot$) reaches only colour $c$ ($\operatorname{ReachesOnly}(B,U,c)$) iff $\{B(y) : B(y)\ne\bot,\ \exists u\in U,\ u\sim y\}=\{c\}$. Area score and net margin are
   $$\operatorname{Area}(B,c) := \lvert S_c(B)\rvert + \bigl\lvert\{\,z\in V_n : B(z)=\bot \land \operatorname{ReachesOnly}(B,\operatorname{Comp}(B,z),c)\,\}\bigr\rvert, \qquad \Delta(B) := \operatorname{Area}(B,\mathrm{B}) - \operatorname{Area}(B,\mathrm{W}),\tag{2.3}$$
   evaluated directly upon $\mathrm{st}=\mathtt{twoPasses}$ without heuristic dead-group removal.

<a id="sec-2-2"></a>

### 2.2 Composite Well-Founded Rank and $19\times 19$ Materialized-Step Identity

Let $\mathcal{B}_n=\{\bot,\mathrm{B},\mathrm{W}\}^{V_n}$ and $\mathcal{U}(F)=\mathcal{B}_n\setminus\operatorname{set}(H(F))$ be the set of unseen boards. For a playing frame set $\phi(F)=2$ when no pass is pending and $\phi(F)=1$ otherwise.

<a id="prop-2-2"></a>

**Proposition 2.2 (Composite termination rank and $19\times 19$ materialized-step identity, `Termination` / `MaterializedStep`; GO2, GO8).**

1. **Strict rank descent**: Define
   $$\rho(F) := \begin{cases} 2\lvert\mathcal{U}(F)\rvert+\phi(F), & \mathrm{st}=\mathtt{playing},\\ 0, & \mathrm{st}\ne\mathtt{playing},\end{cases} \qquad \rho(F)\le 2\cdot 3^{n^2}+2.\tag{2.4}$$
   Every legal PSK transition from play strictly decreases $\rho$. A placement records a previously unseen board, lowering $2\lvert\mathcal{U}\rvert$ by at least two at the cost of increasing $\phi$ by at most one. A pass cannot increase $\lvert\mathcal{U}\rvert$ and changes $\phi$ from two to one or reaches rank zero. Resignation immediately reaches rank zero. Thus every sequence of legal moves terminates within $2\cdot 3^{n^2}+2$ plies.
2. **Materialized $19\times19$ step equivalence**. `MaterializedStep.step?` computes a post-capture board once and reuses its matrix for liberty, repetition and history reads. `step_eq` proves equality with the native step for all laws, frames and moves. `scoring_eq` proves equality of the non-resigning expansion lists for `Law.positionalSuperko 0`.

<a id="sec-2-3"></a>

### 2.3 Reachable Same-Board History Bifurcation and Full-Port Control

We record the exact kernel behaviour on the reachable 5-ply versus 7-ply corner ko paths from Section 1.1 alongside the 13-ply regression runner in the repository.

<a id="ex-2-3"></a>

**Example 2.3 (Reachable same-board ko bifurcation and the 13-ply `RunMaterializedStep19` full-port control; GO8).**
Replaying the 5-ply sequence $\gamma_1$ and 7-ply sequence $\gamma_2$ of Section 1.1 from $F_0(19)$ (verified by hand and by `verify_manuscript.py`) yields frames $F_{\gamma_1}$ and $F_{\gamma_2}$ with identical visible state $V(F_{\gamma_1})=V(F_{\gamma_2})$ (Black $\{(0,1),(1,0),(2,0)\}$, White $\{(0,2),(1,1)\}$, White to move, $p_{\mathrm{pass}}=0$). Move $6$ of $\gamma_2$ visited the board $B^{\star}$ (Black $\{(1,0),(2,0)\}$, White $\{(0,0),(0,2),(1,1)\}$) before $\mathtt{B}(0,1)$ captured $\mathtt{W}(0,0)$ on move $7$. Testing $\mathtt{W}(0,0)$ (`A19`) gives $\operatorname{After}(B,\mathrm{W},(0,0))=B^{\star}$, which is legal at $F_{\gamma_1}$ ($357$ non-resigning ports) and PSK-blocked at $F_{\gamma_2}$ ($356$ non-resigning ports), while `pass` remains legal at both. Complementarily, the compiled Lean runner `RunMaterializedStep19.lean` constructs a synthetic 13-ply control pair $(F_{13},F'_{13})$ at $H_{11}+\mathtt{W}(0,2)+\mathtt{B}(3,1)$ by appending the post-`W(0,3)` board signature to `positionHistory`, verifying full-port agreement ($349$ vs. $348$ ports) between materialized and functional kernels (Table 2).

**Table 2 Comparison of two same-board, different-history PSK bifurcations on $19\times 19$.**

| Frame pair | Origin & shared visible state | History-set difference | Tested move outcomes | $19\times 19$ legal ports |
| --- | --- | --- | --- | --- |
| **Reachable ko pair $(F_{\gamma_1}, F_{\gamma_2})$** | Both legally played from $F_0(19)$ (5-ply $\gamma_1$ vs. 7-ply $\gamma_2$); White to move, $p_{\mathrm{pass}}=0$ | $B^{\star}\notin\operatorname{set}(H_{\gamma_1})$, whereas $B^{\star}\in\operatorname{set}(H_{\gamma_2})$ (from ply 6) | `W(0,0)`: legal capture after $\gamma_1$, PSK-blocked after $\gamma_2$; `pass` legal on both | $357$ vs. $356$ |
| **Regression control $(F_{13}, F'_{13})$** | 13-ply corridor frame $F_{13}$ vs. synthetic control $F'_{13}$ with appended signature | $F'_{13}$ pre-inserts post-`W(0,3)` board into `positionHistory` | `W(0,3)`: legal at $F_{13}$, PSK-blocked at $F'_{13}$; `pass` legal on both | $349$ vs. $348$ |

---

<a id="sec-3"></a>

## 3 Full-Board History Quotient and Arbitrary-Size First-Player Non-Loss

<a id="sec-3-1"></a>

### 3.1 Opening Pass and Two Identities for Strategy Transport

Weninger and Hayward [@WeningerHayward2017, Theorem 1] prove non-loss on rectangular PSK boards by passing from the empty board and swapping colours the first time White places a stone. Their state already includes the set of earlier boards. In the native Lean game, the history instead retains every entry and its turn tag. To transfer the strategy on that carrier we prove two identities:

1. **History-list asymmetry**: $F_0(n)$ carries singleton history $[(B_\emptyset,\mathrm{B})]$, whereas passing on move $1$ produces $F_1$ with two-element history $[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W})]$, which colour swap does not shorten.
2. **Pass-counter offset**: $F_1$ has $p_{\mathrm{pass}}=1$, allowing an immediate game-ending second pass that does not exist at $F_0(n)$ ($p_{\mathrm{pass}}=0$).

Subsections 3.2–3.3 discharge both obligations cleanly via the set quotient $q_{\mathrm{PSK}}$ together with the fact that any winning White move at $F_1$ must be a board placement—which resets $p_{\mathrm{pass}}\mapsto 0$.

<a id="sec-3-2"></a>

### 3.2 Colour-Swap Equivariance and Quotient Bisimulation under $q_{\mathrm{PSK}}$

Define pointwise colour swap $\operatorname{swap}(B)(x) := \overline{B(x)}$ (with $\bar{\bot}=\bot$), lifted componentwise to frames:
$$\operatorname{swap}(B,\tau,p_{\mathrm{pass}},\mathrm{st},H) := \bigl(\operatorname{swap}(B),\;\bar{\tau},\;p_{\mathrm{pass}},\;\operatorname{swap}(\mathrm{st}),\;[(\operatorname{swap}(B'),\bar{\tau}') : (B',\tau')\in H]\bigr), \qquad \Delta(\operatorname{swap}(B)) = -\Delta(B).\tag{3.1}$$
Because colour inversion preserves $4$-connected components, liberties, captures, and monochromatic empty-region borders, $\operatorname{Area}(\operatorname{swap}(B),c)=\operatorname{Area}(B,\bar{c})$.

<a id="lem-3-1"></a>

**Lemma 3.1 (Score antisymmetry and step equivariance under colour swap, `InitialColourPass`).**
For all $n\in\mathbb{N}$, frames $F$, and scoring moves $m$, $\operatorname{step}(\operatorname{swap}(F),m) = \operatorname{swap}(\operatorname{step}(F,m))$ (both defined or both undefined), and terminal margins satisfy Equation (3.1).

Define the PSK quotient map (`PositionFace`) by $q_{\mathrm{PSK}}(F) := (V(F),\operatorname{set}(H(F)))$, and write $F_1 \equiv_{\mathrm{PSK}} F_2$ when $q_{\mathrm{PSK}}(F_1)=q_{\mathrm{PSK}}(F_2)$.

<a id="lem-3-2"></a>

**Lemma 3.2 (Strong bisimulation under $q_{\mathrm{PSK}}$, `PositionFace.legalStep_lift`; GO2).**
Whenever $F_1 \equiv_{\mathrm{PSK}} F_2$, for every scoring move $m$:

1. $\operatorname{step}(F_1,m)$ is defined iff $\operatorname{step}(F_2,m)$ is defined;
2. When defined with successors $F'_1,F'_2$, we have $F'_1 \equiv_{\mathrm{PSK}} F'_2$, and $\operatorname{Expand}(F_1),\operatorname{Expand}(F_2)$ list identical moves with pairwise $\equiv_{\mathrm{PSK}}$-equivalent successor frames.

*Proof.* Beyond $V(F_1)=V(F_2)$, the sole guard reading $H$ in Equation (2.2) is $B'\notin\operatorname{set}(H)$, which depends only on the unordered set $\operatorname{set}(H)$ and ignores list order, multiplicity, and turn tags. Appending $(B_{\mathrm{next}},\bar{\tau})$ maps $\operatorname{set}(H)$ to $\operatorname{set}(H)\cup\{B_{\mathrm{next}}\}$ on both sides, preserving $q_{\mathrm{PSK}}$. $\square$

<a id="sec-3-3"></a>

### 3.3 Finite Determinacy, Arbitrary-Size First-Player Non-Loss, and Rule Boundaries

Define the inductive predicate $\operatorname{Forces}(c,\theta,F)$ (`InitialColourPass.Forces`): constructor `.terminal` holds at $\mathrm{st}=\mathtt{twoPasses}$ when $c=\mathrm{B}\land\Delta(B)\ge\theta$ (or $c=\mathrm{W}\land\Delta(B)\le\theta$); constructor `.choose` holds at $\mathrm{st}=\mathtt{playing}$ with $\tau=c$ when some non-resigning $(m,F')\in\operatorname{Expand}(F)$ satisfies $\operatorname{Forces}(c,\theta,F')$; and constructor `.all` holds with $\tau=\bar{c}$ when all non-resigning $(m,F')\in\operatorname{Expand}(F)$ satisfy $\operatorname{Forces}(c,\theta,F')$.

<a id="lem-3-3"></a>

**Lemma 3.3 (Finite PSK dichotomy, incompatibility, and quotient invariance, `Termination` / `InitialColourPass`).**
For every $n\in\mathbb{N}$, reachable frame $F$ with $\mathrm{st}\in\{\mathtt{playing},\mathtt{twoPasses}\}$, and integers $\theta_{\mathrm{B}},\theta_{\mathrm{W}},\theta\in\mathbb{Z}$:

1. **Dichotomy (`forcing_dichotomy`)**: Either $\operatorname{Forces}(\mathrm{B},\theta,F)$ or $\operatorname{Forces}(\mathrm{W},\theta-1,F)$.
2. **Incompatibility (`Forces.incompatible`)**: If $\theta_{\mathrm{W}} < \theta_{\mathrm{B}}$, $\operatorname{Forces}(\mathrm{B},\theta_{\mathrm{B}},F)$ and $\operatorname{Forces}(\mathrm{W},\theta_{\mathrm{W}},F)$ cannot both hold.
3. **Swap and quotient transport**: $\operatorname{Forces}(c,\theta,F) \iff \operatorname{Forces}(\bar{c},-\theta,\operatorname{swap}(F))$; and $F_1 \equiv_{\mathrm{PSK}} F_2 \implies (\operatorname{Forces}(c,\theta,F_1) \iff \operatorname{Forces}(c,\theta,F_2))$.

*Proof.* (1) By well-founded induction on $\rho(F)$ (Proposition 2.2): at $\mathtt{twoPasses}$ leaves, $\Delta(B)\ge\theta \lor \Delta(B)\le\theta-1$ holds in $\mathbb{Z}$; at $\mathtt{playing}$ nodes (`pass` is always legal), De Morgan duality propagates across $\exists/\forall$ children. (2) `Forces.incompatible` pairs both forcing derivations via `Certificate.guarantee` on their joint execution (equivalently descending along $\rho(F)$ to a $\mathtt{twoPasses}$ leaf), yielding $\theta_{\mathrm{B}}\le\Delta(B)\le\theta_{\mathrm{W}}$, contradicting $\theta_{\mathrm{W}}<\theta_{\mathrm{B}}$. (3) By structural induction on `Forces` via Lemmas 3.1 and 3.2. $\square$

<a id="thm-3-4"></a>

**Theorem 3.4 (Arbitrary-size first-player non-loss at komi $0$, `InitialColourPass`; GO2).**
For every board size $n\in\mathbb{N}$:

1. White cannot force a negative margin from the empty board: $\neg\operatorname{Forces}(\mathrm{W}, -1, F_0(n))$;
2. Black forces at least $0$: $\operatorname{Forces}(\mathrm{B}, 0, F_0(n))$, and $\operatorname{Nonempty}(\mathtt{Certificate}\;\mathrm{B}\;0\;(F_0(n)))$ holds.

*Proof.* Suppose $\operatorname{Forces}(\mathrm{W}, -1, F_0(n))$. At $F_0(n)$ Black legally plays `pass`, reaching $F_1 := (B_\emptyset,\mathrm{W},1,\mathtt{playing},[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W})])$, where universal instantiation gives $\operatorname{Forces}(\mathrm{W},-1,F_1)$. Since $\tau(F_1)=\mathrm{W}$, some legal move $m$ yields $F_2=\operatorname{step}(F_1,m)$ with $\operatorname{Forces}(\mathrm{W},-1,F_2)$:

- **Case 1 ($m=\mathtt{pass}$)**: Then $p_{\mathrm{pass}}$ reaches $2$ and $F_2$ terminates on $B_\emptyset$ with $\Delta(B_\emptyset)=0-0=0\not\le -1$, a contradiction (closing $n=0$ and $n=1$ immediately).
- **Case 2 ($m=\mathtt{play}(x)$)**: Placing White at $x$ on $B_\emptyset$ leaves $W_x := \operatorname{After}(B_\emptyset,\mathrm{W},x)\neq B_\emptyset$ with positive liberties and resets $p_{\mathrm{pass}}(F_2)=0$, giving $F_2=(W_x,\mathrm{B},0,\mathtt{playing},[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W}),(W_x,\mathrm{B})])$. Colour swap and Lemma 3.3(3) yield $\operatorname{Forces}(\mathrm{B},+1,\operatorname{swap}(F_2))$. Conversely, playing $x$ directly as Black's opening move from $F_0(n)$ is legal because $\operatorname{swap}(W_x)=\operatorname{After}(B_\emptyset,\mathrm{B},x)=:B_x$ has positive liberties and $B_x\neq B_\emptyset$, reaching $T_1 := (B_x,\mathrm{W},0,\mathtt{playing},[(B_\emptyset,\mathrm{B}),(B_x,\mathrm{W})])$. Both $\operatorname{swap}(F_2)$ and $T_1$ have visible quadruple $(B_x,\mathrm{W},0,\mathtt{playing})$, and their history sets satisfy
  $$\operatorname{set}\bigl(H(\operatorname{swap}(F_2))\bigr) = \{B_\emptyset, B_\emptyset, B_x\} = \{B_\emptyset, B_x\} = \operatorname{set}\bigl(H(T_1)\bigr),\tag{3.2}$$
  so $\operatorname{swap}(F_2) \equiv_{\mathrm{PSK}} T_1$ (equivalently, `InitialColourPass` resets $p_{\mathrm{pass}}\mapsto 0$ on $\operatorname{swap}(F_1)$ to match $q_{\mathrm{PSK}}(F_0(n))$ before pushing $\mathtt{play}(x)$ to $T_1$, yielding the same identity (3.2)). Lemma 3.3(3) gives $\operatorname{Forces}(\mathrm{B},+1,T_1)$, whereas instantiating $\operatorname{Forces}(\mathrm{W},-1,F_0(n))$ at Black's opening move $\mathtt{play}(x)$ gives $\operatorname{Forces}(\mathrm{W},-1,T_1)$, contradicting Lemma 3.3(2) ($-1 < +1$).

Hence $\neg\operatorname{Forces}(\mathrm{W},-1,F_0(n))$, and Lemma 3.3(1) at $\theta=0$ yields $\operatorname{Forces}(\mathrm{B},0,F_0(n))$ and its nonempty certificate (Theorem 4.6). $\square$

<a id="cor-3-5"></a>

**Corollary 3.5 ($19\times 19$ exact-margin bounds and general-$n$ critical-komi interval, `InitialColourPass.exact_value_bounds`).**
On $n=19$, Lean kernel-proves that any value $v$ witnessing `ExactInitialMargin` satisfies $0 \le v \le 361$. On paper for general $n\in\mathbb{N}$, finite zero-sum determinacy (Lemma 3.3(1)–(2)) and the trivial area ceiling $\Delta(B)\le n^2$ determine a unique minimax critical komi $k^\star(n)\in\mathbb{Z}$ (with $\operatorname{Forces}(\mathrm{B},k^\star(n),F_0(n))$ and $\operatorname{Forces}(\mathrm{W},k^\star(n),F_0(n))$) satisfying
$$\forall n\in\mathbb{N},\qquad \operatorname{Forces}(\mathrm{B},\;0,\;F_0(n)) \quad\text{and}\quad 0 \;\le\; k^\star(n) \;\le\; n^2.\tag{3.3}$$

<a id="rem-3-6"></a>

**Remark 3.6 ($2\times 2$ PSK mirror-symmetry breaking and Allis's solution hierarchy).**
Exhaustive finite-tree evaluation (`validation/verify_manuscript.py`) verifies $k^\star(0)=k^\star(1)=0$, whereas $2\times 2$ yields the first strictly positive critical komi $k^\star(2)=+1$ [@Tromp2x2PSK] and exhibits PSK symmetry breaking on a mirror-symmetric board: after $1.\,\mathtt{B}(0,0),\;2.\,\mathtt{W}(1,1),\;3.\,\mathtt{B}(0,1),\;4.\,\mathtt{W}(1,0)$ (capturing both Black stones), only $\{(1,0),(1,1)\}$ hold White stones while $(0,0)$ and $(0,1)$ are mirror-symmetric empty points. Yet move $1$ recorded $B_{(0,0)}$ in history while $B_{(0,1)}$ has never occurred: playing $5.\,\mathtt{B}(0,0)$ loses under subsequent optimal play by both sides (minimax value $\Delta=-4$) because after $6.\,\mathtt{W}(0,1)$ captures $(0,0)$, recapturing three White stones at $(0,0)$ recreates $B_{(0,0)}$ and is PSK-blocked; playing $5.\,\mathtt{B}(0,1)$ wins under optimal play ($\Delta=+1$) by recapturing to the unseen board $B_{(0,1)}$. In Allis's terminology [@Allis1994], because draws ($\Delta=0$) exist at komi $0$, Theorem 3.4 establishes **first-player non-loss at komi $0$** for all $n\in\mathbb{N}$ rather than separating $k^\star(n)=0$ from $k^\star(n)\ge 1$.

<a id="rem-3-7"></a>

**Remark 3.7 (Rule-variant boundary: situational superko and multi-stone suicide).**
Theorem 3.4 is formalized for `Law.positionalSuperko 0`. The argument also works on paper for pass-exempt, no-suicide situational superko (SSK), which forbids repetition of a (board, side-to-move) pair. The extra entry $(B_\emptyset,\mathrm W)$ in the reflected history cannot obstruct a placement because every legal placement leaves a stone. Without pass exemption, PSK forbids the opening pass and SSK forbids White's immediate second pass, so the same proof does not apply. If SSK allows whole-board suicide, the extra entry can matter: on $2\times2$, start at $T_1$, let White always pass and let Black fill the three remaining points. The last placement self-captures the whole Black chain and produces $(B_\emptyset,\mathrm W)$. The direct line admits it and the reflected one forbids it.

---

<a id="sec-4"></a>

## 4 Eye Coalitions, Opponent-Occupied Vital Chambers, and Typed Strategy Certificates

Theorem 3.4 establishes non-loss non-constructively at the empty board; constructing executable $19\times 19$ strategies without expanding terminal board-filling trees requires local pass-alive closures that guarantee full-board area margins under arbitrary exterior play.

<a id="sec-4-1"></a>

### 4.1 Forcing Invariants and Multi-Group Eye-Coalition Closures

<a id="def-4-1"></a>

**Definition 4.1 (Native-forcing invariant, `ClosedUnderNativeForcing`).**
Fix $n$ and beneficiary $c$. A predicate $I(F)$ is a **native-forcing invariant** for threshold $\theta$ when each frame satisfying $I$ is playing or has ended by two passes, and the following conditions hold. At a scoring terminal, its margin meets the threshold ($\Delta\ge\theta$ for Black, $\Delta\le\theta$ for White). On $c$'s turn in play, some legal non-resigning move preserves $I$. On the opponent's turn in play, every legal non-resigning move preserves $I$.

The rank $\rho(F)$ proves that repeatedly choosing an invariant-preserving move reaches a scoring terminal. In both geometric closures below, a pass is a preserving move for the beneficiary.

<a id="thm-4-2"></a>

**Theorem 4.2 (Multi-group eye-coalition pass-alive closure, `EyeCoalition`; GO4).**
Let nonempty $C\subseteq V_n$ and disjoint $E\subseteq V_n$ satisfy: (i) every eye $e\in E$ is non-isolated with all grid neighbours inside $C$ ($\emptyset\neq\{y:y\sim e\}\subseteq C$); (ii) on the core-mask board $M_C$, every $s\in C$ belongs to a $4$-connected component adjacent to at least two distinct eyes in $E$:
$$\forall s\in C,\qquad \bigl\lvert\{\,e\in E : \exists y\in\operatorname{Comp}(M_C,s),\; y\sim e\,\}\bigr\rvert \;\ge\; 2.\tag{4.1}$$
On scoring frames, $C\subseteq S_c(B) \land E\cap\operatorname{occ}(B)=\emptyset$ forms a native-forcing invariant securing $P:=C\cup E$ with threshold $\theta=2\lvert P\rvert-n^2$ for $c=\mathrm{B}$ ($n^2-2\lvert P\rvert$ for $c=\mathrm{W}$).

*Proof.* Every chain containing $s\in C$ on $B$ includes $\operatorname{Comp}(M_C,s)$ and thus has at least two empty liberties in $E$. An opponent play outside $E$ leaves both eyes empty so no stone of $C$ is captured; an opponent play at $e\in E$ borders only $C$-chains retaining another liberty in $E\setminus\{e\}$, capturing nothing and leaving zero liberties, which no-suicide rejects. At $\mathtt{twoPasses}$, $C\cup E\subseteq\operatorname{Area}(B,c)$ and $(C\cup E)\cap\operatorname{Area}(B,\bar{c})=\emptyset$, giving $\Delta(B)\ge\lvert P\rvert-(n^2-\lvert P\rvert)=2\lvert P\rvert-n^2$. $\square$

<a id="sec-4-2"></a>

### 4.2 Opponent-Occupied Vital Chambers, Conservative Area Bound, and One-Step / Miai Birth

Corner search leaves often contain enclosed chambers already invaded by enemy stones. Benson's vital regions require every empty point in a region to border the supporting chain [@Benson1976]. Pure eyes in Sanko require every vertex to border the chain [@KharmaSchintke2026Sanko, Lemma 1]. We use that stronger geometric condition on a fixed core mask. This lets one chamber witness cover different internal fillings and supports a pass-only area guarantee.

<a id="thm-4-3"></a>

**Theorem 4.3 (Opponent-occupied vital-chamber closure and conservative area bound, `VitalChambers`; GO4).**
Let nonempty $C\subseteq V_n$ and a finite chamber family $\mathcal{K}=\{K_1,\dots,K_m\}$ satisfy: (1) each $K\in\mathcal{K}$ is nonempty, disjoint from $C$, and pairwise disjoint; (2) **enclosed non-isolated boundary**: for every $K\in\mathcal{K}$ and $x\in K$, $\emptyset\neq\{y\in V_n:y\sim x\}\subseteq C\cup K$; (3) **full-chamber two-room support**: on the core-mask board $M_C$, every $s\in C$ has its component adjacent to **all** vertices of at least two distinct chambers:
$$\forall s\in C,\qquad \bigl\lvert\bigl\{\,K\in\mathcal{K} \;:\; K \subseteq \{z\in V_n : \exists y\in\operatorname{Comp}(M_C,s),\; y\sim z\}\,\bigr\}\bigr\rvert \;\ge\; 2.\tag{4.2}$$
Define $\operatorname{Holds}(B)$ by $C\subseteq S_c(B)$ and by the absence of $c$-stones and presence of an empty point in each $K\in\mathcal K$. On scoring frames this is a native-forcing invariant. Each point of $P:=C\cup\bigcup_{K\in\mathcal K,\lvert K\rvert=1}K$ scores for $c$, giving
$$\Delta(B) \;\ge\; 2\lvert P\rvert - n^2 \quad (c=\mathrm{B}), \qquad \Delta(B) \;\le\; n^2 - 2\lvert P\rvert \quad (c=\mathrm{W}).\tag{4.3}$$

*Proof.* Pick an empty vertex $e_K\in K$ in each chamber. By full-chamber adjacency (4.2), $\operatorname{Comp}(M_C,s)$ borders every vertex of its two supporting chambers—in particular $e_{K_1}\neq e_{K_2}$—giving every core chain at least two distinct liberties on $B$. Under any opponent placement at $x$:

- **Core preservation**: Because chambers are pairwise disjoint, $x$ enters at most one chamber, leaving every core chain with an empty liberty in its other supporting chamber; hence $\operatorname{Cap}_n(B,\bar{c},x)\cap C=\emptyset$.
- **Last-empty-point protection**: If $x\notin K$ or $K$ had $\ge 2$ empty points, $K$ still retains an empty point. If $x$ was the **sole** empty point of $K$, then $K\setminus\{x\}\subseteq S_{\bar{c}}(B)$; placing $\bar{c}$ at $x$ fills $K$ completely with $\bar{c}$-stones whose outside neighbours all lie in $C$ by (2) and remain uncaptured, leaving $\operatorname{Comp}(B_1,x)\subseteq K$ with zero liberties in violation of no-suicide.

A pass leaves the board and the geometric hypotheses unchanged. At scoring, every point in $C$ remains a $c$-stone. Each singleton room $K=\{e\}$ has $e$ empty with a nonempty set of neighbours all lying in $C$, so $e$ scores for $c$. The two players' scoring sets are disjoint, which gives (4.3). $\square$

<a id="ex-4-4"></a>

**Example 4.4 (Sharp guaranteed area on the invaded two-point configuration).**
Use the board of Example 1.1(2). Put White at all remaining exterior points except a singleton exterior White eye at $(18,18)$. All chains have liberties. At double-pass scoring, the Black core and its singleton eye score eight points, White scores 352, and $(0,1)$ is dame, giving $\Delta=-344$. This shows that the guarantee of eight Black area points is sharp for this geometry and that preserving the final empty point of a mixed chamber does not by itself assign that point to Black. The uniform bound (4.3) uses only disjoint scoring sets.

<a id="rem-4-5"></a>

**Remark 4.5 (One-step and miai vital-chamber birth, `VitalBirthRecognize` / `SourceLeaf`).**
Interior search positions close as soon as they lie one or two plies from Theorems 4.2–4.3: (i) **one-step birth** closes on $c$'s turn when a legal placement $a\in V_n$ immediately establishes $\operatorname{Holds}$; (ii) **two-option miai birth** closes on $\bar{c}$'s turn when two distinct empty points $a\neq b$ (such as cap points $(0,2)$ and $(0,3)$ in Figure 2(b)) ensure that after every legal opponent move, at least one of $a$ or $b$ remains a legal one-step birth move.

![Figure 2 | Pass-alive closures and the H11 response families. (a) Two chains sharing singleton eyes, and the seven-stone core protecting an invaded chamber and one singleton eye. (b) The eleven-ply corner and the three response families. For the 343 outer replies, Black's B(3,1) gives the seven-stone HookSource. The three families combine in one 351-reply certificate.](figures/fig2-vital-chambers-en.pdf)

<a id="sec-4-3"></a>

### 4.3 Soundness of Typed Strategy Certificates and Quotient Reuse

The inductive type `Certificate` is indexed by beneficiary, threshold and frame. Its constructors include `.choose` for a legal non-resigning move and its child, `.all` for an indexed family of opponent continuations, and `.terminal` for a scored terminal. The remaining constructors are `.twoEye`, `.twoEyeFamily`, `.eyeCoalition` and `.vitalChambers`. Miai certificates are built from `.all`, `.choose` and geometric leaves.

Indexing `.all` directly over the kernel's own $\operatorname{Expand}(F)$ list enforces exhaustiveness by typing: constructing the function requires a certificate for each legal non-resigning opponent reply, including a pass or a legal ko capture.

<a id="thm-4-6"></a>

**Theorem 4.6 (Soundness of typed strategy certificates and $q_{\mathrm{PSK}}$ reuse, `StrategyCertificate`; GO1).**
Given $\mathcal{D} : \mathtt{Certificate}(c,\theta,F)$ on a frame with $\mathrm{st}\in\{\mathtt{playing},\mathtt{twoPasses}\}$:

1. **Constructive policy compilation and all-opponent guarantee**: $\mathcal{D}$ compiles constructively to $\pi_{\mathcal{D}} := \operatorname{policy}(\mathcal{D})$ such that against every executable opponent policy $\pi_{\bar{c}}$, native play $\operatorname{exec}(F,\pi_{\mathcal{D}},\pi_{\bar{c}})$ terminates at $\mathtt{twoPasses}$ satisfying (for $c=\mathrm{B}$; negated for $c=\mathrm{W}$):
   $$\forall \pi_{\bar{c}},\qquad \Delta\bigl(\operatorname{exec}(F,\;\pi_{\mathcal{D}},\;\pi_{\bar{c}})\bigr) \;\ge\; \theta.\tag{4.4}$$
2. **Quotient transport (`faceGuarantee`)**: For any $F' \equiv_{\mathrm{PSK}} F$, $\mathcal{D}$ induces a transported policy $\pi'_{\mathcal{D}}$ establishing Equation (4.4) from $F'$ against all opponent policies.

---

<a id="sec-5"></a>

## 5 Regional Footprint Antichains, Exterior Capacity, and Verified DAG Checking

To lift a bounded $7\times 7$ search graph to $19\times 19$ play without expanding the $312$ exterior points, three properties must hold simultaneously: local captures must match global captures, local Black moves must not violate global PSK, and arbitrary exterior White moves must preserve both invariants. This section proves all three (**GO3**).

<a id="sec-5-1"></a>

### 5.1 Regional Restriction, Connected Exterior, and Boundary-Capture Commutativity

Fix $V_{19}$ (the proofs apply to any proper region $R\subsetneq V_{19}$ with connected exterior; our corner instantiation uses $R := \{0,\dots,6\}^2$, $\lvert R\rvert=49$, $\lvert V_{19}\setminus R\rvert=312$). Write $B|_R$ for the board of the same size obtained by setting $V_{19}\setminus R$ to $\bot$.

<a id="def-5-1"></a>

**Definition 5.1 (Connected exterior and interior buffer, `ExteriorSource` / `RegionProjection`).**

1. A proper subset $R\subsetneq V_{19}$ has a **connected exterior** if $V_{19}\setminus R$ is nonempty and $4$-connected.
2. Its **interior buffer** is $\operatorname{Int}(R) := \{x\in R : \forall y\in V_{19},\, (y\sim x \implies y\in R)\}$ (the upper-left $6\times 6$ subgrid $\{0,\dots,5\}^2$ when $R=\{0,\dots,6\}^2$). Colour $c$ is **interior-confined** on $B$ if $S_c(B)\subseteq\operatorname{Int}(R)$.

<a id="prop-5-2"></a>

**Proposition 5.2 (Pigeonhole exterior liberty and boundary-capture commutativity, `ExteriorLiberty` / `RegionSparse` / `RegionCapture`; GO3).**
Let $R\subsetneq V_{19}$ have a connected exterior, let $B$ satisfy $S_{\mathrm{B}}(B)\subseteq\operatorname{Int}(R)$, and assume $\lvert\operatorname{occ}(B)\rvert < \lvert V_{19}\setminus R\rvert$.

1. **Boundary-crossing White chains retain an exterior liberty**: Every White chain $G=\operatorname{Comp}(B,z)$ containing an exterior vertex $z\in V_{19}\setminus R$ possesses at least one empty liberty inside $V_{19}\setminus R$.
2. **Black's interior step**. For each empty $x\in\operatorname{Int}(R)$, both capture operations remove exactly the same White stones, all lying in $R$, and
   $$\operatorname{Cap}_{19}(B,\mathrm{B},x)=\operatorname{Cap}_{19}(B|_R,\mathrm{B},x),\qquad \operatorname{After}(B,\mathrm{B},x)\big|_R=\operatorname{After}(B|_R,\mathrm{B},x).\tag{5.1}$$
   The exterior is unchanged, and Black's new group has a liberty on the full board exactly when it does on the restricted board.
3. **White's step**. For a White placement at an empty $x\in R$, the restricted result equals the result computed on $B|_R$. If the placement has a liberty globally, it has one in the restriction. A White placement at $x\notin R$ has no effect on $B|_R$. These White statements use only the confinement of Black stones to $\operatorname{Int}(R)$.

*Proof.* For (1), the exterior consists only of White stones and empty points. If a White chain meeting the connected exterior had no exterior liberty, following exterior edges from the chain would force every exterior point into it. That would contradict the capacity assumption.

For (2), the Black placement does not change the exterior. By (1), a White chain crossing the boundary remains uncaptured. On the padded board $B|_R$, its portion connected to an interior neighbour of $x$ has an empty exterior neighbour at its crossing and likewise survives. White chains confined to $R$ have the same liberty test on both boards: their exterior neighbours, if any, are empty because Black is confined and an exterior White neighbour would belong to the chain. This establishes (5.1). Every Black chain lies in $\operatorname{Int}(R)$, so all neighbours of the new Black group are read identically after capture.

For (3), the Black chains adjacent to a White placement lie in the buffer with all their neighbours in $R$. Their capture tests therefore agree. If a full-board White group grown from $x\in R$ stays in $R$, a global liberty remains a liberty on the padded board. If it crosses $R$, a first crossing along a White path from $x$ supplies an empty exterior neighbour of the restricted White group. A placement outside $R$ has no Black neighbour, so it cannot change any point in $R$. $\square$

<a id="sec-5-2"></a>

### 5.2 Maximal Black-Footprint Antichains and Capture-Replay Freshness

Let $\mathcal H=[M_1,\dots,M_k]$ be a list of footprint sets and write $\downarrow\mathcal H=\{D:D\subseteq M\text{ for some }M\in\mathcal H\}$. The full-board history of Black footprints is $\mathcal S_{\mathrm B}(F)=[S_{\mathrm B}(B'):(B',\tau')\in H(F)]$. The checker tests equality of downsets:
$$\operatorname{HistoryMatches}(F,\mathcal H)\quad\Longleftrightarrow\quad\downarrow\mathcal H=\downarrow\mathcal S_{\mathrm B}(F).\tag{5.2}$$
Equivalently every generator of either list is covered by the other. A maximally compressed list consists of the inclusion-maximal footprints, an antichain. The checker accepts any list with the same coverage. In the corner fixture every historical Black footprint lies in $R$, so each fits in a 49-bit mask. Insertion leaves the list unchanged if it already covers the new footprint, and otherwise deletes its strict subsets before adding it.

<a id="thm-5-3"></a>

**Theorem 5.3 (Footprint preservation and capture-replay PSK freshness, `RetainedCoreHistory` / `RegionalProgram`; GO3).**
Suppose $\operatorname{HistoryMatches}(F,\mathcal H)$ and that the current Black stones lie in $R$.

1. **Freshness**. For a Black placement at $x\in\operatorname{Int}(R)$ with new full-board Black footprint $C'=S_{\mathrm B}(\operatorname{After}(B,\mathrm B,x))$,
   $$\bigl(\forall M\in\mathcal H,\ C'\not\subseteq M\bigr)\quad\Longrightarrow\quad\operatorname{After}(B,\mathrm B,x)\notin\operatorname{set}(H(F)).\tag{5.3}$$
2. **Preservation**. After a legal Black placement, $\operatorname{HistoryMatches}(F',\operatorname{insert}(\mathcal H,C'))$ holds. If the current Black footprint is covered by $\mathcal H$, a legal non-resigning White move or a pass preserves $\operatorname{HistoryMatches}$ with $\mathcal H$ unchanged.

*Proof.* A repeated target board has its Black footprint in $\mathcal S_{\mathrm B}(F)$, so (5.2) makes that footprint covered. A legal step appends the target board to history. Insertion represents adjoining its footprint to the old downset. White cannot add Black stones, and a pass leaves them unchanged. Thus when the current footprint is covered, the appended footprint is already covered. Reachable frames record the current board, and the White-node checker tests this footprint condition explicitly. $\square$

<a id="ex-5-4"></a>

**Example 5.4 (Reachable 8-ply $5\times 5$ capture-replay witness and singleton mask `165,760` at `W31`).**

1. **8-ply capture-and-replay where virgin-point checks fail**: On $5\times 5$, play $1.\,\mathtt{B}(0,0),\;2.\,\mathtt{W}(0,1),\;3.\,\mathtt{B}(2,0),\;4.\,\mathtt{W}(1,0)$ (capturing $\mathtt{B}(0,0)$), $5.\,\mathtt{B}(1,1),\;6.\,\mathtt{W}(4,4),\;7.\,\mathtt{B}(0,2),\;8.\,\mathtt{W}(4,3)$. Black's footprints evolve along $\emptyset \to \{(0,0)\} \to \{(0,0),(2,0)\} \to \{(2,0)\} \to \{(1,1),(2,0)\} \to \{(0,2),(1,1),(2,0)\}$, compressing to the two-element maximal antichain
   $$\mathcal{A}_{\mathrm{B}}(H) = \bigl[\;\{(0,2),(1,1),(2,0)\},\;\; \{(0,0),(2,0)\}\;\bigr].$$
   At move $9$, playing $\mathtt{B}(0,0)$ recaptures $\{(0,1),(1,0)\}$. A naive virgin-point check rejects $(0,0)$ because it was played at move $1$; under Equation (5.3), the joint post-capture footprint $C'=\{(0,0),(0,2),(1,1),(2,0)\}$ is contained in neither antichain element, certifying global PSK freshness immediately.
2. **Singleton mask `165,760` at 12-ply `W31`**: Along the capture-free 12-ply prefix $H_{11}+\mathtt{W}(3,1)$ (Section 6), Black's historical footprints form a chain ending at $M_{\mathrm{init}}=\{(1,0),(1,1),(1,2),(1,3),(2,1),(2,3)\}$, compressing all $13$ global history entries into $\mathcal{H}_{\mathrm{init}}=[M_{\mathrm{init}}]$ with $7r+j$ bitmask $2^7+2^8+2^9+2^{10}+2^{15}+2^{17}=165{,}760$.

<a id="sec-5-3"></a>

### 5.3 Capacity-Rank Descent and the Verified Regional DAG Checker

We package local state into `Snapshot` and prove soundness of the single-pass DAG checker `compileDAG` (Figure 3(b)).

<a id="def-5-5"></a>

**Definition 5.5 (Regional snapshots, parity-aware node rank, and `SourceAt`, `RegionalProgram`).**
Fix $R\subsetneq V_{19}$ with connected exterior:

1. **Snapshot and unit-step rank**: A snapshot is a quadruple $s=(B_{\mathrm{loc}},\mathcal{H},\tau,r)$ with local board $B_{\mathrm{loc}}$ on $R$, Black-footprint antichain $\mathcal{H}$, side to move $\tau\in\{\mathrm{B},\mathrm{W}\}$, and remaining round budget $r\in\mathbb{N}$. Define
   $$\operatorname{rank}(s) := 2r + \mathbf{1}_{\tau=\mathrm{W}}.\tag{5.4}$$
   Under Black's step `ownNext` ($r>0$, $r\mapsto r-1$, $\tau:\mathrm{B}\to\mathrm{W}$, so $2r\mapsto 2(r-1)+1=2r-1$) and White's step `whiteNext` ($r$ unchanged, $\tau:\mathrm{W}\to\mathrm{B}$, so $2r+1\mapsto 2r$), every checked transition satisfies $\operatorname{rank}(s_{\mathrm{child}}) + 1 = \operatorname{rank}(s_{\mathrm{parent}})$.
2. **Global applicability predicate $\operatorname{SourceAt}(F,s)$**: A $19\times 19$ frame $F=(B,\tau_F,p_F,\mathrm{st}_F,H_F)$ matches $s$ iff: (i) $B|_R=B_{\mathrm{loc}}$, $\tau_F=\tau$, $\mathrm{st}_F=\mathtt{playing}$, and the one-way pass guard $\tau=\mathrm{W}\implies p_F=0$ holds; (ii) $\operatorname{HistoryMatches}(F,\mathcal{H})$; (iii) $S_{\mathrm{B}}(B)\subseteq\operatorname{Int}(R)$; and (iv) $\lvert\operatorname{occ}(B)\rvert + \operatorname{rank}(s) < \lvert V_{19}\setminus R\rvert$.

![Figure 3 | The regional lift. (a) Actual 12-ply W31 position with four bottom-row White stones and the checked next Black move E17 marked on an empty point. The separate inset illustrates a possible boundary-crossing White chain and one exterior liberty. (b) Every checked edge lowers the rank by one, while occupancy increases by at most one. Their sum stays below 312.](figures/fig3-regional-dag-en.pdf)

At a Black node `.own(x)`, the checker verifies the positive remaining budget, local legality, interior placement, freshness (5.3) and the child snapshot. At a White node `.white`, it verifies that the current Black footprint is covered, counts the supplied edges and looks up one for each admissible code: a locally non-suicidal placement, `.environment` or `.pass`. Both kinds check the child rank and snapshot. At a `.coalition` or `.vital` leaf it checks the geometry, the dynamic hypotheses and the threshold. The geometry lifts to $R$ because its Black core is interior-confined and its eyes or rooms lie in $R$.

<a id="thm-5-6"></a>

**Theorem 5.6 (Soundness of the ascending-rank regional DAG checker, `RegionalProgram.compileDAG`; GO3).**
Let $R\subsetneq V_{19}$ have connected exterior. If `compileDAG?` accepts a raw node array and root index and returns $\mathsf{Prog}$, then for every frame $F$ satisfying $\operatorname{SourceAt}(F,s_{\rm root})$, applying `Compiled.at?` to $\mathsf{Prog}$ and $F$ yields a native certificate $\mathtt{Certificate}\;\mathrm B\;(-345)\;F$. In addition, following the checked graph and then passing at its geometric leaves guarantees at least eight Black area points in $R$.

*Proof.* Unit rank drop forces strict acyclicity, so ascending-rank compilation populates every child program before its parent. Inducting on $\operatorname{rank}(s)$, at any internal node ($\operatorname{rank}(s)\ge 1$) we have $\lvert\operatorname{occ}(B)\rvert < \lvert V_{19}\setminus R\rvert$, activating Proposition 5.2:

- **`.own(x)`**: Proposition 5.2(2) and Theorem 5.3(1) lift local legality and Equation (5.3) to a genuine global step $\operatorname{step}(F,\mathtt{play}(x))=F'$, and placing a stone resets $p_{F'}=0$, maintaining $\tau'=\mathrm{W}\implies p_{F'}=0$. Because any single move increases board occupancy by at most $1$ ($\lvert\operatorname{occ}(B')\rvert \le \lvert\operatorname{occ}(B)\rvert+1$) while $\operatorname{rank}(s')=\operatorname{rank}(s)-1$, the sum does not increase and stays strictly below the exterior size:
  $$\lvert\operatorname{occ}(B')\rvert + \operatorname{rank}(s') \;\le\; \bigl(\lvert\operatorname{occ}(B)\rvert + 1\bigr) + \bigl(\operatorname{rank}(s) - 1\bigr) \;=\; \lvert\operatorname{occ}(B)\rvert + \operatorname{rank}(s) \;<\; \lvert V_{19}\setminus R\rvert.\tag{5.5}$$
- **`.white`**: At the parent, $\tau=\mathrm{W}\implies p_F=0$ ensures that even $m=\mathtt{pass}$ yields $p_{F'}=1<2$ ($\mathtt{playing}$), while $\tau'=\mathrm{B}$ makes $\tau'=\mathrm{W}\implies p_{F'}=0$ vacuously true on all children. Every global $(m,F')\in\operatorname{Expand}(F)$ satisfies Equation (5.5); by Proposition 5.2(3) and Theorem 5.3(2), local plays $x\in R$ match their local non-suicidal port, exterior plays $x\notin R$ preserve $B|_R$ and $\mathcal{H}$ (matching `.environment`), and `pass` matches `.pass`, populating `.all`.
- **Geometric leaves**. The formal leaf constructors lift the checked geometry to the full board. Since their bound $2\lvert P\rvert-361$ meets $-345$, they have $\lvert P\rvert\ge8$. Each such $P$ lies in $R$. For the area statement, follow the checked Black choices and map each actual White move to its verified edge as above. Rank drops at each step and the pass guard keeps all internal frames in play, so the line reaches a geometric leaf. Passing from then on preserves that leaf's $P$ and scores each of its points for Black at the double-pass terminal. The certified margin is the formal certificate's conclusion, and the identified corner area follows from this strategy and the leaf geometry. $\square$

<a id="rem-5-7"></a>

**Remark 5.7 (Soundness of local White-port over-approximation and the 73-node control runner, `RunRegionalProgram19`).**
At `.white` nodes, the checker does not filter out White moves that might be globally PSK-illegal, instead requiring child certificates for **all** locally non-suicidal White plays in $R$. Because White is universally quantified ($\forall$), the set of globally PSK-legal White moves is a subset of the union of locally non-suicidal plays with `.environment` and `.pass`; certifying a superset of opponent replies soundly covers its subset, whereas Black's existential move ($\exists$) is guaranteed globally PSK-legal by Theorem 5.3(1). The compiled regression runner `RunRegionalProgram19.lean` decodes a $73$-node control DAG from a 21-ply corner search slice (rooted after `B(1,1)` with `.environment` moves realized along row-18 exterior points `(18,j)`), verifying in-process both positive `-345` certification and four negative rejection guards (missing White port, broken rank descent, cleared antichain, and unmatched initial board; Table B.2).

---

<a id="sec-6"></a>

## 6 Combinators and Million-Node Certified Computations on the $19\times 19$ Corner Benchmark

<a id="sec-6-1"></a>

### 6.1 The 11-Ply Corner Benchmark, External DAG Export, and Carried-History Corridors

To stress-test Sections 4–5 under global $19\times 19$ rules, we study an **11-ply corner survival benchmark $H_{11}$** (Figure 2(b)): Black places $6$ stones forming the gapped corner frame $\{(1,0),(1,1),(1,2),(1,3),(2,1),(2,3)\}$, White plays a direct first-line invasion $\mathtt{W}(0,1)$ (`B19`) at ply $8$ to disrupt top-edge eye formation, and four row-18 White moves $(18,18),(18,16),(18,14),(18,12)$ (`T1, R1, P1, N1`) fix turn parity and global stone count:
$$\begin{aligned}
H_{11} := \bigl[&\mathtt{B}(1,1),\;\mathtt{W}(18,18),\;\mathtt{B}(1,2),\;\mathtt{W}(18,16),\;\mathtt{B}(1,3),\;\mathtt{W}(18,14),\\
&\mathtt{B}(1,0),\;\mathtt{W}(0,1),\;\mathtt{B}(2,3),\;\mathtt{W}(18,12),\;\mathtt{B}(2,1)\bigr].
\end{aligned}\tag{6.1}$$
After ply $11$ ($\mathtt{B}(2,1)=\mathtt{B17}$), $11$ stones ($6$ Black, $5$ White) occupy the board, `positionHistory` holds $12$ entries, White is to move, and `scoringExpansion` enumerates **exactly $351$ legal White moves** ($350$ placements plus `pass`).

When White's 12th move plays an interior liberty-shortening move such as `W31` ($\mathtt{W}(3,1)=\mathtt{B16}$), play branches into multi-step captures, ko threats, and eye-making tactics inside the upper-left $7\times 7$ region. We handle this via **untrusted external relational search followed by kernel-verified checking**: an external C++ solver performs bounded-horizon retrograde $\exists/\forall$ fixed-point propagation over $7\times 7$ local boards paired with turn, pass count, and $49$-bit Black-footprint antichain IDs (exploring $5{,}564{,}416$ memo states and $4{,}035{,}761$ transition rows on `W31`, pruning upon recognizing `EyeCoalition` or `VitalChambers`), exports the winning subgraph as a `corner-birth-dag/v1` compressed JSON file (`32,417,077` bytes), and hands it to the verified Lean checker of Section 5.3.

Along two sibling deep replies—`W02` ($\mathtt{W}(0,2)$) and `W32` ($\mathtt{W}(3,2)$)—tactics unfold along the top-row or left-column edge corridors, closing via deterministic corridor recursion without external DAGs. Under unmaterialized `Function.update` boards, single deep port expansions along these corridors previously stalled for over $259\,\mathrm{s}$; switching to materialized steps (Proposition 2.2(2)) removed closure traversal, and threading explicit reserve and history-set witnesses eliminated redundant board scans:

<a id="prop-6-1"></a>

**Proposition 6.1 (Carried-history and empty-reserve corridor combinators, `CarriedProgram` / `Corridor`; GO8).**
Building `chooseTracked?` and `allTracked?` atop `MaterializedStep` while threading the seen-board set and regional empty-point reserve ensures well-founded termination whenever each Black defense move consumes a reserve vertex or advances a bounded corridor stage, returning a native `Certificate` upon closing at Theorems 4.2–4.3 or Remark 4.5.

<a id="sec-6-2"></a>

### 6.2 Universal Hook-Source Lemma and 11–12-Ply Certified Computations

Of the 351 legal non-resigning White replies at $H_{11}$, 343 permit Black to play $(3,1)$ and reach the seven-stone source below. The five bridge replies and three deeper replies are shown separately in Figure 2(b) and Table 3. The source lemma concerns the state after Black's $(3,1)$, and then quantifies over its own White continuations.

<a id="prop-6-2"></a>

**Proposition 6.2 (Five-shape closure from a seven-stone hook, `HookSource`; GO4, GO8).**
Let $F$ be a playing $19\times19$ frame with White to move and zero consecutive passes. In $W_{15}=\{0,\dots,3\}^2\setminus\{(3,3)\}$ let $C_7=C_6\cup\{(3,1)\}$ be Black, where $C_6$ is the $H_{11}$ Black core. Let $(0,1)$ be White and all other window points empty. Require the four points $(0,2),(0,3),(3,0),(3,2)$ to have held no Black stone in the current board or any historical board. The exterior 346 points otherwise need no geometric condition. For every legal non-resigning White reply, Black plays $(3,2)$ if White has just played $(3,0)$ and plays $(3,0)$ otherwise. After the next legal non-resigning White move, Black has a legal cap establishing one of the following five vital-chamber geometries (the multi-point rooms may contain White):

1. $C_7\cup\{(3,0),(0,2)\}$ with eye $\{(2,0)\}$ and invaded room $\{(0,0),(0,1)\}$ ($\lvert P\rvert=10$);
2. $C_7\cup\{(3,0),(0,3)\}$ with eye $\{(2,0)\}$ and invaded room $\{(0,0),(0,1),(0,2)\}$ ($\lvert P\rvert=10$);
3. $C_7\cup\{(3,0),(3,2)\}$ with two empty eyes $\{(2,0)\}$ and $\{(2,2)\}$ ($\lvert P\rvert=11$);
4. $C_7\cup\{(3,2),(0,2)\}$ with eye $\{(2,2)\}$ and invaded room $\{(0,0),(0,1)\}$ ($\lvert P\rvert=10$);
5. $C_7\cup\{(3,2),(0,3)\}$ with eye $\{(2,2)\}$ and invaded room $\{(0,0),(0,1),(0,2)\}$ ($\lvert P\rvert=10$);

Each geometry gives Black at least ten guaranteed corner points by Theorem 4.3, and hence
$$\Delta(B_{\mathrm{end}}) \;\ge\; 2\cdot 10 - 361 \;=\; -341 \;>\; -345.\tag{6.2}$$

Table 3 lists the full set of successor positions and the corresponding historical executions.

<a id="comp-6-3"></a>

**Certified Computation 6.3 (`W31` DAG validation and successor certificates at $H_{11}$; GO5, GO8).**
We report the original run receipts and the corresponding source retained at commit `e60a86058abcb74b7f2225f2383c182be8343785`. The large run recorded in `original-certificate.json` used the original `RegionalDAGRun.lean` and `admittedPorts`. The maintained `RunRegionalDAG19.lean` consumes the same artifact with the pointwise equivalent `captureAdmittedPorts`. The receipt records production of a typed certificate in the running process.

1. **12-ply deep regional DAG `W31` ($H_{11}+\mathtt{W}(3,1)$)**: On the upper-left $7\times 7$ region (initial antichain `[165760]`, $249$ antichain shapes; $28$ cached eye-coalition geometries and $85$ cached vital-chamber geometries with mandatory per-leaf `Holds` re-checks), `RegionalDAGCache.compile` validates every node and edge in a single pass, satisfying exact conservation
   $$\begin{aligned}
   \lvert V_{\mathrm{DAG}}\rvert &= 862{,}073_{\mathtt{own}} + 33{,}164_{\mathtt{white}} + 743{,}233_{\mathtt{coalition}} + 62{,}516_{\mathtt{vital}} = 1{,}700{,}986,\\
   \lvert E_{\mathrm{DAG}}\rvert &= 862{,}073_{\mathtt{own}} + 1{,}145{,}389_{\mathtt{white\text{-}ports}} = 2{,}007{,}462,
   \end{aligned}\tag{6.3}$$
   in $3{,}140.66\,\mathrm{s}$ ($7.07\,\mathrm{GB}$ peak RSS), outputting `some (Certificate B (-345) F_W31)` with Black's third-line extension reply $\mathtt{B}(2,4)$ (`E17`, extending rightward from $\mathtt{B}(2,3)=\mathtt{D17}$).
2. **Deep corridor branches `W02` and `W32`**: Both open with $\mathtt{B}(3,1)$ (`B16`) and emit complete `Certificate B (-345)` witnesses. Comparing pure certificate-generation wall times on identical scope (excluding optional post-generation port spot-checks), Proposition 6.1's carried-history recursion reduces `W02` generation from $2{,}030.68\,\mathrm{s}$ to $1{,}748.85\,\mathrm{s}$ (**$13.9\%$** speedup; $2{,}093.02\,\mathrm{s}$ vs. $1{,}755.62\,\mathrm{s}$ including post-audit) and `W32` generation from $1{,}940.31\,\mathrm{s}$ to $1{,}690.88\,\mathrm{s}$ (**$12.9\%$** speedup; $1{,}988.56\,\mathrm{s}$ vs. $1{,}697.42\,\mathrm{s}$ including post-audit).
3. **Five left-bridge branches `ElevenLeftBridge` (`W00, W03, W20, W22, W30`)**: Opening with $\mathtt{B}(0,2)$ (capturing two White stones at `W00` with $351$ subsequent ports, and $348$ ports on each of the four siblings), followed by top-corridor or $(3,1)/(3,3)$ bridge miai, produces `-345` certificates on all five branches.
4. **Assembly and exact successor coverage**. The original `assembly.jsonl` reports 351 legal White ports, 348 retained certificates, and `complete_certificate=false` at $246.337\,\mathrm{s}$. The three pending moves were precisely `W02`, `W31` and `W32`; each has an independent successful execution on the matching native successor. In the [complete execution](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/evidence/certified-go/acceptance/original-source-h11-replay.json), `ElevenAssembly.assemble` uses the same strategy graph and combines all 351 live typed successor certificates into a parent certificate. `ElevenAssembly.run` supplies that certificate to Black’s actual move $(2,1)$ from the 10-ply frame and validates the move and the complete history.

**Table 3 Summary of closure mechanisms and verification receipts across all $351$ legal White replies at $H_{11}$.**

| Branch family (White ply 12) | Ports covered | Closure mechanism & Black reply | Full-board margin | Verification scale & pure-generation time |
| --- | --- | --- | --- | --- |
| **Exterior `HookSource`** | $343$ | $\mathtt{B}(3,1)$, then Proposition 6.2 | $\Delta\ge -341$ at the hook | 348-successor batch, $246.337\,\mathrm s$ with the left bridge |
| **Left bridge `ElevenLeftBridge`** | $5$ | $\mathtt{B}(0,2)$ capture or bridge miai | $\Delta\ge -345$ | `W00`: $351$ ports; $4$ siblings: $348$ ports each |
| **Top corridor `W02`** | $1$ | $\mathtt{B}(3,1)$ horizontal corridor | $\Delta\ge -345$ | Pure gen: $2{,}030.68\,\mathrm{s}\to 1{,}748.85\,\mathrm{s}$ ($-13.9\%$) |
| **Interior corridor `W32`** | $1$ | $\mathtt{B}(3,1)$ vertical corridor | $\Delta\ge -345$ | Pure gen: $1{,}940.31\,\mathrm{s}\to 1{,}690.88\,\mathrm{s}$ ($-12.9\%$) |
| **Regional DAG `W31`** | $1$ | $\mathtt{B}(2,4)$ (`E17`), $7\times 7$ mask `[165760]` | $\Delta\ge -345$ | $1{,}700{,}986$ nodes / $2{,}007{,}462$ edges, $3{,}140.66\,\mathrm{s}$, $7.07\,\mathrm{GB}$ |

![Figure 4 | The W31 run and verification responsibilities. (a) The 1,700,986 checked nodes and 2,007,462 directed edges, and the geometry cache. (b) The search output is checked by an executable Lean program with a kernel-verified certificate type.](figures/fig4-w31-certificate-en.pdf)

---

<a id="sec-7"></a>

## 7 Incremental Bound-Refinement State Machine: Separating Existence Bounds from Executable Policies

Large game-formalization efforts must distinguish **non-constructive `Prop` existence bounds**—such as $k^\star(19)\in[0,361]$ from Section 3—from **constructive `Type`-level strategy certificates** that actually choose moves at runtime (Sections 5–6). Module `CalculationRuntime.lean` (**GO6**) enforces this distinction via a monotone bracket-refinement state machine.

<a id="sec-7-1"></a>

### 7.1 Bracket Refinement, Cursor Equivalence, and `Prop`/`Type` Separation

Let $B_{\mathrm{exec}}=[\ell,u]\subseteq[-361,361]$ denote the current executable bracket at $F_0(19)$. A Black receipt with threshold $\theta_{\mathrm B}$ updates only $\ell$, and a White receipt with threshold $\theta_{\mathrm W}$ updates only $u$. With both receipts processed, the update is
$$\ell' := \max(\ell,\;\theta_{\mathrm{B}}) \;\le\; k^\star(19) \;\le\; \min(u,\;\theta_{\mathrm{W}}) =: u'.\tag{7.1}$$
Corollary 3.5 supplies the separate read-only `MathematicalRange` record with integer fields $0,361$ and a proof that every witnessed exact margin lies between them. It supplies no executable root certificate.

<a id="thm-7-1"></a>

**Theorem 7.1 (Cursor observation equivalence, unilateral receipt absorption, and `Prop`/`Type` separation, `CalculationRuntime`; GO6).**
Stepping the incremental state machine from initial state $\mathrm{seed}$ for $t\in\mathbb{N}$ steps satisfies:

1. **Cursor equivalence (`observe_is_original_cursor`)**: For every step count $t\in\mathbb{N}$, the event-logged state machine agrees identically with iterating the raw evaluation cursor:
   $$\operatorname{observe}(t).\mathrm{current} \;=\; \operatorname{GoalCursor.observe}(t,\operatorname{GoalCursor.seed}).\tag{7.2}$$
2. **Receipt absorption (`received_next`)**. The next state of the installed evaluator consumes the first queued, typed initial-bound receipt. It either retains the refined bracket or emits an exact value when both bounds meet. Lemma 3.3(2) excludes an inverted bracket. A receipt need not improve a bound strictly.
3. **Common source of the readouts (`faceAt_factorizes`)**. At every visit, the exported readout has the occurrence emitted by the original cursor and its complete ledger. Its reported face is the corresponding projection of that occurrence, and its next state equals the original program's next state. This includes the read-only mathematical range.

---

<a id="sec-8"></a>

## 8 Literature Dialogue, Methodological Boundaries, and Conclusion

<a id="sec-8-1"></a>

### 8.1 Symmetric Strategy Stealing, Opening Pass, and Superko Complexity

Zermelo [@Zermelo1913] and Kuhn [@Kuhn1953] provide the extensive-game setting for backward induction. Nash [@Nash1952] and Gale [@Gale1979] treat Hex, and Beck [@Beck2008] develops strategy stealing in placement games. Weninger and Hayward's Theorem 1 [@WeningerHayward2017, pp. 102–103] already gives the same first-player non-loss conclusion on rectangular boards under pass-exempt PSK. Theorem 3.4 proves the square-board case in Lean through exact transition and forcing transport from the full history list. Remark 3.7 identifies the corresponding argument on paper for no-suicide SSK.

Lichtenstein and Sipser [@LichtensteinSipser1980] prove PSPACE-hardness for generalized Go. Robson proves EXPTIME-completeness under basic ko [@Robson1983] and EXPSPACE-completeness for a class of generalized no-repeat games [@Robson1984]. Hearn and Demaine [@HearnDemaine2009] survey these rule-dependent complexity results. For scoring and state counts, Berlekamp and Wolfe [@BerlekampWolfe1994] study endgames, and Tromp and Farnebäck [@TrompFarneback2007] count legal positions under variants of the logical rules.

<a id="sec-8-2"></a>

### 8.2 Static Life, Closed-Region GHI, and Global Lifting over Open Exteriors

Benson [@Benson1976] characterizes static pass-alive chains, and Müller [@Muller2001; @Muller2002] studies local search and static safety. Kishimoto and Müller [@KishimotoMuller2004; @KishimotoMuller2005] address Campbell's graph-history interaction problem [@Campbell1985] using path simulation, including enclosed tsumego. Shih et al. [@ShihEtAl2022RelevanceZones] go beyond a fixed wall: their consistent-replay conditions group exterior moves in $19\times19$ life-and-death problems and $7\times7$ kill-all problems with an unconditional-life goal. They leave goals attainable only through ko or seki outside that study.

Kharma and Schintke [@KharmaSchintke2026Sanko, Theorem 1 and Lemma 1] prove asymmetric transfer of a solved PSK strategy between histories and use full-chamber pure eyes. Their static scoring strategy plays to capture invaders when required. It controls earlier captures and the possibility of immediate double-pass termination. Here the geometries prove a pass-only area guarantee, including on a frame with a previous pass. The regional checker combines those leaves, exact coverage of footprint queries for Black freshness, and a connected-exterior capacity proof to cover all legal full-board White moves in its domain.

<a id="sec-8-3"></a>

### 8.3 Large-Scale Game Solving, Neural Search, and Verified Certificate Checkers

Van der Werf, van den Herik and Uiterwijk [@VanDerWerf2003] obtain exact scores for small Go boards, with several ko rules tabulated separately. The rectangular MIGOS results use basic ko with additional cycle rules [@VanDerWerfWinands2009]. Sanko uses the same no-suicide, pass-exempt PSK and two-pass area convention as this paper. It confirms the $5\times5$ margin of 25 and reports a $4\times7$ margin of 12, where MIGOS yields 28 under its own rules [@KharmaSchintke2026Sanko, Sections 6–7]. Schaeffer et al. [@Schaeffer2007Checkers] combine endgame databases and search to weakly solve $8\times8$ Checkers. AlphaGo, AlphaGo Zero and KataGo use statistical search and learned values for full-board play [@Silver2016AlphaGo; @Silver2017AlphaGoZero; @Wu2019KataGo].

In formal verification and certifying algorithms, Necula and Lee [@NeculaLee1996PCC; @Necula1997] introduced proof-carrying code, McConnell et al. [@McConnell2011Certifying] surveyed certifying algorithms, Gonthier [@Gonthier2008] and Hales et al. [@Hales2017Kepler] mechanized the Four-Color Theorem and Kepler Conjecture, and Cruz-Filipe et al. [@CruzFilipe2017LRAT] and Tan, Heule, and Myreen [@TanHeuleMyreen2021CakeLPR] verified million-step SAT refutation checkers in Coq/ACL2 and CakeML. Our regional DAG checker brings this untrusted-solver / verified-checker architecture to **alternating-quantifier ($\exists/\forall$) game graphs with global history constraints and open exteriors**. Table 4 compares representative works across five orthogonal dimensions.

**Table 4 Five-dimensional comparison across strategy stealing, tsumego GHI, exact game solving, neural Go engines, and verified certificate checkers.**

| Representative work | Rule model & board scale | Local life & exterior assumptions | Repetition / GHI mechanism | Verification tier & output guarantee |
| --- | --- | --- | --- | --- |
| Weninger and Hayward [@WeningerHayward2017] | PSK, any rectangular board | Opening-pass and colour exchange at the empty board | Exact set of past positions | Mathematical proof of first-player non-loss |
| Nash (1952), Gale (1979) and Beck (2008) [@Nash1952; @Gale1979; @Beck2008] | Hex and monotone placement games | Extra stones preserve the winning condition | Stones never leave the board | Strategy-stealing proofs |
| Benson (1976) [@Benson1976] | Static pass-alive Go chains, arbitrary size | Single-side static safe chains & enclosed vital regions | Static criterion only; no dynamic move search | Paper theorem: capture-free survival (no dame area split) |
| Kishimoto & Müller (2004, 2005) [@KishimotoMuller2004; @KishimotoMuller2005] | Enclosed local tsumego problems | Assumes invulnerable outer wall; exterior unexpanded | Path-simulation tables resolve local-graph GHI | Unverified custom solver: local enclosed life/death verdict |
| Shih et al. [@ShihEtAl2022RelevanceZones] | Go life and death, including $19\times19$, and $7\times7$ kill-all | Relevance zones and consistent replay | Unconditional-life goals | Search with local goal-achievement trees |
| van der Werf et al. [@VanDerWerf2003; @VanDerWerfWinands2009] | Small squares and rectangles, principally basic ko | Full-board $\alpha\beta$ search | Depends on the chosen cycle convention | Solver gives exact values for specified rules |
| Kharma and Schintke [@KharmaSchintke2026Sanko] | No-suicide PSK; small full boards | Pure eyes and local games | Asymmetric proof transfer | Mathematical soundness proof and reproducible solver values |
| Schaeffer et al. (2007) [@Schaeffer2007Checkers] | $8\times 8$ Checkers ($\approx 5\times 10^{20}$ states) | Full-board capture rules & retrograde endgame DBs | Draw-by-repetition & search GHI handling | Unverified custom solver: weak initial solution (draw) |
| Silver et al. (2016, 2017); Wu (2019) [@Silver2016AlphaGo; @Silver2017AlphaGoZero; @Wu2019KataGo] | $19\times 19$ full-board Go (multi-rule area/territory) | Statistical value & ownership network inference | Finite history planes; no full-history PSK proof | No worst-case bound: policy priors & expected win/score |
| Cruz-Filipe et al. (2017); Tan et al. (2021) [@CruzFilipe2017LRAT; @TanHeuleMyreen2021CakeLPR] | Million-clause Boolean CNF formulas | Propositional clauses; no spatial board or exterior | Static clause sequence; no $\exists/\forall$ alternation | Coq/ACL2 extracted or CakeML compiler-verified UNSAT |
| This paper (GO1–GO8) | Pass-exempt no-suicide PSK, arbitrary squares and a $19\times19$ corner | Invaded vital chambers and connected-exterior capacity | Strong full-board quotient and exact footprint queries | Lean proofs and a $1.70\times10^6$-node certificate run |

<a id="sec-8-4"></a>

### 8.4 Methodological Boundaries, Open Problems, and Conclusion

The regional checker takes a region and connects its geometry to the full board when Black's stones are confined to the interior buffer. The $19\times19$ implementation targets $\Delta\ge-345$; the corresponding geometric leaf argument in Section 5.3 ensures eight Black area points in the region. The corner benchmark gives a unilateral bound from a fixed noninitial state. The exact empty-board $19\times19$ value and a concrete executable root policy for the non-loss theorem remain open.

The main connection between the two results is the information each proof needs from history. Exact membership of earlier boards suffices for full-board transition transport. For the regional lower bound, the winner's new Black footprint needs only a negative containment answer, and all actual White replies map to checked edges. This allows an untrusted large search graph to yield a Lean strategy certificate under the original rules.

---

<a id="sec-app-a"></a>

## Appendix A Extensive-Form Recovery, Normal-Form Equivalence, and Ko Holonomy (GO7)

Sections 2–7 work directly on `RulesKernel` and `Frame n`. Here we summarize two publicly exported theorems in `H0mework` connecting `Frame n` to Kuhn's extensive-form and normal-form games [@Kuhn1953] (**GO7**), followed by the discrete holonomy obstruction on projected ko cycles.

For any $n\in\mathbb{N}$, law $\mathcal{L}$, generated replay $\mathcal{R} : \mathtt{GeneratedReplay}\;\mathcal{L}\;(F_0(n))\;\mathit{moves}$, and finite horizon $h\in\mathbb{N}$:

<a id="prop-a-1"></a>

**Proposition A.1 (Bidirectional recovery between bounded native continuations and extensive-form histories, `ClassicalGameRecovery`; GO7).**
The recovered game $G_{\mathrm{ext}}=\mathtt{recoverExtensiveGame}(\mathcal R,h)$ has state tree definitionally equal to `futureConeAt R h`. Every admitted word $w$ admits a `GeneratedReplay` continuation of $\mathcal R.\mathtt{final}$, ending at $w.\mathtt{current}$ with its entire state trace a branch of the tree. This continuation is unique by induction on the word: `nativeStep?` fixes the next frame and its legality proof is proof-irrelevant. Conversely, every continuation of length at most $h$ maps canonically to an admitted word with the same final frame.

<a id="prop-a-2"></a>

**Proposition A.2 (Identity-preserving cross-occurrence normal-form equivalence, `NormalFormEquivalence.terminalNormalFormEquivalence`; GO7).**
Whenever two legal replays under the same law $\mathcal{R}_L$ and $\mathcal{R}_R$ reach the same **terminal** visible position ($\mathcal{R}_L.\mathtt{final.visible} = \mathcal{R}_R.\mathtt{final.visible}$ with status `.terminal`), for every horizon $h\in\mathbb{N}$ there exists a typed transporter $\Phi$ comprising bijections $(\phi_P, \phi_S, \phi_{\Pi})$ on players, pure strategies, and profiles such that utilities commute for all profiles $\pi$ and players $i$:
$$u_R\bigl(\phi_{\Pi}(\pi),\;\phi_P(i)\bigr) = u_L(\pi,\;i),\tag{A.1}$$
while preserving the distinct replay identities of $\mathcal{R}_L$ and $\mathcal{R}_R$ (whereas on non-terminal positions, as demonstrated by the reachable 5-ply $\gamma_1$ and 7-ply $\gamma_2$ paths in Example 2.3, identical visible boards diverge in legal future actions due to distinct history sets).

<a id="rem-a-3"></a>

**Remark A.3 (Non-coboundary discrete holonomy of reachable ko cycles, `Ko/PrincipalHolonomy`).**
On the reachable $3\times3$ example, the return segment is $\mathtt B(0,1)$ (capture), $\mathtt W(2,2)$ (exterior placement), Black pass, $\mathtt W(0,0)$ (recapture). The five-point local observation and side to move return to their initial values, while the exterior board and elapsed history differ. For simple ko, PSK and SSK, `PrincipalHolonomy.lean` assigns the nonidentity $C_4$ phase to the returning path and proves nontrivial triangle holonomy. In this example the resulting projected transition cochain cannot be a first coboundary: a coboundary would multiply to the identity along that closed projected path.

---

<a id="sec-app-b"></a>

## Appendix B Lean 4 Declaration, Source Module, and Execution Receipt Map (GO1–GO8)

Table B.1 lists source module names at the original research epoch. The [public source map](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-map.json) resolves the exact Lean owners and original receipts. Table B.2 documents the six regression controls.

**Table B.1 Itemized mapping between claim IDs GO1–GO8, main-text environments, Lean 4 modules, and verification consumers.**

| ID | Main-text location | Original Lean 4 modules | Primary types & theorem declarations | Direct verification / regression consumers |
| --- | --- | --- | --- | --- |
| **GO1** | Theorem 4.6 (§4.3) | `BoardKernel.lean`, `RulesKernel.lean`, `ScoreReadout.lean`, `CriticalKomi/StrategyCertificate.lean` | `Certificate`, `Certificate.closed`, `Certificate.policy`, `Certificate.guarantee`, `Certificate.faceGuarantee` | `InitialColourPass.initial_nonnegative_policy`, `Regression/CriticalKomi/Audit.lean` |
| **GO2** | Lemmas 3.1–3.3, Theorem 3.4, Corollary 3.5 (§3) | `CriticalKomi/PositionFace.lean`, `Termination.lean`, `InitialColourPass.lean` | `PositionFace.legalStep_lift`, `terminationRank`, `forcing_dichotomy`, `initial_not_white_negative`, `initial_nonnegative_certificate`, `exact_value_bounds` | `CalculationRuntime.mathematicalRange`, `Audit.lean` |
| **GO3** | Defs. 5.1, 5.5, Prop. 5.2, Thms. 5.3, 5.6 (§5) | `CriticalKomi/RegionProjection.lean`, `ExteriorLiberty.lean`, `RegionSparse.lean`, `CoreHistory.lean`, `RetainedCoreHistory.lean`, `RegionalProgram.lean` | `own_board_exact`, `HistoryMatches.step`, `HistoryMatches.after_subset`, `SourceAt`, `SourceAt.credit_step`, `compileNode?`, `compileDAG`, `Compiled.at?` | `Regression/CriticalKomi/RunRegionalProgram19.lean`, `RunRegionalDAG19.lean`, `Audit.lean` |
| **GO4** | Theorems 4.2, 4.3 (§§4.1–4.2), Prop. 6.2 (§6.2) | `CriticalKomi/EyeCoalition.lean`, `VitalChambers.lean`, `VitalBirthRecognize.lean`, `HookSource.lean` | `EyeCoalition.Geometry`, `EyeCoalition.closed`, `VitalChambers.Geometry`, `VitalChambers.closed`, `VitalChambers.points_area`, `plan_area_le_possible`, `VitalBirth.miaiCertificate`, `HookSource.certificate?` | `StrategyCertificate.lean`, `SourceLeaf.lean`, `RunEyeCoalition19.lean`, `RunVitalChambers19.lean`, `RunHookSource19.lean` |
| **GO5** | Certified Computation 6.3, Table 3 (§6.2) | `CriticalKomi/RegionalProgramCache.lean`, `Regression/CriticalKomi/RunRegionalDAG19.lean` | `RegionalDAGCache.compile`, `RegionalDAGCache.Provider`, `RunRegionalDAG19.run` | Tracked receipt `results/retained-w31/original-certificate.json` & `original-certificate.log` (`1,700,986` nodes, `exit 0`) |
| **GO6** | Theorem 7.1 (§7.1) | `CriticalKomi/GoalBracket.lean`, `GoalCursor.lean`, `CalculationRuntime.lean` | `Bracket.absorb`, `authoritativeRoot`, `observe_is_original_cursor`, `faceAt_factorizes`, `received_next`, `mathematicalRange` | `Regression/CriticalKomi/RunCalculation.lean`, `RunInitialBoundReceipt19.lean` |
| **GO7** | Props. A.1–A.2, Remark A.3 (App. A) | `Classical/ClassicalGameRecovery.lean`, `NormalFormEquivalence.lean`, `Ko/PrincipalHolonomy.lean` | `recoverExtensiveGame`, `History.factors_through_stateTree`, `terminalNormalFormEquivalence`, `koPrincipalConnection_not_flat`, `koPrincipalTransition_not_oneCoboundary` | `G7ClassicalGameRecoveryRegression.lean`, `G5PrincipalHolonomyRegression.lean` |
| **GO8** | Prop. 2.2, Ex. 2.3 (§§2.2–2.3), Props. 6.1–6.2, Comp. 6.3 (§6) | `CriticalKomi/MaterializedStep.lean`, `CarriedProgram.lean`, `ElevenLeftBridge.lean`, `ElevenW02.lean`, `ElevenW32.lean` | `MaterializedStep.step_eq`, `scoring_eq`, `chooseTracked?`, `allTracked?`, `ElevenLeftBridge.recognize?`, `ElevenW02.certificate?`, `ElevenW32.certificate?`, `provider_at_eq` | `RunMaterializedStep19.lean`, `RunElevenLeftBridge19.lean`, `ElevenAssembly.lean`, receipts `w02-spine.jsonl`, `w02-carried.jsonl`, `Eleven-W32-carried.log`, `assembly.jsonl` |

**Table B.2 Negative-control rejection matrix in the regional DAG checker and regression suite.**

| Control category & module | Constructed malformed / overreaching input | Enforcing guard & machine-checked outcome |
| --- | --- | --- |
| **Same-board PSK flip** (`RunMaterializedStep19`) | Append target signature to $F_{13}$ to form $F'_{13}$, test `W(0,3)` and `pass` | `W(0,3)` returns `none` (repetition blocked); `pass` returns `some` (pass exemption preserved) |
| **Missing White port edge** (`RunRegionalProgram19.runDAG`) | Drop last outgoing edge (`edges.dropLast`) on `.white` nodes in $73$-node DAG | `edges.length = ports.length` fails in `compileNode?`; `compileDAG?` returns `none` |
| **Broken rank descent** (`RunRegionalProgram19.runDAG`) | Zero out `remaining := 0` across nodes (`brokenRank`) | `child.rank + 1 = parent.rank` fails in `checkedEdge?`; `compileDAG?` returns `none` |
| **Cleared history antichain** (`RunRegionalProgram19.run`) | Replace antichain `[165760]` by `[]` at 12-ply `W31` | `HistoryMatches frame .positive []` evaluates to `false`; `ownStep?` returns `none` |
| **Unmatched empty board** (`RunRegionalProgram19` / `RunRegionalDAG19`) | Apply compiled $73$-node or $1.70\times 10^6$-node `Provider` to `Frame.initial 19` | Board restriction mismatch in `sourceAt?`; returns `none` |
| **Corrupted cached eyes / rooms** (`RunRegionalDAG19`) | Inject White-filled eyes (`invadedBoard`) or all-White rooms (`occupiedBoard`) | Mandatory per-leaf `Holds` checks in `coalitionAt?` and `compileVital?` return `none` |

---

<a id="sec-app-c"></a>

## Appendix C Classical Excluded-Middle Boundary and Code-Generator Isolation

<a id="prop-c-1"></a>

**Proposition C.1 (One-way axiomatic boundary between `Prop` determinacy and `Type` executable certificates).**

1. **Executable checking and policy generation**. The checking and policy-selection programs compute connected components, legality, footprint containment, checked edges, geometric leaves and moves by decision procedures. They need no classical witness selection at runtime. Local decidable instances range over the supplied lists and finite sets.
2. **Existence and computational data**. `forcing_dichotomy` and `Forces.certificate_nonempty` establish propositional existence. Lean restricts direct elimination of `Nonempty T` into `T`. An explicit use of `Classical.choice` can still produce a noncomputable term; a computationally relevant use supplies no executable policy. The `mathematicalRange` record contains integer bounds and their correctness proof. The executable bracket takes typed certificates as input.

---

<!-- code-availability:begin -->
## Code and Data Availability

H0mework commit [5190af978f01](https://github.com/Sapientropic/H0mework/tree/5190af978f01c121d50244e34ce538c3b5054f44) fixes the public Lean 4 source, checked declarations, and original evidence. The [GO1–GO8 map](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-map.json) records the exact public module and declaration for each producer and direct consumer. The [selection](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/checks/certified-go-selection.json) retains the complete original import closure, the 73-node control, the W31 strategy graph, and the original execution receipts. The [reproduction guide](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-reproduction.md) gives the commands for restoring the original layout, building with `lake -d Lean build CertifiedGo`, and checking the types and axiom dependencies. Lean 4 v4.33.0 and the Mathlib revision are fixed by the repository. The manuscript archive includes the independent Python checks and editable figures.
<!-- code-availability:end -->

## References

[Zermelo1913] Zermelo, E. Über eine Anwendung der Mengenlehre auf die Theorie des Schachspiels. In *Proceedings of the Fifth International Congress of Mathematicians (Cambridge, 1912)*, Vol. **2**, Cambridge University Press (1913), 501–504.

[Nash1952] Nash, J. F. *Some Games and Machines for Playing Them*. Research Memorandum D-1164, The RAND Corporation, Santa Monica, CA (1952).

[Kuhn1953] Kuhn, H. W. Extensive Games and the Problem of Information. In *Contributions to the Theory of Games, Volume II*, Annals of Mathematics Studies **28**, Princeton University Press (1953), 193–216. DOI: [10.1515/9781400881970-012](https://doi.org/10.1515/9781400881970-012).

[Gale1979] Gale, D. The Game of Hex and the Brouwer Fixed-Point Theorem. *The American Mathematical Monthly*, **86**(10) (1979), 818–827. DOI: [10.1080/00029890.1979.11994922](https://doi.org/10.1080/00029890.1979.11994922).

[Beck2008] Beck, J. *Combinatorial Games: Tic-Tac-Toe Theory*. Encyclopedia of Mathematics and its Applications **114**, Cambridge University Press, Cambridge (2008). DOI: [10.1017/CBO9780511735202](https://doi.org/10.1017/CBO9780511735202).

[BerlekampWolfe1994] Berlekamp, E., and Wolfe, D. *Mathematical Go: Chilling Gets the Last Point*. A K Peters, Wellesley, MA (1994). ISBN: 978-1-56881-032-4.

[Allis1994] Allis, L. V. *Searching for Solutions in Games and Artificial Intelligence*. PhD Thesis, Rijksuniversiteit Limburg (Maastricht University) (1994). ISBN: 90-9007488-0.

[TrompFarneback2007] Tromp, J., and Farnebäck, G. Combinatorics of Go. In *Computers and Games (CG 2006)*, LNCS **4630**, Springer (2007), 84–99. DOI: [10.1007/978-3-540-75538-8_8](https://doi.org/10.1007/978-3-540-75538-8_8).

[WeningerHayward2017] Weninger, N., and Hayward, R. Exploring Positional Linear Go. In *Advances in Computer Games (ACG 2017)*, LNCS **10664**, Springer (2017), 101–114. DOI: [10.1007/978-3-319-71649-7_9](https://doi.org/10.1007/978-3-319-71649-7_9).

[Tromp2x2PSK] Tromp, J. *Solving 2x2 Go*. Program and game tree. [Project page](https://tromp.github.io/java/go/twoxtwo.html).

[ShihEtAl2022RelevanceZones] Shih, C.-C., Wu, T.-R., Wei, T. H., and Wu, I.-C. A Novel Approach to Solving Goal-Achieving Problems for Board Games. *Proceedings of the AAAI Conference on Artificial Intelligence*, **36**(9) (2022), 10362–10369. DOI: [10.1609/aaai.v36i9.21278](https://doi.org/10.1609/aaai.v36i9.21278).

[KharmaSchintke2026Sanko] Kharma, S., and Schintke, F. *Solving Go under Positional Superko: Sound Proof Transfer and New Board Values*. arXiv:2610.29414 (2026). [Preprint](https://arxiv.org/abs/2610.29414v1).

[LichtensteinSipser1980] Lichtenstein, D., and Sipser, M. GO Is Polynomial-Space Hard. *Journal of the ACM*, **27**(2) (1980), 393–401. DOI: [10.1145/322186.322201](https://doi.org/10.1145/322186.322201).

[Robson1983] Robson, J. M. The Complexity of Go. In *Information Processing 83: Proceedings of the IFIP 9th World Computer Congress*, North-Holland (1983), 413–417.

[Robson1984] Robson, J. M. Combinatorial Games with Exponential Space Complete Decision Problems. In *Mathematical Foundations of Computer Science 1984 (MFCS ’84)*, LNCS **176**, Springer (1984), 498–506. DOI: [10.1007/BFb0030333](https://doi.org/10.1007/BFb0030333).

[HearnDemaine2009] Hearn, R. A., and Demaine, E. D. *Games, Puzzles, and Computation*. A K Peters, Wellesley, MA (2009). ISBN: 978-1-56881-322-6.

[Benson1976] Benson, D. B. Life in the Game of Go. *Information Sciences*, **10**(1) (1976), 17–29. DOI: [10.1016/0020-0255(76)90059-1](https://doi.org/10.1016/0020-0255(76)90059-1).

[Muller2001] Müller, M. Global and Local Game Tree Search. *Information Sciences*, **135**(3–4) (2001), 187–206. DOI: [10.1016/S0020-0255(01)00136-0](https://doi.org/10.1016/S0020-0255(01)00136-0).

[Muller2002] Müller, M. Computer Go. *Artificial Intelligence*, **134**(1–2) (2002), 145–179. DOI: [10.1016/S0004-3702(01)00121-7](https://doi.org/10.1016/S0004-3702(01)00121-7).

[Campbell1985] Campbell, M. S. The Graph-History Interaction: On Ignoring Position History. In *Proceedings of the 1985 ACM Annual Conference on the Range of Computing: Mid-80’s Perspective*, ACM (1985), 278–280. ISBN: 0-89791-170-9.

[VanDerWerf2003] van der Werf, E. C. D., van den Herik, H. J., and Uiterwijk, J. W. H. M. Solving Go on Small Boards. *ICGA Journal*, **26**(2) (2003), 92–107. DOI: [10.3233/ICG-2003-26205](https://doi.org/10.3233/ICG-2003-26205).

[VanDerWerfWinands2009] van der Werf, E. C. D., and Winands, M. H. M. Solving Go for Rectangular Boards. *ICGA Journal*, **32**(2) (2009), 77–88. DOI: [10.3233/ICG-2009-32203](https://doi.org/10.3233/ICG-2009-32203).

[KishimotoMuller2004] Kishimoto, A., and Müller, M. A General Solution to the Graph History Interaction Problem. In *Proceedings of the Nineteenth National Conference on Artificial Intelligence (AAAI-04)*, AAAI Press (2004), 644–649.

[KishimotoMuller2005] Kishimoto, A., and Müller, M. Search versus Knowledge for Solving Life and Death Problems in Go. In *Proceedings of the Twentieth National Conference on Artificial Intelligence (AAAI-05)*, AAAI Press (2005), 1374–1379.

[Schaeffer2007Checkers] Schaeffer, J., Burch, N., Björnsson, Y., Kishimoto, A., Müller, M., Lake, R., Lu, P., and Sutphen, S. Checkers Is Solved. *Science*, **317**(5844) (2007), 1518–1522. DOI: [10.1126/science.1144079](https://doi.org/10.1126/science.1144079).

[Silver2016AlphaGo] Silver, D., Huang, A., Maddison, C. J., Guez, A., Sifre, L., van den Driessche, G., Schrittwieser, J., Antonoglou, I., Panneershelvam, V., Lanctot, M., Dieleman, S., Grewe, D., Nham, J., Kalchbrenner, N., Sutskever, I., Lillicrap, T., Leach, M., Kavukcuoglu, K., Graepel, T., and Hassabis, D. Mastering the Game of Go with Deep Neural Networks and Tree Search. *Nature*, **529**(7587) (2016), 484–489. DOI: [10.1038/nature16961](https://doi.org/10.1038/nature16961).

[Silver2017AlphaGoZero] Silver, D., Schrittwieser, J., Simonyan, K., Antonoglou, I., Huang, A., Guez, A., Hubert, T., Baker, L., Lai, M., Bolton, A., Chen, Y., Lillicrap, T., Hui, F., Sifre, L., van den Driessche, G., Graepel, T., and Hassabis, D. Mastering the Game of Go Without Human Knowledge. *Nature*, **550**(7676) (2017), 354–359. DOI: [10.1038/nature24270](https://doi.org/10.1038/nature24270).

[Wu2019KataGo] Wu, D. J. Accelerating Self-Play Learning in Go. Preprint, arXiv:1902.10565 (2019). DOI: [10.48550/arXiv.1902.10565](https://doi.org/10.48550/arXiv.1902.10565).

[NeculaLee1996PCC] Necula, G. C., and Lee, P. Safe Kernel Extensions Without Run-Time Checking. In *Proceedings of the Second USENIX Symposium on Operating Systems Design and Implementation (OSDI ’96)*, ACM (1996), 229–243. DOI: [10.1145/238721.238781](https://doi.org/10.1145/238721.238781).

[Necula1997] Necula, G. C. Proof-Carrying Code. In *Proceedings of the 24th ACM SIGPLAN-SIGACT Symposium on Principles of Programming Languages (POPL ’97)*, ACM (1997), 106–119. DOI: [10.1145/263699.263712](https://doi.org/10.1145/263699.263712).

[Gonthier2008] Gonthier, G. Formal Proof—The Four-Color Theorem. *Notices of the American Mathematical Society*, **55**(11) (2008), 1382–1393. URL: [https://www.ams.org/notices/200811/tx081101382p.pdf](https://www.ams.org/notices/200811/tx081101382p.pdf).

[McConnell2011Certifying] McConnell, R. M., Mehlhorn, K., Näher, S., and Schweitzer, P. Certifying Algorithms. *Computer Science Review*, **5**(2) (2011), 119–161. DOI: [10.1016/j.cosrev.2010.09.009](https://doi.org/10.1016/j.cosrev.2010.09.009).

[Hales2017Kepler] Hales, T., Adams, M., Bauer, G., Dang, T. D., Harrison, J., Hoang, L. T., Kaliszyk, C., Magron, V., McLaughlin, S., Nguyen, T. T., Nguyen, Q. T., Nipkow, T., Obua, S., Pleso, J., Rute, J., Solovyev, A., Ta, T. H. A., Tran, N. T., Trieu, T. D., Urban, J., Vu, K., and Zumkeller, R. A Formal Proof of the Kepler Conjecture. *Forum of Mathematics, Pi*, **5** (2017), e2. DOI: [10.1017/fmp.2017.1](https://doi.org/10.1017/fmp.2017.1).

[CruzFilipe2017LRAT] Cruz-Filipe, L., Heule, M., Hunt, Jr., W. A., Kaufmann, M., and Schneider-Kamp, P. Efficient Certified RAT Verification. In *Automated Deduction – CADE 26*, LNCS **10395**, Springer (2017), 220–236. DOI: [10.1007/978-3-319-63046-5_14](https://doi.org/10.1007/978-3-319-63046-5_14).

[TanHeuleMyreen2021CakeLPR] Tan, Y. K., Heule, M. J. H., and Myreen, M. O. cake_lpr: Verified Propagation Redundancy Checking in CakeML. In *Tools and Algorithms for the Construction and Analysis of Systems (TACAS 2021)*, LNCS **12652**, Springer (2021), 223–241. DOI: [10.1007/978-3-030-72013-1_12](https://doi.org/10.1007/978-3-030-72013-1_12).

[deMouraUllrich2021Lean4] de Moura, L., and Ullrich, S. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, LNCS **12699**, Springer (2021), 625–635. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[mathlib2020] The mathlib Community. The Lean Mathematical Library. In *Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)*, ACM (2020), 367–381. DOI: [10.1145/3372885.3373824](https://doi.org/10.1145/3372885.3373824).

[Gao2026OneBitV2] Gao, J. *Ontological Rigidity and Universal Single-Mother Formation: Axiom-Free Exclusion of Unaccounted Differences, Causal Admission, and Unified Evolution*. Version 2 (v2), Zenodo, 2026. DOI: [10.5281/zenodo.24135399](https://doi.org/10.5281/zenodo.24135399).

[Gao2026SourceProcessCoreV3] Gao, J. *Source-Native Process Algebra and Initial-Coface Revision: Four-Tier Identity, Exact Evaluation Kernels, and Reversible Incremental Continuation*. Version 3 (v3), Zenodo, 2026. DOI: [10.5281/zenodo.24147130](https://doi.org/10.5281/zenodo.24147130).

[Gao2026WholeLedgerV2] Gao, J. *Provenance-Preserving Conservation Calculus and Non-Free Continuity: Whole-Event Ledgers, Observer Safety, and Well-Founded Settlement*. Version 2 (v2), Zenodo, 2026. DOI: [10.5281/zenodo.24147183](https://doi.org/10.5281/zenodo.24147183).
