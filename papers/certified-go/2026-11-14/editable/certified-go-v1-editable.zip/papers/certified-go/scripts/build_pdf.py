#!/usr/bin/env python3
"""Build both reading PDFs for `certified-go` (`manuscript.md` and `manuscript-en.md`).

Run from the publish root:
    python3 papers/certified-go/scripts/build_pdf.py --lang both
"""
from __future__ import annotations

import argparse
from functools import partial
import json
import os
import re
import shutil
import sys
from pathlib import Path

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
sys.path.insert(0, str(ROOT / 'shared/scripts'))
import build_pdf as shared  # noqa: E402

ZH = 'papers/certified-go/manuscript.md'
EN = 'papers/certified-go/manuscript-en.md'
shared.RUNHEADS[ZH] = (
    'certified-go',
    '全局超劫围棋首手非负性与区域策略证书',
    '两层超劫历史压缩、驻敌混合要害室与已验证区域 DAG 检查器',
)
shared.RUNHEADS[EN] = (
    'certified-go',
    'Positional-Superko Go Strategy Certificates',
    'Exact History Quotients, Vital Chambers, and Verified Regional DAG Checking',
)
shared.CONTINUOUS_APPENDICES.add(ZH)
shared.CONTINUOUS_APPENDICES.add(EN)

_latin_title = shared.latin_title


def _subtitle(line: str) -> str | None:
    stripped = line.strip()
    if stripped in ('# Abstract', '## Abstract') or stripped.startswith('**Formal verification'):
        return None
    return _latin_title(line)


shared.latin_title = _subtitle

_prepare = shared.prepare


def _prepare_paginated(source: str, toc: bool, profile: dict):
    title, subtitle, body = _prepare(source, toc, profile)
    body = re.sub(
        r'```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n'
        r'(#{1,2} (?:摘要|Abstract(?: \(English\))?)\s*)\n\n'
        r'```\{=latex\}\n(\\begingroup\\small[^\n]+)\n```'
        r'(.*?)'
        r'```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```',
        lambda m: (
            '```{=latex}\n\\Needspace{9\\baselineskip}\n```\n\n'
            + m.group(1)
            + '\n\n```{=latex}\n'
            + m.group(2)
            + '\n```'
            + m.group(3)
            + '```{=latex}\n\\endgroup\\par\n```'
        ),
        body,
        flags=re.S,
    )
    body = re.sub(
        r'```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n'
        r'(# (?:参考文献|References)\s*)\n\n'
        r'```\{=latex\}\n(\\begingroup\\footnotesize[^\n]+)\n```',
        lambda m: (
            '```{=latex}\n\\Needspace{8\\baselineskip}\n```\n\n'
            + m.group(1)
            + '\n\n```{=latex}\n'
            + m.group(2)
            + '\n```'
        ),
        body,
        count=1,
    )
    body = re.sub(
        r'```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```\s*\Z',
        lambda _: '```{=latex}\n\\endgroup\\par\n```\n',
        body,
        count=1,
    )
    return title, subtitle, body


shared.prepare = _prepare_paginated


def _smart_code_breaks(match: re.Match) -> str:
    inner = match.group(1)
    if re.fullmatch(r'[0-9a-f]{32,64}', inner):
        chunked = re.sub(r'([0-9a-f]{8})(?=[0-9a-f])', r'\1\\allowbreak{}', inner)
        return '{\\sloppy ' + chunked + '}'
    s = inner
    s = s.replace('/', '/\\allowbreak{}')
    s = s.replace('-', '-\\allowbreak{}')
    s = s.replace(',', ',\\allowbreak{}')
    s = s.replace('::', '::\\allowbreak{}')
    s = s.replace('\\_', '\\_\\allowbreak{}')
    s = s.replace('\\{', '\\allowbreak\\{')
    s = s.replace('\\}', '\\}\\allowbreak{}')
    s = re.sub(r'\.(?!lean\b)', r'.\\allowbreak{}', s)
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1\\allowbreak{}\2', s)
    s = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1\\allowbreak{}\2', s)
    return '{\\sloppy ' + s + '}'


def _rebalance_five_col_tables(ts: str) -> str:
    def repl(m: re.Match) -> str:
        block = m.group(0)
        reals = re.findall(r'\\real\{[0-9.]+\}', block)
        if len(reals) != 5:
            return block
        if ('GO1' in block and 'GO8' in block and 'BoardKernel' in block):
            weights = ('0.0700', '0.1600', '0.2500', '0.2800', '0.2400')
        elif 'Weninger' in block and 'MIGOS' in block and 'Benson (1976)' in block:
            weights = ('0.1700', '0.2100', '0.2400', '0.1800', '0.2000')
        elif ('165760' in block and 'ElevenLeftBridge' in block):
            weights = ('0.1900', '0.1100', '0.2300', '0.2000', '0.2700')
        elif ('357' in block and '356' in block and '349' in block):
            weights = ('0.1700', '0.2300', '0.2100', '0.2400', '0.1500')
        else:
            return block
        it = iter(weights)
        return re.sub(r'\\real\{[0-9.]+\}', lambda _: f'\\real{{{next(it)}}}', block, count=5)

    return re.sub(r'\\begin\{longtable\}.*?\\end\{longtable\}', repl, ts, flags=re.S)


_compile_tex = shared.compile_tex


def _compile_clean(tex: Path):
    params = tex.parent / 'paper-params.tex'
    if params.is_file():
        ptxt = params.read_text()
        hook = (
            '\\AtBeginDocument{'
            '\\pretocmd{\\section}{\\Needspace{10\\baselineskip}}{}{}'
            '\\pretocmd{\\subsection}{\\Needspace{8\\baselineskip}}{}{}'
            '}\n'
        )
        if '\\pretocmd{\\subsection}' not in ptxt:
            params.write_text(ptxt + hook)

    ts = tex.read_text()
    ts = re.sub(r'\\seqsplit\{((?:\\.|[^{}])+)\}', _smart_code_breaks, ts)
    ts = _rebalance_five_col_tables(ts)

    thm_pat = re.compile(
        r'(?m)^(\\textbf\{(?:定理|命题|引理|推论|核验计算|定义|例|注记|Theorem|Proposition|Lemma|Corollary|Certified Computation|Definition|Example|Remark)\s+(?:[A-Z](?:\.[0-9]+)?|[0-9]+\.[0-9]+))'
    )
    out_lines = []
    for line in ts.split('\n'):
        if thm_pat.match(line):
            prev_nonempty = next((x for x in reversed(out_lines) if x.strip()), '')
            if '\\Needspace' not in prev_nonempty:
                out_lines.append('\\Needspace{7\\baselineskip}')
        out_lines.append(line)
    tex.write_text('\n'.join(out_lines))
    return _compile_tex(tex)


shared.compile_tex = _compile_clean
shared.fit_wide_displays = partial(shared.fit_wide_displays, tolerance=0.0)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lang', choices=('zh', 'en', 'both'), default='both')
    parser.add_argument('--no-toc', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=PAPER / 'build')
    args = parser.parse_args()

    out_dir = args.output_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    temp = out_dir / 'tmp'
    temp.mkdir(parents=True, exist_ok=True)
    os.environ['TMPDIR'] = str(temp)

    targets = [ZH, EN] if args.lang == 'both' else ([ZH] if args.lang == 'zh' else [EN])
    try:
        for rel in targets:
            rep = shared.build(rel, toc=not args.no_toc, output_dir=out_dir)
            print(json.dumps(rep, ensure_ascii=False))
    finally:
        shutil.rmtree(temp, ignore_errors=True)


if __name__ == '__main__':
    main()
