#!/usr/bin/env python3
"""Create the editable companion to the Chinese and English reading PDFs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
PAPER_PATH = PAPER.relative_to(ROOT)
FIGURES = ('fig1-psk-stealing', 'fig2-vital-chambers', 'fig3-regional-dag', 'fig4-w31-certificate')
SHARED_INPUTS = (
    'shared/scripts/build_pdf.py',
    'shared/scripts/byline.py',
    'shared/styles/article-filter.lua',
    'shared/styles/article-header.tex',
    'shared/styles/article-header-en.tex',
    'shared/figure-style/house_style.py',
    'shared/figure-style/svg_text.py',
)
PAPER_INPUTS = (
    'manuscript.md',
    'manuscript-en.md',
    'references.bib',
    'zenodo-metadata.md',
    'scripts/build_pdf.py',
    'scripts/package_editable.py',
    'validation/verify_manuscript.py',
    'figures/make_figures.py',
    'figures/README.md',
)
PRIVATE_PATH = re.compile(r'/(?:Users|private/tmp|tmp|home)/[^\s"<>]+|file:/+[^\s"<>]+')
README = """# Certified Go · editable source

The archive contains both manuscripts, the bibliography, the four bilingual
vector figures and the inputs to the reading-PDF builder. Start at the extracted
root. The reading build uses Python 3, Pandoc, XeLaTeX, xeCJK and the Noto
Serif/Sans CJK SC fonts in the font locations used by the shared builder.

    python3 papers/certified-go/scripts/build_pdf.py --lang both
    python3 papers/certified-go/validation/verify_manuscript.py

The vector PDFs are included. To regenerate the figures on macOS, install
Chrome, STIX Two and the Noto CJK fonts, and add fontTools to your Python
environment before running:

    python3 papers/certified-go/figures/make_figures.py

Appendix B and Code and Data Availability identify the formalization and the
fixed public inputs. The independent Python check optionally cross-checks the
executions after obtaining their original records from the proof repository:

    python3 papers/certified-go/validation/verify_manuscript.py --receipts \\
      original-certificate.json assembly.jsonl w02-carried.jsonl Eleven-W32-carried.log

The same checker verifies the new full assembly using
`--complete-replay original-source-h11-replay.json original-source-h11-replay.log`.

The preprint and figures use CC BY 4.0. Formalization in H0mework follows the
repository's Apache-2.0 license.
"""


def inputs() -> dict[str, bytes]:
    shared = [Path(name) for name in SHARED_INPUTS]
    paper_files = [Path(name) for name in PAPER_INPUTS]
    paper_files.extend(
        Path('figures') / f'{figure}{language}.{extension}'
        for figure in FIGURES
        for language in ('', '-en')
        for extension in ('svg', 'pdf')
    )
    paper_files.extend(
        Path(name)
        for name in ('source-availability.md', 'evidence-bindings.json', 'public-source-binding.json')
        if (PAPER / name).is_file()
    )
    return {rel.as_posix(): (ROOT / rel).read_bytes()
            for rel in sorted(shared + [PAPER_PATH / name for name in paper_files])}


def package(output: Path) -> None:
    files = inputs()
    for name, data in files.items():
        if name.endswith(('.md', '.bib', '.json', '.svg')) and PRIVATE_PATH.search(data.decode('utf-8')):
            raise ValueError(f'Private path in {name}')
    files['README.md'] = README.encode('utf-8')
    manifest = {'schema': 'publish/editable-inputs@1', 'paper': 'certified-go', 'version': 'v1', 'files': [
        {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        for name, data in sorted(files.items())
    ]}
    files['editable-inputs.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w') as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED)

    with zipfile.ZipFile(output) as archive:
        if archive.testzip() or set(archive.namelist()) != set(files):
            raise ValueError('Editable archive member check failed')
        if any(archive.read(name) != data for name, data in files.items()):
            raise ValueError('Editable archive round trip changed bytes')
    print(f'{output} ({len(files)} files)')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=PAPER / 'build/release-v1/certified-go-v1-editable.zip')
    package(parser.parse_args().output)


if __name__ == '__main__':
    main()
