# Zenodo 发布元数据

## 标题与作者

**英文标题**：First-Player Non-Negativity and Proof-Carrying Regional DAG Strategy Certificates for Positional-Superko Go

**中文标题**：全局超劫围棋的首手非负性定理与证明携带式区域 DAG 策略证书

**作者**：Jian Gao（高健），Independent Researcher，ORCID `0009-0009-5002-1655`。

**类型**：Publication → Preprint。**版本**：v1。**语言**：English、Chinese。**许可**：CC BY 4.0。

## Description

Under positional superko (PSK), two occurrences of the same Go board can admit different moves. In Lean 4 we show that the visible position together with the set of all past boards forms a strong bisimulation. This quotient mechanizes Weninger and Hayward's opening-pass proof that Black can force a nonnegative margin on every square board under no-suicide, pass-exempt PSK and double-pass area scoring. For regional play, maximal historical Black footprints give a sufficient test of global freshness. A connected-exterior capacity bound lets a verified checker lift a corner directed acyclic graph (DAG) to a full-board strategy. The terminal geometry allows enemy stones inside vital chambers while preserving every core stone and counting singleton eyes as guaranteed area. On a 12-ply $19\times 19$ position, the checker validated a DAG with $1{,}700{,}986$ nodes and $2{,}007{,}462$ edges and generated a strategy certificate for margin at least $-345$. Its leaves certify at least eight Black area points in the corner. At the 11-ply position, a single execution assembles certificates for all 351 legal non-resigning White replies. It lifts the resulting certificate to the actual 10-ply predecessor through Black’s move at (2,1).

## 中文摘要

在全局局面超劫（PSK）下，同一可见围棋盘面可因过往盘面不同而拥有不同的合法着法。本文在 Lean 4 中证明，可见状态与曾见盘面的集合构成强双模拟，并形式化 Weninger 与 Hayward 的开局虚着论证：在禁自杀、虚着豁免超劫、双虚着面积计分的规则下，任意方形棋盘的黑方均可在贴目为零时确保分差非负。对区域策略，历史黑子足迹的极大元给出全盘新鲜性的充分判据，连通外部的容量界使经验证的检查器能把角部有向无环图（DAG）提升为全盘策略。终叶允许对手在要害室内驻子，仍保护全部核心棋子，并计入单点眼的面积。在一个 12 手 $19\times19$ 局面上，检查器验证了含 $1{,}700{,}986$ 个节点与 $2{,}007{,}462$ 条边的策略图，生成保底分差 $-345$ 的证书。该图的活棋叶保证角部至少八点。程序在一次运行中总装 11 手局面的全部 351 个合法非认输白应手，再经实下黑着 (2,1) 将证书回接至 10 手前驱。

## 关键词

Go, positional superko, strategy stealing, vital chambers, graph-history interaction, strategy certificates, Lean 4

## 文件

- `certified-go.pdf`
- `certified-go-en.pdf`
- `certified-go-v1-editable.zip`

## 公开证明

[固定源码](https://github.com/Sapientropic/H0mework/tree/5190af978f01c121d50244e34ce538c3b5054f44) · [逐项映射](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-map.json) · [复现](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-reproduction.md)
