#!/usr/bin/env python3
"""Independent verification suite for `certified-go` (`manuscript.md` & `manuscript-en.md`).

Run from the publish root:
    python3 papers/certified-go/validation/verify_manuscript.py

Zero external dependencies (Python 3 standard library only). Verifies:
1. Exact PSK Go game-kernel rules on 0x0, 1x1, and 2x2 (values 0, 0, +1), 2x2 symmetry breaking, and depth-4 q_PSK bisimulation;
2. Both 19x19 same-board different-history PSK bifurcations: reachable 5-ply vs. 7-ply corner ko (357 vs. 356 ports) and 13-ply control (349 vs. 348 ports);
3. Reachable 8-ply 5x5 capture-and-replay antichain witness (Example 5.4) and 12-ply W31 bitmask 165760;
4. Vital-chamber and eye-coalition geometry, all five HookSource shapes, and the 351 White replies at the original eleven-ply frame;
5. W31, W02, W32 and batch receipt facts, when the four original receipt files are supplied;
6. Bilingual structure, references, figures and typography.
"""
from __future__ import annotations

import argparse
import hashlib
from collections import deque
import json
from pathlib import Path
import re

PAPER = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# 1. Clean-room reference implementation of RulesKernel + ScoreReadout
# ---------------------------------------------------------------------------

def neighbours(n: int, pt: tuple[int, int]) -> list[tuple[int, int]]:
    r, c = pt
    out = []
    if r > 0:
        out.append((r - 1, c))
    if r + 1 < n:
        out.append((r + 1, c))
    if c > 0:
        out.append((r, c - 1))
    if c + 1 < n:
        out.append((r, c + 1))
    return out


def component_at(n: int, board: dict[tuple[int, int], str | None], start: tuple[int, int]) -> set[tuple[int, int]]:
    val = board[start]
    seen = {start}
    q = deque([start])
    while q:
        cur = q.popleft()
        for nb in neighbours(n, cur):
            if board[nb] == val and nb not in seen:
                seen.add(nb)
                q.append(nb)
    return seen


def has_liberty(n: int, board: dict[tuple[int, int], str | None], group: set[tuple[int, int]]) -> bool:
    return any(board[nb] is None for stone in group for nb in neighbours(n, stone))


def board_sig(n: int, board: dict[tuple[int, int], str | None]) -> tuple[tuple[str | None, ...], ...]:
    return tuple(tuple(board[(r, c)] for c in range(n)) for r in range(n))


def empty_board(n: int) -> dict[tuple[int, int], str | None]:
    return {(r, c): None for r in range(n) for c in range(n)}


def other(col: str) -> str:
    return 'W' if col == 'B' else 'B'


def swap_board(board: dict[tuple[int, int], str | None]) -> dict[tuple[int, int], str | None]:
    return {pt: (other(v) if v is not None else None) for pt, v in board.items()}


def swap_frame(n: int, frame: dict) -> dict:
    sb = swap_board(frame['board'])
    return {
        'board': sb,
        'toMove': other(frame['toMove']),
        'passes': frame['passes'],
        'status': frame['status'],
        'history': [
            (tuple(tuple(other(cell) if cell else None for cell in row) for row in sig), other(col))
            for sig, col in frame['history']
        ],
    }


def q_psk(n: int, frame: dict) -> tuple:
    return (
        board_sig(n, frame['board']),
        frame['toMove'],
        frame['passes'],
        frame['status'],
        frozenset(sig for sig, _ in frame['history']),
    )


def captured_stones_after_play(n: int, board: dict[tuple[int, int], str | None], col: str, pt: tuple[int, int]) -> set[tuple[int, int]]:
    placed = dict(board)
    placed[pt] = col
    captured: set[tuple[int, int]] = set()
    for nb in neighbours(n, pt):
        if placed[nb] == other(col):
            grp = component_at(n, placed, nb)
            if not has_liberty(n, placed, grp):
                captured |= grp
    return captured


def board_after_play(n: int, board: dict[tuple[int, int], str | None], col: str, pt: tuple[int, int]) -> dict[tuple[int, int], str | None]:
    placed = dict(board)
    placed[pt] = col
    for stone in captured_stones_after_play(n, board, col, pt):
        placed[stone] = None
    return placed


def native_step(n: int, frame: dict, move: tuple[str, tuple[int, int] | None]) -> dict | None:
    if frame['status'] != 'playing':
        return None
    kind, pt = move
    board = frame['board']
    turn = frame['toMove']
    if kind == 'pass':
        np = frame['passes'] + 1
        st = 'twoPasses' if np >= 2 else 'playing'
        nt = other(turn)
        return {
            'board': dict(board),
            'toMove': nt,
            'passes': np,
            'status': st,
            'history': frame['history'] + [(board_sig(n, board), nt)],
        }
    if kind == 'play':
        assert pt is not None
        if board[pt] is not None:
            return None
        nb = board_after_play(n, board, turn, pt)
        if not has_liberty(n, nb, component_at(n, nb, pt)):
            return None
        sig = board_sig(n, nb)
        if any(prev_sig == sig for prev_sig, _ in frame['history']):
            return None
        nt = other(turn)
        return {
            'board': nb,
            'toMove': nt,
            'passes': 0,
            'status': 'playing',
            'history': frame['history'] + [(sig, nt)],
        }
    raise ValueError(kind)


def initial_frame(n: int) -> dict:
    b = empty_board(n)
    return {
        'board': b,
        'toMove': 'B',
        'passes': 0,
        'status': 'playing',
        'history': [(board_sig(n, b), 'B')],
    }


def scoring_expansion(n: int, frame: dict) -> list[tuple[tuple[str, tuple[int, int] | None], dict]]:
    moves: list[tuple[str, tuple[int, int] | None]] = [('play', (r, c)) for r in range(n) for c in range(n)] + [('pass', None)]
    out = []
    for mv in moves:
        nxt = native_step(n, frame, mv)
        if nxt is not None:
            out.append((mv, nxt))
    return out


def area_margin(n: int, board: dict[tuple[int, int], str | None]) -> int:
    area = {'B': 0, 'W': 0}
    for r in range(n):
        for c in range(n):
            v = board[(r, c)]
            if v in ('B', 'W'):
                area[v] += 1
            else:
                reg = component_at(n, board, (r, c))
                borders = {
                    board[nb]
                    for ep in reg
                    for nb in neighbours(n, ep)
                    if board[nb] is not None
                }
                if borders == {'B'}:
                    area['B'] += 1
                elif borders == {'W'}:
                    area['W'] += 1
    return area['B'] - area['W']


def forces_black_ge(n: int, frame: dict, threshold: int, memo: dict | None = None, board_ids: dict | None = None) -> bool:
    if memo is None:
        memo = {}
    if board_ids is None:
        board_ids = {}
    if frame['status'] == 'twoPasses':
        return area_margin(n, frame['board']) >= threshold

    def bid(sig: tuple) -> int:
        idx = board_ids.get(sig)
        if idx is None:
            idx = len(board_ids)
            board_ids[sig] = idx
        return idx

    cur = bid(board_sig(n, frame['board']))
    seen = 0
    for s, _ in frame['history']:
        seen |= 1 << bid(s)
    key = (cur, frame['toMove'], frame['passes'], seen, threshold)
    if key in memo:
        return memo[key]
    children = scoring_expansion(n, frame)
    if frame['toMove'] == 'B':
        children.sort(
            key=lambda it: (
                -100 if (it[0][0] == 'pass' and frame['passes'] == 1 and area_margin(n, frame['board']) >= threshold)
                else sum(1 for val in it[1]['board'].values() if val == 'W')
            )
        )
        ans = any(forces_black_ge(n, ch, threshold, memo, board_ids) for _, ch in children)
    else:
        children.sort(
            key=lambda it: (
                -100 if (it[0][0] == 'pass' and area_margin(n, frame['board']) < threshold)
                else sum(1 for val in it[1]['board'].values() if val == 'B')
            )
        )
        ans = all(forces_black_ge(n, ch, threshold, memo, board_ids) for _, ch in children)
    memo[key] = ans
    return ans


def antichain_insert(ac: list[frozenset[tuple[int, int]]], fp: frozenset[tuple[int, int]]) -> list[frozenset[tuple[int, int]]]:
    if any(fp <= m for m in ac):
        return ac
    return [m for m in ac if not (m < fp)] + [fp]


def check_vital_chambers_geometry(n: int, core: set[tuple[int, int]], rooms: list[set[tuple[int, int]]]) -> set[tuple[int, int]]:
    assert core
    for i in range(len(rooms)):
        assert rooms[i]
        assert not (rooms[i] & core)
        for j in range(i + 1, len(rooms)):
            assert not (rooms[i] & rooms[j])
    for r in rooms:
        for x in r:
            nbs = set(neighbours(n, x))
            assert nbs, f'Isolated point {x}'
            assert nbs <= (core | r), f'Unenclosed boundary at {x}: {nbs - (core | r)}'
    mask = empty_board(n)
    for x in core:
        mask[x] = 'B'
    for s in core:
        comp = component_at(n, mask, s)
        adj_comp = {nb for y in comp for nb in neighbours(n, y)}
        supporting = [r for r in rooms if r <= adj_comp]
        assert len(supporting) >= 2, f'Core stone {s} has <2 supporting vital chambers'
    singletons = set().union(*(r for r in rooms if len(r) == 1))
    return core | singletons


def assert_bisimilar(n: int, f_left: dict, f_right: dict, depth: int) -> None:
    assert q_psk(n, f_left) == q_psk(n, f_right)
    assert area_margin(n, swap_board(f_left['board'])) == -area_margin(n, f_left['board'])
    if depth == 0 or f_left['status'] != 'playing':
        return
    exp_l = scoring_expansion(n, f_left)
    exp_r = scoring_expansion(n, f_right)
    assert [mv for mv, _ in exp_l] == [mv for mv, _ in exp_r]
    for (_, ch_l), (_, ch_r) in zip(exp_l, exp_r):
        assert_bisimilar(n, ch_l, ch_r, depth - 1)


def check_go_anchors_and_receipts() -> None:
    # 1. Exact PSK critical komi values on 0x0 (0), 1x1 (0), and 2x2 (+1), plus Remark 3.6 symmetry breaking
    for sz, exact_val in [(0, 0), (1, 0), (2, 1)]:
        f0_sz = initial_frame(sz)
        memo_sz: dict = {}
        bids_sz: dict = {}
        assert forces_black_ge(sz, f0_sz, exact_val, memo_sz, bids_sz), (sz, exact_val)
        assert not forces_black_ge(sz, f0_sz, exact_val + 1, memo_sz, bids_sz), (sz, exact_val + 1)

    f2_cur = initial_frame(2)
    for mv in [('play', (0, 0)), ('play', (1, 1)), ('play', (0, 1)), ('play', (1, 0))]:
        f2_cur = native_step(2, f2_cur, mv)
        assert f2_cur is not None
    assert f2_cur['board'] == {(0, 0): None, (0, 1): None, (1, 0): 'W', (1, 1): 'W'}
    f_5_bad = native_step(2, f2_cur, ('play', (0, 0)))
    f_5_good = native_step(2, f2_cur, ('play', (0, 1)))
    assert f_5_bad is not None and f_5_good is not None
    m_rem: dict = {}
    b_rem: dict = {}
    assert not forces_black_ge(2, f_5_bad, 0, m_rem, b_rem)
    assert forces_black_ge(2, f_5_bad, -4, m_rem, b_rem)
    assert forces_black_ge(2, f_5_good, 1, m_rem, b_rem)
    assert not forces_black_ge(2, f_5_good, 2, m_rem, b_rem)
    f_6_bad = native_step(2, f_5_bad, ('play', (0, 1)))
    assert f_6_bad is not None and native_step(2, f_6_bad, ('play', (0, 0))) is None
    f_6_good = native_step(2, f_5_good, ('play', (0, 0)))
    assert f_6_good is not None and native_step(2, f_6_good, ('play', (0, 1))) is not None

    # Exhaustive 4-ply verification of Theorem 3.4's opening-pass swap + q_PSK bisimulation lift on 2x2
    f0 = initial_frame(2)
    f1 = native_step(2, f0, ('pass', None))
    assert f1 is not None and len(f1['history']) == 2
    reset_swap_f1 = swap_frame(2, f1)
    reset_swap_f1['passes'] = 0
    assert q_psk(2, reset_swap_f1) == q_psk(2, f0)
    for r in range(2):
        for c in range(2):
            f2 = native_step(2, f1, ('play', (r, c)))
            t1 = native_step(2, f0, ('play', (r, c)))
            assert f2 is not None and t1 is not None
            assert_bisimilar(2, swap_frame(2, f2), t1, depth=4)

    # 2a. Reachable 5-ply gamma_1 vs. 7-ply gamma_2 corner ko bifurcation on 19x19 (Section 1.1 & Example 2.3)
    gamma1 = [('play', (1, 0)), ('play', (0, 2)), ('play', (2, 0)), ('play', (1, 1)), ('play', (0, 1))]
    gamma2 = [
        ('play', (1, 0)), ('play', (0, 0)), ('play', (2, 0)), ('play', (0, 2)),
        ('pass', None), ('play', (1, 1)), ('play', (0, 1)),
    ]
    fg1 = initial_frame(19)
    for mv in gamma1:
        fg1 = native_step(19, fg1, mv)
        assert fg1 is not None
    fg2 = initial_frame(19)
    for mv in gamma2:
        fg2 = native_step(19, fg2, mv)
        assert fg2 is not None
    assert board_sig(19, fg1['board']) == board_sig(19, fg2['board'])
    assert fg1['toMove'] == fg2['toMove'] == 'W'
    assert fg1['passes'] == fg2['passes'] == 0
    assert {pt for pt, v in fg1['board'].items() if v == 'B'} == {(0, 1), (1, 0), (2, 0)}
    assert {pt for pt, v in fg1['board'].items() if v == 'W'} == {(0, 2), (1, 1)}
    assert native_step(19, fg1, ('play', (0, 0))) is not None
    assert native_step(19, fg2, ('play', (0, 0))) is None
    assert native_step(19, fg1, ('pass', None)) is not None
    assert native_step(19, fg2, ('pass', None)) is not None
    assert len(scoring_expansion(19, fg1)) == 357
    assert len(scoring_expansion(19, fg2)) == 356

    # 2b. 11-ply H11, 12-ply W31 bitmask 165760, and 13-ply synthetic regression control (349 vs. 348 ports)
    h11 = [
        ('play', (1, 1)), ('play', (18, 18)), ('play', (1, 2)), ('play', (18, 16)),
        ('play', (1, 3)), ('play', (18, 14)), ('play', (1, 0)), ('play', (0, 1)),
        ('play', (2, 3)), ('play', (18, 12)), ('play', (2, 1)),
    ]
    cur = initial_frame(19)
    for mv in h11:
        cur = native_step(19, cur, mv)
        assert cur is not None
    assert len(cur['history']) == 12
    successors = dict(scoring_expansion(19, cur))
    assert len(successors) == 351
    exceptional = {(0, 0), (0, 2), (0, 3), (2, 0), (2, 2), (3, 0), (3, 1), (3, 2)}
    assert all(('play', pt) in successors for pt in exceptional)
    hook_core = {(1, 0), (1, 1), (1, 2), (1, 3), (2, 1), (2, 3), (3, 1)}
    hook_air = {(0, 0), (0, 2), (0, 3), (2, 0), (2, 2), (3, 0), (3, 2)}
    hook_fresh = {(0, 2), (0, 3), (3, 0), (3, 2)}
    hook_count = 0
    for (_, point), white_target in successors.items():
        if point in exceptional:
            continue
        hook = native_step(19, white_target, ('play', (3, 1)))
        assert hook is not None
        assert (hook['status'], hook['toMove'], hook['passes']) == ('playing', 'W', 0)
        assert all(hook['board'][pt] == 'B' for pt in hook_core)
        assert hook['board'][(0, 1)] == 'W'
        assert all(hook['board'][pt] is None for pt in hook_air)
        assert all(sig[row][col] != 'B'
                   for sig, _ in hook['history'] for row, col in hook_fresh)
        hook_count += 1
    assert hook_count == 343

    w31 = native_step(19, cur, ('play', (3, 1)))
    assert w31 is not None and len(w31['history']) == 13
    black_stones = {pt for pt, v in w31['board'].items() if v == 'B'}
    assert black_stones == {(1, 0), (1, 1), (1, 2), (1, 3), (2, 1), (2, 3)}
    white_stones = {pt for pt, v in w31['board'].items() if v == 'W'}
    assert white_stones == {(0, 1), (3, 1), (18, 12), (18, 14), (18, 16), (18, 18)}
    assert w31['board'][(2, 4)] is None
    assert native_step(19, w31, ('play', (2, 4))) is not None
    mask = sum(1 << (7 * r + c) for r, c in black_stones)
    assert mask == 165760, mask

    f12 = native_step(19, cur, ('play', (0, 2)))
    assert f12 is not None
    f13 = native_step(19, f12, ('play', (3, 1)))
    assert f13 is not None and len(f13['history']) == 14
    assert len(scoring_expansion(19, f13)) == 349
    f14 = native_step(19, f13, ('play', (0, 3)))
    assert f14 is not None
    f13_aug = dict(f13)
    f13_aug['history'] = f13['history'] + [(board_sig(19, f14['board']), f14['toMove'])]
    assert native_step(19, f13_aug, ('play', (0, 3))) is None
    assert native_step(19, f13_aug, ('pass', None)) is not None
    assert len(scoring_expansion(19, f13_aug)) == 348

    # 3. Reachable 8-ply 5x5 capture-and-replay antichain witness (Example 5.4(1))
    seq_5x5 = [
        ('play', (0, 0)), ('play', (0, 1)), ('play', (2, 0)), ('play', (1, 0)),
        ('play', (1, 1)), ('play', (4, 4)), ('play', (0, 2)), ('play', (4, 3)),
    ]
    f5 = initial_frame(5)
    ac: list[frozenset[tuple[int, int]]] = [frozenset()]
    ever_played_black: set[tuple[int, int]] = set()
    for idx, mv in enumerate(seq_5x5):
        if idx % 2 == 0 and mv[1] is not None:
            ever_played_black.add(mv[1])
        f5 = native_step(5, f5, mv)
        assert f5 is not None
        fp = frozenset(pt for pt, v in f5['board'].items() if v == 'B')
        if idx % 2 == 0:
            ac = antichain_insert(ac, fp)
        else:
            assert any(fp <= m for m in ac)
    assert set(ac) == {frozenset({(0, 2), (1, 1), (2, 0)}), frozenset({(0, 0), (2, 0)})}
    assert (0, 0) in ever_played_black  # Virgin-point test fails!
    f5_recap = native_step(5, f5, ('play', (0, 0)))
    assert f5_recap is not None
    c_prime = frozenset(pt for pt, v in f5_recap['board'].items() if v == 'B')
    assert c_prime == frozenset({(0, 0), (0, 2), (1, 1), (2, 0)})
    assert all(not (c_prime <= m) for m in ac)  # Joint-footprint antichain test succeeds!

    # 4. Example 1.1(b) & Fig. 2(a) right 7-stone VitalChambers, EyeCoalition, HookSource, ElevenLeftBridge
    assert 2 * 8 - 19 * 19 == -345
    assert 2 * 10 - 19 * 19 == -341

    ex11b_core = {(0, 2), (1, 0), (1, 1), (1, 2), (2, 1), (3, 0), (3, 1)}
    assert len(ex11b_core) == 7
    m7 = empty_board(19)
    for pt in ex11b_core:
        m7[pt] = 'B'
    assert component_at(19, m7, (1, 1)) == ex11b_core
    p_ex11b = check_vital_chambers_geometry(19, ex11b_core, [{(2, 0)}, {(0, 0), (0, 1)}])
    assert len(p_ex11b) == 8 and 2 * len(p_ex11b) - 361 == -345
    # Verify exact legal non-suicidal board in Example 4.4 (White leaves 1 exterior eye at (18,18)):
    # every stone chain has >=1 liberty, Black gets 8 pts, White gets 352 pts, (0,1) is dame => margin = -344
    tight_b = {(r, c): 'W' for r in range(19) for c in range(19)}
    for pt in ex11b_core:
        tight_b[pt] = 'B'
    tight_b[(2, 0)] = None
    tight_b[(0, 0)] = 'W'
    tight_b[(0, 1)] = None
    tight_b[(18, 18)] = None
    for pt, v in tight_b.items():
        if v is not None:
            assert has_liberty(19, tight_b, component_at(19, tight_b, pt)), f'Zero-liberty chain at {pt}'
    assert area_margin(19, tight_b) == 8 - 352 == -344

    # Verify Definition 5.5 Snapshot.rank unit drop (RegionalProgram.lean:415-424)
    def snap_rank(turn: str, rem: int) -> int:
        return 2 * rem + (1 if turn == 'W' else 0)

    for rem in range(1, 15):
        assert snap_rank('W', rem - 1) + 1 == snap_rank('B', rem)  # ownNext: r -> r-1, B -> W
        assert snap_rank('B', rem) + 1 == snap_rank('W', rem)      # whiteNext: r kept, W -> B

    ec_core = {(0, 0), (0, 2), (1, 2), (1, 1), (2, 1), (2, 0)}
    ec_eyes = {(0, 1), (1, 0)}
    for e in ec_eyes:
        nbs = set(neighbours(19, e))
        assert nbs and nbs <= ec_core
    assert len(ec_core | ec_eyes) == 8

    hook_base = {(1, 0), (1, 1), (1, 2), (1, 3), (2, 1), (2, 3), (3, 1)}
    hook_shapes = [
        (hook_base | {(3, 0), (0, 2)}, [{(0, 0), (0, 1)}, {(2, 0)}], 10),
        (hook_base | {(3, 0), (0, 3)}, [{(0, 0), (0, 1), (0, 2)}, {(2, 0)}], 10),
        (hook_base | {(3, 0), (3, 2)}, [{(2, 0)}, {(2, 2)}], 11),
        (hook_base | {(3, 2), (0, 2)}, [{(0, 0), (0, 1)}, {(2, 2)}], 10),
        (hook_base | {(3, 2), (0, 3)}, [{(0, 0), (0, 1), (0, 2)}, {(2, 2)}], 10),
    ]
    for sh_core, sh_rooms, expected_p in hook_shapes:
        p_sh = check_vital_chambers_geometry(19, sh_core, sh_rooms)
        assert len(p_sh) == expected_p and 2 * len(p_sh) - 361 >= -341

    for w_pt, expected_ports in [((0, 0), 351), ((0, 3), 348), ((2, 0), 348), ((2, 2), 348), ((3, 0), 348)]:
        f_w = native_step(19, cur, ('play', w_pt))
        assert f_w is not None
        f_b02 = native_step(19, f_w, ('play', (0, 2)))
        assert f_b02 is not None
        assert len(scoring_expansion(19, f_b02)) == expected_ports, (w_pt, len(scoring_expansion(19, f_b02)))

def check_original_receipts(w31: Path, assembly: Path, w02: Path, w32: Path) -> None:
    regional = json.loads(w31.read_text(encoding='utf-8'))
    inp, comp = regional['input'], regional['compiler']
    assert regional['status'] == 'original_certificate_generated'
    assert regional['certificate']['type'] == 'Certificate .positive (-345) frame'
    assert regional['certificate']['first_original_move'] == [2, 4]
    assert regional['certificate']['native_step_and_complete_history_checked'] is True
    assert regional['source']['original_history_rows'] == 13
    assert regional['execution']['exit_code'] == 0
    assert regional['execution']['whole_process_wall_seconds'] == 3140.66
    assert regional['execution']['peak_rss_bytes'] == 7_065_436_160
    coalition_leaves = comp['coalition_hits'] + comp['coalition_geometry_compiles']
    vital_leaves = comp['vital_hits'] + comp['vital_geometry_compiles']
    assert (coalition_leaves, vital_leaves) == (743_233, 62_516)
    assert inp['own_nodes'] + inp['white_nodes'] + coalition_leaves + vital_leaves == comp['checked_nodes'] == inp['nodes'] == 1_700_986
    assert inp['own_nodes'] + inp['white_ports'] == inp['edges'] == 2_007_462

    batch = json.loads(assembly.read_text(encoding='utf-8').splitlines()[-1])
    assert batch['stage'] == 'assembled_current_producers'
    assert (batch['source_plies'], batch['history_length']) == (11, 12)
    assert (batch['original_white_ports'], batch['retained_children'], batch['elapsed_ms']) == (351, 348, 246_337)
    assert batch['complete_certificate'] is False
    assert [entry.rsplit('play ', 1)[-1] for entry in batch['outstanding_source_ports']] == [
        '(0, 2)', '(3, 1)', '(3, 2)',
    ]

    source, generated, completed = [json.loads(row) for row in w02.read_text(encoding='utf-8').splitlines()]
    assert (source['plies'], source['history_length'], generated['elapsed_ms']) == (12, 13, 1_748_854)
    assert generated['first_black'].endswith('play (3, 1)')
    assert completed['complete_certificate'] is True
    assert (completed['inspected_ports'], completed['original_white_ports']) == (8, 349)
    vertical = w32.read_text(encoding='utf-8')
    assert re.search(r'Certificate positive \(-345\) emitted; first .*play \(3, 1\); 1690875 ms', vertical)
    assert 'checked 7 of 349 original first White ports and Black responses; 1697420 ms' in vertical


def check_bilingual_parity_and_hygiene() -> None:
    zh = (PAPER / 'manuscript.md').read_text(encoding='utf-8')
    en = (PAPER / 'manuscript-en.md').read_text(encoding='utf-8')

    # Monolingual hygiene in manuscript-en.md and *-en.svg
    cjk = re.findall(r'[\u4e00-\u9fff]', en)
    assert not cjk, f'CJK leakage in manuscript-en.md: {cjk[:10]}'
    fw = re.findall(r'[｜：；，。（）！　]', en)
    assert not fw, f'Full-width punctuation in manuscript-en.md: {fw[:10]}'
    assert '！' not in zh, 'Full-width exclamation mark in manuscript.md'

    for en_svg in sorted((PAPER / 'figures').glob('*-en.svg')):
        svg_txt = en_svg.read_text(encoding='utf-8')
        assert not re.findall(r'[\u4e00-\u9fff｜：；，。（）！　]', svg_txt), f'CJK/fullwidth in {en_svg.name}'

    # Tone & cold-read hygiene (no hype buzzwords, author byline present, exact Zenodo self-cite titles)
    assert '**作者：高健（Jian Gao）**\\' in zh, 'Missing Chinese author byline in manuscript.md'
    assert '**Author: Jian Gao**\\' in en, 'Missing English author byline in manuscript-en.md'
    assert '源生过程代数与初始余面修订：四层同一性、正合求值核与可逆增量续行' in zh
    assert '溯源守恒演算与非免费连续性：全事件账本、观察安全与良基结清' in zh
    banned_zh = (
        '百分之百', '彻底闭合', '零信任', '最小充要桥梁', '绝非', '迎头相撞', '硬骨头', '严格锁定',
        '实战定式', '六子外势', '单行整账', '无聊和棋', '二路虎补', '分毫不差', '长远而迷人',
    )
    for bw in banned_zh:
        assert bw not in zh, f'Banned buzzword in manuscript.md: {bw}'

    # Inline code ASCII hygiene, quote hygiene, list spacing, table math hygiene, and DOI link match
    doi_pat = re.compile(r'\[([0-9]{2}\.[0-9]{4,9}/[^\]]+)\]\(https://doi\.org/((?:[^()\s]|\([^()\s]*\))+)\)')
    for label, txt in [('zh', zh), ('en', en)]:
        for disp_doi, url_doi in doi_pat.findall(txt):
            assert disp_doi == url_doi, f'{label} DOI display/URL mismatch: [{disp_doi}] vs https://doi.org/{url_doi}'

        lines = txt.splitlines()
        for idx, line in enumerate(lines):
            lineno = idx + 1
            if not line.startswith('```'):
                for code_span in re.findall(r'`([^`]+)`', line):
                    assert all(ord(ch) <= 127 for ch in code_span), (
                        f'{label}:{lineno} non-ASCII char inside inline code (`lmmono` missing-glyph hazard): `{code_span}`'
                    )
                stripped_no_code = re.sub(r'`[^`]+`', '', line)
                if not stripped_no_code.startswith('<a id='):
                    assert '"' not in stripped_no_code, f'{label}:{lineno} raw ASCII quote under Pandoc -smart: {line}'
                if re.match(r'^([-*] |\d+\. )', line) and idx > 0:
                    prev = lines[idx - 1]
                    assert prev.strip() == '' or re.match(r'^([-*] |\d+\. |\s+)', prev), (
                        f'{label}:{lineno} Markdown list missing preceding blank line: {line[:50]}'
                    )
            if line.startswith('|'):
                for math_span in re.findall(r'\$([^$]+)\$', line):
                    assert '|' not in math_span, f'{label}:{lineno} raw/double pipe inside table math: ${math_span}$'

    # Heading counts (zh has ## 摘要 + ## Abstract => 15 vs 14; H3 = 23 vs 23)
    h2_zh = re.findall(r'(?m)^## +(.+)$', zh)
    h2_en = re.findall(r'(?m)^## +(.+)$', en)
    assert len(h2_zh) == len(h2_en) + 1 == 15, (len(h2_zh), len(h2_en))

    h3_zh = re.findall(r'(?m)^### +(.+)$', zh)
    h3_en = re.findall(r'(?m)^### +(.+)$', en)
    assert len(h3_zh) == len(h3_en) == 23, (len(h3_zh), len(h3_en))

    # Anchors (69 exact 1-to-1 anchors)
    anc_zh = re.findall(r'<a id="([^"]+)"></a>', zh)
    anc_en = re.findall(r'<a id="([^"]+)"></a>', en)
    assert anc_zh == anc_en, ('Anchor mismatch', set(anc_zh) ^ set(anc_en))
    assert len(anc_zh) == len(set(anc_zh)) == 69, len(anc_zh)

    # Numbered environments (35 exact 1-to-1 environments including Theorem A/B/C and Certified Computation 6.3)
    env_zh = re.findall(r'(?m)^\*\*(定理|命题|引理|推论|核验计算|定义|例|注记)\s+([A-Z](?:\.[0-9]+)?|[0-9]+\.[0-9]+)', zh)
    env_en = re.findall(
        r'(?m)^\*\*(Theorem|Proposition|Lemma|Corollary|Certified Computation|Definition|Example|Remark)\s+([A-Z](?:\.[0-9]+)?|[0-9]+\.[0-9]+)',
        en,
    )
    map_kind = {
        '定理': 'Theorem', '命题': 'Proposition', '引理': 'Lemma',
        '推论': 'Corollary', '核验计算': 'Certified Computation',
        '定义': 'Definition', '例': 'Example', '注记': 'Remark',
    }
    assert [(map_kind[k], n) for k, n in env_zh] == env_en, ('Environment mismatch', env_zh, env_en)
    assert len(env_zh) == 35, len(env_zh)

    # Equation tags (25 exact 1-to-1 equation tags)
    tags_zh = re.findall(r'\\tag\{([^}]+)\}', zh)
    tags_en = re.findall(r'\\tag\{([^}]+)\}', en)
    assert tags_zh == tags_en, ('Equation tag mismatch', tags_zh, tags_en)
    assert len(tags_zh) == len(set(tags_zh)) == 25, len(tags_zh)

    # Tables & Figures
    tbl_zh = re.findall(r'(?m)^\*\*表\s+([A-Z0-9.]+)', zh)
    tbl_en = re.findall(r'(?m)^\*\*Table\s+([A-Z0-9.]+)', en)
    assert tbl_zh == tbl_en == ['1', '2', '3', '4', 'B.1', 'B.2'], (tbl_zh, tbl_en)

    fig_zh = re.findall(r'!\[图\s+(\d+)｜', zh)
    fig_en = re.findall(r'!\[Figure\s+(\d+)\s+\|', en)
    assert fig_zh == fig_en == ['1', '2', '3', '4'], (fig_zh, fig_en)

    # Citations and bibliography keys must agree in both languages and BibTeX.
    bib = (PAPER / 'references.bib').read_text(encoding='utf-8')
    bib_keys = re.findall(r'(?m)^@[a-zA-Z]+\{([A-Za-z0-9]+),', bib)
    ref_zh = re.findall(r'(?m)^\[([A-Za-z0-9]+)\]\s', zh.split('## 参考文献')[1])
    ref_en = re.findall(r'(?m)^\[([A-Za-z0-9]+)\]\s', en.split('## References')[1])
    assert bib_keys == ref_zh == ref_en and len(bib_keys) == len(set(bib_keys)), (
        len(bib_keys), len(ref_zh), len(ref_en),
    )

    for label, txt in [('zh', zh), ('en', en)]:
        cited: set[str] = set()
        for bracket_grp in re.findall(r'\[([^\]]*@[^\]]*)\]', txt):
            cited.update(re.findall(r'@([A-Za-z][A-Za-z0-9]+)', bracket_grp))
        missing = cited - set(bib_keys)
        unused = set(bib_keys) - cited
        assert not missing, (label, 'missing bib keys:', missing)
        assert not unused, (label, 'unused bib keys:', unused)


def check_complete_replay(receipt: Path, log: Path) -> None:
    readback = json.loads(receipt.read_bytes())
    payload = log.read_bytes()
    assert readback['status'] == 'passed' and readback['exit_code'] == 0
    assert readback['log']['sha256'] == hashlib.sha256(payload).hexdigest()
    stages = {}
    for line in payload.splitlines():
        if line.startswith(b'{'):
            row = json.loads(line)
            if row['stage'] != 'assembling':
                assert row['stage'] not in stages
                stages[row['stage']] = row
    assert stages == readback['results']
    assert stages['original_program_checked']['raw_nodes'] == 1_700_986
    assembly = stages['assembled_current_producers']
    assert (assembly['source_plies'], assembly['history_length']) == (11, 12)
    assert (assembly['original_white_ports'], assembly['retained_children']) == (351, 351)
    assert assembly['complete_certificate'] and not assembly['outstanding_source_ports']
    predecessor = stages['actual_predecessor']
    assert (predecessor['source_plies'], predecessor['history_length']) == (10, 11)
    assert predecessor['black_reply'].endswith('play (2, 1)')
    assert predecessor['complete_certificate']


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--receipts', type=Path, nargs=4,
                        metavar=('W31_JSON', 'ASSEMBLY_JSONL', 'W02_JSONL', 'W32_LOG'),
                        help='validate the four original execution receipts alongside the paper')
    parser.add_argument('--complete-replay', type=Path, nargs=2, metavar=('RECEIPT', 'LOG'),
                        help='check the live H11 assembly and original 10-ply predecessor')
    args = parser.parse_args()
    check_go_anchors_and_receipts()
    check_bilingual_parity_and_hygiene()
    print('PASS: small-board PSK values, reachable superko controls, 343 hook sources, '
          'corner geometry, and bilingual manuscript structure')
    if args.receipts:
        check_original_receipts(*args.receipts)
        print('PASS: W31 DAG, 348/351 batch, and independent W02/W32 execution records')
    if args.complete_replay:
        check_complete_replay(*args.complete_replay)
        print('PASS: Complete H11 assembly (351/351) and original 10-ply predecessor')


if __name__ == '__main__':
    main()
