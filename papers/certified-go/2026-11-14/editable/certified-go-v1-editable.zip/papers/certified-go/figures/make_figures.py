#!/usr/bin/env python3
"""Generate the four bilingual vector plates (SVG + Chrome vector PDF) for certified-go.

Run from the publish root:
    python3 papers/certified-go/figures/make_figures.py

All board configurations, masks, node counts, and TCB boundaries match the
machine-checked Lean 4 modules and tracked execution receipts of GO1-GO8.
"""
from __future__ import annotations

from html import escape
from pathlib import Path
import argparse
import math
import os
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, GOLD, WASH  # noqa: E402
from svg_text import line as text_line, text_width  # noqa: E402

W = 1000
MIN_SIZE = 17
FULLWIDTH_EN = re.compile(r'[｜：；，。（）　]')
CJK_RE = re.compile(r'[\u4e00-\u9fff]')
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
GO_COLS = 'ABCDEFGHJKLMNOPQRST'


class Plate:
    def __init__(self, height: int, lang: str, title: tuple[str, str]):
        self.h = height
        self.lang = lang
        chosen = self.choose(title)
        self.items = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
            f'viewBox="0 0 {W} {height}" role="img" xml:lang="{lang}">',
            f'<title>{escape(chosen)}</title>',
            '<rect width="100%" height="100%" fill="white"/>',
        ]

    def choose(self, value):
        return value[0 if self.lang == 'zh' else 1] if isinstance(value, tuple) else value

    def text(self, x: float, y: float, value, size: float = MIN_SIZE,
             color: str = INK, weight: int = 400, anchor: str = 'start',
             max_width: float = 960, min_floor: float = MIN_SIZE):
        s = str(self.choose(value))
        assert size >= min_floor, (s, size)
        if self.lang == 'en':
            bad = FULLWIDTH_EN.findall(s)
            assert not bad, f'full-width char in EN figure text: {s!r} -> {bad}'
            cjk = CJK_RE.findall(s)
            assert not cjk, f'CJK char in EN figure text: {s!r} -> {cjk}'
        w = text_width(s, size) * (1.07 if (self.lang == 'en' and weight >= 600) else 1.0)
        assert w <= max_width, (self.lang, s, round(w, 1), max_width)
        self.items.append(text_line(x, y, s, size, color, weight, anchor))

    def rect(self, x: float, y: float, w: float, h: float,
             fill: str = 'white', stroke: str = HAIR, sw: float = 1.2,
             rx: float = 6, dash: str = ''):
        da = f' stroke-dasharray="{dash}"' if dash else ''
        self.items.append(
            f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
            f'rx="{rx:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{da}/>'
        )

    def card(self, x: float, y: float, w: float, h: float,
             fill: str = 'white', stroke: str = HAIR, accent: str | None = DEEP):
        self.rect(x, y, w, h, fill=fill, stroke=stroke, sw=1.2, rx=6)
        if accent:
            self.items.append(
                f'<line x1="{x + 1:.1f}" y1="{y + 6:.1f}" x2="{x + 1:.1f}" y2="{y + h - 6:.1f}" '
                f'stroke="{accent}" stroke-width="3.2" stroke-linecap="round"/>'
            )

    def seg(self, x1: float, y1: float, x2: float, y2: float,
            color: str = SLATE, sw: float = 1.5, dash: str = ''):
        da = f' stroke-dasharray="{dash}"' if dash else ''
        self.items.append(
            f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="{color}" stroke-width="{sw}"{da}/>'
        )

    def arrow(self, x1: float, y1: float, x2: float, y2: float,
              color: str = SLATE, sw: float = 1.7, dash: str = ''):
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        if L < 1e-6:
            return
        ux, uy = dx / L, dy / L
        hl, hw = 8.5, 4.3
        bx, by = x2 - ux * (hl - 1.5), y2 - uy * (hl - 1.5)
        self.seg(x1, y1, bx, by, color=color, sw=sw, dash=dash)
        px, py = -uy * hw, ux * hw
        p1x, p1y = x2 - ux * hl + px, y2 - uy * hl + py
        p2x, p2y = x2 - ux * hl - px, y2 - uy * hl - py
        self.items.append(
            f'<polygon points="{x2:.1f},{y2:.1f} {p1x:.1f},{p1y:.1f} {p2x:.1f},{p2y:.1f}" fill="{color}"/>'
        )

    def bi_arrow(self, x1: float, y1: float, x2: float, y2: float,
                 color: str = DEEP, sw: float = 1.9):
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        self.arrow(mx, my, x1, y1, color=color, sw=sw)
        self.arrow(mx, my, x2, y2, color=color, sw=sw)

    def circle(self, cx: float, cy: float, r: float,
               fill: str = 'white', stroke: str = INK, sw: float = 1.6, dash: str = ''):
        da = f' stroke-dasharray="{dash}"' if dash else ''
        self.items.append(
            f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{da}/>'
        )

    def go_grid(self, x0: float, y0: float, rows: int, cols: int, cell: float,
                black: list[tuple[int, int]], white: list[tuple[int, int]],
                highlights: list[tuple[int, int, str, str]] | None = None,
                shades: list[tuple[int, int, str]] | None = None,
                top_edge: bool = True, left_edge: bool = True,
                dual_coords: bool = False):
        """Draw a top-left Go board corner with 0-indexed (row, col) and optional A19 coordinates."""
        pad = 21
        bw = (cols - 1) * cell + 2 * pad
        bh = (rows - 1) * cell + 2 * pad
        self.rect(x0 - pad, y0 - pad, bw, bh, fill=WASH, stroke=HAIR, sw=1.0, rx=5)

        if shades:
            for r, c, col in shades:
                cx, cy = x0 + c * cell, y0 + r * cell
                self.rect(cx - cell * 0.44, cy - cell * 0.44, cell * 0.88, cell * 0.88,
                          fill=col, stroke='none', sw=0, rx=4)

        ext_r = 10 if cols < 19 else 0
        ext_b = 10 if rows < 19 else 0
        for r in range(rows):
            y = y0 + r * cell
            sw = 2.2 if (r == 0 and top_edge) else 1.05
            col = INK if (r == 0 and top_edge) else SLATE
            self.seg(x0, y, x0 + (cols - 1) * cell + ext_r, y, color=col, sw=sw)
        for c in range(cols):
            x = x0 + c * cell
            sw = 2.2 if (c == 0 and left_edge) else 1.05
            col = INK if (c == 0 and left_edge) else SLATE
            self.seg(x, y0, x, y0 + (rows - 1) * cell + ext_b, color=col, sw=sw)

        for c in range(cols):
            lbl = f'{c}/{GO_COLS[c]}' if dual_coords else str(c)
            self.text(x0 + c * cell, y0 - pad - 5, lbl, size=17, color=SLATE, anchor='middle')
        for r in range(rows):
            self.text(x0 - pad - 6, y0 + r * cell + 6, str(r), size=17, color=SLATE, anchor='end')

        sr = cell * 0.41
        for r, c in black:
            self.circle(x0 + c * cell, y0 + r * cell, sr, fill=INK, stroke=INK, sw=1.2)
        for r, c in white:
            self.circle(x0 + c * cell, y0 + r * cell, sr, fill='white', stroke=INK, sw=1.9)

        if highlights:
            for r, c, kind, col in highlights:
                cx, cy = x0 + c * cell, y0 + r * cell
                if kind == 'ring':
                    self.circle(cx, cy, sr * 0.92, fill='white', stroke=col, sw=2.4, dash='4,3')
                    self.circle(cx, cy, 3.6, fill=col, stroke='none', sw=0)
                elif kind == 'dot':
                    self.circle(cx, cy, 5.2, fill=col, stroke='white', sw=1.2)
                elif kind == 'square':
                    d = sr * 0.62
                    self.rect(cx - d, cy - d, 2 * d, 2 * d, fill='none', stroke=col, sw=2.2, rx=2)

    def save(self, stem: str) -> Path:
        self.items.append('</svg>')
        suffix = '-en' if self.lang == 'en' else ''
        svg_path = HERE / f'{stem}{suffix}.svg'
        svg_path.write_text('\n'.join(self.items) + '\n', encoding='utf-8')
        return svg_path


def render_pdf(svg: Path, temp_dir: Path) -> None:
    pdf = svg.with_suffix('.pdf')
    head = svg.read_text(encoding='utf-8')[:1500]
    m = re.search(r'viewBox="0 0 (\d+) (\d+)"', head)
    assert m, f'missing viewBox in {svg}'
    w, h = m.group(1), m.group(2)
    html = temp_dir / f'{svg.stem}.html'
    html.write_text(
        '<!doctype html><html><head><style>'
        f'@page{{size:{w}px {h}px;margin:0}}html,body{{margin:0;padding:0}}'
        f'img{{display:block;width:{w}px;height:{h}px}}</style></head>'
        f'<body><img src="{svg.as_uri()}"></body></html>',
        encoding='utf-8',
    )
    subprocess.run(
        [
            CHROME, '--headless=new', '--disable-gpu', '--no-pdf-header-footer',
            '--allow-file-access-from-files', f'--print-to-pdf={pdf}', html.as_uri(),
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def build_fig1(lang: str) -> Path:
    p = Plate(
        525,
        lang,
        (
            '可达同盘异史超劫分岔与开局虚着集合商双模拟',
            'Reachable same-board PSK bifurcation and opening-pass quotient bisimulation',
        ),
    )
    # Panel (a): Reachable 5-ply gamma_1 vs 7-ply gamma_2 corner ko witness
    p.text(24, 30,
           ('(a) 两条合法可达路径到达同一可见盘面的超劫分岔',
            '(a) Two reachable paths to one board, different PSK'),
           size=19, weight=700, max_width=462)
    p.seg(24, 42, 476, 42, color=HAIR, sw=1.2)

    p.go_grid(
        68, 96, rows=4, cols=4, cell=48,
        black=[(0, 1), (1, 0), (2, 0)],
        white=[(0, 2), (1, 1)],
        highlights=[(0, 0, 'ring', VERMILION)],
        dual_coords=True,
    )
    p.text(276, 98, ('回提测试点 A19', 'Ko point A19'), size=17, color=VERMILION, weight=700, max_width=195)
    p.text(276, 124, 'W(0, 0)', size=18, color=VERMILION, weight=700, max_width=195)
    p.arrow(272, 104, 92, 96, color=VERMILION, sw=1.8)

    p.rect(272, 148, 204, 118, fill='white', stroke=HAIR, sw=1.2, rx=5)
    p.text(284, 174, ('两路径共同可见状态', 'Shared visible position'), size=17, color=SLATE, weight=700, max_width=184)
    p.text(284, 202, ('轮白行棋, p{sub:pass} = 0', 'White to move, p{sub:pass} = 0'), size=17, color=INK, max_width=184)
    p.text(284, 230, ('(0,0) = A19, 行 19−r', '(0,0) = A19, row 19−r'), size=17, color=SLATE, max_width=184)
    p.text(284, 254, ('B(0,1) 仅剩 (0,0) 一气', 'B(0,1) in atari at (0,0)'), size=17, color=INK, max_width=184)

    # Two comparison cards under board
    p.card(24, 294, 220, 210, fill='white', stroke=DEEP, accent=DEEP)
    p.text(36, 322, ('5 手可达路径 γ{sub:1}', '5-ply path γ{sub:1}'), size=18, color=DEEP, weight=700, max_width=198)
    p.text(36, 350, 'B(1,0) W(0,2) B(2,0)', size=17, color=SLATE, max_width=198)
    p.text(36, 375, 'W(1,1) B(0,1)', size=17, color=SLATE, max_width=198)
    p.text(36, 408, ('W(0,0) → 合法提 B(0,1)', 'W(0,0) → Legal capture'), size=17, color=DEEP, weight=700, max_width=198)
    p.text(36, 438, ('pass   → 豁免合法', 'pass   → Exempt legal'), size=17, color=INK, max_width=198)
    p.text(36, 468, ('19×19 合法端口 = 357', '19×19 legal ports = 357'), size=17, color=SLATE, max_width=198)

    p.card(256, 294, 220, 210, fill='white', stroke=VERMILION, accent=VERMILION)
    p.text(268, 322, ('7 手可达路径 γ{sub:2}', '7-ply path γ{sub:2}'), size=18, color=VERMILION, weight=700, max_width=198)
    p.text(268, 350, 'B(1,0) W(0,0) B(2,0) W(0,2)', size=17, color=SLATE, max_width=204)
    p.text(268, 375, ('pass W(1,1) B(0,1)[提]', 'pass W(1,1) B(0,1)[cap]'), size=17, color=SLATE, max_width=204)
    p.text(268, 408, ('W(0,0) → {v:PSK 禁止}', 'W(0,0) → {v:PSK blocked}'), size=17, color=INK, weight=700, max_width=204)
    p.text(268, 438, ('pass   → 豁免合法', 'pass   → Exempt legal'), size=17, color=INK, max_width=198)
    p.text(268, 468, ('19×19 合法端口 = 356', '19×19 legal ports = 356'), size=17, color=SLATE, max_width=198)

    p.seg(492, 18, 492, 505, color=HAIR, sw=1.2)

    # Panel (b)
    p.text(510, 30,
           ('(b) 集合商 q{sub:PSK} 下的开局虚着双模拟（定理 3.4）',
            '(b) Opening-pass bisimulation under q{sub:PSK} (Thm 3.4)'),
           size=19, weight=700, max_width=470)
    p.seg(510, 42, 980, 42, color=HAIR, sw=1.2)

    p.rect(508, 66, 194, 86, fill=WASH, stroke=INK, sw=1.3, rx=6)
    p.text(602, 95, ('初局空盘 F{sub:0}(n)', 'Initial empty F{sub:0}(n)'), size=18, weight=700, anchor='middle', max_width=186)
    p.text(605, 121, 'p = 0, H = [(∅, B)]', size=17, color=SLATE, anchor='middle', max_width=186)
    p.text(605, 143, ('反设 W 强制 Δ ≤ −1', 'Suppose W forces Δ ≤ −1'), size=17, color=VERMILION, anchor='middle', max_width=186)

    p.arrow(704, 108, 770, 108, color=DEEP, sw=1.9)
    p.text(735, 96, 'B pass', size=17, color=DEEP, weight=700, anchor='middle', max_width=80)

    p.rect(772, 66, 208, 86, fill='white', stroke=DEEP, sw=1.4, rx=6)
    p.text(873, 95, ('虚着后 F{sub:1}', 'After pass F{sub:1}'), size=18, color=DEEP, weight=700, anchor='middle', max_width=198)
    p.text(876, 121, 'p = 1, [(∅,B), (∅,W)]', size=17, color=SLATE, anchor='middle', max_width=198)
    p.text(876, 143, ('W 若 pass 得 Δ=0 矛盾', 'W pass gives Δ=0 (⊥)'), size=17, color=INK, anchor='middle', max_width=198)

    p.arrow(873, 154, 873, 198, color=INK, sw=1.8)
    p.text(883, 183, 'W play(x)', size=17, color=INK, weight=700, max_width=110)

    p.rect(756, 200, 222, 78, fill='white', stroke=INK, sw=1.3, rx=6)
    p.text(867, 228, ('白实着帧 F{sub:2}', 'White placement F{sub:2}'), size=18, weight=700, anchor='middle', max_width=212)
    p.text(867, 256, 'p = 0, Forces(W, −1, F{sub:2})', size=17, color=SLATE, anchor='middle', max_width=212)

    p.arrow(867, 280, 867, 326, color=DEEP, sw=1.8)
    p.text(877, 309, ('swap + 反号', 'swap + sign'), size=17, color=DEEP, weight=700, max_width=115)

    p.rect(756, 328, 222, 84, fill='white', stroke=DEEP, sw=1.5, rx=6)
    p.text(867, 356, ('反演帧 swap(F{sub:2})', 'Reflected swap(F{sub:2})'), size=18, color=DEEP, weight=700, anchor='middle', max_width=214)
    p.text(867, 382, 'set(H) = {∅, B{sub:x}}', size=17, color=INK, anchor='middle', max_width=214)
    p.text(867, 404, 'Forces(B, +1, swap(F{sub:2}))', size=17, color=DEEP, weight=700, anchor='middle', max_width=214)

    p.arrow(598, 154, 598, 326, color=INK, sw=1.8)
    p.text(588, 246, ('真初局实着', 'Direct play'), size=17, color=SLATE, anchor='end', max_width=105)
    p.text(588, 270, 'B play(x)', size=17, color=INK, weight=700, anchor='end', max_width=105)

    p.rect(508, 328, 178, 84, fill='white', stroke=VERMILION, sw=1.8, rx=6)
    p.text(597, 356, ('真初局后继 T{sub:1}', 'Target frame T{sub:1}'), size=18, color=VERMILION, weight=700, anchor='middle', max_width=170)
    p.text(597, 382, 'set(H) = {∅, B{sub:x}}', size=17, color=INK, anchor='middle', max_width=170)
    p.text(597, 404, 'Forces(W, −1, T{sub:1})', size=17, color=VERMILION, weight=700, anchor='middle', max_width=170)

    # Bidirectional quotient equivalence bar
    p.bi_arrow(688, 370, 754, 370, color=DEEP, sw=1.9)
    p.text(721, 354, ('同商 ≡', '≡ q{sub:PSK}'), size=17, color=DEEP, weight=700, anchor='middle', max_width=64)

    p.card(510, 430, 468, 74, fill=WASH, stroke=VERMILION, accent=VERMILION)
    p.text(526, 459,
           ('同一帧 T{sub:1} 上 +1 ≤ Δ ≤ −1 矛盾 ⇒ ¬Forces(W, −1, F{sub:0})',
            'Collision +1 ≤ Δ ≤ −1 at T{sub:1} ⇒ ¬Forces(W, −1, F{sub:0})'),
           size=17, weight=700, max_width=442)
    p.text(526, 488,
           ('有限超劫二分 ⇒ ∀ n ∈ ℕ, 贴目 0 下黑方先手不败 (Δ ≥ 0)',
            'PSK dichotomy ⇒ Black can force Δ ≥ 0 at komi 0'),
           size=17, color=DEEP, weight=700, max_width=444)

    return p.save('fig1-psk-stealing')


def build_fig2(lang: str) -> Path:
    p = Plate(
        540,
        lang,
        (
            '多群协作护眼、驻敌混合要害室与 11 手角部基准局面',
            'Multi-group eye coalitions, invaded vital chambers, and 11-ply benchmark',
        ),
    )
    p.text(24, 30,
           ('(a) 两类无条件活棋闭包与保底面积律（定理 4.2–4.3）',
            '(a) Pass-alive closures & area law (Thms 4.2–4.3)'),
           size=19, weight=700, max_width=524)
    p.seg(24, 42, 536, 42, color=HAIR, sw=1.2)

    # Sub-board 1: EyeCoalition
    p.text(136, 68, ('多群协作护眼 EyeCoalition', 'EyeCoalition (2 chains)'), size=18, color=DEEP, weight=700, anchor='middle', max_width=235)
    ec_black = [(0, 0), (0, 2), (1, 2), (1, 1), (2, 1), (2, 0)]
    p.go_grid(
        68, 122, rows=4, cols=4, cell=44,
        black=ec_black, white=[],
        shades=[(0, 1, '#e3eef8'), (1, 0, '#e3eef8')],
        highlights=[(0, 1, 'dot', DEEP), (1, 0, 'dot', DEEP)],
    )
    p.card(24, 304, 246, 214, fill='white', stroke=DEEP, accent=DEEP)
    p.text(38, 332, ('C{sub:1}={(0,0)} 与 C{sub:2} 分离', 'Disjoint chains C{sub:1}, C{sub:2}'), size=17, max_width=224)
    p.text(38, 360, ('共用两眼 (0,1), (1,0)', 'Shared eyes (0,1), (1,0)'), size=17, color=DEEP, weight=700, max_width=224)
    p.text(38, 390, ('各享 ≥ 2 气，对手禁入眼', 'Each has ≥ 2 liberties'), size=17, max_width=224)
    p.text(38, 422, ('保底集 P = C ∪ E (|P|=8)', 'Secured P = C ∪ E (|P|=8)'), size=17, weight=700, max_width=224)
    p.text(38, 452, ('Δ ≥ 2·8 − 361 = −345', 'Δ ≥ 2·8 − 361 = −345'), size=17, color=DEEP, weight=700, max_width=224)
    p.text(38, 484, ('恒虚着至终局保住 8 点', 'Pass-only secures 8 pts'), size=17, color=SLATE, max_width=224)

    # Sub-board 2: Exact 7-stone VitalChambers from Example 1.1(b)!
    p.text(404, 68, ('驻敌要害室 VitalChambers', 'VitalChambers (Ex. 1.1b)'), size=18, color=VERMILION, weight=700, anchor='middle', max_width=245)
    vc_black_7 = [(0, 2), (1, 0), (1, 1), (1, 2), (2, 1), (3, 0), (3, 1)]
    p.go_grid(
        336, 122, rows=5, cols=4, cell=36,
        black=vc_black_7, white=[(0, 0)],
        shades=[(0, 0, '#fbeaec'), (0, 1, '#fbeaec'), (2, 0, '#e3eef8')],
        highlights=[(0, 1, 'ring', VERMILION), (2, 0, 'dot', DEEP)],
    )
    p.card(280, 304, 258, 214, fill='white', stroke=VERMILION, accent=VERMILION)
    p.text(294, 332, ('7 子黑核围 K{sub:1}={(2,0)}', '7-stone core, eye K{sub:1}={(2,0)}'), size=17, max_width=236)
    p.text(294, 360, ('二格室 K{sub:2}={(0,0),(0,1)} 驻白', 'Room K{sub:2}={(0,0),(0,1)} has W'), size=17, max_width=236)
    p.text(294, 390, ('白填末空 (0,1) → 零气自杀', 'W at (0,1) → 0-lib suicide'), size=17, color=VERMILION, weight=700, max_width=236)
    p.text(294, 422, ('虚着终局 (0,1) 成双色公气', 'At twoPasses, (0,1) is neutral'), size=17, max_width=236)
    p.text(294, 452, ('仅计 P = C ∪ K{sub:1} (|P|=8)', 'Only P = C ∪ K{sub:1} (|P|=8)'), size=17, weight=700, max_width=236)
    p.text(294, 484, ('Δ ≥ −345 (免提保底 8 点)', 'Δ ≥ −345 (8 pts without cap)'), size=17, color=DEEP, weight=700, max_width=236)

    p.seg(552, 18, 552, 520, color=HAIR, sw=1.2)

    # Panel (b): 11-ply benchmark H11 + 5 HookSource shapes
    p.text(570, 30,
           ('(b) 11 手角部基准局面 H{sub:11} 与五种钩形要害室',
            '(b) Benchmark H{sub:11} & 5 HookSource shapes'),
           size=19, weight=700, max_width=418)
    p.seg(570, 42, 980, 42, color=HAIR, sw=1.2)

    h11_black = [(1, 0), (1, 1), (1, 2), (1, 3), (2, 1), (2, 3)]
    p.go_grid(
        618, 102, rows=5, cols=5, cell=36,
        black=h11_black, white=[(0, 1)],
        highlights=[
            (0, 2, 'ring', VERMILION),
            (3, 1, 'ring', VERMILION),
            (3, 2, 'ring', VERMILION),
            (0, 0, 'square', GOLD),
            (0, 3, 'square', GOLD),
            (2, 0, 'square', GOLD),
            (2, 2, 'square', GOLD),
            (3, 0, 'square', GOLD),
        ],
    )
    p.rect(804, 86, 176, 172, fill=WASH, stroke=HAIR, sw=1.1, rx=5)
    p.text(816, 112, ('351 白应手三分流', '351 White replies'), size=17, weight=700, max_width=156)
    p.circle(824, 140, 7, fill='white', stroke=VERMILION, sw=2.2, dash='3,2')
    p.text(838, 146, ('3 深层分支', '3 deep branches'), size=17, color=VERMILION, weight=700, max_width=136)
    p.rect(817, 166, 14, 14, fill='none', stroke=GOLD, sw=2.2, rx=2)
    p.text(838, 179, ('5 左桥近端分支', '5 bridge branches'), size=17, color=INK, max_width=136)
    p.text(816, 212, ('其余 343 外围应手', 'Other 343 replies:'), size=17, color=SLATE, max_width=156)
    p.text(816, 238, ('由钩形源一次闭合', 'by HookSource'), size=17, color=DEEP, weight=700, max_width=156)

    # Detailed 5 HookSource shapes + sibling closures
    p.card(570, 274, 410, 114, fill='white', stroke=DEEP, accent=DEEP)
    p.text(584, 300, ('白应手后，B(3,1) 接成七子钩形源', 'After White, B(3,1) forms the seven-stone source'),
           size=17, color=DEEP, weight=700, max_width=386)
    p.text(584, 326, ('左脚 B(3,0) 围眼 (2,0)，可成三形', 'Left foot B(3,0): eye (2,0), three shapes'),
           size=17, max_width=388)
    p.text(584, 352, ('右脚 B(3,2) 围眼 (2,2)，可成两形', 'Right foot B(3,2): eye (2,2), two shapes'),
           size=17, max_width=388)
    p.text(584, 376, ('见合封口后保住 10 点，Δ ≥ −341', 'Miai caps secure 10 points and Δ ≥ −341'),
           size=17, color=SLATE, max_width=388)

    p.card(570, 398, 410, 56, fill='white', stroke=GOLD, accent=GOLD)
    p.text(584, 422, ('左侧双桥（5 端口）：B(0,2) → 顶走廊或 (3,1)/(3,3)', 'Left bridge (5 ports): B(0,2) → top or (3,1)/(3,3)'), size=17, color=INK, weight=700, max_width=388)
    p.text(584, 444, ('W00 提二白子验 351 端口；余四源各验 348 端口', 'W00 captures 2 stones (351 ports); 4 siblings (348)'), size=17, color=SLATE, max_width=388)

    p.card(570, 464, 410, 56, fill='white', stroke=VERMILION, accent=VERMILION)
    p.text(584, 488, ('三深层分支：W02 / W32 边线走廊 + W31 区域 DAG', 'Deep trio: W02 / W32 corridors + W31 DAG'), size=17, color=VERMILION, weight=700, max_width=388)
    p.text(584, 510, ('348 个批量通过；这 3 个分别独立通过', '348 in one batch; these 3 passed separately'),
           size=17, color=INK, max_width=388)

    return p.save('fig2-vital-chambers')


def build_fig3(lang: str) -> Path:
    p = Plate(
        525,
        lang,
        (
            'W31 实盘、跨界外气与容量界',
            'The W31 position, exterior liberties and the capacity bound',
        ),
    )
    p.text(24, 30,
           ('(a) W31 实盘与跨界外气示意',
            '(a) W31 position and a schematic exterior chain'),
           size=19, weight=700, max_width=462)
    p.seg(24, 42, 474, 42, color=HAIR, sw=1.2)

    # Full 19x19 board (15px step => 18*15 = 270px)
    bx, by, step = 48, 72, 15
    bsize = 18 * step
    p.rect(bx - 12, by - 12, bsize + 24, bsize + 24, fill=WASH, stroke=INK, sw=1.7, rx=4)

    # 7x7 region R (0..6 => 6*15 = 90px + 8px margin)
    r_span = 6 * step + 7
    p.rect(bx - 4, by - 4, r_span, r_span, fill='#e9f1f8', stroke=DEEP, sw=2.2, rx=3)
    # 6x6 SupportInterior (0..5 => 5*15 = 75px)
    si_span = 5 * step + 3
    p.rect(bx - 2, by - 2, si_span, si_span, fill='white', stroke=DEEP, sw=1.3, rx=2, dash='4,3')

    for i in range(19):
        p.seg(bx, by + i * step, bx + bsize, by + i * step, color='#cfd6dd', sw=0.6)
        p.seg(bx + i * step, by, bx + i * step, by + bsize, color='#cfd6dd', sw=0.6)

    # Axis corner markers (0/A, 6/G, 18/T and 0/19, 6/13, 18/1)
    p.text(bx, by - 16, '0/A', size=17, color=SLATE, anchor='middle')
    p.text(bx + 6 * step, by - 16, '6/G', size=17, color=DEEP, weight=700, anchor='middle')
    p.text(bx + 18 * step, by - 16, '18/T', size=17, color=SLATE, anchor='middle')
    p.text(bx - 16, by + 5, '0', size=17, color=SLATE, anchor='end')
    p.text(bx - 16, by + 6 * step + 5, '6', size=17, color=DEEP, weight=700, anchor='end')
    p.text(bx - 16, by + 18 * step + 5, '18', size=17, color=SLATE, anchor='end')

    # The ring marks the checked next move on an empty point.
    for r, c in [(1, 0), (1, 1), (1, 2), (1, 3), (2, 1), (2, 3)]:
        p.circle(bx + c * step, by + r * step, 5.4, fill=INK, stroke=INK, sw=1.0)
    p.circle(bx + 4 * step, by + 2 * step, 5.8, fill='white', stroke=DEEP, sw=1.8)

    # White W(0,1), W(3,1) + 4 row-18 tenukis (18,12..18)
    for r, c in [(0, 1), (3, 1), (18, 12), (18, 14), (18, 16), (18, 18)]:
        p.circle(bx + c * step, by + r * step, 5.4, fill='white', stroke=INK, sw=1.5)

    p.circle(345, 83, 5.8, fill='white', stroke=DEEP, sw=1.8)
    p.text(357, 89, ('首应 E17', 'Next B: E17'), size=17, color=DEEP, weight=700, max_width=110)
    p.text(338, 119, ('区域 R：7×7', 'Region R: 7×7'), size=17, color=DEEP, max_width=140)
    p.text(338, 145, ('外部：312 点', 'Exterior: 312 pts'), size=17, color=SLATE, max_width=140)
    p.text(48, 371, ('底行白子 N1、P1、R1、T1', 'Bottom row: W at N1, P1, R1, T1'),
           size=17, color=SLATE, max_width=276)

    # A separate hypothetical local diagram: the example stones are not W31 stones.
    p.card(336, 164, 139, 193, fill='white', stroke=HAIR, accent=VERMILION)
    p.text(347, 187, ('跨界白链示意', 'Chain sketch'), size=17, color=VERMILION, weight=700, max_width=120)
    p.rect(350, 202, 46, 46, fill='#e9f1f8')
    for i in range(4):
        y = 214 + i * 23
        p.seg(354, y, 394, y, color=HAIR, sw=0.9)
    for x in (355, 372, 391):
        p.seg(x, 214, x, 283, color=HAIR, sw=0.9)
    p.seg(350, 248, 400, 248, color=DEEP, sw=1.4, dash='3,2')
    p.seg(372, 214, 372, 260, color=VERMILION, sw=2.0)
    for y in (214, 237, 260):
        p.circle(372, y, 6.4, fill='white', stroke=VERMILION, sw=1.6)
    p.circle(372, 283, 5.7, fill='white', stroke=VERMILION, sw=1.4, dash='2,2')
    p.text(407, 233, 'R', size=17, color=DEEP, weight=700)
    p.text(407, 270, ('外部', 'Outside'), size=17, color=SLATE, max_width=59)
    p.text(347, 316, ('虚线圆为外气', 'Dotted ring:'), size=17, color=SLATE, max_width=120)
    if lang == 'en':
        p.text(347, 340, 'exterior liberty', size=17, color=SLATE, max_width=120)

    p.card(24, 388, 450, 116, fill='white', stroke=DEEP, accent=DEEP)
    p.text(38, 404,
           ('黑子内缩时，无外气的跨界白块必填满连通外部',
            'No exterior liberty implies a full exterior.'),
           size=17, weight=700, max_width=428)
    p.text(38, 434,
           ('黑子内缩且 |occ(B)| < 312 时，内缩黑着的提子集相同',
            'With interior Black support and |occ(B)| < 312,'),
           size=17, color=DEEP, weight=700, max_width=428)
    p.text(38, 464,
           ('限制盘面在同一张 19×19 棋盘上把 R 外置空',
            'Black interior captures agree on the padded board.'),
           size=17, color=SLATE, max_width=428)
    p.text(38, 492,
           ('反链 A{sub:B}(H) 保留历史黑足迹的包含查询',
            'Antichain A{sub:B}(H) preserves Black footprint queries.'),
           size=17, color=INK, max_width=428)

    p.seg(488, 18, 488, 506, color=HAIR, sw=1.2)

    # Panel (b): Rank-occupancy conservation across 4 edge types
    p.text(504, 30,
           ('(b) 节点秩严格下降，容量界保持（定理 5.6）',
            '(b) Rank decreases and capacity persists (Thm 5.6)'),
           size=19, weight=700, max_width=476)
    p.seg(504, 42, 980, 42, color=HAIR, sw=1.2)

    p.rect(510, 58, 464, 76, fill=WASH, stroke=DEEP, sw=1.6, rx=6)
    p.text(742, 86,
           ('父快照 s：rank(s) = 2r + 1{sub:τ=W}，黑足迹反链 H',
            'Snapshot s: rank(s) = 2r + 1{sub:τ=W}, antichain H'),
           size=18, color=DEEP, weight=700, anchor='middle', max_width=436)
    p.text(742, 116,
           ('源适用不等式：|occ(F.B)| + rank(s) < 312',
            'Source invariant: |occ(F.B)| + rank(s) < 312'),
           size=17, color=VERMILION, weight=700, anchor='middle', max_width=436)

    rows = [
        (
            152, DEEP,
            ('黑内缩实着 .own(x)', 'Black interior .own(x)'),
            ('r ↦ r−1, Δrank = −1；更新极大反链 H', 'r ↦ r−1, Δrank = −1; update antichain H'),
        ),
        (
            220, INK,
            ('白区域内实着 .play(x∈R)', 'White interior .play(x∈R)'),
            ('r 不变, Δrank = −1；反链 H 原样保持', 'r kept, Δrank = −1; H unchanged'),
        ),
        (
            288, VERMILION,
            ('白区域外着法 .environment', 'White exterior .environment'),
            ('r 不变, Δrank = −1；B|{sub:R} 不变, p{sub:F} ↦ 0', 'r kept, Δrank = −1; B|{sub:R} kept, p{sub:F} ↦ 0'),
        ),
        (
            356, GOLD,
            ('白虚着 .pass', 'White .pass'),
            ('r 不变, Δrank = −1；B|{sub:R} 不变, p{sub:F}: 0 ↦ 1', 'r kept, Δrank = −1; B|{sub:R} kept, p{sub:F}: 0 ↦ 1'),
        ),
    ]
    for ry, col, left_lbl, right_lbl in rows:
        p.card(510, ry, 464, 56, fill='white', stroke=HAIR, accent=col)
        p.text(524, ry + 24, left_lbl, size=17, color=col if col != GOLD else INK, weight=700, max_width=436)
        p.text(524, ry + 46, right_lbl, size=17, color=SLATE, max_width=436)

    p.rect(510, 428, 464, 76, fill='#e9f1f8', stroke=DEEP, sw=1.6, rx=6)
    p.text(742, 456,
           ("|occ(B')| + rank(s') ≤ (|occ|+1) + (rank−1) < 312",
            "|occ(B')| + rank(s') ≤ (|occ|+1) + (rank−1) < 312"),
           size=17, color=DEEP, weight=700, anchor='middle', max_width=448)
    p.text(742, 486,
           ('检查器接入真实着法与几何叶，得到分差下界 −345',
            'The checker links native moves to leaves for Δ ≥ −345'),
           size=17, color=INK, anchor='middle', max_width=448)

    return p.save('fig3-regional-dag')


def build_fig4(lang: str) -> Path:
    p = Plate(
        520,
        lang,
        (
            '170 万节点 W31 证书定量解剖与三层可信基架构',
            'W31 1.70M-node certificate anatomy and three-tier TCB architecture',
        ),
    )
    p.text(24, 30,
           ('(a) 12 手基准 W31 策略图核验解剖（1,700,986 节点）',
            '(a) Verified W31 DAG anatomy (1,700,986 nodes)'),
           size=19, weight=700, max_width=492)
    p.seg(24, 42, 514, 42, color=HAIR, sw=1.2)

    bx, by, bh = 28, 60, 32
    node_counts = (862_073, 33_164, 743_233, 62_516)
    for count, colour in zip(node_counts, (DEEP, GOLD, '#4a7c9b', VERMILION)):
        width = 480 * count / sum(node_counts)
        p.rect(bx, by, width, bh, fill=colour, stroke='white', sw=1.0, rx=1)
        bx += width

    bars = [
        (
            108, DEEP,
            ('黑方选择节点 .own：862,073（50.68%）', 'Black choice .own: 862,073 (50.68%)'),
            ('各含 1 条经复核实着边 → 862,073 条有向边', '1 checked move edge each → 862,073 edges'),
        ),
        (
            178, GOLD,
            ('白方全端口节点 .white：33,164（1.95%）', 'White universal .white: 33,164 (1.95%)'),
            ('覆盖局部非自杀 + 外着 + 虚着 → 1,145,389 条边', 'Local + env + pass ports → 1,145,389 edges'),
        ),
        (
            248, '#4a7c9b',
            ('多群协作护眼叶 .coalition：743,233（43.69%）', 'EyeCoalition leaves: 743,233 (43.69%)'),
            ('28 份编译几何，743,205 次缓存命中', '28 compiled geometries; 743,205 cache hits'),
        ),
        (
            318, VERMILION,
            ('驻敌混合要害室叶 .vital：62,516（3.68%）', 'VitalChambers leaves: 62,516 (3.68%)'),
            ('85 份编译几何，62,431 次缓存命中', '85 compiled geometries; 62,431 cache hits'),
        ),
    ]
    for ry, col, t1, t2 in bars:
        p.card(28, ry, 484, 58, fill='white', stroke=HAIR, accent=col)
        p.text(42, ry + 25, t1, size=17, color=INK if col == GOLD else col, weight=700, max_width=460)
        p.text(42, ry + 48, t2, size=17, color=SLATE, max_width=460)

    p.card(28, 392, 484, 108, fill=WASH, stroke=DEEP, accent=DEEP)
    p.text(42, 420,
           ('合计：1,700,986 节点 / 2,007,462 边 / 249 反链形状',
            'Total: 1,700,986 nodes / 2,007,462 edges / 249 antichains'),
           size=17, color=DEEP, weight=700, max_width=460)
    p.text(42, 450,
           ('已验证检查器执行 (--trust=0)：3,140.66 s, 7.07 GB RSS',
            'Verified checker run (--trust=0): 3,140.66 s, 7.07 GB RSS'),
           size=17, color=INK, max_width=460)
    p.text(42, 480,
           ('输出：全盘分差证书 Δ ≥ −345，首应 B(2,4)',
            'Output: full-board margin Δ ≥ −345, move B(2,4)'),
           size=17, color=VERMILION, weight=700, max_width=460)

    p.seg(530, 18, 530, 502, color=HAIR, sw=1.2)

    # Panel (b): Three-tier TCB & Prop/Type separation
    p.text(548, 30,
           ('(b) 图的生成、执行与证明验证',
            '(b) Search, execution and proof verification'),
           size=19, weight=700, max_width=435)
    p.seg(548, 42, 980, 42, color=HAIR, sw=1.2)

    # Tier 1: Outside TCB (Untrusted external solver)
    p.card(548, 60, 432, 114, fill='white', stroke=SLATE, accent=SLATE)
    p.text(564, 88,
           ('可信基之外：外部 C++ 搜索器与候选 JSON 图',
            'Outside TCB: External C++ solver & raw JSON'),
           size=18, color=INK, weight=700, max_width=404)
    p.text(564, 118,
           ('7×7 关系搜索（5.56M 记忆项）导出无标签图结构',
            '7×7 relational search (5.56M memos) exports raw DAG'),
           size=17, color=SLATE, max_width=404)
    p.text(564, 146,
           ('检查器根据着法、边与几何叶判定接收',
            'Checker verifies moves, edges and leaves'),
           size=17, color=VERMILION, weight=700, max_width=404)

    p.arrow(764, 176, 764, 204, color=DEEP, sw=1.8)

    # Tier 2: Execution of the verified checker
    p.card(548, 206, 432, 132, fill='white', stroke=DEEP, accent=DEEP)
    p.text(564, 234,
           ('运行复核层：已验证检查器与 Lean 运行时',
            'Execution TCB: Verified checker + Lean runtime'),
           size=18, color=DEEP, weight=700, max_width=404)
    p.text(564, 264,
           ('进程内复核 W31 / W02 / W32 及 73 节点、13 手控制',
            'Runs W31 / W02 / W32 + 73-node & 13-ply controls'),
           size=17, color=INK, max_width=404)
    p.text(564, 294,
           ('状态机仅接收携带可执行策略 π{sub:B}, π{sub:W} 的上下界',
            'State machine [ℓ, u] accepts concrete policies'),
           size=17, color=SLATE, max_width=404)
    p.text(564, 322,
           ('理论区间 0 ≤ v ≤ 361 独立保存',
            'The mathematical range 0 ≤ v ≤ 361 is read-only'),
           size=17, color=DEEP, weight=700, max_width=404)

    p.arrow(764, 368, 764, 340, color=DEEP, sw=1.8)

    # Tier 3: Lean 4 kernel proof TCB
    p.card(548, 370, 432, 130, fill=WASH, stroke=DEEP, accent=VERMILION)
    p.text(564, 398,
           ('定理证明层：Lean 4 内核（标准三公理，0 sorry）',
            'Lean 4 kernel and three standard axioms'),
           size=18, color=INK, weight=700, max_width=404)
    p.text(564, 428,
           ('内核直接检验：∀n 先手不败、护眼与驻敌要害室、',
            'Kernel-checks: ∀n non-loss, EyeCoalition,'),
           size=17, color=INK, max_width=404)
    p.text(564, 456,
           ('VitalChambers、Certificate 与 compileDAG 健全性',
            'VitalChambers, Certificate & compileDAG soundness'),
           size=17, color=INK, max_width=404)
    p.text(564, 484,
           ('Audit.lean 复核全部 89 个导出声明的公理足迹',
            'Audit.lean checks #print axioms on 89 exports'),
           size=17, color=SLATE, max_width=404)

    return p.save('fig4-w31-certificate')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-pdf', action='store_true')
    args = parser.parse_args()

    svgs: list[Path] = []
    for lang in ('zh', 'en'):
        svgs.append(build_fig1(lang))
        svgs.append(build_fig2(lang))
        svgs.append(build_fig3(lang))
        svgs.append(build_fig4(lang))

    if not args.no_pdf:
        temp = HERE / '.pdf-tmp'
        temp.mkdir(exist_ok=True)
        try:
            os.environ['TMPDIR'] = str(temp)
            for svg in svgs:
                render_pdf(svg, temp)
        finally:
            shutil.rmtree(temp, ignore_errors=True)

    print(f'Generated {len(svgs)} SVG plates' + ('' if args.no_pdf else ' + sibling vector PDFs'))


if __name__ == '__main__':
    main()
