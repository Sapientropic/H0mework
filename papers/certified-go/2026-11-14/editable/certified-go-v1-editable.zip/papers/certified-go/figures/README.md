# `certified-go` 双语矢量图板清单

全部图板由 [make_figures.py](make_figures.py) 从 `GO1–GO8` 的精确盘面坐标、反链掩模与核验回执生成（宽度 `1000px`，最小字号 `17px`，英文版零全角标点与 CJK 字符），配套同名矢量 `.pdf` 供阅读版 PDF 编译直接嵌入：

1. `fig1-psk-stealing.svg` / `-en.svg`（图 1）：5 手与 7 手合法可达路径在同一可见盘面上的超劫分岔（`γ₁` vs `γ₂`），以及集合商 $q_{\mathrm{PSK}}$ 下的开局虚着双模拟（定理 3.4）。
2. `fig2-vital-chambers.svg` / `-en.svg`（图 2）：多群协作护眼与驻敌混合要害室（与例 1.1(b) 完全同形的 7 子黑核构型）对比，以及 11 手角部基准局面 $H_{11}$ 与五种 9 子钩形要害室几何（定理 4.2–4.3、命题 6.2）。
3. `fig3-regional-dag.svg` / `-en.svg`（图 3）：`W31` 的完整 $19\times 19$ 全盘基准局面（含标准坐标、底行四白子、以空圈标出下一黑着 `B(2,4)`；跨界白链与外气单独置于示意小图）及逐边严格降秩与容量界保持（命题 5.2、定理 5.6）。
4. `fig4-w31-certificate.svg` / `-en.svg`（图 4）：12 手基准局面 `W31` 的 $1{,}700{,}986$ 节点策略图核验解剖，以及搜索、运行和内核证明的分工（核验计算 6.3、定理 7.1）。

重建命令（在 `publish/` 根目录）：

```sh
~/.venvs/figtools/bin/python papers/certified-go/figures/make_figures.py
```
