# 全局超劫围棋的首手非负性定理与证明携带式区域 DAG 策略证书

*First-Player Non-Negativity and Proof-Carrying Regional DAG Strategy Certificates for Positional-Superko Go*

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

## 摘要

在全局局面超劫（PSK）下，同一可见围棋盘面可因过往盘面不同而拥有不同的合法着法。本文在 Lean 4 中证明，可见状态与曾见盘面的集合构成强双模拟，并形式化 Weninger 与 Hayward 的开局虚着论证：在禁自杀、虚着豁免超劫、双虚着面积计分的规则下，任意方形棋盘的黑方均可在贴目为零时确保分差非负。对区域策略，历史黑子足迹的极大元给出全盘新鲜性的充分判据，连通外部的容量界使经验证的检查器能把角部有向无环图（DAG）提升为全盘策略。终叶允许对手在要害室内驻子，仍保护全部核心棋子，并计入单点眼的面积。在一个 12 手 $19\times19$ 局面上，检查器验证了含 $1{,}700{,}986$ 个节点与 $2{,}007{,}462$ 条边的策略图，生成保底分差 $-345$ 的证书。该图的活棋叶保证角部至少八点。程序在一次运行中总装 11 手局面的全部 351 个合法非认输白应手，再经实下黑着 (2,1) 将证书回接至 10 手前驱。

**关键词**：围棋；全局局面超劫；首手非负性；Benson 无条件活棋；图历史交互；策略证书；Lean 4

## Abstract

Under positional superko (PSK), two occurrences of the same Go board can admit different moves. In Lean 4 we show that the visible position together with the set of all past boards forms a strong bisimulation. This quotient mechanizes Weninger and Hayward's opening-pass proof that Black can force a nonnegative margin on every square board under no-suicide, pass-exempt PSK and double-pass area scoring. For regional play, maximal historical Black footprints give a sufficient test of global freshness. A connected-exterior capacity bound lets a verified checker lift a corner directed acyclic graph (DAG) to a full-board strategy. The terminal geometry allows enemy stones inside vital chambers while preserving every core stone and counting singleton eyes as guaranteed area. On a 12-ply $19\times 19$ position, the checker validated a DAG with $1{,}700{,}986$ nodes and $2{,}007{,}462$ edges and generated a strategy certificate for margin at least $-345$. Its leaves certify at least eight Black area points in the corner. At the 11-ply position, a single execution assembles certificates for all 351 legal non-resigning White replies. It lifts the resulting certificate to the actual 10-ply predecessor through Black’s move at (2,1).

**Keywords**: Go; positional superko; first-player non-negativity; vital chambers; GHI; strategy certificates; Lean 4

---

<a id="sec-1"></a>

## 1 引言：超劫历史的两层压缩、主要定理与可信基边界

<a id="sec-1-1"></a>

### 1.1 为什么可见盘面不够，而超劫历史可以两层压缩

在 $19\times 19$ 棋盘左上角，考察两条均从空盘合法走出的简短对局（行、列均取零起始坐标 $(r,j)\in\{0,\dots,18\}^2$，对应标准棋谱列标 `ABCDEFGHJKLMNOPQRST[j]` 与行号 $19-r$，例如角点 $(0,0)=\mathtt{A19}$）：

- **5 手对局 $\gamma_1$**：$1.\,\mathtt{B}(1,0),\;2.\,\mathtt{W}(0,2),\;3.\,\mathtt{B}(2,0),\;4.\,\mathtt{W}(1,1),\;5.\,\mathtt{B}(0,1)$；
- **7 手对局 $\gamma_2$**：$1.\,\mathtt{B}(1,0),\;2.\,\mathtt{W}(0,0),\;3.\,\mathtt{B}(2,0),\;4.\,\mathtt{W}(0,2),\;5.\,\mathtt{B}\,\mathtt{pass},\;6.\,\mathtt{W}(1,1),\;7.\,\mathtt{B}(0,1)$（第 $7$ 手提去角点白子 $\mathtt{W}(0,0)$）。

两条路径走完后，棋盘上的可见状态完全重合：黑子位于 $\{(0,1),(1,0),(2,0)\}$，白子位于 $\{(0,2),(1,1)\}$，连续虚着计数 $p_{\mathrm{pass}}=0$，轮白方行棋，且黑子 $(0,1)$ 仅剩角点 $(0,0)$ 一口气。然而在全局局面超劫（PSK）规则下，两者的下一步合法着法集却不相同：在 $\gamma_1$ 后，白落 $\mathtt{W}(0,0)$ 合法提去 $\mathtt{B}(0,1)$，全盘共有 $357$ 个非认输合法动作；而在 $\gamma_2$ 后，$\mathtt{W}(0,0)$ 提子所得盘面恰好重现了 $\gamma_2$ 第 $6$ 手刚走过的盘面，因而被超劫禁止，全盘仅剩 $356$ 个非认输合法动作（见图 1(a) 与例 2.3；这是最基本的角部劫形，而全局 PSK 将同一历史禁令推广至任意步长的盘面循环）。

这一可达算例表明，全局超劫围棋不是纯可见盘面上的无记忆马尔可夫博弈。也正因如此，两条经典研究路线在全局 PSK 下都会遇到同一根源的障碍：

1. **开局虚着盗策略**。Weninger 与 Hayward [@WeningerHayward2017, 定理 1] 已用黑首手虚着及颜色反演证明矩形 PSK 围棋先手不败。Hex [@Nash1952; @Gale1979] 及 Beck [@Beck2008] 讨论的占格博弈可利用落子单调性。围棋允许提子，多一子还可能紧掉己方的气。显式历史表中的首个虚着会留下第二项空盘历史，并将虚着计数置一。本文的形式证明给出用于比较反射续行和黑方直接首着的精确商。
2. **局部死活图的全盘提升**。在有向无环图中合并相同局部盘面会引发图历史交互（GHI）[@Campbell1985; @KishimotoMuller2004; @KishimotoMuller2005]。外着还会改变全盘历史和跨界棋块的气。固定外墙的求解器 [@Muller2001] 与关联区域策略树 [@ShihEtAl2022RelevanceZones] 分别处理了其中的环节。本文的证书给出全局超劫下的全盘面积保证。

在全盘尺度，我们对合法转移取商。在区域尺度，我们保留黑子足迹包含查询的精确答案。
$$q_{\mathrm{PSK}}(F) := \bigl(V(F),\;\operatorname{set}(H(F))\bigr), \qquad \mathcal{A}_{\mathrm{B}}(H) := \max_{\subseteq}\bigl\{\,S_{\mathrm{B}}(B') \;:\; (B',\cdot)\in H\,\bigr\}.\tag{1.1}$$
在全盘尺度上，由于禁自杀 PSK 只检验目标盘面是否曾在历史中出现，忘记次序、重复重数与手番标签的集合商 $q_{\mathrm{PSK}}$ 精确保持全部合法后继与终局分差；黑方第 $1$ 手虚着留下的重复空盘在集合取像下自动坍缩为 $\{B_\emptyset\}$，而白方若想赢棋就必须在第 $2$ 手落下实着从而把 $p_{\mathrm{pass}}$ 清零，使颜色反演严格落回真初局首手实着的商等价类（图 1(b)）。区域检查器使用 $\mathcal{A}_{\mathrm{B}}(H)$ 表示历史全盘黑子足迹的下闭包。新足迹落在下闭包之外时，新全盘必未出现过。全盘占子数与节点秩之和的线性上界则在 $312$ 点连通外部为跨界白块保留真气。

<a id="sec-1-2"></a>

### 1.2 三项主要结果

记 $V_n := \{0,\dots,n-1\}^2$ 为 $n\times n$ 棋盘网格。对任意盘面 $B$，记 $S_c(B)\subseteq V_n$ 为颜色 $c\in\{\mathrm{B},\mathrm{W}\}$ 的棋子集合，$\operatorname{occ}(B):=S_{\mathrm{B}}(B)\cup S_{\mathrm{W}}(B)$ 为全部已占点集合，$\Delta(B):=\operatorname{Area}(B,\mathrm{B})-\operatorname{Area}(B,\mathrm{W})\in\mathbb{Z}$ 为黑减白的 Tromp–Taylor 净面积分差。本文证明以下三项主要结果（全部定义见第 2–5 节，Lean 4 源码映射见附录表 B.1）。

<a id="thm-a"></a>

**定理 A（任意尺寸棋盘上全局超劫围棋先手不败的形式证明；详定理 3.4 与推论 3.5）。**
在禁自杀、虚着豁免全局局面超劫且以连续两次虚着终局、不设死子清理的 Tromp–Taylor 面积计分规则下，对任意棋盘边长 $n\in\mathbb{N}$，空盘初局 $F_0(n)$ 具有首手非负性（即贴目为 $0$ 时黑方先手不败）：白方不存在任何策略可强迫终局净面积分差 $\Delta(B)\le -1$，且黑方存在策略证书对一切白方合法应对保证有限步终局并满足 $\Delta(B)\ge 0$。特别在 $19\times 19$ 棋盘上，任意满足双向紧致策略对的精确初始分差值 $v$ 满足 $0 \le v \le 361$。

<a id="thm-b"></a>

**定理 B（驻敌混合要害室无条件活棋律与类型化策略证书；详定理 4.2、4.3 与 4.6）。**
对任意棋盘边长 $n\in\mathbb{N}$ 与颜色 $c\in\{\mathrm{B},\mathrm{W}\}$：

1. **多群护眼与驻敌混合要害室**：设 $C\subseteq S_c(B)$ 为非空己方核心棋子集，$\mathcal{K}$ 为两两不交且与 $C$ 不交的非空封闭要害室族，使得 $C$ 在纯核心掩模盘面上的每个四连通块都至少完整邻接两个不同的要害室 $K_1,K_2\in\mathcal{K}$。即便大小 $\lvert K\rvert\ge 2$ 的室中驻有对手棋子，只要当前每个室不含 $c$ 方棋子且至少保留一个空点，则 $c$ 方全程仅出虚着即可抵御对手一切合法非认输着法：核心 $C$ 永不被提，且每个室始终保有至少一个空点。记保底面积点集 $P := C \cup \bigcup_{K\in\mathcal{K},\,\lvert K\rvert=1} K$，则任一双虚着终局满足免提面积下界（以黑方 $c=\mathrm{B}$ 计，白方反号）：
   $$\Delta(B_{\mathrm{end}}) \;\ge\; 2\lvert P\rvert - n^2.\tag{1.2}$$
2. **依赖类型策略证书与商复用**：由单方选择步、覆盖规则核全体合法动作的对手分支步、双虚着终局叶及上述静态／一步／见合活棋叶归纳构成的类型化策略证书 $\mathcal{D}$，可构造性编译为无外部循环假设的可执行策略 $\pi_{\mathcal{D}}$，对任意对手策略保证终局达标，且在同一 $q_{\mathrm{PSK}}$ 商等价类上跨历史直接复用。

<a id="thm-c"></a>

**定理 C（区域足迹反链 DAG 检查器健全性与 $19\times 19$ 百万节点角部证书；详定理 5.6 与核验计算 6.3）。**
设 $R\subsetneq V_{19}$ 为补集 $V_{19}\setminus R$ 四连通的观察区域（角部实例取左上 $7\times 7$，故 $\lvert V_{19}\setminus R\rvert=312$）。若无信任外部搜索导出的有向图在按节点秩 $\operatorname{rank}(s)=2r+\mathbf{1}_{\tau=\mathrm{W}}$ 升序单遍扫描时通过局部盘面转移、极大黑足迹反链包含条件、白方局部非自杀端口加外着与虚着的全覆盖校核以及叶节点活棋校核，则对满足局部盘面一致、反链支配且满足线性容量不等式
$$\lvert\operatorname{occ}(B)\rvert + \operatorname{rank}(s) \;<\; \lvert V_{19}\setminus R\rvert = 312\tag{1.3}$$
的任意 $19\times 19$ 全盘帧 $F$，检查器产出保底分差 $\Delta\ge-345$ 的全盘 `Certificate`。沿经查验的分支到达几何活棋叶，还可确保 $R$ 内至少八点黑方面积（定理 5.6）。在 12 手测试源 `W31` 上，一次运行核验了输入图的全部 $1{,}700{,}986$ 个节点与 $2{,}007{,}462$ 条边。在其 11 手前驱 $H_{11}$，一次运行交付全部 351 个后继证书，经黑着 $(2,1)$ 回接至原 10 手帧（核验计算 6.3）。

表 1 汇总了支撑定理 A–C 的五组核心不变量，并给出去掉任一前提时的精确反例或回归拦截行为。

**表 1　两层超劫压缩与区域策略提升的五组核心不变量及最小失效反例。**

| 层级与数学环节 | 若省略该条件会发生什么（精确反例） | 本文采用的精确条件与对应定理 |
| --- | --- | --- |
| **全盘开局虚着反射** | 第 $1$ 手 `pass` 产生两项空盘历史且 $p_{\mathrm{pass}}=1$，与真初局帧字面不等 | 集合商 $q_{\mathrm{PSK}}(F)=(V,\operatorname{set}(H))$ 吸收重复空盘；白第 $2$ 手实着将 $p_{\mathrm{pass}}$ 归零（引理 3.2、定理 3.4） |
| **驻敌室面积计分** | 例 1.1 的驻敌二格室末空是公气。将其加入 $P$ 会虚增一个面积点，使公式 $2\lvert P\rvert-n^2$ 多算两分。 | 核心棋子与单点眼构成保底集合 $P$（定理 4.3、例 4.4）。 |
| **跨界棋块区域外真气** | 若全盘外区被填满，局部视图中借边界外延看似有气的跨界块会在全盘因零气被提 | 连通补集鸽笼引理：$\lvert\operatorname{occ}(B)\rvert<\lvert V_{19}\setminus R\rvert\implies$ 跨界块必享至少一外气，局部与全盘提子相等（命题 5.2） |
| **区域内失子重落 PSK 保鲜** | 仅查“未曾落过的处女点”会误拒提子重落（例 5.4）；完全忽略历史则会踏入全盘超劫禁手 | 极大黑足迹反链：重落新足迹 $C'$ 只要不含于任何历史极大黑足迹 $M\in\mathcal{H}$，全盘必为新盘面（定理 5.3） |
| **对手 $312$ 外点任意脱先** | 逐点展开外区使分支因子乘上 $312$；忽略外着又会漏算 `passes` 清零与外区占子增长 | 单一 `.environment` 抽象端口配严格降秩且保持容量界 $\lvert\operatorname{occ}(B')\rvert+\operatorname{rank}(s')<312$（定理 5.6） |

![图 1｜全局局面超劫下的可达历史分岔与集合商开局虚着双模拟。(a) 两条从空盘合法可达的对局（5 手 $\gamma_1$ 与 7 手 $\gamma_2$）到达完全相同的可见盘面，但角点回提 W(0,0) 在 $\gamma_1$ 后合法、在 $\gamma_2$ 后被 PSK 禁止。(b) 集合商 $q_{\mathrm{PSK}}$ 抹平重复空盘历史，实着重置虚着计数，导出任意 $n\times n$ 棋盘贴目 0 下黑方先手不败。](figures/fig1-psk-stealing.pdf)

<a id="sec-1-3"></a>

### 1.3 三个纸笔验算算例

在进入一般定义之前，我们先用三个可直接手算的小算例说明定理 A、B、C 各自的运作机制。

<a id="ex-1-1"></a>

**例 1.1（两层历史压缩与驻敌要害室计分的纸笔验算）。**

1. **$1\times 1$ 棋盘双虚着与 $n\ge 2$ 开局虚着商等价**：在 $1\times 1$ 棋盘上，唯一格点 $(0,0)$ 无邻点；黑落 $(0,0)$ 后该子零气且无敌子可提，故被禁自杀排除。唯一合法着是黑 `pass`，继而白也只能 `pass`，终局 $\Delta(B_\emptyset)=0$。在 $n\ge 2$ 棋盘上，反设白方有策略在初局 $F_0(n)$ 强迫 $\Delta\le -1$。令黑第 $1$ 手走 `pass` 进入 $F_1$（历史表为 $[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W})]$，$p_{\mathrm{pass}}=1$）。白若跟走 `pass` 则双虚着终局得 $\Delta=0$，不达 $\le -1$；故白第 $2$ 手必在某点 $x$ 合法落子进入 $F_2$，此时实着规则把 $p_{\mathrm{pass}}$ 重置为 $0$，历史集变为 $\{B_\emptyset, W_x\}$。将 $F_2$ 黑白互换得 $\operatorname{swap}(F_2)$：轮白行棋，$p_{\mathrm{pass}}=0$，历史集变为 $\{B_\emptyset, B_x\}$。这与真初局黑第 $1$ 手直接落 $x$ 所得帧 $T_1$ 具有完全相同的可见状态与历史集合 $q_{\mathrm{PSK}}(\operatorname{swap}(F_2))=q_{\mathrm{PSK}}(T_1)$。于是白在 $F_2$ 强迫 $\Delta\le -1$ 经颜色反演变成黑在 $T_1$ 强迫 $\Delta\ge +1$，与白在真初局应对黑首手 $x$ 强迫 $\Delta\le -1$ 正面冲突。
2. **七子黑核与驻敌二格室**。在 $19\times19$ 左上角取四连通黑核 $C=\{(0,2),\allowbreak(1,0),\allowbreak(1,1),\allowbreak(1,2),\allowbreak(2,1),\allowbreak(3,0),\allowbreak(3,1)\}$，围住单点眼 $K_1=\{(2,0)\}$ 和二格室 $K_2=\{(0,0),(0,1)\}$。设 $(0,0)$ 有白子且 $(0,1)$ 为空。白填单点眼时黑核仍有另一口气，白着自杀。白填 $(0,1)$ 时两枚白子只邻接仍有 $K_1$ 真气的黑核，白着同样自杀。因此黑方可一直虚着，守住黑核与单点眼。计分时两者共给黑方八点。两色得分点集不交，故白方至多得 $361-8=353$ 点，$\Delta\ge-345$。在这个具体的驻敌构型中，室内最后一空是公气，白方至多得 352 点，达到时 $\Delta=-344$（例 4.4）。
3. **12 手基准局面上的线性容量预算**：在第 6 节的 12 手角部测试源 `W31` 上，全盘共落下 $6$ 黑 $6$ 白，故 $\lvert\operatorname{occ}(B)\rvert=12$，当前轮黑方行棋（$\tau=\mathrm{B}$，故 $\operatorname{rank}(s)=2r$）。若局部 DAG 根节点剩余对局预算为 $r=10$ 个回合（$\operatorname{rank}(s)=20$），则 $\lvert\operatorname{occ}(B)\rvert+\operatorname{rank}(s)=12+20=32<312$：黑落首应手（第 $13$ 手，消耗一轮黑方步预算 $r:10\mapsto 9$）后盘面至多 $13$ 子，轮白行棋时 $\operatorname{rank}$ 降为 $2\cdot 9+1=19$，和仍不超过 $13+19=32<312$；此后无论白方在区域外 $312$ 点如何脱先造劫，每步占子至多加 $1$ 而节点秩严格减 $1$，跨界白块在耗尽预算前不可能填满全部 $312$ 个外点。

<a id="sec-1-4"></a>

### 1.4 可信基边界、公理足迹与阅读路径

参照现代认证 SAT 检查器文献 [@CruzFilipe2017LRAT; @TanHeuleMyreen2021CakeLPR] 的惯例，我们将本文结论的验证责任与可信计算基（Trusted Computing Base, TCB）明确划分为以下三层（见图 4(b)）：

1. **Lean 内核** [@deMouraUllrich2021Lean4]。原公理审计检查了终止性、先手不败、静态活棋、区域检查器和增量求值器等定理。被审查声明的公理依赖在 `propext`、`Classical.choice` 与 `Quot.sound` 之内。第 4.3 节和附录 C 区分证明与可执行策略生成。
2. **Lean 执行**。`W31` 检查器、`W02`/`W32` 走廊生成器、原批量程序、全端口总装及有限对照以 Lean 程序运行。历史 `lean --run` 回执依赖 Lean 对这些程序的执行，包括解释器与运行时。接收的程序可构造证书这一结论由内核检查，具体程序成功执行则以运行回执记录（第 6.2 节）。
3. **外部输入与独立复算**。C++ 搜索及其 `corner-birth-dag/v1` 图文件提供候选策略，检查器逐边和逐叶按 Lean 规则核查验。无第三方依赖的 `validation/verify_manuscript.py` 独立复算小盘值、可达超劫反例、几何与回执数值。第 2–6 节及附录以围棋规则核和 `mathlib` 为基础 [@mathlib2020]。第 7 节接入同系列的过程状态与账本框架 [@Gao2026OneBitV2; @Gao2026SourceProcessCoreV3; @Gao2026WholeLedgerV2]。

**分读者阅读路径**：关注**组合博弈论与先手对称性**的读者可读 **§2 → §3 → §8.1**；关注**计算机围棋、局部死活与 GHI** 的读者可读 **§2.1 → §4.2 → §5 → §6 → §8.2–8.3**；关注**交互式定理证明与认证算法**的读者可读 **§1.4 → §4.3 → §5.3 → §7 → 附录 B–C**。

---

<a id="sec-2"></a>

## 2 禁自杀 Tromp–Taylor 全局超劫规则核与历史分岔算例

<a id="sec-2-1"></a>

### 2.1 网格连通块、提子算子、全局超劫与双虚着面积计分

设棋盘边长 $n\in\mathbb{N}$，网格顶点集为 $V_n := \{0,\dots,n-1\}^2$（当 $n=0$ 时 $V_0=\emptyset$；当 $n=19$ 时，顶点 $(r,j)$ 对应棋谱列 `ABCDEFGHJKLMNOPQRST[j]`、行 $19-r$）。两点 $x=(r,j)$ 与 $y=(r',j')$ 四邻接（记作 $x\sim y$）当且仅当 $\lvert r-r'\rvert+\lvert j-j'\rvert=1$。颜色集取二元集 $\{\mathrm{B},\mathrm{W}\}$（Lean 源码 `StoneColour` 中记作 `.positive` 与 `.negative`），记对合反演为 $\bar{\mathrm{B}}=\mathrm{W}$、$\bar{\mathrm{W}}=\mathrm{B}$。盘面是函数 $B : V_n \to \{\bot, \mathrm{B}, \mathrm{W}\}$，其中 $B(x)=\bot$ 表空点；记 $S_c(B):=\{x\in V_n : B(x)=c\}$，$\operatorname{occ}(B):=S_{\mathrm{B}}(B)\cup S_{\mathrm{W}}(B)$。

对任意点 $x\in V_n$，记 $\operatorname{Comp}(B,x)\subseteq V_n$ 为包含 $x$ 且具有相同取值 $B(y)=B(x)$ 的极大四连通分量。棋子连通块 $G=\operatorname{Comp}(B,x)$（$B(x)\neq\bot$）的气集定义为 $\operatorname{Lib}(B,G):=\{z\in V_n : B(z)=\bot \land \exists y\in G,\, y\sim z\}$；当 $\operatorname{Lib}(B,G)\neq\emptyset$ 时称 $G$ 有气。

<a id="def-2-1"></a>

**定义 2.1（禁自杀、虚着豁免 PSK 与双虚着面积计分核，`RulesKernel` / `ScoreReadout`）。**
固定边长 $n\in\mathbb{N}$：

1. **提子后盘面**：在空点 $x$（$B(x)=\bot$）由 $c$ 方落子，先置 $B_1 := B[x\mapsto c]$；只移除邻接落点的零气敌块，记被提敌子集 $\operatorname{Cap}_n(B,c,x) := \{y\in V_n : B_1(y)=\bar{c},\; \operatorname{Lib}(B_1,\operatorname{Comp}(B_1,y))=\emptyset,\; \exists v\in\operatorname{Comp}(B_1,y),\; v\sim x\}$，定义落子后盘面为
   $$\operatorname{After}(B,c,x)(z) := \begin{cases} \bot, & z\in \operatorname{Cap}_n(B,c,x), \\ B_1(z), & z\notin \operatorname{Cap}_n(B,c,x). \end{cases}\tag{2.1}$$
2. **原生历史帧与转移算子**：一帧对局状态为五元组 $F=(B,\tau,p_{\mathrm{pass}},\mathrm{st},H)$，其中前四项组成可见状态 $V(F)=(B,\tau,p_{\mathrm{pass}},\mathrm{st})$，$\tau\in\{\mathrm{B},\mathrm{W}\}$ 为行棋方，$p_{\mathrm{pass}}\in\mathbb{N}$ 为连续虚着数，$\mathrm{st}\in\{\mathtt{playing},\mathtt{twoPasses},\mathtt{resigned}(c)\}$ 为状态标签，$H=[(B_0,\tau_0),\dots,(B_k,\tau_k)]$ 为已出现盘面与手番的历史列表。初局帧为 $F_0(n):=(B_\emptyset,\mathrm{B},0,\mathtt{playing},[(B_\emptyset,\mathrm{B})])$。本文固定规则核 `Law.positionalSuperko 0`（禁多子与单子自杀、全局局面超劫、虚着豁免超劫，区别于允许全块无气自提的原始 Tromp–Taylor 变体）。当 $\mathrm{st}=\mathtt{playing}$ 时，计分着法 $m\in\{\mathtt{play}(x):x\in V_n\}\cup\{\mathtt{pass}\}$ 的部分转移函数 $\operatorname{step}(F,m)$ 为：
   $$\operatorname{step}(F,m) := \begin{cases} \bigl(B,\;\bar{\tau},\;p_{\mathrm{pass}}+1,\;\mathrm{st}',\;H\mathbin{\Vert}[(B,\bar{\tau})]\bigr), & m=\mathtt{pass},\\[4pt] \bigl(B',\; \bar{\tau},\; 0,\; \mathtt{playing},\; H\mathbin{\Vert}[(B',\bar{\tau})]\bigr), & m=\mathtt{play}(x),\; B(x)=\bot,\; \operatorname{Lib}(B',\operatorname{Comp}(B',x))\neq\emptyset,\; B'\notin\operatorname{set}(H), \end{cases}\tag{2.2}$$
   其中 $B':=\operatorname{After}(B,\tau,x)$，$\operatorname{set}(H):=\{B'' : (B'',\cdot)\in H\}$，且当 $p_{\mathrm{pass}}+1\ge 2$ 时 $\mathrm{st}'=\mathtt{twoPasses}$，否则 $\mathrm{st}'=\mathtt{playing}$。记枚举全体合法计分着法及其后继帧的列表为 $\operatorname{Expand}(F)$。
3. **无死子清理双虚着面积计分**：对任意盘面 $B$，空连通域 $U=\operatorname{Comp}(B,z)$（$B(z)=\bot$）归属颜色 $c$（记作 $\operatorname{ReachesOnly}(B,U,c)$）当且仅当 $\{B(y) : B(y)\ne\bot,\ \exists u\in U,\ u\sim y\}=\{c\}$。单方区域得分与黑减白净面积分差定义为
   $$\operatorname{Area}(B,c) := \lvert S_c(B)\rvert + \bigl\lvert\{\,z\in V_n : B(z)=\bot \land \operatorname{ReachesOnly}(B,\operatorname{Comp}(B,z),c)\,\}\bigr\rvert, \qquad \Delta(B) := \operatorname{Area}(B,\mathrm{B}) - \operatorname{Area}(B,\mathrm{W}).\tag{2.3}$$
   双虚着终局时直接读取 $\Delta(B)$，不引入人工死活协议或终局死子清理。

<a id="sec-2-2"></a>

### 2.2 有限超劫复合良基秩与 $19\times 19$ 矩阵物化步恒等

记 $\mathcal{B}_n=\{\bot,\mathrm{B},\mathrm{W}\}^{V_n}$ 为全体盘面，$\mathcal{U}(F)=\mathcal{B}_n\setminus\operatorname{set}(H(F))$ 为未见盘面集。尚在对局的帧 $F$ 在虚着计数为零时取 $\phi(F)=2$，已有虚着时取 $\phi(F)=1$。

<a id="prop-2-2"></a>

**命题 2.2（有限超劫复合终止秩与 $19\times 19$ 矩阵物化步恒等，`Termination` / `MaterializedStep`；GO2, GO8）。**

1. **复合秩严格下降**：定义自然数秩
   $$\rho(F) := \begin{cases} 2\lvert\mathcal{U}(F)\rvert+\phi(F), & \mathrm{st}=\mathtt{playing},\\ 0, & \mathrm{st}\ne\mathtt{playing},\end{cases} \qquad \rho(F)\le 2\cdot 3^{n^2}+2.\tag{2.4}$$
   全局 PSK 下的每个合法转移都严格降秩。实着记录新盘面，令 $2\lvert\mathcal{U}\rvert$ 至少减二，$\phi$ 至多增一。虚着不会扩大未见盘面集，并使 $\phi$ 从二变一或直接终局归零。认输也直接终局归零。故任意合法对局至多经过 $2\cdot 3^{n^2}+2$ 手。
2. **$19\times19$ 矩阵物化步恒等**。`MaterializedStep.step?` 只计算一次提子后盘面，后续查气、超劫和历史记录共用这张矩阵。`step_eq` 对任意规则、帧与着法证明物化步等同原生步。`scoring_eq` 在 `Law.positionalSuperko 0` 下证明合法非认输着法及后继帧的枚举列表相等。

<a id="sec-2-3"></a>

### 2.3 可达同盘异史对局分岔与全端口控制

我们将引言中的 5 手与 7 手角部提劫对局补齐为精确的规则核证物，并交代源码回归运行器中的 13 手全端口控制。

<a id="ex-2-3"></a>

**例 2.3（可达同盘异史劫争分岔与 `RunMaterializedStep19` 的 13 手全端口控制；GO8）。**
在 $19\times 19$ 空盘 $F_0(19)$ 上执行第 1.1 节的 5 手合法序列 $\gamma_1$ 与 7 手合法序列 $\gamma_2$（由独立脚本 `verify_manuscript.py` 与纸笔重放核验），分别到达帧 $F_{\gamma_1}$ 与 $F_{\gamma_2}$。两者具有完全相同的可见四元组 $V(F_{\gamma_1})=V(F_{\gamma_2})$（黑子 $\{(0,1),(1,0),(2,0)\}$，白子 $\{(0,2),(1,1)\}$，轮白行棋，$p_{\mathrm{pass}}=0$），但 $\gamma_2$ 在第 $6$ 手走过盘面 $B^{\star}$（黑 $\{(1,0),(2,0)\}$、白 $\{(0,0),(0,2),(1,1)\}$）并于第 $7$ 手落 $\mathtt{B}(0,1)$ 提去 $\mathtt{W}(0,0)$。当白方在角点测试回提 $\mathtt{W}(0,0)$（`A19`）时，$\operatorname{After}(B,\mathrm{W},(0,0))=B^{\star}$：在 $F_{\gamma_1}$ 上 $B^{\star}\notin\operatorname{set}(H)$，非认输合法端口数为 $357$；在 $F_{\gamma_2}$ 上 $B^{\star}\in\operatorname{set}(H)$ 被 PSK 拦截，非认输合法端口数为 $356$，而 `pass` 因豁免超劫在两帧均合法。与此同时，编译执行的 Lean 回归运行器 `RunMaterializedStep19.lean` 在第 6 节的 13 手走廊帧 $F_{13}$（$H_{11}+\mathtt{W}(0,2)+\mathtt{B}(3,1)$）上构造人工追加目标盘面签名的单测对 $(F_{13},F'_{13})$，核验矩阵物化步在全部 $349$ vs. $348$ 个端口上与原生函数式规则核逐项一致（表 2）。

**表 2　两组同可见盘面、异历史集合的 $19\times 19$ 全局 PSK 分岔对照。**

| 对照帧对 | 生成方式与共同可见状态 | 历史集合关键差异 | 测试着法结果 | $19\times 19$ 合法端口数 |
| --- | --- | --- | --- | --- |
| **可达劫争对 $(F_{\gamma_1}, F_{\gamma_2})$** | 均从空盘合法走出（5 手 $\gamma_1$ vs. 7 手 $\gamma_2$）；轮白，$p_{\mathrm{pass}}=0$ | $B^{\star}\notin\operatorname{set}(H_{\gamma_1})$，而 $B^{\star}\in\operatorname{set}(H_{\gamma_2})$（第 6 手出现） | `W(0,0)`：$\gamma_1$ 合法提子，$\gamma_2$ 被 PSK 拒；`pass` 均合法 | $357$ vs. $356$ |
| **回归单测对 $(F_{13}, F'_{13})$** | 13 手走廊帧 $F_{13}$ 与人工追加 `W(0,3)` 后盘面的控制帧 $F'_{13}$ | $F'_{13}$ 预置一线延气后盘面签名 | `W(0,3)`：$F_{13}$ 合法，$F'_{13}$ 被拒；`pass` 均合法 | $349$ vs. $348$ |

---

<a id="sec-3"></a>

## 3 全盘历史集合商与任意 $n\times n$ 棋盘先手不败定理

<a id="sec-3-1"></a>

### 3.1 开局虚着与策略传输的两条等式

Weninger 与 Hayward [@WeningerHayward2017, 定理 1] 在矩形 PSK 棋盘上证明先手不败。其证明从空盘出发让黑先虚着，若白实着再交换颜色。他们的状态已包括过往盘面的集合。Lean 原生历史仍保存每条记录及行棋方标签。为在这个载体上传输策略，需证明两处等式：

1. **历史列表不对称**：真初局 $F_0(n)$ 的历史为单项列表 $[(B_\emptyset,\mathrm{B})]$，而黑第 $1$ 手 `pass` 后的帧 $F_1$ 历史为两项列表 $[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W})]$；颜色互换不会消除列表长度差。
2. **虚着计数偏移**：$F_1$ 的连续虚着数为 $p_{\mathrm{pass}}=1$，若直接在此状态做颜色反演，白方只需再补一手 `pass` 即可触发双虚着终局，与真初局 $p_{\mathrm{pass}}=0$ 的博弈树并不步步同构。

下面两小节展示，集合商 $q_{\mathrm{PSK}}$ 与“白方欲强制获胜则第 $2$ 手不能虚着、而实着自动重置 $p_{\mathrm{pass}}\mapsto 0$”恰好无缝消解这两项义务。

<a id="sec-3-2"></a>

### 3.2 颜色反演等变性与集合商 $q_{\mathrm{PSK}}$ 的双模拟提升

对任意盘面 $B$，定义逐点颜色互换 $\operatorname{swap}(B)(x) := \overline{B(x)}$（规定 $\bar{\bot}=\bot$），并逐分量扩充至状态标签与历史帧：
$$\operatorname{swap}(B,\tau,p_{\mathrm{pass}},\mathrm{st},H) := \bigl(\operatorname{swap}(B),\;\bar{\tau},\;p_{\mathrm{pass}},\;\operatorname{swap}(\mathrm{st}),\;[(\operatorname{swap}(B'),\bar{\tau}') : (B',\tau')\in H]\bigr), \qquad \Delta(\operatorname{swap}(B)) = -\Delta(B).\tag{3.1}$$
这是因为颜色双射保持网格同色四连通分量、气集、提子算子及空域单色邻接关系，从而交换黑白双方的区域得分 $\operatorname{Area}(\operatorname{swap}(B),c)=\operatorname{Area}(B,\bar{c})$。

<a id="lem-3-1"></a>

**引理 3.1（颜色反演的得分反对称与单步等变性，`InitialColourPass`）。**
对任意边长 $n\in\mathbb{N}$、历史帧 $F$ 与计分着法 $m$，$\operatorname{step}(\operatorname{swap}(F),m) = \operatorname{swap}(\operatorname{step}(F,m))$（两端同时有定义或同时无定义），且终局面积分差满足式 (3.1) 的精确反号恒等。

接下来定义全盘 PSK 集合商投影（源码 `PositionFace`）：对任意帧 $F=(V,H)$，令 $q_{\mathrm{PSK}}(F) := (V,\operatorname{set}(H))$，称满足 $q_{\mathrm{PSK}}(F_1)=q_{\mathrm{PSK}}(F_2)$ 的两帧**商等价**，记作 $F_1 \equiv_{\mathrm{PSK}} F_2$。

<a id="lem-3-2"></a>

**引理 3.2（集合商 $q_{\mathrm{PSK}}$ 下的强双模拟提升，`PositionFace.legalStep_lift`；GO2）。**
设两帧满足 $F_1 \equiv_{\mathrm{PSK}} F_2$。则对任意计分着法 $m$：

1. $\operatorname{step}(F_1,m)$ 有定义当且仅当 $\operatorname{step}(F_2,m)$ 有定义；
2. 若有定义并分别记后继帧为 $F'_1,F'_2$，则仍有 $F'_1 \equiv_{\mathrm{PSK}} F'_2$，且枚举端口序列满足相同着法顺序与逐项商等价。

*证明。* 式 (2.2) 中除可见四元组 $V(F)$ 相等外，唯一读取历史列表 $H$ 的守卫是实着新盘面检验 $B'\notin\operatorname{set}(H)$，仅依赖无序盘面集合 $\operatorname{set}(H)$ 而与出现次序、重复次数及手番标签无关。转移成功后，无论是虚着并入 $B$ 还是实着并入 $B'$，新历史集合均为 $\operatorname{set}(H)\cup\{B_{\mathrm{next}}\}$，故后继帧保持 $q_{\mathrm{PSK}}(F'_1)=q_{\mathrm{PSK}}(F'_2)$。$\square$

<a id="sec-3-3"></a>

### 3.3 有限超劫确定性、任意尺寸先手不败主定理与规则变体边界

定义归纳谓词 $\operatorname{Forces}(c,\theta,F)$（源码 `InitialColourPass.Forces`）：当 $\mathrm{st}=\mathtt{twoPasses}$ 时，由构造子 `.terminal` 在 $c=\mathrm{B}\land\Delta(B)\ge\theta$（或 $c=\mathrm{W}\land\Delta(B)\le\theta$）时成立；当 $\mathrm{st}=\mathtt{playing}$ 且 $\tau=c$ 时，由构造子 `.choose` 在存在合法非认输后继 $(m,F')\in\operatorname{Expand}(F)$ 使 $\operatorname{Forces}(c,\theta,F')$ 时成立；当 $\mathrm{st}=\mathtt{playing}$ 且 $\tau=\bar{c}$ 时，由构造子 `.all` 在一切合法非认输后继均满足 $\operatorname{Forces}(c,\theta,F')$ 时成立。

<a id="lem-3-3"></a>

**引理 3.3（有限超劫二分、双向阈值不相容与商不变性，`Termination` / `InitialColourPass`）。**
对任意边长 $n\in\mathbb{N}$、处于 $\mathtt{playing}$ 或 $\mathtt{twoPasses}$ 的合法帧 $F$ 及整数 $\theta_{\mathrm{B}},\theta_{\mathrm{W}},\theta\in\mathbb{Z}$：

1. **有限二分（`forcing_dichotomy`）**：对任意阈值 $\theta$，必有 $\operatorname{Forces}(\mathrm{B},\theta,F)$ 或 $\operatorname{Forces}(\mathrm{W},\theta-1,F)$。
2. **不相容性（`Forces.incompatible`）**：若 $\theta_{\mathrm{W}} < \theta_{\mathrm{B}}$，则 $\operatorname{Forces}(\mathrm{B},\theta_{\mathrm{B}},F)$ 与 $\operatorname{Forces}(\mathrm{W},\theta_{\mathrm{W}},F)$ 不可能同时成立。
3. **反演与商传输**：$\operatorname{Forces}(c,\theta,F) \iff \operatorname{Forces}(\bar{c},-\theta,\operatorname{swap}(F))$；且若 $F_1 \equiv_{\mathrm{PSK}} F_2$，则 $\operatorname{Forces}(c,\theta,F_1) \iff \operatorname{Forces}(c,\theta,F_2)$。

*证明。* (1) 对复合终止秩 $\rho(F)$（命题 2.2）做良基归纳：在双虚着叶上由整数线性序 $\Delta(B)\ge\theta \lor \Delta(B)\le\theta-1$ 成立；在内部节点（`pass` 豁免超劫，故任意 $\mathtt{playing}$ 帧至少含有合法动作 `pass`），由德摩根律传递存在／全称分支。(2) 源码 `Forces.incompatible` 将双方归纳证明映射为策略对并在同一对局终盘比较分差（等价地沿所选合法步按 $\rho(F)$ 下降至双虚着终局），得 $\theta_{\mathrm{B}}\le\Delta(B)\le\theta_{\mathrm{W}}$，与 $\theta_{\mathrm{W}}<\theta_{\mathrm{B}}$ 矛盾。(3) 对 `Forces` 归纳结构直接应用引理 3.1 与引理 3.2 立得。$\square$

<a id="thm-3-4"></a>

**定理 3.4（任意 $n\times n$ 棋盘贴目 $0$ 下黑方先手不败主定理，`InitialColourPass`；GO2）。**
对任意棋盘边长 $n\in\mathbb{N}$：

1. 白方在初局空盘上不存在负分必胜策略：$\neg\operatorname{Forces}(\mathrm{W}, -1, F_0(n))$；
2. 黑方在初局空盘上必有非负策略：$\operatorname{Forces}(\mathrm{B}, 0, F_0(n))$，且在类型层满足 $\operatorname{Nonempty}(\mathtt{Certificate}\;\mathrm{B}\;0\;(F_0(n)))$。

*证明。* 反设 $\operatorname{Forces}(\mathrm{W}, -1, F_0(n))$。在 $F_0(n)$ 轮黑行棋，`pass` 合法，推进一步到达 $F_1 := (B_\emptyset,\mathrm{W},1,\mathtt{playing},[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W})])$。因白在 $F_0(n)$ 对黑一切合法着均强迫 $\le -1$，故 $\operatorname{Forces}(\mathrm{W},-1,F_1)$。在 $F_1$ 轮白行棋，故存在某合法动作 $m$ 及后继 $F_2=\operatorname{step}(F_1,m)$ 使 $\operatorname{Forces}(\mathrm{W},-1,F_2)$：

- **情形 1（$m=\mathtt{pass}$）**：则 $p_{\mathrm{pass}}$ 增至 $2$，$F_2$ 直接以空盘 $B_\emptyset$ 进入 $\mathtt{twoPasses}$ 终局。因空盘无任何棋子，无空域单色邻接黑或白，$\Delta(B_\emptyset)=0-0=0\not\le -1$，矛盾（当 $n=0$ 或 $n=1$ 时无合法实着，证明在此直接结束）。
- **情形 2（$m=\mathtt{play}(x)$）**：白在空盘落子 $x$，所得盘面 $W_x := \operatorname{After}(B_\emptyset,\mathrm{W},x)$ 有气且 $W_x\neq B_\emptyset$。按式 (2.2)，实着步将连续虚着数重置为 $p_{\mathrm{pass}}(F_2)=0$，故 $F_2=(W_x,\mathrm{B},0,\mathtt{playing},[(B_\emptyset,\mathrm{B}),(B_\emptyset,\mathrm{W}),(W_x,\mathrm{B})])$。对 $F_2$ 施以颜色反演并引用引理 3.3(3)，由 $\operatorname{Forces}(\mathrm{W},-1,F_2)$ 得 $\operatorname{Forces}(\mathrm{B},+1,\operatorname{swap}(F_2))$。另一方面，在真初局 $F_0(n)$ 由黑方直接落同一坐标 $x$：因 $\operatorname{swap}(W_x)=\operatorname{After}(B_\emptyset,\mathrm{B},x)=:B_x$ 有气且 $B_x\neq B_\emptyset$，该步合法到达真初局首手后继帧 $T_1 := (B_x,\mathrm{W},0,\mathtt{playing},[(B_\emptyset,\mathrm{B}),(B_x,\mathrm{W})])$。直接核对两帧的商投影：两者可见四元组均为 $(B_x,\mathrm{W},0,\mathtt{playing})$，且历史无序集合满足
  $$\operatorname{set}\bigl(H(\operatorname{swap}(F_2))\bigr) = \{B_\emptyset, B_\emptyset, B_x\} = \{B_\emptyset, B_x\} = \operatorname{set}\bigl(H(T_1)\bigr),\tag{3.2}$$
  即 $\operatorname{swap}(F_2) \equiv_{\mathrm{PSK}} T_1$（源码 `InitialColourPass` 等价地先对 $\operatorname{swap}(F_1)$ 置 $p_{\mathrm{pass}}\mapsto 0$ 在初局核对商相等，再推送同一实着 $x$ 到达 $T_1$，两写法导出同一商等式 (3.2)）。由引理 3.3(3) 得 $\operatorname{Forces}(\mathrm{B},+1,T_1)$；但反设对黑初局合法选步 $\mathtt{play}(x)$ 同时给出 $\operatorname{Forces}(\mathrm{W},-1,T_1)$，违反引理 3.3(2)（$-1 < +1$）。

故 $\neg\operatorname{Forces}(\mathrm{W},-1,F_0(n))$ 恒成立。再对 $\theta=0$ 应用引理 3.3(1) 即得 $\operatorname{Forces}(\mathrm{B},0,F_0(n))$，进而在良基树上诱导出非空证书类型（定理 4.6）。$\square$

<a id="cor-3-5"></a>

**推论 3.5（$19\times 19$ 精确初始分差界与一般 $n$ 临界贴目区间，`InitialColourPass.exact_value_bounds`）。**
在 $n=19$ 上，源码机器证明对任意满足双向紧致证书对 `ExactInitialMargin` 的分差值 $v$ 恒有 $0 \le v \le 361$。在纸面数学上，对一般边长 $n\in\mathbb{N}$，有限零和确定性（引理 3.3(1)–(2)）与面积平凡上界 $\Delta(B)\le n^2$ 直接确定唯一整数极小极大临界贴目 $k^\star(n)\in\mathbb{Z}$（使 $\operatorname{Forces}(\mathrm{B},k^\star(n),F_0(n))$ 且 $\operatorname{Forces}(\mathrm{W},k^\star(n),F_0(n))$），满足
$$\forall n\in\mathbb{N},\qquad \operatorname{Forces}(\mathrm{B},\;0,\;F_0(n)) \quad\text{且}\quad 0 \;\le\; k^\star(n) \;\le\; n^2.\tag{3.3}$$

<a id="rem-3-6"></a>

**注记 3.6（$2\times 2$ 棋盘上 PSK 破缺镜面对称的复算算例与 Allis 求解层级定位）。**
经独立穷举复算（`validation/verify_manuscript.py`）易验 $k^\star(0)=k^\star(1)=0$，而 $2\times 2$ 棋盘给出第一个严格正临界贴目 $k^\star(2)=+1$ [@Tromp2x2PSK]，且直接展示了全局 PSK 如何打破可见盘面的几何对称：考虑合法 4 手序列 $1.\,\mathtt{B}(0,0),\;2.\,\mathtt{W}(1,1),\;3.\,\mathtt{B}(0,1),\;4.\,\mathtt{W}(1,0)$（第 $4$ 手白提去第一行两枚黑子）。此时可见盘面仅有底行两白子 $\{(1,0),(1,1)\}$，顶行两空点 $(0,0)$ 与 $(0,1)$ 左右完全镜面对称。然而历史集记录了第 $1$ 手的单黑盘面 $B_{(0,0)}$，却从未出现单黑盘面 $B_{(0,1)}$：若第 $5$ 手黑落 $(0,0)$，白第 $6$ 手扑入 $(0,1)$ 提去 $(0,0)$ 后，黑在 $(0,0)$ 反提三白子会重现 $B_{(0,0)}$ 而被 PSK 封死，此后双方最优应对下黑终局净负（极小极大值 $\Delta=-4$）；反之若第 $5$ 手黑落 $(0,1)$，白扑 $(0,0)$ 后黑在 $(0,1)$ 反提三白子产生全新盘面 $B_{(0,1)}$，此后双方最优应对下黑终局净胜（$\Delta=+1$）。同时，按 Allis [@Allis1994] 的求解分类，贴目为 $0$ 时允许平局（$\Delta=0$），定理 3.4 给出的是任意尺寸棋盘上的**贴目 $0$ 先手不败性**（first-player non-loss：排除白胜，保证黑胜或平），而非区分 $k^\star(n)=0$（和棋）与 $k^\star(n)\ge 1$（黑严格必胜）的超弱完全解。

<a id="rem-3-7"></a>

**注记 3.7（情境超劫 SSK 与自杀规则变体下的精确成立边界）。**
定理 3.4 的 Lean 证明使用 `Law.positionalSuperko 0`。在纸面上，若改用虚着豁免、禁自杀的情境超劫（SSK，禁重现同一盘面与同一行棋方），证明仍成立。反射历史多出的 $(B_\emptyset,\mathrm W)$ 不会阻挡实着，因为合法实着必留下落点上的棋子。取消虚着豁免后，PSK 禁黑方首个虚着，SSK 则禁白方紧接的第二个虚着，原证明因而失效。若 SSK 允许整盘自杀，多出的历史项可能触发禁手：在 $2\times2$ 上从 $T_1$ 开始，白方每次虚着，黑方依次填满剩余三点。末着提尽黑棋并产生 $(B_\emptyset,\mathrm W)$，直接首着的历史允许这一步，反射历史禁止。

---

<a id="sec-4"></a>

## 4 多群协作护眼、驻敌混合要害室与类型化策略证书

定理 3.4 在命题层排除了空盘先手必败；要在具体 $19\times 19$ 局面上构造可执行策略并剪除终局前天文数字级的填子分支，必须拥有无需继续搜索即可在任意全盘状态下保底终局分差的静态与短步活棋判据。

<a id="sec-4-1"></a>

### 4.1 强迫保持不变量与多群协作护眼闭包

<a id="def-4-1"></a>

**定义 4.1（强迫保持不变量，`ClosedUnderNativeForcing`）。**
固定边长 $n$ 与受益方 $c$。若所有满足 $I(F)$ 的帧均在对局中或已双虚着终局，并满足以下条件，称 $I$ 为阈值 $\theta$ 的**强迫保持不变量**。双虚着终局满足分差阈值（黑方为 $\Delta\ge\theta$，白方为 $\Delta\le\theta$）。对局中轮 $c$ 行棋时，至少一个合法非认输后继保持 $I$。轮对手行棋时，每个合法非认输后继都保持 $I$。

由秩 $\rho(F)$ 的有限下降，每步取保持不变量的合法着法，最终到达符合阈值的计分终局。下述两种几何闭包里，受益方只需虚着。

<a id="thm-4-2"></a>

**定理 4.2（多群协作护眼无条件活棋律，`EyeCoalition`；GO4）。**
设非空核心点集 $C\subseteq V_n$ 与纯空眼集 $E\subseteq V_n$ 满足 $C\cap E=\emptyset$，使得：(i) 每个眼点 $e\in E$ 非孤立且其四邻点全部落入核心：$\emptyset\neq\{y:y\sim e\}\subseteq C$；(ii) 在仅置核心石的掩模盘面 $M_C$ 上，每个核心石 $s\in C$ 所属的四连通分量至少邻接 $E$ 中两个不同眼点：
$$\forall s\in C,\qquad \bigl\lvert\{\,e\in E : \exists y\in\operatorname{Comp}(M_C,s),\; y\sim e\,\}\bigr\rvert \;\ge\; 2.\tag{4.1}$$
若当前帧能计分（尚在对局或已双虚着终局），且满足 $C\subseteq S_c(B)$ 且 $E\cap\operatorname{occ}(B)=\emptyset$，则该动态条件构成关于保底点集 $P:=C\cup E$、阈值 $\theta=2\lvert P\rvert-n^2$（当 $c=\mathrm{B}$；$c=\mathrm{W}$ 取 $n^2-2\lvert P\rvert$）的强迫保持不变量。

*证明。* 任意核心石 $s\in C$ 在真实盘面 $B$ 上的同色连通块包含掩模连通块 $\operatorname{Comp}(M_C,s)$，故至少享有 $E$ 中两口真气。对手 $\bar{c}$ 若落子于非眼点 $x\notin E$，由于对手单步落子至多占用一个空点，每个核心分量至少剩有 $E$ 中两口气，绝不被提；对手若试图投入眼点 $e\in E$，因 $e$ 的全部邻点均属于至少剩有另一眼点真气的核心 $C$，故既不能提掉任何核心石，自身又无空邻点，被禁自杀规则直接拦截。双虚着终局时，$C$ 计入 $c$ 方棋子，$E$ 中每点均为单点空域且四邻全属 $C$，故 $P=C\cup E\subseteq \operatorname{Area}(B,c)$ 且与 $\operatorname{Area}(B,\bar{c})$ 不交，从而 $\Delta(B)\ge \lvert P\rvert-(n^2-\lvert P\rvert)=2\lvert P\rvert-n^2$。$\square$

<a id="sec-4-2"></a>

### 4.2 驻敌混合要害室闭包、免提保守面积下界与一步／见合出生

角部策略叶常遇到已经驻有敌子的封闭空间。Benson 的要害域要求每个空点与支撑棋块相邻 [@Benson1976]，Sanko 的纯眼要求室内各点都与棋块相邻 [@KharmaSchintke2026Sanko, 引理 1]。本文在固定核心掩模上采用后一种几何条件，使同一个室证据覆盖不同的室内占子方式，并给出只走虚着即可保证的面积下界。

<a id="thm-4-3"></a>

**定理 4.3（驻敌混合要害室闭包与免提保守面积下界，`VitalChambers`；GO4）。**
设非空核心集 $C\subseteq V_n$ 与有限要害室族 $\mathcal{K}=\{K_1,\dots,K_m\}$ 满足静态几何公理：(1) 各 $K\in\mathcal{K}$ 非空、与 $C$ 不交且两两不交；(2) **封闭边界与非孤立性**：对每个 $K\in\mathcal{K}$ 与 $x\in K$，$\emptyset\neq\{y\in V_n:y\sim x\}\subseteq C\cup K$；(3) **整室双支撑**：在纯核心掩模盘面 $M_C$ 上，每个核心石 $s\in C$ 所属连通块至少完整邻接两个不同的要害室：
$$\forall s\in C,\qquad \bigl\lvert\bigl\{\,K\in\mathcal{K} \;:\; K \subseteq \{z\in V_n : \exists y\in\operatorname{Comp}(M_C,s),\; y\sim z\}\,\bigr\}\bigr\rvert \;\ge\; 2.\tag{4.2}$$
定义 $\operatorname{Holds}(B)$ 为 $C\subseteq S_c(B)$，且每个 $K\in\mathcal K$ 都无己方棋子、至少有一空点。在能计分的帧上，这是强迫保持不变量。令 $P:=C\cup\bigcup_{K\in\mathcal K,\lvert K\rvert=1}K$，则 $P$ 的每一点均给 $c$ 方计分，故
$$\Delta(B) \;\ge\; 2\lvert P\rvert - n^2 \quad (c=\mathrm{B}), \qquad \Delta(B) \;\le\; n^2 - 2\lvert P\rvert \quad (c=\mathrm{W}).\tag{4.3}$$

*证明。* 设 $\operatorname{Holds}(B)$ 成立。每个室 $K\in\mathcal{K}$ 至少含一空点 $e_K\in K$；由整室邻接公理 (4.2)，掩模分量 $\operatorname{Comp}(M_C,s)$ 与支撑它的每个室 $K$ 中的**每一个点**（尤其 $e_K$）直接四邻接，故每个核心分量在 $B$ 上至少享有两口位于不同室内的真气 $e_{K_1}\neq e_{K_2}$。对手 $\bar{c}$ 在 $x$ 落子时：

- **核心不失**：单步落子 $x$ 至多填入某一个室（因各室两两不交），每个核心分量在另一个支撑室中仍至少保有一口空点真气，故 $\operatorname{Cap}_n(B,\bar{c},x)\cap C=\emptyset$，核心 $C$ 原样保留。
- **每室必留空点**：若 $x\notin K$，原空点 $e_K\in K$ 保持为空。若 $x\in K$：当 $K$ 原有至少两个空点时，落 $x$ 后仍剩空点；当 $x$ 恰是 $K$ 的**唯一剩余空点**时，落子前 $K\setminus\{x\}$ 全为 $\bar{c}$ 方棋子。置 $B_1=B[x\mapsto\bar{c}]$ 后，$K$ 被 $\bar{c}$ 完全填满，而由封闭边界公理 (2)，$K$ 向外越界邻接的全部顶点均属于核心 $C$（已证在 $B_1$ 上仍有另一室的真气故不被提）。从而连通块 $\operatorname{Comp}(B_1,x)\subseteq K$ 在提子后盘面 $B'$ 上零气，违反禁自杀守卫，故填满末空在规则核中不可能合法发生。

虚着不改变盘面，因而保持几何条件。终局计分时，$C$ 内仍全为 $c$ 色棋子；每个单点室 $K=\{e\}$ 中的空点 $e$ 邻点非空且全在 $C$ 内，也给 $c$ 方计分。两色得分点集不交，故有式 (4.3)。$\square$

<a id="ex-4-4"></a>

**例 4.4（驻敌二格室构型的最优保底点数）。**
取例 1.1(2) 的盘面。角外除 $(18,18)$ 留给白棋作为单点眼外均置白子，各块棋都保有真气。双虚着计分时，黑核与单点眼给黑方八点，白方得 352 点，$(0,1)$ 为公气，$\Delta=-344$。此构型中黑方保底八点恰可取到；多点室中留下的空点未必给黑方计分。通用下界 (4.3) 只需两色得分点集不交。

<a id="rem-4-5"></a>

**注记 4.5（一步补点出生与双补点见合 miai 出生，`VitalBirthRecognize` / `SourceLeaf`）。**
在搜索树内部，许多尚未直接满足定理 4.3 的局部形态只需再补一至两手即可成型：(i) **一步补点出生**：当轮己方行棋时，若补入空点 $a\in V_n$ 后新盘面合法（不自杀且未触发 PSK）并直接满足定理 4.2 或 4.3 的条件，则一步即闭合；(ii) **双补点见合（miai）出生**：当轮对手行棋且存在两个不同空点 $a\neq b$（例如图 2(b) 右上角钩形源的封口点对 $(0,2)$ 与 $(0,3)$），只要在对手的每一个合法后继帧上 $a$ 或 $b$ 至少有一点仍合法完成上述一步补点，己方便可按“对手占 $a$ 我补 $b$，对手走他处我补 $a$”在两手内闭合全部对手分支。

![图 2｜虚着活棋与 H11 的三类白应手。(a) 左为共用单点眼的两条黑链，右为保护驻敌要害室和单点眼的七子黑核。(b) 11 手角部实盘与应手分流。对 343 个外围白应手，黑补 B(3,1) 形成七子钩形源。三类策略在同次执行中总装为完整的 351 应手证书。](figures/fig2-vital-chambers.pdf)

<a id="sec-4-3"></a>

### 4.3 依赖类型策略证书的可靠性与集合商跨帧复用

归纳类型 `Certificate` 由受益方、阈值及当前帧索引。构造子 `.choose` 携带本方合法非认输着法及后继证书；`.all` 携带对手合法非认输着法的全族续证；`.terminal` 检验终局得分。几何构造子为 `.twoEye`、`.twoEyeFamily`、`.eyeCoalition` 和 `.vitalChambers`。见合证书由 `.all`、`.choose` 和几何叶组合而成。

这里有一处关键的接口设计：`.all` 构造子不接受外部分支列表，而是直接对规则核自身枚举的 $\operatorname{Expand}(F)$ 作依赖函数索引；因此在类型层面上，任何遗漏哪怕单个合法对手着法（包括 `pass` 或边角扑劫）的候选对象都无法通过类型检查。

<a id="thm-4-6"></a>

**定理 4.6（类型化策略证书的可靠性与 $q_{\mathrm{PSK}}$ 商等价类复用，`StrategyCertificate`；GO1）。**
给定任意证书实例 $\mathcal{D} : \mathtt{Certificate}(c,\theta,F)$（且当前帧处于计分可达状态 $\mathrm{st}\in\{\mathtt{playing},\mathtt{twoPasses}\}$）：

1. **构造性策略提取与全对手保底保证**：$\mathcal{D}$ 可构造性编译为确定性可执行策略 $\pi_{\mathcal{D}} := \operatorname{policy}(\mathcal{D})$，使得对对手的一切可执行策略 $\pi_{\bar{c}}$，原生对局执行函数 $\operatorname{exec}(F,\pi_{\mathcal{D}},\pi_{\bar{c}})$ 必在有限步到达双虚着终局盘面 $B_{\mathrm{end}}$ 并满足（当 $c=\mathrm{B}$ 时；$c=\mathrm{W}$ 方向反号）：
   $$\forall \pi_{\bar{c}},\qquad \Delta\bigl(\operatorname{exec}(F,\;\pi_{\mathcal{D}},\;\pi_{\bar{c}})\bigr) \;\ge\; \theta.\tag{4.4}$$
2. **商等价跨帧传输（`faceGuarantee`）**：若另一帧 $F'$ 满足 $F' \equiv_{\mathrm{PSK}} F$，则同一证书对象诱导商迁移策略 $\pi'_{\mathcal{D}}$，在 $F'$ 上对一切对手策略同样保证式 (4.4)。

---

<a id="sec-5"></a>

## 5 区域黑足迹极大反链、外部容量不等式与已验证 DAG 检查器

第 4 节解决了活棋终叶的免提判据；要在尚未活净的复杂角部攻防中避免展开 $19\times 19$ 全盘搜索树，还必须回答：**局部 $7\times 7$ 搜索图凭什么在不查看外部 $312$ 个交叉点的前提下，保证局部提子等于全盘提子、局部落子不触发全盘超劫、且外部任意脱先不破坏局部生存？** 本节给出回答这三个问题的三项定理（**GO3**）。

<a id="sec-5-1"></a>

### 5.1 区域限制、连通外部空间与跨界提子交换律

以下固定 $19\times 19$ 棋盘网格 $V_{19}$（通用证明对满足补集连通的任意子集成立；角部基准具体取左上角 $7\times 7$ 子网格 $R := \{0,\dots,6\}^2$，$\lvert R\rvert=49$，补集 $\lvert V_{19}\setminus R\rvert=312$）。对全盘盘面 $B$，记其在 $R$ 上的限制为 $B|_R$（将 $V_{19}\setminus R$ 置空）。

<a id="def-5-1"></a>

**定义 5.1（连通外部空间与内缩缓冲，`ExteriorSource` / `RegionProjection`）。**

1. 称真子集 $R\subsetneq V_{19}$ 具有**连通外部空间**，若补集 $V_{19}\setminus R$ 非空且在四邻接图上连通。
2. 定义 $R$ 的**内缩缓冲核**为 $\operatorname{Int}(R) := \{x\in R : \forall y\in V_{19},\, (y\sim x \implies y\in R)\}$（对左上 $7\times 7$ 区域 $R=\{0,\dots,6\}^2$，$\operatorname{Int}(R)=\{0,\dots,5\}^2$ 为左上 $6\times 6$ 子网格，四邻绝不跨出 $R$）。称全盘盘面 $B$ 的 $c$ 方棋子**内缩于 $\operatorname{Int}(R)$**，若 $S_c(B)\subseteq\operatorname{Int}(R)$。

<a id="prop-5-2"></a>

**命题 5.2（鸽笼外气守恒与跨界提子精确交换律，`ExteriorLiberty` / `RegionSparse` / `RegionCapture`；GO3）。**
设 $R\subsetneq V_{19}$ 具有连通外部空间，全盘盘面 $B$ 满足黑子内缩 $S_{\mathrm{B}}(B)\subseteq\operatorname{Int}(R)$，且全盘总占子数满足严格容量界 $\lvert\operatorname{occ}(B)\rvert < \lvert V_{19}\setminus R\rvert$。

1. **跨界白块必有外气**：任何包含某外部顶点 $z\in V_{19}\setminus R$ 的白棋连通块 $G=\operatorname{Comp}(B,z)$ 必在 $V_{19}\setminus R$ 内至少享有一口真气。
2. **黑方内缩步**。对任意空点 $x\in\operatorname{Int}(R)$，两种提子运算移除完全相同的白子，且被提子全在 $R$ 内：
   $$\operatorname{Cap}_{19}(B,\mathrm{B},x)=\operatorname{Cap}_{19}(B|_R,\mathrm{B},x),\qquad \operatorname{After}(B,\mathrm{B},x)\big|_R=\operatorname{After}(B|_R,\mathrm{B},x).\tag{5.1}$$
   外部盘面不变，且新黑块在全盘有气当且仅当在限制盘面有气。
3. **白方步**。白在 $R$ 内空点落子时，全盘后继的限制等于在 $B|_R$ 上计算的后继。落子在全盘有气，则在限制盘面也有气。白在 $R$ 外落子保持 $B|_R$。这三项只需黑子内缩于 $\operatorname{Int}(R)$。

*证明。* (1) 外部各点非白即空。含外点的白块若无外气，沿连通外部的边追踪下去，全部外点都将属于该白块，与容量界矛盾。

(2) 黑方内缩落子不会改变外部。由 (1)，跨界白块仍有真气。在外部置空的限制盘面上，从 $x$ 的邻点连到实际出界处也保有一口外气。完全处于 $R$ 的白块在两盘的有气检验一致：若它有外邻，该邻点必为空，因为外部无黑子，外部白子又会并入该白块。故有 (5.1)。新黑块全在 $\operatorname{Int}(R)$，提子后的全部邻点在两盘取值一致。

(3) 与白着邻接的黑块全在缓冲核，所有邻点都在 $R$，提子检验一致。若白从 $x\in R$ 落子后形成的全盘白块不出界，其全盘真气在限制盘面仍为空；若白块出界，从 $x$ 出发首次穿越边界处给限制盘白块留下一口外气。白落在 $R$ 外时无黑邻，因而不改变 $R$ 内任何点。$\square$

<a id="sec-5-2"></a>

### 5.2 黑足迹极大反链与失子重落超劫保鲜律

记黑子足迹列表 $\mathcal H=[M_1,\dots,M_k]$ 的下闭包为 $\downarrow\mathcal H=\{D:\exists M\in\mathcal H,\ D\subseteq M\}$。令 $\mathcal S_{\mathrm B}(F)=[S_{\mathrm B}(B'):(B',\tau')\in H(F)]$ 为历史中各盘面的全盘黑足迹。检查器比较两边下闭包：
$$\operatorname{HistoryMatches}(F,\mathcal H)\quad\Longleftrightarrow\quad\downarrow\mathcal H=\downarrow\mathcal S_{\mathrm B}(F).\tag{5.2}$$
也就是说，每一边的生成元都被另一边覆盖。只保留按包含关系极大的足迹就得到反链，检查器接受覆盖关系等价的列表。角部夹具的历史黑子都在 $R$ 内，每项可编码为 49 位掩模。插入已被覆盖的新足迹不改列表，否则移除其严格子集，再加入新足迹。

<a id="thm-5-3"></a>

**定理 5.3（足迹保持与失子重落超劫保鲜律，`RetainedCoreHistory` / `RegionalProgram`；GO3）。**
设 $\operatorname{HistoryMatches}(F,\mathcal H)$ 且当前黑子都在 $R$ 内。

1. **全盘新鲜性**。黑方在 $x\in\operatorname{Int}(R)$ 落子后，全盘新黑足迹为 $C'=S_{\mathrm B}(\operatorname{After}(B,\mathrm B,x))$，则
   $$\bigl(\forall M\in\mathcal H,\ C'\not\subseteq M\bigr)\quad\Longrightarrow\quad\operatorname{After}(B,\mathrm B,x)\notin\operatorname{set}(H(F)).\tag{5.3}$$
2. **保持性**。合法黑实着后有 $\operatorname{HistoryMatches}(F',\operatorname{insert}(\mathcal H,C'))$。若当前黑足迹已被 $\mathcal H$ 覆盖，则合法非认输白着或虚着保持 $\operatorname{HistoryMatches}$，列表无需更新。

*证明。* 重复盘面的黑足迹必已出现在 $\mathcal S_{\mathrm B}(F)$，由 (5.2) 得其已被覆盖。一步合法转移将后继盘面附加到历史，插入运算在原下闭包中接入其足迹。白方无法添加黑子，虚着不改黑子。因此当前足迹已被覆盖时，新足迹也已被覆盖。可达帧的历史记录当前盘面，白节点检查器也会显式检查这一条件。$\square$

<a id="ex-5-4"></a>

**例 5.4（8 手 $5\times 5$ 失子重落算例与 12 手基准局面的单掩模压缩）。**

1. **处女点判据失败而足迹反链成功的 8 手对局**：在 $5\times 5$ 棋盘上考察合法 8 手序列：$1.\,\mathtt{B}(0,0),\;2.\,\mathtt{W}(0,1),\;3.\,\mathtt{B}(2,0),\;4.\,\mathtt{W}(1,0)$（提去 $\mathtt{B}(0,0)$），$5.\,\mathtt{B}(1,1),\;6.\,\mathtt{W}(4,4),\;7.\,\mathtt{B}(0,2),\;8.\,\mathtt{W}(4,3)$。在历史中，黑棋足迹依次经历 $\emptyset \to \{(0,0)\} \to \{(0,0),(2,0)\} \to \{(2,0)\} \to \{(1,1),(2,0)\} \to \{(0,2),(1,1),(2,0)\}$。其极大黑足迹反链恰有两个不可比极大元：
   $$\mathcal{A}_{\mathrm{B}}(H) = \bigl[\;\{(0,2),(1,1),(2,0)\},\;\; \{(0,0),(2,0)\}\;\bigr].$$
   第 $9$ 手轮黑行棋，角点 $(0,0)$ 正是反提两枚白子 $\{(0,1),(1,0)\}$ 的急所。若用朴素“处女点检验”，因 $(0,0)$ 在第 $1$ 手下过而被误拒；而在式 (5.3) 的联合足迹反链下，黑落 $(0,0)$ 后的新黑足迹为 $C'=\{(0,0),(0,2),(1,1),(2,0)\}$，既不包含于 $\{(0,2),(1,1),(2,0)\}$（多了 $(0,0)$），也不包含于 $\{(0,0),(2,0)\}$（多了 $(0,2),(1,1)$），故定理 5.3 立即放行该反提步并保证全盘绝不触发超劫。
2. **12 手基准源 `W31` 的单掩模初值**：在第 6 节的 12 手序列 $H_{11}+\mathtt{W}(3,1)$ 中，黑棋从未被提子，历史黑足迹构成单调递增链，最终停在 $6$ 子集合 $M_{\mathrm{init}}=\{(1,0),(1,1),(1,2),(1,3),(2,1),(2,3)\}$。故整条 13 项全盘历史压缩为**单元素反链** $\mathcal{H}_{\mathrm{init}}=[M_{\mathrm{init}}]$；按 $7r+j$ 位序编码，其整数掩模恰为 $2^7+2^8+2^9+2^{10}+2^{15}+2^{17}=165{,}760$。

<a id="sec-5-3"></a>

### 5.3 外部容量—节点秩下降与已验证区域 DAG 检查器

我们将区域局部状态封装为快照 `Snapshot`，并给出已验证 DAG 检查器 `compileDAG` 的完整健全性定理（图 3(b)）。

<a id="def-5-5"></a>

**定义 5.5（区域快照、奇偶节点秩与全盘源适用谓词 `SourceAt`，`RegionalProgram`）。**
固定具有连通补集的区域 $R\subsetneq V_{19}$：

1. **区域快照与严格单步秩**：一个区域快照为四元组 $s=(B_{\mathrm{loc}},\mathcal{H},\tau,r)$，其中 $B_{\mathrm{loc}}$ 为 $R$ 上的局部盘面，$\mathcal{H}$ 为黑足迹反链，$\tau\in\{\mathrm{B},\mathrm{W}\}$ 为当前行棋方，$r\in\mathbb{N}$ 为剩余整回合预算。定义手番奇偶精细秩：
   $$\operatorname{rank}(s) := 2r + \mathbf{1}_{\tau=\mathrm{W}}.\tag{5.4}$$
   在黑走一步 `ownNext`（当 $r>0$ 时将 $r\mapsto r-1$、$\tau:\mathrm{B}\to\mathrm{W}$，故 $2r\mapsto 2(r-1)+1=2r-1$）或白走一步 `whiteNext`（保持 $r$ 不变、$\tau:\mathrm{W}\to\mathrm{B}$，故 $2r+1\mapsto 2r$）的标准局部转移下，每条有向边精确满足单位降秩：
   $$\operatorname{rank}(s_{\mathrm{child}}) + 1 = \operatorname{rank}(s_{\mathrm{parent}}).$$
2. **全盘源适用谓词 $\operatorname{SourceAt}(F,s)$**：全盘帧 $F=(B,\tau_F,p_F,\mathrm{st}_F,H_F)$ 匹配快照 $s$，若：(i) $B|_R = B_{\mathrm{loc}}$，$\tau_F=\tau$，$\mathrm{st}_F=\mathtt{playing}$，且满足单向虚着守卫 $\tau=\mathrm{W}\implies p_F=0$；(ii) $\operatorname{HistoryMatches}(F,\mathcal{H})$；(iii) 黑子内缩 $S_{\mathrm{B}}(B)\subseteq\operatorname{Int}(R)$；(iv) 全盘总占子与节点秩满足线性容量不等式 $\lvert\operatorname{occ}(B)\rvert + \operatorname{rank}(s) < \lvert V_{19}\setminus R\rvert$。

![图 3｜区域策略向全盘的提升。(a) 实际 12 手 W31 全盘，底行有四枚白子，下一黑着 E17 标在空点上。独立小图示意一种可能跨界的白链及一口外气。(b) 经查验的每条边使秩减一，占子数至多增一，两者之和始终小于 312。](figures/fig3-regional-dag.pdf)

黑选择节点 `.own(x)` 检查剩余预算、局部合法性、内缩落点、式 (5.3) 的新鲜性和后继快照。白全称节点 `.white` 检查当前黑足迹已被覆盖，比较边数，并按端口码查验每个准入端口：局部非自杀落点、`.environment` 或 `.pass`。两种节点都核对后继秩与快照。几何叶 `.coalition`、`.vital` 查验静态形状、动态保持条件与阈值。黑核内缩，眼或室全部在 $R$ 内，故叶端几何可提升到全盘。

<a id="thm-5-6"></a>

**定理 5.6（升秩单遍区域 DAG 检查器的全盘证书健全性，`RegionalProgram.compileDAG`；GO3）。**
设 $R\subsetneq V_{19}$ 具有连通补集。若 `compileDAG?` 接受候选节点数组和根索引，返回 $\mathsf{Prog}$，则对任意满足 $\operatorname{SourceAt}(F,s_{\rm root})$ 的全盘帧 $F$，`Compiled.at?` 将 $\mathsf{Prog}$ 应用于 $F$ 即产出原生证书 $\mathtt{Certificate}\;\mathrm B\;(-345)\;F$。沿经查验的图走到几何叶后始终虚着，还能保证 $R$ 内至少八点黑方面积。

*证明。* 因每条经核验边满足 $\operatorname{rank}(s_{\mathrm{child}})+1=\operatorname{rank}(s_{\mathrm{parent}})$，有向图严格无环，按 $\operatorname{rank}$ 从 $0$ 升序单遍填表时所有子节点程序均已先于父节点就绪。对秩作归纳，只需验证父帧满足 $\operatorname{SourceAt}(F,s)$ 时所有子步均合法保持 $\operatorname{SourceAt}(F',s')$。由于 $\operatorname{rank}(s)\ge 1$（内部节点），父帧自然满足 $\lvert\operatorname{occ}(B)\rvert < \lvert V_{19}\setminus R\rvert$，命题 5.2 生效：

- **`.own(x)` 节点**：局部有气加命题 5.2(2) 给出全盘落点有气与局部盘面相等；反链检验式 (5.3) 加定理 5.3(1) 保证全盘 $B'\notin\operatorname{set}(H(F))$，故全盘原生步 $\operatorname{step}(F,\mathtt{play}(x))=F'$ 合法存在，且实着自动将 $p_{F'}$ 清零，保持子快照上的 $\tau'=\mathrm{W}\implies p_{F'}=0$。由于单步落子（可能伴随提子）至多净增 $1$ 枚盘面占子，即 $\lvert\operatorname{occ}(B')\rvert \le \lvert\operatorname{occ}(B)\rvert + 1$，而 $\operatorname{rank}(s')=\operatorname{rank}(s)-1$，故核心容量不等式逐边守恒：
  $$\lvert\operatorname{occ}(B')\rvert + \operatorname{rank}(s') \;\le\; \bigl(\lvert\operatorname{occ}(B)\rvert + 1\bigr) + \bigl(\operatorname{rank}(s) - 1\bigr) \;=\; \lvert\operatorname{occ}(B)\rvert + \operatorname{rank}(s) \;<\; \lvert V_{19}\setminus R\rvert.\tag{5.5}$$
- **`.white` 节点**：取全盘 $\operatorname{Expand}(F)$ 中的任一真实合法白着 $(m,F')$。父帧满足 $\tau=\mathrm{W}\implies p_F=0$，故即便 $m=\mathtt{pass}$ 亦仅使 $p_{F'}=1<2$（仍处于 $\mathtt{playing}$），且子快照 $\tau'=\mathrm{B}$ 使蕴涵式 $\tau'=\mathrm{W}\implies p_{F'}=0$ 空真成立。三类白着均有 $\lvert\operatorname{occ}(B')\rvert \le \lvert\operatorname{occ}(B)\rvert+1$ 且 $\operatorname{rank}(s')=\operatorname{rank}(s)-1$，故式 (5.5) 同样成立：若 $m=\mathtt{play}(x)$（$x\in R$），命题 5.2(3) 保证局部盘面同步更新且命中对应局部非自杀端口；若 $m=\mathtt{play}(x)$（$x\notin R$），局部盘面与反链均不变而命中 `.environment`；若 $m=\mathtt{pass}$，命中 `.pass`。故全盘 $\operatorname{Expand}(F)$ 的每个真实分支均由已编译子证书覆盖，组装为 `.all`。
- **几何叶**。形式化构造子把经查验的几何提升到全盘。各叶的 $2\lvert P\rvert-361$ 达到 $-345$，故 $\lvert P\rvert\ge8$，且各自的 $P$ 都包含于 $R$。证明角部面积时，令黑方走图中核过的着法，将所有实际白应手送到对应的经查验边。每步秩减少，虚着守卫让内节点全都保持在对局中，所以必到达一个几何叶。此后黑方一直虚着，保持该叶的 $P$，双虚着终局时其中每点都给黑计分。形式化证书给出分差下界，具体角部面积由这里的策略和叶端几何给出。$\square$

<a id="rem-5-7"></a>

**注记 5.7（局部白端口超近似的单向健全性与 73 节点控制运行器，`RunRegionalProgram19`）。**
注意在 `.white` 节点上，检查器并未用反链去过滤白方的全盘超劫禁手，而是要求对局部盘面上的**所有**非自杀白点都备齐子证书。这在逻辑上完全健全：白方是全称对手方（$\forall$），全盘真实合法的 PSK 白着集是局部非自杀端口加 `.environment` 与 `.pass` 的**子集**；为超集备齐应对策略自然覆盖其子集（至多让局部 DAG 多准备若干全盘因白方自身超劫而走不出的防御分支），而黑方作为存在选择方（$\exists$）则必须由定理 5.3 保证所选步在全盘不违规。编译执行的回归运行器 `RunRegionalProgram19.lean` 从早期 21 手角部搜索切片（以 `B(1,1)` 起手并将 `.environment` 步依次映射为底行外点 `(18,j)`）解码一张 $73$ 节点的迷你区域 DAG，在进程内同时验证了正向编译生成 `-345` 证书以及缺漏白边、破坏降秩、清空反链与错配空盘四项负向拦截（见附录表 B.2）。

---

<a id="sec-6"></a>

## 6 $19\times 19$ 角部基准局面上的组合子与百万节点核验计算

<a id="sec-6-1"></a>

### 6.1 11 手角部基准局面、外部搜索导出与携带历史走廊引理

为在真实 $19\times 19$ 全盘规则下检验第 4–5 节的理论工具，我们构造了一个具有明确组合测试意图的 **11 手角部存活基准局面 $H_{11}$**（图 2(b)）：黑方在左上角布下 $6$ 枚棋子构成带缺口曲尺形 $\{(1,0),(1,1),(1,2),(1,3),(2,1),(2,3)\}$，白方在第 $8$ 手直接打入一线要害点 $\mathtt{W}(0,1)$（`B19`）破坏顶边成眼，其余四手白棋落在底行外区 $(18,18),(18,16),(18,14),(18,12)$（即 `T1, R1, P1, N1`）作为固定手番奇偶与全盘占子数的标准脱先填充：
$$\begin{aligned}
H_{11} := \bigl[&\mathtt{B}(1,1),\;\mathtt{W}(18,18),\;\mathtt{B}(1,2),\;\mathtt{W}(18,16),\;\mathtt{B}(1,3),\;\mathtt{W}(18,14),\\
&\mathtt{B}(1,0),\;\mathtt{W}(0,1),\;\mathtt{B}(2,3),\;\mathtt{W}(18,12),\;\mathtt{B}(2,1)\bigr].
\end{aligned}\tag{6.1}$$
走完第 $11$ 手 $\mathtt{B}(2,1)$（`B17`）后，盘面共占 $11$ 子（$6$ 黑 $5$ 白），历史列表含 $12$ 项，轮白方行棋，规则核枚举出**恰好 $351$ 个合法白方动作**（$350$ 个空点实着加 `pass`）。

当白方第 $12$ 手落入角腹紧气点（如 `W31` 即 $\mathtt{W}(3,1)=\mathtt{B16}$）时，双方在左上 $7\times 7$ 区域内展开多步提子、扑劫与做眼攻防。我们采用一条**“外部无信任关系搜索 + Lean 内核验证检查器复核”**的两阶段流程：外部 C++ 求解器在左上 $7\times 7$ 局部盘面、手番、虚着计数与 $49$ 位黑足迹反链编号构成的有限商状态图上作有界步预算的逆向 $\exists/\forall$ 不动点传播（在 `W31` 上探索 $5{,}564{,}416$ 个状态记忆项与 $4{,}035{,}761$ 条转移关系行，识别出多群护眼或驻敌要害室即停机剪枝），将求得的黑方保活子图序列化为 `corner-birth-dag/v1` 压缩 JSON 文件（`32,417,077` 字节），随后完全交由第 5.3 节的 Lean 检查器逐节点、逐有向边独立复核。

与此同时，在另两条深层应手分支 `W02`（第 $12$ 手 $\mathtt{W}(0,2)$）与 `W32`（第 $12$ 手 $\mathtt{W}(3,2)$）上，攻防沿着第一行顶边或第一列左边走廊展开（无需百万节点图，用确定性走廊递归即可闭合）。在早期未物化的函数式盘面表示下，走廊深层单次枚举全盘合法动作曾因 `Function.update` 闭包回溯停滞逾 $259\,\mathrm{s}$；切入命题 2.2(2) 的矩阵物化步消除了这一开销，而进一步沿递归显式携带已占用空点储备与历史集合则省去了重复全盘扫描：

<a id="prop-6-1"></a>

**命题 6.1（携带历史与空点储备的确定性走廊组合子，`CarriedProgram` / `Corridor`；GO8）。**
在矩阵物化步之上定义携带已见盘面集与指定区域空点储备的选步组合子 `chooseTracked?` 与全端口组合子 `allTracked?`：若每次黑方走廊防卫步均消耗至少一个储备空点或严格推进有界走廊阶段秩，且叶端接入定理 4.2–4.3 或注记 4.5 的活棋识别器，则递归良基终止并在成功时直接返回原生帧上的完整 `Certificate` 实例。

<a id="sec-6-2"></a>

### 6.2 泛外盘钩形源引理与 11–12 手全分支核验计算

在 $H_{11}$ 的 351 个合法非认输白应手中，有 343 个可由黑补 $(3,1)$ 进入下述七子源。五个左桥应手和三个深层应手见图 2(b) 与表 3。引理的起点是黑补 $(3,1)$ 后的帧，随后对该帧的白应手全称量化。

<a id="prop-6-2"></a>

**命题 6.2（七子钩形源的五形闭包，`HookSource`；GO4, GO8）。**
设 $19\times19$ 帧 $F$ 尚在对局、轮白行棋，且连续虚着数为零。左上窗口 $W_{15}=\{0,\dots,3\}^2\setminus\{(3,3)\}$ 内，黑子占 $C_7=C_6\cup\{(3,1)\}$（$C_6$ 是 $H_{11}$ 的黑核），白子占 $(0,1)$，其余为空。要求 $(0,2),(0,3),(3,0),(3,2)$ 在当前盘面及历史中均未占过黑子。外部 346 点无额外几何约束。对白方每个合法非认输应手，若白刚落 $(3,0)$，黑落 $(3,2)$；否则黑落 $(3,0)$。下一手白棋后，至少一个合法黑封口点可形成下列五种要害室几何之一（多点室可含白子）：

1. $C_7\cup\{(3,0),(0,2)\}$，围单眼 $\{(2,0)\}$ 与驻白二格室 $\{(0,0),(0,1)\}$（$\lvert P\rvert=10$）；
2. $C_7\cup\{(3,0),(0,3)\}$，围单眼 $\{(2,0)\}$ 与驻白三格室 $\{(0,0),(0,1),(0,2)\}$（$\lvert P\rvert=10$）；
3. $C_7\cup\{(3,0),(3,2)\}$，围双纯空单眼 $\{(2,0)\}$ 与 $\{(2,2)\}$（$\lvert P\rvert=11$）；
4. $C_7\cup\{(3,2),(0,2)\}$，围单眼 $\{(2,2)\}$ 与驻白二格室 $\{(0,0),(0,1)\}$（$\lvert P\rvert=10$）；
5. $C_7\cup\{(3,2),(0,3)\}$，围单眼 $\{(2,2)\}$ 与驻白三格室 $\{(0,0),(0,1),(0,2)\}$（$\lvert P\rvert=10$）；

由定理 4.3，每种几何均保证黑方至少十个角部面积点，故
$$\Delta(B_{\mathrm{end}}) \;\ge\; 2\cdot 10 - 361 \;=\; -341 \;>\; -345\tag{6.2}$$
这一分差保证由全盘策略证书给出。

表 3 列明每类后继与对应的历史运行。

<a id="comp-6-3"></a>

**核验计算 6.3（`W31` 区域 DAG 核验与 $H_{11}$ 后继证书；GO5, GO8）。**
以下保留原运行回执的身份，相关源码固定在提交 `e60a86058abcb74b7f2225f2383c182be8343785`。`original-certificate.json` 记录的大规模执行使用原 `RegionalDAGRun.lean` 与 `admittedPorts`。维护版 `RunRegionalDAG19.lean` 通过已证等价的 `captureAdmittedPorts` 消费同一工件。原回执记录的是运行进程内实际产出的类型化证书。

1. **12 手核心深层源 `W31`（$H_{11}+\mathtt{W}(3,1)$）**：流式缓存检查器 `RegionalDAGCache.compile` 在左上 $7\times 7$ 区域（反链初值 $[165{,}760]$，共出现 $249$ 种反链形状；预编译复核 $28$ 份护眼几何与 $85$ 份要害室几何，并在每个叶节点强制重检动态 `Holds`）上单遍复核全部节点与有向边，精确满足计数守恒
   $$\begin{aligned}
   \lvert V_{\mathrm{DAG}}\rvert &= 862{,}073_{\mathtt{own}} + 33{,}164_{\mathtt{white}} + 743{,}233_{\mathtt{coalition}} + 62{,}516_{\mathtt{vital}} = 1{,}700{,}986,\\
   \lvert E_{\mathrm{DAG}}\rvert &= 862{,}073_{\mathtt{own}} + 1{,}145{,}389_{\mathtt{white\text{-}ports}} = 2{,}007{,}462,
   \end{aligned}\tag{6.3}$$
   耗时 $3{,}140.66\,\mathrm{s}$、峰值内存 $7.07\,\mathrm{GB}$ RSS，在真实 12 手帧上产出 `some (Certificate B (-345) F_W31)`，首应手为黑棋三路长补 $\mathtt{B}(2,4)$（棋谱坐标 `E17`，紧邻 $\mathtt{B}(2,3)=\mathtt{D17}$ 向右延伸）。
2. **两条边线走廊深层源 `W02` 与 `W32`**：两者首应手均为 $\mathtt{B}(3,1)$（`B16`），各自独立生成完整 `Certificate B (-345)`。按日志记录的同口径纯证书构造耗时（不含构造完成后的附加端口抽检），命题 6.1 的携带历史版本将 `W02` 纯生成时间从 $2{,}030.68\,\mathrm{s}$ 降至 $1{,}748.85\,\mathrm{s}$（提速 **$13.9\%$**；含附加后验核查总墙钟为 $2{,}093.02\,\mathrm{s}$ vs. $1{,}755.62\,\mathrm{s}$），将 `W32` 纯生成时间从 $1{,}940.31\,\mathrm{s}$ 降至 $1{,}690.88\,\mathrm{s}$（提速 **$12.9\%$**；含附加后验核查总墙钟为 $1{,}988.56\,\mathrm{s}$ vs. $1{,}697.42\,\mathrm{s}$）。
3. **五个左侧近端源 `ElevenLeftBridge`（`W00, W03, W20, W22, W30`）**：黑首应手统一取 $\mathtt{B}(0,2)$（其中 `W00` 即白落角点 $(0,0)$ 后 $\mathtt{B}(0,2)$ 直接提去左上两白子，后续验满 $351$ 个白端口；其余四源各验 $348$ 个白端口），接顶边走廊或 $(3,1)/(3,3)$ 双桥见合，全部产出 `-345` 证书。
4. **总装与后继覆盖**。原 `assembly.jsonl` 记录了 351 个合法白端口、348 个已生成证书、`complete_certificate=false`，耗时 $246.337\,\mathrm{s}$。余下恰为 `W02`、`W31` 与 `W32`，各自在对应原生后继上有独立成功回执。[本次完整回执](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/evidence/certified-go/acceptance/original-source-h11-replay.json)使用同一张策略图，`ElevenAssembly.assemble` 在同一进程中取得全部 351 枚后继证书并构造父证书。`ElevenAssembly.run` 将它交给 10 手原帧的黑着 $(2,1)$，同时验证落子和完整历史。

**表 3　11 手角部基准局面 $H_{11}$ 全部 $351$ 个合法白方应手的闭合方式与核验回执汇总。**

| 分支族（白第 12 手） | 覆盖端口数 | 闭合机制与黑首应手 | 全盘分差下界 | 机器核验规模与同口径纯生成耗时 |
| --- | --- | --- | --- | --- |
| **外围分支 `HookSource`** | $343$ | $\mathtt{B}(3,1)$ 后使用命题 6.2 | 钩形源 $\Delta\ge -341$ | 与左桥同批，348 后继共 $246.337\,\mathrm s$ |
| **左桥近端 `ElevenLeftBridge`** | $5$ | $\mathtt{B}(0,2)$ 提子或双桥见合 | $\Delta\ge -345$ | `W00` 验 $351$ 端口，余四源各验 $348$ 端口 |
| **顶边深层走廊 `W02`** | $1$ | $\mathtt{B}(3,1)$ 横向走廊递归 | $\Delta\ge -345$ | 纯生成 $2{,}030.68\,\mathrm{s}\to 1{,}748.85\,\mathrm{s}$（$-13.9\%$） |
| **腹地深层走廊 `W32`** | $1$ | $\mathtt{B}(3,1)$ 纵向走廊递归 | $\Delta\ge -345$ | 纯生成 $1{,}940.31\,\mathrm{s}\to 1{,}690.88\,\mathrm{s}$（$-12.9\%$） |
| **紧气深层 DAG `W31`** | $1$ | $\mathtt{B}(2,4)$（`E17`），$7\times 7$ 反链 `[165760]` | $\Delta\ge -345$ | $1{,}700{,}986$ 节点／$2{,}007{,}462$ 边，$3{,}140.66\,\mathrm{s}$，$7.07\,\mathrm{GB}$ |

![图 4｜W31 的执行结果与验证环节。(a) 1,700,986 个核验节点、2,007,462 条有向边及几何缓存。(b) Lean 程序检查搜索图，其证书类型由内核验证。](figures/fig4-w31-certificate.pdf)

---

<a id="sec-7"></a>

## 7 增量上下界求值状态机：存在性下界与物化策略区间的类型隔离

在大型棋类形式化项目中，常容易混淆两类性质截然不同的结论：一类是第 3 节在命题层（`Prop`）通过反证与排中律证出的**非构造性存在界** $k^\star(19)\in[0,361]$；另一类是第 5–6 节在数据层（`Type`）通过显式策略树与区域 DAG 构造出的**可执行策略证书**。为防止把纯存在性定理误当作可运行下棋程序，模块 `CalculationRuntime.lean`（**GO6**）将增量求值组织为一个类型隔离的单调区间收缩状态机。

<a id="sec-7-1"></a>

### 7.1 区间收缩、游标等价与 `Prop`/`Type` 双轨隔离

记 $B_{\mathrm{exec}}=[\ell,u]\subseteq[-361,361]$ 为 $F_0(19)$ 的当前可执行区间。黑方阈值为 $\theta_{\mathrm B}$ 的回执只更新 $\ell$，白方阈值为 $\theta_{\mathrm W}$ 的回执只更新 $u$。两份回执都吸收后，有
$$\ell' := \max(\ell,\;\theta_{\mathrm{B}}) \;\le\; k^\star(19) \;\le\; \min(u,\;\theta_{\mathrm{W}}) =: u'.\tag{7.1}$$
推论 3.5 另接只读记录 `MathematicalRange`。该记录用整数保存 $0,361$，并证明任何有证据的精确初始分差都在其间。可执行初局证书由求值状态机另行接收。

<a id="thm-7-1"></a>

**定理 7.1（增量求值游标等价、单侧收据吸收与 `Prop`/`Type` 双轨隔离，`CalculationRuntime`；GO6）。**
设从初始种子状态 $\mathrm{seed}$ 出发按步数 $t\in\mathbb{N}$ 推进增量求值状态机：

1. **游标观察等价（`observe_is_original_cursor`）**：对任意步数 $t\in\mathbb{N}$，封装历史事件记录后的观察状态机与直接迭代求值游标满足精确状态相等：
   $$\operatorname{observe}(t).\mathrm{current} \;=\; \operatorname{GoalCursor.observe}(t,\operatorname{GoalCursor.seed}).\tag{7.2}$$
2. **回执吸收（`received_next`）**。求值器下一步吸收队首的类型化初局单侧回执。上下界尚未相遇时保留收紧后的区间，相遇时给出精确值。引理 3.3(2) 排除上下界逆序。较弱的回执也可被吸收，区间不缩窄。
3. **读数的共同来源（`faceAt_factorizes`）**。每次访问的公开读数均具有原游标生成的同一发生及其完整账本。读数等于该发生的对应投影，下一状态等于原程序的下一状态。这也适用于只读理论区间。

---

<a id="sec-8"></a>

## 8 文献对话、方法适用边界与结论

<a id="sec-8-1"></a>

### 8.1 对称盗策略、开局虚着与超劫计算复杂度

Zermelo [@Zermelo1913] 与 Kuhn [@Kuhn1953] 提供了逆向归纳的扩展式博弈框架，Nash [@Nash1952] 和 Gale [@Gale1979] 研究 Hex，Beck [@Beck2008] 发展占格博弈的盗策略。Weninger 与 Hayward [@WeningerHayward2017, 第 102–103 页] 的定理 1 已给出虚着豁免 PSK 下矩形棋盘的同一先手不败结论。定理 3.4 在方形棋盘上经 Lean 证明，给出从完整历史表到集合商的精确转移与策略传输。注记 3.7 对禁自杀 SSK 给出相应纸面论证。

Lichtenstein 与 Sipser [@LichtensteinSipser1980] 证明广义围棋为 PSPACE-hard。Robson 证明基本劫围棋为 EXPTIME-complete [@Robson1983]，一类采用禁重复规则的广义博弈为 EXPSPACE-complete [@Robson1984]。Hearn 与 Demaine [@HearnDemaine2009] 综述这些规则相关的复杂度结果。在计分与盘面计数方向，Berlekamp 与 Wolfe [@BerlekampWolfe1994] 研究官子，Tromp 与 Farnebäck [@TrompFarneback2007] 研究逻辑规则各变体的合法盘面数。

<a id="sec-8-2"></a>

### 8.2 静态活棋、封闭死活图历史交互与开放外部空间的全盘提升

Benson [@Benson1976] 刻画静态虚着活棋，Müller [@Muller2001; @Muller2002] 研究局部搜索与静态安全。Kishimoto 与 Müller [@KishimotoMuller2004; @KishimotoMuller2005] 用路径模拟处理 Campbell [@Campbell1985] 的图历史交互，并将其用于封闭死活题。Shih 等 [@ShihEtAl2022RelevanceZones] 的一致回放条件走出固定外墙，在 $19\times19$ 死活题和 $7\times7$ 杀尽棋中将区域外应手归类，目标为无条件活棋。他们把只能通过劫或双活达成的目标留给后续研究。

Kharma 与 Schintke [@KharmaSchintke2026Sanko, 定理 1、引理 1] 证明已解 PSK 策略可在不同历史之间非对称传输，并使用整室邻接的纯眼。其静态计分策略在必要时主动提敌子，条件涉及早先的提子以及能否立即双虚着终局。本文的几何闭包通过虚着即可保证面积，在已有一次虚着的帧上也成立。区域检查器连接这些几何叶、用于黑方保鲜的精确足迹包含查询，以及连通外部容量证明，从而覆盖其适用范围内全部合法的全盘白应手。

<a id="sec-8-3"></a>

### 8.3 大型棋类求解、现代神经网络搜索与已验证证书检查器

Van der Werf、van den Herik 与 Uiterwijk [@VanDerWerf2003] 给出小盘精确解并分列不同劫规则的结果。矩形盘的 MIGOS 结果采用基本劫并配额外的循环规则 [@VanDerWerfWinands2009]。Sanko 采用与本文相同的禁自杀、虚着豁免 PSK 和双虚着面积计分，确认 $5\times5$ 的最优分差为 25，并证实 $4\times7$ 分差为 12；MIGOS 在自己的规则下算得 28 [@KharmaSchintke2026Sanko, 第 6–7 节]。Schaeffer 等 [@Schaeffer2007Checkers] 结合残局库与搜索取得 $8\times8$ 西洋跳棋的弱解。AlphaGo、AlphaGo Zero 与 KataGo 用统计搜索和学习估值处理全盘实战 [@Silver2016AlphaGo; @Silver2017AlphaGoZero; @Wu2019KataGo]。

在形式化验证与认证算法谱系中，Necula 与 Lee [@NeculaLee1996PCC; @Necula1997] 提出了证明携带代码（PCC），McConnell 等人 [@McConnell2011Certifying] 系统总结了认证算法范式，Gonthier [@Gonthier2008] 与 Hales 等人 [@Hales2017Kepler] 完成了四色定理与开普勒猜想的内核计算证明，Cruz-Filipe 等人 [@CruzFilipe2017LRAT] 与 Tan、Heule 和 Myreen [@TanHeuleMyreen2021CakeLPR] 则把不可信 SAT 求解器的百万行反驳日志交由已验证检查器认证。本文把这一“不可信外部搜索 + 已验证检查器”范式推进至**带交替量词（$\exists/\forall$）、全局历史禁手与开放外部空间的 $19\times 19$ 博弈图**。表 4 在五个正交维度上汇总了本文与代表性前人工作的精确对比。

**表 4　本文与组合博弈盗策略、局部死活 GHI、棋类求解、神经网络引擎及认证检查器的五维对比。**

| 代表性工作 | 规则模型与棋盘尺度 | 局部活棋与区域外交互假设 | 盘面重复／GHI 处理机制 | 验证层级与输出保证 |
| --- | --- | --- | --- | --- |
| Weninger 与 Hayward [@WeningerHayward2017] | 任意矩形 PSK 棋盘 | 空盘首虚与颜色反演 | 精确过往盘面集合 | 先手不败的数学证明 |
| Nash（1952）、Gale（1979）与 Beck（2008）[@Nash1952; @Gale1979; @Beck2008] | Hex 与单调占格棋类 | 增加己方子不破坏取胜条件 | 棋子不会离盘 | 盗策略证明 |
| Benson (1976) [@Benson1976] | 围棋静态虚着无条件活棋，任意尺寸 | 单方纯静态安全链与封闭要害域 | 仅静态判据，无动态落子搜索树 | 纸面充要定理：核心链永不被提（未区分无清死面积公气） |
| Kishimoto & Müller (2004, 2005) [@KishimotoMuller2004; @KishimotoMuller2005] | 封闭边界局部死活问题（TsumeGo） | 假定包围外墙安全，不展开全盘外点 | 搜索表模拟关系消除局部图内 GHI | 未经定理证明器核验的专用求解器：局部死活判定 |
| Shih 等 [@ShihEtAl2022RelevanceZones] | 含 $19\times19$ 的死活题与 $7\times7$ 杀尽棋 | 关联区域与一致回放 | 无条件活棋目标 | 局部达成目标的策略树 |
| van der Werf 等 [@VanDerWerf2003; @VanDerWerfWinands2009] | 方形与矩形小盘，主要采用基本劫 | 全盘 $\alpha\beta$ 搜索 | 依约定的循环规则 | 给出所选规则的精确值 |
| Kharma 与 Schintke [@KharmaSchintke2026Sanko] | 禁自杀 PSK，小型全盘 | 纯眼与局部博弈 | 非对称证明传输 | 健全性数学证明与可复现求解器结果 |
| Schaeffer et al. (2007) [@Schaeffer2007Checkers] | $8\times 8$ 西洋跳棋（约 $5\times 10^{20}$ 状态） | 全盘吃子规则与逆向残局库 | 跳棋循环和棋与搜索图 GHI 处理 | 未经定理证明器核验的专用求解器：初局必和弱解 |
| Silver et al. (2016, 2017); Wu (2019) [@Silver2016AlphaGo; @Silver2017AlphaGoZero; @Wu2019KataGo] | $19\times 19$ 全盘围棋（多规则面积／目数） | 全盘价值头与领地头统计推理 | 有限步历史特征平面，无全史硬约束 | 无最坏情形下界证明：策略先验与连续胜率／目数期望 |
| Cruz-Filipe et al. (2017); Tan et al. (2021) [@CruzFilipe2017LRAT; @TanHeuleMyreen2021CakeLPR] | 百万子句级布尔 CNF 公式 | 纯命题公式，无空间区域或外点 | 静态子句推导序列，无 $\exists/\forall$ 交替手番 | Coq/ACL2 提取检查器或 CakeML 编译级验证：UNSAT 证明 |
| 本文（GO1–GO8） | 禁自杀虚着豁免 PSK，任意方盘及 $19\times19$ 角部 | 驻敌要害室与连通外部容量 | 全盘强双模拟与精确足迹查询 | Lean 证明及 170 万节点证书运行 |

<a id="sec-8-4"></a>

### 8.4 方法适用边界、开放问题与结论

区域检查器接收选定的区域，并在黑子各邻点都位于区域内时把局部几何提升到全盘。$19\times19$ 实现的证书阈值是 $\Delta\ge-345$，第 5.3 节的几何叶论证给出区域内至少八点的面积保证。角部基准从有固定前缀的局面出发，给出单侧分差界。$19\times19$ 空盘的精确分差，以及先手不败定理对应的可执行初局策略，仍为开放问题。

贯通两项结果的是各自所需的历史信息。曾见盘面的精确成员关系支持全盘转移传输；区域下界只需新黑足迹在历史包含查询中返回否定，且每个实际白应手都可映到经查验的边。这使未经信任的大规模搜索图能够生成遵守原规则的 Lean 策略证书。

---

<a id="sec-app-a"></a>

## 附录 A 有限视野经典扩展式双向恢复、策略式等价与劫循环和乐（GO7）

正篇第 2–7 节直接在原生规则核 `RulesKernel` 与历史帧 `Frame n` 上陈述证明。本附录简述公开仓 `H0mework` 中连接该表示与 Kuhn [@Kuhn1953] 经典扩展式／策略式博弈的两条双向恢复定理（**GO7**），并给出投影劫循环不可降维为单值势函数的几何旁证。

对任意棋盘边长 $n\in\mathbb{N}$、规则 $\mathcal{L}$、从初局生成的合法历史回放 $\mathcal{R} : \mathtt{GeneratedReplay}\;\mathcal{L}\;(F_0(n))\;\mathit{moves}$ 及任意有限观察视野 $h\in\mathbb{N}$：

<a id="prop-a-1"></a>

**命题 A.1（任意有限视野下源生有界续行与经典扩展式历史的双向恢复，`ClassicalGameRecovery`；GO7）。**
由回放 $\mathcal R$ 和视野 $h$ 生成的 $G_{\mathrm{ext}}=\mathtt{recoverExtensiveGame}(\mathcal R,h)$，其状态树与 `futureConeAt R h` 定义相等。每个容许历史 $w$ 从 $\mathcal R.\mathtt{final}$ 重构一条 `GeneratedReplay` 续行，到达 $w.\mathtt{current}$，且整条状态迹是树的一条分支。沿着着法字归纳可得唯一性：`nativeStep?` 决定下一帧，合法性证明项无关。反之，每个长度至多 $h$ 的源生续行典范地给出同终帧的容许历史。

<a id="prop-a-2"></a>

**命题 A.2（同可见终局跨发生路径的保身份策略式等价传输，`NormalFormEquivalence.terminalNormalFormEquivalence`；GO7）。**
设同一规则下两条合法回放 $\mathcal{R}_L$ 与 $\mathcal{R}_R$ 到达相同的可见**终局**状态（$\mathcal{R}_L.\mathtt{final.visible} = \mathcal{R}_R.\mathtt{final.visible}$ 且处于 `.terminal`）。则对任意视野 $h\in\mathbb{N}$，存在由参与者双射 $\phi_P$、纯策略双射 $\phi_S$ 与策略组合双射 $\phi_{\Pi}$ 组成的类型化跨发生传输算子 $\Phi$，使得对一切策略组合 $\pi$ 与参与者 $i$ 保持效用读数：
$$u_R\bigl(\phi_{\Pi}(\pi),\;\phi_P(i)\bigr) = u_L(\pi,\;i),\tag{A.1}$$
同时保留 $\mathcal{R}_L$ 与 $\mathcal{R}_R$ 各自的独立历史身份（而在未终局的中间态上，正如例 2.3 中从空盘合法可达的 5 手 $\gamma_1$ 与 7 手 $\gamma_2$ 所示，相同可见盘面会因历史不同而分岔出不等的后续合法动作集）。

<a id="rem-a-3"></a>

**注记 A.3（可达劫循环不可表示为可见盘面单值势函数差分的离散和乐旁证，`Ko/PrincipalHolonomy`）。**
在 $3\times3$ 可达实例中，回路片段依次为 $\mathtt B(0,1)$ 提劫、$\mathtt W(2,2)$ 外着、黑方虚着、$\mathtt W(0,0)$ 回提。劫口五点及行棋方回复原状，外部盘面和历史已经改变。对基本劫、PSK、SSK，`PrincipalHolonomy.lean` 给出回路的非单位 $C_4$ 相位，并证明三角回路和乐非平凡。该投影转移余链无法写成一阶上边缘，因为上边缘沿闭投影回路的乘积恒为单位元。

---

<a id="sec-app-b"></a>

## 附录 B Lean 4 核心声明、源码模块与执行回执映射表（GO1–GO8）

表 B.1 列出研究纪元的原模块名。[公开来源映射](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-map.json)登记实际公开模块、声明与原始回执。表 B.2 汇总六类回归控制。

**表 B.1　命题编号 GO1–GO8 与正文环境、Lean 4 源码模块及核验消费者的逐项映射。**

| 编号 | 正文位置 | 原 Lean 4 模块 | 关键类型与定理声明 | 直接核验／回归消费者 |
| --- | --- | --- | --- | --- |
| **GO1** | 定理 4.6（§4.3） | `BoardKernel.lean`、`RulesKernel.lean`、`ScoreReadout.lean`、`CriticalKomi/StrategyCertificate.lean` | `Certificate`, `Certificate.closed`, `Certificate.policy`, `Certificate.guarantee`, `Certificate.faceGuarantee` | `InitialColourPass.initial_nonnegative_policy`, `Regression/CriticalKomi/Audit.lean` |
| **GO2** | 引理 3.1–3.3、定理 3.4、推论 3.5（§3） | `CriticalKomi/PositionFace.lean`、`Termination.lean`、`InitialColourPass.lean` | `PositionFace.legalStep_lift`, `terminationRank`, `forcing_dichotomy`, `initial_not_white_negative`, `initial_nonnegative_certificate`, `exact_value_bounds` | `CalculationRuntime.mathematicalRange`, `Audit.lean` |
| **GO3** | 定义 5.1, 5.5、命题 5.2、定理 5.3, 5.6（§5） | `CriticalKomi/RegionProjection.lean`、`ExteriorLiberty.lean`、`RegionSparse.lean`、`CoreHistory.lean`、`RetainedCoreHistory.lean`、`RegionalProgram.lean` | `own_board_exact`, `HistoryMatches.step`, `HistoryMatches.after_subset`, `SourceAt`, `SourceAt.credit_step`, `compileNode?`, `compileDAG`, `Compiled.at?` | `Regression/CriticalKomi/RunRegionalProgram19.lean`, `RunRegionalDAG19.lean`, `Audit.lean` |
| **GO4** | 定理 4.2, 4.3（§4.1–4.2）、命题 6.2（§6.2） | `CriticalKomi/EyeCoalition.lean`、`VitalChambers.lean`、`VitalBirthRecognize.lean`、`HookSource.lean` | `EyeCoalition.Geometry`, `EyeCoalition.closed`, `VitalChambers.Geometry`, `VitalChambers.closed`, `VitalChambers.points_area`, `plan_area_le_possible`, `VitalBirth.miaiCertificate`, `HookSource.certificate?` | `StrategyCertificate.lean`, `SourceLeaf.lean`, `RunEyeCoalition19.lean`, `RunVitalChambers19.lean`, `RunHookSource19.lean` |
| **GO5** | 核验计算 6.3、表 3（§6.2） | `CriticalKomi/RegionalProgramCache.lean`、`Regression/CriticalKomi/RunRegionalDAG19.lean` | `RegionalDAGCache.compile`, `RegionalDAGCache.Provider`, `RunRegionalDAG19.run` | 已跟踪回执 `results/retained-w31/original-certificate.json` 与 `original-certificate.log`（`1,700,986` 节点，`exit 0`） |
| **GO6** | 定理 7.1（§7.1） | `CriticalKomi/GoalBracket.lean`、`GoalCursor.lean`、`CalculationRuntime.lean` | `Bracket.absorb`, `authoritativeRoot`, `observe_is_original_cursor`, `faceAt_factorizes`, `received_next`, `mathematicalRange` | `Regression/CriticalKomi/RunCalculation.lean`, `RunInitialBoundReceipt19.lean` |
| **GO7** | 命题 A.1–A.2、注记 A.3（附录 A） | `Classical/ClassicalGameRecovery.lean`、`NormalFormEquivalence.lean`、`Ko/PrincipalHolonomy.lean` | `recoverExtensiveGame`, `History.factors_through_stateTree`, `terminalNormalFormEquivalence`, `koPrincipalConnection_not_flat`, `koPrincipalTransition_not_oneCoboundary` | `G7ClassicalGameRecoveryRegression.lean`, `G5PrincipalHolonomyRegression.lean` |
| **GO8** | 命题 2.2、例 2.3（§2.2–2.3）、命题 6.1–6.2、核验计算 6.3（§6） | `CriticalKomi/MaterializedStep.lean`、`CarriedProgram.lean`、`ElevenLeftBridge.lean`、`ElevenW02.lean`、`ElevenW32.lean` | `MaterializedStep.step_eq`, `scoring_eq`, `chooseTracked?`, `allTracked?`, `ElevenLeftBridge.recognize?`, `ElevenW02.certificate?`, `ElevenW32.certificate?`, `provider_at_eq` | `RunMaterializedStep19.lean`, `RunElevenLeftBridge19.lean`, `ElevenAssembly.lean`, 回执 `w02-spine.jsonl`, `w02-carried.jsonl`, `Eleven-W32-carried.log`, `assembly.jsonl` |

**表 B.2　区域 DAG 检查器与回归套件中的负向拦截测试矩阵。**

| 测试类别与所在模块 | 构造的越权或损坏输入 | 拦截守卫与实际机器核验结果 |
| --- | --- | --- |
| **同盘异史全局 PSK 拦截**（`RunMaterializedStep19`） | 13 手帧 $F_{13}$ 追加目标签名得 $F'_{13}$，测试 `W(0,3)` 与 `pass` | `W(0,3)` 返回 `none`（拦截重复盘面）；`pass` 返回 `some`（保留虚着豁免） |
| **缺漏白方端口边**（`RunRegionalProgram19.runDAG`） | 对 $73$ 节点 DAG 每个 `.white` 节点删去末条边（`edges.dropLast`） | `compileNode?` 处 `edges.length = ports.length` 失败，`compileDAG?` 返回 `none` |
| **破坏严格降秩**（`RunRegionalProgram19.runDAG`） | 将节点 `remaining` 置 $0$（`brokenRank`） | `checkedEdge?` 处 `child.rank + 1 = parent.rank` 失败，`compileDAG?` 返回 `none` |
| **清空历史反链**（`RunRegionalProgram19.run`） | 在 `W31` 12 手源上用空反链 `[]` 替代 `[165760]` | `HistoryMatches frame .positive []` 判定为 `false`，`ownStep?` 返回 `none` |
| **错配初局空盘**（`RunRegionalProgram19` / `RunRegionalDAG19`） | 将已编译的 $73$ 节点或 $1.70\times 10^6$ 节点 `Provider` 作用于 `Frame.initial 19` | `sourceAt?` 区域盘面限制不匹配，返回 `none` |
| **篡改缓存眼位／满白室**（`RunRegionalDAG19`） | 向缓存注入白占眼 `invadedBoard` 或全白室 `occupiedBoard` | `coalitionAt?` 与 `compileVital?` 因逐叶重检 `Holds` 失败全部返回 `none` |

---

<a id="sec-app-c"></a>

## 附录 C 经典逻辑排中律的作用边界与代码生成隔离

<a id="prop-c-1"></a>

**命题 C.1（`Prop` 确定性层与 `Type` 可执行证书层的单向公理边界）。**

1. **可执行检查与策略生成**。检查器及策略程序通过判定过程计算连通块、合法性、足迹包含、边、几何叶与后继着法。运行时无需经典选择提供见证。局部可判定实例在提供的列表和有限集上计算。
2. **存在命题与可计算数据**。`forcing_dichotomy` 与 `Forces.certificate_nonempty` 证明命题层的存在性。Lean 限制直接把 `Nonempty T` 消去到 `T`；显式调用 `Classical.choice` 可构造不可计算项，但计算依赖该项时不能得到可运行策略。`mathematicalRange` 保存整数边界与正确性证明，状态机的可执行区间吸收类型化证书。

---

<!-- code-availability:begin -->
## 代码与数据可得性

H0mework 固定提交 [5190af978f01](https://github.com/Sapientropic/H0mework/tree/5190af978f01c121d50244e34ce538c3b5054f44) 保存本文的 Lean 4 证明、独立消费者与原始证据。[GO1–GO8 映射](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-map.json)逐项登记原声明与公开模块。[选集](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/checks/certified-go-selection.json)保留完整依赖、73 节点对照、W31 原策略图和各历史执行回执。按[复现指南](https://github.com/Sapientropic/H0mework/blob/5190af978f01c121d50244e34ce538c3b5054f44/docs/certified-go-reproduction.md)还原原目录，运行 `lake -d Lean build CertifiedGo` 并核对声明类型与公理依赖。仓库固定 Lean 4 v4.33.0 与 Mathlib 版本。独立 Python 复算和可编辑图件随论文源码包提供。
<!-- code-availability:end -->

## 参考文献

[Zermelo1913] Zermelo, E. Über eine Anwendung der Mengenlehre auf die Theorie des Schachspiels. In *Proceedings of the Fifth International Congress of Mathematicians (Cambridge, 1912)*, Vol. **2**, Cambridge University Press (1913), 501–504.

[Nash1952] Nash, J. F. *Some Games and Machines for Playing Them*. Research Memorandum D-1164, The RAND Corporation, Santa Monica, CA (1952).

[Kuhn1953] Kuhn, H. W. Extensive Games and the Problem of Information. In *Contributions to the Theory of Games, Volume II*, Annals of Mathematics Studies **28**, Princeton University Press (1953), 193–216. DOI: [10.1515/9781400881970-012](https://doi.org/10.1515/9781400881970-012).

[Gale1979] Gale, D. The Game of Hex and the Brouwer Fixed-Point Theorem. *The American Mathematical Monthly*, **86**(10) (1979), 818–827. DOI: [10.1080/00029890.1979.11994922](https://doi.org/10.1080/00029890.1979.11994922).

[Beck2008] Beck, J. *Combinatorial Games: Tic-Tac-Toe Theory*. Encyclopedia of Mathematics and its Applications **114**, Cambridge University Press, Cambridge (2008). DOI: [10.1017/CBO9780511735202](https://doi.org/10.1017/CBO9780511735202).

[BerlekampWolfe1994] Berlekamp, E., and Wolfe, D. *Mathematical Go: Chilling Gets the Last Point*. A K Peters, Wellesley, MA (1994). ISBN: 978-1-56881-032-4.

[Allis1994] Allis, L. V. *Searching for Solutions in Games and Artificial Intelligence*. PhD Thesis, Rijksuniversiteit Limburg (Maastricht University) (1994). ISBN: 90-9007488-0.

[TrompFarneback2007] Tromp, J., and Farnebäck, G. Combinatorics of Go. In *Computers and Games (CG 2006)*, LNCS **4630**, Springer (2007), 84–99. DOI: [10.1007/978-3-540-75538-8_8](https://doi.org/10.1007/978-3-540-75538-8_8).

[WeningerHayward2017] Weninger, N., and Hayward, R. Exploring Positional Linear Go. In *Advances in Computer Games (ACG 2017)*, LNCS **10664**, Springer (2017), 101–114. DOI: [10.1007/978-3-319-71649-7_9](https://doi.org/10.1007/978-3-319-71649-7_9).

[Tromp2x2PSK] Tromp, J. *Solving 2x2 Go*. Program and game tree. [Project page](https://tromp.github.io/java/go/twoxtwo.html).

[ShihEtAl2022RelevanceZones] Shih, C.-C., Wu, T.-R., Wei, T. H., and Wu, I.-C. A Novel Approach to Solving Goal-Achieving Problems for Board Games. *Proceedings of the AAAI Conference on Artificial Intelligence*, **36**(9) (2022), 10362–10369. DOI: [10.1609/aaai.v36i9.21278](https://doi.org/10.1609/aaai.v36i9.21278).

[KharmaSchintke2026Sanko] Kharma, S., and Schintke, F. *Solving Go under Positional Superko: Sound Proof Transfer and New Board Values*. arXiv:2610.29414 (2026). [Preprint](https://arxiv.org/abs/2610.29414v1).

[LichtensteinSipser1980] Lichtenstein, D., and Sipser, M. GO Is Polynomial-Space Hard. *Journal of the ACM*, **27**(2) (1980), 393–401. DOI: [10.1145/322186.322201](https://doi.org/10.1145/322186.322201).

[Robson1983] Robson, J. M. The Complexity of Go. In *Information Processing 83: Proceedings of the IFIP 9th World Computer Congress*, North-Holland (1983), 413–417.

[Robson1984] Robson, J. M. Combinatorial Games with Exponential Space Complete Decision Problems. In *Mathematical Foundations of Computer Science 1984 (MFCS ’84)*, LNCS **176**, Springer (1984), 498–506. DOI: [10.1007/BFb0030333](https://doi.org/10.1007/BFb0030333).

[HearnDemaine2009] Hearn, R. A., and Demaine, E. D. *Games, Puzzles, and Computation*. A K Peters, Wellesley, MA (2009). ISBN: 978-1-56881-322-6.

[Benson1976] Benson, D. B. Life in the Game of Go. *Information Sciences*, **10**(1) (1976), 17–29. DOI: [10.1016/0020-0255(76)90059-1](https://doi.org/10.1016/0020-0255(76)90059-1).

[Muller2001] Müller, M. Global and Local Game Tree Search. *Information Sciences*, **135**(3–4) (2001), 187–206. DOI: [10.1016/S0020-0255(01)00136-0](https://doi.org/10.1016/S0020-0255(01)00136-0).

[Muller2002] Müller, M. Computer Go. *Artificial Intelligence*, **134**(1–2) (2002), 145–179. DOI: [10.1016/S0004-3702(01)00121-7](https://doi.org/10.1016/S0004-3702(01)00121-7).

[Campbell1985] Campbell, M. S. The Graph-History Interaction: On Ignoring Position History. In *Proceedings of the 1985 ACM Annual Conference on the Range of Computing: Mid-80’s Perspective*, ACM (1985), 278–280. ISBN: 0-89791-170-9.

[VanDerWerf2003] van der Werf, E. C. D., van den Herik, H. J., and Uiterwijk, J. W. H. M. Solving Go on Small Boards. *ICGA Journal*, **26**(2) (2003), 92–107. DOI: [10.3233/ICG-2003-26205](https://doi.org/10.3233/ICG-2003-26205).

[VanDerWerfWinands2009] van der Werf, E. C. D., and Winands, M. H. M. Solving Go for Rectangular Boards. *ICGA Journal*, **32**(2) (2009), 77–88. DOI: [10.3233/ICG-2009-32203](https://doi.org/10.3233/ICG-2009-32203).

[KishimotoMuller2004] Kishimoto, A., and Müller, M. A General Solution to the Graph History Interaction Problem. In *Proceedings of the Nineteenth National Conference on Artificial Intelligence (AAAI-04)*, AAAI Press (2004), 644–649.

[KishimotoMuller2005] Kishimoto, A., and Müller, M. Search versus Knowledge for Solving Life and Death Problems in Go. In *Proceedings of the Twentieth National Conference on Artificial Intelligence (AAAI-05)*, AAAI Press (2005), 1374–1379.

[Schaeffer2007Checkers] Schaeffer, J., Burch, N., Björnsson, Y., Kishimoto, A., Müller, M., Lake, R., Lu, P., and Sutphen, S. Checkers Is Solved. *Science*, **317**(5844) (2007), 1518–1522. DOI: [10.1126/science.1144079](https://doi.org/10.1126/science.1144079).

[Silver2016AlphaGo] Silver, D., Huang, A., Maddison, C. J., Guez, A., Sifre, L., van den Driessche, G., Schrittwieser, J., Antonoglou, I., Panneershelvam, V., Lanctot, M., Dieleman, S., Grewe, D., Nham, J., Kalchbrenner, N., Sutskever, I., Lillicrap, T., Leach, M., Kavukcuoglu, K., Graepel, T., and Hassabis, D. Mastering the Game of Go with Deep Neural Networks and Tree Search. *Nature*, **529**(7587) (2016), 484–489. DOI: [10.1038/nature16961](https://doi.org/10.1038/nature16961).

[Silver2017AlphaGoZero] Silver, D., Schrittwieser, J., Simonyan, K., Antonoglou, I., Huang, A., Guez, A., Hubert, T., Baker, L., Lai, M., Bolton, A., Chen, Y., Lillicrap, T., Hui, F., Sifre, L., van den Driessche, G., Graepel, T., and Hassabis, D. Mastering the Game of Go Without Human Knowledge. *Nature*, **550**(7676) (2017), 354–359. DOI: [10.1038/nature24270](https://doi.org/10.1038/nature24270).

[Wu2019KataGo] Wu, D. J. Accelerating Self-Play Learning in Go. Preprint, arXiv:1902.10565 (2019). DOI: [10.48550/arXiv.1902.10565](https://doi.org/10.48550/arXiv.1902.10565).

[NeculaLee1996PCC] Necula, G. C., and Lee, P. Safe Kernel Extensions Without Run-Time Checking. In *Proceedings of the Second USENIX Symposium on Operating Systems Design and Implementation (OSDI ’96)*, ACM (1996), 229–243. DOI: [10.1145/238721.238781](https://doi.org/10.1145/238721.238781).

[Necula1997] Necula, G. C. Proof-Carrying Code. In *Proceedings of the 24th ACM SIGPLAN-SIGACT Symposium on Principles of Programming Languages (POPL ’97)*, ACM (1997), 106–119. DOI: [10.1145/263699.263712](https://doi.org/10.1145/263699.263712).

[Gonthier2008] Gonthier, G. Formal Proof—The Four-Color Theorem. *Notices of the American Mathematical Society*, **55**(11) (2008), 1382–1393. URL: [https://www.ams.org/notices/200811/tx081101382p.pdf](https://www.ams.org/notices/200811/tx081101382p.pdf).

[McConnell2011Certifying] McConnell, R. M., Mehlhorn, K., Näher, S., and Schweitzer, P. Certifying Algorithms. *Computer Science Review*, **5**(2) (2011), 119–161. DOI: [10.1016/j.cosrev.2010.09.009](https://doi.org/10.1016/j.cosrev.2010.09.009).

[Hales2017Kepler] Hales, T., Adams, M., Bauer, G., Dang, T. D., Harrison, J., Hoang, L. T., Kaliszyk, C., Magron, V., McLaughlin, S., Nguyen, T. T., Nguyen, Q. T., Nipkow, T., Obua, S., Pleso, J., Rute, J., Solovyev, A., Ta, T. H. A., Tran, N. T., Trieu, T. D., Urban, J., Vu, K., and Zumkeller, R. A Formal Proof of the Kepler Conjecture. *Forum of Mathematics, Pi*, **5** (2017), e2. DOI: [10.1017/fmp.2017.1](https://doi.org/10.1017/fmp.2017.1).

[CruzFilipe2017LRAT] Cruz-Filipe, L., Heule, M., Hunt, Jr., W. A., Kaufmann, M., and Schneider-Kamp, P. Efficient Certified RAT Verification. In *Automated Deduction – CADE 26*, LNCS **10395**, Springer (2017), 220–236. DOI: [10.1007/978-3-319-63046-5_14](https://doi.org/10.1007/978-3-319-63046-5_14).

[TanHeuleMyreen2021CakeLPR] Tan, Y. K., Heule, M. J. H., and Myreen, M. O. cake_lpr: Verified Propagation Redundancy Checking in CakeML. In *Tools and Algorithms for the Construction and Analysis of Systems (TACAS 2021)*, LNCS **12652**, Springer (2021), 223–241. DOI: [10.1007/978-3-030-72013-1_12](https://doi.org/10.1007/978-3-030-72013-1_12).

[deMouraUllrich2021Lean4] de Moura, L., and Ullrich, S. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, LNCS **12699**, Springer (2021), 625–635. DOI: [10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[mathlib2020] The mathlib Community. The Lean Mathematical Library. In *Proceedings of the 9th ACM SIGPLAN International Conference on Certified Programs and Proofs (CPP 2020)*, ACM (2020), 367–381. DOI: [10.1145/3372885.3373824](https://doi.org/10.1145/3372885.3373824).

[Gao2026OneBitV2] 高健（Jian Gao）. *现实刚性与单母源普遍形成：无账外差异的零公理构造、因果准入与统一演化*（*Ontological Rigidity and Universal Single-Mother Formation*）. 第二版（v2），Zenodo，2026. DOI: [10.5281/zenodo.24135399](https://doi.org/10.5281/zenodo.24135399).

[Gao2026SourceProcessCoreV3] 高健（Jian Gao）. *源生过程代数与初始余面修订：四层同一性、正合求值核与可逆增量续行*（*Source-Native Process Algebra and Initial-Coface Revision*）. 第三版（v3），Zenodo，2026. DOI: [10.5281/zenodo.24147130](https://doi.org/10.5281/zenodo.24147130).

[Gao2026WholeLedgerV2] 高健（Jian Gao）. *溯源守恒演算与非免费连续性：全事件账本、观察安全与良基结清*（*Provenance-Preserving Conservation Calculus and Non-Free Continuity*）. 第二版（v2），Zenodo，2026. DOI: [10.5281/zenodo.24147183](https://doi.org/10.5281/zenodo.24147183).
