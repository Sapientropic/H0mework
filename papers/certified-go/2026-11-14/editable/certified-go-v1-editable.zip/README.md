# Certified Go · editable source

The archive contains both manuscripts, the bibliography, the four bilingual
vector figures and the inputs to the reading-PDF builder. Start at the extracted
root. The reading build uses Python 3, Pandoc, XeLaTeX, xeCJK and the Noto
Serif/Sans CJK SC fonts in the font locations used by the shared builder.

    python3 papers/certified-go/scripts/build_pdf.py --lang both
    python3 papers/certified-go/validation/verify_manuscript.py

The vector PDFs are included. To regenerate the figures on macOS, install
Chrome, STIX Two and the Noto CJK fonts, and add fontTools to your Python
environment before running:

    python3 papers/certified-go/figures/make_figures.py

Appendix B and Code and Data Availability identify the formalization and the
fixed public inputs. The independent Python check optionally cross-checks the
executions after obtaining their original records from the proof repository:

    python3 papers/certified-go/validation/verify_manuscript.py --receipts \
      original-certificate.json assembly.jsonl w02-carried.jsonl Eleven-W32-carried.log

The same checker verifies the new full assembly using
`--complete-replay original-source-h11-replay.json original-source-h11-replay.log`.

The preprint and figures use CC BY 4.0. Formalization in H0mework follows the
repository's Apache-2.0 license.
