# The Structural Theorem of Capitalism — editable bundle

Open [the rebuild guide](papers/capital-formation/packaging-README.md) for contents, requirements and commands. The paper and shared dependency directories retain their relative layout.
