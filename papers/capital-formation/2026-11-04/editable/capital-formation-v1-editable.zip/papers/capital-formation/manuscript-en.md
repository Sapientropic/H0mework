# The Structural Theorem of Capitalism

## Full Structural Characterization, Public Replacement, and Joint Settlement

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

This paper proves a structural theorem covering all forms of capitalism: the complete exclusion of capital relations has the absence of asymmetry in permissions as its minimal support; every actual capital relation can be reconstructed from its own evidence of production, dependence, and control, and can enter a common social contract for termination and continuation. Coverage comes from universal proofs over laws, constructor types, execution sequences, and actual histories. For any production sequence, public replay preserves the full successor state, actual physical quantities, provision for every member's living and maintenance needs, and task services, while eliminating capital control. From any point in an actual run, a disposition procedure produces either a witness of complete abolition or a specific obstruction within a finite number of steps determined by the current internal workload. Success jointly preserves members' independent execution, productive capacity, executable futures, and full-account non-loss for every person and good, together with a strict gain; failure retains the precise responsibility and an entry for continuation. Debt not represented at the financial entry appears as a specific matrix discrepancy. Mechanisms fixed before unknown events support paid local information, real risk settlement, and continuing innovation beyond the quoted menu; throughout any actual continuation, cumulative receipts for one contribution origin across all account positions cannot exceed its issued quantity. Complete responsibilities are carried through coalitions, open mechanisms, and institutional changes, without requiring the existing ledger to be finite. For settlement costs, a financial tail with sufficient resources has an actual optimum, while another complete settlement domain supplies a strictly cheaper complete settlement for every completing candidate. By distinguishing the grounds of basic participation, repayment for contributions, and continuing control, the paper connects these results to theories of production relations, property rights, innovation, and common governance. It shows how production can continue while domination ceases to acquire permanent standing from the necessity of its functions.

**Keywords:** capital relations; production relations; permission asymmetry; public replacement; social reproduction; contribution settlement; institutional change

## 1 How Production Can Continue When Capital Ends

A production organization operates through equipment, methods, labor, finance, and continuing maintenance. Workers need access to materials and also need to continue living after leaving their jobs. Funds already supplied must be settled according to the undertaking made. New discoveries may require changes to production. If the controller of equipment may enter a stage of production while excluding people who depend on it, that permission can bind access to the conditions of life, the provision of labor or assumption of debt, and submission to control.

This situation introduces the paper's object. What determines a capital relation is how these actual relationships connect, rather than the existence of equipment or the organization's name. Equipment can keep operating while permissions change; contributions can be repaid while control ends; old debts can remain while new methods become open. Turning these distinctions into a theory requires answers to three questions together: what constitutes a capital relation; how every relation with that structure enters a common disposition; and how production, life, and the next action actually connect after its removal.

The paper gives a common answer. A minimal-support theorem characterizes the permission condition required to exclude capital relations. Complete reconstruction connects every piece of capital evidence to the execution that establishes it. Public replay preserves execution functions. A social contract connects replacement, settlement, migration, and further action within the same actual run. Theorems on innovation, contributions, and costs then show how unknown discoveries can enter and real undertakings can be settled, while completing settlement leaves the future open to further action.

### 1.1 Introducing the Formal Objects Through an Action

Write \(L\) for the law, \(s\) for the current state, and \(w\) for a finite sequence of actions. The law specifies how a request obtains permission, whether it is valid, what it actually consumes and produces, and how it updates the state. The current state records each person's stocks, financial claims, technology, and clock. A complete execution also records accepted and rejected requests, the states before and after each step, and their positions in the execution.

A programme source includes a law, an initial state, and static instructions or a dynamic programme that generates action sequences. A social contract is a set of obligations that these sources and their actual successors must jointly fulfill: checking inputs, generating execution or a specific obstruction, carrying existing responsibilities forward, and leaving an entry for further action.

A production port \(p\) represents the access relation required to perform a class of actions. The controller \(c\) is the controlling party designated by the law for that technology and port. An affected person \(i\) is someone whose needs, inputs, or financial responsibilities enter the execution. **Permission asymmetry** means that the same port admits the controller while denying another participant. When this connects to the actual provision of needs, a return flow, and a capacity to exercise control, it forms the capital relation denoted by \(C\).

“Actual” means that an action has been executed by the given program and has produced its own stocks, accounts, and successor state; “feasible” means that it can pass the relevant checks. Each has a distinct role. A power of disposition that has not yet been exercised can be a real power, whereas appropriation that has occurred must have actual entries. Objects are tracked under these two descriptions throughout.

### 1.2 The Common Main Result

**Theorem 1 (The structural theorem of capitalism).** For the structures of production, needs, permissions, finance, and history defined in this paper, the following results hold jointly.

1. **Minimal support and complete reconstruction.** For any permission law \(L\), the complete absence of capital holds if and only if permissions have no asymmetry. Every witness of a capital kernel, transferable asset title, actual surplus, or current historical control can be traced to its specific access relation, needs, controller, and origin of occurrence. Every specified constructor input yields either a capital witness or an exact failure of a condition. Every established capital witness is reconstructed from its own fields as that very witness.
2. **A common social disposition for any capital relation.** For any actual source and current state, every capital relation \(C\) on its execution sequence generates positive registration from its own evidence and enters the same social contract; the same holds for any actual use of control. When the financial entry starts from empty claims and matches the source’s initial zero debt, the contract maintains termination, public replacement, renewal, and future expansion at every actual point, preserving subsequently issued debts through their actual history. When the entry leaves a debt discrepancy, the contract returns the discrepancy at a specific financial address while retaining the full social law and actual successor.
3. **General public replacement.** For any \(L,s,w\), a public execution sequence can be generated that preserves length, the full successor state, and an item-by-item correspondence of all actual execution entries. Whether provision for any membership list's living and maintenance needs is paid, and whether any task's service is adequate, are each equivalent to the corresponding conditions in the given execution. The public execution has no capital kernel.
4. **Finite actual disposition.** From any point in an actual run, the run reaches a complete disposition in at most the current internal workload plus one step. Public success is jointly generated by a financial audit, member migration, and a currently executable future. It preserves provision for living and maintenance needs, independent execution, productive capacity, absence of new control, full-account non-loss for every person and good, and at least one strict gain. Failure returns an initial replacement-review obstruction or a financial, migration, or future check that fails after public execution has begun. Every path continuing from the same point according to the actual successor reaches the same disposition at that step.
5. **Continuing contributions, reproduction, and settlement.** A mechanism fixed in advance generates a disposition for every actual unknown event, and innovation with actual payment can continue. Total receipts across all accounts for one contribution origin are bounded by its issued quantity. All old responsibilities and all physical and financial origins are preserved through actual institutional changes, without requiring a finite old ledger; this also covers confluence events already issued by the source and their successful registration or specific rejection. A financial tail with sufficient resources has an actual cost minimizer. In another complete settlement domain, every completing candidate has a strictly cheaper complete settlement alternative starting from the same already-executed prefix.

| Branch of the joint theorem | Political-economic question | Sections and results |
| --- | --- | --- |
| Minimal support and complete reconstruction | What structure constitutes capital, and how are all its constructor forms recognized? | §§3–4.1; Theorems 2–4 |
| Common social disposition | How does each capital relation generate its own registration and carry existing debts into one contract? | §§4.2–4.3; Theorem 5 |
| General public replacement | Which productive, financial, and living functions are fully preserved when private access gates are removed? | §6; Theorem 8 |
| Finite actual disposition | When does the current transition reach a complete disposition, where are obstructions located, and how is control persistently excluded? | §5; Theorems 6–7 |
| Continuing contributions, reproduction, and settlement | How does innovation continue, how are contributions and old responsibilities settled, and why can completion remain open to improvement? | §7: 9–11; §8: 12–13; §9: 14–16; §10: 17–18 |

Table 1: The five branches of the joint theorem and the results below. Result 10 is a proposition; the others are theorems.

Sections 3–10 state and prove these conclusions individually; the technical supplement gives parameters, longer proofs, and correspondences to fixed declarations. Their common strength is that **any given object produces a result that can be used in what follows**. The identified \(C\) itself enters the social contract; replacement preserves the full successor state of the identified source; settlement uses actual accounts; and continuation starts from the state produced by this execution.

Universal quantification determines the form of coverage. Whenever a new arrangement has the capital structure defined in §3, it is already an input to the theorem; whether its name has appeared before does not alter the conclusion. When constructor conditions fail, the procedure retains exactly which evidence is missing. A different kind of relation requires concepts that describe that relation. Structure and a uniform construction provide the theory's coverage; historical materials can then explain how different institutions form, sustain, and alter these relations.

### 1.3 What This Paper Continues and Advances

*The Canonical Society Theorem* establishes a common structure for subjects, a root law, real exit, and continuing renewal. *An Economic Constitution of Possibility* develops the argument for basic participation, production, distribution, settlement, and authority over rules. [@Gao2026Society; @Gao2026Constitution] The present paper takes responsibility for the characterization and complete disposition of capital relations: it specifies their actual constitution, proves how all constructors are recognized, shows how production functions can be replayed, and brings common termination, unknown innovation, contribution bounds, and settlement costs into one argument.

This question connects directly to central problems in political economy. Marx explains capital relations through producers' separation from the conditions of production and follows how production reproduces that separation. Property-rights theory analyzes how control affects investment and bargaining. The theory of innovation asks how knowledge production can be rewarded and its results widely used. This paper advances these questions by locating separation in the relation between actual permissions and needs, connecting control and remuneration to their respective grounds in execution, and proving how old responsibilities and productive capacity can continue together after replacement.

## 2 Why Basic Participation Precedes Standing Based on Capital

### 2.1 A Person's Standing Cannot Be Assessed by Their Usefulness

Common rules that require a person to bear the consequences of production, access, and settlement should recognize that person's standing to demand a response. This standing precedes investment, employment, and assessments of contribution. Children, patients, caregivers, and people who can never produce measurable output all have needs and live under conditions created by institutions.

Making basic provision a reward for contributions already made makes access depend on a prior contribution, even though nutrition, care, learning, and opportunities for entry are needed before contribution can begin. Making eligibility depend instead on a future return leaves the dependence intact; it still gives those who assess another person's usefulness the power to withdraw the conditions of life. Basic participation therefore has two grounds: meeting human needs and recognizing each person's equal standing as someone subject to the rules. The second ground ensures that participation does not lapse when repayment is impossible. [@Gao2026Society, §1.2; @Gao2026Constitution, §3]

Sen's capability evaluation reconnects resources to what people can actually do and be; Robeyns further explains how bodies, environments, and social relations affect the conversion of resources. [@Sen1980; @Robeyns2017] This paper carries that concern into institutional relationships. Access to the means of life raises further questions: who delivers them, who controls entry, whether refusal can receive a response, and whether provision continues after someone leaves a role. A person may possess nominal purchasing power while necessary services remain dependent on an irreplaceable controller; the relationship still determines that person's conditions of action.

Basic participation does not require everyone to receive identical goods. More care, accessible facilities, or longer periods of learning may serve equal standing. Nor does it replace the conditions of professional office and specific actions: operating equipment requires technical qualifications, using scarce resources requires a budget, and holding office requires authorization. **Basic standing, task qualifications, contribution claims, and governance powers answer different questions.** Providing funds can establish a claim that should be repaid; that claim alone cannot determine entry for everyone who comes later.

### 2.2 How a Principle Becomes an Institutional Process

Consider again a worker in a production organization. Who takes over provision for the worker's living and maintenance needs after they leave the job? A process that can be checked should contain at least five connected stages.

First, identify needs for a specific person, service, and time window, such as housing, care, and necessary upkeep in the next period. Second, identify the providing institution and its budget; beneficiaries, providers, and payers may be different people. Third, the provider actually delivers resources or services, and the execution record identifies the beneficiary and the corresponding need. Fourth, refusal, delay, or shortfall retains a specific reason and responsible party, and the affected person can challenge it and propose an alternative. Finally, after a change of role, continuation starts from current stocks and responsibilities, and the next period's service obtains its own budget and performance.

This process connects unconditional basic standing to provision that has real costs. Standing can hold even when the person has no income from contributions; insufficient funds then become a specific responsibility for the providing institution to address. The later condition that “provision for every member's living and maintenance needs is paid” checks precisely whether delivery has occurred. A future promise cannot replace that delivery, and increased total output cannot offset an unpaid need of a particular person.

Fraser's argument about social reproduction explains the political-economic significance of this requirement: capital accumulation depends on care and the work of sustaining social relations, while also being able to erode those conditions. [@Fraser2016] If a model of settlement and production records only inputs and outputs inside the firm, provision for living and maintenance needs may be shifted to households or other parties at the very moment the model records success. This paper includes members' living and maintenance needs in its success conditions and checks each responsible party separately, making such cost shifting visible in the result.

### 2.3 Who Can Require an Institution to Respond

In their discussion of corporate objectives, Hart and Zingales acknowledge that production and external effects may be inseparable. They propose pursuing shareholder welfare by allowing shareholders to express social preferences, while preserving shareholders' decision-making position. [@HartZingales2022, §§II–III, V] This brings external effects into corporate objectives and leaves a specific disagreement: having one's interests considered by a shareholder and possessing one's own standing to demand reasons, raise objections, and actually exit are different institutional relationships.

Anderson's discussion of private government further locates the issue in relationships: power over people's lives should answer to their standing to demand reasons and choose other relationships. [@Anderson2015, pp.64–65, 110–111] This paper requires independent grounds for that standing. Workers, service users, and people affected by shifted costs need not hold shares or have participated in the initial financing, yet the rules act on them. Basic participation therefore extends the scope of governance from asset holders' preferences to the standing of people who actually bear the consequences. Governance procedures must specify who may propose, who may decide, who may review, and how consent to office, resource budgets, and the carrying forward of responsibilities are implemented. A “public” name cannot establish these requirements by itself.

This normative argument explains why these institutional conditions are chosen. The formal results that follow examine how they can be realized together: what eliminating permission asymmetry requires, how functions are preserved, how debt continues, and how failure is precisely located. Reasons and constructions meet at this interface.

## 3 What Structure Makes a Production Relation Capital

### 3.1 From Obtaining Provision for Needs to a Relation of Domination

A capital kernel \(C\) consists of three structures on the same finite execution. We first introduce what each does, then show how uniform theorems constrain them.

**Needs and access.** A person actually obtains or uses physical quantities needed for living and maintenance. The execution contains a corresponding effective need item, an actual receipt or consumption, and a delivery path connecting them. The production port required for that receipt is subject to permission asymmetry. Both before the receipt and in the full successor state of the execution, the controller is admitted and the affected person excluded. Dependence thus has a specific need and a position of occurrence.

**Consideration or return flow.** This dependence connects to at least one reverse relation: the affected person's physical quantities enter production inputs through an actual route; physical quantities return to the controller along a nonempty route; or a positive claim borne by the affected person and benefiting the controller is actually issued or transferred. These three relations accommodate the organization of labor or inputs, physical return flows, and financial claims. An unpaid debt can support the third relation without waiting for accounting profit to become positive.

**Capacity for disposition.** At some state already reached in this history, the right holder can independently submit a local disposition request that passes the checks—for example, to use or transfer physical quantities or to transfer a claim—and continues to hold the corresponding private access advantage. This condition checks a feasible exercise of control. The power can affect participants' circumstances even if it has not been exercised in the current history.

Writing \(A\) for needs and access, \(R\) for consideration or return flow, and \(D\) for the capacity for disposition, the capital kernel has the structure
\[
C(L,s,w)=(A,R,D).
\tag{1}
\]
Equation (1) denotes three mutually indexed pieces of evidence containing actual requests, positions of occurrence, physical quantities, and checks under the law. All three must belong to this execution and its legal local alternatives; one cannot assemble a capital relation by taking one component from each of three unrelated histories. Appendix A gives the exact conditions for the two access paths, three return-flow constructors, and disposition requests.

Returning to the production organization, obtaining the means of life brings the worker's needs into the relationship; inputs, returns, or debt give that dependence an economic circuit; independently exercisable powers of disposition make control persist beyond the outcome of a single transaction. The definition identifies both flows and power. It therefore captures capital relations that remain when an organization makes a loss, control has not yet been exercised, or a financial return has not yet been realized.

### 3.2 How Property, Surplus, and History Extend the Same Kernel

Three further objects must be distinguished above the capital kernel.

**Transferable asset title** adds to \(C\) evidence that the controller can be replaced by an actual or feasible valid action changing rights: the controller of the same port changes, the old holder loses access, and the new holder obtains it. This shows that the power can be separated from the person and transferred. A person's fixed permission over their own body does not acquire this transferability merely because it is also called “control.”

**Actual surplus appropriation** requires evidence that appropriation has occurred. Its five origins are consumption, investment, retention, routed consumption, and financial return. Consumption and investment must identify actual physical quantities; financial return must identify the issuance origin of the same claim in the capital relation. An unexercised quote, asset revaluation, or an ungrounded receipt coordinate cannot replace this evidence.

**Intertemporal capital and current historical control** retain exact access positions and subject lineages for past access, needs, and return flows. To count as a use of control today, an action must also be valid now, actually invoke the relevant port, and exclude a current affected person. A past capital relation establishes a historical origin; a new exercise of control must be supported by today's relation.

These distinctions allow reproduction to be traced occurrence by occurrence. In Chapter 6 of Volume I of *Capital*, Marx connects the sale of labor power to workers' separation from the conditions required to realize their labor. Chapter 23 treats production as the reproduction of that relation, while Chapter 26 examines its historical formation. [@Marx1867, chs.6, 23, 26] This paper shares that relational choice of object and develops “how separation continues after an execution” into checkable conditions: needs are actually met through a particular access relation, return flows have actual origins, and control is preserved in the successor state or a later occurrence. Property, appropriation, and history thus have their own evidence. They can support one another within one relation and can end or continue separately when institutions change.

### 3.3 The Necessary and Sufficient Condition for Minimal Support

Let \(a_L(s,p,i)\in\{0,1\}\) be participant \(i\)'s access result for port \(p\), evaluated at the technology component of current state \(s\), and let \(c_L(s,p)\) be its controller. Private access asymmetry is
\[
\operatorname{Private}_L(s,p,i)
\iff
a_L(s,p,c_L(s,p))=1
\ \land\
a_L(s,p,i)=0.
\tag{2}
\]
This describes the permission layer alone. An actual \(C\) also requires the needs, return-flow, and disposition evidence in (1). Define
\[
\operatorname{NoAsymmetry}(L)
\iff
\forall s,p,i,\quad
a_L(s,p,c_L(s,p))=1
\Rightarrow a_L(s,p,i)=1.
\tag{3}
\]

Equation (3) compares permissions of control. Whether a request can actually execute also depends on the law's checks of technology, physical quantities, needs, and other validity conditions; these conditions appear separately in the capital kernel's access evidence. Absence of permission asymmetry specifies the relation at this control layer.

The complete absence-of-capital condition \(\operatorname{NoCapital}(L)\) excludes five levels together: private access asymmetry, capital kernels, transferable capital asset titles, actual surplus appropriation, and newly occurring historical control in the present. Including the first level means that excluding capital also requires removing the access advantage on which it can depend; the other four levels check that this removal extends through the specific capital objects.

**Theorem 2 (Minimal support).** For any permission law \(L\) over the specified object types with decidable equality,
\[
\boxed{\operatorname{NoCapital}(L)
\iff\operatorname{NoAsymmetry}(L).}
\tag{4}
\]

**Proof.** Suppose complete absence of capital holds. Its permission component excludes (2) for any \(s,p,i\). If the controller's access is 1, the participant's access must also be 1; otherwise, the excluded private access asymmetry would arise directly. This gives (3).

Conversely, suppose (3) holds. It directly excludes every private access asymmetry. The effective access evidence of any capital kernel contains such an asymmetry, so no capital kernel can exist. Any transferable capital asset title and any actual surplus each carry a corresponding capital dependence. Current historical control also requires a current private access asymmetry. Eliminating these witnesses one by one establishes all five components. Both directions quantify over all states, ports, and participants. □

**Theorem 3 (A permission family realizing sufficiency).** In a permission family retaining the same actual stocks, needs, instructions, and financial materials, for any controller-access value, affected-person-access value, clock, and round,
\[
C\text{ exists}
\iff
(\text{controller admitted}=1)
\land(\text{affected person admitted}=0).
\tag{5}
\]
At the exhibited starting point of this family, where both clock and round are 0, opening access to the affected person also preserves all actual physical quantities and the full successor state of the execution.

Theorem 3 generates evidence of needs, returns, and disposition from an actual execution with the required materials, then checks the two permissions. The reverse direction reads the two permissions from the capital kernel's private access asymmetry. This connects the permission layer of Theorem 2 to a complete occurrence of capital. Return of stock, actual financial issuance, and routed appropriation supply distinct, nonempty actual uses of the construction; the existing debt left by the actual issuance remains.

![Permission matrix and the complete absence-of-capital condition](figures/fig01-structure-en.svg)

Figure 1: The two permissions determine private access advantage. When both controller and affected person are denied access, permissions still have no asymmetry; admitting the affected person can also remove the advantage. The five components of absence of capital share this supporting layer. Generating an actual capital kernel also uses evidence of needs, returns, and disposition. The complete capital conclusions in the four cells refer to the fully supplied permission family of Theorem 3.

### 3.4 Why Closing Access to Everyone Creates a Further Responsibility

Closing all ports still satisfies absence of permission asymmetry. That state removes the controller's relative advantage but has thereby delivered no means of life. Two institutional tasks become distinct: removing structural exclusion, and actually producing and paying for services.

This division also explains why general public replay and complete actual disposition are needed next. Common abolition must leave productive conditions under which people can act; provision for living and maintenance needs, independent execution, and executable futures require their own constructions. Section 4 brings all occurrences of capital into a common social contract, §5 explains how joint success is generated component by component, and §6 proves how functions are preserved. The removal of power thereby connects to the continuation of life.


## 4 How Every Occurrence of Capital Enters the Same Social Contract

### 4.1 Recognition Must Return to the Execution That Establishes the Relation

A definition alone does not yet show coverage of every form of formation that it permits. The reconstruction results use three classes of complete inputs: production inputs, physical returns, and financial claims for capital kernels; the five kinds of evidence for actual appropriation; and the four kinds of evidence for historical capital—title, retention, consumption, and investment. Inputs contain the law, current state, execution sequence, and corresponding proposal. The checking procedure determines access, returns, disposition, and historical conditions itself, returning a successful witness or an exact failure.

**Theorem 4 (Reconstruction of all constructors and recovery of the same object).** For any input of the constructor types above, the checking procedure returns a capital witness on that same input or the specific condition that fails. For any established capital witness \(C\), resubmitting its own stored fields produces exactly \(C\):
\[
\operatorname{reconstruct}(\operatorname{fields}(C))=C.
\tag{6}
\]
The conclusion holds separately for capital kernels, actual appropriation, and intertemporal history.

**Proof outline.** Decompose the constructor types exhaustively and run their corresponding checks. Kernel constructors check access, returns, and disposition item by item. Actual appropriation first checks the shared dependence, then its five classes of events. Historical constructors check accesses, indices, and current permissions. Every failure branch retains the same proposal and the failed condition. Given an established \(C\), its valid evidence ensures that the checks pass, and the successful branch generates the same value as \(C\) from its fields. The proof recovers positions of occurrence, need items, financial origins, and lineages, so (6) preserves object identity. □

This explains how coverage of all forms is achieved. New names for forms may continue to appear, and the specific laws, people, goods, technologies, and histories that constitute capital may change; all parameters in the constructor types are already quantified. Changing a corporate form, repackaging a claim, or routing appropriation differently leads back to actual evidence of access, returns, disposition, and history. Institutional analysis can therefore identify “which relation remains” without treating every new name as a fresh gap in the theory.

### 4.2 Capital Evidence Obtains Its Own Registration

A common termination theorem must cross a further difficulty: how does a recognized capital relation become something that the social run actually processes? If “it has already been successfully registered” must be assumed separately, a gap remains between recognition and disposition.

Let \(\sigma\) be an actual program source. A source may directly emit an execution or store finite instructions; \(w_\sigma(s)\) is the action sequence it generates at the current state. Write \(r(\sigma)\) for the registration quantity. This registration comes from the same program source, rather than from a separate list of capital relations.

**Theorem 5 (Any capital relation enters the social contract from its own evidence).** For any \(\sigma,s\) and
\[
C:\operatorname{CapitalRelationKernel}
   (L_\sigma,s,w_\sigma(s)),
\]
we have \(r(\sigma)>0\), and the source's complete social capital contract is generated. Any actual use of control also generates a contract of the same kind.

**Proof.** If the source generates execution through an emitting program, the generation mechanism directly gives a positive registration quantity. If it uses static instructions, the registration quantity equals their length. The access item in the capital evidence must belong to the execution's actual entries. Empty instructions generate no entries, contradicting that membership evidence. The static instruction sequence is therefore nonempty, and the registration quantity strictly positive. This fact generated by the source is then used to enter social registration and execution; no separate certificate of success is added to the input. An actual use of control first recovers the capital relation on which it depends, then uses the same construction. □

Although short, this proof fulfills an important universal requirement. Every capital relation carries the source it needs to enter the contract; recognition proceeds beyond an external observational label. Six explicit models—industrial capital, care, finance, platforms, automation, and state capital—each obtain this contract from their own actual control witnesses. Their organizational names differ; registration and disposition use evidence of occurrences within the same structure.

### 4.3 Two Complete Answers at the Financial Entry

The social run reads both the execution state and financial accounts organized by slots. The execution state also stores a debt matrix
\[
F(j,d,h),
\]
where \(j\) is a financial instrument, \(d\) a debtor, and \(h\) a holder. Slot accounts additionally store issuance origins, performance histories, and archiving. The two layers must identify the same obligation for settlement to have a precise object.

The common contract checks the financial entry accordingly and gives one of two answers.

**Debt is represented by the entry.** This entry's financial slot accounts are generated from an empty set of claims and match the program source's initial debt matrix, so this branch identifies the initial debt matrix as zero. Subsequent actual issuances enter the accounts through their own occurrences. The social contract then delivers complete results for termination, public replacement, initial choice, available renewal, and future expansion at every point. Section 5 develops the finite actual disposition contained in these results.

**The entry leaves a debt discrepancy.** A precise \((j,d,h)\) is returned, proving that debt in the execution state at that address differs from its representation at the entry. The discrepancy remains with the full social law and actual successor. The next step must address this incorrectly represented obligation; switching to empty accounts cannot erase it.

Both answers provide a disposition for any actual \(C\). The financial compatibility required for success is checked within the contract, while failure enters further action at a specific address. Matching financial identities is thus part of social disposition.

## 5 How Abolition Becomes an Actual Process

### 5.1 Three Endpoints Must Belong to the Same Run

Consider the moment when a production organization is moving into public execution. It must prepare an available replacement, complete registration, and process the accounts before it can address current members and their future. Compressing these steps into “conversion to public ownership” omits the connections most liable to break.

Let \(x\) denote the current point in the actual run, and \(T(x)\) the next point actually generated by this source. Write \(m(x)\) for the outstanding internal workload, calculated from the run's own pending contents. Repeated execution of \(T\) gives \(T^n(x)\). Internal steps record processing work; periods of life and wall-clock time are accounted for through their respective actual events.

**Theorem 6 (Finite actual complete disposition).** For any actual point \(x\), there exists
\[
n\le m(x)+1
\tag{7}
\]
such that \(T^n(x)\) reaches one of the following complete dispositions:

- the initial public-replacement review is obstructed, retaining the specific failure, existing responsibilities, and an entry for continuation;
- public execution has begun and a complete abolition witness has been obtained;
- public execution has begun and the financial, migration, or current-future check returns an exact residual.

If another path starts from the same \(x\) and follows \(x_{k+1}=T(x_k)\) at every step, it agrees with this actual iteration at step \(n\), and therefore reaches the same disposition.

**Proof outline.** When internal work remains, one actual processing step strictly decreases the corresponding natural-number workload. After internal work is exhausted, the next step generates either a public state or an initial-review obstruction through the actual choice. The bound therefore comes from the current workload. Upon reaching a public state, the complete-disposition check reads that very state and generates success or one of the three kinds of residual. For another legal path, induction on the step number applies: the initial point is the same, and the successor is given by the same \(T\), so every step is the same. The current run generates both the endpoint and agreement along every such path. □

![Registration and actual disposition of any capital relation](figures/fig02-disposition-en.svg)

Figure 2: Capital evidence produces positive registration, after which the accuracy of the debt entry is checked. Once the actual disposition chain begins, the finite bound guarantees a complete answer: an obstruction in the initial replacement review, or entry into public execution followed by financial, migration, and current-future checks. Success, discrepancies, and failures all retain the same source's responsibilities and successor. The branches name distinct actual outputs.

### 5.2 What a Complete Abolition Witness Contains

Complete success simultaneously contains facts obtained from three checks.

**The financial audit** fixes the common point at which public execution begins, then runs the pre-transition law and programme from that point for the same number of rounds as the public history to generate the comparison baseline. At each round, the baseline programme reads its own current state and generates that round’s actions. Write \(S^{\mathrm{pub}},S^{\mathrm{base}}\) for the endpoint stocks and \(F^{\mathrm{pub}},F^{\mathrm{base}}\) for the debt matrices. For participant \(i\) and good \(g\), the complete difference is
\[
\Delta_{i,g}
=(S^{\mathrm{pub}}-S^{\mathrm{base}})_{i,g}
+[V_L(F^{\mathrm{pub}}-F^{\mathrm{base}})]_{i,g}.
\]
Here \(V_L\) uses each instrument's designated settlement good and rate to enter a claim positively for its holder and a debt negatively for its debtor. The payer’s stock decreases as the corresponding debt is retired, so both effects must be assessed at the same coordinate. The audit requires positive rates for instruments entering the valuation, a positive comparison window, and equal endpoint clocks. It then establishes \(\Delta_{i,g}\ge0\) at every coordinate, with strict positivity at at least one. Fulfilled and outstanding claims each retain their status; actual retirement and archiving of all debts are further generated by the resource conditions and repayment procedure of §9.

**Member migration** is bound to the first admitted public execution and its entering membership list. It checks how each member's productive and living relations are handed over. That execution must pay for members' living and maintenance needs, preserve independent execution and productive capacity, and introduce no new control; this evidence of the migration already performed is retained by the current run.

**The current-future check** runs adaptive compilation from the current state, generating an accepted, executable candidate for continuation and checking whether that execution can pay for the living and maintenance needs of everyone on the current membership list. This future starts from stocks, accounts, and permissions already obtained; the candidate's required resources and responsible parties are identified in the same check.

Success can therefore be written as
\[
\operatorname{Abolished}(x)
=
\operatorname{Finance}(x)
\land\operatorname{Migration}(x)
\land\operatorname{Future}(x).
\tag{8}
\]
The three pieces of evidence belong to the same actual run: the financial audit reads the current complete account, migration identifies the first public execution, and the future check generates continuation from the current state. The significance of (8) is their joint satisfaction: complete accounts show non-loss and a strict gain, migration preserves members' living conditions and independent execution, and an executable continuation is available now. Legal claims not yet retired remain in the accounts and enter their respective repayment procedures.

If the financial check fails, the result retains the specific financial object and failed item. Migration failure retains the particular member and obstacle. Future failure retains failure over the candidate domain generated at the current state. When the initial replacement has not yet been accepted, its own review obstruction remains. Each failure excludes complete success at that same checked state and leaves a definite object for the next processing step.

This structure separates “incomplete reform” into judgments about processes for which responsibility can be assigned. What has happened to debt representation, actual repayment, member handover, and the capacity to continue can be identified separately; passing one check cannot stand in for another.

### 5.3 How an Available Replacement Is Chosen and Renewal Actually Occurs

General functional replacement supplies an executable public sequence. To become an institutional change, that sequence must also be selected by the current run. The initial-choice theorem proves that, when a complete replacement satisfies all the source's admission checks, the selection procedure actually enters the acceptance branch and generates public execution with its complete witness. An available plan thereby becomes an action.

Renewal likewise begins from the current state. When an actual public state has no pending internal work, the automatic proposal is to advance, and a current candidate passes both the renewal and successor-feasibility checks, that renewal is actually executed and produces a new witness. New provision for living and maintenance needs, financial effects, and future checks all belong to this occurrence; passing in the previous period does not count as payment in this one.

This connects directly to Ostrom's distinctions in governance. Provision decisions, concrete production, use, management, and exclusion can be carried by different arrangements; daily operations, collective choice, and constitutional rules also occupy different levels. [@Ostrom2009, pp.411–414, 419–422] The paper develops replacement requirements into actual history: who hands over which resources, when a successor can execute independently, who continues unfinished services, and how the old term ends. The availability of common governance is realized through these connections.

### 5.4 Recurrent Control Also Encounters a Specific Obstruction

Termination also covers a stronger situation: capital need not be permanently present but may repeatedly reappear after exit. Consider an infinite path starting from an actual point and following \(T\) step by step. Recurrence in every tail means that, for every cutoff, some later step contains new capital control.

Public execution also has a persistence lemma. Once actual execution enters public mode, each successor continues to read the public interpretation already in force. Processing pending financial items and the next request preserves public mode and the properties of having no new capital kernel and no new use of control. Induction over subsequent steps yields the entire public tail after that actual entry. This lemma supplies the continuing exclusion used in the following proof.

**Theorem 7 (A run without an unresolved review obstruction cannot be an absorbing path for recurrent control).** No actual path has both properties: new capital control occurs in every tail, and every step is free of unresolved initial-replacement-review obstructions.

**Proof.** Theorem 6 gives a finite disposition. If the path reaches a persistent public tail, every subsequent step has no new capital kernel or control, contradicting recurrence in every tail. If it reaches an initial-review obstruction, that contradicts the absence of unresolved review obstructions throughout the path. These possibilities exhaust the cases. □

Intermittent recurrence must therefore also expose responsibility at a specific review. The legal termination of capital and the continuation of society are supported by their respective conditions: settling a responsibility, ending a term, or exhausting internal work each connects to the next actual input.

## 6 How Public Execution Preserves Productive Functions

### 6.1 Preserving the Effects of the Entire Execution

Capital's organizational functions are commonly described as advances, investment, coordination, risk bearing, innovation, and settlement. These functions have concrete carriers here: financing issuance and actual receipt, production inputs, actual instructions, paid information, risk settlement, and account updates. The general replacement theorem acts directly on the action sequences carrying these functions.

This section and §5 test two connected requirements. Theorem 8 generates a public replay from any given finite action sequence \(w\), preserving its complete effects; paid needs and unpaid shortfalls are preserved with them. Theorem 6 instead advances an actual institutional transition from the current point. Success requires the run to admit the public replacement, the financial entry to identify existing debts, migration to preserve members' independent execution and productive capacity, the full account to show non-loss for every person and good with at least one strict gain, and current adaptive continuation to generate a future that can pay for every member's living and maintenance needs. **Functional preservation supplies a public realization of the same effects; joint success of the actual transition is generated by the financial, migration, and future checks in (8).**

Let \(L^{\mathrm{pub}}\) be the public interpretation that shares \(L\)'s technology, physical-quantity, and settlement rules: required production ports are opened, the operation policy is set to unrestricted, and the controller's private consent gate is removed. Let \(\rho_{L,s}(w)\) be the public replay generated item by item from \(w\), and \(\iota_L\) the corresponding transformation of actual entries. Write \(M\) for the membership list and \(\tau\) for a task; the task specifies a user, a bundle, a purpose, and a time window.

**Theorem 8 (Complete public replay of any execution).** For any \(L,s,w,M,\tau\),
\[
\begin{aligned}
|\rho_{L,s}(w)|&=|w|,\\
\operatorname{next}_{L^{\mathrm{pub}}}(s,\rho_{L,s}(w))
 &=\operatorname{next}_{L}(s,w),\\
\operatorname{items}_{L^{\mathrm{pub}}}(s,\rho_{L,s}(w))
 &=\operatorname{map}(\iota_L,\operatorname{items}_{L}(s,w)).
\end{aligned}
\tag{9}
\]
Moreover,
\[
\begin{aligned}
\operatorname{AllNeedsPaid}(L^{\mathrm{pub}},s,M,\rho_{L,s}(w))
&\iff\operatorname{AllNeedsPaid}(L,s,M,w),\\
\operatorname{ServiceAdequate}(L^{\mathrm{pub}},s,\tau,\rho_{L,s}(w))
&\iff\operatorname{ServiceAdequate}(L,s,\tau,w),
\end{aligned}
\tag{10}
\]
and public execution has no capital kernel. Every request in the replay is valid, carries no controller-consent condition, and receives public access at the required port.

The full successor state in (9) includes stocks, the debt matrix, technology, and the clock; the permission interpretation changes from \(L\) to \(L^{\mathrm{pub}}\). The same productive and financial results can therefore be realized under different relations of control. Equation (10) carries equality into actual use: whose living and maintenance needs are paid and who receives which service in which window are preserved item by item.

### 6.2 Why Rejected Positions Can Also Be Preserved

The decisive step is to generate the replay item by item, rather than write a different plan with similar effects.

For a request accepted in the given execution, replay preserves the operation and signer while removing the controller-consent condition. With the required ports open, the request remains valid and has the same physical and financial effects. For a rejected request, replay turns that position into a zero-effect presentation with the same signer and purpose. The presentation has no physical effect, preserving the state at that position without turning a rejection into a new payment.

Induction along the request sequence gives the same incoming state and the same item-level effects at every step, hence the same successor state. Actual entry indices, physical debits and credits, and states before and after each entry retain their correspondence. This proves (9). Payments for living and maintenance needs and services are identified by actual use entries; a zero-effect presentation cannot count as a use. Payment evidence therefore corresponds exactly in both directions, giving (10). Opening all ports also excludes private access asymmetry and hence excludes capital kernels. □

![Public replay of the same execution sequence](figures/fig03-replay-en.svg)

Figure 3: The upper sequence executes under the given law; the lower sequence is its public replay, generated position by position. Accepted operations retain their actual effects; rejected positions become zero-effect records. Physical quantities, accounts, and states correspond at every step, so evidence of provision for living and maintenance needs and services can be recovered in both directions. Arrows show execution order and item-by-item correspondence.

The result gives a strong form to the claim that functions do not require capital relations. For any given execution of a function, public replay generates a realization without capital, with the same length and full successor state. The financial effects of advances, knowledge already paid for, and legal claims can all be preserved.

### 6.3 Where the Argument Meets Property-Rights Theory

Grossman and Hart study investment that cannot be fully contracted in advance and allocation after investment. Once investment is given, the parties can renegotiate. Residual control over assets changes bargaining positions and the distribution of returns, thereby changing investment incentives in advance. Ownership allocation therefore chooses among different incentive losses: concentrated control has both benefits and costs. [@GrossmanHart1986, pp.691–699] Hart and Moore further specify asset control as the power to decide who may use assets: exclusion from asset use indirectly changes people's feasible actions. [@HartMoore1990, pp.1121–1122] Exclusion from asset use corresponds directly to this paper's ports, controllers, and affected persons.

Both studies already distinguish rights to income from rights of control. This paper continues that distinction and proves a relation covering the entire execution domain: given an actual production sequence, all its effects can be replayed under an open interpretation, so continued exclusion does not become a necessary condition of those effects. Property-rights models explain how control produces incentives within a specified bargaining and investment structure; the replay theorem shows that realized productive effects and private access advantage are structurally separable.

The next difficulty concerns future action. Why do funders continue to finance, why do researchers bear failure, and how does local knowledge enter the next choice? Remuneration, risk, information, and renewed participation each require executable mechanisms. Section 7 connects advance quotations, actual financing, paid observation, settlement after failure, and release of the next round into a complete process. Functional separation thus has both a general preservation theorem and a constructive mechanism for continuing innovation.

### 6.4 Local Knowledge and Public Coordination

Hayek emphasizes that knowledge of particular times and places is dispersed among actors, and that prices help them adjust without knowing every cause of change. [@Hayek1945, §§III–VI] For public coordination, the question is therefore who obtains information, how it is paid for, and when it enters a choice. The actual mechanisms here read only their own signals acquired through payment; discoveries enter as their own events, and later inputs cannot rewrite observations that have already occurred.

Public replay first proves that execution effects can be preserved; it does not need to foresee which technology will later be discovered. For new choices, the current source generates candidates, checks resources and responsibilities, and updates again after the next actual event. Public coordination therefore consists of actual information, executable procedures, and checks with responsible parties. Knowledge can remain dispersed and methods can change, while actions must still identify the resources they use and the consequences they produce.


## 7 How Unknown Innovation and Bounded Contributions Continue

### 7.1 The Mechanism Is Fixed Before the Event Occurs

Let \(M\) be an experimental mechanism. It first supplies the law, local programs, financing, investment, probing, and closing arrangements, then receives an actual unknown event \(\nu\). The quotation menu \(Q_M\) is a finite event domain used for advance calculation; actual events come from the full request type and need not belong to \(Q_M\).

**Theorem 9 (Complete disposition of open events by an advance mechanism).** For any \(M\) and any actual event \(\nu\), the mechanism generates a complete disposition of the corresponding execution: actual execution when the conditions pass, and an exact failure otherwise. Execution under the public interpretation has no capital kernel. The next event re-enters the same disposition mechanism from the successor state generated by this execution.

Execution first identifies actual financing. After a loan claim has been signed and issued, the real receipt of materials must still be identified; issuance itself adds no materials. Investment deducts actual stocks, and failure does not reverse the expenditure. Local strategies read only their own incoming information; sensor readings come from their own stocks, relevant debts, and clocks. A charged observation requires a positive actual debit. Experiments, messages, observations, subsequent actions, and settlement enter the same execution history.

Knight's distinction between risk and uncertainty has a precise place here: weights declared in advance cannot preinstall everything that will later occur; judgment, waiting, and failure still require institutional arrangements. [@Knight1921, part III, chs.VII, IX] This paper keeps the quotation domain finite and the actual event domain open, placing the disposition of new events in a mechanism fixed in advance. Actual observation costs also account for how new knowledge is obtained and enters action.

### 7.2 Quotations, Risk, and Actual Repayment Have Their Own Accounts

Let a participant's declared success weight be \(p>0\), weighted loss on failure be \(\ell\), outside opportunity be \(a\), and additional remuneration be \(b\ge0\). When weights are nonnegative and sum to 1, the mechanism calculates the success payment
\[
R=\frac{\ell+a+b}{p},
\qquad
pR-\ell=a+b.
\tag{11}
\]
Expected net cash under the declared weights thus equals the outside opportunity plus additional remuneration. If there is no success support, the weights are invalid, or the remuneration conditions fail, the quotation procedure returns the corresponding problem. Declared weights belong to the advance participation arrangement; actual payment still depends on the event that later occurs and its settlement.

One risk-settlement instance gives net risk cash of \(+3\) on success and \(-2\) on failure; under declared equal weights, the arithmetic expectation is \(1/2\). These quantities come solely from that risk-settlement item. Principal, production income, and rent are each recorded by their own origins. Actual new principal and risk claims are fulfilled and archived at their respective account positions; the old holder's existing debt of 1 remains. Refusal to pay leaves both the new risk responsibility and the old debt. Refusal cannot be recorded as the disappearance of responsibility.

Arrow already explained that knowledge production needs remuneration while widespread use after discovery has social benefits. He discussed separating innovation rewards from use and the organizational problems facing public finance. [@Arrow1962, pp.614–619, 623–625] This paper develops that organizational problem into steps that can continue in execution: who supplies materials first, who obtains information, which outcome triggers which claim, how actual repayment retires the claim, and where the next round obtains resources. Recognition of remuneration and open use of knowledge hold together through these steps.

### 7.3 Two Discoveries, Each Paid For

**Proposition 10 (Continuing actual payment and discovery outside the menus).** In an explicit source for a two-round experiment, both rounds are actually accepted, and technology advances from 0 to 1 and then to 2. The second discovery lies outside both rounds' quotation menus. Each round has its own financing, investment, and paid signal, and pays for every member's living and maintenance needs. The second round preserves existing debt, obtains a new paid signal from its own empty message packet and initial inbox state, and quotes again on the basis of its own actual prefix.

In this continuing-experiment instance, each round invests 3 units of material and 3 units of message resources, including an observation charge of 1. Before the second experiment, the corresponding prototype stock is 0. Technology 2 is therefore obtained through a new round of actual inputs and discovery. Old debt of 1 persists through both rounds.

Release of the next round also requires an additional actual check: provision for everyone's living and maintenance needs in the current period must already have been paid. The materials contain an explicit failure comparison: the next period's proposal is payable and the current experiment has been accepted, but unpaid current living and maintenance needs still prevent the next experiment from being released. Missing finance, missing paid observation, and unpaid current needs each leave a specific failed case and condition.

![Continuing innovation and the receipt bound for a contribution origin](figures/fig04-innovation-en.svg)

Figure 4: Mechanisms and quotation rules are fixed first; actual discoveries enter afterward. Technologies 0, 1, and 2 belong to the two-round instance with actual payment. Each round obtains its own resources and signal, while old debt persists. The contribution-origin bound below quantifies over all actual account positions and every finite continuation. The two results show, respectively, that innovation can continue and that continued operation cannot enlarge the quantity of the same undertaking.

### 7.4 Why Cumulative Receipts for One Contribution Are Bounded

A recognized contribution receives an origin identifier \(o\) and a quantity \(Q_o\) at issuance. The quantity may correspond to advanced principal, risk remuneration, or another established finite undertaking. Its amount is determined by the applicable rules of undertaking; execution should fulfill that established quantity exactly.

Write
\[
\operatorname{receivedForOrigin}(o,H)
\]
for **the cumulative principal retired—that is, actual contribution receipts on claims from that origin**—summed by origin \(o\) across all account positions at the endpoint of actual history \(H\). This quantity tracks actual payments on the specified claim. Production income, gifts, and new contributions are recorded under their own origins.

**Theorem 11 (The cumulative contribution bound across all account positions).** For any actual program source, fix a contribution origin \(o\) already registered at the initial point. For every finite continuation of its account cursor, and every public suffix after any actual prefix,
\[
\boxed{\operatorname{receivedForOrigin}(o,H)\le Q_o.}
\tag{12}
\]
The same conclusion applies to any actual event, stage, continuation length, and account position in an innovation run.

**Proof.** For the same account position already present at the initial point, an actual settlement satisfies
\[
q_{\mathrm{after}}+\operatorname{paid}=q_{\mathrm{before}}.
\tag{13}
\]
Chaining actual events gives remaining principal plus cumulative receipts since that point equal to principal at the point. To examine cumulative receipts since issuance, choose the initial point immediately after that origin is admitted; before it, no retirement payment for that origin has occurred. Issuance is not payment, payments at other positions do not enlarge this position's quantity, and archived claims have no event reopening them.

Conservation at individual slots does not yet establish the full-account bound: if the same issuance were arbitrarily registered twice, each copy could conserve its own quantity while supporting duplicate claims. The actual source generates uniqueness of origin from stock positions, issuance events, and access order; account cursors and public suffixes preserve it. Summing all positions for the same \(o\) then identifies the quantity of that very issuance. Nonnegativity of remaining principal gives (12). □

Pistor analyzes capital's durability, priority, and effects against third parties through legal coding, making the connection between assets and legally conferred powers explicit. [@Pistor2019] Equation (12) imposes an execution constraint at that connection: transfer changes the holder, a stage changes the setting of an effect, and time extends the history, but none can recreate quantity for the same contribution already issued. New services and undertakings can obtain new claims; continuing control must be re-established in light of current tasks and the standing of affected people.

A finite total and a finite repayment time are different objects. Equation (12) bounds cumulative receipts over any actual finite prefix. When repayment is completed depends on resources, payments, and scheduling conditions. Section 9 supplies actual completion of joint settlement.

## 8 How Complete Accounts Connect Returns from Control to Responsibility

### 8.1 Distinguishing Production, Transfers, and Revaluation

The same amount of book income can arise from real production, transfers, returns from control, or asset revaluation. Combining them into one number can count repayment of principal as profit and price increases as new production. The paper decomposes actual entries item by item, measuring each person and each physical good separately.

Let \(\mathcal I\) be complete income including changes in financial positions, \(P_{\!n}\) actual output minus actual production, use, and revision costs, \(T_{\!o}\) other transfers, and \(K_{\!c}\) the signed net transfer at controller addresses identified through capital witnesses. Given an opening valuation \(\pi_0\), book income \(\mathcal B\) satisfies
\[
\begin{aligned}
\mathcal I&=P_{\!n}+T_{\!o}+K_{\!c},\\
\mathcal B&=\pi_0P_{\!n}+\pi_0T_{\!o}+\pi_0K_{\!c}
            +\operatorname{Revaluation}.
\end{aligned}
\tag{14}
\]
The control term is identified by entry positions and controller addresses in actual capital witnesses; other effects remain in the complementary terms. A transfer can change a person's conditions of action even when it adds no physical goods to the social total. The cash leg of repayment is offset by retirement of the corresponding claim, so principal cannot be counted again as a net gain.

**Theorem 12 (Complete decomposition of returns).** For any given execution, (14) holds item by item according to actual operation types, preserving financial instruments, settlement units, debtors, holders, and histories. Through the item-by-item public replay of §6, the complete effects and account operations of any execution are preserved.

The proof exhausts the operation types: actual production and use enter net production, physical and financial transfers enter their respective terms, and closing positions enter the revaluation calculation at fixed valuations. An empty action history generates no new production or transfers; its book changes belong to revaluation. This decomposition makes it possible to discuss contribution, wealth holding, and capital control by their actual origins.

### 8.2 Net Losses from Control Must Include All Costs

In comparing controlled and open execution of the same production task, both sides retain the same initial stocks, financing, investment, own strategy, and rules for responses that adapt to history. Changing permissions may trigger different responses; all actual costs of experiments, adoption, migration, maintenance, and retaliation on each side enter the comparison. A strict net gain arises only when additional output exceeds additional real costs.

For affected person \(i\) and good \(g\), let net production on the two sides be \(P^{\mathrm{open}}_{i,g}\) and \(P^{\mathrm{controlled}}_{i,g}\). The damage quantity arising from the specific control difference is
\[
d_{i,g}
=\max\{0,\,
 P^{\mathrm{open}}_{i,g}-P^{\mathrm{controlled}}_{i,g}\}.
\tag{15}
\]
Differences due to permissions and differences due to operation-policy restrictions are first separated by origin; the group of participants exercising control and the damaged coordinates are then connected to responsibility.

Roemer connects exploitation to property relations and coalition withdrawal. His per capita property-withdrawal test evaluates what a coalition could achieve with its per capita share of alienable productive assets, together with the loss to its complement. He also includes dominance as a necessary condition, while the chapter’s game-theoretic formalization concentrates on withdrawal and distribution. [@Roemer1982, pp.194–198, 202–203] This paper connects needs, access, return flows, and disposition into specific evidence of capital relations, then carries the requirement of a feasible alternative into the execution of a change in permissions. Equation (15) fixes the initial state and response rules, recording the gains and costs actually triggered by that change in their respective accounts; existing debts retain their identities. Damage is identified for each person and good, while provision for living and maintenance needs has its own check of actual payment for every member. Loss to the complementary coalition in the exploitation test and full-account non-loss for everyone in complete abolition serve different judgments: the former identifies an existing distributional relation; the latter tests whether conversion can be executed together with its real obligations.

One actual execution instance yields, after complete accounting, a net increase of 18 in materials and 3 in outputs; both complete debt matrices preserve the initial debt. Further comparisons cover a pure rent transfer and a case in which costs exhaust the additional output. Whether altered access increases net physical quantities must therefore be assessed through the same complete account. The 18 units of material and 3 units of output have different units and form separate vector coordinates.

Acemoglu and Restrepo's task framework distinguishes productivity effects, automation's displacement of labor from tasks, and the reinstatement of labor through new tasks. [@AcemogluRestrepo2019, pp.3–12] Higher total output therefore does not by itself determine workers' income or conditions of action. This paper connects the distinction to the same actual disposition: production is compared good by good, living conditions person by person, and independent execution is checked again after migration. A net gain at one coordinate does not offset another person's unpaid need.

Recent research on artificial intelligence develops this distinction into an explicit macroeconomic mechanism. Acemoglu derives aggregate productivity from task-level cost savings and separately derives wages and distribution. In a setting with complementary tasks, increased physical productivity of a kind of labor changes task prices and labor allocation; labor income need not improve in proportion to output. His example in which greater low-skill productivity widens the income gap makes the separation between technological benefit and income benefit especially clear. [@Acemoglu2025, §§2.3–2.4, 2.9–2.10]

### 8.3 Damage and Restitution Use the Stock Only Once

Complete damage is carried by a matrix indexed by harmed persons and physical goods. Its finite positive support comes from the actual finite production flow. Every positive damage has a corresponding position, so affected people are not deleted because they are absent from a preset population list. When several capital relations share the same actual source and stocks, responsibilities are also generated from that common occurrence.

In joint settlement, \(P\) records repair of production damage, while \(G\) records gross restitution of controlled physical return flows by victim, recipient, and good. \(G\) is generated from actual entries in identified capital relations. Return flows controlled by the recipient are distinguished from signed gifts and expressly consented transfers; existing financial debts await their own actual settlement. Both responsibilities refer to the same current state. Each execution runs its action sequence once and allocates the actual increase in distributable physical quantities once: \(P\) reserves its share first, and \(G\) receives a share of that same remainder. All production, consumption, transfers, and restitution remain in the complete account. Repair and restitution can thus hold together without using one stock to pay two separate accounts.

For a responsibility position \(k\), the actual update preserves
\[
G'_k+\operatorname{allocatedG}_k=G_k.
\tag{16}
\]
Adding along the execution connects, coordinate by coordinate, physical quantities obtained through control, quantities already returned, and burdens still unpaid. Returning goods and repaying financial claims also have distinct legs: actual entries identify which physical quantities are returned first, and which settlement units subsequently retire which claims.

The actual resource construction takes only recipes, initial resources, needs, and capacity for a single allocation, then produces executable plans and actual payments. Sufficient resources yield joint payment of repair, restitution, and provision for everyone's living and maintenance needs. Insufficient resources return a specific request, both kinds of remaining responsibility, and the failure of provision for living and maintenance needs. Joint signature, claim issuance, and changing a recipient are each accounted for according to their own effects.

### 8.4 How Renewal Powers Acquire a Boundary During Repayment

The responsibility-first mechanism reads stocks, unpaid matrices, declarations, and members from the current responsibility row. New proposals are checked request by request. Scanning stops at the first rejection; the admitted prefix is actually executed, and the unexecuted tail retained. Partial payment updates responsibilities, and continuation begins again from that actual successor state.

Write
\[
B(x)=\#\{k:\operatorname{remaining}_k(x)>0\}
\]
for the number of currently positive responsibility positions. An input admitted to continue using this repair responsibility requires acceptance of the entire sequence, actual payment of everyone's living and maintenance needs, and clearance of at least one responsibility position. Thus, along the actually admitted sequence,
\[
\#\operatorname{admittedInputs}+B(x_{\mathrm{next}})
\le B(x_{\mathrm{start}}).
\tag{17}
\]
Finiteness comes from the responsibility matrix's actual support. If this occurrence fails to clear a position, it returns a specific threshold failure, unpaid need, or positive residual; earlier actual payments remain.

Along an actual mechanism chain, let \(\mathcal I_{A,g}\) be the complete income of §8.1 accumulated step by step and read at coalition \(A\) and good \(g\). Let \(\operatorname{Consumed}_{A,g}\) be the total consumption at that coordinate recorded by actual use entries in the same execution. The coalition is arbitrary; aggregation reads only the finite effects that actually occur.

**Theorem 13 (A bound for every coalition after a responsibility is settled).** Starting from an actual cleared repair row, along any finite open chain of mechanisms continuing to draw authorization from that responsibility, for any participant coalition \(A\) and any good \(g\),
\[
\mathcal I_{A,g}\le0,
\qquad
\mathcal I_{A,g}+\operatorname{Consumed}_{A,g}=0.
\tag{18}
\]
The settled old repair right no longer authorizes new transfers, production, revision, or financing withdrawals; current legal provision for living and maintenance needs remains payable on its basic grounds.

The same conclusion applies to every finite prefix of any submitted sequence of open mechanisms. The proof first uses admission rules for a cleared row to restrict each step's effects, then adds item-level conservation along actual successors. Different mechanisms may be chosen at successive steps, with each mechanism's initial point and law bound on site to current stocks and permissions. Balances carried by an old mechanism cannot be injected again.

Coalitions now provide a further test: once a repair obligation has been settled, no grouping of participants can obtain positive net income along an open mechanism chain authorized by that old obligation. Theorem 13 covers every coalition, every good, and mechanisms that may change from step to step. Splitting recipients or changing procedures cannot restore a fulfilled claim as a right to draw further resources. Roemer's withdrawal comparison asks which coalitions are disadvantaged by an allocation; equation (18) gives a universal boundary on what a settled obligation can continue to authorize. [@Roemer1982, pp.194–198] New labor, risk, gifts, and services can establish new grounds for income. A settled obligation must actually end.


## 9 Settlement Costs: An Attained Optimum and Completion That Can Always Be Improved

### 9.1 How Obligations Are Actually Archived After Balances Reach Zero

Financial settlement must process both the complete debt matrix and performance histories at individual slots. Each slot stores a specific claim, issuance origin, debtor, holder, remaining principal, and archive status. Several positions may share one address. The allocator must consume the same allowance slot by slot, with later slots receiving only what remains.

A zero balance does not automatically imply archiving. A valid issuance of quantity zero can leave a slot with zero balance that is still active. After actually retiring principal, complete settlement therefore submits a corresponding zero-amount settlement to each position still active, triggering that position's own checks and terminal archiving. It does not consume principal already paid a second time.

**Theorem 14 (Actual archiving of all financial positions).** For any ready settlement state satisfying the recipe and initial-resource conditions, a finite actual repayment program is generated that clears the complete debt matrix, gives every active slot its own terminal archive, and preserves the content and complete history of every obligation. Any subsequent financial run preserves the same archived receipt; new claims use their own new occurrences and positions.

Item-by-item execution and account processing enter actual visits to the common root together. The successor state of that run is the real result of the repayment program, after which the next query resumes. Completion of the full account and continuation of society meet at the same point.

### 9.2 A Financial Tail with Sufficient Resources Has an Actual Optimum

Suppose an already-executed common prefix \(h\) has completed the required production and provision for living and maintenance needs, and current settlement resources are sufficient. We now compare tails that start from the same point and complete these existing financial claims.

The actual cost account separately records production inputs, production maintenance, technological revision, kinds of use, cash transfers, and elapsed time. The linear measure \(J\) below assigns fixed nonnegative weights only to real resource consumption and elapsed time. Cash transfers remain separately recorded in the account; principal used in settlement is not counted as resource destruction. These weights serve comparison and do not determine request admission.

**Theorem 15 (An actual minimizer for the financial tail).** For any such ready state, existing institutional binding, and resource conditions, an actual repayment program \(w_*\) is generated. For any finite strategy program \(w\) of that source and any fixed nonnegative measure \(J\), additional resource and time costs satisfy
\[
J(w_*)\le J(w).
\tag{19}
\]
This minimizer also preserves complete account archiving, current institutional control, root access, and the actual successor. The costs of the already-executed prefix are included in full in the comparison.

**Proof.** The generated repayment sequence performs actual settlement alone. Existing resources retire claims, with zero additional consumption of production resources and zero corresponding clock increment. Every resource and time channel of other programs is nonnegative, so none can be smaller channel by channel. Summing with fixed nonnegative weights gives (19). Theorem 14 supplies archiving of every slot. Existing institutional bindings are preserved along actual repayment, and the endpoint continues with the next query. Program concatenation satisfies
\[
J(h\mathbin{+\!\!+}w)=J(h)+J(w),
\tag{20}
\]
so costs already incurred in the common prefix have not been deleted. □

This comparison quantifies over the whole domain and has an actual minimizer: it covers all finite programs in the financial-tail source, and the generated plan really completes debt settlement and archiving. When production has not yet been completed, settlement faces a different feasible domain.

### 9.3 In One Complete Settlement Domain, Every Completion Can Be Improved

The following source retains actual financing, living provision, maintenance, production, and debt retirement in one history. A fixed prefix first issues debt of 1 and transfers in 1 unit of the settlement good, then pays 1 for necessary living provision and 1 for maintenance. At the comparison point, both parties have zero stock of the settlement good, while debt of 1 remains. The common prefix costs 2.

Available technologies are indexed by \(n\in\mathbb N\). Technology \(n\) produces 1 unit of the settlement good while consuming maintenance of 1 and an input of
\[
\varepsilon_n=\frac1{n+2}.
\]
A request to change technology in this source consumes no additional resources, and the elapsed-time increment of a microstep is 0. Costs assign weight 1 to all resource and time channels. Adopting the technology, producing, and settling form a finite tail \(w_n\), with tail cost \(1+\varepsilon_n\) and full-history cost
\[
J(h\mathbin{+\!\!+}w_n)
=3+\frac1{n+2}.
\tag{21}
\]
Every \(w_n\) actually completes debt settlement, provision for everyone's living and maintenance needs, and terminal archiving of the corresponding slot, while preserving obligation content and history.

**Theorem 16 (Every completing candidate has a strictly cheaper complete alternative).** For any finite program \(w\) of this source, if it actually clears the complete debt matrix, a \(w_n\) can be generated from its own actual cost such that \(w_n\) passes complete-settlement and root-execution checks and
\[
J(h\mathbin{+\!\!+}w_n)
<
J(h\mathbin{+\!\!+}w).
\tag{22}
\]
The infimum of cost in this complete settlement domain is therefore 3, but no completing program minimizes cost.

**The decisive construction.** First show that every completing candidate has tail cost \(c\) strictly greater than 1. At the comparison point there is no settlement good. Issuance can only add claims, transfer preserves total debt, and zero-amount settlement cannot retire positive debt. To clear debt actually, execution must contain real production. Real production requires maintenance of 1 and a strictly positive input; all other costs are nonnegative. Hence \(c>1\).

Now read this arbitrary candidate's own cost and set
\[
\delta=c-1>0,\qquad
n=\left\lceil\frac1\delta\right\rceil.
\tag{23}
\]
Then \(1/(n+2)<\delta\), and the generated tail satisfies
\[
1+\frac1{n+2}<1+\delta=c.
\]
Adding back the same actually incurred prefix cost of 2 on both sides gives (22). For any positive tolerance, a sufficiently large finite \(n\) also supplies a complete plan whose cost lies between \(3\) and \(3\) plus that tolerance, so 3 is the infimum. No completion attains 3 because every completing tail costs more than 1. □

These candidates all start from the same already-executed prefix; the comparison is among available complete suffixes. The algorithm reads the actual cost of any completing candidate, directly chooses a cheaper technology, and produces another complete repayment program. The common prefix cost of 2, already incurred, remains in every plan. Completeness is also checked separately in accounts and institutional execution: actual requests take effect in sequence, corresponding financial processing identifies the same account, and the current institution executes each disposition. The endpoint preserves archives and payment for needs, then returns to a state that can process the next request. Appendix G gives the complete access chain. The lower cost thus belongs to a settlement that truly completes and can continue.

![Cost results for two settlement domains](figures/fig05-cost-en.svg)

Figure 5: The left side compares financial tails after the same point with sufficient resources; actual settlement attains the lower bound on additional resource and time costs. The right side compares complete settlement histories that include production. The horizontal axis is technology parameter \(n\), and cost is \(3+1/(n+2)\). Every point has completed settlement. For any completing candidate in the domain, (23) generates a strictly cheaper complete plan. The starting point and feasible domain on each side determine its conclusion.

### 9.4 Completion Need Not Wait for a Final Optimum

Paying established responsibilities requires an actual completing plan. When resources are sufficient, Theorem 15 gives a minimizer. In a task domain like that of Theorem 16, completion is always possible and always open to improvement. An institution cannot deny that these completions have occurred because no minimum-cost plan exists, nor can one completed settlement confer the right to close off later improvements.

This clarifies the respective work of social continuation and optimization. Payments, archives, and provision for living and maintenance needs that have occurred retain their factual status; new plans answer for their own costs and effects. Joint settlement permits a debt to end while leaving room for new judgments about production.

## 10 How Institutional Change Preserves Old Responsibilities and an Open Future

### 10.1 New Rules Begin from the Current Actual State

Institutions can update code, review, migration, and authorization. The decisive issue is how the update occurs: every source choice reads current stocks, subjects, financial accounts, and the effective law, and the complete report produced by execution enters the next state. Pending financial effects are first processed through their own entry. New institutional action starts from the present point only after current work has been exhausted. Updating does not return to initial stocks or consume completed production again.

The responsibility-progress budget below is a natural-number allowance carried by each responsibility row and transported with the identity of its claim.

**Theorem 17 (Complete continuation through any actual institutional history).** At any finite point of any actual institutional history, all existing responsibility rows receive injective transport of claim identities through actual successors; the budget for responsibility progress does not increase, and paid rows remain paid. For every participant and good,
\[
\operatorname{stock}_{\mathrm{after}}
+\operatorname{debit}
=
\operatorname{stock}_{\mathrm{before}}
+\operatorname{credit};
\tag{24}
\]
for every financial instrument, debtor, and holder,
\[
F_{\mathrm{after}}
=
F_{\mathrm{before}}+\Delta F_{\mathrm{actual}}.
\tag{25}
\]
Every actual net increase in a physical quantity can be traced to an actual positive credit entry accepted in the same execution report. The existing responsibility ledger need not be finite. For a confluence event already issued by the source, the responsibility rows in its actual past generate a common carrier. Each row takes the minimum budget already attained in that past; the event’s own registration procedure generates compatible continuation and the successor of its first write, or returns a specific lineage conflict.

**Proof outline.** Each step uses the complete-account mapping of the actual successor, preserving claims, responsibility rows, and budgets. The physical equality holds item by item through the debit-credit decomposition of operations; the financial equality is updated by the same actual entries. Induction along the finite history completes the proof. If a net increase had no accepted positive credit entry, the right-hand side could not exceed the starting quantity. The increase can therefore be traced back to its own source in production or supply. The confluence branch uses the natural-number minimum actually attained by each responsibility row, then runs the event’s own lineage and registration checks; §10.3 develops this construction. □

Actual external supply, production, cash transfers, and financial issuance have different effects here. A new name does not change the material origin in (24), nor does a new institutional moment change the existing debt in (25). Legal coding, as analyzed by Pistor, can change how rights are organized; this theorem requires those changes to carry actual identities, effects, and responsibilities with them. [@Pistor2019]

### 10.2 Reconstituted Capital Must Identify the Permission That Changed

**Theorem 18 (The exact permission difference of reconstituted capital).** Under the active public interpretation, any purportedly reconstituted capital kernel generates a specific permission address: the law under which it is claimed denies the affected person there, while the currently active interpretation permits access at that same address.

The proof recovers private access asymmetry from the capital witness and then reads the fully open property of the current active public interpretation. Both readings refer to the same technology, port, and affected-person address. If the interpretations are the same, the difference cannot hold. If there has been a change, it appears at that address and must be accounted for by an actual update of the rules.

This develops the question of reproduction into successive institutional effects. Capital relations can be reconstructed and hence traced; their return cannot hide in renaming an organization, rewriting code, or projecting history. Rules may be revised, but the revision itself must supply its occurrence, effective permissions, and continuation of old responsibilities.

The legitimate legislative procedure currently installed uses four dispositions of the common root law: presentation; rejection with a specific reason; execution carrying actual effects and a complete-account successor; and conditional revision triggered by a failure of expression on the same responsibility. Revision generates its own initial write and successor while preserving responsibilities and histories that remain effective. Such openness retains both the capacity to change rules and the matters for which rule changes must answer.

### 10.3 Infinite Old Accounts and Events That Bring Histories Together

Individual executions above are finite, while the ledger of existing responsibilities may be infinite. Complete continuation is defined by each row's actual origin. Parts not updated in this occurrence remain unchanged; updated parts change through actual mappings, without first enumerating the entire past. Coalitions are also read through actual finite effects, so infinite old accounts do not invalidate complete-account equalities.

An event that brings together a sequence of actual past states requires a further account of how rows at those points enter the resulting common carrier. The objects used here are **events already emitted by the source and their actual pasts**. For any old row within them, the responsibility budget is a nonincreasing sequence of natural numbers and therefore reaches a stable minimum at some already-occurred point of its own. Different responsibility rows may stabilize at different points; each value records the actual progress of that row's responsibility.

The generating procedure constructs a common carrier from these actual rows and mappings, preserving claim identities and facts of payment. It then checks lineage compatibility at the event's own registration entry. Compatibility produces a destination row, registration evidence, and the successor of the first actual write after registration. Incompatibility retains a specific past point, the complete row, and the lineage conflict. Splitting and merging in row lifecycles continue to use their own actual evidence; changes of representation do not erase responsibility content.

This result concerns a different object from cost optimization in §9. The minimum of a responsibility budget comes from a descending natural-number chain within the same actual history; cost comparison takes place among different complete programs. The former can stabilize while the latter still has no minimizing completion. Together they allow society to carry forward the past that has occurred while continuing to generate new actions.

### 10.4 Which Judgment in Political Economy the Universal Theorems Change

Marx makes capital a question of production relations and their reproduction. Property-rights theory places the effects of control on action and investment at the center. Arrow and Knight ask how exploration and uncertainty are borne. Ostrom and Hayek require coordination mechanisms to take rules and local knowledge seriously. Following these questions, the paper constructs a common object: how actual needs pass through access, how inputs, returns, and debts form dependence, how control persists, and how life continues after termination.

Roemer argues that even if profits are regarded as a return needed to reproduce capital, the continuing income of particular capitalists does not thereby acquire the same necessity. An investment requirement conditional on maintaining existing property relations cannot, in turn, establish the necessity of those relations themselves. [@Roemer1982, pp.276–278] This paper develops that question into preservation and continuation results across the entire execution domain. Theorem 8 generates a complete public replay of any given execution; §7 connects dispositions for unknown events, an instance of successive innovation with actual payment, and contribution bounds across all accounts to future action; Theorem 6 checks the current transition and an executable future. Production, exploration, and settlement each have their own conditions of fulfillment. Continuing control must have a present justification independent of past contributions.

The same distinction changes the unit by which abolition is judged. Theorem 5 brings any capital relation into the same social contract, and Theorem 6 advances the actual run to a finite complete answer. Success jointly supplies improvement in complete accounts, migration, and an executable future; settlement is then completed through specific resources and archiving procedures. Failure retains specific responsibilities. Theorems 17–18 further show that changes in rules and coalitions, and the reconstitution of capital, must all have identifiable destinations in actual permissions and complete accounts.

Basic participation gives these constructions a definite institutional purpose: people can end a controlled relation while continuing to live, produce, and create. Contributions can be repaid, debts settled, terms ended, and methods used by those who come later. The structural theory covering all forms connects these requirements in one checkable run, so that the necessity of production ceases to warrant the permanent continuation of any historical relation of control.

## Formal Proofs and Materials for Verification

The natural-language theorems, decisive proofs, and technical supplement together constitute the argument. Appendices A–H give technical details and declaration correspondences for capital objects, reconstruction, actual disposition, public replay, innovation and contributions, complete accounts, costs, and dynamic continuation. Editable figures and both language versions use the same objects and formulas.

The formal source is fixed at version commit df421ff600085cbc290a7ae946193961bed7c83b of the formal research repository Homework; the public reproduction selection is fixed at version commit 2d6fbc96e33b7c4c3cfd91104fda74e3caeda045 of the public code repository H0mework. The accompanying source correspondences and verification notes identify the public modules, declarations, direct uses, and source identities. Code checking, mathematical statements, and institutional reasons undertake their respective parts of the argument: definitions and proofs preserve quantifiers and actual execution, while §2 and the literature discussions explain the choice of concepts and institutional requirements.

## References

[Marx1867] Marx, Karl. *Capital: A Critique of Political Economy*, vol. I. 1867. English edition, 1887, translated by Samuel Moore and Edward Aveling, edited by Friedrich Engels. [Chapters 6, 23, 26](https://www.marxists.org/archive/marx/works/1867-c1/).

[GrossmanHart1986] Grossman, Sanford J., and Oliver D. Hart. “The Costs and Benefits of Ownership: A Theory of Vertical and Lateral Integration.” *Journal of Political Economy* 94(4), 1986: 691–719. [doi:10.1086/261404](https://doi.org/10.1086/261404).

[HartMoore1990] Hart, Oliver, and John Moore. “Property Rights and the Nature of the Firm.” *Journal of Political Economy* 98(6), 1990: 1119–1158. [doi:10.1086/261729](https://doi.org/10.1086/261729).

[Arrow1962] Arrow, Kenneth J. “[Economic Welfare and the Allocation of Resources for Invention](https://www.nber.org/system/files/chapters/c2144/c2144.pdf).” In *The Rate and Direction of Inventive Activity: Economic and Social Factors*, 609–626. Princeton University Press for NBER, 1962.

[Knight1921] Knight, Frank H. *[Risk, Uncertainty, and Profit](https://www.econlib.org/library/Knight/knRUP.html)*. Boston and New York: Houghton Mifflin, 1921. Part III, chapters VII and IX.

[Hayek1945] Hayek, F. A. “[The Use of Knowledge in Society](https://www.econlib.org/library/Essays/hykKnw.html).” *American Economic Review* 35(4), 1945: 519–530.

[Ostrom2009] Ostrom, Elinor. “[Beyond Markets and States: Polycentric Governance of Complex Economic Systems](https://www.nobelprize.org/uploads/2018/06/ostrom_lecture.pdf).” Nobel Prize Lecture, 8 December 2009.

[Pistor2019] Pistor, Katharina. “Coding Capital for the Globe.” *Stanford Social Innovation Review*, 4 September 2019. Excerpt from *The Code of Capital*. [doi:10.48558/GYV7-NE54](https://doi.org/10.48558/GYV7-NE54).

[Sen1980] Sen, Amartya. “[Equality of What?](https://tannerlectures.org/documents/sen80/)” In *The Tanner Lectures on Human Values*, vol. 1, edited by Sterling M. McMurrin, 197–220. Cambridge University Press, 1980. Lecture delivered 22 May 1979.

[Robeyns2017] Robeyns, Ingrid. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Cambridge: Open Book Publishers, 2017. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[Anderson2015] Anderson, Elizabeth. “[Liberty, Equality, and Private Government](https://tannerlectures.utah.edu/_resources/documents/a-to-z/a/Anderson%20manuscript.pdf).” *The Tanner Lectures on Human Values*, delivered at Princeton University, 4–5 March 2015.

[Fraser2016] Fraser, Nancy. “[Contradictions of Capital and Care](https://newleftreview.org/issues/ii100/articles/nancy-fraser-contradictions-of-capital-and-care).” *New Left Review* 100, 2016: 99–117.

[AcemogluRestrepo2019] Acemoglu, Daron, and Pascual Restrepo. “Automation and New Tasks: How Technology Displaces and Reinstates Labor.” *Journal of Economic Perspectives* 33(2), 2019: 3–30. [doi:10.1257/jep.33.2.3](https://doi.org/10.1257/jep.33.2.3).

[HartZingales2022] Hart, Oliver, and Luigi Zingales. “[The New Corporate Governance](https://businesslawreview.uchicago.edu/print-archive/new-corporate-governance).” *The University of Chicago Business Law Review* 1(1), 2022: 195–216.

[Gao2026Society] Gao, Jian（高健）. *The Canonical Society Theorem（典范社会总定理）*. Version 2. Preprint. Zenodo, 2026. [doi:10.5281/zenodo.23917896](https://doi.org/10.5281/zenodo.23917896).

[Gao2026Constitution] Gao, Jian（高健）. *An Economic Constitution of Possibility（可能性的经济宪法）*. Version 2. Preprint. Zenodo, 2026. [doi:10.5281/zenodo.23917902](https://doi.org/10.5281/zenodo.23917902).

[Acemoglu2025] Acemoglu, Daron. “The Simple Macroeconomics of AI.” *Economic Policy* 40(121), 2025: 13–58. First published online 6 August 2024. [doi:10.1093/epolic/eiae042](https://doi.org/10.1093/epolic/eiae042).

[Roemer1982] Roemer, John E. *A General Theory of Exploitation and Class*. Cambridge, MA, and London: Harvard University Press, 1982. [doi:10.4159/harvard.9780674435865](https://doi.org/10.4159/harvard.9780674435865).
