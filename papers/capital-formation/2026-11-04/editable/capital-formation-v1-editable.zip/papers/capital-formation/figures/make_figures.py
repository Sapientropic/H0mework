#!/usr/bin/env python3
"""Editable bilingual figures for The Structural Theorem of Capitalism.

Run with python3 in an environment with the figure dependencies.
Shared fonts and colors are read-only dependencies. No manuscript text is changed.
SVG text stays editable; PDFs contain text and vector paths, never preview pixels.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from html import escape
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys
import unicodedata

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH
import svg_text
from svg_text import line
svg_text.OPS.update("∅↔⇒≤∀∃∑")
W, PRINT_WIDTH, MIN_SIZE = 1440, 464, 24
LANG = "zh"
CHECK_ONLY = False
PARTS, BOXES, SHAPES, MANIFEST = [], [], [], []
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

def L(zh, en):
    return zh if LANG == "zh" else en

@lru_cache(maxsize=None)
def metrics(cls, weight):
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont
    font_path = svg_text._FONT_FILES[cls]
    if cls == "zh" and weight >= 600:
        suffix = "Bold" if weight >= 700 else "SemiBold"
        font_path = Path.home() / "Library/Fonts" / ("NotoSerifCJKsc-" + suffix + ".otf")
    font = TTFont(str(font_path))
    if "fvar" in font:
        font = instantiateVariableFont(font, {"wght": weight}, inplace=True)
    return font.getBestCmap(), font["hmtx"].metrics, font["head"].unitsPerEm

def width(text, size, weight):
    total = 0
    for piece, tag in svg_text._pieces(str(text)):
        actual_size = svg_text._script(size, MIN_SIZE) if tag in ("sub", "sup", "isub") else size
        actual_weight = 700 if tag == "b" else weight
        for ch in piece:
            cls = "en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i", "isub") and cls == "en":
                cls = "it"
            cmap, hmtx, upm = metrics(cls, actual_weight)
            glyph = cmap.get(ord(ch))
            assert glyph in hmtx, ("missing glyph", ch, cls, actual_weight)
            total += hmtx[glyph][0] * actual_size / upm
    return total

def start(height, title, description):
    PARTS.clear(); BOXES.clear(); SHAPES.clear()
    PARTS.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" viewBox="0 0 {W} {height}" role="img" style="font-variant-ligatures:none;font-feature-settings:normal">')
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append(f'<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="{DEEP}"/></marker><marker id="arrow-neutral" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="{MUTE}"/></marker></defs>')
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height

def txt(x, y, text, size=28, color=INK, weight=400, anchor="start", max_width=None):
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, tw, max_width)
    x0 = x - {"start": 0, "middle": tw/2, "end": tw}[anchor]
    BOXES.append({"box": [x0, y-.90*size, x0+tw, y+.28*size],
                  "text": text, "font_px": size})
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))

def lines(x, y, labels, size=28, color=INK, weight=400, anchor="start", gap=39, max_width=None):
    for i, label in enumerate(labels):
        txt(x, y+i*gap, label, size, color, weight, anchor, max_width)

def path(d, bounds, color=HAIR, stroke=1.8, arrow=False, dashed=False):
    marker_id = "arrow-neutral" if color in (HAIR, MUTE, SLATE) else "arrow"
    marker = f' marker-end="url(#{marker_id})"' if arrow else ""
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round"{marker}{dash}/>')
    SHAPES.append(bounds)

def segment(x1, y1, x2, y2, color=HAIR, stroke=1.8, arrow=False, dashed=False):
    path(f"M {x1} {y1} L {x2} {y2}",
         [min(x1,x2), min(y1,y2), max(x1,x2), max(y1,y2)],
         color, stroke, arrow, dashed)

def rect(x, y, w, h, stroke=HAIR, fill="white", sw=1.8):
    PARTS.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    SHAPES.append([x,y,x+w,y+h])

def circle(x, y, r, color=DEEP, fill="white", sw=2.4):
    PARTS.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="{sw}"/>')
    SHAPES.append([x-r,y-r,x+r,y+r])

def rule(y):
    segment(48,y,1392,y,HAIR,1.5)

def normalized(text):
    return "".join(unicodedata.normalize("NFKC", text).split())

def repair_pdf_text_mapping(pdf, expected):
    """Preserve source characters when Chrome chooses a same-glyph radical alias.

    Only aliases sharing the exact font glyph with a unique source character
    are changed. Vector glyphs and geometry are untouched.
    """
    import pymupdf
    cmap = metrics("zh", 400)[0]
    glyph_sources = {}
    for ch in set(expected):
        if 0x3400 <= ord(ch) <= 0x9fff and ord(ch) in cmap:
            glyph_sources.setdefault(cmap[ord(ch)], set()).add(ch)
    aliases = {}
    for cp, glyph in cmap.items():
        choices = glyph_sources.get(glyph, set())
        if 0x2e80 <= cp <= 0x2fff and len(choices) == 1:
            aliases[chr(cp)] = next(iter(choices))
    repairs = {}
    temporary = pdf.with_suffix(".unicode.pdf")
    with pymupdf.open(pdf) as doc:
        changed = False
        for xref in range(1, doc.xref_length()):
            if not doc.xref_is_stream(xref):
                continue
            stream = doc.xref_stream(xref)
            if b"begincmap" not in stream:
                continue
            def replace(match):
                original = chr(int(match[2], 16))
                replacement = aliases.get(original)
                if replacement is None:
                    return match[0]
                repairs[original] = replacement
                return match[1] + ("<%04X>" % ord(replacement)).encode()
            repaired = re.sub(rb"(<[0-9A-Fa-f]+>\s+)<([0-9A-Fa-f]{4})>", replace, stream)
            if repaired != stream:
                doc.update_stream(xref, repaired)
                changed = True
        if changed:
            doc.save(temporary, garbage=4, deflate=True)
    if repairs:
        temporary.replace(pdf)
    return repairs

def save(stem, height, semantics):
    for i, item in enumerate(BOXES):
        a=item["box"]
        assert a[0]>=16 and a[2]<=W-16 and a[1]>=8 and a[3]<=height-8, ("outside canvas",item)
        for other in BOXES[i+1:]:
            b=other["box"]
            assert not (a[0]<b[2] and b[0]<a[2] and a[1]<b[3] and b[1]<a[3]), ("text overlap",item["text"],other["text"])
    for s in SHAPES:
        assert min(s[:2])>=8 and s[2]<=W-8 and s[3]<=height-8, ("shape outside",s)
    name=stem+("-en" if LANG=="en" else "")
    entry={"stem":name,"language":LANG,"canvas_px":[W,height],"print_width_pt":PRINT_WIDTH,
           "minimum_text_px":MIN_SIZE,"glyph_coverage":"pass","text_geometry":"pass",
           "shape_bounds":"pass","semantics":semantics,"labels":list(BOXES)}
    if CHECK_ONLY:
        MANIFEST.append(entry)
        return
    svg=OUT/(name+".svg")
    svg.write_text("\n".join(PARTS+["</svg>"])+"\n",encoding="utf-8")
    preview=OUT/".review"
    preview.mkdir(exist_ok=True)
    page=preview/(name+".html")
    hp=height/W*PRINT_WIDTH
    page.write_text('<!doctype html><html><head><meta charset="utf-8"><style>'
        +f'@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}'
        +f'img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>'
        +f'<body><img src="{svg.as_uri()}"></body></html>')
    pdf=OUT/(name+".pdf")
    result=subprocess.run([CHROME,"--headless=new","--disable-gpu","--no-pdf-header-footer",
        "--no-first-run","--allow-file-access-from-files",
        f"--user-data-dir={preview/'chrome-profile'}",f"--print-to-pdf={pdf}",page.as_uri()],
        capture_output=True,text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:]+result.stderr[-2000:])
    import pymupdf
    expected="".join(piece for b in BOXES for piece,_ in svg_text._pieces(b["text"]))
    text_repairs=repair_pdf_text_mapping(pdf,expected)
    with pymupdf.open(pdf) as doc:
        assert len(doc)==1, ("page count",name,len(doc))
        p=doc[0]
        assert abs(p.rect.width-PRINT_WIDTH)<1 and abs(p.rect.height-hp)<1
        assert not p.get_images(full=True), ("raster image in vector PDF",name)
        pdf_text=p.get_text()
        assert "\ufffd" not in pdf_text, ("replacement character",name)
        expected="".join(piece for b in BOXES for piece,_ in svg_text._pieces(b["text"]))
        missing=Counter(normalized(expected))-Counter(normalized(pdf_text))
        assert not missing, ("text missing from PDF",name,dict(missing))
        span_count=0
        for block in p.get_text("dict")["blocks"]:
            for ln in block.get("lines",[]):
                for span in ln["spans"]:
                    span_count+=1
                    x0,y0,x1,y1=span["bbox"]
                    assert x0>=-1 and y0>=-1 and x1<=p.rect.width+1 and y1<=p.rect.height+1, ("PDF text outside",name,span)
                    assert span["size"]>=MIN_SIZE/W*PRINT_WIDTH*.95, ("PDF type below floor",name,span)
        assert span_count>0 and p.get_drawings(), ("empty PDF",name)
        fonts=sorted({font[3] for font in p.get_fonts(full=True)})
        p.get_pixmap(matrix=pymupdf.Matrix(W/p.rect.width,W/p.rect.width),alpha=False).save(OUT/(name+".png"))
        entry["pdf_checks"]={"pages":1,"raster_images":0,"editable_text_spans":span_count,
                             "glyph_text_preserved":True,"all_text_in_page":True,"fonts":fonts,
                             "font_types":sorted({f[2] for f in p.get_fonts(full=True)}),
                             "source_character_mapping_repairs":text_repairs}
    entry["files"]={}
    for ext in ("svg","pdf","png"):
        f=OUT/(name+"."+ext)
        entry["files"][ext]={"path":f.name,"bytes":f.stat().st_size,
                             "sha256":hashlib.sha256(f.read_bytes()).hexdigest()}
    MANIFEST.append(entry)

def structure():
    h=start(800,L("权限不对称与资本关系的五面刻画","Permission asymmetry and the five faces of capital"),
      L("左侧是固定生产来源族的四种权限赋值，资本仅在控制者获准且受影响者被拒时出现。右侧列出完整无资本条件的五个分量。底部一般充要关系对任意权限法则成立；矩阵不表示无资本自动支付了需要。",
        "The left matrix varies permissions within one fixed production-source family. Capital occurs exactly when the controller is allowed and the affected person is refused. The right lists five components of the complete no-capital condition. The general equivalence below quantifies over every permission law; absence of capital alone does not pay needs."))
    txt(48,52,L("A  同一生产来源的权限矩阵","A  Permissions in one source family"),30,DEEP,600,max_width=655)
    txt(780,52,L("B  完整无资本条件","B  Complete no-capital condition"),30,DEEP,600,max_width=610)
    txt(780,100,L("以下五类见证全部排除","All five kinds of witness are absent"),25,SLATE,max_width=610)
    segment(720,95,720,594,HAIR,1.8)
    txt(440,125,L("控制者 c","Controller c"),29,DEEP,600,"middle",400)
    txt(330,188,L("未获准","Refused"),28,SLATE,anchor="middle",max_width=190)
    txt(550,188,L("获准","Allowed"),28,SLATE,anchor="middle",max_width=190)
    txt(48,259,L("受影响者 i","Affected i"),26,DEEP,600,max_width=175)
    for cy,row in [(290,0),(450,1)]:
        txt(168,cy+12,L("未获准" if not row else "获准","Refused" if not row else "Allowed"),26,SLATE,anchor="end",max_width=155)
        for cx,col in [(330,0),(550,1)]:
            is_capital=col==1 and row==0
            rect(cx-100,cy-64,200,128,VERMILION if is_capital else HAIR,WASH if is_capital else "white",2 if is_capital else 1.5)
            txt(cx,cy+13,L("资本关系" if is_capital else "无资本","Capital" if is_capital else "No capital"),
                31,VERMILION if is_capital else DEEP,600 if is_capital else 400,"middle",185)
    txt(440,567,L("控制者获准而受影响者被拒","Controller allowed; affected person refused"),25,VERMILION,600,"middle",650)
    faces=[("私人准入差异","Private access asymmetry"),("资本关系核心","Capital-relation kernel"),
           ("可转移的资产控制","Transferable asset control"),("实际剩余占有","Actual surplus"),
           ("历史关系的当期控制","Current control from history")]
    for j,(zh,en) in enumerate(faces):
        y=155+j*87
        circle(802,y-9,7,DEEP,DEEP,1)
        txt(830,y,L(zh,en),31,DEEP,600,max_width=540)
        segment(830,y+25,1385,y+25,HAIR,1.4)
    rule(634)
    txt(720,697,"NoCapital(L) ↔ NoAsymmetry(L)",39,DEEP,600,"middle",1300)
    txt(720,761,L("任意端口 p 与人 i：c 获准 ⇒ i 获准","For every port p and person i: c allowed ⇒ i allowed"),29,INK,anchor="middle",max_width=1320)
    save("fig01-structure",h,{"matrix_scope":"one fixed Permissions source family","capital_iff":{"controller":True,"affected":False},
      "five_faces":["private phase","kernel","proper title","actual surplus","fresh history"],
      "general_equivalence":"NoCapital law iff NoAsymmetry law","all_laws":True,"needs_payment_is_separate":True})

def disposition():
    h=start(1200,L("全形态进入与完整实际处置","Universal admission and complete actual disposition"),
      L("同一实际资本关系自行生成正登记，再进入统一社会合同。金融入口区分债务已表示与准确矩阵差额；已表示分支在internalMass+1步以内到达完整实际处置。成功依次通过财务、成员迁移与当前未来检查，失败保留对应来源与检查。",
        "The actual capital relation generates positive registration and enters the common social contract. The financial boundary distinguishes represented debt from an exact matrix discrepancy. The represented branch reaches complete actual disposition within internalMass+1 steps. Success passes financial, member-migration and current-future checks in order; each failure retains its exact source check."))
    boxes=[(48,360,L("任意实际资本关系 C","Any actual relation C")),
           (520,380,L("C 自行生成正登记","Positive registration by C")),
           (1010,382,L("统一社会合同","Common social contract"))]
    for x,w,label in boxes:
        rect(x,58,w,92,DEEP,sw=2)
        txt(x+w/2,112,label,29,DEEP,600,"middle",w-28)
    segment(420,104,504,104,DEEP,2.4,arrow=True)
    segment(912,104,994,104,DEEP,2.4,arrow=True)
    txt(720,207,L("按实际金融入口分派","Dispatch at the actual financial boundary"),28,SLATE,anchor="middle",max_width=1320)
    path("M 1201 162 L 1201 225 L 275 225 L 275 257",[275,162,1201,257],HAIR,1.8,True)
    segment(1201,225,1201,257,DEEP,1.8,arrow=True)
    rect(48,270,455,260,HAIR,WASH,1.5)
    txt(275,320,L("入口留下债务差额","Debt discrepancy at entry"),30,DEEP,600,"middle",420)
    lines(275,379,L(["确切的工具、债务人与债权人","对应矩阵项不相等"],
                   ["Exact instrument, debtor, creditor","The corresponding entries differ"]),
          26,INK,anchor="middle",gap=43,max_width=420)
    txt(275,486,L("规则与实际后继仍保留","Law and actual next are retained"),26,DEEP,600,"middle",420)
    rect(565,270,827,92,DEEP,"white",2)
    txt(978,322,L("债务已由运行入口表示","Debt represented by the execution boundary"),30,DEEP,600,"middle",785)
    txt(978,408,L("到完整处置的步数 ≤ m(x) + 1","Steps to complete disposition ≤ m(x) + 1"),27,VERMILION,600,"middle",805)
    rect(580,435,445,84,DEEP,sw=1.8)
    txt(802,487,L("初始替代审查","Initial replacement review"),29,DEEP,600,"middle",415)
    path("M 568 477 L 535 477 L 535 735 L 508 735",[508,477,568,735],MUTE,1.8,True)
    segment(802,531,802,569,DEEP,2.2,True)
    txt(838,558,L("进入公共执行","Public execution"),25,SLATE,max_width=240)
    checks=[
      (610,"财务全账","Full financial account","财务审计失败","Financial audit issue"),
      (750,"成员实际迁移","Actual member migration","迁移检查失败","Migration issue"),
      (890,"当前可执行未来","Currently executable future","当前候选域的阻塞","Candidate obstruction")]
    for idx,(y,zh,en,zf,ef) in enumerate(checks):
        rect(580,y-35,445,84,DEEP,sw=1.8)
        txt(802,y+17,L(zh,en),29,DEEP,600,"middle",415)
        segment(1038,y+7,1078,y+7,MUTE,1.8,True)
        rect(1090,y-30,302,74,MUTE,"white",1.3)
        txt(1241,y+16,L(zf,ef),25,SLATE,anchor="middle",max_width=274)
        if idx<2: segment(802,y+62,802,y+98,DEEP,2.2,True)
    rect(48,650,455,245,HAIR,WASH,1.5)
    txt(275,708,L("替代审查阻塞","Replacement review obstructed"),29,DEEP,600,"middle",425)
    lines(275,775,L(["仍处于受控状态","既有责任行及预算保持"],
                   ["The controlled state remains","Existing claims and budgets persist"]),
          26,INK,anchor="middle",gap=45,max_width=425)
    segment(802,952,802,997,DEEP,2.2,True)
    rect(565,1012,827,136,DEEP,WASH,2)
    txt(978,1063,L("完整废止见证","Complete abolition witness"),31,DEEP,600,"middle",785)
    txt(978,1114,L("生活与维护 · 生产能力 · 未来 · 全账增益","Life and maintenance · capacity · future · account gains"),27,DEEP,anchor="middle",max_width=785)
    save("fig02-disposition",h,{"scope":"any actual source CapitalRelationKernel and ControlUse",
      "registration":"strictly positive, generated from C","outer_dispatch":["represented initial claims","exact instrument/debtor/creditor matrix discrepancy"],
      "finite_bound":"current.internalMass + 1","bound_target":"CompleteActualDisposition; success or residual",
      "initial_review_failure":"preserves controlled state and existing responsibility rows",
      "ordered_checks":["financial","migration of original members in actual first body","adaptive future at current cut"],
      "failure_preserves_exact_check":True,"law_and_next_preserved_on_outer_residual":True})

def replay():
    h=start(790,L("公共重放保留同一完整后态","Public replay preserves the same complete next state"),
      L("每条实际执行词逐项转换为公共执行，操作位置数不变、执行项逐一映射、完整后态严格相等。生活维护和任务服务各自等价；重放生成合法开放请求且无控制者同意门。",
        "Every actual word is transformed position by position into a public execution. Its length is unchanged, execution items are mapped one to one, and the complete next state is exactly equal. Needs payment and task service are each equivalent. The replay generates valid open requests without controller-consent gates."))
    txt(48,52,L("任意权限法则 L、状态 s 与执行词 w","Any law L, state s and execution word w"),30,DEEP,600,max_width=1320)
    txt(720,113,L("同一发生逐项对应","One occurrence, matched position by position"),28,SLATE,anchor="middle",max_width=1280)
    for y,label,short in [(235,L("执行词 w 的实际项","Actual items of w"),"I"),(445,L("公共重放 R(w)","Public replay R(w)"),"J")]:
        txt(48,y-68,label,30,DEEP,600,max_width=600)
        circle(100,y,35,DEEP,sw=2.1); txt(100,y+10,"s",31,DEEP,600,"middle")
        segment(150,y,250,y,DEEP,2.2,True)
        for x,num in [(330,1),(590,2),(1040,"k")]:
            rect(x-65,y-40,130,80,DEEP,sw=1.8)
            txt(x,y+11,f"{short}{{sub:{num}}}",29,DEEP,600,"middle",120)
        segment(410,y,510,y,DEEP,2.2,True)
        segment(670,y,750,y,DEEP,2.2,True)
        txt(825,y+8,"· · ·",32,SLATE,anchor="middle",max_width=110)
        segment(895,y,960,y,DEEP,2.2,True)
    segment(1120,235,1260,320,DEEP,2.2,True)
    segment(1120,445,1260,360,DEEP,2.2,True)
    circle(1320,340,52,VERMILION,sw=2.5)
    txt(1320,351,"s′",34,VERMILION,600,"middle")
    for x in (330,590,1040):
        segment(x,290,x,386,HAIR,1.8,True,True)
    txt(790,343,L("逐项映射","item map"),26,SLATE,anchor="middle",max_width=270)
    rule(540)
    segment(500,570,500,695,HAIR,1.3)
    segment(940,570,940,695,HAIR,1.3)
    txt(280,607,L("同长度 · 同一完整后态","Same length · same next state"),28,VERMILION,600,"middle",420)
    txt(280,657,L("执行项逐一映射","Item-by-item mapping"),25,SLATE,anchor="middle",max_width=420)
    txt(720,607,L("生活维护支付 ↔ 重放支付","Needs paid ↔ replay paid"),25,DEEP,600,"middle",410)
    txt(720,657,L("任务服务适足 ↔ 重放适足","Service adequate ↔ replay adequate"),24,INK,anchor="middle",max_width=410)
    txt(1160,607,L("请求合法 · 需要端口开放","Valid requests · required ports open"),24,DEEP,600,"middle",420)
    txt(1160,657,L("无控制者同意门","No controller-consent gate"),25,INK,anchor="middle",max_width=420)
    txt(720,754,L("被拒绝的位置保留为同位置的零作用记录","Each rejected position is retained as a zero-effect record at that position"),26,SLATE,anchor="middle",max_width=1330)
    save("fig03-replay",h,{"universal_inputs":["law","current","word","members","task"],
      "length_preserved":True,"full_next":"literal equality","shared_next_state_node":True,"rawItems":"map(itemAt law)",
      "needs_payment":"iff","service_adequacy":"iff","public_requests":"valid; consents=[]; required ports allowed",
      "no_capital_kernel":True,"vertical_arrows":"replay item map","horizontal_arrows":"execution order"})

def innovation():
    h=start(920,L("连续创新与贡献来源的有限结算","Successive innovation and bounded settlement by origin"),
      L("上部是实付创新见证：机制先于未知事件固定，技术从0到1到2；每轮物量投资3、消息资源3（含观察收费1），生活与维护分别实付。第二发现不在任何一轮报价菜单中，旧债1保持。下部是一般贡献界：按同一发行来源o汇总所有账户槽的实际本金退休或贡献受领，累计量不超过其quantity，不是个人全部收入上限。",
        "Above: a paid innovation witness. The mechanism is fixed before the unknown event, technology moves from 0 to 1 to 2, and each round separately pays material investment 3 and message resource 3, including observation fee 1, plus living and maintenance for everyone. Discovery 2 occurs in neither quote menu; old debt 1 persists. Below: the general contribution bound sums actual principal retirement or contribution receipts across every slot with issuance origin o and bounds that sum by its quantity. It is not a cap on all income."))
    txt(48,48,L("A  固定机制，连续实付","A  Fixed mechanism, successive payment"),30,DEEP,600,max_width=1320)
    txt(720,86,L("机制先固定 → 未知事件 → 当期实际支付 → 下一试验","Mechanism fixed → unknown event → actual period payment → next trial"),
        27,SLATE,anchor="middle",max_width=1330)
    xs=(110,720,1310)
    txt(415,126,L("第一轮","Round 1"),29,DEEP,600,"middle")
    txt(1015,126,L("第二轮","Round 2"),29,DEEP,600,"middle")
    for x,num,label in zip(xs,(0,1,2),[L("初始状态","Initial state"),L("第一次发现","First discovery"),L("第二次发现","Second discovery")]):
        col=VERMILION if num==2 else DEEP
        circle(x,160,43,col,sw=2.7)
        txt(x,176,str(num),49,col,600,"middle")
        txt(x,230,label,27,col,600,"middle",240)
    for x1,x2 in zip(xs,xs[1:]): segment(x1+60,160,x2-60,160,DEEP,2.7,True)
    for x,round_no,round_zh in [(80,1,"第一"),(790,2,"第二")]:
        rect(x,265,570,200,HAIR,sw=1.5)
        txt(x+24,300,L(f"{round_zh}轮：实际付款",f"Round {round_no}: actual payment"),29,DEEP,600,max_width=522)
        txt(x+24,343,L("物量投资","Material investment"),27,max_width=310)
        txt(x+546,343,L("3 物量单位","3 physical units"),27,DEEP,600,"end",max_width=240)
        txt(x+24,382,L("消息资源总消耗","Message resource spent"),27,max_width=330)
        txt(x+546,382,L("3 消息单位","3 message units"),27,DEEP,600,"end",max_width=240)
        txt(x+24,414,L("含观察收费：1 消息单位","Observation fee included: 1 message unit"),24,SLATE,max_width=522)
        txt(x+24,446,L("全员生活、维护分别实付","For all: living and maintenance paid separately"),25,INK,max_width=522)
    txt(720,510,L("第二次发现不在任何一轮的报价菜单中","Discovery 2 is absent from both rounds' quoted menus"),30,VERMILION,600,"middle",1320)
    txt(48,555,L("同一旧债：1 债务单位，贯穿两轮","Same old debt: 1 debt unit, carried through both rounds"),27,DEEP,max_width=800)
    segment(110,590,1310,590,DEEP,2.2)
    for x in xs:
        segment(x,577,x,603,DEEP,2.2)
        circle(x,590,5,DEEP,DEEP,1)
    txt(720,645,L("物量、消息资源与债务各有单位，数值不相加","Material, message and debt units are distinct; these numbers are not added"),
        26,SLATE,anchor="middle",max_width=1340)
    rule(680)
    txt(48,725,L("B  同一贡献来源 o，汇总其全部槽","B  Aggregate all slots belonging to contribution origin o"),30,DEEP,600,max_width=1320)
    for j,label in enumerate([L("槽 1","slot 1"),L("槽 2","slot 2"),"…",L("槽 k","slot k")]):
        x=160+j*210
        if label!="…": rect(x-70,770,140,70,HAIR,sw=1.5)
        txt(x,818,label,29,DEEP,anchor="middle",max_width=130)
    path("M 90 852 L 90 868 L 860 868 L 860 852",[90,852,860,868],HAIR,1.6)
    segment(880,805,954,805,DEEP,2.2,True)
    lines(1180,810,L(["同一来源的累计受领","≤ 该来源发行数量"],
                     ["Cumulative receipts for o","≤ quantity issued at o"]),
          28,VERMILION,600,"middle",gap=40,max_width=420)
    txt(720,895,L("转让、换槽与等待不充值贡献；其他来源收入各按其账","Transfers, new slots and waiting do not refill o; other origins keep their own accounts"),
        26,INK,anchor="middle",max_width=1330)
    save("fig04-innovation",h,{"panel_A":"constructive paid-renewal witness","technology_states":[0,1,2],
      "mechanism_before_nature":True,"separate_actual_payment_each_round":True,
      "physical_investment_each_round":3,"message_resource_consumption_each_round":3,
      "observation_fee_included_message_units":1,"living_and_maintenance_separately_paid_for_all":True,
      "units_not_additive":True,"second_discovery_absent_from_all_quoted_menus":True,"old_debt":1,
      "panel_B":"universal origin bound","receivedForOrigin":"sum actualPaid principal retirement / contribution receipts over all slots matching origin",
      "bound":"<= original quantity","not_person_total_income":True,"other_origin_income":"separately accounted"})

def cost():
    h=start(880,L("两种清算域，两种最优性结论","Two clearing domains and two optimality conclusions"),
      L("左部资源足额的金融清算尾具有实际成本达到者，其成本不高于同域全部允许策略。右部为另一完整清算源的离散族J(h ++ w_n)=3+1/(n+2)，n为非负整数技术参数；每点均含完整生活维护、真实付款与归档。极限3不被该完成域达到，每个完成候选由自身成本差构造从同一已发生前缀出发的更便宜完整清算。",
        "Left: a resource-sufficient financial clearing tail has an actual cost attainer no more expensive than any admissible policy in that domain. Right: a different complete-clearing source has the discrete family J(h ++ w_n)=3+1/(n+2), n a nonnegative integer technology parameter. Every point includes living, maintenance, actual payments and archival. The limit 3 is not attained in the completion domain; each completed candidate supplies a cost gap used to construct a cheaper rooted completion from the same incurred prefix."))
    txt(48,52,L("A  资源足额的金融清算尾","A  Resource-sufficient financial tail"),30,DEEP,600,max_width=635)
    txt(765,52,L("B  另一完整清算域","B  A different complete-clearing domain"),30,DEEP,600,max_width=630)
    segment(720,90,720,742,HAIR,1.7)
    rect(76,139,588,130,DEEP,WASH,2)
    txt(370,192,L("实际执行的达到者 w*","Actual executed attainer w*"),31,DEEP,600,"middle",550)
    txt(370,239,L("完整账户、归档与控制保持","Accounts, archive and control retained"),27,DEEP,anchor="middle",max_width=550)
    txt(370,350,"J(w*) ≤ J(w)",40,VERMILION,600,"middle",580)
    txt(370,400,L("对该域内每个允许策略 w","For every admissible policy w in this domain"),27,SLATE,anchor="middle",max_width=600)
    rect(76,485,190,110,HAIR,"white",1.5)
    rect(296,485,190,110,DEEP,"white",1.8)
    rect(516,485,148,110,HAIR,"white",1.5)
    segment(266,540,286,540,DEEP,2,True)
    segment(486,540,506,540,DEEP,2,True)
    lines(171,525,L(["已发生成本","完整保留"],["Incurred cost","retained"]),
          24,INK,anchor="middle",gap=38,max_width=170)
    lines(391,525,L(["金融尾 w*","实际比较"],["Financial tail","w* comparison"]),
          24,DEEP,600,anchor="middle",gap=38,max_width=170)
    lines(590,525,L(["实际后继","继续执行"],["Actual next","continues"]),
          24,INK,anchor="middle",gap=38,max_width=124)
    # Right panel: exact discrete points. No fabricated observations or connecting curve.
    x0,x1,y0,y1=845,1350,535,160
    def xp(n): return x0+n/12*(x1-x0)
    def yp(v): return y0-(v-3)/.55*(y0-y1)
    segment(x0,y1,x0,y0,SLATE,1.7)
    segment(x0,y0,x1+18,y0,SLATE,1.7)
    for val,lab in [(3,"3"),(3.25,"3.25"),(3.5,"3.5")]:
        yy=yp(val); segment(x0-7,yy,x0,yy,SLATE,1.7)
        txt(x0-17,yy+9,lab,25,SLATE,anchor="end",max_width=75)
        if val==3: segment(x0,yy,x1,yy,VERMILION,2.1,False,True)
        else: segment(x0,yy,x1,yy,HAIR,1.1)
    for n in (0,3,6,9,12):
        xx=xp(n); segment(xx,y0,xx,y0+7,SLATE,1.7); txt(xx,y0+39,str(n),25,SLATE,anchor="middle")
    for n in range(13): circle(xp(n),yp(3+1/(n+2)),5.4,DEEP,DEEP,1)
    txt(1110,120,"J(h ++ w{sub:n}) = 3 + 1/(n + 2)",32,DEEP,600,"middle",615)
    txt(1110,659,L("每个点都是完整清算","Every point is a complete clearing"),28,DEEP,600,"middle",580)
    txt(1110,710,L("下确界 3；没有最小完成者","Infimum 3; no least-cost completion"),27,VERMILION,600,"middle",580)
    txt(1110,610,L("技术 n","technology n"),26,SLATE,anchor="middle")
    rule(752)
    txt(720,813,L("任意完成候选 w → 自身正成本差 δ → 选择 1/(n+2) < δ → 更便宜的完整清算",
        "Any completion w → its positive cost gap δ → choose 1/(n+2) < δ → a cheaper completion"),27,DEEP,600,"middle",1330)
    txt(720,860,L("从同一已发生前缀 h 出发；两侧可行域不同；右图为离散的已证成本族","Same incurred prefix h; the feasible domains differ; the right plot is the proved discrete family"),
        26,SLATE,anchor="middle",max_width=1330)
    save("fig05-cost",h,{"distinct_feasible_domains":True,"panel_A":"resource-sufficient native financial tail actual minimum",
      "panel_B":"complete rooted clearing counterexample","formula":"3 + 1/(n + 2)","n":"nonnegative integer technology parameter",
      "plotted_n":list(range(13)),"each_point_complete":True,"infimum":3,"minimum":False,
      "algorithm":"same incurred prefix; replace candidate suffix using its positive cost gap delta and n=ceil(1/delta)",
      "no_observational_data":True})

FIGURES=[("fig01-structure",structure),("fig02-disposition",disposition),("fig03-replay",replay),
         ("fig04-innovation",innovation),("fig05-cost",cost)]

def main():
    global LANG,CHECK_ONLY
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only",choices=[x[0] for x in FIGURES])
    ap.add_argument("--language",choices=["zh","en","both"],default="both")
    ap.add_argument("--check-only",action="store_true")
    args=ap.parse_args()
    CHECK_ONLY=args.check_only
    for LANG in (["zh","en"] if args.language=="both" else [args.language]):
        for name,draw in FIGURES:
            if args.only is None or args.only==name: draw()
    report={"paper":"capital-formation","created_utc":datetime.now(timezone.utc).isoformat(),
       "generator":"make_figures.py","renderer_adapted_from":"economic-constitution/figures/make_figures.py",
       "shared_dependencies_read_only":True,"fonts":["Noto Serif CJK SC","STIX Two Text","STIX Two Math"],
       "colors":{"navy":DEEP,"vermilion":VERMILION,"hairline":HAIR},
       "checks":"Glyph coverage; measured text boxes; pairwise text overlap; shape bounds; PDF vector/text checks.",
       "visual_inspection":"Recorded separately after actual display.","figures":MANIFEST}
    (OUT/".review").mkdir(exist_ok=True)
    target=OUT/(".review/layout-report.json" if CHECK_ONLY else
       ("manifest.json" if args.only is None and args.language=="both" else ".review/partial-manifest.json"))
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"count":len(MANIFEST),"report":str(target),"outputs":[x["stem"] for x in MANIFEST]},ensure_ascii=False))

if __name__=="__main__": main()
