#!/usr/bin/env python3
"""Render this paper's output PDFs for page-by-page visual inspection.

The report binds every page PNG to a PDF SHA256. It records mechanical
findings only: human visual acceptance must be recorded after actual display.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import pymupdf
from PIL import Image, ImageDraw, ImageFont

PAPER = Path(__file__).resolve().parents[1]

def contacts(out, pages, stem):
    result=[]
    font=ImageFont.load_default(size=20)
    for first in range(0,len(pages),6):
        group=pages[first:first+6]
        sheet=Image.new('RGB',(2040,1980),'white')
        draw=ImageDraw.Draw(sheet)
        for slot,p in enumerate(group):
            im=Image.open(out/p['png']).convert('RGB')
            im.thumbnail((660,940))
            x=(slot%3)*680+(680-im.width)//2
            y=(slot//3)*990+34
            sheet.paste(im,(x,y))
            draw.text(((slot%3)*680+20,(slot//3)*990+7),f"Page {p['page']}",fill='#555555',font=font)
        name=f'contact-{first//6+1:02d}.png'
        sheet.save(out/name)
        result.append({'png':name,'pages':[p['page'] for p in group]})
    return result

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def render(pdf, output_root, width):
    pdf = pdf.resolve()
    if not pdf.is_relative_to(PAPER / "build"):
        raise ValueError("Inspect only this paper's generated PDFs under build/.")
    digest = sha(pdf)
    out = output_root / (pdf.stem + "-" + digest[:12])
    out.mkdir(parents=True, exist_ok=True)
    pages = []
    with pymupdf.open(pdf) as doc:
        for index, page in enumerate(doc):
            text = page.get_text()
            outside = []
            for block in page.get_text("dict")["blocks"]:
                for line in block.get("lines", []):
                    for span in line["spans"]:
                        r = pymupdf.Rect(span["bbox"])
                        if (r.x0 < -1 or r.y0 < -1 or
                            r.x1 > page.rect.width+1 or r.y1 > page.rect.height+1):
                            outside.append({"text": span["text"], "box": list(r)})
            name = f"page-{index+1:03d}.png"
            png = out / name
            scale = width / page.rect.width
            page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False).save(png)
            pages.append({"page":index+1, "png":name, "png_sha256":sha(png),
                "page_pt":[page.rect.width,page.rect.height],
                "text_characters":len(text),
                "replacement_characters":text.count("\ufffd"),
                "out_of_page_text":outside,
                "nearly_empty_page":len(text.strip())<30,
                "visual_review":"pending"})
    if sha(pdf) != digest:
        raise RuntimeError("PDF changed during review rendering; render its final version again.")
    contact_sheets=contacts(out,pages,pdf.stem)
    report = {"pdf":str(pdf), "pdf_sha256":digest,
        "created_utc":datetime.now(timezone.utc).isoformat(),
        "width_px":width, "page_count":len(pages),
        "contact_sheets":contact_sheets,
        "visual_review":"Pending actual display of every listed page.",
        "mechanical_findings":{
            "replacement_characters":sum(p["replacement_characters"] for p in pages),
            "out_of_page_spans":sum(len(p["out_of_page_text"]) for p in pages),
            "nearly_empty_pages":[p["page"] for p in pages if p["nearly_empty_page"]]},
        "pages":pages}
    (out/"render-report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"pdf":str(pdf),"sha256":digest,"pages":len(pages),
        "review_directory":str(out),"mechanical_findings":report["mechanical_findings"]},
        ensure_ascii=False),flush=True)
    return report

def detail(pdf, output_root, width, numbers):
    pdf=pdf.resolve()
    if not pdf.is_relative_to(PAPER/'build'):
        raise ValueError('Inspect only this paper generated PDFs.')
    digest=sha(pdf)
    out=output_root/(pdf.stem+'-'+digest[:12])/'details'
    out.mkdir(parents=True,exist_ok=True)
    records=[]
    with pymupdf.open(pdf) as doc:
        for number in sorted(set(numbers)):
            if not 1<=number<=len(doc): raise ValueError(number)
            page=doc[number-1]
            png=out/f'page-{number:03d}-{width}px.png'
            scale=width/page.rect.width
            page.get_pixmap(matrix=pymupdf.Matrix(scale,scale),alpha=False).save(png)
            records.append({'page':number,'png':png.name,'png_sha256':sha(png)})
    if sha(pdf)!=digest: raise RuntimeError('PDF changed during detail rendering.')
    report={'pdf':str(pdf),'pdf_sha256':digest,'width_px':width,'pages':records,
        'visual_review':'pending actual display'}
    (out/'detail-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'details':str(out),'pages':numbers,'width_px':width}),flush=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("pdfs",nargs="+",type=Path)
    ap.add_argument("--output-root",type=Path,default=PAPER/"build"/"pdf-review")
    ap.add_argument("--width",type=int,default=1440)
    ap.add_argument("--detail-pages",help="Comma-separated 1-based pages; render selected detail views only.")
    args=ap.parse_args()
    output_root=args.output_root.resolve()
    if not output_root.is_relative_to(PAPER):
        raise ValueError("Keep this paper's review renders inside its own directory.")
    if args.width<1000:
        raise ValueError("Use at least 1000px width for full-page reading inspection.")
    for pdf in args.pdfs:
        if args.detail_pages:
            detail(pdf,output_root,args.width,[int(x) for x in args.detail_pages.split(',')])
        else:
            render(pdf,output_root,args.width)

if __name__=="__main__":
    main()
