#!/usr/bin/env python3
"""Check publication identities that can silently drift between language editions."""
from pathlib import Path
import hashlib,json,re
PAPER=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    z=(PAPER/"manuscript.md").read_text()
    e=(PAPER/"manuscript-en.md").read_text()
    reports={}
    for lang,text,marker,pattern in [
        ("zh",z,"## 参考文献",r"\*\*(定理|命题)(\d+)"),
        ("en",e,"## References",r"\*\*(Theorem|Proposition)\s+(\d+)\b")]:
        assert marker in text,(lang,"references heading")
        body,refs=text.split(marker,1)
        results=re.findall(pattern,body)
        assert [int(n) for _,n in results]==list(range(1,19)),(lang,"results")
        assert [int(n) for k,n in results if k in ("命题","Proposition")]==[10]
        equations=re.findall(r"\\tag\{(\d+)\}",body)
        assert list(map(int,equations))==list(range(1,26)),(lang,"equation numbering")
        keys=re.findall(r"^\[([A-Za-z][A-Za-z0-9]+)\]",refs,re.M)
        used=re.findall(r"@([A-Za-z][A-Za-z0-9]+)"," ".join(re.findall(r"\[@[^\]]+\]",body)))
        assert len(keys)==18 and len(set(keys))==18 and set(used)==set(keys),(lang,"citations")
        figures=re.findall(r"!\[[^\]]*\]\((figures/[^)]+)\)",body)
        assert len(figures)==5 and all((PAPER/f).is_file() for f in figures)
        expected_suffix="-en.svg" if lang=="en" else ".svg"
        assert all(f.endswith(expected_suffix) for f in figures)
        assert "原构造" not in body and "私人阶段" not in body
        reports[lang]={"numbered_results":len(results),"numbered_equations":len(equations),
            "display_math_blocks":len(re.findall(r"\\\[(.*?)\\\]",body,re.S)),
            "references":keys,"citation_blocks":re.findall(r"\[@([^\]]+)\]",body),
            "section_numbers":re.findall(r"^#{2,3}\s+(\d+(?:\.\d+)*)\s+",body,re.M),
            "figures":figures}
    assert reports["zh"]["references"]==reports["en"]["references"]
    assert reports["zh"]["section_numbers"]==reports["en"]["section_numbers"]
    assert reports["zh"]["display_math_blocks"]==reports["en"]["display_math_blocks"]==32
    zcite=[re.findall(r"@?([A-Za-z][A-Za-z0-9]+)",b.split(",")[0]) for b in reports["zh"]["citation_blocks"]]
    assert len(reports["zh"]["citation_blocks"])==len(reports["en"]["citation_blocks"])==20
    bib=(PAPER/"references.bib").read_text()
    bibkeys=re.findall(r"@\w+\s*\{\s*([^,\s]+)",bib)
    assert set(bibkeys)==set(reports["zh"]["references"]),(bibkeys,"bib keys")
    sz=(PAPER/"supplement.md").read_text()
    se=(PAPER/"supplement-en.md").read_text()
    assert re.findall(r"\\tag\{([^}]+)\}",sz)==re.findall(r"\\tag\{([^}]+)\}",se)
    assert re.findall(r"^##\s+([A-H])(?:[ .])",sz,re.M)==re.findall(r"^##\s+([A-H])(?:[ .])",se,re.M)==list("ABCDEFGH")
    binding=json.loads((PAPER/"records/public-source-binding.json").read_text())
    assert binding["source_selection_sha256"]==sha(PAPER/"records/source-selection.json")
    for row in binding["entries"]:
        if "preserved_source" in row:
            assert sha(PAPER/row["preserved_source"]["path"])==row["source_sha256"]
    report={"status":"passed",
        "scope":"Bilingual numbering, bibliography, local figure paths, appendix formula order, source-selection and preserved-file identities. Semantic translation and proof review are separately recorded in source-audit and literature-audit.",
        "manuscripts":{n:sha(PAPER/n) for n in ("manuscript.md","manuscript-en.md","supplement.md","supplement-en.md")},
        "editions":reports,"source_binding_summary":binding["summary"]}
    out=PAPER/"records/manuscript-consistency.json"
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"status":"passed","results":18,"equations":25,"references":18,
                      "figures_per_language":5,"sections":len(reports["zh"]["section_numbers"]),
                      "source_files":binding["summary"]["source_files_read"]},ensure_ascii=False))
if __name__=="__main__":main()
