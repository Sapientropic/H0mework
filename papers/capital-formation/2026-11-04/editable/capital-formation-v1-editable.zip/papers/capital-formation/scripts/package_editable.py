#!/usr/bin/env python3
"""Create the editable capital-formation bundle from an explicit allowlist.

Run from any working directory. This script reads only this paper and the seven
shared build dependencies below; it never modifies shared files. --check checks
the available inputs and the isolated build dependency closure without making
the zip. Final PDFs must match the current four-source build receipt.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
REL = PAPER.relative_to(ROOT).as_posix()
PDF_NAMES = (
    "capital-formation.pdf", "capital-formation-en.pdf",
    "capital-formation-supplement.pdf", "capital-formation-supplement-en.pdf",
)
SOURCES = ("manuscript.md", "manuscript-en.md", "supplement.md", "supplement-en.md")
FIGURES = ("fig01-structure", "fig02-disposition", "fig03-replay",
           "fig04-innovation", "fig05-cost")
EXCERPTS = ("s022-Forms.lean", "s065-Total.lean", "s103-Archive.lean",
            "s104-Zero.lean", "s105-Zero.lean")
SHARED = (
    "shared/scripts/build_pdf.py",
    "shared/scripts/byline.py",
    "shared/styles/article-header.tex",
    "shared/styles/article-header-en.tex",
    "shared/styles/article-filter.lua",
    "shared/figure-style/house_style.py",
    "shared/figure-style/svg_text.py",
)
PAPER_FIXED = SOURCES + (
    "references.bib", "reading-guide.md", "source-availability.md",
    "source-correspondence.md", "verification.md", "packaging-README.md",
    "zenodo-metadata.json",
    "figures/make_figures.py", "figures/manifest.json", "figures/README.md",
    "scripts/build_reading.py", "scripts/table-layout.lua",
    "scripts/render_pdf_review.py", "scripts/package_editable.py",
    "scripts/check_manuscript.py", "scripts/build_source_index.py",
    "records/manuscript-consistency.json", "records/figure-optimization-review.json",
    "records/public-source-binding.json", "records/source-selection.json",
    "records/source-audit.md", "records/literature-audit.md",
    "records/figure-build-pdfs.json", "records/figure-build-visual.json",
    "records/figure-build-pages-main.json", "records/figure-build-pages-supplement.json",
    "records/figure-build-pages-main-en-tail.json",
    "records/figure-build-pages-main-en-7-10.json",
    "records/figure-build-source-identities.json", "records/source-index-check.json",
)
PRIVATE_PATH = re.compile(rb"(?:file://)?/(?:Users|home|Volumes)/(?![\s\"'`<>])[^\r\n\"'`<>]+")
PRIVATE_MATERIAL = re.compile(
    rb"(?:^|[/\\\s\"'])\.(?:work|agents|lake)(?:[/\\]|$)"
    rb"|(?:^|[/\\\s\"'])(?:private[-_]?prompts?|raw[-_]?private)(?:[/\\]|$)", re.I)
CREDENTIAL = re.compile(
    rb"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"
    rb"|\bAuthorization\s*[:=]\s*[\"']?Bearer\s+\S+"
    rb"|[\"'](?:token|api[_-]?key|access[_-]?token)[\"']\s*:\s*"
    rb"[\"'][A-Za-z0-9_./+=-]{16,}[\"']", re.I)
FORBIDDEN_PARTS = {".git", ".work", ".agents", ".lake", "private-prompts", "raw-private",
                   "__pycache__", ".review", "pdf-work", "pdf-work-en",
                   "pdf-work-supplement", "pdf-work-supplement-en", "pdf-review"}
TEXT_EXTENSIONS = {".md", ".json", ".py", ".lua", ".tex", ".bib", ".lean", ".svg", ".txt"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def relative_member(name: str) -> None:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or "\\" in name:
        raise ValueError("Unsafe archive member: " + name)
    if set(p.parts) & FORBIDDEN_PARTS or p.name in {"AGENTS.md", "SKILL.md", ".DS_Store"} or p.suffix in {".png", ".pyc", ".log", ".aux", ".toc"}:
        raise ValueError("Excluded artifact: " + name)
    if name.startswith("papers/") and not name.startswith(REL + "/"):
        raise ValueError("Another paper is outside this bundle: " + name)


def allowlist(review_records: list[str]) -> list[str]:
    paper = list(PAPER_FIXED)
    paper.extend("build/" + p for p in PDF_NAMES)
    paper.extend("source-excerpts/" + p for p in EXCERPTS)
    for stem in FIGURES:
        for language in ("", "-en"):
            for extension in (".svg", ".pdf"):
                paper.append("figures/" + stem + language + extension)
    for item in review_records:
        path = PurePosixPath(item)
        if path.parts[:1] != ("records",) or path.suffix not in {".json", ".md"}:
            raise ValueError("Review records must be explicit JSON/Markdown files in records/.")
        relative_member(REL + "/" + item)
        paper.append(item)
    names = sorted(set(REL + "/" + p for p in paper) | set(SHARED))
    for name in names:
        relative_member(name)
    return names


def exported_copy(name: str, data: bytes) -> tuple[bytes, list[str]]:
    changes = []
    if Path(name).suffix not in TEXT_EXTENSIONS:
        return data, changes
    text = data.decode("utf-8")
    if name == REL + "/figures/make_figures.py":
        updated = re.sub(r"(?m)^Run with /[^\n]+/bin/python\.$",
                         "Run with python3 in an environment with the figure dependencies.", text)
        if updated != text:
            changes.append("Replaced the author-specific interpreter hint with python3.")
            text = updated
    if name == REL + "/scripts/build_reading.py":
        old = 'str(Path.home()/".venvs/figtools/bin/python")'
        if old in text:
            if text.count(old) != 1:
                raise ValueError("Unexpected figure interpreter occurrences.")
            text = text.replace(old, "sys.executable")
            changes.append("The --figures subprocess uses the active Python interpreter.")
    if name.endswith(".md"):
        updated = re.sub(r"\[([^\]]+)\]\((?:\.\./)?claims\.md(?:#[^)]*)?\)",
                         r"\1（仓库工作记录，不随本可编辑包提供）", text)
        if updated != text:
            changes.append("Kept the repository-only claims label as plain text.")
            text = updated
    if name.endswith(".md"):
        updated = re.sub(r"/(?:Users|home)/[A-Za-z0-9_./-]+/bin/python\b", "python3", text)
        if updated != text:
            changes.append("Replaced author-specific Python commands with the active python3 environment.")
            text = updated
    if name == REL + "/reading-guide.md":
        text += "\n\n## 可编辑包中的图件范围\n\n本包提供SVG与同名矢量PDF；记录中列明的PNG预览及逐页审阅图可由脚本重建，不随本包提供。\n"
        changes.append("Clarified that recorded PNG previews and page renders are not bundled.")
    if name.startswith(REL + "/records/"):
        prefix = ROOT.as_posix() + "/"
        if prefix in text:
            text = text.replace(prefix, "")
            changes.append("Converted workspace-root paths in the copied record to bundle-relative paths.")
    if name == REL + "/records/figure-optimization-review.json":
        original = json.loads(text)
        command = original["mechanical_checks"]["generator_command"]
        public_command = "python3 papers/capital-formation/figures/make_figures.py"
        if command == public_command:
            return text.encode("utf-8"), changes
        if not re.fullmatch(r"/(?:Users)/[^/\s]+/\.venvs/figtools/bin/python "
                            r"papers/capital-formation/figures/make_figures\.py", command):
            raise ValueError("Unexpected original figure-review interpreter command.")
        before, after = json.dumps(command, ensure_ascii=False), json.dumps(public_command)
        if text.count(before) != 1:
            raise ValueError("Expected exactly one recorded figure interpreter command.")
        text = text.replace(before, after, 1)
        original["mechanical_checks"]["generator_command"] = public_command
        if json.loads(text) != original:
            raise ValueError("Figure-review publication view changed another field.")
        changes.append("Made the recorded figure interpreter portable; all other JSON bytes and original review conclusions are unchanged.")
    result = text.encode("utf-8")
    if name in SHARED and result != data:
        raise ValueError("Shared dependencies must be copied byte for byte.")
    return result, changes


def scan_public(name: str, data: bytes) -> None:
    if PRIVATE_PATH.search(data) or PRIVATE_MATERIAL.search(data) or CREDENTIAL.search(data):
        # Never echo the rejected value into a public packaging receipt.
        raise ValueError("Private path, credential or internal prompt material in " + name)


def receipt_source_hashes(entries: list[dict]) -> dict[str, str]:
    hashes = {e["path"]: e["source_sha256"] for e in entries}
    manifest = ROOT / "PACKAGE-MANIFEST.json"
    if manifest.is_file():
        saved = json.loads(manifest.read_bytes())
        if saved.get("schema") != "capital-formation/editable-package@1":
            raise ValueError("Unknown extracted-package input manifest")
        # Public-view helpers retain the hash of their original source. Use it only
        # when the extracted input still exactly matches the shipped public bytes.
        for entry in saved["members"]:
            name = entry["path"]
            if hashes.get(name) == entry["sha256"] and entry.get("source_sha256"):
                hashes[name] = entry["source_sha256"]
    return hashes


def validate_receipts(payload: dict[str, bytes]) -> dict:
    at = lambda p: payload[REL + "/" + p]
    receipt = json.loads(at("records/figure-build-pdfs.json"))
    builds = receipt["builds"]
    expected_pdfs = {REL + "/build/" + p for p in PDF_NAMES}
    if {b["pdf"] for b in builds} != expected_pdfs or len(builds) != 4:
        raise ValueError("The build receipt must bind exactly the four final PDFs.")
    for build in builds:
        for kind, key in (("manuscript", "source_sha256"), ("pdf", "pdf_sha256")):
            name = build[kind]
            if sha(payload[name]) != build[key]:
                raise ValueError("Stale build receipt for " + name)
        if build.get("missing_characters") or build.get("overfull_boxes"):
            raise ValueError("A final PDF still has recorded layout findings.")
    figures = json.loads(at("figures/manifest.json"))
    if len(figures["figures"]) != 10:
        raise ValueError("Expected ten bilingual figure entries.")
    for figure in figures["figures"]:
        for kind in ("svg", "pdf"):
            item = figure["files"][kind]
            name = REL + "/figures/" + item["path"]
            if sha(payload[name]) != item["sha256"]:
                raise ValueError("Figure manifest mismatch: " + name)
    consistency = json.loads(at("records/manuscript-consistency.json"))
    if consistency["status"] != "passed":
        raise ValueError("Manuscript consistency check has not passed.")
    for name in SOURCES:
        if consistency["manuscripts"][name] != sha(at(name)):
            raise ValueError("Stale manuscript consistency record: " + name)
    binding = json.loads(at("records/public-source-binding.json"))
    if binding["source_selection_sha256"] != sha(at("records/source-selection.json")):
        raise ValueError("The public source binding uses an earlier source selection.")
    preserved = []
    for row in binding["entries"]:
        if "preserved_source" in row:
            path = row["preserved_source"]["path"]
            if sha(at(path)) != row["source_sha256"]:
                raise ValueError("Preserved source byte mismatch: " + path)
            preserved.append(path)
    if set(preserved) != {"source-excerpts/" + p for p in EXCERPTS}:
        raise ValueError("The five preserved source identities are not exactly covered.")
    return {
        "final_pdf_source_bindings": "pass",
        "figure_svg_pdf_hashes": "pass",
        "source_selection_binding": "pass",
        "five_preserved_source_files": "pass",
        "pdf_sha256": {b["pdf"]: b["pdf_sha256"] for b in builds},
        "source_sha256": {b["manuscript"]: b["source_sha256"] for b in builds},
    }


def validate_links(payload: dict[str, bytes]) -> dict:
    checked = 0
    for name, raw in payload.items():
        if not name.endswith(".md"):
            continue
        text = raw.decode("utf-8")
        fence = r"(?ms)^[ \t]*(" + chr(96) + r"{3,}|~{3,})[^\n]*\n.*?^[ \t]*\1[ \t]*$"
        text = re.sub(fence, "", text)
        for match in re.finditer(r"\[[^\]]*\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)", text):
            target = match.group(1)
            if re.match(r"^(?:https?://|mailto:|#)", target):
                continue
            target = target.split("#", 1)[0]
            if not target:
                continue
            resolved = os.path.normpath(str(PurePosixPath(name).parent / target)).replace("\\", "/")
            directory_present = target.endswith("/") and any(p.startswith(resolved + "/") for p in payload)
            if resolved not in payload and not directory_present:
                raise ValueError("Unbundled local link: " + name + " -> " + target)
            checked += 1
    return {"local_markdown_links": checked, "unbundled_local_links": 0}


def isolated_dependency_check(payload: dict[str, bytes]) -> dict:
    for name, raw in payload.items():
        if name.endswith(".py"):
            ast.parse(raw.decode(), filename=name)
    for name in SHARED:
        if name.endswith(".tex"):
            for target in re.findall(r"\\(?:input|include)\{([^}]+)\}", payload[name].decode()):
                resolved = str(PurePosixPath(name).parent / target)
                if resolved not in payload and resolved + ".tex" not in payload:
                    raise ValueError("Missing TeX include: " + resolved)
    with tempfile.TemporaryDirectory(prefix="package-dependencies-", dir=PAPER / "build") as work:
        stage = Path(work)
        for name, data in payload.items():
            dest = stage / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        script = stage / REL / "scripts/build_reading.py"
        spec = importlib.util.spec_from_file_location("packaged_capital_reading", script)
        module = importlib.util.module_from_spec(spec)
        old_path = list(sys.path)
        previous_byline = sys.modules.pop("byline", None)
        try:
            spec.loader.exec_module(module)
            if module.PUBLISH != stage:
                raise ValueError("Packaged builder escaped the extracted root.")
            prepared = []
            for (_, _), (rel, _) in module.TARGETS.items():
                source = stage / rel
                lines = source.read_text().splitlines()
                module.builder.byline.pop(lines)
                lang = "en" if source.name.endswith("-en.md") else "zh"
                profile = dict(module.builder.PROFILES[lang], continuous_appendices=True)
                title, subtitle, body = module.prepare("\n".join(lines) + "\n", True, profile)
                body = module.builder.vector_figures(body, source.parent, stage / "dependency-check")
                if not title or not body:
                    raise ValueError("Empty prepared manuscript: " + rel)
                for target in re.findall(r"!\[[^\]]*\]\(([^)\s]+)", body):
                    if not Path(target).is_file() or not Path(target).is_relative_to(stage):
                        raise ValueError("Image dependency escaped or is missing: " + target)
                prepared.append(rel)
        finally:
            sys.path[:] = old_path
            sys.modules.pop("byline", None)
            if previous_byline is not None:
                sys.modules["byline"] = previous_byline
    return {
        "python_syntax": "pass", "shared_runtime_imports": "pass",
        "isolated_preparation": prepared, "svg_to_vector_pdf_resolution": "pass",
        "additional_tex_input_files": 0,
        "external_environment": [
            "Python 3.10+", "Pandoc 3", "XeLaTeX with the listed TeX packages",
            "Noto Serif/Sans CJK SC and Latin Modern fonts",
        ],
        "optional_figure_regeneration": ["fontTools", "PyMuPDF", "Google Chrome",
                                          "Noto Serif CJK SC", "STIX Two Text/Math"],
        "optional_page_review": ["PyMuPDF", "Pillow"],
        "scope": "Imports, preparation, image closure and explicit TeX includes; not a second full TeX rebuild.",
    }


def final_review_state(payload: dict[str, bytes], source_hashes: dict[str, str]) -> dict:
    issues, historical, pages = [], {}, 0
    latest_name = REL + "/records/figure-optimization-review.json"
    successor = json.loads(payload[latest_name]) if latest_name in payload else None
    for filename, key in (("figure-build-pages-main.json", "documents"),
                          ("figure-build-pages-supplement.json", "editions")):
        review = json.loads(payload[REL + "/records/" + filename])
        if not str(review.get("status", "")).lower().startswith("pass"):
            issues.append(filename + ": final status is not passed")
        if review.get("open_findings"):
            issues.append(filename + ": open findings remain")
        for doc in review[key]:
            path = doc["pdf"]
            name = path if path.startswith(REL + "/") else REL + "/" + path
            if name in historical:
                issues.append("Repeated historical PDF review: " + name)
            historical[name] = doc
            if not successor and (name not in payload or doc["pdf_sha256"] != sha(payload[name])):
                issues.append(filename + ": PDF identity has changed for " + path)
            reviewed_pages = doc["pages"]
            if len(reviewed_pages) != doc["page_count"] or {p["page"] for p in reviewed_pages} != set(range(1, doc["page_count"] + 1)):
                issues.append(filename + ": page count does not match reviewed pages")
            for page in reviewed_pages:
                status = page.get("status", page.get("visual_status", ""))
                if status not in {"accepted", "pass", "passed"}:
                    issues.append(filename + ": unaccepted page " + str(page["page"]))
                if page.get("actually_displayed") is not True or not re.fullmatch(r"[0-9a-f]{64}", page.get("png_sha256", "")):
                    issues.append(filename + ": page display identity is missing")
            pages += doc["page_count"]
    expected = {REL + "/build/" + p for p in PDF_NAMES}
    if set(historical) != expected:
        issues.append("Final page reviews do not cover exactly the four PDF editions")
    if not successor:
        return {"ready": not issues, "reviewed_pages": pages, "issues": issues}

    if (successor.get("paper") != "capital-formation" or successor.get("status") != "pass"
            or successor.get("revision") != "figure-clarity-optimization"
            or successor.get("remaining_actionable_issues") != []):
        issues.append("The successor optimization review is not accepted")
    if not successor.get("display_method") or not successor.get("pagination_review"):
        issues.append("The successor review omits its display or pagination scope")
    for field in ("source_script", "manifest", "build_record"):
        ref = successor[field]
        name = REL + "/" + ref["path"]
        relative_member(name)
        if name not in payload or source_hashes.get(name) != ref["sha256"]:
            issues.append("The successor review uses another " + field)
    for path in successor.get("prior_acceptance_records", []):
        if REL + "/" + path not in payload:
            issues.append("Missing predecessor review: " + path)
    if not {"records/figure-build-pages-main.json", "records/figure-build-pages-supplement.json"}.issubset(successor.get("prior_acceptance_records", [])):
        issues.append("The successor review does not identify both prior page reviews")

    figures = successor.get("figures", [])
    if {f["pair"] for f in figures} != set(FIGURES) or len(figures) != len(FIGURES) or any(
            f.get("actual_display") is not True or f.get("visual_status") != "pass" for f in figures):
        issues.append("The bilingual figure display review is incomplete")
    mechanical = successor["mechanical_checks"]
    if (mechanical.get("language_versions") != 10 or mechanical.get("glyph_coverage") != "pass"
            or mechanical.get("measured_label_overlap_assertions") != 0
            or mechanical.get("shape_or_text_outside_canvas") != 0):
        issues.append("The successor review retains a figure finding")

    builds = {b["pdf"]: b for b in json.loads(payload[REL + "/records/figure-build-pdfs.json"])["builds"]}
    current = {}
    for edition, doc in successor["reading_pdfs"].items():
        name = REL + "/" + doc["path"]
        relative_member(name)
        if name in current or name not in expected:
            issues.append("Unexpected or repeated successor PDF: " + name)
            continue
        current[name] = doc
        if sha(payload[name]) != doc["sha256"] or builds[name]["pdf_sha256"] != doc["sha256"]:
            issues.append("The successor review uses another PDF: " + name)
        count = doc["pages"]
        if count != historical[name]["page_count"]:
            issues.append("The successor PDF page count does not match: " + name)
        if edition.endswith("_supplement"):
            if doc.get("exact_prior_accepted_png_matches") != count:
                issues.append("Supplement page identity continuation is incomplete: " + name)
        else:
            displayed = doc.get("figure_pages", [])
            if len(displayed) != len(FIGURES) or len(set(displayed)) != len(FIGURES) or any(
                    not isinstance(p, int) or p < 1 or p > count for p in displayed):
                issues.append("Main figure-page display scope is incomplete: " + name)
            if (doc.get("replacement_characters") != 0 or doc.get("out_of_page_spans") != 0
                    or doc.get("nearly_empty_pages") != []):
                issues.append("The successor main PDF retains a layout finding: " + name)
    if set(current) != expected:
        issues.append("Successor review does not cover exactly the four current PDFs")
    return {"ready": not issues, "reviewed_pages": pages, "issues": issues,
            "current_review": "records/figure-optimization-review.json",
            "acceptance_method": "Hash-bound successor review, actual figure-page displays and exact prior supplement PNG identity continuation; original page reviews retain their original PDF identities."}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--review-record", action="append", default=[])
    ap.add_argument("--output", type=Path,
                    default=PAPER / "build/capital-formation-editable.zip")
    ap.add_argument("--audit-output", type=Path,
                    default=PAPER / "records/package-audit.json")
    args = ap.parse_args()
    names = allowlist(args.review_record)
    missing = [name for name in names if not (ROOT / name).is_file()]
    if missing:
        print(json.dumps({"status": "waiting-for-required-inputs", "missing": missing},
                         ensure_ascii=False, indent=2))
        raise SystemExit(2)
    payload, entries = {}, []
    for name in names:
        source = ROOT / name
        if source.is_symlink():
            raise ValueError("Symlink not allowed: " + name)
        raw = source.read_bytes()
        data, changes = exported_copy(name, raw)
        scan_public(name, data)
        payload[name] = data
        entries.append({
            "path": name, "bytes": len(data), "sha256": sha(data),
            "source_sha256": sha(raw), "packaging_changes": changes,
            "read_only_shared_dependency": name in SHARED,
        })
    payload["README.md"] = (
        "# The Structural Theorem of Capitalism — editable bundle\n\n"
        "Open [the rebuild guide](papers/capital-formation/packaging-README.md) "
        "for contents, requirements and commands. "
        "The paper and shared dependency directories retain their relative layout.\n"
    ).encode()
    checks = validate_receipts(payload)
    checks.update(validate_links(payload))
    checks["rebuild_dependencies"] = isolated_dependency_check(payload)
    review_state = final_review_state(payload, receipt_source_hashes(entries))
    checks["final_page_review"] = review_state
    pending_review = b"FINAL_" in payload[REL + "/verification.md"] or not review_state["ready"]
    entries.append({"path": "README.md", "bytes": len(payload["README.md"]),
                    "sha256": sha(payload["README.md"]), "generated": True})
    manifest = {
        "schema": "capital-formation/editable-package@1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Only capital-formation and its explicitly required read-only shared dependencies.",
        "members": entries,
        "checks": checks,
        "omitted": ["Other papers", "planning claims", "PNG previews", "page renders",
                    "TeX intermediates", "caches", "fonts and external executables"],
        "manifest_note": "This manifest lists all payload members except itself. The outer zip hash is in the packaging receipt.",
    }
    payload["PACKAGE-MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    for name in payload:
        relative_member(name)
        scan_public(name, payload[name])
    if args.check:
        print(json.dumps({"status": "dependencies-ready-final-review-pending" if pending_review else "ready", "members": len(payload), "checks": checks},
                         ensure_ascii=False, indent=2))
        return
    if pending_review:
        raise ValueError("Final visual verification has not yet been signed off.")
    output = args.output.resolve()
    if not output.is_relative_to(PAPER / "build"):
        raise ValueError("Keep the archive inside this paper's build directory.")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(".zip.tmp")
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name in sorted(payload):
                info = zipfile.ZipInfo(name, date_time=(2026, 11, 4, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                mode = 0o444 if name in SHARED else (0o755 if name.endswith(".py") else 0o644)
                info.external_attr = (stat.S_IFREG | mode) << 16
                z.writestr(info, payload[name])
        with zipfile.ZipFile(temporary) as z:
            if set(z.namelist()) != set(payload) or len(z.namelist()) != len(payload):
                raise ValueError("Archive member allowlist mismatch.")
            if z.testzip() is not None:
                raise ValueError("Archive CRC failure.")
            for name in z.namelist():
                if z.read(name) != payload[name]:
                    raise ValueError("Archive bytes mismatch: " + name)
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    result = {
        "schema": "capital-formation/packaging-audit@1",
        "created_utc": manifest["created_utc"],
        "archive": output.relative_to(ROOT).as_posix(),
        "sha256": sha(output.read_bytes()), "bytes": output.stat().st_size,
        "member_count": len(payload), "member_allowlist": sorted(payload),
        "checks": checks,
        "shared_dependencies_copied_verbatim": list(SHARED),
        "packaging_transformations": {e["path"]: e["packaging_changes"]
                                     for e in entries if e.get("packaging_changes")},
    }
    audit = args.audit_output.resolve()
    if not audit.is_relative_to(PAPER / "records") or audit.relative_to(ROOT).as_posix() in payload:
        raise ValueError("Keep a distinct packaging receipt in this paper's records directory.")
    audit.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
