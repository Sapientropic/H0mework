#!/usr/bin/env python3
"""Bind the paper's source register to a fixed, already accepted public package.
Only reads Git objects and existing receipts; does not run Lean or change either
research repository. --check compares deterministic generated artifacts.
"""
from pathlib import Path
import argparse, gzip, hashlib, json, re, subprocess, sys
PAPER = Path(__file__).resolve().parents[1]
SOURCE = "df421ff600085cbc290a7ae946193961bed7c83b"
PUBLIC = "2d6fbc96e33b7c4c3cfd91104fda74e3caeda045"
URL = "https://github.com/Sapientropic/H0mework"
PACKAGE = "economic-constitution-source-df"
ROOT = "H0mework.Papers.EconomicConstitutionSourceDF"
MAP = "docs/economic-constitution-map.json"
ACCEPTANCE = "evidence/economic-constitution/acceptance/initial-intake/"
BASE = "Lean/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/"
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encode(value): return (json.dumps(value, ensure_ascii=False, indent=2)+"\n").encode()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--homework-repository",type=Path,required=True)
    ap.add_argument("--h0-repository",type=Path,required=True)
    ap.add_argument("--check",action="store_true")
    args=ap.parse_args()
    sys.dont_write_bytecode=True
    helpers={}
    for p in ("tools/source_view.py","tools/whole_ledger_export.py"):
        fixed=subprocess.check_output(["git","-C",str(args.h0_repository),"show",PUBLIC+":"+p])
        assert (args.h0_repository/p).read_bytes()==fixed,("Use the fixed public helper version",p)
        helpers[p]=sha(fixed)
    sys.path.insert(0,str(args.h0_repository/"tools"))
    import source_view as sv
    from whole_ledger_export import FixedGit
    public_git,source_git=FixedGit(args.h0_repository),FixedGit(args.homework_repository)
    try:
        read=lambda p:public_git.read(PUBLIC,p)
        read_source=lambda p:source_git.read(SOURCE,p)
        selection_path=PAPER/"records/source-selection.json"
        selection_raw=selection_path.read_bytes()
        selection=json.loads(selection_raw)
        assert selection["source_commit"]==SOURCE and selection["public_commit"]==PUBLIC
        map_raw,export_raw=read(MAP),read("tools/export-map.json")
        mapping,exported=json.loads(map_raw),json.loads(export_raw)
        assert mapping["acceptance"]["status"]=="passed"
        summary_raw=read(ACCEPTANCE+"summary.json")
        summary=json.loads(summary_raw)
        assert summary["status"]=="passed" and summary["claim_map_sha256"]==sha(map_raw)
        package=next(p for p in mapping["proof_packages"] if p["id"]==PACKAGE)
        assert package["lean_target"]==ROOT and package["source_commit"]==SOURCE
        receipts,receipt_refs={},{}
        for kind in ("build","trust","declaration_types"):
            ref=mapping["acceptance"][kind]
            raw=read(ref["path"])
            assert sha(raw)==ref["sha256"]
            payload=gzip.decompress(raw) if ref.get("compression")=="gzip" else raw
            assert sha(payload)==ref["payload_sha256"]
            receipt=json.loads(payload)
            assert receipt["inputs_unchanged"] is True
            assert receipt["input_identity"]==receipt["input_identity_after"]
            assert receipt.get("ok",receipt.get("status")=="passed") is True
            receipts[kind],receipt_refs[kind]=receipt,ref
        types=receipts["declaration_types"]["declarations"]
        assert len(types)==3313
        rows={r["target"]:r for r in exported["modules"]}
        contents,imports,paths={},{},{}
        def module(target):
            if target not in contents:
                path=rows[target]["path"] if target in rows else "Lean/"+target.replace(".","/")+".lean"
                raw=read(path)
                if target in rows: assert sha(raw)==rows[target]["target_sha256"],target
                contents[target],paths[target]=raw,path
                imports[target]=[n for _,_,n in sv.import_tokens(raw.decode())]
            return contents[target]
        todo,closure,parent=[ROOT],set(),{}
        while todo:
            target=todo.pop()
            if target in closure: continue
            closure.add(target); module(target)
            for child in imports[target]:
                if child in rows and child not in closure:
                    parent.setdefault(child,target);todo.append(child)
        layouts={}
        def layout(target):
            if target not in layouts:
                row=rows[target]
                deps=[layout(n) for n in imports[target] if n in rows]
                layouts[target]=sv.layout_identity(row["source_path"],row["source_sha256"],row.get("source_origin"),deps)
            return layouts[target]
        for target in sorted(closure):
            if target in rows:layout(target)
        path_index={}
        for target in closure:
            if target not in rows:continue
            row=rows[target]
            candidates={row.get("source_path")}
            candidates.update(a.get("source_path") for a in row.get("source_aliases",[]))
            for path in candidates-{None}:
                rec=sv.source_record(row,path,SOURCE)
                if rec and sv.row_at(rec,SOURCE):path_index.setdefault(path,[]).append((target,rec))
        all_entries=[(c["id"],role,e) for c in mapping["claims"]
                     for role in ("producers","direct_consumers") for e in c[role]]
        type_index={}
        for idx,item in enumerate(types):
            if item["package"]!=PACKAGE:continue
            assert item["kernel_equivalent"] is True and not item["unsafe"] and not item["partial"]
            assert set(item["axioms"])<={"propext","Classical.choice","Quot.sound"}
            type_index.setdefault(item["module"],[]).append((idx,item))
        bound,auxiliary,observed_type_indices=[],[],set()
        preserved_outputs={}
        for ordinal,original in enumerate(selection["entries"],1):
            raw=read_source(original["path"])
            assert sha(raw)==original["source_sha256"],original["path"]
            candidates=[(t,r) for t,r in path_index.get(original["path"],[])
                        if r["source_sha256"]==original["source_sha256"]]
            assert len(candidates)<=1,("Ambiguous accepted owner",original["path"],candidates)
            entry=dict(original);entry["id"]=f"s{ordinal:03d}"
            if not candidates:
                entry["binding_status"]="auxiliary-reading-outside-accepted-package"
                entry["public"]=None;entry["type_observations"]=[]
                saved="source-excerpts/"+entry["id"]+"-"+Path(entry["path"]).name
                entry["preserved_source"]={"path":saved,"sha256":sha(raw),"status":"unchanged fixed-commit source bytes; no new execution"}
                preserved_outputs[PAPER/saved]=raw
                auxiliary.append({"id":entry["id"],"path":entry["path"],"source_groups":entry["source_groups"]})
                bound.append(entry);continue
            target,record=candidates[0]
            chain,cursor=[target],target
            while cursor!=ROOT:
                cursor=parent[cursor];chain.append(cursor)
            entry["binding_status"]="fixed-source-in-accepted-package-import-closure"
            entry["public"]={"module":target,"path":paths[target],
                "url":URL+"/blob/"+PUBLIC+"/"+paths[target],
                "target_sha256":sha(contents[target]),
                "source_record":{k:record.get(k) for k in (
                    "source_path","source_revision","source_revisions","source_sha256","source_origin")},
                "recursive_layout_sha256":layouts[target],"actual_imports":imports[target],
                "import_chain_from_accepted_root":list(reversed(chain))}
            entry["type_observations"]=[]
            for idx,item in type_index.get(target,[]):
                observed_type_indices.add(idx)
                entry["type_observations"].append({"declaration_index":idx,
                    "qualified_name":item["qualified_name"],"kind":item["kind"],
                    "type_format":item["type_format"],"type_sha256":sha(item["type"].encode()),
                    "kernel_equivalent":True,"axioms":item["axioms"],"unsafe":False,"partial":False})
            adopted=[e for _,_,e in all_entries if e["source_commit"]==SOURCE
                     and e["source_path"]==entry["path"] and e["source_sha256"]==entry["source_sha256"]]
            entry["previous_claim_map_declarations"]=[]
            for e in adopted:
                assert e["public"]["module"]==target and e["public"]["sha256"]==sha(contents[target])
                assert e["verification"]["kernel"]=="passed"
                assert e["verification"]["proof_package"]==PACKAGE
                assert e["verification"]["source_scope_sha256"]==package["accepted_source_scope_sha256"]
                for d in e["declarations"]:
                    ref=d["complete_type"];item=types[ref["declaration_index"]]
                    assert item["module"]==target and item["qualified_name"]==d["qualified_name"]
                    assert sha(item["type"].encode())==ref["type_sha256"]
                    entry["previous_claim_map_declarations"].append(d)
            for consumer in entry.get("consumers",[]):
                cb=read_source(consumer["path"]);consumer["source_sha256"]=sha(cb)
                matches=[(t,r) for t,r in path_index.get(consumer["path"],[]) if r["source_sha256"]==sha(cb)]
                assert len(matches)<=1
                consumer["public_module"]=matches[0][0] if matches else None
                consumer["public_binding_kind"]="accepted-import-closure" if matches else "fixed-source-lexical-reference"
            bound.append(entry)
        stats={"source_files_read":len(bound),
            "source_declaration_locations":sum(len(e["declarations"]) for e in bound),
            "direct_import_relationships":sum(len(e.get("consumers",[])) for e in bound),
            "accepted_public_modules":sum(e["public"] is not None for e in bound),
            "auxiliary_reading_files":len(auxiliary),
            "accepted_package_recursive_modules":len(closure),
            "existing_complete_type_observations_in_selected_modules":len(observed_type_indices),
            "previous_claim_map_named_adoptions":sum(len(e.get("previous_claim_map_declarations",[])) for e in bound),
            "existing_receipt_total_complete_types":len(types),
            "new_Lean_execution":False,"new_scientific_execution":False}
        binding={"schema":"capital-formation/public-source-binding@1",
            "source_commit":SOURCE,"public_repository":URL,"public_commit":PUBLIC,
            "source_selection_sha256":sha(selection_raw),
            "identity_method":"Choose owners only inside the already accepted SourceDF package's actual recursive imports. Then match the exact pinned source alias, source bytes, public bytes and recursive import layout. Existing type receipts are indexed separately; a lexical declaration list is not a new typecheck.",
            "accepted_package":package,
            "evidence":{"claim_map":{"path":MAP,"sha256":sha(map_raw)},
                "export_map":{"path":"tools/export-map.json","sha256":sha(export_raw)},
                "acceptance_summary":{"path":ACCEPTANCE+"summary.json","sha256":sha(summary_raw)},
                "receipts":receipt_refs,"verified_helper_bytes":helpers},
            "summary":stats,"auxiliary_reading":auxiliary,"entries":bound}
        lines=["# 定理、声明、消费者与固定公开源码","",
            f"研究来源固定于 Homework `{SOURCE}`；公开证明材料固定于 "
            f"[H0mework]({URL}/tree/{PUBLIC})。本表由实际源码字节与已有验收回执生成。","",
            f"本轮全文核读 {stats['source_files_read']} 个来源文件，登记 "
            f"{stats['source_declaration_locations']} 处声明及 {stats['direct_import_relationships']} "
            f"条直接导入关系。其中 {stats['accepted_public_modules']} 个模块位于已验收 "
            "`EconomicConstitutionSourceDF` 的实际导入闭包；它们的公开字节和固定来源别名逐项一致。","",
            f"这些模块在已有回执中有 {stats['existing_complete_type_observations_in_selected_modules']} "
            "项完整类型观测。每项保存完整限定名、类型哈希、回执索引、公理及kernel等价结果；"
            "文件中的其他声明由完整构建的导入关系定位，不补造单独类型观测。","",
            "机器明细见 [public-source-binding.json](records/public-source-binding.json)，"
            "阅读深度见 [source-selection.json](records/source-selection.json)，"
            "正文审校见 [source-audit.md](records/source-audit.md)。",""]
        groups=sorted({g for e in bound for g in e["source_groups"]},key=lambda x:int(x[1:]))
        for group in groups:
            lines.extend(["## "+group,""])
            for e in bound:
                if group not in e["source_groups"]:continue
                short=e["path"].removeprefix(BASE)
                lines.extend([f"### {e['id']} · {short}","",
                    "- 正文位置："+"、".join(e.get("manuscript",[]))+"。",
                    "- 附录位置："+"、".join(e.get("supplement",[]))+"。",
                    "- 固定源 SHA256：`"+e["source_sha256"]+"`。",
                    "- 声明："+"；".join("`"+d["name"]+"` (L"+str(d["line"])+")"
                        for d in e["declarations"])+"。"])
                if e["public"]:
                    lines.append("- 实际公开模块：["+e["public"]["module"]+"]("+e["public"]["url"]+")。")
                    lines.append("- 已有完整类型观测："+str(len(e["type_observations"]))+"项；逐项回执索引见机器记录。")
                else:
                    lines.append("- 阅读用途：辅助实例或分配引理；不作为主结论的独立验收根。[固定源码原字节]("+e["preserved_source"]["path"]+")。")
                if e.get("consumers"):
                    lines.append("- 直接消费者："+"；".join("`"+c["path"].removeprefix(BASE)+"`"
                        for c in e["consumers"])+"。")
                lines.append("")
        lines.extend(["## 认证身份","",
            "使用的是上述固定公开快照已经完成的本地build、trust与完整类型回执。"
            "本轮执行源码对应、声明及证明核读、正文审校和出版构建；没有新跑Lean、"
            "重算科学结果或修改研究仓。历史独立T1认证保留其日期、源码范围和回执身份，见claims。",""])
        outputs={**preserved_outputs,PAPER/"records/public-source-binding.json":encode(binding),
                 PAPER/"source-correspondence.md":("\n".join(lines)).encode()}
        assert selection_path.read_bytes()==selection_raw,"Selection changed; run again."
        for path,raw in outputs.items():
            assert not re.search(rb"/(?:Users|Volumes|home)/",raw),"Private path in public binding"
            if args.check:assert path.read_bytes()==raw,"Generated binding is stale: "+path.name
            else:
                path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(raw)
        print(json.dumps({"status":"passed",**stats,"auxiliary":auxiliary,
            "outputs":{p.relative_to(PAPER).as_posix():sha(b) for p,b in outputs.items()}},
            ensure_ascii=False,indent=2))
    finally:
        public_git.close();source_git.close()
if __name__=="__main__":main()
