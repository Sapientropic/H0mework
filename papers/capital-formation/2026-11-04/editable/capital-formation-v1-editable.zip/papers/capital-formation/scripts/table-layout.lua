-- Paper-local layout only: preserve long hashes and allocate source-table space.
function Header(el)
  if not FORMAT:match('latex') or el.level ~= 1 then return nil end
  local title = pandoc.utils.stringify(el.content)
  local short_titles = {
    ['7 How Unknown Innovation and Bounded Contributions Continue'] = '7 Unknown Innovation and Bounded Contributions',
    ['9 Settlement Costs: An Attained Optimum and Completion That Can Always Be Improved'] = '9 Settlement Costs: Attainment and Strict Improvement'
  }
  if short_titles[title] then
    local latex = pandoc.write(pandoc.Pandoc({el}), 'latex')
    latex = latex:gsub('\\section{', '\\section[' .. short_titles[title] .. ']{', 1)
    return pandoc.RawBlock('latex', latex)
  end
end

function Str(el)
  if not FORMAT:match('latex') then return nil end
  -- Pandoc may keep a hash and adjacent Chinese prose in the same Str.
  -- Split only complete forty-digit hexadecimal runs, preserving all prose.
  local result = pandoc.List()
  local cursor = 1
  for first, token, after in el.text:gmatch('()([0-9a-f]+)()') do
    if #token == 40 then
      if first > cursor then result:insert(pandoc.Str(el.text:sub(cursor, first - 1))) end
      result:insert(pandoc.RawInline('latex', '\\paperinlinecode{\\seqsplit{' .. token .. '}}'))
      cursor = after
    end
  end
  if cursor > 1 then
    if cursor <= #el.text then result:insert(pandoc.Str(el.text:sub(cursor))) end
    return result
  end
end

function Table(el)
  if not FORMAT:match('latex') then return nil end
  if not el.head or not el.head.rows or #el.head.rows == 0 then return nil end
  local row = el.head.rows[1]
  if #row.cells == 0 then return nil end
  local label = pandoc.utils.stringify(row.cells[1].contents)
  if #el.colspecs == 3 and
     (label == '总定理分肢' or label == 'Branch of the joint theorem') then
    -- Keep the question dominant and the section/result map readable.
    el.colspecs[1][2] = 0.20
    el.colspecs[2][2] = 0.46
    el.colspecs[3][2] = 0.34
    return {pandoc.RawBlock('latex', '\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.08}\\renewcommand{\\arraystretch}{1.15}}\n\\setlength{\\LTpre}{0.65em}\\setlength{\\LTpost}{0.65em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
  if #el.colspecs ~= 2 or #row.cells ~= 2 then return nil end
  if label == '标识' or label == 'ID' then
    el.colspecs[1][2] = 0.10
    el.colspecs[2][2] = 0.90
    -- The source table is last; keep its closing account on the same page.
    return {pandoc.RawBlock('latex', '\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.08}\\renewcommand{\\arraystretch}{1.08}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
end
