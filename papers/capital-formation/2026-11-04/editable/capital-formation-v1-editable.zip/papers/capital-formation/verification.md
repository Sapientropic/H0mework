# 成稿、来源与阅读版核验

《资本主义的结构总定理》  
终稿修订：2026-11-04（Asia/Shanghai）

**交付状态：独立冷读、定点回源、双语一致性与最终逐页版式检查全部通过。**

## 正文及本次实质修订

唯一中文正文为 [manuscript.md](manuscript.md)，英文镜像为 [manuscript-en.md](manuscript-en.md)；技术展开由 [supplement.md](supplement.md) 与 [supplement-en.md](supplement-en.md)承担。正文保留18项编号结果（第10项为命题）、25个既有公式编号，显示数学块因补入完整金融差额定义增至32个；双语均有47个编号章、节。

定理1后新增五分肢导览表，逐项连接政治经济学问题与定理2—18。§6.1说明任意给定有限序列的功能保持与当前制度转换的实际选择、责任承接和可执行未来；公共重放仍量化任意给定序列。§8.2、§8.4和§10.4与Roemer的财产权、联盟退出、支配及资本再生产论证形成实质对话，比较对象和责任范围分别明确。

冷读后补实§5.2：以同一起点、同轮数且按自身状态逐期发词的转换前来源生成基准；完整金融差额合并库存变化和按指定结算品、结算率计量的债权／债务变化，正结算率、正窗口与相同终钟各有明确检查。附录C.3展开有限支持求和与本金支付的物量、金融两腿。迁移认回首次公共执行及当时成员，金融检查读取截至当前的全账，未来从当前状态与名册生成。

§3.4修正了全关闭例子所反驳的命题；英文承重处补齐生活与维护两项。来源、社会合同和自然数责任进展预算各在首次使用处解释；六个明确资本模型作为一般定理的实际应用出现。定理13定义联盟收入与耗用，明说任意有限开放机制链及任意输入序列的每个有限前缀。定理17把无需有限旧账、来源已发出的汇合事件、逐行实际最小预算和登记成功／具体冲突纳入正式陈述。

独立审读报告、固定源码裁决及修订后的定点复核保存于 [source-audit.md](records/source-audit.md)。必要问题已闭合，末项付款人归属措辞也已采用；没有重启新研究或削弱任意执行、全槽累计受领和任意完成候选的已证量词。

## 文献与固定来源

18条正式参考文献全部在正文使用，双语各20处引用块对应。Roemer原书的退出与支配讨论定位于pp.194—198、202—203，功能与特定资本家之分定位于pp.276—278；不将全书概括成只处理静态或忽略需要。八条核查性尾注改为题名超链接，原文入口保留。两篇前作仍使用正式v2 DOI。原文范围、定位及比较裁决见 [literature-audit.md](records/literature-audit.md)。

形式研究来源保持Homework提交df421ff600085cbc290a7ae946193961bed7c83b，公开证明选集保持H0mework提交2d6fbc96e33b7c4c3cfd91104fda74e3caeda045。当前H0快照2e68d950eedda807acbedd443cfcd6a456b21218的相关Lean、选集、工具和验收材料与该固定版本一致；两处工作树及相关未提交入口也已核查。

来源审校保存105个固定源文件、675处声明位置与191条直接导入关系。100个对应公开模块位于已验收SourceDF实际2825模块闭包，其中160项完整类型观测准确接回既有回执；五份辅助实例、分配引理与归档反例继续保存固定源码原字节。确定性对应检查本轮实际运行通过，未执行新的Lean构建或科学重算。具体身份见 [来源说明](source-availability.md)、[来源对应](source-correspondence.md)、[public-source-binding.json](records/public-source-binding.json)及 [source-index-check.json](records/source-index-check.json)。

## 双语、图件与出版构建

[manuscript-consistency.json](records/manuscript-consistency.json)绑定最终四份稿件，检查结果、式号、显示数学块、章节、18条书目、20处引用块、五组图路径、附录公式顺序与固定来源字节。语义一致性由独立审读与定点回源另行承担。

五组十张双语图件保留可编辑SVG、矢量PDF、PNG与生成脚本。本轮图件优化保持图1的成熟构图；图2分离主流程与失败卡片，图3以共同后态节点和分组结果带减少重复说明，图4以两轮独立付款卡及连续旧债基线显示实际支付，图5将左部改为成本保留、金融尾比较与实际后继的三段流程。全部命题、数值、量词和固定来源不变；图4恢复原画幅，未靠缩小字号消除分页问题。本篇局部过滤器设置五分肢三列表列宽，并让中文连写文本中的40位提交哈希正确换行；共享模板未修改。

| 阅读版 | 页数 | 文件 |
| --- | ---: | --- |
| 中文正文 | 24 | [capital-formation.pdf](build/capital-formation.pdf) |
| 英文正文 | 35 | [capital-formation-en.pdf](build/capital-formation-en.pdf) |
| 中文技术附录 | 11 | [capital-formation-supplement.pdf](build/capital-formation-supplement.pdf) |
| 英文技术附录 | 15 | [capital-formation-supplement-en.pdf](build/capital-formation-supplement-en.pdf) |

四份共85页，全部零缺字、零溢出、零公式缩放。[figure-build-pdfs.json](records/figure-build-pdfs.json)保存当前源文件与PDF哈希；[figure-optimization-review.json](records/figure-optimization-review.json)保存本轮十图身份、实际显示、正文页面及分页复核。此前的[图件验收](records/figure-build-visual.json)保持原版本。

## 实际页面检查与所报字符问题

最终85页全部具有实际视觉检查依据；版式调整后，变化页重新显示，字节完全相同的页面按完整PNG哈希接续实际显示证据。本轮另显示了两份附录的当前总览，其26个单页PNG与既有验收逐页完全相同。既有正文与附录记录见 [figure-build-pages-main.json](records/figure-build-pages-main.json) 和 [figure-build-pages-supplement.json](records/figure-build-pages-supplement.json)，本轮直接显示与同像素接续的边界另由[图件优化验收](records/figure-optimization-review.json)登记，没有以编译通过替代读图。

对上轮中文PDF（SHA256 88a6d973f4a625455621440738af3f4cf6e0b72741699df188846fcba12a1b1c），实际核对源码、文字层和p4、p12、p17、p23页面：所报“令”、L、items首字母、受控生产量上下标、引文右方括号及Author拼写均完整，未复现字符故障。未将这些项目虚记为已修复的LaTeX缺字。书目核查性尾注与代码库名称解释则已实际修订，新增表格、金融式、汇合陈述及其分页均按新成品检查。

## 可编辑材料与交付范围

[reading-guide.md](reading-guide.md)与 [packaging-README.md](packaging-README.md)提供阅读、重建和复核入口。可编辑包包括四份稿件及PDF、十张SVG与对应矢量PDF、书目、来源对应、五份辅助源码、审读记录和本稿构建脚本，并按原字节收录必要的七个共享依赖。打包器检查成员白名单、各文件哈希、四份源与成品绑定、链接闭合、ZIP CRC及独立目录中的构建依赖。

本地阶段只更新本稿和roadmap的本稿入口；阶段提交以包含本说明的Git提交为准。临时页面、排版工作目录和已用完的QA已清理，正式稿件、图件、来源和核验记录保留。
