# 阅读与复核指南

本稿把资本的结构刻画、公共功能替代、实际共同处置和继续行动接在同一组执行对象上。中英文正文各自完整呈现论证；双语技术附录保存定义、决定性证明及声明对应。

## 阅读入口

| 材料 | 文件 | 用途 |
| --- | --- | --- |
| 中文正文 | [capital-formation.pdf](build/capital-formation.pdf) | 从基础参与的理由进入资本对象、全称定理和文献对话 |
| English article | [capital-formation-en.pdf](build/capital-formation-en.pdf) | Complete English article with the same theorem and equation structure |
| 中文技术附录 | [capital-formation-supplement.pdf](build/capital-formation-supplement.pdf) | A—H：形式对象、关键证明、实际来源及消费者 |
| English technical supplement | [capital-formation-supplement-en.pdf](build/capital-formation-supplement-en.pdf) | Definitions, decisive proofs and fixed-source correspondence |

正文源为 [manuscript.md](manuscript.md) 与 [manuscript-en.md](manuscript-en.md)；附录源为 [supplement.md](supplement.md) 与 [supplement-en.md](supplement-en.md)。

### 先理解对象，再看结果的强度

§1—§3从一次生产行动开始，解释需要、准入、回流和处分怎样构成资本关系，并证明完整无资本条件与权限无不对称的充要关系。§2把基础参与、任务资格、贡献索偿和治理权限的理由分别说清，再用实际供给与复核过程把它们接合。

§4—§6展示全称结果怎样使用：每项实际资本证据由自身生成登记并进入同一社会合同；任意实际截点在有限内部步数内得到完整处置；任意执行词可以逐项公共重放，保留完整后态、生活维护和任务服务。处置图同时保留成功与具体失败的实际对象。

§7—§10将未知事件前固定的机制、连续创新、贡献来源的累计结算、完整账户、两类清算成本和制度变更接回这条运行。贡献界逐来源汇总全部槽，成本比较分别使用财务尾段与完整清算的可行域。

§1.2的五分肢导览表把18项结果接回各自的政治经济学问题。§5.2定义全账改善的同起点、同轮数基准与金融差额，§6.1区分任意序列的功能保持和当前转换的实际成功。§8.2—§8.4及§10.4与Roemer的财产权、联盟退出和再生产论证对话；§10的正式陈述同时保留无限旧账与来源已发出的汇合事件。

需要检查证明时，正文的关键构造后接相应技术附录。附录A—B对应资本对象及重构，C对应实际处置，D对应公共重放，E对应创新与贡献，F对应账户与动态承接，G对应成本，H给出固定源码位置。

## 五组双语图

[图件说明](figures/README.md)解释每个箭头、数值和量化范围。[make_figures.py](figures/make_figures.py)是可编辑生成源；每幅保留SVG、矢量PDF与PNG，英文文件名增加`-en`。

| 图件 | 对应论证 |
| --- | --- |
| `fig01-structure` | 权限矩阵与完整无资本条件的五面刻画 |
| `fig02-disposition` | 资本证据自行登记、金融入口分派与有限实际处置 |
| `fig03-replay` | 实际执行项逐一映射与同一完整后态 |
| `fig04-innovation` | 连续实付创新与按同一贡献来源汇总全部槽 |
| `fig05-cost` | 不同可行域中的实际达到者与任意完成候选的严格改进 |

图件源画布宽1440px、正文嵌入宽464pt。正文引用SVG，构建时采用同名矢量PDF。图5的离散点取自已证成本式；图中技术参数不表示时间或清算次数。

## 声明与固定来源

claims.md（仓库工作记录，不随本可编辑包提供）保存论文主张与形式声明的对应；[records](records/)保存来源身份、文献、构建与验收记录。

本稿采用形式化研究代码库Homework提交`df421ff600085cbc290a7ae946193961bed7c83b`，公开对应版本为复现代码库H0mework提交`2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`。图件直接承重文件的字节身份另见 [figure-build-source-identities.json](records/figure-build-source-identities.json)。

四份阅读PDF的源文件哈希、输出哈希、页数及编译结果集中在 [figure-build-pdfs.json](records/figure-build-pdfs.json)。本轮图件优化的双语成图、正文页面与附录同像素复核见 [figure-optimization-review.json](records/figure-optimization-review.json)；此前十张双语图的验收保留在 [figure-build-visual.json](records/figure-build-visual.json)。正文与附录的既有逐页实际显示记录分别见 [figure-build-pages-main.json](records/figure-build-pages-main.json) 与 [figure-build-pages-supplement.json](records/figure-build-pages-supplement.json)；各记录按自己的版本绑定PNG与PDF身份，区分直接显示和经过字节核对的同像素接续。

## 重建本稿

以下命令从`publish`根执行，范围只包括本稿。

```sh
python3 papers/capital-formation/scripts/build_reading.py
```

默认生成中英文正文和中英文附录四份PDF。可以用`--part main`或`--part supplement`选正文/附录，用`--language zh`或`--language en`选语种。重建图件再生成PDF：

```sh
python3 papers/capital-formation/scripts/build_reading.py --figures
```

正文排版复用`shared/scripts/build_pdf.py`、`byline.py`和`shared/styles/`。本稿的[build_reading.py](scripts/build_reading.py)与[table-layout.lua](scripts/table-layout.lua)只处理本稿标题、章节相邻关系、来源表、长哈希和参考文献分页。共享样式保持为依赖；所有修改位于本稿目录。

PDF编译需要Python3、Pandoc3、XeLaTeX及xeCJK、模板使用的Latin Modern和Noto Serif/Sans CJK SC字体。图件重建另用fontTools、PyMuPDF、Pillow、Chrome及STIX Two Text/Math字体。已交付的同名矢量PDF可直接用于正文排版。

## 版面检查的复现

[render_pdf_review.py](scripts/render_pdf_review.py)将指定PDF渲染为1440px宽逐页图，并生成六页总览及机械检查报告。例：

```sh
python3 papers/capital-formation/scripts/render_pdf_review.py papers/capital-formation/build/capital-formation.pdf --width 1440
```

输出位于`build/pdf-review/<PDF名>-<SHA前12位>/`。选定关键页可另渲染2160px细查图，例如：

```sh
python3 papers/capital-formation/scripts/render_pdf_review.py papers/capital-formation/build/capital-formation.pdf --width 2160 --detail-pages 10,20
```

机械报告用于发现缺字、页外文字与近空白页；实际显示后再记录图注、箭头、公式、表格和分页的阅读结果。正式验收记录保留，临时页图与排版工作目录可按本稿构建流程重新生成。


## 可编辑包中的图件范围

本包提供SVG与同名矢量PDF；记录中列明的PNG预览及逐页审阅图可由脚本重建，不随本包提供。
