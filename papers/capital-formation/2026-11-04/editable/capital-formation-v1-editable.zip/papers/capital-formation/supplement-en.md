# The Structural Theorem of Capitalism: Technical Supplement

## A Capital evidence on one execution

This supplement supplies the definitions, decisive proofs and source correspondence used in the article. Let $I,G,P,T,F$ be the types of parties, goods, ports, technologies and financial instruments. The finite inspections use the relevant decidable equality structures. A law $L$ specifies request validity, permissions, material and financial effects, and needs. A state $s$ records stocks $x_s(i,g)$, a claim matrix $b_s(f,d,h)$, technology, a clock and a round. Write the execution inventory of a finite request sequence $w$ as
\[
E_L(s,w)=\bigl[(j,s_j,r_j)\bigr]_{j<|w|}.
\tag{A1}
\]
Each item retains its position $j$, its state before the request $s_j$, and the request $r_j$. Rejected requests retain their positions. Let $N_L(s,w)$ be the complete resulting state, including technology and the clock. Instruction addresses below refer to this inventory; evidence spanning periods also retains the visit and the position within that visit.

### A.1 Acquisition of needs and unequal access

Let $c_L(s,p)$ be the controller of port $p$ at $s$, and let $a_L(s,p,i)\in\{0,1\}$ be the permission of party $i$. A private access asymmetry is
\[
\operatorname{Private}_L(s,p,i)
\ \Longleftrightarrow\
a_L(s,p,c_L(s,p))=1\ \land\ a_L(s,p,i)=0.
\tag{A2}
\]
This is a present permission relation. Capital evidence additionally specifies how that relation enters the acquisition of needs and an economic circuit.

An access proposal $A$ names an acquisition item $e_a$, a needs item $e_n$, an affected party $i$, an acquisition holder $h$, a port $p$, acquisition and needs goods, and a delivery route connecting the items. Its checks require the following.

1. The acquisition item is valid, and $p$ is an actually required port of its request.
2. The relation $\operatorname{Private}_L(-,p,i)$ holds both before $e_a$ and at $N_L(s,w)$.
3. The needs item is a valid necessity or maintenance use for $i$, with strictly positive quantity of the specified good. Validity also requires the bundle to equal the necessity or maintenance bundle prescribed by the law at that state.
4. Acquisition has two modes. The **acquired** mode requires an actual positive credit at $(h,g_a)$ and a time ordered delivery route from after $e_a$ to $(i,g_n)$ at $e_n$. The **used** mode requires the same position for both items, holder equal to affected party, equal goods, an empty route and the corresponding actual positive debit.

Routes are formed from accepted items and their temporal connections. Needs acquisition therefore retains a particular person, good and occurrence; an asset valuation cannot supply that evidence. See S1.

### A.2 Reciprocity, return and disposal

Reciprocity $R$ has three constructors, all reading the same inventory.

| Constructor | Actual checks |
| --- | --- |
| Productive input | A valid production item calls $p$ no later than the acquisition item; a nonempty route connects material from the affected party to an actual positive production debit. |
| Return flow | A nonempty route carries material from the affected party to the controller associated with the acquisition item and finishes within this sequence. |
| Financial claim | A valid positive issuance or assignment has the controller as beneficiary; the affected party is the debtor at issuance, or the debtor or sender at assignment. |

A disposal proposal $D$ identifies an intermediate state that actually occurred and a local alternative request executable there. The holder signs the request, its controller consent list is empty, and it is valid. The operation is an external or investment use by the holder, a material transfer toward the holder, or an assignment by the holder to another party. The relevant quantity is positive. A valid allocation chain within the same history may update the holder. The disposal site retains a private access asymmetry against the affected party.

Thus
\[
C(L,s,w)=
\{(A,R,D):\operatorname{Check}_A(A)
\land\operatorname{Check}_R(A,R)
\land\operatorname{Check}_D(A,D)\}.
\tag{A3}
\]
The symbol $C$ denotes an evidence type with fields. Disposal records an executable power, while the other legs include executed acquisition, needs and reciprocal relations. A positive unpaid debt can provide financial reciprocity. Profit, increasing reserves and success in a later round are not premises of (A3). S1 defines the checks and their compiler.

### A.3 Transferable authority, actual appropriation and history

**Transferable asset control** augments $C$ with a control transfer at the same port. A valid revision changes its controller from $h$ to $h'$, where $h\ne h'$; $h$ is permitted before and denied afterward, and $h'$ is permitted afterward. The request may have been executed or may be a checked local quotation at an actual intermediate state. Authority permanently attached to one actor cannot satisfy this controller change.

**Actual surplus appropriation** adds executed evidence to $C$ in one of five forms: consumption, investment, retention, consumption along a control route, or financial return. Retention checks acquisition, subsequent debits and final stock. Routed evidence preserves the material and control connections. Financial return must align with the same financial issuance origin used by the kernel. Actual appropriation and feasible disposal establish, respectively, what was received and what can be decided.

**Historical capital relations** place access, needs, reciprocity and disposal addresses within one actual visit history. Their title quotation, retention, consumption or investment evidence may span different visits. At the endpoint, the current controller remains permitted while a current participant is excluded. For a historical relation to be exercised as current control, the current request must be valid and actually require the port; its affected party is read from the current item's positive material beneficiary, producer, needs bearer or financial bearer.

Actor and relation lineages are generated from these occurrences. The actual access signer appears in the participants of that visit and receives an actor birth record. The required port and its controller generate a relation birth record. Lookup along each successor returns the same birth record. A change of controller preserves the relation's origin and does not replace an actor with the new asset holder. Filtering new circuits by visit index does not count an old access item as a new acquisition. S2 establishes these distinctions and preservation properties.

## B Minimal support, complete reconstruction and universal scope

### B.1 The two directions of the five-part contract

Define
\[
\operatorname{NoAsymmetry}(L)
\Longleftrightarrow
\forall s,p,i,\
a_L(s,p,c_L(s,p))=1\Rightarrow a_L(s,p,i)=1.
\tag{B1}
\]
The complete contract $\operatorname{NoCapital}(L)$ jointly excludes private access asymmetry, a capital kernel, transferable capital asset authority, actual surplus appropriation, and fresh historical control under the same effective law.

**Proposition B1.** For every $L$,
\[
\operatorname{NoCapital}(L)\Longleftrightarrow
\operatorname{NoAsymmetry}(L).
\tag{B2}
\]

**Proof.** The first component of the complete absence contract excludes every private access asymmetry. Fix $s,p,i$ and suppose the controller is permitted. The Boolean permission of $i$ cannot be zero, since that would give (A2). It is therefore one, proving (B1).

Conversely, (B1) excludes (A2). Every kernel contains (A2) in its access check, so no kernel exists. Transferable capital authority and actual surplus retain that same kernel dependency. Fresh historical control carries (A2) for a currently affected party. Eliminating these dependencies proves all five components. $\square$

The permission component of the contract supplies necessity directly; the remaining components establish that this support extends through the capital objects. A separate materially complete permission family proves actual sufficiency. It keeps the stocks, needs, return and disposal data while varying only the controller's and affected party's two permissions. At every clock and round, a kernel exists exactly when the controller is permitted and the affected party is denied. At the displayed zero-clock, zero-round starting point, opening the affected party also preserves every execution item and the complete resulting state. S3 supplies the universal characterization and this actual nonempty family.

### B.2 Exact disposition of every constructor input

The compiler checks access, reciprocity and disposal in sequence. When all pass it returns a kernel retaining the submitted proposal; the first failed check identifies a failure. For every proposal $q$,
\[
\begin{aligned}
&\left(\exists c,\ \operatorname{compile}(q)=\operatorname{some}(c)
\land c.\operatorname{proposal}=q\right)\\
&\qquad\lor\neg\operatorname{Check}_A(q)
\lor\neg\operatorname{Check}_R(q)
\lor\neg\operatorname{Check}_D(q).
\end{aligned}
\tag{B3}
\]
The successful branch and the three failed checks form a disjunction. The programme returns the first failure in checking order. The three reciprocity constructors exhaust the input type, so (B3) covers that entire type.

For actual surplus, the compiler first checks the kernel dependency and then one of the five appropriation forms. Success preserves the same proposal and evidence; failure identifies the kernel or appropriation check. The historical compiler similarly checks the three structural legs and four historical forms.

**Proposition B2.** Every packaged witness is reconstructed exactly from its own fields:
\[
\operatorname{compile}(c.\operatorname{proposal})
=\operatorname{some}(c).
\tag{B4}
\]
Actual surplus and historical capital satisfy corresponding equalities.

**Proof.** Eliminate the constructor of the packaged witness to expose its fields and the established checks. Substituting those checks into the same compiler selects the success branch, which returns the witness field by field. No new witness is selected. $\square$

The unified control family also has an exact membership characterization: title discovery, surplus discovery or historical discovery at the same item, together with its private access asymmetry or fresh historical control, gives precisely its family membership. An actual control use additionally requires a valid current item that calls the port. Identification and execution thus remain connected. See S3–S4.

## C Social admission and finite disposition of arbitrary capital

### C.1 Registration generated by capital evidence

An institutional input $X$ contains a law, an initial state and static instructions or a dynamic emission programme. Let $r(X)$ be its registration size and $w_X(s)$ its current emitted word.

**Proposition C1.** Every
\[
c:C(X.L,s,w_X(s))
\]
produces $r(X)>0$ and thereby enters the social capital contract.

**Proof.** When a dynamic emitter exists, its registration rule gives a positive size. In the static branch, registration size equals instruction-list length. Length zero would make both the current word and its item inventory empty. Yet the access field of $c$ identifies an item in that inventory, a contradiction. Registration size is positive. Feeding this fact to the same social admission programme produces the contract. An actual control use likewise carries a real instruction item and generates the required registration. $\square$

The contract also quantifies over the registered social visit, source index, boundary, source origin, actual ingress datum, reader, finite window parameters and optional review context. These parameters determine how the same run enters an existing social occurrence; they do not provide a successful destination.

### C.2 The two financial entrance branches

Financial admission compares
\[
B_X=\operatorname{claims}(X.\operatorname{initial}),
\qquad B_{\mathrm{native}}(X).
\tag{C1}
\]
The native genesis account used by this admission has $B_{\mathrm{native}}(X)=0$. A successful comparison yields equality and admits, at every tick of the same run, the termination, public replacement and renewal contracts. A failed comparison returns
\[
\exists f,d,h,\quad
B_X(f,d,h)\ne B_{\mathrm{native}}(X)(f,d,h),
\tag{C2}
\]
while retaining the complete input, social law and actual root successor. Genesis inspection is distinct from subsequent actual issuance, inheritance and settlement. The old debt in the innovation instance is issued in actual history and then retained. S5 supplies the admission branches and their same-root equations.

### C.3 Why internal work gives a finite bound

Fix an actual run with states $z_t$ and successor $T$. Its internal mass $m(z_t)\in\mathbb N$ is computed from the pending work inventory. Each internal step consumes a position. The completion programme reaches an institutional review boundary within $m(z_t)$ actual steps; boundary selection uses at most one more step to produce a public state or an exact review obstruction. Hence
\[
\exists k\le m(z_t)+1,\quad
\operatorname{CompleteDisposition}(z_{t+k}).
\tag{C3}
\]

Complete disposition has two levels. Before public admission, it identifies an initial replacement-review obstruction while preserving the relevant row identities, claims and unspent budgets. Once public execution is installed, the programme reads three checks in order.

| Check | Successful content | Object retained by failure |
| --- | --- | --- |
| Full account assessment | Complete change is nonnegative for every person and good, and strictly positive at some coordinate. | The failed financial check at this current account. |
| Member migration | Actual independent execution; paid life and maintenance for the entering members; retained production capacity; no fresh control. | A migration issue on the same initial public execution and member list. |
| Current future | An executable plan compiled from the current snapshot pays the current members' needs. | Failed checks over this snapshot's candidate set. |

The full-account audit uses the baseline defined in §5.2 of the main text. Starting at the common point of public admission, the pre-transition source runs under its own law for the number of rounds in the public history, reading its current state and issuing actions anew at each round. Write \(\Delta F=F^{\mathrm{pub}}-F^{\mathrm{base}}\) for the difference between endpoint debt matrices, and \(u_j,r_j\) for instrument \(j\)'s settlement good and rate. Valuation is
\[
V_L(\Delta F)_{i,g}
=\sum_{j,d,h}\Delta F(j,d,h)r_j\,
\mathbf{1}_{\{g=u_j\}}
\bigl(\mathbf{1}_{\{i=h\}}-\mathbf{1}_{\{i=d\}}\bigr).
\]
The sum reads only the finite difference support generated by the two actual financial executions. Their common initial debt matrix cancels in the comparison; debt identities and actual performance histories remain. A claim increment enters positively for its holder and negatively for its debtor. An actual settlement's physical payment and claim retirement are combined at the same settlement-good coordinate, so principal is not counted again as a net gain or loss. The checks also require positive rates for instruments with a financial difference, positive elapsed public time, and equal endpoint clocks. After adding the endpoint stock difference, every person–good coordinate must be nonnegative and at least one strictly positive. S6's financial-source, valuation and checking declarations jointly establish this result.

The three successful outputs jointly form an abolition witness. A future obstruction excludes the current candidate set. Actual admission separately guarantees the initial migration; the three checks retain a uniform evidence structure.

If another path satisfies $y_0=z_t$ and $y_{n+1}=T(y_n)$, induction gives $y_n=T^n(z_t)=z_{t+n}$. Thus (C3) is a result about the same actual iteration. S6 supplies the bound, checks and path uniqueness.

### C.4 Exact meaning of no legally absorbing terminal state

A legally absorbing capital path would follow the same successor and satisfy both
\[
\forall n,\ \exists m\ge n:\operatorname{FreshControl}(z_m),
\qquad
\forall n,\ \operatorname{ReviewClosed}(z_n).
\tag{C4}
\]
The first permits intermittent control but requires its recurrence in every tail. The second inspects initial public replacement: at every applicable boundary before public admission, initial selection has not returned an unresolved obstruction. In a public state that second condition holds automatically.

The finite review result excludes this path. If the run enters a persistent public tail, its effective interpreter opens every port, so no fresh title, surplus or historical control occurs there. If it returns an initial review obstruction, the second condition fails. The same argument also excludes cofinal generation of a kernel on some word. Finite work must therefore yield public continuation or an identified review responsibility. S6 retains the existing financial claims and historical prefix along these successors.

## D General public replay and actual selection

### D.1 Construction for each request

Let $L^\circ$ preserve the material, financial, technological and needs operations of $L$, open permissions and set operation policy to unrestricted. For state $s$ and request $r$, define
\[
\rho_L(s,r)=
\begin{cases}
\text{same operation and signer, with controller consents removed},
&\operatorname{Valid}_L(s,r),\\
\text{zero-effect presentation with the same signer and purpose},
&\neg\operatorname{Valid}_L(s,r).
\end{cases}
\tag{D1}
\]
A rejected request retains its execution position; the corresponding source inventory retains its detailed failed request. A presentation cannot count as a material delivery.

Recursion advances by the actual successor under the given law:
\[
\begin{aligned}
\mathcal R_L(s,[])&=[],\\
\mathcal R_L(s,r::w)&=
\rho_L(s,r)::\mathcal R_L(\operatorname{step}_L(s,r),w).
\end{aligned}
\tag{D2}
\]
Both branches are valid under $L^\circ$, and
\[
\operatorname{step}_{L^\circ}(s,\rho_L(s,r))
=\operatorname{step}_L(s,r).
\tag{D3}
\]
An accepted request preserves the operation and resource checks. For a rejected request, both sides leave the state unchanged. Actual debit and credit also agree item by item.

**Proposition D1.** For every $L,s,w$, replay preserves length, the complete resulting state and an exact inventory map:
\[
\begin{aligned}
|\mathcal R_L(s,w)|&=|w|,\\
N_{L^\circ}(s,\mathcal R_L(s,w))&=N_L(s,w),\\
E_{L^\circ}(s,\mathcal R_L(s,w))&=
\operatorname{map}(\widehat\rho_L,E_L(s,w)).
\end{aligned}
\tag{D4}
\]
The map $\widehat\rho_L$ retains each item's position and prior state and replaces only its request.

**Proof.** The empty sequence is immediate. For $r::w$, (D3) gives the same next state on both sides, so the induction hypothesis applies to the remainder. The leading inventory item corresponds by $\widehat\rho_L$. The complete resulting state includes the same period update; equal lengths preserve the clock and round updates. $\square$

### D.2 Two-way preservation of needs and services

For any member list $M$,
\[
\operatorname{AllNeedsPaid}_{L^\circ}
(s,M,\mathcal R_L(s,w))
\Longleftrightarrow
\operatorname{AllNeedsPaid}_L(s,M,w).
\tag{D5}
\]
First prove the correspondence for one person's one bundle. A valid use preserves its operation and bundle in replay. Conversely, a replayed use cannot have come from a zero-effect presentation, so it identifies the accepted corresponding item. Apply this to life and maintenance, then quantify over the members of $M$.

A service task also identifies its specified user, bundle, purpose and time window. Equation (D4) preserves the terminal clock, and bundle correspondence preserves payment, yielding the same equivalence for service adequacy. Open permissions exclude private asymmetry and hence a capital kernel. S7 supplies the request construction, inventory induction and service proofs.

### D.3 From an available replacement to actual selection

Replay supplies a functionally equivalent execution. Actual selection additionally reads current candidates and a full account preference: an initial candidate must pass the complete account improvement check and retain a feasible continuation after its execution. If such a candidate exists, selection actually returns a public plan, and its initial public state produces a complete abolition witness.

Renewal has two further conditions: the current internal work is complete, and the automatic proposal is an advance. If the current candidate set contains a renewal passing its complete improvement and post-execution feasibility checks, the compiler selects a plan. The next actual snapshot equals that plan's successor and produces a fresh abolition witness. Uniqueness of successful selection identifies the checked plan with the returned plan; migration, account and future checks then apply to that value. See the selection theorems in S6.

## E Ex ante innovation and contribution receipts

### E.1 Mechanism, event and quotation

A mechanism $M$ fixes its law, local programme, financing word, investment request, information costs, policy and closing actions before the actual event $\nu$ enters. The quotation domain is a finite event syntax; the actual event domain consists of all requests of that mechanism. Consequently,
\[
\forall M\ \forall\nu\in\operatorname{Nature}(M),\quad
\operatorname{Disposition}(M,\nu)
\tag{E1}
\]
does not require membership of a quotation menu. Disposition contains an accepted trial with its evidence, or an actual financing, observation or execution failure.

Local policy reads the party's acquired information. Paid information requires an actual positive debit; financing requires material delivery in addition to valid issuance. Quotation weights are declared, nonnegative and normalized. Success weight $p>0$, weighted failure loss $\ell$, outside opportunity $a$ and loading $b\ge0$ give
\[
r=\frac{\ell+a+b}{p},\qquad
\mathbb E_{\mathrm{declared}}[\Delta]=a+b.
\tag{E2}
\]
Failed quotation checks return their issues. Subsequent requests perform the actual payment. S8 supplies the order of construction and total disposition over the two event domains.

The two-trial instance finances, invests and buys information in each round. Technology progresses from zero to one to two, and the second discovery belongs to neither quotation menu. The second trial starts with zero prototype stock, so a retained earlier sample cannot supply the new discovery. Investment loss is three in each trial, and the actual message-resource difference is three in each. Balance one at the debt address $(\text{instrument},0,2)$ persists. Both periods actually pay all members' life and maintenance, and the second quotation is recomputed from its own prefix.

Releasing a further trial separately checks the current period's needs. The programme first runs the current disposition and then checks life and maintenance for each member; failure identifies the person and unpaid category. An instance with a payable future proposal but unpaid current needs is rejected by this gate. S8 includes both the positive example and this refusal.

### E.2 Slot conservation and the bound over all slots of an origin

Let $P_j(q)\ge0$ be the remaining principal in slot $j$ at account state $q$. For a financial run $\gamma:q_0\leadsto q_1$, define
\[
R_j(\gamma)=\sum_{e\in\gamma}
\mathbf1_{\{\operatorname{slot}(e)=j\}}\,
\operatorname{actualPaid}(e).
\tag{E3}
\]
Here $\operatorname{actualPaid}$ measures the principal actually retired by an event. Assignment changes allocation among holders; issuance establishes its own claim; waiting retires no principal.

**Proposition E1.** For each slot already present at the starting state,
\[
P_j(q_1)+R_j(\gamma)=P_j(q_0).
\tag{E4}
\]
Admission of a new slot does not pay an existing slot. Crossing a financial boundary on the same slot reduces its principal by exactly the payment. Crossing a different slot leaves this one unchanged. Reopening a terminal slot has an empty event type in this financial process. Induction on the run adds these step equalities to obtain (E4).

Fix the contribution origin $o$ of a slot registered at $q_0$, and let $Q_o$ be its issuance quantity. Its origin receipt is
\[
R_o(\gamma)
=\sum_{\substack{j<|\operatorname{slots}(q_1)|\\
\operatorname{origin}(q_1,j)=o}}R_j(\gamma).
\tag{E5}
\]
It counts actual principal retirement in every terminal-account slot bearing that origin: the receipt of the specified contribution claim.

The actual source generates uniqueness through the strict order of occurrence addresses. An issuance item enters once. Static registration, actual ingress and public continuation use distinct origin tags. Account transport preserves those tags without reissuing the claim. Thus at most one terminal slot has origin $o$. Equation (E5) reduces to (E4) for that slot. Since $P_j(q_1)\ge0$ and $P_j(q_0)\le Q_o$,
\[
\boxed{R_o(\gamma)\le Q_o.}
\tag{E6}
\]
This fixes an origin registered at the starting cut and quantifies over every actual cursor continuation and every public suffix after an actual prefix. Taking the starting cut immediately after admission gives the cumulative bound from issuance: issuance itself pays nothing, and the slot had no payments before admission. Every actual public visit of the innovation run consumes the same proof. These runs generate source uniqueness; arbitrary repeated abstract admissions of one claim do not satisfy that condition.

For an unbounded demand sequence $d_n$, choose $d_n>Q_o$. Equation (E6) excludes its payment from a suffix of origin $o$. New contributions, gifts and other income sources retain their own accounts. Finite total receipt does not specify the clock of final payment. S9 proves slot conservation, source uniqueness and the bound over all slots.

## F Complete responsibility and dynamic continuation

### F.1 Material and financial identities for the same execution

For every finite prefix of an actual programme, each person and good satisfy
\[
x_{\mathrm{after}}(i,g)+D(i,g)
=x_{\mathrm{before}}(i,g)+K(i,g),
\tag{F1}
\]
where $D,K$ are the inventory's complete actual debits and credits. Every instrument, debtor and holder satisfy
\[
b_{\mathrm{after}}(f,d,h)
=b_{\mathrm{before}}(f,d,h)+\Delta b_E(f,d,h).
\tag{F2}
\]
Induction follows actual compilation and programme concatenation. Accepted branches use the execution's balance identity; refusals and metadata branches add no material effects. Every positive net stock gain must identify an accepted positive-credit item in the same inventory. Otherwise all credits are nonpositive, contradicting (F1) and nonnegative debits. Issuing a financial claim does not provide this material witness. S10 identifies actual institutional history with this programme fold.

Complete income distinguishes net production, other transfers and signed net transfers at the identified controller addresses. Valuation additionally reads a revaluation component. Net production includes actual production, use and revision costs. Settlement cash and claim retirement enter the same account, so principal repayment is not counted again as net gain.

### F.2 Joint repair without duplicate allocation

Net productive blockage compares controlled and open executions of the same source:
\[
q(i,g)=
\max\{0,\operatorname{productiveOpen}(i,g)
-\operatorname{productiveControlled}(i,g)\}.
\tag{F3}
\]
Financing, information, experimentation and the responses actually triggered on each branch enter the comparison. Its positive support is generated from finite flow support. One responsibility object contains the complete matrix of harmed persons and goods.

Productive repair $P$ uses this positive harm matrix. Gross control-return responsibility $G$ is generated from an executed controlled return: the recipient signs, the sender has not consented, a private access asymmetry exists, and this very item belongs to a discovered capital return route. Quantity equals the victim's actual debit and the recipient's actual credit. It is grouped by victim, recipient and good. Signed gifts, explicit consent and public repair fail these control conditions. Reading $G$ does not deduct or retire financial claims; actual settlement must perform that work separately.

Both responsibilities share one stock state, one execution and one successor. Each allocable receipt first reserves material for $P$; $G$ receives only the remainder. The full-word calculation deducts shares allocated to the other responsibility and actual costs. All members' life and maintenance are checked separately. Resource conditions concern recipes, starting stocks, needs and single-allocation capacity. They generate payment or a specific failure rather than accepting a caller-supplied paid state.

Responsibility renewal uses the number $B$ of currently positive residual cells. An admitted renewal input must pass for the whole word, actually pay every member's needs and clear at least one cell. Therefore, for $n$ consecutively admitted inputs,
\[
n+B(z_n)\le B(z_0).
\tag{F4}
\]
The first input without the required decrease returns settlement or an addressed obstruction; partial payments that actually occurred remain in the successor. This bounds renewals of the same outstanding responsibility. S11 supplies these responsibility and allocation mechanisms.

Financial completion also distinguishes zero principal from formal archival. A slot scan allocates a single payment amount, leaving only the remainder for later slots. A live zero-principal slot subsequently passes its own check to create a terminal archive. The archive retains obligation, content, origin and history; every successor preserves that receipt. New debt uses a new occurrence and slot.

### F.3 Arbitrary coalitions, institutional changes and emitted limits

A coalition is a Boolean selection of parties. Sums use finite execution support and retain each good separately. Continuations permitted by an already paid repair row satisfy
\[
\operatorname{Income}_{S,g}
+\operatorname{Consumed}_{S,g}=0,\qquad
\operatorname{Income}_{S,g}\le0.
\tag{F5}
\]
The paid responsibility authorizes no further extraction, while actual life and maintenance consumption may continue. An open mechanism may change at every tick, but its initial state and effective law are rebound to the current state. Equation (F5) adds along the same actual finite chain. A replacement mechanism's packaged stock cannot recharge the current account. Other legitimate sources retain their income and responsibilities.

Institutional successors transport all old rows through the same whole-account map. Claim images remain injective, unspent budgets do not increase, and paid rows remain zero. The full financial matrix obeys (F2), and material balances obey (F1). The effective interpreter retains the absence contract. If a purported law supplies a new capital witness, the witness identifies a permission address denied to the affected party by that law but permitted by the actual interpreter. Regeneration is thereby located at a specific difference in interpretation.

For a cofinal occurrence already emitted by its source, the completion representation is generated from actual past rows and their connections. Each nonincreasing natural-number budget reaches its minimum at an occurred cut; different rows may use different cuts. The completion carrier retains those claims and budgets. Registration is still decided by that event's source programme: compatibility generates a carrying row and first write; incompatibility returns a row and lineage conflict. Finite cuts do not preload future completion rows. S11–S12 supply the inherited contract and these dynamic results.

## G Clearing cost: attainment and improvement of every candidate

### G.1 The sufficiently funded financial suffix

Cost records actual resource use separately for productive inputs, production maintenance, revision and purposes, and also records elapsed clock time. For nonnegative weights,
\[
K_\lambda(w)=
\sum_{e\in E(w)}\sum_{\chi,i,g}
\lambda_{\chi,i,g}\,d_\chi(e;i,g)
+\lambda_t\,\Delta t,\qquad
\lambda_{\chi,i,g},\lambda_t\ge0.
\tag{G1}
\]
Transfers and settlements have cash legs. Financial principal retirement is not itself resource destruction.

Fix an actual ready position with the material resources needed to settle and archive each slot. The account-generated clearing word contains the corresponding settlement and archival actions. Additional resource use and physical time are zero. It is therefore minimal in every cost channel among comparable source programmes and minimizes every nonnegative readout. The resource conditions make it an actual completion: all principal is zero, every slot is archived, and current institutional control, history and the actual successor remain connected. Comparison with any actual policy begins at this same cut; concatenation adds the entire common historical cost back to both sides. S13 establishes attainment and comparison under a live institution.

### G.2 A concrete complete cost domain

Nonattainment uses a fixed source with two parties and two goods. Let $g_0$ be the life and settlement good and $g_1$ the production and maintenance material. The actual prefix issues debt one, transfers one unit of settlement good from holder to debtor, and actually consumes one life unit and one maintenance unit. Prefix cost is two. At the resulting cut, both parties hold zero settlement good, debt one remains, and the producer holds five units of maintenance material.

Technology $n\in\mathbb N$ consumes $\varepsilon_n=1/(n+2)$ input plus one unit of production maintenance to produce one settlement unit. Technology revision cost is empty, microstep durations are zero, and all resource and time weights are one. The candidate
\[
w_n=[\,\operatorname{revise}(n),\
\operatorname{produce},\
\operatorname{settle}(1)\,]
\tag{G2}
\]
has three valid requests; $\varepsilon_n\le1/2$ ensures affordability. Its suffix and full-history costs are
\[
K_{\mathrm{tail}}(w_n)=1+\varepsilon_n,\qquad
K_{\mathrm{full}}(w_n)=3+\varepsilon_n.
\tag{G3}
\]

Completion is also established in the financial lifecycle. The three requests enter a real run of the same account. The debt slot acquires its terminal archive while retaining its issued obligation, content and prior history; all principal is zero. Actual uses in the prefix preserve life and maintenance payment. Three physical effects and three financial consumptions execute in six root resolutions; all seven positions retain legality from the same source. The terminal position has no pending item and generates the next inquiry. S14–S15 therefore make every point in (G3) a complete clearing.

### G.3 An improvement algorithm for any completed candidate

Let $v$ be any finite programme in this source that clears the entire claim matrix. Write $c(v)$ for its actual suffix cost.

**Step 1: prove a strict lower bound.** Without an accepted production item, zero settlement stock is preserved by every nonproduction operation. Issuance only increases debt, assignment preserves its total, and settlement cannot pay positive settlement material. Total debt therefore remains at least one. A clearing programme must contain accepted production. That item pays maintenance one and strictly positive input $\varepsilon_n$, while all other costs are nonnegative. Thus
\[
c(v)>1.
\tag{G4}
\]

**Step 2: compute an improvement from the candidate's own cost.** Set
\[
\delta=c(v)-1>0,\qquad
n(v)=\left\lceil\frac1\delta\right\rceil.
\tag{G5}
\]
Since $1/\delta\le n(v)<n(v)+2$,
\[
\varepsilon_{n(v)}=\frac1{n(v)+2}<\delta.
\tag{G6}
\]
Generate $w_{n(v)}$ from (G2). Its completion properties hold for every $n$, and hence
\[
2+c(w_{n(v)})=3+\varepsilon_{n(v)}
<2+c(v).
\tag{G7}
\]
The comparison starts at the cut after the same occurred prefix and replaces $v$ by a cheaper candidate. It does not append actions after executing $v$. The common prefix cost two remains on both sides. The output includes actual payment, archival, all members' needs, a run from the same root and its successor.

**Step 3: exclude a minimum.** Suppose a completion were no more expensive than every complete candidate. Applying Step 2 to that completion gives a strictly cheaper complete candidate, a contradiction. For any tolerance $\eta>0$, choosing $n=\lceil1/\eta\rceil$ also produces a full cost strictly between three and $3+\eta$. The infimum is three and is unattained in the completion domain.

The proof quantifies over arbitrary completed programmes and computes an improvement from actual cost. Its conclusion exceeds a comparison within a displayed decreasing sequence. Optimality of a funded financial suffix and nonattainment in a complete productive clearing domain follow from their respective initial resources and tasks. S14–S16 supply the lower bound, algorithm and actual root consumers.

## H Statements and fixed sources

The article uses Homework commit \(\texttt{df421ff600085cbc290a7ae946193961bed7c83b}\). Its public counterpart is H0mework commit \(\texttt{2d6fbc96e33b7c4c3cfd91104fda74e3caeda045}\). All paths below lie under the common prefix $\texttt{Lean/SaturationMonoid/ProcessGame/Society/}$ followed immediately by $\texttt{Institutions/Capitalism/}$. Concatenating the two segments gives the complete source prefix. The claim evidence table and source record give exported modules, direct consumers and verification identities.

- **U**: \(\texttt{Universal/Source/ProgrammeControl/}\).
- **A**: \(\texttt{Universal/Abolition/}\).
- **C**: \(\texttt{Accounting/Quantifiers/Assembly/Strengthening/Characterization/}\) under A.
- **O**: \(\texttt{Accounting/Quantifiers/Assembly/Strengthening/Optimality/}\) under A.

| ID | Definitions, proofs and direct uses |
| --- | --- |
| S1 | U: Kernel/Access, Reciprocity, Disposal, Core. Access, reciprocity and disposal checks form the kernel. |
| S2 | U: Kernel/AssetAuthority/ProperKernel, Transfer; Kernel/ActualSurplus/Core; History/Core, Family, Binding. |
| S3 | C: Support/Law; Models/Permissions/Classification. The five-part equivalence and the actual permission family. |
| S4 | C: Support/Local, History, Exact; Models/Reconstruction/Kernel, Surplus, History. |
| S5 | A: Completion/Actual/External/Admission, ClaimsReceipt/Actual; Assembly/Society; Consumers/Forms supplies illustrative form-specific uses. |
| S6 | A: Completion/Actual/Finite/Resolution; Assembly/Disposition, Consumer, Control, Current; Capital/Runtime. |
| S7 | A: Functions/Replay/Request, Trace, Effects, Services, Public; Completion/Actual/Assembly/Functions. |
| S8 | A: Innovation/Completion/SourceLaw, Society, Assembly; Trials/Consumers/Renewal, RenewalGate; Trials/Source/Renewal/Decision. |
| S9 | A: Accounting/Contribution/Flow, Settlement; Source/Legacy, Receipts, Cursor; Epoch/Complete, Consumer, Actual. |
| S10 | C: Escape/Material, Actual, History, Complete. Actual institutional folds preserve material, financial and existing-row accounts. |
| S11 | A: Accounting/Quantifiers/Assembly/Completion/Core, Dynamic, Complete; Accounting/Profit/Inventory, Decomposition, Valuation, Public. Joint payment, full income and the open-mechanism contract. |
| S12 | C: Root/Contract, Consumers/Registered; inherited Total/Finite, Epoch, Cofinal, Complete and the complete cost contracts. |
| S13 | O: ActiveControl/Source, Minimum; Root/Complete, Institutional; Completion/Complete. All-slot archival also uses Archive/Native/Source, Acceptance, Complete; Archive/Word; Primitive/Archives; Consumers/Zero under A: Accounting/Quantifiers/Evolution/Ingress/Joint/Material/Runtime/Retirement/CompleteLedger. |
| S14 | O: Countermodels/Nonattainment/Source, Prefix, Programme, Cost/Lower, Cost/Pricing, Complete. |
| S15 | O: Countermodels/Nonattainment/Family/Source, Family/Cost, Native/Complete; Completion/Source; RootedSource/Complete. |
| S16 | O: Recognition/Family. Every cleared candidate generates a cheaper complete clearing from the same root; Completion/Complete inherits this result. |

Every listed file has extension \(\texttt{.lean}\). The main contract inherits, in order, minimal support and escape, complete clearing cost, institutional cost, cost, strengthened capital, actual institutional epochs, actual finite clearing, and the complete capital quantifier contract. A registered capital instance directly consumes the inheritance chain, so the universal results jointly constrain the same source and its successors.
