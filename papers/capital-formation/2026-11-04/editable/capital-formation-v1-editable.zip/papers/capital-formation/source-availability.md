# 来源、形式证明与复核入口

## 固定证明材料

本稿的形式化研究来源固定于研究代码库 Homework 提交 **df421ff600085cbc290a7ae946193961bed7c83b**，tree **13c04d40cc7d3e17f97434e53984e319d1c328c4**。公开证明材料沿用 [复现代码库 Sapientropic/H0mework 的固定快照](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045)，提交 **2d6fbc96e33b7c4c3cfd91104fda74e3caeda045**。

正文的18项编号结果由双语技术附录展开，逐项对应见 [source-correspondence.md](source-correspondence.md)。[机器绑定](records/public-source-binding.json)保存固定来源字节、实际公开模块、递归导入环境、声明与消费者，以及已有完整类型回执中的准确位置。

## 终稿修订时的公开快照核对（2026-11-04）

本轮只读观察到 H0mework 的 `main` 与本地 `origin/main` 同指向 **2e68d950eedda807acbedd443cfcd6a456b21218**。与上述验收快照相比，证明源码、导出映射、选集及验收回执均未改变，因此本稿继续固定引用 **2d6fbc96e33b7c4c3cfd91104fda74e3caeda045**，直接落在完成验收的版本。

两处已登记工作树的相关材料均无未提交改动；本次未发现另行完成的资本论文专用导出或验收入口。现有 SourceDF 导出与验收已经完成，本稿按其实际范围复用。下列五份辅助源码仍由本稿保存固定字节，其身份保持不变。`build_source_index.py --check` 再次通过，生成绑定与既有回执准确对应。

## 本稿实际采用与已有验收

本次全文核读105个固定来源文件，登记675处声明和191条直接导入关系。100个文件的对应模块位于已经验收的 `H0mework.Papers.EconomicConstitutionSourceDF` 实际导入闭包内；该闭包共2825个模块。绑定先从这个真实导入环境选择模块，再核对df来源别名、源码SHA256、公开目标SHA256和递归环境，未以路径相似或单个相同哈希代替模块身份。

这100个模块在既有验收回执中包含160项完整类型观测。每项绑定完整限定名、类型哈希、回执索引、kernel等价结果与公理；所用公理限于 `propext`、`Classical.choice`、`Quot.sound`，对应观测无unsafe或partial。其余声明保留准确的文件、行、定义和证明阅读记录，不把675处源码声明登记改写为675次新的独立类型检查。

既有验收的范围与本稿新编制的阅读、引用范围分别记录。以下路径相对于固定H0mework快照：

| 材料 | 固定路径与作用 |
| --- | --- |
| 采用包入口 | `Lean/H0mework/Papers/EconomicConstitutionSourceDF.lean` |
| 先前已验收主张映射 | `docs/economic-constitution-map.json` |
| 有限选集 | `checks/economic-constitution-selection.json` |
| 实际验收汇总 | `evidence/economic-constitution/acceptance/initial-intake/summary.json` |
| 类型与公理回执 | 由上述映射的 `acceptance.declaration_types` 给出路径、压缩与解压SHA；本稿逐项索引保存在机器绑定 |
| 复现说明 | `docs/economic-constitution-reproduction.md` |

该既有验收共含16个包与3313项完整类型观测；本稿列出的160项是其准确子集。历史独立T1认证保持各自的来源和执行范围，见命题证据表（仓库工作记录，不随本可编辑包提供）。本次写作窗口完成源码与回执核对、独立内容审读、翻译对照和出版构建，没有重跑Lean或科学实验。

## 五份辅助来源的原字节保全

另有五份固定df来源属于形态实例、分配引理及归档反例消费者，未作为上述已验收包的独立证明根。它们的完整源码原字节随稿保留于 `source-excerpts/`，对应原路径和哈希见机器绑定：

- `s022-Forms.lean`：六类资本形态对一般社会合同的使用。
- `s065-Total.lean`：共同分配的累计不重复花费引理。
- `s103-Archive.lean`：完整金融归档的具体消费者。
- `s104-Zero.lean`：零余额与未归档状态的具体消费者。
- `s105-Zero.lean`：零数量发行的原语反例。

全形态社会合同由 `Assembly/Society` 等一般生产声明承担；单笔共同分配由 `Allocation/Kernel` 与 `Split` 承担；一般全槽归档由 `Archive/Native/Complete`、`Primitive/Archives` 和 `Archive/Word` 承担。这些一般来源均位于已验收闭包。五份补充保留自己的阅读与文件身份，不补写新的执行回执。

## 再生本稿对应表

在论文仓内运行：

```sh
python3 papers/capital-formation/scripts/build_source_index.py \
  --homework-repository /path/to/Homework \
  --h0-repository /path/to/H0mework
```

加入 `--check` 可检查生成物是否与当前固定输入一致。脚本只读取Git对象和既有回执，输出本稿目录下的对应表、机器绑定与五份辅助文件。PDF与图件的构建入口见 [reading-guide.md](reading-guide.md)。

## English availability note

The research source is fixed at Homework commit **df421ff600085cbc290a7ae946193961bed7c83b**. Public proof materials are bound to [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045), commit **2d6fbc96e33b7c4c3cfd91104fda74e3caeda045**.

The source audit read 105 files in full and registered 675 declaration locations and 191 direct-import relationships. One hundred corresponding public modules belong to the already accepted SourceDF package's actual recursive import closure of 2825 modules. The binding verifies exact source aliases at the pinned epoch, source and target bytes, recursive import environments, and the existing claim map. Within those modules, 160 complete-type observations are indexed to the prior receipt, with exact qualified names, type hashes, kernel equivalence, and standard-axiom information. Source declaration locations and independently recorded type observations remain distinct.

The remaining five files are supporting examples, allocation lemmas, and archive counterexample consumers. Their unchanged fixed-commit bytes are included under `source-excerpts/`. The general producers used by the paper are present in the accepted package. Historical certifications retain their original scope. This writing task read and checked the existing evidence and produced the manuscripts and reading editions; it did not perform a new Lean run or scientific recalculation.

At the final revision, the observed H0mework main branch and local origin/main reference both pointed to **2e68d950eedda807acbedd443cfcd6a456b21218**. The proof files, export map, selection and acceptance receipts were unchanged from the pinned acceptance commit. The paper therefore retains its direct citation of **2d6fbc96e33b7c4c3cfd91104fda74e3caeda045**. A read-only check of both registered worktrees found no separate capital-paper export or acceptance entry. The existing SourceDF export and acceptance are complete; the paper reuses their verified scope, with the five supporting source files preserved separately. The deterministic source-binding check passed again.
