# 资本主义的结构总定理：编辑与维护说明（v2）

[中文正文](manuscript.md)、[英文正文](manuscript-en.md)、[中文技术附录](supplement.md)与[英文技术附录](supplement-en.md)共同承担 `capital-formation` 第二版（v2）大改定稿。精确命题与来源见 claims（仓库工作记录，不随本可编辑包提供），五轴文献核查见 [literature-v2.md](literature-v2.md)，全局排期见 roadmap（仓库全局排期，不随本单篇可编辑包提供）。首版 Zenodo 发布成品（DOI `10.5281/zenodo.23927949`：`build/capital-formation{,-en,-supplement,-supplement-en}.pdf`、`build/capital-formation-v1-editable.zip`、[references.bib](references.bib)、[zenodo-metadata.json](zenodo-metadata.json)、首版五组图 `figures/fig01..fig05`、[source-correspondence.md](source-correspondence.md)、`source-excerpts/*` 及首版 `records/*`）原字节完整保留。

## 稿件合同（v2）

- **结构与双语镜像**：中英文正文严格镜像 §1–§10（共 48 个编号章节）、**19 项编号结果**（定理 1–9、命题 10、定理 11–19，其中 18 条全称定理均配显式证明段落）、**2 则纸笔验算锚点**（例 1、例 2）、**28 个唯一 `\tag{...}` 公式标签**（`(1)`–`(28)`，共 32 个显示数学块）、**3 张结构对比表**（表 1 正反双向门禁表、表 2 六类资本形态与三类非资本负控 `6 + 3` 双向核验矩阵、表 3 五轴文献交锋表）、**6 幅双语 v2 矢量主图**与 **30 条参考文献**（35 处引用块）；中英文技术附录严格镜像附录 A–H、**39 个唯一 `\tag{...}` 公式标签**（`A1–A3`、`B1–B4`、`C1–C4`、`D1–D5`、`E1–E11`、`F1–F5`、`G1–G7`，共 42 个显示数学块）与表 H `S1–S17`（逐模块对应见 [source-correspondence-v2.md](source-correspondence-v2.md) 与 [cf17-source-binding.json](records/cf17-source-binding.json)）。
- **核心升级与增量**：
  1. **跨学科直觉入口、`6 + 3` 双向判别矩阵与快速验证架构**：在 §1.1 增设三分钟双人单机纸笔验算锚点（例 1，同时手算同长度无支配公共功能重放与零概率先验风险定价），在 §1.2 以表 1 将六分肢正向全称定理与可证伪反向负控一一配对，在 §1.3 增设政治经济学、企业与不完全契约理论、金融经济学、形式方法四条 15 分钟快速核验通道，并在 §4.1 以表 2 完整展示工业、照护、金融、平台、零雇佣自动化与技术升级型国家资本六类正例与共同合作生产、个人直兑公共信用、自主家计独立自给三类非资本负控（`controls = []`）的可判定核验矩阵。
  2. **同局部信号唯一最小必要风险补偿定理（`CF17`）与契约正交脱钩**：在 §7.5（定理 12、例 2、图 5）与附录 E.3（命题 E2、定理 E3、式 `E7–E11`、表 H 之 `S17`）完整合入固定源码 `7c228ac7fd77350d3fe761c24b887cbf2f6e5afc`（公开靶标 `H0mework.Papers.SocietyBookRiskCompensation`，独立 T1 回执 SHA-256 `50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`）的源内风险定价闭合——不引入任何主观先验概率、多先验集合、效用函数或贴现率，由零参数可执行非金融外部替代基准 $(a_P,a_B)$ 与同付费局部信号 $s_{\mathrm{loc}}$ 纤维上各报价分支完整收入 $(y_P,y_B)$ 导出双边安全闭区间 $[\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]$，证明向零投影 $q^*(s_{\mathrm{loc}})$ 的严格唯一绝对值最小性、提议金额四分互斥判决及两阶段零隐蔽头寸结算，阐明 $q=q^*(s_{\mathrm{loc}})+\lambda$ 如何将下行风险填平与事后合作剩余分配（对比 Nash／GHM 重谈）正交拆开，并以单物品日程消费者（`[4,8] -> q*=4`、`3/4/7/100` 四分）与双物品社会状态消费者（食物 `(1,1)`、结算材料 `(109,117)`、`[4,16] -> q*=4`）双线完成核验。因插入定理 12，首版定理 12–18 在第二版顺延为定理 13–19，并为定理 14、15 补齐正文显式证明段落。
  3. **五轴 30 篇原始文献正面对话**：由首版 18 篇扩充并逐篇核查至 30 篇原始文献（新增 Hohfeld 1913、Böhm 1928、Coase 1937、Hirschman 1970、Alchian & Demsetz 1972、Townsend 1979、Fama & Jensen 1983、Shavell 1986、Gilboa & Schmeidler 1989、Rajan & Zingales 1998、Ellerman 2014 及同系整账法前作 Gao 2026c），在各章证明现场与 §10.4 表 3 中逐轴完成定理级比较。
- **独立实质审读与源码回核闭环**：双语正文、附录、文献表与六组 v2 图件经独立审读子智能体逐式、逐数值交叉核查固定 Lean 源码，全部反馈均已核实吸收，包括：统一例 1、§6.1、例 2 与图 5 的库存坐标顺序 $(x_P,x_B)$ 并校核例 1(1) 五阶段七请求终点库存 $(99,109)$ 与例 1(2) $y_B=+1-1-1+10-1-1=+7$；严格区分空纤维 $\Omega(s_{\mathrm{loc}})=\emptyset$ 拒签与非空交叉区间 $\operatorname{lo}>\operatorname{hi}$ 无安全转移不可能定理；补齐 $q^*=0$ 空词分支、$q^*\ne 0$ 异主体及地址零原余额预检门禁、原矩阵复原与原生槽终结归档的区分，以及就绪可审查状态交付与无条件全尝试旧行单射承接的前提分账；分列单物品日程消费者与双物品社会状态消费者；统一局部信号记号 $s_{\mathrm{loc}}$ 以消除与运行状态 $s$ 的跨节撞车；去除中文“原根”数论歧义直译、附录长代码标识符断行与内部核查表元叙事括号；将 `EconomicConstitutionSourceDF`（`2d6fbc96e3`）与 `docs/capital-formation-map.json`（`7d15dbcaf5`）精确分绑；修正英文图 5 `Payer overcharge` 标签与嵌套下标排版。

## 验证与构建命令

在 `publish` 根目录执行双语一致性核验、图件重建与四份 v2 阅读版 PDF 构建：

```sh
python3 papers/capital-formation/scripts/check_manuscript.py
python3 papers/capital-formation/figures/make_figures_v2.py --check-only
python3 papers/capital-formation/scripts/build_reading.py \
  --output-dir papers/capital-formation/build/reading-review-v2
python3 papers/capital-formation/scripts/package_editable.py --edition v2
```
