# The Structural Theorem of Capitalism: Technical Supplement

## A Capital Evidence on a Single Execution

This supplement gives the formal object definitions, decisive proofs, and fixed-source correspondences underlying the main text. Let $I,G,P,T,F$ be types with decidable equality representing participants, goods, production ports, technologies, and financial instruments. A law $L$ specifies request validity, port access permissions, physical debit and credit effects, financial updates, and living and maintenance requirements. A state $s$ records physical stocks $x_s(i,g)$, the claim matrix $b_s(f,d,h)$, the active technology, the physical clock, and the round counter. The execution inventory of a finite request sequence $w$ under law $L$ from state $s$ is
\[
E_L(s,w)=\bigl[(j,s_j,r_j)\bigr]_{j<|w|}.
\tag{A1}
\]
Each entry retains its position index $j$, pre-request state $s_j$, and request $r_j$; rejected requests also occupy their own positions. Write $N_L(s,w)$ for the full successor state, including updated stocks, claims, technology, and clock. Occurrence addresses in single-period capital evidence point to positions in (A1); intertemporal evidence records both the historical visit index and the position within that visit.

### A.1 Provision for Needs and Private Access Asymmetry

Let $c_L(s,p)$ be the controller of port $p$ at the technology component of state $s$, and let $a_L(s,p,i)\in\{0,1\}$ be participant $i$'s Boolean access value. Private access asymmetry is defined by
\[
\operatorname{Private}_L(s,p,i)
\ \Longleftrightarrow\
a_L(s,p,c_L(s,p))=1\ \land\ a_L(s,p,i)=0.
\tag{A2}
\]
Condition (A2) captures asymmetry at the permission layer. For a relation to constitute capital, that permission asymmetry must also enter the participant's actual provision for living or maintenance needs and an economic return circuit.

An access candidate $A$ specifies an acquisition entry $e_a$, a need entry $e_n$, an affected person $i$, an acquired-good holder $h$, a production port $p$, an acquired good $g_a$, a needed good $g_n$, and a physical delivery route connecting them. The check $\operatorname{Check}_A(A)$ requires four conditions jointly:

1. $e_a$ is valid at its pre-request state, and port $p$ belongs to the ports actually required by $e_a$.
2. $\operatorname{Private}_L(-,p,i)$ holds both at the pre-request state of $e_a$ and in the full successor state $N_L(s,w)$.
3. $e_n$ is a valid living or maintenance use for $i$ with strictly positive quantity, and its bundle equals the exact living or mandatory-maintenance bundle specified by $L$ at that state.
4. Acquisition connects to need by one of two modes: **routed acquisition** requires $e_a$ to record a positive actual credit for $(h,g_a)$ and a chronological delivery route of accepted entries connecting that credit to $(i,g_n)$ at $e_n$; **direct use** requires $e_a$ and $e_n$ to share the same position, $h=i$, $g_a=g_n$, an empty route, and a corresponding positive actual debit.

Because routes are built exclusively from accepted entries in strict execution order, dependence retains the concrete person, good, and position of occurrence, and cannot be replaced by an abstract asset valuation. Proof declarations appear in S1 of Table H.

### A.2 Consideration, Return Flows, and Feasible Disposition

The reverse economic relation $R$ on the same execution inventory $E_L(s,w)$ has three exhaustive constructors:

| Return constructor | Exact check |
| --- | --- |
| Productive input | A valid production entry invokes port $p$ no later than $e_a$; a nonempty accepted route delivers $i$'s good into a positive input of the producer |
| Physical return | A nonempty accepted route delivers $i$'s good to the controller identified at $e_a$, completing within the same finite execution sequence |
| Financial claim | A valid issuance or assignment has strictly positive quantity with the controller as beneficiary; $i$ is the debtor upon issuance, or the debtor or assignor upon transfer |

A feasible-disposition candidate $D$ specifies an intermediate state reached in the execution together with a locally valid alternative request at that state. Signed by the right holder without requiring additional controller consent, this request may be an external or investment use by the holder, a positive physical transfer to the holder, or an assignment of a positive claim by the holder to another party. Holder identity may update along valid allocation chains in the same history, and private access asymmetry against $i$ must still hold at the disposition state.

Mutually indexed, the three legs form the capital-relation kernel type:
\[
C(L,s,w)=
\{(A,R,D):\operatorname{Check}_A(A)
\land\operatorname{Check}_R(A,R)
\land\operatorname{Check}_D(A,D)\}.
\tag{A3}
\]
Here $A$ and $R$ record executed provision and return flows, whereas $D$ checks an independently exercisable power of control at a reached state. An unpaid positive debt suffices for the financial leg; accounting profit, reserve growth, and subsequent trial success are not prerequisites of (A3) (see S1).

### A.3 Transferable Asset Titles, Actual Surplus, and Intertemporal Lineage

**Transferable asset control** augments $C$ with evidence of controller replacement at the same port: an executed or locally feasible valid rights-change request replaces controller $h$ with $h'\ne h$ such that $h$ was previously admitted and is subsequently excluded while $h'$ becomes admitted. Fixed bodily permissions inseparable from a person fail controller replaceability and are never conflated with alienable capital titles.

**Actual surplus appropriation** augments $C$ with executed appropriation evidence across five exhaustive modes: consumption, investment, retention at the terminal state, routed consumption, and financial return. Consumption and investment identify actual physical debits; retention jointly checks acquisition, subsequent debits, and positive terminal stock; financial return aligns with the exact issuance origin address of the claim in $C$. Unexercised quotes and book revaluations do not constitute actual appropriation.

**Intertemporal capital and present historical control** embed access, need, return, and disposition addresses in a multi-visit history. Title quotes, retention, consumption, or investment evidence may span distinct visits provided the terminal state still exhibits controller admission and participant exclusion. Exercising historical capital as present control ($\operatorname{ControlUse}$) additionally requires the current request to be valid, to invoke the port, and to exclude a current physical beneficiary, producer, need bearer, or financial bearer. Subject and relation birth records are uniquely generated at initial admission and preserved across every successor; replacing an asset holder preserves the relation's origin, and visit-indexed filtering prevents old admissions from being double-counted as fresh cycles (S2).

## B Minimal Support, Complete Reconstruction, and Universal Scope

### B.1 Two-Way Proof of the Five-Face Equivalence

For any law $L$, define absence of port-permission asymmetry by
\[
\operatorname{NoAsymmetry}(L)
\Longleftrightarrow
\forall s,p,i,\ 
a_L(s,p,c_L(s,p))=1\Rightarrow a_L(s,p,i)=1.
\tag{B1}
\]
Complete absence of capital $\operatorname{NoCapital}(L)$ jointly excludes five witness layers: (1) private access asymmetry, (2) capital-relation kernels, (3) transferable capital asset titles, (4) all five modes of actual surplus appropriation, and (5) newly occurring present historical control under the active law.

**Proposition B1.** For any permission law $L$ over the specified object types with decidable equality,
\[
\operatorname{NoCapital}(L)\Longleftrightarrow
\operatorname{NoAsymmetry}(L).
\tag{B2}
\]

**Proof.** Suppose $\operatorname{NoCapital}(L)$ holds. Its first component excludes (A2) for every $(s,p,i)$. Fix $(s,p,i)$ with $a_L(s,p,c_L(s,p))=1$; if $a_L(s,p,i)=0$, then (A2) holds immediately, a contradiction. Since access takes values in $\{0,1\}$, $a_L(s,p,i)=1$, establishing (B1).

Conversely, suppose (B1) holds. Then $a_L(s,p,c_L(s,p))=1\land a_L(s,p,i)=0$ holds for no $(s,p,i)$, ruling out all private access asymmetries. Every capital kernel $C=(A,R,D)$ carries (A2) inside $\operatorname{Check}_A(A)$, so the kernel type is empty. Every transferable capital asset title and every actual surplus witness carries an underlying capital kernel, so both types are empty. Present historical control likewise requires (A2) against a current affected person, and is therefore empty. All five exclusions hold jointly. □

Non-vacuous sharpness of minimal support is established by the material-complete four-cell permission family: holding stocks, needs, production instructions, and financial entries fixed while varying only the controller's and affected person's Boolean access values, a capital kernel exists for every clock and round if and only if the controller is admitted ($1$) and the affected person refused ($0$). At clock zero and round zero, opening the affected person's access also preserves every execution entry and the full successor state identically (S3).

### B.2 Exact Recompilation and Self-Reconstruction Across All Constructors

The compiler checks access, return flow, and feasible disposition in order: if all three hold, it returns a capital kernel preserving the input proposal; otherwise it returns the first failing check. Hence for every kernel proposal $q$,
\[
\begin{aligned}
&\left(\exists c,\ \operatorname{compile}(q)=\operatorname{some}(c)
\land c.\operatorname{proposal}=q\right)\\
&\qquad\lor\neg\operatorname{Check}_A(q)
\lor\neg\operatorname{Check}_R(q)
\lor\neg\operatorname{Check}_D(q).
\end{aligned}
\tag{B3}
\]
Because the three return-flow constructors exhaust the sum type, (B3) covers the entire input space. Actual surplus appropriation and intertemporal capital satisfy isomorphic total-compilation disjunctions.

**Proposition B2.** Every established sealed capital witness $c$ is reconstructed as itself from its own stored proposal fields:
\[
\operatorname{compile}(c.\operatorname{proposal})
=\operatorname{some}(c),
\tag{B4}
\]
with corresponding self-reconstruction identities for all five modes of actual surplus and all four modes of intertemporal capital.

**Proof.** Destructuring the sealed witness $c$ yields its proposal fields together with proofs that all checks hold. Evaluating the deterministic function $\operatorname{compile}$ on those fields takes the true branch at each guard and reassembles $c$ identically without external witness selection. Controlled contribution-reproduction witnesses likewise unpack directly into gated port needs and return flows on the same execution. The unified control family further proves that title discovery, surplus discovery, or historical discovery on an item together with private access asymmetry (or fresh historical control) is equivalent to family membership, while active $\operatorname{ControlUse}$ adds request validity and actual port invocation (S3, S4). □

## C Social Admission and Finite-Step Disposition of Any Capital Relation

### C.1 Self-Proved Positive Registration from Capital Evidence

An institutional programme source $X$ packages a law, an initial state, and either a static instruction list or a dynamic emitter; write $r(X)$ for its registration size and $w_X(s)$ for the sequence emitted at state $s$.

**Proposition C1.** For every programme source $X$, state $s$, and capital kernel witness
\[
c:C(X.L,s,w_X(s)),
\]
one has $r(X)>0$, which directly generates the complete social capital disposition contract; the same holds for any active control-use witness.

**Proof.** When $X$ uses a dynamic emitter, its registration rule yields $r(X)>0$ directly. When $X$ uses a static instruction list, $r(X)$ equals the list length. If that length were zero, both $w_X(s)$ and $E_{X.L}(s,w_X(s))$ would be empty, contradicting the acquisition entry address inside $c$'s access evidence $A$. Thus $r(X)>0$ is proved from $c$ itself without assuming external registration in the hypothesis; six concrete capital forms (industrial, care, financial, platform, zero-wage automated, and upgrading state capital) enter the unified social contract by this route, whereas cooperative production, redeemable public credit, and autonomous household self-supply are verified by decidable computation to carry empty control lists (S5). □

### C.2 Exact Financial-Boundary Dispatch

At initial social admission, the boundary check compares the source's initial claim matrix against the genesis slot-account matrix:
\[
B_X=\operatorname{claims}(X.\operatorname{initial}),
\qquad B_{\mathrm{native}}(X).
\tag{C1}
\]
The genesis account satisfies $B_{\mathrm{native}}(X)=0$. When $B_X=B_{\mathrm{native}}(X)$, the source enters the per-step termination, public replacement, initial selection, renewal, and future-expansion contract with zero unrepresented initial debt, while all debts issued later in the run are tracked slot by slot. When they differ, the procedure returns an exact discrepancy coordinate
\[
\exists f,d,h,\quad B_X(f,d,h)\ne B_{\mathrm{native}}(X)(f,d,h),
\tag{C2}
\]
retaining the full input source, social law, and actual runtime successor so existing liabilities cannot be erased by initializing an empty account (S5).

### C.3 Internal Workload Bound and the Three-Part Abolition Audit

Let $z_t$ denote the actual run state and $T$ the deterministic single-step successor. The pending internal workload $m(z_t)\in\mathbb N$ counts remaining items in the internal processing queue. Each internal step strictly decreases $m$ by one, reaching the institutional review boundary in at most $m(z_t)$ steps; boundary selection uses at most one further step to produce either a public state or a named initial review obstruction. Hence for every cut $z_t$,
\[
\exists k\le m(z_t)+1,\quad
\operatorname{CompleteDisposition}(z_{t+k}).
\tag{C3}
\]

Before public execution is entered, complete disposition retains the exact initial replacement-review obstruction together with all existing responsibility rows and unspent budgets. Once in public mode, the audit checks three components sequentially:

| Audit component | Success condition | Object retained upon failure |
| --- | --- | --- |
| Full-account audit | Complete net change $\Delta_{i,g}\ge 0$ for every person and good, with at least one cell strictly positive | Exact failing financial condition on the same current full account |
| Member migration | First public execution is valid and independent, pays all entering members' needs, preserves productive capacity, and adds zero control | Exact migration shortfall on that first public execution and roster |
| Executable future | Adaptive compilation from the current snapshot yields a valid continuation paying all current members' needs | Specific check failures across the generated candidate set |

The full-account audit fixes the common starting state at public entry and runs the pre-transition source under its original law for the same number of rounds, reading its own state at each round. With terminal stocks $S^{\mathrm{pub}},S^{\mathrm{base}}$, claim difference $\Delta F=F^{\mathrm{pub}}-F^{\mathrm{base}}$, and settlement good and positive rate $(u_j,r_j)$ for instrument $j$, claim valuation at $(i,g)$ is
\[
V_L(\Delta F)_{i,g}
=\sum_{j,d,h}\Delta F(j,d,h)r_j\,
\mathbf{1}_{\{g=u_j\}}
\bigl(\mathbf{1}_{\{i=h\}}-\mathbf{1}_{\{i=d\}}\bigr),
\]
summed over the finite support generated by actual financial entries on both branches. Merging $\Delta_{i,g}=(S^{\mathrm{pub}}-S^{\mathrm{base}})_{i,g}+V_L(\Delta F)_{i,g}$ ensures that cash paid to retire principal cancels the matching debt reduction at the settlement coordinate, neither penalizing debt repayment nor mistaking fresh borrowing for net gain. The check verifies positive settlement rates on the difference support, positive elapsed window, and matching terminal clocks. Any path satisfying $y_0=z_t$ and $y_{n+1}=T(y_n)$ satisfies $y_n=T^n(z_t)=z_{t+n}$ by induction and therefore reaches the identical disposition at step $k$ (S6).

### C.4 Ruling Out Obstruction-Free Recurrent-Control Absorption Paths

An obstruction-free absorption path of recurrent control along $T$ would have to satisfy jointly
\[
\forall n,\ \exists m\ge n:\operatorname{FreshControl}(z_m),
\qquad
\forall n,\ \operatorname{ReviewClosed}(z_n),
\tag{C4}
\]
where the first clause asserts fresh capital control in every tail and the second asserts no unresolved initial replacement-review obstruction at any pre-public boundary. Applying (C3) yields $z_{t+k}$: an initial review obstruction directly contradicts $\operatorname{ReviewClosed}$, whereas entering public mode triggers runtime persistence—every subsequent step retains the open-port interpreter and therefore excludes any fresh capital kernel or active control use across the entire tail, contradicting tail recurrence. Both cases fail, ruling out (C4) while preserving all prior claims and history prefixes (S6).

## D General Public Functional Replay and Actual Selection

### D.1 Position-Wise Request Transformation and State Identity

Let the open interpretation $L^\circ$ (written $L^{\mathrm{pub}}$ in the main text) retain all physical debit/credit rules, financial settlement rules, technology recipes, need bundles, and clock durations of $L$, while opening port permissions and setting the operational policy to unrestricted. For any state $s$ and request $r$, define
\[
\rho_L(s,r)=
\begin{cases}
\text{open request keeping operation and signer (empty consents)},&
\operatorname{Valid}_L(s,r),\\
\text{zero-effect presentation keeping signer and purpose},&
\neg\operatorname{Valid}_L(s,r).
\end{cases}
\tag{D1}
\]
Extend $\rho_L$ recursively along the single-step transition $\operatorname{step}_L$:
\[
\begin{aligned}
\mathcal R_L(s,[])&=[],\\
\mathcal R_L(s,r::w)&=
\rho_L(s,r)::\mathcal R_L(\operatorname{step}_L(s,r),w).
\end{aligned}
\tag{D2}
\]
When $r$ is valid under $L$, clearing controller consents under open ports preserves validity and produces identical physical and financial effects; when $r$ is rejected under $L$, neither $r$ nor the zero-effect presentation alters the state or records physical entries. Thus every single step satisfies
\[
\operatorname{step}_{L^\circ}(s,\rho_L(s,r))
=\operatorname{step}_L(s,r).
\tag{D3}
\]

**Proposition D1.** For every law $L$, state $s$, and finite word $w$, public replay preserves word length, the full successor state, and exact item-by-item inventory correspondence:
\[
\begin{aligned}
|\mathcal R_L(s,w)|&=|w|,\\
N_{L^\circ}(s,\mathcal R_L(s,w))&=N_L(s,w),\\
E_{L^\circ}(s,\mathcal R_L(s,w))&=
\operatorname{map}(\widehat\rho_L,E_L(s,w)),
\end{aligned}
\tag{D4}
\]
where $\widehat\rho_L(j,s_j,r_j)=(j,s_j,\rho_L(s_j,r_j))$.

**Proof.** Structural induction on $w$: the empty word is immediate; for $r::w$, (D3) identifies the intermediate states after the head request, the induction hypothesis identifies length, successor state, and inventory tail, and equal word lengths induce identical period-end clock and round updates. □

### D.2 Bidirectional Preservation of Needs Payment and Service Adequacy

For every membership roster $M$, full living and maintenance payment satisfies
\[
\operatorname{AllNeedsPaid}_{L^\circ}
(s,M,\mathcal R_L(s,w))
\Longleftrightarrow
\operatorname{AllNeedsPaid}_L(s,M,w).
\tag{D5}
\]
Any accepted use entry in $w$ retains its user, bundle, and purpose under $\rho_L$; conversely, a valid use entry in $\mathcal R_L(s,w)$ cannot arise from a zero-effect presentation and therefore identifies an accepted use entry at the same index in $w$. Conjoining across living and maintenance bundles for every member in $M$ yields (D5). Task service adequacy (specified user, bundle, purpose, and time window) follows identically using terminal-clock equality from (D4), while open port permissions eliminate private access asymmetry and any capital kernel (S7).

### D.3 From Functional Existence to Actual Selection and Renewal

When the candidate set contains a public plan passing both full-account improvement and post-execution future feasibility, the initial selector adopts that plan and produces a complete abolition witness at the first public snapshot. In public mode, whenever pending internal work is zero and the automatic proposal is an advance, any renewal candidate passing complete improvement and post-execution feasibility is uniquely selected and executed, generating a fresh abolition witness at the successor snapshot (S6).

## E Ex-Ante Innovation, Origin Receipt Bounds, and Source-Native Risk Pricing

### E.1 Fixed Mechanisms, Off-Menu Two-Round Discovery, and the Renewal Gate

A trial mechanism $M$ fixes its law, local programme, signed financing word, investment request, observation fee, local policy, and closing actions prior to receiving an unknown event $\nu\in\operatorname{Nature}(M)$. While the quotation menu reads a finite event syntax $\operatorname{QuotedNature}(M)$, mechanism disposition covers the entire request type:
\[
\forall M\ \forall\nu\in\operatorname{Nature}(M),\quad
\operatorname{Disposition}(M,\nu).
\tag{E1}
\]
Under the declared-weight participation interface, normalized nonnegative weights with success weight $p>0$, weighted failure loss $\ell$, outside option $a$, and loading $b\ge 0$ satisfy
\[
r=\frac{\ell+a+b}{p},\qquad
\mathbb E_{\mathrm{declared}}[\Delta]=a+b.
\tag{E2}
\]
Equation (E2) records arithmetic participation under declared weights, whereas endogenous authority to write necessary risk compensation without exogenous $(p,a,b)$ is established in Section E.3 below.

The constructive two-round instance executes real material disbursement, physical investment $3$, message-resource expenditure $3$ (including paid observation debit $1$), and full living and maintenance payment in each round, advancing technology from $0$ to $1$ to $2$: Round 2 starts with zero prototype stock, discovery $2$ belongs to neither round's quotation menu, and balance $1$ at debt address $(\text{instrument},0,2)$ persists throughout. The release gate `paidNextTrial?` checks every member's living and maintenance payment in the current period before releasing the next trial, rejecting an instance whose future proposal is payable while current needs remain unpaid (S8).

### E.2 Slot Conservation and the Cumulative Bound Across All Slots of an Origin

Let $P_j(q)\ge 0$ denote remaining principal in slot $j$ at account state $q$. Along any finite financial run $\gamma:q_0\leadsto q_1$, define cumulative principal retired in slot $j$ by
\[
R_j(\gamma)=\sum_{e\in\gamma}
\mathbf1_{\{\operatorname{slot}(e)=j\}}\,
\operatorname{actualPaid}(e).
\tag{E3}
\]
Assignments reallocate holders without retiring principal, fresh issuances open distinct slots, waiting retires zero principal, and archived slots have an empty reopening event type.

**Proposition E1.** For every slot $j$ present at starting state $q_0$,
\[
P_j(q_1)+R_j(\gamma)=P_j(q_0).
\tag{E4}
\]

Fixing an issuance origin $o$ registered at $q_0$ with issued quantity $Q_o$, aggregate actual principal retirement across all terminal slots carrying origin $o$:
\[
R_o(\gamma)
=\sum_{\substack{j<|\operatorname{slots}(q_1)|\\
\operatorname{origin}(q_1,j)=o}}R_j(\gamma).
\tag{E5}
\]
Strict ordering of occurrence addresses together with disjoint origin tags across static registration, actual ingress, and public continuation ensures that at most one terminal slot carries origin $o$, and account transport preserves tags without re-issuance. Reducing (E5) to (E4) and applying $P_j(q_1)\ge 0$ and $P_j(q_0)\le Q_o$ gives
\[
\boxed{R_o(\gamma)\le Q_o.}
\tag{E6}
\]
Choosing $q_0$ immediately after admission yields the cumulative bound from issuance, ruling out payment of any unbounded demand sequence $d_n>Q_o$ from suffixes of a single past contribution while keeping separate origins for fresh labor, discoveries, and risk undertakings (S9).

### E.3 Bilateral Safe Intervals, Unique Minimal Payment, and Four-Way Admission (CF17)

This subsection gives the complete mathematical construction and proof of Theorem 12 (`CF17` in Section 7.5 of the main text); fixed-source declarations appear in S17 of Table H.

**Layer 1: Parameter-free executable outside baselines.** Before the unknown event arrives, ex-ante preparation rebinds the proposed mechanism to the active law, current stocks, and complete member census at the current cut, ignoring any packaged initial state or permission interpreter inside the proposal. Within the source action alphabet and step budget $B\in\mathbb N$, a finite word $u$ passes outside-baseline verification if and only if: (1) every request is valid; (2) all members' living and maintenance needs are paid; (3) execution is independent and preserves productive capacity; (4) no new control arises; and (5) $u$ is non-financial, preserving the entire claim matrix. The candidate set is nonempty if and only if a real adequate alternative exists, in which case the provider's ($P$, lender) and payer's ($B$, borrower) outside baselines $a_P,a_B\in\mathbb Q$ at the instrument's settlement good equal the exact maximum complete incomes (proved equal to computable complete income) attained by executable witness words. In the single-good schedule of Example 2, upkeep uses $1$ per participant and the executable alternatives give $a_P=a_B=-1$. If no feasible word fits the budget, the procedure reports an obstruction for each candidate.

**Layer 2: Bilateral safe envelope on a paid local-signal fiber.** For a paid local signal $s_{\mathrm{loc}}$, let the signal fiber of quoted events be
\[
\Omega(s_{\mathrm{loc}})
=\bigl\{\omega\in\operatorname{QuotedNature}(M):
\operatorname{paidSignal}(\omega)=\operatorname{some}(s_{\mathrm{loc}})\bigr\}.
\]
For each branch $\omega\in\Omega(s_{\mathrm{loc}})$, let $y_P(\omega),y_B(\omega)\in\mathbb Q$ be the complete branch incomes (combining physical stocks and financial claims so unreturned loans never masquerade as net income) after the trial body. On a single branch, a transfer $q\in\mathbb Q$ preserves both outside baselines if and only if $a_P\le y_P(\omega)+q$ and $a_B\le y_B(\omega)-q$, i.e., $a_P-y_P(\omega)\le q\le y_B(\omega)-a_B$. By list induction over a nonempty fiber $\Omega(s_{\mathrm{loc}})\ne\emptyset$:
\[
\Bigl(\forall\omega\in\Omega(s_{\mathrm{loc}}),\ 
a_P\le y_P(\omega)+q\ \land\ a_B\le y_B(\omega)-q\Bigr)
\Longleftrightarrow
\operatorname{lo}(s_{\mathrm{loc}})\le q\le\operatorname{hi}(s_{\mathrm{loc}}),
\tag{E7}
\]
with worst-branch endpoints
\[
\operatorname{lo}(s_{\mathrm{loc}})
:=\max_{\omega\in\Omega(s_{\mathrm{loc}})}\bigl(a_P-y_P(\omega)\bigr),
\qquad
\operatorname{hi}(s_{\mathrm{loc}})
:=\min_{\omega\in\Omega(s_{\mathrm{loc}})}\bigl(y_B(\omega)-a_B\bigr).
\tag{E8}
\]
If $\Omega(s_{\mathrm{loc}})=\emptyset$, no quoted branch supports pricing on that signal and quotation is refused as an empty fiber; if $\Omega(s_{\mathrm{loc}})\ne\emptyset$ and $\operatorname{lo}(s_{\mathrm{loc}})>\operatorname{hi}(s_{\mathrm{loc}})$, transitivity on the nonempty fiber proves that no rational transfer $q$ can jointly protect both baselines across $\Omega(s_{\mathrm{loc}})$, refusing quotation as incompatible. Because quotation is fixed before unknown events arrive, any two branches $\omega_1,\omega_2$ sharing the same paid local signal receive the exact same quote (S17).

**Proposition E2 (Unique minimal absolute payment and baseline binding).** Whenever $\operatorname{lo}\le\operatorname{hi}$, define the canonical risk transfer
\[
q^*(\operatorname{lo},\operatorname{hi})
:=
\begin{cases}
\operatorname{lo}, & \operatorname{lo}>0,\\
\operatorname{hi}, & \operatorname{hi}<0,\\
0, & \operatorname{lo}\le 0\le\operatorname{hi}.
\end{cases}
\tag{E9}
\]
Then $q^*(\operatorname{lo},\operatorname{hi})\in[\operatorname{lo},\operatorname{hi}]$, and every safe transfer $q\in[\operatorname{lo},\operatorname{hi}]$ with $q\ne q^*(\operatorname{lo},\operatorname{hi})$ satisfies the strict inequality $|q^*(\operatorname{lo},\operatorname{hi})|<|q|$. If the endpoints come from (E8) and $q^*\ne 0$, there is a quoted branch $\omega$ on which $y_P(\omega)+q^*=a_P$ or $y_B(\omega)-q^*=a_B$. Adding any nonzero difference $\lambda\ne 0$ to $q^*$ exits the safe interval or strictly increases absolute payment.

**Proof.** Split into three mutually exclusive cases: (1) if $\operatorname{lo}>0$, then $q^*=\operatorname{lo}$, and any $q\in[\operatorname{lo},\operatorname{hi}]$ with $q\ne\operatorname{lo}$ satisfies $0<\operatorname{lo}<q$, so $|q^*|=\operatorname{lo}<q=|q|$; (2) if $\operatorname{lo}\le 0$ and $\operatorname{hi}<0$, then $q^*=\operatorname{hi}<0$, and any $q\in[\operatorname{lo},\operatorname{hi}]$ with $q\ne\operatorname{hi}$ satisfies $q<\operatorname{hi}<0$, so $|q^*|=-\operatorname{hi}<-q=|q|$; (3) if $\operatorname{lo}\le 0\le\operatorname{hi}$, then $q^*=0$ and $|q^*|=0<|q|$ for every $q\ne 0$. When $q^*\ne 0$, case (3) is impossible. The quoted branches form a finite nonempty set, so some branch attains the maximum in case (1) or the minimum in case (2). This gives equality at the provider's or payer's baseline, respectively. For any $\lambda\ne 0$, $q^*+\lambda\ne q^*$, so if $q^*+\lambda\in[\operatorname{lo},\operatorname{hi}]$ then $|q^*|<|q^*+\lambda|$ by strict uniqueness, and otherwise interval feasibility fails. □

**Theorem E3 (Four-way amount partition, zero hidden claim residual, and two-phase ledger closure).** On any compatible interval $\operatorname{lo}(s_{\mathrm{loc}})\le\operatorname{hi}(s_{\mathrm{loc}})$, every proposed rational $q\in\mathbb Q$ falls into one of four mutually exclusive source dispositions:
\[
\bigl(q=q^*\bigr)
\ \lor\ 
\bigl(\operatorname{lo}\le q\le\operatorname{hi}\land |q^*|<|q|\bigr)
\ \lor\ 
\bigl(q<\operatorname{lo}\bigr)
\ \lor\ 
\bigl(q>\operatorname{hi}\bigr),
\tag{E10}
\]
corresponding respectively to **necessary risk compensation**, **independent surplus distribution**, **provider shortfall**, and **payer overcharge**. When $q^*=0$, the necessary-risk channel executes an empty zero-request word; when $q^*\ne 0$, preflight verification enforces distinct borrower and lender and zero pre-settlement balance at that instrument–debtor–creditor address after the trial body, issuing a signed native claim of size $|q^*|/r_{\mathrm{inst}}$ (for settlement rate $r_{\mathrm{inst}}>0$) and executing real settlement only for $q=q^*$, whereas the other three branches, together with unpriced events, unpaid observations, empty fibers, and crossed bounds, send zero risk-compensation requests. Issuing and settling $q^*$ restores the entire claim matrix identically (distinct from native-slot terminal archival in Section G.1):
\[
\operatorname{claims}\bigl(\operatorname{final}(w_{\mathrm{body}}\mathbin{+\!\!+}w_{\mathrm{price}}(q^*))\bigr)
=
\operatorname{claims}\bigl(\operatorname{after}(w_{\mathrm{body}})\bigr).
\tag{E11}
\]
On ready, reviewable social states and preflight-approved quoted events, two-phase execution preserves both real outside benchmarks across all participant–good coordinates and pays every member's living and maintenance needs, while every attempt—obstructed, refused, or completed—unconditionally transports all legacy responsibility rows injectively without budget refill. Two verified consumers instantiate the theorem: the single-good schedule consumer at $(x_P,x_B)=(100,100)$ with $a_P=a_B=-1$ computes $y_P\in\{-3,-5\}$, $y_B=7$, safe interval $[4,8]$, $q^*(s_0)=4$, post-settlement stocks $(x_P,x_B)=(101,103)$ and $(99,103)$, four-way classification of $3,4,7,100$, and rejection of unquoted loss $3$; the two-good social-state consumer with food $(1,1)$ (baseline change $-1$) and settlement material $(x_P,x_B)=(109,117)$ (baseline change $0$, output $18$) computes $(-2,16)$ and $(-4,16)$, safe interval $[4,16]$, and the same $q^*(s_0)=4$, delivering payment across two phases while carrying all prior responsibility rows injectively (S17).

## F Complete Responsibility and Dynamic Continuation

### F.1 Physical and Financial Conservation Identities

For every finite prefix of an actual programme, each participant $i$ and good $g$ satisfy
\[
x_{\mathrm{after}}(i,g)+D(i,g)
=x_{\mathrm{before}}(i,g)+K(i,g),
\tag{F1}
\]
where $D,K$ sum actual debits and credits across the execution inventory, and each instrument $f$, debtor $d$, and holder $h$ satisfy
\[
b_{\mathrm{after}}(f,d,h)
=b_{\mathrm{before}}(f,d,h)+\Delta b_E(f,d,h).
\tag{F2}
\]
Every strictly positive net stock gain identifies an accepted positive-credit entry in the same inventory; issuing a financial claim never creates physical stock (S10). Complete income decomposes into net production (net of input, use, and revision costs), open transfers, signed net control transfers at identified controller addresses, and valuation changes, with cash settlement cancelling principal retirement at the settlement coordinate (S11).

### F.2 Net Productive Blockage and Single-Stock Non-Duplicate Allocation

Net productive blockage compares open and controlled executions from the same starting stocks, financing, investment, local policy, and adaptive historical response rule:
\[
q(i,g)=
\max\{0,\operatorname{productiveOpen}(i,g)
-\operatorname{productiveControlled}(i,g)\}.
\tag{F3}
\]
Productive-harm repair $P$ uses the positive matrix (F3); controlled-return restitution $G$ aggregates non-consensual controlled physical returns bearing private access asymmetry (strictly excluding signed gifts and public repair). Sharing one stock state and one execution, allocable receipts reserve stock for $P$ first and grant $G$ only the remainder, barring one unit of stock from paying two liabilities. Each consecutively admitted renewal input must pass across the whole word, pay all members' needs, and clear at least one positive residual cell, so the positive residual count $B$ satisfies
\[
n+B(z_n)\le B(z_0),
\tag{F4}
\]
bounding renewals of any outstanding responsibility (S11).

### F.3 All-Coalition Zero-Extraction Bound, Institutional Transport, and Emitted Limits

For every Boolean coalition $S$ and good $g$, any finite chain of open mechanisms authorized by an already settled repair row (rebinding initial state and active law to the current cut at each step without external stock injection) satisfies
\[
\operatorname{Income}_{S,g}
+\operatorname{Consumed}_{S,g}=0,\qquad
\operatorname{Income}_{S,g}\le0,
\tag{F5}
\]
authorizing zero positive net extraction while allowing basic living consumption and independent new income sources. Finite institutional histories transport all existing rows injectively (without assuming a finite prior ledger), preserving nonincreasing budgets, zero-paid rows, and (F1)–(F2); under an active public interpreter, any purported fresh capital witness locates an exact permission discrepancy where the claimed law denies an affected party whom the active interpreter admits. For a cofinal confluence event already emitted by its source, each nonincreasing natural-number row budget attains its minimum at an occurred cut, and the event's registration procedure either constructs the compatible carrying row and first write or returns an explicit lineage conflict (S11, S12).

## G Clearing Cost: Attainment and Constructive Strict Improvement

### G.1 Cost Minimizer for a Funded Financial Tail

For nonnegative weights on real resource channels and elapsed clock time, let
\[
K_\lambda(w)=
\sum_{e\in E(w)}\sum_{\chi,i,g}
\lambda_{\chi,i,g}\,d_\chi(e;i,g)
+\lambda_t\,\Delta t,\qquad \lambda_{\chi,i,g},\lambda_t\ge0,
\tag{G1}
\]
excluding principal transfers from resource destruction. At any ready cut with sufficient settlement stocks, the account-generated clearing word $w_*$ performs only slot settlements and formal archival (including zero-amount settlement on live zero-balance slots), incurring zero extra resource use and zero elapsed time. Hence $K_\lambda(w_*)\le K_\lambda(w)$ for every finite admissible policy $w$ and nonnegative readout $K_\lambda$ after the same incurred prefix, while preserving terminal archives and the live successor (S13).

### G.2 Discrete Productive Complete-Clearing Family

In the two-party, two-good ($g_0$ settlement/life, $g_1$ production/maintenance) complete-clearing source, the common occurred prefix $h$ issues debt $1$, transfers $1$ unit of $g_0$, and consumes $1$ life unit and $1$ maintenance unit at prefix cost $2$, leaving zero $g_0$ stock, unpaid debt $1$, and $5$ units of $g_1$. Technology $n\in\mathbb N$ uses input $\varepsilon_n=1/(n+2)$ plus maintenance $1$ to produce $1$ unit of $g_0$, with zero revision cost, zero microstep duration, and unit weights. Every candidate suffix
\[
w_n=[\,\operatorname{revise}(n),\
\operatorname{produce},\
\operatorname{settle}(1)\,]
\tag{G2}
\]
is affordable ($\varepsilon_n\le 1/2$), clears all principal, archives the debt slot across the six-step underlying state-resolution cycle, and generates the next inquiry, with tail and full-history costs
\[
K_{\mathrm{tail}}(w_n)=1+\varepsilon_n,\qquad
K_{\mathrm{full}}(w_n)=3+\varepsilon_n.
\tag{G3}
\]

### G.3 Constructive Strict Improvement for Any Completing Candidate

Let $v$ be any finite programme in this source that clears the entire claim matrix, with tail cost $c(v)$.

1. **Strict lower bound $c(v)>1$.** Without an accepted production entry, every nonproduction operation preserves zero $g_0$ stock and keeps total debt at least $1$. Hence $v$ contains at least one accepted production entry paying maintenance $1$ plus positive input $\varepsilon_m>0$, giving
\[
c(v)>1.
\tag{G4}
\]
2. **Constructive replacement from $v$'s own cost gap.** Set
\[
\delta=c(v)-1>0,\qquad
n(v)=\left\lceil\frac1\delta\right\rceil.
\tag{G5}
\]
Since $1/\delta\le n(v)<n(v)+2$, one has
\[
\varepsilon_{n(v)}=\frac1{n(v)+2}<\delta,
\tag{G6}
\]
yielding a strictly cheaper complete clearing from the same occurred prefix $h$:
\[
2+c(w_{n(v)})=3+\varepsilon_{n(v)}
<2+c(v).
\tag{G7}
\]
3. **Unattained infimum $3$.** Any purported least-cost completion $v$ is strictly improved by $w_{n(v)}$, a contradiction, while $n=\lceil 1/\eta\rceil$ places full cost in $(3,3+\eta)$ for every $\eta>0$ (S14–S16).

## H Declarations, Inheritance Chain, and Fixed Sources

Results 1–11 and 13–19 (CF0–CF16) use H0mework's [fixed proof snapshot](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) for `EconomicConstitutionSourceDF` and the [first-edition claim map](https://github.com/Sapientropic/H0mework/blob/7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6/docs/capital-formation-map.json). Theorem 12, Example 2, and Section E.3 (CF17) use H0mework's [fixed proof snapshot](https://github.com/Sapientropic/H0mework/tree/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e) for `SocietyBookRiskCompensation`, with the [CF17 declarations and direct consumers](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/checks/society-book-map.json) and [reproduction guide](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/docs/society-book-reproduction.md). Table H identifies the declarations for both sets.

Short paths below lie under $\texttt{Lean/SaturationMonoid/ProcessGame/Society/}$ followed by $\texttt{Institutions/Capitalism/}$:

- **U**: \(\texttt{Universal/Source/ProgrammeControl/}\)
- **A**: \(\texttt{Universal/Abolition/}\)
- **C**: \(\texttt{Accounting/Quantifiers/Assembly/Strengthening/Characterization/}\) under A
- **O**: \(\texttt{Accounting/Quantifiers/Assembly/Strengthening/Optimality/}\) under A
- **P**: \(\texttt{Innovation/Contribution/Pricing/}\) under A (pinned commit `7c228ac7fd`)

| ID | Definitions, decisive proofs, and direct consumers |
| --- | --- |
| S1 | U: Kernel/Access, Reciprocity, Disposal, Core. Gated needs, three return constructors, and feasible disposal form $C=(A,R,D)$. |
| S2 | U: Kernel/AssetAuthority/ProperKernel, Transfer; Kernel/ActualSurplus/Core; History/Core, Family, Binding. |
| S3 | C: Support/Law; Models/Permissions/Classification. Five-face equivalence and four-cell actual permission family. |
| S4 | C: Support/Local, History, Exact; Models/Reconstruction/Kernel, Surplus, History. Total recompilation and self-reconstruction. |
| S5 | A: Completion/Actual/External/Admission, ClaimsReceipt/Actual; Assembly/Society; Consumers/Forms (six concrete capital forms and three non-capital negative controls). |
| S6 | A: Completion/Actual/Finite/Resolution; Assembly/Disposition, Consumer, Control, Current; Capital/Runtime. |
| S7 | A: Functions/Replay/Request, Trace, Effects, Services, Public; Completion/Actual/Assembly/Functions. |
| S8 | A: Innovation/Completion/SourceLaw, Society, Assembly; Trials/Consumers/Renewal, RenewalGate; Trials/Source/Renewal/Decision. |
| S9 | A: Accounting/Contribution/Flow, Settlement; Source/Legacy, Receipts, Cursor; Epoch/Complete, Consumer, Actual. |
| S10 | C: Escape/Material, Actual, History, Complete. Material, financial, and legacy-row conservation across institutional folds. |
| S11 | A: Accounting/Quantifiers/Assembly/Completion/Core, Dynamic, Complete; Accounting/Profit/Inventory, Decomposition, Valuation, Public. |
| S12 | C: Root/Contract, Consumers/Registered; inherited Total/Finite, Epoch, Cofinal, Complete and cost contracts. |
| S13 | O: ActiveControl/Source, Minimum; Root/Complete, Institutional; Completion/Complete; plus CompleteLedger Archive/Native/Source, Acceptance, Complete, Archive/Word, Primitive/Archives, Consumers/Zero. |
| S14 | O: Countermodels/Nonattainment/Source, Prefix, Programme, Cost/Lower, Cost/Pricing, Complete. |
| S15 | O: Countermodels/Nonattainment/Family/Source, Family/Cost, Native/Complete; Completion/Source; RootedSource/Complete. |
| S16 | O: Recognition/Family. Constructive strictly cheaper rooted completion for every cleared candidate, inherited by Completion/Complete. |
| S17 | P: Outside/Source, Compiler, Complete, Consumers; Arithmetic/Interval, Accounts, Controls; Source/Branches, Envelope, Compiler, Authority, Submission, Preflight; Settlement/Compiler, Accounting, Trace; Root/Preparation, Protocol, Completion, Accounts, Carrying, Contract (`CapitalRiskCompensationClosedAt` extending `MinimalSupportAndEscapeAt`); Consumers/Source, Prices, Submission, Registered, ActualRoot (delivers $q^*=4$ and $3,4,7,100$ four-way classification). |

All listed files carry extension \(\texttt{.lean}\), depend solely on Lean 4's three standard axioms (`propext`, `Classical.choice`, `Quot.sound`), and contain zero `sorry`, `unsafe`, or `partial` declarations. At the top of the inheritance hierarchy, `CapitalRiskCompensationClosedAt` extends `MinimalSupportAndEscapeAt → ClearingCostClaimsClosedAt → InstitutionalCostedCapitalRootAt → … → CapitalQuantifiersClosedAt`, binding minimal permission support, public functional replay, finite-step complete disposition, origin-bounded receipts, unique minimal risk pricing, dual clearing-cost regimes, and cross-institutional ledger transport to the same actual source and all its successors.
