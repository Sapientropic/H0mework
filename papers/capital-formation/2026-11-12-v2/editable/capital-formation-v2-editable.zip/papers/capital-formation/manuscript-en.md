# The Structural Theorem of Capitalism

## Minimal Permission Support, Public Functional Replay, and Unique Minimal Risk Pricing

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

Is exclusive private control an unavoidable institutional price for coordinating complex production and bearing unknown innovation risk? Working over formalized structures of production, needs, port permissions, slot-indexed finance, and intertemporal history, this paper proves a negative answer and establishes a structural theorem covering all forms of capitalism. First, for any permission law \(L\), five-layer complete absence of capital—jointly excluding private access asymmetry, capital-relation kernels, transferable capital asset titles, all five modes of actual surplus appropriation, and present historical control—holds if and only if production ports exhibit no permission asymmetry: \(\operatorname{NoCapital}(L)\iff\operatorname{NoAsymmetry}(L)\). Every constructor input across industrial wage labor, care outsourcing, financial credit, platform algorithms, fully automated assets, and state capital compiles into either a valid capital witness or an exact failing check; every established witness reconstructs itself from its own fields, proves positive registration \(r(\sigma)>0\) without external assumptions, enters a unified social contract, and reaches either a complete abolition witness (jointly satisfying full-account Pareto improvement, independent member migration, and a currently executable future paying all needs) or an exact named obstruction in at most \(n\le m(x)+1\) steps. Second, every finite production sequence \(w\) under any law \(L\) admits an explicit same-length non-dominating public functional replay \(\rho_{L,s}(w)\) preserving the full successor state, every physical and financial entry, provision for all members' living and maintenance needs, and task service adequacy, while clearing controller-consent gates and eliminating capital kernels.

Addressing the classic objection that future uncertainty and innovation still require permanent equity control, we prove that mechanisms fixed before unknown events execute successive paid discoveries beyond the quoted menu (\(0\to 1\to 2\)) behind a current-period living-payment gate, while cumulative principal receipts across all account slots of any issuance origin \(o\) satisfy \(\operatorname{receivedForOrigin}(o,H)\le Q_o\). Furthermore, **without subjective probability priors, exogenous utility functions, discount rates, or arbitrary loadings**, executable non-financial outside baselines \((a_P,a_B)\) and complete branch incomes \((y_P(\omega),y_B(\omega))\) across any paid local-signal fiber \(\Omega(s_{\mathrm{loc}})\) endogenously determine the bilateral safe compensation interval \(\max_{\omega\in\Omega(s_{\mathrm{loc}})}(a_P-y_P(\omega))\le q\le\min_{\omega\in\Omega(s_{\mathrm{loc}})}(y_B(\omega)-a_B)\); when nonempty, its unique rational closest to zero \(q^*(s_{\mathrm{loc}})\) is the unique minimal necessary risk compensation and partitions all proposed amounts into necessary compensation, independent surplus distribution, provider shortfall, and payer overcharge. Clearing costs bifurcate between an attained minimizer on funded financial tails and constructive strict improvement (\(3+1/(n+2)\)) for every completing candidate on a productive domain; legacy obligations transport injectively across arbitrary institutional changes without assuming a finite prior ledger, and any purported capital regeneration exposes an exact permission-discrepancy address against the active public interpreter. Productive coordination and unknown-risk pricing are thereby mathematically decoupled from permanent private domination.

**Keywords:** structural theorem of capitalism; permission asymmetry; public functional replay; abolition audit; endogenous risk pricing; incomplete contracts; political economy

## 1 Private Control Is Not the Price of Production: Problem, Pen-and-Paper Anchor, and Main Theorem

A productive and research organization operates through equipment, recipes, labor, advanced funds, and ongoing upkeep. Workers and researchers need entry to critical stages of production and must continue living after leaving a post; financiers who have advanced materials or absorbed trial losses are owed settlement according to their undertaking; and unannounced technical discoveries may outrun the initial contract menu. Theories of team production, incomplete contracts, and uncertainty explain how monitoring, residual control, and risk bearing shape organizations. [@AlchianDemsetz1972; @GrossmanHart1986; @Knight1921; @FamaJensen1983] Do productive coordination and the pricing of unknown innovation risk require bundling exclusive residual control and unbounded residual claims in one capital holder?

We construct an institutional process that coordinates production and settles necessary risk compensation after removing that bundle. What makes an arrangement a capital relation is neither the physical presence of machinery and specialized division of labor, nor organizational labels such as “corporation,” “platform,” or “state enterprise,” but **how asymmetric port-access permissions interlock with living needs, economic return flows, and independently exercisable powers of disposition**. Equipment can run while private exclusion gates are removed; advanced principal and necessary risk can be settled in full while control terminates; and off-menu technologies can be discovered sequentially without encoding a one-time contribution into permanent jurisdiction over later participants. Establishing this as a checkable scientific conclusion requires closing four problems together: (1) what minimal structural condition is necessary and sufficient for all forms of capital; (2) whether removing private access gates preserves every productive and living-support function intact while transitioning in finitely many steps; (3) how unknown innovation risk is priced uniquely and minimally without subjective probability oracles or permanent equity; and (4) how legacy debts, physical stocks, and covert permission regressions are tracked across institutional change.

### 1.1 Seeing the Core Distinctions on a Two-Party Port and Risk Ledger

Before introducing general notation, we verify the paper's two central mechanisms by hand in three minutes on a minimal ledger with two participants, one production port, and one good serving both subsistence and settlement.

Write \(L\) for a permission law, \(s\) for the current state, and \(w\) for a finite sequence of action requests. A state \(s\) records each participant's physical stocks, the financial claim matrix, the active technology, and the physical clock; a law \(L\) specifies which production ports \(p\) a request requires, who is designated controller \(c_L(s,p)\) of port \(p\), whether participant \(i\) is admitted (\(a_L(s,p,i)\in\{0,1\}\)), and how valid requests update stocks and claims. **Private access asymmetry** means that the same port admits its controller (\(a_L(s,p,c_L(s,p))=1\)) while excluding an affected participant (\(a_L(s,p,i)=0\)). An **actual** action sequence has been executed and recorded in stocks and accounts; a **feasible** request is one that passes the law's checks at a given state. An unexercised feasible power of disposition already shapes participants' standing, whereas realized appropriation and repayment require actual ledger entries.

**Example 1 (Three-minute pen-and-paper check: two-party public replay and prior-free risk pricing).** Consider lender-controller \(P\) and borrower-producer \(B\), a single good with settlement rate \(1\), initial stocks ordered as \((x_P,x_B)=(100,100)\), initial debt \(0\), and a mandatory subsistence requirement of \(1\) unit per person per period. Production at port \(p_0\) yields \(10\) units with zero extra raw-material input.

1. **Controlled execution versus same-length public replay (Theorems 2 and 8).** Under controlled law \(L\), \(P\) controls port \(p_0\): \(a_L(s,p_0,P)=1\), whereas \(a_L(s,p_0,B)=0\) unless \(P\)'s private consent signature is attached. Take sequence \(w\) spanning five operational stages (\(7\) atomic requests): (i) \(B\) issues a \(1\)-unit loan claim to \(P\) and receives \(1\) physical unit from \(P\); (ii) \(B\) submits an unconsented process-change request, which \(L\) rejects; (iii) with \(P\)'s consent, \(B\) enters \(p_0\) to produce \(10\) units; (iv) \(B\) repays \(1\) unit to retire the loan; (v) \(P\) and \(B\) each consume \(1\) subsistence unit. Under \(L\), \(B\) meets subsistence through a gated port, debt and return flows occur, and \(P\) retains an independent feasible disposition power—forming a capital kernel \(C=(A,R,D)\). Now flip port access alone to the open interpretation \(L^{\mathrm{pub}}\) (\(a_{L^{\mathrm{pub}}}(s,p_0,B)=1\)) and construct the public replay \(\rho_{L,s}(w)\) request by request: stages (i), (iii), (iv), and (v) retain their operations with empty controller-consent lists, while the rejected stage (ii) becomes a zero-effect presentation at the same index. Comparing both ledgers: atomic word length is \(7\), terminal stocks are identically \((x_P,x_B)=(99,109)\) (or \((99,108)\) when stage i includes a \(1\)-unit trial investment debit by \(B\)), terminal debt is \(0\), both members' subsistence is paid, and both private access asymmetry and the capital kernel vanish under \(L^{\mathrm{pub}}\).
2. **Unique minimal necessary risk compensation across unknown loss branches (Theorem 12, `CF17`).** Next consider a trial with unknown external loss: \(B\) borrows \(1\), invests \(1\) unit in the trial, pays \(1\) unit for local observation yielding signal \(s_0\), produces \(10\) units, repays the \(1\)-unit loan, and both parties consume \(1\) subsistence unit; meanwhile, risk-bearer \(P\) suffers an external loss of either \(2\) (branch \(\omega_1\)) or \(4\) (branch \(\omega_2\)), and paid local observation returns the **same signal \(s_0\)** on both branches. Posit neither subjective probabilities nor utility functions, and read the accounts directly:
   - **Endogenous outside baselines**: Without running the financial trial, each party's valid, non-financial, subsistence-paying alternative is simply paying \(1\) unit of living consumption, giving complete-income baselines \(a_P=-1\) and \(a_B=-1\) (strictly negative, never defaulted to \(0\); if stock cannot pay subsistence, preparation returns an exact obstruction).
   - **Same-signal complete branch incomes**: Prior to risk compensation, \(B\)'s complete net income on both branches is \(y_B=+1-1-1+10-1-1=+7\) (loan receipt \(+1\) and repayment \(-1\) cancel); \(P\)'s complete net income is \(y_P(\omega_1)=-2-1=-3\) on \(\omega_1\) and \(y_P(\omega_2)=-4-1=-5\) on \(\omega_2\).
   - **Bilateral safe interval and unique minimal transfer**: Requiring transfer \(q\) to preserve both parties' outside baselines on every branch in \(s_0\)'s fiber (\(y_P(\omega)+q\ge a_P\) and \(y_B(\omega)-q\ge a_B\)) yields \((-1)-(-3)=2\le q\le 7-(-1)=8\) on \(\omega_1\) and \((-1)-(-5)=4\le q\le 7-(-1)=8\) on \(\omega_2\). Intersecting across the signal fiber gives the exact closed interval \([4,8]\)! Its unique rational closest to \(0\) is \(q^*(s_0)=4\). Paying \(q^*=4\) leaves terminal stocks \((x_P,x_B)=(101,103)\) on \(\omega_1\) and \((99,103)\) on \(\omega_2\) (binding \(P\)'s baseline \(99-100=-1=a_P\) on \(\omega_2\)) and restores the claim matrix to \(0\); proposing \(q=3\) leaves a provider shortfall, \(q=7\) is safe yet strictly larger (\(|7|>|4|\), classified as independent surplus distribution), and \(q=100\) breaches the payer's baseline, so all three are barred from issuing necessary-risk claims.

Part 1 of Example 1 follows directly from Theorem 8's single-step rules, and every number and four-way classification in Part 2 is kernel-verified by decidable computation in the pinned formal source (Supplement Section E.3 and S17 of Table H). Theorems 1–19 generalize both anchors across arbitrary finite object types, all constructor forms, arbitrary finite words, and arbitrary intertemporal institutional histories.

### 1.2 The Structural Theorem of Capitalism and Paired Negative Controls

Throughout the paper, a programme source packages a law, an initial state, and either static instructions or a dynamic emitter generating action sequences; a social disposition contract is the joint bundle of verification, migration, settlement, and continuation obligations fulfilled by a source and its actual successors (parenthetical keys `CF0–CF17` denote fixed proposition identifiers in the public formal proof maps).

**Theorem 1 (The structural theorem of capitalism).** Over the structures of production, living and maintenance needs, port permissions, slot-indexed finance, and intertemporal history defined in this paper, the following six conclusions hold jointly:

1. **Minimal permission support and self-reconstruction (`CF0–CF3`).** For any permission law \(L\), five-layer complete absence of capital holds if and only if production ports exhibit no permission asymmetry. Every witness of a capital kernel, transferable asset title, actual surplus appropriation (across five modes), controlled contribution reproduction, or present historical control traces back to concrete gated needs, return flows, and control origins on the same execution; every specified constructor input compiles to a valid witness or an exact failing condition, and every established witness reconstructs itself from its own fields.
2. **Self-proved registration and financial-entry dispatch (`CF12`).** Every capital kernel \(C\) (and every active control use) on the execution of any programme source and state proves positive registration \(r(\sigma)>0\) from its own nonempty entry and enters the unified social disposition contract. When initial debt matches the genesis zero account, the contract maintains termination, public replacement, renewal, and future expansion at every step while tracking subsequently issued debts slot by slot; when initial debt leaves an unrepresented discrepancy, it returns an exact \((j,d,h)\) matrix address while retaining the full law and actual successor.
3. **Finite-step complete abolition disposition and persistent tail (`CF12–CF13`).** From any cut \(x\) of an actual run, iterating the deterministic successor \(T\) reaches a unique complete disposition in at most \(m(x)+1\) steps: public success jointly delivers full-account Pareto improvement (\(\Delta_{i,g}\ge 0\) everywhere with at least one strict gain), independent member migration, and a currently executable future paying all needs; failure retains an initial review obstruction or an exact financial, migration, or future residual. Once public mode is entered, runtime persistence excludes any fresh capital kernel or control use across the entire tail, ruling out obstruction-free recurrent-control absorption paths.
4. **Universal non-dominating public functional replay (`CF14`).** For any \(L,s,w\), any membership roster \(M\), and any service task \(\tau\), position-wise public replay \(\rho_{L,s}(w)\) preserves word length, the full successor state, and exact item-by-item inventory mapping, preserves full needs payment and service adequacy each if and only if they hold in \(w\), clears controller-consent gates, and eliminates capital kernels.
5. **Off-menu paid innovation, origin receipt cap, and unique minimal risk pricing (`CF8–CF9, CF11, CF15–CF17`).** Mechanisms fixed before unknown events generate complete dispositions over all open events and execute successive off-menu paid discoveries behind a current-period living-payment gate; cumulative principal receipts across all slots of any registered issuance origin \(o\) satisfy \(\operatorname{receivedForOrigin}(o,H)\le Q_o\). Without subjective priors, utility functions, or exogenous loadings, executable outside baselines and complete branch incomes over any paid local signal \(s_{\mathrm{loc}}\) uniquely determine the bilateral safe interval \([\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\): empty fibers or crossed bounds issue zero claims, while nonempty compatible intervals yield the unique minimal necessary risk compensation \(q^*(s_{\mathrm{loc}})\) closest to zero, partition all proposed rationals into four disjoint dispositions, and settle in two phases on the underlying social state while preserving all members' needs, all participant–good benchmarks, and pre-compensation claim matrices.
6. **Net control harm, dual clearing-cost regimes, and cross-institutional ledger transport (`CF4–CF7, CF10`).** Complete income decomposes into net production, open transfers, signed control transfers, and revaluation; once a repair row is settled, every open mechanism chain it continues to authorize satisfies \(\mathcal I_{A,g}\le 0\) for every coalition \(A\). Clearing cost attains a minimum on funded financial tails, whereas in a productive complete-clearing domain every completing candidate admits a constructively cheaper completion (unattained infimum \(3\)). Arbitrary finite institutional histories transport all legacy rows, physical origins, and claim matrices injectively without assuming a finite old ledger (including emitted cofinal confluences), and any purported capital regeneration locates an exact permission discrepancy against the active public interpreter.

| Branch of Theorem 1 | Core political-economic & contract problem | Sections & results | Paired structural negative control |
| --- | --- | --- | --- |
| Minimal support & self-reconstruction | What constitutes capital across all forms, and can legal repackaging evade detection? | §§3–4.1; Theorems 2–4 | Uniformly closed law \((0,0)\) satisfies `NoAsymmetry` yet pays zero needs (§3.4), separating non-exclusion from provision |
| Self-registration & finite-step audit | How does recognized capital enter disposition, and where do stalled transitions halt? | §§4.2–5; Theorems 5–7 | Unrepresented initial debt exposes exact \((j,d,h)\); intermittent recurrence hits an unresolved review obstruction |
| Public functional replay | Does removing private residual control disrupt coordination, finance, or services? | §6; Theorem 8 | Rejected requests map to same-index zero-effect presentations rather than being dropped or turned into free goods |
| Off-menu innovation & origin cap | How does open exploration continue without turning one contribution into endless rent? | §§7.1–7.4; Theorem 9, Prop. 10, Theorem 11 | Payable future proposal with unpaid current needs is strictly blocked by the living-payment renewal gate |
| Unique minimal risk pricing | Without objective probabilities, must unknown risk be priced via permanent equity? | §7.5; Theorem 12, Ex. 2 | Negative baselines \((-1)\) refute \(0\)-defaults; \(3/7/100\), unpaid signals, and unquoted events write zero risk claims |
| Repair, clearing cost & transport | How are harms and debts settled, and can institutional renaming erase liabilities? | §§8–10; Theorems 13–19 | Pure rent & cost-eaten gains yield zero net blockage; zero balance \(\ne\) archive; domain \(3+1/(n+2)\) has no minimum |

Table 1: The six branches of the main theorem, section locations, and paired structural negative controls. Result 10 is a constructive proposition; the other 18 results are universal or equivalence theorems.

The rightmost column of Table 1 highlights the paper's methodological discipline: every positive universal theorem is paired with a formal negative control showing exactly which countermodel or named obstruction fires when a condition fails. Universal quantifiers range directly over laws, constructor sum types, finite execution words, and histories: any historical or contemporary arrangement satisfying Section 3's three-leg kernel and port asymmetry—whether factory wage labor, platform algorithmic gating, subcontracted care, or automated compute leasing—is already a valid input to Theorem 1, while inputs failing a constructor check return the exact missing leg.

### 1.3 Fifteen-Minute Fast Verification Channels and Series Division of Labor

Readers from different disciplines can inspect self-contained slices of the argument directly:

- **Political economy and social philosophy** (exploitation, social reproduction, capabilities, and private government): Section 1.1 Example 1 $\to$ Section 2 normative foundations $\to$ Section 3 three-leg kernel and Theorem 2 $\to$ Section 5.2 three-part abolition audit $\to$ Sections 8.2, 8.4, and 10.4 five-axis synthesis.
- **Theory of the firm, incomplete contracts, and legal institutionalism** (Coasean direction, team-production five-right bundle, GHM residual control, resource access, and legal coding of capital): Sections 3.2–3.3 Theorems 2–3 $\to$ Section 4.1 Theorem 4 $\to$ Section 5.3 polycentric renewal $\to$ Section 6 Theorem 8 public functional replay $\to$ Sections 10.1–10.2 Theorems 18–19 (with Supplement Sections B and D).
- **Financial economics, innovation, and ambiguity pricing** (Knightian uncertainty, multiple-prior ambiguity, costly state verification, and equity risk premia): Section 1.1 Example 1 Part 2 $\to$ Section 7 Theorem 9, Proposition 10, Theorems 11–12, and Example 2 (Figures 4–5) $\to$ Section 8.1 Theorem 13 $\to$ Section 9 Theorems 15–17 (with Supplement Sections E and G).
- **Formal verification and mechanism design** (dependent-type constructions, invariant preservation, and constructive algorithms): Section 1.2 Theorem 1 $\to$ proofs of Theorems 2, 4, 6, 8, 11, 12, 17, and 18 together with Supplement Equations (A1)–(G7) and Table H's fixed-source bindings.

Within our broader monograph series, *Book-Balancing Magic Has Nowhere to Hide* establishes whole-event inventories, non-free responsibility lifecycles, and two-key settlement; *The Canonical Society Theorem* constructs subject lineages without pre-installed individuals, the four-part complete root law, repair unidentifiability under coarsened readouts, and cofinal constitutional self-revision; and *An Economic Constitution of Possibility* formulates the normative separation of basic participation, contribution claims, scarce budgets, and revocable governance. [@Gao2026WholeLedger; @Gao2026Society; @Gao2026Constitution] Building on those foundations, the present paper independently proves the full characterization, functional replay, finite-step abolition, and unique minimal risk pricing of capital relations; multi-period fiscal envelopes with order-sensitive transition reserves and cross-border reparations with Byzantine peace handoffs are proved in dedicated companion works.

## 2 Why Basic Participation Precedes Standing Based on Capital

### 2.1 Institutional Standing Cannot Be Graded by Usefulness or Expected Return

When common rules require a person to bear the consequences of production schedules, port access, and debt settlement, those rules owe that person equal standing to demand reasons and an institutional response. Such standing precedes capital contribution, employment, and output grading. Children, patients, elderly people, caregivers, and individuals who can never generate market-measurable output all have real living needs and inhabit the boundaries drawn by institutions.

Treating basic subsistence as an ex post reward for prior market contributions inverts causality: nutrition, shelter, care, learning, and safe entry are preconditions for forming agency and productive capacity in the first place. Conditioning eligibility on expected future returns leaves the dependence intact, because whoever grades another person's prospective usefulness retains the power to withdraw the conditions of life. Basic participation therefore rests on two distinct grounds: meeting human living and maintenance needs, and recognizing every person subject to common rules as an equal bearer of standing—the second ground ensuring that participation never lapses when repayment is impossible. [@Gao2026Society, §1.2; @Gao2026Constitution, §3]

Sen's capability approach shifts evaluation from nominal commodity holdings to what people are actually able to do and be, and Robeyns shows how bodily, social, and environmental conversion factors together with structural constraints shape the translation of resources into achievable lives. [@Sen1980, §§3–5; @Robeyns2017, pp.46–47, 65–66, 81–86] Here that insight is carried into checkable permission and delivery relations: even when someone holds nominal purchasing power, if obtaining essential services still requires passing through an irreplaceable controller's private gate, that person's actionable freedom remains governed by the gatekeeper.

Unconditional basic participation neither mandates identical commodity rations nor erases technical qualifications. Disability support, extended care, or longer training serve equal standing, whereas operating hazardous equipment still requires certified skill, drawing scarce materials requires a shared budget, and holding public office requires explicit mandate and term limits. **Basic standing, task qualification, contribution claims, and revocable governance answer four distinct institutional questions.** Supplying funds can establish a valid claim to repayment, but a loan receipt cannot buy permanent gatekeeping power over everyone who arrives later.

### 2.2 Five Checkable Provision Stages and the Hard Constraint of Social Reproduction

Returning to our production organization: when a worker refuses controlled terms or leaves a post, how does living support actually continue? Turning basic participation into an auditable institutional process requires five connected stages:

1. **Need identification**: registering living and mandatory-maintenance bundles for a specific person, good or service, and time window;
2. **Institutional and budget binding**: designating the providing body and shared budget, allowing beneficiary, provider, and payer to be distinct parties;
3. **Executed delivery**: recording physical or service delivery in the execution inventory with verified beneficiary and need tags;
4. **Addressed refusal and challenge**: retaining a named reason and responsible party whenever delivery is refused, delayed, or short, with standing to challenge and propose alternatives;
5. **Cross-role continuation**: continuing next-period provision directly from current stocks and open obligations after a change of role, without re-clearing a private employer's usefulness screen.

Fraser's critique of the contradictions between capital and care underscores the political-economic weight of this requirement: commodity production depends on caregiving and social reproduction while systematically externalizing and eroding those very conditions behind positive firm-level profits. [@Fraser2016] Hirschman's analysis of **exit** and **voice** in organizations likewise shows that when leaving carries prohibitive livelihood loss for lack of an actionable outside continuation, the exit threat loses credibility and internal voice withers alongside it. [@Hirschman1970, pp.3–4, 35–36, 81–82] Accordingly, **actual per-person payment of living and maintenance needs** (\(\operatorname{AllNeedsPaid}\)) enters as a hard gate across Section 5's complete abolition witness, Section 6's public replay, and Section 7's innovation-renewal release: promises of future growth cannot substitute for current delivery, and aggregate output gains never offset a single member's unpaid subsistence.

### 2.3 Standing of Those Who Bear Consequences and Public-Law Bounds on Private Power

Contemporary corporate-governance theory has recognized the limits of pure market-value maximization when externalities and incomplete contracts intertwine. Hart and Zingales argue that where social or environmental harms are inseparable from production, firms should pursue **shareholder welfare**—incorporating shareholders' prosocial preferences via shareholder voting—while explicitly retaining shareholders' priority in decision-making. [@HartZingales2022, §§II–III, V] Taking their argument at full strength exposes a sharp constitutional divide: **having one's interests weighted inside a benevolent shareholder's utility function is fundamentally different from possessing one's own institutional standing to demand reasons, contest refusals, audit accounts, and exit without loss of livelihood.**

Two foundational legal-political traditions converge on this divide. Early in the Freiburg ordoliberal tradition, Böhm insisted that private economic coercion is never a purely private affair immune to public law: any economic power capable of directing others' lives must be subject to public authorization, accountability, legal remedies, and revocation. [@Bohm1928, pp.55–57, 65–67] Anderson's critique of workplace **private government** further pinpoints how modern employers wield unaccountable authority of command and sanction inside the firm precisely by converting control over productive assets into governance over persons. [@Anderson2015, pp.64–65, 110–111] Section 2 anchors governance standing in bearing institutional consequences rather than holding shares; Sections 3–10 then prove formally that enforcing this standing neither impairs productive coordination nor paralyzes risk-bearing.

## 3 What Structure Makes a Production Relation Capital

### 3.1 Three Mutually Indexed Legs on One Execution: Gated Needs, Return Flow, and Feasible Disposition

Proving a theorem across all forms of capitalism requires isolating the minimal relational kernel rather than cataloging historical labels. On **one and the same finite execution** of sequence \(w\) from state \(s\) under law \(L\), a capital-relation kernel \(C\) consists of three mutually indexed pieces of evidence:

1. **Provision for needs under asymmetric access (\(A\)).** An affected participant \(i\) actually obtains or consumes a positive bundle required for living or mandatory maintenance via a chronological delivery route of accepted entries (or direct same-index use). Crucially, a production port \(p\) required by that acquisition exhibits private access asymmetry: both at the pre-request state of acquisition and in the full successor state of \(w\), law \(L\) admits controller \(c_L(-,p)\) while excluding \(i\). Subsistence is thus concretely routed through an asymmetrically gated port.
2. **Consideration or economic return flow (\(R\)).** That dependence connects to at least one reverse economic circuit in the same execution inventory: (i) **productive input**, delivering \(i\)'s physical quantities along a nonempty accepted route into a production entry invoking port \(p\); (ii) **physical return**, delivering \(i\)'s physical quantities along a nonempty accepted route to the controller; or (iii) **financial claim**, issuing or transferring a strictly positive claim benefiting the controller and borne by \(i\) as debtor (or assignor). These three constructors cover wage-labor input, physical extraction, and credit-debt dependence; an unpaid positive debt suffices for the third constructor without waiting for accounting profit to turn positive.
3. **Independently exercisable capacity for disposition (\(D\)).** At some state already reached in this execution, the right holder can independently sign and submit a locally valid disposition request—external use, investment use, positive physical transfer to the holder, or assignment of a positive claim—without requiring extra controller consent, while retaining private access asymmetry against \(i\). Disposition checks a **feasible power of control**: even if held in reserve during the current period, an actionable prerogative over the gated resource already structures the relationship.

Writing \(A\), \(R\), and \(D\) for these three legs gives
\[
C(L,s,w)=(A,R,D).
\tag{1}
\]
Equation (1) requires all three witnesses to inhabit the same execution inventory and its legal local alternatives (Supplement Equations (A1)–(A3)), barring artificial patchwork across unrelated histories. In Hohfeld's classic analytical jurisprudence, the blanket term “capital ownership” conflates distinct jural relations; here they are cleanly separated into port access permission \(a_L\) (privilege), the directed claim matrix \(F\) (claim-right), and feasible disposition \(D\) together with rights-change operations (power). [@Hohfeld1913] Separating these three planes is what enables subsequent theorems to excise private access exclusion and arbitrary control while preserving legitimate claim settlement and productive operations intact.

### 3.2 Transferable Asset Titles, Five Modes of Surplus Appropriation, and Intertemporal Control

Above the kernel \(C(L,s,w)\), three higher-order structures are distinguished with exact constructors (Supplement Section A.3):

- **Transferable capital asset title**: augments \(C\) with an executed or locally feasible valid rights-change request replacing port controller \(h\) with \(h'\ne h\) so that \(h\) loses access and \(h'\) gains access. This captures alienability from the person; fixed bodily permissions inseparable from an agent fail controller replaceability and are never misclassified as capital property.
- **Actual surplus appropriation**: augments \(C\) with executed appropriation records across five exhaustive modes—consumption, reinvestment, terminal stock retention, routed consumption, and financial return aligned with the exact issuance origin in \(C\). Unexercised quotes and paper revaluations do not count as actual appropriation.
- **Intertemporal capital and present historical control**: preserves exact historical access, need, and return addresses together with subject and relation birth lineages across multiple visits; counting as active present control (\(\operatorname{ControlUse}\)) additionally requires the current request to be valid, to invoke the port, and to exclude a current affected bearer.

This two-tier architecture bridges classical political economy and modern organizational economics. In Volume I of *Capital*, Marx grounds the sale of labor power in producers' separation from the conditions of labor (Chapter 6), analyzes continuous production as the reproduction of that separation (Chapter 23), and traces its historical genesis (Chapter 26). [@Marx1867, chs.6, 23, 26] Equation (1) and intertemporal lineage turn “reproduction of separation” into occurrence-by-occurrence checks: needs pass through a gated port, return flows enter the ledger, and exclusion persists in the successor state. From another angle, Rajan and Zingales critique Grossman–Hart–Moore's narrow focus on formal title to physical assets, defining **access**—the ability to use or work with a critical resource such as a machine, an idea, or a core team—and showing how regulating privileged access generates organizational power and rent races even without transferring formal ownership. [@RajanZingales1998, §I] Anchoring \(C\) at port-access asymmetry rather than alienable title alone captures algorithmic platform gating, non-transferable bureaucratic control, and alienable corporate property under one roof.

### 3.3 Equivalence Between Five-Face Absence of Capital and Absence of Permission Asymmetry

Let \(c_L(s,p)\) be the controller of port \(p\) at the technology component of state \(s\), and let \(a_L(s,p,i)\in\{0,1\}\) be participant \(i\)'s access value. Private access asymmetry is
\[
\operatorname{Private}_L(s,p,i)
\iff
a_L(s,p,c_L(s,p))=1
\ \land\
a_L(s,p,i)=0,
\tag{2}
\]
and **absence of port-permission asymmetry** for law \(L\) is
\[
\operatorname{NoAsymmetry}(L)
\iff
\forall s,p,i,\quad
a_L(s,p,c_L(s,p))=1
\Rightarrow a_L(s,p,i)=1.
\tag{3}
\]
Note the exact layer on which (3) acts: it eliminates double standards at the **control-permission layer**, where a controller is admitted while another participant is barred. Whether a specific request actually executes still depends on the law's validity checks for technology recipes, available stocks, technical qualifications, and need bundles. Equation (3) therefore never licenses untrained operation of hazardous equipment; it stipulates only that beyond objective operational checks, no private gate may exclude participants by non-controller status.

Define **five-face complete absence of capital** \(\operatorname{NoCapital}(L)\) as the simultaneous exclusion across all states, ports, executions, and histories of: (1) private access asymmetry; (2) capital-relation kernels \(C\); (3) transferable capital asset titles; (4) all five modes of actual surplus appropriation; and (5) newly occurring present historical control. Including the first layer ensures that abolishing capital removes the latent permission pedestal on which capital could immediately re-form, while the other four layers verify that removing this pedestal eliminates every higher-order manifestation.

**Theorem 2 (Minimal permission support equivalence).** For any permission law \(L\) over the specified object types with decidable equality,
\[
\boxed{\operatorname{NoCapital}(L)
\iff\operatorname{NoAsymmetry}(L).}
\tag{4}
\]

**Proof.** For necessity (\(\Rightarrow\)), suppose \(\operatorname{NoCapital}(L)\) holds; its first component excludes (2) for every \((s,p,i)\). Whenever \(a_L(s,p,c_L(s,p))=1\), \(a_L(s,p,i)\) cannot be \(0\) without triggering (2), so \(a_L(s,p,i)=1\), giving (3).

For sufficiency (\(\Leftarrow\)), suppose (3) holds. Then (2) is impossible for every \((s,p,i)\), eliminating all private access asymmetries. Every capital kernel \(C=(A,R,D)\) requires (2) inside its access evidence \(A\), so no kernel exists; transferable capital asset titles and all five modes of actual surplus each carry an underlying capital kernel and are therefore empty; present historical control likewise requires (2) against a current affected person and is empty. All five exclusions hold jointly across all states, ports, and participants. □

To confirm that (4) is never vacuously satisfied by inconsistent kernel conditions, Theorem 3 exhibits an explicit material-complete realization family.

**Theorem 3 (Permission classification in a material-complete source family).** Within the permission-law family holding fixed the same real initial stocks, living and maintenance needs, production instructions, and financial entries while varying only the controller's and affected person's Boolean access values, for every clock and round:
\[
C\text{ exists}
\iff
(\text{controller admitted}=1)
\land(\text{affected person admitted}=0).
\tag{5}
\]
Moreover, at clock zero and round zero in this family, opening the affected person's access from \(0\) to \(1\) preserves every physical execution entry and the full successor state identically.

Theorem 3 pairs Theorem 2's all-law characterization with concrete non-vacuous witnesses across stock returns, debt issuance (preserving prior debt), and routed appropriation: among the four cells \((0,0),(0,1),(1,0),(1,1)\), only \((1,0)\) generates \(C=(A,R,D)\), whereas flipping to \((1,1)\) delivers the identical productive and financial outcome with zero capital kernel (Figure 1).

![Permission asymmetry, three-leg kernel, and five-face equivalence](figures/fig01-structure-v2-en.svg)

Figure 1: Left (A): the four permission assignments in a material-complete source family and the same-execution three-leg kernel \(C=(A,R,D)\); capital arises exclusively when the controller is admitted (\(1\)) and the affected person refused (\(0\)). Right (B): the five witness layers excluded by complete absence of capital together with exact self-reconstruction. Bottom: the all-law equivalence and the uniformly closed negative control.

### 3.4 The Uniform-Closure Negative Control: Why Removing Asymmetry Demands Replay and Audit

Inspect the upper-left cell \((0,0)\) of Figure 1: if a law shuts every port to controller and participant alike (\(a_L\equiv 0\)), the antecedent of (3) is false everywhere, so \(\operatorname{NoAsymmetry}(L)\) holds! Retaining this countermodel marks a sharp institutional boundary: **eliminating asymmetric privilege is not yet delivering the means of life.** Shutting down production achieves “no capital” while paying zero subsistence.

Consequently, a serious theory of abolition cannot stop at \(\operatorname{NoCapital}(L)\iff\operatorname{NoAsymmetry}(L)\). Once private gates are removed, three positive tasks must be discharged: every existing capital form must enter a common disposition procedure without omission (Section 4); transitions must pass a finite-step audit of full-account non-loss, paid needs, independent migration, and executable futures (Section 5); and arbitrary productive coordination sequences must replay intact under open ports (Section 6).

## 4 How All Forms of Capital Enter One Social Disposition Contract

### 4.1 Total Constructor Recompilation and Self-Reconstruction of Established Witnesses

Historical capitalism never confines itself to a single organizational template: it operates through factory piece-work, subcontracted care agencies, supply-chain credit pledges, algorithmic platform lockouts, automated compute tollbooths, and state enterprises maintaining internal exclusion gates. If every novel legal wrapper required a fresh theoretical patch, structural coverage would remain perpetually incomplete.

Our recompilation procedure operates exhaustively over the full constructor sum types across all three levels: the three return-flow inputs for capital kernels (productive input, physical return, financial claim), the five appropriation inputs for actual surplus (consumption, investment, retention, routed consumption, financial return), and the four intertemporal inputs for historical capital (title, retention, consumption, investment). Given any law, state, execution sequence, and proposal, the compiler checks every condition and returns either a valid capital witness or the exact first failing check.

**Theorem 4 (Total constructor recompilation and self-reconstruction).** For every proposal input in the constructor types above, the compilation procedure returns either a valid capital witness on that input or an exact failing condition. Conversely, for every established capital witness \(C\), submitting its own stored proposal fields back to the compiler reconstructs \(C\) identically:
\[
\operatorname{reconstruct}(\operatorname{fields}(C))=C.
\tag{6}
\]
Capital kernels, all five modes of actual surplus appropriation, and all four modes of intertemporal capital each satisfy (6).

**Proof.** Case-splitting exhaustively across the constructor sum types runs the access, return, disposition, and appropriation or lineage checks in fixed order, returning the exact failing check alongside the proposal whenever a guard fails (Supplement Equation (B3)). Destructuring an already established witness \(C\) supplies its stored fields together with proofs of every guard; evaluating the deterministic compiler on those fields takes the success branch throughout and reassembles \(C\) with identical occurrence addresses, need items, issuance origins, and lineages (Equation (B4)). □

Pistor shows how land, debt, knowledge, and genetic code are turned into capital through legal modules conferring priority, durability, universality, and convertibility across jurisdictions. [@Pistor2019] Theorem 4 provides the exact structural decoder for those legal wrappers: however corporate or financial engineering repackages claims, whenever gated needs, return flows, and feasible disposition co-occur on an execution, recompilation recovers the exact capital witness. Equally decisive, a sharp structural criterion must achieve **both zero false negatives and zero false positives**: it must capture zero-wage automated toll gates and non-producing platform licensing while never mislabeling cooperative shared production, redeemable public credit, or autonomous household tools as “capitalism.” Our pinned sources (Table H, S5 and preserved source excerpts) verify nine canonical institutional models in both directions by decidable computation (Table 2).

| Institutional form | Core economic feature & boundary test | Port-access asymmetry & return structure | Unified control & disposition verdict |
| --- | --- | --- | --- |
| 1 Industrial wage capital | Separate material and labor coordinates; worker spends material to reproduce labor | Gated workshop port; labor enters production, owner pays wage & consumes surplus | Control detected; proves \(r(\sigma)>0\) & enters social contract |
| 2 Social-reproduction care capital | Caregiver, wage earner, and employer; unpaid care is a required input to labor | Employer pays earner alone, shifting caregiver subsistence onto household transfer | Control detected; enters unified social contract |
| 3 Assigned financial & interest capital | Financier advances material, takes assigned claim, and collects at rate \(2>1\) | Financial return and retained next investment separated from productive owner | Financier port detected independently in same word; enters contract |
| 4 Platform licence & fee capital | Worker owns and supplies input and performs production; platform output is `[]` | Platform gates required licence port, rejects unconsented work, extracts fee | Control detected (domination needs no production by controller) |
| 5 Zero-wage automated capital | Zero labor input and zero wage requests; controlling site alone holds recipe (\(1\mapsto 6\)) | Affected persons must issue and settle access debt to obtain subsistence goods | Control detected (refutes wage-only narrow definitions) |
| 6 Upgrading state/institutional capital | Institutional controller pays wages and upkeep, investing surplus in tech upgrade (\(5\to 6\)) | Zero personal luxury consumption, yet retains internal port exclusion and return | Control detected; enters unified social contract |
| 7 Cooperative production (negative control) | Equipment input returned by joint production; every member's need met in full | Open access; each member signs own allocation & use without discretionary consent | Full open interpretation verified; unified controls `= []` |
| 8 Redeemable public credit (negative control) | Public production backs periodic credit with real goods and purchasing power | Member redeems personally without employer/official consent; no private external use | Full open interpretation verified; unified controls `= []` |
| 9 Autonomous household self-supply (negative control) | Two households hold mutually closed personal ports and produce own necessities | Private household boundary holds, yet zero cross-household gated need or return | Full open interpretation verified; unified controls `= []` |

Table 2: Two-sided decidable verification across six positive capital forms and three non-capital institutional negative controls (Table H, S5).

### 4.2 Capital Evidence Proves Positive Registration Endogenously

Recognizing a capital relation raises an immediate operational question: what guarantees that an identified relation actually enters social disposition rather than lingering off-ledger? Adding an external hypothesis “assuming the relation is registered” would leave unregistered arrangements outside the theorem.

Let \(\sigma\) be an actual programme source (packaging law \(L_\sigma\), initial state, and static instructions or a dynamic emitter), \(w_\sigma(s)\) the sequence generated at state \(s\), and \(r(\sigma)\in\mathbb N\) the source's own registration size.

**Theorem 5 (Every capital witness proves positive registration and enters the social contract).** For any programme source \(\sigma\), state \(s\), and capital kernel witness
\[
C:\operatorname{CapitalRelationKernel}(L_\sigma,s,w_\sigma(s)),
\]
without any external registration hypothesis, \(C\) itself proves \(r(\sigma)>0\) and generates the unified social capital disposition contract for \(\sigma\). Every active present control-use witness likewise proves \(r(\sigma)>0\) and enters the same contract.

**Proof.** Split on how \(\sigma\) generates executions. If \(\sigma\) uses a dynamic emitter, its emitter registration rule yields \(r(\sigma)>0\) directly. If \(\sigma\) uses a static instruction list, \(r(\sigma)\) equals the list length; were \(r(\sigma)=0\), both \(w_\sigma(s)\) and its execution inventory would be empty, contradicting the concrete acquisition entry inside \(C\)'s access evidence \(A\). Hence \(r(\sigma)>0\) holds unconditionally, feeding directly into social admission without an extra registration premise; active control use first recovers its underlying capital relation and applies the same construction. □

### 4.3 Exact Financial-Boundary Verification and Discrepancy Dispatch

Sources entering social disposition typically carry existing credit and debt positions. Execution states record the ternary claim matrix \(F(j,d,h)\) (instrument \(j\), debtor \(d\), holder \(h\)), while slot-indexed financial accounts track each obligation's issuance origin, payment history, and terminal archive receipt. Settlement is well-defined only when both representations identify the same obligations. [@Gao2026WholeLedger]

At social admission, the contract verifies the financial boundary and produces two exhaustive dispatches (Supplement Equations (C1)–(C2)):

- **Initial debt represented at the boundary**: the genesis slot account starts empty and matches the source's zero initial debt matrix; every debt subsequently issued during actual history (such as legacy debt \(1\) in Section 7's innovation runs) enters its own slot as it occurs. The contract then delivers finite-step disposition, public replay, initial selection, renewal, and future expansion at every step.
- **Boundary leaves an unrepresented debt discrepancy**: if the source's initial state carries prior debt not represented by the genesis account, admission never silently erases it; instead it returns an exact coordinate \((j,d,h)\) where state debt differs from the boundary account while retaining the full social law and actual runtime successor for dedicated opening verification.

## 5 How Social Abolition of Capital Becomes a Finite-Step Actual Process

### 5.1 Finite-Step Complete Disposition Bounded by Pending Internal Workload

Declaring “productive assets are henceforth public” takes a single sentence on paper, yet real institutional transitions stall whenever pending accounts, member livelihoods, or executable next-period plans fall through the cracks. Turning abolition into an auditable process requires reaching a definite verdict within a finite bound determined by the current state itself.

Let \(x\) denote the current cut of an actual run, \(T(x)\) the deterministic next cut generated by the source, and \(m(x)\in\mathbb N\) the length of the pending internal work queue at \(x\) (internal steps measure queue processing, while physical clocks and living periods follow their own event rules).

**Theorem 6 (Finite-step actual complete disposition).** For every actual run cut \(x\), there exists
\[
n\le m(x)+1
\tag{7}
\]
such that \(T^n(x)\) reaches one of three complete dispositions:

1. **Initial public-replacement review obstructed**: the run remains in controlled mode, retaining the exact failing review check together with all existing responsibility rows, unspent progress budgets, and a continuation entry;
2. **Complete public abolition witness obtained**: the run enters public mode and jointly passes the full-account financial audit, actual member migration, and currently executable future checks;
3. **Named post-entry residual located**: the run enters public mode and returns the exact failing object in the financial audit, member migration, or current future candidate set.

Moreover, any legal path starting at \(x\) and satisfying \(x_{k+1}=T(x_k)\) coincides with \(T^n(x)\) at step \(n\) and therefore recognizes the identical complete disposition.

**Proof.** While pending internal work satisfies \(m>0\), each internal step consumes one item and strictly decreases the natural number \(m\); hence the internal queue empties and reaches the review boundary in at most \(m(x)\) steps. Boundary selection uses at most \(1\) additional step to produce either an admitted public state or an initial review obstruction, bounding total steps by \(m(x)+1\). Upon entering a public state, the disposition checker reads the current full account, the first public execution record, and the adaptive candidate set to return either the joint witness or a named residual. Induction on \(k\) gives \(x_k=T^k(x)\) for every path following \(T\). □

![Self-registration, financial dispatch, and finite-step complete disposition](figures/fig02-disposition-v2-en.svg)

Figure 2: Any actual capital witness \(C\) proves positive registration \(r(\sigma)>0\) and enters the unified social contract. Financial dispatch isolates unrepresented initial debts at exact \((j,d,h)\) coordinates, while represented runs reach complete disposition in \(n\le m(x)+1\) steps through initial review and sequential full-account, member-migration, and executable-future audits.

### 5.2 The Complete Abolition Witness: Full-Account Pareto Gain, Migration, and Executable Future

A “complete public abolition witness” in Theorem 6 requires a single state \(x\) to deliver three simultaneous certifications (Supplement Section C.3):

First, **full-account Pareto-improvement audit (\(\operatorname{Finance}(x)\))**. Fixing the common state at public entry, the audit runs the pre-transition controlled source under its original law for the exact same number of rounds (reading its own state each round) as a dynamic counterfactual benchmark. Writing \(S^{\mathrm{pub}},S^{\mathrm{base}}\) for terminal physical stocks and \(F^{\mathrm{pub}},F^{\mathrm{base}}\) for terminal claim matrices, define the **complete net account difference** for participant \(i\) and good \(g\):
\[
\Delta_{i,g}
=(S^{\mathrm{pub}}-S^{\mathrm{base}})_{i,g}
+[V_L(F^{\mathrm{pub}}-F^{\mathrm{base}})]_{i,g},
\]
where \(V_L\) values claims at each instrument's settlement good and positive settlement rate as positive for holders and negative for debtors. Combining stock changes and valued claim changes at the same coordinate is essential: when a debtor pays \(1\) physical unit to retire \(1\) unit of principal, stock falls by \(1\) while debt liability falls by \(1\), leaving \(\Delta_{i,g}=0\) rather than misclassifying honest debt repayment as harm; conversely, inflating stocks via fresh unbacked borrowing is offset by the matching liability. Verifying positive settlement rates, positive comparison window, and equal terminal clocks, the audit requires **\(\Delta_{i,g}\ge 0\) for every participant \(i\) and good \(g\), with strict inequality \(\Delta_{i,g}>0\) at some coordinate**. Unmatured valid claims remain intact in their slots for settlement and archival in Section 9.

Second, **actual member migration (\(\operatorname{Migration}(x)\))**. Identifying the first admitted public execution and the membership roster at entry, the check verifies that members executed independently without controller-consent gates, paid every member's living and maintenance needs, preserved productive capacity, and introduced zero new control.

Third, **currently executable future (\(\operatorname{Future}(x)\))**. Adaptive compilation from the current snapshot must produce an accepted, valid continuation sequence that pays living and maintenance needs for the entire current roster from current stocks, accounts, and open permissions.

Conjoining all three defines complete abolition:
\[
\operatorname{Abolished}(x)
=
\operatorname{Finance}(x)
\land\operatorname{Migration}(x)
\land\operatorname{Future}(x).
\tag{8}
\]
Failure of any conjunct retains the exact failing account coordinate, member shortfall, or candidate obstruction while ruling out premature declarations of success at \(x\).

### 5.3 Actual Selection of Available Replacements, Cross-Period Renewal, and Polycentric Handoffs

Section 6 proves that every production sequence admits a functionally equivalent public replay; turning existence into institutional transition requires the runtime selector to adopt it. Our initial-selection theorem (Supplement Section D.3) proves that whenever the candidate set contains a public plan passing full-account improvement and post-execution future feasibility, boundary selection enters the acceptance branch and produces (8) at the initial public state. Likewise, once in public mode with pending internal work cleared and an advance proposal active, any renewal candidate passing complete improvement and post-execution feasibility is uniquely selected and executed, generating a fresh witness at the next snapshot—last period's certificate never substitutes for paying this period's needs.

This connects directly to Ostrom's institutional analysis of polycentric governance. Separating **provision** decisions from **production** execution across operational, collective-choice, and constitutional layers allows communities to contract specialized producers and replace underperforming arrangements without erecting a permanent central monopoly. [@Ostrom2009, pp.411–414, 419–422] Here contract replacement is carried into step-by-step state handoffs: existing claim matrices, independent execution, current needs payment, and executable next-period futures are verified jointly at every transition.

### 5.4 Persistent Public Tails and Exclusion of Recurrent-Control Absorption Paths

Institutional history poses a subtler danger: capital control may retreat temporarily only to reappear intermittently in every later tail along an infinite trajectory \(T^n(x)\).

Runtime execution satisfies a **public-mode persistence lemma**: once a run enters public mode, every subsequent step continues reading the active open-port interpretation; processing pending financial items and executing new requests both preserve public mode and, by Theorem 2, exclude any fresh capital kernel or active control use across the entire infinite tail thereafter.

**Theorem 7 (Obstruction-free runs rule out recurrent-control absorption paths).** No actual trajectory following \(T\) can exhibit fresh capital control in every tail while encountering zero unresolved initial replacement-review obstructions at pre-public boundaries.

**Proof.** Suppose such a trajectory existed. Applying Theorem 6 at its starting cut yields complete disposition within \(k\le m(x)+1\) steps: entering public mode invokes public-mode persistence, eliminating fresh capital kernels and control uses at all steps \(\ge k\) and contradicting tail recurrence; stopping at an initial replacement-review obstruction directly contradicts absence of unresolved review obstructions. Both cases fail. □

## 6 How Productive Coordination Functions Persist Without Domination in Public Execution

### 6.1 Universal Item-by-Item Public Functional Replay

The strongest defense of capitalism appeals not to privilege for its own sake, but to organizational function: advancing working capital, deploying specialized equipment, coordinating multi-stage schedules, purchasing local information, and settling claims. If private consent gates are removed, does complex coordination fall apart?

This section answers universally over every finite action sequence carrying those functions. Note the complementary roles of Section 5 and the present section: Theorem 8 below takes **any given finite execution sequence \(w\)** and constructs a same-length, non-dominating public replay preserving its full successor state and item-by-item effects—carrying forward both already-paid needs and any unpaid gaps—whereas Theorem 6 in Section 5 governs live institutional transitions, additionally requiring full-account Pareto improvement, independent migration, and an executable future.

Let the open interpretation \(L^{\mathrm{pub}}\) share all technology recipes, physical debit and credit rules, settlement standards, need bundles, and clock durations of \(L\), while opening production ports, setting operational policy to unrestricted, and removing private controller-consent gates. Write \(\rho_{L,s}(w)\) for the position-wise public replay of \(w\), \(\iota_L\) for the inventory-item correspondence, \(M\) for a membership roster, and \(\tau\) for a service task specifying user, bundle, purpose, and time window.

**Theorem 8 (Complete public functional replay of any execution).** For every law \(L\), state \(s\), finite action sequence \(w\), membership roster \(M\), and service task \(\tau\), public replay satisfies
\[
\begin{aligned}
|\rho_{L,s}(w)|&=|w|,\\
\operatorname{next}_{L^{\mathrm{pub}}}(s,\rho_{L,s}(w))
 &=\operatorname{next}_{L}(s,w),\\
\operatorname{items}_{L^{\mathrm{pub}}}(s,\rho_{L,s}(w))
 &=\operatorname{map}(\iota_L,\operatorname{items}_{L}(s,w)).
\end{aligned}
\tag{9}
\]
Furthermore, full living-and-maintenance payment and task service adequacy are each preserved if and only if they hold in \(w\):
\[
\begin{aligned}
\operatorname{AllNeedsPaid}(L^{\mathrm{pub}},s,M,\rho_{L,s}(w))
&\iff\operatorname{AllNeedsPaid}(L,s,M,w),\\
\operatorname{ServiceAdequate}(L^{\mathrm{pub}},s,\tau,\rho_{L,s}(w))
&\iff\operatorname{ServiceAdequate}(L,s,\tau,w),
\end{aligned}
\tag{10}
\]
while every request in \(\rho_{L,s}(w)\) is valid under \(L^{\mathrm{pub}}\), carries an empty controller-consent list, obtains open access at all required ports, and generates zero capital-relation kernels.

In (9), the full successor state \(\operatorname{next}\) encompasses physical stocks, the claim matrix, active technology, and the physical clock: the identical terminal stocks \((x_P,x_B)=(99,109)\) and cleared debt across the seven-request sequence in Example 1 hold universally for any multi-party sequence involving credit, information purchase, and multi-port production.

### 6.2 Inductive Proof: Clearing Consent Gates on Accepted Steps and Mapping Rejections to Zero-Effect Presentations

Why not simply delete rejected requests from \(w\) and replay only accepted steps? Because sequence length, entry indices, and period-end updates govern clocks and responsibility addresses; dropping rejected indices would scramble addresses and alter period boundaries. Conversely, letting requests that failed stock or recipe checks under \(L\) execute physically under open ports would corrupt terminal stocks or fabricate unpaid deliveries.

Theorem 8 avoids both traps through a position-wise construction (Supplement Equations (D1)–(D5)):

- Whenever request \(r_j\) at index \(j\) is **accepted** under \(L\) at pre-request state \(s_j\), replay maps it to \(r'_j\) preserving the exact operation and signer while emptying the controller-consent list; because required ports are open under \(L^{\mathrm{pub}}\) and objective stock and recipe checks are unchanged, \(r'_j\) passes validity and produces the identical physical and financial state transition.
- Whenever \(r_j\) is **rejected** under \(L\), replay maps index \(j\) to a **zero-effect presentation** retaining the original signer and purpose tag; valid under \(L^{\mathrm{pub}}\), a presentation records zero physical or financial delta, preserving state \(s_j\) and never masquerading as a need or service delivery.

Inducting along \(w\), identical pre-states and identical single-step transitions (Equation (D3)) yield identical full successor states and item mappings in (9). Because accepted use entries correspond bijectively while zero-effect presentations never count as uses, both equivalences in (10) follow; open port permissions exclude private access asymmetry and, by Theorem 2, eliminate capital kernels (Figure 3). □

![Universal item-by-item non-dominating public functional replay](figures/fig03-replay-v2-en.svg)

Figure 3: Any execution word \(w\) under law \(L\) maps position by position to public replay \(\rho_{L,s}(w)\) under \(L^{\mathrm{pub}}\). Accepted requests clear controller-consent gates with identical stock and claim updates; rejected positions become zero-effect presentations preserving state and index. Both runs reach the identical full successor state \(s'\), preserving needs payment and service adequacy without capital kernels.

### 6.3 Engaging Coasean Direction, the Team-Metering Five-Right Bundle, and Incomplete Contracts

Taken together, Theorems 2 and 8 directly reshape three foundational generations of the theory of the firm:

First, **Coase's “islands of conscious power.”** Coase explained the emergence of firms by the transaction costs of discovering prices and negotiating separate market contracts, characterizing the firm by open-ended direction within contractual limits. [@Coase1937, pp.387–392] Theorem 8 separates **organized operational coordination** from **private access exclusion**: every production instruction, material transfer, and settlement in \(w\) executes intact under \(L^{\mathrm{pub}}\), proving that saving market contracting friction requires shared operational rules and open ports rather than private gatekeeping.

Second, **Alchian and Demsetz's five-right bundle of the classical capitalist firm.** Because team production makes individual marginal products costly to meter separably, Alchian and Demsetz argued that curbing shirking requires coalescing five rights in one employer-owner: (1) residual claimant status; (2) observing input behavior; (3) serving as central party common to all input contracts; (4) altering team membership; and (5) selling these rights. [@AlchianDemsetz1972, pp.777–784] Our formal theorems unbundle all five links: link (5) is the alienable asset title isolated in Section 3.2; removing links (3)–(4)'s private exclusion gates in Theorem 8 preserves every team-production and service outcome in (9)–(10); link (2) enters Section 7 as a paid local-observation debit rather than an ownership prerogative; and link (1)'s unbounded residual claim is replaced in Sections 7.4–7.5 by origin-bounded repayment and unique minimal risk compensation. Coalescing those five rights is a contingent property institution, not a mathematical requirement of team production.

Third, **Grossman–Hart–Moore incomplete contracts and residual control.** Grossman and Hart define ownership as residual rights of control when investments are non-contractible ex ante, analyzing how concentrated control alters ex post bargaining and ex ante investment incentives; Hart and Moore sharpen asset ownership into **the ability to exclude others from using assets**. [@GrossmanHart1986, pp.691–699; @HartMoore1990, pp.1120–1122, 1135] Both papers already distinguish contractual income streams from control rights (see Hart and Moore, note 3). Theorem 8 establishes across the entire execution domain that realized productive, financial, and service operations are structurally separable from asset exclusion. That leaves the forward-looking question raised by property-rights theory—once private exclusion gates are removed, what sustains future exploration, costly information, and risk-bearing? Section 7 answers with constructive mechanisms.

### 6.4 Dispersed Local Knowledge, Paid Observation, and Non-Dominating Coordination

Hayek emphasized that knowledge of particular circumstances of time and place is dispersed across local actors and cannot be assumed freely available to a central planner. [@Hayek1945, §§I–VI] Public coordination here respects that epistemic constraint strictly: local policies read only signals acquired by the party itself through positive paid debits, discoveries enter as actual runtime events, and later inputs never rewrite earlier observation records. Theorem 8 shows that preserving realized coordination needs no private exclusion; Section 7 next proves that pricing unknown risk across local signal fibers needs neither a central probability oracle nor private equity control.

## 7 Off-Menu Innovation, Bounded Origin Receipts, and Unique Minimal Risk Pricing

### 7.1 Mechanisms Fixed Before Unknown Events and Open-Event Disposition

Beyond routine production lies the final stronghold of capital-necessity arguments: under genuine Knightian uncertainty—where future technological possibilities cannot even be listed in advance—who advances trial materials, pays for local observation, absorbs failure losses, and settles risk without receiving permanent equity control?

Let a trial mechanism \(M\) fix its law, local programme, signed financing word, investment request, probe and observation fees, local policy, and closing actions **before** any unknown event \(\nu\) arrives. While the ex ante quotation menu \(Q_M\) spans a finite event grammar, the realized event \(\nu\) ranges over the entire open request type and need not belong to \(Q_M\).

**Theorem 9 (Complete disposition of open unknown events by an ex ante fixed mechanism).** For every trial mechanism \(M\) and every realized event \(\nu\), the mechanism fixed prior to \(\nu\) produces a complete disposition: either an accepted execution with its successor state or an exact failure identifying missing disbursement, unpaid observation, or invalid execution. Under the open port interpretation, the execution contains zero capital kernels, and the next event enters the same mechanism from the resulting successor state.

Every stage enforces material and informational accounting (Supplement Section E.1): signing a loan note creates zero physical material until actual disbursement is verified; trial investment debits real stock that failure never reverses; local policy reads only the party's own inbox, and sensory observation requires a strictly positive debit (\(\operatorname{ReadingCostPaid}\)) so free packets cannot masquerade as verified knowledge. Engaging both Knight's separation of unmeasurable uncertainty from calculable risk and Townsend's **costly state verification** paradigm, unpaid observation routes strictly to an \(\operatorname{unread}\) disposition barred from fabricating risk claims. [@Knight1921, part III, chs.VII, IX; @Townsend1979]

### 7.2 Declared-Weight Participation Arithmetic and Separating Invention Reward from Open Use

Before deriving prior-free endogenous pricing, we record the arithmetic participation interface under declared weights. When normalized nonnegative weights declare success weight \(p>0\), weighted failure loss \(\ell\), outside option \(a\), and loading \(b\ge 0\), setting success reward
\[
R=\frac{\ell+a+b}{p},
\qquad
pR-\ell=a+b,
\tag{11}
\]
matches declared expected net cash to \(a+b\), returning exact issues whenever parameters are unsupported. In a concrete settlement scenario yielding \(+3\) upon success and \(-2\) upon failure (arithmetic expectation \(1/2\) under equal declared weights), new principal and risk claims settle and archive in their own slots, prior debt \(1\) persists, and refusal to pay retains both the risk claim and old debt rather than erasing liability.

Arrow identified the classic tension in allocating resources for invention: once knowledge is produced, unrestricted use maximizes social benefit and feeds subsequent research, yet recouping R&D cost via exclusive rights restricts downstream use—motivating institutional separation between **remunerating inventive risk-bearing** and **open access to resulting methods**. [@Arrow1962, pp.614–619, 623–625] Proposition 10 and Theorems 11–12 realize that separation across successive open-port trials.

### 7.3 Two-Round Off-Menu Paid Innovation and the Living-Payment Renewal Gate

**Proposition 10 (Successive paid innovation and off-menu discovery).** In an explicit open-access two-round trial source, both Round 1 and Round 2 are accepted, advancing technology from \(0\) to \(1\) to \(2\), where **the second discovery (technology \(2\)) belongs to neither round's quotation menu**. Each round independently executes real disbursement, invests \(3\) physical units and \(3\) message-resource units (including \(1\) paid-observation debit), and pays every member's living and maintenance needs; Round 2 starts with zero prototype stock carried over, purchases a fresh signal from an empty inbox, recomputes quotes from its own incurred prefix, and preserves existing debt \(1\) throughout.

Proposition 10 is paired with a hard negative control against growth-by-austerity: the renewal release gate (formalized as `paidNextTrial?`) checks every member's living and maintenance payment in the current period before releasing the next trial. An explicit countermodel—where the next proposal is affordable and the current trial succeeded, yet a member's current living need remains unpaid—is strictly blocked by this gate, retaining the exact person and unpaid category (Figure 4, top).

![Ex-ante fixed mechanism, off-menu paid innovation, and origin receipt bound](figures/fig04-innovation-v2-en.svg)

Figure 4: Top (A): a mechanism fixed prior to unknown events advances technology \(0\to 1\to 2\) across a living-payment renewal gate, with discovery \(2\) outside both quote menus and legacy debt \(1\) preserved. Bottom (B): the universal origin cap bounds cumulative principal retirement across all account slots of issuance origin \(o\) by issued quantity \(Q_o\).

### 7.4 Cumulative Receipt Cap Across All Account Slots of One Contribution Origin

Once contributions and risk undertakings are recognized for repayment, how does a finite initial advance mutate under capitalist law into an endless residual claim? By conflating a bounded past undertaking with open-ended extraction across time and account slots.

When an admitted contribution is issued, it receives a unique origin tag \(o\) and issued quantity \(Q_o\). Write \(\operatorname{receivedForOrigin}(o,H)\) for cumulative actual principal retirement summed across **all terminal account slots** carrying origin \(o\) along run history \(H\).

**Theorem 11 (Cumulative contribution bound across all account positions).** For any actual programme source and any contribution origin \(o\) registered at the starting cut, across every finite continuation of the account cursor and every public suffix \(H\) following an incurred prefix,
\[
\boxed{\operatorname{receivedForOrigin}(o,H)\le Q_o.}
\tag{12}
\]
The same bound holds across every unknown event, stage, continuation length, and account slot of an innovation run.

**Proof.** On any single slot already present at the starting cut, each settlement event satisfies principal conservation:
\[
q_{\mathrm{after}}+\operatorname{paid}=q_{\mathrm{before}},
\tag{13}
\]
while holder assignments reallocate without retiring principal, new issuances open distinct slots, waiting retires zero, and archived slots cannot reopen; summing along the run equates remaining principal plus cumulative retirement to starting principal (Supplement Equations (E3)–(E4)). Slot-wise conservation alone would still fail if one origin \(o\) could be registered in multiple slots. Actual programme sources establish **origin uniqueness** via strictly ordered occurrence addresses and disjoint origin tags across static registration, ingress, and public continuation, preserved without re-issuance under account transport; thus at most one terminal slot carries tag \(o\). Nonnegativity of remaining principal and starting principal \(\le Q_o\) immediately yield (12). □

Equation (12) places an exact ceiling at the intersection of Pistor's legal durability/convertibility modules and Fama and Jensen's analysis of unrestricted residual claims. [@Pistor2019; @FamaJensen1983] Claims may change holders, cross institutional stages, or settle in installments, yet no slot transfer or rollover can manufacture extra principal for origin \(o\). Crucially, (12) bounds **principal retirement of one specific past undertaking \(o\)**, never a person's total earnings: fresh labor, new discoveries, and subsequent risk undertakings open distinct origins with their own accounts.

### 7.5 Prior-Free Bilateral Safe Envelopes and Unique Minimal Necessary Risk Compensation (CF17)

Now we confront the sharpest challenge from financial economics: Equation (11) still took exogenous declared weights \(p\), outside option \(a\), and loading \(b\); under genuine uncertainty, an ex ante mechanism may have no usable probability model. If a financier insists, “Because uncertainty is unmeasurable, I demand an arbitrary risk premium \(b\)—or permanent equity and residual control—before participating,” can an institution compute **the unique minimal necessary risk compensation** directly from objective accounts, with **zero subjective priors, zero utility functions, and zero discount rates**?

Theorem 12 (`CF17`) answers in the affirmative by an explicit source-native construction (full proofs in Supplement Section E.3, Equations (E7)–(E11), and Table H, S17).

Before the unknown event arrives, ex-ante preparation rebinds the proposed mechanism to the active law, current stocks, and complete member census at the current cut, ignoring any packaged initial stock or old permission interpreter. Within the source action alphabet and step budget, it enumerates all **executable outside alternatives** satisfying five checks: (1) step-by-step validity; (2) full living and maintenance payment for every member; (3) independent execution preserving productive capacity; (4) zero new control; and (5) non-financial execution preserving the entire claim matrix. An outside baseline exists if and only if this set is nonempty, in which case risk-provider \(P\)'s and payer \(B\)'s **outside baselines** \((a_P,a_B)\) are the separate maxima of their complete incomes over the feasible alternatives. The procedure selects an attaining word for each party and resolves ties by the candidate order. If the feasible set is empty, it reports an obstruction for each candidate.

Next, for any paid local observation signal \(s_{\mathrm{loc}}\), form the fiber \(\Omega(s_{\mathrm{loc}})\) of all quoted events generating signal \(s_{\mathrm{loc}}\). On each branch \(\omega\in\Omega(s_{\mathrm{loc}})\), let \(y_P(\omega),y_B(\omega)\in\mathbb Q\) denote the **complete branch incomes** (combining physical stock changes and financial positions so unpaid loans never inflate income) after the trial body. Because the settlement rule is fixed before unknown events arrive and sees only the paid local signal \(s_{\mathrm{loc}}\), a rational transfer \(q\in\mathbb Q\) (positive from \(B\) to \(P\), negative in reverse, pre-installing neither party as permanent recipient) preserves both parties' real outside baselines on **every** branch in a nonempty fiber \(\Omega(s_{\mathrm{loc}})\) (\(y_P(\omega)+q\ge a_P\) and \(y_B(\omega)-q\ge a_B\)) if and only if \(q\) lies in the bilateral safe closed interval:
\[
\operatorname{lo}(s_{\mathrm{loc}})
:=\max_{\omega\in\Omega(s_{\mathrm{loc}})}\bigl(a_P-y_P(\omega)\bigr)
\ \le\ q\ \le\ 
\min_{\omega\in\Omega(s_{\mathrm{loc}})}\bigl(y_B(\omega)-a_B\bigr)
=:\operatorname{hi}(s_{\mathrm{loc}}).
\tag{14}
\]
Whenever \(\Omega(s_{\mathrm{loc}})\ne\emptyset\) and \(\operatorname{lo}(s_{\mathrm{loc}})\le\operatorname{hi}(s_{\mathrm{loc}})\), define the canonical projection of \([\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\) toward zero:
\[
q^*(s_{\mathrm{loc}})
:=
\begin{cases}
\operatorname{lo}(s_{\mathrm{loc}}), & \operatorname{lo}(s_{\mathrm{loc}})>0,\\
\operatorname{hi}(s_{\mathrm{loc}}), & \operatorname{hi}(s_{\mathrm{loc}})<0,\\
0, & \operatorname{lo}(s_{\mathrm{loc}})\le 0\le\operatorname{hi}(s_{\mathrm{loc}}).
\end{cases}
\tag{15}
\]

**Theorem 12 (Unique minimal necessary risk compensation and four-way admission under the same local signal).** For every current run state and every proposed trial mechanism—with zero subjective probability, utility, discount-rate, or exogenous loading inputs—the source-native risk-pricing contract establishes jointly:

1. **Bilateral safety equivalence and unique minimal absolute payment.** If \(\Omega(s_{\mathrm{loc}})=\emptyset\), no quoted branch supports pricing on that signal and quotation is refused as an empty fiber; if \(\Omega(s_{\mathrm{loc}})\ne\emptyset\) and \(\operatorname{lo}(s_{\mathrm{loc}})>\operatorname{hi}(s_{\mathrm{loc}})\), no rational transfer measurable with respect to local signal \(s_{\mathrm{loc}}\) can preserve both parties' outside baselines across \(\Omega(s_{\mathrm{loc}})\), and quotation is refused as incompatible—both cases issuing zero risk-compensation claims. Whenever \(\Omega(s_{\mathrm{loc}})\ne\emptyset\) and \(\operatorname{lo}(s_{\mathrm{loc}})\le\operatorname{hi}(s_{\mathrm{loc}})\), \(q^*(s_{\mathrm{loc}})\) in (15) preserves both baselines on every branch in \(\Omega(s_{\mathrm{loc}})\) and achieves the **strictly unique minimal absolute payment** among all safe rules using that local signal:
\[
\forall q\in[\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})],\quad
q\ne q^*(s_{\mathrm{loc}})\implies |q^*(s_{\mathrm{loc}})|<|q|.
\tag{16}
\]
If \(q^*(s_{\mathrm{loc}})\ne 0\), at least one quoted branch brings one party's account exactly to its outside baseline. Adding any nonzero difference \(\lambda\ne 0\) to \(q^*(s_{\mathrm{loc}})\) either violates \([\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\) or strictly increases \(|q|\).
2. **Exhaustive four-way amount disposition and anti-masquerading firewall.** On any compatible interval \(\operatorname{lo}(s_{\mathrm{loc}})\le\operatorname{hi}(s_{\mathrm{loc}})\), every proposed rational \(q\in\mathbb Q\) is partitioned into four mutually exclusive dispositions: (i) \(q=q^*(s_{\mathrm{loc}})\) enters the **necessary risk-compensation** channel; (ii) \(q\in[\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\) with \(q\ne q^*(s_{\mathrm{loc}})\) satisfies \(|q^*(s_{\mathrm{loc}})|<|q|\) and is classified as **independent surplus distribution** (barred from issuing claims under risk-compensation authority and requiring its own distribution source); (iii) \(q<\operatorname{lo}(s_{\mathrm{loc}})\) returns a **provider shortfall**; and (iv) \(q>\operatorname{hi}(s_{\mathrm{loc}})\) returns a **payer overcharge**. Cases (ii)–(iv), together with unquoted events (\(\operatorname{unpriced}\)) and unpaid observations (\(\operatorname{unread}\)), send zero risk-compensation requests.
3. **Two-phase settlement and full-bearer conservation.** When \(q^*(s_{\mathrm{loc}})=0\), settlement executes as an empty zero-request word; when \(q^*(s_{\mathrm{loc}})\ne 0\), preflight verification requires distinct borrower and lender and zero balance at that instrument–debtor–creditor address after the trial body, whereupon signed native issuance of size \(|q^*(s_{\mathrm{loc}})|/r_{\mathrm{inst}}\) (at settlement rate \(r_{\mathrm{inst}}>0\)) followed by actual settlement restores the entire claim matrix identically to its post-body value. On ready, reviewable social states and preflight-approved quoted events, two-phase execution pays every member's living and maintenance needs and preserves both real outside benchmarks across all participant–good coordinates, while every attempt—whether obstructed, refused, or completed—unconditionally transports all legacy responsibility rows injectively without budget refill.

**Proof.** On each branch \(\omega\), \(a_P\le y_P(\omega)+q\) and \(a_B\le y_B(\omega)-q\) rearrange to \(a_P-y_P(\omega)\le q\le y_B(\omega)-a_B\); conjoining across the nonempty finite fiber \(\Omega(s_{\mathrm{loc}})\) yields (14) by taking the maximum lower bound and minimum upper bound (Supplement Equations (E7)–(E8)). On a nonempty fiber, crossed bounds \(\operatorname{lo}(s_{\mathrm{loc}})>\operatorname{hi}(s_{\mathrm{loc}})\) rule out any common solution by transitivity. When \(\operatorname{lo}(s_{\mathrm{loc}})\le\operatorname{hi}(s_{\mathrm{loc}})\), split on the three mutually exclusive cases of (15): if \(\operatorname{lo}(s_{\mathrm{loc}})>0\), any \(q\in[\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\) with \(q\ne\operatorname{lo}(s_{\mathrm{loc}})\) satisfies \(0<q^*(s_{\mathrm{loc}})=\operatorname{lo}(s_{\mathrm{loc}})<q\), giving \(|q^*(s_{\mathrm{loc}})|<|q|\); if \(\operatorname{hi}(s_{\mathrm{loc}})<0\), then \(q<\operatorname{hi}(s_{\mathrm{loc}})=q^*(s_{\mathrm{loc}})<0\), giving \(|q^*(s_{\mathrm{loc}})|=-\operatorname{hi}(s_{\mathrm{loc}})<-q=|q|\); if \(0\in[\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\), then \(q^*(s_{\mathrm{loc}})=0<|q|\), establishing (16). Comparing any \(q\in\mathbb Q\) against \(q=q^*(s_{\mathrm{loc}})\), \(q<\operatorname{lo}(s_{\mathrm{loc}})\), and \(q>\operatorname{hi}(s_{\mathrm{loc}})\) leaves \(\operatorname{lo}(s_{\mathrm{loc}})\le q\le\operatorname{hi}(s_{\mathrm{loc}})\) with \(q\ne q^*(s_{\mathrm{loc}})\), establishing the four-way partition via (16). Finally, under preflight zero pre-compensation balance at that address, native issuance and immediate settlement of \(q^*(s_{\mathrm{loc}})\) add and retire equal claim amounts, restoring the claim matrix (Equation (E11)) while preserving all participant–good benchmarks and legacy rows across both execution phases. □

**Example 2 (Two complementary verified consumers: single-good four-way classification and two-good social-state delivery).** The pinned formal source verifies Theorem 12 through two complementary consumers. First, in the single-good schedule consumer, initial stocks are \((x_P,x_B)=(100,100)\), initial debt is \(0\), and non-financial living-payment programmes yield strictly negative outside baselines \(a_P=-1\) and \(a_B=-1\); external losses \(2\) and \(4\) both generate the same paid local signal \(s_0\), with post-body complete incomes \((y_P(\omega_1),y_B(\omega_1))=(-3,7)\) and \((y_P(\omega_2),y_B(\omega_2))=(-5,7)\). Equation (14) yields \([2,8]\cap[4,8]=[4,8]\) and Equation (15) selects \(q^*(s_0)=4\): settling \(4\) leaves terminal stocks \((x_P,x_B)=(101,103)\) and \((99,103)\), restores the claim matrix to \((0,0)\), classifies \(q\in\{3,4,7,100\}\) by kernel computation into provider shortfall (\(3<4\)), necessary risk compensation (\(4\)), independent surplus distribution (\(4<7\le 8\), \(|7|>|4|\)), and payer overcharge (\(100>8\)), and bars an unquoted loss-\(3\) event from receiving fabricated risk payment (Figure 5). Second, in the two-good social-state consumer continuing the nonempty code lineage after paid food repair, food stocks are \((1,1)\) (outside baseline change \(-1\) each) and settlement-material stocks are \((x_P,x_B)=(109,117)\) (outside baseline change \(a_P=a_B=0\), trial output \(18\)); losses \(2\) and \(4\) yield settlement-good complete incomes \((-2,16)\) and \((-4,16)\), safe interval \([2,16]\cap[4,16]=[4,16]\), and the same unique minimal transfer \(q^*(s_0)=4\), delivered across two-phase preparation and execution while preserving both goods' benchmarks and carrying all prior responsibility rows injectively.

![Bilateral safe compensation interval and unique minimal necessary risk pricing](figures/fig05-risk-pricing-v2-en.svg)

Figure 5: Geometry and four-way admission of Theorem 12 (`CF17`, writing \(\Omega=\Omega(s_{\mathrm{loc}})\)). Top (A): executable living-paying outside baselines \(a_P=a_B=-1\) and complete incomes across two branches sharing paid signal \(s_0\) intersect at \([4,8]\), selecting the unique minimal rational \(q^*(s_0)=4\) closest to zero. Bottom (B): proposed rationals partition into provider shortfall (\(q<4\)), necessary compensation (\(q^*=4\)), surplus distribution requiring separate authority (\(4<q\le 8\)), and payer overcharge (\(q>8\)), while empty fibers, crossed intervals, unpaid signals, and unquoted events write zero claims.

The construction can be compared directly with four strands of the literature.

- **Beyond subjective multiple-prior maxmin utility (Gilboa–Schmeidler)**: Under Knightian ambiguity, Gilboa and Schmeidler replace a single Bayesian prior with worst-case expected utility \(\min_{P\in\mathcal C}\int u\circ f\,dP\) over a closed convex set of subjective priors \(\mathcal C\) and utility \(u\). [@GilboaSchmeidler1989, §§1–2] Theorem 12 shows that institutional risk settlement **needs neither a subjective prior set \(\mathcal C\) nor an exogenous utility function \(u\)**: taking the bilateral worst-branch envelope \([\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]\) directly on complete physical-and-financial accounts over the paid signal fiber \(\Omega(s_{\mathrm{loc}})\) and projecting toward zero determines \(q^*(s_{\mathrm{loc}})\) objectively and mechanically.
- **Severing “risk-bearing \(\implies\) permanent equity control” (Knight / Fama–Jensen)**: Any safe payment exceeding \(|q^*(s_{\mathrm{loc}})|\) (such as \(q=7\) in Example 2) is stripped of the disguise of “risk pricing” by (16) and exposed as surplus distribution; meanwhile, once \(q^*(s_{\mathrm{loc}})\) is issued and settled, the claim matrix returns to its pre-compensation state without granting any gatekeeping power over subsequent production. [@Knight1921; @FamaJensen1983]
- **Ex ante protection against judgment-proofness (Shavell)**: Shavell shows that a party's assets bound recoverable damages and can weaken deterrence. [@Shavell1986] Theorem 12's upper bound \(\operatorname{hi}(s_{\mathrm{loc}})=\min_\omega(y_B(\omega)-a_B)\) enforces ex ante affordability across every same-signal branch after paying subsistence and outside baselines, rejecting overcharges (\(q=100\)) or crossed intervals (\(\operatorname{lo}>\operatorname{hi}\)) before execution.
- **Ex post renegotiation and authority to pay for risk.** In incomplete-contract models, asset ownership affects the outside options in ex post bargaining and thereby influences ex ante investment incentives. [@GrossmanHart1986; @HartMoore1990] A symmetric division of the slack in Example 2's interval \([4,8]\) would give \(q=6\). Of that amount, \(4\) covers the worst-branch shortfall and \(2\) is a separate distribution. Theorem 12 writes each safe amount as \(q=q^*(s_{\mathrm{loc}})+\lambda\). The necessary payment is zero when the interval contains zero. Otherwise it covers one party's exact shortfall on at least one branch. Any nonzero difference \(\lambda\) requires independent distribution authority.

## 8 How Complete Accounts Reconnect Control Gains to Repair Responsibilities

### 8.1 Exact Decomposition into Net Production, Open Transfers, Signed Control Transfers, and Revaluation

Conventional accounting profits blend four distinct phenomena into a single scalar: net physical production, consensual transfers, transfers extracted across asymmetric control gates, and price revaluations. Collapsing them mistakes principal repayment for new wealth and conflates asset inflation or rent extraction with productive contribution. [@Ellerman2014]

Decomposing every execution inventory per participant and per good, write \(\mathcal I\) for complete income combining stock and claim changes, \(P_{\!n}\) for net production after deducting input, use, and revision costs, \(T_{\!o}\) for non-controlling open transfers, and \(K_{\!c}\) for **signed net control transfers** (positive or negative) at controller addresses identified by capital witnesses; for fixed initial valuation weights \(\pi_0\), book income \(\mathcal B\) satisfies
\[
\begin{aligned}
\mathcal I&=P_{\!n}+T_{\!o}+K_{\!c},\\
\mathcal B&=\pi_0P_{\!n}+\pi_0T_{\!o}+\pi_0K_{\!c}
            +\operatorname{Revaluation}.
\end{aligned}
\tag{17}
\]

**Theorem 13 (Item-by-item complete income decomposition).** For every execution sequence, (17) holds entry by entry across operation types while preserving instruments, settlement units, debtors, holders, and histories; under Section 6's public replay (Theorem 8), all physical and account components are preserved identically.

Exhaustive induction over operation types places production and uses in \(P_{\!n}\), splits transfers between \(K_{\!c}\) and \(T_{\!o}\) by verified capital witnesses, cancels cash settlement legs against claim retirement, and isolates pure price shifts on empty histories inside \(\operatorname{Revaluation}\) (Supplement Section F.1).

### 8.2 Net Productive Blockage After Deducting Adaptation and Retaliation Costs

Private control also suppresses output whenever a controller blocks unlisted methods to protect existing rents. Measuring that suppression fairly requires deducting every real transition and response cost triggered by opening access. Holding initial stocks, financing, investment, local policy, and **the same adaptive historical response rule** fixed across controlled and open interpretations—including experimentation, adoption, migration, maintenance, and historically triggered retaliation costs—define **net productive blockage** for participant \(i\) and good \(g\):
\[
d_{i,g}
=\max\{0,\,
 P^{\mathrm{open}}_{i,g}-P^{\mathrm{controlled}}_{i,g}\}.
\tag{18}
\]
Formal sources separate port-permission asymmetry from general operational policy restrictions. In an explicit discovery-and-retaliation source, after deducting all trial, adoption, migration, and retaliation costs, open execution strictly gains **\(18\) material units and \(3\) output units** (kept in separate physical coordinates without arbitrary price aggregation) while preserving initial debts on both branches; paired negative controls confirm zero net blockage under pure rent transfers and when response costs consume gross gains (Supplement Section F.2).

This advances two major literatures onto occurrence-level accounts. First, Roemer's property-withdrawal game defines capitalist exploitation via per-capita alienable asset coalitions and notes in Chapter 7 that dominance is also necessary, while leaving dominance unformalized in the characteristic function. [@Roemer1982, pp.194–198, 202–203] Here \(C=(A,R,D)\) formalizes dominance directly, while separating Roemer's diagnostic test (where the complementary controller coalition loses under withdrawal) from Section 5.2's transition test (\(\Delta_{i,g}\ge 0\) for all parties including valid debts). Second, Acemoglu and Restrepo's task framework and Acemoglu's macroeconomic AI model prove that when tasks are complementary with elasticity below \(1\), physical productivity gains shift task prices and labor allocation so wages can lag or inequality widen despite higher output. [@AcemogluRestrepo2019, pp.3–12; @Acemoglu2025, §§2.3–2.4, 2.9–2.10] Refusing to let aggregate output mask individual losses, our audit checks net production per good, living payment per person, and independent execution after migration.

### 8.3 Non-Duplicate Single-Stock Allocation Across Productive Harm and Controlled Restitution

When controlled history leaves productive harm and non-consensual extraction, two matrices share the current stock state: productive-harm repair \(P\) (the positive support of (18)) and controlled-return restitution \(G\) (aggregating non-consensual physical returns across private access asymmetry on identified capital routes, excluding signed gifts and public repair while leaving financial claims to financial settlement).

One unit of stock can never pay two liabilities: running a single execution reserves allocable output for \(P\) first and grants \(G\) only the remainder, maintaining at every cell \(k\)
\[
G'_k+\operatorname{allocatedG}_k=G_k.
\tag{19}
\]
Sufficient stocks and recipe capacity yield an executable plan paying \(P\), \(G\), and all members' needs together; insufficient capacity returns the exact failing request, remaining \(P\) and \(G\) balances, and unpaid needs without fictitious balancing (Supplement Section F.2).

### 8.4 Bounded Repair Renewals and the Post-Settlement All-Coalition Zero-Extraction Theorem

Repair authority itself must terminate once fulfilled, lest historical redress harden into a new permanent privilege. Let the count of currently positive residual cells be
\[
B(x)=\#\{k:\operatorname{remaining}_k(x)>0\}.
\]
Every input admitted to renew an outstanding repair row must pass across the whole word, pay all members' living and maintenance needs, and **clear at least one positive cell**, forcing strict monotone descent:
\[
\#\operatorname{admittedInputs}+B(x_{\mathrm{next}})
\le B(x_{\mathrm{start}}).
\tag{20}
\]
Once settled (\(B=0\)), can any subgroup repackage that closed row across new mechanisms to extract positive net income? Theorem 14 rules out extraction for **every coalition**. Write \(\mathcal I_{A,g}\) for cumulative complete income from (17) summed over coalition \(A\) and good \(g\), and \(\operatorname{Consumed}_{A,g}\) for actual use consumption on \((A,g)\).

**Theorem 14 (All-coalition and open-mechanism bound after repair settlement).** Starting from any settled repair row, along every finite chain of open mechanisms continued under that row's authorization (where mechanisms may change each step but rebind initial state and active law to current stocks and permissions without external stock injection) and every finite prefix of any submitted input sequence, for **every participant coalition \(A\)** and **every good \(g\)**,
\[
\mathcal I_{A,g}\le0,
\qquad
\mathcal I_{A,g}+\operatorname{Consumed}_{A,g}=0.
\tag{21}
\]

**Proof.** Starting from a settled row (zero remaining reparation credit), each switched open mechanism in the chain rebinds to that same settled row without refilling credit, preserving the settled predicate inductively across the entire finite chain and issuing zero further reparation payouts. At each step, complete income on that row equals terminal minus initial physical stock, which without fresh payouts equals minus each participant's actual use consumption; summing over coalition \(A\) and telescoping across the finite chain yields \(\mathcal I_{A,g}+\operatorname{Consumed}_{A,g}=0\) (Supplement Equation (F5)), whence \(\operatorname{Consumed}_{A,g}\ge 0\) implies \(\mathcal I_{A,g}\le 0\). □

Equation (21) ensures that a settled repair obligation authorizes zero positive net extraction for any individual or coalition (while basic living consumption continues under basic standing and fresh labor, discoveries, or risk undertakings earn on their own new origins), complementing Roemer's static coalition criterion with a universal post-settlement boundary. [@Roemer1982, pp.194–198]

## 9 Clearing Costs: Attained Financial-Tail Optimality Versus Perpetually Improvable Complete Clearing

### 9.1 Zero Balance Is Not Archival: Formal Terminal Archival Across All Live Slots

In scalar double-entry bookkeeping—formalized in Pacioli difference groups by the equivalence \([x\!\mathbin{//}\!y]=[0\!\mathbin{//}\!0]\) whenever debits equal credits—a subtle institutional gap hides behind zero net balance: does balance zero mean an obligation has formally terminated? [@Ellerman2014; @Gao2026WholeLedger]

No. An explicit countermodel in our pinned sources (Table H, S13 and preserved excerpts) shows that a valid zero-quantity issuance leaves claim balance \(0\) while keeping a **live** obligation slot open; multiple slots from distinct origins can also share one \((j,d,h)\) address. Complete clearing therefore allocates payment sequentially across slots (later slots receiving only remainders), and after retiring all positive principal submits zero-amount closing settlements to every remaining live zero-principal slot, generating un-reopenable **terminal archive receipts**.

**Theorem 15 (Complete claim clearing and terminal archival across all financial positions).** For every ready clearing state satisfying recipe and settlement-stock conditions, a finite clearing programme zeroes the entire claim matrix and generates terminal archive receipts preserving original obligation content and full payment history across all live slots. Every subsequent financial run retains those identical archive receipts, and new debts require fresh occurrences and slots.

**Proof.** The clearing compiler concatenates ordered positive-principal settlements with a zero-amount boundary settlement generated by each remaining live zero-balance slot without requesting principal twice. Under settlement-resource readiness, every request in this finite clearing word passes validity step by step, zeroing the entire claim matrix and converting every live slot into a terminal archive preserving original obligation content and payment history (Supplement Section G.1); because the financial event type has no reopening constructor for archived slots, every subsequent run retains those receipts identically. □

### 9.2 Actual Cost Minimizer on Funded Financial Tails

How much real social resource cost does clearing existing debts require? The answer bifurcates sharply between funded financial tails and productive complete-clearing domains.

First consider a funded financial tail: a common incurred prefix \(h\) has already completed production and needs payment, and sufficient settlement goods are on hand at the cut. Cost accounts record productive inputs, production maintenance, technology revision, uses, cash transfers, and elapsed clock time; a linear readout \(J\) assigns arbitrary nonnegative weights to real resource channels and elapsed time (principal transfers cancel debt retirement rather than counting as resource destruction).

**Theorem 16 (Actual cost minimizer on a funded financial tail).** For every ready funded clearing state, existing institutional binding, and nonnegative readout \(J\), the account-generated clearing programme \(w_*\) satisfies against every finite policy programme \(w\) of that source:
\[
J(w_*)\le J(w),
\tag{22}
\]
while completing Theorem 15's all-slot archival, preserving institutional control, underlying state access, and the actual successor, and retaining incurred prefix costs by concatenation:
\[
J(h\mathbin{+\!\!+}w)=J(h)+J(w).
\tag{23}
\]

**Proof.** Programme \(w_*\) executes only settlements and archival using existing stocks, incurring zero extra production input, maintenance, or elapsed time; nonnegativity of every resource and time channel on any competing \(w\) yields \(J(w_*)=0\le J(w)\), and (23) preserves full-history cost comparison. □

### 9.3 Constructive Strict Improvement for Every Completing Candidate in a Productive Clearing Domain

Now consider a productive clearing domain where debt remains positive while settlement stock is zero, so production must precede settlement.

In our explicit two-party, two-good (\(g_0\) life/settlement, \(g_1\) production/maintenance) source (Supplement Sections G.2–G.3), the common incurred prefix \(h\) issues debt \(1\), transfers \(1\) unit of \(g_0\), and pays \(1\) life unit and \(1\) maintenance unit at prefix cost \(J(h)=2\), leaving zero \(g_0\) stock, unpaid debt \(1\), and \(5\) units of \(g_1\). Technologies indexed by \(n\in\mathbb N\) produce \(1\) unit of \(g_0\) from maintenance \(1\) plus input \(\varepsilon_n=1/(n+2)\) (with zero revision cost, zero microstep duration, and unit weights). Every three-step suffix \(w_n=[\operatorname{revise}(n),\,\operatorname{produce},\,\operatorname{settle}(1)]\) is valid (\(\varepsilon_n\le 1/2\le 5\)), clears all debt, preserves paid needs, and archives the slot across the six-step underlying state-resolution cycle at exact full-history cost
\[
J(h\mathbin{+\!\!+}w_n)
=3+\frac1{n+2}.
\tag{24}
\]

**Theorem 17 (Constructive strict improvement of every completing candidate).** In this complete-clearing source, for **every** finite programme \(w\) that clears the full claim matrix (not merely members of the displayed family \(\{w_n\}\)), an index \(n\in\mathbb N\) is computed directly from \(w\)'s own incurred tail cost such that \(w_n\) passes complete clearing, archival, and full-state execution verification while costing strictly less after the same prefix \(h\):
\[
J(h\mathbin{+\!\!+}w_n)
<
J(h\mathbin{+\!\!+}w).
\tag{25}
\]
Consequently, full-history clearing cost has infimum \(3\), **attained by no completing programme**.

**Decisive constructive proof.** Proceed in two steps:

1. **Strict tail lower bound \(c>1\) on any completion.** Let \(c=J(w)\) be the tail cost of any claim-clearing programme \(w\). At the cut, \(g_0\) stock is \(0\): issuance increases debt, assignment preserves total debt, and zero settlement cannot retire debt \(1\). Hence \(w\) **must contain at least one accepted production step**, paying maintenance \(1\) plus strictly positive input \(1/(m+2)>0\) for some technology \(m\) while all other entries have nonnegative cost, forcing \(c>1\).
2. **Constructing a cheaper replacement from \(w\)'s own cost gap.** From \(c\), define
\[
\delta=c-1>0,\qquad
n=\left\lceil\frac1\delta\right\rceil.
\tag{26}
\]
Because \(1/\delta\le n<n+2\), one has \(\varepsilon_n=1/(n+2)<\delta=c-1\). Replacing \(w\) after the identical prefix \(h\) with \(w_n\) gives
\[
J(h\mathbin{+\!\!+}w_n)=2+\Bigl(1+\frac1{n+2}\Bigr)<2+(1+\delta)=2+c=J(h\mathbin{+\!\!+}w),
\]
proving (25) without altering sunk prefix cost \(2\). Any purported least-cost completion \(w^\star\) would be strictly beaten by \(w_n\) computed from \(w^\star\) itself, a contradiction; meanwhile \(n=\lceil 1/\eta\rceil\) places full cost inside \((3,3+\eta)\) for every \(\eta>0\) (Figure 6). □

![Two clearing domains: funded financial-tail minimizer and strict improvement algorithm](figures/fig06-cost-v2-en.svg)

Figure 6: Bifurcation between clearing domains. Left (A): on a funded financial tail, executed programme \(w_*\) attains zero extra resource cost \(J(w_*)\le J(w)\) with full archival. Right (B): in the productive complete-clearing domain, discrete completions \(3+1/(n+2)\) (plotted for \(n=0,\dots,12\)) clear all debt and archive slots with unattained infimum \(3\); every completing candidate \(w\) yields a strictly cheaper completion via (26).

### 9.4 Institutional Division of Labor Between Completing Settlement and Continuing Improvement

Juxtaposing Theorems 16 and 17 resolves a recurring confusion in institutional economics: when settlement goods are on hand, clearing has an exact zero-waste optimum; when clearing couples to ongoing production, absence of a minimum reflects open-ended technical improvement rather than failure to settle. Society can neither cite “even cheaper future recipes” to default on payable obligations today, nor let one completed settlement freeze out strictly better methods tomorrow.

## 10 Whole-Ledger Transport Across Institutional Change, Locating Regeneration, and Five-Axis Synthesis

### 10.1 Injective Legacy-Row Transport and Material-Financial Conservation Across Finite Histories

Living institutions revise statutes, reconfigure coalitions, and span indefinite horizons. If changing rules could silently drop old responsibility rows or conjure unbacked physical stock, every conservation law above would leak at institutional boundaries.

Across institutional updates, each open responsibility row carries its request identity and natural-number progress budget; each step reads current stocks, member roster, financial accounts, and active law, processing pending financial items before new actions.

**Theorem 18 (Whole-ledger transport and confluence closure across arbitrary institutional histories).** At every finite cut of any actual institutional history, all existing responsibility rows are transported **injectively** by request identity along the actual successor, progress budgets never increase (zero refill), and settled rows remain zero. Every participant and good satisfy physical debit-credit conservation:
\[
\operatorname{stock}_{\mathrm{after}}
+\operatorname{debit}
=
\operatorname{stock}_{\mathrm{before}}
+\operatorname{credit};
\tag{27}
\]
and every instrument, debtor, and holder satisfy exact claim-matrix transport:
\[
F_{\mathrm{after}}
=
F_{\mathrm{before}}+\Delta F_{\mathrm{actual}}.
\tag{28}
\]
Every strictly positive net stock gain identifies an accepted positive-credit entry in the same execution report (external material supply likewise requires an accepted entry; issuing debt never creates physical stock). **No finiteness assumption is imposed on the prior responsibility ledger.** Moreover, for any cofinal confluence event already emitted by its source, each legacy row's nonincreasing natural-number budget attains its stable minimum at some occurred cut; the confluence procedure constructs the common carrier from those actual rows and checks lineage compatibility at registration, producing either the carrying row and first-write successor or an explicit cut, row, and lineage conflict.

Pistor examines how legal mechanisms sustain capital claims over time, and Shavell shows how limited assets constrain recovery. [@Pistor2019; @Shavell1986] Theorem 18 (Supplement Sections F.1 and F.3) gives the accounting invariant under institutional change: even an infinite prior ledger carries forward each debt in (28) and preserves stock provenance as specified in (27). [@Gao2026WholeLedger]

### 10.2 Locating the Exact Active Permission Discrepancy of Any Purported Capital Regeneration

What if someone claims that under an active public regime, a capital kernel \(C\) has quietly re-emerged? Theorem 19 proves that regeneration can never hide in vague organizational atmosphere: it must expose an exact ternary address where permissions diverged.

**Theorem 19 (Exact permission-discrepancy address of regenerated capital).** Under an active open public interpreter, any purported capital kernel witness on an execution explicitly identifies a concrete (technology, production port, affected participant) address at which the purported law denies access to the affected participant while the active public interpreter grants access.

**Proof.** By Theorem 4 and Section 3.1, extracting access evidence \(A\) from the purported kernel yields a private access asymmetry coordinate \((s,p,i)\) where the purported law evaluates \(a_{L_{\mathrm{claimed}}}(s,p,i)=0\); reading open port permissions of the active public interpreter at the identical technology, port \(p\), and participant \(i\) yields \(a_{L^{\mathrm{pub}}}(s,p,i)=1\). If the purported law coincides with the active interpreter, \(0=1\) refutes regeneration immediately; if a rule was covertly altered, the discrepancy is pinned to that exact ternary address. □

Lawful rule change remains fully open: the installed legislative procedure uses the root law's four-way disposition—presentation, reasoned refusal, full-ledger execution, and minimal coface revision triggered when an open responsibility hits expressive bankruptcy, carrying all legacy rows alongside the new direction on first write. [@Gao2026Society] Society retains continuous constitutional self-revision while forcing any attempt to re-install private exclusion gates to surface at an explicit port address.

### 10.3 Infinite Prior Ledgers Versus Dense Rational Costs: Well-Founded Stabilization

Notice the mathematical contrast between Section 9.3 and Section 10.1. In Section 9.3, productive clearing costs \(3+1/(n+2)\) take values in the dense rationals \(\mathbb Q\), allowing infimum \(3\) to remain unattained; in Section 10.1, each individual responsibility row's progress budget takes values in the well-founded natural numbers \(\mathbb N\) and never increases along actual successors, so without enumerating an infinite past, every legacy row stabilizes at its exact minimum at a finite occurred cut! Well-founded natural budgets guarantee rock-solid intertemporal accountability, while rational cost sequences keep technological improvement permanently open.

### 10.4 Five-Axis Synthesis: When Production and Risk Pricing Stop Testifying for Permanent Domination

Across a century of debates spanning classical political economy, theories of the firm, incomplete contracts, corporate finance, and commons governance, arguments for the inevitability of capitalism have revolved around five axes. Table 3 synthesizes the strongest form of each tradition alongside the exact judgment altered by Theorems 1–19.

| Theoretical axis | Representative primary works | Strongest classical insight & open gap | Judgment altered by Theorems 1–19 (`CF0–CF17`) |
| --- | --- | --- | --- |
| 1 Production relations, coalitions & reproduction | Marx (1867); Roemer (1982); Fraser (2016); Acemoglu & Restrepo (2019); Acemoglu (2025) | Separation & its reproduction, property-withdrawal exploitation, shifted care costs, productivity–wage divergence; lacked operational dominance iff & debt-carrying transition audit | Pins five-face support to `NoCapital ↔ NoAsymmetry` (Theorem 2); audits \(\Delta_{i,g}\ge 0\) with paid needs (Theorem 6); bars post-settlement extraction across all coalitions (Theorem 14) |
| 2 Firm direction, team 5-right bundle & control | Coase (1937); Alchian & Demsetz (1972); Grossman & Hart (1986); Hart & Moore (1990); Rajan & Zingales (1998) | Conscious direction saving market costs, team metering, asset exclusion & privileged resource access; treated exclusive control as price of coordination or investment | Theorem 8 replays every word \(w\) at equal length and identical full state \(s'\) without consent gates, unbundling all five classical firm rights and capturing non-title port gating |
| 3 Uncertainty, verification & ambiguity pricing | Knight (1921); Arrow (1962); Townsend (1979); Fama & Jensen (1983); Gilboa & Schmeidler (1989) | Unmeasurable uncertainty, open knowledge vs. R&D reward, costly verification & multiple-prior maxmin utility; bundled residual risk-bearing with permanent equity claims | Theorem 9 & Prop. 10 execute off-menu paid discovery (\(0\to 1\to 2\)); Theorem 11 caps origin receipts \(R_o\le Q_o\); Theorem 12 derives prior-free, utility-free minimal compensation \(q^*(s_{\mathrm{loc}})\) & 4-way split |
| 4 Dispersed knowledge, polycentricity & law coding | Hohfeld (1913); Böhm (1928); Hayek (1945); Ostrom (2009); Pistor (2019) | Unbundled jural relations, public-law revocation of private power, local knowledge, replaceable provision & legal modules of capital | Policies read paid local signals only; Theorem 4 decodes all legal wrappers; Theorems 5–7 complete replaceable handoffs in \(m(x)+1\) steps and rule out silent recurrence |
| 5 Capabilities, private government & ledgers | Hirschman (1970); Sen (1980); Shavell (1986); Ellerman (2014); Anderson (2015); Robeyns (2017); Hart & Zingales (2022) | Credible exit backing voice, conversion factors, judgment-proofness, difference-group accounting, workplace private government & shareholder welfare | Anchors standing in consequence-bearers; separates zero balance from archival (Theorems 15–17); blocks judgment-proof truncation and infinite-ledger erasure (Theorems 18–19) |

Table 3: Synthesis of theoretical engagements across five axes and the formal advances established in this paper.

Return one last time to the two-person workshop and laboratory of Example 1. Flipping port \(p_0\) from asymmetric exclusion \((1,0)\) to open access \((1,1)\) delivers every unit of output, loan settlement, and living provision across the five operational stages to the exact same terminal state; facing unknown external losses of \(2\) or \(4\) behind a single paid local signal, with zero guessed probabilities, the left endpoint \(q^*=4\) of the bilateral safe interval \([4,8]\) settles necessary risk compensation uniquely—neither shortchanging the risk-bearer, nor letting \(7\) or \(100\) masquerade as necessary risk pricing, nor leaving behind a shred of permanent authority over later participants.

Near the close of his treatise, Roemer asked whether the functional need to reward accumulation and risk-bearing could ever justify the continuing income and dominance of a specific class of capitalists. [@Roemer1982, pp.276–278] Across nineteen formal propositions covering every constructor form of capital, our verdict is exact: **productive coordination requires coherent rules and open ports, past contributions require origin-bounded repayment, and unknown risk requires the unique minimal transfer closest to zero inside the same-signal bilateral safe envelope—whereas private exclusionary domination over others' labor and conditions of life is structurally superfluous to every one of those functions.** Once necessity of production and uncertainty of innovation cease to testify on behalf of permanent control, human beings can settle what is owed from the past and step into unknown futures as free equals.

## Formal Proofs and Reproducible Materials

The definitions, nineteen numbered results, two hand-checkable examples, six bilingual vector figures, and Technical Supplement Sections A–H form a self-contained written proof architecture. Supplement Sections A–H provide complete derivations and fixed-declaration mappings for three-leg capital evidence, the five-face minimal-support equivalence, total constructor recompilation, self-proved registration and \(m(x)+1\) finite-step disposition, position-wise public replay, off-menu two-round innovation and origin receipt bounds, same-signal bilateral safe intervals and unique minimal risk compensation (`CF17`), complete income decomposition and all-coalition post-settlement bounds, dual clearing-cost regimes, and cross-institutional ledger transport.

The formal proofs use two fixed research revisions. CF0–CF16 from the [first edition](https://doi.org/10.5281/zenodo.23927949) use Homework `df421ff600085cbc290a7ae946193961bed7c83b` and the H0mework [fixed proof snapshot](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) for `EconomicConstitutionSourceDF`, with the [first-edition claim map](https://github.com/Sapientropic/H0mework/blob/7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6/docs/capital-formation-map.json). CF17 uses Homework `7c228ac7fd77350d3fe761c24b887cbf2f6e5afc` and the H0mework [fixed proof snapshot](https://github.com/Sapientropic/H0mework/tree/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e) for `SocietyBookRiskCompensation`. The [risk-compensation map](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/checks/society-book-map.json) and [public reproduction guide](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/docs/society-book-reproduction.md) locate the declarations and checks for Theorem 12, Example 2, and Supplement Section E.3. The proof packages use Lean's standard axioms `propext`, `Classical.choice`, and `Quot.sound`.

## References

[Marx1867] Marx, Karl. *Capital: A Critique of Political Economy*, vol. I. 1867. English edition, 1887, translated by Samuel Moore and Edward Aveling, edited by Friedrich Engels. [Chapters 6, 23, 26](https://www.marxists.org/archive/marx/works/1867-c1/).

[Hohfeld1913] Hohfeld, Wesley Newcomb. “Some Fundamental Legal Conceptions as Applied in Judicial Reasoning.” *The Yale Law Journal* 23(1), 1913: 16–59. [doi:10.2307/785533](https://doi.org/10.2307/785533).

[Knight1921] Knight, Frank H. *[Risk, Uncertainty, and Profit](https://www.econlib.org/library/Knight/knRUP.html)*. Boston and New York: Houghton Mifflin, 1921. Part III, chapters VII and IX.

[Bohm1928] Böhm, Franz. “[Das Problem der privaten Macht. Ein Beitrag zur Monopolfrage](https://api.pageplace.de/preview/DT0400.9783161514760_A27134534/preview-9783161514760_A27134534.pdf#page=59).” In *Grundtexte zur Freiburger Tradition der Ordnungsökonomik*, edited by Nils Goldschmidt and Michael Wohlgemuth, 49–67. Tübingen: Mohr Siebeck, 2008 [1928].

[Coase1937] Coase, R. H. “The Nature of the Firm.” *Economica* 4(16), 1937: 386–405. [doi:10.1111/j.1468-0335.1937.tb00002.x](https://doi.org/10.1111/j.1468-0335.1937.tb00002.x).

[Hayek1945] Hayek, F. A. “[The Use of Knowledge in Society](https://www.econlib.org/library/Essays/hykKnw.html).” *American Economic Review* 35(4), 1945: 519–530.

[Arrow1962] Arrow, Kenneth J. “[Economic Welfare and the Allocation of Resources for Invention](https://www.nber.org/system/files/chapters/c2144/c2144.pdf).” In *The Rate and Direction of Inventive Activity: Economic and Social Factors*, 609–626. Princeton University Press for NBER, 1962.

[Hirschman1970] Hirschman, Albert O. *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Cambridge, MA: Harvard University Press, 1970.

[AlchianDemsetz1972] Alchian, Armen A., and Harold Demsetz. “[Production, Information Costs, and Economic Organization](https://www.jstor.org/stable/1815199).” *American Economic Review* 62(5), 1972: 777–795.

[Townsend1979] Townsend, Robert M. “Optimal Contracts and Competitive Markets with Costly State Verification.” *Journal of Economic Theory* 21(2), 1979: 265–293. [doi:10.1016/0022-0531(79)90031-0](https://doi.org/10.1016/0022-0531(79)90031-0).

[Sen1980] Sen, Amartya. “[Equality of What?](https://tannerlectures.org/documents/sen80/)” In *The Tanner Lectures on Human Values*, vol. 1, edited by Sterling M. McMurrin, 197–220. Cambridge University Press, 1980. Lecture delivered 22 May 1979.

[Roemer1982] Roemer, John E. *A General Theory of Exploitation and Class*. Cambridge, MA, and London: Harvard University Press, 1982. [doi:10.4159/harvard.9780674435865](https://doi.org/10.4159/harvard.9780674435865).

[FamaJensen1983] Fama, Eugene F., and Michael C. Jensen. “Agency Problems and Residual Claims.” *The Journal of Law and Economics* 26(2), 1983: 327–349. [doi:10.1086/467038](https://doi.org/10.1086/467038).

[GrossmanHart1986] Grossman, Sanford J., and Oliver D. Hart. “The Costs and Benefits of Ownership: A Theory of Vertical and Lateral Integration.” *Journal of Political Economy* 94(4), 1986: 691–719. [doi:10.1086/261404](https://doi.org/10.1086/261404).

[Shavell1986] Shavell, Steven. “The Judgment Proof Problem.” *International Review of Law and Economics* 6(1), 1986: 45–58. [doi:10.1016/0144-8188(86)90038-4](https://doi.org/10.1016/0144-8188(86)90038-4).

[GilboaSchmeidler1989] Gilboa, Itzhak, and David Schmeidler. “Maxmin Expected Utility with Non-Unique Prior.” *Journal of Mathematical Economics* 18(2), 1989: 141–153. [doi:10.1016/0304-4068(89)90018-9](https://doi.org/10.1016/0304-4068(89)90018-9).

[HartMoore1990] Hart, Oliver, and John Moore. “Property Rights and the Nature of the Firm.” *Journal of Political Economy* 98(6), 1990: 1119–1158. [doi:10.1086/261729](https://doi.org/10.1086/261729).

[RajanZingales1998] Rajan, Raghuram G., and Luigi Zingales. “Power in a Theory of the Firm.” *The Quarterly Journal of Economics* 113(2), 1998: 387–432. [doi:10.1162/003355398555630](https://doi.org/10.1162/003355398555630).

[Ostrom2009] Ostrom, Elinor. “[Beyond Markets and States: Polycentric Governance of Complex Economic Systems](https://www.nobelprize.org/uploads/2018/06/ostrom_lecture.pdf).” Nobel Prize Lecture, 8 December 2009.

[Ellerman2014] Ellerman, David. “On Double-Entry Bookkeeping: The Mathematical Treatment.” *Accounting Education* 23(5), 2014: 483–501. [doi:10.1080/09639284.2014.949803](https://doi.org/10.1080/09639284.2014.949803).

[Anderson2015] Anderson, Elizabeth. “[Liberty, Equality, and Private Government](https://tannerlectures.utah.edu/_resources/documents/a-to-z/a/Anderson%20manuscript.pdf).” *The Tanner Lectures on Human Values*, delivered at Princeton University, 4–5 March 2015.

[Fraser2016] Fraser, Nancy. “[Contradictions of Capital and Care](https://newleftreview.org/issues/ii100/articles/nancy-fraser-contradictions-of-capital-and-care).” *New Left Review* 100, 2016: 99–117.

[Robeyns2017] Robeyns, Ingrid. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Cambridge: Open Book Publishers, 2017. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[AcemogluRestrepo2019] Acemoglu, Daron, and Pascual Restrepo. “Automation and New Tasks: How Technology Displaces and Reinstates Labor.” *Journal of Economic Perspectives* 33(2), 2019: 3–30. [doi:10.1257/jep.33.2.3](https://doi.org/10.1257/jep.33.2.3).

[Pistor2019] Pistor, Katharina. “Coding Capital for the Globe.” *Stanford Social Innovation Review*, 4 September 2019. Excerpt from *The Code of Capital*. [doi:10.48558/GYV7-NE54](https://doi.org/10.48558/GYV7-NE54).

[HartZingales2022] Hart, Oliver, and Luigi Zingales. “[The New Corporate Governance](https://businesslawreview.uchicago.edu/print-archive/new-corporate-governance).” *The University of Chicago Business Law Review* 1(1), 2022: 195–216.

[Acemoglu2025] Acemoglu, Daron. “The Simple Macroeconomics of AI.” *Economic Policy* 40(121), 2025: 13–58. First published online 6 August 2024. [doi:10.1093/epolic/eiae042](https://doi.org/10.1093/epolic/eiae042).

[Gao2026WholeLedger] Gao, Jian (高健). *Book-Balancing Magic Has Nowhere to Hide: Source-Native Accounting and Actual Continuation (平账魔法别想逃：源生整账与真实续行)*. Version 1. Preprint. Zenodo, 2026. [doi:10.5281/zenodo.23437454](https://doi.org/10.5281/zenodo.23437454).

[Gao2026Society] Gao, Jian (高健). *The Canonical Society Theorem (典范社会总定理)*. Version 2. Preprint. Zenodo, 2026. [doi:10.5281/zenodo.23917896](https://doi.org/10.5281/zenodo.23917896).

[Gao2026Constitution] Gao, Jian (高健). *An Economic Constitution of Possibility (可能性的经济宪法)*. Version 2. Preprint. Zenodo, 2026. [doi:10.5281/zenodo.23917902](https://doi.org/10.5281/zenodo.23917902).
