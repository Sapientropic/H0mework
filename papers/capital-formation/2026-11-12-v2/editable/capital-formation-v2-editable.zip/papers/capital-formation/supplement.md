# 资本主义的结构总定理：技术附录

## A 同一执行上的资本证据

本附录展开正文的形式对象定义、决定性证明与固定源码对应。参与者、物品、生产端口、技术与金融工具分别取具有可判等结构的类型 $I,G,P,T,F$。法则 $L$ 规定请求的有效性、端口准入、物量借贷作用、金融更新及生活维护需求。状态 $s$ 保存库存 $x_s(i,g)$、请求权矩阵 $b_s(f,d,h)$、当前技术、物理时钟和轮次。有限请求序列 $w$ 在法则 $L$ 与状态 $s$ 下的执行清单定义为
\[
E_L(s,w)=\bigl[(j,s_j,r_j)\bigr]_{j<|w|}.
\tag{A1}
\]
每个清单项同时记录位置索引 $j$、请求前状态 $s_j$ 与请求 $r_j$；未通过检查而被拒绝的请求同样保留自身位置。记 $N_L(s,w)$ 为包含库存、请求权、技术与时钟更新在内的完整后态。单期资本证据中的发生地址均指向式（A1）的清单位置；跨期证据则同时保存历史访问序号与该次访问内的清单位置。

### A.1 需要取得与私人准入差异

设端口 $p$ 在状态 $s$ 的技术分量下由 $c_L(s,p)$ 控制，参与者 $i$ 的布尔准入读数为 $a_L(s,p,i)\in\{0,1\}$。私人准入差异定义为
\[
\operatorname{Private}_L(s,p,i)
\ \Longleftrightarrow\
a_L(s,p,c_L(s,p))=1\ \land\ a_L(s,p,i)=0.
\tag{A2}
\]
式（A2）刻画控制许可层的不对称关系。一项关系成为资本，还须使该准入差异实际嵌入参与者的生活维护需要与经济回流回路。

准入候选 $A$ 指定取得项 $e_a$、需要项 $e_n$、受影响者 $i$、取得物持有人 $h$、生产端口 $p$、取得物 $g_a$、需要物 $g_n$，以及连接两者的物量交付路线。检查谓词 $\operatorname{Check}_A(A)$ 要求同时满足四项条件：

1. $e_a$ 在其请求前状态实际有效，且端口 $p$ 属于该请求实际调用的必需端口。
2. 在 $e_a$ 的请求前状态与整段执行的完整后态 $N_L(s,w)$ 上，$\operatorname{Private}_L(-,p,i)$ 均成立。
3. $e_n$ 是对受影响者 $i$ 的有效生活或维护使用，指定物品数量严格为正，且物品束恰好等于法则在该状态规定的生活或必要维护束。
4. 取得与需要之间由以下两种方式之一连接：**间接取得型**要求 $e_a$ 对 $(h,g_a)$ 产生实际正贷记，且存在由后续已接受执行项组成的时序交付路线将其连接到 $e_n$ 上的 $(i,g_n)$；**直接使用型**要求 $e_a$ 与 $e_n$ 为同一位置、$h=i$、$g_a=g_n$、交付路线为空，且具有对应的实际正借记。

由于交付路线仅由已接受的实际分录按严格先后顺序构成，需要依赖始终绑定具体当事人、具体物量与确切发生位置，不能由抽象资产估值替代。证明来源见表 H 的 S1。

### A.2 对价回流与可行处分

反向经济关系 $R$ 在同一执行清单 $E_L(s,w)$ 上有三种穷尽构造：

| 回流构造 | 实际检查条件 |
| --- | --- |
| 生产投入 | 有效生产项实际调用端口 $p$ 且位置不晚于取得项；非空实际交付路线将受影响者的物量送入生产者的某项正投入 |
| 实物返流 | 非空实际交付路线将受影响者的物量送达取得项对应的控制者，且整条路线在该有限执行序列内完成 |
| 金融请求 | 有效发行或转让请求具有严格正数量，控制者为受益持有人；发行时受影响者为债务人，转让时受影响者为债务人或转出方 |

可行处分候选 $D$ 指定该执行已到达的某个中间状态，以及一项在该状态可独立通过有效性检查的局部替代请求。该请求由权利持有人本人签署，无需额外附加控制者同意，内容可为持有人的外部使用或投资使用、向持有人的正数量实物转移，或由持有人向他人转让正数量金融请求权；持有人身份亦可沿同一历史中的有效分配链更新，且处分发生处仍保持针对受影响者的私人准入差异。

三腿证据通过共同索引耦合为资本关系核心类型：
\[
C(L,s,w)=
\{(A,R,D):\operatorname{Check}_A(A)
\land\operatorname{Check}_R(A,R)
\land\operatorname{Check}_D(A,D)\}.
\tag{A3}
\]
其中 $A$ 与 $R$ 记录已经发生的需要取得与经济回流，$D$ 记录持有人在已达状态上可独立行使的支配权能。尚未清偿的正额债务即可承担金融回流，账面盈利、净储备增长或后续试验成功均非式（A3）的前提（S1）。

### A.3 可转移资产权、实际剩余占有与跨期谱系

**可转移资产控制**在核心 $C$ 之上增加同一端口的改权转移证据：存在已发生或在该中间状态局部可行的有效改权请求，将端口控制者由 $h$ 变更为 $h'\ne h$，使 $h$ 原获准而改权后被拒、$h'$ 改权后获准。不可与人身分离的固定身体权限不满足控制者可替换条件，从而不会与资本资产权混淆。

**实际剩余占有**在核心 $C$ 之上增加已经发生的占有记录，穷尽五类形态：消费、投资、期末留存、经受控路线的消费，以及金融返流。消费与投资认回实际借记物量；留存同时核验取得、后续借记与终点正库存；金融返流必须与核心 $C$ 中同一笔金融请求权的发行来源地址严格对齐。未行使的报价或账面重估不构成实际剩余占有。

**跨期资本与当期历史控制**把准入、需要、回流与处分地址放入多期访问历史：产权报价、留存、消费或投资证据可跨越不同访问阶段，终点仍保有当前控制者获准、当前受影响者被拒的不对称关系；当历史资本在当期实际行使控制（$\operatorname{ControlUse}$）时，当期请求须有效且实际调用该端口，并排除某名当期物量受益人、生产者、需要承担者或金融承担者。主体与关系的出生记录由首次准入发生唯一生成，沿任意后继查找保持恒等；更换资产持有人不篡改关系起源，按访问序号筛选新增循环亦不会把旧准入重复计为新生控制（S2）。

## B 最小支撑、完整重构与全称范围

### B.1 五面无资本合同的两向充要证明

对任意法则 $L$，定义端口权限无不对称谓词：
\[
\operatorname{NoAsymmetry}(L)
\Longleftrightarrow
\forall s,p,i,\ 
a_L(s,p,c_L(s,p))=1\Rightarrow a_L(s,p,i)=1.
\tag{B1}
\]
完整无资本条件 $\operatorname{NoCapital}(L)$ 同时排除五层见证：（1）私人准入差异；（2）资本关系核心；（3）可转移资本资产权；（4）五类实际剩余占有；（5）同一有效法则下新发生的当期历史控制。

**命题B1。** 对任意具有规定可判等对象类型的权限法则 $L$，
\[
\operatorname{NoCapital}(L)\Longleftrightarrow
\operatorname{NoAsymmetry}(L).
\tag{B2}
\]

**证明。** 若 $\operatorname{NoCapital}(L)$ 成立，其第一分量对全部 $(s,p,i)$ 排除式（A2）。任取 $(s,p,i)$ 并设 $a_L(s,p,c_L(s,p))=1$；若 $a_L(s,p,i)=0$，则式（A2）直接成立，矛盾。因准入取值于 $\{0,1\}$，必有 $a_L(s,p,i)=1$，即得式（B1）。

反之，设式（B1）成立，则对任意 $(s,p,i)$ 均不可能出现 $a_L(s,p,c_L(s,p))=1\land a_L(s,p,i)=0$，故全部私人准入差异被排除。任一资本核心 $C=(A,R,D)$ 的 $\operatorname{Check}_A(A)$ 均内含式（A2），故资本核心类型为空；可转移资本资产权与实际剩余占有各自携带一枚基础资本核心依赖，随之为空；当期历史控制同样要求对当期受影响者成立式（A2），亦为空。五层排除同时得证。□

最小支撑的非空锐性由材料齐备的四格权限族独立兑现：固定同一真实库存、需要、生产指令与金融材料，仅参数化控制者与受影响者的两枚准入布尔值。对任意时钟与轮次，资本核心存在当且仅当控制者获准（$1$）且受影响者被拒（$0$）；在零时钟、零轮次起点，将受影响者准入翻转为 $1$ 还完整保持全部执行分录与后态不变（S3）。

### B.2 全部构造输入的精确重编译与自身恢复

重编译程序按固定顺序依次运行准入、回流与处分三道检查：全部通过时输出保留原提案的资本核心见证，否则返回首个未通过的检查条件。故对任意核心构造提案 $q$，
\[
\begin{aligned}
&\left(\exists c,\ \operatorname{compile}(q)=\operatorname{some}(c)
\land c.\operatorname{proposal}=q\right)\\
&\qquad\lor\neg\operatorname{Check}_A(q)
\lor\neg\operatorname{Check}_R(q)
\lor\neg\operatorname{Check}_D(q).
\end{aligned}
\tag{B3}
\]
三种回流构造穷尽输入和类型，式（B3）覆盖整个构造空间。实际剩余占有与跨期历史资本各自具有同构的总编译析取式。

**命题B2。** 任意已成立的封装资本见证 $c$ 均由其自身保存的提案字段精确重构为自身：
\[
\operatorname{compile}(c.\operatorname{proposal})
=\operatorname{some}(c),
\tag{B4}
\]
且五类实际剩余占有与四类跨期历史资本见证均满足对应自身恢复等式。

**证明。** 展开封装见证 $c$ 的构造子即可取出提案字段及其已通过的各项有效性证明；将其代回确定性编译函数 $\operatorname{compile}$，全部检查分支取真并按原字段组装返回原值 $c$，无需外接任何附加见证。受控贡献再生产见证同样反解回同一次执行中的受控端口需要与回流证据；统一控制族进一步证明：同一分录上的产权发现、实际剩余发现或历史发现连同私人准入差异（或当期历史控制）与族成员资格充要等价，当期控制使用在此基础上叠加请求有效性与端口实际调用检查（S3、S4）。□

## C 任意资本关系的社会接入与有限步处置

### C.1 由资本证据内生证明正登记

制度程序来源 $X$ 包含法则、初态，以及静态指令列表或动态发射程序；记其登记规模为 $r(X)$，在状态 $s$ 发出的执行词为 $w_X(s)$。

**命题C1。** 对任意程序来源 $X$、状态 $s$ 及任意资本核心见证
\[
c:C(X.L,s,w_X(s)),
\]
必有 $r(X)>0$，并由该正登记直接生成完整社会资本处置合同；任意当期控制使用见证亦然。

**证明。** 若 $X$ 由动态发射器构成，其发射登记规则直接给出 $r(X)>0$。若 $X$ 由静态指令表构成，则 $r(X)$ 等于指令表长度；倘若长度为 $0$，则 $w_X(s)$ 与执行清单 $E_{X.L}(s,w_X(s))$ 均为空表，但 $c$ 的准入证据 $A$ 包含清单中的确切取得项地址，矛盾。故 $r(X)>0$ 恒由资本见证自身导出，无需向定理前提外加“已获登记”假设；六类资本形态（工业、照护、金融、平台、零雇佣自动化、技术升级型国家资本）均由此进入统一社会处置合同，而共同合作生产、个人直兑公共信用与自主家计自给三类非资本对照源则经可判定核验确认统一控制列表为空（S5）。□

### C.2 金融入口的精确核对与分派

社会接入在初始边界比较程序来源的初始请求权矩阵与创生逐槽账户表示：
\[
B_X=\operatorname{claims}(X.\operatorname{initial}),
\qquad B_{\mathrm{native}}(X).
\tag{C1}
\]
创生金融账户满足 $B_{\mathrm{native}}(X)=0$。当 $B_X=B_{\mathrm{native}}(X)$ 时，来源以零初始未表债务进入逐期终止、公共替代、初始选择、可用续期与未来扩张合同，此后历史中真实发行的债务逐笔入槽追踪；当两者不等时，程序精确交出差额坐标
\[
\exists f,d,h,\quad B_X(f,d,h)\ne B_{\mathrm{native}}(X)(f,d,h),
\tag{C2}
\]
并完整保留输入来源、社会法则与实际运行后继，杜绝借空账户抹消既有历史债务（S5）。

### C.3 内部工作量上界与三项联合废止审计

设实际运行状态序列为 $z_t$，单步确定性后继算子为 $T$。当前待处理内部工作量 $m(z_t)\in\mathbb N$ 度量待消费内部队列长度。内部处理步每步严格减少一个待办位置，故至多经 $m(z_t)$ 步即抵达制度审查边界；边界选择再至多耗用一步即产出公共执行状态或具名初始审查阻塞。从而对任意截点 $z_t$，
\[
\exists k\le m(z_t)+1,\quad
\operatorname{CompleteDisposition}(z_{t+k}).
\tag{C3}
\]

完整处置在尚未进入公共执行时保留初始替代审查阻塞及既有责任行与未支预算；已进入公共执行时依次核验三项条件：

| 审计分项 | 通过判据 | 未通过时保留的精确对象 |
| --- | --- | --- |
| 全账户金融审计 | 逐人逐物量完整净差额 $\Delta_{i,g}\ge 0$，且至少一格严格大于 $0$ | 同一当前全账上的具体金融未过项 |
| 成员实际迁移 | 首次公共执行独立有效、全员生活维护实付、产能保持且零新增控制 | 首次公共执行及当时名册上的具体迁移缺口 |
| 当前可执行未来 | 自适应编译从当前快照生成有效续行方案并付清当前名册全员需要 | 当前生成候选集上各方案的具体检查失败 |

全账户金融审计从转入公共执行的共同起点出发，令转换前的来源在原法则下按公共经历的相同轮数逐期读取自身状态并生成基准执行。设两端终点库存为 $S^{\mathrm{pub}},S^{\mathrm{base}}$，债务矩阵差为 $\Delta F=F^{\mathrm{pub}}-F^{\mathrm{base}}$，金融工具 $j$ 的指定结算品与正结算率为 $(u_j,r_j)$，则债务矩阵差折算到人—物坐标的估值为
\[
V_L(\Delta F)_{i,g}
=\sum_{j,d,h}\Delta F(j,d,h)r_j\,
\mathbf{1}_{\{g=u_j\}}
\bigl(\mathbf{1}_{\{i=h\}}-\mathbf{1}_{\{i=d\}}\bigr),
\]
其中有限和遍历双侧实际金融分录产生的有限差额支撑。完整差额 $\Delta_{i,g}=(S^{\mathrm{pub}}-S^{\mathrm{base}})_{i,g}+V_L(\Delta F)_{i,g}$ 将现金偿付的库存减少与同额本金退休在同一结算品坐标合并相抵，既不把偿债误判为受损，也不把借新债误判为净增。审计同时核验相关结算率为正、比较窗口为正且双方终点时钟一致。任意满足 $y_0=z_t$ 与 $y_{n+1}=T(y_n)$ 的合法路径由归纳法满足 $y_n=T^n(z_t)=z_{t+n}$，故在第 $k$ 步必然认回同一完整处置（S6）。

### C.4 排除无审查阻塞的反复控制吸收路径

所谓“无审查欠付的反复控制吸收路径”，是指沿同一后继算子 $T$ 同时满足
\[
\forall n,\ \exists m\ge n:\operatorname{FreshControl}(z_m),
\qquad
\forall n,\ \operatorname{ReviewClosed}(z_n).
\tag{C4}
\]
其中第一式表示每个尾段仍有新资本控制再现，第二式表示在尚未进入公共模式的每个边界均未留下初始替代审查阻塞。由式（C3）取有限步处置位置 $z_{t+k}$：若留下初始审查阻塞，则直接违背 $\operatorname{ReviewClosed}$；若进入公共模式，运行时持久性引理保证后续每一步均沿用全开放端口解释，从而整个公共尾段不再产生任何新资本核心或当期控制使用，直接违背尾段无限再现条件。两支穷尽，式（C4）恒不可满足，且既有债权与历史前缀沿整条后继保持（S6）。

## D 一般公共功能重放与实际选择

### D.1 逐位置请求变换与状态恒等

令开放解释 $L^\circ$（正文记为 $L^{\mathrm{pub}}$）保留原法则 $L$ 的全部物量借贷、金融结算、技术配方、生活维护标准与时钟规则，仅将端口准入设为开放并将操作政策设为不受限。对任意状态 $s$ 与单步请求 $r$，定义逐位置重放变换：
\[
\rho_L(s,r)=
\begin{cases}
\text{保留原操作与签署者、清空控制者同意列表的请求},&
\operatorname{Valid}_L(s,r),\\
\text{保留原签署者与用途标签的零作用呈示},&
\neg\operatorname{Valid}_L(s,r).
\end{cases}
\tag{D1}
\]
再沿原法则单步状态转移 $\operatorname{step}_L$ 对有限词递归生成整词重放：
\[
\begin{aligned}
\mathcal R_L(s,[])&=[],\\
\mathcal R_L(s,r::w)&=
\rho_L(s,r)::\mathcal R_L(\operatorname{step}_L(s,r),w).
\end{aligned}
\tag{D2}
\]
在已接受分支中，撤去私人同意门且端口开放后，原操作与资源检查完全保持；在被拒绝分支中，原请求与零作用呈示均不改变状态、不产生借贷分录。故单步转移恒满足
\[
\operatorname{step}_{L^\circ}(s,\rho_L(s,r))
=\operatorname{step}_L(s,r).
\tag{D3}
\]

**命题D1。** 对任意法则 $L$、状态 $s$ 与有限词 $w$，公共重放严格保持词长、完整后态与执行清单逐项映射：
\[
\begin{aligned}
|\mathcal R_L(s,w)|&=|w|,\\
N_{L^\circ}(s,\mathcal R_L(s,w))&=N_L(s,w),\\
E_{L^\circ}(s,\mathcal R_L(s,w))&=
\operatorname{map}(\widehat\rho_L,E_L(s,w)),
\end{aligned}
\tag{D4}
\]
其中 $\widehat\rho_L(j,s_j,r_j)=(j,s_j,\rho_L(s_j,r_j))$。

**证明。** 对 $w$ 作结构归纳：空词显然成立；对 $r::w$，式（D3）保证首步到达完全相同的下一状态，归纳假设随即给出余词的长度、后态与清单映射等式，完整周期收尾亦按相同词长与相同终态同步更新时钟与轮次。□

### D.2 生活维护支付与任务服务适足的充要保持

对任意成员名册 $M$，全员生活维护支付满足双向充要等价：
\[
\operatorname{AllNeedsPaid}_{L^\circ}
(s,M,\mathcal R_L(s,w))
\Longleftrightarrow
\operatorname{AllNeedsPaid}_L(s,M,w).
\tag{D5}
\]
这是因为原词中的有效使用项在 $\rho_L$ 下保留同一使用者、物品束与用途；反之，重放词中的有效使用项绝不可能来自零作用呈示，必可唯一反解回原词同位置的已接受使用项。对单人生活束与维护束分别应用该双射并对 $M$ 取合取即得式（D5）。任务服务适足性（指定使用者、物品束、用途及时间窗口）同理结合式（D4）的终点时钟恒等得到充要等价；同时 $L^\circ$ 全端口开放直接排除私人准入差异与资本核心（S7）。

### D.3 从功能存在性到当前运行的实际选中与续期

当候选集合中存在同时通过全账户改进检查与执行后未来可行性检查的公共方案时，初始选择器实际接纳该方案，并在首个公共快照上生成完整废止见证。进入公共模式后，只要当前内部待办排空且自动提案为推进，任何通过完整改进与后态可行检查的续期候选均被编译器唯一选中并实际执行，其后继快照即刻生成新一期完整废止见证（S6）。

## E 事前创新、贡献累计上界与源生成风险定价

### E.1 事前固定机制、菜单外两轮发现与生活续期门

试验机制 $M$ 先于未知事件固定法则、局部程序、签署融资词、投资请求、观察收费、局部策略与收尾动作，随后接收任意请求类型的实际未知事件 $\nu\in\operatorname{Nature}(M)$。事前报价菜单仅读取有限事件语法 $\operatorname{QuotedNature}(M)$，而机制处置覆盖全部开放事件：
\[
\forall M\ \forall \nu\in\operatorname{Nature}(M),\quad
\operatorname{Disposition}(M,\nu).
\tag{E1}
\]
在声明权重参与接口中，若参与者给定归一化非负声明权重、成功权重 $p>0$、加权失败损失 $\ell$、外部机会 $a$ 与附加报酬 $b\ge 0$，则报价公式为
\[
r=\frac{\ell+a+b}{p},\qquad
\mathbb E_{\mathrm{declared}}[\Delta]=a+b.
\tag{E2}
\]
该式刻画声明权重下的算术参与条件，但其外填参数 $(p,a,b)$ 不自动授予源内必要风险补偿权限（后者由下节 E.3 严格内生决定）。

两轮连续实付实例在同一机制链上依次完成融资到账、物量投资 $3$、消息资源消耗 $3$（含正借记观察费 $1$）与全员生活维护实付，使技术从 $0$ 升至 $1$ 再升至 $2$：第二轮起点原型库存归零，技术 $2$ 不属于任一轮事前报价菜单，旧债地址 $(\text{工具},0,2)$ 的余额 $1$ 贯穿保留。续期释放门 `paidNextTrial?` 在本期执行后逐人核查生活与维护实付；若下期提案可付但本期生活欠付，门禁精确阻断释放并保留欠付承担者（S8）。

### E.2 逐槽本金守恒与按发行来源的全槽累计上界

设账户状态 $q$ 中槽位 $j$ 的剩余本金为 $P_j(q)\ge 0$。沿任意有限金融运行 $\gamma:q_0\leadsto q_1$，记槽位 $j$ 的累计实际退休本金为
\[
R_j(\gamma)=\sum_{e\in\gamma}
\mathbf1_{\{\operatorname{slot}(e)=j\}}\,
\operatorname{actualPaid}(e).
\tag{E3}
\]
转让仅改变持有人归属，新发行另立新槽，空等待不退休本金，已终结归档槽在事件类型中无重开构造。

**命题E1。** 对起始状态 $q_0$ 已存在的任意槽位 $j$，
\[
P_j(q_1)+R_j(\gamma)=P_j(q_0).
\tag{E4}
\]

固定起始截点 $q_0$ 已登记的贡献发行来源 $o$ 及其原始发行量 $Q_o$，定义终点全部槽位上归属来源 $o$ 的累计实际受领量：
\[
R_o(\gamma)
=\sum_{\substack{j<|\operatorname{slots}(q_1)|\\
\operatorname{origin}(q_1,j)=o}}R_j(\gamma).
\tag{E5}
\]
程序来源利用发生地址的严格全序以及静态登记、实际准入与公共续行互不相交的来源标签生成来源唯一性，账户运输保持标签且不重复发行，故终点至多存在唯一槽位携带来源 $o$。将式（E5）化归至式（E4）并结合 $P_j(q_1)\ge 0$ 与 $P_j(q_0)\le Q_o$，即得全槽累计受偿界：
\[
\boxed{R_o(\gamma)\le Q_o.}
\tag{E6}
\]
取起始截点为刚完成发行准入之刻，即得从发行起的完整累计上界，直接排除由单次历史贡献支付任意无界需求序列 $d_n>Q_o$ 的可能；新的劳动、发现与风险承担各自创立新来源账户（S9）。

### E.3 同局部信号的双边安全区间、唯一最小支付与四分准入（CF17）

本节给出正文第 7.5 节定理 12（`CF17`）的完整数学构造与证明，源码归属见表 H 的 S17。

**第一层：零外填参数的可执行外部替代基准。** 在未知事件到来前，事前准备程序将提议机制重新绑定至当前运行截点的有效法则、真实库存与完整成员名册，不读取提议机制自带的旧初态或旧权限解释器。在来源行动字母表与动作步数预算 $B\in\mathbb N$ 内，有限候选词 $u$ 通过外部基准检查当且仅当：（1）每步请求有效；（2）全体成员生活与维护实付；（3）独立执行且保持生产能力；（4）本词无新增控制；（5）全词非金融，从而完整保持既有请求权矩阵不变。有限候选集非空当且仅当存在至少一条此类真实替代程序；此时提供方（出资／担险方 $P$）与付款方（使用／借款方 $B$）在指定工具结算品上的外部替代基准 $a_P,a_B\in\mathbb Q$ 分别取该可行集上完整账户收入（与可计算读数逐项等价）的精确达到最大值。例 2 的单物品日程中，生活维护各耗用 $1$，合法替代程序使 $a_P=a_B=-1$。若预算内找不到合格替代词，程序逐候选给出阻滞。

**第二层：同付费局部信号纤维上的双边安全包络。** 对已付费局部信号 $s_{\mathrm{loc}}$，记报价事件域中产生该信号的全部风险分支纤维为
\[
\Omega(s_{\mathrm{loc}})
=\bigl\{\omega\in\operatorname{QuotedNature}(M):
\operatorname{paidSignal}(\omega)=\operatorname{some}(s_{\mathrm{loc}})\bigr\}.
\]
对每个分支 $\omega\in\Omega(s_{\mathrm{loc}})$，记试验主体词执行后的完整账户收入（含真实库存变动与金融头寸变动，故未归还借款绝不冒充净收入）为 $y_P(\omega),y_B(\omega)\in\mathbb Q$。在单分支上，转移额 $q\in\mathbb Q$ 同时保住双方外部替代基准当且仅当 $a_P\le y_P(\omega)+q$ 且 $a_B\le y_B(\omega)-q$，等价于 $a_P-y_P(\omega)\le q\le y_B(\omega)-a_B$。对非空列表 $\Omega(s_{\mathrm{loc}})$ 归纳求包络，即得充要条件：
\[
\Bigl(\forall\omega\in\Omega(s_{\mathrm{loc}}),\ 
a_P\le y_P(\omega)+q\ \land\ a_B\le y_B(\omega)-q\Bigr)
\Longleftrightarrow
\operatorname{lo}(s_{\mathrm{loc}})\le q\le\operatorname{hi}(s_{\mathrm{loc}}),
\tag{E7}
\]
其中下界与上界由同信号纤维的最坏分支内生决定：
\[
\operatorname{lo}(s_{\mathrm{loc}})
:=\max_{\omega\in\Omega(s_{\mathrm{loc}})}\bigl(a_P-y_P(\omega)\bigr),
\qquad
\operatorname{hi}(s_{\mathrm{loc}})
:=\min_{\omega\in\Omega(s_{\mathrm{loc}})}\bigl(y_B(\omega)-a_B\bigr).
\tag{E8}
\]
若 $\Omega(s_{\mathrm{loc}})=\emptyset$，该信号下无受支持报价分支可供定价，报价以空纤维拒签；若 $\Omega(s_{\mathrm{loc}})\ne\emptyset$ 且 $\operatorname{lo}(s_{\mathrm{loc}})>\operatorname{hi}(s_{\mathrm{loc}})$，由非空纤维上的不等式传递性立即推出不存在任何有理转移 $q$ 可同时保住该信号下全部报价分支的双边基准，报价以区间不相容拒签。机制先于未知事件固定，故共享同一已付局部信号的任意两分支 $\omega_1,\omega_2$ 必获完全相同的报价结果（S17）。

**命题E2（唯一最小绝对支付与基准紧绑定）。** 当 $\operatorname{lo}\le\operatorname{hi}$ 时，定义典范风险转移算子
\[
q^*(\operatorname{lo},\operatorname{hi})
:=
\begin{cases}
\operatorname{lo}, & \operatorname{lo}>0,\\
\operatorname{hi}, & \operatorname{hi}<0,\\
0, & \operatorname{lo}\le 0\le\operatorname{hi}.
\end{cases}
\tag{E9}
\]
则 $q^*(\operatorname{lo},\operatorname{hi})\in[\operatorname{lo},\operatorname{hi}]$；且对任意满足 $\operatorname{lo}\le q\le\operatorname{hi}$ 且 $q\ne q^*(\operatorname{lo},\operatorname{hi})$ 的安全转移 $q\in\mathbb Q$，恒有严格不等式 $|q^*(\operatorname{lo},\operatorname{hi})|<|q|$。若端点来自式（E8）且 $q^*\ne 0$，至少有一个报价分支 $\omega$ 使 $y_P(\omega)+q^*=a_P$ 或 $y_B(\omega)-q^*=a_B$。任何非零差额 $\lambda\ne 0$ 叠加到 $q^*$ 上，都会越出安全区间或严格增大绝对支付量。

**证明。** 分三种互斥情形讨论：（1）若 $\operatorname{lo}>0$，则 $q^*=\operatorname{lo}$，任取 $q\in[\operatorname{lo},\operatorname{hi}]$ 且 $q\ne\operatorname{lo}$，必有 $0<\operatorname{lo}<q$，故 $|q^*|=\operatorname{lo}<q=|q|$；（2）若 $\operatorname{lo}\le 0$ 且 $\operatorname{hi}<0$，则 $q^*=\operatorname{hi}<0$，任取 $q\in[\operatorname{lo},\operatorname{hi}]$ 且 $q\ne\operatorname{hi}$，必有 $q<\operatorname{hi}<0$，故 $|q^*|=-\operatorname{hi}<-q=|q|$；（3）若 $\operatorname{lo}\le 0\le\operatorname{hi}$，则 $q^*=0$，任意 $q\ne 0$ 满足 $|q^*|=0<|q|$。当 $q^*\ne 0$ 时，第（3）支被排除。由于报价分支有限且非空，第（1）支的最大值或第（2）支的最小值必在某分支达到，分别给出提供方或付款方的等式。对任意 $\lambda\ne 0$，$q^*+\lambda\ne q^*$，若其仍落在 $[\operatorname{lo},\operatorname{hi}]$ 内，由前述严格唯一性即得 $|q^*|<|q^*+\lambda|$；否则直接破坏区间可行性。□

**定理E3（四分金额判决、零隐蔽头寸与两阶段整账闭合）。** 在可行区间 $\operatorname{lo}(s_{\mathrm{loc}})\le\operatorname{hi}(s_{\mathrm{loc}})$ 上，任意提议金额 $q\in\mathbb Q$ 唯一落入四类互斥源内处置之一：
\[
\bigl(q=q^*\bigr)
\ \lor\ 
\bigl(\operatorname{lo}\le q\le\operatorname{hi}\land |q^*|<|q|\bigr)
\ \lor\ 
\bigl(q<\operatorname{lo}\bigr)
\ \lor\ 
\bigl(q>\operatorname{hi}\bigr),
\tag{E10}
\]
依次对应**必要风险补偿**、**额外剩余分配**、**提供方受偿缺口**与**付款方超界缺口**。当 $q^*=0$ 时，必要风险通道走零请求空词分支；当 $q^*\ne 0$ 时，事前预检强制要求借贷双方非同一主体且试验主体结束时该工具—债务人—债权人地址原余额为零，仅在 $q=q^*$ 分支按结算率 $r_{\mathrm{inst}}>0$ 由实际债务人签署数量为 $|q^*|/r_{\mathrm{inst}}$ 的原生发行请求并执行真实结算，其余三类以及菜单外事件、未付费观察、空纤维和区间交叉均不签发风险补偿请求。真实签发并结清 $q^*$ 后，完整请求权矩阵精确复原为补偿前矩阵（此原矩阵复原区别于附录 G.1 的原生金融槽终结归档）：
\[
\operatorname{claims}\bigl(\operatorname{final}(w_{\mathrm{body}}\mathbin{+\!\!+}w_{\mathrm{price}}(q^*))\bigr)
=
\operatorname{claims}\bigl(\operatorname{after}(w_{\mathrm{body}})\bigr).
\tag{E11}
\]
在就绪可审查的底层社会状态与已通过预检的报价事件上，两阶段执行在全部参与者—物品坐标上保住双边真实外部基准并付清全体成员生活维护；同时，包括准备失败、报价拒签与中途中断在内的每一次尝试均无条件单射运输全部旧责任行且不回填预算。两套核验消费者共同证实上述构造：单物品日程消费者在 $(x_P,x_B)=(100,100)$ 与 $a_P=a_B=-1$ 下，对共享信号 $s_0$ 的损失 $2,4$ 两分支算出 $y_P\in\{-3,-5\},y_B=7$、区间 $[4,8]$、唯一最小支付 $q^*(s_0)=4$、实付终态库存 $(x_P,x_B)=(101,103)$ 与 $(99,103)$，并经内核可判定证明完成 $3,4,7,100$ 四分归类与菜单外损失 $3$ 拒付；双物品社会状态消费者在食物 $(1,1)$（外部基准变动 $-1$）与结算材料 $(x_P,x_B)=(109,117)$（外部基准变动 $0$、产出 $18$）上算出 $(-2,16)$ 与 $(-4,16)$、区间 $[4,16]$ 与同一 $q^*(s_0)=4$，经两阶段准备与执行完成真实交付并单射承接全部既有责任行（S17）。

## F 完整责任与动态续行

### F.1 同一次执行的物量与金融守恒恒等式

对任意实际程序的有限前缀，逐参与者 $i$ 与物品 $g$ 成立物量借贷恒等式：
\[
x_{\mathrm{after}}(i,g)+D(i,g)
=x_{\mathrm{before}}(i,g)+K(i,g),
\tag{F1}
\]
其中 $D,K$ 分别为该前缀执行清单累计的实际借记与贷记；逐金融工具 $f$、债务人 $d$ 与持有人 $h$ 成立请求权更新式：
\[
b_{\mathrm{after}}(f,d,h)
=b_{\mathrm{before}}(f,d,h)+\Delta b_E(f,d,h).
\tag{F2}
\]
任何严格正的库存净增必可反解到同一执行清单中某项已接受的正贷记分录，单纯签发金融债务不产生实物增量（S10）。完整收益进一步将净生产（扣除投入、使用与修订耗费）、开放转移、控制者地址上的有号净控制转移与期末价格重估逐项分离，本金清偿的现金支付与请求权退休同坐标相抵（S11）。

### F.2 控制净阻塞损害与单次库存不重复分配

控制净阻塞固定同一起点库存、融资、投资、本方策略与自适应历史反应规则，逐人逐物品比较开放执行与受控执行的净生产：
\[
q(i,g)=
\max\{0,\operatorname{productiveOpen}(i,g)
-\operatorname{productiveControlled}(i,g)\}.
\tag{F3}
\]
生产损害修复责任 $P$ 采用式（F3）的正支持矩阵；受控回流返还责任 $G$ 则汇总未获出让方同意、具私人准入差异且属于已识别资本回流路线的实际实物转移（与明确同意的赠与或公共修复严格区分）。$P$ 与 $G$ 共享同一状态与单次执行：新增可分配物量先为 $P$ 预留，$G$ 仅消费扣除后的余量，严禁同一单位库存重复清偿两份责任账。连续获准的 $n$ 次责任续约每次必须全词有效、付清全员生活维护并至少清零一格正残差，故正残差格数 $B$ 满足
\[
n+B(z_n)\le B(z_0),
\tag{F4}
\]
从而同一旧责任的续约次数严格有界（S11）。

### F.3 全联盟提款零界、制度变更运输与已发出汇合极限

对任意布尔联盟 $S$ 与物品 $g$，由一笔已结清修复责任继续授权的任意有限开放机制链（每步均现场重绑当前库存与有效法则，禁止自带外生库存充值）恒满足
\[
\operatorname{Income}_{S,g}
+\operatorname{Consumed}_{S,g}=0,\qquad
\operatorname{Income}_{S,g}\le0,
\tag{F5}
\]
即已清旧责任不再授权任何联盟提取正净收入，而基础生活维护耗用与其他新来源收入各自按其规则正常存续。跨制度有限历史沿整账映射单射运输全部既有责任行（无需假设旧账有限），保持预算不增、已付为零及式（F1）–（F2）；在活动公共解释下，任何声称再生的资本见证均直接定位出一处“声称法则拒绝受影响者而活动解释器允许准入”的确切权限分歧地址。对来源已发出的共尾汇合事件，每条旧行的非增自然数预算在各自已发生截点取得稳定最小值，事件自身的登记程序核验谱系相容性以生成承接首写或返回具名谱系冲突（S11、S12）。

## G 清算成本：达到者与逐候选严格改进算法

### G.1 资源足额的金融清算尾段达到者

设非负线性成本读数为
\[
K_\lambda(w)=
\sum_{e\in E(w)}\sum_{\chi,i,g}
\lambda_{\chi,i,g}\,d_\chi(e;i,g)
+\lambda_t\,\Delta t,\qquad \lambda_{\chi,i,g},\lambda_t\ge0,
\tag{G1}
\]
只对真实资源耗用通道与经过时钟赋非负权重，不将本金结算转移计作资源毁损。在结算资源足额的就绪截点上，账户自产清偿词 $w_*$ 仅执行逐槽偿付与终结归档（含对零余额活动槽提交零额结算以生成正式归档收据），新增生产资源耗用与时钟增量均为 $0$，故在同一已发生前缀后对任意有限允许策略 $w$ 及任意非负权重 $\lambda$ 均达到最小成本 $K_\lambda(w_*)\le K_\lambda(w)$，同时保持完整归档与制度后继（S13）。

### G.2 含生产的完整清算离散族

在两人、两物品（生活／结算品 $g_0$，生产／维护物料 $g_1$）完整清算源中，共同已发生前缀 $h$ 先发行债务 $1$、交付 $g_0$ 数量 $1$ 并实付生活 $1$ 与维护 $1$，前缀成本为 $2$；截点处双方 $g_0$ 库存均为 $0$，未清债务为 $1$，生产者持有 $g_1$ 数量 $5$。技术 $n\in\mathbb N$ 耗用投入 $\varepsilon_n=1/(n+2)$ 与生产维护 $1$ 产出 $1$ 单位 $g_0$，改技术耗费与微步耗时均为 $0$，全通道权重取 $1$。候选尾段
\[
w_n=[\,\operatorname{revise}(n),\
\operatorname{produce},\
\operatorname{settle}(1)\,]
\tag{G2}
\]
全部有效（$\varepsilon_n\le 1/2$），在包含六步底层状态消解的完整执行中完成全部物理与金融消费、清零债务并生成终结归档与下一查询，其尾成本与全史成本精确为
\[
K_{\mathrm{tail}}(w_n)=1+\varepsilon_n,\qquad
K_{\mathrm{full}}(w_n)=3+\varepsilon_n.
\tag{G3}
\]

### G.3 对任意完整清算候选的构造性严格改进

设 $v$ 为该来源中任意清零完整请求权矩阵的有限程序，尾段成本为 $c(v)$。

1. **严格下界 $c(v)>1$。** 若 $v$ 不含已接受的生产项，所有非生产操作均保持 $g_0$ 库存为 $0$ 且总债务不低于 $1$，不可能清零债务矩阵。故 $v$ 必含至少一次有效生产，支付维护 $1$ 与严格正投入 $\varepsilon_m>0$，其余成本非负，从而
\[
c(v)>1.
\tag{G4}
\]
2. **由自身成本差构造改进。** 令
\[
\delta=c(v)-1>0,\qquad
n(v)=\left\lceil\frac1\delta\right\rceil,
\tag{G5}
\]
则 $1/\delta\le n(v)<n(v)+2$，故
\[
\varepsilon_{n(v)}=\frac1{n(v)+2}<\delta,
\tag{G6}
\]
代入式（G2）–（G3）得同一共同前缀 $h$ 后的全史严格改进不等式：
\[
2+c(w_{n(v)})=3+\varepsilon_{n(v)}
<2+c(v).
\tag{G7}
\]
3. **下确界 $3$ 无最小达到者。** 若某完成候选 $v$ 在完成域内成本最小，对其自身应用式（G5）–（G7）即得严格更便宜的完整清算候选 $w_{n(v)}$，矛盾；同时对任意 $\eta>0$ 取 $n=\lceil 1/\eta\rceil$ 即落在 $(3,3+\eta)$ 内，证毕下确界 $3$ 可任意逼近而无最小完成者（S14–S16）。

## H 声明、继承链与固定来源

正文第 1–11、13–19 项结果（CF0–CF16）采用 H0mework [固定证明快照](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) 的 `EconomicConstitutionSourceDF` 及[首版逐项映射](https://github.com/Sapientropic/H0mework/blob/7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6/docs/capital-formation-map.json)。定理 12、例 2 和附录 E.3（CF17）采用 H0mework [固定证明快照](https://github.com/Sapientropic/H0mework/tree/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e) 的 `SocietyBookRiskCompensation`，对应 [CF17 声明与直接消费者](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/checks/society-book-map.json)及[复现指南](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/docs/society-book-reproduction.md)。表 H 给出两批材料的逐项声明。

下表短路径位于共同目录 $\texttt{Lean/SaturationMonoid/ProcessGame/Society/}$ 接续 $\texttt{Institutions/Capitalism/}$ 之下：

- **U**：\(\texttt{Universal/Source/ProgrammeControl/}\)
- **A**：\(\texttt{Universal/Abolition/}\)
- **C**：A 下的 \(\texttt{Accounting/Quantifiers/Assembly/Strengthening/Characterization/}\)
- **O**：A 下的 \(\texttt{Accounting/Quantifiers/Assembly/Strengthening/Optimality/}\)
- **P**：A 下的 \(\texttt{Innovation/Contribution/Pricing/}\)（固定提交 `7c228ac7fd`）

| 标识 | 定义、决定性证明与直接消费位置 |
| --- | --- |
| S1 | U 的 Kernel/Access、Reciprocity、Disposal、Core；需要准入、三种回流与可行处分耦合为资本核心 $C=(A,R,D)$ |
| S2 | U 的 Kernel/AssetAuthority/ProperKernel、Transfer；Kernel/ActualSurplus/Core；History/Core、Family、Binding |
| S3 | C 的 Support/Law；Models/Permissions/Classification；五面无资本充要支撑定理与四格真实权限族 |
| S4 | C 的 Support/Local、History、Exact；Models/Reconstruction/Kernel、Surplus、History；全构造重编译与自身恢复 |
| S5 | A 的 Completion/Actual/External/Admission、ClaimsReceipt/Actual；Assembly/Society；Consumers/Forms（六类资本形态入合同与三类非资本负控核验） |
| S6 | A 的 Completion/Actual/Finite/Resolution；Assembly/Disposition、Consumer、Control、Current；Capital/Runtime |
| S7 | A 的 Functions/Replay/Request、Trace、Effects、Services、Public；Completion/Actual/Assembly/Functions |
| S8 | A 的 Innovation/Completion/SourceLaw、Society、Assembly；Trials/Consumers/Renewal、RenewalGate；Trials/Source/Renewal/Decision |
| S9 | A 的 Accounting/Contribution/Flow、Settlement；Source/Legacy、Receipts、Cursor；Epoch/Complete、Consumer、Actual |
| S10 | C 的 Escape/Material、Actual、History、Complete；跨制度折叠的物量、金融与旧行单射守恒 |
| S11 | A 的 Accounting/Quantifiers/Assembly/Completion/Core、Dynamic、Complete；Accounting/Profit 的 Inventory、Decomposition、Valuation、Public |
| S12 | C 的 Root/Contract、Consumers/Registered；继承 Total/Finite、Epoch、Cofinal、Complete 与完整成本合同 |
| S13 | O 的 ActiveControl/Source、Minimum；Root/Complete、Institutional；Completion/Complete；以及 CompleteLedger 下 Archive/Native/Source、Acceptance、Complete 与 Archive/Word、Primitive/Archives、Consumers/Zero |
| S14 | O 的 Countermodels/Nonattainment/Source、Prefix、Programme、Cost/Lower、Cost/Pricing、Complete |
| S15 | O 的 Countermodels/Nonattainment/Family/Source、Family/Cost、Native/Complete；Completion/Source；RootedSource/Complete |
| S16 | O 的 Recognition/Family：对任意已清候选构造严格更便宜的同根完整清算，并由 Completion/Complete 纳入总合同 |
| S17 | P 的 Outside/Source、Compiler、Complete、Consumers；Arithmetic/Interval、Accounts、Controls；Source/Branches、Envelope、Compiler、Authority、Submission、Preflight；Settlement/Compiler、Accounting、Trace；Root/Preparation、Protocol、Completion、Accounts、Carrying、Contract（`CapitalRiskCompensationClosedAt` 扩展 `MinimalSupportAndEscapeAt`）；Consumers/Source、Prices、Submission、Registered、ActualRoot（实付 $q^*=4$ 及 $3,4,7,100$ 四分判例） |

上述模块均以 \(\texttt{.lean}\) 为扩展名，仅依赖 Lean 4 标准三公理（`propext`、`Classical.choice`、`Quot.sound`），零 `sorry`、零 `unsafe`／`partial`。顶层总合同由 `CapitalRiskCompensationClosedAt` 完整继承 `MinimalSupportAndEscapeAt → ClearingCostClaimsClosedAt → InstitutionalCostedCapitalRootAt → … → CapitalQuantifiersClosedAt`，使最小权限支撑、公共功能重放、有限步完备处置、来源累计受偿界、同局部信号唯一最小必要风险补偿、双域清算成本与跨制度整账承接共同约束同一实际来源及其全部后继。
