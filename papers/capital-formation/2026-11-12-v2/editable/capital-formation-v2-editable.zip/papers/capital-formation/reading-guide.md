# 阅读与复核指南

## 版本与预印本锚点

- **第二版（v2）**：合入源内唯一最小必要风险定价定理（`CF17`，定理 12 与附录 E.3）、引言与第 7.5 节两处纸笔验算锚点（例 1、例 2）、§4.1 六类资本形态与三类非资本负控 `6 + 3` 双向核验矩阵（表 2）、四学科 15 分钟快读通道、六组双语 v2 矢量主图及五轴 30 篇原始文献对话（表 3）。中英文正文与技术附录源为 [manuscript.md](manuscript.md)、[manuscript-en.md](manuscript-en.md)、[supplement.md](supplement.md)、[supplement-en.md](supplement-en.md)；四份本地阅读版 PDF 输出于 `build/reading-review-v2/`，构建回执见 [figure-build-pdfs-v2.json](records/figure-build-pdfs-v2.json)，一致性回执见 [manuscript-consistency-v2.json](records/manuscript-consistency-v2.json)，编辑说明见 [editorial-notes.md](editorial-notes.md)。
- **首版（Zenodo v1，冻结成品）**：已于 2026-11-04 正式发布 [Zenodo v1：10.5281/zenodo.23927949](https://doi.org/10.5281/zenodo.23927949)。冻结的四份首版 PDF（capital-formation.pdf（Zenodo v1 冻结成品 `capital-formation.pdf`）、capital-formation-en.pdf（Zenodo v1 冻结成品 `capital-formation-en.pdf`）、capital-formation-supplement.pdf（Zenodo v1 冻结成品 `capital-formation-supplement.pdf`）、capital-formation-supplement-en.pdf（Zenodo v1 冻结成品 `capital-formation-supplement-en.pdf`），共 85 页）与首版可编辑源码包（Zenodo v1 冻结成品 `capital-formation-v1-editable.zip`）原字节完整保留，SHA-256 见发布登记（Zenodo v1 归档登记，DOI: 10.5281/zenodo.23927949）和[发布验收](records/zenodo-release-review.json)。

## 阅读入口（v2）

| 材料 | 源文件 | 本地阅读版（v2） | 用途 |
| --- | --- | --- | --- |
| 中文正文 | [manuscript.md](manuscript.md) | [capital-formation.pdf](build/reading-review-v2/capital-formation.pdf) | 从双人单机纸笔模型与规范理由进入 19 项结果、例 2 风险定价验算及五轴 30 篇文献对话 |
| English article | [manuscript-en.md](manuscript-en.md) | [capital-formation-en.pdf](build/reading-review-v2/capital-formation-en.pdf) | Complete English article mirroring all 19 results, 2 examples, 28 equations, 6 figures, and 30 references |
| 中文技术附录 | [supplement.md](supplement.md) | [capital-formation-supplement.pdf](build/reading-review-v2/capital-formation-supplement.pdf) | 附录 A—H：形式对象、39 个带标公式、决定性证明（含 E.3 `CF17`）及 `S1–S17` 固定来源 |
| English technical supplement | [supplement-en.md](supplement-en.md) | [capital-formation-supplement-en.pdf](build/reading-review-v2/capital-formation-supplement-en.pdf) | Appendices A–H: formal definitions, decisive proofs (including Section E.3 for `CF17`), and source correspondence |

### 先抓纸笔直觉，再核全称定理锋芒

1. **§1—§3（最小权限支撑与四格分类）**：§1.1 例 1 用两人一机一回合的纸笔模型直观展示受控执行与开放重放的差异；§1.2 定理 1 与表 1 将六分肢主结论与配对反控并列；§1.3 为政治经济学、企业与金融契约理论、制度政治哲学、形式方法四类读者提供 15 分钟核验路线。§2 区分基础参与、任务胜任、贡献索偿与可撤治理四类规范理由，§3 证明五面完整无资本与权限无不对称的充要等价（定理 2–3）。
2. **§4—§6（全形态统一社会合同、有限步处置与公共功能重放）**：§4 证明工业、照护、金融、平台、零雇佣自动化与技术升级型国家资本六形态由同一编译器重构进入统一社会合同，并以表 2 对照共同合作生产、个人直兑公共信用与自主家计自给三类非资本负控（定理 4–5）；§5 证明从任意实际截点在 `internalMass + 1` 步内必达完整废止见证或精确阻塞残差（定理 6–7）；§6 证明任意有限生产执行词存在同长度公共功能重放，严格保持完整后态、物量分录、全员生活维护与任务服务，同时将控制者同意门清零（定理 8）。
3. **§7（菜单外创新、来源受偿上界与唯一最小必要风险定价 `CF17`）**：§7.1–§7.4 建立事前固定机制的全事件处置、两轮菜单外实付发现（`0 → 1 → 2`）与按发行来源汇总全部账户槽的累计受偿上界（定理 9、命题 10、定理 11）。**§7.5 定理 12（`CF17`）与例 2** 不预设主观概率、多先验或效用函数，由零参数可执行外部替代收益 `(a_P, a_B)` 与同付费局部信号分支真实收入 `(y_P, y_B)` 内生导出双边安全闭区间 `[lo, hi]`，证明离零最近的有理数 `q*` 为唯一最小必要风险补偿，将下行风险填平与合作剩余分配正交拆解（必要补偿、额外分配、欠额与超额四分）。
4. **§8—§10（完整账户、两类清算域与跨演进旧债守恒）**：§8 将控制移除净增益（材料 18、成果 3）与全联盟零提款边界接回完整账户（定理 13–14）；§9 区分资源足额财务尾段的实际最优达到者与完整清算域 `3 + 1/(n+2)` 的严格改进算法（定理 15–17）；§10 证明无需有限旧账假定的单射责任运输与复辟权限分歧定位（定理 18–19），并以表 3 收束五轴 30 篇文献对话。

## 六组双语主图（v2）

[图件说明](figures/README.md)解释每幅图的箭头、数值和量化范围。[make_figures_v2.py](figures/make_figures_v2.py) 是 v2 可编辑生成源（清单见 [manifest-v2.json](figures/manifest-v2.json)）；首版五组图与 [make_figures.py](figures/make_figures.py) 原字节保留。

| 图件 | 对应论证 |
| --- | --- |
| `fig01-structure-v2` | 权限四格矩阵与完整五面无资本条件的充要刻画 |
| `fig02-disposition-v2` | 资本见证自行生成正登记、金融入口分派与 `m(x)+1` 步完整实际处置 |
| `fig03-replay-v2` | 执行词逐项公共重放、同一完整后态 `s′` 与服务充要保持 |
| `fig04-innovation-v2` | 连续两轮菜单外实付创新与按同一贡献来源 `o` 汇总全部槽的受偿上界 |
| `fig05-risk-pricing-v2` | 同局部信号 `s_0` 下双边安全区间 `[4, 8]`、唯一最小支付 `q* = 4` 与四分准入（`CF17`） |
| `fig06-cost-v2` | 资源足额财务尾段实际达到者 `w*` 与完整清算域 `3 + 1/(n+2)` 严格下降族 |

## 声明与固定来源

claims.md（仓库工作记录，不随本可编辑包提供） 保存 `CF0–CF17` 主张与形式声明对应；[source-correspondence-v2.md](source-correspondence-v2.md) 与 [cf17-source-binding.json](records/cf17-source-binding.json) 保存 v2 逐模块声明行号、SHA-256 与公开模块绑定；[literature-v2.md](literature-v2.md) 与 [references-v2.bib](references-v2.bib) 保存 30 篇原始文献核查记录；[source-availability.md](source-availability.md) 说明固定研究提交与公开复现入口：

- `CF0–CF16` 固定于 Homework `df421ff600085cbc290a7ae946193961bed7c83b` 与公开仓 H0mework `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`（`H0mework.Papers.EconomicConstitutionSourceDF`）。
- `CF17`（定理 12 与附录 E.3／S17）固定于 Homework `7c228ac7fd77350d3fe761c24b887cbf2f6e5afc`，公开导出靶标为 H0mework `H0mework.Papers.SocietyBookRiskCompensation`（提交 `fd6147f8c337d88ebf72d91ddadef0aa601e6c2e`，见 [society-book-reproduction.md](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/docs/society-book-reproduction.md)），独立 T1 核验回执 SHA-256 为 `50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`。

## 重建与版面检查（v2）

从 `publish` 根目录运行双语一致性检查与 v2 四份阅读版 PDF 构建（默认输出至 `build/reading-review-v2/`，自动保护 `build/` 下冻结的首版 PDF）：

```sh
python3 papers/capital-formation/scripts/check_manuscript.py
python3 papers/capital-formation/scripts/build_reading.py
```

如需先重生成 v2 六组双语图再构建 PDF，可加 `--figures`；逐页版面渲染检查使用 [render_pdf_review.py](scripts/render_pdf_review.py)，检查完毕后删除临时页图与 TeX 中间目录。


## 可编辑包中的图件范围

本包提供SVG与同名矢量PDF；记录中列明的PNG预览及逐页审阅图可由脚本重建，不随本包提供。
