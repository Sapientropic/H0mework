#!/usr/bin/env python3
"""Generate deterministic v2 source correspondence (S1-S17) and CF17 public binding.

Preserves v1 source-correspondence.md and records/public-source-binding.json untouched.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

PAPER = Path(__file__).resolve().parents[1]
HW_COMMIT = "7c228ac7fd77350d3fe761c24b887cbf2f6e5afc"
H0_BASE_COMMIT = "a8e94ac1ecbc23503cab91c977b4f71e04e44cb5"
H0_COMMIT = "fd6147f8c337d88ebf72d91ddadef0aa601e6c2e"
H0_V1_COMMIT = "2d6fbc96e33b7c4c3cfd91104fda74e3caeda045"
H0_MAP_COMMIT = "7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6"
T1_RECEIPT_SHA = "50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08"

HW_PREFIX = "Lean/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/"
PRICING_PREFIX = HW_PREFIX + "Universal/Abolition/Innovation/Contribution/Pricing/"
H0_MOD_PREFIX = "H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism."
H0_PATH_PREFIX = "Lean/" + H0_MOD_PREFIX.replace(".", "/")


def git_bytes(repo: Path, rev_path: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(repo), "show", rev_path])


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build_data(hw_repo: Path, h0_repo: Path) -> tuple[dict, str]:
    files = sorted(
        subprocess.check_output(
            ["git", "-C", str(hw_repo), "ls-tree", "-r", "--name-only", HW_COMMIT, PRICING_PREFIX],
            text=True,
        ).splitlines()
    )
    assert len(files) == 55, f"Expected 55 Pricing files, found {len(files)}"

    target_raw = git_bytes(h0_repo, f"{H0_COMMIT}:Lean/H0mework/Papers/SocietyBookRiskCompensation.lean")
    map_raw = git_bytes(h0_repo, f"{H0_COMMIT}:checks/society-book-map.json")
    map_json = json.loads(map_raw.decode("utf-8"))
    risk_claims = [c for c in map_json.get("claims", []) if c.get("id") == "capital-risk-compensation"]
    assert len(risk_claims) == 1, "Missing capital-risk-compensation in checks/society-book-map.json"

    short_to_imports: dict[str, list[str]] = {}
    entries = []
    for idx, full in enumerate(files, 201):
        rel_cap = full[len(HW_PREFIX):]
        hw_raw = git_bytes(hw_repo, f"{HW_COMMIT}:{full}")
        h0_rel = H0_PATH_PREFIX + rel_cap
        h0_raw = git_bytes(h0_repo, f"{H0_COMMIT}:{h0_rel}")
        text = hw_raw.decode("utf-8")
        decls = []
        imports = []
        for lineno, line in enumerate(text.splitlines(), 1):
            im = re.match(
                r"^import\s+SaturationMonoid\.ProcessGame\.Society\.Institutions\.Capitalism\.([A-Za-z0-9_.]+)",
                line,
            )
            if im:
                imp_rel = im.group(1).replace(".", "/") + ".lean"
                imports.append(imp_rel)
            dm = re.match(r"^(def|abbrev|structure|inductive|theorem|lemma)\s+([A-Za-z0-9_.]+)", line)
            if dm:
                decls.append({"kind": dm.group(1), "name": dm.group(2), "line": lineno})
        short_to_imports[rel_cap] = imports
        mod_name = H0_MOD_PREFIX + rel_cap[:-5].replace("/", ".")
        entries.append({
            "id": f"s{idx}",
            "group": "S17",
            "relative_path": rel_cap,
            "homework_commit": HW_COMMIT,
            "source_sha256": sha(hw_raw),
            "h0_commit": H0_COMMIT,
            "public_module": mod_name,
            "public_path": h0_rel,
            "public_sha256": sha(h0_raw),
            "declarations": decls,
            "direct_pricing_imports": [i for i in imports if i.startswith("Universal/Abolition/Innovation/Contribution/Pricing/")],
        })

    consumers_map: dict[str, list[str]] = {e["relative_path"]: [] for e in entries}
    for e in entries:
        for imp in e["direct_pricing_imports"]:
            if imp in consumers_map:
                consumers_map[imp].append(e["relative_path"])
    for e in entries:
        e["direct_pricing_consumers"] = sorted(consumers_map[e["relative_path"]])

    binding = {
        "schema": "capital-formation/cf17-source-binding@2",
        "paper": "capital-formation",
        "edition": "v2",
        "claim": "CF17",
        "homework_commit": HW_COMMIT,
        "h0_base_commit": H0_BASE_COMMIT,
        "h0_supplement_commit": H0_COMMIT,
        "public_target_module": "H0mework.Papers.SocietyBookRiskCompensation",
        "public_target_path": "Lean/H0mework/Papers/SocietyBookRiskCompensation.lean",
        "public_target_sha256": sha(target_raw),
        "society_book_map_sha256": sha(map_raw),
        "independent_t1_receipt": {
            "name": "iqa-capital-risk-pricing-independent-v1/verification.json",
            "sha256": T1_RECEIPT_SHA,
            "axioms": ["propext", "Classical.choice", "Quot.sound"],
        },
        "module_count": len(entries),
        "declaration_count": sum(len(e["declarations"]) for e in entries),
        "entries": entries,
    }

    md_lines = [
        "# 第二版（v2）定理、声明、消费者与固定公开源码对应",
        "",
        "本表承担《资本主义的结构总定理》第二版（v2，`CF0–CF17`，正文 19 项编号结果、例 1–2，附录 A–H 及表 H 之 `S1–S17`）的完整源码对应；首版冻结对应表 [source-correspondence.md](source-correspondence.md)（`s001–s105`）与机器绑定 [public-source-binding.json](records/public-source-binding.json) 原字节保持不变。",
        "",
        "## 一、固定版本与公开复现入口",
        "",
        f"1. **`CF0–CF16`（`S1–S16`，`s001–s105`）**：研究代码库 Homework 固定于 `{ 'df421ff600085cbc290a7ae946193961bed7c83b' }`；公开验收闭包 `H0mework.Papers.EconomicConstitutionSourceDF`（2825 模块）固定于 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/{H0_V1_COMMIT}) 提交 `{H0_V1_COMMIT}`，首版公开证明映射 `docs/capital-formation-map.json` 固定于提交 `{H0_MAP_COMMIT}`。",
        f"2. **`CF17`（`S17`，`s201–s255`）**：研究代码库 Homework 固定于 `{HW_COMMIT}`；公开复现靶标 `H0mework.Papers.SocietyBookRiskCompensation` 固定于 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/{H0_COMMIT}) 提交 `{H0_COMMIT}`（基底提交 `{H0_BASE_COMMIT}`，映射 `checks/society-book-map.json` 条目 `capital-risk-compensation`），独立 T1 核验回执 `iqa-capital-risk-pricing-independent-v1/verification.json` SHA-256 为 `{T1_RECEIPT_SHA}`。机器绑定见 [cf17-source-binding.json](records/cf17-source-binding.json)。",
        "",
        "## 二、第二版（v2）编号结果与首版编号映射总表",
        "",
        "因第 7.5 节合入 `CF17` 为**定理 12**，首版定理 12–18 在第二版正文中顺延为**定理 13–19**；定理 1–9、命题 10、定理 11 保持原编号不变。",
        "",
        "| v2 正文结果 | v1 对应编号 | 命题键 | 附录位置 | 来源组与对应条目 |",
        "| --- | --- | --- | --- | --- |",
        "| 例 1（§1.1） | 新增纸笔锚点 | CF1, CF3, CF14, CF17 | B.1, D.1, E.3 | S3, S7, S17（`s219–s221`） |",
        "| 定理 1（§1.2） | 定理 1（扩至六分肢） | CF0, CF12–CF14, CF17 | A–H | S1–S17（`s001–s105`, `s201–s255`） |",
        "| 定理 2（§3.3） | 定理 2 | CF1 | B.1 | S3（`s011`） |",
        "| 定理 3（§3.4） | 定理 3 | CF3 | B.1 | S3（`s012–s013`） |",
        "| 定理 4（§4.1，配表 2） | 定理 4 | CF2–CF3 | B.2, C.1 | S4–S5（`s014–s022`） |",
        "| 定理 5（§4.2–§4.3） | 定理 5 | CF12 | C.1–C.2 | S5（`s020–s022`） |",
        "| 定理 6（§5.1–§5.2） | 定理 6 | CF13 | C.3, D.3 | S6（`s023–s028`） |",
        "| 定理 7（§5.4） | 定理 7 | CF12–CF13 | C.4 | S6（`s025, s028`） |",
        "| 定理 8（§6.1–§6.2） | 定理 8 | CF14 | D.1–D.2 | S7（`s029–s034`） |",
        "| 定理 9（§7.1–§7.2） | 定理 9 | CF8, CF11 | E.1 | S8（`s035–s037`） |",
        "| 命题 10（§7.3） | 命题 10 | CF15 | E.1 | S8（`s038–s040`） |",
        "| 定理 11（§7.4） | 定理 11 | CF16 | E.2 | S9（`s041–s049`） |",
        "| **定理 12（§7.5）** | **v2 新增主定理** | **CF17** | **E.3（命题 E2、定理 E3）** | **S17（`s201–s255`）** |",
        "| **例 2（§7.5）** | **v2 新增双消费者核验** | **CF17** | **E.3** | **S17（`s206–s223`）** |",
        "| 定理 13（§8.1–§8.2） | 定理 12 | CF10 及收益分解 | F.1–F.2 | S11（`s057–s058, s066–s067, s091–s097`） |",
        "| 定理 14（§8.4） | 定理 13 | 全联盟与开放机制边界 | F.3 | S11–S12（`s054–s056, s068–s073`） |",
        "| 定理 15（§9.1） | 定理 14 | 全槽终结归档 | G.1 | S13（`s098–s105`） |",
        "| 定理 16（§9.2） | 定理 15 | CF4 | G.1 | S13（`s074–s078`） |",
        "| 定理 17（§9.3） | 定理 16 | CF5 | G.2–G.3 | S14–S16（`s079–s090`） |",
        "| 定理 18（§10.1） | 定理 17 | CF6 | F.1, F.3 | S10, S12（`s050–s053, s068–s073`） |",
        "| 定理 19（§10.2） | 定理 18 | CF7 | F.3 | S10, S12（`s068–s069`） |",
        "",
        "其中 `S1–S16`（`s001–s105`）的逐文件 SHA-256、声明行号与消费者列表完整保存于 [source-correspondence.md](source-correspondence.md)。下文展开 `S17`（`s201–s255`，共 55 个固定模块）的逐文件对应。",
        "",
        "## S17（`CF17`：源内双边安全包络、唯一最小必要风险补偿与两阶段整账结算）",
        "",
    ]

    for e in entries:
        decl_str = "；".join(f"`{d['name']}` (L{d['line']})" for d in e["declarations"]) or "（纯导入装配模块）"
        cons_str = "；".join(f"`{c}`" for c in e["direct_pricing_consumers"]) or "本索引无同域直接消费者，依公开靶标的递归导入链核验"
        url = f"https://github.com/Sapientropic/H0mework/blob/{H0_COMMIT}/{e['public_path']}"
        md_lines.extend([
            f"### {e['id']} · {e['relative_path']}",
            "",
            "- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。",
            "- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。",
            f"- 固定 Homework 源 SHA256：`{e['source_sha256']}`。",
            f"- 声明：{decl_str}。",
            f"- 实际公开模块：[{e['public_module']}]({url})（公开 SHA256：`{e['public_sha256']}`）。",
            f"- 同域直接消费者：{cons_str}。",
            "",
        ])

    return binding, "\n".join(md_lines)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--homework-repository", type=Path, required=True)
    ap.add_argument("--h0-repository", type=Path, required=True)
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    binding, md = build_data(args.homework_repository, args.h0_repository)
    json_path = PAPER / "records/cf17-source-binding.json"
    md_path = PAPER / "source-correspondence-v2.md"

    json_bytes = (json.dumps(binding, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    md_bytes = md.encode("utf-8")

    if args.check:
        assert json_path.read_bytes() == json_bytes, "Stale records/cf17-source-binding.json"
        assert md_path.read_bytes() == md_bytes, "Stale source-correspondence-v2.md"
        print(json.dumps({"status": "passed", "cf17_modules": binding["module_count"], "declarations": binding["declaration_count"]}))
        return

    json_path.write_bytes(json_bytes)
    md_path.write_bytes(md_bytes)
    print(json.dumps({"status": "written", "cf17_modules": binding["module_count"], "declarations": binding["declaration_count"]}))


if __name__ == "__main__":
    main()
