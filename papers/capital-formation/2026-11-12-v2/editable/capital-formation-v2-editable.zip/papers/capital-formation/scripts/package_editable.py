#!/usr/bin/env python3
"""Create the editable capital-formation bundle from an explicit allowlist.

Supports --edition v1 (frozen first-edition layout) and --edition v2 (second-edition
bundle outputting to build/reading-review-v2/capital-formation-v2-editable.zip and
records/package-audit-v2.json without touching frozen v1 artifacts).
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
REL = PAPER.relative_to(ROOT).as_posix()
PDF_NAMES = (
    "capital-formation.pdf", "capital-formation-en.pdf",
    "capital-formation-supplement.pdf", "capital-formation-supplement-en.pdf",
)
SOURCES = ("manuscript.md", "manuscript-en.md", "supplement.md", "supplement-en.md")
FIGURES_V1 = ("fig01-structure", "fig02-disposition", "fig03-replay",
              "fig04-innovation", "fig05-cost")
FIGURES_V2 = ("fig01-structure-v2", "fig02-disposition-v2", "fig03-replay-v2",
              "fig04-innovation-v2", "fig05-risk-pricing-v2", "fig06-cost-v2")
EXCERPTS = ("s022-Forms.lean", "s065-Total.lean", "s103-Archive.lean",
            "s104-Zero.lean", "s105-Zero.lean")
SHARED = (
    "shared/scripts/build_pdf.py",
    "shared/scripts/byline.py",
    "shared/styles/article-header.tex",
    "shared/styles/article-header-en.tex",
    "shared/styles/article-filter.lua",
    "shared/figure-style/house_style.py",
    "shared/figure-style/svg_text.py",
)
PAPER_FIXED_V1 = SOURCES + (
    "references.bib", "reading-guide.md", "source-availability.md",
    "source-correspondence.md", "verification.md", "packaging-README.md",
    "zenodo-metadata.json",
    "figures/make_figures.py", "figures/manifest.json", "figures/README.md",
    "scripts/build_reading.py", "scripts/table-layout.lua",
    "scripts/render_pdf_review.py", "scripts/package_editable.py",
    "scripts/check_manuscript.py", "scripts/build_source_index.py",
    "records/manuscript-consistency.json", "records/figure-optimization-review.json",
    "records/public-source-binding.json", "records/source-selection.json",
    "records/source-audit.md", "records/literature-audit.md",
    "records/figure-build-pdfs.json", "records/figure-build-visual.json",
    "records/figure-build-pages-main.json", "records/figure-build-pages-supplement.json",
    "records/figure-build-pages-main-en-tail.json",
    "records/figure-build-pages-main-en-7-10.json",
    "records/figure-build-source-identities.json", "records/source-index-check.json",
)
PAPER_FIXED_V2 = SOURCES + (
    "references-v2.bib", "references.bib", "literature-v2.md", "editorial-notes.md",
    "reading-guide.md", "source-availability.md",
    "source-correspondence.md", "source-correspondence-v2.md",
    "verification.md", "packaging-README.md",
    "zenodo-metadata.json", "zenodo-metadata-v2.json",
    "figures/make_figures.py", "figures/make_figures_v2.py",
    "figures/manifest.json", "figures/manifest-v2.json", "figures/README.md",
    "scripts/build_reading.py", "scripts/table-layout.lua",
    "scripts/render_pdf_review.py", "scripts/package_editable.py",
    "scripts/check_manuscript.py", "scripts/build_source_index.py",
    "scripts/build_source_index_v2.py",
    "records/manuscript-consistency-v2.json", "records/figure-build-pdfs-v2.json",
    "records/cf17-source-binding.json",
    "records/manuscript-consistency.json",
    "records/public-source-binding.json", "records/source-selection.json",
    "records/source-audit.md", "records/literature-audit.md",
    "records/figure-build-pdfs.json",
    "records/figure-build-source-identities.json", "records/source-index-check.json",
    "records/zenodo-release-review.json",
)
PRIVATE_PATH = re.compile(rb"(?:file://)?/(?:Users|home|Volumes)/(?![\s\"'`<>])[^\r\n\"'`<>]+")
PRIVATE_MATERIAL = re.compile(
    rb"(?:^|[/\\\s\"'])\.(?:work|agents|lake)(?:[/\\]|$)"
    rb"|(?:^|[/\\\s\"'])(?:private[-_]?prompts?|raw[-_]?private)(?:[/\\]|$)", re.I)
CREDENTIAL = re.compile(
    rb"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"
    rb"|\bAuthorization\s*[:=]\s*[\"']?Bearer\s+\S+"
    rb"|[\"'](?:token|api[_-]?key|access[_-]?token)[\"']\s*:\s*"
    rb"[\"'][A-Za-z0-9_./+=-]{16,}[\"']", re.I)
FORBIDDEN_PARTS = {".git", ".work", ".agents", ".lake", "private-prompts", "raw-private",
                   "__pycache__", ".review", ".review-v2", "pdf-work", "pdf-work-en",
                   "pdf-work-supplement", "pdf-work-supplement-en", "pdf-review", "pdf-review-v2"}
TEXT_EXTENSIONS = {".md", ".json", ".py", ".lua", ".tex", ".bib", ".lean", ".svg", ".txt"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def relative_member(name: str) -> None:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or "\\" in name:
        raise ValueError("Unsafe archive member: " + name)
    if set(p.parts) & FORBIDDEN_PARTS or p.name in {"AGENTS.md", "SKILL.md", ".DS_Store"} or p.suffix in {".png", ".pyc", ".log", ".aux", ".toc"}:
        raise ValueError("Excluded artifact: " + name)
    if name.startswith("papers/") and not name.startswith(REL + "/"):
        raise ValueError("Another paper is outside this bundle: " + name)


def allowlist(edition: str, review_records: list[str]) -> list[str]:
    if edition == "v2":
        paper = list(PAPER_FIXED_V2)
        paper.extend("build/reading-review-v2/" + p for p in PDF_NAMES)
        paper.extend("source-excerpts/" + p for p in EXCERPTS)
        for stem in FIGURES_V2:
            for language in ("", "-en"):
                for extension in (".svg", ".pdf"):
                    paper.append("figures/" + stem + language + extension)
    else:
        paper = list(PAPER_FIXED_V1)
        paper.extend("build/" + p for p in PDF_NAMES)
        paper.extend("source-excerpts/" + p for p in EXCERPTS)
        for stem in FIGURES_V1:
            for language in ("", "-en"):
                for extension in (".svg", ".pdf"):
                    paper.append("figures/" + stem + language + extension)
    for item in review_records:
        path = PurePosixPath(item)
        if path.parts[:1] != ("records",) or path.suffix not in {".json", ".md"}:
            raise ValueError("Review records must be explicit JSON/Markdown files in records/.")
        relative_member(REL + "/" + item)
        paper.append(item)
    names = sorted(set(REL + "/" + p for p in paper) | set(SHARED))
    for name in names:
        relative_member(name)
    return names


def exported_copy(edition: str, name: str, data: bytes) -> tuple[bytes, list[str]]:
    changes = []
    if Path(name).suffix not in TEXT_EXTENSIONS:
        return data, changes
    text = data.decode("utf-8")
    if name in (REL + "/figures/make_figures.py", REL + "/figures/make_figures_v2.py"):
        updated = re.sub(r"(?m)^Run with /[^\n]+/bin/python\.$",
                         "Run with python3 in an environment with the figure dependencies.", text)
        if updated != text:
            changes.append("Replaced the author-specific interpreter hint with python3.")
            text = updated
    if name == REL + "/scripts/build_reading.py":
        old = 'str(Path.home()/".venvs/figtools/bin/python")'
        if old in text:
            text = text.replace(old, "sys.executable")
            changes.append("The --figures subprocess uses the active Python interpreter.")
    if name.endswith(".md"):
        updated = re.sub(r"\[([^\]]+)\]\((?:\.\./)?claims\.md(?:#[^)]*)?\)",
                         r"\1（仓库工作记录，不随本可编辑包提供）", text)
        if updated != text:
            changes.append("Kept the repository-only claims label as plain text.")
            text = updated
        if edition == "v2":
            updated = re.sub(
                r"\[([^\]]+)\]\((?:\.\./)+roadmap\.md(?:#[^)]*)?\)",
                r"\1（仓库全局排期，不随本单篇可编辑包提供）",
                text,
            )
            updated = re.sub(
                r"\[([^\]]+)\]\((?:\.\./)+shared/zenodo-publications-20261104\.json(?:#[^)]*)?\)",
                r"\1（Zenodo v1 归档登记，DOI: 10.5281/zenodo.23927949）",
                updated,
            )
            updated = re.sub(
                r"\[([^\]]+)\]\(build/(capital-formation(?:-en|-supplement(?:-en)?|-v1-editable)?\.(?:pdf|zip))\)",
                r"\1（Zenodo v1 冻结成品 `\2`）",
                updated,
            )
            if updated != text:
                changes.append("Converted repository-level and frozen-v1 binary links to descriptive text in the v2 bundle.")
                text = updated
    if name.endswith(".md"):
        updated = re.sub(r"/(?:Users|home)/[A-Za-z0-9_./-]+/bin/python\b", "python3", text)
        if updated != text:
            changes.append("Replaced author-specific Python commands with the active python3 environment.")
            text = updated
    if name == REL + "/reading-guide.md":
        text += "\n\n## 可编辑包中的图件范围\n\n本包提供SVG与同名矢量PDF；记录中列明的PNG预览及逐页审阅图可由脚本重建，不随本包提供。\n"
        changes.append("Clarified that recorded PNG previews and page renders are not bundled.")
    if name.startswith(REL + "/records/"):
        prefix = ROOT.as_posix() + "/"
        if prefix in text:
            text = text.replace(prefix, "")
            changes.append("Converted workspace-root paths in the copied record to bundle-relative paths.")
    if name == REL + "/records/figure-optimization-review.json":
        original = json.loads(text)
        command = original["mechanical_checks"]["generator_command"]
        public_command = "python3 papers/capital-formation/figures/make_figures.py"
        if command != public_command:
            if not re.fullmatch(r"/(?:Users)/[^/\s]+/\.venvs/figtools/bin/python "
                                r"papers/capital-formation/figures/make_figures\.py", command):
                raise ValueError("Unexpected original figure-review interpreter command.")
            before, after = json.dumps(command, ensure_ascii=False), json.dumps(public_command)
            text = text.replace(before, after, 1)
            changes.append("Made the recorded figure interpreter portable; all other JSON bytes and original review conclusions are unchanged.")
    result = text.encode("utf-8")
    if name in SHARED and result != data:
        raise ValueError("Shared dependencies must be copied byte for byte.")
    return result, changes


def scan_public(name: str, data: bytes) -> None:
    if PRIVATE_PATH.search(data) or PRIVATE_MATERIAL.search(data) or CREDENTIAL.search(data):
        raise ValueError("Private path, credential or internal prompt material in " + name)


def validate_receipts_v2(payload: dict[str, bytes]) -> dict:
    at = lambda p: payload[REL + "/" + p]
    receipt = json.loads(at("records/figure-build-pdfs-v2.json"))
    builds = receipt["builds"]
    expected_pdfs = {REL + "/build/reading-review-v2/" + p for p in PDF_NAMES}
    if {b["pdf"] for b in builds} != expected_pdfs or len(builds) != 4:
        raise ValueError("The v2 build receipt must bind exactly the four v2 PDFs.")
    for build in builds:
        for kind, key in (("manuscript", "source_sha256"), ("pdf", "pdf_sha256")):
            name = build[kind]
            if sha(payload[name]) != build[key]:
                raise ValueError("Stale v2 build receipt for " + name)
        if build.get("missing_characters") or build.get("overfull_boxes") or build.get("fitted_displays"):
            raise ValueError("A v2 PDF still has recorded layout findings.")
    figures = json.loads(at("figures/manifest-v2.json"))
    if len(figures["figures"]) != 12:
        raise ValueError("Expected twelve bilingual v2 figure entries.")
    for figure in figures["figures"]:
        for kind in ("svg", "pdf"):
            item = figure["files"][kind]
            name = REL + "/figures/" + item["path"]
            if sha(payload[name]) != item["sha256"]:
                raise ValueError("v2 figure manifest mismatch: " + name)
    consistency = json.loads(at("records/manuscript-consistency-v2.json"))
    if consistency["status"] != "passed" or consistency.get("edition") != "v2":
        raise ValueError("v2 manuscript consistency check has not passed.")
    for name in SOURCES:
        if consistency["manuscripts"][name] != sha(at(name)):
            raise ValueError("Stale v2 manuscript consistency record: " + name)
    if consistency["bibliography_sha256"] != sha(at("references-v2.bib")):
        raise ValueError("Stale v2 bibliography hash.")
    cf17 = json.loads(at("records/cf17-source-binding.json"))
    if cf17["module_count"] != 55 or cf17["claim"] != "CF17":
        raise ValueError("Unexpected CF17 source binding summary.")
    binding = json.loads(at("records/public-source-binding.json"))
    if binding["source_selection_sha256"] != sha(at("records/source-selection.json")):
        raise ValueError("The public source binding uses an earlier source selection.")
    preserved = []
    for row in binding["entries"]:
        if "preserved_source" in row:
            path = row["preserved_source"]["path"]
            if sha(at(path)) != row["source_sha256"]:
                raise ValueError("Preserved source byte mismatch: " + path)
            preserved.append(path)
    if set(preserved) != {"source-excerpts/" + p for p in EXCERPTS}:
        raise ValueError("The five preserved source identities are not exactly covered.")
    return {
        "edition": "v2",
        "final_pdf_source_bindings": "pass",
        "figure_svg_pdf_hashes": "pass",
        "cf17_source_binding_modules": cf17["module_count"],
        "source_selection_binding": "pass",
        "five_preserved_source_files": "pass",
        "pdf_sha256": {b["pdf"]: b["pdf_sha256"] for b in builds},
        "source_sha256": {b["manuscript"]: b["source_sha256"] for b in builds},
    }


def validate_receipts_v1(payload: dict[str, bytes]) -> dict:
    at = lambda p: payload[REL + "/" + p]
    receipt = json.loads(at("records/figure-build-pdfs.json"))
    builds = receipt["builds"]
    expected_pdfs = {REL + "/build/" + p for p in PDF_NAMES}
    if {b["pdf"] for b in builds} != expected_pdfs or len(builds) != 4:
        raise ValueError("The build receipt must bind exactly the four final PDFs.")
    for build in builds:
        for kind, key in (("manuscript", "source_sha256"), ("pdf", "pdf_sha256")):
            name = build[kind]
            if sha(payload[name]) != build[key]:
                raise ValueError("Stale build receipt for " + name)
        if build.get("missing_characters") or build.get("overfull_boxes"):
            raise ValueError("A final PDF still has recorded layout findings.")
    figures = json.loads(at("figures/manifest.json"))
    if len(figures["figures"]) != 10:
        raise ValueError("Expected ten bilingual figure entries.")
    for figure in figures["figures"]:
        for kind in ("svg", "pdf"):
            item = figure["files"][kind]
            name = REL + "/figures/" + item["path"]
            if sha(payload[name]) != item["sha256"]:
                raise ValueError("Figure manifest mismatch: " + name)
    consistency = json.loads(at("records/manuscript-consistency.json"))
    if consistency["status"] != "passed":
        raise ValueError("Manuscript consistency check has not passed.")
    for name in SOURCES:
        if consistency["manuscripts"][name] != sha(at(name)):
            raise ValueError("Stale manuscript consistency record: " + name)
    binding = json.loads(at("records/public-source-binding.json"))
    if binding["source_selection_sha256"] != sha(at("records/source-selection.json")):
        raise ValueError("The public source binding uses an earlier source selection.")
    preserved = []
    for row in binding["entries"]:
        if "preserved_source" in row:
            path = row["preserved_source"]["path"]
            if sha(at(path)) != row["source_sha256"]:
                raise ValueError("Preserved source byte mismatch: " + path)
            preserved.append(path)
    if set(preserved) != {"source-excerpts/" + p for p in EXCERPTS}:
        raise ValueError("The five preserved source identities are not exactly covered.")
    return {
        "edition": "v1",
        "final_pdf_source_bindings": "pass",
        "figure_svg_pdf_hashes": "pass",
        "source_selection_binding": "pass",
        "five_preserved_source_files": "pass",
        "pdf_sha256": {b["pdf"]: b["pdf_sha256"] for b in builds},
        "source_sha256": {b["manuscript"]: b["source_sha256"] for b in builds},
    }


def validate_links(payload: dict[str, bytes]) -> dict:
    checked = 0
    for name, raw in payload.items():
        if not name.endswith(".md"):
            continue
        text = raw.decode("utf-8")
        fence = r"(?ms)^[ \t]*(" + chr(96) + r"{3,}|~{3,})[^\n]*\n.*?^[ \t]*\1[ \t]*$"
        text = re.sub(fence, "", text)
        for match in re.finditer(r"\[[^\]]*\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)", text):
            target = match.group(1)
            if re.match(r"^(?:https?://|mailto:|#)", target):
                continue
            target = target.split("#", 1)[0]
            if not target:
                continue
            resolved = os.path.normpath(str(PurePosixPath(name).parent / target)).replace("\\", "/")
            directory_present = target.endswith("/") and any(p.startswith(resolved + "/") for p in payload)
            if resolved not in payload and not directory_present:
                raise ValueError("Unbundled local link: " + name + " -> " + target)
            checked += 1
    return {"local_markdown_links": checked, "unbundled_local_links": 0}


def isolated_dependency_check(payload: dict[str, bytes]) -> dict:
    for name, raw in payload.items():
        if name.endswith(".py"):
            ast.parse(raw.decode(), filename=name)
    for name in SHARED:
        if name.endswith(".tex"):
            for target in re.findall(r"\\(?:input|include)\{([^}]+)\}", payload[name].decode()):
                resolved = str(PurePosixPath(name).parent / target)
                if resolved not in payload and resolved + ".tex" not in payload:
                    raise ValueError("Missing TeX include: " + resolved)
    with tempfile.TemporaryDirectory(prefix="package-dependencies-", dir=PAPER / "build") as work:
        stage = Path(work)
        for name, data in payload.items():
            dest = stage / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        script = stage / REL / "scripts/build_reading.py"
        spec = importlib.util.spec_from_file_location("packaged_capital_reading", script)
        module = importlib.util.module_from_spec(spec)
        old_path = list(sys.path)
        previous_byline = sys.modules.pop("byline", None)
        try:
            spec.loader.exec_module(module)
            if module.PUBLISH != stage:
                raise ValueError("Packaged builder escaped the extracted root.")
            prepared = []
            for (_, _), (rel, _) in module.TARGETS.items():
                source = stage / rel
                lines = source.read_text().splitlines()
                module.builder.byline.pop(lines)
                lang = "en" if source.name.endswith("-en.md") else "zh"
                profile = dict(module.builder.PROFILES[lang], continuous_appendices=True)
                title, subtitle, body = module.prepare("\n".join(lines) + "\n", True, profile)
                body = module.builder.vector_figures(body, source.parent, stage / "dependency-check")
                if not title or not body:
                    raise ValueError("Empty prepared manuscript: " + rel)
                for target in re.findall(r"!\[[^\]]*\]\(([^)\s]+)", body):
                    if not Path(target).is_file() or not Path(target).is_relative_to(stage):
                        raise ValueError("Image dependency escaped or is missing: " + target)
                prepared.append(rel)
        finally:
            sys.path[:] = old_path
            sys.modules.pop("byline", None)
            if previous_byline is not None:
                sys.modules["byline"] = previous_byline
    return {
        "python_syntax": "pass", "shared_runtime_imports": "pass",
        "isolated_preparation": prepared, "svg_to_vector_pdf_resolution": "pass",
        "additional_tex_input_files": 0,
        "external_environment": [
            "Python 3.10+", "Pandoc 3", "XeLaTeX with the listed TeX packages",
            "Noto Serif/Sans CJK SC and Latin Modern fonts",
        ],
        "optional_figure_regeneration": ["fontTools", "PyMuPDF", "Google Chrome",
                                          "Noto Serif CJK SC", "STIX Two Text/Math"],
        "optional_page_review": ["PyMuPDF", "Pillow"],
        "scope": "Imports, preparation, image closure and explicit TeX includes; not a second full TeX rebuild.",
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--edition", choices=["v1", "v2"], default="v2")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--review-record", action="append", default=[])
    ap.add_argument("--output", type=Path, default=None)
    ap.add_argument("--audit-output", type=Path, default=None)
    args = ap.parse_args()

    default_out = (
        PAPER / "build/reading-review-v2/capital-formation-v2-editable.zip"
        if args.edition == "v2"
        else PAPER / "build/capital-formation-editable.zip"
    )
    default_audit = (
        PAPER / "records/package-audit-v2.json"
        if args.edition == "v2"
        else PAPER / "records/package-audit.json"
    )
    output_path = (args.output or default_out).resolve()
    audit_path = (args.audit_output or default_audit).resolve()

    if output_path == (PAPER / "build/capital-formation-v1-editable.zip").resolve():
        raise ValueError("Refusing to overwrite frozen Zenodo v1 archive.")
    if audit_path in {
        (PAPER / "records/zenodo-package-audit.json").resolve(),
        (PAPER / "records/package-audit.json").resolve() if args.edition == "v2" else Path("/nonexistent"),
    }:
        raise ValueError("Refusing to overwrite frozen v1 packaging audit.")

    names = allowlist(args.edition, args.review_record)
    missing = [name for name in names if not (ROOT / name).is_file()]
    if missing:
        print(json.dumps({"status": "waiting-for-required-inputs", "missing": missing},
                         ensure_ascii=False, indent=2))
        raise SystemExit(2)

    payload, entries = {}, []
    for name in names:
        source = ROOT / name
        if source.is_symlink():
            raise ValueError("Symlink not allowed: " + name)
        raw = source.read_bytes()
        data, changes = exported_copy(args.edition, name, raw)
        scan_public(name, data)
        payload[name] = data
        entries.append({
            "path": name, "bytes": len(data), "sha256": sha(data),
            "source_sha256": sha(raw), "packaging_changes": changes,
            "read_only_shared_dependency": name in SHARED,
        })
    payload["README.md"] = (
        f"# The Structural Theorem of Capitalism ({args.edition}) — editable bundle\n\n"
        "Open [the rebuild guide](papers/capital-formation/packaging-README.md) "
        "for contents, requirements and commands. "
        "The paper and shared dependency directories retain their relative layout.\n"
    ).encode("utf-8")

    checks = (
        validate_receipts_v2(payload)
        if args.edition == "v2"
        else validate_receipts_v1(payload)
    )
    checks.update(validate_links(payload))
    checks["rebuild_dependencies"] = isolated_dependency_check(payload)
    pending_review = b"FINAL_" in payload[REL + "/verification.md"]

    entries.append({"path": "README.md", "bytes": len(payload["README.md"]),
                    "sha256": sha(payload["README.md"]), "generated": True})
    manifest = {
        "schema": f"capital-formation/editable-package@{2 if args.edition == 'v2' else 1}",
        "edition": args.edition,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Only capital-formation and its explicitly required read-only shared dependencies.",
        "members": entries,
        "checks": checks,
        "omitted": ["Other papers", "planning claims", "PNG previews", "page renders",
                    "TeX intermediates", "caches", "fonts and external executables"],
        "manifest_note": "This manifest lists all payload members except itself. The outer zip hash is in the packaging receipt.",
    }
    payload["PACKAGE-MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    for name in payload:
        relative_member(name)
        scan_public(name, payload[name])
    if args.check:
        print(json.dumps({
            "edition": args.edition,
            "status": "dependencies-ready-final-review-pending" if pending_review else "ready",
            "members": len(payload),
            "checks": checks,
        }, ensure_ascii=False, indent=2))
        return
    if pending_review:
        raise ValueError("Final visual verification has not yet been signed off.")
    if not output_path.is_relative_to(PAPER / "build"):
        raise ValueError("Keep the archive inside this paper's build directory.")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_suffix(".zip.tmp")
    zip_dt = (2026, 11, 12, 0, 0, 0) if args.edition == "v2" else (2026, 11, 4, 0, 0, 0)
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name in sorted(payload):
                info = zipfile.ZipInfo(name, date_time=zip_dt)
                info.compress_type = zipfile.ZIP_DEFLATED
                mode = 0o444 if name in SHARED else (0o755 if name.endswith(".py") else 0o644)
                info.external_attr = (stat.S_IFREG | mode) << 16
                z.writestr(info, payload[name])
        with zipfile.ZipFile(temporary) as z:
            if set(z.namelist()) != set(payload) or len(z.namelist()) != len(payload):
                raise ValueError("Archive member allowlist mismatch.")
            if z.testzip() is not None:
                raise ValueError("Archive CRC failure.")
            for name in z.namelist():
                if z.read(name) != payload[name]:
                    raise ValueError("Archive bytes mismatch: " + name)
        temporary.replace(output_path)
    finally:
        temporary.unlink(missing_ok=True)
    result = {
        "schema": f"capital-formation/packaging-audit@{2 if args.edition == 'v2' else 1}",
        "edition": args.edition,
        "created_utc": manifest["created_utc"],
        "archive": output_path.relative_to(ROOT).as_posix(),
        "sha256": sha(output_path.read_bytes()),
        "bytes": output_path.stat().st_size,
        "member_count": len(payload),
        "member_allowlist": sorted(payload),
        "checks": checks,
        "shared_dependencies_copied_verbatim": list(SHARED),
        "packaging_transformations": {e["path"]: e["packaging_changes"]
                                     for e in entries if e.get("packaging_changes")},
    }
    if not audit_path.is_relative_to(PAPER / "records") or audit_path.relative_to(ROOT).as_posix() in payload:
        raise ValueError("Keep a distinct packaging receipt in this paper's records directory.")
    audit_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
