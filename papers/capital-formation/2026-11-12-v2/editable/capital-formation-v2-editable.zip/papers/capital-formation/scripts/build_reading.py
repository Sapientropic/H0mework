#!/usr/bin/env python3
"""Build only this paper's Chinese/English main texts and supplements.
Defaults to --output-dir build/reading-review-v2 so published v1 PDFs in build/ remain byte-identical.
The shared typography and figure filter are read-only dependencies.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
SHARED = PUBLISH / "shared" / "scripts"
sys.dont_write_bytecode = True
sys.path.insert(0, str(SHARED))
spec = importlib.util.spec_from_file_location("capital_shared_pdf", SHARED / "build_pdf.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
REL = PAPER.relative_to(PUBLISH).as_posix()
TARGETS = {
    ("main", "zh"): (f"{REL}/manuscript.md", ("capital-formation", "资本主义的结构总定理", "最小支撑、公共重放与风险定价")),
    ("main", "en"): (f"{REL}/manuscript-en.md", ("capital-formation", "The Structural Theorem of Capitalism", "Minimal support, public replay, and risk pricing")),
    ("supplement", "zh"): (f"{REL}/supplement.md", ("capital-formation-supplement", "资本主义的结构总定理", "技术附录")),
    ("supplement", "en"): (f"{REL}/supplement-en.md", ("capital-formation-supplement", "The Structural Theorem of Capitalism", "Technical supplement")),
}
for rel, heads in TARGETS.values():
    builder.EXPLICIT_RUNHEADS[rel] = heads
    builder.CONTINUOUS_APPENDICES.add(rel)
shared_prepare = builder.prepare
shared_latin_title = builder.latin_title


def latin_title(line):
    if re.match(r"^#{1,2}\s+(?:Abstract\b|References\b|[A-H](?:\.\d+)*\s|\d+(?:\.\d+)*\s)", line.strip()):
        return None
    return shared_latin_title(line)


builder.latin_title = latin_title
shared_run = builder.run


def run(command, **kwargs):
    command = list(command)
    if command and str(command[0]) == "pandoc":
        command.extend(["--lua-filter", str(PAPER / "scripts/table-layout.lua")])
    return shared_run(command, **kwargs)


builder.run = run


def prepare(source, toc, profile):
    override = ""
    if source.startswith("# 资本主义的结构总定理\n"):
        for candidate in (
            "全形态最小支撑、公共功能重放与唯一最小风险定价",
            "全形态刻画、公共替代与共同清算",
        ):
            marker = "\n## " + candidate + "\n"
            if marker in source:
                if source.count(marker) != 1:
                    raise RuntimeError("Ambiguous Chinese subtitle.")
                source = source.replace(marker, "\n", 1)
                override = candidate
                break
    title, subtitle, body = shared_prepare(source, toc, profile)
    for definition in ("\n\n记当前未清零的正责任坐标个数为\n\\[\nB(x)=", "\n\n记\n\\[\nB(x)="):
        if definition in body:
            body = body.replace(
                definition,
                "\n\n```{=latex}\n\\Needspace{6\\baselineskip}\n```" + definition,
                1,
            )
            break
    if override:
        if subtitle:
            raise RuntimeError("Unexpected extra subtitle.")
        subtitle = override
    ref = re.search("(?m)" + builder.REFERENCES, body)
    if ref:
        opening = "```{=latex}\n\\noindent\\begin{minipage}{\\linewidth}\n```\n\n"
        prefix = body[:ref.start()]
        if not prefix.endswith(opening):
            raise RuntimeError("Shared bibliography wrapper changed.")
        body = prefix[:-len(opening)] + body[ref.start():]
        closing = "\\endgroup\\end{minipage}\\par"
        end = body.rfind(closing)
        if end < 0:
            raise RuntimeError("Shared bibliography end changed.")
        body = body[:end] + "\\endgroup\\par" + body[end + len(closing):]
    lines = body.splitlines(keepends=True)
    result = []
    fenced = False
    for index, ln in enumerate(lines):
        if ln.lstrip().startswith("```"):
            fenced = not fenced
        if not fenced and re.match(r"^# ", ln):
            following = next((x for x in lines[index + 1:] if x.strip()), "")
            if following.startswith("## "):
                result.append("```{=latex}\n\\Needspace{13\\baselineskip}\n```\n\n")
        if not fenced and re.match(r"^## ", ln):
            result.append("```{=latex}\n\\Needspace{8\\baselineskip}\n```\n\n")
        result.append(ln)
    return title, subtitle, "".join(result)


builder.prepare = prepare


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--language", choices=["zh", "en", "both"], default="both")
    ap.add_argument("--part", choices=["main", "supplement", "all"], default="all")
    ap.add_argument("--no-toc", action="store_true")
    ap.add_argument("--figures", action="store_true")
    ap.add_argument("--output-dir", type=Path, default=PAPER / "build" / "reading-review-v2")
    args = ap.parse_args()
    if args.output_dir.resolve() == (PAPER / "build").resolve():
        raise SystemExit("Refusing to overwrite frozen Zenodo v1 PDFs in build/; use build/reading-review-v2 or another subdirectory.")
    if args.figures:
        subprocess.run([sys.executable, str(PAPER / "figures/make_figures_v2.py")], check=True)
    langs = ["zh", "en"] if args.language == "both" else [args.language]
    parts = ["main", "supplement"] if args.part == "all" else [args.part]
    reports = []
    for part in parts:
        for lang in langs:
            rel, _ = TARGETS[(part, lang)]
            source = PUBLISH / rel
            if not source.is_file():
                raise FileNotFoundError(source)
            source_bytes = source.read_bytes()
            source_digest = hashlib.sha256(source_bytes).hexdigest()
            print(json.dumps({"building": rel}, ensure_ascii=False), flush=True)
            report = builder.build(rel, toc=not args.no_toc, output_dir=args.output_dir)
            pdf = PUBLISH / report["pdf"]
            if source.read_bytes() != source_bytes:
                raise RuntimeError("Manuscript changed during build; rebuild its stable version.")
            report.update(
                source_sha256=source_digest,
                pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),
                part=part,
                language=lang,
            )
            reports.append(report)
            print(json.dumps(report, ensure_ascii=False), flush=True)
    record = {
        "edition": "v2",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "only capital-formation v2",
        "visual_review": "Requires actual display of the final PDF pages.",
        "builds": reports,
    }
    name = "figure-build-pdfs-v2" + ("-" + args.part if args.part != "all" else "") + ("-" + args.language if args.language != "both" else "") + ".json"
    (PAPER / "records" / name).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if any(r["missing_characters"] or r["overfull_boxes"] for r in reports):
        raise SystemExit("Layout findings remain; inspect this paper's build reports.")


if __name__ == "__main__":
    main()
