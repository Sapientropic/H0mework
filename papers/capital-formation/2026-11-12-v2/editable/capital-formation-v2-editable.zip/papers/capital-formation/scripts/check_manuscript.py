#!/usr/bin/env python3
"""Check publication identities that can silently drift between language editions.
Defaults to --edition v2 (writing records/manuscript-consistency-v2.json without touching v1 records).
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re

PAPER = Path(__file__).resolve().parents[1]


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--edition", choices=["v1", "v2"], default="v2")
    args = ap.parse_args()

    expected_results = 19 if args.edition == "v2" else 18
    expected_eqs = 28 if args.edition == "v2" else 25
    expected_refs = 30 if args.edition == "v2" else 18
    expected_figs = 6 if args.edition == "v2" else 5
    expected_dblocks = 32
    bib_file = "references-v2.bib" if args.edition == "v2" else "references.bib"

    z = (PAPER / "manuscript.md").read_text(encoding="utf-8")
    e = (PAPER / "manuscript-en.md").read_text(encoding="utf-8")
    reports = {}
    for lang, text, marker, pattern, ex_pat in [
        ("zh", z, "## 参考文献", r"\*\*(定理|命题)(\d+)", r"\*\*(例)(\d+)"),
        ("en", e, "## References", r"\*\*(Theorem|Proposition)\s+(\d+)\b", r"\*\*(Example)\s+(\d+)\b"),
    ]:
        assert marker in text, (lang, "references heading")
        body, refs = text.split(marker, 1)
        results = re.findall(pattern, body)
        assert [int(n) for _, n in results] == list(range(1, expected_results + 1)), (lang, "results", results)
        assert [int(n) for k, n in results if k in ("命题", "Proposition")] == [10], (lang, "proposition index")
        if args.edition == "v2":
            examples = re.findall(ex_pat, body)
            assert [int(n) for _, n in examples] == [1, 2], (lang, "examples", examples)
        equations = re.findall(r"\\tag\{(\d+)\}", body)
        assert list(map(int, equations)) == list(range(1, expected_eqs + 1)), (lang, "equation numbering", equations)
        keys = re.findall(r"^\[([A-Za-z][A-Za-z0-9]+)\]", refs, re.M)
        cblocks = re.findall(r"\[@[^\]]+\]", body)
        used = re.findall(r"@([A-Za-z][A-Za-z0-9]+)", " ".join(cblocks))
        assert len(keys) == expected_refs and len(set(keys)) == expected_refs and set(used) == set(keys), (
            lang, "citations", len(keys), set(keys) ^ set(used)
        )
        figures = re.findall(r"!\[[^\]]*\]\((figures/[^)]+)\)", body)
        assert len(figures) == expected_figs and all((PAPER / f).is_file() for f in figures), (lang, "figures", figures)
        if args.edition == "v2":
            expected_suffix = "-v2-en.svg" if lang == "en" else "-v2.svg"
        else:
            expected_suffix = "-en.svg" if lang == "en" else ".svg"
        assert all(f.endswith(expected_suffix) for f in figures), (lang, "figure suffix", figures)
        assert "原构造" not in body and "私人阶段" not in body and "直接消费者" not in body, (lang, "jargon leak")
        if lang == "en":
            # Verify zero full-width CJK punctuation or stray Chinese in English body
            assert not re.search(r"[\u3000-\u303f\uff00-\uffef]", body), "Full-width punctuation in English body"
            body_no_author = body.replace("(高健)", "")
            assert not re.search(r"[\u4e00-\u9fff]", body_no_author), "Stray CJK characters in English body"
        reports[lang] = {
            "numbered_results": len(results),
            "numbered_equations": len(equations),
            "display_math_blocks": len(re.findall(r"\\\[(.*?)\\\]", body, re.S)),
            "references": keys,
            "citation_blocks": [b[1:-1] for b in cblocks],
            "section_numbers": re.findall(r"^#{2,3}\s+(\d+(?:\.\d+)*)\s+", body, re.M),
            "figures": figures,
        }

    assert reports["zh"]["references"] == reports["en"]["references"], "Reference order mismatch"
    assert reports["zh"]["section_numbers"] == reports["en"]["section_numbers"], "Section numbering mismatch"
    assert reports["zh"]["display_math_blocks"] == reports["en"]["display_math_blocks"] == expected_dblocks, (
        "Display math block count mismatch",
        reports["zh"]["display_math_blocks"],
        reports["en"]["display_math_blocks"],
    )
    zcite = [re.findall(r"@?([A-Za-z][A-Za-z0-9]+)", b) for b in reports["zh"]["citation_blocks"]]
    ecite = [re.findall(r"@?([A-Za-z][A-Za-z0-9]+)", b) for b in reports["en"]["citation_blocks"]]
    assert zcite == ecite, ("Citation block key alignment mismatch", zcite, ecite)

    bib = (PAPER / bib_file).read_text(encoding="utf-8")
    bibkeys = re.findall(r"@\w+\s*\{\s*([^,\s]+)", bib)
    assert bibkeys == reports["zh"]["references"], ("BibTeX order/key mismatch", bibkeys, reports["zh"]["references"])

    sz = (PAPER / "supplement.md").read_text(encoding="utf-8")
    se = (PAPER / "supplement-en.md").read_text(encoding="utf-8")
    assert re.findall(r"\\tag\{([^}]+)\}", sz) == re.findall(r"\\tag\{([^}]+)\}", se), "Supplement tags mismatch"
    assert len(re.findall(r"\\\[(.*?)\\\]", sz, re.S)) == len(re.findall(r"\\\[(.*?)\\\]", se, re.S)), "Supplement math block count mismatch"
    assert re.findall(r"^##\s+([A-H])(?:[ .])", sz, re.M) == re.findall(r"^##\s+([A-H])(?:[ .])", se, re.M) == list("ABCDEFGH")
    assert not re.search(r"[\u3000-\u303f\uff00-\uffef\u4e00-\u9fff]", se), "CJK or full-width punctuation in English supplement"

    binding = json.loads((PAPER / "records/public-source-binding.json").read_text(encoding="utf-8"))
    assert binding["source_selection_sha256"] == sha(PAPER / "records/source-selection.json")
    for row in binding["entries"]:
        if "preserved_source" in row:
            assert sha(PAPER / row["preserved_source"]["path"]) == row["source_sha256"]

    report = {
        "edition": args.edition,
        "status": "passed",
        "scope": "Bilingual numbering, examples, bibliography, v2 figure paths, English character hygiene, supplement formula alignment, and preserved source-selection identities.",
        "manuscripts": {n: sha(PAPER / n) for n in ("manuscript.md", "manuscript-en.md", "supplement.md", "supplement-en.md")},
        "bibliography_file": bib_file,
        "bibliography_sha256": sha(PAPER / bib_file),
        "editions": reports,
        "supplement_equations": len(re.findall(r"\\tag\{([^}]+)\}", sz)),
        "source_binding_summary": binding["summary"],
    }
    out_name = "manuscript-consistency-v2.json" if args.edition == "v2" else "manuscript-consistency.json"
    out = PAPER / "records" / out_name
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "edition": args.edition,
        "status": "passed",
        "results": expected_results,
        "equations": expected_eqs,
        "supplement_equations": report["supplement_equations"],
        "references": expected_refs,
        "citation_blocks": len(zcite),
        "figures_per_language": expected_figs,
        "sections": len(reports["zh"]["section_numbers"]),
        "output": str(out.relative_to(PAPER)),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
