-- Paper-local layout only: preserve long hashes and allocate table column widths cleanly.
function Header(el)
  if not FORMAT:match('latex') then return nil end
  if el.level == 2 then
    return {pandoc.RawBlock('latex', '\\Needspace{5\\baselineskip}'), el}
  end
  if el.level ~= 1 then return nil end
  local title = pandoc.utils.stringify(el.content)
  local short_titles = {
    ['1 Private Control Is Not the Price of Production: Problem, Pen-and-Paper Anchor, and Main Theorem'] = '1 Problem, Pen-and-Paper Anchor, and Main Theorem',
    ['6 How Productive Coordination Functions Persist Without Domination in Public Execution'] = '6 Non-Dominating Public Functional Replay',
    ['7 Off-Menu Innovation, Bounded Origin Receipts, and Unique Minimal Risk Pricing'] = '7 Innovation, Origin Bounds, and Unique Minimal Risk Pricing',
    ['7 How Unknown Innovation and Bounded Contributions Continue'] = '7 Unknown Innovation and Bounded Contributions',
    ['8 How Complete Accounts Reconnect Control Gains to Repair Responsibilities'] = '8 Complete Accounts and Repair Responsibilities',
    ['9 Clearing Costs: Attained Financial-Tail Optimality Versus Perpetually Improvable Complete Clearing'] = '9 Clearing Costs: Attainment and Strict Improvement',
    ['9 Settlement Costs: An Attained Optimum and Completion That Can Always Be Improved'] = '9 Settlement Costs: Attainment and Strict Improvement',
    ['10 Whole-Ledger Transport Across Institutional Change, Locating Regeneration, and Five-Axis Synthesis'] = '10 Whole-Ledger Transport and Five-Axis Synthesis'
  }
  if short_titles[title] then
    local latex = pandoc.write(pandoc.Pandoc({el}), 'latex')
    latex = latex:gsub('\\section{', '\\section[' .. short_titles[title] .. ']{', 1)
    return pandoc.RawBlock('latex', latex)
  end
end

function Str(el)
  if not FORMAT:match('latex') then return nil end
  local result = pandoc.List()
  local cursor = 1
  for first, token, after in el.text:gmatch('()([0-9a-f]+)()') do
    if #token >= 40 then
      if first > cursor then result:insert(pandoc.Str(el.text:sub(cursor, first - 1))) end
      result:insert(pandoc.RawInline('latex', '\\paperinlinecode{\\seqsplit{' .. token .. '}}'))
      cursor = after
    end
  end
  if cursor > 1 then
    if cursor <= #el.text then result:insert(pandoc.Str(el.text:sub(cursor))) end
    return result
  end
end

function Table(el)
  if not FORMAT:match('latex') then return nil end
  if not el.head or not el.head.rows or #el.head.rows == 0 then return nil end
  local row = el.head.rows[1]
  if #row.cells == 0 then return nil end
  local label = pandoc.utils.stringify(row.cells[1].contents)
  if #el.colspecs == 4 and
     (label == '总定理分肢' or label == 'Branch of Theorem 1') then
    el.colspecs[1][2] = 0.17
    el.colspecs[2][2] = 0.27
    el.colspecs[3][2] = 0.21
    el.colspecs[4][2] = 0.35
    return {pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.15}}\n\\setlength{\\LTpre}{0.6em}\\setlength{\\LTpost}{0.6em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
  if #el.colspecs == 4 and
     (label == '制度形态与模型' or label == 'Institutional form') then
    el.colspecs[1][2] = 0.20
    el.colspecs[2][2] = 0.24
    el.colspecs[3][2] = 0.29
    el.colspecs[4][2] = 0.27
    return {pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.15}}\n\\setlength{\\LTpre}{0.6em}\\setlength{\\LTpost}{0.6em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
  if #el.colspecs == 4 and
     (label == '学科对话主轴' or label == 'Theoretical axis') then
    el.colspecs[1][2] = 0.16
    el.colspecs[2][2] = 0.22
    el.colspecs[3][2] = 0.30
    el.colspecs[4][2] = 0.32
    return {pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.02}\\renewcommand{\\arraystretch}{1.08}}\n\\setlength{\\LTpre}{0.45em}\\setlength{\\LTpost}{0.25em}'),
      el, pandoc.RawBlock('latex', '\\endgroup\\nopagebreak[4]')}
  end
  if #el.colspecs == 3 and
     (label == '总定理分肢' or label == 'Branch of the joint theorem' or label == '审计分项' or label == 'Audit component') then
    el.colspecs[1][2] = 0.20
    el.colspecs[2][2] = 0.44
    el.colspecs[3][2] = 0.36
    return {pandoc.RawBlock('latex', '\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.08}\\renewcommand{\\arraystretch}{1.15}}\n\\setlength{\\LTpre}{0.65em}\\setlength{\\LTpost}{0.65em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
  if #el.colspecs == 2 and (label == '标识' or label == 'ID') then
    el.colspecs[1][2] = 0.09
    el.colspecs[2][2] = 0.91
    return {pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.08}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
  if #el.colspecs == 2 and (label == '回流构造' or label == 'Return constructor') then
    el.colspecs[1][2] = 0.20
    el.colspecs[2][2] = 0.80
    return {pandoc.RawBlock('latex', '\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.08}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
end
