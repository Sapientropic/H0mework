# 第二版（v2）定理、声明、消费者与固定公开源码对应

本表承担《资本主义的结构总定理》第二版（v2，`CF0–CF17`，正文 19 项编号结果、例 1–2，附录 A–H 及表 H 之 `S1–S17`）的完整源码对应；首版冻结对应表 [source-correspondence.md](source-correspondence.md)（`s001–s105`）与机器绑定 [public-source-binding.json](records/public-source-binding.json) 原字节保持不变。

## 一、固定版本与公开复现入口

1. **`CF0–CF16`（`S1–S16`，`s001–s105`）**：研究代码库 Homework 固定于 `df421ff600085cbc290a7ae946193961bed7c83b`；公开验收闭包 `H0mework.Papers.EconomicConstitutionSourceDF`（2825 模块）固定于 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) 提交 `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`，首版公开证明映射 `docs/capital-formation-map.json` 固定于提交 `7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6`。
2. **`CF17`（`S17`，`s201–s255`）**：研究代码库 Homework 固定于 `7c228ac7fd77350d3fe761c24b887cbf2f6e5afc`；公开复现靶标 `H0mework.Papers.SocietyBookRiskCompensation` 固定于 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e) 提交 `fd6147f8c337d88ebf72d91ddadef0aa601e6c2e`（基底提交 `a8e94ac1ecbc23503cab91c977b4f71e04e44cb5`，映射 `checks/society-book-map.json` 条目 `capital-risk-compensation`），独立 T1 核验回执 `iqa-capital-risk-pricing-independent-v1/verification.json` SHA-256 为 `50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`。机器绑定见 [cf17-source-binding.json](records/cf17-source-binding.json)。

## 二、第二版（v2）编号结果与首版编号映射总表

因第 7.5 节合入 `CF17` 为**定理 12**，首版定理 12–18 在第二版正文中顺延为**定理 13–19**；定理 1–9、命题 10、定理 11 保持原编号不变。

| v2 正文结果 | v1 对应编号 | 命题键 | 附录位置 | 来源组与对应条目 |
| --- | --- | --- | --- | --- |
| 例 1（§1.1） | 新增纸笔锚点 | CF1, CF3, CF14, CF17 | B.1, D.1, E.3 | S3, S7, S17（`s219–s221`） |
| 定理 1（§1.2） | 定理 1（扩至六分肢） | CF0, CF12–CF14, CF17 | A–H | S1–S17（`s001–s105`, `s201–s255`） |
| 定理 2（§3.3） | 定理 2 | CF1 | B.1 | S3（`s011`） |
| 定理 3（§3.4） | 定理 3 | CF3 | B.1 | S3（`s012–s013`） |
| 定理 4（§4.1，配表 2） | 定理 4 | CF2–CF3 | B.2, C.1 | S4–S5（`s014–s022`） |
| 定理 5（§4.2–§4.3） | 定理 5 | CF12 | C.1–C.2 | S5（`s020–s022`） |
| 定理 6（§5.1–§5.2） | 定理 6 | CF13 | C.3, D.3 | S6（`s023–s028`） |
| 定理 7（§5.4） | 定理 7 | CF12–CF13 | C.4 | S6（`s025, s028`） |
| 定理 8（§6.1–§6.2） | 定理 8 | CF14 | D.1–D.2 | S7（`s029–s034`） |
| 定理 9（§7.1–§7.2） | 定理 9 | CF8, CF11 | E.1 | S8（`s035–s037`） |
| 命题 10（§7.3） | 命题 10 | CF15 | E.1 | S8（`s038–s040`） |
| 定理 11（§7.4） | 定理 11 | CF16 | E.2 | S9（`s041–s049`） |
| **定理 12（§7.5）** | **v2 新增主定理** | **CF17** | **E.3（命题 E2、定理 E3）** | **S17（`s201–s255`）** |
| **例 2（§7.5）** | **v2 新增双消费者核验** | **CF17** | **E.3** | **S17（`s206–s223`）** |
| 定理 13（§8.1–§8.2） | 定理 12 | CF10 及收益分解 | F.1–F.2 | S11（`s057–s058, s066–s067, s091–s097`） |
| 定理 14（§8.4） | 定理 13 | 全联盟与开放机制边界 | F.3 | S11–S12（`s054–s056, s068–s073`） |
| 定理 15（§9.1） | 定理 14 | 全槽终结归档 | G.1 | S13（`s098–s105`） |
| 定理 16（§9.2） | 定理 15 | CF4 | G.1 | S13（`s074–s078`） |
| 定理 17（§9.3） | 定理 16 | CF5 | G.2–G.3 | S14–S16（`s079–s090`） |
| 定理 18（§10.1） | 定理 17 | CF6 | F.1, F.3 | S10, S12（`s050–s053, s068–s073`） |
| 定理 19（§10.2） | 定理 18 | CF7 | F.3 | S10, S12（`s068–s069`） |

其中 `S1–S16`（`s001–s105`）的逐文件 SHA-256、声明行号与消费者列表完整保存于 [source-correspondence.md](source-correspondence.md)。下文展开 `S17`（`s201–s255`，共 55 个固定模块）的逐文件对应。

## S17（`CF17`：源内双边安全包络、唯一最小必要风险补偿与两阶段整账结算）

### s201 · Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Accounts.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`43bcbdd71db1b4546e211edc6cca4e652ad116006315141e249751b69be5df6a`。
- 声明：`claimLeg` (L13)；`rawClaimIncome` (L16)；`completeItemIncome` (L26)；`completeIncome` (L31)；`raw_claim_income_is_the_complete_original_financial_position` (L34)；`complete_item_income_is_the_original_full_change` (L42)；`complete_income_is_the_original_full_account` (L52)；`completeIncome_append` (L64)；`complete_income_of_claims_neutral_word` (L70)；`completeIncome_rawItems_index_invariant` (L89)；`completeIncome_word_append` (L101)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Arithmetic.Accounts](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Accounts.lean)（公开 SHA256：`a8ac04749bbc13fca585252c4da433f540c187a736308d17ae07661bab83e3e2`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Branches.lean`。

### s202 · Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Controls.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`0492c135b39a40226169700ab347873173cc01e6d77db6844db5c2caa637dcdf`。
- 声明：`ordinaryRows` (L7)；`rareRows` (L8)；`hundredfoldRows` (L9)；`failureOnly` (L10)；`both_binary_forecasts_have_normalized_nonnegative_weights` (L12)；`both_forecasts_have_the_same_failure_exposure` (L18)；`their_exact_break_even_floors_differ` (L22)；`the_same_tenfold_payment_exceeds_or_misses_the_floor` (L26)；`a_hundredfold_payment_can_be_exactly_break_even` (L32)；`loading_alone_can_raise_the_original_three_to_one_hundred` (L38)；`no_success_is_an_exact_blocker` (L44)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Arithmetic.Controls](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Controls.lean)（公开 SHA256：`de397378f513097e9825dbfe3d2df1fc31dff0a896e1c5649eab14b4d30e6f63`）。
- 同域直接消费者：本索引无同域直接消费者，依公开靶标的递归导入链核验。

### s203 · Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Excess.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`8e409cb3e0648a943f1e2c57912f9fabaa25a7dabcce855e604488f03b2e59d7`。
- 声明：`excess_above_the_floor` (L7)；`the_entire_return_separates_compensation_and_excess` (L16)；`strictly_above_the_floor_iff` (L24)；`a_declared_loading_exposes_its_exact_excess` (L30)；`a_loading_meets_the_requirement_iff` (L39)；`zero_success_has_an_exact_return` (L46)；`zero_success_has_an_exact_feasibility_check` (L51)；`zero_success_blocks_every_reward` (L56)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Arithmetic.Excess](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Excess.lean)（公开 SHA256：`5c1e4d5fbc970096bb62e5fdfde72251e507f50e05374d59252dfe85676e6465`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Controls.lean`。

### s204 · Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Floor.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`3f243f30f312e4ff8e6e8a7eee56171d5c33790bd6f45366d0b1e57538106694`。
- 声明：`requiredReward` (L7)；`compensationFloor` (L10)；`meets_required_return_iff` (L13)；`exact_required_return_iff` (L21)；`required_reward_attains_the_return` (L29)；`required_reward_is_the_least_sufficient_payment` (L34)；`meets_compensation_requirement_iff` (L41)；`exact_compensation_requirement_iff` (L46)；`the_floor_has_no_independent_loading` (L51)；`the_original_quote_has_exactly_its_declared_loading` (L57)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Arithmetic.Floor](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Floor.lean)（公开 SHA256：`00e54a0133c0efc684e3f7211005899046003adbbc2d13c492e8cd1882e37dcf`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Excess.lean`。

### s205 · Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Interval.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`c85d822f1b5add847168371a5772b003dca4592e14f7c35d0fc9dbea885b25ea`。
- 声明：`canonicalTransfer` (L7)；`both_accounts_meet_their_baselines_iff` (L10)；`a_jointly_safe_transfer_exists_iff` (L16)；`canonical_transfer_is_in_the_interval` (L24)；`canonical_transfer_has_minimal_absolute_payment` (L33)；`any_different_safe_transfer_has_strictly_larger_absolute_payment` (L50)；`every_nonzero_canonical_payment_binds_an_original_baseline` (L68)；`an_added_loading_is_extra_payment_or_breaks_the_interval` (L84)；`every_transfer_has_an_exact_source_interval_disposition` (L93)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Arithmetic.Interval](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Arithmetic/Interval.lean)（公开 SHA256：`6ece05c3d73b0e48f2babf8a3dd766393f247a04c5290e62794df737090b8258`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Envelope.lean`。

### s206 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualBase.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`58b0636a2ecea707ba6a5f8e02d91485a751a92097df7904450cda54c1e5d2ff`。
- 声明：`base` (L24)；`base_ready` (L26)；`base_review` (L28)；`base_has_the_same_original_raw_cut` (L33)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualBase](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualBase.lean)（公开 SHA256：`bf8be1a4bfd74623c6bab4430cebc118d28a68cfa740fe19330ae695ed992dbd`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualCut.lean`。

### s207 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualBranches.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`727d1d6cc56630b496723f10bbcae2f602c8828f0c42295dcb58bbafa3420361`。
- 声明：`law` (L13)；`priceSuffix` (L15)；`wholeWord` (L16)；`every_actual_quoted_branch_is_one_of_the_original_two` (L18)；`every_actual_branch_has_its_paid_original_signal` (L26)；`every_actual_branch_selects_the_original_computed_plan` (L45)；`the_actual_branch_requests_have_no_external_price_parameter` (L73)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualBranches](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualBranches.lean)（公开 SHA256：`3a1b224fcfdfcb3491909749522236e03b2c931c4474c50495915ef7d35f51c8`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualChecks.lean`。

### s208 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualCatalogue.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`4d552631740b71a2a8322fd771fef4502615ee96c141d79f3e47f9384fb764fa`。
- 声明：`each_life_request_is_in_the_original_executed_programme` (L36)；`each_life_request_is_in_the_actual_original_source_alphabet` (L51)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualCatalogue](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualCatalogue.lean)（公开 SHA256：`18b51f45f6b98ccc26c8be92c1cf99daca36727fe83cd4bca9d5da754d68e090`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReady.lean`。

### s209 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualChecks.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`53491d68f952c849285c81cf9e84a4f1d4a27cf76150654d04c6ea6e1759a728`。
- 声明：`lifeWord` (L14)；`checkedWords` (L15)；`each_original_test_word_really_passes_the_complete_period_checks` (L17)；`every_actual_generated_schedule_has_safe_original_whole_accounts` (L59)；`every_actual_generated_schedule_passes_all_its_original_branch_checks` (L73)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualChecks](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualChecks.lean)（公开 SHA256：`0c593fa19e1d86fd470c5b7d9769b26570e99b0690ca540929af03fb3fdca61f`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReady.lean`。

### s210 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualCut.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`79f8080cf3a78253b8a40717e70c42b828a3fbc301f9166a5a0a034cabc76bef`。
- 声明：`the_actual_original_choice_is_the_existing_default_word` (L23)；`the_actual_original_selected_word_is_not_recomputed` (L43)；`base_raw_is_the_original_default_execution` (L49)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualCut](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualCut.lean)（公开 SHA256：`7177f1b4538ac97ecbe9239c270e47908fb201e5ffaeda06c7eb1bd06ce3abc0`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualState.lean`。

### s211 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualHistory.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`18453f781f7aa94cde0c19c300f5b6933cfa91f796dd05cddbc81949f95cc226`。
- 声明：`the_real_repair_keeps_each_original_consumed_input` (L31)；`the_original_paid_programme_is_still_in_the_actual_quote_history` (L45)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualHistory](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualHistory.lean)（公开 SHA256：`83818c15b9e8551dd7682e39bf60d95f97576b218bfe864ed8e25d3399a72208`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualCatalogue.lean`。

### s212 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualMechanism.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`2bbd03c60c1f6397f6004d7aef47d2adc04095168558925f40aa38803aaa3ed1`。
- 声明：`request` (L12)；`life` (L14)；`nature` (L15)；`readFee` (L16)；`produce` (L17)；`loan` (L18)；`funding` (L19)；`repay` (L20)；`task` (L22)；`code` (L28)；`mechanism` (L52)；`signal` (L63)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualMechanism](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualMechanism.lean)（公开 SHA256：`da3f1b80c20d19b221803f325c3ab8d88e85b64ec321677ac9b4b720ffc8d9ec`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualOutside.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReadback.lean`。

### s213 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualOutside.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`1074fd93bae6a5649ecbf96536b56d875397f383349f2a56225ff27eaa300aff`。
- 声明：`two_paid_lives_use_the_entire_original_two_request_budget` (L37)；`every_two_request_paid_outside_word_has_no_spare_productive_income` (L65)；`every_two_request_outside_word_has_its_exact_original_living_account` (L102)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualOutside](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualOutside.lean)（公开 SHA256：`c83b767e95d7beb1b6538d8edcbc982f5481ffb4f764c106140e335d74dcd98b`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualQuote.lean`。

### s214 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualQuote.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`2c8c40c56b9a9a30628cc4549af0f3b9fd99538656e8761b38862084bfa39e5d`。
- 声明：`every_actual_outside_word_has_the_same_complete_account` (L12)；`every_actual_schedule_uses_the_original_unreloaded_programme` (L24)；`both_actual_outside_amounts_are_computed_zero` (L30)；`quoteAmount` (L43)；`quoted` (L48)；`the_actual_original_root_generates_four_without_loading` (L51)；`every_actual_schedule_has_its_computed_four_plan` (L63)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualQuote](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualQuote.lean)（公开 SHA256：`30f35e003e9017784e631fe1f65182d0bf76d680bfab45212abb31e9e3a02481`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualBranches.lean`。

### s215 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReadback.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`b99704a160ccfbd368e78ac2087346e8903fa7f233e7a4078e5c96b4bba2aafe`。
- 声明：`source_parameters` (L14)；`every_original_person_keeps_actual_standing` (L23)；`the_quote_uses_the_original_public_physical_law` (L33)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualReadback](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReadback.lean)（公开 SHA256：`4efe98f5de75827ae4f83f6aa013d6a8377a06d95324b938f73889b3e17f8f72`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualHistory.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualQuote.lean`。

### s216 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReady.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`6dcd0c90290da77dc0632d70255779f650ec27c35dbbe948c6847d843a8c573c`。
- 声明：`the_two_lives_are_actually_in_the_source_word_domain` (L13)；`the_two_actual_lives_pass_the_outside_checks` (L23)；`firstNature` (L28)；`the_actual_source_preparation_is_ready` (L32)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualReady](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualReady.lean)（公开 SHA256：`55e4794adcc03e822fc154514edac75c02139c3225381943090e751b44602903`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualRoot.lean`。

### s217 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualRoot.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`ba3b17aec4e5ba3039beec2545b0c5fcdfa4cff46390b677d08c9b304b582034`。
- 声明：`the_original_capital_total_contract_actually_delivers_its_generated_nonzero_risk_payment` (L12)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualRoot](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualRoot.lean)（公开 SHA256：`df56def8b8c1bd9694fd997da7b65b09ebf50ae690377eb413baa406f64fc4dd`）。
- 同域直接消费者：本索引无同域直接消费者，依公开靶标的递归导入链核验。

### s218 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualSource.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`73163458f7acdf4ff8666e490861736720df8e65bca6908fc4189b75bb3a470f`。
- 声明：`Raw` (L15)；`R` (L16)；`base_input_is_the_original_registered_input` (L18)；`the_original_food_repair_is_actually_payable` (L21)；`source` (L26)；`quoteCut` (L28)；`source_ready` (L32)；`source_review` (L36)；`the_actual_quote_cut_comes_from_the_paid_original_food_repair` (L40)；`source_input_is_the_original_registered_input` (L47)；`the_repair_really_funds_both_original_lives` (L52)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualSource](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualSource.lean)（公开 SHA256：`9a2f70387a1486d0737443c7c2e07d328b175fe8084cdf0eedaa30b63c209933`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualMechanism.lean`。

### s219 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualState.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`c41c9b9de46c978a0d1c53d5ed76477a74c7d99384463c2e5c558b61fb51c06d`。
- 声明：`settledCut` (L28)；`base_raw_is_the_real_settled_cut` (L35)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.ActualState](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualState.lean)（公开 SHA256：`6594f08ed5549ac278051b3a43b1b5e241c47ee175e4b318e63e1989184b3cf3`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualSource.lean`。

### s220 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Prices.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`e4094a0570cc8b30c6595b5c67f16e84ee016b9df2bb3b77c0ae3ab014dd273b`。
- 声明：`selectedPayment` (L7)；`classified` (L14)；`allLivingAndMaintenanceChecked` (L25)；`oldClaims` (L31)；`the_generated_price_is_really_paid_in_both_risk_branches` (L38)；`every_original_member_is_paid_and_original_claims_are_not_reset` (L42)；`a_shortfall_extra_distribution_and_overcharge_have_different_source_dispositions` (L47)；`a_live_unquoted_event_cannot_receive_a_fabricated_risk_payment` (L51)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.Prices](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Prices.lean)（公开 SHA256：`9c9b7567c470242d2d9523e2e17d01a5eafddec79ef06f7e19646542ece72c6d`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Submission.lean`。

### s221 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Registered.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`bace6ae3c8d450fc0f8f61fa5a4a76e8f4021b56cfce76830389a1b4cb9ed475`。
- 声明：`the_original_registered_capital_root_consumes_source_native_risk_compensation` (L16)；`actualSource` (L20)；`the_same_actual_paid_root_consumes_the_new_price_method` (L22)；`actualPreparation` (L27)；`actualAttempt` (L28)；`the_same_actual_root_returns_a_price_execution_or_its_exact_original_obstruction` (L32)；`every_same_root_price_attempt_keeps_all_original_responsibilities` (L38)；`the_original_capital_and_cost_contract_is_retained` (L45)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.Registered](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Registered.lean)（公开 SHA256：`4464980e07247bf8b9cb0a5f75438e1d9190b9911ae0d2434a447c4c1fb07132`）。
- 同域直接消费者：本索引无同域直接消费者，依公开靶标的递归导入链核验。

### s222 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Source.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`d42f6ce3a241898dab54406c054b957a391e6674610b7603372820b4e6333f56`。
- 声明：`R` (L10)；`Raw` (L11)；`request` (L13)；`life` (L15)；`law` (L16)；`initial` (L29)；`input` (L30)；`task` (L36)；`nature` (L42)；`readFee` (L43)；`produce` (L44)；`loan` (L45)；`funding` (L46)；`repay` (L47)；`code` (L49)；`mechanism` (L73)；`sampleSignal` (L84)；`schedule` (L86)；`quotedAmount` (L87)；`both_outside_options_really_pay_living` (L94)；`one_local_signal_covers_both_actual_risk_branches` (L99)；`the_source_generates_four_without_a_loading_or_probability_input` (L103)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.Source](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Source.lean)（公开 SHA256：`776c3d05301d58618f0a512a56ce73c5dbf87b2f0e82c52d942a851493fa3efd`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Prices.lean`。

### s223 · Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Submission.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`bbc98a7c8d5a69ec2d1d10a7ac760736ef257148b78429d9ed91e97c5a3ab489`。
- 声明：`proposedRiskWord` (L8)；`requiredRiskAmount` (L13)；`allBranchesChecked` (L18)；`the_contract_is_checked_on_every_source_branch_before_nature_is_selected` (L25)；`the_default_and_exact_explicit_quote_generate_the_same_two_real_financial_requests` (L28)；`shortfall_safe_extra_and_overcharge_cannot_write_a_required_risk_claim` (L33)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Consumers.Submission](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Submission.lean)（公开 SHA256：`83940aa604b84c3be0fca649689b1215d7ab43d3b524fc0ca1ebf4f9d77e7584`）。
- 同域直接消费者：本索引无同域直接消费者，依公开靶标的递归导入链核验。

### s224 · Universal/Abolition/Innovation/Contribution/Pricing/Outside/Compiler.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`c7d0c25b259bc8162acd1e44010893341ab87b687f9530637478fa2a79e72588`。
- 声明：`Witness` (L15)；`Witness.amount` (L22)；`Issue` (L25)；`Issue.refutes` (L30)；`rejection` (L37)；`Outcome` (L46)；`generate` (L53)；`sourceOutside` (L65)；`Witness.amount_is_actually_attained_in_the_complete_account` (L70)；`Witness.every_original_feasible_alternative_is_below_the_attained_amount` (L76)；`Witness.the_selected_alternative_has_no_fresh_or_erased_financial_claim` (L85)；`every_obstruction_excludes_every_feasible_original_alternative` (L90)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Outside.Compiler](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Outside/Compiler.lean)（公开 SHA256：`3f730839f53340f069970f5a79b336f1406052a253bc8c59b8adf4255754ceeb`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Outside/Complete.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Source/Branches.lean`。

### s225 · Universal/Abolition/Innovation/Contribution/Pricing/Outside/Complete.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`49d2a10294e43dc4a8cd12f4c687d1074cd8024bfdf3f86de299f65f9e9e5511`。
- 声明：`generated_words_cover_exactly_the_original_adequate_budgeted_grammar` (L14)；`an_outside_amount_is_returned_iff_a_real_adequate_alternative_exists` (L21)；`nativeOutside` (L34)；`native_members_are_the_original_root_census` (L37)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Outside.Complete](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Outside/Complete.lean)（公开 SHA256：`b2bfa636be6d9ac91e8273c4980455787cae719d4ce30b1663e0398d5faa5109`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Outside/Consumers.lean`。

### s226 · Universal/Abolition/Innovation/Contribution/Pricing/Outside/Consumers.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`3c8149f2e142ecac2c754071d2f252bd03600dd36db6cdef37592f04fa69ddcb`。
- 声明：`law` (L9)；`current` (L23)；`pay` (L30)；`input` (L32)；`amountAt` (L37)；`a_paid_outside_option_can_have_a_strictly_negative_complete_value` (L42)；`an_unpaid_life_bill_does_not_generate_a_free_zero_outside_option` (L45)；`an_empty_action_budget_does_not_silently_remove_standing` (L48)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Outside.Consumers](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Outside/Consumers.lean)（公开 SHA256：`6072703a7954265ac75e9101c98c31865b1a3741e79fcc999283d3ba3404d623`）。
- 同域直接消费者：本索引无同域直接消费者，依公开靶标的递归导入链核验。

### s227 · Universal/Abolition/Innovation/Contribution/Pricing/Outside/Maximum.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`6edc3eeb1b055d9ab9735abff5699f57a9f040b2607030f47d27bfbd395332a8`。
- 声明：`Maximum` (L9)；`maximum` (L14)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Outside.Maximum](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Outside/Maximum.lean)（公开 SHA256：`6edc3eeb1b055d9ab9735abff5699f57a9f040b2607030f47d27bfbd395332a8`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Outside/Compiler.lean`。

### s228 · Universal/Abolition/Innovation/Contribution/Pricing/Outside/Source.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`25b60bcb0afcb971cfe29f0c439fe96546248c5cbe7e1c920614fa81c6ea4005`。
- 声明：`Checks` (L17)；`words` (L24)；`value` (L27)；`word_mem_iff` (L31)；`every_generated_word_keeps_the_complete_original_claims` (L36)；`every_generated_word_pays_each_original_member` (L42)；`a_checked_value_is_its_complete_original_account` (L50)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Outside.Source](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Outside/Source.lean)（公开 SHA256：`b546924e70590561b46f995205ae17819b029b67287d1545cf14b0a17e7497ab`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Outside/Compiler.lean`。

### s229 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Accounts.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`b3dd4733f429c6ef7c7918bfba8c1ab15090d79b97de02e306190d8511dbf6d9`。
- 声明：`the_returned_root_is_the_literal_complete_price_execution` (L21)；`both_actual_phases_carry_every_original_row_without_refilling` (L37)；`actual_risk_completion_keeps_each_original_living_and_maintenance_payment` (L52)；`all_original_full_accounts_retain_both_real_outside_benchmarks` (L63)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Accounts](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Accounts.lean)（公开 SHA256：`d8da9a22e891f2b4e0788ddba0961aecf87a9e2256c680712f836fa481ee9526`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Method.lean`。

### s230 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Carrying.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`c234869a513123b40c11bc3401deeee94a1cefbbc24dadeaa04fb510629e5fe6`。
- 声明：`Accounted` (L19)；`Accounted.trans` (L26)；`the_original_actual_next_carries_every_old_row` (L36)；`a_queued_refusal_next_carries_every_original_row` (L42)；`every_runtime_outcome_carries_its_complete_original_account` (L50)；`every_risk_protocol_execution_carries_all_original_responsibilities` (L61)；`every_actual_risk_attempt_carries_all_original_rows_and_claims` (L72)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Carrying](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Carrying.lean)（公开 SHA256：`8a5bbf719991cedc03201505fa2bbe29064b9d8271c58e8df9e8ee68c3252472`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Contract.lean`。

### s231 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Completion.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`2ff4e58da221bc225c8dec075b97ba3e13c803a44ac63844b4d6a8f3ff733b89`。
- 声明：`an_actual_trace_keeps_its_ready_boundary_and_available_review` (L25)；`the_default_payment_is_exactly_the_preflighted_source_suffix` (L39)；`a_supported_prepared_trial_forces_its_actual_price_completion` (L48)；`the_prepared_default_contract_is_delivered_by_the_same_actual_root` (L81)；`the_two_actual_instruction_traces_compose_without_another_occurrence` (L95)；`the_prepared_default_payment_generates_its_same_whole_ledger_successor` (L104)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Completion](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Completion.lean)（公开 SHA256：`5c42744a7ab0b23f26a7f90c16231931f0ed9a197d44884ac9f5d0adfde4a002`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualBase.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Root/Accounts.lean`。

### s232 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Contract.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`92980805387518a8859b29263e4eef2a608cd317d6d79bbe633721ce5dfd6a20`。
- 声明：`SourceNativeRiskCompensationAt` (L20)；`the_actual_root_closes_source_generated_risk_compensation` (L60)；`CapitalRiskCompensationClosedAt` (L88)；`the_original_capital_root_closes_the_risk_compensation_amount_and_authority` (L92)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Contract](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Contract.lean)（公开 SHA256：`03a95c775aa2c47d7ee85122a53412b0e061117afaf9c71111de5482297bbd6e`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/ActualRoot.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Registered.lean`。

### s233 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Method.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`85453be8e6f86c0f7c8cc79c1a90a1bb5e7b975809b3c7e855d627642cff22b7`。
- 声明：`attempt` (L18)；`PreparationDisposition` (L23)；`every_actual_preparation_generates_its_price_execution_or_exact_source_obstruction` (L34)；`the_failed_preparation_keeps_the_original_root_and_its_whole_ledger_next` (L46)；`the_method_cannot_return_an_unaccounted_failure_current` (L51)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Method](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Method.lean)（公开 SHA256：`33b27692b44156e6c0a3b6f7c66cfa38793e2e77fad5a1b22ee40292697f1c6d`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Carrying.lean`。

### s234 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Preparation.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`95d4f8c954de8250f06ac94a1b984c844ed2320f75e342ea5e786863c5fa0a98`。
- 声明：`sourceInput` (L22)；`the_actual_remaining_programme_is_in_the_quote_catalogue` (L29)；`ScheduleAt` (L35)；`Prepared` (L37)；`Preparation` (L44)；`prepare` (L57)；`the_quote_reads_the_same_active_law_and_complete_actual_census` (L68)；`the_proposed_initial_stock_cannot_refill_the_original_quote` (L74)；`preparation_has_no_unwitnessed_outside_or_loading_parameter` (L79)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Preparation](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Preparation.lean)（公开 SHA256：`eb5bf7c31da498d0060bbe118c5cecc43d133e00d029db0a525226e034288ef2`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Protocol.lean`。

### s235 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Protocol.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`b0155fdb2f20682a27fd429de719adcae91b9ef63ad06b555cb51fbce4aa2765`。
- 声明：`bodyWord` (L22)；`decision` (L23)；`priceWord` (L24)；`every_refused_risk_amount_sends_no_financial_requests` (L26)；`runtimeBlocked` (L37)；`Execution` (L42)；`execute` (L49)；`Execution.current` (L56)；`the_actual_trial_endpoint_is_the_original_price_basis` (L60)；`a_completed_trial_keeps_the_original_accounts_and_every_responsibility` (L67)；`every_new_price_request_is_routed_by_its_original_root` (L73)；`a_supported_prepared_trial_forces_its_actual_body_completion` (L83)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Protocol](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Protocol.lean)（公开 SHA256：`f34148cacb67ffaebecf197464e38c123e2784cac53d86fef3237d4aef872437`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Completion.lean`。

### s236 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Action.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`0cbc9f629f6d93249073aaa456646f91c50f16d5d5a4c92f3309086aa41f320f`。
- 声明：`afterBody` (L22)；`the_selected_request_keeps_the_original_scope_route` (L24)；`the_original_root_executes_the_generated_request` (L37)；`the_primitive_preserves_the_original_review_coordinate` (L56)；`afterBody_keeps_the_original_review_coordinate` (L68)；`the_actual_body_is_the_same_root_answer_and_generated_next` (L77)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Runtime.Action](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Action.lean)（公开 SHA256：`55181387acacbde7ce55763947d27d5a2950fe8ec1743fa4d5364b77147efe38`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Native.lean`。

### s237 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Complete.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`c0546f16fd1004cc32c4bb1e402b266693a8bbef890d0af915cbb7f78aa55ff7`。
- 声明：`Trace.keeps_the_original_source_input` (L20)；`Trace.raw_is_the_original_instruction_fold` (L28)；`an_original_execution_has_the_same_literal_instruction_fold` (L39)；`Trace.raw_is_the_complete_original_execution` (L47)；`claimThrough` (L53)；`rowThrough` (L58)；`claimThrough_never_merges_original_claims` (L65)；`rowThrough_keeps_the_same_original_claim_and_never_refills` (L70)；`Trace.carries_every_original_row_and_claim_without_refilling` (L82)；`a_checked_original_word_forces_actual_root_completion` (L100)；`Trace.every_original_instruction_has_its_actual_guards` (L124)；`Trace.every_original_request_has_no_controller_consents` (L140)；`Trace.a_nonempty_execution_starts_at_the_actual_ready_boundary` (L151)；`actual_completion_iff_the_nonempty_original_word_passes_all_source_guards` (L158)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Runtime.Complete](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Complete.lean)（公开 SHA256：`8b80834e840fa92fcb01a76b617af1dedf61c7aae8983b6f262f43166b2ece11`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Preparation.lean`。

### s238 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Native.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`74bde94322a301974090db2cf8468881a51f424d4039ea65d49c7ea0c82eeb42`。
- 声明：`afterNative` (L23)；`the_actual_body_has_its_single_original_native_head` (L25)；`the_actual_body_must_consume_its_original_native_head` (L60)；`native_head_uses_the_original_admission_or_consumption` (L73)；`native_head_keeps_the_same_original_control` (L94)；`native_head_keeps_the_same_actual_material_cut` (L105)；`the_single_native_head_finishes_at_its_next_actual_root` (L124)；`two_actual_root_steps_pay_and_consume_the_generated_primitive` (L162)；`afterNative_keeps_the_same_original_input` (L179)；`afterNative_keeps_the_available_review` (L183)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Runtime.Native](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Native.lean)（公开 SHA256：`ab989a5500036973608fc45994cc5b27d2a56206cbf20e475744c11b1a881a1f`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Runner.lean`。

### s239 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Request.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`06611c8b01ee69d003b47cac966b3348904edf4b0908092aad23704a7de6113c`。
- 声明：`queued` (L21)；`Ready` (L23)；`ReviewAvailable` (L25)；`queued_keeps_the_original_control_and_complete_account` (L33)；`queued_keeps_the_original_raw_and_census` (L38)；`queued_selects_the_same_source_request` (L41)；`queued_is_ready_iff` (L44)；`the_available_review_forwards_the_actual_requested_primitive` (L46)；`each_queued_request_is_an_actual_whole_ledger_root_step` (L59)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Runtime.Request](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Request.lean)（公开 SHA256：`10661da9b33df55083b8cfaa64636be03625a8588d1980b4893b58bf542f91b7`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Action.lean`。

### s240 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Resign.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`b661c608c3486479a5965021f9385a8f0cb2556f64195386be514bda1833e852`。
- 声明：`normalise` (L15)；`public_validity_is_unchanged_by_normalising_one_request` (L19)；`public_step_keeps_the_original_request_effect` (L26)；`normalised_requests_have_no_controller_consents` (L40)；`normalisation_keeps_every_original_operation` (L49)；`public_normalisation_keeps_the_complete_original_execution` (L55)；`public_normalisation_preserves_all_actual_request_guards` (L67)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Runtime.Resign](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Resign.lean)（公开 SHA256：`30c1a2ccb51e86826e435b9d6cadd0f58f0beb7c192e76192e0f2fb974ba8709`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Preparation.lean`。

### s241 · Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Runner.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`76352104d960a09a74dcfbc43ae41cb5920179441842f8876a25af8933285be6`。
- 声明：`Trace` (L20)；`Issue` (L28)；`Outcome` (L44)；`run` (L52)；`Outcome.current` (L71)；`Outcome.ticks` (L76)；`the_actual_attempt_bound_is_generated_by_its_original_finite_word` (L81)；`every_blocked_attempt_keeps_its_actual_whole_ledger_next` (L92)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Root.Runtime.Runner](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Runner.lean)（公开 SHA256：`0341b095f2500b76adac6b94f8e6bf0f90784d9b9ce63306dd7677a19ac45837`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Root/Runtime/Complete.lean`。

### s242 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Accounting.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`d58ea1b142482b2325a804f1aefce31f54ca424876877f83967594b47715dde1`。
- 声明：`a_paid_price_has_zero_complete_financial_delta` (L26)；`a_paid_price_has_its_exact_original_full_account` (L37)；`the_generated_price_enters_both_original_full_accounts` (L49)；`every_other_original_full_account_has_zero_price_change` (L60)；`original_raw_final_is_independent_of_the_inventory_index` (L68)；`appended_price_uses_the_literal_original_body_endpoint` (L75)；`appended_price_keeps_every_original_body_inventory_item` (L84)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Accounting](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Accounting.lean)（公开 SHA256：`1752b68082a84a76297eb962ba6ee7db765e2007bbb096d2b6c2277ce8e52391`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Trace.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Source/Authority.lean`。

### s243 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Compiler.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`d0a9edda597b5a3f3d956843869697b32ed9b84f47512165d46d220a22a67864`。
- 声明：`Result` (L17)；`compile` (L31)；`word` (L46)；`execution` (L52)；`next` (L55)；`the_inventory_is_the_actual_submitted_prefix` (L57)；`no_payment_has_no_actual_effect` (L61)；`a_refused_issue_does_not_send_the_settlement` (L64)；`a_refused_settlement_keeps_the_original_issued_debt` (L70)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Compiler](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Compiler.lean)（公开 SHA256：`dab84592bbc1f2f4f3173174c165227ea2b325edf74ccc9dcd307579cf5a153c`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Effects.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Source/Compiler.lean`。

### s244 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Effects.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`0def209608abdad7399552a2a229ab0e16b649cba1e902b15770f8afd61698d3`。
- 声明：`the_first_actual_issue_keeps_material_and_adds_its_exact_claim` (L20)；`actual_payment_retains_the_entire_original_claim_matrix` (L36)；`actual_payment_has_the_same_technology_and_microclock` (L48)；`actual_payment_has_its_exact_original_debit_and_credit` (L62)；`actual_payment_pays_the_generated_signed_net` (L77)；`every_other_original_material_coordinate_is_retained` (L97)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Effects](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Effects.lean)（公开 SHA256：`65f4f6699c259c4e9abecddfc027351dda1960cd97a6598f03807725329749c5`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Accounting.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Resources.lean`。

### s245 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Primitive.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`4ab0c71a789d6337f9ce0398bc9186b2edba11cf63876bd2ac23dd54b4d82d51`。
- 声明：`PhysicalCurrent` (L18)；`the_original_primitive_compiler_executes_the_same_raw_step` (L22)；`primitiveNext` (L49)；`every_submitted_primitive_keeps_the_original_raw_execution` (L56)；`the_generated_price_uses_the_original_physical_compiler` (L72)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Primitive](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Primitive.lean)（公开 SHA256：`799abc421f8d2b00474680c68e3c552d8c900e7d8fd1c3f21f8993ca92aebc59`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Trace.lean`。

### s246 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Resources.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`08928e315a0388f86875dd5856149596b95da6e787089a452e2c360461f0d96e`。
- 声明：`physical_issue_is_generated_from_the_nonnegative_source_units` (L19)；`physical_resources_generate_the_actual_settlement` (L28)；`sufficient_original_resources_force_the_compiler_paid_branch` (L63)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Resources](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Resources.lean)（公开 SHA256：`ab4bcc4f75bf45cd0d33bc70967a5d66f06c93a5b65814a6624d69e1f4f7a4be`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Primitive.lean`。

### s247 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Syntax.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`5d2dabe4ae295f7b8ed6c4af50728aae4abd8175d1181da58e2fe4f4b72af006`。
- 声明：`debtor` (L16)；`creditor` (L17)；`units` (L18)；`issue` (L20)；`settle` (L24)；`afterIssue` (L28)；`afterPayment` (L31)；`requests` (L35)；`actual_debtor_signs_both_original_requests` (L40)；`quantities_are_nonnegative` (L45)；`the_claim_units_pay_the_exact_material_amount` (L49)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Syntax](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Syntax.lean)（公开 SHA256：`ff3077907d9613e4138f4137bbc2d8b2d847e65b4262c5c036e9db39119d3877`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Compiler.lean`。

### s248 · Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Trace.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`efb5e1a2d2c059b2779d7dccf144333cec61e80bacbca520655b4967d36b2d5a`。
- 声明：`original_primitive_reports_keep_the_complete_financial_change` (L27)；`original_primitive_reports_keep_the_complete_material_change` (L46)；`original_primitive_reports_keep_the_complete_full_account` (L64)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Settlement.Trace](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Settlement/Trace.lean)（公开 SHA256：`09d219a39cffe2aa2d62273810211fb35ec6bd863cc87e78a3379fe99abf35f5`）。
- 同域直接消费者：本索引无同域直接消费者，依公开靶标的递归导入链核验。

### s249 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Authority.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`a6477e4de73512725c9bfdc02215bc3e8b7df2f42f0e32bfcca9c6fe48c19234`。
- 声明：`AmountDisposition` (L17)；`classifyAmount` (L24)；`riskClaim` (L36)；`the_original_risk_claim_cannot_contain_an_independent_loading` (L40)；`a_nonempty_risk_fibre_has_an_exact_feasibility_obstruction` (L46)；`completedWord` (L54)；`sufficient_payment_has_no_hidden_financial_position` (L59)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Authority](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Authority.lean)（公开 SHA256：`5c993cc37f73688789b35669f2ac03ea7a2bc4924efe28d13254b5ed2c10f741`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Realization.lean`。

### s250 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Branches.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`1923038ca79d9f76933761799458517f9ca0b16529bb52c01691a1efa4debe54`。
- 声明：`atCut` (L16)；`income` (L23)；`the_branch_income_is_its_complete_original_account` (L27)；`signalDomain` (L33)；`signalDomain_mem_iff` (L36)；`riskRows` (L41)；`accountsSafe` (L48)；`the_original_branch_accounts_are_exactly_the_generated_intervals` (L56)；`every_priced_branch_keeps_both_original_accounts` (L72)；`every_safe_branch_rule_pays_at_least_the_generated_compensation` (L78)；`a_safe_different_amount_is_an_independent_surplus_distribution` (L86)；`localTransfer` (L94)；`branches_with_the_same_paid_local_signal_receive_the_same_quote` (L100)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Branches](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Branches.lean)（公开 SHA256：`4e923e02003695d534bc6301c8a32a34e46db3f9e94f2bdea93c7d1650893d00`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Compiler.lean`。

### s251 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Compiler.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`84bbea969d7696ae885b19481603239a359039dcb5ebadcf6d0fa475ccd86714`。
- 声明：`Schedule` (L16)；`ScheduleOutcome` (L23)；`compileSchedule` (L32)；`Schedule.programme` (L44)；`Schedule.rows` (L47)；`Schedule.table` (L51)；`NatureOutcome` (L54)；`original_nature_iff` (L69)；`Schedule.select` (L82)；`Schedule.payment` (L93)；`Schedule.requests` (L103)；`a_generated_price_preserves_every_matching_original_risk_branch` (L110)；`a_generated_price_is_least_among_all_rules_using_that_local_information` (L116)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Compiler](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Compiler.lean)（公开 SHA256：`1fa4d8f77d7f977673bc5cab645f2dfa85cb93e89b3a3f248316506a333ef079`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Authority.lean`。

### s252 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Envelope.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`50a512b62e171ada9d82971913a64fc149019a6d2852b802bf317f5bfd652682`。
- 声明：`envelope` (L7)；`envelope_none_iff` (L13)；`envelope_is_exact` (L18)；`Quote` (L44)；`Quote.transfer` (L50)；`QuoteIssue` (L53)；`QuoteOutcome` (L58)；`quote` (L62)；`Quote.all_branches` (L69)；`Quote.least_actual_payment` (L74)；`Quote.unique_least_payment` (L79)；`QuoteIssue.no_safe_contract` (L85)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Envelope](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Envelope.lean)（公开 SHA256：`e4af8f7e7a0021ce7014786a914d0ee766eadbb905119474992168801ebcc1c5`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Branches.lean`。

### s253 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Preflight.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`9a39d2856aa997f8754d5574ed8726c283824ae80881ab378978e2bcbd9265fc`。
- 声明：`completedPayment` (L15)；`retainedAccounts` (L21)；`branchChecks` (L30)；`preflight` (L45)；`all_source_branches_pass_before_the_actual_nature` (L47)；`every_approved_actual_branch_keeps_all_original_bearers_and_goods` (L52)；`every_approved_branch_pays_the_original_living_and_maintenance` (L62)；`each_failed_preflight_keeps_its_original_branch_and_check` (L70)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Preflight](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Preflight.lean)（公开 SHA256：`af75815807de0c4898873cd6c52366df81ac41c17c3c417906d09c61983cf89a`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Source/Submission.lean`。

### s254 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Realization.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`6e4902493416139e268e1d73d1131300c0329914d763537f2ae1068c1a3ddb45`。
- 声明：`actual_full_accounts_are_the_original_trial_plus_its_generated_payment` (L23)；`actual_risk_settlement_reaches_both_source_generated_outside_options` (L58)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Realization](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Realization.lean)（公开 SHA256：`8ebe81c2206f4c2a4903c24335b2fb1eb42331c09794b89d03b19eb11aec832a`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Source.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Source/Preflight.lean`。

### s255 · Universal/Abolition/Innovation/Contribution/Pricing/Source/Submission.lean

- 正文位置：§1.1 例 1（第 2 部分）、§1.2 定理 1（第 5 分肢）、§7.5 定理 12 与例 2。
- 附录位置：E.3（命题 E2、定理 E3）、H（S17）。
- 固定 Homework 源 SHA256：`4d9d638912c47914a220d265dd412f064216fd43fe3a0d707ac53fbc3e86e5b1`。
- 声明：`Submission` (L15)；`submit` (L30)；`Submission.net` (L44)；`Submission.word` (L49)；`every_written_risk_claim_uses_exactly_the_generated_compensation` (L58)；`a_safe_surplus_cannot_be_written_through_the_required_risk_channel` (L71)。
- 实际公开模块：[H0mework.Versions.R7c228ac7.ReleaseMaterials.SaturationMonoid.ProcessGame.Society.Institutions.Capitalism.Universal.Abolition.Innovation.Contribution.Pricing.Source.Submission](https://github.com/Sapientropic/H0mework/blob/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e/Lean/H0mework/Versions/R7c228ac7/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/Source/Submission.lean)（公开 SHA256：`0e33cf7d4823d1589a348f1c9f0e7f02eb36ba22f2c81f19ed6c7cb80a947fec`）。
- 同域直接消费者：`Universal/Abolition/Innovation/Contribution/Pricing/Consumers/Submission.lean`；`Universal/Abolition/Innovation/Contribution/Pricing/Root/Preparation.lean`。
