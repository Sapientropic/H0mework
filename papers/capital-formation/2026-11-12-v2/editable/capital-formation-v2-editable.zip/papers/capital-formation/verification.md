# 成稿、来源与阅读版核验

## 第二版（v2）成稿验收（2026-11-12）

《资本主义的结构总定理：全形态最小支撑、公共功能重放与唯一最小风险定价》  
终稿修订：2026-11-12（Asia/Shanghai）

**交付状态：独立冷读审校、定点回源核查、五轴文献核验、双语一致性检查与四份阅读版逐页版式检查全部通过；首版 Zenodo 发布成品与冻结材料原字节 100% 保持不变。**

### 1. 正文、附录与实质升级

第二版唯一中文正文为 [manuscript.md](manuscript.md)，忠实英文镜像为 [manuscript-en.md](manuscript-en.md)；技术补充材料由 [supplement.md](supplement.md) 与 [supplement-en.md](supplement-en.md) 承担。双语正文各含 48 个编号章节、**19 项编号结果**（第 10 项为构造性命题，其余 18 项为全称／充要定理且均配显式证明段落）、**2 则完整手算锚点**（例 1、例 2）、**28 个公式编号**（32 个显示数学块）、**3 张结构对比表**与 **6 幅双语 v2 矢量主图**；双语技术附录各含附录 A–H、**39 个公式编号**（42 个显示数学块）与表 H `S1–S17` 固定来源对应（逐模块声明行号见 [source-correspondence-v2.md](source-correspondence-v2.md) 与 [cf17-source-binding.json](records/cf17-source-binding.json)）。

本次升版完成三项实质推进：

1. **跨学科直觉入口、`6 + 3` 双向核验矩阵与正反门禁架构**：§1.1 例 1 以两人一端口一物品的极简账本，在三分钟内纸笔验算五阶段七原子请求的同长度无支配公共重放（终点库存 $(x_P,x_B)=(99,109)$、债务归零、生活实付）与同信号双分支的唯一最小必要风险补偿（$[4,8]\to q^*=4$）；§1.2 表 1 将总定理六大分肢与配对反向负控一一并列；§1.3 提供政治经济学、企业与不完全契约理论、金融经济学、形式方法四条 15 分钟快速核验通道；§4.1 表 2 展示工业、照护、金融、平台、零雇佣自动化与技术升级型国家资本六类正例入合同，同时以可判定计算验证共同合作生产、个人直兑公共信用与自主家计独立自给三类非资本制度控制列表为空（`controls = []`）。
2. **源内唯一最小必要风险补偿定理（`CF17`）与契约正交脱钩**：在 §7.5（定理 12、例 2、图 5）与附录 E.3（命题 E2、定理 E3、式 `E7–E11`）中，不假定任何主观先验概率、多先验集合、效用函数或贴现率，由零参数可执行非金融外部替代基准 $(a_P,a_B)$ 与同一付费局部信号 $s_{\mathrm{loc}}$ 纤维上各报价分支完整收入 $(y_P,y_B)$ 内生导出双边安全闭区间 $[\operatorname{lo}(s_{\mathrm{loc}}),\operatorname{hi}(s_{\mathrm{loc}})]$，证明向零投影 $q^*(s_{\mathrm{loc}})$ 的严格唯一绝对值最小性、提议有理数四分互斥判决及两阶段零隐蔽头寸结算，阐明正交分解 $q=q^*(s_{\mathrm{loc}})+\lambda$ 如何拆开下行风险填平与事后合作剩余分配（对比 Nash／GHM 重谈），并以单物品日程消费者（`[4,8] -> q*=4`、`3/4/7/100` 四分）与双物品社会状态消费者（食物 `(1,1)`、结算材料 `(109,117)`、`[4,16] -> q*=4`）双线核验。因插入定理 12，首版定理 12–18 在第二版顺延为定理 13–19，并为定理 14、15 补齐正文显式证明。
3. **五轴 30 篇原始文献定理级对话**：正式书目 [references-v2.bib](references-v2.bib) 与核查表 [literature-v2.md](literature-v2.md) 将参考文献由 18 条扩充至 **30 条**（双语正文各 35 处引用块一一对应），新增 Hohfeld (1913)、Böhm (1928)、Coase (1937)、Hirschman (1970)、Alchian & Demsetz (1972)、Townsend (1979)、Fama & Jensen (1983)、Shavell (1986)、Gilboa & Schmeidler (1989)、Rajan & Zingales (1998)、Ellerman (2014) 与同系整账法前作 Gao (2026c)，在各章证明现场与 §10.4 表 3 展开公允比较。

### 2. 独立实质审读闭环与固定来源身份

独立审读对全部公式、手算算例、证明前提与固定 Lean 4 源码逐项交叉核查，检出的全部事项已在双语正文、附录与图件中同步闭合：校核例 1(1) 与 §6.1 的五阶段七原子请求终点库存 $(x_P,x_B)=(99,109)$、例 1(2) 的 $y_B=+1-1-1+10-1-1=+7$ 及统一 $(x_P,x_B)$ 坐标顺序；区分空纤维 $\Omega(s_{\mathrm{loc}})=\emptyset$ 拒签与非空交叉区间 $\operatorname{lo}>\operatorname{hi}$ 的无安全转移不可能定理；补齐 $q^*=0$ 空词分支、$q^*\ne 0$ 异主体及地址零原余额预检门禁、原矩阵复原与原生槽归档之别，以及就绪可审查交付与无条件全尝试旧行单射承接的前提分账；分列单物品日程消费者与双物品社会状态消费者；统一局部信号记号 $s_{\mathrm{loc}}$，消除“原根”数论歧义直译、附录长代码标识符断行及内部元叙事括号；修正英文图 5 `Payer overcharge` 与下标排版。详情见 [editorial-notes.md](editorial-notes.md)。

形式来源保持精确双纪元绑定：`CF0–CF16` 固定于 Homework `df421ff600085cbc290a7ae946193961bed7c83b`、公开 H0mework `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`（`EconomicConstitutionSourceDF` 2825 模块已验收闭包）及首版映射提交 `7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6`；`CF17` 固定于 Homework `7c228ac7fd77350d3fe761c24b887cbf2f6e5afc`，公开导出靶标为 H0mework `H0mework.Papers.SocietyBookRiskCompensation`（基底提交 `a8e94ac1ecbc23503cab91c977b4f71e04e44cb5`，补充提交 `fd6147f8c337d88ebf72d91ddadef0aa601e6c2e`），独立 T1 核验回执 `iqa-capital-risk-pricing-independent-v1/verification.json` SHA-256 为 `50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`。

CF17 的 H0mework 公开闭包含 1,372 个模块。本地复用 Lake 缓存完成构建、信任审计和 17 项完整声明类型核验；55 个风险定价模块及 3 个支撑根从公开 owner 逆恢复，与对应 Homework 固定源码逐字节一致。原独立 T1 回执以原始摘要保全身份，公开验收采用此次 H0mework 执行回执。

### 3. 第二版双语构建与逐页版式核验

一致性回执 [manuscript-consistency-v2.json](records/manuscript-consistency-v2.json)、六组双语图清单 [manifest-v2.json](figures/manifest-v2.json) 与四份阅读版构建回执 [figure-build-pdfs-v2.json](records/figure-build-pdfs-v2.json) 均检验通过：

| v2 阅读版 | 页数 | 文件 | 编译与页面检查 |
| --- | ---: | --- | --- |
| 中文正文 | 31 | [capital-formation.pdf](build/reading-review-v2/capital-formation.pdf) | 零缺字、零溢出、零公式缩放、零越界文字 |
| 英文正文 | 40 | [capital-formation-en.pdf](build/reading-review-v2/capital-formation-en.pdf) | 零缺字、零溢出、零公式缩放、零越界文字 |
| 中文技术附录 | 12 | [capital-formation-supplement.pdf](build/reading-review-v2/capital-formation-supplement.pdf) | 零缺字、零溢出、零公式缩放、零越界文字 |
| English 技术附录 | 15 | [capital-formation-supplement-en.pdf](build/reading-review-v2/capital-formation-supplement-en.pdf) | 零缺字、零溢出、零公式缩放、零越界文字 |

四份 v2 阅读版共 98 页，机械边界与逐页版式检查通过，见[最终页面回执](records/figure-build-pages-v2.json)。

---

## Zenodo 首版发布与历史验收存档（2026-11-04）

2026-11-04 正式发布首版（v1）预印本 [10.5281/zenodo.23927949](https://doi.org/10.5281/zenodo.23927949)。冻结的首版四份 PDF（capital-formation.pdf（Zenodo v1 冻结成品 `capital-formation.pdf`） 24 页、capital-formation-en.pdf（Zenodo v1 冻结成品 `capital-formation-en.pdf`） 35 页、capital-formation-supplement.pdf（Zenodo v1 冻结成品 `capital-formation-supplement.pdf`） 11 页、capital-formation-supplement-en.pdf（Zenodo v1 冻结成品 `capital-formation-supplement-en.pdf`） 15 页，共 85 页）与首版可编辑源码包（Zenodo v1 冻结成品 `capital-formation-v1-editable.zip`）通过独立审查，五文件匿名下载 SHA-256 与本地原字节完全一致，详见发布登记（Zenodo v1 归档登记，DOI: 10.5281/zenodo.23927949）、[发布验收](records/zenodo-release-review.json)、[首版构建回执](records/figure-build-pdfs.json)、[首版一致性回执](records/manuscript-consistency.json)、[首版来源审读](records/source-audit.md)与[首版文献核查](records/literature-audit.md)。
