#!/usr/bin/env python3
"""Editable bilingual v2 figures for The Structural Theorem of Capitalism (v2).

Run with python3 in an environment with the figure dependencies.
Preserves all v1 figure files untouched by emitting *-v2{,-en}.{svg,pdf,png} and manifest-v2.json.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from html import escape
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys
import unicodedata

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH
import svg_text
from svg_text import line
svg_text.OPS.update("∅↔⇒≤≥∀∃∑∈∉∩−×±≠∧∨⌈⌉ℕ′")
W, PRINT_WIDTH, MIN_SIZE = 1440, 464, 24
LANG = "zh"
CHECK_ONLY = False
PARTS, BOXES, SHAPES, MANIFEST = [], [], [], []
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"


def L(zh, en):
    return zh if LANG == "zh" else en


@lru_cache(maxsize=None)
def metrics(cls, weight):
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont
    font_path = svg_text._FONT_FILES[cls]
    if cls == "zh" and weight >= 600:
        suffix = "Bold" if weight >= 700 else "SemiBold"
        font_path = Path.home() / "Library/Fonts" / ("NotoSerifCJKsc-" + suffix + ".otf")
    font = TTFont(str(font_path))
    if "fvar" in font:
        font = instantiateVariableFont(font, {"wght": weight}, inplace=True)
    return font.getBestCmap(), font["hmtx"].metrics, font["head"].unitsPerEm


def width(text, size, weight):
    total = 0
    for piece, tag in svg_text._pieces(str(text)):
        actual_size = svg_text._script(size, MIN_SIZE) if tag in ("sub", "sup", "isub") else size
        actual_weight = 700 if tag == "b" else weight
        for ch in piece:
            cls = "en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i", "isub") and cls == "en":
                cls = "it"
            cmap, hmtx, upm = metrics(cls, actual_weight)
            glyph = cmap.get(ord(ch))
            assert glyph in hmtx, ("missing glyph", ch, cls, actual_weight)
            total += hmtx[glyph][0] * actual_size / upm
    return total


def start(height, title, description):
    PARTS.clear(); BOXES.clear(); SHAPES.clear()
    PARTS.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" viewBox="0 0 {W} {height}" role="img" style="font-variant-ligatures:none;font-feature-settings:normal">')
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append(
        f'<defs>'
        f'<marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="{DEEP}"/></marker>'
        f'<marker id="arrow-red" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="{VERMILION}"/></marker>'
        f'<marker id="arrow-neutral" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 z" fill="{MUTE}"/></marker>'
        f'</defs>'
    )
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height


def txt(x, y, text, size=28, color=INK, weight=400, anchor="start", max_width=None):
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, tw, max_width)
    x0 = x - {"start": 0, "middle": tw / 2, "end": tw}[anchor]
    BOXES.append({"box": [x0, y - 0.88 * size, x0 + tw, y + 0.26 * size],
                  "text": text, "font_px": size})
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))


def lines(x, y, labels, size=28, color=INK, weight=400, anchor="start", gap=39, max_width=None):
    for i, label in enumerate(labels):
        txt(x, y + i * gap, label, size, color, weight, anchor, max_width)


def path(d, bounds, color=HAIR, stroke=1.8, arrow=False, dashed=False):
    if color == VERMILION:
        marker_id = "arrow-red"
    elif color in (HAIR, MUTE, SLATE):
        marker_id = "arrow-neutral"
    else:
        marker_id = "arrow"
    marker = f' marker-end="url(#{marker_id})"' if arrow else ""
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round"{marker}{dash}/>')
    SHAPES.append(bounds)


def segment(x1, y1, x2, y2, color=HAIR, stroke=1.8, arrow=False, dashed=False):
    path(f"M {x1} {y1} L {x2} {y2}",
         [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)],
         color, stroke, arrow, dashed)


def rect(x, y, w, h, stroke=HAIR, fill="white", sw=1.8):
    PARTS.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    SHAPES.append([x, y, x + w, y + h])


def circle(x, y, r, color=DEEP, fill="white", sw=2.4):
    PARTS.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="{sw}"/>')
    SHAPES.append([x - r, y - r, x + r, y + r])


def rule(y):
    segment(48, y, 1392, y, HAIR, 1.5)


def normalized(text):
    return "".join(unicodedata.normalize("NFKC", text).split())


def repair_pdf_text_mapping(pdf, expected):
    import pymupdf
    cmap = metrics("zh", 400)[0]
    glyph_sources = {}
    for ch in set(expected):
        if 0x3400 <= ord(ch) <= 0x9fff and ord(ch) in cmap:
            glyph_sources.setdefault(cmap[ord(ch)], set()).add(ch)
    aliases = {}
    for cp, glyph in cmap.items():
        choices = glyph_sources.get(glyph, set())
        if 0x2e80 <= cp <= 0x2fff and len(choices) == 1:
            aliases[chr(cp)] = next(iter(choices))
    repairs = {}
    temporary = pdf.with_suffix(".unicode.pdf")
    with pymupdf.open(pdf) as doc:
        changed = False
        for xref in range(1, doc.xref_length()):
            if not doc.xref_is_stream(xref):
                continue
            stream = doc.xref_stream(xref)
            if b"begincmap" not in stream:
                continue
            def replace(match):
                original = chr(int(match[2], 16))
                replacement = aliases.get(original)
                if replacement is None:
                    return match[0]
                repairs[original] = replacement
                return match[1] + ("<%04X>" % ord(replacement)).encode()
            repaired = re.sub(rb"(<[0-9A-Fa-f]+>\s+)<([0-9A-Fa-f]{4})>", replace, stream)
            if repaired != stream:
                doc.update_stream(xref, repaired)
                changed = True
        if changed:
            doc.save(temporary, garbage=4, deflate=True)
    if repairs:
        temporary.replace(pdf)
    return repairs


def save(stem, height, semantics):
    for i, item in enumerate(BOXES):
        a = item["box"]
        assert a[0] >= 16 and a[2] <= W - 16 and a[1] >= 8 and a[3] <= height - 8, ("outside canvas", stem, LANG, item)
        for other in BOXES[i + 1:]:
            b = other["box"]
            assert not (a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]), ("text overlap", stem, LANG, item["text"], other["text"])
    for s in SHAPES:
        assert min(s[:2]) >= 8 and s[2] <= W - 8 and s[3] <= height - 8, ("shape outside", stem, LANG, s)
    name = stem + ("-en" if LANG == "en" else "")
    entry = {"stem": name, "language": LANG, "canvas_px": [W, height], "print_width_pt": PRINT_WIDTH,
             "minimum_text_px": MIN_SIZE, "glyph_coverage": "pass", "text_geometry": "pass",
             "shape_bounds": "pass", "semantics": semantics, "labels": list(BOXES)}
    if CHECK_ONLY:
        MANIFEST.append(entry)
        return
    svg = OUT / (name + ".svg")
    svg.write_text("\n".join(PARTS + ["</svg>"]) + "\n", encoding="utf-8")
    preview = OUT / ".review-v2"
    preview.mkdir(exist_ok=True)
    page = preview / (name + ".html")
    hp = height / W * PRINT_WIDTH
    page.write_text('<!doctype html><html><head><meta charset="utf-8"><style>'
        + f'@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}'
        + f'img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>'
        + f'<body><img src="{svg.as_uri()}"></body></html>')
    pdf = OUT / (name + ".pdf")
    result = subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
        "--no-first-run", "--allow-file-access-from-files",
        f"--user-data-dir={preview / 'chrome-profile'}", f"--print-to-pdf={pdf}", page.as_uri()],
        capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:] + result.stderr[-2000:])
    import pymupdf
    expected = "".join(piece for b in BOXES for piece, _ in svg_text._pieces(b["text"]))
    text_repairs = repair_pdf_text_mapping(pdf, expected)
    with pymupdf.open(pdf) as doc:
        assert len(doc) == 1, ("page count", name, len(doc))
        p = doc[0]
        assert abs(p.rect.width - PRINT_WIDTH) < 1 and abs(p.rect.height - hp) < 1
        assert not p.get_images(full=True), ("raster image in vector PDF", name)
        pdf_text = p.get_text()
        assert "\ufffd" not in pdf_text, ("replacement character", name)
        missing = Counter(normalized(expected)) - Counter(normalized(pdf_text))
        assert not missing, ("text missing from PDF", name, dict(missing))
        span_count = 0
        for block in p.get_text("dict")["blocks"]:
            for ln in block.get("lines", []):
                for span in ln["spans"]:
                    span_count += 1
                    x0, y0, x1, y1 = span["bbox"]
                    assert x0 >= -1 and y0 >= -1 and x1 <= p.rect.width + 1 and y1 <= p.rect.height + 1, ("PDF text outside", name, span)
                    assert span["size"] >= MIN_SIZE / W * PRINT_WIDTH * 0.95, ("PDF type below floor", name, span)
        assert span_count > 0 and p.get_drawings(), ("empty PDF", name)
        fonts = sorted({font[3] for font in p.get_fonts(full=True)})
        p.get_pixmap(matrix=pymupdf.Matrix(W / p.rect.width, W / p.rect.width), alpha=False).save(OUT / (name + ".png"))
        entry["pdf_checks"] = {"pages": 1, "raster_images": 0, "editable_text_spans": span_count,
                               "glyph_text_preserved": True, "all_text_in_page": True, "fonts": fonts,
                               "font_types": sorted({f[2] for f in p.get_fonts(full=True)}),
                               "source_character_mapping_repairs": text_repairs}
    entry["files"] = {}
    for ext in ("svg", "pdf", "png"):
        f = OUT / (name + "." + ext)
        entry["files"][ext] = {"path": f.name, "bytes": f.stat().st_size,
                               "sha256": hashlib.sha256(f.read_bytes()).hexdigest()}
    MANIFEST.append(entry)


def structure_v2():
    h = start(880,
        L("权限不对称、三腿核心与资本关系的五面充要刻画", "Permission asymmetry, three-leg kernel, and five-face equivalence"),
        L("左部展示材料齐备源族中的四种权限赋值及三腿资本核 C=(A,R,D)；右部列出完整无资本条件同时排除的五层见证及自身重构等式；底部给出全法则充要支撑定理。",
          "Left: the four permission assignments in a material-complete source family and the three-leg kernel C=(A,R,D). Right: the five witness layers jointly excluded by complete absence of capital and exact self-reconstruction. Bottom: the all-law equivalence."))
    txt(48, 52, L("A  材料齐备源族的权限矩阵与核心", "A  Permission matrix and kernel in one family"), 30, DEEP, 600, max_width=650)
    txt(768, 52, L("B  五面无资本条件与全构造自身恢复", "B  Five-face absence and self-reconstruction"), 30, DEEP, 600, max_width=620)
    segment(720, 88, 720, 668, HAIR, 1.8)
    txt(435, 112, L("控制者 c 准入值", "Controller c access"), 28, DEEP, 600, "middle", 410)
    txt(325, 168, L("0（拒绝）", "0 (refused)"), 26, SLATE, anchor="middle", max_width=195)
    txt(545, 168, L("1（获准）", "1 (allowed)"), 26, SLATE, anchor="middle", max_width=195)
    txt(48, 226, L("受影响者 i", "Affected i"), 26, DEEP, 600, max_width=165)
    for cy, row in [(268, 0), (416, 1)]:
        txt(196, cy + 10, L("0（拒绝）" if not row else "1（获准）", "0 (refused)" if not row else "1 (allowed)"), 25, SLATE, anchor="end", max_width=155)
        for cx, col in [(325, 0), (545, 1)]:
            is_cap = col == 1 and row == 0
            rect(cx - 104, cy - 60, 208, 120, VERMILION if is_cap else HAIR, WASH if is_cap else "white", 2.2 if is_cap else 1.5)
            txt(cx, cy - 4, L("生成 C=(A,R,D)" if is_cap else "无资本核", "C = (A, R, D)" if is_cap else "No capital"),
                26, VERMILION if is_cap else DEEP, 600 if is_cap else 400, "middle", 196)
            if is_cap:
                sub_zh, sub_en = "私人排除 + 回流", "Exclusion + return"
            elif col == 0 and row == 0:
                sub_zh, sub_en = "全关：未付需要", "Closed: unpaid"
            elif col == 0 and row == 1:
                sub_zh, sub_en = "i 获准：无私门", "i allowed (c out)"
            else:
                sub_zh, sub_en = "双方获准：开放", "Both open: replay"
            txt(cx, cy + 38, L(sub_zh, sub_en), 24, VERMILION if is_cap else SLATE, 400, "middle", 196)
    rect(48, 514, 636, 134, DEEP, "white", 1.7)
    txt(366, 558, L("三腿证据同源耦合：C(L,s,w) = (A, R, D)", "Same-execution coupling: C(L,s,w) = (A, R, D)"), 27, DEEP, 600, "middle", 608)
    txt(366, 604, L("A 需要与受控准入 · R 投入/返流/债权 · D 独立可行处分", "A gated needs · R input/return/debt · D disposal"), 24, INK, 400, "middle", 614)
    faces = [
        ("1  私人准入差异 Private(s,p,i)", "1  Private access asymmetry Private(s,p,i)"),
        ("2  资本关系核心 C = (A, R, D)", "2  Capital-relation kernel C = (A, R, D)"),
        ("3  可转移的资产控制头衔", "3  Transferable asset-control title"),
        ("4  五类实际剩余占有记录", "4  Actual surplus appropriation (5 modes)"),
        ("5  跨期历史关系的当期控制", "5  Present control from historical lineage"),
    ]
    for j, (zh, en) in enumerate(faces):
        y = 128 + j * 76
        circle(792, y - 9, 6.5, DEEP, DEEP, 1)
        txt(818, y, L(zh, en), 28, DEEP, 600, max_width=565)
        segment(818, y + 22, 1388, y + 22, HAIR, 1.3)
    rect(768, 514, 624, 134, HAIR, WASH, 1.6)
    txt(1080, 558, "reconstruct(fields(C)) = C", 29, DEEP, 600, "middle", 590)
    txt(1080, 604, L("6 类资本形态入合同 · 3 类合作/兑付/自给零误判", "6 capital forms recognized · 3 coop/UBI/self-supply = []"), 24, INK, 400, "middle", 600)
    rule(688)
    txt(720, 750, "NoCapital(L)  ↔  NoAsymmetry(L)", 38, VERMILION, 600, "middle", 1300)
    txt(720, 806, L("对任意法则 L、状态 s、端口 p 与参与者 i：a{sub:L}(s,p,c{sub:L}(s,p)) = 1 ⇒ a{sub:L}(s,p,i) = 1",
                    "For every law L, state s, port p, and person i: a{sub:L}(s,p,c{sub:L}(s,p)) = 1 ⇒ a{sub:L}(s,p,i) = 1"),
        27, DEEP, 600, "middle", 1330)
    txt(720, 852, L("反向负控：全关闭法则满足无不对称但未交付生活资料，故须接入公共重放与完备处置",
                    "Negative control: uniform closure satisfies NoAsymmetry without paying needs, motivating public replay & audit"),
        24, SLATE, 400, "middle", 1340)
    save("fig01-structure-v2", h, {"theorem_scope": "CF1-CF3 (Theorems 2-4)", "all_laws_iff": True, "self_reconstruction": True})


def disposition_v2():
    h = start(1180,
        L("全形态自行登记、金融入口分派与有限步完备处置", "Self-registration, financial dispatch, and finite-step complete disposition"),
        L("任意实际资本见证 C 自行证明正登记 r(σ)>0 并进入统一社会合同；金融入口分派债务差额或已表示分支；后者在 m(x)+1 步内到达完备废止见证或具名阻塞残差。",
          "Any actual capital witness C proves positive registration r(σ)>0 and enters the common social contract. Financial dispatch separates exact matrix discrepancies from represented runs, reaching complete disposition within m(x)+1 steps."))
    boxes = [
        (48, 382, L("任意实际资本见证 C", "Any actual capital witness C")),
        (506, 402, L("自证正登记 r(σ) > 0", "Self-proved r(σ) > 0")),
        (984, 408, L("统一社会处置合同", "Unified social contract")),
    ]
    for x, w, label in boxes:
        rect(x, 52, w, 90, DEEP, sw=2)
        txt(x + w / 2, 107, label, 28, DEEP, 600, "middle", w - 24)
    segment(440, 97, 494, 97, DEEP, 2.4, arrow=True)
    segment(918, 97, 972, 97, DEEP, 2.4, arrow=True)
    txt(720, 194, L("按初始金融请求矩阵与逐槽账户核对分派", "Dispatch by initial claim matrix vs. slot-account boundary"), 27, SLATE, anchor="middle", max_width=1320)
    path("M 1188 152 L 1188 214 L 272 214 L 272 250", [272, 152, 1188, 250], HAIR, 1.8, True)
    segment(1188, 214, 1188, 250, DEEP, 2.0, arrow=True)

    rect(48, 262, 448, 260, HAIR, WASH, 1.6)
    txt(272, 312, L("金融入口留下债务差额", "Entry debt discrepancy"), 29, DEEP, 600, "middle", 418)
    lines(272, 368, L(["定位确切 (工具 j, 债务人 d, 持有人 h)", "执行状态债务 ≠ 入口表示"],
                      ["Exact address (j, debtor d, holder h)", "State debt ≠ boundary account"]),
          25, INK, anchor="middle", gap=42, max_width=422)
    txt(272, 476, L("保留完整法则与实际后继", "Retains full law and actual next"), 26, DEEP, 600, "middle", 418)

    rect(556, 262, 836, 92, DEEP, "white", 2)
    txt(974, 317, L("初始零债务匹配（后续发行逐笔入槽）", "Initial debt represented (later issues tracked per slot)"), 28, DEEP, 600, "middle", 804)
    txt(974, 398, L("任意合法路径在 n ≤ m(x) + 1 步内到达同一完备处置", "Every legal path reaches the same disposition in n ≤ m(x) + 1 steps"), 26, VERMILION, 600, "middle", 826)

    rect(572, 424, 452, 82, DEEP, sw=1.8)
    txt(798, 475, L("初始公共替代审查", "Initial replacement review"), 28, DEEP, 600, "middle", 422)
    path("M 560 465 L 526 465 L 526 720 L 498 720", [498, 465, 560, 720], MUTE, 1.8, True)
    segment(798, 516, 798, 558, DEEP, 2.2, True)
    txt(832, 546, L("接纳公共执行", "Public mode entered"), 25, SLATE, max_width=270)

    checks = [
        (596, "1  全账差额审计 Δ{sub:i,g} ≥ 0 且有 > 0", "1  Account audit Δ{sub:i,g} ≥ 0 & > 0", "金融审计残差", "Financial residual"),
        (732, "2  成员迁移：生活实付·独立·产能", "2  Migration: needs & independence", "成员迁移残差", "Migration residual"),
        (868, "3  当前自适应可执行未来（全员已付）", "3  Executable future (all needs paid)", "候选未来阻塞", "Future obstruction"),
    ]
    for idx, (y, zh, en, zf, ef) in enumerate(checks):
        rect(572, y - 34, 452, 82, DEEP, sw=1.8)
        txt(798, y + 17, L(zh, en), 25, DEEP, 600, "middle", 434)
        segment(1034, y + 7, 1078, y + 7, MUTE, 1.8, True)
        rect(1090, y - 29, 302, 72, MUTE, "white", 1.4)
        txt(1241, y + 16, L(zf, ef), 25, SLATE, anchor="middle", max_width=280)
        if idx < 2:
            segment(798, y + 58, 798, y + 92, DEEP, 2.2, True)

    rect(48, 636, 448, 236, HAIR, WASH, 1.6)
    txt(272, 692, L("初始替代审查受阻", "Initial review obstructed"), 29, DEEP, 600, "middle", 418)
    lines(272, 752, L(["保留受控状态与失败原因", "全部旧责任行与预算不回填"],
                      ["Controlled state & reason retained", "Legacy rows & budgets preserved"]),
          25, INK, anchor="middle", gap=43, max_width=418)

    segment(798, 926, 798, 974, VERMILION, 2.4, True)
    rect(556, 988, 836, 142, VERMILION, WASH, 2.2)
    txt(974, 1038, L("完备废止见证 Abolished(x) = Finance ∧ Migration ∧ Future",
                     "Complete abolition witness: Finance ∧ Migration ∧ Future"), 27, VERMILION, 600, "middle", 812)
    txt(974, 1088, L("持久公共尾无新增资本核与控制使用 · 排除无阻塞反复控制吸收路径",
                     "Persistent public tail has zero fresh kernels & rules out recurrent control"),
        24, DEEP, 600, "middle", 816)
    save("fig02-disposition-v2", h, {"theorem_scope": "CF12-CF13 (Theorems 5-7)", "step_bound": "m(x)+1"})


def replay_v2():
    h = start(820,
        L("任意生产执行序列的逐位置无支配公共重放", "Universal item-by-item non-dominating public functional replay"),
        L("对任意法则 L、状态 s 与有限请求序列 w，公共重放逐位置映射已接受请求与被拒绝请求，汇入严格同一完整后态 s′，双向保持生活维护与服务适足，并彻底消除控制者同意门与资本核心。",
          "For any law L, state s, and word w, public replay maps accepted and rejected positions one-to-one, reaches the identical full next state s′, preserves needs payment and service adequacy iff, and removes controller-consent gates and capital kernels."))
    txt(48, 52, L("任意法则 L、状态 s 与含接受/拒绝项的有限执行词 w", "Any law L, state s, and finite word w (accepted & rejected items)"), 30, DEEP, 600, max_width=1340)
    txt(720, 104, L("逐位置精确构造 ρ{sub:L,s}(w)：不删减长度、不篡改物量与债权后态",
                    "Position-wise construction ρ{sub:L,s}(w): identical length, stocks, claims, technology, and clock"),
        26, SLATE, anchor="middle", max_width=1320)

    # Upper row: L, lower row: L^pub (keep row tags strictly left of x=236 so vertical dashed arrows never cross text)
    y_top, y_bot = 232, 456
    txt(48, 166, L("原法则 L 执行 w", "Word w under L"), 26, DEEP, 600, max_width=278)
    txt(48, 390, L("开放解释 L{sup:pub} 重放", "Replay on L{sup:pub}"), 25, DEEP, 600, max_width=278)

    for y in (y_top, y_bot):
        circle(96, y, 34, DEEP, sw=2.2)
        txt(96, y + 10, "s", 31, DEEP, 600, "middle")
        segment(142, y, 224, y, DEEP, 2.2, True)

    # Three representative slots: accepted 1, rejected 2, accepted k
    slots = [
        (335, L("接受项 r{sub:1}", "Accepted r{sub:1}"), L("开放项 r′{sub:1}", "Open r′{sub:1}"), L("清同意门", "consents=[]"), True),
        (635, L("拒绝项 r{sub:2}", "Rejected r{sub:2}"), L("零作用呈示", "Zero-effect"), L("保原位状态", "state kept"), False),
        (1035, L("接受项 r{sub:k}", "Accepted r{sub:k}"), L("开放项 r′{sub:k}", "Open r′{sub:k}"), L("同物量金融", "same Δstock/ΔF"), True),
    ]
    for x, top_l, bot_l, sub_l, accepted in slots:
        rect(x - 98, y_top - 42, 196, 84, DEEP if accepted else SLATE, "white", 1.9 if accepted else 1.5)
        txt(x, y_top + 10, top_l, 26, DEEP if accepted else SLATE, 600 if accepted else 400, "middle", 182)
        rect(x - 98, y_bot - 46, 196, 92, DEEP if accepted else MUTE, WASH if accepted else "white", 1.9 if accepted else 1.5)
        txt(x, y_bot - 6, bot_l, 26, DEEP if accepted else SLATE, 600, "middle", 182)
        txt(x, y_bot + 30, sub_l, 24, INK if accepted else SLATE, 400, "middle", 182)
        segment(x, y_top + 52, x, y_bot - 56, DEEP if accepted else MUTE, 1.8, True, True)
    txt(485, 350, L("逐位映射", "item map"), 24, SLATE, 400, "middle", 140)

    for y in (y_top, y_bot):
        segment(444, y, 526, y, DEEP, 2.2, True)
        segment(744, y, 814, y, DEEP, 2.2, True)
        txt(865, y + 9, "· · ·", 30, SLATE, anchor="middle", max_width=85)
        segment(912, y, 928, y, DEEP, 2.2, True)

    segment(1144, y_top, 1266, 322, DEEP, 2.3, True)
    segment(1144, y_bot, 1266, 362, DEEP, 2.3, True)
    circle(1324, 342, 54, VERMILION, WASH, 2.6)
    txt(1324, 353, "s′", 35, VERMILION, 600, "middle")

    rule(558)
    segment(486, 584, 486, 718, HAIR, 1.4)
    segment(954, 584, 954, 718, HAIR, 1.4)
    lines(267, 626, L(["长度相等 |ρ(w)| = |w|", "完整后态 next 完全恒等"],
                      ["Equal length |ρ(w)| = |w|", "Identical full next state s′"]),
          26, VERMILION, 600, "middle", gap=44, max_width=420)
    lines(720, 626, L(["全员生活维护已付 ↔ 重放已付", "任务服务适足 ↔ 重放适足"],
                      ["AllNeedsPaid ↔ replay paid", "ServiceAdequate ↔ replay adequate"]),
          26, DEEP, 600, "middle", gap=44, max_width=444)
    lines(1173, 626, L(["所需生产端口全部开放", "控制者同意门清零 · 无资本核"],
                       ["All required ports open", "Zero consent gate · no capital"]),
          26, DEEP, 600, "middle", gap=44, max_width=420)
    txt(720, 778, L("功能与支配彻底解耦：垫付、协调、投资、信息与结算全数保留，私人排除不再是生产的必要条件",
                    "Function decoupled from domination: coordination, finance, and settlement stay intact without private exclusion"),
        25, INK, 400, "middle", 1344)
    save("fig03-replay-v2", h, {"theorem_scope": "CF14 (Theorem 8)", "rejected_mapped_to_zero_effect": True})


def innovation_v2():
    h = start(940,
        L("事前固定机制、菜单外连续实付创新与来源累计受偿上界", "Ex-ante fixed mechanism, off-menu paid innovation, and origin receipt bound"),
        L("上部展示机制先于未知事件固定、经本期全员生活维护实付门禁连续推进两轮技术 0→1→2（第二发现不在任一报价菜单，旧债 1 贯穿保留）；下部展示同一发行来源 o 在全部账户槽的累计本金受领不超过原发行量 Q_o。",
          "Top: mechanism fixed before unknown events advances technology 0→1→2 across a living-payment renewal gate, with discovery 2 absent from all quote menus and old debt 1 preserved. Bottom: cumulative principal receipts across all slots of origin o never exceed issued quantity Q_o."))
    txt(48, 50, L("A  机制先于未知事件固定：菜单外发现与生活实付续期门", "A  Mechanism fixed before unknown events: off-menu discovery & gate"), 30, DEEP, 600, max_width=1340)
    xs = (118, 720, 1308)
    for x, num, label in zip(xs, (0, 1, 2), [L("初始技术 0", "Initial tech 0"), L("第一轮发现 1", "Discovery 1"), L("菜单外发现 2", "Off-menu tech 2")]):
        col = VERMILION if num == 2 else DEEP
        circle(x, 148, 40, col, WASH if num == 2 else "white", 2.6)
        txt(x, 162, str(num), 44, col, 600, "middle")
        txt(x, 218, label, 26, col, 600, "middle", 220)
    segment(172, 148, 666, 148, DEEP, 2.5, True)
    segment(774, 148, 1254, 148, VERMILION, 2.5, True)
    rect(846, 86, 336, 42, VERMILION, "white", 1.6)
    txt(1014, 115, L("门禁：本期生活维护全员已付", "Gate: current needs all paid"), 24, VERMILION, 600, "middle", 322)

    for x, rno, rzh in [(68, 1, "第一轮"), (782, 2, "第二轮")]:
        rect(x, 254, 590, 206, HAIR, "white", 1.6)
        txt(x + 24, 294, L(f"{rzh}：独立融资、探测与实付结算", f"Round {rno}: actual financing, signal & payment"), 27, DEEP, 600, max_width=542)
        txt(x + 24, 338, L("真实物量投资支出", "Physical investment spent"), 26, INK, max_width=330)
        txt(x + 566, 338, L("3 物量单位", "3 physical units"), 26, DEEP, 600, "end", max_width=220)
        txt(x + 24, 378, L("消息资源总消耗（含观察费 1）", "Message resource (incl. fee 1)"), 25, INK, max_width=360)
        txt(x + 566, 378, L("3 消息单位", "3 message units"), 26, DEEP, 600, "end", max_width=210)
        txt(x + 24, 418, L("全员生活与维护逐人实付 · 第二轮原型初值 0", "All needs paid · Round 2 prototype stock reset to 0") if rno == 2
            else L("全员生活与维护逐人实付 · 欠付则阻断释放", "All needs paid · unpaid needs block next trial"),
            24, SLATE, max_width=546)

    txt(720, 506, L("技术 2 不属于任一轮事前报价菜单 Q{sub:M}；新报价由第二轮实际前缀重算",
                    "Technology 2 belongs to neither round's quote menu Q{sub:M}; Round 2 quotes from its actual prefix"),
        27, VERMILION, 600, "middle", 1340)
    txt(48, 554, L("既有旧债连续保留：地址 (工具, 0, 2) 余额 1 贯穿两轮（物量、消息与债务单位互不相加）",
                    "Legacy debt preserved: balance 1 at (instrument, 0, 2) across both rounds (distinct units not added)"),
        25, DEEP, 600, max_width=1340)
    segment(118, 588, 1308, 588, DEEP, 2.2)
    for x in xs:
        segment(x, 575, x, 601, DEEP, 2.2)
        circle(x, 588, 5, DEEP, DEEP, 1)

    rule(632)
    txt(48, 680, L("B  全来源累计受偿定理：同一发行来源 o 汇总全部账户槽", "B  Universal origin cap: aggregate all slots of issuance origin o"), 30, DEEP, 600, max_width=1340)
    for j, label in enumerate([L("槽 1", "slot 1"), L("槽 2", "slot 2"), "· · ·", L("槽 k", "slot k")]):
        x = 155 + j * 195
        if "·" not in label:
            rect(x - 74, 720, 148, 72, DEEP, "white", 1.6)
        txt(x, 766, label, 28, DEEP, 600 if "·" not in label else 400, "middle", 136)
    path("M 82 806 L 82 824 L 814 824 L 814 806", [82, 806, 814, 824], HAIR, 1.6)
    segment(838, 756, 916, 756, VERMILION, 2.4, True)
    rect(932, 706, 460, 108, VERMILION, WASH, 2.0)
    txt(1162, 748, "receivedForOrigin(o, H) ≤ Q{sub:o}", 28, VERMILION, 600, "middle", 436)
    txt(1162, 792, L("来源唯一性排除转槽或展期重复索偿", "Unique origin bars re-issuance"), 24, DEEP, 600, "middle", 436)
    txt(720, 892, L("结清旧贡献 ≠ 封顶个人收入：新的劳动、发现与风险承担各自生成新来源账户",
                    "Bounding one past claim ≠ capping personal income: new labor, discoveries, and risks open fresh origins"),
        25, INK, 400, "middle", 1344)
    save("fig04-innovation-v2", h, {"theorem_scope": "CF8, CF11, CF15-CF16 (Theorem 9, Prop 10, Theorem 11)"})


def risk_pricing_v2():
    h = start(1070,
        L("同局部信号双边安全补偿闭区间与唯一最小必要风险定价（CF17）", "Bilateral safe compensation interval and unique minimal necessary risk pricing (CF17)"),
        L("无需外生主观概率、效用函数或附加费率：从可执行非金融外部替代基准 (a_P,a_B) 与同信号全部风险分支真实完整收入 (y_P,y_B) 内生导出安全闭区间 [lo(s),hi(s)]=[4,8]，离零最近有理数 q*(s)=4 唯一最小，并将任意提议金额四分判决。",
          "Without subjective priors, utility functions, or exogenous loadings: executable outside baselines (a_P,a_B) and complete branch incomes (y_P,y_B) under one paid signal s_0 yield [lo(s_0),hi(s_0)]=[4,8], unique minimal transfer q*(s_0)=4, and an exhaustive four-way amount classification."))
    txt(48, 50, L("A  零概率先验内生定价：同一付费局部信号 s{sub:0} 下的双边分支交集",
                  "A  Prior-free endogenous pricing: bilateral branch intersection on paid signal s{sub:0}"),
        30, DEEP, 600, max_width=1344)

    # Left card: Endogenous outside baseline
    rect(48, 86, 560, 250, DEEP, "white", 1.8)
    txt(72, 128, L("1  可执行外部替代基准", "1  Executable outside baselines"), 28, DEEP, 600, max_width=512)
    lines(72, 174, L([
        "全员生活实付 · 独立执行 · 非金融保原债",
        "典范源实算：a{sub:P} = −1，a{sub:B} = −1",
        "负控：严格负值合法；欠生活费返回空阻滞",
        "零主观概率 · 零效用函数 · 零外填附加率",
    ], [
        "All needs paid · independent · non-financial",
        "Canonical source: a{sub:P} = −1, a{sub:B} = −1",
        "Control: negative valid; unpaid needs → none",
        "Zero priors · zero utility · zero loading input",
    ]), 24, INK, 400, "start", gap=38, max_width=516)

    # Right card: Two branches under same paid signal
    rect(648, 86, 744, 250, DEEP, "white", 1.8)
    txt(672, 128, L("2  同信号 s{sub:0} 报价分支完整收入与安全行", "2  Same-signal s{sub:0} complete branch accounts"), 28, DEEP, 600, max_width=696)
    lines(672, 174, L([
        "分支 ω{sub:1}（损失 2）：y{sub:P}=−3, y{sub:B}=7 ⇒ [a{sub:P}−y{sub:P}, y{sub:B}−a{sub:B}] = [2, 8]",
        "分支 ω{sub:2}（损失 4）：y{sub:P}=−5, y{sub:B}=7 ⇒ [a{sub:P}−y{sub:P}, y{sub:B}−a{sub:B}] = [4, 8]",
        "全分支交集：lo(s{sub:0}) = max{2,4} = 4，hi(s{sub:0}) = min{8,8} = 8",
        "向零投影唯一最小绝对支付：q*(s{sub:0}) = q*(4, 8) = 4",
    ], [
        "Branch ω{sub:1} (loss 2): y{sub:P}=−3, y{sub:B}=7 ⇒ [a{sub:P}−y{sub:P}, y{sub:B}−a{sub:B}] = [2, 8]",
        "Branch ω{sub:2} (loss 4): y{sub:P}=−5, y{sub:B}=7 ⇒ [a{sub:P}−y{sub:P}, y{sub:B}−a{sub:B}] = [4, 8]",
        "Signal fiber envelope: lo(s{sub:0}) = max{2,4} = 4, hi(s{sub:0}) = min{8,8} = 8",
        "Projection toward zero (least |q|): q*(s{sub:0}) = q*(4, 8) = 4",
    ]), 24, INK, 400, "start", gap=38, max_width=700)

    segment(614, 211, 640, 211, DEEP, 2.2, True)

    # Formula banner
    rect(48, 362, 1344, 96, VERMILION, WASH, 2.0)
    txt(720, 403, "lo(s{sub:loc}) = max{sub:ω∈Ω} [a{sub:P} − y{sub:P}(ω)]  ≤  q  ≤  min{sub:ω∈Ω} [y{sub:B}(ω) − a{sub:B}] = hi(s{sub:loc})",
        29, DEEP, 600, "middle", 1300)
    txt(720, 443, L("q*(s{sub:loc}) ∈ [lo(s{sub:loc}), hi(s{sub:loc})] 为距 0 最近唯一有理数：∀ 安全 q ≠ q*(s{sub:loc})，必有 |q*(s{sub:loc})| < |q|",
                    "q*(s{sub:loc}) ∈ [lo(s{sub:loc}), hi(s{sub:loc})] is closest to 0: every safe q ≠ q*(s{sub:loc}) satisfies |q*(s{sub:loc})| < |q|"),
        25, VERMILION, 600, "middle", 1300)

    rule(486)
    txt(48, 534, L("B  提议金额的四分源内判决与两阶段实付整账闭合",
                  "B  Exhaustive four-way amount disposition and two-phase ledger settlement"),
        30, DEEP, 600, max_width=1344)

    # Number line / 4-zone geometry across x in [90, 1350]
    # Zones: q < 4 [90..410], q = 4 at 455, 4 < q <= 8 [490..950], q > 8 [970..1352]
    y_bar = 666
    rect(88, y_bar - 26, 332, 52, MUTE, "white", 1.5)
    txt(254, y_bar + 9, L("q < 4：提供方受偿不足", "q < 4: provider shortfall"), 25, SLATE, 600, "middle", 314)

    rect(490, y_bar - 26, 460, 52, DEEP, "white", 1.8)
    txt(720, y_bar + 9, L("4 < q ≤ 8：安全但属额外剩余分配", "4 < q ≤ 8: safe surplus distribution"), 25, DEEP, 600, "middle", 442)

    rect(970, y_bar - 26, 382, 52, MUTE, "white", 1.5)
    txt(1161, y_bar + 9, L("q > 8：超出付款方安全上界", "q > 8: payer overcharge"), 25, SLATE, 600, "middle", 364)

    # Highlight exact point q* = 4 at x = 455
    circle(455, y_bar, 24, VERMILION, VERMILION, 2.2)
    txt(455, y_bar + 9, "4", 28, "white", 700, "middle")
    segment(455, y_bar - 64, 455, y_bar - 31, VERMILION, 2.4, True)
    txt(455, y_bar - 76, L("唯一最小必要风险补偿 q* = 4", "Unique minimal compensation q* = 4"), 26, VERMILION, 600, "middle", 460)

    # Four concrete verified probes cards (3, 4, 7, 100)
    probes = [
        (68, 300, "q = 3", L("提供方缺口", "Provider shortfall"), L("拒发金融请求", "No claim issued"), MUTE, "white"),
        (392, 344, "q* = 4", L("必要风险补偿", "Necessary compensation"), L("终态 (P,B)=(101,103)/(99,103)", "Stocks (P,B): (101,103)/(99,103)"), VERMILION, WASH),
        (760, 316, "q = 7", L("额外剩余分配", "Surplus distribution"), L("|7|>|4| 须独立来源授权", "|7|>|4| needs own source"), DEEP, "white"),
        (1100, 292, "q = 100", L("付款方超界", "Payer overcharge"), L("拒发金融请求", "No claim issued"), MUTE, "white"),
    ]
    for x, w, head, l1, l2, st, fl in probes:
        rect(x, 744, w, 168, st, fl, 2.0 if st == VERMILION else 1.5)
        txt(x + w / 2, 788, head, 28, VERMILION if st == VERMILION else DEEP, 600, "middle", w - 20)
        txt(x + w / 2, 836, l1, 25, DEEP if st in (VERMILION, DEEP) else SLATE, 600, "middle", w - 20)
        txt(x + w / 2, 882, l2, 24, INK, 400, "middle", w - 18)

    rule(944)
    txt(720, 990, L("完备闭合门禁：空纤维或 lo > hi 拒签 · 未付费观察与菜单外事件 (nature 3) 严禁虚构风险请求",
                    "Closure gates: empty fiber or crossed lo > hi, unpaid signals, and unquoted events (nature 3) send zero claims"),
        25, DEEP, 600, "middle", 1344)
    txt(720, 1036, L("两阶段实付完整保留全体成员生活维护、全部主体—物品坐标双替代基准与补偿前债权矩阵",
                     "Two-phase settlement preserves all members' needs, all party–good baselines, and the pre-compensation claim matrix"),
        24, SLATE, 400, "middle", 1344)
    save("fig05-risk-pricing-v2", h, {"theorem_scope": "CF17 (Theorem 12 & Example 2)", "verified_probes": [3, 4, 7, 100]})


def cost_v2():
    h = start(890,
        L("两类清算可行域：资源足额尾段最优达到者与完整清算严格改进算法", "Two clearing domains: funded financial-tail minimizer and strict improvement algorithm"),
        L("左部在资源足额的金融清算尾段给出逐非负读数最小的实际达到者 w*；右部在含生产的完整清算域给出离散完成族 J(h ++ w_n)=3+1/(n+2)，下确界 3 不被达到，任意完成候选由自身成本差构造更便宜完整方案。",
          "Left: a funded financial tail has an actual executed minimizer w* for every nonnegative readout. Right: a productive complete-clearing domain has discrete completions 3+1/(n+2) with unattained infimum 3 and constructive strict improvement for any completing candidate."))
    txt(48, 52, L("A  资源足额的金融清算尾段（CF4）", "A  Funded financial clearing tail (CF4)"), 30, DEEP, 600, max_width=640)
    txt(762, 52, L("B  含生产的完整清算非达到域（CF5）", "B  Productive complete-clearing domain (CF5)"), 30, DEEP, 600, max_width=630)
    segment(720, 88, 720, 744, HAIR, 1.7)

    rect(72, 132, 596, 134, DEEP, WASH, 2.0)
    txt(370, 184, L("实际执行的最小成本达到者 w{sub:*}", "Actual executed cost minimizer w{sub:*}"), 30, DEEP, 600, "middle", 564)
    txt(370, 232, L("全部本金归零 · 活动槽终结归档 · 制度后继保持", "Zero principal · all slots archived · live successor"), 25, DEEP, 400, "middle", 572)
    txt(370, 344, "J(w{sub:*}) ≤ J(w)", 40, VERMILION, 600, "middle", 580)
    txt(370, 396, L("对该财务尾段内任意有限允许策略 w 及非负权重 J", "For every finite policy w and nonnegative readout J"), 25, SLATE, 400, "middle", 610)

    rect(72, 476, 188, 114, HAIR, "white", 1.5)
    rect(290, 476, 192, 114, DEEP, "white", 1.8)
    rect(508, 476, 164, 114, HAIR, "white", 1.5)
    segment(260, 533, 282, 533, DEEP, 2.0, True)
    segment(482, 533, 502, 533, DEEP, 2.0, True)
    lines(166, 520, L(["共同前缀 J(h)", "费用完整保留"], ["Prefix cost J(h)", "fully retained"]), 24, INK, 400, "middle", gap=38, max_width=172)
    lines(386, 520, L(["金融尾段 w{sub:*}", "额外耗用为 0"], ["Tail w{sub:*}", "zero extra use"]), 24, DEEP, 600, "middle", gap=38, max_width=176)
    lines(590, 520, L(["终结收据", "续接后续查询"], ["Archived", "next inquiry"]), 24, INK, 400, "middle", gap=38, max_width=152)
    txt(370, 666, L("负控：零余额活动槽仍须经零额结算生成终结收据",
                    "Control: zero-balance live slots still require archival"),
        24, SLATE, 400, "middle", 620)

    x0, x1, y0, y1 = 845, 1352, 532, 162
    def xp(n): return x0 + n / 12 * (x1 - x0)
    def yp(v): return y0 - (v - 3) / 0.55 * (y0 - y1)
    segment(x0, y1, x0, y0, SLATE, 1.7)
    segment(x0, y0, x1 + 18, y0, SLATE, 1.7)
    for val, lab in [(3, "3"), (3.25, "3.25"), (3.5, "3.5")]:
        yy = yp(val)
        segment(x0 - 7, yy, x0, yy, SLATE, 1.7)
        txt(x0 - 17, yy + 9, lab, 25, SLATE, anchor="end", max_width=75)
        if val == 3:
            segment(x0, yy, x1, yy, VERMILION, 2.1, False, True)
            txt(x1 - 4, yy - 14, L("y = 3（未达下确界）", "y = 3 (unattained infimum)"), 24, VERMILION, 600, "end", 320)
        else:
            segment(x0, yy, x1, yy, HAIR, 1.1)
    for n in (0, 3, 6, 9, 12):
        xx = xp(n)
        segment(xx, y0, xx, y0 + 7, SLATE, 1.7)
        txt(xx, y0 + 38, str(n), 25, SLATE, anchor="middle")
    for n in range(13):
        circle(xp(n), yp(3 + 1 / (n + 2)), 5.4, DEEP, DEEP, 1)
    txt(1108, 120, "J(h ++ w{sub:n}) = 3 + 1/(n + 2)", 31, DEEP, 600, "middle", 615)
    txt(1108, 608, L("离散技术参数 n ∈ ℕ", "Discrete technology parameter n ∈ ℕ"), 25, SLATE, anchor="middle", max_width=460)
    txt(1108, 658, L("每点均实付生活维护、清零债务并终结归档", "Every point pays needs, clears debt & archives"), 26, DEEP, 600, "middle", 600)
    txt(1108, 706, L("下确界 3 可任意逼近，但完成域内无最小者", "Infimum 3 approached arbitrarily; no minimum"), 26, VERMILION, 600, "middle", 600)

    rule(756)
    txt(720, 808, L("构造性改进算法：任意完成候选 w 必有尾成本 c = J(w) > 1 ⇒ 取 δ = c−1, n = ⌈1/δ⌉ ⇒ J(h ++ w{sub:n}) < J(h ++ w)",
                    "Constructive improvement: any completion w has tail cost c = J(w) > 1 ⇒ δ = c−1, n = ⌈1/δ⌉ ⇒ J(h ++ w{sub:n}) < J(h ++ w)"),
        25, DEEP, 600, "middle", 1348)
    txt(720, 856, L("从同一已发生前缀 h（成本 2）替换后缀：完成一项真实清偿既无需等待终极最优，也不封闭后续改进",
                    "Replaces the suffix after the same incurred prefix h (cost 2): valid settlement neither awaits a minimum nor closes improvement"),
        24, SLATE, 400, "middle", 1348)
    save("fig06-cost-v2", h, {"theorem_scope": "CF4-CF5 (Theorems 15-17)", "discrete_n": list(range(13))})


FIGURES = [
    ("fig01-structure-v2", structure_v2),
    ("fig02-disposition-v2", disposition_v2),
    ("fig03-replay-v2", replay_v2),
    ("fig04-innovation-v2", innovation_v2),
    ("fig05-risk-pricing-v2", risk_pricing_v2),
    ("fig06-cost-v2", cost_v2),
]


def main():
    global LANG, CHECK_ONLY
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only", choices=[x[0] for x in FIGURES])
    ap.add_argument("--language", choices=["zh", "en", "both"], default="both")
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()
    CHECK_ONLY = args.check_only
    for LANG in (["zh", "en"] if args.language == "both" else [args.language]):
        for name, draw in FIGURES:
            if args.only is None or args.only == name:
                draw()
    report = {
        "paper": "capital-formation",
        "edition": "v2",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "generator": "make_figures_v2.py",
        "shared_dependencies_read_only": True,
        "v1_figures_preserved": True,
        "fonts": ["Noto Serif CJK SC", "STIX Two Text", "STIX Two Math"],
        "colors": {"navy": DEEP, "vermilion": VERMILION, "hairline": HAIR},
        "checks": "Glyph coverage; measured text boxes; pairwise text overlap; shape bounds; PDF vector/text checks.",
        "figures": MANIFEST,
    }
    (OUT / ".review-v2").mkdir(exist_ok=True)
    target = OUT / (".review-v2/layout-report.json" if CHECK_ONLY else
                    ("manifest-v2.json" if args.only is None and args.language == "both" else ".review-v2/partial-manifest.json"))
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"count": len(MANIFEST), "report": str(target), "outputs": [x["stem"] for x in MANIFEST]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
