# 可编辑交付包与重建说明

## 内容与目录

本包保留 publish 工作区的相对层级：本稿位于 papers/capital-formation，共享构建依赖位于 shared。将压缩包解压到任意目录后，以解压根目录为以下命令的工作目录。

- 中文正文与英文正文：manuscript.md、manuscript-en.md。
- 中文附录与英文附录：supplement.md、supplement-en.md。
- 四份第二版 PDF 位于 build/reading-review-v2，编辑后重建会更新相应文件。
- figures 包含双语 SVG 及同名矢量 PDF（首版五组十份，第二版六组十二份）。SVG 保留可编辑文字，正文构建直接使用同名矢量 PDF。
- 图生成脚本与完整生成清单位于 figures（首版 make_figures.py / manifest.json；第二版 make_figures_v2.py / manifest-v2.json）；书目位于 references.bib（首版）与 references-v2.bib（第二版）。
- 来源对应（首版 [来源对应](source-correspondence.md)，第二版含 `CF17` 全模块见 [第二版来源对应](source-correspondence-v2.md)）、[公开来源说明](source-availability.md)、五份固定字节的辅助 Lean 节选与实际复核记录随包保留。
- scripts 包含本稿构建器、表格排版过滤器、页面审阅渲染器与白名单打包器。shared 中仅保留这些工具实际使用的七个依赖文件，按原字节复制并标记为只读。

四份正文/附录及正式 PDF 的身份在根目录 PACKAGE-MANIFEST.json 与构建记录中对应。来源节选的用途、固定提交和公开源入口见 [来源说明](source-availability.md) 与 [来源对应](source-correspondence.md)。

本包不含其他论文、规划用 claims 表、字体文件、外部可执行程序、PNG 预览、逐页截图、TeX 中间文件或缓存。图件的原始 manifest 仍记录曾生成的 PNG 及其校验值；这些是可重建但未打包的预览。SVG 与矢量 PDF 均随包提供，并逐文件核对该清单。页面审阅记录描述实际检查过的成品，所列审阅图像不随包分发。

## 重建四份 PDF

当前构建配置适用于 macOS，依赖：

1. Python 3.10 或更新版本；
2. Pandoc 3；
3. XeLaTeX 及模板使用的 TeX 包；
4. Noto Serif CJK SC、Noto Sans CJK SC 和 Latin Modern 字体。

正文构建器只使用 Python 标准库。使用已经随包提供的矢量图，不需要先安装图生成或页面渲染的 Python 扩展。

~~~sh
python3 papers/capital-formation/scripts/build_reading.py --language both --part all
~~~

单独重建某一份：

~~~sh
python3 papers/capital-formation/scripts/build_reading.py --language en --part main
python3 papers/capital-formation/scripts/build_reading.py --language zh --part supplement
~~~

构建器保留作者元数据、公式和引文定位，自动将手工书目键转为数字编号。图件引用 SVG 时，实际排版读取同名矢量 PDF。默认输出位于本稿 build/reading-review-v2，构建记录将绑定本次 Markdown 字节和 PDF 字节的 SHA-256。构建中间文件可在完成检查后删除。

模板显式使用的 TeX 包包括 fontspec、unicode-math、xeCJK、newunicodechar、xcolor、geometry、setspace、microtype、titlesec、needspace、etoolbox、fancyhdr、enumitem、caption、float、placeins、adjustbox、seqsplit、xurl、fvextra、longtable、booktabs 和 array。Latin Modern 字体由 TeX 环境提供。Noto CJK 字体应安装在当前用户的 Library/Fonts，或系统 Library/Fonts：需要 NotoSerifCJKsc-Regular.otf、NotoSerifCJKsc-Bold.otf、NotoSansCJKsc-Regular.otf、NotoSansCJKsc-Bold.otf。两份 header 是完整模板，没有再读取其他本仓 TeX 文件。

## 修改与重建图件

直接编辑 SVG 后，须同步更新同名矢量 PDF，因为正文构建器优先使用已有 PDF。使用图生成脚本时，两者会一起生成。

图生成另外需要 fontTools、PyMuPDF、Google Chrome，以及 Noto Serif CJK SC 和 STIX Two Text/Math。中等字重还需要 NotoSerifCJKsc-SemiBold.otf。共享文字测量脚本读取当前用户的 Noto 字体及 macOS 的 STIX Two 系统字体；Chrome 使用其标准 macOS 安装位置。共享依赖没有包含作者账户目录。

可在自己的 Python 环境中安装所需扩展，再运行：

~~~sh
python3 -m pip install fonttools pymupdf pillow
python3 papers/capital-formation/figures/make_figures_v2.py
~~~

只重建一张英文图：

~~~sh
python3 papers/capital-formation/figures/make_figures_v2.py --only fig03-replay-v2 --language en
~~~

只运行字形及几何检查：

~~~sh
python3 papers/capital-formation/figures/make_figures_v2.py --check-only
~~~

也可使用正文构建器的 --figures 参数。包内构建器会以当前 Python 解释器启动图生成；这个环境应具备上述扩展。图件重新生成后，应实际打开图件和最终 PDF，检查文字、图义、图注、尺寸及分页。

## 双语与来源一致性检查

此检查只使用包内文件，核对 19 项结果、28 个正文式号、39 个附录式号、30 条书目、图路径、附录数学块顺序、来源选择绑定及五份节选字节：

~~~sh
python3 papers/capital-formation/scripts/check_manuscript.py --edition v2
~~~

## 页面检查

页面审阅渲染器另外使用 PyMuPDF 和 Pillow。以下命令在本稿 build 目录内生成审阅图与机械检查记录：

~~~sh
python3 papers/capital-formation/scripts/render_pdf_review.py \
  papers/capital-formation/build/reading-review-v2/capital-formation.pdf \
  papers/capital-formation/build/reading-review-v2/capital-formation-en.pdf \
  papers/capital-formation/build/reading-review-v2/capital-formation-supplement.pdf \
  papers/capital-formation/build/reading-review-v2/capital-formation-supplement-en.pdf
~~~

记录中的每页图与输入 PDF 的 SHA-256 绑定。机械边界检查与实际视觉检查各自记录；修改后的新 PDF 需要检查自己的版面。完成检查后，审阅页图与临时缓存可直接删除。

## 白名单与包装变换

打包器只读取脚本中列明的本稿文件、五份指定来源节选、首版十组与第二版十二组 SVG/PDF 文件及七个共享依赖；额外审阅记录必须通过明确的 --review-record 参数指定。它核对四份 PDF 的源绑定、图件哈希、来源选择哈希、Markdown 本地链接和抽离目录中的构建依赖，然后验证 ZIP 成员、CRC 与每个成员字节。

~~~sh
python3 papers/capital-formation/scripts/package_editable.py --edition v2 --check
python3 papers/capital-formation/scripts/package_editable.py --edition v2
~~~

需要一并保留新的最终审阅记录时，显式添加其相对路径，例如：

~~~sh
python3 papers/capital-formation/scripts/package_editable.py \
  --edition v2 --review-record records/figure-build-pages-v2.json
~~~

此参数把实际审阅记录加入第二版打包白名单。重新打包前，应更新复核说明与审阅记录，使其对应新的成品。

包内 Markdown 正文、附录、SVG、矢量 PDF、五份来源节选及共享依赖保留原字节。少量包装变换单独记入 PACKAGE-MANIFEST：图生成器的作者专用解释器提示改为通用 python3；本稿构建器的图生成子进程改用当前解释器；不随包提供的仓库规划记录链接改为文字；若审阅记录含工作区绝对前缀，导出副本转为包内相对路径。每个成员均记录源字节哈希与包内字节哈希，源文件不被改写。

## Editable bundle: quick reference

Extract the archive without flattening its directories. From the extraction root, run Python on papers/capital-formation/scripts/build_reading.py to rebuild all four PDFs. The supplied vector figure PDFs allow rebuilding the papers without regenerating figures. The current shared configuration targets macOS and requires Pandoc 3, XeLaTeX, and the fonts listed above.

The archive contains this paper and the seven build dependencies it actually uses. Figure previews and page-render images are intentionally omitted; their existing hashes remain documentary records. PACKAGE-MANIFEST.json lists every payload member and any packaging-only transformation. Formal-source scope and fixed identities are documented in source-availability.md and source-correspondence.md.
