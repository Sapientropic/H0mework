# 来源、形式证明与复核入口

## 固定证明材料（v1 基础与 v2 新增闭合）

本稿第二版（v2，`CF0–CF17`，正文定理 1–19 及附录 A–H）的形式化证明材料由两批固定快照精确承接，且首版（Zenodo v1，`10.5281/zenodo.23927949`）全部对应关系与冻结字节保持不变：

1. **核心结构刻画、公共重放、有限步处置与完整账户（`CF0–CF16`；定理 1–11、定理 13–19，附录 S1–S16）**：
   - 研究代码库 Homework 固定提交：**`df421ff600085cbc290a7ae946193961bed7c83b`**（tree **`13c04d40cc7d3e17f97434e53984e319d1c328c4`**）。
   - 公开复现代码库 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) 固定验收快照：**`2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`**（包入口 `H0mework.Papers.EconomicConstitutionSourceDF`），首版公开证明映射 `docs/capital-formation-map.json` 固定于提交 **`7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6`**。
   - 105 个固定源文件、675 处声明与 191 条直接导入关系的逐项对应见 [source-correspondence.md](source-correspondence.md)，机器绑定见 [public-source-binding.json](records/public-source-binding.json)（因定理 12 插入 `CF17`，v1 定理 12–18 在 v2 正文中顺延为定理 13–19，其余编号 1–11 保持不变）。
2. **同付费局部信号的源内唯一最小必要风险定价（`CF17`；定理 12、例 2 及附录 E.3／S17）**：
   - 研究代码库 Homework 固定提交：**`7c228ac7fd77350d3fe761c24b887cbf2f6e5afc`**，模块路径前缀为 `Lean/SaturationMonoid/ProcessGame/Society/Institutions/Capitalism/Universal/Abolition/Innovation/Contribution/Pricing/`（含 `Outside/{Source,Compiler,Complete,Consumers}.lean`、`Arithmetic/Interval.lean`、`Source/{Branches,Envelope,Compiler,Preflight,Authority}.lean`、`Root/{Preparation,Protocol,Completion,Accounts,Carrying,Contract}.lean` 及 `Consumers/{Source,Prices,Submission,Registered,ActualRoot}.lean`）。
   - 公开复现代码库 [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e) 固定补充提交：**`fd6147f8c337d88ebf72d91ddadef0aa601e6c2e`**（基底提交 `a8e94ac1ecbc23503cab91c977b4f71e04e44cb5`），导出靶标为 **`H0mework.Papers.SocietyBookRiskCompensation`**（`Lean/H0mework/Papers/SocietyBookRiskCompensation.lean`），主张映射见 `checks/society-book-map.json`（条目 `capital-risk-compensation`），复现说明见 `docs/society-book-reproduction.md`。
   - 独立机器核验回执：`iqa-capital-risk-pricing-independent-v1/verification.json`（T1 标准三公理：`propext`、`Classical.choice`、`Quot.sound`；零 `sorry`、零 `unsafe`、零 `partial`），SHA-256 为 **`50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`**。55 个模块的逐文件 SHA-256、398 处声明行号、同域直接消费者与公开靶标对应见 [source-correspondence-v2.md](source-correspondence-v2.md) 与机器绑定 [cf17-source-binding.json](records/cf17-source-binding.json)。

## `CF0–CF16` 既有验收与公开模块闭合

对 `df421ff600085cbc290a7ae946193961bed7c83b` 批次全文核读的 105 个固定源文件中，100 个文件的对应公开模块位于已验收的 `H0mework.Papers.EconomicConstitutionSourceDF` 实际递归导入闭包内（共 2825 个模块）。绑定先从该真实导入环境选择模块，再逐一核对来源别名、源码 SHA-256、公开目标 SHA-256 与递归环境。

这 100 个模块在既有验收回执中包含 160 项完整类型观测，每项绑定完整限定名、类型哈希、回执索引、kernel 等价结果与标准三公理（`propext`、`Classical.choice`、`Quot.sound`）。以下路径相对于固定 H0mework 快照 `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`：

| 材料 | 固定路径与作用 |
| --- | --- |
| 采用包入口（`CF0–CF16`） | `Lean/H0mework/Papers/EconomicConstitutionSourceDF.lean` |
| 已验收主张映射 | `docs/economic-constitution-map.json` |
| 有限选集 | `checks/economic-constitution-selection.json` |
| 实际验收汇总 | `evidence/economic-constitution/acceptance/initial-intake/summary.json` |
| 复现说明（`CF0–CF16`） | `docs/economic-constitution-reproduction.md` |
| 风险定价补充靶标（`CF17`，提交 `fd6147f8c3`） | `Lean/H0mework/Papers/SocietyBookRiskCompensation.lean` 与 `docs/society-book-reproduction.md` |

历史独立 T1 认证（`0802cc07ad1009d74a4e5dea08b30591a171894de70044ff6821925d1c9890fa`、`c4dbdcbb4806844d411c60b95126173f4f28d58e2bd6ddb7fb6382421baca215` 及 `CF17` 的 `50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`）各自保持真实的来源与执行范围，详见 命题证据表（仓库工作记录，不随本可编辑包提供）。

## 五份辅助来源的原字节保全

另有五份固定 `df421ff600` 来源属于形态实例、分配引理及归档反例消费者，未作为 `EconomicConstitutionSourceDF` 的独立证明根。其完整源码原字节随稿冻结保存于 `source-excerpts/`：

- `s022-Forms.lean`：六类资本形态对一般社会合同的实际消费。
- `s065-Total.lean`：共同分配的累计不重复花费引理。
- `s103-Archive.lean`：完整金融归档的具体消费者。
- `s104-Zero.lean`：零余额与未归档状态的具体消费者。
- `s105-Zero.lean`：零数量发行的原语反例。

一般主结论均由已验收公开包中的生产声明承担；五份补充文件保持既有阅读与原字节身份。

## 再生对应表与核验命令

在论文仓内检查 `CF0–CF16` 固定来源绑定与双语 v2 稿件一致性：

```sh
python3 papers/capital-formation/scripts/build_source_index.py \
  --homework-repository /path/to/Homework \
  --h0-repository /path/to/H0mework \
  --check
python3 papers/capital-formation/scripts/build_source_index_v2.py \
  --homework-repository /path/to/Homework \
  --h0-repository /path/to/H0mework \
  --check
python3 papers/capital-formation/scripts/check_manuscript.py
```

PDF 与图件的构建入口见 [reading-guide.md](reading-guide.md)。

## English availability note

The Second Edition (v2, `CF0–CF17`, Theorems 1–19 and Appendices A–H) binds two pinned formal proof snapshots while preserving all Zenodo v1 (`10.5281/zenodo.23927949`) files byte-for-byte:

1. **Core structural characterization, public replay, finite-step disposition, and full-ledger accounting (`CF0–CF16`; Theorems 1–11 and 13–19, `S1–S16`)**: fixed at Homework commit **`df421ff600085cbc290a7ae946193961bed7c83b`**, with the verified 2825-module `H0mework.Papers.EconomicConstitutionSourceDF` closure fixed at public [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) commit **`2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`** (100 public modules, 160 indexed complete-type observations, plus five unchanged supporting files in `source-excerpts/`) and the first-edition public proof map `docs/capital-formation-map.json` fixed at commit **`7d15dbcaf5bd7a1d8373020b0fc3293505a40ba6`** (inserting `CF17` as Theorem 12 shifts v1 Theorems 12–18 to v2 Theorems 13–19).
2. **Source-native unique minimal risk pricing on paid local-signal fibers (`CF17`; Theorem 12, Example 2, and Section E.3 / `S17`)**: fixed at Homework commit **`7c228ac7fd77350d3fe761c24b887cbf2f6e5afc`** (`.../Innovation/Contribution/Pricing/`) and exported in public [Sapientropic/H0mework](https://github.com/Sapientropic/H0mework/tree/fd6147f8c337d88ebf72d91ddadef0aa601e6c2e) commit **`fd6147f8c337d88ebf72d91ddadef0aa601e6c2e`** under target **`H0mework.Papers.SocietyBookRiskCompensation`** (`checks/society-book-map.json` entry `capital-risk-compensation`, `docs/society-book-reproduction.md`), backed by independent T1 verification receipt `iqa-capital-risk-pricing-independent-v1/verification.json` (SHA-256 **`50c5bb9c1ba6200dda1d72be8cc6f45b6506d5a2f8ad6645d7040cb1ae9efa08`**, standard Lean axioms `propext`, `Classical.choice`, `Quot.sound` only).
