-- Paper-local v3 layout filter for economic-constitution:
-- 1. Keep headings with following text via \Needspace.
-- 2. Allow safe line-breaking inside long commit hashes and qualified Lean module/declaration paths.
-- 3. Allocate exact column proportions for 4-column and 6-column comparison tables.

function Header(el)
  if not FORMAT:match('latex') then return nil end
  if el.level == 2 then
    return {pandoc.RawBlock('latex', '\\Needspace{6\\baselineskip}'), el}
  end
  if el.level == 3 then
    return {pandoc.RawBlock('latex', '\\Needspace{5\\baselineskip}'), el}
  end
  if el.level ~= 1 then return nil end
  local title = pandoc.utils.stringify(el.content)
  local short_titles = {
    ['1 The Constitutional Problem: Ordering Standing, Contribution, and Power When Possibilities Multiply'] = '1 Ordering Standing, Contribution, and Power',
    ['4 Settling Contribution, Risk, Waiting, and Open Innovation'] = '4 Contribution, Risk, Waiting, and Open Innovation',
    ['6 Technical Progress and the Autonomous Time Dividend'] = '6 Technical Progress and Autonomous Time',
    ['7 Non-Sovereign Public Coordination and Anti-Panopticon Scoped Verification'] = '7 Non-Sovereign Coordination and Scoped Audit',
    ['8 External Boundaries, Intergenerational Upkeep, and Bookkeeping Discipline'] = '8 External Boundaries and Bookkeeping Discipline',
    ['9 Open Amendment, Anti-Capture, and World-Safe Regeneration'] = '9 Open Amendment and World-Safe Regeneration',
    ['10 Five-Axis Synthesis, Institutional Boundaries, and Downstream Interfaces'] = '10 Five-Axis Synthesis and Interfaces'
  }
  if short_titles[title] then
    local latex = pandoc.write(pandoc.Pandoc({el}), 'latex')
    latex = latex:gsub('\\section{', '\\section[' .. short_titles[title] .. ']{', 1)
    return pandoc.RawBlock('latex', latex)
  end
end

local function escape_latex_code(s)
  return (s:gsub('([\\{}#$%%&_~^])', function(c)
    local map = {
      ['\\'] = '\\textbackslash{}',
      ['{'] = '\\{',
      ['}'] = '\\}',
      ['#'] = '\\#',
      ['$'] = '\\$',
      ['%'] = '\\%',
      ['&'] = '\\&',
      ['_'] = '\\_\\allowbreak{}',
      ['~'] = '\\textasciitilde{}',
      ['^'] = '\\textasciicircum{}'
    }
    return map[c] or c
  end):gsub('/', '/\\allowbreak{}'):gsub('%.', '.\\allowbreak{}'))
end

function Code(el)
  if not FORMAT:match('latex') then return nil end
  local t = el.text
  if #t >= 32 and t:match('^[0-9a-f]+$') then
    return pandoc.RawInline('latex', '\\paperinlinecode{\\seqsplit{' .. t .. '}}')
  end
  if #t >= 26 and (t:find('_') or t:find('/') or t:find('%.')) then
    return pandoc.RawInline('latex', '\\paperinlinecode{' .. escape_latex_code(t) .. '}')
  end
  return nil
end

function Str(el)
  if not FORMAT:match('latex') then return nil end
  local result = pandoc.List()
  local cursor = 1
  for first, token, after in el.text:gmatch('()([0-9a-f]+)()') do
    if #token >= 40 then
      if first > cursor then result:insert(pandoc.Str(el.text:sub(cursor, first - 1))) end
      result:insert(pandoc.RawInline('latex', '\\paperinlinecode{\\seqsplit{' .. token .. '}}'))
      cursor = after
    end
  end
  if cursor > 1 then
    if cursor <= #el.text then result:insert(pandoc.Str(el.text:sub(cursor))) end
    return result
  end
end

function Table(el)
  if not FORMAT:match('latex') then return nil end
  if not el.head or not el.head.rows or #el.head.rows == 0 then return nil end
  local row = el.head.rows[1]
  if #row.cells == 0 then return nil end
  local label = pandoc.utils.stringify(row.cells[1].contents)

  if #el.colspecs == 4 and (label == '原则与章节' or label == 'Principle & Section') then
    el.colspecs[1][2] = 0.16
    el.colspecs[2][2] = 0.21
    el.colspecs[3][2] = 0.26
    el.colspecs[4][2] = 0.28
    return {
      pandoc.RawBlock('latex', '\\Needspace{14\\baselineskip}\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.05}\\renewcommand{\\arraystretch}{1.13}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end

  if #el.colspecs == 6 and (label == '制度方案' or label == 'Policy Regime') then
    el.colspecs[1][2] = 0.16
    el.colspecs[2][2] = 0.13
    el.colspecs[3][2] = 0.15
    el.colspecs[4][2] = 0.14
    el.colspecs[5][2] = 0.14
    el.colspecs[6][2] = 0.17
    return {
      pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.04}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end

  if #el.colspecs == 4 and (label == '核算维度' or label == 'Accounting Dimension') then
    el.colspecs[1][2] = 0.15
    el.colspecs[2][2] = 0.24
    el.colspecs[3][2] = 0.26
    el.colspecs[4][2] = 0.26
    return {
      pandoc.RawBlock('latex', '\\Needspace{14\\baselineskip}\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.05}\\renewcommand{\\arraystretch}{1.13}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end

  if #el.colspecs == 4 and (label == '外部与跨期维度' or label == 'Cross-Boundary Dimension') then
    el.colspecs[1][2] = 0.16
    el.colspecs[2][2] = 0.25
    el.colspecs[3][2] = 0.29
    el.colspecs[4][2] = 0.21
    return {
      pandoc.RawBlock('latex', '\\Needspace{14\\baselineskip}\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.05}\\renewcommand{\\arraystretch}{1.13}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end

  if #el.colspecs == 4 and (label == '理论主轴与代表文献' or label == 'Research Axis & Primary Works') then
    el.colspecs[1][2] = 0.19
    el.colspecs[2][2] = 0.22
    el.colspecs[3][2] = 0.22
    el.colspecs[4][2] = 0.28
    return {
      pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.04}\\renewcommand{\\arraystretch}{1.11}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.45em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end

  if #el.colspecs == 4 and (label == '正文结果' or label == 'Main-Text Result') then
    el.colspecs[1][2] = 0.14
    el.colspecs[2][2] = 0.36
    el.colspecs[3][2] = 0.25
    el.colspecs[4][2] = 0.16
    return {
      pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.05}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end

  if #el.colspecs == 2 and (label == '合同' or label == 'Contract' or label == '层次' or label == 'Layer') then
    el.colspecs[1][2] = 0.24
    el.colspecs[2][2] = 0.69
    return {
      pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.05}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el,
      pandoc.RawBlock('latex', '\\endgroup')
    }
  end
end
