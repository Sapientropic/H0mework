#!/usr/bin/env python3
"""Editable bilingual v3 vector figures for An Economic Constitution of Possibility.

Generates six bilingual plates (01-four-claims-v3 .. 06-world-safe-regeneration-v3)
and manifest-v3.json while keeping frozen v2 plates (01..03) and manifest.json untouched.
Run with a Python 3 environment providing fontTools and pymupdf.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from html import escape
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import unicodedata

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION  # noqa: E402
import svg_text  # noqa: E402
from svg_text import line  # noqa: E402

svg_text.OPS.update("∅∧∨¬⊂⊊≺∑−∓±⪯⪰≡⇔✓①②③④⑤⑥")
W, PRINT_WIDTH, MIN_SIZE = 1440, 464, 24
LANG = "zh"
CHECK_ONLY = False
PARTS, BOXES, SHAPES, MANIFEST = [], [], [], []
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
TINT_NAVY = "#F4F6F9"
TINT_WARM = "#FDF6F4"


def L(zh: str, en: str) -> str:
    return zh if LANG == "zh" else en


@lru_cache(maxsize=None)
def metrics(cls: str, weight: int):
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont

    font_path = svg_text._FONT_FILES[cls]
    if cls == "zh" and weight >= 600:
        suffix = "Bold" if weight >= 700 else "SemiBold"
        font_path = Path.home() / "Library/Fonts" / ("NotoSerifCJKsc-" + suffix + ".otf")
    font = TTFont(str(font_path))
    if "fvar" in font:
        font = instantiateVariableFont(font, {"wght": weight}, inplace=True)
    return font.getBestCmap(), font["hmtx"].metrics, font["head"].unitsPerEm


def width(text: str, size: float, weight: int) -> float:
    total = 0.0
    for piece, tag in svg_text._pieces(str(text)):
        actual_size = svg_text._script(size, MIN_SIZE) if tag in ("sub", "sup", "isub") else size
        actual_weight = 700 if tag == "b" else weight
        for ch in piece:
            cls = "en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i", "isub") and cls == "en":
                cls = "it"
            cmap, hmtx, upm = metrics(cls, actual_weight)
            glyph = cmap.get(ord(ch))
            assert glyph in hmtx, ("missing glyph", ch, cls, actual_weight, text)
            total += hmtx[glyph][0] * actual_size / upm
    return total


def start(height: int, title: str, description: str) -> int:
    PARTS.clear()
    BOXES.clear()
    SHAPES.clear()
    PARTS.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
        f'viewBox="0 0 {W} {height}" style="font-variant-ligatures: none;" role="img">'
    )
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append(
        "<defs>"
        f'<marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
        f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{DEEP}"/></marker>'
        f'<marker id="arrow-v" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
        f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{VERMILION}"/></marker>'
        "</defs>"
    )
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height


def txt(x: float, y: float, text: str, size: float = 26, color: str = INK, weight: int = 400,
        anchor: str = "start", max_width: float | None = None) -> None:
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, round(tw, 1), max_width)
    x0 = x - {"start": 0.0, "middle": tw / 2.0, "end": tw}[anchor]
    BOXES.append({"box": [x0, y - 0.88 * size, x0 + tw, y + 0.26 * size], "text": text, "font_px": size})
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))


def lines(x: float, y: float, labels: list[str], size: float = 26, color: str = INK, weight: int = 400,
          anchor: str = "start", gap: float = 36, max_width: float | None = None) -> None:
    for idx, label in enumerate(labels):
        txt(x, y + idx * gap, label, size, color, weight, anchor, max_width)


def path(d: str, bounds: list[float], color: str = HAIR, stroke: float = 1.8,
         arrow: str | bool = False, dashed: bool = False) -> None:
    marker = ""
    if arrow == "v":
        marker = ' marker-end="url(#arrow-v)"'
    elif arrow:
        marker = ' marker-end="url(#arrow)"'
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(
        f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{stroke}" '
        f'stroke-linecap="round" stroke-linejoin="round"{marker}{dash}/>'
    )
    SHAPES.append(bounds)


def segment(x1: float, y1: float, x2: float, y2: float, color: str = HAIR, stroke: float = 1.8,
            arrow: str | bool = False, dashed: bool = False) -> None:
    path(f"M {x1} {y1} L {x2} {y2}", [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)],
         color, stroke, arrow, dashed)


def rect(x: float, y: float, w: float, h: float, stroke: str = HAIR, fill: str = "white",
         sw: float = 1.8, rx: float = 0, dashed: bool = False) -> None:
    dash = ' stroke-dasharray="8 6"' if dashed else ""
    radius = f' rx="{rx}" ry="{rx}"' if rx else ""
    PARTS.append(
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" '
        f'stroke="{stroke}" stroke-width="{sw}"{radius}{dash}/>'
    )
    SHAPES.append([x, y, x + w, y + h])


def circle(x: float, y: float, r: float, color: str = DEEP, fill: str = "white", sw: float = 2.4) -> None:
    PARTS.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{color}" stroke-width="{sw}"/>')
    SHAPES.append([x - r, y - r, x + r, y + r])


def rule(y: float) -> None:
    segment(44, y, 1396, y, HAIR, 1.5)


def cross_mark(cx: float, cy: float, half: float = 11, color: str = VERMILION, sw: float = 2.8) -> None:
    segment(cx - half, cy - half, cx + half, cy + half, color, sw)
    segment(cx - half, cy + half, cx + half, cy - half, color, sw)


def normalized(text: str) -> str:
    return "".join(unicodedata.normalize("NFKC", text).split())


def repair_pdf_text_mapping(pdf: Path, expected: str) -> dict[str, str]:
    import pymupdf

    cmap = metrics("zh", 400)[0]
    glyph_sources: dict[int, set[str]] = {}
    for ch in set(expected):
        if 0x3400 <= ord(ch) <= 0x9FFF and ord(ch) in cmap:
            glyph_sources.setdefault(cmap[ord(ch)], set()).add(ch)
    aliases = {}
    for cp, glyph in cmap.items():
        choices = glyph_sources.get(glyph, set())
        if 0x2E80 <= cp <= 0x2FFF and len(choices) == 1:
            aliases[chr(cp)] = next(iter(choices))
    repairs: dict[str, str] = {}
    temporary = pdf.with_suffix(".unicode.pdf")
    with pymupdf.open(pdf) as doc:
        changed = False
        for xref in range(1, doc.xref_length()):
            if not doc.xref_is_stream(xref):
                continue
            stream = doc.xref_stream(xref)
            if b"begincmap" not in stream:
                continue

            def replace(match):
                original = chr(int(match[2], 16))
                replacement = aliases.get(original)
                if replacement is None:
                    return match[0]
                repairs[original] = replacement
                return match[1] + ("<%04X>" % ord(replacement)).encode()

            repaired = re.sub(rb"(<[0-9A-Fa-f]+>\s+)<([0-9A-Fa-f]{4})>", replace, stream)
            if repaired != stream:
                doc.update_stream(xref, repaired)
                changed = True
        if changed:
            doc.save(temporary, garbage=4, deflate=True)
    if repairs:
        temporary.replace(pdf)
    return repairs


def save(stem: str, height: int, semantics: dict) -> None:
    for idx, item in enumerate(BOXES):
        a = item["box"]
        assert a[0] >= 14 and a[2] <= W - 14 and a[1] >= 8 and a[3] <= height - 8, ("outside canvas", stem, LANG, item)
        for other in BOXES[idx + 1:]:
            b = other["box"]
            assert not (a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]), (
                "text overlap",
                stem,
                LANG,
                item["text"],
                other["text"],
                a,
                b,
            )
    for s in SHAPES:
        assert min(s[:2]) >= 6 and s[2] <= W - 6 and s[3] <= height - 6, ("shape outside", stem, LANG, s)

    name = stem + ("-en" if LANG == "en" else "")
    entry = {
        "stem": name,
        "language": LANG,
        "canvas_px": [W, height],
        "print_width_pt": PRINT_WIDTH,
        "minimum_text_px": MIN_SIZE,
        "glyph_coverage": "pass",
        "text_geometry": "pass",
        "shape_bounds": "pass",
        "semantics": semantics,
        "labels": list(BOXES),
    }
    if CHECK_ONLY:
        MANIFEST.append(entry)
        return

    svg = OUT / (name + ".svg")
    svg.write_text("\n".join(PARTS + ["</svg>"]) + "\n", encoding="utf-8")
    preview = OUT / ".review-v3"
    preview.mkdir(exist_ok=True)
    page = preview / (name + ".html")
    hp = height / W * PRINT_WIDTH
    page.write_text(
        '<!doctype html><html><head><meta charset="utf-8"><style>'
        + f"@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}"
        + f"img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>"
        + f'<body><img src="{svg.as_uri()}"></body></html>',
        encoding="utf-8",
    )
    pdf = OUT / (name + ".pdf")
    result = subprocess.run(
        [
            CHROME,
            "--headless=new",
            "--disable-gpu",
            "--no-pdf-header-footer",
            "--no-first-run",
            "--allow-file-access-from-files",
            f"--user-data-dir={preview / 'chrome-profile'}",
            f"--print-to-pdf={pdf}",
            page.as_uri(),
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:] + result.stderr[-2000:])

    import pymupdf

    expected = "".join(piece for b in BOXES for piece, _ in svg_text._pieces(b["text"]))
    text_repairs = repair_pdf_text_mapping(pdf, expected)
    with pymupdf.open(pdf) as doc:
        assert len(doc) == 1, ("page count", name, len(doc))
        p = doc[0]
        assert abs(p.rect.width - PRINT_WIDTH) < 1 and abs(p.rect.height - hp) < 1
        assert not p.get_images(full=True), ("raster image in vector PDF", name)
        pdf_text = p.get_text()
        assert "\ufffd" not in pdf_text, ("replacement character", name)
        missing = Counter(normalized(expected)) - Counter(normalized(pdf_text))
        assert not missing, ("text missing from PDF", name, dict(missing))
        span_count = 0
        for block in p.get_text("dict")["blocks"]:
            for ln in block.get("lines", []):
                for span in ln["spans"]:
                    span_count += 1
                    x0, y0, x1, y1 = span["bbox"]
                    assert x0 >= -1 and y0 >= -1 and x1 <= p.rect.width + 1 and y1 <= p.rect.height + 1, (
                        "PDF text outside",
                        name,
                        span,
                    )
                    assert span["size"] >= MIN_SIZE / W * PRINT_WIDTH * 0.94, ("PDF type below floor", name, span)
        assert span_count > 0 and p.get_drawings(), ("empty PDF", name)
        fonts = sorted({font[3] for font in p.get_fonts(full=True)})
        p.get_pixmap(matrix=pymupdf.Matrix(W / p.rect.width, W / p.rect.width), alpha=False).save(
            preview / (name + ".png")
        )
        entry["pdf_checks"] = {
            "pages": 1,
            "raster_images": 0,
            "editable_text_spans": span_count,
            "glyph_text_preserved": True,
            "all_text_in_page": True,
            "fonts": fonts,
            "font_types": sorted({f[2] for f in p.get_fonts(full=True)}),
            "source_character_mapping_repairs": text_repairs,
        }
    entry["files"] = {}
    for ext in ("svg", "pdf"):
        f = OUT / (name + "." + ext)
        entry["files"][ext] = {
            "path": f.name,
            "bytes": f.stat().st_size,
            "sha256": hashlib.sha256(f.read_bytes()).hexdigest(),
        }
    MANIFEST.append(entry)


def plate_01_four_claims() -> None:
    h = start(
        920,
        L("四项独立制度资格、三角色分离与权力携证原则", "Four separated entitlements, role decoupling, and proof-carrying power"),
        L(
            "面板A展示共同预算、服务提供者与基础受益者的三角色结构分离及权力携证方向；面板B展示基础参与、贡献索偿、稀缺请求与可撤治理四条独立资格及其禁止自动跨层转换边界。",
            "Panel A shows structural separation among common budget, service provider, and beneficiary together with proof-carrying power; Panel B shows the four independently grounded entitlements and blocked automatic cross-promotion.",
        ),
    )
    txt(44, 48, L("A  三角色支付分离与权力携证方向", "A  Three-role payment decoupling and proof-carrying power"), 29, DEEP, 600, max_width=920)
    txt(1396, 48, L("定义 1.1 · 定理 1.2 · 反全景核验", "Def. 1.1 · Thm. 1.2 · Anti-Panopticon"), 24, SLATE, 400, "end", 450)

    # Panel A boxes
    rect(44, 78, 390, 148, DEEP, TINT_NAVY, 2.0, rx=6)
    txt(239, 120, L("共同预算承担者", "Common budget bearer"), 28, DEEP, 600, "middle", 360)
    txt(239, 158, L("筹集物量、人力与维护资源", "Funds materials, labor & upkeep"), 25, INK, 400, "middle", 365)
    txt(239, 196, L("缺口公开入账，不改判资格", "Deficits logged openly"), 24, SLATE, 400, "middle", 365)

    rect(525, 78, 390, 148, DEEP, "white", 2.0, rx=6)
    txt(720, 120, L("服务提供机构", "Service provider"), 28, DEEP, 600, "middle", 360)
    txt(720, 158, L("按任期与标准实际交付服务", "Delivers service under term"), 25, INK, 400, "middle", 365)
    txt(720, 196, L("携证提交不越权与结清回执", "Submits non-overreach proof"), 24, VERMILION, 600, "middle", 365)

    rect(1006, 78, 390, 148, VERMILION, TINT_WARM, 2.2, rx=6)
    txt(1201, 120, L("基础参与受益者", "Basic beneficiary"), 28, VERMILION, 600, "middle", 360)
    txt(1201, 158, L("凭到来与需要享有生活条件", "Grounded in arrival & need"), 25, INK, 400, "middle", 365)
    txt(1201, 196, L("零事先贡献门槛 · 零自证清白", "No prior output or worthiness test"), 24, DEEP, 600, "middle", 370)

    segment(436, 134, 519, 134, DEEP, 2.4, arrow=True)
    txt(478, 114, L("拨付", "pays"), 24, DEEP, 600, "middle", 82)
    segment(917, 134, 1000, 134, DEEP, 2.4, arrow=True)
    txt(959, 114, L("交付", "gives"), 24, DEEP, 600, "middle", 82)

    # Blocked reverse demand
    path("M 1180 228 L 1180 264 L 260 264 L 260 232", [260, 228, 1180, 264], VERMILION, 2.0, arrow="v", dashed=True)
    cross_mark(340, 264, 10, VERMILION, 2.8)
    txt(760, 254, L("禁止以本人事先贡献或全景审查作为生存前提", "No prior-contribution gate or Panopticon worthiness test"), 25, VERMILION, 600, "middle", 820)

    rule(302)
    txt(44, 348, L("B  四项必须分别说明理由的宪制资格（禁止跨行自动晋升）", "B  Four independently justified entitlements (automatic promotion blocked)"), 29, DEEP, 600, max_width=1060)
    txt(1396, 348, L("约束边界", "Boundary"), 25, SLATE, 600, "end", 240)

    rows = [
        (
            "1 · 基础参与",
            "1 · Basic participation",
            "依据：到来、生活需要与平等地位（ECN1–ECN2）",
            "Ground: arrival, living needs & equal standing (ECN1–ECN2)",
            "五门真实退出 K > 0；拒任反报复；旧主体再现同债继承",
            "Five-gate exit K > 0; anti-retaliation; same-debt reappearance",
            "地位常驻",
            "standing kept",
        ),
        (
            "2 · 贡献索偿",
            "2 · Contribution claims",
            "依据：事前认可的探索、风险、等待与维护（ECN3）",
            "Ground: agreed exploration, risk, waiting & upkeep (ECN3)",
            "按原发行来源累计受领 ∑ R{isub:i} ≤ Q{isub:o}；转让不再生",
            "Origin-unique cap ∑ R{isub:i} ≤ Q{isub:o}; transfer never remints",
            "总额封顶",
            "issuance cap",
        ),
        (
            "3 · 稀缺请求",
            "3 · Scarce requests",
            "依据：当期真实物量预算与公开分配规则（ECN4–ECN5）",
            "Ground: real budget & public allocation rules (ECN4–ECN5)",
            "方法公域零边际复用；稀缺维护与时段逐腿清算",
            "Non-rival method reuse; scarce slots cleared leg by leg",
            "预算硬界",
            "budget gate",
        ),
        (
            "4 · 可撤治理",
            "4 · Revocable power",
            "依据：明确任务、期限 d{sub:ε}、异议复核与携证核验（ECN6–ECN8）",
            "Ground: task, term d{sub:ε}, challenge & scoped audit (ECN6–ECN8)",
            "到期权限永久归零 ¬J{sub:ε}；未结旧责随交接完整承接",
            "Expired jurisdiction ¬J{sub:ε} vanishes; duties persist across handoff",
            "到期可撤",
            "term expires",
        ),
    ]

    for idx, (z_name, e_name, z_g, e_g, z_r, e_r, z_b, e_b) in enumerate(rows):
        y = 376 + idx * 124
        rect(44, y, 1110, 98, HAIR, TINT_NAVY if idx % 2 == 0 else "white", 1.6, rx=4)
        txt(66, y + 40, L(z_name, e_name), 29 if LANG == "zh" else 27, DEEP, 600, max_width=310)
        txt(390, y + 38, L(z_g, e_g), 25, DEEP, 600, max_width=745)
        txt(390, y + 76, L(z_r, e_r), 24, INK, 400, max_width=745)

        # Right boundary emblem
        cx, cy = 1280, y + 36
        if idx == 0:
            path(f"M {cx - 38} {cy + 12} C {cx - 38} {cy - 34} {cx + 38} {cy - 34} {cx + 38} {cy + 12}",
                 [cx - 38, cy - 34, cx + 38, cy + 12], DEEP, 2.5)
        elif idx == 1:
            segment(cx - 42, cy - 16, cx + 42, cy - 16, VERMILION, 2.8)
            segment(cx - 42, cy + 12, cx + 42, cy + 12, DEEP, 2.2)
            segment(cx, cy + 12, cx, cy - 12, DEEP, 2.2, arrow=True)
        elif idx == 2:
            rect(cx - 42, cy - 18, 84, 34, DEEP, "white", 2.2)
            segment(cx, cy - 18, cx, cy + 16, DEEP, 2.0)
        else:
            rect(cx - 44, cy - 18, 72, 34, DEEP, "white", 2.2)
            cross_mark(cx + 42, cy - 1, 10, VERMILION, 2.6)
        txt(cx, y + 84, L(z_b, e_b), 24, SLATE, 600, "middle", 210)

        if idx < 3:
            # Show explicit firewall between rows
            by = y + 111
            segment(195, by - 9, 195, by + 9, VERMILION, 2.2)
            cross_mark(195, by, 6, VERMILION, 2.2)

    txt(
        720,
        894,
        L("出资受偿 ≠ 永久管辖 · 握有债权 ≠ 封锁生存 · 基础享有 ≠ 无限占用稀缺公地",
          "Contribution claim ≠ permanent rule · Debt claim ≠ survival blockade · Basic standing ≠ unbounded rival use"),
        26,
        VERMILION,
        600,
        "middle",
        1350,
    )
    save(
        "01-four-claims-v3",
        h,
        {
            "panel_a": "beneficiary_provider_budget_separation_and_proof_carrying_power",
            "panel_b": "four_independently_justified_entitlements_with_no_automatic_promotion",
            "theorems": ["Def 1.1", "Thm 1.2", "ECN1-ECN8"],
        },
    )


def plate_02_exit_diagnosis() -> None:
    h = start(
        900,
        L("五门退出充要结构、需求守恒、同正容量盲区与粗读出修复障碍", "Five-gate exit characterization, demand balance, equal-capacity blind spot, and coarse-readout obstruction"),
        L(
            "面板A展示同一继续行动与已服务槽上的五门二分匹配充要条件、原始退出需求守恒及三种零容量来源；面板B对比同容量K=1下的完整生活组合差异，以及全领域粗读数(0,∅)下的2×2对角修复矩阵。",
            "Panel A shows the five-gate bipartite matching characterization, original exit-demand balance, and three distinct zero-capacity origins; Panel B contrasts equal positive capacity K=1 with missing health service and shows the 2x2 diagonal repair matrix behind coarse readout (0, empty).",
        ),
    )
    txt(44, 48, L("A  五门退出、“三个零”与需求守恒（定理 2.1 · 命题 2.3）", "A  Five-gate exit, Three Zeros & demand balance (Thm. 2.1 · Prop. 2.3)"), 28, DEEP, 600, max_width=900)
    txt(1396, 48, L("K + D{sub:max} = |C{sub:act}| · 改报价不变 K", "K + D{sub:max} = |C{sub:act}| · re-quote keeps K"), 24, SLATE, 600, "end", 480)

    # Left bipartite diagram
    rect(44, 76, 800, 316, HAIR, "white", 1.6, rx=6)
    txt(232, 114, L("候选行动 C", "Actions C"), 25, SLATE, 600, "middle", 280)
    txt(687, 114, L("本轮已服务槽 J", "Served slots J"), 25, SLATE, 600, "middle", 250)

    actions = [
        (172, L("work · 原岗位内 ¬R", "work · inside role ¬R"), MUTE),
        (248, L("idle · 空转等待 I", "idle · idle action I"), MUTE),
        (326, L("leave · 角色外 R ∧ ¬I ∧ ¬H", "leave · outside R ∧ ¬I ∧ ¬H"), VERMILION),
    ]
    for cy, label, col in actions:
        rect(64, cy - 26, 336, 48, col, TINT_WARM if col == VERMILION else "white", 2.0, rx=4)
        txt(232, cy + 6, label, 24, col if col == MUTE else DEEP, 600 if col == VERMILION else 400, "middle", 318)

    slots = [
        (192, L("槽 0：权利保有", "Slot 0: rights"), DEEP),
        (274, L("槽 1：健康服务", "Slot 1: health"), DEEP),
        (348, L("请求 2：待办队列", "Req. 2: unserved"), MUTE),
    ]
    for cy, label, col in slots:
        rect(556, cy - 25, 262, 46, col, TINT_NAVY if col == DEEP else "white", 1.8, rx=4, dashed=(col == MUTE))
        txt(687, cy + 6, label, 24, col, 600 if col == DEEP else 400, "middle", 248)

    path("M 400 326 C 462 326 488 192 554 192", [400, 192, 554, 326], VERMILION, 2.8, arrow="v")
    txt(478, 356, "{i:P}({i:c}) ∧ {i:T}({i:c}, 0)", 24, VERMILION, 600, "middle", 180)

    # Right box: Three Zeros
    rect(870, 76, 526, 316, DEEP, TINT_NAVY, 1.8, rx=6)
    txt(1133, 116, L("单删任一门禁 ⇒ 同值 K = 0", "Drop one gate ⇒ identical K = 0"), 27, DEEP, 600, "middle", 490)
    zeros = [
        ("z{isub:c}", L("删 ¬H（受控捕获） → K = 0", "drop ¬H (captured) → K = 0")),
        ("z{isub:p}", L("删 P（无付款关联） → K = 0", "drop P (no payment link) → K = 0")),
        ("z{isub:r}", L("删 T（服务断路）   → K = 0", "drop T (broken route) → K = 0")),
    ]
    for idx, (sym, desc) in enumerate(zeros):
        zy = 172 + idx * 62
        txt(900, zy, sym, 27, VERMILION, 600, "start", 70)
        txt(972, zy, desc, 25, INK, 400, "start", 408)
    txt(1133, 366, L("全捕获则 D{sub:max} = |C{sub:act}|；标量 K 无失败源左逆", "Capture ⇒ D{sub:max} = |C{sub:act}| · no origin inverse"), 24, VERMILION, 600, "middle", 506)

    rule(424)
    txt(44, 470, L("B  同正容量盲区与全领域粗读数修复不可识别性（定理 2.2）", "B  Equal-capacity blind spot and coarse-readout repair impossibility (Thm. 2.2)"), 29, DEEP, 600, max_width=1120)

    # Bottom-left: Two Ones K = 1
    rect(44, 498, 632, 330, HAIR, "white", 1.8, rx=6)
    txt(360, 538, L("同正容量“两个一”：K(x{isub:d}) = K(y{isub:d}) = 1", "Two Ones at positive capacity: K(x{isub:d}) = K(y{isub:d}) = 1"), 26, DEEP, 600, "middle", 600)
    rect(72, 566, 272, 182, DEEP, TINT_NAVY, 1.8, rx=4)
    txt(208, 606, L("完整源 x{isub:d}", "Complete x{isub:d}"), 26, DEEP, 600, "middle", 245)
    txt(208, 648, L("槽 0 权利 ✓", "Slot 0 rights ✓"), 25, INK, 400, "middle", 245)
    txt(208, 688, L("槽 1 健康 ✓", "Slot 1 health ✓"), 25, INK, 400, "middle", 245)
    txt(208, 730, "{i:P}({i:x}{isub:d}) ≠ ∅", 26, DEEP, 600, "middle", 245)

    rect(376, 566, 272, 182, VERMILION, TINT_WARM, 1.8, rx=4)
    txt(512, 606, L("单服务源 y{isub:d}", "Single-slot y{isub:d}"), 26, VERMILION, 600, "middle", 245)
    txt(512, 648, L("槽 0 权利 ✓", "Slot 0 rights ✓"), 25, INK, 400, "middle", 245)
    txt(512, 688, L("槽 1 健康：缺失", "Slot 1 health: absent"), 25, VERMILION, 600, "middle", 245)
    txt(512, 730, "{i:P}({i:y}{isub:d}) = ∅", 26, VERMILION, 600, "middle", 245)

    txt(360, 798, L("任何仅读 K 的判别器 q(1) 必然至少误判一侧", "Any predicate q(K) fails on either x{isub:d} or y{isub:d}"), 24, SLATE, 600, "middle", 600)

    # Bottom-right: 2x2 Diagonal Repair Matrix
    rect(708, 498, 688, 330, DEEP, "white", 1.8, rx=6)
    txt(1052, 538, L("粗读数碰撞 ρ{isub:d}(c{isub:d}) = ρ{isub:d}(r{isub:d}) = (0, ∅)", "Coarse collision ρ{isub:d}(c{isub:d}) = ρ{isub:d}(r{isub:d}) = (0, ∅)"), 26, DEEP, 600, "middle", 650)

    # Matrix headers
    txt(1090, 588, L("解除捕获", "Release capture"), 24, DEEP, 600, "middle", 190)
    txt(1290, 588, L("恢复通路", "Restore route"), 24, DEEP, 600, "middle", 190)
    segment(736, 606, 1372, 606, HAIR, 1.5)

    txt(744, 650, L("捕获源 c{isub:d}", "Captured c{isub:d}"), 25, INK, 600, "start", 230)
    txt(1090, 650, "1", 30, DEEP, 700, "middle", 80)
    txt(1290, 650, "0", 30, VERMILION, 700, "middle", 80)

    txt(744, 706, L("断路源 r{isub:d}", "Broken route r{isub:d}"), 25, INK, 600, "start", 230)
    txt(1090, 706, "0", 30, VERMILION, 700, "middle", 80)
    txt(1290, 706, "1", 30, DEEP, 700, "middle", 80)
    segment(736, 730, 1372, 730, HAIR, 1.5)

    txt(1052, 770, L("任意后处理 g(f(ρ{isub:d})) 输出同值 ⇒ 至少错一次", "Any post-processing g(f(ρ{isub:d})) errs on ≥ 1 branch"), 24, VERMILION, 600, "middle", 655)
    txt(1052, 808, L("补回失败种类 (ρ{isub:d}, φ{isub:d}) 单射恢复唯一有效修复", "Refinement (ρ{isub:d}, φ{isub:d}) injectively restores unique repair"), 24, DEEP, 600, "middle", 655)

    txt(
        720,
        876,
        L("原则一：财富评价必须保留失败生成原因与修复权限，不可压缩为无源总分",
          "Principle 1: Capability metrics must retain failure provenance and repair authority"),
        26,
        DEEP,
        600,
        "middle",
        1340,
    )
    save(
        "02-exit-diagnosis-v3",
        h,
        {
            "panel_a": "five_gate_bipartite_exit_three_zeros_and_original_demand_balance",
            "panel_b": "two_ones_portfolio_blind_spot_and_diagonal_repair_obstruction",
            "theorems": ["Thm 2.1", "Thm 2.2", "Prop 2.3"],
        },
    )


def plate_03_paid_renewal() -> None:
    h = start(
        930,
        L("两轮菜单外实付创新、续期门禁与原发行全槽受领上界", "Two-round out-of-menu paid innovation, renewal gate, and origin-unique receipt cap"),
        L(
            "面板A追踪同一开放准入机制从0到1到2的两轮实付探索、当期生活维护门禁及三项反控；面板B展示原发行唯一身份下跨转让与阶段变化的望远镜累计受领上界。",
            "Panel A traces two rounds of paid open-access exploration 0 -> 1 -> 2, the current-period living gate, and three negative controls; Panel B shows the origin-unique telescoping cap on cumulative receipts across transfers and stages.",
        ),
    )
    txt(44, 48, L("A  开放事件两轮实付探索与当期生活门禁（定理 4.1）", "A  Two-round open-event exploration and current-living gate (Thm. 4.1)"), 28, DEEP, 600, max_width=925)
    txt(1396, 48, "L = (1−{i:p})ℓ = 1 · {i:q} = (L+{i:a}+{i:b})/{i:p} = 3", 24, SLATE, 600, "end", 500)

    # State nodes 0 -> 1 -> 2
    nodes = [
        (116, "0", L("初始技术", "Initial tech"), DEEP),
        (720, "1", L("第一轮发现", "Discovery 1"), DEEP),
        (1310, "2", L("菜单外发现 2", "Out-of-menu 2"), VERMILION),
    ]
    for cx, num, lbl, col in nodes:
        circle(cx, 118, 36, col, TINT_WARM if col == VERMILION else "white", 2.8)
        txt(cx, 131, num, 42, col, 700, "middle")
        txt(cx, 184, lbl, 25, col, 600, "middle", 210)
    segment(162, 118, 672, 118, DEEP, 2.6, arrow=True)
    segment(766, 118, 1262, 118, VERMILION, 2.6, arrow="v")

    for bx, rno, rzh in [(68, 1, "第一轮"), (764, 2, "第二轮")]:
        rect(bx, 206, 608, 192, HAIR, TINT_NAVY if rno == 1 else "white", 1.6, rx=5)
        txt(bx + 22, 244, L(f"{rzh}实付账（新融资 + 空证据起步）", f"Round {rno} actual account (fresh funding & signal)"), 26, DEEP, 600, max_width=568)
        txt(bx + 22, 288, L("物量投资", "Material investment"), 25, INK, 400, max_width=290)
        txt(bx + 586, 288, L("3 物量单位", "3 material units"), 25, DEEP, 600, "end", 260)
        txt(bx + 22, 330, L("消息消耗（含观察费 1）", "Message spent (obs. fee 1)"), 25, INK, 400, max_width=340)
        txt(bx + 586, 330, L("3 消息单位", "3 message units"), 25, DEEP, 600, "end", 240)
        txt(bx + 22, 372, L("全员本期生活与维护包", "All parties' living & upkeep"), 25, INK, 400, max_width=340)
        txt(bx + 586, 372, L("当期实付 ✓", "Paid now ✓"), 25, VERMILION, 600, "end", 230)

    # Old debt line + 3 negative controls strip
    segment(116, 456, 1310, 456, DEEP, 2.2)
    for cx in (116, 720, 1310):
        circle(cx, 456, 5, DEEP, DEEP, 1.0)
    txt(720, 438, L("既有旧债 = 1 债务单位（全程保留，物量、消息与债额单位互不相加）", "Existing old debt = 1 debt unit preserved throughout (units never summed)"), 24, DEEP, 600, "middle", 1120)
    txt(720, 496, L("三道硬反控：删再融资 → 未筹资失败；删观察费 1 → 无已付信号；下期可付而本期欠付 → 续期门阻断",
                    "Three negative controls: no refunding → unfunded; no obs. fee → no paid signal; unpaid current living → gate blocks"),
        24, VERMILION, 600, "middle", 1350)

    rule(524)
    txt(44, 568, L("B  源生成唯一性与同一贡献全槽累计受领上界（定理 4.2）", "B  Origin uniqueness and cumulative receipt cap across all slots (Thm. 4.2)"), 29, DEEP, 600, max_width=1060)

    # Panel B left: Telescoping chain
    rect(44, 594, 868, 258, DEEP, "white", 1.8, rx=6)
    txt(478, 634, L("原发行来源 o（约定额度 Q{isub:o}）：转让与跨阶段不再生本金", "Issuance origin o (cap Q{isub:o}): transfer & stages never remint"), 26, DEEP, 600, "middle", 830)

    stages = [
        (86, L("发行准入", "Admission"), "{i:p}{isub:i}({i:A}) = {i:Q}{isub:o}"),
        (366, L("原槽换持有人", "Holder transfer"), "same slot, origin {i:o}"),
        (646, L("实际有限后缀", "Actual finite suffix"), "{i:p}{isub:i}({i:B}) + {i:R}{isub:i}({i:r}) ≤ {i:Q}{isub:o}"),
    ]
    for sx, stitle, sform in stages:
        rect(sx, 662, 232, 102, HAIR, TINT_NAVY, 1.6, rx=4)
        txt(sx + 116, 700, stitle, 25, DEEP, 600, "middle", 216)
        txt(sx + 116, 742, sform, 24, INK, 600, "middle", 220)
    segment(320, 713, 360, 713, DEEP, 2.2, arrow=True)
    segment(600, 713, 640, 713, DEEP, 2.2, arrow=True)
    txt(478, 818, L("全槽汇总：0 ≤ R{isub:o}(r) = ∑{sub:origin=o} R{isub:i}(r) = R{isub:i}(r) ≤ Q{isub:o}",
                    "All-slot sum: 0 ≤ R{isub:o}(r) = ∑{sub:origin=o} R{isub:i}(r) = R{isub:i}(r) ≤ Q{isub:o}"),
        26, VERMILION, 600, "middle", 830)

    # Panel B right: Duplicate admission negative control
    rect(938, 594, 458, 258, VERMILION, TINT_WARM, 1.8, rx=6, dashed=True)
    txt(1167, 636, L("重复准入负控（已封堵）", "Duplicate-admission control"), 26, VERMILION, 600, "middle", 430)
    txt(1167, 686, L("若容许自由重复登记同一来源 o：", "If free double admission of o:"), 24, INK, 400, "middle", 430)
    txt(1167, 730, L("若各足额清偿，合计 2Q{isub:o}", "If both pay in full, total 2Q{isub:o}"), 25, VERMILION, 600, "middle", 435)
    txt(1167, 782, L("源访问严格有序 ⇒ 每 o 至多一槽", "Ordered source visits ⇒ ≤ 1 slot per o"), 24, DEEP, 600, "middle", 435)
    txt(1167, 822, L("任何无界序列 d(k) 均不可能兑付", "Unbounded sequence d(k) impossible"), 24, SLATE, 600, "middle", 435)

    txt(
        720,
        902,
        L("原则三：真实贡献按事前约定受偿结清，绝不借转让或时间延续转化为永久控制权",
          "Principle 3: Contributions settle up to agreed issuance and never convert into permanent control"),
        26,
        DEEP,
        600,
        "middle",
        1340,
    )
    save(
        "03-paid-renewal-v3",
        h,
        {
            "panel_a": "two_round_open_event_innovation_witness_and_three_negative_controls",
            "panel_b": "origin_unique_telescoping_bound_and_duplicate_admission_control",
            "theorems": ["Thm 4.1", "Thm 4.2"],
        },
    )


def plate_04_time_dividend() -> None:
    h = start(
        920,
        L("公共方法全词可交换劳动红利与 25 步自愿退出双审轨迹", "Whole-word commuting labor dividend and 25-step voluntary-exit dual-audit trace"),
        L(
            "面板A展示已付方法复用省下的同一单位初始生产单元劳动在支出、末库存与任意旧合法行动序列执行后的等价读面；面板B展示25步公共生产轨迹中的自愿退出、空派工、角色外生产、重返及Raw/Ledger双路独立验收。",
            "Panel A shows one saved unit of initial-unit labor across current debit, terminal carrier x + 1, and execution of every previously lawful finite sequence w; Panel B shows the 25-step trace with exit, empty dispatch, outside production, paid return, and dual Raw/Ledger verification.",
        ),
    )
    txt(44, 48, L("A  同一单位劳动红利的全词可交换保持（定理 6.1(i)）", "A  Whole-word commutation of one saved labor unit (Thm. 6.1(i))"), 29, DEEP, 600, max_width=940)
    txt(1396, 48, L("访问 4 实付审计 1 → 访问 7 复用", "Visit 4 pays audit 1 → Visit 7 reuses"), 24, SLATE, 600, "end", 450)

    circle(168, 248, 72, VERMILION, TINT_WARM, 3.0)
    txt(168, 276, "+1", 74, VERMILION, 700, "middle")
    txt(168, 364, L("同一单位劳动", "One labor unit"), 26, VERMILION, 600, "middle", 240)

    segment(248, 248, 316, 248, HAIR, 2.0)
    path("M 352 146 L 316 146 L 316 350 L 352 350", [316, 146, 352, 350], HAIR, 2.0)
    for ry in (146, 248, 350):
        segment(316, ry, 366, ry, HAIR, 2.0)

    cards = [
        (146, L("读面 1 · 当期审计借记", "Reading 1 · Current debit"), L("母单元劳动支出少 1（全地址贷记相等）", "Initial unit spends 1 less labor (all credits equal)")),
        (248, L("读面 2 · 完整末态载体", "Reading 2 · Terminal carrier"), "{i:x}{sub:shared} = {i:x}{sub:base} ⊕ 1"),
        (350, L("读面 3 · 任意旧合法词 w", "Reading 3 · Old legal word w"), "execute({i:x}{sub:shared}, {i:w}) = execute({i:x}{sub:base}, {i:w}) ⊕ 1"),
    ]
    for ry, left_lbl, right_lbl in cards:
        rect(372, ry - 38, 1024, 72, HAIR, TINT_NAVY if ry == 248 else "white", 1.6, rx=4)
        txt(396, ry + 9, left_lbl, 26, DEEP, 600, max_width=360)
        txt(1374, ry + 9, right_lbl, 25, VERMILION if ry != 146 else INK, 600, "end", 620)

    txt(720, 434, L("三层读面刻画同一份实物劳动余裕，不可重复相加；如何转化为减工时由净额核算与受影响者决定",
                    "Three readings of the same saved labor unit (never summed); worktime reduction requires net accounting & choice"),
        24, INK, 600, "middle", 1340)

    rule(468)
    txt(44, 514, L("B  同一 25 步轨迹：自愿退出、零强制派工、角色外生产与双路验收（定理 6.1(ii)–(iii)）",
                    "B  Same 25-step trace: exit, empty dispatch, outside production & dual audit (Thm. 6.1(ii)–(iii))"),
        28, DEEP, 600, max_width=1350)

    # Timeline nodes: state 0 -> step 18 -> step 19 -> step 21 -> step 22 -> step 24 -> state 25
    y_line = 616
    rect(52, y_line - 28, 68, 56, DEEP, TINT_NAVY, 2.2)
    txt(86, y_line + 10, "0", 30, DEEP, 700, "middle")
    txt(86, y_line - 42, L("初态", "init"), 24, SLATE, 600, "middle", 90)

    step_nodes = [
        (276, "18", DEEP, [L("本人退出", "Actor exits"), L("至状态 19", "to state 19")]),
        (488, "19", DEEP, [L("他人拒任", "Peer refuses"), L("至状态 20", "to state 20")]),
        (718, "21", VERMILION, [L("审计付得起", "Audit affordable"), L("派工仍为空", "dispatch = [ ]")]),
        (948, "22", VERMILION, [L("角色外生产", "Outside prod."), L("种子净 +2", "seed net +2")]),
        (1168, "24", DEEP, [L("实付重返", "Paid return"), L("劳动借记 1", "pays labor 1")]),
    ]

    segment(124, y_line, 240, y_line, DEEP, 2.2, arrow=True, dashed=True)
    segment(312, y_line, 452, y_line, DEEP, 2.2, arrow=True)
    segment(524, y_line, 682, y_line, DEEP, 2.2, arrow=True, dashed=True)
    segment(754, y_line, 912, y_line, VERMILION, 2.4, arrow="v")
    segment(984, y_line, 1132, y_line, DEEP, 2.2, arrow=True, dashed=True)
    segment(1204, y_line, 1312, y_line, DEEP, 2.4, arrow=True)

    for sx, snum, scol, slines in step_nodes:
        circle(sx, y_line, 32, scol, TINT_WARM if scol == VERMILION else "white", 2.5)
        txt(sx, y_line + 11, snum, 30, scol, 700, "middle")
        lines(sx, y_line + 78, slines, 24, scol if scol == VERMILION else INK, 600, "middle", gap=34, max_width=205)

    rect(1318, y_line - 28, 68, 56, DEEP, TINT_NAVY, 2.2)
    txt(1352, y_line + 10, "25", 30, DEEP, 700, "middle")
    txt(1352, y_line - 42, L("末态", "end"), 24, SLATE, 600, "middle", 90)

    # Dual audit footer bar
    rect(44, 770, 1352, 86, DEEP, TINT_NAVY, 1.8, rx=5)
    txt(
        720,
        806,
        L("双路独立验收：Raw 发生扫描 与 Ledger 槽位重放（原 6 槽 + 4 次出生 8 新槽）各自独立通过",
          "Dual independent audit: Raw occurrence scan & Ledger slot replay (6 original + 8 newborn slots) both pass"),
        25,
        DEEP,
        600,
        "middle",
        1310,
    )
    txt(
        720,
        842,
        L("全地址仍保 +1 劳动差与全旧词可执行性；末尾 CopyReview 诚实保留下轮供料缺口",
          "Full carrier retains +1 labor & all old legal continuations; final CopyReview preserves real supply gap"),
        24,
        SLATE,
        600,
        "middle",
        1310,
    )
    txt(
        720,
        896,
        L("原则五：有能力工作不等于必须接受派工；技术余裕须经完整净账回到人的自主时间",
          "Principle 5: Capacity to work never implies compulsory dispatch; surplus returns via full net accounting"),
        26,
        VERMILION,
        600,
        "middle",
        1340,
    )
    save(
        "04-time-dividend-v3",
        h,
        {
            "panel_a": "three_non_additive_readings_and_whole_word_commutation",
            "panel_b": "25_step_exit_empty_dispatch_outside_production_and_dual_audit",
            "theorems": ["Thm 6.1"],
        },
    )


def plate_05_revocable_governance_audit() -> None:
    h = start(
        940,
        L("公职到期无吸收终局、双发票内生计费规划与限域零泄漏核验", "Term expiry without absorbing sink, dual-invoice paid planning, and zero-leakage scoped audit"),
        L(
            "面板A展示任意有限续行中目录、责任与金融收据完整延续而到期权限永久归零，以及净转换成本上界；面板B展示共同切口全自适应对手联合表比较、六阶段互斥票据槽计量与双掩码自适应零泄漏公开核验。",
            "Panel A shows unbroken directory, responsibility, and financial continuation alongside permanent expiration of term jurisdiction and the net switching-cost bound; Panel B shows common-cut adaptive-opponent planning, 6-phase work metering, and two-mask zero-leakage public verification.",
        ),
    )
    txt(44, 48, L("A  责任跨期连续 vs. 公职任期无永久吸收汇（定理 7.1–7.2）", "A  Continuous responsibility vs. no sovereign absorbing sink (Thms. 7.1–7.2)"), 29, DEEP, 600, max_width=1050)
    txt(1396, 48, L("原未结 settled = false", "unsettled = true"), 24, SLATE, 600, "end", 320)

    # Panel A left-to-right tracks
    rect(44, 78, 860, 290, HAIR, "white", 1.8, rx=6)
    txt(474, 118, L("任意同路径片段 C{isub:s} → C{isub:s+k} = causalAt(C{isub:s}, k)", "Any on-path segment C{isub:s} → C{isub:s+k} = causalAt(C{isub:s}, k)"), 26, DEEP, 600, "middle", 820)

    # Track 1: Responsibility & Directory persists
    rect(72, 146, 804, 84, DEEP, TINT_NAVY, 1.8, rx=4)
    txt(94, 182, L("公共职能与责任轨道（跨更替完整保持）", "Public directory & responsibility track (preserved)"), 25, DEEP, 600, max_width=760)
    txt(94, 216, L("目录前缀 · 基准 · origin(r') = origin(r) · 收据 · 三歧处置", "Directory · bases · origin(r') = origin(r) · receipts · review"), 24, INK, 400, max_width=765)

    # Track 2: Incumbent jurisdiction expires
    rect(72, 254, 420, 92, DEEP, "white", 1.8, rx=4)
    txt(282, 292, L("任期内 clock ≤ d{sub:ε}", "In term: clock ≤ d{sub:ε}"), 25, DEEP, 600, "middle", 390)
    txt(282, 330, L("有效管辖 J{sub:ε}(i, x) 成立", "Jurisdiction J{sub:ε}(i, x) active"), 24, INK, 400, "middle", 390)

    segment(496, 300, 548, 300, VERMILION, 2.6, arrow="v")
    rect(554, 254, 322, 92, VERMILION, TINT_WARM, 2.0, rx=4)
    txt(715, 292, L("届满后全部实际后缀", "All post-expiry suffixes"), 25, VERMILION, 600, "middle", 302)
    txt(715, 330, L("¬J{sub:ε}(i, x) · 无吸收域", "¬J{sub:ε}(i, x) · no absorbing sink"), 24, VERMILION, 600, "middle", 302)

    # Panel A right: Net capture bound
    rect(928, 78, 468, 290, DEEP, TINT_NAVY, 1.8, rx=6)
    txt(1162, 120, L("同窗可替换净负担界（定理 7.2）", "Switching-cost bound (Thm. 7.2)"), 26, DEEP, 600, "middle", 442)
    txt(1162, 174, L("三歧判决：基准未付 ∨ 严格改善", "Unpaid baseline ∨ improvement"), 24, INK, 400, "middle", 442)
    txt(1162, 212, L("∨ 计算稳定下对全部候选 a：", "∨ under computed stability ∀ a:"), 24, INK, 400, "middle", 442)
    rect(956, 236, 412, 62, VERMILION, "white", 2.0, rx=4)
    txt(1162, 276, "{i:F}{isub:s}({i:b}) − {i:F}{isub:s}({i:a}) ≤ {i:B}({i:a}; {i:b}) − {i:G}({i:a}; {i:b})", 26, VERMILION, 700, "middle", 396)
    txt(1162, 340, L("动态缺口 remaining + paid = quantity", "Cell: remaining + paid = quantity"), 24, SLATE, 600, "middle", 442)

    rule(400)
    txt(44, 446, L("B  内生计费政策比较与反全景限域零泄漏核验（定理 7.3–7.4）", "B  Endogenously metered planning and zero-leakage scoped audit (Thms. 7.3–7.4)"), 29, DEEP, 600, max_width=1180)

    # Panel B left: Paid planning
    rect(44, 474, 666, 382, HAIR, "white", 1.8, rx=6)
    txt(377, 514, L("共同切口比较与双发票守恒（定理 7.3）", "Common-cut planning & billing (Thm. 7.3)"), 25, DEEP, 600, "middle", 640)
    txt(377, 562, L("有限联合表 ∀t ∈ T  ⇔  全允许自适应对手 ∀ω", "Joint tables ∀t ∈ T  ⇔  all adaptive opponents ∀ω"), 25, VERMILION, 600, "middle", 635)
    txt(377, 606, L("票 1 目录 L → 票 2：u{sub:cmp} = 1 + p + ∑(1 + p + 3|w|)", "Bill 1 L → Bill 2: u{sub:cmp} = 1 + p + ∑(1 + p + 3|w|)"), 24, INK, 600, "middle", 642)

    # 6-phase bar
    bx0, by0 = 72, 636
    widths = [92, 92, 98, 92, 92, 86, 86]
    p_labels = ["e{sub:0}", "e{sub:1}", "e{sub:2}", "e{sub:3}", "e{sub:4}", "e{sub:5}", L("未用", "left")]
    cur_x = bx0
    for idx, (pw, pl) in enumerate(zip(widths, p_labels)):
        fill = TINT_NAVY if idx < 6 else "white"
        rect(cur_x, by0, pw, 54, DEEP if idx < 6 else SLATE, fill, 1.6)
        txt(cur_x + pw / 2, by0 + 36, pl, 24, DEEP if idx < 6 else SLATE, 600, "middle", pw - 6)
        cur_x += pw

    txt(377, 734, L("互斥票据槽单射：∑ e{isub:j} + unused = u", "Disjoint slot injection: ∑ e{isub:j} + unused = u"), 24, DEEP, 600, "middle", 640)
    txt(377, 778, L("全责任非劣且无支配选择；否则逐意向保留失守行", "Non-dominated choice or per-intent failure row"), 24, INK, 400, "middle", 642)
    txt(377, 822, L("实际部署窗口 ≡ 所比较完整窗口（含自身实付前缀）", "Installed window ≡ compared full cut window"), 24, SLATE, 600, "middle", 640)

    # Panel B right: Anti-Panopticon Scoped Audit
    rect(736, 474, 660, 382, VERMILION, TINT_WARM, 1.8, rx=6)
    txt(1066, 514, L("权力携证 · 双掩码零泄漏审计（定理 7.4）", "Proof-carrying · Zero-leakage audit (Thm. 7.4)"), 25, VERMILION, 600, "middle", 632)

    rect(762, 542, 286, 114, DEEP, "white", 1.7, rx=4)
    txt(905, 580, L("参与方 3 私域 false", "Party 3 priv. false"), 25, DEEP, 600, "middle", 268)
    txt(905, 616, L("储备 39 · 转 39 ✓", "Stock 39 · send 39 ✓"), 24, INK, 600, "middle", 268)

    rect(1084, 542, 286, 114, DEEP, "white", 1.7, rx=4)
    txt(1227, 580, L("参与方 3 私域 true", "Party 3 priv. true"), 25, DEEP, 600, "middle", 268)
    txt(1227, 616, L("储备 38 · 转 39 拒", "Stock 38 · send 39 no"), 24, VERMILION, 600, "middle", 272)

    segment(905, 658, 995, 698, DEEP, 2.0, arrow=True)
    segment(1227, 658, 1137, 698, DEEP, 2.0, arrow=True)

    rect(762, 702, 608, 130, DEEP, "white", 1.9, rx=4)
    txt(1066, 740, L("双掩码核验通过 ⇒ 原槽实付", "Either verified verdict ⇒ original slot paid"), 24, DEEP, 600, "middle", 588)
    txt(1066, 778, "∀π, {i:k}: adaptive(π, false, {i:k}) = adaptive(π, true, {i:k})", 25, VERMILION, 700, "middle", 588)
    txt(1066, 814, L("有限独立联合律相等 · 交接恢复私域后继", "Equal finite joint law · own next at handoff"), 24, SLATE, 600, "middle", 592)

    txt(
        720,
        910,
        L("原则六：公共职能连续而公职可撤；规划计算实付入账；核验权力携证而私人自主零泄漏",
          "Principle 6: Functions persist while offices expire; planning pays its bill; public audit leaks zero private reserve"),
        26,
        DEEP,
        600,
        "middle",
        1350,
    )
    save(
        "05-revocable-governance-audit-v3",
        h,
        {
            "panel_a": "unbroken_public_responsibility_term_expiry_and_net_capture_bound",
            "panel_b": "common_cut_paid_planning_and_zero_leakage_scoped_audit",
            "theorems": ["Thm 7.1", "Thm 7.2", "Thm 7.3", "Thm 7.4"],
        },
    )


def plate_06_world_safe_regeneration() -> None:
    h = start(
        920,
        L("跨清算外部责任保留、严格自由进展与同发生世界安全再生", "Post-settlement external liability, strict paid-frontier progress, and world-safe regeneration"),
        L(
            "面板A展示本地空账不抹除跨界外部责任、耗尽责任账零预算夹逼闭包及瞬时容量恒为1时的已付权威前沿真包含；面板B展示同一次周期付款同时兑现六项世界安全再生因子及深度0双分支修法。",
            "Panel A shows cross-boundary external liability surviving an empty local ledger, zero-budget squeeze on exhausted rows, and strict paid-frontier expansion at constant capacity K=1; Panel B shows one periodic payment realizing all six world-safe regeneration factors plus depth-0 dual-branch revision.",
        ),
    )
    txt(44, 48, L("A  跨界外部责任、零预算夹逼与已付前沿真包含（定理 8.1, 9.1 · 命题 9.2）",
                    "A  External liability, zero-budget squeeze & strict frontier (Thms. 8.1, 9.1 · Prop. 9.2)"),
        28, DEEP, 600, max_width=1350)

    # Three cards in Panel A
    # Card 1: External liability
    rect(44, 78, 426, 286, DEEP, "white", 1.8, rx=6)
    txt(257, 118, L("1 · 跨清算外部责任保留", "1 · Cross-boundary liability"), 26, DEEP, 600, "middle", 400)
    txt(257, 166, L("本地开放账：OpenLedger{sub:loc} = ∅", "Local open ledger = ∅"), 24, SLATE, 600, "middle", 400)
    txt(257, 210, L("跨界责任：Λ{sub:ext}(e{sub:2}) ≠ ∅", "External liability Λ{sub:ext}(e{sub:2}) ≠ ∅"), 25, VERMILION, 700, "middle", 400)
    txt(257, 258, L("根、付款与服务发生关于 k 单射", "Root, payment & service injective in k"), 24, INK, 400, "middle", 400)
    txt(257, 302, L("本地空账仍有跨界外责", "Empty local ledger, live external duty"), 24, DEEP, 600, "middle", 408)

    # Card 2: Zero-budget squeeze
    rect(507, 78, 426, 286, HAIR, TINT_NAVY, 1.8, rx=6)
    txt(720, 118, L("2 · 耗尽账零预算夹逼闭包", "2 · Zero-budget squeeze"), 26, DEEP, 600, "middle", 400)
    txt(720, 166, "0 ≤ {i:B}({i:e}) ≤ {i:B}({i:a}') ≤ {i:B}({i:a}) = 0", 25, VERMILION, 700, "middle", 404)
    txt(720, 214, L("修法三活行：贡献 · 阻碍 · 新残差", "3 U8 rows: contrib. · block · residual"), 24, INK, 400, "middle", 404)
    txt(720, 258, L("真实回答存在 ∧ 正进展预算为空", "Actual answer exists ∧ B > 0 empty"), 24, DEEP, 600, "middle", 404)
    txt(720, 302, L("更换阶段不能凭空变出推进资源", "Stage change never refills capacity"), 24, SLATE, 600, "middle", 404)

    # Card 3: Strict frontier expansion
    rect(970, 78, 426, 286, VERMILION, TINT_WARM, 1.8, rx=6)
    txt(1183, 118, L("3 · 已付权威前沿严格扩张", "3 · Strict paid-frontier growth"), 26, VERMILION, 600, "middle", 400)
    txt(1183, 166, "{i:A}{sub:0} ⊊ {i:A}{sub:1} ⊊ {i:A}{sub:2} ⊊ ···", 26, VERMILION, 700, "middle", 400)
    txt(1183, 214, L("瞬时退出容量可恒为 K{isub:d} = 1", "Instantaneous capacity stays K{isub:d} = 1"), 24, INK, 400, "middle", 400)
    txt(1183, 258, "{i:C}{isub:r} ≺{sub:can} {i:C}{isub:t}  ⇔  {i:r} < {i:t}", 25, DEEP, 700, "middle", 400)
    txt(1183, 302, L("昨日收据不顶今日；共终修法新生", "Fresh payment + cofinal self-U8"), 24, DEEP, 600, "middle", 404)

    rule(396)
    txt(44, 442, L("B  同一次周期付款 p{isub:d} 的六因子世界安全再生（定理 9.3）", "B  Six-factor world-safe regeneration at one payment p{isub:d} (Thm. 9.3)"),
        29, DEEP, 600, max_width=1050)
    txt(1396, 442, L("p{isub:d} ≠ p{isub:d+1} · 零预存未来表", "p{isub:d} ≠ p{isub:d+1} · no stored future"), 24, SLATE, 600, "end", 420)

    # Central hub p_d and 6 surrounding factor boxes (3 left, 3 right)
    circle(720, 646, 76, VERMILION, TINT_WARM, 3.0)
    txt(720, 636, "{i:p}{isub:d}", 42, VERMILION, 700, "middle")
    txt(720, 678, L("同发生付款", "1 payment"), 24, DEEP, 600, "middle", 142)

    left_factors = [
        (476, L("① 同谱系有界修复", "① Same-lineage bounded repair"), L("深度 0 另有不同 self-U8 落点", "Distinct self-U8 landing at depth 0")),
        (606, L("② 普通退出容量不收缩", "② Non-contracting exit"), "1 ≤ {i:K}{isub:d} ≤ {i:K}{isub:d+1}" if LANG == "zh" else "1 ≤ {i:K}{isub:d} ≤ {i:K}{isub:d+1}"),
        (736, L("③ 捕获核逃逸与目标修复安装", "③ Exit-kernel escape"), L("p{isub:d} 捕获为空 → d+1 装入修复程序", "Captured = ∅ at p{isub:d} → repaired at d+1")),
    ]
    right_factors = [
        (476, L("④ 无不可见残差承担者", "④ No invisible residual bearer"), L("激活消费者后继 ≡ 付款后继", "Consumer next ≡ payment next")),
        (606, L("⑤ 保持 U8 修法通道且无终态封死", "⑤ Open U8 route & no terminal lock"), L("指定修复像无接地终态", "No grounded terminal in repair image")),
        (736, L("⑥ 跨界价值与源属责任精确结算", "⑥ Cross-boundary accountability"), L("对手方 ≠ 劳动者 · 保源属边界义务", "Counterparty ≠ worker · source-owned duty")),
    ]

    for fy, ftitle, fsub in left_factors:
        rect(44, fy, 548, 94, DEEP, TINT_NAVY if fy == 606 else "white", 1.7, rx=5)
        txt(66, fy + 38, ftitle, 25, DEEP, 600, max_width=510)
        txt(66, fy + 74, fsub, 24, INK, 400, max_width=510)
        segment(642, 646 + (fy - 606) * 0.32, 594, fy + 47, DEEP, 2.0, arrow=True)

    for fy, ftitle, fsub in right_factors:
        rect(848, fy, 548, 94, DEEP, TINT_NAVY if fy == 606 else "white", 1.7, rx=5)
        txt(870, fy + 38, ftitle, 25, DEEP, 600, max_width=510)
        txt(870, fy + 74, fsub, 24, INK, 400, max_width=510)
        segment(798, 646 + (fy - 606) * 0.32, 846, fy + 47, DEEP, 2.0, arrow=True)

    txt(
        720,
        888,
        L("原则七与八：任何局部繁荣不得靠向账外或后来者转嫁残差维持；每次更新须以新实付重获正当性",
          "Principles 7 & 8: Regeneration never exports hidden cross-boundary residuals; every renewal earns fresh standing"),
        26,
        VERMILION,
        600,
        "middle",
        1350,
    )
    save(
        "06-world-safe-regeneration-v3",
        h,
        {
            "panel_a": "post_settlement_external_liability_zero_budget_squeeze_and_strict_frontier",
            "panel_b": "six_factor_same_occurrence_world_safe_regeneration_and_depth_zero_self_u8",
            "theorems": ["Thm 8.1", "Thm 9.1", "Prop 9.2", "Thm 9.3"],
        },
    )


FIGURES = [
    ("01-four-claims-v3", plate_01_four_claims),
    ("02-exit-diagnosis-v3", plate_02_exit_diagnosis),
    ("03-paid-renewal-v3", plate_03_paid_renewal),
    ("04-time-dividend-v3", plate_04_time_dividend),
    ("05-revocable-governance-audit-v3", plate_05_revocable_governance_audit),
    ("06-world-safe-regeneration-v3", plate_06_world_safe_regeneration),
]


def main() -> None:
    global LANG, CHECK_ONLY
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only", choices=[x[0] for x in FIGURES])
    ap.add_argument("--language", choices=["zh", "en", "both"], default="both")
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()
    CHECK_ONLY = args.check_only

    for LANG in (["zh", "en"] if args.language == "both" else [args.language]):
        for name, draw in FIGURES:
            if args.only is None or args.only == name:
                draw()

    report = {
        "paper": "economic-constitution",
        "edition": "v3",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "generator": "make_figures_v3.py",
        "shared_dependencies_read_only": True,
        "frozen_v2_figures_untouched": True,
        "fonts": ["Noto Serif CJK SC", "STIX Two Text", "STIX Two Math"],
        "colors": {"navy": DEEP, "vermilion": VERMILION, "hairline": HAIR},
        "checks": "Glyph maps, measured label boxes, pairwise label overlap, shape extents, PDF vector/text/bounds.",
        "figures": MANIFEST,
    }
    (OUT / ".review-v3").mkdir(exist_ok=True)
    target = OUT / (
        ".review-v3/layout-report.json"
        if CHECK_ONLY
        else ("manifest-v3.json" if args.only is None and args.language == "both" else ".review-v3/partial-manifest.json")
    )
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"count": len(MANIFEST), "report": str(target), "outputs": [x["stem"] for x in MANIFEST]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
