# 公开源码与复现 / Public Sources and Reproduction

第三版的十八项正文结果见[逐项对应](source-correspondence-v3.md)和[机器可读绑定](records/v3-source-binding.json)。[公开源码映射](https://github.com/Sapientropic/H0mework/blob/main/docs/economic-constitution-v3-map.json)列出 Lean 声明、完整类型、直接消费者、原纪元及回执。[复现指南](https://github.com/Sapientropic/H0mework/blob/main/docs/economic-constitution-v3-reproduction.md)提供本地验收入口。

- 经济选集与同发生再生固定在 `2d6fbc96`，沿用原十六包的 3,313 项完整类型。
- 退出需求、再出现、限域审计及源隐私沿用 `fd6147f8`。第三版补充验收包含十五个目标和 87 项完整类型。
- [有限独立抽样的公开源码](https://github.com/Sapientropic/H0mework/tree/3c6a36c3d7ddd920f52afeb52990f0456ee53c83)复用原 `Privacy.Network`，保留新增证明的原 Git 纪元和可逆源码。
- [第二版归档](https://doi.org/10.5281/zenodo.23917902)与包内的[旧版声明绑定](records/public-source-binding.json)提供原九十行接口。历史回执保留各次真实验收范围。

The [result-by-result crosswalk](source-correspondence-v3.md) and [machine-readable binding](records/v3-source-binding.json) identify the public owners for all eighteen results. The [reproduction guide](https://github.com/Sapientropic/H0mework/blob/main/docs/economic-constitution-v3-reproduction.md) verifies the inherited acceptance, the fifteen additional targets, and the finite independent observation law.
