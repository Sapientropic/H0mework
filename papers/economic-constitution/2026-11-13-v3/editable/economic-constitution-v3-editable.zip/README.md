# An Economic Constitution of Possibility

The Chinese and English main papers and technical supplements are under
papers/economic-constitution/build/reading-v3/. The Markdown, bibliography,
and vector figures are in papers/economic-constitution/.

To rebuild from Markdown, install Python 3, Pandoc, XeLaTeX and the Latin and
CJK fonts named in shared/styles/. Place the Noto Serif and Sans CJK SC OTF
files in ~/Library/Fonts. The builder uses latexmk when available.

    python3 verify-inputs.py
    python3 papers/economic-constitution/scripts/build_reading_v3.py

Four standalone XeLaTeX sources are also included. From the paper directory,
place the four Noto CJK OTF files under fonts/ and compile the matching source.

    xelatex -halt-on-error latex/economic-constitution.tex

Repeat the command for the English paper and the two supplements, and rerun
for cross-references when requested by XeLaTeX. The supplied figure PDFs are
enough for either build. The vector source generator uses CairoSVG, fontTools,
and the fonts named in shared/figure-style/svg_text.py.

[Proof correspondence](papers/economic-constitution/source-correspondence-v3.md)
and the [H0mework reproduction guide](https://github.com/Sapientropic/H0mework/blob/main/docs/economic-constitution-v3-reproduction.md)
give the original declaration types and direct consumers.

Paper text and original figures are CC BY 4.0. Original code and formalization
are Apache-2.0.
