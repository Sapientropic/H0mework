#!/usr/bin/env python3
"""Draw the third-edition (v3) structural plates for source-process-core.

Preserves all v1 (figure1..figure6, supp1..supp2) and v2 (figure7-receipt-feedback-v2)
vector art untouched on disk, writing new v3 plates under `-v3` stems and enforcing
automated bounding-box, containment, non-overlap, and arrow-clearance checks.

Usage:
  python3 papers/source-process-core/figures/src/draw_v3_figures.py --lang zh
  python3 papers/source-process-core/figures/src/draw_v3_figures.py --lang en
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = Path(__file__).resolve().parents[4]
PAPER_DIR = Path(__file__).resolve().parents[2]
OUT = PAPER_DIR / "figures" / "vector"

sys.path.insert(0, str(ROOT / "shared" / "figure-style"))
from house_style import DEEP, GOLD, HAIR, INK, MUTE, SLATE, VERMILION, WASH, install  # noqa: E402
from matplotlib import font_manager

for _bold_cjk in (
    Path.home() / "Library/Fonts/NotoSerifCJKsc-Bold.otf",
    Path("/Library/Fonts/NotoSerifCJKsc-Bold.otf"),
):
    if _bold_cjk.exists():
        font_manager.fontManager.addfont(str(_bold_cjk))


SOURCE_COMMITS = {
    "H": "e60a86058abcb74b7f2225f2383c182be8343785",
    "MV3": "9c73a630ce05bea062ec889b188f5105c0afb796",
    "MV4": "ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa",
    "MV5": "df421ff600085cbc290a7ae946193961bed7c83b",
    "C53_54": "7e4da746f300b3796b8b18afb26cb0765c29afcb",
}


def verify_geometry(fig, ax, labels, box_patches, owned, arrow_segments):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = {t: t.get_window_extent(renderer) for t in labels}
    for t, b in bounds.items():
        assert fig.bbox.contains(b.x0, b.y0) and fig.bbox.contains(b.x1, b.y1), (
            f"Label exceeds canvas: {t.get_text()!r} -> {b}"
        )
    overlaps = [
        (labels[i].get_text(), labels[j].get_text())
        for i in range(len(labels))
        for j in range(i)
        if bounds[labels[i]].overlaps(bounds[labels[j]])
    ]
    assert not overlaps, f"Overlapping labels: {overlaps}"

    box_ext = [p.get_window_extent(renderer) for p in box_patches]
    for t, p_idx in owned.items():
        ext = box_ext[p_idx]
        b = bounds[t]
        margin = 3.0
        assert (
            b.x0 > ext.x0 + margin
            and b.x1 < ext.x1 - margin
            and b.y0 > ext.y0 + margin
            and b.y1 < ext.y1 - margin
        ), f"Owned label {t.get_text()!r} outside box {p_idx}: label={b}, box={ext}"

    def seg_hits_rect(p, q, r):
        x0, y0 = min(p[0], q[0]), min(p[1], q[1])
        x1, y1 = max(p[0], q[0]), max(p[1], q[1])
        if x1 < r.x0 or x0 > r.x1 or y1 < r.y0 or y0 > r.y1:
            return False
        if r.contains(p[0], p[1]) or r.contains(q[0], q[1]):
            return True
        edges = [
            ((r.x0, r.y0), (r.x1, r.y0)),
            ((r.x1, r.y0), (r.x1, r.y1)),
            ((r.x1, r.y1), (r.x0, r.y1)),
            ((r.x0, r.y1), (r.x0, r.y0)),
        ]

        def cross(a, b, c, d):
            def ccw(u, v, w):
                return (w[1] - u[1]) * (v[0] - u[0]) > (v[1] - u[1]) * (w[0] - u[0])

            return ccw(a, c, d) != ccw(b, c, d) and ccw(a, b, c) != ccw(a, b, d)

        return any(cross(p, q, e0, e1) for e0, e1 in edges)

    arrow_disp = [
        (ax.transData.transform(p), ax.transData.transform(q))
        for p, q in arrow_segments
    ]
    for t in labels:
        if t in owned:
            continue
        b = bounds[t]
        for i, ext in enumerate(box_ext):
            inside = ext.fully_contains(b.x0, b.y0) and ext.fully_contains(b.x1, b.y1)
            assert not (b.overlaps(ext) and not inside), (
                f"Label {t.get_text()!r} crosses box {i} frame"
            )
        for p, q in arrow_disp:
            assert not seg_hits_rect(p, q, b), (
                f"Label {t.get_text()!r} crosses arrow segment {p}->{q}"
            )
    return len(labels)


STRINGS_FIG2 = {
    "zh": dict(
        top_L="支路 I · 语言破产时的 T0 初始余面修订（第 7–8 节）",
        top_Ls1=r"双空破产 $\eta \mapsto C_\eta = L_+ \sqcup \{\star_\eta\}$，旧定理存续，新行零预算",
        top_Ls2=r"范畴初始唯一态射 $F:C_\eta\to\mathcal{E}$；旧债与 $\star_\eta$ 同入首写，第 2 拍直答（定理 8.4, 8.6–8.7）",
        top_R="支路 II · 语言充足时的 T1 可逆增量续行（第 8.5–10 节）",
        top_Rs1=r"总值写回 $V=p+n$、六面余链与最大未来核 $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$（定理 8.15, 9.9–9.12）",
        top_Rs2=r"双取反恢复已付树行 $f^{(n+1)}$、逐原语微分与步—请求反演 $r=a_i+s$（定理 10.1–10.6）",
        gap34="反例门禁：一次性空纤维无自主续行（命题 8.10）；双空破产无旧词可表（命题 7.4）",
        t4="第 4 层 · 同一笔责任与内生扣款（T0 良基核／T1 整账编译，第 6 节）",
        t4s1=r"生命周期三律；无总法则 $\leq\,;\,<\,;\,\leq$ 付款宏步良基性（定理 6.7）；零预算空终账反例",
        t4s2=r"无旧承担者计算责任行内生出生、逐步严格扣款与 Type 完成回执 $d_i=B_i$（定理 6.10, 6.12）",
        gap23="反例门禁：同序列状态快照可洗掉活债谱系或偷换承担槽位",
        t3="第 3 层 · 同一次有根发生与唯一实现比较（T0 零公理，第 5 节）",
        t3s1=r"双向发生—事件表示、发射相容与编译合法恢复全部已安装投影与原生后继（命题 5.2）",
        t3s2=r"无需外部模拟关系或辅助历史变量：任意候选事件映射逐点唯一等于源生比较（定理 5.3）",
        gap12="反例门禁：两套实现产出相同观测读数，却无法指认哪一事件对应哪次发生",
        t2="第 2 层 · 同一源对象、纯语法左逆与正合求值核（T1 模代数层，第 2.3–4 节）",
        t2s1=r"自由载体 $\mathbb{Z}[S]$ 与三项更新律；构造子恒零 $\kappa\equiv 0$ 时整树程序仍纯语法单射逆读（定理 3.9）",
        t2s2=r"推导差与模律正合覆盖求值核 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$；逆极限完备化演化律（定理 4.4, 4.6–4.7）",
        gap01=r"反例门禁：三拍局部同读 $0,0,1$ 无共同源词（例 4.1）；旧关系 $x^2-x$ 跨拍失效（例 4.2）",
        t0="第 1 层起点与 T0 零公理地基 · 单构造子发生展开与根读恒等（第 1.1, 2.1–2.2 节）",
        t0s1=r"零公理单构造子 $\mathrm{occur}(a,[T_1,\dots,T_k])$ 派生前沿、结合推进、并／联组合与万有唯一折叠（定理 2.2）",
        t0s2=r"根读恒等 $\mathrm{rootRead}(o)=o$ 零隐藏空证人；固定法则过程后继确定且不暗藏修订（命题 2.4）",
        foot="自下而上逐层增持不变量；朱砂框标出第三版封顶闭合层，全部定理配对精确反例或反向门禁",
    ),
    "en": dict(
        top_L="Branch I | T0 Initial-Coface Revision (§7–§8)",
        top_Ls1=r"Double-empty $\eta \mapsto C_\eta = L_+ \sqcup \{\star_\eta\}$; old theorems kept, zero budget",
        top_Ls2=r"Unique initial map $F:C_\eta\to\mathcal{E}$; shared 1st write & tick-2 answer (8.4, 8.6–8.7)",
        top_R="Branch II | T1 Reversible Continuation (§8.5–§10)",
        top_Rs1=r"Writeback $V=p+n$, six-face cochain & kernel $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$ (8.15, 9.9–9.12)",
        top_Rs2=r"Double-negation AST $f^{(n+1)}$, step replay $d^{0,1}$ & slice $r=a_i+s$ (10.1–10.6)",
        gap34="Obstruction gate: empty query fibre blocks one-shot runs (Prop. 8.10); double emptiness blocks old syntax (Prop. 7.4)",
        t4="Tier 4 | Same Obligation & Endogenous Step Payment (T0 Kernel / T1 Ledger, §6)",
        t4s1=r"Three lifecycle laws; law-free $\leq\,;\,<\,;\,\leq$ macro well-foundedness (Thm. 6.7); zero-budget empty-terminal counterexample",
        t4s2=r"Bearer-free computational debt birth, strict per-step debit & Type completion receipt $d_i=B_i$ (Thms. 6.10, 6.12)",
        gap23="Obstruction gate: identical state snapshots can erase live debt lineage or swap obligation slots",
        t3="Tier 3 | Same Rooted Occurrence & Unique Realization Comparison (T0 Zero-Axiom, §5)",
        t3s1=r"Two-sided occurrence–event representation & lawful compilation recover all installed projections and next (Prop. 5.2)",
        t3s2=r"No preset simulation or history variable needed: every candidate event map equals the source comparison (Thm. 5.3)",
        gap12="Obstruction gate: two implementations emit equal observation traces without identifying which event is which occurrence",
        t2="Tier 2 | Same Source Object, Syntactic Left Inverse & Exact Kernel (T1 Module Layer, §2.3–§4)",
        t2s1=r"Free carrier $\mathbb{Z}[S]$ & 3-term update; even under $\kappa\equiv 0$, whole-tree programs invert by syntax alone (Thm. 3.9)",
        t2s2=r"Exact kernel $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$, fibre criterion & elementwise completion evolution (Thms. 4.4, 4.6–4.7)",
        gap01=r"Obstruction gate: 3-tick local readings $0,0,1$ admit no common word (Ex. 4.1); $x^2-x$ fails across ticks (Ex. 4.2)",
        t0="Tier 1 Baseline & T0 Zero-Axiom Foundation | Single-Constructor Unfolding (§1.1, §2.1–§2.2)",
        t0s1=r"Single constructor $\mathrm{occur}(a,[T_1,\dots,T_k])$ derives frontier, associative advance, $+/\times$ shadows & unique fold (Thm. 2.2)",
        t0s2=r"Root identity $\mathrm{rootRead}(o)=o$ excludes hidden-null witnesses; fixed-law processes preserve law surface (Prop. 2.4)",
        foot="From bottom to top each tier retains strictly stronger invariants; vermilion marks the v3 capstone closure",
    ),
}


def draw_fig2_v3(lang: str) -> tuple[plt.Figure, int]:
    install("spc-v3-architecture", lang)
    s = STRINGS_FIG2[lang]
    en = lang == "en"
    fig, ax = plt.subplots(figsize=(10.6, 8.8))
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    ax.set(xlim=(0, 12), ylim=(0, 10.0))
    ax.axis("off")

    labels = []
    box_patches = []
    arrow_segments = []
    owned = {}

    def label(x, y, value, size=10.0, color=INK, weight="normal", ha="center", owner=None):
        item = ax.text(x, y, value, ha=ha, va="center", fontsize=size, color=color, fontweight=weight)
        labels.append(item)
        if owner is not None:
            owned[item] = owner
        return item

    def box(x, y, w, h, fill="white", edge=DEEP, lw=1.05):
        p = FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.04,rounding_size=0.07",
            facecolor=fill, edgecolor=edge, linewidth=lw,
        )
        ax.add_patch(p)
        box_patches.append(p)
        return len(box_patches) - 1

    def arrow(start, end, color=DEEP, lw=1.2):
        ax.add_patch(
            FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=11.5, linewidth=lw, color=color)
        )
        arrow_segments.append((start, end))

    tsz = 9.2 if en else 10.3
    ssz = 8.05 if en else 8.95
    gsz = 7.95 if en else 8.85

    # Bottom T0 foundation + Tier 2 + Tier 3 + Tier 4
    rows = [
        (0.55, 1.32, "t0", "t0s1", "t0s2", "white", DEEP, 1.15),
        (2.47, 1.32, "t2", "t2s1", "t2s2", "white", DEEP, 1.05),
        (4.39, 1.32, "t3", "t3s1", "t3s2", "white", DEEP, 1.05),
        (6.31, 1.32, "t4", "t4s1", "t4s2", "white", DEEP, 1.05),
    ]
    for y, h, tk, sk1, sk2, fill, edge, lw in rows:
        bi = box(0.42, y, 11.16, h, fill=fill, edge=edge, lw=lw)
        label(6.0, y + 1.00, s[tk], tsz, DEEP, "bold", owner=bi)
        label(6.0, y + 0.61, s[sk1], ssz, INK, owner=bi)
        label(6.0, y + 0.24, s[sk2], ssz, SLATE, owner=bi)

    # Top bifurcated capstone row: Branch I (left) & Branch II (right)
    ty, th = 8.26, 1.46
    bL = box(0.42, ty, 5.44, th, fill=WASH, edge=VERMILION, lw=1.25)
    label(3.14, ty + 1.13, s["top_L"], 8.75 if en else 9.8, VERMILION, "bold", owner=bL)
    label(3.14, ty + 0.70, s["top_Ls1"], 7.75 if en else 8.65, INK, owner=bL)
    label(3.14, ty + 0.27, s["top_Ls2"], 7.55 if en else 8.45, SLATE, owner=bL)

    bR = box(6.14, ty, 5.44, th, fill=WASH, edge=VERMILION, lw=1.25)
    label(8.86, ty + 1.13, s["top_R"], 8.75 if en else 9.8, VERMILION, "bold", owner=bR)
    label(8.86, ty + 0.70, s["top_Rs1"], 7.75 if en else 8.65, INK, owner=bR)
    label(8.86, ty + 0.27, s["top_Rs2"], 7.55 if en else 8.45, SLATE, owner=bR)

    # Arrows on left/right side rails so center obstruction text never touches an arrow
    ax_xL, ax_xR = 0.88, 11.12
    for y_low, y_high in [(1.93, 2.41), (3.85, 4.33), (5.77, 6.25)]:
        arrow((ax_xL, y_low), (ax_xL, y_high), DEEP, 1.2)
        arrow((ax_xR, y_low), (ax_xR, y_high), DEEP, 1.2)

    arrow((ax_xL, 7.69), (ax_xL, 8.20), VERMILION, 1.3)
    arrow((ax_xR, 7.69), (ax_xR, 8.20), VERMILION, 1.3)

    # Obstruction gates centered cleanly in the inter-row gaps
    label(6.0, 2.17, s["gap01"], gsz, SLATE)
    label(6.0, 4.09, s["gap12"], gsz, SLATE)
    label(6.0, 6.01, s["gap23"], gsz, SLATE)
    label(6.0, 7.95, s["gap34"], gsz, VERMILION)

    label(6.0, 0.20, s["foot"], 7.6 if en else 8.6, MUTE)

    checked = verify_geometry(fig, ax, labels, box_patches, owned, arrow_segments)
    return fig, checked


STRINGS_FIG8 = {
    "zh": dict(
        secA="A · 全环境语义零关系与残差同债结清（定理 10.1–10.2，C46–C49）",
        a1="全环境语义零同余",
        a1s1=r"$\delta_{e\ominus e'}-(\delta_e-\delta_{e'})\in\mathcal{Z}_{\rm sem}$",
        a1s2=r"$\forall a\in\{\ast\}^{<\omega},\forall j$ 同属 $\mathsf{M}_{\rm fut}$ 类",
        a2="保留余项重排联合求值",
        a2s1=r"$\mathrm{jointCode}(c)$ 分离物理与残差输入",
        a2s2=r"合值 $=\mathrm{ev}_{\rho_{\rm phys}+\rho_{\rm res}}(c)$",
        a3="出生语法信用同债完结",
        a3s1=r"严格扣款 $B{-}1\to 0$（零效应仍付语法费）",
        a3s2=r"交出 $\mathrm{eff}_{\rho,\varepsilon}(e)$、旧／出生行与规范后继",
        secB="B · 双取反恢复已付语法树与整词逐原语上同调回放（定理 10.3–10.4，C51–C52）",
        b1="两层残差双取反提取",
        b1s1=r"$\mathrm{retainedCode}=(-\mathrm{id})((-\mathrm{id})(e'))$",
        b1s2=r"零环标量恢复已付常量树 $p=\mathrm{ev}_\rho(e)$",
        b2="预定加法同态跨包执行",
        b2s1=r"逐级提升 $f^{(0)}=f,\ f^{(n+1)}=f^{(n)}\times f^{(n)}$",
        b2s2=r"下一共尾包读出 $(f^{(n+1)}(p),0)$ 并入出生库",
        b3="整词逐原语余链微分锁步",
        b3s1=r"$\mathrm{embeddedTrace}$ 逐步转入原生环境",
        b3s2=r"$\mathrm{rel}_{\widetilde\rho}(\tau_1\mu)=b_{\rm act}=d^{0,1}(b_{\rm act})$",
        secC="C · 执行步—请求双向区间反演与封存前缀末态续行（定理 10.5–10.6，C53–C54）",
        c1="正向连续请求切片",
        c1s1=r"步骤 $i \mapsto \mathrm{stepInterval}(i)=[a_i,a_i+c_i)$",
        c1s2="切片有号和等于解码仿射动作边界",
        c2="反向唯一起源与防漏重门禁",
        c2s1=r"请求 $r \mapsto (i,s)$ 满足 $r=a_i+s$",
        c2s2="拼接还原整批；删／重任一非空组必改迹",
        c3="封存历史锁前缀末态续行",
        c3s1=r"$\mathrm{prefix}_{\rm fuel}(\mathrm{extendTo}(H,\mathrm{total}))=H$",
        c3s2=r"仅从末态跑 $\mathrm{total}-\mathrm{fuel}$ 步；时间表长 $\mathrm{fuel}+1$",
        feedAB="规范后继携带完整已付材料",
        feedBC="出生库存移交整条回放迹",
        foot="朱砂框标出三处核心无损不变量：同债语法完结、双取反同态续行、双向切片寻址与前缀锁定",
    ),
    "en": dict(
        secA="A | All-Environment Semantic Zero & Same-Debt Residual Settlement (Thms. 10.1–10.2, C46–C49)",
        a1="Universal Semantic-Zero Class",
        a1s1=r"$\delta_{e\ominus e'}-(\delta_e-\delta_{e'})\in\mathcal{Z}_{\rm sem}$",
        a1s2=r"same $\mathsf{M}_{\rm fut}$ class $\forall a\in\{\ast\}^{<\omega},\,\forall j$",
        a2="Regrouped Joint Residual Code",
        a2s1=r"$\mathrm{jointCode}(c)$ splits base & residual",
        a2s2=r"sum $=\mathrm{ev}_{\rho_{\rm phys}+\rho_{\rm res}}(c)$",
        a3="Same-Debt Syntax Settlement",
        a3s1=r"strict debit $B{-}1\to 0$ (even if effect $=0$)",
        a3s2=r"delivers $\mathrm{eff}_{\rho,\varepsilon}(e)$, rows & canonical next",
        secB="B | Double-Negation Paid-AST Recovery & Primitive Cochain Replay (Thms. 10.3–10.4, C51–C52)",
        b1="Double-Negation Extraction",
        b1s1=r"$\mathrm{retainedCode}=(-\mathrm{id})((-\mathrm{id})(e'))$",
        b1s2=r"ring-free paid AST $p=\mathrm{ev}_\rho(e)$",
        b2="Pre-Fixed Homomorphic Step",
        b2s1=r"lift $f^{(0)}=f,\ f^{(n+1)}=f^{(n)}\times f^{(n)}$",
        b2s2=r"next packet $(f^{(n+1)}(p),0)$ in stock",
        b3="Primitive Cochain Lockstep",
        b3s1=r"$\mathrm{embeddedTrace}$ replays each step",
        b3s2=r"$\mathrm{rel}_{\widetilde\rho}(\tau_1\mu)=b_{\rm act}=d^{0,1}(b_{\rm act})$",
        secC="C | Bidirectional Step–Request Slice Inversion & Tail Continuation (Thms. 10.5–10.6, C53–C54)",
        c1="Forward Contiguous Slice",
        c1s1=r"step $i \mapsto \mathrm{stepInterval}(i)=[a_i,a_i+c_i)$",
        c1s2="slice sum = affine decoded boundary",
        c2="Backward Origin & Gate",
        c2s1=r"request $r \mapsto (i,s)$ with $r=a_i+s$",
        c2s2="omit/dup nonempty group alters trace",
        c3="Sealed-Prefix Continuation",
        c3s1=r"$\mathrm{prefix}_{\rm fuel}(\mathrm{extendTo}(H,\mathrm{total}))=H$",
        c3s2=r"runs $\mathrm{total}-\mathrm{fuel}$ suffix; table $\mathrm{fuel}+1$",
        feedAB="canonical next carries paid material",
        feedBC="born stock hands over replay trace",
        foot="Vermilion marks the three lossless invariants: same-debt settlement, homomorphic AST reuse, and slice/prefix inversion",
    ),
}


def draw_fig8_v3(lang: str) -> tuple[plt.Figure, int]:
    install("spc-v3-continuation", lang)
    s = STRINGS_FIG8[lang]
    en = lang == "en"
    fig, ax = plt.subplots(figsize=(10.6, 7.6))
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    ax.set(xlim=(0, 12), ylim=(0, 8.6))
    ax.axis("off")

    labels = []
    box_patches = []
    arrow_segments = []
    owned = {}

    def label(x, y, value, size=10.0, color=INK, weight="normal", ha="center", owner=None):
        item = ax.text(x, y, value, ha=ha, va="center", fontsize=size, color=color, fontweight=weight)
        labels.append(item)
        if owner is not None:
            owned[item] = owner
        return item

    def box(x, y, w, h, fill="white", edge=DEEP, lw=1.05):
        p = FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.04,rounding_size=0.07",
            facecolor=fill, edgecolor=edge, linewidth=lw,
        )
        ax.add_patch(p)
        box_patches.append(p)
        return len(box_patches) - 1

    def arrow(start, end, color=DEEP, lw=1.2):
        ax.add_patch(
            FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=11.5, linewidth=lw, color=color)
        )
        arrow_segments.append((start, end))

    xs = [0.42, 4.26, 8.10]
    bw = 3.48
    bh = 1.50

    hsz = 9.2 if en else 10.3
    tsz = 8.75 if en else 9.8
    ssz = 7.75 if en else 8.65

    bands = [
        (6.32, "secA", [("a1", False), ("a2", False), ("a3", True)]),
        (3.60, "secB", [("b1", False), ("b2", True), ("b3", False)]),
        (0.88, "secC", [("c1", False), ("c2", True), ("c3", True)]),
    ]

    for y, sec_key, cards in bands:
        label(0.42, y + bh + 0.34, s[sec_key], hsz, DEEP, "bold", ha="left")
        for idx, (ck, accent) in enumerate(cards):
            x = xs[idx]
            bi = box(
                x, y, bw, bh,
                fill=WASH if accent else "white",
                edge=VERMILION if accent else DEEP,
                lw=1.22 if accent else 1.02,
            )
            cx = x + bw / 2
            label(cx, y + 1.15, s[ck], tsz, VERMILION if accent else DEEP, "bold", owner=bi)
            label(cx, y + 0.69, s[ck + "s1"], ssz, INK, owner=bi)
            label(cx, y + 0.26, s[ck + "s2"], ssz, SLATE, owner=bi)
        arrow((xs[0] + bw + 0.07, y + bh / 2), (xs[1] - 0.07, y + bh / 2), DEEP, 1.2)
        arrow((xs[1] + bw + 0.07, y + bh / 2), (xs[2] - 0.07, y + bh / 2), DEEP, 1.2)

    # Vertical handoff arrows on right column (A3 -> B3 -> C3)
    rx = xs[2] + bw / 2
    arrow((rx, 6.25), (rx, 5.56), VERMILION, 1.25)
    label(rx - 0.14, 5.90, s["feedAB"], 7.4 if en else 8.3, VERMILION, ha="right")

    arrow((rx, 3.53), (rx, 2.84), VERMILION, 1.25)
    label(rx - 0.14, 3.18, s["feedBC"], 7.4 if en else 8.3, VERMILION, ha="right")

    label(6.0, 0.30, s["foot"], 7.55 if en else 8.5, MUTE)

    checked = verify_geometry(fig, ax, labels, box_patches, owned, arrow_segments)
    return fig, checked


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lang", choices=("zh", "en"), default="zh")
    parser.add_argument("--dpi", type=int, default=300)
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    suffix = "-en" if args.lang == "en" else ""
    stamp = datetime(2026, 11, 11, tzinfo=timezone.utc)

    artifacts = {}
    label_counts = {}
    for stem, drawer, title in [
        ("figure2-four-tier-architecture-v3", draw_fig2_v3,
         "v3 four-tier process identity, T0/T1 split, initial coface and reversible continuation"),
        ("figure8-reversible-continuation-v3", draw_fig8_v3,
         "v3 semantic-zero request, double-negation homomorphic AST, and step-request slice inversion"),
    ]:
        fig, checked = drawer(args.lang)
        label_counts[stem + suffix] = checked
        for ext in ("svg", "pdf", "png"):
            path = OUT / f"{stem}{suffix}.{ext}"
            meta = {"Title": title}
            if ext == "pdf":
                meta.update({"Creator": "source-process-core v3 figure generator", "CreationDate": stamp})
            elif ext == "svg":
                meta["Date"] = stamp.isoformat()
            fig.savefig(path, dpi=args.dpi if ext == "png" else None, metadata=meta if ext != "png" else None)
            artifacts[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        plt.close(fig)

    record = {
        "schema": "source-process-core-v3-figure-checks/v1",
        "language": args.lang,
        "source_commits": SOURCE_COMMITS,
        "claim_refs": ["C1-C54"],
        "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "verified_labels": label_counts,
        "artifacts": artifacts,
    }
    check_path = OUT / f"third-edition-figure-checks{suffix}.json"
    check_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(f"OK [{args.lang}]: {label_counts}")


if __name__ == "__main__":
    main()
