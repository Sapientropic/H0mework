# 补充材料：完整证明

**源生过程代数与初始余面修订：四层同一性、正合求值核与可逆增量续行**

**作者：高健（Jian Gao）**

本补充给出正文 §6.5、§7.2 末、§8.5、§9、§10.1–§10.3 各结果及 §10.4 预解梳／有限窗口／CPS1 实装的完整自足书面证明。正文已陈述结果并给出证明思路；这里逐条交代对象与定义域、实际输入与量词、关键引理、决定性推导，以及同一对象在后续结果中的直接使用，最后对应到形式证明声明。记号与正文相同，定义、定理与公式编号均指正文。正文 §2–§5、§6.1–§6.4、§7.1–§7.2 前段与 §8.1–§8.4 的证明已在正文与附录 A–C 中完整给出，不再重复。

每节末的“形式对应”列出承载该结果的 Lean 声明；所在源提交与完整路径见正文附录 D.2–D.4，公开复现入口见正文“代码与数据可得性”。

---

本补稿的固定来源：H = `e60a86058abcb74b7f2225f2383c182be8343785`（及 C17/C18/C19–C21 增量 X = `eec031c489`、Z = `453de27572`、AA = `d087a6b289`），AB = `fde5c14df36b6064c87064acd20830d3df0500bb`，AC = `b67aa48c75b3cd7738766ed40093bb3f7c1d7a1a`，AD = `aef0ad2a26199d9fd6da9bc9e7ec1a65636ef63f`，AE = `26b91feb6b507fdc3f43be9c429edb63fb9395ef`，PR = `e05558097256e86b537c019c8ca63cd449d6b2d2`，MF = `c62f3d25c42d4bf2b77ac009b49fc71cfd752f46`，MV2 = `71e94e8261d67cf4849a05eb14ac95aa2f7dcbb9`，MV3 = `9c73a630ce05bea062ec889b188f5105c0afb796`，MV4 = `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`，MV5 = `df421ff600085cbc290a7ae946193961bed7c83b` 及 `7e4da746f300b3796b8b18afb26cb0765c29afcb`（Homework）；H0-S = `a1adcc9f4a06b872c381b8ad49513d6bf1cd621a`（公开源环境配置）。附录 D.1–D.4 给出完整路径缩写及声明入口。

## S0 共同工具

**S0.1 剩余计数与执行。**命题 3.7 给出：每个执行步恰使剩余计数减 $1$；常量没有执行步；从左到右的执行 $\mathrm{exec}_\rho(e):e\to\mathrm{const}(\mathrm{ev}_\rho e)$ 的长度为 $r(e)$；每条执行迹都是推导，故端点求值相等（命题 3.6(1)，下称**可靠性**）。

**S0.2 配对语言保持剩余计数。**附录 A.2 的配对化 $e\mapsto\widetilde e$ 把变量、常量、加法、线性与双线性节点逐一换成配对值上的同类节点，因此 $r(\widetilde e)=r(e)$（对 $e$ 的结构归纳，每个节点贡献的计数不变），且
$$\mathrm{ev}_{(\rho,\varepsilon)}(\widetilde e)=\bigl(\mathrm{ev}_\rho(e),\ \mathrm{eff}_{\rho,\varepsilon}(e)\bigr).\tag{S0.1}$$

**S0.3 迹的关系像与更新读法。**设 $t:e\to e'$ 是环境 $\rho$ 下的执行迹。每个执行步是一枚推导证据，其关系像是两端点之差；整条迹的关系像伸缩为 $e-e'$。由可靠性，$e-e'\in\ker(\mathrm{ev}_\rho)$。给定增量 $\varepsilon$，命题 3.3 的更新等式给出
$$\mathrm{ev}_{\rho+\varepsilon}(e-e')=\mathrm{ev}_\rho(e-e')+\mathrm{eff}_{\rho,\varepsilon}(e-e')=\mathrm{eff}_{\rho,\varepsilon}(e)-\mathrm{eff}_{\rho,\varepsilon}(e').\tag{S0.2}$$
特别地，$e'=\mathrm{const}(c)$ 时 $\mathrm{eff}(e')=0$，更新后的值就是 $\mathrm{eff}_{\rho,\varepsilon}(e)$。

**S0.4 余像与诱导映射。**对 $\mathbb Z$-线性映射 $f:X\to Y$，记 $\mathrm{Res}(f):=X/\ker f$ 为其余像，$\mathrm{can}_f:X\to\mathrm{Res}(f)$ 为商映射；$\mathrm{Res}(f)\cong\mathrm{range}(f)$。若 $f'\circ s=t\circ f$（称 $(s,t)$ 为从 $f$ 到 $f'$ 的态射），则 $s(\ker f)\subseteq\ker f'$，故 $s$ 诱导 $\overline s:\mathrm{Res}(f)\to\mathrm{Res}(f')$，满足 $\overline s\circ\mathrm{can}_f=\mathrm{can}_{f'}\circ s$。$\mathrm{can}_f(x)=0$ 当且仅当 $f(x)=0$。

**S0.5 提升残差。**设 $(s,t)$ 是从 $f:C\to D$ 到 $f':C'\to D'$ 的态射。对 $c\in C$，其**纤维** $\mathrm{Fib}_f(c):=\{x:f(x)=f(c)\}$。$s$ 把 $\mathrm{Fib}_f(c)$ 送入 $\mathrm{Fib}_{f'}(s c)$，并把 $\ker f$ 送入 $\ker f'$。对 $y\in\mathrm{Fib}_{f'}(sc)$，令
$$\mathrm{lift}(c,y):=[\,y-s(c)\,]\in\ker f'\big/s(\ker f).$$

> **引理 S0.5.** $\mathrm{lift}(c,y)=0$ 当且仅当存在 $x\in\mathrm{Fib}_f(c)$ 使 $s(x)=y$。
>
> *证明。*若 $y-s(c)=s(k)$，$k\in\ker f$，取 $x=c+k$，则 $f(x)=f(c)$ 且 $s(x)=y$。反之若 $x\in\mathrm{Fib}_f(c)$ 且 $s(x)=y$，则 $k=x-c\in\ker f$，$y-s(c)=s(k)$。∎

**S0.6 作用词模型。**设 $X$ 为加法群，$(A_\ell)_{\ell\in L}$ 为其上一族加性作用，$\mathrm{rd}:X\to Y$ 为加性读出。对词 $w=\ell_1\cdots\ell_n$（先作用 $\ell_1$）记 $A_w:=A_{\ell_n}\cdots A_{\ell_1}$。令 $K:=\{x:\forall w,\ \mathrm{rd}(A_wx)=0\}$。

> **引理 S0.6.** (i) $K$ 对每个 $A_\ell$ 封闭，因而每个 $A_\ell$ 诱导到 $\mathrm{Mod}:=X/K$；(ii) $[x]=[y]$ 当且仅当 $\forall w,\ \mathrm{rd}(A_wx)=\mathrm{rd}(A_wy)$；(iii) 把 $[x]$ 送到读出族 $(w\mapsto\mathrm{rd}(A_wx))$ 的映射单射，因而 $\mathrm{Mod}$ 与这一族的像（即全部词读出的完成载体）线性同构，同构与各作用交换。
>
> *证明。*(i) 若 $x\in K$，则对任意 $w$，$\mathrm{rd}(A_wA_\ell x)=\mathrm{rd}(A_{\ell w}x)=0$。(ii) 由 $K$ 的定义与线性。(iii) 由 (ii)，交换性在代表元上逐词验证。∎

**S0.7 效应历史方程。**设另有 $W$ 上的加性作用 $(U_\ell)$ 与加性观察 $M:X\to W$。对点 $x$ 与词 $w$，令总残差 $R(w,x):=U_wM(x)-M(A_wx)$；单字母残差 $r(\ell,x):=U_\ell M(x)-M(A_\ell x)$；递归定义
$$\mathrm{Acc}([\,],x)=0,\qquad \mathrm{Acc}(\ell w,x)=U_w\,r(\ell,x)+\mathrm{Acc}(w,A_\ell x).$$

> **引理 S0.7.** $\mathrm{Acc}(w,x)=R(w,x)$；记录 $(\ell_k,x_{k-1},r(\ell_k,x_{k-1}))$ 的历史长度为 $|w|$。
>
> *证明。*对 $w$ 的长度归纳：
> $$\begin{aligned}R(\ell w,x)&=U_wU_\ell M(x)-M(A_wA_\ell x)\\&=U_w\bigl(U_\ell M(x)-M(A_\ell x)\bigr)+\bigl(U_wM(A_\ell x)-M(A_wA_\ell x)\bigr),\end{aligned}$$
> 第一项是 $U_w\,r(\ell,x)$，第二项是 $R(w,A_\ell x)$。∎

**S0.8 联合作用词载体。**设 $I,H,Q$ 为加法群，带三族作用 $(\alpha_\ell),(\eta_\ell),(\mu_\ell)$ 与两个加性读出 $c:I\to H$、$m:I\to Q$。在 $I\times H\times Q$ 上令 $\theta_\ell:=\alpha_\ell\times\eta_\ell\times\mu_\ell$，种子 $\mathrm{seed}(i):=(i,c(i),m(i))$。**完整轨道载体** $\mathcal C$ 是全部 $\theta_w(\mathrm{seed}\,i)$ 张成的子模。

> **引理 S0.8.** (i) $\mathcal C$ 是包含全部种子且对每个 $\theta_\ell$ 封闭的最小子模；(ii) 三个分量投影 $\pi_I,\pi_H,\pi_Q$ 与词作用交换；(iii) 关联元 $\mathrm{inc}(w,i):=\theta_w(\mathrm{seed}\,i)-\mathrm{seed}(\alpha_wi)$ 的 $I$ 分量为零，$H$、$Q$ 分量分别是 $\eta_wc(i)-c(\alpha_wi)$ 与 $\mu_wm(i)-m(\alpha_wi)$。
>
> *证明。*(i) 生成子模由定义包含种子；任一包含种子且封闭的子模包含全部 $\theta_w(\mathrm{seed}\,i)$，故包含其张成。$\mathcal C$ 自身对 $\theta_\ell$ 封闭，因为生成元的像仍是生成元。(ii) $\theta_\ell$ 是分量积。(iii) 由 (ii) 逐分量计算。∎

---

## S1 定理 6.10：无旧承担者的责任出生与付款

**对象与定义域。**固定世界网络 $N$、其上一个带完整整账根登记的权威根、原点当前 $c$，以及读取器：它对根在 $c$ 处的每个发生给出完整的环境—表达式对。记 $o$ 为 $c$ 处的规范发生，$(\rho,e)$ 为读取器在 $o$ 的输出，$B=r(e)$，$\Lambda=\Lambda_{\rho,e}$ 为定义 6.9 的执行债律。

**输入与量词。**定理对上述任意数据成立。不输入旧责任行、已登记的询问、程序表、未来请求表或空覆盖证书；原点支撑在整个计算中固定。

**构造。**

1. *扩世界与词汇。*扩世界 $N[\Lambda]$ 由定义 6.3 给出：支撑为 $\mathrm{Sup}\times\mathrm{Option}(\text{债状态})$。词汇的当前取 $\Lambda$ 的债状态，即对 $(e',t)$，$t:e\to e'$ 为已付执行迹；初始当前为 $(e,\mathrm{id})$。当前 $x$ 的支撑是 $(\mathrm{supp}(o),\mathrm{some}\ x)$。
2. *事件代数。*在当前 $x=(e',t)$ 上，**源选动作**是执行器的输出：若 $e'$ 为常量，取结算；否则取命题 3.7 执行的第一步 $s:e'\to e''$。后继当前 $x^+$ 在结算处为 $x$，在执行步处为 $(e'',t\cdot s)$。编译把结算送到 $\Lambda$ 的恒同输运（定义 6.9 第四项），把执行步送到原生写入。
3. *整账演化。*$\mathrm{whole}(x)$ 把支撑 $(\mathrm{supp}(o),x)$ 上的每一行送到 $(\mathrm{supp}(o),x^+)$ 上：数学行 $\mathrm{row}(x)$（$\Lambda$ 在状态 $x$ 的债行）送到 $\mathrm{row}(x^+)$；每条旧行原样输运。去向与起源互逆。
4. *补丁、余项与证书。*有限补丁只含一条生成行，即数学行；其余全部行由同源输运余项覆盖——余项的发生是“该行属于旧账”的证据，无需旧账有限。补丁折叠回整账演化：$\mathrm{fold}(\mathrm{patch}(x))=\mathrm{whole}(x)$。重构证书由整账演化去向的单射性生成。
5. *编译器、根与过程。*编译器在每个当前发射补丁与整账；整账根由源与编译器组成；权威根与活过程按根登记的标准构造得到。过程在计数 $k$ 的状态记为 $x_k$，满足 $x_0=(e,\mathrm{id})$ 与 $x_{k+1}=x_k^+$。

**关键引理。**

> **引理 S1.1（一步预算）.** $r(x^+)=r(x)-1$（自然数减法）；若 $r(x)=0$，则 $x^+=x$。
>
> *证明。*$r(x)>0$ 时 $e'$ 非常量，源选动作是执行步，由 S0.1 剩余计数减一；$r(x)=0$ 时 $e'$ 为常量，动作是结算，后继不变。∎

> **引理 S1.2（预算与历史）.** 对每个 $k$：$r(x_k)=B-k$，且 $|t_k|+r(x_k)=B$，其中 $t_k$ 为 $x_k$ 的已付迹。
>
> *证明。*对 $k$ 归纳。$k=0$ 时 $t_0$ 为空、$r(x_0)=B$。归纳步：若 $r(x_k)>0$，执行步使迹长加一、计数减一；若 $r(x_k)=0$，状态不变，且 $B-(k+1)=0$。∎

**决定性推导。**

1. *出生。*由构造 2–4，每个当前恰发射一个事件；编译在结算处为恒同输运，在执行步处为原生写入。补丁恰含一条生成行；全部旧行作为余项保留，起源—去向互逆给出重构证书。原支撑不变（支撑第一分量恒为 $\mathrm{supp}(o)$），法则面、旧投影与原点处的类型与值观察作为根读出保留。
2. *付款。*第 $k$ 访问的同债当前是 $\mathrm{row}(x_k)$；去向等式 $\mathrm{whole}(x_k)(\mathrm{row}(x_k))=\mathrm{row}(x_{k+1})$ 沿 $k$ 归纳给出它到 $\mathrm{row}(x_0)$ 的谱系。其预算为 $r(x_k)=B-k$（引理 S1.2）。$k<B$ 时 $r(x_k)>0$，源选动作是执行步 $s$，同债目标是 $\mathrm{row}(x_{k+1})$，预算严格下降（引理 S1.1）；以两侧空历史合成为定义 6.6 的付款宏。目标预算 $\le$ 当前预算，故不回充；续行关系沿预算严格下降，良基。
3. *结算。*$k=B$ 时 $r(x_B)=0$，故 $x_B$ 的表达式为常量 $\mathrm{const}(v)$，局部结算存在；预算为零的当前没有付款宏。已付迹 $t_B:e\to\mathrm{const}(v)$ 的长度为 $B$（引理 S1.2），由可靠性 $v=\mathrm{ev}_\rho(e)$。由引理 S1.1，$x_{B+1}=x_B$；访问计数继续推进，因果深度不同的访问在有限历史中仍被区分。
4. *收据。*由 S0.3，$t_B$ 的关系像是 $e-\mathrm{const}(\mathrm{ev}_\rho e)\in\ker(\mathrm{ev}_\rho)$；对任意增量 $\varepsilon$，它在 $\rho+\varepsilon$ 下的值是 $\mathrm{eff}_{\rho,\varepsilon}(e)$。∎

**直接使用。**命题 6.11 以整树程序为读取器调用本定理；定理 7.7 与 §9 的各个运行都以同一所有者无关安装为数学行，读取其值、计费历史、原材料与关系边界。

**形式对应。**`JS/OwnerFree/Source.lean`（`vocabulary`、`eventAlgebra`、`whole`、`mathEntry`、`destination_math`）；`OwnerFree/Compiler.lean`（`remainder`、`patch`、`patch_fold`、`compiler`、`ledgerRoot`）；`OwnerFree/Completion.lean`（`next_budget`、`budget`、`history_accounting`、`completed_value`、`completed_history_length`、`completed_next_state`）；`OwnerFree/Payment.lean`（`lineage`、`debtCurrent`、`activePayment`、`wellFounded`、`no_refill`、`endpoint_no_paid`）；`OwnerFree/Consumer.lean`（`value_source`、`paid_history`、`relation_boundary`、`updated_inverse_fibre`）。提交 AB。

### S1.3 定理 6.12：Type 完成回执与持续出生

**数据与构造。**固定原程序 $\mathcal P$、递归帧 $\Phi_i$ 和实际动作 $a_i$；$B_i$ 为当前已付状态表达式的剩余计数。回执的定义域是实际起点 $i$，返回的不是命题存在量词，而是依赖和
$$\sum_{d:\mathbb N}\{s:\mathsf{Settlement}(\Phi_{i+d}.\mathrm{state})\mid d\le B_i\ \land\ a_{i+d}=\operatorname{inl}s\}.$$
按 $B_i$ 强递归消去 $a_i$。结算支选 $d=0$ 与实际 $s$；付款支选 $a_i=\operatorname{inr}p$，其中 $p$ 的目标**就是** $\Phi_{i+1}$ 的数学状态。$B_{i+1}=B_i-1<B_i$，故读取该准确起点的回执 $(d',s',\ldots)$，返回 $(d'+1,s',\ldots)$。目标偏移 $(i+1)+d'=i+(d'+1)$ 给出结算事件运输，$d'\le B_i-1$ 给出 $d'+1\le B_i$。这定义了所有起点的 Type 回执，且每一步保留实际分支等式。

**距离恰好为预算。**先对 $h\le B_i$ 归纳。若 $h<B_i$，归纳得到 $B_{i+h}=B_i-h>0$。结算要求当前表达式为常量，预算为零，所以实际动作必须是付款；其目标按实际帧的下一步给出 $B_{i+h+1}=B_i-h-1$。于是
$$B_{i+h}=B_i-h\quad(0\le h\le B_i),\qquad a_{i+h}=\operatorname{inr}p_h\quad(h<B_i).$$
回执的终点是实际结算，故 $B_{i+d}=0$；回执已给出 $d\le B_i$，代入上式得到 $d=B_i$。特别地，零预算起点返回距离零，既不制造付款也不跳过结算。

**完整状态与环境。**每个 $p_h$ 将已付执行迹接上一步真实执行步并保留登记原输入；归纳即给出完整已付前缀及全部中间状态，可靠性给出终点常量值 $\mathrm{ev}_\rho e$。环境读取器的登记相容律保证在固定输入的数学推进处读回同一环境；沿上述付款等式逐步施用该律，即得环境在 $0\le h\le B_i$ 全程保持（证明距离与预算本身无需借用该环境律）。

**原编译与出生。**在终点等式 $a_{i+B_i}=\operatorname{inl}s$ 上展开编译器：结清触发新责任准入，发射的规范直达后继恰为出生帧 $\mathrm{nextBorn}(\Phi_{i+B_i},\mathcal P)$ 的激活呈现，密封运行将其认回第 $i+B_i+1$ 帧，故准入后继与下一帧在完整状态层严格相等。

最后令 $u_0=i$、$v_j=u_j+B_{u_j}$、$u_{j+1}=v_j+1$。每个 $v_j$ 携带上述 `Type` 完成回执且 $v_{j+1}\ge v_j+1$；归纳得 $v_j\ge i+j$，对任意拍号 $t$ 取 $j\ge t$ 即有 $t\le v_j$，故出生序列共尾，且每段 $u_j,\ldots,v_j$ 仍是同一递归运行在这些下标处的节点值。∎

**形式对应。**总值写回环境消费回执中的实际结清（S5.2），共尾停点将每段已付前缀接入同一运行（S5.3）；声明位于 MV2／MV3 的 `ACT/Completion.lean`、`Completion/Prefix.lean` 与 `Completion/Births.lean`（`receipt`, `receipt_distance_exact`, `receipt_next`, `receipt_compiles` 及前缀／覆盖引理）。

---

## S2 定理 8.12 与定理 7.7

### S2.1 定理 8.12：实际动作生成下一问

**对象。**询问帧 $\Phi$：询问状态、读取根编译器的完整原生程序、当前访问登记的原始输入 $(\rho,e)$、为每个原发生给出实际环境的读取器 $E$、因果深度 $k$。帧的数学状态是 $\Lambda_{\rho,e}$ 的已付状态 $(e',t)$；$\rho'$ 为 $E$ 在帧所在发生处的读数，$\varepsilon=\rho'-\rho$。

**(1) 请求的值。**残差请求 $e\ominus e'=e+\mathrm{linear}_{-\mathrm{id}}(e')$ 登记在 $\rho+\varepsilon=\rho'$ 上。按求值定义 $\mathrm{ev}_{\rho'}(e\ominus e')=\mathrm{ev}_{\rho'}(e)-\mathrm{ev}_{\rho'}(e')$。由可靠性 $\mathrm{ev}_\rho(e)=\mathrm{ev}_\rho(e')$，旧值为零。已付迹的关系像为 $e-e'$（S0.3），其在 $\rho'$ 下的值由 (S0.2) 等于 $\mathrm{eff}_{\rho,\varepsilon}(e)-\mathrm{eff}_{\rho,\varepsilon}(e')$，与请求值一致。由 S0.4，这份证书在 $\mathrm{ev}_{\rho'}$ 下的典范残差为零，当且仅当它的值为零，即请求值为零。结算处 $e'=\mathrm{const}(\mathrm{ev}_\rho e)$，请求值是 $\mathrm{eff}_{\rho,\varepsilon}(e)$。

**(2) 必然出生。**$r(e\ominus e')=r(e)+\bigl(r(e')+1\bigr)+1$：加法节点贡献 $1$，线性节点贡献 $1$。此数为正，故初始状态不是常量，执行器的第一个动作是执行步；在出生编译中，这一步编译为责任准入（新责任的出生），而不是任何旧债行的付款。

**(3) 递归帧与运行。**定义帧的**秩** $\mathrm{rk}(\Phi):=(r(e),\,k+1)$，按字典序比较。下一帧由当前动作决定：

- 执行步：同一帧，深度加一，秩为 $(r(e),k+2)$；
- 结算：出生帧，旧状态取当前询问状态，程序取后继程序，登记输入取残差请求，深度归零，秩为 $(r(e)+r(e')+2,\,1)$。

两种情形都严格增大秩。帧序列 $\Phi_n$（$\Phi_{n+1}$ 为 $\Phi_n$ 的下一帧）因此沿字典序严格递增。帧的擦除确定其秩：原始输入由根的观察读回（擦除保留词汇与访问，观察读回登记的原始输入），因果深度由擦除后访问的历史读回。若 $\Phi_m$ 与 $\Phi_n$ 擦除相同而 $m<n$，则秩相同，与严格递增矛盾。故擦除单射。逐支检查后继合法：执行步使用直接回答的后继律，结算使用责任准入的后继律，两者都保持同一根上生成的活法则。现成规范询问运行时在计数 $n$ 的节点就是 $\Phi_n$ 的呈现：对 $n$ 归纳，节点的激活后继等于下一帧。每个帧的查询纤维是单点（它唯一的查询就是该帧的登记输入），故不需要外部的未来请求表。

**(4) 付款与出生分离。**把实际节点限制到固定根的债过程：执行步分支在同一数学行上发射同债付款回执，其整账去向等于联合执行步的账演化（定理 6.10(2) 的读法）；预算为零处没有付款宏（定理 6.10(3)）；结算分支的出生是新的责任准入。∎

**形式对应。**`JS/Native/ResidualRequest.lean`（`expression_eval`、`old_value`、`budget`、`action_is_paid`、`updated_value`、`residual_zero_iff`）；`JS/Native/Restructuring/Inquiry/Continuation/` 的 `Policy.lean`（`rank`、`Before`、`next_progress`、`frames_forward`）、`Inventory.lean`（`rank_eq_of_erasure`、`frames_erase_injective`）、`Occurrence.lean`（`successor_valid`）、`Runtime.lean`（`actual_node`、`macro_next`、`macro_next_preserves`）、`Payment.lean`（`actual_paid_receipt`、`no_paid_of_zero`）。提交 AB。

### S2.2 定理 7.7：登记输入的共享运行与后继供料

**对象。**命题 7.6 的固定数据：旧询问状态（根、访问、审计协议、演算、查询类型、承担者与权威）、完备复内积空间 $\mathcal H$ 上安装的识别、该访问的一步及其处置 $\mathrm{settle}$；另取根在该访问登记的原询问输入 $\iota$：一个投影位置、它在该发生处的激活证明、分类等式与查询类型等式。

**(1) 登记激活。**按 $\mathrm{settle}$ 的输出分支。

*全生成或联合残差支。*命题 7.6 给出程序包与计算询问状态，后者的根是装入计算询问后的根。在该根上新增一条**查询投影律**：投影类型为单点；在发生 $o'$ 处，激活当且仅当 $o'$ 是本次访问的准确发生；载荷类型为计算查询；投影值是以 $\iota$ 的原查询为关联的计算查询。新根 $r_\iota$ 是原根加这一面投影；访问不变。登记输入 $\iota'$ 取这面投影、准确发生的激活证明与分类等式（分类在准确发生处按定义取激活支），查询类型等式按定义成立。询问状态 $s_\iota$ 的根为 $r_\iota$，访问、审计协议与演算沿用旧状态；承担者经查询的关联读出；权威是旧权威沿新增投影面的提升；编译程序对每个查询取回答，回答面是程序包的结果面经投影嵌入。

于是 $s_\iota$ 对 $\iota'$ 的查询编译为回答（按定义）。回答面读出的表达式是程序包的整树程序，故解析器读回 $T$（定理 3.9(3) 与命题 7.6 的树等式）；值为 $\delta_{\tau(T)}$（定理 3.9(1)）；源状态是程序包的已付状态。旧状态对每个原查询 $q$ 的编译面经同一嵌入读回，所读出的仍是旧编译的典范令牌。

*其余四支。*终账支返回根编译器在源发生处的整账编译，三个残差支返回残差对象本身，与命题 7.6 一致。

**(2) 共享运行。**以 $s_\iota$ 为询问状态、以“返回 $\iota'$ 查询的原始输入”的常值函数为读取器，构造数学询问运行时（定理 6.10 的所有者无关安装，加上 §8.5 的运行时）。所有者无关安装的原始输入就是该查询的原始输入；由定理 3.9(3)，其表达式读回 $T$。定理 6.10(3) 给出计费历史长度 $r(\mathrm{prog}_\kappa T)$，由定理 3.9(2) 改写为 $\beta(T)$；完成值 $\mathrm{ev}(\mathrm{prog}_\kappa T)=\delta_{\tau(T)}$。各计数处数学行的整账写回与原材料、各运行偏移处的实际查询、回答与后继，是数学询问运行时在相应计数与偏移的节点等式（定理 8.12(3)）。

**(3) 后继供料。**输入只取活根、访问 $v$、识别与审计协议。在非终账分支，步携带后继 $\mathrm{succ}$ 与等式 $\mathrm{next}(v)=\mathrm{succ}.\mathrm{current}$；令 $v^+:=v.\mathrm{next}(\mathrm{succ})$。识别在 $v^+$ 生成一步并经 $\mathrm{settle}$ 分类，(1)(2) 的构造在 $v^+$ 重新给出供给与运行。终账支只返回整账编译。每个非终账支把前拍的程序包（对齐两支）或残差（三个残差支）与下一运行配对返回。

两拍的整账写回与下一当前：步的定义包含 $\mathrm{whole}(\mathrm{step}(v))=\mathrm{generatedLedgerAt}(v.\mathrm{current})$ 与 $\mathrm{nextCurrent}(\mathrm{step}(v))=\mathrm{generatedNextCurrentAt}(v)$，在 $v^+$ 同样成立。后继的目标发生等于根在 $v^+$ 当前的规范发生（目标发生是编译器为下一当前发射的事件），历史是发生的函数，故两处历史相等。∎

**直接使用。**§9 的联合程序（定理 9.2）以同一识别与同一后继为输入；定理 9.8 的默认运行在每个访问消费 (3) 的下一运行。

**形式对应。**`DJ/Input/{Source,Consumer}.lean`、`DJ/Input/Runtime/{Source,Consumer}.lean`、`DJ/Next/{Source,Consumer}.lean`；低源询问 `JS/OwnerFree/Installation/Math/{Inquiry,Frame}/Source.lean`。提交 AC。

### S2.3 定理 8.14：同次差词、独立收费与源环境方块

**两份实际边界。**取原源族生成的后继包及其精确二阶后继发生；$b_\Psi$ 是原终端执行的配对提升，$b_\mu$ 是原下一编译执行的完整边界。两份 Trace 各自给出原下一历史关系闭包中的成员证明。它们没有按读数选择发生。在后继作用域中，记共同原根点为 $r$，原终端值为 $\Psi$，原写入值为 $\mu=(\Psi,\sigma)$，常值嵌入为 $c$。原编译的两个仿射边界公式是
$$Q^+(b_\Psi)=r-c(\Psi,0),\qquad Q^+(b_\mu)=r-c(\mu).$$
因此 $d=b_\Psi-b_\mu$ 在同一关系闭包中，且线性与加群消去给出
$$Q^+(d)=(r-c(\Psi,0))-(r-c(\mu))=c(\mu-(\Psi,0))=c(0,\sigma).$$
后继作用域的实际环境读取这个常值，于是独立差词查询的求值为 $(0,\sigma)$。这里的历史闭包保存两次原执行的责任来源；更新后读数由后继作用域读取，没有假设更新前的核继续是更新后的核。

**系数程序自己的费用。**把 $d$ 的有限支撑按其原支撑列表写成 $(e_1,a_1),\ldots,(e_k,a_k)$。定义 $N_0(e)=\mathrm{const}(0)$、$N_{n+1}(e)=e+N_n(e)$；对整数 $a$，正系数展开为 $N_a(e)$，负系数 $a=-(n+1)$ 展开为 $-N_{n+1}(e)$（一枚原负号线性节点）。由 $n$ 归纳，
$$\mathrm{ev}_\rho N_n(e)=n\,\mathrm{ev}_\rho e,\qquad r(N_n(e))=n(r(e)+1).$$
故整数展开 $E_a(e)$ 满足
$$\mathrm{ev}_\rho E_a(e)=a\,\mathrm{ev}_\rho e,\qquad r(E_a(e))=|a|(r(e)+1)+\mathbf1_{a<0}.$$
令 $F([])=\mathrm{const}(0)$、$F((e,a)::L)=E_a(e)+F(L)$。列表归纳给出
$$\mathrm{coeff}(d)=F(\mathrm{supportList}(d)),\qquad c(d)=\sum_{(e,a)\in\mathrm{supportList}(d)}\bigl(|a|(r(e)+1)+\mathbf1_{a<0}+1\bigr),$$
以及 $\mathrm{ev}_\rho(\mathrm{coeff}(d))=\mathrm{ev}_\rho d$、$r(\mathrm{coeff}(d))=c(d)$。空差词费用为零；结清后的残差出生仍由其自身正预算保证。定理 6.10 执行该系数程序，生成长 $c(d)$ 的执行迹、全部 $c(d)+1$ 个债务态及自身结果 $(0,\sigma)$，不借用任一母查询的计费回执。

**投影安装与规范直达后继。**将该原输入、结果、执行迹与全部偏移材料登记为根的一条投影律。查询关联认回该登记：已回答编译保留查询结果，残差出生编译在同一根与同一访问处触发新责任准入；准入投影读回刚登记的完整材料，整账编译余项继承全部旧投影，使效应、逆残差、计费、执行迹、整账与规范直达后继出自同一编译路径，精确后继在第 $k+2$ 包供给下一原输入而无需外设包表。

**反馈与完整联合库存。**设 $q$ 为该源族的完整查询，$q'$ 为其已付终点，$h=q\ominus q'$，$b_q:=\delta_q-\delta_{q'}$ 为其形式迹边界，$\theta$ 为动作变量代换绑定。可靠性给出 $\mathrm{ev}_\rho h=0$；代换求值与更新等式给出
$$\mathrm{ev}_\rho(h[\theta])=\mathrm{eff}_{\rho,\,\rho\circ\theta-\rho}(b_q),\qquad
\mathrm{ev}_\rho(h+h[\theta])=\mathrm{eff}_{\rho,\,\rho\circ\theta-\rho}(b_q),$$
其中 $\rho\circ\theta$ 表示在环境 $\rho$ 中求值代换绑定所得的环境。因 $r(h)\ge2$、$r(h+h[\theta])\ge3$，该反馈表达式严格逐步扣款，完成迹长等于自身剩余步数；S0.3 将同一值认回 $b_q$ 的更新典范余像残差，有序混合效应按 S0.7 逐步伸缩给出同一完整结果。联合库存定义为
$$\mathrm{seed}\bigl(H_{\rm old},\mathrm{seed}(\mathrm{seed}(H_{\rm dispatch},\mathrm{exposure}(T_q)),\mathrm{exposure}(T_{h+h[\theta]}))\bigr),$$
左右并列种子嵌入分别保存旧库存、原查询的每条已付事件与反馈的每条新付事件，供外层读取器、内层查询与整账后继统一读取。

**有限入站配置与环境对齐方块。**有限入站配置将计算读取器设为 $\mathrm{Incoming}(\Phi,D)$（$D$ 为查询数据项）：当配对库存为空时直接返回 $D.\mathrm{reader}(o)$；非空时取出库存表达式或关系词系数表达式 $g$，返回
$$\bigl(D.\mathrm{reader}(o).\mathrm{environment},\ D.\mathrm{reader}(o).\mathrm{expression}+g\bigr).$$
两条分支的环境按定义均等于查询读取器环境。默认动作读取器在未配置计算读取器时退回查询读取器，在配置为上述 $\mathrm{Incoming}$ 时由两分支定义相等，从而在每次发生处内生证出动作读取器环境等于查询读取器环境（且 $\mathrm{Incoming}$ 不递归调用旧计算读取器，新项 $g$ 恰加一次；原查询读取器、解码器与库存保存映射均不变）。残差接收器初始预算为 $B_{\mathrm{res}}=r(e)+r(e')+2\ge2$，首步执行后仍余 $B_{\mathrm{res}}-1\ge1$，故严格保持已付性，与环境对齐方块共同闭合写入、出生与下一查询的环境链。∎

**形式对应。**差词与安装源自 PR，联合载体回写源自 MF：`Cx/Profile/Finite/Reader/Difference/{Source,Inquiry/Source,Inquiry/Installation,Inquiry/Input,Inquiry/Receipt,Inquiry/Compiler,Inquiry/Actual,Actual}.lean`、`Profile/Producer{,/Consumer}.lean`、`Mixed/{Effect,Receipt,Consumer}.lean`、`Difference/Actual.lean` 与 `Psi/TerminalTransport.lean`；源环境配置公开补充位于 H0-S 的 `EffectInstalled.lean`、`GeneratedEnvironment.lean`、`FiniteCalculationInstallation.lean`、`FiniteIncoming.lean`、`ContextualFactory.lean`、`ActualNativeEnvironment.lean` 与 `EnvironmentErasure.lean`。

---

## S3 定理 9.2 与定理 9.3

### S3.1 定理 9.2：同一程序承载完整时间、共同历史与作用差

**对象。**活根、时间访问 $v$、识别、审计协议；$\mathrm{step}(v)$ 落在全生成或联合残差支，带后继 $v^+$、历史转移与配对对齐；$T$ 为命题 7.6 的对齐构造子树。

**(1) 时间码。**根的时间访问由三种归纳历史之一给出：自初始当前有限步可达，封闭共尾，或共尾之后可达。对每一种，归纳类型 $\mathrm{Hist}$、$\mathrm{Post}$ 与原可达性证据之间有互逆的编码与解码，按构造子逐一定义并逐一验证。时间码 $c=(\text{当前},\text{历史码})$；$\mathrm{enc}$、$\mathrm{dec}$ 逐分量取上述编码与解码，故互逆，$\mathrm{enc}$ 单射。$\mathrm{act}(c)=(\mathrm{rcpt}(c),\mathrm{nx}(c))$ 的第一分量包含 $c$ 本身，故 $\mathrm{act}$ 单射。后继：时间访问的后继由编译器的下一当前与历史延长给出，编码在延长上逐构造子交换，于是 $\mathrm{enc}(v^+)=\mathrm{nx}(\mathrm{enc}\,v)$。

**(2) 联合程序。**节点类型取（$T$ 的对齐节点，时间码），$T_J$ 为 $T$ 的每个节点配上 $\mathrm{enc}(v)$。结果类型取五元组
$$(\text{效应折叠值},\ \text{收据树},\ \text{两段历史的原始材料},\ \text{两侧评价器输入},\ \text{两侧暴露计划}).$$
构造子 $\kappa_J(n,\vec y)$：第一分量是原依赖效应的单节点折叠 $\mathrm{effectFold}(n_1,[\,y_{i,1}\,])$；第二分量是以 $\mathrm{act}(n_2)$ 为根、以各子结果的收据树为子树的树；后三分量分别取两段历史的原始材料、两侧评价器输入与两侧暴露，与子结果无关。程序 $P=\mathrm{prog}_{\kappa_J}T_J$（定义 3.8）。环境 $\delta$ 把每个节点变量送到其状态点；$\delta'$ 把每个节点 $n$ 送到 $\delta_{n^+}$，$n^+:=(n_1,\mathrm{nx}(n_2))$（无后继时保持 $n_2$）。

*值。*对 $T_J$ 与子列作互递归：
$$\mathrm{ev}_{\delta'}(P)=\delta_{\mathrm{fold}_{\kappa_J}(T_J^+)},$$
其中 $T_J^+$ 是把每个节点换成 $n^+$ 的树——这与定理 3.9(1) 的证明相同，只是基点换成 $n^+$。由 S0.2，配对环境 $(\delta,\delta'-\delta)$ 下 $\widetilde P$ 的值为 $(\mathrm{ev}_\delta P,\ \mathrm{eff}_{\delta,\delta'-\delta}P)$；更新等式（命题 3.3）给出 $\mathrm{eff}_{\delta,\delta'-\delta}(P)=\mathrm{ev}_{\delta'}(P)-\mathrm{ev}_\delta(P)$。合起来，值为 $(\delta_F,\delta_{F'}-\delta_F)$，$F=\mathrm{fold}_{\kappa_J}T_J$，$F'=\mathrm{fold}_{\kappa_J}T_J^+$。

*分量。*对 $T_J$ 归纳：$F$ 的第一分量只依赖各节点的第一分量与子结果的第一分量，恰为 $\mathrm{fold}_{\mathrm{effectFold}}(T)=\tau(T)$；$F$ 的第二分量是 $T_J$ 逐节点取 $\mathrm{act}$ 的像树，其根为 $\mathrm{act}(\mathrm{enc}\,v)$，由 (1) 解码回 $v$。

*计费与付款。*由 S0.2 与定理 3.9(2)，$r(\widetilde P)=r(P)=\beta(T_J)$，而 $T_J$ 与 $T$ 形状相同，故 $\beta(T_J)=\beta(T)$。把定理 6.10 施加于读取器 $o\mapsto(\text{配对环境},\widetilde P)$：已付迹长度为 $\beta(T)$，每个计数 $k<\beta(T)$ 有严格付款，目标预算不回充，续行良基。

*逆读与后继。*在每个计数，安装面保留的表达式是 $P$，解析器读回 $T_J$（定理 3.9(3)），去掉码分量即读回 $T$。读回的根码解码为 $v$，其生成下一当前就是根在 $v$ 处的生成下一当前。更新态射 $(\mathrm{id},\mathrm{ev}_{\delta'})$ 从 $\mathrm{ev}_\delta$ 指向 $\mathrm{ev}_{\delta'}$；源侧取旧迹的关系词，目标纤维元素取旧、新两条迹关系词之和。由引理 S0.5，提升残差为零当且仅当目标纤维元素是旧纤维中某一元素的像；这份残差随结果原样保留。

**(3) 共同历史。**源、目标历史都是同一历史法则在两个发生处的历史；共同历史的事件、支撑、生成元闭包与关系闭包取两侧之并。两条转移把各侧的生成元按定义嵌入。完成映射把一侧生成元闭包中的词 $u$ 送到共同完成中同一个词的类，因此像为零当且仅当 $u$ 属于共同历史的关系闭包。两侧评价器取历史法则在两个发生处的忠实评价，在每个生成元上读回原忠实面的值；关系可靠性两侧等价。完成载体 $\mathrm{Src}$、$\mathrm{Tgt}$ 之积带有由两条转移诱导的作用与观察，构成作用模型；配对与对偶作用由历史的标量配对给出；测量 $\mathrm{Src}\times\mathrm{Tgt}\to\ell^2(\mathcal H\times\mathcal H)$ 与该空间上的线性等距演化组成积分—相干联合作用数据。

**(4) 作用差的逆判据。**记 $\partial_s,\partial_t$ 为两侧的微分（测量），转移满足 $\partial_t\circ\iota=\partial_s$。

*若*存在 $r$ 使 $\partial_s r=\partial_s a_s$ 且 $\iota(r)=a_t$：则 $d=\iota(r)-\iota(a_s)=\iota(r-a_s)$ 属于 $\mathrm{range}\,\iota$，像残差为零；$\partial_t d=\partial_s(r-a_s)=0$，观察残差为零。

*反之*，像残差为零给出 $r_0$ 使 $\iota(r_0)=a_t$，于是 $d=\iota(r_0-a_s)$，观察残差 $\partial_td=\partial_s(r_0-a_s)=0$，故 $r_0\in\mathrm{Fib}_{\partial_s}(a_s)$。

计算程序是三输出表达式：差 $d$，它的测量，及它在余核中的类；其剩余计数为 $25$。定理 6.10 给出 $25$ 步已付迹，每步严格付款，续行良基，整账与下一当前在每个计数保持。

**(5) 规范直达后继。**$\mathrm{step}(v)$ 的目标发生是编译器为下一当前发射的事件，等于 $v^+$ 当前的规范发生，而后者就是 $\mathrm{step}(v^+)$ 的源发生。历史、生成元闭包、关系闭包、暴露与暴露树都是（当前，发生）的函数，故两两相等；目标词沿生成元闭包的相等运到下一源词，底层的词不变。∎

**形式对应。**`Occurrence/Temporal/{Source,Action/Source,Action/Inverse}.lean`；`Occurrence/Temporal/History/Common/{RootSource,Closure,Evaluator/Source,Action/Source}.lean`；`DJ/Joint/{Source,Laws,Consumer,TargetDifference,TargetProgramme,TargetConsumer}.lean`；`DJ/Next/{Material,Pursuit}.lean`。提交 AD。

### S3.2 定理 9.3：全部作用者的共同恢复

**对象。**定理 9.2 的数据与一个计数。源、目标配对展开树分别以全部配对位置为节点，每个节点带暴露 $(M_p,A_p,U_p)$。作用者是树迹中的成员；节点 Hilbert 的指标取树迹的位置（同一载荷重复出现时分别计入）。

**(1) 全词模型。**联合载体取两侧载体之积；字母 $\ell$ 的作用是该作用者的载体作用（源作用者作用于第一分量，目标作用者作用于第二分量，“同时”同时作用两侧的根），根作用者的作用就是原步的源、目标暴露作用。读出 $\mathrm{rd}$ 是粗读口与全部作用者测量的积。引理 S0.6 给出商 $\mathrm{Mod}$、纤维刻画与完成等价；完成载体中两元素相等当且仅当它们对所有后续词的读出相同，这是 S0.6(ii) 在完成一侧的表述。

**(2) 有序效应历史。**取 $W=\mathcal H^{\text{作用者}}$，$U_\ell$ 对被选作用者的分量施加 $U_p$、其余分量不变（“同时”对两侧根分量施加），$M$ 为各作用者的测量。引理 S0.7 给出总残差等于各步残差经其后演化运送之和，历史长度为 $|w|$；单字母情形，总残差就是该作用者的协变效应 $U_pM_p(x)-M_p(A_px)$。

**(3) 节点 Hilbert。**测量 $\mathrm{meas}:\mathrm{Mod}\to\ell^2(\text{位置};\mathcal H)$ 逐位置取该作用者的特征（作用者测量经模型读出）。在 $\ell^2$ 中范数平方是各坐标范数平方之和，故
$$\|\mathrm{meas}(x)\|^2=\sum_p\|M_p(x)\|^2.$$
字母在 $\ell^2$ 上的演化逐坐标取 $U_p$ 或恒等，故是线性等距。节点效应按协变耦合残差的定义逐坐标展开。

**(4) 未来恢复与三面。**

*未来恢复。*设 $x\in\mathrm{Mod}$ 被粗读口与全部未来读口同时送到零。全部未来 $\mathcal H$ 读口为零意味着：对每个前缀界与每个词，每个作用者在词作用后的测量与零点处相同。粗读口为零给出粗读出在每个词作用后与零点相同。于是 $x$ 与 $0$ 在每个词作用后的全部读出相同，由 (1) 得 $x=0$。合成映射单射，$\mathrm{Mod}$ 与其像线性同构，两个方向的复合是恒等。

*三面。*以 $I=\mathrm{Mod}$（作用为模型推进）、$H=$ 全部前缀界上的 $\ell^2$ 族（作用为逐界演化）、$Q=$ 粗模型（作用为粗推进），$c$ 为未来读口，$m$ 为粗限制，作引理 S0.8 的完整轨道载体 $\mathcal C\subseteq I\times H\times Q$。积分面与粗读面就是第一、第三分量。相干面把第二分量（全部前缀界上的族）送到沿前缀界限制的逆极限：逐界限制与演化交换，故这是相容族的完成映射，并与每个字母的演化交换；完成映射的每一界坐标就是第二分量在该界的值，所以相干面为零当且仅当第二分量为零。于是三面同时为零的元素三个分量都为零，即为零：三面联合单射，在像上双逆，并与词作用交换（S0.8(ii)）。

**(5) 有偿恢复。**对点、种子词、历史词与查询词 $q$，所有者无关计算执行的是按查询词生成的程序，其剩余计数由程序预算引理给出为 $|q|+3$；定理 6.10 给出已付迹长度 $|q|+3$，计算值等于下一值（值读回引理）。恢复映射施加于作用后的元素，第一分量按 (4) 的同构读回下一值。配对库存作为新生库存的一部分进入下一次出生，同债不回充（定理 6.10(2)）。∎

**形式对应。**`AW/{Source,Complete/Source,EffectHistory/Equation,EffectHistory/Source}.lean`；`AW/NodeHilbert/{Source,Future/Recovery/Source}.lean`；`AW/NodeHilbert/Future/Wave/{Words/Kernel,Full/Source,Recovery/Source,Recovery/Consumer,Incidence/Consumer}.lean`。提交 AD。

### S3.3 定理 9.11：同一实际材料的六面

**共同材料。**取当帧已付材料 $M$，其中保存发生 $o$、环境 $\rho$、原表达式 $e$、已付终点 $e'$、完整执行迹 $T:e\to e'$、承担者与环境增量 $\varepsilon$。关系词 $\eta=T.\mathrm{relationWords}$ 由执行迹逐步生成而非从末态读数反猜；每步关系像为 $\delta_{e_h}-\delta_{e_{h+1}}$，伸缩求和得
$$\operatorname{rel}_\rho\eta=\sum_{h<|T|}(\delta_{e_h}-\delta_{e_{h+1}})=\delta_e-\delta_{e'}=:b.$$
令 $H$ 为该已付前缀的前缀历史；每条关系见证均产自该前缀，故其和属于关系闭包 $H.\mathrm{relationClosure}$，给出具体关系元素 $\sigma=(b,\,b\in H.\mathrm{relationClosure})$，将 $b$ 投影到历史完备化载体恒得零。

**六面与复形。**代数面保留 $(e,e',e\ominus e')$ 与完整系数配对；组合面保留执行迹 $T$ 及每步暴露位置；拓扑面为前缀历史及其关系闭包；逻辑面为链复合为零条件。令第一微分 $d_1$ 为关系闭包嵌入、第二微分 $d_0$ 为历史完备化投影：
$$C_1\xrightarrow{d_1}C_0\xrightarrow{d_0}\widehat C_0,\qquad d_1(\sigma)=b,\qquad d_0d_1(\sigma)=0.$$
关系面保存 $\sigma$，余链面保存该复形与同一边界；六面由同一个 $M$ 同步生成，发生与原输入读出按定义全等。

**效应与全词恢复。**由 S0.3 有
$$\mathrm{ev}_{\rho+\varepsilon}b=\mathrm{eff}_{\rho,\varepsilon}b=\mathrm{ev}_{\rho+\varepsilon}(e\ominus e').$$
对更新求值核取商，典范余像类为零当且仅当右端为零，由余像与值域的标准同构读回原生值。全词恢复映射以全体基词系数读出为输入，核严格为零，故对任意形式词 $w$ 满足 $\mathrm{rec}(\mathrm{can}(w))=w$，同时组合面保留完整执行迹。

**跨出生保留。**准入的库存保存映射将该已付材料嵌入出生库存并保持同一执行迹 $T$；结清编译给出下一根与当前的完整等式，沿该等式搬运已安装原输入的投影、激活、分类器与载荷四项证明，即得下一查询原输入及随行材料。设出生帧环境为 $\rho_B$，旧登记请求仍锚定原环境 $\rho$（增量变为 $\rho_B-\rho$），故旧 $(\sigma,b,T)$ 原样保留且更新效应为 $\mathrm{eff}_{\rho,\rho_B-\rho}b$；新请求在 $\rho_B$ 下归约则另行生成新关系面 $\sigma_B$，两者在库存中分立保存而不混淆。∎

**形式对应。**MV3 的 `ACT/Receipt/Configured/Writeback/Successor/FourFace/{Source,Consumer,Native/Source,Native/Consumer}.lean` 与 `Operations/Inquiry/Cofinal/Native/{Source,Consumer,Registered/Source,Next/Source,Next/Consumer,Installed/Source,Installed/Consumer,Cofinal/Source,Cofinal/Consumer}.lean`。

---

## S4 定理 9.5–9.7

### S4.1 定理 9.5：通用源程序准入

**对象。**询问帧 $\Phi$ 与源程序 $\mathcal S=(L,\text{读取器},\ldots)$（定义 9.4）。共享运行时把 $\Phi$ 与 $\mathcal S$ 的读取器装成询问状态并回答其唯一查询；$s$ 是这一已回答状态，$o$ 是其当前发生，$\rho'$ 是共享运行时字面下一状态的查询原始输入的环境。

**(1) 材料与值。**材料按定义装配：环境 $\rho$ 与表达式 $e$ 取读取器在 $o$ 的输出，增量 $\varepsilon=\rho'-\rho$，已付状态 $(e',t)$ 取共享运行时在 $o$ 的结果，承担者取 $s$ 对该查询的承担者。登记输入是定义 8.11 的残差请求，环境为 $\rho+(\rho'-\rho)=\rho'$。值与残差由 S2.1(1) 给出。

**(2) 必然准入。**残差请求的初始状态若为结算，其预算为零（执行债律在结算处预算为零）；但残差请求预算为 $r(e)+r(e')+2>0$（S2.1(2)），矛盾。故源的第一个动作是执行步。出生程序由旧状态、查询、登记输入、源包、权威与这一步生成；在 $s$ 的根与访问上，编译程序把唯一查询送到该出生程序在精确时间因果事件上的生成，即责任准入，等式按定义成立。

**(3) 目标。**准入目标携带：字面下一当前等于目标状态的（词汇，根，访问）；整账的第一次写入；每个旧投影在目标上的结果与原结果相等（异构相等）。后继合法性由“主动节点在准入后继下保持生成活法则”的一般准则给出，其前提正是上述字面下一当前与编译等式。

**(4) 新生帧。**新生帧取 $s$ 为旧状态、残差请求为登记输入、读取器环境、深度零，库存为已付迹的全部暴露。其当前状态按定义就是准入目标状态。定理 8.12 的运行时以它为初始帧：初始节点的擦除等于目标呈现的擦除；每一拍的宏后继与活法则保持是 S2.1(3) 的节点等式；不回充与良基是 S2.1(4) 与定理 6.10(2)。

**(5) 下一内容。**由 (S0.1) 与更新等式，已付结果的（旧，效应）之和等于程序在更新环境中的值：
$$\mathrm{ev}_\rho(e)+\mathrm{eff}_{\rho,\varepsilon}(e)=\mathrm{ev}_{\rho+\varepsilon}(e).$$
新生帧在每个发生处的环境由这一值的环境读出给出。宏历史程序满足 $\mathrm{next}(\mathrm{hist}_k)=\mathrm{hist}_{k+1}$；初始帧的活跃环境已是第 $k$ 拍历史的下一值，即第 $k+1$ 拍，新生帧再推进一拍，故为第 $k+2$ 拍。新生库存取旧库存与已付暴露的并列种子，两者都是它的部分（左、右嵌入）。

**(6) 原生移位。**同一阶段的查询帧经原生游标移位得到新的帧；对它施加 (1)–(4)，即得编译、整账首写、后继合法、规范直达后继、每个偏移的运行、不回充与良基；移位后环境就是游标移位的实际环境，效应与逆读由残差请求读出。∎

**形式对应。**`ACT/Programme.lean`、`ACT/Receipt/{Source,Execution,Compiler,Consumer,Runtime}.lean`、`ACT/Target.lean`、`ACT/Receipt/Faces/{Source,Action,Consumer,Native/Source,Native/Consumer}.lean`；下一内容 `AW/NodeHilbert/Future/Wave/Incidence/Environment/{Source,Consumer}.lean`。提交 AD。

### S4.2 定理 9.6：有类型库存越过准入

**对象。**定理 9.5 的设置；物理原始输入 $(\rho_P,e_P)$（变量取物理类型 $\mathrm{Var}_P$）与已付结果，低层原始输入 $(\rho_L,e_L)$（变量取 $L$）与结果。绑定 $\sigma:\mathrm{Var}_P\to\mathrm{Expr}_L$，$\sigma(x)=\mathrm{const}(\rho_P(x))$。

**(1) 绑定保值。**对表达式结构归纳证明 $\mathrm{ev}_{\rho_L}(e[\sigma])=\mathrm{ev}_{\rho_P}(e)$：变量处 $\mathrm{ev}_{\rho_L}(\mathrm{const}\,\rho_P(x))=\rho_P(x)$；常量处两边相同；加法、线性、双线性节点由归纳假设逐项相等。形式词按线性延拓。低层查询 $(\rho_L,e_P[\sigma])$ 的值因此等于物理查询的值。代换迹是物理已付迹沿 $\sigma$ 的代换，起点为 $e_P[\sigma]$，关系边界随之代换；物理已付状态是常量，代换后仍是常量。任何以常量为终点的执行迹，其长度等于起点的剩余计数（命题 3.7(1)），故代换迹的长度为 $r(e_P[\sigma])$。

**(2) 库存登记与读回。**完整材料（两侧原始输入与结果、绑定、两份已写库存与代换迹）作为一面投影安装在帧的基础根上，载荷类型就是材料的类型。通用准入目标的投影律继承旧投影律（定理 9.5(2)），在这面投影处的结果与原结果异构相等；类型相等由同一异构等式给出，沿它把结果转换为材料类型，即得到材料本身。

**(3) 新生库存。**物理库存中的每个事件经 $\sigma$ 代换迁入低层语言，迁入后与低层库存并列成为新生库存；左、右嵌入保证两侧每个事件都在其中。新生帧按定理 9.5 运行；下一库存是新生库存的扩展，坐标映射在 $\mathrm{mathNext}$ 与 $\mathrm{nextBorn}$ 两种动作下都单射，且逐事件读回原事件。

**(4) 逆读。**以新生库存的事件为指标，词族 $W$ 的联合映射 $W\mapsto(\mathrm{index}\mapsto(\mathrm{ev}_\rho,\mathrm{eff}_{\rho,\varepsilon})(W_{\mathrm{index}}))$；实际词族的典范残差为零当且仅当其像为零（S0.4），而像就是结果值。下一拍的逆读是更新态射诱导的映射（S0.4）。共尾的每一拍：关系词在该拍环境下的配对值，读出下一拍场在偏移零处的值；已付迹长度等于原始输入的剩余计数。∎

**形式对应。**`ACT/Receipt/Inventory/{Source,Laws,Installation}.lean`；`Inventory/Born/{Source,Consumer}.lean`；`Inventory/Born/Vector/Fibre/{Source,Consumer}.lean`；`Inventory/Born/Coordinates/Actual/{Source,Query}.lean`；`Coordinates/Actual/Cofinal/{Source,Consumer}.lean`。提交 AE。

### S4.3 定理 9.7：词—状态配对与有偿前缀

**对象。**运行时及其源；状态 $s$ 的旧环境 $\rho_s$ 与增量 $\varepsilon_s=\rho_{\sigma(s)}-\rho_s$。轨道变量的绑定 $\sigma$ 满足两条读回：$\mathrm{ev}_{\rho_s}(\sigma x)=\rho_{\sigma(s)}(x)$ 与 $\mathrm{eff}_{\rho_s,\varepsilon_s}(\sigma x)=\varepsilon_{\sigma(s)}(x)$。

**(1) 配对。**$\langle w,\cdot\rangle$ 在基点 $\delta_s$ 上取阶段库存 $(\mathrm{ev}_{\rho_s}w,\mathrm{eff}_{\rho_s,\varepsilon_s}w)$，由自由模泛性质（命题 2.5）唯一线性延拓；对 $w$ 线性由求值与效应的线性给出。

**(2) 协变与像作用。**在基点上：
$$\langle w[\sigma],\delta_s\rangle=\bigl(\mathrm{ev}_{\rho_s}(w[\sigma]),\ \mathrm{eff}_{\rho_s,\varepsilon_s}(w[\sigma])\bigr)=\bigl(\mathrm{ev}_{\rho_{\sigma(s)}}w,\ \mathrm{eff}_{\rho_{\sigma(s)},\varepsilon_{\sigma(s)}}w\bigr)=\langle w,A\delta_s\rangle,$$
中间一步是代换引理：代换后求值等于在“变量取代换式之值”的环境中求值，效应同理；两条读回把这个环境认作 $\rho_{\sigma(s)}$ 与 $\varepsilon_{\sigma(s)}$。两边对 $\mathbb Z[S]$ 线性，故整个载体上 $\langle\sigma^*(\cdot),\cdot\rangle=\langle\cdot,A(\cdot)\rangle$。这说明 $(\sigma^*,A^*)$ 是从配对到自身的态射，由 S0.4 诱导余像上的作用；读出公式在 $\mathrm{can}[e]$ 上由定义给出。

**(3) 迭代即时间。**对 $n$ 归纳：$n=0$ 平凡；归纳步用 (2) 的基点等式于第 $d$ 拍，再对 $d+1$ 用归纳假设。$\mathrm{act}^n[e]=[e[\sigma]^n]$ 由诱导映射与典范映射交换得到。

**(4) 前缀计费。**第 $i$ 个前缀执行 $\widetilde{e[\sigma]^i}$，由 S0.1 与 S0.2，迹长 $r(e[\sigma]^i)$；求和得 $\Sigma_n$。批量查询把 $n+1$ 项装入向量值语言：每一项经一个坐标嵌入节点与一个累加节点进入，剩余计数为各项之和加 $2(n+1)$；执行长度等于剩余计数（命题 3.7(2)）。定理 6.10 给出逐步严格付款与同债谱系。

**(5) 调用恢复。**调用帧在计数 $c+i$ 处的实际查询材料给出该处环境；所需快照的旧值与增量逐项取自这些环境（增量为相邻两处之差）。由此组装的批量环境与轨道批量环境按定义逐坐标相等，故两个查询的结果值相等；每个调用的已付迹长度等于其剩余计数（定理 6.10(3)），求和得调用计费等于调用成本。∎

**形式对应。**`Operations/Inquiry/Context/Native/Pairing/{Source,Orbit/Source,Orbit/Action,Orbit/Iteration,Orbit/Iteration/Batch,Orbit/Iteration/Current}.lean`；调用与历史 `…/Batch/Calls/{Source,Consumer,History/Source,History/Consumer}.lean`（完整前缀见正文附录 D.2）。提交 AE。

### S4.4 定理 9.9：完整恢复、双库存与迹位置保序单射

**全词先行恢复。**记密封运行的状态集为 $S$，自由载体为 $\mathcal F=\mathbb Z[S]$，全词模型商映射为 $q$。因全词读出包含空作用词上的整词读出，故对每个 $w\in\mathcal F$ 有 $\mathrm{rec}(q(w))=w$。令 $O$ 在基点上读取登记帧并线性延拓为 $O(\delta_s)=\delta_{\mathrm{readFrame}(s)}$。第 $i$ 拍状态储存递归下标，由节点等式与擦除单射知 $\mathrm{readFrame}(s_i)=\Phi_i$；结合模型点作用 $Aq(\delta_{s_i})=q(\delta_{s_{i+1}})$ 即得
$$O\mathrm{rec}(q(\delta_{s_i}))=\delta_{\Phi_i},\qquad O\mathrm{rec}(Aq(\delta_{s_i}))=\delta_{\Phi_{i+1}}.$$
进一步投影帧内的标量与配对库存即读回双库存单点词；若第 $i,j$ 拍模型点相等，先经 $\mathrm{rec}$ 恢复相同原状态再由严格递增帧秩推出 $i=j$，既往已付态不会因先裁剪执行帧而丢失。

**完整库存交接。**当次查询的原输入、求值、执行迹、效应、逆残差、解码器、整账与规范直达后继均由当次发生的已安装读取器统一给出（未配置计算读取器时取登记输入，已配置时取实际计算读取器）；库存程序将整份材料送入通用准入并保持双库存更新映射，`Type` 完成回执在距离加一处精确读回出生完整帧。

**迹位置保序单射。**记 $H_Q$ 为当次查询的源写入暴露，$H_o$ 为旧已写库存，$H_m$ 为迁入已写库存，$H_P$ 为物理已写库存。合并已写库存与出生库存定义为
$$H_C=\mathrm{seed}(\mathrm{seed}(H_o,H_Q),H_m),\qquad H_B=\mathrm{seed}(H_P,H_C).$$
沿内层右嵌入、中层左嵌入、外层右嵌入三道并列种子接缝逐层复合读回等式，由于每道种子接缝占 $1$ 个位置（共偏移 $3$），立得
$$H_B.\mathrm{trace}[\iota(j)]=H_Q.\mathrm{trace}[j],\qquad \iota(j)=j+|H_o|+|H_P|+3.$$
在自然数上消去公共偏移 $|H_o|+|H_P|+3$ 即证 $\iota$ 单射且严格递增（$i<j\Rightarrow\iota(i)<\iota(j)$），不同位置上的同值事件严格分槽保存。

**新旧两处读取位置分明。**结清准入在旧初访处的继承读口保留原安装材料，在新当前处的后继读口给出下一编译查询，各自沿对应的完整当前等式搬运回原读取器，绝不将两次不同访问混为同一查询。∎

**形式对应。**MV2／MV3 的 `Operations/Inquiry/Context/Native/Frame/{Source,Stock,Stock/Return,Stock/Coordinates,Stock/Birth}.lean`（`actual_full_source_return`, `intoBorn_injective`, `intoBorn_read`, `intoBorn_strictMono` 等声明）。

---

## S5 实际总值、完整续跑与原整词作用

### S5.1 定理 9.8：默认运行执行源自产请求与子树

**(1) 源自产请求。**取定理 9.2 的联合程序根与已安装读取器，作所有者无关安装的源询问帧，种子取登记表达式生成元的零展开。默认运行时的源程序以“本发生的原始请求”为读取器：在发生 $o$ 处，读取器返回为 $o$ 生成的请求表达式与环境。把定理 9.5 施加于这一源程序：查询原始输入就是安装面读出的请求（按定义）；结果值等于请求的执行值（定理 6.10 的完成值，连同 $\mathrm{ev}$ 的可靠性）；已付迹长度等于登记输入的剩余计数（定理 6.10(3)）；新生配对库存按定理 9.5(5) 由既往已写与本次已付两部分组成；每个计数的实际查询、回答与后继是运行时的节点等式。账根相同是构造上的恒等。分支版本的核心表达式与关系表达式各自成为二元批量的一个坐标，批量执行的迹与代换迹进入初始库存。

**(2) 子树进入主表达式。**主表达式是三项之和：原查询表达式、旧码处子树、新码处子树，各项经坐标嵌入进入输出类型。某码处的子树：若识别在该码的访问没有后继，子树为零常量；否则为该码处子程序原始输入的嵌入。于是
$$\mathrm{ev}(\text{主})=\bigl(\mathrm{ev}(\text{查询}),\ \mathrm{ch}(c_{\mathrm{old}})+\mathrm{ch}(c_{\mathrm{next}})\bigr),$$
其中子树值的第一分量为零。剩余计数逐项相加，再加两次加法与一次线性嵌入，共三个组合节点：$r(\text{主})=r(\text{查询})+c_{\mathrm{old}}+c_{\mathrm{next}}+3$。已付迹长度：所有者无关安装的迹长等于剩余计数，查询自身的已付迹长度等于 $r(\text{查询})$，代入即得。两棵子树的执行长度等于各自的剩余计数（命题 3.7(2)）。旧库存与新付事件的保留由并列种子的嵌入给出；旧、新作用者分量之和是本次源操作的状态点，由完整作用者载体的读出读回。

**(3) 子树环境。**在被供给的发生处，子树环境由该环境中原绑定的读出定义；新生帧的环境取实际更新后的环境（定理 9.5(5)），子树环境随之由同一绑定读出。标量与配对库存的保留与 (2) 同理；运行时初始节点与每拍输入是运行时的定义式。∎

**形式对应。**`ACT/Inventory/Pair/Residual/Joint/Past/NextObservation/Request/Acted/{Source,Consumer}.lean`；`DJ/{Joint,Branch}/Primary/{Source,Consumer}.lean`；`DJ/Branch/JointQuery/Actor/{Source,Embedding,Action/Source,Operation/Source,Operation/Consumer}.lean` 与 `Actor/Operation/Query/Inventory/{Language,Source,Consumer,Action/Source,Action/Consumer,Live/Source,Live/Consumer}.lean`；默认后继 `DJ/Next/{Source,Consumer}.lean`。提交 AE。

### S5.2 定理 8.15：真实总值、逐回执解码器重生与出生写回

**同次动作材料。**动作读取器在发生 $o$ 处给出原输入 $(\rho,e)$，结清结果给出已付终点 $\mathrm{const}(p)$、完整执行迹与旧已付值 $p=\mathrm{ev}_\rho e$。动作材料 $M$ 保存上述数据与后继环境增量 $\varepsilon$；新环境 $\rho+\varepsilon$ 上的残差请求 $N(M)=e\ominus\mathrm{const}(p)$ 满足
$$\mathrm{ev}_{\rho+\varepsilon}N(M)=\mathrm{ev}_{\rho+\varepsilon}e-p=:n,\qquad p+n=\mathrm{ev}_{\rho+\varepsilon}e.$$
第一式展开减法定义，第二式仅用阿贝尔群消去：$p$ 与 $n$ 分别为旧查询已付值与当次残差完成值，无需外部预供更新后目标总值。

**结清支路写回总值。**保持低层程序的源、查询与计算读取器、效应／逆读、整账及双库存保存映射不变，仅将下一环境读取器设为 $\mathrm{write}(p+\nu(o'))$，其中 $\nu$ 在中间扣款支路上取 $0$、在结清支路上取结算完成值。沿原帧运行时，定理 6.12 `Type` 回执选定的结清事件 $o_B$ 满足 $\nu(o_B)=n$，展开结清编译的出生环境字段即得
$$\mathrm{env}(\mathrm{nextBorn})=\mathrm{write}(p+\nu(o_B))=\mathrm{write}(p+n).$$
中间扣款支路仅推进数学已付态而不触发出生环境写回；在 S2.3 的有限入站源族中，环境对齐方块还将查询读取器环境与该动作材料环境严格对齐。

**跨包解码器再生。**设第 $j$ 包为 $P_j$，回执给出出生帧 $B_j$，下一包 $P_{j+1}$ 由 $B_j$ 的完整材料与登记表达式生成新种子。下一包配置重读其自身动作结果 $p_{j+1}$ 与残差完成函数 $\nu_{j+1}$，安装新鲜解码器 $\mathrm{write}_{j+1}(p_{j+1}+\nu_{j+1})$，对 $P_{j+1}$ 重复上段推导即得
$$\rho_{B_{j+1}}=\mathrm{write}_{j+1}(p_{j+1}+n_{j+1}),$$
全程不混用前包旧值 $p_j$，对 $j$ 归纳即证每份回执重生独立解码器并保留双库存。∎

**常值零效应正控制。**取常值配置查询 $\mathrm{const}(1,0)$：旧已付值 $p=(1,0)$，当步更新效应 $n=0$，出生环境准确写回 $(1,0)$，下一配对代仍保非零已付值 $((1,0),(0,0))$，验证原生效应 $n$ 不能替代完整总值 $p+n$。

**形式对应。**MV3 的 `ACT/Receipt/Configured/Writeback/{Source,Consumer}.lean` 与 `Writeback/Successor/{Source,Consumer}.lean`（`old_paid_value`, `native_value`, `updated_total`, `born_environment`, `successorPacket`, `second_decoder`, `second_writeback`），以及预解梳实装 `Feedback/ClozelOriginalK{ConfiguredPairWriteback,SourceSuccessor}.lean`。

### S5.3 定理 9.10：同一运行的共尾准入停点与完整中间段覆盖

**运行时的双阶段表示。**运行阶段为依赖和：准入态（admission）保存包等级、数据项、配置与语言；延续态（continuation）额外携带当前已付询问帧。单步推进在准入态将当包准入送入延续态；在延续态的中间扣款分支保持包等级与材料而推进数学帧，在结清分支取出生帧接入下一包种子并返回准入态，全程为单一源生成函数而无需外部日程表。

**到达下一准入的 `Type` 步距。**对任意拍号 $t$ 按当前阶段分情况：若已在准入态，返回距离 $0$；若在延续态，调用 S1.3 的递归帧 `Type` 回执取得精确剩余扣款数 $B$ 与全部 $B$ 拍已付前缀，再加结清转准入的 $1$ 拍得总步距 $B+1$。以（库存规模，因果深度 $+1$）为字典序秩：准入／结清严格增大库存，中间扣款保持库存而严格增大深度，故源擦除在全部运行拍上为单射。

**共尾停点与段覆盖。**令 $d(t)$ 为上述步距，递推定义 $t_0=d(0)$、$\ell_j=1+d(t_j+1)$、$t_{j+1}=t_j+\ell_j$。则两端点均处于准入态，完整保留中间拍 $t_j+h$（$0\le h\le\ell_j$）的全部询问帧，且满足
$$t_j+\ell_j=t_{j+1},\qquad t_{j+1}\ge t_j+1,\qquad t_j\ge j.$$
对任意拍号 $t$ 取 $j=t$ 即有 $t\le t_j$（严格共尾），取首个大于 $t$ 的停点即由前一段覆盖 $t$；包等级 $j$ 仅在准入转换处加 $1$，绝不冒充底层运行拍号。

**完整场词推进。**记第 $t$ 拍的完整场词为 $W_t$，单拍状态点作用满足 $A_{\mathcal R}W_t=W_{t+1}$；对 $h$ 归纳得 $A_{\mathcal R}^hW_t=W_{t+h}$，代入 $h=\ell_j$ 即证 $A_{\mathcal R}^{\ell_j}W_{t_j}=W_{t_{j+1}}$，自由载体上的全词、共尾点单射与词—状态对偶沿同一跨度严格交换。∎

**形式对应。**MV3 的 `F/Admission.lean`、`F/SourceFamily/{Runtime,Activation/Source,Activation/Stage,Activation/Admissions}.lean`（前缀 `F/` 见附录 D.3）及 `Operations/Inquiry/Cofinal/{Source,Consumer}.lean`（`source_span`, `strictMono`, `cofinal`, `cover`）。

### S5.4 定理 9.12：依值直和整词源作用与最大未来不可见核模型

**逐包语言与接收器配对方块。**由 S3.3 与 S5.3 取第 $j$ 个停点的已安装原输入与包等式，其完整形式词模 $\mathcal W_j$ 的成对读出为
$$d_j(u)=\bigl(\mathrm{ev}_{\rho_j}u,\mathrm{eff}_{\rho_j,\varepsilon_j}u\bigr).$$
对 $\mathcal W_j$ 中表达式逐节点作配对提升并沿下一包语言等式搬运，定义逐步源词作用 $S_j:\mathcal W_j\to\mathcal W_{j+1}$；由附录 A.2 配对求值恒等式线性延拓即得接收器方块
$$\mathrm{ev}_{\rho_{j+1}^{\rm receiver}}(S_ju)=d_j(u),$$
无需假定不同包等级环境相等 $\rho_{j+1}=\rho_j$。

**有限支撑直和与库存保持。**标量关系库存成员经配对提升进入出生关系库存，配对库存与已付前缀在扣款与出生两步下均保持入库。在有限支撑直和 $\mathcal W=\bigoplus_j\mathcal W_j$ 上定义
$$S(w)=\sum_{j\in\mathrm{supp}(w)}\mathrm{in}_{j+1}(S_jw_j),\qquad D_j(w)=d_j(w_j).$$
下标平移 $j\mapsto j+1$ 保持有限支撑，故 $S$ 良定且 $\mathbb Z$-线性；全体站点读出 $D_j$ 在有限前缀 $0,\dots,b$ 上沿删末位限制生成联合完备化载体。

**全未来词与最大不可见不变子模。**在单字母集 $\{*\}$（字母作用取 $S$，$S_{[]}={\rm id},\ S_{a*}=S\circ S_a$）下定义
$$K_{\rm fut}=\bigcap_{a\in\{*\}^{<\omega}}\bigcap_j\ker(D_j\circ S_a).$$
对任意 $w\in K_{\rm fut}$ 与任意 $a,j$，$D_j(S_a(Sw))=D_j(S_{*a}w)=0$，故 $S(K_{\rm fut})\subseteq K_{\rm fut}$，商映射 $q_{\rm fut}:\mathcal W\to\mathsf{M}_{\rm fut}:=\mathcal W/K_{\rm fut}$ 唯一诱导模型作用 $\bar S$ 与读出 $\bar D_{j,a}$：
$$\bar S q_{\rm fut}=q_{\rm fut}S,\qquad \bar D_{j,a}q_{\rm fut}=D_jS_a.$$
两元素同商类充要于经一切允许未来词在一切站点的读出全等。若子模 $L\subseteq\bigcap_j\ker D_j$ 满足 $S(L)\subseteq L$，对词长归纳得 $S_a(L)\subseteq L\subseteq\bigcap_j\ker D_j$，即 $L\subseteq K_{\rm fut}$，证得最大性；取空词 $a=[\,]$ 即得 $K_{\rm fut}\subseteq\bigcap_j\ker D_j$，自然投影回当前联合完备化并与 $\bar S$ 交换。∎

**形式对应。**MV3 的 `Operations/Inquiry/Cofinal/Native/Installed/Cofinal/Tower/{Source,Consumer,Action/Source,Action/Consumer,Action/Common/Source,Action/Common/Consumer}.lean` 与 `Operations/Observed/Words/{Kernel,Model}.lean`。

### S5.5 §10.4：预解梳完整 $R$ 计算、总值反馈与 Mellin 定价恒等式

**发射器前完整计算与安装。**右半平面非平凡零点观察给出 $\zeta$（满足 $\Re\zeta>1/2$，故预解参数 $z=\zeta/2$ 满足 $\Re z>1/4$）、精确 $\Xi$ 阶数 $m$ 与初始梳向量 $q_0$。定义 $e_0=x,\ e_{k+1}=\mathrm{linear}_R(e_k)$，对 $k$ 归纳有
$$\mathrm{ev}_\rho e_k=R^k(\rho(x)),\qquad r(e_k)=k+1.$$
在 $\rho(x)=q_0$ 下执行生成实算值 $v=R^m q_0$ 与长 $m+1$ 的完整执行迹；封闭门面在发射器前将该结果律安装到同一发生，同时由投影余项完整保留底层整账与物理后继。

**由实算值内生生成环境增量。**令 $\rho^+=\mathrm{constEnv}(v)$、环境增量 $\delta=\rho^+-\rho$，已付材料上的残差请求求值为
$$\mathrm{ev}_{\rho+\delta}(e_m\ominus\mathrm{const}(v))=R^m v-v,$$
经 S1.3 `Type` 回执与 S5.2 加法解码器 $(a,b)\mapsto a+b$ 精确写回出生环境 $\mathrm{constEnv}(v+(R^m v-v))=\mathrm{constEnv}(R^m v)$。

**完整 $R_z$ 先执行后正交分解与 Mellin 定价。**记环境预解算子为 $R_z$、闭子空间正交投影为 $P$。在配对输入 $(v,0)$ 上，三步程序依次执行变量绑定 $\to(v,0)$、完整线性预解 $\to(u,0)=(R_z v,0)$、正交分裂 $\to(p,r)=(Pu,(1-P)u)$（共 $3$ 步原语扣款，执行迹完整保留中间态 $(u,0)$ 及恒等分解 $p+r=u$）。在 $\Re z>1/4,\ 1/4<\Re w<1/2$ 域内，环境完备化 Mellin 泛函 $L_w$ 与预解算子 Bochner 积分可交换，伸缩律将核化为指数衰减积分 $\Re(1/2-z-w)<0$：
$$L_w(R_zv)=-\int_0^\infty e^{(1/2-z-w)h}\,dh\ L_w(v)=-\frac{L_w(v)}{z+w-1/2}.$$
由 $\Gamma_{\mathbb R}(2w)\ne0$ 消去归一化因子得物理热读出 $H_w(v)=2L_w(v)$ 与余项读出 $M_w(r)=L_w(r)$，对 $p+r=R_z v$ 作用 $2L_w$ 立得完整定价恒等式
$$H_w(p)+2M_w(r)=-\frac{H_w(v)}{z+w-1/2}.$$
下一包从物理出生值 $p$ 继续生成 $(PR_z p,(1-P)R_z p)$（即便当步残差为零，S5.2 仍保完整旧已付值写回并逐包重生解码器）。∎

**形式对应。**计算面源自 MV2，总值反馈与完整 $R$ 消费者源自 MV3：`NoIslandNoMagic/CanonicalRiemann/GeneralizedDual/CoPoissonEnergy/Muntz/Cokernel/CenteredGram/JointAction/Runtime/` 下的 `Material/Calculation/ClozelOriginalKCombSourceCalculation.lean`、`Root/ClozelPairedOmegaEffectRowRoot.lean`、`Facade/ClozelPairedOmegaEffectRuntimeFacade.lean` 与 `Feedback/ClozelOriginalK{ReceiptSource,ReceiptFeedback,PhysicalPricing,PhysicalAction,PhysicalFeedback,RegisteredSourceFeed,ConfiguredPairWriteback,SourceSuccessor}.lean`。

### S5.6 §10.4：37 原语全原子连续平滑体系与能量储备分派

**原输入与 `Type 0` 身体生成。**固定 37 项原语输入 $I$，源内有限程序依序执行翻译、修复、资源响应与化学交换；依值类型 $\mathsf{InputBodyAt}(I)$ 对全部结果分支作穷尽构造性消元，固定源实例的正向完成证明选定成功分支，由原值字段内生生成包含 DNA、完整编码、蛋白质、原子核与电子场、资源账户、氨甲酰磷酸反应位点焦点、开立责任、完整库存与已写历史的 `Type 0` 身体 $B:\mathsf{InputBodyAt}(I)$。在原生当前 $(\mathrm{phase},I,B)$ 上，单拍更新写入并验证规范直达后继身体恒等
$$\mathrm{next}(\mathrm{phase},I,B)=(\mathrm{phase}+1,I,\mathrm{bodyNext}_I(B)),$$
对拍号归纳知运行身体恒为 $\mathrm{bodyNext}_I$ 的迭代结果，交付层读出与根当前、发射写入及目标后继逐字段全等。

**全光滑性与二进时间精化。**在步后态上，电子占据态矩阵与原子核构型执行半步 Cayley 更新，完整核—电子能量涵盖全部核排斥项、电子迹与二体四次库仑项；高斯核积分的四类局域／存储分项允许积分号下求导，分离核构型处核间距严格非零，从而由原场直接给出全光滑性而无需外供未来力场。记候选步的能量差价格为 $\pi(t)$：当 $t\to 0$ 时半步占据态趋回初态、力场连续且核位移趋零（保持分离构型），能量连续性给出
$$\pi(0)=0,\qquad \lim_{t\to0}\pi(t)=0.$$
二进精化在保持场、库存与账户不变的同时令步长折半 $t_k=t_0\,2^{-k}$，充分大的 $k$ 必进入就绪态。

**按能量储备分派的有限 `Type` 处分与逐拍兑现。**当储备 $A>0$ 时，由 $\lim_{t\to 0}\pi(t)=0$ 知存在就绪且 $\pi(t_k)<A$ 的有限 $k$；`Nat.find` 内生选出首个满足就绪且 $\pi(t_{k_*})\le A$ 的指标 $k_*$，返回携带 $k_*$、步后态与更新账本的已付处分（所有 $k<k_*$ 均为未付精化步，保持总电荷／电子数与总能量 $E+A$ 严格守恒）。当储备 $A=0$ 时，先取首个就绪指标 $k_*$，再按 $\pi(t_{k_*})\le 0$ 或 $>0$ 分派已付处分或携带正价格见证的显式能量短缺处分，绝不靠零储备伪造付款。对步数归纳，精化步身体序列与密封运行时的规范直达后继异构相等，从而在每个实际演化拍上连续运行同一权威根。∎

**形式对应。**MV3 的 `NoIslandNoMagic/Consciousness/Immortality/Embodied/Molecule/CPS1Personalized2025/`（`Source/NativeRegistration/{Source,Programme,Registration,Positive,BodyPositive}.lean`, `Root/{NativeCurrent,Base,Installation}.lean`, `Delivery/Runtime.lean`, `Runtime/{RegisteredBody,BodyPaid,BodyFunction}.lean`）与 `Lean/DomainProofs/CPS1ResourceExecution/CPS1MaterialIncidence/`（`NativeRoot{FromInput,Data,MaterialData,NextLaw}.lean`, `Native{RawRegularity,FullSmooth,BodyPaidSource,BodyFunction}.lean`）。

---

## S6 第三版可逆增量续行与跨周期方法完整证明（定理 10.1–10.6，C46–C54）

### S6.1 定理 10.1（C46）：全环境语义零同余与规范后继可写请求

**对象与量词。**固定任意类别集合 $\mathcal{K}$、加法阿贝尔群族 $W$、变量族 $X$、逐级源程序族 `Factory`、初始询问帧 $\Phi_0$、程序配置 $\mathrm{cfg}$、语言等式 $L_{\mathrm{cfg}}=X$ 及任意实际共尾包序数 $j\in\mathbb{N}$。对任意值群载体 $V$，定义**全环境语义零子模**为
$$\mathcal{Z}_{\mathrm{sem}}(V):=\bigl\{w\in\mathrm{Fm}_{\mathbb{Z}}(\kappa)\ \big|\ \forall\rho\in\mathrm{Env}(V,X),\ \mathrm{ev}_\rho(w)=0\bigr\}.\tag{S6.1}$$
由求值映射对词的 $\mathbb{Z}$-线性性，$0\in\mathcal{Z}_{\mathrm{sem}}$ 且对加减与整数倍封闭，故 $\mathcal{Z}_{\mathrm{sem}}$ 为子模。

**关键引理与决定性推导。**

> **引理 S6.1（全库存消失与配对提升封闭）。** 若 $w\in\mathcal{Z}_{\mathrm{sem}}(V)$，则：(i) 对任意旧环境 $\rho$ 与增量环境 $\varepsilon$，更新库存 $U_{\rho,\varepsilon}(w)=(\mathrm{ev}_\rho(w),\mathrm{eff}_{\rho,\varepsilon}(w))=(0,0)$；(ii) 配对提升词满足 $\widetilde w\in\mathcal{Z}_{\mathrm{sem}}(V\times V)$；(iii) 沿任意包等式或变量语言等式的线性搬运保持 $\mathcal{Z}_{\mathrm{sem}}$ 成员性。
>
> *证明。*(i) 由命题 3.3 更新等式 $\mathrm{ev}_{\rho+\varepsilon}(w)=\mathrm{ev}_\rho(w)+\mathrm{eff}_{\rho,\varepsilon}(w)$，因 $w\in\mathcal{Z}_{\mathrm{sem}}$ 故 $\mathrm{ev}_{\rho+\varepsilon}(w)=0$ 且 $\mathrm{ev}_\rho(w)=0$，消去得 $\mathrm{eff}_{\rho,\varepsilon}(w)=0$。(ii) 对任意配对环境 $\widetilde\rho\in\mathrm{Env}(V\times V,X)$，令 $\rho(x):=\pi_1(\widetilde\rho(x)),\ \varepsilon(x):=\pi_2(\widetilde\rho(x))$，按点外延有 $\widetilde\rho=(\rho,\varepsilon)$；由 (S0.1) 线性延拓 $\mathrm{ev}_{(\rho,\varepsilon)}(\widetilde w)=U_{\rho,\varepsilon}(w)=(0,0)$。(iii) 对等式作 `cases` 归纳归约为恒等线性同构。∎

**(1) 残差单点词与迹边界在 $\mathsf{M}_{\mathrm{fut}}$ 中严格同余。**对任意表达式 $e,e'\in\mathrm{Expr}(V,X,\kappa)$ 及任意环境 $\rho$，直接展开求值得
$$\mathrm{ev}_\rho\bigl(\delta_{e\ominus e'}-(\delta_e-\delta_{e'})\bigr)=\bigl(\mathrm{ev}_\rho(e)-\mathrm{ev}_\rho(e')\bigr)-\bigl(\mathrm{ev}_\rho(e)-\mathrm{ev}_\rho(e')\bigr)=0,\tag{S6.2}$$
即 $z_0:=\delta_{e_j\ominus e'_j}-(\delta_{e_j}-\delta_{e'_j})\in\mathcal{Z}_{\mathrm{sem}}$。在 S5.4 的直和共同载体 $\mathcal{W}=\bigoplus_m\mathcal{W}_m$ 中，单步源作用 $S_m:\mathcal{W}_m\to\mathcal{W}_{m+1}$ 由配对提升 `liftMap` 复合包／语言线性搬运定义，故由引理 S6.1(ii)(iii) 知 $S_m(\mathcal{Z}_{\mathrm{sem}})\subseteq\mathcal{Z}_{\mathrm{sem}}$。对允许未来动作词 $a\in\{\ast\}^{<\omega}$ 的长度归纳：$a=[\,]$ 时 $\iota_j(z_0)$ 在站点 $j$ 处属 $\mathcal{Z}_{\mathrm{sem}}$、其余站点为零；若 $S_a(\iota_j(z_0))$ 在每个站点 $m$ 的分量均属 $\mathcal{Z}_{\mathrm{sem}}$，则再作用一步 $S$ 后各站点分量仍属 $\mathcal{Z}_{\mathrm{sem}}$，再由引理 S6.1(i) 知每个站点读出 $D_m(S_a(\iota_j(z_0)))=U_{\rho_m,\varepsilon_m}(\cdot)=(0,0)$。这证明 $\iota_j(z_0)\in K_{\mathrm{fut}}$，两词在 $\mathsf{M}_{\mathrm{fut}}=\mathcal{W}/K_{\mathrm{fut}}$ 中同属一类。

**(2) 规范后继可写请求与整账双行去向。**在共尾停点 $j$ 处，由 S1.3 与 S5.3，选定完成回执在结清终点触发 `StockTarget.compiles_settled` 与 `birthProgram`；展开准入后继定义，实际下一包 $j+1$ 的准入当前严格等于该结算目标的 `nextCurrent`。沿该完整当前等式将包 $j$ 选定已付材料的整套元组（登记环境、原语法树、已付态、全迹及持有人）依值搬运为 `rootedMaterial`，直接生成包 $j+1$ 内的可写原生请求 `rootedRequest`；由 (1) 其模型类等于源边界类，且同一次首次整账写入同时给出原继承旧行 `originalOldRow` 与新生行 `originalBornRow` 的目标去向。∎

**形式对应。**MV4 的 `RC/Semantics.lean`（`semanticZero`, `universal_inventory_zero`, `lift_semantic_zero`, `residual_semantic_zero`, `all_word_site_invisible`, `semantic_model_equiv`）、`RC/Source.lean`（`rootedMaterial`, `rootedRequest`, `rooted_request_model`, `actual_generated_current`, `original_compiles`, `originalOldRow`, `originalBornRow`）、`RC/Consumer.lean`（`actual_root_future`, `actual_root_eliminate`）；CP121。

### S6.2 定理 10.2（C47–C49）：保留余项重排联合求值、共同源出处与同债完结

**(1) 保留余项重排联合求值（C47）。**在双层配对值群 $(V\times V)\times(V\times V)$ 上定义加法同态
$$\mathrm{regroup}\bigl((u_{11},u_{12}),(u_{21},u_{22})\bigr):=\bigl((u_{11}+u_{21},\,0),\,(u_{12}+u_{22},\,0)\bigr).$$
对任意双层环境 $\Theta$，记合并输入 $\rho_{\mathrm{tot}}(x):=\Theta(x)_1+\Theta(x)_2\in V\times V$，定义物理分支输入 $\rho_{\mathrm{phys}}(x):=(\pi_1(\rho_{\mathrm{tot}}(x)),0)$ 与保留残差输入 $\rho_{\mathrm{res}}(x):=(\pi_2(\rho_{\mathrm{tot}}(x)),0)$。在变量绑定 $\beta(x)=\mathrm{linear}_{\mathrm{regroup}}(\mathrm{var}\,x)$ 下逐点核验得 $\mathrm{ev}_\Theta(\beta(x))=(\rho_{\mathrm{phys}}(x),\rho_{\mathrm{res}}(x))$，恰为配对环境 $(\rho_{\mathrm{phys}},\rho_{\mathrm{res}})$。对源所属代码 $c\in\mathrm{Expr}(V\times V)$ 令 $\mathrm{jointCode}(c):=(\widetilde c)[\beta]$，由代换求值引理与 (S0.1) 立得
$$\mathrm{ev}_\Theta\bigl(\mathrm{jointCode}(c)\bigr)=\mathrm{ev}_{(\rho_{\mathrm{phys}},\rho_{\mathrm{res}})}(\widetilde c)=\bigl(\mathrm{ev}_{\rho_{\mathrm{phys}}}(c),\ \mathrm{eff}_{\rho_{\mathrm{phys}},\rho_{\mathrm{res}}}(c)\bigr),\tag{S6.3}$$
两坐标相加再由命题 3.3 更新等式即还原完整输入上的值 $\mathrm{ev}_{\rho_{\mathrm{phys}}+\rho_{\mathrm{res}}}(c)$。在发射器之前仅替换 `calculationReader` 为读取该联合代码，原查询读取器、解码器与四路库存回调定义不变，经 S5.2 总值写回与 S5.3 包后继归纳覆盖全部共尾包。

**(2) 共同源输入与线性接收器出处（C48）。**将完整材料与动作读取器输出 $\mathrm{Raw}=(\rho_{\mathrm{Raw}},e_{\mathrm{Raw}})$ 共载于同一投影限制；记出生帧活跃环境为 $\rho_{\mathrm{Born}}$，定义自产增量 $\delta:=\rho_{\mathrm{Born}}-\rho_{\mathrm{Raw}}$，群消去律给出 $\rho_{\mathrm{Raw}}+\delta=\rho_{\mathrm{Born}}$。在配对环境 $(\rho_{\mathrm{Raw}},\delta)$ 下执行 $\widetilde{e_{\mathrm{Raw}}}$，由 (S0.1) 与命题 3.3 知两输出坐标之和等于 $\mathrm{ev}_{\rho_{\mathrm{Born}}}(e_{\mathrm{Raw}})$。在线性同态接收器登记周期中，每次访问重读共同源并对提升表达式作用线性节点，输出更新值等于初值加同源实际效应。

**(3) 同债语法信用严格扣款与完结回答（C49）。**在每个实际当前的已安装材料中，选定完成回执给出已结清常量终点，故 S2.1(1) 证明下一可写残差请求的求值严格等于前一源表达式的实际效应 $\mathrm{eff}_{\rho,\varepsilon}(e)$。出生帧已在准入处执行首步原语归约，其剩余预算为 $B-1=r(e)+r(e')+1\ge 1$（S2.1(2)）：在每个实际扣款分支上，剩余语法信用严格减 $1$（即便语义值 $\mathrm{eff}_{\rho,\varepsilon}(e)=0$，语法节点归约仍照常逐步扣款）、绝不回充，并由依值消元认回同一活账、访问、责任行与整账目标去向。时钟后缀终点落回完整完成当前，求值由可靠性定理还原 $\mathrm{eff}_{\rho,\varepsilon}(e)$；结算处调用 `StockTarget.compiles_settled` 生成责任准入，直接交出完成回答、回执、旧／出生双行去向与规范直达后继。∎

**形式对应。**MV4 的 `SF/Factory/{Source,Consumer}.lean`、`SF/ActualInput/{Source,Consumer}.lean`、`SF/FullResidual/{Source,Consumer,Dynamics/Source,Dynamics/Consumer,Dynamics/Initial}.lean`（CP122–126）；`Q/{Source,Consumer,Next/Source,Next/Consumer,Next/EnvironmentUpdate/...,Next/Linear/Receiver/...}.lean`（CP128–131, 135–136）；`SF/ActualInput/EnvironmentUpdate/CurrentMaterial/{Source,Consumer,RootedEffect/...}.lean`（CP132–134）。

### S6.3 定理 10.3（C51）：无环标量双取反提取与跨共尾预定加法同态续行

**对象与构造。**固定加法群族 $W$（无需环乘法结构）与预先选定的加法群同态 $f:W_s\to W_s$。递归定义逐级配对群 $V_0(t)=W(t),\ V_{n+1}(t)=V_n(t)\times V_n(t)$ 与逐级加法同态 $f^{(0)}:=f,\ f^{(n+1)}(u,v):=(f^{(n)}(u),f^{(n)}(v))$（`map_zero` 与 `map_add` 逐坐标验证）。在第 $n$ 级帧 $\Phi$ 上按正文式 (10.3) 定义 `retainedCode`，并置方法原输入为在零增量配对环境 $(\rho_\Phi,0)$ 下执行 $\mathrm{linear}_{f^{(n+1)}}(\widetilde{\mathrm{retainedCode}_n(\Phi)})$。

**关键引理。**

> **引理 S6.3（零增量配对求值与双取反恒等）。** 在任意加法群载体 $U$、环境 $\rho$ 与表达式 $e$ 上：(i) $\mathrm{eff}_{\rho,0}(e)=0$，从而 $\mathrm{ev}_{(\rho,0)}(\widetilde e)=(\mathrm{ev}_\rho(e),0)$；(ii) $\mathrm{ev}_\rho\bigl(\mathrm{linear}_{-\mathrm{id}}(\mathrm{linear}_{-\mathrm{id}}(e))\bigr)=\mathrm{ev}_\rho(e)$；(iii) 沿定理 6.12 完成回执的全部已付前缀步 $0\le h\le d_0$，递归帧的登记输入表达式保持恒定 $\Phi_h.\mathrm{registered.input.expression}=\Phi_0.\mathrm{registered.input.expression}$。
>
> *证明。*(i) 在命题 3.3 更新等式中取 $\varepsilon=0$ 得 $\mathrm{ev}_\rho(e)=\mathrm{ev}_\rho(e)+\mathrm{eff}_{\rho,0}(e)$，群左消去得 $\mathrm{eff}_{\rho,0}(e)=0$，代入 (S0.1) 即得。(ii) 展开两次取反同态即阿贝尔群对合律 $-(-x)=x$。(iii) 对 $h$ 归纳：$h<d_0$ 时当步为扣款步 $\Phi_{h+1}=\Phi_h.\mathrm{mathNext}$，数学扣款步仅推进债务态而不更改登记输入。∎

**决定性推导。**对任意准入包 $P_n=(n,(\Phi_{\mathrm{src}},\mathrm{seed}),\mathrm{cfg},\text{语言等式})$，由定理 6.10(3) 知原动作结果的已付终点表达式为常量 $e'_{\mathrm{paid}}=\mathrm{const}(p)$（其中 $p$ 为该包完成结果）。接收器在已付前缀终点选定帧处触发出生 `nextBorn`，其新登记表达式按定义 8.11 为 $\mathrm{add}(e_{\mathrm{prev}},\,\mathrm{linear}_{-\mathrm{id}}(e'_{\mathrm{paid}}))$（由引理 S6.3(iii) 已付前缀全程不改登记输入）。因此进入下一原生包后，模式匹配器 `retainedCode` 命中加法右支 $\mathrm{paid}=\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(p))$ 并输出
$$\mathrm{retainedCode}_{n+1}=\mathrm{linear}_{-\mathrm{id}}\bigl(\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(p))\bigr).\tag{S6.4}$$
在新环境 $\rho_{\mathrm{next}}$ 下应用引理 S6.3(ii) 与常量求值得 $\mathrm{ev}_{\rho_{\mathrm{next}}}(\mathrm{retainedCode}_{n+1})=-(-p)=p$。再由引理 S6.3(i) 与 $f^{(n+1)}(0)=0$ 计算下一包动作读取器的求值：
$$f^{(n+2)}\bigl(\mathrm{ev}_{(\rho_{\mathrm{next}},0)}(\widetilde{\mathrm{retainedCode}_{n+1}})\bigr)=\bigl(f^{(n+1)}(p),\ f^{(n+1)}(0)\bigr)=\bigl(f^{(n+1)}(p),\ 0\bigr).\tag{S6.5}$$
同时，程序配置将 `nextPairInventory` 回调设为 `Stock.preserve` 并列合流既往库存与当次完整已写查询库存 `completeQueryWritten`；由并列种子右嵌入定理（定理 2.2 并列展开迹包含律），当次完整查询迹的每个事件均进入出生库存 `writtenStock`。四面组件投影律在查询／结果／编译投影之前先行嵌入基础根，使选定发生处的 `rootRead` 定义相等读回完整四面、对偶与余链，并沿共尾归纳与有限步场段推进保持。∎

**形式对应。**MV5 的 `SF/ActualInput/PaidMethod/Source.lean`（`pairAction`, `actionAt`, `retainedCode`, `raw`, `raw_value`, `completePairOutput_query`, `templateFourFaces`）、`PaidMethod/Recovery.lean`（`negate_paid`, `paid_prefix_expression`, `after_native_retained`, `after_native_value`, `after_native_whole_action`, `actual_complete_query_written`, `actual_native_faces`）、`PaidMethod/Admissions.lean`（`cofinal_paid_method_faces`, `finite_paid_method_faces`）；CP483。

### S6.4 定理 10.4（C52）：整词逐原语回放与库存—边界—余链微分四路锁步

**对象与构造。**设源过程 $\mathcal{P}$ 配有状态环境读出 $\mathrm{readEnv}:S\to\mathrm{Env}$，对自由载体元素 $w\in\mathbb{Z}[S]$ 定义观察环境 $\rho^{\mathrm{obs}}_w(x):=\widehat{\mathrm{readEnv}(\cdot)(x)}(w)$；在状态点 $w=\delta_{s_t}$ 上由命题 2.5 基点性质立得 $\rho^{\mathrm{obs}}_{\delta_{s_t}}=\mathrm{readEnv}(s_t)$，且对任意表达式 $e$ 结构归纳得上下文嵌入求值恒等式 $\mathrm{ev}_{\mathrm{ctx}(w)}(\mathrm{embed}(e))=\mathrm{ev}_{\rho^{\mathrm{obs}}_w}(e)$。

**(1) 逐原语步嵌入与代换计费。**对观察环境下的单步归约 $s:e_1\to e_2$ 作归纳定义 `embeddedStep`：变量绑定步调用上下文环境中 $\mathrm{embed}(\mathrm{var}\,x)$ 的标准执行迹并用嵌入求值等式改写常量终点；三条根常量收缩规则映为单步迹；五条同余规则递归提升子迹。按步拼接得 `embeddedTrace`；在作用后词 $Aw$ 上取标准执行迹并沿绑定等式 $\mathrm{ev}_{\mathrm{ctx}(w)}\circ\sigma=\mathrm{ctx}(Aw)$ 代换即得正向迹 $\mathrm{forward}(w,e)$，零效应配对提升得 $\mathrm{pairedForward}(w,e)$。因它终结于常量，由命题 3.7(1) 其长度精确等于起点剩余步数 $r(\mathrm{embed}(e)[\sigma])$。

**(2) 出生入库与下一查询保留。**密封运行时在第 $k$ 计数帧处的活跃环境经归纳对齐证明等于物理运行态推进 $11+k$ 步的原生环境，从而状态点环境与当帧活跃配对环境 $\widetilde\rho_k$ 严格相等。回调将回放暴露 $\mathrm{replayStock}$ 并入出生库存 $\mathrm{birthStock}$，再由并列种子左嵌入传递进入下一出生帧 `nextBorn` 的完整已写查询迹 `completeQueryWritten`。

**(3) 四路锁步恒等式。**记源回放迹关系词为 $\mu_k$，其源关系像为 $w_{\mathrm{src},k}=\mathrm{rel}(\mu_k)$，代换链映射为 $\tau_1$，下一历史关系闭包中的实际边界元为 $b_{\mathrm{act},k}:=\mathrm{rel}_{\widetilde\rho_k}(\mathrm{nativeReplayAt}_k.\mathrm{relationWords})$。首先，展开两侧执行迹的伸缩端点差（S0.3）并利用代换对单点差与提升表达式的线性交换律，得 $b_{\mathrm{act},k}=\mathrm{subst}_\sigma(w_{\mathrm{src},k})$。其次，代换复形边界方块恒等式 $\mathrm{rel}_{\widetilde\rho_k}\circ\tau_1=\mathrm{subst}_\sigma\circ\mathrm{rel}$ 作用于 $\mu_k$ 给出
$$\mathrm{rel}_{\widetilde\rho_k}\bigl(\tau_1(\mu_k)\bigr)=\mathrm{subst}_\sigma(w_{\mathrm{src},k})=b_{\mathrm{act},k}.\tag{S6.6}$$
再者，下一前缀历史生成的自然上同调复形其 $0\to 1$ 阶微分 $d^{0,1}:X^0\hookrightarrow X^1$ 在关系闭包元素上定义为到生成元闭包的子模包含映射，故底层词满足 $d^{0,1}(b_{\mathrm{act},k})=b_{\mathrm{act},k}=\mathrm{rel}_{\widetilde\rho_k}(\tau_1(\mu_k))$，且作用在 $X^1$ 上的完备化投影 $\pi_{\mathrm{comp}}$ 在关系闭包上恒取零 $\pi_{\mathrm{comp}}(d^{0,1}(b_{\mathrm{act},k}))=0$。最后，由配对绑定方块 $\widetilde\rho_k\circ\sigma=\widetilde\rho_{k+1}$ 知 $(\mathrm{subst}_\sigma,\mathrm{id})$ 构成从第 $k+1$ 拍根求值到第 $k$ 拍根求值的态射，由 S0.4 诱导余像作用满足 $\mathrm{act}_{\mathrm{coim},k}([w_{\mathrm{src},k}]_{k+1})=[\mathrm{subst}_\sigma(w_{\mathrm{src},k})]_k=[b_{\mathrm{act},k}]_k$。将发生展开对第一投影映射复合 `map_map` 与 `map_id`，即证擦除还原原展开且根第二分量读回 `rootRead`。∎

**形式对应。**MV5 的 `Operations/Native/Context/WordExecution.lean`（`observerEnvironment`, `embed_eval`, `binding_word`, `embeddedStep`, `embeddedTrace`, `forward`, `pairedForward`, `forward_charge`）与 `NM/RelationCochain/{Source,Consumer}.lean`（`replayStock`, `replay_written`, `replay_next_query`, `actual_boundary_from_source`, `actual_complex_boundary`, `generated_differential`, `actual_complex_differential`, `completion_consumes_relation`, `actual_coimage_boundary`, `actual_coimage_differential`, `actual_relation_cochain_method`）；CP485。

### S6.5 定理 10.5（C53 及 C50 窗口库存说明）：执行步—请求双向区间反演与防漏重门禁

**对象与批次展开。**记出生执行记录的 $M$ 条已付步骤关系词经源词作用 $S_P$ 映射后构成关系事件表 $E=[e_0,\dots,e_{M-1}]$，其中第 $i$ 个事件 $e_i=\mathrm{relation}(S_P w_i)$ 含有号支撑项表 $\mathrm{items}(e_i)$（长 $c_i=|\mathrm{items}(e_i)|$）。从源前缀偏移 $s_0$ 出发的展开算子满足拼接同态律 `requestsFrom_append`：$\mathrm{req}(s_0, E_1\mathbin{++}E_2)=\mathrm{req}(s_0,E_1)\mathbin{++}\mathrm{req}(s_0+|E_1|,E_2)$。记整批请求表为 $\mathcal{B}:=\mathrm{req}(s_0,E)$，总长 $N=|\mathcal{B}|$。

**(1) 正向连续切片（`stepInterval`）。**对任意步骤下标 $i<M$，将事件表三段分解为 $E=E[0:i]\mathbin{++}[e_i]\mathbin{++}E[i+1:M]$。两次应用 `requestsFrom_append` 并代入 $|E[0:i]|=i$ 与源前缀位置等式，将总表精确拆为三段拼接 $\mathcal{B}=\mathrm{prior}_i\mathbin{++}\mathrm{own}_i\mathbin{++}\mathrm{later}_i$，其中起点 $a_i:=|\mathrm{prior}_i|=|\mathrm{req}(s_0,E[0:i])|$，本步段 $\mathrm{own}_i=\mathrm{req}(s_0+i,[e_i])$ 长度恰为 $|\mathrm{own}_i|=|\mathrm{items}(e_i)|=c_i$。由列表先丢弃前 $a_i$ 项再截取前 $c_i$ 项的恒等式 `(prior ++ own ++ later).drop |prior| |>.take |own| = own`，立得切片等式 $\mathcal{B}[a_i:a_i+c_i)=\mathrm{own}_i$；对切片内各项请求词在解码环境 $\rho_{\mathrm{dec}}$ 下求和，由单关系词请求和引理 `relations_request_sum` 精确给出仿射边界 $\mathrm{affine}_{\rho_{\mathrm{dec}}}(S_P w_i):=S_P w_i-q_{\rho_{\mathrm{dec}}}(S_P w_i)$。

**(2) 反向唯一起源与地址恒等（`readRequestOrigin`）。**定义单调累积表 $P(n):=\mathrm{req}(s_0,E[0:n])$，满足 $P(0)=[\,]$, $P(n+1)=P(n)\mathbin{++}\mathrm{part}(n)$ 及 $P(M)=\mathcal{B}$。对任意请求序号 $r<N=|P(M)|$，有序划分定位引理 `locatePart` 构造性给出唯一块下标 $i<M$ 与块内局部下标 $s<|\mathrm{part}(i)|=c_i$，满足 $r=|P(i)|+s$ 且第 $r$ 项等于 $\mathrm{part}(i)[s]$。与源前缀请求块拼接并消去公共左前缀长度 $|\mathrm{before}|$，即证精确寻址恒等式
$$r = a_i + s,\qquad \mathcal{B}[0:r]=\mathrm{req}(s_0,E[0:i])\mathbin{++}\mathrm{map}_{\mathrm{form}}\bigl(\mathrm{items}(e_i)[0:s]\bigr).\tag{S6.7}$$

**(3) 整批拼接与防漏重负控制门禁。**令分组列表为 $G:=[\mathcal{B}[a_0:a_0+c_0),\dots,\mathcal{B}[a_{M-1}:a_{M-1}+c_{M-1})]$（其中 $c_i=0$ 的空切片原位保留为空表 $[\,]$）。逐下标由 (1) 知 $G[i]=\mathrm{req}(s_0+i,[e_i])$，对 $E$ 归纳展开拼接即得 $\mathrm{flatten}(G)=\mathcal{B}$；由 `executedTrace` 对分组拼接的同态性得 $\mathrm{flatten}(\mathrm{map}_{\mathrm{executedTrace}}G)=\mathrm{executedTrace}(\mathcal{B})$；由列表嵌套求和结合律得各步切片边界之和等于整批总边界。**负控制证明**：设第 $i$ 步组非空（$c_i>0$），由于每条请求产生至少一步非空执行事件，该组对应的原生迹切片长 $\ell_i>0$；若从 $G$ 中删去第 $i$ 组或将该组重复一次，所得总执行迹长度分别变为 $L-\ell_i<L$ 与 $L+\ell_i>L$，故总执行迹严格不等于原执行迹，任何非空组的漏删或重放均被类型化门禁拒绝。

*附注（C50 有限窗口四迹与逆残差纠正）。*在 Riesz 有限 $P_a$ 窗口实装（MV4，CP217／CP219）中，已收到的 Möbius 源 $\nu$ 与两项均值在进入写回准入前将截断拉回、倒数权重与源生 Tate 极点编译为字面加性／线性表达式，使正向、逆向、二阶均值与余链四份迹通过并列种子回调一并保入出生库存；随后读取首阶逆残差并以字面差 $\nu-\mathrm{residual}$ 构造纠正代码，在保持全部四份旧库存嵌入的同时追加新纠正迹并输出源窗价减残差窗价，保持联合观察完整纤维。∎

**形式对应。**`7e4da746f3` 的 `A_src/Receipt.lean`、`A_src/Receipt/{Origin,Block,Block/Position,Block/SourceOrigin,Block/StepInterval,Block/StepInterval/Whole}.lean`（`RequestOriginAt`, `readRequestOrigin`, `StepInterval`, `stepInterval`, `sourceRequestAt_interval_address`, `grouped_requests`, `grouped_executed_trace`, `grouped_request_boundary`）、具名 `NextReceiptStepJointWhole.lean` 与门禁 `Verification/no-island/riemann-r-cofinal-complete-grouped-write/Gate.lean`（CP514, 521, 528–532）；窗口实装见 MV4 `J/ClozelOriginalK{FinitePaWindowOperator,WindowInverseResidual}SourceAction/...`（CP217, CP219）。

### S6.6 定理 10.6（C54）：封存运行历史的前缀刚性、末态增量续行与单遍时间表

**(1) 封存历史唯一性与末态续行（`extendTo_prefix`）。**在源生询问运行时 $\mathcal{R}$ 中，首先对已存历史 $H\in\mathsf{HistoryAt}(\mathcal{R},\mathrm{fuel},s_0)$ 作归纳证明规范生成唯一性 $H=\mathrm{runFrom}(\mathrm{fuel},s_0)$：$\mathrm{fuel}=0$ 时两侧同为 `.exhausted`；归纳步对 `step activated tail` 用归纳假设将 `tail` 改写为 $\mathrm{runFrom}(\mathrm{fuel},a.\mathrm{nextState})$，折叠定义即得 $\mathrm{runFrom}(\mathrm{fuel}+1,s_0)$。同理对 $\mathrm{fuel}$ 归纳，在首元素 `0` 与后继元素 `j.succ` 上分情况（消去空转类型转换 `occurrenceAt_cast`）立得存储读口与动态读口恒等 $H.\mathrm{storedOccurrenceAt}(i)=H.\mathrm{occurrenceAt}(i)$。

定义延续算子 `continueFor(H, extra)` 对 $\mathrm{fuel}$ 递归：当 $\mathrm{fuel}=0$（即到达 $H$ 的封存末态 $s_{\mathrm{tail}}$）时，直接从该存储末态启动 `runFrom(extra, s_tail)`；当 $\mathrm{fuel}>0$ 时，原封不动保留已存首步激活 `.step activated` 而仅递归延续尾段，全程不重算前 $\mathrm{fuel}$ 拍的任何激活。对任意 $\mathrm{total}\ge\mathrm{fuel}$，沿自然数等式 $(\mathrm{total}-\mathrm{fuel})+\mathrm{fuel}=\mathrm{total}$ 搬运 `continueFor(H, total - fuel)` 定义 `extendTo(H, total)`。因任何 `HistoryAt` 对象均等于相应长度的 `runFrom`，结合 `prefix_runFrom` 截断引理即得一行严格证明：
$$\mathrm{prefix}_{\mathrm{fuel}}\bigl(\mathrm{extendTo}(H,\mathrm{total})\bigr)=\mathrm{prefix}_{\mathrm{fuel}}\bigl(\mathrm{runFrom}(\mathrm{total},s_0)\bigr)=\mathrm{runFrom}(\mathrm{fuel},s_0)=H.\tag{S6.8}$$

**(2) 单遍存储时间表与阶段库存还原（`storedTimeline`）。**对活根微步历史 $H_{\mathrm{mic}}\in\mathsf{SourceNativeLivingRootHistoryAt}(\mathcal{P},\mathrm{fuel},s_0)$ 与投影 $\pi:S\to M$，递归收集器 `collect` 从预分配容量 $\mathrm{fuel}+1$ 的空动态数组 `acc` 出发，沿 $H_{\mathrm{mic}}$ 每步将当前已存状态投影压入数组末尾一次，终态再压入一次，归纳得最终数组长度 $|T|=0+(\mathrm{fuel}+1)=\mathrm{fuel}+1$。对累加器任意初长 $|\mathrm{acc}|$ 作归纳证明相邻对不变量 `collect_adjacent`：在索引 $0$ 处刚压入的末格与下一首格恰为 $(\pi(s_0),\pi(s_1))$；在索引 $j+1$ 处由数组下标平移 $|\mathrm{acc}|+(j+1)=(|\mathrm{acc}|+1)+j$ 归约为尾段归纳假设。取空初始数组即得对一切 $i<\mathrm{fuel}$ 有 $(T[i],T[i+1])=(\pi(s_i),\pi(s_{i+1}))$。对其作用加性环境同态 $\rho\circ\pi$，即把 $\bigl(\rho(T[i]),\,\rho(T[i+1]-T[i])\bigr)$ 逐拍等同于动态生成的 $(\rho_i,\varepsilon_i)$，从而导出的 `timelineInventory` 与正文定义 4.5 的动态阶段库存 $U_i^{s_0}$ 逐词严格相等。∎

**形式对应。**`7e4da746f3` 的 `Operations/Inquiry/NativeHistoryContinuation.lean`（`HistoryAt.eq_runFrom`, `storedOccurrenceAt`, `stored_occurrence_eq`, `continueFor`, `extendTo`, `extendTo_prefix`）、`Operations/Runtime/StoredHistory.lean`（`stored_pair_actual`, `stored_environments_actual`, `stored_inventory_actual`）、`Operations/Runtime/StoredTimeline.lean`（`storedTimeline`, `stored_timeline_adjacent`, `timelineEnvironments`, `timelineInventory`, `timeline_environments_actual`, `timeline_inventory_actual`）及 Goldbach 微步／时间表门禁（CP596–598）。

---

## S7 全部主张编号（C1–C54）与正文／书面证明位置索引

下表将本文统合的全部主张编号 **C1–C54**（含 T0 单构造子核、辅助桥接条目 C14–C21 及跨领域实装实例）逐一定位到第三版（v3）正文编号环境、自足书面证明位置与固定源提交，供审稿与机器复核逐条核查。

| 主张编号 | 第三版（v3）正文位置 | 自足书面证明位置 | 固定源提交 |
| --- | --- | --- | --- |
| T0 单构造子与根读核 | §2.1 定义 2.1、定理 2.2 | 正文 §2.1（完整） | H / MV4（并列基数公式 `[propext]`，其余 `[]`） |
| C1 | §6.1 命题 6.1 | 正文 §6.1（完整） | H（`8e29b8e` 回归对齐） |
| C2 | §6.4 定义 6.6、定理 6.7、注记 6.8、图 S2 | 正文 §6.4（完整） | H（良基核 `[]`） |
| C3 | §2.2 定义 2.3、命题 2.4 | 正文 §2.2（完整） | H（`[]`） |
| C4 | §8.4 规范询问运行时激活段 | 正文 §8.4 | H |
| C5 | §8.4 命题 8.9、表 4、图 5 | 正文 §8.4；附录 C.3 | H |
| C6 | §8.4 命题 8.10 | 正文 §8.4（完整） | H（`[]`） |
| C7 | §3.1–§3.3 定义 3.1–3.2, 3.4、命题 3.3, 3.5–3.6 | 正文 §3.1–§3.3（完整） | H |
| C8 | §4 定理 4.4, 4.6–4.7、命题 4.8、例 4.1–4.2、图 1, 3–4, S1 | 正文 §4；附录 A–B | H |
| C9 | §2.3–§2.4 命题 2.5、定义 2.6、命题 2.7 | 正文 §2.3–§2.4；附录 A.1 | H |
| C10 | §5 定义 5.1、命题 5.2、定理 5.3 | 正文 §5（完整） | H（`[]`） |
| C11 | §7.1–§7.2 命题 7.1、定义 7.2、命题 7.3–7.5 | 正文 §7；附录 C.6 | H（7.3–7.4 `[]`） |
| C12 | §6.2–§6.3 定义 6.2–6.3、命题 6.4–6.5、表 2 | 正文 §6.2–§6.3；附录 C.5 | H（6.4–6.5 `[]`） |
| C13 | §8.1–§8.3 定义 8.1、命题 8.2–8.3、定理 8.4、定义 8.5、定理 8.6–8.7、命题 8.8 | 正文 §8.1–§8.3；附录 C.1–C.4 | H（`[]`） |
| C14–C18（上游辅助与跨稿桥接） | C14–C15 为门控／休眠辅助源核（非本篇正文主张）；C16 供 §7.2 命题 7.5；C17 为 §7.1 同债反控；C18 主收《忠实表示》R14–R17 | 命题 7.5 见附录 C.6；其余归上游源码与兄弟专篇 | H / X / Z |
| C19–C21（域内计算桥接一般化） | 完全一般化并入 §6.5 定理 6.10、§8.5 定理 8.12 与 §10.4 Fock 实装 | 补充 S1, S2.1 | AA / AB |
| C22 | §6.5 定义 6.9、定理 6.10 | 补充 S1 | AB |
| C23 | §3.4 命题 3.7、定义 3.8、定理 3.9；§6.5 命题 6.11；§10.4 | 正文 §3.4, §6.5（完整） | AB |
| C24 | §8.5 定义 8.11、定理 8.12、例 8.13、图 6 | 补充 S2.1 | AB |
| C25 | §7.2 命题 7.6 | 正文 §7.2（完整） | AB |
| C26–C27 | §7.2 定理 7.7(1)–(3) | 补充 S2.2 | AC |
| C28 | §9.1 定义 9.1、定理 9.2 | 补充 S3.1 | AD |
| C29 | §9.2 定理 9.3 | 补充 S3.2 | AD |
| C30 | §9.3 定义 9.4、定理 9.5 | 补充 S4.1 | AD |
| C31 | §9.3 定理 9.6 | 补充 S4.2 | AE |
| C32 | §9.3 定理 9.7 | 补充 S4.3 | AE |
| C33–C34 | §9.4 定理 9.8(1)–(3) | 补充 S5.1 | AE |
| C35–C38 | §8.5 定理 8.14（同发生边界差、独立计费与环境方块） | 补充 S2.3 | PR, MF, H0-S |
| C39 | §6.5 定理 6.12 | 补充 S1.3 | MV2 / MV3 |
| C40 | §9.4 定理 9.9、例 9.13(1) | 补充 S4.4 | MV2 / MV3 |
| C41 | §10.4 预解梳完整 $R^m q_0$ 计算、图 7B | 补充 S5.5 | MV2 / MV3 |
| C42 | §8.5 定理 8.15；§10.4 预解梳总值反馈、图 7 | 补充 S5.2, S5.5 | MV3 |
| C43 | §9.4 定理 9.10、例 9.13(2) | 补充 S5.3 | MV3 |
| C44 | §9.4 定理 9.11、例 9.13(3) | 补充 S3.3 | MV3 |
| C45 | §9.4 定理 9.12、例 9.13(3) | 补充 S5.4 | MV3 |
| C46 | §10.1 定理 10.1、图 8A | 补充 S6.1 | MV4 |
| C47–C49 | §10.1 定理 10.2(1)–(3)、图 8A | 补充 S6.2 | MV4 |
| C50 | §10.4 有限 $P_a$ 窗口四迹入库与逆残差纠正 | 正文 §10.4；补充 S6.5 附注 | MV4 |
| C51 | §10.2 定理 10.3、例 1.1(b)、例 10.7、图 8B | 补充 S6.3 | MV5 |
| C52 | §10.2 定理 10.4、图 8B | 补充 S6.4 | MV5 |
| C53 | §10.3 定理 10.5、例 10.7、图 8C | 补充 S6.5 | `7e4da746f3` |
| C54 | §10.3 定理 10.6、例 10.7、图 8C | 补充 S6.6 | `7e4da746f3` |
| CPS1 37 原语实装 | §10.4 第三组全原子连续平滑与能量储备分派 | 补充 S5.6 | MV3 |
