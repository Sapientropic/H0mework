# Zenodo 第三版（v3）上传元数据

本记录对应过程核心第三版和固定的公开证明选集。各文件的 DOI 与校验值见发布登记。

## Files

- `source-process-core.pdf`
- `source-process-core-en.pdf`
- `source-process-core-supplement.pdf`
- `source-process-core-supplement-en.pdf`
- `source-process-core-v3-editable.zip`

## Resource type

Publication → Preprint

## Digital Object Identifier (DOI)

从已发表记录（第一版 https://doi.org/10.5281/zenodo.23210084 、第二版 https://doi.org/10.5281/zenodo.23297175 ）创建 New version 草稿；第三版版本 DOI 由 Zenodo 自动分配。

## Title

Source-Native Process Algebra and Initial-Coface Revision: Four-Tier Identity, Exact Evaluation Kernels, and Reversible Incremental Continuation

## Additional titles

- Translated title（Chinese）：源生过程代数与初始余面修订：四层同一性、正合求值核与可逆增量续行
- Alternative title（Earlier editions v1–v2）：The State Is Not the History, the Source Is: Identity, Responsibility, and Minimal Revision in Processes

## Publication date

填写第三版首次公开日期（发布时核对）。

## Creators

- Person：Gao, Jian
- ORCID：0009-0009-5002-1655
- Affiliation：Independent Researcher
- Role：（留空；独著）

## Description

Static state snapshots and tick-wise numerical equalities cannot anchor identity across an evolving process: two locally valid trajectory segments agreeing at their shared state can still lack any common generating object across the combined history; two implementations can emit identical observation sequences without identifying which event realizes which occurrence; and ledger updates or expressive breakdowns can erase the lineage of unfinished obligations. Working across an explicitly separated zero-axiom constructive kernel (T0, Lean 4 `#print axioms = []`) and a free-module completion and continuation layer (T1), we develop a source-native process algebra organized along four strictly strengthening tiers: same reading < same source object < same rooted occurrence < same obligation and revision.

A single inductive constructor `occur(a, [T_1, ..., T_k])` derives nonempty frontiers, associative substitution, parallel/joint cardinality shadows (`+` and `x`), and a universally unique fold without a second constructor or primitive arithmetic axioms. In Lean the parallel cardinality formula uses `propext`. Root-read identity `rootRead(o) = o` excludes hidden-null witnesses for every downstream consumer. Between any two faithful realizations of a fixed root, the shared occurrence uniquely generates—without pre-supplied simulation relations or auxiliary history/prophecy variables—a pointwise event comparison compatible with emitters and whole-ledger compilation. Whenever an old theory has both empty expression-witness and empty lawful-realization fibres for an obstructed demand (rooted double-empty bankruptcy `eta`), `eta` constructs in zero axioms the categorical initial coface `C_eta = L_+ + {*_eta}`, preserving all old facts and theorems without contraction, admitting a unique injective budget-non-increasing factorization into every admissible extension, and sending the adjoined direction onto the exact live row consumed by a typed revision's first whole-ledger write so the new root answers directly at the second tick.

In the T1 module and reversible-continuation layer, arbitrary structureless state sets `S` and binary operations lift freely into a many-sorted algebraic language satisfying the three-term bilinear update equation. Every rooted tree `T` and constructor `kappa` compiles to a whole-tree program of exact syntax budget `beta(T)` equipped with an evaluation-free syntactic left inverse: even when `kappa = 0` collapses all semantic outputs to one state point, the program map remains injective and recovers `T` intact. Over any commutative ring `R`, derivation endpoint differences and module laws span the exact evaluation kernel `range(rel_rho) = ker(ev_rho)`, and every element of the inverse-limit completion `C_hat(s)` obeys the elementwise evolution law. Environment–expression pairs birth bearer-free computational obligations paid strictly step by step with `Type`-valued completion receipts returning exact distance `d_i = B_i`; after settlement, the updated difference `e (-) e'` births the next inquiry, writes back total value `V = p + n` with fresh decoders, and generates six compatible faces alongside the maximal future-invisible invariant kernel model `M_fut = W / K_fut`.

Finally, universal semantic-zero congruence identifies `e (-) e'` with the trace boundary `delta_e - delta_{e'}` across all future action words and sites to form a writable request in canonical next; ring-free syntactic double negation `retainedCode` recovers paid ASTs to execute any pre-fixed additive homomorphism `f^{(n+1)}` across cofinal stops while primitive-by-primitive whole-word replay updates substitution `tau_1`, relation boundaries, and cochain differentials `d^{0,1}` in lockstep; executed steps and next-batch signed requests invert bidirectionally via contiguous slices `stepInterval` and `readRequestOrigin` (`r = a_i + s`, rejecting omission or duplication of any nonempty group); and sealed histories extend across horizons by locking the paid prefix and running only the missing tail suffix. Instantiations in Fock arithmetic, Riesz resolvent combs with windowed inverse-residual correction, and a 37-primitive whole-atom smooth dynamical system demonstrate cross-domain habitability, situated within a theorem-level comparison across twenty-four primary works.

## Additional descriptions

- Type：Abstract；Language：Chinese

静态状态快照与逐拍数值相等无法锚定演化过程的同一性：两段局部相容的读数在共享交点处取值相同，仍可能不存在任何贯穿全历史的共同生成对象；两套实现可以产出完全一致的观测序列而无法指认哪一事件属于哪次发生；一次模律更新或表达破产更可能抹去未结责任的谱系与归属。本文在显式分离的零公理构造性内核（T0，`#print axioms = []`）与自由模完备化代数层（T1）之上，建立沿“同一读数 < 同一源对象 < 同一次有根发生 < 同一笔责任与修订”逐级闭合的源生过程代数。在构造层，单一归纳构造子 `occur(a,[T_1,...,T_k])` 无需第二构造子或原语算术公理即派生非空前沿、结合推进、并／联基数阴影（`+` 与 `x`）及万有唯一折叠。Lean 中的并列基数公式使用 `propext`。根读恒等 `rootRead(o)=o` 对一切下游消费排除隐藏空证人；同一权威根的任意两个忠实实现无需外部模拟关系或历史／预言辅助变量，即由共同发生零公理唯一导出与发射器及整套编译器相容的逐事件比较态射；当旧理论对某阻滞需求既无表达见证也无合法实现（双空破产 `eta`）时，`eta` 零公理生成保守保持全部旧事实与旧定理的范畴初始余面 `C_eta = L_+ + {*_eta}`，对任意容许扩充给出三坐标单射且预算不回充的唯一态射分解，并将新增方向精确送入有类型修订新根首次整账写入所消费的新行，在第 2 拍由同一新根直接给出回答。

在 T1 代数与可逆续行层中，无需自带加法的任意原生状态集 `S` 与二元函数经自由 Z-模与张量泛性质进入多类异质表达式语言，满足双线性三项增量更新律；任意有根树与构造子函数 `kappa` 编译为步长恰等于语法预算 `beta(T)` 的整树程序，并由纯语法解析器给出不经求值的左逆——即便 `kappa = 0` 使所有树求值坍缩为同一零状态点，程序映射仍保持单射并完整还原原树。任意交换环 `R` 上归约推导端点差与标量模律的线性像正合等于求值核 `range(rel_rho) = ker(ev_rho)`，逆极限完备化载体 `C_hat(s)` 的全体元素满足逐拍演化等式。原发生登记的环境—表达式对无需借用旧承担者即内生生成执行债务律，逐步严格扣款并由 `Type` 值完成回执返回精确步距 `d_i = B_i` 与已付前缀；结清后，已付关系在新环境中的差词 `e (-) e'` 内生提出预算严格为正的下一问，每次回执按 `V = p + n` 写回总值并重生解码器，同一材料同步生成代数／组合／拓扑／逻辑／关系／余链六面及依值直和载体上的最大未来不可见不变核模型 `M_fut = W / K_fut`。进一步，全环境语义零关系证明残差请求与已付迹边界在一切允许未来词与站点下同属同一 `M_fut` 类并直达规范后继可写请求；纯语法双取反提取器 `retainedCode` 无环标量恢复已付常量语法树以跨共尾执行任意预定加法同态 `f^{(n+1)}`，整词逐原语回放使替换链映射 `tau_1`、实际边界与余链微分 `d^{0,1}` 严格锁步；已执行原语步与下一批有号请求建立连续切片 `stepInterval` 与起源反演 `readRequestOrigin` 的双向恒等 `r = a_i + s`（漏删或重复任一非空组必改变原生迹），封存运行历史在视野延长时锁死已付前缀、仅从实际末态续跑缺失后缀。算术 Fock 空间、Riesz 预解梳与有限窗口逆残差纠正及 37 原语全原子连续平滑体系给出跨领域实装核验。

## Licenses

Creative Commons Attribution 4.0 International（CC BY 4.0）。代码仓另为 Apache-2.0。

## Keywords and subjects

source-native process algebra; four-tier process identity; zero-axiom constructive kernel; exact evaluation kernel; syntactic left inverse; categorical initial coface; well-founded debt settlement; reversible incremental continuation; dependent-type formalization; Lean 4

## Languages

English (eng), Chinese (zho) — English and Chinese editions

## Version

v3

## Related works

- Relation：Is new version of；Identifier：10.5281/zenodo.23297175；Scheme：DOI；Resource type：Publication → Preprint
- Relation：Is new version of；Identifier：10.5281/zenodo.23210084；Scheme：DOI；Resource type：Publication → Preprint
- Relation：Is supplemented by；Identifier：https://github.com/Sapientropic/H0mework/tree/5f94af7e988c9831c92e54fe89747699fa29cd85；Scheme：URL；Resource type：Software
- Relation：Is documented by；Identifier：https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/source-process-core-v3-map.json；Scheme：URL；Resource type：Software

## Notes（可选）

Third edition (v3) unifying claims C1–C54 across an explicitly separated T0 zero-axiom kernel and T1 module/reversible-continuation layer while preserving all cross-paper theorem numbers in Sections 3–9. Entry modules and reproduction commands are listed in Appendix D and "Code and Data Availability".
