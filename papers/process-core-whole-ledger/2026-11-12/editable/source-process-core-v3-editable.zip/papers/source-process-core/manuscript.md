# 源生过程代数与初始余面修订：四层同一性、正合求值核与可逆增量续行

**Source-Native Process Algebra and Initial-Coface Revision: Four-Tier Identity, Exact Evaluation Kernels, and Reversible Incremental Continuation**

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

---

**形式验证与版本说明。** 本文全部核心构造、定理与反例门禁均经 Lean 4 内核严格验证，独立审核覆盖声明类型、证明项与归纳／递归元数据的完整依赖闭包。全篇显式分离两层公理核：**T0 零公理构造性内核**（`#print axioms = []`，不依赖任何公理）管辖单构造子有根发生展开与万有折叠、根读无盲区恒等、固定法则过程后继刚性、忠实过程实现的无预置模拟唯一比较、无总法则 $\le\,;\,<\,;\,\le$ 付款宏步良基性、一次性空纤维不可能反例，以及根植双空破产下的范畴初始余面唯一态射分解与双行同首写修订；**T1 标准三公理代数与完备化层**（仅依赖命题外延性 `propext`、经典选择 `Classical.choice` 与商健全性 `Quot.sound`，零研究公理、零未完成占位）管辖任意无加法状态的自由 $\mathbb{Z}$-模与双线性提升、正合求值核、逆极限历史完备化、全未来不变核模型、双取反已付语法树同态续行、整词逐原语余链微分回放、执行步—请求双向区间反演及跨领域算子与连续平滑实装，且绝不反向污染 T0 内核的零公理身份。本文为已发表第一、二版（原题《状态不是历史，源才是：过程同一性、责任承接与最小修订》，第二版 DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175)）的第三版（v3）重构定稿，完整统合 **C1–C54** 证据链。[首发证明验收](https://github.com/Sapientropic/H0mework/blob/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/evidence/first-release/acceptance/proof-20261007/receipt.json)、[第二版源码绑定](https://github.com/Sapientropic/H0mework/blob/e9734c69f38cf03b79859a1108ae23a5663a0495/docs/assets/paper-source-binding-b9d66048.json)、附录 D 与“代码与数据可得性”登记各批次固定提交与复核入口。

## 摘要

静态状态快照与逐拍数值相等无法锚定演化过程的同一性：两段局部相容的读数在共享交点处取值相同，仍可能不存在任何贯穿全历史的共同生成对象；两套实现可以产出完全一致的观测序列而无法指认哪一事件属于哪次发生；一次模律更新或表达破产更可能抹去未结责任的谱系与归属。本文在显式分离的**零公理构造性内核（T0）**与**自由模完备化代数层（T1）**之上，建立沿“同一读数 $<$ 同一源对象 $<$ 同一次有根发生 $<$ 同一笔责任与修订”逐级闭合的**源生过程代数**。在构造层，单一归纳构造子 $\mathrm{occur}(a,[T_1,\dots,T_k])$ 无需第二构造子或原语算术公理即派生非空前沿、结合推进、并／联基数阴影（$+$ 与 $\times$）及万有唯一折叠。并列基数公式在 Lean 中依赖命题外延性。根读恒等 $\mathrm{rootRead}(o)=o$ 对一切下游消费排除隐藏空证人；同一权威根的任意两个忠实实现无需外部模拟关系或历史／预言辅助变量，即由共同发生零公理唯一导出与发射器及整套编译器相容的逐事件比较态射；当旧理论对某阻滞需求既无表达见证也无合法实现（双空破产 $\eta$）时，$\eta$ 零公理生成保守保持全部旧事实与旧定理的**范畴初始余面** $C_\eta=L_+\sqcup\{\star_\eta\}$，对任意容许扩充给出三坐标单射且预算不回充的唯一态射分解，并将新增方向精确送入有类型修订新根首次整账写入所消费的新行，在第 2 拍由同一新根直接给出回答。

在 T1 代数与可逆续行层中，无需自带加法的任意原生状态集 $S$ 与二元函数经自由 $\mathbb{Z}$-模与张量泛性质进入多类异质表达式语言，满足双线性三项增量更新律；任意有根树与构造子函数 $\kappa$ 编译为步长恰等于语法预算 $\beta(T)$ 的整树程序，并由纯语法解析器给出不经求值的左逆——即便 $\kappa\equiv 0$ 使所有树求值坍缩为同一零状态点，程序映射仍保持单射并完整还原原树。任意交换环 $R$ 上归约推导端点差与标量模律的线性像正合等于求值核 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$，逆极限完备化载体 $\widehat C(s)$ 的全体元素满足逐拍演化等式。原发生登记的环境—表达式对无需借用旧承担者即内生生成执行债务律，逐步严格扣款并由 `Type` 值完成回执返回精确步距 $d_i=B_i$ 与已付前缀；结清后，已付关系在新环境中的差词 $e\ominus e'$ 内生提出预算严格为正的下一问，每次回执按 $V=p+n$ 写回总值并重生解码器，同一材料同步生成代数／组合／拓扑／逻辑／关系／余链六面及依值直和载体上的最大未来不可见不变核模型 $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$。进一步，全环境语义零关系证明残差请求与已付迹边界在一切允许未来词与站点下同属同一 $\mathsf{M}_{\rm fut}$ 类并直达规范后继可写请求；纯语法双取反提取器 $\mathrm{retainedCode}$ 无环标量恢复已付常量语法树以跨共尾执行任意预定加法同态 $f^{(n+1)}$，整词逐原语回放使替换链映射 $\tau_1$、实际边界与余链微分 $d^{0,1}$ 严格锁步；已执行原语步与下一批有号请求建立连续切片 $\mathrm{stepInterval}$ 与起源反演 $\mathrm{readRequestOrigin}$ 的双向恒等 $r=a_i+s$（漏删或重复任一非空组必改变原生迹），封存运行历史在视野延长时锁死已付前缀、仅从实际末态续跑缺失后缀。算术 Fock 空间、Riesz 预解梳与有限窗口逆残差纠正及 37 原语全原子连续平滑体系给出跨领域实装核验。

**关键词**：源生过程代数；四层过程同一性；零公理构造性内核；正合求值核；整树纯语法左逆；范畴初始余面；良基同债结算；可逆增量续行；依赖类型形式化

### Abstract (English)

Static state snapshots and tick-wise numerical equalities cannot anchor identity across an evolving process: two locally valid trajectory segments agreeing at their shared state can still lack any common generating object across the combined history; two implementations can emit identical observation sequences without identifying which event realizes which occurrence; and ledger updates or expressive breakdowns can erase the lineage of unfinished obligations. Working across an explicitly separated **zero-axiom constructive kernel (T0)** and a **free-module completion and continuation layer (T1)**, we develop a **source-native process algebra** organized along four strictly strengthening tiers: *same reading $<$ same source object $<$ same rooted occurrence $<$ same obligation and revision*. A single inductive constructor $\mathrm{occur}(a,[T_1,\dots,T_k])$ derives nonempty frontiers, associative substitution, parallel and joint cardinality shadows ($+$ and $\times$), and a universally unique fold. The Lean proof of the parallel cardinality formula uses `propext`. Root-read identity $\mathrm{rootRead}(o)=o$ excludes hidden-null witnesses for every downstream consumer. Between any two faithful realizations of a fixed root, the shared occurrence uniquely generates—without pre-supplied simulation relations or auxiliary history/prophecy variables—a pointwise event comparison compatible with emitters and whole-ledger compilation. Whenever an old theory has both empty expression-witness and empty lawful-realization fibres for an obstructed demand (rooted double-empty bankruptcy $\eta$), $\eta$ constructs in zero axioms the **categorical initial coface** $C_\eta=L_+\sqcup\{\star_\eta\}$, preserving all old facts and theorems without contraction, admitting a unique injective budget-non-increasing factorization into every admissible extension, and sending the adjoined direction onto the exact live row consumed by a typed revision’s first whole-ledger write so the new root answers directly at the second tick.

In the T1 module and reversible-continuation layer, arbitrary structureless state sets $S$ and binary operations lift freely into a many-sorted algebraic language satisfying the three-term bilinear update equation. Every rooted tree $T$ and constructor $\kappa$ compiles to a whole-tree program of exact syntax budget $\beta(T)$ equipped with an evaluation-free syntactic left inverse: even when $\kappa\equiv 0$ collapses all semantic outputs to one state point, the program map remains injective and recovers $T$ intact. Over any commutative ring $R$, derivation endpoint differences and module laws span the exact evaluation kernel $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$, and every element of the inverse-limit completion $\widehat C(s)$ obeys the elementwise evolution law. Environment–expression pairs birth bearer-free computational obligations paid strictly step by step with `Type`-valued completion receipts returning exact distance $d_i=B_i$; after settlement, the updated difference $e\ominus e'$ births the next inquiry, writes back total value $V=p+n$ with fresh decoders, and generates six compatible faces alongside the maximal future-invisible invariant kernel model $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$. Finally, universal semantic-zero congruence identifies $e\ominus e'$ with the trace boundary $\delta_e-\delta_{e'}$ across all future action words and sites to form a writable request in canonical next; ring-free syntactic double negation $\mathrm{retainedCode}$ recovers paid ASTs to execute any pre-fixed additive homomorphism $f^{(n+1)}$ across cofinal stops while primitive-by-primitive whole-word replay updates substitution $\tau_1$, relation boundaries, and cochain differentials $d^{0,1}$ in lockstep; executed steps and next-batch signed requests invert bidirectionally via contiguous slices $\mathrm{stepInterval}$ and $\mathrm{readRequestOrigin}$ ($r=a_i+s$, rejecting omission or duplication of any nonempty group); and sealed histories extend across horizons by locking the paid prefix and running only the missing tail suffix. Instantiations in Fock arithmetic, Riesz resolvent combs with windowed inverse-residual correction, and a 37-primitive whole-atom smooth dynamical system demonstrate cross-domain habitability.

**Keywords**: source-native process algebra; four-tier process identity; zero-axiom constructive kernel; exact evaluation kernel; syntactic left inverse; categorical initial coface; well-founded debt settlement; reversible incremental continuation; dependent-type formalization

---

## 1 引言：四层同一性、反例锚点与双核总纲

### 1.1 为什么相等读数与状态快照锁不住过程同一性

考虑一个最简单的三拍演化问题。设单变量环境依次取 $x\mapsto 1$、$x\mapsto 0$、$x\mapsto 1$。若某个代数词在一段更新前后的求值恰等于规定目标读数，称该词**局部实现**这段更新。第一段环境从 $1$ 变为 $0$，要求读数实现 $0\to 0$，常零词 $w_1=0$ 满足要求；第二段环境从 $0$ 变回 $1$，要求读数实现 $0\to 1$，变量词 $w_2=x$ 满足要求。两段在中间共享环境 $x\mapsto 0$ 处的读数也严格相等，均为 $0$。

两段局部检查全部通过，交接点数值严丝合缝。然而，若追问是否存在**同一个源词** $w$ 从头到尾产生三拍读数 $0,0,1$，答案是否定的：这样的 $w$ 必须同时满足 $\mathrm{ev}_1(w)=0$、$\mathrm{ev}_0(w)=0$ 与 $\mathrm{ev}_1(w)=1$，而首末两拍在同一求值映射 $\mathrm{ev}_1$ 下要求 $0=1$，直接矛盾（图 1；例 4.1）。谬误出在隐含的推理步：把“交点处数值读数相等”当成了“两段同属一个持续源对象的历史”。相等读数只说明两个对象在该拍不可区分，绝不使它们成为同一个源对象。

![图 1 局部见证无法拼接为共同源历史](figures/vector/figure1-three-tick-counterexample.png)

**图注**。图 1｜局部见证与共同源词反例（精确数值图；例 4.1，表 1）。环境依次为 $x\mapsto 1,0,1$。深蓝零词在首段实现 $0\to 0$，金色变量词在次段实现 $0\to 1$；实线为局部采用段，虚线与空心圆补出该词在另一段的真实读数，朱砂括号标首末两拍共享同一环境 $x\mapsto 1$。任何共同源词都须在同一求值映射 $\mathrm{ev}_1$ 下同时取 $0$ 与 $1$，首末条件已直接构成矛盾。

完全相同的断裂依次出现在代数关系、系统实现、未结责任与语言修订四个层面：

1. **关系跨拍失效**：多项式词 $x^2-x$ 在 $x\mapsto 1$ 下求值为 $0$（属于当前求值核），环境更新为 $x\mapsto 2$ 后变为 $2\ne 0$（例 4.2）——把当前拍成立的等式当作永久恒等式，下一拍即产出伪证。
2. **观测同迹而发生失锚**：两套不同宿主表示或编译器可以吐出完全相同的数值流，却无法仅凭状态快照指认哪一个实现事件对应哪一次底层发生，除非向状态外置添加历史变量乃至预知未来的预言变量[[7]](#ref-7)。
3. **账面平转掩盖活债谱系**：一笔待履行的计算或领域责任在整账更新后，若仅比较总余额或允许等额重贴标签，便可洗掉原债务谱系或让未结义务无限空转而不着陆。
4. **表达破产越出旧语言边界**：当新发生暴露出旧理论既无语法词可表、亦无合法实现见证的需求（双空破产）时，固定语言内的信念收缩[[18]](#ref-18)无从落脚：问题不在于删去哪条旧定理，而在于如何在不破坏任何旧事实与旧活债的前提下，以最小、唯一且可入账的方式扩充表达空间本身。

本文建立一套**源生过程代数（source-native process algebra）**，将上述现象严格组织为逐层增持不变量的**四层过程同一性**，并在最顶层闭合语言破产修订与跨周期可逆增量续行两条主干（图 2）。全篇在公理地基上作严格双核切分：发生树展开的非空前沿、结合推进、唯一折叠、根读安全、单根实现唯一比较、同债宏步良基骨架及范畴初始余面唯一分解均在**T0 零公理构造性内核**（Lean 4 `#print axioms = []`，不调用选择公理、命题外延性或商公理[[17]](#ref-17)）中完成。定理 2.2 的并列基数公式在 Lean 中只使用 `propext`。凡涉及自由 $\mathbb{Z}$-模商、任意交换环 $R$ 上的正合表现、逆极限完备化、依值直和未来核及算子分析实装的定理，全部置于**T1 标准三公理代数层**（`propext`、`Classical.choice`、`Quot.sound`），两层边界在每个定理处显式标定。

四层同一性的核心正向定理、配对反例／反向门禁及公理核归属总览如下表所示（后续编号表自表 1 起算）：

| 同一性层级与公理核 | 锁定的核心正向定理 | 配对反例／反向门禁（缺少该层时的精确失效） | 正文与证明 |
| --- | --- | --- | --- |
| **T0 地基与第 1 层起点**（`[]`）单构造子发生与根读 | 单一构造子 $\mathrm{occur}(a,\vec T)$ 派生前沿、结合推进、联合基数阴影与唯一万有折叠；根读恒等 $\mathrm{rootRead}(o)=o$ 排除一切隐藏空证人；固定法则过程后继确定 | 低维投影读出存在隐藏空证人盲区；状态外隐参数若不进入完整当前即无法分叉合法后继 | §2.1–§2.2（定理 2.2、命题 2.4） |
| **第 2 层：同一源对象**（T1）自由载体、语法左逆与正合核 | 无加法状态自由提升 $\mathbb{Z}[S]$ 与三项更新律；整树程序纯语法左逆 $\mathrm{read}(\mathrm{prog}_\kappa T)=T$；正合核 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$；逆极限完备化 $\widehat C(s)$ 全元素演化律 | 三拍局部同读 $0,0,1$ 无共同源词（例 4.1）；旧核关系 $x^2-x$ 跨拍失效（例 4.2）；常零构造子 $\kappa\equiv 0$ 抹平全部求值但抹不掉整树程序（定理 3.9(4)） | §2.3–§4（定理 3.9、4.4、4.6–4.7；附录 A–B） |
| **第 3 层：同一次发生**（T0 `[]`）忠实实现与唯一比较 | 双向发生—事件表示恢复全部已安装投影与原生后继；同一根任意两忠实实现导出**逐点唯一**事件比较，保持整套编译器结果 | 仅凭相同观测序列无法确定跨实现事件对应；单访问事件纤维非单点时候选映射失去无条件唯一性 | §5（命题 5.2、定理 5.3） |
| **第 4 层：同一笔责任**（T0 良基核／T1 执行账） | 生命周期三律（禁凭空生成／禁越界点亮／禁无证消失）；无总法则 $\le\,;\,<\,;\,\le$ 宏步良基性；无旧承担者内生执行账逐步扣款与 `Type` 完成回执 $d_i=B_i$ | 仅靠等额传输无限空转不终止；零预算但终账纤维为空时同债总律成空类型（注记 6.8）；零语义效应仍须照付语法步预算 | §6（命题 6.1, 6.4–6.5；定理 6.7, 6.10, 6.12；补充 S1） |
| **封顶支路 I：初始余面修订**（T0 `[]`）破产语言升维 | 依赖残差给出双空破产 $\eta$；零公理生成初始余面 $C_\eta=L_+\sqcup\{\star_\eta\}$，旧定理存续、旧面零泄漏，对任意容许扩充具**唯一忠实单射分解**，新方向直入新根首写并在第 2 拍直答 | 一次性空查询纤维接口不存在自主询问运行（命题 8.10）；双空破产在旧理论内表达与实现纤维俱空（命题 7.4）；转移行不能冒充理论审计保持行 | §7–§8.4（命题 7.4–7.5, 8.9–8.10；定理 8.4, 8.6–8.7；附录 C） |
| **封顶支路 II：可逆增量续行**（T1）跨周期方法与双向切片 | 总值写回 $V=p+n$、六面余链与最大未来核 $\mathsf{M}_{\rm fut}$；语义零同余直达后继请求（C46–C49）；$\mathrm{retainedCode}$ 双取反恢复已付树执行同态 $f^{(n+1)}$ 与逐原语余链微分（C51–C52）；$\mathrm{stepInterval}$ 与 $\mathrm{readRequestOrigin}$ 双向反演 $r=a_i+s$ 及 $\mathrm{extendTo}$ 锁前缀末态续行（C53–C54） | 常值配置查询零效应正控制 $(1,0)$ 检验总值不丢旧值（补充 S5.2）；漏删或重复任一非空步骤请求组必改变原生执行迹（定理 10.5 负控制门禁） | §8.5–§10.3（定理 8.12, 8.14–8.15, 9.2–9.3, 9.5–9.12, 10.1–10.6；补充 S2–S6） |

![图 2 四层过程同一性、T0/T1 公理分界与双向封顶架构](figures/vector/figure2-four-tier-architecture-v3.png)

**图注**。图 2｜四层过程同一性、T0/T1 公理分界与双向封顶架构（结构总图）。自下而上每层严格增持不变量：底层建立在零公理（`[]`）单构造子发生展开 $\mathrm{occur}(a,[T_1,\dots,T_k])$ 与根读无盲区恒等 $\mathrm{rootRead}(o)=o$ 之上（§2.1–§2.2，定理 2.2、命题 2.4）；第 2 层（T1）将无加法原生状态嵌入自由载体 $\mathbb{Z}[S]$，证明零求值下仍保持的纯语法整树左逆、正合求值核 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$ 与完备化载体逐元素演化律（§2.3–§4，定理 3.9、4.4、4.6–4.7）；第 3 层（T0）无需外部模拟关系或辅助历史变量，由共同发生唯一确定两忠实实现的逐事件比较（§5，定理 5.3）；第 4 层给出无总法则 $\le\,;\,<\,;\,\le$ 付款宏步良基性（T0）、无旧承担者内生严格扣款与 `Type` 完成回执 $d_i=B_i$（§6，定理 6.7、6.10、6.12）；顶层按旧语言破产或充足分叉为支路 I（§7–§8：T0 范畴初始余面唯一分解 $F:C_\eta\to\mathcal{E}$ 与旧债、新行同入首写及第 2 拍直答，定理 8.4、8.6–8.7）与支路 II（§8.5–§10：T1 总值写回 $V=p+n$、六面余链、最大未来核 $\mathsf{M}_{\rm fut}$、双取反同态续行 $f^{(n+1)}$、逐原语余链微分与步—请求双向区间反演 $r=a_i+s$，定理 8.15、9.9–9.12、10.1–10.6）。层间文字标出迫使升层的精确反例门禁；朱砂框标出第三版封顶闭合层。

### 1.2 三分钟纸笔验算锚点

在进入一般形式定义之前，读者只需用纸笔花三分钟验算以下三个初等算例，即可直接触摸本文三条核心机制——**阶段库存分离伪拼接与零求值语法左逆**、**双取反无损恢复已付语法树执行同态**、以及**破产语言初始余面的双行首写承接**。

**例 1.1（三分钟纸笔验算）。**

**(a) 阶段库存一拍拆穿三拍伪拼接，纯语法左逆抵抗全零坍缩。** 在图 1 的三拍环境 $1\to 0\to 1$ 中，第 $1$ 拍旧环境为 $\rho_1(x)=0$，步进增量为 $\varepsilon_1=1-0=+1$。单拍**阶段库存**（定义 4.5）同时记录（旧值，效应）对 $U_1(w)=(\mathrm{ev}_{\rho_1}w,\ \mathrm{eff}_{\rho_1,\varepsilon_1}w)$：

$$U_1(0)=(0,\,0),\qquad U_1(x)=(0,\,1)\neq(0,\,0).$$

交点处的“相等读数 $0$”只是旧值坐标的巧合，效应坐标当场将两词分开（定理 4.6）。反过来，考虑两棵不同的有根树 $T_1=\mathrm{occ}(a;[\,])$ 与 $T_2=\mathrm{occ}(a;[\mathrm{occ}(b;[\,])])$，取常零构造子 $\kappa\equiv 0: \mathrm{Root}\to\mathrm{List}(\mathbb{Z})\to\mathbb{Z}$。两棵树求值完全坍缩为同一状态点 $\mathrm{ev}_\delta(\mathrm{prog}_\kappa T_1)=\mathrm{ev}_\delta(\mathrm{prog}_\kappa T_2)=\delta_0$；但它们的语法预算分别为 $\beta(T_1)=2$ 与 $\beta(T_2)=2+(2+0+1)=5$，纯语法解析器 $\mathrm{read}$ 不调用 $\kappa$ 即可从程序文本无损还原 $\mathrm{read}(\mathrm{prog}_\kappa T_1)=T_1\neq T_2=\mathrm{read}(\mathrm{prog}_\kappa T_2)$（定理 3.9(4)）。数值求值可以遗忘一切，源程序一字不漏。

**(b) 双取反从残差语法树无环标量取回已付常量，驱动跨周期同态并照付零效应语法费。** 在环境 $\rho_0(x)=3$ 下执行表达式 $e=x+x$：左变量绑定、右变量绑定、常量相加共 $r(e)=3$ 步严格扣款（$3\to 2\to 1\to 0$），结清终点为已付常量语法树 $e'=\mathrm{const}(6)$。若下一拍环境保持 $\rho_1(x)=3$（增量 $\varepsilon=0$），结清触发的残差请求为

$$e\ominus e' = (x+x) + \mathrm{linear}_{-\mathrm{id}}\bigl(\mathrm{const}(6)\bigr),$$

其语义效应为 $\mathrm{ev}_{\rho_1}(e\ominus e')=6-6=0$，但语法剩余步数为 $r(e\ominus e')=r(e)+r(e')+2=3+0+2=5>0$——语义效应为零绝不免除 $5$ 步语法核验扣款（定理 8.12(2)、定理 10.2）。进入下一共尾包时，模式匹配提取器 $\mathrm{retainedCode}$ 从残差右支 $\mathrm{paid}=\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(6))$ 直接构造纯语法双取反（定理 10.3）：

$$\mathrm{retainedCode}=\mathrm{linear}_{-\mathrm{id}}\bigl(\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(6))\bigr),\qquad \mathrm{ev}_{\rho_1}(\mathrm{retainedCode})=-(-6)=6.$$

全程无需借用环乘法标量 $-1$ 或外置缓存表，即从残差语法原位取回已付值 $p=6$；再施以预先固定的倍增同态 $f(v)=2v$，下一包直接算出 $(f(6),0)=(12,0)$ 并写入出生库存。

**(c) 双空破产语言的初始余面粘接与两拍接力。** 设旧支承上的活账仅有一条预算为 $2$ 的旧责任行 $e_o$，而旧理论对阻滞 $o$ 的表达见证类型与合法实现类型皆为空（$E_\Theta=\varnothing, I_\Theta(o)=\varnothing$）。根植破产 $\eta$ 零公理构造初始余面 $C_\eta=L_+\sqcup\{\star_\eta\}$，旧行预算保持 $\beta(\operatorname{inl}e_o)=2$，新增方向预算定为 $\beta(\operatorname{inr}\star_\eta)=0$（命题 8.2）。有类型修订在自然数流载体 $\mathbb{N}$ 上执行首次写入 $0\to 1$，其双行补丁同时消费旧行与新行（$2\to 2,\ 0\to 0$），目标处编译 $1\to 2$ 给出宏后继 $2$；第 $2$ 拍在同一新根访问 $2$ 处无需再次修订，直接读出单点回答 $\ast$ 并推进至 $3$（命题 8.9，表 4）。

### 1.3 十五分钟分学科快速核验通道

本文横跨程序设计语言与增量计算、范畴论与同调代数、并发过程与余代数语义、以及依赖类型论四个领域。不同背景的审稿人与读者可按以下四条独立通道在十五分钟内直达核心定理与完整书面证明：

- **程序设计语言、数据库增量计算与可逆计算读者**：先读 §2.3（自由载体 $\mathbb{Z}[S]$ 与二元函数联合提升）$\to$ §3.1–§3.4（命题 3.3 三项更新律、**定理 3.9** 整树语法计费与常零求值下的纯语法左逆）$\to$ §8.5（**定理 8.12、8.15** 残差再询问与 $V=p+n$ 总值写回）$\to$ **§10.1–§10.3（定理 10.1–10.6，例 10.7**：双取反 $\mathrm{retainedCode}$ 同态续行、$\mathrm{stepInterval}$ 与 $\mathrm{readRequestOrigin}$ 双向切片寻址及 $\mathrm{extendTo}$ 锁前缀末态续行；完整证明见补充材料 S6，文献对照见 §10.5 轴一）。
- **范畴论、交换／同调代数与代数规格说明读者**：先读 §4.2–§4.3（**定理 4.4** 任意交换环上 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$ 双证书正合分解，附录 A.3；**定理 4.6–4.7** 逆极限完备化载体演化律，附录 B.1）$\to$ **§8.1–§8.3（定理 8.4、8.6** 零公理范畴初始余面唯一忠实态射分解与首次写入合流，附录 C.1–C.4）$\to$ §9.4 与 §10.2（**定理 9.11、10.4** 六面余链复形 $d_0 d_1=0$ 与逐原语回放链映射锁步；与制度论[[19]](#ref-19)对照见 §10.5 轴四）。
- **过程代数、余代数互模拟与形式化精化验证读者**：先读 §2.1–§2.2（**定理 2.2** 单构造子发生展开与根读安全、**命题 2.4** 固定法则后继刚性）$\to$ **§5（定义 5.1、定理 5.3** 无需历史／预言变量的共同发生唯一比较）$\to$ §9.2 与 §9.4（**定理 9.3、9.9、9.12** 全行动者恢复、全词先恢复再保序入库、以及最大未来不可见不变核 $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$；与 TLA/精化映射[[6]](#ref-6)[[7]](#ref-7)及泛余代数[[9]](#ref-9)对照见 §10.5 轴二）。
- **依赖类型论、资源逻辑与定理证明器读者**：先读 §2.1（T0 `#print axioms = []` 单构造子与非单值同构边界）$\to$ **§6.1–§6.5（命题 6.1** 生命周期三律、**定理 6.7** 无总法则 $\le\,;\,<\,;\,\le$ 良基核、**定理 6.10** 无旧承担者内生执行账、**定理 6.12** `Type` 值完成回执 $d_i=B_i$，补充 S1）$\to$ 附录 D（各批次固定 Git 提交、声明签名与 T0/T1 公理闭包清单；与 Martin-Löf 类型论[[15]](#ref-15)、HoTT[[16]](#ref-16) 及资源分离逻辑[[12]](#ref-12)[[13]](#ref-13)对照见 §10.5 轴三）。

### 1.4 文献坐标、适用边界与全文结构

**四轴文献坐标概览。** 本文在 §10.5（配合表 5）围绕四条主轴与二十四项原始文献展开逐定理对话：(1) **增量、自调整、双向变换与可逆计算**：明确复用 DBSP[[1]](#ref-1) 的 Z-集 $\mathbb{Z}[A]$ 与双线性三项增量公式及张量泛性质[[5]](#ref-5)，对照高阶语言变化理论[[2]](#ref-2)、自调整计算动态依赖图与外置 memo 表[[22]](#ref-22)、来源半环[[3]](#ref-3)、树双向透镜 $\mathrm{get}$ 与 $\mathrm{put}$[[23]](#ref-23) 及逻辑可逆图灵机[[4]](#ref-4)，推进出正合求值核、抗全零坍缩且无需旧树辅助的纯语法整树左逆、零外置缓存的双取反语法树同态复用及无需退算的执行步—请求双向区间反演；(2) **经典并发过程代数、精化映射与余代数可观测性**：对照 Milner CCS[[20]](#ref-20)、Bergstra–Klop 公理化过程代数 ACP[[21]](#ref-21)、TLA[[6]](#ref-6)、精化映射辅助变量完备性[[7]](#ref-7)、事件结构[[8]](#ref-8)、泛余代数终对象互模拟[[9]](#ref-9)与线性系统极小实现[[10]](#ref-10)，界定“源生过程代数”保留完整分叉发生树而非对非确定性选择或互模拟取商，阐明 $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$ 如何实现模线性可观测商，同时证明源同一性严格强于行为互模拟且单根比较无需预言变量；(3) **资源逻辑与类型论公理边界**：对照线性逻辑[[11]](#ref-11)、分离逻辑[[12]](#ref-12)、摊还资源分离逻辑[[13]](#ref-13)、携证代码[[14]](#ref-14)、直觉主义类型论[[15]](#ref-15)、同伦类型论单值公理[[16]](#ref-16)与 Lean 4 内核[[17]](#ref-17)，说明为何所有回执与起源置于 `Type` 且 T0 内核拒绝把载体同构直接等同于发生同一；(4) **理论修订、单纯余面算子与范畴制度论**：对照 AGM 信念收缩[[18]](#ref-18)、单纯范畴余面／余退化算子[[24]](#ref-24)与 Goguen–Burstall 制度论[[19]](#ref-19)（满足条件与保守扩充），展示根植双空破产如何内生生成零泄漏初始余面并直入新根首次整账写入。

**范围与外供假设边界。** 全文讨论**确定性单根过程**：固定权威根在每次时序访问处恰发射一个规范发生且至多具有一个合法整账演化（§5）；非确定性分支与并发冲突不在本文范围内。全文严格区分两类对象：**源或编译器内生生成的对象**（携带发生出处见证）与**定理显式接收的领域输入**。以下三项属于显式前提而非无条件结论，每处使用时均逐条标明：(i) 一般领域债务的同债良基总律（定理 6.7 证明“给定总律 $\Rightarrow$ 有限终账结清”，而 §6.5 计算责任无需该外供输入）；(ii) 有类型语义修订及其语义锚定证明（定理 8.6–8.7）；(iii) 修订后新根按定义 2.3 重新登记为源过程（一旦完成登记即可直接复用 §2.3–§4 的自由载体与完备化定理，§8.4 末）。此外，命题 3.6(3) 的语义纤维刻画与命题 7.1 的非构造性六分支分类（Lean 中标 `noncomputable`）是存在性／结构分类定理，不宣称提供可判定算法或计算复杂度上界。

**全文记号与阅读路线。** 全文固定四项标准记号：依赖和（$\Sigma$ 类型）记作 $\sum_{x:A}B(x)$，元素记作 $(x,y)$ 或 $\langle x,y\rangle$；不相交并（余积）记作 $A\sqcup B$（或 $A\oplus B$），左右注入记作 $\operatorname{inl},\operatorname{inr}$；自由 $R$-模记作 $\mathrm{Fm}_R(X)=X\to_0 R$（整数环情形记作 $\mathbb{Z}[S]$），单点基元记作 $\delta_s$；分处相等类型纤维上的异质相等记作 $\simeq$。§2 建立 T0 单构造子发生展开、源过程与自由提升；§3–§4 建立三项更新律、整树语法左逆、正合求值核与逆极限完备化；§5 证明忠实实现的唯一比较；§6 建立生命周期三律、宏步良基核、内生计算扣款与 `Type` 完成回执；§7–§8 建立依赖残差审计、T0 初始余面唯一分解、两拍修订与结清后自动再询问及总值写回；§9 建立完整时序编码、全行动者恢复、双库存跨越准入、六面复形与最大未来不变核；§10 建立全未来语义零请求、双取反同态续行、逐原语余链回放、执行步—请求双向反演与封存前缀末态续行（C46–C54），并给出三组跨领域实装与四轴文献对话；§11 总结全文。附录 A–C 给出完整技术推导，附录 D–E 给出固定源码声明索引与术语速查表，补充材料 S0–S7 给出 §6.5、§7.2 末、§8.5、§9 与 §10 全部定理的自足书面证明。

---

## 2 T0 零公理单构造子发生树与原生自由载体提升

要让一个回答归属于当次运行，底层必须先具备一种既不依赖外置算术公理、也不靠预存未来表驱动的发生结构，随后再将无需自带加法的任意领域状态无损送入线性代数载体。本节前两小节在 **T0 零公理构造性内核**（`#print axioms = []`）中建立单构造子发生树、根读无盲区恒等与源过程刚性（C3）；后两小节进入 **T1 模代数层**建立自由 $\mathbb{Z}$-模与二元原生函数的双线性提升及运行时实际见证原则（C9）。

**世界关系网络与权威根的最小记录定义。** **世界关系网络** $N$ 是由下表前三行承载类型与依值类型族构成的记录；$N$ 上的**权威根（authoritative root）**是固定词汇表、原生流、发生发射器与整账编译器的运行登记。**时序访问（visit）** $v$ 是根携带可达历史的某次访问，**发生（occurrence）**是在该访问处规范发射的依值对象。记根上当前状态为 $c$，其所在支承为 $s(c)$；下表后三行列出由根登记导出的发生与演化字段。

<!-- definition-fields:begin -->
| 字段归属 | 所用载体或依值类型族 | 结构职责 |
| --- | --- | --- |
| $N$：支承与定位 | $\mathrm{Sup}$；锚点、关联、谱系及其支承读出 | 定位发生所在支承，记录出处、连接与跨步继承身份 |
| $N$：责任与主张 | $\mathrm{Responsibility},\mathrm{Claim}$；$\mathrm{OpenAt}(s,r),\mathrm{HoldsAt}(s,a)$；开立行的主张与自然数预算 | 开立见证使责任成为活账行；成立见证使主张成为该支承上的世界事实 |
| $N$：阻滞与处置 | $\mathrm{Obs}(s)$ 及其阻滞主张；语义变化族；$\mathrm{Disposition}(s,k)$ | 记录受阻对象及整支承结清、转移或法则面扩充的依值回执 |
| 根：规范发生 | $\mathrm{Occ}_W(c)$，$g_c\in\mathrm{Occ}_W(c)$ | 将当次访问唯一锚定为其规范发射的发生对象 |
| 根：合法演化 | $\mathrm{Evol}_W(c)$，$\mathrm{Lawful}_c(g,e)$ | 在候选整体演化中标定发生 $g$ 的合法整账演化结果 $e$ |
| 根：整账编译器 | $\mathrm{comp}_c:\mathrm{Occ}_W(c)\to\mathrm{Evol}_W(c)$ | 生成整本活账写回与供后续访问使用的下一当前状态 |
<!-- definition-fields:end -->

此处 $\mathrm{OpenAt}$、$\mathrm{HoldsAt}$ 与各类处置均为携带见证的 `Type` 族而非抹平信息的命题。由权威根登记导出的**因果世界** $W$ 同时锁定两条无魔法定律：其一，单访问发生纤维单点化——任意 $g\in\mathrm{Occ}_W(c)$ 均满足 $g=g_c$；其二，合法整账演化唯一化——编译器为每个发生选出合法演化，且同一发生的任意合法演化均与之相等。这两条定律均由根编译器构造性生成而非向调用方索取（附录 D.1）。

### 2.1 零公理单构造子发生展开与根读恒等（T0）

在引入任何环、模或自然数加法之前，一次有根过程展开所需的分层因果、叶前沿推进、并／联组合与万有折叠，可以完全由**唯一一个归纳构造子**在零公理内核中派生。

**定义 2.1（单构造子有根记账发生展开）。** 设 $A$ 为任意发生标签类型。**有根记账发生展开** $\mathcal{U}(A)$ 与有序子展开表由单一互归纳构造子生成：

$$T ::= \mathrm{occur}(a,\,[T_1,\dots,T_k])\qquad (a:A,\ k\ge 0).$$

除 $\mathrm{occur}$ 外不设空树构造子、旁支合并构造子或已完成未来字段。在该单构造子之上纯递归派生以下七项运算：

1. **当步根与零前瞻观察**：$\mathrm{root}(\mathrm{occur}(a,\vec T)):=a$，当步观察 $\mathrm{observe}(T):=\mathrm{root}(T)$（仅读已生成的当前根，不含任何未发生子步）；
2. **叶前沿与全迹**：当 $\vec T=[\,]$ 时叶前沿为单点表 $\mathrm{fr}(\mathrm{occur}(a,[\,])):=[a]$；当 $\vec T\neq[\,]$ 时 $\mathrm{fr}(\mathrm{occur}(a,\vec T)):=\mathrm{fr}^*(\vec T)$ 为各子展开叶前沿的依序拼接；全迹 $\mathrm{tr}(\mathrm{occur}(a,\vec T)):=a :: \mathrm{tr}^*(\vec T)$ 按前序记录全部已发生节点；
3. **一步前沿推进**：给定前沿续生律 $\sigma:A\to\mathcal{U}(A)$，$\mathrm{adv}(T,\sigma)$ 在叶处将 $\mathrm{occur}(a,[\,])$ 替换为 $\sigma(a)$，在内部节点处保持当前根 $a$ 并递归推进各子展开；
4. **有根并列与联合组合**：对新根 $r:A$ 与两份展开 $U,V\in\mathcal{U}(A)$，定义**并列组合** $U\oplus_r V:=\mathrm{occur}(r,[U,V])$，以及将 $V$ 嫁接于 $U$ 每个叶前沿位置之上的**联合组合** $U\otimes_r V:=\mathrm{occur}\bigl(r,\,[\mathrm{adv}(U,\ x\mapsto V)]\bigr)$；叶前沿长度 $|\mathrm{fr}(T)|\in\mathbb{N}$ 称为 $T$ 的**基数阴影（cardinal shadow）**；
5. **万有折叠**：对任意目标载体 $C$、列表载体 $L$ 与代数结构 $\mathcal{A}=(f:A\to L\to C,\ e:L,\ c:C\to L\to L)$，互递归定义 $\mathrm{fold}_{\mathcal{A}}(\mathrm{occur}(a,\vec T)):=f(a,\mathrm{fold}^*_{\mathcal{A}}(\vec T))$，$\mathrm{fold}^*_{\mathcal{A}}([\,]):=e$，$\mathrm{fold}^*_{\mathcal{A}}(T::\vec T):=c(\mathrm{fold}_{\mathcal{A}}T,\mathrm{fold}^*_{\mathcal{A}}\vec T)$。

对于权威账本根 $R$ 的完整时序根发生类型 $\mathcal{E}(R)$，定义**根余面读出**为恒等映射 $\mathrm{rootRead}(o):=o$。对任意观察映射 $\pi:\mathcal{E}(R)\to O$ 与下游处分映射 $\chi:\mathcal{E}(R)\to D$，若 $\pi(o_1)=\pi(o_2)\Rightarrow\chi(o_1)=\chi(o_2)$，称 $\pi$ 对 $\chi$ **消费安全**；**隐藏空证人（hidden-null witness）**则是满足 $\pi(o_1)=\pi(o_2)$ 但 $\chi(o_1)\neq\chi(o_2)$ 的发生对 $(o_1,o_2)$。

**定理 2.2（万有折叠、前沿推进结合律与根读无盲区恒等）。** 对任意类型 $A$、展开 $T,U,V\in\mathcal{U}(A)$、续生律 $\sigma,\tau:A\to\mathcal{U}(A)$ 及权威根 $R$：

1. **非空前沿与推进结合律**：$\mathrm{fr}(T)\neq[\,]$（故 $|\mathrm{fr}(T)|\ge 1$），且前沿推进满足严格结合律与基数阴影公式
   $$\begin{aligned}\mathrm{adv}\bigl(\mathrm{adv}(T,\sigma),\tau\bigr)&=\mathrm{adv}\bigl(T,\,x\mapsto\mathrm{adv}(\sigma(x),\tau)\bigr),\\ |\mathrm{fr}(U\oplus_r V)|&=|\mathrm{fr}(U)|+|\mathrm{fr}(V)|,\qquad |\mathrm{fr}(U\otimes_r V)|=|\mathrm{fr}(U)|\cdot|\mathrm{fr}(V)|.\end{aligned}\tag{2.1}$$
   并列基数公式的公开 Lean 证明依赖 `propext`。本定理其余已列声明的公理列表为空。
2. **万有折叠唯一性**：任意满足上述节点与分支递推等式的映射对 $(g:\mathcal{U}(A)\to C,\ g^*:\mathrm{List}(\mathcal{U}(A))\to L)$ 必在每个输入上逐点等于 $(\mathrm{fold}_{\mathcal{A}},\mathrm{fold}^*_{\mathcal{A}})$。
3. **根读无盲区与已安装投影唯一分解**：$\mathrm{rootRead}(o)=o$ 对**任意**下游处分 $\chi:\mathcal{E}(R)\to D$ 均消费安全，其隐藏空证人类型严格为空类型；且 $R$ 上任一已安装子系统投影律 $\chi_{\mathrm{sub}}$ 的读出连同整账写回与下一当前状态，均通过当次访问的唯一规范根演化分解。

证明。(1) 对 $T$ 与子展开列表作互结构归纳：当 $\vec T=[\,]$ 时 $\mathrm{fr}(T)=[a]\neq[\,]$；当 $\vec T=T_1::\vec T'$ 时 $\mathrm{fr}(T)=\mathrm{fr}(T_1)\mathbin{++}\mathrm{fr}^*(\vec T')$，由归纳假设首段非空故拼接非空。结合律在叶处两边同取 $\mathrm{adv}(\sigma(a),\tau)$；在非空分支处注意 $\mathrm{adv}(T_1,\sigma)$ 仍是由 $\mathrm{occur}$ 构造的非空展开，分支非空判据保持不变，由子列表归纳假设立得。并列基数公式由列表长度对拼接可加得到；联合基数公式对 $U$ 归纳：叶处 $|\mathrm{fr}(\mathrm{adv}(\mathrm{occur}(a,[\,]),x\mapsto V))|=|\mathrm{fr}(V)|=1\cdot|\mathrm{fr}(V)|$，分支处由分配律归结为子列表之和。(2) 对 $T$ 与 $\vec T$ 互归纳，在每个构造子上用递推等式改写子项即得逐点相等，全程无需函数外延性。(3) 若 $\mathrm{rootRead}(o_1)=\mathrm{rootRead}(o_2)$，由定义即 $o_1=o_2$，故 `congrArg` 直接给出 $\chi(o_1)=\chi(o_2)$；任何隐藏空证人都携带与消费安全矛盾的不等证明，故其类型为空。已安装投影分解由规范根演化的单点相等 $e=e_{\mathrm{can}}$ 与投影嵌入的异质交换律传递得到。∎

定理 2.2 奠定了全篇的构造性起点，也划清了本文与经典并发过程代数的根本区别：在 Milner 的 CCS[[20]](#ref-20) 与 Bergstra–Klop 的 ACP[[21]](#ref-21) 中，$+$ 表示非确定性选择、$\cdot$ 表示顺序复合，并借互模拟或右分配公理 $(x+y)\cdot z=x\cdot z+y\cdot z$ 将分叉时机不同的树商化为同一行为元；而在本文的源生过程代数中，唯一构造子 $\mathrm{occur}(a,\vec T)$ 完整保留有根分叉几何，算术中的 $+$ 与 $\times$ 仅是并列组合 $\oplus_r$ 与前沿嫁接 $\otimes_r$ 在抹去树形结构后的基数阴影，隐藏空证人（“账外差异”）不可能存在于未商化的根发生本身，只能产生于丢弃维度的下游低维观察投影。

### 2.2 源过程与固定法则后继刚性（T0）

世界网络 $N$ 上的**活当前（living current）**是依值三元组 $c=(V,\mathcal{R},v)$，包含词汇表 $V$、完整活根 $\mathcal{R}$ 以及该根的一次时序访问 $v$；当前发生与单拍后继均直接从该登记读出。**擦除（erasure）**操作 $\mathrm{erase}(c)$ 仅隐去活根在发射器之前的延续律包装而保留词汇表、权威根与同一次访问 $v$。

**定义 2.3（源过程）。** $N$ 上的**源过程** $\mathcal{P}=(S,\iota,s_0,\sigma)$ 由四项数据构成：

- 无需任何代数结构假设的原生状态类型 $S$；
- 将每个状态登记为活当前的单射 $\iota:S\hookrightarrow\mathrm{Cur}(N)$；
- 初始状态 $s_0\in S$；
- 携带生成证据的单拍生成后继 $\sigma:S\to S$：满足 $\mathrm{erase}(\iota(\sigma(s)))$ 等于 $\iota(s)$ 所在根在该访问处编译生成的下一权威当前，且在非终结分支上保持同一活根。

**命题 2.4（固定法则过程后继的确定性与按需有限历史，T0）。** 设 $\mathcal{P}=(S,\iota,s_0,\sigma)$ 为源过程。则在零公理内核中：

1. $\mathrm{erase}(\iota(\sigma(s)))$ 等于 $\iota(s)$ 的根编译器在当前访问生成的下一权威当前；
2. $\iota(\sigma(s))$ 的根法则面（命名当前所遵循理论法则的根登记字段）等于 $\iota(s)$ 的根法则面；
3. 若 $\iota(s_1)=\iota(s_2)$，则 $\iota(\sigma(s_1))=\iota(\sigma(s_2))$——任何未反映在完整登记当前中的状态外参数均不可能暗中分叉下一世界；
4. 对任意有限观察视野 $n\in\mathbb{N}$ 与起点 $s\in S$，同一定律递归生成长 $n$ 的有限过程历史；视野耗尽（$n=0$）仅停止观察而不伪造世界终结处置。

证明。(1) 与 (3) 直接展开定义 2.3，其中 (3) 由单射 $\iota(s_1)=\iota(s_2)\Rightarrow s_1=s_2$ 再作用 $\iota\circ\sigma$ 即得（定义相等 `rfl`）。(2) 对 (1) 两端取根法则面投影，利用根登记自带的“编译后继保持法则面”等式即得。(4) 对自然数视野 $n$ 作结构递归：$0$ 步返回视野耗尽构造子，$n+1$ 步由 $\sigma(s)$ 的 $n$ 步历史前置一步得到。∎

命题 2.4(2) 划出一条硬边界：固定法则的源过程绝不能在局部结算或状态移交中暗藏理论修订；真正的语言升维必须走 §8 的显式初始余面构造。

### 2.3 自由 $\mathbb{Z}$-模载体与任意二元原生函数的联合提升（T1）

原生状态可能是数据库快照、棋盘格局、分子构型或证明器运行态，本身并无加法。为每个状态 $s\in S$ 保留独立基点并取有限整数线性组合，即得自由 $\mathbb{Z}$-模（Z-集[[1]](#ref-1)）$\mathbb{Z}[S]:=S\to_0\mathbb{Z}$，其中**状态点**记作 $\delta_s:=1\cdot s$。映射 $s\mapsto\delta_s$ 为单射，互异状态绝不混同；原生后继 $\sigma:S\to S$ 逐基点线性延拓为自同态 $A:\mathbb{Z}[S]\to\mathbb{Z}[S]$，满足 $A\delta_s=\delta_{\sigma(s)}$。

**命题 2.5（任意原生观察的唯一自由线性延拓）。** 设 $B$ 为任意加法阿贝尔群，$\mathrm{read}:S\to B$ 为任意原生观察映射。则存在唯一的 $\mathbb{Z}$-线性映射 $\widehat{\mathrm{read}}:\mathbb{Z}[S]\to B$ 满足 $\widehat{\mathrm{read}}(\delta_s)=\mathrm{read}(s)$，且它与源作用自然交换：

$$\widehat{\mathrm{read}}\circ A=\widehat{\mathrm{read}\circ\sigma}.\tag{2.2}$$

证明。由自由模泛性质给出：在全部基点 $\delta_s$ 上取值相等的两个线性映射在有限支撑和上逐项相等，故唯一；按系数线性求和即得存在性。式 (2.2) 两端在任意基点 $\delta_s$ 上均取值 $\mathrm{read}(\sigma(s))$，由唯一性在全载体上成立，无需值群 $B$ 自带独立演化算子。∎

当计算同时消费两个输入（如乘法、表连接、路径拼接或算符配对）时，不仅要提升单侧状态，还必须保留左右输入的配对关系。给定任意类型 $X,Y,Z$ 与原生二元函数 $f:X\to Y\to Z$：

**定义 2.6（联合自由提升）。** **联合映射** $\mathrm{joint}:\mathbb{Z}[X]\to\mathbb{Z}[Y]\to\mathbb{Z}[X\times Y]$ 是由 $\mathrm{joint}(\delta_x,\delta_y)=\delta_{(x,y)}$ 唯一确定的双加性映射；**前推映射** $\mathrm{push}_f:\mathbb{Z}[X\times Y]\to\mathbb{Z}[Z]$ 是由 $(x,y)\mapsto\delta_{f(x,y)}$ 唯一确定的线性延拓；$f$ 的**自由双线性提升**定义为复合 $\mathrm{lift}(f):=\mathrm{push}_f\circ\mathrm{joint}$。

此构造利用张量积泛性质[[5]](#ref-5)，但显式区分**独立配对** $\mathrm{joint}(u,v)$ 与**已关联联合库存** $w\in\mathbb{Z}[X\times Y]$：当 $x\neq x',y\neq y'$ 时，关联和 $\delta_{(x,y)}+\delta_{(x',y')}$ 直接进入 $\mathrm{push}_f$，而不可能写成任何独立配对 $\mathrm{joint}(u,v)$（后者必同时带出交叉项 $(x,y')$ 与 $(x',y)$）。§7 的依值配对树正是处理此类已关联联合材料。

**命题 2.7（基点读回与完整三项增量展开）。** 取三类集合 $\{\text{left},\text{right},\text{result}\}$（值载体依次为 $\mathbb{Z}[X],\mathbb{Z}[Y],\mathbb{Z}[Z]$），设基点环境 $\rho^\delta$ 将左右变量分别映为 $\delta_x,\delta_y$，令原生表达式为 $e_{f,x,y}:=\mathrm{bilinear}_{\mathrm{lift}(f)}(\mathrm{var}\,x,\mathrm{var}\,y)$（语法见定义 3.1）。则：

1. $\mathrm{ev}_{\rho^\delta}(e_{f,x,y})=\delta_{f(x,y)}$，且 $\mathrm{lift}(f)(\delta_x,\delta_y)=\delta_{f(x,y)}$；
2. 对任意增量环境 $\varepsilon=(\varepsilon_x,\varepsilon_y)$，更新值精确展开为四项之和：
   $$\mathrm{ev}_{\rho^\delta+\varepsilon}(e_{f,x,y})=\delta_{f(x,y)}+\mathrm{lift}(f)(\delta_x,\varepsilon_y)+\mathrm{lift}(f)(\varepsilon_x,\delta_y)+\mathrm{lift}(f)(\varepsilon_x,\varepsilon_y).\tag{2.3}$$

证明。(1) 在基点上直接展开 $\mathrm{push}_f(\mathrm{joint}(\delta_x,\delta_y))=\mathrm{push}_f(\delta_{(x,y)})=\delta_{f(x,y)}$。(2) 由双加性展开 $\mathrm{lift}(f)(\delta_x+\varepsilon_x,\delta_y+\varepsilon_y)$（即下节命题 3.3 在该双线性节点上的特例）。∎

注意式 (2.3) 对字符串拼接、哈希查表或离散组合映射等**毫无可微性或原生线性结构**的函数 $f$ 同样精确成立：右单改、左单改与双侧共改三项由自由模双线性提升自动分离。

### 2.4 实际见证原则：状态读数取自运行，绝不从数值反解

将一次单拍转移连同其发生、整账与后继的完整登记称为一**拍（tick）**。在值载体为 $\mathbb{Z}[S]$ 的单类语言中，记 $s_k:=\sigma^k(s_0)$，源词 $\mathrm{var}$ 与作用词 $\mathrm{linear}_A(\mathrm{var})$ 在第 $i$ 有限阶段读出的（旧值，效应）对分别为 $(\delta_{s_i},\,\delta_{s_{i+1}}-\delta_{s_i})$ 与 $(\delta_{s_{i+1}},\,\delta_{s_{i+2}}-\delta_{s_{i+1}})$。作用词旧值分量中的状态点 $\delta_{s_{i+1}}$ 直接由下一运行态 $\sigma^{i+1}(s_0)$ 作见证；对无需加法的任意原生读出 $h:S\to B$，同样先在该实际运行态上取 $h(s_{i+1})$，再由 $\Sigma$ 类型携带它与自由观察像一致的等式证明（附录 A.1）。这就是贯穿全文的**实际见证原则**：一切状态点与原生读出均顺向取自已生成的运行态，绝不从线性组合或观测读数逆向猜测底层状态。

---

## 3 双线性三项增量、可重放推导与整树纯语法左逆

本节把更新前后的变化写成由表达式结构逐节点生成的**效应（effect）**，给出保留位置与重数的混合项分解及 `Type` 值可重放归约推导（C7），进而将归约展开为逐步计费的执行迹，证明任意有根树生成的整树程序兼具精确语法计费与不经求值的纯语法左逆（C23）。

### 3.1 多类异质表达式与三项效应方程

**定义 3.1（异质代数表达式与求值）。** 设 $\mathcal{K}$ 为类别（sort）集合，每个类别 $\kappa\in\mathcal{K}$ 配有加法阿贝尔群值载体 $V(\kappa)$ 与变量集 $\mathrm{Var}(\kappa)$。类别 $\kappa$ 的**表达式** $e\in\mathrm{Expr}(\kappa)$ 由归纳语法生成：

$$e ::= \mathrm{var}\,x \mid \mathrm{const}\,c \mid e_1+e_2 \mid \mathrm{linear}_h(e) \mid \mathrm{bilinear}_\mu(e_1,e_2),$$

其中 $h:V(\kappa_1)\to V(\kappa)$ 为加法群同态，$\mu:V(\kappa_1)\to V(\kappa_2)\to V(\kappa)$ 为双加性映射。环境 $\rho$ 为每个类别的每个变量指定 $V(\kappa)$ 中的值，求值映射 $\mathrm{ev}_\rho:\mathrm{Expr}(\kappa)\to V(\kappa)$ 按标准结构递归定义。语法树完整保留全部中间类别与源算子，不预先作任何商化或范式合并。

**定义 3.2（结构效应）。** 给定旧环境 $\rho$ 与增量环境 $\varepsilon$，表达式 $e$ 的**效应** $\mathrm{eff}_{\rho,\varepsilon}(e)$ 递归定义为：$\mathrm{eff}_{\rho,\varepsilon}(\mathrm{var}\,x)=\varepsilon(x)$，$\mathrm{eff}_{\rho,\varepsilon}(\mathrm{const}\,c)=0$，加法与线性节点逐子项递归，双线性节点完整保留左旧右增、左增右旧与双增三项[[1]](#ref-1)：

$$\mathrm{eff}_{\rho,\varepsilon}\bigl(\mathrm{bilinear}_\mu(e_1,e_2)\bigr):=\mu\bigl(\mathrm{ev}_\rho e_1,\mathrm{eff}_{\rho,\varepsilon}e_2\bigr)+\mu\bigl(\mathrm{eff}_{\rho,\varepsilon}e_1,\mathrm{ev}_\rho e_2\bigr)+\mu\bigl(\mathrm{eff}_{\rho,\varepsilon}e_1,\mathrm{eff}_{\rho,\varepsilon}e_2\bigr).\tag{3.1}$$

**命题 3.3（精确更新等式）。** 对任意类别 $\kappa$、表达式 $e\in\mathrm{Expr}(\kappa)$ 及环境 $\rho,\varepsilon$：

$$\mathrm{ev}_{\rho+\varepsilon}(e)=\mathrm{ev}_\rho(e)+\mathrm{eff}_{\rho,\varepsilon}(e).\tag{3.2}$$

证明。对 $e$ 作结构归纳。变量处 $(\rho+\varepsilon)(x)=\rho(x)+\varepsilon(x)$，常量处 $c=c+0$；加法利用阿贝尔群交换结合律重排四项，线性节点利用同态加性 $h(a+b)=h(a)+h(b)$；双线性节点由归纳假设将 $\mu(\mathrm{ev}_\rho e_1+\mathrm{eff}_{\rho,\varepsilon}e_1,\ \mathrm{ev}_\rho e_2+\mathrm{eff}_{\rho,\varepsilon}e_2)$ 经双加性完全展开为四项，首项为 $\mu(\mathrm{ev}_\rho e_1,\mathrm{ev}_\rho e_2)$，其余三项之和恰为式 (3.1)，缺一不可。∎

### 3.2 保序保重数的混合项表

求和后的总效应值可能因正负抵消而掩盖中间发生的变化。为实现逐项核查，我们进一步把效应拆成保留语法遍历顺序与重数的显式列表。

**定义 3.4（有序混合项表）。** 表达式 $e$ 在 $(\rho,\varepsilon)$ 下的**混合项表** $\mathrm{mix}_{\rho,\varepsilon}(e)\in\mathrm{List}(V(\kappa))$ 递归定义为：变量取单元素表 $[\varepsilon(x)]$；常量取空表 $[\,]$；加法取左右子表的拼接 $\mathrm{mix}(e_1)\mathbin{++}\mathrm{mix}(e_2)$；线性节点对子表逐项作用 $h$；双线性节点依次拼接三段列表——右增量段 $[y\mapsto\mu(\mathrm{ev}_\rho e_1,y)](\mathrm{mix}(e_2))$、左增量段 $[x\mapsto\mu(x,\mathrm{ev}_\rho e_2)](\mathrm{mix}(e_1))$ 以及笛卡尔积交叉段 $[(x,y)\mapsto\mu(x,y)](\mathrm{mix}(e_1)\times_{\mathrm{list}}\mathrm{mix}(e_2))$。

**命题 3.5（混合项表精确求和）。** 对任意表达式 $e$ 与环境 $\rho,\varepsilon$，混合项表元素之和严格等于效应：$\sum\mathrm{mix}_{\rho,\varepsilon}(e)=\mathrm{eff}_{\rho,\varepsilon}(e)$。

证明。对 $e$ 作结构归纳。前四类节点直接由列表和的可加性与加法同态保持求和得出。双线性节点分三段求和：右增量段由右加性提出为 $\mu(\mathrm{ev}_\rho e_1,\sum\mathrm{mix}(e_2))$，左增量段由左加性提出为 $\mu(\sum\mathrm{mix}(e_1),\mathrm{ev}_\rho e_2)$，笛卡尔积段对左表作列表归纳并反复应用双加性化为 $\mu(\sum\mathrm{mix}(e_1),\sum\mathrm{mix}(e_2))$；代入归纳假设后三段之和恰等于式 (3.1)。∎

### 3.3 `Type` 中的可重放推导：归约生成与语义纤维刻画

效应记录“变了多少”，**推导（derivation）**则记录“两式为何相等”的具体变换路径。固定环境 $\rho$，推导 $d:e\vdash_\rho e'$ 是定义在 `Type`（而非抹平见证的 `Prop`）中的归纳对象，由自反、对称、传递、变量绑定（$\mathrm{var}\,x\vdash_\rho\mathrm{const}(\rho(x))$）、三条常量收缩规则（常量加、线性常量、双线性常量）及三条对应语法节点的同余规则生成。因 $d$ 居于 `Type`，后续构造可直接对其归纳、替换、拼接并提取每一步的端点差。

**命题 3.6（归约生成与语义纤维刻画）。** 对任意环境 $\rho$ 与同类别表达式 $e,e'$：

1. **健全性**：若存在 $d:e\vdash_\rho e'$，则 $\mathrm{ev}_\rho(e)=\mathrm{ev}_\rho(e')$；
2. **内生归约**：每个表达式 $e$ 无需外供范式器或语义等式，即可结构递归生成归约推导 $\mathrm{norm}_\rho(e):e\vdash_\rho\mathrm{const}(\mathrm{ev}_\rho(e))$；
3. **语义纤维刻画**：推导类型 $(e\vdash_\rho e')$ 非空当且仅当 $\mathrm{ev}_\rho(e)=\mathrm{ev}_\rho(e')$。

证明。(1) 对 $d$ 结构归纳，每条常量规则均为定义相等。(2) 对 $e$ 递归：变量取绑定规则，常量取自反，复合节点先由同余规则将子式归约为常量，再接当节点常量收缩规则。(3) 必要性即 (1)；充分性将 $\mathrm{norm}_\rho(e)$、沿等式 $\mathrm{ev}_\rho(e)=\mathrm{ev}_\rho(e')$ 的常量搬运与对称逆推导 $(\mathrm{norm}_\rho(e'))^{-1}$ 串联即得。∎

### 3.4 整树程序：逐步语法计费与抗全零坍缩的纯语法左逆

推导允许可逆对称步，而真实计算必须按不可倒退的原语步逐一计费。定义表达式 $e$ 的**剩余原语步数** $r(e)\in\mathbb{N}$ 为：

$$\begin{aligned}r(\mathrm{var}\,x)&=1,\quad r(\mathrm{const}\,c)=0,\quad r(\mathrm{linear}_h e)=r(e)+1,\\ r(e_1+e_2)&=r(e_1)+r(e_2)+1,\quad r\bigl(\mathrm{bilinear}_\mu(e_1,e_2)\bigr)=r(e_1)+r(e_2)+1.\end{aligned}$$

一步**执行步（execution step）**是在任意语法同余位置上施行一次原语归约（变量绑定或三条常量运算之一）；有限条首尾相接的执行步构成一条**执行迹（execution trace）**。

**命题 3.7（逐步计费执行迹）。** 对任意环境 $\rho$ 与表达式 $e$：

1. 每一步执行步使剩余原语步数严格减 $1$（$r(e'')=r(e')-1$）；常量无执行步，单步执行关系良基；
2. 按自左向右后序遍历存在唯一标准执行迹 $\mathrm{exec}_\rho(e):e\to\mathrm{const}(\mathrm{ev}_\rho e)$，其长度恰为 $|\mathrm{exec}_\rho(e)|=r(e)$；
3. 每条执行迹均可规范提升为 §3.3 的推导对象，其步级关系像伸缩求和为端点差 $e-\mathrm{const}(\mathrm{ev}_\rho e)$。

证明。(1) 对单步关系归纳：四条根部原语规则将剩余步数 $1$ 化为 $0$，同余规则使受改子式减 $1$ 而其余子式不变；到 $(\mathbb{N},<)$ 的严格下降保证良基。(2) 对 $e$ 结构递归：依次拼接左子迹、右子迹及根部单步，长度累加恰得 $r(e)$。(3) 每个单步均为推导生成元，首尾拼接对应传递律与差项伸缩抵消。∎

现在将第 2.1 节的单构造子有根树送入这套计费语言，给出区分“数值读数”与“源对象”最锋利的定理。

**定义 3.8（有根树与整树程序）。** 给定根标签集 $\mathrm{Root}$、目标载体 $C$ 与任意**构造子函数** $\kappa:\mathrm{Root}\to\mathrm{List}(C)\to C$，有根树 $T=\mathrm{occ}(a;[T_1,\dots,T_k])$（此处及下文将单构造子 $\mathrm{occur}$ 简记作 $\mathrm{occ}$）的折叠值记为 $\mathrm{fold}_\kappa(T)=\kappa(a,[\mathrm{fold}_\kappa T_1,\dots,\mathrm{fold}_\kappa T_k])$。取三类集合 $\{\text{root},\text{result},\text{children}\}$（值载体分别为 $\mathbb{Z}[\mathrm{Root}],\mathbb{Z}[C],\mathbb{Z}[\mathrm{List}(C)]$；仅 $\text{root}$ 类设变量，基点环境 $\delta$ 将变量 $a$ 映为 $\delta_a$）。互递归定义**整树程序** $\mathrm{prog}_\kappa(T)$、**子树表程序** $\mathrm{kids}_\kappa(\vec T)$ 与**树语法预算** $\beta(T)$：

$$\begin{aligned}
\mathrm{prog}_\kappa\bigl(\mathrm{occ}(a;\vec T)\bigr)&:=\mathrm{bilinear}_{\mathrm{lift}(\kappa)}\bigl(\mathrm{var}\,a,\ \mathrm{kids}_\kappa(\vec T)\bigr),\\
\mathrm{kids}_\kappa([\,]):=\mathrm{const}(\delta_{[\,]}),\qquad
\mathrm{kids}_\kappa(T::\vec T)&:=\mathrm{bilinear}_{\mathrm{lift}(\mathrm{cons})}\bigl(\mathrm{prog}_\kappa T,\ \mathrm{kids}_\kappa(\vec T)\bigr),\\
\beta\bigl(\mathrm{occ}(a;\vec T)\bigr):=2+\beta^*(\vec T),\qquad \beta^*([\,])&:=0,\qquad \beta^*(T::\vec T):=\beta(T)+\beta^*(\vec T)+1.
\end{aligned}\tag{3.3}$$

**定理 3.9（整树程序执行、语法计费与纯语法左逆）。** 对任意根标签集 $\mathrm{Root}$、载体 $C$、构造子函数 $\kappa:\mathrm{Root}\to\mathrm{List}(C)\to C$ 及有根树 $T$：

1. **精确求值**：$\mathrm{ev}_\delta(\mathrm{prog}_\kappa T)=\delta_{\mathrm{fold}_\kappa T}$；
2. **纯语法计费**：$r(\mathrm{prog}_\kappa T)=\beta(T)$，故标准执行迹 $\mathrm{exec}_\delta(\mathrm{prog}_\kappa T)$ 长度恰为 $\beta(T)$，仅取决于树形拓扑而与 $\kappa$ 及其取值无关，迹端点差为 $\mathrm{prog}_\kappa T-\mathrm{const}(\delta_{\mathrm{fold}_\kappa T})$；
3. **不经求值的纯语法左逆**：存在仅检查语法节点与类别标签、从不调用 $\kappa$ 或求值器的偏解析函数 $\mathrm{read}:\mathrm{Expr}(\text{result})\rightharpoonup\mathcal{U}(\mathrm{Root})$，满足 $\mathrm{read}(\mathrm{prog}_\kappa T)=T$；特别地，$\mathrm{prog}_\kappa$ 对任意 $\kappa$ 均为单射；
4. **抗全零坍缩反例对照**：取 $C=\mathbb{Z}$ 且令 $\kappa\equiv 0$ 恒取零，则**所有**有根树均执行到同一个状态点 $\delta_0$，外显读数彻底不可区分；但 $\mathrm{prog}_0$ 依然单射，且 $\mathrm{read}$ 从每份程序精确还原整棵原树。

证明。对有根树 $T$ 与子树列表 $\vec T$ 作互结构归纳。(1) 由命题 2.7(1) 基点读回 $\mathrm{lift}(\kappa)(\delta_a,\delta_{\vec c})=\delta_{\kappa(a,\vec c)}$ 与 $\mathrm{lift}(\mathrm{cons})(\delta_c,\delta_{\vec c})=\delta_{c::\vec c}$ 配合归纳假设立得。(2) 每个树节点含 $1$ 个变量节点与 $1$ 个双线性节点（共 $+2$），空表常量计 $0$，每延长一项子树增加 $1$ 个双线性 `cons` 节点（$+1$），与 $\beta,\beta^*$ 递推完全一致。(3) 在 $\text{result}$ 类上，$\mathrm{read}$ 仅接受左类别为 $\text{root}$ 且左子式为 $\mathrm{var}\,a$、右类别为 $\text{children}$ 的双线性节点，读出根标签 $a$ 并递归解析右子式；在 $\text{children}$ 类上，将常量读为空表，将左类别为 $\text{result}$、右类别为 $\text{children}$ 的双线性节点递归解析为列表首尾。互归纳即得 $\mathrm{read}(\mathrm{prog}_\kappa T)=T$，左逆存在直接蕴含 $\mathrm{prog}_\kappa$ 单射。(4) 将 $\kappa\equiv 0$ 代入 (1) 与 (3) 即得。∎

定理 3.9(4) 与开篇三拍反例形成精准镜像：三拍反例中局部读数相等但源词不同；此处所有树的求值读数恒同为 $\delta_0$，源程序却单射保存并交回完整生成树。读数可以抹平一切，源对象绝不遗忘。

---

## 4 自由模正合求值核与逆极限完备化历史

要回答跨越多拍的同一性问题，必须同时解决两件事：其一，单拍之内哪些代数关系构成完备的相等证书（§4.2）；其二，多拍之间兼容的有限前缀如何拼成携带统一演化律的完整历史载体（§4.3–§4.4）。自本节起，设 $R$ 为任意交换环，每个类别的值载体 $V(\kappa)$ 均为 $R$-模。

### 4.1 两个精确反例：局部同读伪拼接与旧关系跨拍失效

取单类别、值模 $\mathbb{Z}$ 与单变量 $x$，候选词 $0$、$x$ 与 $x^2-x$（即 $x\cdot x+(-1)\cdot x$）在不同环境下的读数汇总于表 1。

**例 4.1（局部见证无法拼接为共同源历史）。** 在三拍环境序列 $x\mapsto 1\to x\mapsto 0\to x\mapsto 1$ 中：(1) 首段 $1\to 0$ 上零词 $w=0$ 实现读数 $0\to 0$；(2) 次段 $0\to 1$ 上变量词 $w=x$ 实现读数 $0\to 1$；(3) 两段在中间共享环境 $x\mapsto 0$ 处读数同为 $0$；(4) 但不存在任何形式源词 $w$ 同时满足 $\mathrm{ev}_1(w)=0,\ \mathrm{ev}_0(w)=0,\ \mathrm{ev}_1(w)=1$，因首末两式在同一求值映射下导出 $0=1$（附录 B.2）。

**例 4.2（旧阶段求值核关系在环境更新后失效）。** 在环境 $x\mapsto 1$ 下，$\mathrm{ev}_1(x^2-x)=1-1=0$，故 $x^2-x\in\ker(\mathrm{ev}_1)$；当环境更新为 $x\mapsto 2$ 后，$\mathrm{ev}_2(x^2-x)=4-2=2\neq 0$，即 $\ker(\mathrm{ev}_1)\not\subseteq\ker(\mathrm{ev}_2)$。在 $x\mapsto 1$ 下 $x^2-x$ 与 $0$ 读数相等，更新后分离为 $2$ 与 $0$。

**表 1 候选词在各环境下的读数对照表。** 行对应候选源词，列对应环境赋值，单元格为求值读数。

| 候选词 $\setminus$ 环境 | $x\mapsto 1$ | $x\mapsto 0$ | $x\mapsto 2$ |
| --- | --- | --- | --- |
| $0$ | $0^{\otimes,\dagger}$ | $0^{\dagger}$ | $0^{\ddagger}$ |
| $x$ | $1^{\otimes,\dagger}$ | $0^{\dagger}$ | $2$ |
| $x^2-x$ | $0$ | $0$ | $2^{\ddagger}$ |

表中三组记号分别锁定三项机制：$\otimes$ 标出例 4.1 首末同在 $x\mapsto 1$ 列却要求同时命中 $0$ 与 $1$ 的矛盾；$\dagger$ 标出两段局部正确且在 $x\mapsto 0$ 列同取 $0$ 的假相容；$\ddagger$ 标出例 4.2 在 $x\mapsto 1$ 列同取 $0$ 而在 $x\mapsto 2$ 列分离的关系失效。

### 4.2 双证书正合求值核定理

**定义 4.3（形式源词与双族关系指标）。** 类别 $\kappa$ 上的**形式词**（用作跨拍历史见证时称**源词**）定义为表达式的有限 $R$-线性组合 $\mathrm{Fm}_R(\kappa):=\mathrm{Expr}(\kappa)\to_0 R$，求值线性延拓为 $R$-模同态 $\mathrm{ev}_\rho:\mathrm{Fm}_R(\kappa)\to V(\kappa)$。固定环境 $\rho$，**关系指标类型**定义为两族可核验证据的不相交并：

$$\mathrm{RelIdx}(\rho,\kappa):=\Bigl(\sum_{e,e'\in\mathrm{Expr}(\kappa)}(e\vdash_\rho e')\Bigr)\ \sqcup\ \mathrm{SclIdx}(\kappa),$$

其中左支为**推导证据**，将 $(e,e',d)$ 映为端点形式差 $\delta_e-\delta_{e'}$；右支为值载体 $V(\kappa)$ 上的**标量模律证据**，由加法关系 $(v,v')\mapsto\delta_{\mathrm{const}(v)}+\delta_{\mathrm{const}(v')}-\delta_{\mathrm{const}(v+v')}$ 与环标量作用关系 $(r,v)\mapsto\delta_{\mathrm{const}(r\cdot v)}-r\,\delta_{\mathrm{const}(v)}$ 组成。按系数 $R$-线性延拓即得**关系映射** $\mathrm{rel}_\rho:\mathrm{Fm}_R(\mathrm{RelIdx}(\rho,\kappa))\to\mathrm{Fm}_R(\kappa)$。

**定理 4.4（关系像恰等于求值核：三项正合表现）。** 对任意交换环 $R$、任意 $R$-模值载体族 $V$、任意环境 $\rho$ 及每个类别 $\kappa$，关系映射的像精确等于求值同态的核：

$$\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho),\qquad \mathrm{Fm}_R\bigl(\mathrm{RelIdx}(\rho,\kappa)\bigr)\xrightarrow{\ \mathrm{rel}_\rho\ }\mathrm{Fm}_R(\kappa)\xrightarrow{\ \mathrm{ev}_\rho\ }V(\kappa)\longrightarrow 0\ \text{正合}.\tag{4.1}$$

证明。正向包含 $\operatorname{range}(\mathrm{rel}_\rho)\subseteq\ker(\mathrm{ev}_\rho)$ 逐生成元核验：由命题 3.6(1) 推导端点求值相等 $\mathrm{ev}_\rho(\delta_e-\delta_{e'})=0$，两类模律生成元经 $\mathrm{ev}_\rho$ 求值后亦恒为零，线性延拓即落入核中。反向包含 $\ker(\mathrm{ev}_\rho)\subseteq\operatorname{range}(\mathrm{rel}_\rho)$ 分两步显式构造证书（无需对推导见证作非构造选证，因归约推导已由命题 3.6(2) 在 `Type` 中直接构造；完整细节见附录 A.3 与图 S1）：设 $w=\sum_i a_i\delta_{e_i}\in\ker(\mathrm{ev}_\rho)$，记 $v_i=\mathrm{ev}_\rho(e_i)$，令逐项求值后的常量形式和为 $q=\sum_i a_i\delta_{\mathrm{const}(v_i)}$。第一步，对每个支撑项 $e_i$ 取命题 3.6(2) 内生生成的归约推导 $\mathrm{norm}_\rho(e_i):e_i\vdash_\rho\mathrm{const}(v_i)$，按系数 $a_i$ 合成**推导证书** $c_{\mathrm{der}}$，满足 $\mathrm{rel}_\rho(c_{\mathrm{der}})=w-q$。第二步，因 $\sum_i a_i v_i=\mathrm{ev}_\rho(w)=0$，形式和 $q_0=\sum_i a_i\delta_{v_i}\in R[V(\kappa)]$ 落入自由模求值核；而 $R[V(\kappa)]$ 商去加法与标量作用两族模律子模后经 $[x]\mapsto\mathrm{eval}(x)$ 与 $v\mapsto[\delta_v]$ 给出互逆 $R$-线性同构，故 $q_0$ 在商中为零，从而存在**标量模律证书** $c_{\mathrm{scl}}$ 使 $\mathrm{rel}_\rho(c_{\mathrm{scl}})=q$。合并两份证书即得 $\mathrm{rel}_\rho(c_{\mathrm{der}}+c_{\mathrm{scl}})=(w-q)+q=w$。满射性由任意 $v\in V(\kappa)$ 取原像 $\delta_{\mathrm{const}(v)}$ 给出。∎

![图 S1 求值核的双证书正合分解](figures/vector/supp1-two-certificates-kernel.png)

**图注**。图 S1｜求值核的双证书正合分解（证明结构图；定理 4.4，附录 A.3）。设 $q_\rho(w)$ 为逐表达式求值后的常量形式和。归约推导给出关系像 $w-q_\rho(w)$；当 $\mathrm{ev}_\rho(w)=0$ 时，模律关系给出剩余 $q_\rho(w)$ 的标量证书，两份证书相加（朱砂）得到精确关系像 $w$，给出反向包含；正向包含逐条验证证据求值为零。

注意命题 3.7 的每条执行迹 $t:e\to\mathrm{const}(\mathrm{ev}_\rho e)$ 已把第一份推导证书按原语步逐项拆开，其总关系像恰为 $\delta_e-\delta_{\mathrm{const}(\mathrm{ev}_\rho e)}\in\ker(\mathrm{ev}_\rho)$；当环境叠加上增量 $\varepsilon$ 时，该旧证书在新求值映射 $\mathrm{ev}_{\rho+\varepsilon}$ 下的读数恰等于效应 $\mathrm{eff}_{\rho,\varepsilon}(e)$。这一恒等式将在 §6.5、§8.5 与 §10.1 中反复充当“已付收据转化为下一问”的代数枢轴。

### 4.3 逆极限完备化载体与逐元素演化方程

固定源过程 $\mathcal{P}=(S,\iota,s_0,\sigma)$、加法材料群 $M$、材料读出 $\mathrm{mat}:S\to M$ 与加性环境投影 $\pi:M\to\mathrm{Env}$。对起始运行态 $s$ 与拍号 $i\in\mathbb{N}$，记 $s_i:=\sigma^i(s)$、旧环境 $\rho_i:=\pi(\mathrm{mat}(s_i))$、单拍增量 $\varepsilon_i:=\rho_{i+1}-\rho_i$。

**定义 4.5（阶段库存、前缀商塔与完备化载体）。** 源词 $w\in\mathrm{Fm}_R(\kappa)$ 在第 $i$ 拍的**阶段库存**定义为成对读出

$$U_i^s(w):=\bigl(\mathrm{ev}_{\rho_i}(w),\ \mathrm{eff}_{\rho_i,\varepsilon_i}(w)\bigr)\in V(\kappa)\times V(\kappa).\tag{4.2}$$

给定视野上界 $b\in\mathbb{N}$，长 $b+1$ 的**前缀读数**为 $\mathrm{pre}_b^s(w):=(U_0^s(w),\dots,U_b^s(w))$，相应余像商模记作**阶段商** $Q_b(s):=\mathrm{Fm}_R(\kappa)/\ker(\mathrm{pre}_b^s)$。删去末拍 $U_{b+1}^s$ 给出固定起点的**前缀限制映射** $r_b^s:Q_{b+1}(s)\to Q_b(s)$；沿限制塔 $(Q_b(s),r_b^s)_{b\in\mathbb{N}}$ 所取的逆极限定义为**历史完备化载体** $\widehat C(s):=\varprojlim_b Q_b(s)$，带规范投影 $\mathrm{pr}_b^s:\widehat C(s)\to Q_b(s)$ 与源词典范映射 $w\mapsto[w]_s$。另一方面，因 $\sigma(s)$ 的第 $i$ 拍恰为 $s$ 的第 $i+1$ 拍，删去首拍 $U_0^s$ 给出改变起点的**起点推进映射** $d_b^s:Q_{b+1}(s)\to Q_b(\sigma(s))$；它与限制映射可交换（$r_b^{\sigma(s)}\circ d_{b+1}^s=d_b^s\circ r_{b+1}^s$），故在逆极限上唯一诱导 $R$-线性**完备化后继算子** $T:\widehat C(s)\to\widehat C(\sigma(s))$，满足 $\mathrm{pr}_b^{\sigma(s)}\circ T=d_b^s\circ\mathrm{pr}_{b+1}^s$ 及 $T([w]_s)=[w]_{\sigma(s)}$（图 3）。

**定理 4.6（完备化纤维的逐拍关系充要刻画）。** 两个源词 $u,v\in\mathrm{Fm}_R(\kappa)$ 在完备化载体 $\widehat C(s)$ 中具有相同像（$[u]_s=[v]_s$），当且仅当对**每一拍** $i\in\mathbb{N}$，配对提升词 $\widetilde{u-v}$（附录 A.2）落入当拍配对环境的关系像：

$$[u]_s=[v]_s \quad\Longleftrightarrow\quad \forall i\in\mathbb{N},\ \ \widetilde{u-v}\in\operatorname{range}\bigl(\mathrm{rel}_{(\rho_i,\varepsilon_i)}\bigr).\tag{4.3}$$

证明。逆极限中元素相等充要于每个有限阶段商 $Q_b(s)$ 中的投影相等，即对一切 $i\ge 0$ 有 $U_i^s(u-v)=(0,0)$。由附录 A.2 配对语言求值恒等式 $\mathrm{ev}_{(\rho_i,\varepsilon_i)}(\widetilde w)=U_i^s(w)$，该条件等价于 $\widetilde{u-v}\in\ker(\mathrm{ev}_{(\rho_i,\varepsilon_i)})$；对配对语言在每拍环境 $(\rho_i,\varepsilon_i)$ 处应用定理 4.4 即得式 (4.3)。∎

**定理 4.7（完备化载体的逐元素演化等式）。** 对完备化载体 $\widehat C(s)$ 中的**任意元素** $z$（无需假定 $z$ 来自单个源词的典范像）及任意有限阶段视野的每一拍 $i$：

$$\mathrm{old}_i\bigl(T(z)\bigr)=\mathrm{old}_i(z)+\mathrm{eff}_i(z),\tag{4.4}$$

其中 $\mathrm{old}_i,\mathrm{eff}_i$ 分别读出第 $i$ 拍阶段库存的第一、第二坐标。

证明。先在任意源词 $w$ 上核验：由命题 3.3 与 $\rho_i+\varepsilon_i=\rho_{i+1}$，有 $\mathrm{ev}_{\rho_{i+1}}(w)=\mathrm{ev}_{\rho_i}(w)+\mathrm{eff}_{\rho_i,\varepsilon_i}(w)$。固定需要读出的拍号 $i$，取有限窗口 $b=i+1$：因商投影 $\mathrm{Fm}_R(\kappa)\twoheadrightarrow Q_{i+1}(s)$ 为满同态，完备化元素 $z$ 的有限坐标 $\mathrm{pr}_{i+1}^s(z)\in Q_{i+1}(s)$ 必有某有限阶段代表词 $w_{(i+1)}$（无需跨无穷阶段公共选词！）。利用 $\mathrm{pr}_i^{\sigma(s)}(Tz)=d_i^s(\mathrm{pr}_{i+1}^s(z))$ 将左端读回为 $w_{(i+1)}$ 在第 $i+1$ 拍的旧值，代入上述源词更新等式即得式 (4.4)（完整推导见附录 B.1）。∎

![图 3 前缀截断与起点推进](figures/vector/figure3-prefix-tower-and-shift.png)

**图注**。图 3｜前缀截断与起点推进（结构图；定义 4.5，定理 4.6–4.7）。A：同起点限制映射 $r_b^s:Q_{b+1}(s)\to Q_b(s)$ 删去末拍，完备化载体 $\widehat C(s)$ 是沿该族限制取的逆极限。B：推进映射 $d_b^s:Q_{b+1}(s)\to Q_b(\sigma(s))$ 删去首拍（朱砂虚线框）并推进起点，在逆极限上诱导线性后继 $T$；两族映射作用于有限窗口的不同端，定理 4.7 的演化等式覆盖 $\widehat C(s)$ 的每个元素 $z$，无需假定 $z$ 来自单个源词。

### 4.4 保持共同源词的前缀延拓

**命题 4.8（保持共同源词的前缀见证延拓）。** 固定起始推进深度与视野上界 $b$，设源词 $w$ 为前缀点 $p=\mathrm{pre}_b^s(w)$ 的源词见证。则**同一个源词** $w$ 直接给出视野 $b+1$ 的延拓见证 $p^+=\mathrm{pre}_{b+1}^s(w)$：删去新增末拍限制回 $p$，且新增末拍所激活的运行态严格等于原 $b$-视野历史的目标运行态，全程无需由旧读数点作任何选词反演。∎

证明。保持同一源词 $w$ 向后多读一拍，限制投影按定义还原前 $b+1$ 拍读数 $p$，末拍运行态按定义等于 $\sigma^{b+1}(s)$，与原历史目标拍一致。该延拓在算术 Fock 运行时中连同有效载荷、粒子—波读出、整账写回与下一当前逐字段对齐核验（附录 D.1）。至此，开篇三拍反例获得彻底解答：单纯交点读数无法替代共同源词，唯有携带共同源词见证的前缀方能沿生成后继合法延拓（图 4）。

![图 4 保持共同源词的前缀延拓](figures/vector/figure4-common-source-history-extension.png)

**图注**。图 4｜保持共同源词的前缀延拓（结构图；命题 4.8）。给定 $p=\mathrm{pre}_b^s(w)$ 与源词见证 $w$，以同一个 $w$ 读出 $\mathrm{pre}_{b+1}^s(w)$，删去新增末拍即回到原前缀；新增末拍所激活的运行态恰为原历史的目标拍。朱砂标出保持不变的源词见证 $w$；下方回看例 4.1：交点读数相等从未选定贯穿两段的共同见证。

---

## 5 忠实过程实现与无预置模拟关系的唯一比较

共同源词解决了单一载体内的历史同一性；当两套采用不同宿主语言、事件编码或编译策略的系统回答同一个问题时，还必须回答哪一个实现事件对应哪一次底层发生（第 3 层同一性）。经典精化映射[[7]](#ref-7)直接在两个实现的状态空间之间构造态射，往往需要向低层外置补充历史变量乃至预知未来的预言变量；本节在 **T0 零公理内核**（`#print axioms = []`）中走另一条路径：令每个实现各自与同一权威根导出的因果世界 $W$ 建立忠实表示，无需两实现直接对话或引入任何辅助变量，共同发生本身即唯一锁定跨实现事件比较与整套编译结果（C10）。

一个**执行过程** $P$ 在每个当前 $c$ 处给出事件载体 $\mathrm{Evt}_P(c)$、发射事件 $\mathrm{emit}_P(c)\in\mathrm{Evt}_P(c)$ 以及编译器 $\mathrm{compile}_P$（返回下一当前与整账写回候选演化）。比较基准是由第 2 节固定根登记导出的因果世界 $W$：每次访问恰有唯一规范发生 $g_c\in\mathrm{Occ}_W(c)$，且满足合法整账演化唯一化定律。

**定义 5.1（忠实过程实现）。** 称执行过程 $P$ **忠实实现**因果世界 $W$，若它提供以下三项零公理构造性数据：

- **双向发生—事件表示**：在每个当前 $c$ 处给出 $\varphi_c:\mathrm{Occ}_W(c)\rightleftarrows\mathrm{Evt}_P(c):\varphi_c^{-1}$，满足左右互逆 $\varphi_c^{-1}\circ\varphi_c=\mathrm{id}$ 与 $\varphi_c\circ\varphi_c^{-1}=\mathrm{id}$（无需选择公理或商构造）；
- **发射器相容**：在每个当前 $c$ 处满足 $\varphi_c(g_c)=\mathrm{emit}_P(c)$；
- **编译合法性**：对每个世界发生 $g\in\mathrm{Occ}_W(c)$，经 $\varphi_c$ 翻译并由 $\mathrm{compile}_P$ 编译所得结果属于 $W$ 在 $g$ 处的合法演化族 $\mathrm{Lawful}_c(g,\mathrm{compile}_P(\varphi_c(g)))$。

**命题 5.2（逐事件完整恢复，T0）。** 设 $P$ 忠实实现 $W$，$v$ 为任意时序访问，$e\in\mathrm{Evt}_P(v)$ 为该访问纤维中的**任意**事件（无需预先假定 $e$ 是发射事件）。则在零公理内核中：

1. **同一发生**：$\varphi_v^{-1}(e)=g_v$ 逐点等于根在访问 $v$ 处生成的规范发生；
2. **事件即发射事件**：$e=\mathrm{emit}_P(v)$，故固定单次访问内的事件纤维坍缩为发射事件单点（而跨不同访问的事件族仍可任意丰富）；
3. **全部已安装投影一致**：对 $W$ 源投影律中的**任意**投影 $\chi$，在恢复发生 $\varphi_v^{-1}(e)$ 上读取 $\chi$ 异质等于根自身在访问 $v$ 处的投影结果；
4. **原生后继一致**：$P$ 编译事件 $e$ 所得的下一当前严格等于根在访问 $v$ 处生成的下一当前。

证明。记 $g_v$ 为访问 $v$ 处的规范发生。因 $\varphi_v^{-1}(e)\in\mathrm{Occ}_W(v)$，单访问发生唯一性直接给出 $\varphi_v^{-1}(e)=g_v$，此即 (1)。对两端作用 $\varphi_v$，依次利用右逆律与发射器相容即得 $e=\varphi_v(\varphi_v^{-1}(e))=\varphi_v(g_v)=\mathrm{emit}_P(v)$，证得 (2)。(3) 因先完整恢复同一个发生对象 $g_v$ 再取依值投影，沿等式 $\varphi_v^{-1}(e)=g_v$ 搬运任意已安装投影 $\chi$ 的纤维类型并复合定理 2.2(3) 的安装相容律即得，全称量词覆盖全部已安装投影而非抽样字段。(4) 由因果世界演化载体的后继定义固定为 $\mathrm{next}(g_v)$ 直接读出。∎

**定理 5.3（无预置模拟关系的唯一实现比较，T0）。** 设 $P_1,P_2$ 均忠实实现同一个因果世界 $W$。则在零公理内核中：

1. **源生比较与整编译器保持**：复合映射 $\Phi_{12,c}:=\varphi_{2,c}\circ\varphi_{1,c}^{-1}:\mathrm{Evt}_{P_1}(c)\rightleftarrows\mathrm{Evt}_{P_2}(c)$ 构成双向事件表示，与两侧发射器相容，且保持**整套编译结果**：对任意 $e\in\mathrm{Evt}_{P_1}(c)$，有 $\mathrm{compile}_{P_2}(\Phi_{12,c}(e))=\mathrm{compile}_{P_1}(e)$；特别地，两实现在每个当前处生成的整账演化完全相等；
2. **无条件逐点唯一性**：**任意**候选事件映射族 $\Psi_c:\mathrm{Evt}_{P_1}(c)\to\mathrm{Evt}_{P_2}(c)$（**无需附加发射器相容、同态或交换图假设**）在每个当前 $c$ 与每个事件 $e$ 上均逐点满足 $\Psi_c(e)=\Phi_{12,c}(e)$。

证明。(1) 双向互逆与发射器相容由 $\varphi_1,\varphi_2$ 的互逆律及 $\varphi_{2,c}(\varphi_{1,c}^{-1}(\mathrm{emit}_{P_1}(c)))=\varphi_{2,c}(g_c)=\mathrm{emit}_{P_2}(c)$ 复合即得。对任意 $e\in\mathrm{Evt}_{P_1}(c)$，记 $g=\varphi_{1,c}^{-1}(e)$，由两侧编译合法性知 $\mathrm{compile}_{P_1}(e)=\mathrm{compile}_{P_1}(\varphi_{1,c}(g))$ 与 $\mathrm{compile}_{P_2}(\Phi_{12,c}(e))=\mathrm{compile}_{P_2}(\varphi_{2,c}(g))$ 同属同一个发生 $g$ 的合法演化族 $\mathrm{Lawful}_c(g,\cdot)$，故合法演化唯一化定律迫使二者相等。(2) 对任意候选映射 $\Psi_c$ 与事件 $e$，$\Psi_c(e)$ 与 $\Phi_{12,c}(e)$ 均落在单次访问 $c$ 的目标事件纤维 $\mathrm{Evt}_{P_2}(c)$ 中；由命题 5.2(2)，两者同等于 $\mathrm{emit}_{P_2}(c)$，故逐点严格相等。∎

定理 5.3 的两个要点各司其职：单访问发生纤维单点性决定事件映射的无条件逐点唯一性，而合法演化唯一化定律决定整本账写回与后继编译的严格一致。同源物理构造直接调用这一定理对齐不同表示面上的完整构型准入、物质读回、作用方程与宏后继（§10.4）。

---

## 6 责任账本：生命周期三律、无总法则良基核与内生执行扣款

进入运行的提问在过程自身的账本中留下一笔待处置的**责任（obligation / responsibility）**。支承 $s$ 上的**完整活账（whole live ledger）**是携带开立见证的依赖和

$$L_s:=\sum_{r:\mathrm{Responsibility}}\mathrm{OpenAt}(s,r),$$

每条活账行都可投影读出其主张与自然数进展预算 $\beta$。一次合法整账演化必须为每条目标行指认源起源、为每条源行指认目标去向，并证明它们服从同一次发生的写回规则；有限补丁仅列出当次**新生成的行**，未变旧行作为**同源恒等传输余项**原样保留。本节依次建立生命周期守恒三律（§6.1，C1）、债务激活与按事件整账编译（§6.2–§6.3，C12）、无总法则宏步良基性与给定总律下的有限终账结清（§6.4，C2），以及无需借用旧承担者的计算责任内生出生、严格扣款与 `Type` 值完成回执（§6.5，C22, C39）。

### 6.1 生命周期三律：边语法上的守恒律

固定责任词汇表 $\mathcal{V}$，**原生责任过程**的状态为槽位列表，每个槽位或处于**活跃（live）**态，或处于**终结归档（terminal archive）**态。状态间的合法边恰有三类：(1) **准入（admission）**：在末尾追加一个活跃槽位；(2) **跨界（boundary crossing）**：对某既有活跃槽位施加跨界事件，分类器给出四种处分中的唯一一种——延续（carry）、持有人释放（holder release）、继承终结（inherited terminal）或最终义务终结（final-obligation terminal）；(3) **重开（reopening）**：对终结归档槽位施加重开事件使其重新活跃。

**命题 6.1（责任生命周期三律与保序历史）。** 对任意词汇表 $\mathcal{V}$、任意原生责任过程及任意合法边 $s\to t$ 与槽位 $k$：

1. **禁凭空生成**：新分配的活跃槽位（$s$ 无槽位 $k$ 而 $t_k$ 活跃）只能由准入边产生；
2. **重开为唯一复生通道**：新点亮的槽位（$s_k$ 非活跃而 $t_k$ 活跃）只能来自准入或重开，跨界边绝不能将归档槽位无证点亮；
3. **禁无证消失**：活跃槽位的消失（$s_k$ 活跃而 $t_k$ 非活跃）必来自该边在槽位 $k$ 处的最终义务终结处分；延续、持有人释放与继承终结均在同一谱系槽位留下活跃后继；
4. **保序历史**：任意有限运行段的目标态历史等于源态历史按序拼接各边事件；从空生命周期依值折叠生成的状态，其历史恰等于生成事件列表。

证明。逐类检查三种边对槽位列表的作用：准入仅在表尾追加一项而保持全部旧槽位；跨界与重开仅替换指定下标 $k$ 而保持表长与其余槽位。在跨界边的四分支分类器中，延续、持有人释放与继承终结三支均向目标槽位写入活跃载荷，唯独最终义务终结支写入非活跃归档，故活跃消失别无他源。(4) 对有限运行步数归纳即得。∎

### 6.2 债务激活律：扩充世界与双向读回

**定义 6.2（债务激活律）。** 一套**债务激活律** $\Lambda$ 由七项依值数据构成（可选族默认为空类型）：(1) **债务身份**：债务状态集 $D$、固定债务标签 $\mathrm{id}_0$ 与固定债务主张 $\mathrm{cl}_0$；(2) **自然数预算** $\beta:D\to\mathbb{N}$；(3) **严格扣款步** $\mathrm{Step}(d,d'):\mathrm{Type}$，每个步见证携带严格下降证明 $\beta(d')<\beta(d)$；(4) **同债不增传输**：预算满足 $\beta(d')\le\beta(d)$ 的可选传输族；(5) **局部结清见证族** $\mathrm{Settle}$，仅在 $\beta(d)=0$ 处允许非空；(6) **整支承阶段终结族**，每项内含一份局部结清见证；(7) **状态阻滞族** $\mathrm{Obs}:D\to\mathrm{Type}$。

**定义 6.3（扩充世界网络）。** 激活律 $\Lambda$ 将世界网络 $N$ 扩充为 $N[\Lambda]$：支承变为 $\mathrm{Sup}\times\mathrm{Option}(D)$（第二坐标记录该债务行是否处于活跃态 $d$）；责任与主张载体分别取不相交并 $\mathrm{Responsibility}\sqcup\mathrm{DebtId}$ 与 $\mathrm{Claim}\sqcup\mathrm{DebtClaim}$；新侧开立纤维在 $\langle s,\mathrm{none}\rangle$ 上为空类型，在 $\langle s,\mathrm{some}\,d\rangle$ 上仅对唯一标签 $\mathrm{id}_0$ 开立，其主张为 $\operatorname{inr}\mathrm{cl}_0$、预算为 $\beta(d)$；处置族同步扩充扣款转移、阶段终结与阻滞三支。

**命题 6.4（扩充世界活账双向读回，T0）。** 在零公理内核中，扩充世界网络 $N[\Lambda]$ 满足：(1) 在非活跃支承 $\langle s,\mathrm{none}\rangle$ 上，开立活账纤维与原世界 $L_s$ 存在保持全部证明相关字段的双向构造性表示，新债务侧严格为空；(2) 在活跃支承 $\langle s,\mathrm{some}\,d\rangle$ 上，开立活账双向表示为“原活账 $L_s\ \sqcup$ 唯一新债务行”，任何开立的新侧标签必等于 $\mathrm{id}_0$，预算为 $\beta(d)$；(3) 原有旧行的嵌入严格保持各自原主张与原预算；(4) 扣款步映射为活跃面上的严格降预算转移，同债传输预算不增，结清见证仅在零预算处存在，且单纯数值 $\beta(d)=0$ 本身绝不自动构造阶段终结事件；(5) 若旧账具构造性有限清点，则活跃支承整账清点恰为“旧索引 $\sqcup$ 新债务行”（字段级证明见附录 C.5）。∎

### 6.3 按发生事件的整账编译与算术定目标实例

附着于当前 $c$ 规范发生的**按发生索引源（occurrence-indexed source）**给出生成事件 $\mathrm{gen}$，并直接从事件读出激活律 $\Lambda$、当前债务态 $d$ 以及**内生处分分支**——严格扣款步（含目标态）、阶段终结事件或阻滞事件三者之一。阻滞分支接入固定**审计协议**（术语对照见附录 E）：生产演算由阻滞 $o$ 生成绑定于确定活账行的需求事件，演化演算将其编译为结清、转移或“需执行理论审计”。

**命题 6.5（按发生事件的整账编译，T0）。** 设旧世界配有审计协议，且活跃债务行已属于扩充世界的完整活账。编译器仅读取生成事件自身的处分分支而无需外部选择：若为严格扣款步，输出从当前活账到目标债务态活账的完整整账演化；若为阶段终结事件，输出整支承终结整账演化；若为阻滞事件，输出同一债务行的理论审计，其中审计需求行严格等于该活跃债务行，编译处分严格等于“需执行理论审计”（证明见附录 C.5）。∎

**表 2 算术定目标 $6$ 素数对分拆债务实例的状态、预算与双接口处分。** 扣款步与目标终结来自两个独立接口：按发生索引源仅发射首行严格扣款，次行终结由目标态的阶段终结族单独给出（源码定位见附录 D.1）。

| 债务状态 | 预算 $\beta$ | 处分分支及其发生出处 | 编译输出对象 | 下一预算 |
| --- | --- | --- | --- | --- |
| 开立（活跃） | $1$ | 严格扣款步：原生分拆重排 $2+4\to 3+3$（唯一严格步） | 完整整账演化（旧行恒等余项保留） | $0$ |
| 已付（目标） | $0$ | 目标态阶段终结族生成的结清见证（非同一源二次发射） | 整支承终结整账演化 | —（终结） |

### 6.4 无总法则 $\le\,;\,<\,;\,\le$ 宏步良基性与同债总律有限结清

没有严格扣款约束的账本可以通过无限次等额平转永远拖延义务。为追踪源过程 $\mathcal{P}$ 中某笔初始债务 $\omega$，定义三项结构：(1) **同债当前**：三元组 $(s,r,\text{谱系与主张相等证明})$；(2) **同债单步**：在过程确定的下一状态 $\sigma(s)$ 活账中给出唯一同债目标行及行演化见证，满足预算不增 $\beta(r')\le\beta(r)$；(3) **付款宏步（payment macro）**：由前置预算不增有限同债链 $h_-$、中间一步**真实严格扣款步** $p$（$\beta_{\mathrm{paid}}<\beta_{\mathrm{pay}}$）与后置预算不增有限同债链 $h_+$ 三段串接而成（两侧宏历史允许为空恒等链）。

**定义 6.6（同债良基总律）。** 固定过程 $\mathcal{P}$ 与初始债务 $\omega$，**同债良基总律**（简称**总律**）是一个覆盖全部同债当前的发射器 $\ell$：在每个同债当前 $x$ 处，$\ell(x)$ 要么返回局部终结结清见证（并证明下一状态活账中已无同债行），要么返回一条付款宏步 $m=(h_-,p,h_+)$，其预算沿边界满足三段夹逼不等式（表 3，图 S2）：

$$\beta(m.\mathrm{target})\ \le\ \beta_{\mathrm{paid}}\ <\ \beta_{\mathrm{pay}}\ \le\ \beta(x).$$

**表 3 付款宏步三段复合的预算夹逼规律（定义 6.6）。** 唯独中间真实扣款段要求严格下降，前后两段仅要求预算不回充；右列对应表 2 实例取两侧恒等边界时的具体数值。

| 复合阶段 | 一般预算约束 | 表 2 固定实例数值 |
| --- | --- | --- |
| 目标预算 $\to$ 扣款后预算 | 不回充（$\le$） | $0\le 0$ |
| 扣款后预算 $\to$ 扣款源预算 | 真实严格扣款（$<$） | $0<1$ |
| 扣款源预算 $\to$ 宏步起点预算 | 不回充（$\le$） | $1\le 1$ |

![图 S2 付款宏步的三段预算夹逼下降](figures/vector/supp2-same-debt-budget-descent.png)

**图注**。图 S2｜付款宏步的三段预算夹逼下降（精确数值图；定义 6.6，定理 6.7，表 3）。沿付款宏步边界顺序预算取 $1,1,0,0$：中间段为表 2 的真实扣款 $1\to 0$，两侧为恒等传输边界。一般规律为 $\beta_{\mathrm{target}}\le\beta_{\mathrm{paid}}<\beta_{\mathrm{pay}}\le\beta_{\mathrm{source}}$；两侧亦允许严格下降，唯独中间段（朱砂）必须严格下降，虚线框标出求取完整终账时外供的同债总律。

**定理 6.7（无总法则宏步良基性与给定总律下的有限终账结清，T0）。** 在零公理内核（`#print axioms = []`）中：

1. **无总法则良基核**：无需任何同债总律输入，同债付款宏步的延续关系本身即构造性良基；不存在回到同一同债当前的付款宏步闭环，且预算为零的同债当前不存在任何付款宏步；
2. **给定总律下的有限终账结清**：若进一步给定定义 6.6 的同债总律 $\ell$，则对**每一个**同债当前 $x$，构造性良基递归生成有限结清历史、确定的结清终点、下一状态无同债行证明以及被追踪债务行的终账回执。

证明。(1) 对任意付款宏步 $m:x\rightsquigarrow y$，将三段夹逼串联得严格自然数不等式 $\beta(y)\le\beta_{\mathrm{paid}}<\beta_{\mathrm{pay}}\le\beta(x)$，即 $\beta(y)<\beta(x)$。因此宏步关系是自然数严格小于关系 $(\mathbb{N},<)$ 沿函数 $\beta$ 拉回的子关系；由 `InvImage.wf` 与 `Nat.lt_wfRel`（纯归纳构造，零公理）即得良基性。自环将导致 $\beta(x)<\beta(x)$，零预算起点将导致 $\beta(y)<0$，均不可能。(2) 给定总律 $\ell$，沿 (1) 的良基关系作依值递归：若 $\ell(x)=\operatorname{inl}s$，直接返回当前终点与结清 $s$（并保留分支等式见证 $\epsilon_x$）；若 $\ell(x)=\operatorname{inr}m$，因 $\beta(m.\mathrm{target})<\beta(x)$，在精确目标 $m.\mathrm{target}$ 处合法调用递归得到尾段结清树，与宏历史 $(h_-\cdot p)\cdot h_+$ 拼接即得完整有限结清历史，并在终点局部阶段终结事件上提取被追踪行的整账终结回执。∎

**注记 6.8（总律的输入边界与零预算空终账反例）。** 定理 6.7(2) 严格证明“总律 $\Rightarrow$ 有限终账”，总律本身是领域输入。若缺少总律，即便预算已降为零仍可无法结清：构造一个预算 $\beta(x)=0$ 且局部终结纤维为空类型的状态，则零预算排除付款宏步分支，空终结纤维排除结清分支，定义 6.6 的总律类型本身退化为空类型。这正说明“数值预算归零”绝不等同于“持有合法终账回执”。

### 6.5 无需旧承担者：源程序内生出生计算责任、逐步扣款并交出 `Type` 完成回执

一般领域责任需外供总律；而**代数计算责任**无需向调用方索取任何旧承担行、总律或未来请求表——登记在发生上的环境—表达式对 $(\rho,e)$ 本身已是一套完整的债务激活律。

**定义 6.9（执行债务律）。** 对任意环境 $\rho$ 与表达式 $e$，**执行债务律** $\Lambda_{\rho,e}$ 定义为定义 6.2 的如下实例：债务状态为携带已付前缀迹的序对 $(e',t)$（其中 $t:e\to e'$ 为 $\rho$ 下的执行迹），债务标签为单点类型，主张为原表达式 $e$ 本身；预算为剩余原语步数 $\beta(e',t):=r(e')$；严格扣款步由一步实际执行步 $s:e'\to e''$ 将 $(e',t)$ 推至 $(e'',t\cdot s)$（由命题 3.7(1) 预算严格减 $1$）；局部结清见证当且仅当 $e'$ 为常量时存在（此时 $\beta=0$），唯一同债传输为结清处的恒等传输，阻滞族为空。

**定理 6.10（无旧承担者计算责任行的内生出生、严格扣款与关系收据）。** 固定世界网络 $N$ 上的任意完整整账权威根、起始当前 $c$ 以及在 $c$ 处发生上读出环境—表达式对 $(\rho,e)$ 的读取器，记总语法预算 $B:=r(e)$。无需任何旧责任行充当承担者，亦无需预登记询问或未来请求表，即可在扩充世界 $N[\Lambda_{\rho,e}]$ 上内生构造源、整账编译器、权威根与活过程，使得（完整证明见补充材料 S1）：

1. **内生出生与整账恒等余项**：过程当前即为 $\Lambda_{\rho,e}$ 的债务状态，初态为 $(e,\mathrm{id})$；有限补丁仅含唯一一条新生成的数学责任行，原支承上的**全部旧活账行**作为同源恒等传输余项原封不动保留（无需旧账有限性假设），整账起源与去向互逆；原支承、法则面与全部旧投影均作为根读出保持；
2. **逐步严格扣款与禁回充**：第 $k$ 次因果访问处的同债当前预算精确为 $B-k$（自然数截断减法）；对一切 $k<B$，执行器选出的首步原语归约构成两侧边界为空的真实付款宏步，预算严格减 $1$、绝不回充，延续关系良基；
3. **精确步数结清与求值一致**：在 $k=B$ 处预算归零、无付款宏步且存在局部结清，已付执行迹长度恰为 $B$，完成常量值严格等于 $\mathrm{ev}_\rho(e)$；此后访问保持已付终态而访问计数继续推进；
4. **关系收据与更新效应读出**：已付全迹的关系像为 $\delta_e-\delta_{\mathrm{const}(\mathrm{ev}_\rho e)}\in\ker(\mathrm{ev}_\rho)$；对任意环境增量 $\varepsilon$，该收据在新求值映射 $\mathrm{ev}_{\rho+\varepsilon}$ 下的值精确等于效应 $\mathrm{eff}_{\rho,\varepsilon}(e)$。∎

**命题 6.11（整树询问：同答交付求值、溯源与计费）。** 若询问态的根投影律在每次发生 $o$ 处读出有根树 $T(o)$，取读取器 $o\mapsto(\delta,\mathrm{prog}_\kappa T(o))$ 安装定理 6.10 的内生计算，则结果面在同一回答中同时交出折叠值 $\delta_{\mathrm{fold}_\kappa T}$、长 $\beta(T)$ 的逐步已付执行迹，且结果面与查询面保存的表达式均由定理 3.9(3) 的纯语法解析器无损逆读回原树 $T$。∎

当上述内生执行嵌入跨周期持续询问运行时（§8.5）时，下游构造需要直接从任意实际起点提取结算终点与完整已付前缀。为此必须构造居于 `Type` 的精确完成回执（C39）：

**定理 6.12（`Type` 值完成回执与精确已付前缀）。** 固定初始询问帧 $\Phi_0$ 与已安装源程序配置 $\mathcal{P}$，记递归帧序列为 $\Phi_i$、当帧实际发射的数学动作为 $a_i$（左注入为局部结清，右注入为实际扣款步），当前已付态表达式的剩余步数为 $B_i:=r(\Phi_i.\mathrm{state.expr})$。则从**任意实际起点** $i\in\mathbb{N}$，源按 $B_i$ 强递归内生构造 `Type` 值回执（完整证明见补充材料 S1.3）：

$$\mathsf{Receipt}_i:=\sum_{d_i:\mathbb{N}}\Bigl\{s_i:\mathsf{Settle}(\Phi_{i+d_i}.\mathrm{state})\ \Big|\ d_i\le B_i\ \land\ a_{i+d_i}=\operatorname{inl}s_i\Bigr\},\tag{6.1}$$

且满足四条精确性质：(1) **步距恰等于预算**：$d_i=B_i$，且对一切 $0\le h<B_i$，$a_{i+h}$ 均为实际扣款步、预算依次为 $B_i-h$，完整保留中间全部已付态与编译；(2) **终点值与环境保持**：终点 $\Phi_{i+B_i}$ 保存原登记输入与完整已付迹，状态表达式为 $\mathrm{const}(\mathrm{ev}_\rho e)$（若环境读取器满足相容律则前缀全程保持同一实际环境）；(3) **原编译直达下一出生帧**：回执选定的结清编译直接调用原程序的责任准入，其规范后继在同一运行中严格等于下一出生帧 $\mathrm{nextBorn}(\Phi_{i+B_i},\mathcal{P})$；(4) **共尾出生序列**：由 $u_0=i,\ v_j=u_j+B_{u_j},\ u_{j+1}=v_j+1$ 迭代生成的结清—出生停点满足 $v_{j+1}\ge v_j+1$（故 $v_j\ge i+j$），在 $\mathbb{N}$ 中严格递增共尾，且每段 $[u_j,v_j]$ 均留存在同一递归帧运行内。∎

---

## 7 依值配对树残差、双空破产定位与因果审计供料

当一次演化步在既有表达中留下无法消去的偏差时，不能将其掩埋为未定义错误，而必须先把它精确分类并锚定为**本次发生的根植破产**，再移交给第 8 节的初始余面修订；反之，当配对树成功对齐时，同一分类直接交出按定理 6.10 计费的整树程序包并由原生后继自动供料下一访问（C11, C25–C27）。

固定完整根登记、完备复内积空间 $\mathcal{H}$（本节分类与审计证明不依赖其内积度量，采用该载体旨在与 §9 及物理应用共享联合识别接口）、根上已安装的联合识别 $\mathrm{rec}$ 及一次时序访问 $v$。这组数据确定一个**演化步** $\mathrm{step}(v)$：源发生、账本后继（或终结结清）、整账写回与下一当前，其中写回与下一当前按定义等于根自身的生成记录。

### 7.1 六分支总处置与同支承自由残差扩充

**命题 7.1（依赖步六分支总处置）。** 每个演化步由六分支归纳类型穷尽分类，总处置映射 $\mathrm{settle}$ 全域有定义，六个互斥分支各自携带精确坐标：(1) **终结结清**；(2) **生成元残差**（目标历史相对源历史的生成元偏差）；(3) **关系残差**（生成元闭包相容下的关系偏差）；(4) **配对树形状残差**（源与目标完整配对展开树对齐失败时的精确分支坐标）；(5) **完全生成**（配对树成功对齐并无残差折叠，根恰为配对发生序列）；(6) **联合残差**（配对树对齐后在原对齐迹某确定节点处留下的残差载荷）。∎

证明。按固定优先级嵌套调度三项既有全域判定——账本后继是否终结、生成元／关系历史比对与配对展开树位置拉链对齐（定理 2.2 同构分支拉链核）、以及对齐树折叠，各分支精确坐标直接从子判定的依值返回类型读出。∎

**定义 7.2（同支承自由残差扩充）。** 取密封运行 $\mathrm{settle}$ 选出的**有根被动残差** $r$（携带源支承、残差坐标族 $\mathcal{R}$ 与目标发生），定义**同支承自由扩充世界** $N[\mathcal{R}]$：支承、锚点、关联与谱系保持 $N$ 不变；责任与主张载体取不相交并 $\mathrm{Responsibility}\sqcup\mathcal{R}$ 与 $\mathrm{Claim}\sqcup\mathcal{R}$；新责任行仅在 $r$ 的焦点支承处开立；阻滞族取 $\mathrm{Obs}\sqcup(\mathcal{R}\times[\text{支承}=\text{焦点}])$；处置族仅在“法则面扩充”支添加新坐标开立回执。

此处的**理论状态** $\Theta$ 由各支承上的表达式纤维 $E_\Theta(s)$、指称映射 $d_\Theta:E_\Theta(s)\to\mathrm{Claim}$、定理纤维与世界事实的双向表示、以及每个阻滞 $o$ 在旧法则表下的合法实现纤维 $I_\Theta(o)$ 构成。阻滞 $o$ 的表达见证类型为 $\sum_{a:E_\Theta(s)}[d_\Theta(a)=\mathrm{claim}(o)]$；当该表达见证类型与合法实现纤维 $I_\Theta(o)$ **两者同时为空类型**时，称为**双空表达破产（double-empty expressive failure）**。

**命题 7.3（新主张消元初始性与旧账保守读回，T0）。** 在零公理内核中，$N[\mathcal{R}]$ 新主张坐标的消元子逐点初始：分别给定旧主张映射 $f$ 与残差映射 $g$，存在唯一合成映射 $[f,g]$ 在左右注入上分别还原 $f$ 与 $g$；全部旧开立活账行、旧世界事实与旧处置回执在 $N[\mathcal{R}]$ 中均由构造性双向表示或定义相等原样保持。

**命题 7.4（依赖残差构成精确双空破产，T0）。** 将旧理论状态 $\Theta$ 保守搬运至 $N[\mathcal{R}]$ 为 $\widetilde\Theta$（保持旧表达式集 $E_\Theta(s)$，指称改为 $d_{\widetilde\Theta}(a):=\operatorname{inl}d_\Theta(a)$，新阻滞侧合法实现纤维定为空类型 $\varnothing$）。则在零公理内核中，每一个新残差坐标在 $\widetilde\Theta$ 下均构成精确双空破产：既不存在任何旧表达式指称其阻滞主张 $\operatorname{inr}r$，亦不存在任何旧合法实现见证——即便 $\Theta$ 在原世界 $N$ 上原本完备亦然。

证明（命题 7.3、7.4）。余积消元 $[f,g]$ 在 $\operatorname{inl},\operatorname{inr}$ 上的取值唯一固定，旧行 $\langle r_0,h\rangle\mapsto\langle\operatorname{inl}r_0,h\rangle$ 不改动开立见证 $h$。对命题 7.4，若存在旧表达式 $a\in E_\Theta(s)$ 满足 $d_{\widetilde\Theta}(a)=\operatorname{inr}r$，即 $\operatorname{inl}d_\Theta(a)=\operatorname{inr}r$，由不相交并左右构造子互斥（`nomatch`）立得矛盾；新侧合法实现纤维 $I_{\widetilde\Theta}(\operatorname{inr}(r,h))=\varnothing$ 按定义为空。破产纯属旧词汇表达维度不足，而非旧理论内部逻辑谬误。∎

### 7.2 因果审计转移与依赖步整树自动供料

**命题 7.5（因果审计转移：旧行恒等余项与新行唯一权威）。** 给定选定残差 $r$、$N$ 上固定的审计协议及精确时序因果根事件，内生生成一次**因果审计转移**（字段级构造见附录 C.6）：(1) 步处分确为 $\mathrm{settle}$ 输出且根事件发生等于步的源发生；(2) 转移目标源的发生载荷同时封存源发生与残差目标发生两端；(3) 根事件、演化步与原根三者的整账写回及下一当前彼此相等；(4) **旧行逐行通过恒等核验**：有限补丁生成器对每条嵌入旧行返回“非当次新生成行”，全部作为恒等余项保留；(5) **唯独新残差行获得活时序因果准入权威**；(6) 同一新行直接装配出定义 8.1 的**根植双空破产**及第 8 节的**初始余面**。∎

当命题 7.1 落入另外两条对齐分支（完全生成支或联合残差支）时，源直接交出整树计费程序包并自动接入运行：

**命题 7.6（依赖步整树程序供料）。** 在本节固定数据下，命题 7.1 的总处置为每个演化步生成类型精确匹配的**供料对象（feed）**：终结支返回源发生处的整账演化；三类残差支返回对应残差对象；完全生成支与联合残差支返回**整树程序包**——对齐构造树 $T$、以 $\mathrm{prog}_\kappa T$ 为读取器的执行债务律已付态与完成值 $\delta_{\tau(T)}$（其中 $\tau$ 为被动效应沿 $T$ 的折叠）、源发生原材料以及全部 $\beta(T)+1$ 个阶段材料，计费精确等于 $\beta(T)$，且整账写回与下一当前保持等于根生成记录。∎

**定理 7.7（登记输入激活与原生后继自动供料）。** 除命题 7.6 数据外，取根在当前访问 $v$ 处登记的原询问输入 $\iota$（投影位置、激活证明与分类器等式）。则（逐字段保持合同与完整证明见补充材料 S2.2）：

1. **登记激活与整树语法逆读**：在两条对齐分支上生成新询问态 $s_\iota$，将 $\iota$ 的关联查询编译为回答——回答面经定理 3.9(3) 纯语法左逆还原整棵树 $T$ 并求值为 $\delta_{\tau(T)}$（同时原样保持一切旧查询编译面）；
2. **长 $\beta(T)$ 同源计费运行**：由 $s_\iota$ 启动的询问运行时沿长 $\beta(T)$ 的严格扣款历史收敛于 $\delta_{\tau(T)}$，在每一计数与运行偏移处保持整账写回与确定后继；
3. **无前问输入的原生后继供料**：仅凭活根、访问 $v$、识别 $\mathrm{rec}$ 与审计协议（无需调用方预供已完成前问状态），编译器非终结后继自动生成下一访问 $v^+$ 与下一供料／运行，且后继目标发生处的历史与 $v^+$ 规范发生处的历史严格相等。∎

---

## 8 T0 零公理范畴初始余面修订、两拍接力与残差自动再询问

现在处理过程同一性最深刻的一跃：当旧理论对当前需求既无表达词、亦无合法实现（双空破产）时，如何在不删改任何旧定理、不丢失任何旧活债的前提下扩充语言并继续回答？本节前四小节在 **T0 零公理内核**（`#print axioms = []`）中证明根植双空破产 $\eta$ 内生生成**范畴初始余面（initial coface）**，对一切容许扩充具有唯一单射且不回充预算的忠实态射分解，并将新增方向精确送入有类型修订新根首次整账写入所消费的新行，在固定两拍实例中令第 2 拍直接回答（C4–C6, C13）；第 8.5 小节回到语言充足侧，证明已结清答案如何以自身在新环境中的关系差内生提出下一问、独立计费执行同发生双边界差词，并按 $V=p+n$ 逐回执写回完整总值（C24, C35–C38, C42）。

贯穿 §8.1–§8.4 的**固定最小实例**直观展示这一机制：旧世界支承为布尔二元集 $\{\mathrm{false},\mathrm{true}\}$，锚点、关联、谱系、责任与主张均为单点类型；每个支承上有一条预算为 $2$ 的旧开立责任行，旧主张事实纤维含唯一成员；旧根当前载荷恒为单点 $()$，规范发生为 $\langle\mathrm{true},()\rangle$，每拍微步写入回到 $()$ 而访问深度加 $1$。旧理论 $\Theta$ 的表达式纤维与合法实现纤维均定为空类型，单点查询 $()$ 绑定于初访与预算 $2$ 的旧行，阻滞 $o=()$ 位于支承 $\mathrm{true}$。仅看状态载荷，每一拍都是毫无差别的 $()$；但一旦绑定根、访问与破产账行，空无本身便获得了精确地址。

### 8.1 根植双空破产与零泄漏初始余面（T0）

**定义 8.1（根植双空表达破产）。** 固定旧权威根、时序访问 $v$、理论状态 $\Theta$、支承 $s$ 上的阻滞 $o$ 及双空破产证明 $f$。称 $f$ 在该访问处**根植（rooted）**，若同时具备六项依值见证（合记为 $\eta$）：(1) **理论归属**：$\Theta$ 确为该旧根的法则面；(2) **发生投影**：当次实际发射发生的已安装投影读出 $f$；(3) **阻滞审计**：同一阻滞的审计事件已编译为“需执行理论审计”；(4) **责任行与权威**：需求指向的旧活账行 $e$ 持有由生成行赋予的因果权威；(5) **整账相容**：审计协议对 $e$ 的处分与旧根整账编译逐行交换（在固定实例中排除以“转移行”冒充保留原行的审计处分）；(6) **非终结因果后继**：给出该行推进到达的旧目标支承 $s_+$、旧目标活账 $L_+$ 与旧目标行 $e_+\in L_+$。

**命题 8.2（局部初始余面与零预算附着方向，T0）。** 在零公理内核中，任意根植双空破产 $\eta$ 唯一生成单构造子方向类型 $D_\eta=\{\star_\eta\}$ 与局部初始余面载体

$$C_\eta := L_+ \sqcup D_\eta,\qquad \beta(\operatorname{inl}e):=\beta(e),\qquad \beta(\operatorname{inr}\star_\eta):=0.\tag{8.1}$$

旧目标活账 $L_+$ 经左注入 $\operatorname{inl}$ 嵌入 $C_\eta$，构造性收缩映射在 $\operatorname{inl}e$ 上还原 $e$、在新点 $\operatorname{inr}\star_\eta$ 上取 $\eta$ 自带的 $e_+$（故先嵌入后收缩严格恒等）；新增点 $\operatorname{inr}\star_\eta$ 无任何旧账原像，且携带以 $\eta$ 为唯一边界的附着方向（由单构造子归纳直接证明唯一性）。

证明。不相交并左右构造子互斥直接排除 $\operatorname{inl}e=\operatorname{inr}\star_\eta$，故新点无旧原像（`PEmpty`/`IsEmpty` 消元，零公理）；收缩映射在新点处直接读取 $\eta$ 已携带的确定目标行 $e_+$，绝不外借选择公理挑选旧行；预算在左支原样继承，在右支定为 $0$。∎

这里“**初始余面（initial coface）**”的命名直接对应范畴论与单纯同调中的余单纯结构[[24]](#ref-24)：在单纯范畴 $\Delta$ 中，单射余面算子 $\delta_i^n:[n-1]\hookrightarrow[n]$ 将低一维顶点集嵌入新增一个顶点的单纯形，满射余退化算子 $\sigma_i^n:[n]\twoheadrightarrow[n-1]$ 将新增顶点压回既有顶点并满足左逆恒等 $\sigma_i^n\circ\delta_i^n=\mathrm{id}$。式 (8.1) 中的左注入 $\operatorname{inl}:L_+\hookrightarrow L_+\sqcup\{\star_\eta\}$ 正是漏掉破产新顶点 $\star_\eta$ 的余面嵌入，而将 $\operatorname{inr}\star_\eta$ 压回确定目标行 $e_+\in L_+$ 的构造性收缩则是与之配对的余退化映射；定理 8.4 将证明这一 $(\operatorname{inl},\text{收缩},\star_\eta)$ 三元组恰为全体容许余面修订范畴的严格初始对象。

**命题 8.3（整网络初始余面、旧面零泄漏与旧定理存续，T0）。** 在零公理内核中，同一个 $\eta$ 生成完整扩充世界网络 $N_\eta$：支承、关联、责任与主张载体均取原载体与 $D_\eta$ 的不相交并，锚点与谱系保持不变（四类纤维的分片精确定义见附录 C.1），并满足：

1. **旧支承零泄漏保守保持**：在任意嵌入旧支承 $\operatorname{inl}s$ 上，开立活账、世界事实与处置回执均与原世界 $N$ 在 $s$ 处的对象双向构造性同构（后两者定义相等）；新责任与新主张在旧支承上的纤维严格为空类型（$\mathrm{Open}'(\operatorname{inl}s,\operatorname{inr}\star_\eta)=\varnothing$，$\mathrm{Holds}'(\operatorname{inl}s,\operatorname{inr}\star_\eta)=\varnothing$），绝不向旧世界泄漏任何伪行或伪事实；
2. **新余面支承的整账继承与密封处置**：在新支承 $\operatorname{inr}\star_\eta$ 上，$s_+$ 的全部旧开立责任与旧事实原样保持，并恰新增唯一一条主张为 $\operatorname{inr}\star_\eta$、预算为 $0$ 的开立行 $e_{\mathrm{obs}}=\langle\operatorname{inr}\star_\eta,\mathrm{same}(\star_\eta)\rangle$；新主张在该新支承上成立，从原阻滞主张 $\operatorname{inl}\mathrm{claim}(o)$ 到 $\operatorname{inr}\star_\eta$ 存在唯一单构造子语义变化 $\mathrm{reveal}_\eta$；$s_+$ 的旧处置回执经以 $\eta$ 索引的单字段信封 $\mathrm{Seal}_{\eta,k}$ 双向封装保留，防止未登记的旧回执或旁支修订冒用新支承身份；
3. **旧定理全数存续**：旧理论 $\Theta$ 的每一条定理证明项 $p:\mathrm{Theorem}_\Theta(a)$，经 $\Theta$ 的定理—事实表示及旧事实左嵌入，原封不动存续为 $N_\eta$ 旧面上的同一世界事实，无需作任何 AGM 式删减收缩[[18]](#ref-18)。∎

### 8.2 范畴初始性：三类坐标上的唯一忠实分解（T0）

**定理 8.4（T0 零公理初始余面的范畴初始性与唯一忠实态射分解）。** 固定根植双空破产 $\eta$。称 $\mathcal{E}$ 为 $\eta$ 的一个**容许余面修订（admissible coface revision）**，若它在活账、关联与主张三类坐标上分别提供从旧目标活账 $L_+$、旧关联 $\mathrm{Inc}$ 与旧主张 $\mathrm{Claim}$ 出发的构造性收缩对 $(j_{\mathrm{led}},p_{\mathrm{led}}),(j_{\mathrm{inc}},p_{\mathrm{inc}}),(j_{\mathrm{clm}},p_{\mathrm{clm}})$，每类载体中各含一个无旧原像的新增生成元 $(a_{\mathrm{led}},a_{\mathrm{inc}},a_{\mathrm{clm}})$，且活账预算映射满足旧行预算不回充 $\beta_{\mathcal{E}}(j_{\mathrm{led}}(e))\le\beta(e)$ 与新增元零预算 $\beta_{\mathcal{E}}(a_{\mathrm{led}})=0$。则在零公理内核（`#print axioms = []`）中：

1. **初始余面自身容许**：命题 8.3 生成的整网络余面 $N_\eta$ 在新支承 $\operatorname{inr}\star_\eta$ 上自身构成一个典范容许余面修订；
2. **存在忠实单射且预算不回充的初始态射**：从初始余面到**任意**容许余面修订 $\mathcal{E}$ 存在典范忠实态射 $F:C_\eta\to\mathcal{E}$，其三坐标映射
   $$F_{\mathrm{led}}(\operatorname{inl}e)=j_{\mathrm{led}}(e),\quad F_{\mathrm{led}}(\operatorname{inr}\star_\eta)=a_{\mathrm{led}}\tag{8.2}$$
   （关联映射 $F_{\mathrm{inc}}$、主张映射 $F_{\mathrm{clm}}$ 同式定义）全部为**单射**，严格保持全部旧嵌入与新增生成元，且在每条活账坐标上满足预算不回充 $\beta_{\mathcal{E}}(F_{\mathrm{led}}(x))\le\beta(x)$；
3. **严格唯一分解**：在保持结构的忠实余面态射类中，$F$ 严格唯一；且任何在旧嵌入与新增点上满足上述交换等式的候选坐标映射均在每个元素上与 $F$ 逐点相等。

证明。(1) 将命题 8.3 的新支承活账收缩、无旧原像证明及预算定义代入容许条件，旧行预算等号成立（$\beta(e)\le\beta(e)$），新行预算定义相等为 $0$。(2) 验证式 (8.2) 的单射性（对 $F_{\mathrm{led}},F_{\mathrm{inc}},F_{\mathrm{clm}}$ 完全同构）：设 $F_{\mathrm{led}}(u)=F_{\mathrm{led}}(v)$，分四种构造子情形消元——若 $u=\operatorname{inl}e_1,v=\operatorname{inl}e_2$，对等式 $j_{\mathrm{led}}(e_1)=j_{\mathrm{led}}(e_2)$ 两端作用左逆收缩 $p_{\mathrm{led}}$ 得 $e_1=p_{\mathrm{led}}(j_{\mathrm{led}}(e_1))=p_{\mathrm{led}}(j_{\mathrm{led}}(e_2))=e_2$；若一侧为 $\operatorname{inl}e$ 而另一侧为 $\operatorname{inr}\star_\eta$，等式 $j_{\mathrm{led}}(e)=a_{\mathrm{led}}$ 直接给出 $a_{\mathrm{led}}$ 的旧原像，与 $\mathcal{E}$ 的无旧原像空类型证明矛盾；若两侧同为 $\operatorname{inr}$，因 $D_\eta$ 仅有唯一构造子 $\star_\eta$，必有 $u=v$。预算不回充在 $\operatorname{inl}e$ 上由 $\mathcal{E}$ 的继承预算条件给出，在 $\operatorname{inr}\star_\eta$ 上由 $\beta_{\mathcal{E}}(a_{\mathrm{led}})=0\le 0$ 给出。(3) 任何保持旧嵌入与新增点的候选映射在左右两类构造子及单点 $D_\eta$ 上的取值均已被式 (8.2) 唯一锁死，故逐点相等；形式态射令牌仅设唯一典范构造子而不携冗余映射字段，故态射对象本身由单次构造子归纳与自反性 `rfl` 证得严格相等（附录 C.1）。∎

定理 8.4 给出了“最小修订”毫无含糊的范畴定义：**后续修订可以拥有更丰富的动态载体，但绝不能绕过初始余面所锁定的这一新增方向**。

### 8.3 有类型语义修订、语义锚定与新根首次写入（T0）

初始余面生成了静态世界网络 $N_\eta$；要让新方向真正开口回答提问，还需由**有类型语义修订**提供运行中的新活根，并证明定理 8.4 的唯一初始态射恰好把附着方向送到新根首次整账写入所消费的那条活账行上。

**定义 8.5（有类型语义修订）。** 固定根植双空破产 $\eta$，一个**有类型语义修订** $\Xi$ 提供七项带相容证明的运行数据：(1) 新世界、词汇表、语义翻译与完整新活根；(2) 新根初态支承收缩回旧后继支承 $s_+$；(3) 旧目标活账 $L_+$ 经收缩嵌入新初始活账，保持翻译主张且预算不回充；(4) 旧后继发生纤维与新根初访发生纤维双向构造性对应且保持规范发射；(5) 新初始活账含一条预算为 $0$ 的新方向行 $e_{\mathrm{new}}$，该行、其主张及新支承关联均无旧原像；(6) $e_{\mathrm{new}}$ 的主张在新初始支承成立并携带源自旧阻滞主张的语义变化；(7) **首次整账写入**：新根初访的规范整账编译为非终结演化，且全部继承旧行与新行 $e_{\mathrm{new}}$ 均属于本次编译实际生成的补丁行。

**定理 8.6（同一附着方向的唯一分解与首次整账写入合流，T0）。** 在零公理内核中，每一个有类型语义修订 $\Xi$ 自动诱导出定理 8.4 的一个容许余面修订及其唯一忠实态射 $F_\Xi$；该唯一态射将初始余面的附着方向精确映为 $\Xi$ 的新方向行 $F_\Xi(\operatorname{inr}\star_\eta)=e_{\mathrm{new}}$，且该行恰被 $\Xi$ 新根的首次整账写入作为生成行实际消费。∎

证明。定义 8.5 的条件 (3)(5) 逐字段构成容许余面修订，故定理 8.4 给出唯一忠实态射 $F_\Xi$ 且 $F_\Xi(\operatorname{inr}\star_\eta)=e_{\mathrm{new}}$；再与条件 (7) 中 $e_{\mathrm{new}}$ 的首次写入补丁生成证明复合，即把范畴初始性与运行期首次写入锁在同一个对象上。∎

**定理 8.7（语义锚定与旧债、新行双路回答—后继恢复，T0）。** 设 $\Xi$ 进一步具备以下两类**语义锚定（semantic anchoring）**证明之一：**精确语义锚定**（逐项以一个世界等式与七个异质等式认回 $\Xi$ 的新世界、根法则面、翻译、初支承、旧账收缩、新行、新事实与语义变化恰为 $N_\eta$ 自身生成的典范对象，见附录 C.2）或**分裂精化语义锚定**（允许更丰富的新世界，要求新法则面为该世界的根语义，且首次编译将迁移旧破产行真实分裂为预算严格下降的两条互异子行，无潜伏账外行）。则在零公理内核中，首次写入的每条生成行获得初始因果权威；沿首次整账演化将迁移旧破产行与新方向行 $e_{\mathrm{new}}$ 推进至各自目标行，并在目标访问处调用**新根自身**的因果回答—后继编译器，无需外供目标发生或后继当前，即可同步交出双路回答—后继令牌及定理 8.6 的唯一分解（完整推导见附录 C.3）。∎

**命题 8.8（逐次修订相对表达容量的结合律，T0）。** 若第二次有类型修订根植于第一次修订所生成新根的某次访问，则从原世界到第二次修订世界在关联与主张两类坐标上的相对表达容量均具有以 $D_1\sqcup D_2$ 为新增方向族的单射嵌入；对任意三段可复合容量，先合成前两段与先合成后两段所得嵌入在方向余积规范重加括号同构下逐点严格相等（证明见附录 C.4）。∎

### 8.4 固定两拍修订实例与一次性接口不可能反例

**命题 8.9（固定两拍实例的初始余面修订与第 2 拍新根直答）。** 对本节开头的固定最小实例及采用精确语义锚定的自然数流新根（当前载体 $\mathbb{N}$，原生写入 $n\mapsto n+1$，双行补丁索引 $\{0,1\}$），规范询问运行时的首拍必落入表达修订分支（术语对照见附录 E）：首拍公开回答即为破产生成的附着方向 $\star_\eta$，其发生完整读回新根初访的首次写入 $0\to 1$（同步消费预算为 $2$ 的迁移旧行 $e_o$ 与预算为 $0$ 的新行 $e_n$），目标处编译 $1\to 2$ 使两条行给出同一个新活根宏后继当前 $2$（该宏后继属于三点支承网络 $\mathrm{Bool}\sqcup D_\eta$，严格区别于留在二点支承网络上的旧根微后继）；第 $2$ 拍在同一新根访问 $2$ 处直接进入已回答分支，读出回答面单点载荷唯一元 $\ast$（同时认回原查询 $()$、当次发生与新行 $e_n$），并将当前推进至 $3$（表 4，图 5）。

**表 4 固定两拍初始余面修订实例的完整演化轨迹。** $\star_\eta$ 为根植破产 $\eta$ 的唯一附着方向；$e_o=\langle\operatorname{inl}(),()\rangle$ 为迁移旧行，$e_n=\langle\operatorname{inr}\star_\eta,\mathrm{same}(\star_\eta)\rangle$ 为新增零预算行；表中 $0,1,2,3$ 为新根的自然数当前状态。

| 演化阶段 | 当前、支承与活账配置 | 核心对象与状态转移 | 输入与内生输出边界 |
| --- | --- | --- | --- |
| 旧根初始询问 | 旧初访，载荷 $()$；支承 $\mathrm{true}$；单条旧行预算 $2$ | 查询 $()$，发生 $\langle\mathrm{true},()\rangle$；旧理论表达与实现纤维皆空 | 旧世界、双空旧理论与查询程序为实例给定数据 |
| 首拍双空破产 | 审计将旧行保留至旧后继，载荷仍为 $()$ | 阻滞 $o=()$；两空纤维消元证明；审计需求行与账本延续一致 | $\eta$ 由已安装编译程序的破产分支内生输出 |
| 初始余面生成 | 新支承类型 $\mathrm{Bool}\sqcup D_\eta$；新支承 $\star_\eta$；活账 $e_o:2,\ e_n:0$ | 关联、责任与主张增持 $\star_\eta$；旧事实存续，新主张成立，含唯一 $\mathrm{reveal}_\eta$ | 由 $\eta$ 零公理内生生成；此步不含自然数动态程序 |
| 修订安装与锚定 | 新根初始当前 $0$，发生 $\langle\star_\eta,()\rangle$ | 新当前载体 $\mathbb{N}$，写入 $n\mapsto n+1$，双行补丁；法则面取 $N_\eta$ 根语义 | 有类型修订提供动态程序，精确语义锚定逐项认回 $N_\eta$ |
| 新根首次写入 | 当前 $0\to 1$，支承保持 $\star_\eta$ | 双行各自不增转移 $e_o:2\to 2,\ e_n:0\to 0$；补丁索引 $\{0,1\}$ 全覆盖 | 首次编译同步消费旧、新两行并赋予目标因果权威 |
| 首拍目标编译 | 在新根访问 $1$ 消费两条目标行，后继同取 $2$ | 首拍公开回答为 $\star_\eta$；宏后继定为新活根当前 $2$（异于旧微后继） | 调用新根自身编译器，合 $0\to 1$ 与 $1\to 2$ 为首拍宏步 |
| 第 2 拍新根直答 | 同一新根访问 $2$，原查询仍为 $()$ | 回答面直接读出 $\ast$；核验令牌认回原查询、当次发生与 $e_n$；当前 $2\to 3$ | 无需再次修订原问，后续激活沿同一新根递归续生 |

证明。分四环逐一核验：(i) 旧询问程序在双空阻滞下定义输出修订分支，规范运行时首拍逐点等于该输出；(ii) 双行补丁索引 $\{0,1\}$ 由责任左／右构造子双向完备匹配，无漏行、无预算回充；(iii) 首次写入 $0\to 1$ 后定理 8.7 在访问 $1$ 调用新根行编译器对 $e_o,e_n$ 均算出下一当前 $2$，且三点支承不可能注入二点支承证明新宏后继严格异于旧微后继；(iv) 新根在访问 $2$ 处的查询编译按构造走直接回答分支，输出单点元 $\ast$ 并由原生写入推进至 $3$。∎

![图 5 从根植双空破产到同一新根的两拍回答](figures/vector/figure5-coproduct-revision-and-continuation.png)

**图注**。图 5｜从根植双空破产到同一新根的两拍回答（精确轨迹图；表 4，命题 8.9）。双空破产 $\eta$ 零公理生成初始余面与附着方向 $\star_\eta$；有类型修订提供自然数动态程序，经精确语义锚定衔接。首拍公开回答即为该附着方向，其发生读回新根首次写入：$0\to 1$ 同步消费预算为 $2$ 与 $0$ 的旧、新两行，目标处编译 $1\to 2$ 给出共同宏后继 $2$；第 2 拍在同一新根访问 $2$ 处直接读出单点值 $\ast$（朱砂）并推进至 $3$；虚线框标出外供修订输入。

**命题 8.10（一次性空纤维接口无自主询问运行，T0）。** 在零公理内核（`#print axioms = []`）中，对回答后查询纤维为空类型的任意一次性询问接口，不存在覆盖该接口的自主询问运行时。

证明。反证：若存在自主询问运行时，其全域激活律必须在首拍回答的精确后继状态处给出下一次查询激活；投影取出该激活的查询对象即得到空类型的成员，矛盾。∎

注意第 8.4 节与 §2.3–§4 的复用边界：一旦修订后的新活根按定义 2.3 登记为源过程，自由载体 $\mathbb{Z}[S]$、求值核与完备化载体 $\widehat C(s)$ 即可原样作用于新根之上（该重登记在形式化中作为显式参数化接口保留，附录 D）。

### 8.5 结清之后：已付关系内生提出下一问、差词独立计费与总值写回

命题 8.10 从反面指出：若回答之后没有下一问，运行必然断流。现在给出无需外供未来请求表的正面闭环：当 §6.5 的计算结清时，已付执行迹留下的关系收据在变化后的真实环境中重新求值，其差词直接成为下一笔新责任的出生输入（C24）。

一个**询问帧（inquiry frame）** $\Phi$ 由询问态、读取根编译器的原生程序、当次访问登记的原输入 $(\rho,e)$、在每次原发生处读出当前真实环境的读取器 $E$ 以及因果深度 $k$ 构成；其数学状态为执行债务律 $\Lambda_{\rho,e}$ 的已付态 $(e',t)$。记当帧发生处的真实环境为 $\rho'$，实际增量为 $\varepsilon:=\rho'-\rho$。

**定义 8.11（残差请求）。** 已付态 $(e',t)$ 在真实环境 $\rho'=\rho+\varepsilon$ 下生成的**残差请求**定义为登记于环境 $\rho'$ 的新原输入

$$e\ominus e' := e + \mathrm{linear}_{-\mathrm{id}}(e'),\tag{8.3}$$

其责任关联指向当帧当前责任行。

**定理 8.12（已付关系在实际环境内生生成下一问与递归帧运行）。** 对任意初始询问帧 $\Phi_0$（完整证明见补充材料 S2.1，结构见图 6）：

1. **请求求值恰等于更新效应**：$\mathrm{ev}_{\rho'}(e\ominus e')=\mathrm{ev}_{\rho'}(e)-\mathrm{ev}_{\rho'}(e')$，在原登记环境 $\rho$ 下旧值为 $0$，在更新环境 $\rho'$ 下严格等于已付迹关系证书 $\delta_e-\delta_{e'}$ 在增量 $\varepsilon$ 下的效应 $\mathrm{eff}_{\rho,\varepsilon}(e)-\mathrm{eff}_{\rho,\varepsilon}(e')$，且为零当且仅当该证书在新求值核商中的典范余像为零；特别地，在结清终点 $e'=\mathrm{const}(\mathrm{ev}_\rho e)$ 处，请求值恰为原表达式的效应 $\mathrm{eff}_{\rho,\varepsilon}(e)$；
2. **强制触发新责任准入**：因剩余步数 $r(e\ominus e')=r(e)+\bigl(r(e')+1\bigr)+1=r(e)+r(e')+2\ge 2>0$，残差请求在起点绝不可能处于零预算结清态；其首步必为实际执行步，并在出生编译中严格编译为**新责任准入（obligation admission）**而非旧债扣款；
3. **无外部请求表的递归帧运行**：一步执行步将 $\Phi$ 推至深度 $k+1$ 的同输入帧（字典序秩 $(r(e),k+1)\to(r(e),k+2)$），局部结清则推至深度 $0$、登记输入为残差请求 $e\ominus e'$ 的**出生帧**（秩升至 $(r(e)+r(e')+2,1)$）；帧序列严格递增使源擦除为单射，与规范询问运行时的逐拍节点及宏后继严格一致，每帧查询纤维均为单点；
4. **扣款与出生严格分离**：限制于固定根债务过程时，唯独执行步分支发射同债扣款回执且整账去向等于联合执行步演化；零预算处无付款宏步，结清分支则开启全新责任行。∎

**例 8.13（三拍世界候选词结清后的下一问手算对照）。** 回到 §4.1 表 1 的单变量世界，在初始环境 $x\mapsto 1$ 下登记各候选词并执行至结清，再令真实环境变化：(1) 常零词 $0$ 步数为 $0$，当即结清得 $\mathrm{const}(0)$；环境移至 $x\mapsto 0$ 后，下一问 $0\ominus\mathrm{const}(0)$ 求值为 $0$，语法预算为 $0+0+2=2$（关系仍成立，核验新问照常出生计费）；(2) 变量词 $x$ 经 $1$ 步绑定结清得 $\mathrm{const}(1)$；环境移至 $x\mapsto 0$ 后，下一问 $x\ominus\mathrm{const}(1)$ 求值为 $0-1=-1$，预算为 $1+0+2=3$；(3) 多项式词 $x^2-x$ 在 $x\mapsto 1$ 结清得 $\mathrm{const}(0)$；环境移至 $x\mapsto 2$ 后，下一问求值为 $2-0=2$，例 4.2 的跨拍关系失效在此精确转化为一笔待执行的正预算新请求。若在交点 $x\mapsto 0$ 登记 $0$ 与 $x$，两者当拍回答同为 $0$，而当环境回到 $x\mapsto 1$ 时各自提出的下一问取值分别为 $0$ 与 $1$——阶段库存的旧值是“本拍回答”，效应则是“下一拍追问”。∎

![图 6 从原始发生到下一问的内生计算链](figures/vector/figure6-source-program-chain.png)

**图注**。图 6｜从原始发生到下一问的内生计算链（结构图；定理 3.9、6.10、8.12，例 8.13）。原始发生的投影读出有根树 $T$；整树程序在 $\beta(T)$ 步内执行完毕，纯语法解析器无需回求值即逆读回 $T$。每步执行在同一内生数学责任行上严格扣款 $B,B-1,\dots,0$；结清处完成值等于原求值且已付迹给出关系收据。真实环境变化后，残差请求以效应为值、预算 $r(e)+r(e')+2>0$，首步触发新责任准入（朱砂）并返回同一询问运行；全链无虚线外供输入框。

进一步，同一次发生处两条实际执行留下的完整关系边界之差，本身就能生成拥有独立语法预算的新查询并将反馈写回联合库存（C35–C38），而每张完成回执则将旧已付值与当前原生效应合成为完整更新总值写回出生环境（C42）：

**定理 8.14（同发生双边界差词的独立语法计费执行与联合库存反馈）。** 固定逐级源程序族生成的后继包及其精确发生。设 $b_\Psi,b_\mu$ 为该发生处两条共享环境 $\rho^+$ 的已付关系边界（均属于下一历史的关系闭包），其原生配对写回值为 $\mu=(\Psi,\sigma)$，后继作用域词读出 $Q^+$ 与常量嵌入 $c$ 满足 $Q^+(b_\Psi)=r-c(\Psi,0)$ 及 $Q^+(b_\mu)=r-c(\mu)$（其中 $r$ 为共同原根点）。则完整边界差形式词 $d:=b_\Psi-b_\mu$ 按有限支撑顺序展开生成独立系数表达式 $\mathrm{coeff}(d)$（完整证明见补充材料 S2.3）：

1. **公共根点抵消与精确差值**：$d$ 仍属于同一关系闭包且 $Q^+(d)=c(0,\sigma)$，在后继真实环境下的独立系数查询求值精确等于 $(0,\sigma)$；
2. **自有语法计费**：$\mathrm{coeff}(d)$ 的剩余步数精确等于其自有展开预算
   $$c(d):=\sum_{(e_i,a_i)\in\mathrm{suppList}(d)}\Bigl(|a_i|\bigl(r(e_i)+1\bigr)+\mathbf{1}_{a_i<0}+1\Bigr),\tag{8.4}$$
   定理 6.10 生成长 $c(d)$ 的执行迹与全部 $c(d)+1$ 个债务态，绝不借用任一母查询的计费回执；
3. **跨准入反馈与环境对齐方块**：对源族查询 $q$、已付终点 $q'$ 与动作变量代换绑定 $\theta$（代换记号见 §9.3），回答编译在同一根与访问处触发残差准入，将同源残差 $h=q\ominus q'$、代换反馈 $h+h[\theta]$（预算 $\ge 3$，求值等于形式迹边界的效应 $\mathrm{eff}_{\rho,\rho\circ\theta-\rho}(\delta_q-\delta_{q'})$）及新付暴露一并并入联合库存；有限入站配置保证动作读取器与原查询读取器的环境在每次发生处严格相等 $\mathrm{env}(\mathrm{actionReader}(o))=\mathrm{env}(\mathrm{queryReader}(o))$，且残差接收器因预算 $B_{\mathrm{res}}=r(e)+r(e')+2\ge 2$ 在首步后仍有 $B_{\mathrm{res}}-1\ge 1$ 而严格保持已付性。∎

**定理 8.15（每张完成回执写回总值并逐包重生解码器）。** 固定当次动作材料 $M=(\rho,\varepsilon,e,\mathrm{State},\mathrm{Trace},\mathrm{owner})$，设原计算已在常量终点 $\mathrm{const}(p)$ 处结清（其中 $p=\mathrm{ev}_\rho e$），新环境 $\rho+\varepsilon$ 下的残差请求为 $e\ominus\mathrm{const}(p)$，其定理 6.12 `Type` 完成回执给出的实际完成值记作 $n$。对任意已登记解码器 $\mathrm{write}$，将出生环境读取器在结清支路上设为读取 $\mathrm{write}(p+n)$，则同一运行满足（完整证明及常值零效应正控制见补充材料 S5.2）：

$$n=\mathrm{ev}_{\rho+\varepsilon}(e)-p,\qquad V:=p+n=\mathrm{ev}_{\rho+\varepsilon}(e),\qquad \rho_{\mathrm{Born}}=\mathrm{write}(V),\tag{8.5}$$

中间扣款支路仅推进数学已付态而不误写环境；进入下一共尾包时，程序从下一包自身实算结果 $p^+$ 重新生成新鲜解码器并写回 $p^++n^+$。即便更新效应 $n=0$ 而旧已付值 $p\neq 0$，出生环境仍准确写入 $\mathrm{write}(p)$，绝不因当步效应为零而抹掉已付成果。∎

---

## 9 完整执行：时序编码、全行动者恢复、双库存保序入库与最大未来不变核

第 8.5 节的残差请求展示了单条词如何提出下一问；而在真实多级运行中，一次访问还携带着完整时序历史、源与目标两套依赖历史、配对树每个节点上的测量算子以及物理与低层两类库存。本节证明同一份源程序在折叠效应的同时一并折叠完整时序与公共历史（§9.1，C28），全体配对节点行动者联合恢复全词模型与全部未来读出（§9.2，C29），任意源程序配置经通用准入保值携带双层库存与词—状态协变配对（§9.3，C30–C32），最终由默认运行将全词恢复、迹位置严格保序入库、共尾中间拍覆盖、六面余链复形与依值直和上的**最大未来不可见不变核模型**完整闭环（§9.4，C33–C34, C40, C43–C45）。

本节的分工边界须先行点明：**§9.1–§9.2** 沿用第 7 节设定（活根、时序访问 $v$、完备复内积空间 $\mathcal{H}$ 上安装的联合识别 $\mathrm{rec}$ 及审计协议，非终结步 $\mathrm{step}(v)$ 携带下一访问 $v^+$、源／目标历史 $\mathcal{H}_s,\mathcal{H}_t$ 与配对展开树），利用 $\mathcal{H}$ 的范数结构刻画多节点等距测量与纤维提升判据；而自 **§9.3 起直至第 10 节全文**，所有定理均**彻底卸去内积与拓扑完备性假设**，回归任意加法阿贝尔群载体——通用准入、双库存保序入库、六面余链复形、最大未来不可见核 $\mathsf{M}_{\mathrm{fut}}$ 及后续可逆增量续行纯由自由模与语法结构驱动，并在节末**例 9.13** 中直接落回例 1.1 的整数表达式手算核验。

### 9.1 单一联合程序折叠完整时序、公共历史与作用差反演判据

**定义 9.1（时序编码、发生回执与配对暴露）。** (1) **时序编码**：根的时序访问分为有限可达、封存共尾与后共尾三类，每类由归纳类型编码，**时序编码** $c$ 记录当前状态与该历史编码，编码 $\mathrm{enc}$ 与解码 $\mathrm{dec}$ 逐构造子互逆；(2) **发生回执与时序动作**：$\mathrm{rcpt}(c)$ 将 $c$ 与该当前规范发生的原源材料打包，$\mathrm{nx}(c)$ 取后继访问编码（终结处为空），时序动作定义为 $\mathrm{act}(c):=(\mathrm{rcpt}(c),\mathrm{nx}(c))$；(3) **配对暴露与行动者**：识别在每个配对位置安装三元组 $(M,A,U)$——$\mathbb{Z}$-线性测量 $M:\mathrm{Car}\to\mathcal{H}$、载体等变作用 $A$ 与 $\mathcal{H}$ 上的线性等距算子 $U$；源与目标配对展开树的**每一个节点位置**称为一个**行动者（actor）**（同一载荷在不同树位置重复出现时按位置分别计数）。

**定理 9.2（单一联合程序：完整时序、公共历史与作用差提升判据）。** 设 $\mathrm{step}(v)$ 落入命题 7.1 的完全生成支或联合残差支，$T$ 为命题 7.6 给出的对齐构造树。则（完整证明见补充材料 S3.1）：

1. **时序编码双逆**：$\mathrm{dec}\circ\mathrm{enc}=\mathrm{id}$，$\mathrm{enc}\circ\mathrm{dec}=\mathrm{id}$，$\mathrm{act}$ 为单射，且编码与实际后继严格交换 $\mathrm{enc}(v^+)=\mathrm{nx}(\mathrm{enc}\,v)$；
2. **联合整树程序计费与语法逆读**：为 $T$ 每个节点赋予编码 $\mathrm{enc}(v)$ 得树 $T_J$，五分量构造子 $\kappa_J$ 同步折叠依赖效应 $\tau(T)$、回执树及两侧历史／求值／暴露数据；在配对环境 $(\delta,\delta'-\delta)$ 下，$\mathrm{prog}_{\kappa_J}T_J$ 的严格扣款迹长恰为 $\beta(T_J)=\beta(T)$，每计数处纯语法左逆还原 $T_J$ 与访问 $v$，且更新提升残差为零当且仅当目标纤维元素来自旧纤维元素的更新像；
3. **双历史公共闭包**：$\mathcal{H}_s$ 与 $\mathcal{H}_t$ 的延续生成并集公共历史，任一侧词在公共完备化中像为零当且仅当它落入公共历史的关系闭包（两侧零纤维正合），两侧完备化载体乘积 $\mathrm{Src}\times\mathrm{Tgt}$ 导出 $\ell^2(\mathcal{H}\times\mathcal{H})$ 上的等距测量演化；
4. **作用差的双残差充要提升判据**：设节点处双侧暴露作用后的值为 $a_s,a_t$，历史转移载体映射为 $\iota$，作用差为 $d:=a_t-\iota(a_s)$。则源纤维中存在 $r\in\mathrm{Fib}_{\partial_s}(a_s)$ 满足 $\iota(r)=a_t$，**当且仅当**余核像残差 $[d]\in\operatorname{coker}\iota$ 与测量观察残差 $\partial_t a_t-\partial_s a_s\in\mathcal{H}$ 同时为零；一个固定 $25$ 步的内生计费程序逐步扣款算出三元组 $(d,\partial d,[d])$；
5. **规范直达后继**：$\mathrm{step}(v)$ 的目标发生严格等于 $\mathrm{step}(v^+)$ 的源发生，目标历史与下一源历史的生成元闭包、关系闭包及整棵暴露树逐项相等。∎

### 9.2 全体行动者：全词模型、有序效应历史与全未来联合恢复

单看配对树根会漏掉内部节点的中间抵消；把整棵配对展开树上的所有行动者合为字母表 $L$（含全部源行动者、全部目标行动者与双根同步字母，读出映射 $\mathrm{rd}$ 合粗粒度读取器与全体行动者测量于一体），即可完全恢复有限字轨道上的可观测结构（类比线性系统极小能观实现[[10]](#ref-10)与余代数终商[[9]](#ref-9)，但无需域结构或有限维假设）。

**定理 9.3（全体行动者的全词模型与全未来联合恢复）。** 在上述设定下（完整证明见补充材料 S3.2）：

1. **全词可观测商模型**：令 $K:=\{x:\forall w\in L^*,\ \mathrm{rd}(A_w x)=0\}$，商模 $\mathrm{Mod}:=\mathrm{Car}/K$ 上每个字母作用良定下降，两点同像充要于经任意有限动作词 $w\in L^*$ 作用后读出全等，且 $\mathrm{Mod}$ 与全词读出完备化载体线性同构；
2. **防抵消擦除的有序效应历史**：对任意词 $w=\ell_1\cdots\ell_n$ 与点 $x$（记 $x_k=A_{\ell_k}\cdots A_{\ell_1}x$，$\mathcal{U}_w=U_{\ell_n}\cdots U_{\ell_1}$），总协变残差精确分解为各步残差经后续等距演化搬运之和：
   $$\mathcal{U}_w M(x)-M(A_w x)=\sum_{k=1}^n U_{\ell_n}\cdots U_{\ell_{k+1}}\bigl(U_{\ell_k}M(x_{k-1})-M(x_k)\bigr),$$
   长 $n$ 的有序效应历史逐拍封存 $(\ell_k,x_{k-1},\text{步残差})$——即便首末总残差正负相消为零，非零中间步残差仍逐位保留；
3. **节点 $\ell^2$ 等距与三面双逆恢复**：按配对树全体位置（含重数）索引的测量 $\mathrm{meas}:\mathrm{Mod}\to\ell^2(\text{positions};\mathcal{H})$ 满足 $\|\mathrm{meas}(x)\|^2=\sum_p\|M_p(x)\|^2$ 且字母演化为线性等距；合并粗读取器与全部未来 $\mathcal{H}$ 读取器的映射在 $\mathrm{Mod}$ 上为单射，且种子在全词作用下的最小稳定子模（完整轨道载体）上整面、相干共尾面与粗面三面联合单射并与一切词作用可交换；对任意查询词 $q$，长 $|q|+3$ 的内生计费执行精确算回下一状态值并禁止同债回充。∎

### 9.3 通用源程序准入、双层库存保值跨越与词—状态协变配对

**定义 9.4（源程序配置）。** 第 8.5 节询问帧上的一个**源程序配置** $\mathcal{S}$ 仅由三项数据给定：独立低层变量族 $L$、可选附加投影以及在每次发生处给出配对值载体（旧值，效应）原输入 $(\rho,e)$ 的读取器（可附下一环境与库存解码器）。

**定理 9.5（通用源程序准入：已付查询内生触发下一责任出生）。** 对任意询问帧 $\Phi$ 与源程序配置 $\mathcal{S}$，设同源运行回答后的状态为 $s$、当前发生为 $o$、下一查询环境为 $\rho'$。则（旧投影保持与游标移位合同见补充材料 S4.1）：(1) 当次材料在更新环境 $\rho'=\rho+(\rho'-\rho)$ 上装配残差请求，求值等于效应，且因正预算 $r(e)+r(e')+2>0$ 在同一根与访问处必然编译为**新责任准入**（保持首次整账写入）；(2) 出生帧启动定理 8.12 的良基无回充运行，出生帧环境等于旧值加效应的更新总值（宏历史从第 $k$ 拍直达第 $k+2$ 拍），旧库存与新付暴露通过并列种子嵌入无损合流于出生库存。∎

**定理 9.6（双层类型化库存保值跨越准入与逐事件逆读）。** 在定理 9.5 设定下，记帧的物理层原输入为 $(\rho_P,e_P)$、源程序的低层原输入为 $(\rho_L,e_L)$，定义常量代换绑定 $\sigma(x):=\mathrm{const}(\rho_P(x))$。则（完整证明见补充材料 S4.2）：(1) 对任意表达式 $e$ 有 $\mathrm{ev}_{\rho_L}(e[\sigma])=\mathrm{ev}_{\rho_P}(e)$，代换已付迹保持关系边界且长度恰为 $r(e_P[\sigma])$；(2) 完整材料登记为根投影后，准入目标通过投影类型等式（而非数值巧合）异质无损继承该材料；(3) 物理库存经 $\sigma$ 代换与低层库存并列合成为出生库存，其坐标映射在数学步与出生步下均为单射并逐一读回原事件；(4) 按出生库存事件索引的词族其典范余像残差为零当且仅当结果值为零。∎

**定理 9.7（源词—状态双线性协变配对与迭代前缀计费）。** 固定运行时及其源过程，记状态 $s$ 的旧环境为 $\rho_s$、单拍增量为 $\varepsilon_s=\rho_{\sigma(s)}-\rho_s$，设轨道变量代换绑定 $\sigma$ 满足 $\mathrm{ev}_{\rho_s}(\sigma x)=\rho_{\sigma(s)}(x)$ 与 $\mathrm{eff}_{\rho_s,\varepsilon_s}(\sigma x)=\varepsilon_{\sigma(s)}(x)$。则（完整证明见补充材料 S4.3）：(1) 自由模泛性质定义值留存在原载体中的 $\mathbb{Z}$-双线性配对 $\langle w,\delta_s\rangle:=(\mathrm{ev}_{\rho_s}w,\ \mathrm{eff}_{\rho_s,\varepsilon_s}w)$；(2) 代换算子 $\sigma^*(w):=w[\sigma]$ 与状态推进算子 $A$ 满足全载体协变对偶 $\langle\sigma^*w,u\rangle=\langle w,Au\rangle$，从而诱导配对余像商模上的良定时间推进 $\mathrm{act}^n[e]=[e[\sigma]^n]$（第 $d$ 拍读 $e[\sigma]^n$ 严格等于第 $d+n$ 拍读 $e$）；(3) 前缀 $0,\dots,n$ 独立执行总步长为 $\Sigma_n=\sum_{i\le n}r(e[\sigma]^i)$，合并为单次向量批次查询时语法预算精确等于 $\Sigma_n+2(n+1)$，且所需有限快照可逐项从实际调用帧环境无损恢复。∎

### 9.4 默认运行、全词保序入库、六面余链复形与最大未来不变核

**定理 9.8（默认运行同步执行源生请求与新旧子树）。** 定理 9.2 联合程序的根与读取器生成初始询问帧及默认运行（完整证明见补充材料 S5.1）：(1) 在每一计数处，查询原输入即为当次发生的源生请求，已付迹长等于登记输入剩余步数，出生配对库存合流既往写入与当次新付；(2) 单一主表达式将原查询、旧编码子树与下一编码子树经三个组合节点合一执行，求值为 $(\mathrm{ev}(\text{query}),\ \mathrm{ch}(c_{\mathrm{old}})+\mathrm{ch}(c_{\mathrm{next}}))$，语法总预算精确为 $r(\text{query})+c_{\mathrm{old}}+c_{\mathrm{next}}+3$，旧／新行动者分量之和读回当拍源操作状态点；(3) 子树环境由更新后的出生环境经同一原绑定读出。∎

在跨周期接力中，如果先投影裁剪执行帧再做恢复，就会丢失同读数异拍号的区分信息；必须**先恢复完整形式源词，再限制读取执行帧与双库存**，并将已付迹的每一个位置严格保序地注入出生库存。举例而言，若某查询产生两条求值结果同为 $0$ 但处于第 $0$ 步与第 $1$ 步的中间关系事件，集合去重会把它们压成一项，而下面的保序单射将它们精确存放在相隔 $1$ 位的互异地址上：

**定理 9.9（先恢复完整源词再读执行帧及已付迹位置保序单射入库，C40）。** 固定密封询问运行时 $\mathcal{R}$、完整原生形式载体 $\mathcal{F}=\mathbb{Z}[\mathcal{R}.\mathrm{State}]$、典范全词模型商映射 $q$ 及恢复映射 $\mathrm{rec}$，令 $O:\mathcal{F}\to\mathbb{Z}[\mathrm{Frame}]$ 为读取状态内登记帧的线性映射。则（完整证明见补充材料 S4.4）：

1. **全词无损恢复与帧推进单射**：对任意完整形式词 $w\in\mathcal{F}$ 有 $\mathrm{rec}(q(w))=w$；在第 $i$ 拍状态 $s_i$ 及模型作用 $A$ 下满足
   $$O\,\mathrm{rec}\bigl(q(\delta_{s_i})\bigr)=\delta_{\Phi_i},\qquad O\,\mathrm{rec}\bigl(Aq(\delta_{s_i})\bigr)=\delta_{\Phi_{i+1}},\tag{9.1}$$
   完整恢复当前、已付态、原输入、全迹、解码器与双库存，且模型点关于拍号 $i$ 为单射；
2. **已付迹位置严格保序单射入库**：记旧已写库存与物理已写库存的迹长分别为 $L_{\mathrm{old}},L_{\mathrm{phys}}$，则当次源查询完整迹暴露的每个位置下标 $j$ 经严格递增单射 $\iota(j)=j+L_{\mathrm{old}}+L_{\mathrm{phys}}+3$（偏移量 $3$ 来自三道并列种子接缝）嵌入实际出生库存 $H_B$，满足 $H_B.\mathrm{trace}[\iota(j)]=H_Q.\mathrm{trace}[j]$，不同位置上的同值事件严格分槽保存（旧初访与新当前两处读取器亦沿各自当前恒等保持独立，见补充材料 S4.4）。∎

**定理 9.10（同一运行中的共尾准入停点与完整中间已付段覆盖，C43）。** 在保留实际动作读取器的源程序族运行中，源从任意帧 $t$ 内生计算到达下一准入包的 `Type` 步距 $d(t)$，递推定义准入停点序列（完整证明见补充材料 S5.3，结构见图 7A）：

$$t_0:=d(0),\qquad \ell_j:=1+d(t_j+1),\qquad t_{j+1}:=t_j+\ell_j,\qquad A_{\mathcal{R}}^{\ell_j}W_{t_j}=W_{t_{j+1}}.\tag{9.2}$$

则 $(t_j)_{j\in\mathbb{N}}$ 为严格递增且在 $\mathbb{N}$ 中共尾（$t_j\ge j$）的实际准入停点；相邻包 $j$ 与 $j+1$ 之间的完整运行段恰好覆盖原运行的全部中间拍 $t_j,t_j+1,\dots,t_j+\ell_j$（含初始准入、全部中间扣款拍、结清与下一准入，包等级 $j$ 在扣款期间固定而因果深度递增），且完整场词 $W_t$ 在原状态点作用 $A_{\mathcal{R}}$ 下经 $\ell_j$ 步精确推进至 $W_{t_{j+1}}$，无需任何外部未来包表。∎

![图 7 单张回执恢复完整总值，下一回执重生旧值与解码器](figures/vector/figure7-receipt-feedback-v2.png)

**图注**。图 7｜单张回执恢复完整总值，下一回执重生旧值与解码器（结构图；定理 8.15、9.10，§10.4）。A：当次材料给出 $p=\operatorname{ev}_\rho(e)$，结清处原生残差值 $n=\operatorname{ev}_{\rho+\varepsilon}(e-\mathrm{const}(p))$ 与之合成为总值 $V=p+n$，新解码器写入本回执完整总值；唯独结清支路触发出生，横带保留同一运行中的全部中间已付拍。B：预解梳完整计算结果 $v=R^m q_0$ 生成环境增量 $\delta_v=\operatorname{constEnv}(v)-\rho$ 进入下一环境，原算子 $R$ 先完整执行 $u=Rv$ 再正交分解为 $Pu$ 与 $(1-P)u$；朱砂标出总值合成与由实算值生成的环境更新。

**定理 9.11（同一实际已付边界同步生成六面复形与跨出生保留，C44）。** 对每个共尾准入包 $j$，取其实际已付材料 $M_j$、原表达式 $e_j$、已付终点 $e'_j$、执行迹 $T_j$ 与前缀历史 $H_j$，记形式边界 $b_j:=\delta_{e_j}-\delta_{e'_j}$。则同一份 $M_j$ 同步构造出**代数面**（$(e_j,e'_j,e_j\ominus e'_j)$ 与全系数配对）、**组合面**（全迹 $T_j$ 及步级暴露位置）、**拓扑面**（实际历史关系闭包 $H_j.\mathrm{relationClosure}$）、**逻辑面**（链复合为零）、**关系面** $\sigma_j=(b_j,\,b_j\in H_j.\mathrm{relationClosure})$ 与**余链面**（完整证明见补充材料 S3.3）：

$$C_1\xrightarrow{\ d_1\ }C_0\xrightarrow{\ d_0\ }\widehat C_0,\qquad d_1(\sigma_j)=b_j,\qquad d_0\bigl(d_1(\sigma_j)\bigr)=0,\tag{9.3}$$

其中 $d_1$ 为关系闭包嵌入、$d_0$ 为历史完备化投影；在更新环境 $\rho_j+\varepsilon_j$ 下 $b_j$ 的效应读数恰等于残差请求值，全词余像恢复满足 $\mathrm{rec}(\mathrm{can}(w))=w$；跨出生搬运保留旧 $(b_j,\sigma_j,T_j)$ 的独立身份，并与新请求在出生环境 $\rho_B$ 下归一化生成的新边界 $\sigma_B$ 分开入库。∎

**定理 9.12（依值直和整词源作用与最大未来不可见不变核模型，C45）。** 设实际共尾包 $j$ 的完整形式词模为 $\mathcal{W}_j$，取有限支撑直和共同载体 $\mathcal{W}:=\bigoplus_{j\in\mathbb{N}}\mathcal{W}_j$。下一包处的配对提升与语言搬运生成逐步作用 $S_j:\mathcal{W}_j\to\mathcal{W}_{j+1}$ 及共同线性算子 $S\bigl(\sum_j\iota_j(w_j)\bigr):=\sum_j\iota_{j+1}(S_j w_j)$；记第 $j$ 站点的成对读出为 $d_j(u):=(\mathrm{ev}_{\rho_j}u,\mathrm{eff}_{\rho_j,\varepsilon_j}u)$，共同读出为 $D_j(w):=d_j(w_j)$。令单字母允许动作词集为 $\{\ast\}^{<\omega}$（$S_{[\,]}=\mathrm{id},\ S_{a\ast}=S\circ S_a$），定义（完整证明见补充材料 S5.4）：

$$K_{\mathrm{fut}}:=\bigcap_{a\in\{\ast\}^{<\omega}}\bigcap_{j\in\mathbb{N}}\ker(D_j\circ S_a),\qquad \mathsf{M}_{\mathrm{fut}}:=\mathcal{W}/K_{\mathrm{fut}}.\tag{9.4}$$

则：(1) **接收器配对方块**：在下一包原接收器环境中求值有 $\mathrm{ev}_{\rho_{j+1}^{\mathrm{rec}}}(S_j w)=d_j(w)$（无需假定不同等级环境相等 $\rho_{j+1}=\rho_j$），原库存成员在 $S_j$ 下保持入库；(2) **全未来同余刻画**：两整词在 $\mathsf{M}_{\mathrm{fut}}$ 中相等当且仅当经一切允许未来词 $a\in\{\ast\}^{<\omega}$ 作用后在一切站点 $j$ 的读出全等；(3) **最大不变不可见子模泛性质**：$S(K_{\mathrm{fut}})\subseteq K_{\mathrm{fut}}$ 使 $S$ 与全部 $D_j\circ S_a$ 唯一诱导至 $\mathsf{M}_{\mathrm{fut}}$，且 $K_{\mathrm{fut}}$ 是 $\mathcal{W}$ 中**当下全站点不可见（$\subseteq\bigcap_j\ker D_j$）且在源作用 $S$ 下不变的最大子模**；在空词 $a=[\,]$ 处自然投影回当前联合完备化并与模型作用严格交换。∎

**例 9.13（两包运行在 §9.3–§9.4 中的保序入库地址、共尾停点与最大未来核手算验算）。** 取例 1.1(b) 的整数值群 $W=\mathbb{Z}$ 与初始表达式 $e_0=x+x$，设初始环境为 $\rho_0(x)=3$、下一包环境移至 $\rho_1(x)=5$（增量 $\varepsilon_0=+2$），初始旧库存与物理库存均为空（$L_{\mathrm{old}}=L_{\mathrm{phys}}=0$）：

1. **保序单射地址（定理 9.9）**：包 $0$ 执行 $e_0=x+x$ 的 $r(e_0)=3$ 条原语步（下标 $j=0,1,2$），经 $\iota(j)=j+0+0+3=j+3$ 依次写入出生库存槽位 $\iota(0)=3,\ \iota(1)=4,\ \iota(2)=5$；即便在 $\rho_0(x)=0$ 的退化情形下前两步端点求值全为 $0$，两次绑定事件仍分居槽位 $3\neq 4$ 而绝不合并，且必须先由 $\mathrm{rec}(q(w))=w$ 还原未商化状态词后才能读出这三处精确槽位。
2. **共尾停点递推（定理 9.10）**：起点到达首包结清的步距为 $t_0=d(0)=r(x+x)=3$（第 $0,1,2$ 拍严格扣款 $3\to 2\to 1\to 0$，第 $3$ 拍结清于 $e'_0=\mathrm{const}(6)$ 并在第 $4$ 拍准入残差请求 $e_1=e_0\ominus\mathrm{const}(6)$）；第 $4$ 拍的剩余步数为 $d(4)=r(e_0\ominus\mathrm{const}(6))=3+0+2=5$，故段长 $\ell_0=1+d(4)=6$，第二准入停点精确落在 $t_1=t_0+\ell_0=3+6=9$，原状态作用 $A_{\mathcal{R}}^6 W_3=W_9$ 在同一运行内完整覆盖全部中间拍 $3,4,\dots,9$。
3. **六面边界与最大未来核判别（定理 9.11–9.12）**：在包 $0$ 处，已付迹形式边界 $b_0=\delta_{x+x}-\delta_{\mathrm{const}(6)}$ 满足余链复合 $d_0(d_1(\sigma_0))=0$（因 $\mathrm{ev}_{\rho_0}(b_0)=6-6=0$），但站点成对读出为 $d_0(b_0)=(\mathrm{ev}_{\rho_0}b_0,\ \mathrm{eff}_{\rho_0,+2}b_0)=(0,4)\neq(0,0)$，故 $\iota_0(b_0)\notin K_{\mathrm{fut}}$（未来环境变化立即暴露该关系边界的非零效应）；反之，考察非零形式差词 $z_0:=\delta_{(x+x)\ominus\mathrm{const}(6)}-b_0\in\mathcal{W}_0$，对任意环境 $\rho$ 与增量 $\varepsilon$ 均有 $\mathrm{ev}_\rho(z_0)=(2\rho(x)-6)-(2\rho(x)-6)=0$ 及 $\mathrm{eff}_{\rho,\varepsilon}(z_0)=2\varepsilon(x)-2\varepsilon(x)=0$，故 $D_j(S_a(\iota_0(z_0)))=(0,0)$ 对一切允许未来词 $a\in\{\ast\}^{<\omega}$ 与站点 $j$ 恒成立，从而给出非零元 $\iota_0(z_0)\in K_{\mathrm{fut}}$——这正是紧接第 10.1 节定理 10.1 一般化的精确原型。∎

---

## 10 可逆增量续行、跨领域实装与四轴文献对话

定理 9.12 建立了跨共尾包的整词源作用 $S$ 与最大未来模型 $\mathsf{M}_{\rm fut}$，但要把这套过程代数锻造为真正**无损、可复用且双向可逆的增量计算核**，还必须回答三个决定性的收官问题：

1. 当前包结清产生的可执行残差差词 $e\ominus e'$ 与代数迹边界 $\delta_e-\delta_{e'}$，能否无需另铸新付款事件即在全未来模型 $\mathsf{M}_{\rm fut}$ 中严格同余，并直达规范后继成为可写请求、驱动完整源程序作用于全部保留余项并同债完结（§10.1，C46–C49）？
2. 已被付清的常量语法树在嵌入两层残差表达式后，能否不借环乘法标量或外置缓存而由纯语法原位恢复，跨共尾持续执行任意预定加法同态 $f$，同时让整词每个中间原语步都驱动关系边界与上同调微分同步更新（§10.2，C51–C52）？
3. 已执行的每一条原语步与下一批生成的有号请求之间是否存在**双向可逆的精确区间寻址**（漏删或重复任何非空组皆被拦截），且当运行视野从 $\mathrm{fuel}$ 延长至任意 $\mathrm{total}\ge\mathrm{fuel}$ 时，能否严格锁死全部已付前缀而**仅从实际末态增量续跑缺失后缀**（§10.3，C53–C54）？

本节前三小节（图 8，完整自足证明见补充材料 S6）逐一给出肯定定理并在例 10.7 中手算走通全链，第 10.4 节展示三组跨领域实装（C41, C50 及 CPS1），第 10.5 节展开四轴文献对话。

![图 8 可逆增量续行：全未来语义零同余、双取反已付语法树复用与执行步—请求双向反演](figures/vector/figure8-reversible-continuation-v3.png)

**图注**。图 8｜可逆增量续行：全未来语义零同余、双取反已付语法树复用与执行步—请求双向反演（结构图；定理 10.1–10.6，C46–C49、C51–C54）。A：残差请求与已付迹边界之差 $\delta_{e\ominus e'}-(\delta_e-\delta_{e'})$ 属于全环境语义零子模 $\mathcal{Z}_{\rm sem}$，在一切允许未来词 $a\in\{\ast\}^{<\omega}$ 与站点 $j$ 下同属一个 $\mathsf{M}_{\rm fut}$ 等价类；重排联合代码 $\mathrm{jointCode}(c)$ 分离物理与残差输入求值，出生语法信用严格扣款 $B{-}1\to 0$（即便语义效应为零仍付语法费）并交出 $\mathrm{eff}_{\rho,\varepsilon}(e)$、旧／出生行及规范后继。B：$\mathrm{retainedCode}$ 以纯语法双取反 $(-\mathrm{id})((-\mathrm{id})(e'))$ 无环标量恢复已付常量语法树 $p=\mathrm{ev}_\rho(e)$，驱动预定加法同态逐级提升 $f^{(n+1)}$ 在下一共尾包算出 $(f^{(n+1)}(p),0)$ 并写入出生库存；$\mathrm{embeddedTrace}$ 逐原语回放使替换链映射 $\tau_1$、实际边界 $b_{\rm act}$ 与余链微分 $d^{0,1}$ 严格锁步。C：正向 $\mathrm{stepInterval}$ 将步骤 $i$ 映为连续请求切片 $[a_i,a_i+c_i)$，反向 $\mathrm{readRequestOrigin}$ 将任意请求 $r$ 按 $r=a_i+s$ 唯一反演回源步骤与支撑位（漏删或重复任一非空组必改变原生迹），$\mathrm{extendTo}$ 锁死已付前缀仅从末态续跑 $\mathrm{total}-\mathrm{fuel}$ 步（单遍时间表长 $\mathrm{fuel}+1$）。

### 10.1 全环境语义零同余、保留余项联合求值与同债完结（C46–C49）

定义形式词模中的**全环境语义零子模**为在一切环境赋值下求值恒为零的子模：

$$\mathcal{Z}_{\mathrm{sem}}(\kappa):=\bigl\{w\in\mathrm{Fm}_{\mathbb{Z}}(\kappa)\ \big|\ \forall\rho\in\mathrm{Env},\ \mathrm{ev}_\rho(w)=0\bigr\}.$$

与固定单环境核 $\ker(\mathrm{ev}_{\rho_0})$（例 4.2 指出 $x^2-x\in\ker(\mathrm{ev}_1)$ 但 $\notin\ker(\mathrm{ev}_2)$）截然不同，$\mathcal{Z}_{\mathrm{sem}}$ 中的恒等关系在任何环境演化与配对提升下永不破灭。

**定理 10.1（全环境语义零关系、最大未来核同余与规范后继可写请求，C46）。** 对任意逐级源程序族、初始询问帧、程序配置、语言等式及实际共尾包序数 $j$，记当前选定已付材料的原表达式为 $e_j$、已付态表达式为 $e'_j$。则（完整证明见补充材料 S6.1）：

1. **全环境语义零与配对提升封闭性**：可执行残差单点生成元与形式迹边界之差恒属于全环境语义零子模，且在一切更新库存、逐层配对提升 $\widetilde{(\cdot)}$ 与包／语言搬运下封闭：
   $$\begin{aligned}\delta_{e_j\ominus e'_j}-(\delta_{e_j}-\delta_{e'_j})&\in\mathcal{Z}_{\mathrm{sem}}\\ \Longrightarrow\quad \forall a\in\{\ast\}^{<\omega},\ \forall m\in\mathbb{N},\ \ D_m\Bigl(S_a\bigl(\iota_j(\delta_{e_j\ominus e'_j})-\iota_j(\delta_{e_j}-\delta_{e'_j})\bigr)\Bigr)&=(0,0),\end{aligned}\tag{10.1}$$
   故残差请求与已付迹边界在定理 9.12 的最大未来模型 $\mathsf{M}_{\mathrm{fut}}=\mathcal{W}/K_{\mathrm{fut}}$ 中严格代表**同一个全未来等价类**；
2. **直达规范后继的可写请求与双行去向**：定理 6.12 选定的完成回执直接驱动结算出生程序，使实际下一准入包 $j+1$ 的当前状态严格等于该结算目标的规范后继当前；整份已付材料（环境、语法树、状态、执行迹与责任持有人）沿该当前等式搬运为包 $j+1$ 内自产的可写原生请求，其模型类与源边界同余，且原旧活账行与新出生行由同一次整账写入一并给出目标去向。

证明思路。对任意环境 $\rho$，$\mathrm{ev}_\rho(\delta_{e\ominus e'})=\mathrm{ev}_\rho(e)-\mathrm{ev}_\rho(e')=\mathrm{ev}_\rho(\delta_e-\delta_{e'})$，故差词落入 $\mathcal{Z}_{\mathrm{sem}}$。若 $w\in\mathcal{Z}_{\mathrm{sem}}$，对任意旧环境 $\rho$ 与增量 $\varepsilon$，由更新等式 $\mathrm{ev}_{\rho+\varepsilon}(w)=\mathrm{ev}_\rho(w)+\mathrm{eff}_{\rho,\varepsilon}(w)$ 知 $0=0+\mathrm{eff}_{\rho,\varepsilon}(w)$，故成对库存 $U_{\rho,\varepsilon}(w)=(0,0)$；而任意配对环境均可拆为 $(\rho,\varepsilon)$，故 $\widetilde w\in\mathcal{Z}_{\mathrm{sem}}$。对允许未来词 $a\in\{\ast\}^{<\omega}$ 的长度归纳即证 $S_a$ 将该差词留在全站点 $\mathcal{Z}_{\mathrm{sem}}$ 中，从而属于 $K_{\mathrm{fut}}$（补充 S6.1）。∎

**定理 10.2（跨共尾源程序重生、保留余项重排联合求值与同债严格结清，C47–C49）。** 给定配对值载体上的源所属代码 $c\in\mathrm{Expr}(V\times V)$ 及逐级源程序族（完整证明见补充材料 S6.2）：

1. **全保留余项重排联合求值（C47）**：定义双层配对载体上的加法同态 $\mathrm{regroup}\bigl((u_{11},u_{12}),(u_{21},u_{22})\bigr):=\bigl((u_{11}+u_{21},0),(u_{12}+u_{22},0)\bigr)$，令联合代码为 $\mathrm{jointCode}(c):=(\widetilde c)[x\mapsto\mathrm{linear}_{\mathrm{regroup}}(\mathrm{var}\,x)]$。对任意完整双层环境 $\Theta$，记其合并嵌入的物理输入与保留残差输入分别为 $\rho_{\mathrm{phys}}(x):=(\pi_1(\Theta(x)_1+\Theta(x)_2),0)$ 与 $\rho_{\mathrm{res}}(x):=(\pi_2(\Theta(x)_1+\Theta(x)_2),0)$，则联合代码一次执行同时分离并相加给出完整作用值（定理 8.15 跨全部共尾包递归写回，查询与库存映射保持合同见补充材料 S6.2）：
   $$\mathrm{ev}_\Theta\bigl(\mathrm{jointCode}(c)\bigr)=\bigl(\mathrm{ev}_{\rho_{\mathrm{phys}}}(c),\ \mathrm{eff}_{\rho_{\mathrm{phys}},\rho_{\mathrm{res}}}(c)\bigr),\qquad \pi_1+\pi_2=\mathrm{ev}_{\rho_{\mathrm{phys}}+\rho_{\mathrm{res}}}(c);\tag{10.2}$$
2. **共同源输入与线性接收器同次出处（C48）**：原完整材料与动作读取器的原输入 $\mathrm{Raw}$ 共载于同一投影限制；下一访问处原输入环境 $\rho_{\mathrm{Raw}}$ 与解码出生环境 $\rho_{\mathrm{Born}}$ 自产精确增量 $\delta=\rho_{\mathrm{Born}}-\rho_{\mathrm{Raw}}$，使配对提升求值的两坐标之和严格等于 $\mathrm{ev}_{\rho_{\mathrm{Born}}}(e_{\mathrm{Raw}})$；在线性同态接收器中每次访问重读共同源，输出更新值等于初值加同源实际效应；
3. **同债语法信用严格扣款与完成回答交付（C49）**：出生帧已在准入处执行首步，剩余语法信用 $B-1\ge 1$ 在每个实际扣款分支上驱动同债严格减 $1$ 且禁止预算回充（即便语义效应 $\mathrm{eff}_{\rho,\varepsilon}(e)=0$ 仍照付全部语法步）；时钟后缀终点精确落回完成当前，求值等于 $\mathrm{eff}_{\rho,\varepsilon}(e)$，并经原结算编译一并交出完成回答、回执、旧／出生双行整账去向及规范直达后继。∎

### 10.2 双取反恢复已付语法树、跨共尾同态续行与逐原语上同调回放（C51–C52）

在仅要求加法阿贝尔群（未必有环单位元 $1$ 或标量乘法）的通用值载体 $W_s$ 上，已结清终点 $\mathrm{const}(p)$ 进入下一帧时被包裹在残差表达式 $e\ominus\mathrm{const}(p)=\mathrm{add}(e,\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(p)))$（或附加有限入站项 $g$ 后的两层加法 $\mathrm{add}(\mathrm{add}(e,\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(p))),g)$）之中。如何在不外借历史表、亦不引入环标量的条件下，从当前帧登记表达式原位取回已付常量语法树并持续施加任意预定加法同态 $f:W_s\to W_s$？

**定理 10.3（两层残差语法双取反提取与跨共尾预定加法同态续行，C51）。** 对任意加法群族 $W$、预先固定的加法同态 $f:W_s\to W_s$ 及逐级配对群 $V_0=W,\ V_{n+1}=V_n\times V_n$，归纳定义逐级同态 $f^{(0)}:=f,\ f^{(n+1)}:=f^{(n)}\times f^{(n)}$，并在第 $n$ 级询问帧 $\Phi$ 上按登记表达式语法定义**保留代码提取器**：

$$\mathrm{retainedCode}_n(\Phi):=\begin{cases}\mathrm{linear}_{-\mathrm{id}}(\mathrm{paid}),&\text{若登记式形如 }\mathrm{add}(\mathrm{add}(\_, \mathrm{paid}),\_)\ \text{或 }\mathrm{add}(\_,\mathrm{paid}),\\ e_{\mathrm{src}},&\text{其他情形 }e_{\mathrm{src}}.\end{cases}\tag{10.3}$$

令方法原输入在零增量配对环境 $(\rho_\Phi,0)$ 下执行 $\mathrm{linear}_{f^{(n+1)}}(\widetilde{\mathrm{retainedCode}_n(\Phi)})$。则对任意逐级源程序族与实际共尾包 $P_n$（完整证明见补充材料 S6.3）：

1. **无环标量精确恢复已付语法树**：沿定理 6.12 已付前缀登记输入保持不变；包 $P_n$ 的配对动作计算结清于完成值 $p\in V_{n+1}$ 后跨越出生使 $\mathrm{paid}=\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(p))$，故 $\mathrm{retainedCode}_{n+1}$ 异质等于双取反语法树 $\mathrm{linear}_{-\mathrm{id}}(\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(p)))$，在任意环境下求值严格还原前一包的完整已付结果 $-(-p)=p$（在第 $0$ 级帧直接执行方法原输入时则将 $p_0\in V_0$ 送入 $f^{(1)}(p_0,0)=(f(p_0),0)\in V_1$）；
2. **跨共尾预定同态求值与全迹入库**：下一实际共尾包 $P_{n+1}$ 在第 $n+1$ 级帧上执行 $\mathrm{linear}_{f^{(n+2)}}(\widetilde{\mathrm{retainedCode}_{n+1}})$，动作结果精确等于 $\bigl(f^{(n+1)}(p),\ 0\bigr)\in V_{n+2}$（保留完整前代成对结构，当次新增效应坐标由零增量定为 $0$）；当次完整查询执行迹经库存保存映射全数并入出生库存 $\mathrm{writtenStock}$，并在发射器前同步安装四面表示、对偶读回与余链结构，对任意有限更新步同样进入密封场运行时的真实源作用段。∎

不仅最终常量值可以跨包同态续行，源表达式归约途中的**每一步中间原语发生**都可以原样嵌入原生载体环境，驱动关系闭包、上同调余链微分与余像作用严格锁步前进（C52）：

**定理 10.4（整词逐原语原生回放与库存—边界—余链微分同步更新，C52）。** 设源过程 $\mathcal{P}$ 配有状态环境读出 $\mathrm{readEnv}:S\to\mathrm{Env}$，由命题 2.5 自由延拓为观察环境 $\rho^{\mathrm{obs}}_w$（在状态点 $w=\delta_{s_t}$ 处还原 $\mathrm{readEnv}(s_t)$），记上下文嵌入为 $\mathrm{embed}$、轨道代换绑定为 $\sigma$。则（完整证明见补充材料 S6.4）：

1. **逐原语步嵌入与精确代换计费**：递归转换器 $\mathrm{embeddedStep}$ 与 $\mathrm{embeddedTrace}$ 将观察环境下的每一步原语归约 $s:e_1\to e_2$ 构造为上下文环境下的真实执行迹，经 $\sigma$ 代换与零效应配对提升得到正向回放迹 $\mathrm{pairedForward}$，其步长精确等于代换式剩余步数 $r(\mathrm{embed}(e)[\sigma])$；
2. **出生入库与跨包查询继承**：在密封运行时任意计数 $k$ 处，回放迹暴露与原已付迹一并写入当次出生库存 $\mathrm{birthStock}$，并全部保留在下一出生帧的完整已写查询迹之中；
3. **链映射、实际边界、余链微分与余像四路锁步**：记源回放迹生成的整数关系词为 $\mu_k$、代换诱导的复形链映射为 $\tau_1$、下一历史关系闭包 $X^0$ 中的实际边界元为 $b_{\mathrm{act},k}$、从关系闭包 $X^0$ 到生成元闭包 $X^1$ 的自然上同调 $0\to 1$ 阶微分（子模包含映射）为 $d^{0,1}:X^0\hookrightarrow X^1$、作用在 $X^1$ 上的完备化投影为 $\pi_{\mathrm{comp}}$。则对每个计数 $k$ 成立底层词与商类严格锁步恒等式：
   $$\begin{aligned}\mathrm{rel}_{\widetilde\rho_k}\bigl(\tau_1(\mu_k)\bigr)=b_{\mathrm{act},k}&=d^{0,1}(b_{\mathrm{act},k}),\qquad \pi_{\mathrm{comp}}\bigl(d^{0,1}(b_{\mathrm{act},k})\bigr)=0,\\ \mathrm{act}_{\mathrm{coim},k}\bigl([\mathrm{rel}(\mu_k)]_{k+1}\bigr)&=[b_{\mathrm{act},k}]_k,\end{aligned}\tag{10.4}$$
   且有根展开经投影擦除精确还原当帧根读出 $\mathrm{rootRead}$。∎

### 10.3 执行步—请求双向区间反演与封存前缀末态续行（C53–C54）

在多步计算向下一批接收器成批移交有号请求时，若仅对比批次总和，漏掉一对正负抵消的步骤或重复提交同一组请求都可能逃过总和检查。定理 10.5 在“已执行的每一步原语步”与“下一批展开的每一条有号请求”之间建立**无间隙、无重漏的双向区间反演**（对照逻辑可逆计算[[4]](#ref-4)需逆算消去历史磁带，此处直接通过单调前缀偏移实现双侧精确寻址）；定理 10.6 则证明封存运行历史在延长观察视野时绝不重跑已付前缀，仅从已达末态增量续跑缺失后缀。

**定理 10.5（已执行原语步与下一批有号请求的双向区间反演及防漏重门禁，C53）。** 固定逐级源程序族、准入包 $P$ 与真实出生处的执行记录 $E$，记已付迹各步关系词经源词作用 $S_P$ 移交后展开的下一批有号请求总表为 $\mathcal{B}$（表长 $N=|\mathcal{B}|$），已付步骤总数为 $M$。则（完整证明见补充材料 S6.5）：

1. **正向连续请求切片（$\mathrm{stepInterval}$）**：对每一个已执行步骤下标 $i\in\{0,\dots,M-1\}$，存在唯一确定的连续区间 $[a_i,\,a_i+c_i)\subseteq\{0,\dots,N\}$，其中起点 $a_i$ 等于前 $i$ 步已展开请求前缀的长度，区间长度 $c_i$ 等于第 $i$ 步移交词完整有号支撑项的个数；总表切片 $\mathcal{B}[a_i : a_i+c_i)$ 逐项等于该步独立生成的有号请求表，且切片内有号请求词 $\mathrm{word}(q):=a(\delta_e-\delta_{\mathrm{const}(\mathrm{ev}_{\rho_{\mathrm{dec}}}e)})$ 之和严格等于该步移交词经库存解码环境 $\rho_{\mathrm{dec}}$ 读出的仿射边界 $\mathrm{affine}_{\rho_{\mathrm{dec}}}(S_P w_i):=S_P w_i-q_{\rho_{\mathrm{dec}}}(S_P w_i)$（其中 $q_\rho$ 为定理 4.4 逐项求值常量形式和）；
2. **反向唯一起源认回（$\mathrm{readRequestOrigin}$）**：反之，任取下一批总表中的一条有号请求序号 $r\in\{0,\dots,N-1\}$，无需外部索引表即可构造性反演出唯一源步骤下标 $i\in\{0,\dots,M-1\}$、步内有号支撑槽位 $s\in\{0,\dots,c_i-1\}$、有号系数及精确前缀分解，满足双向寻址恒等式
   $$r = a_i + s,\qquad \bigsqcup_{i=0}^{M-1}\mathcal{B}[a_i : a_i+c_i)=\mathcal{B},\qquad \sum_{i=0}^{M-1}\sum_{q\in\mathcal{B}[a_i:a_i+c_i)}\mathrm{word}(q)=\sum_{q\in\mathcal{B}}\mathrm{word}(q);\tag{10.5}$$
3. **整批拼接与防漏重负控制门禁**：按原步骤顺序拼接全部切片 $\mathcal{B}[a_i : a_i+c_i)$（空切片保留原位下标）即一字不差还原整批请求表 $\mathcal{B}$、完整已执行迹 $\mathrm{executedTrace}(\mathcal{B})$ 及联合余链总边界；对任意产生非空切片（$c_i>0$）的实际步骤，从分组列表中**删去**或**重复**该步切片均严格改变原生执行迹（双向防篡改门禁）。∎

**定理 10.6（封存运行历史的前缀刚性与仅从末态出发的增量续行及单遍时间表，C54）。**

1. **封存历史前缀锁定与末态后缀续跑**：对任意源生询问运行时 $\mathcal{R}$、起始状态 $s_0$ 及视野长度为 $\mathrm{fuel}\in\mathbb{N}$ 的任意已存历史 $H\in\mathsf{HistoryAt}(\mathcal{R},\mathrm{fuel},s_0)$，在所有有限位 $i<\mathrm{fuel}$ 上存储状态读口严格等于动态激活读口 $H.\mathrm{storedOccurrenceAt}(i)=H.\mathrm{occurrenceAt}(i)$；当视野延长至任意绝对地平线 $\mathrm{total}\ge\mathrm{fuel}$ 时，延拓算子 $\mathrm{extendTo}$ 保留 $H$ 中全部已存激活不重算，**仅从 $H$ 已到达的末态出发新执行恰 $\mathrm{total}-\mathrm{fuel}$ 步缺失后缀**，并严格满足前缀锁定恒等式（完整证明见补充材料 S6.6）：
   $$\mathrm{prefix}_{\mathrm{fuel}}\bigl(\mathrm{extendTo}(H,\mathrm{total})\bigr)=H;\tag{10.6}$$
2. **单遍存储时间表与相邻阶段库存还原**：对任意活根微步历史 $H_{\mathrm{mic}}\in\mathsf{SourceNativeLivingRootHistoryAt}(\mathcal{P},\mathrm{fuel},s_0)$ 与状态材料投影 $\pi:S\to M$，单遍收集器 $\mathrm{storedTimeline}$ 预分配容量 $\mathrm{fuel}+1$、对每个已存状态恰投影追加一次，生成长 $\mathrm{fuel}+1$ 的向量表 $T\in M^{\mathrm{fuel}+1}$；对每个拍号 $i<\mathrm{fuel}$，相邻双格 $(T[i],\,T[i+1])$ 直接给出旧环境与差分增量环境 $T[i+1]-T[i]$，其导出的时间表更新库存与定理 4.6 的动态阶段库存 $U_i^{s_0}$ 逐点严格相等。∎

下面用初等算术把定理 10.1–10.6 的整条可逆续行链手算走通，使每个抽象符号都落到具体数字上。

**例 10.7（可逆增量续行全链手算验算）。** 在值群 $W=\mathbb{Z}$ 上取表达式 $e=\mathrm{var}\,x+\mathrm{var}\,x$，初始环境 $\rho_0(x)=3$，预定加法同态取三倍映射 $f(v)=3v$。

1. **首包执行与语义零同余（定理 10.1–10.2）**：$e$ 经 $M=3$ 步原语归约（步 $0$ 左绑定 $\delta_{x+x}\to\delta_{\mathrm{const}(3)+x}$，步 $1$ 右绑定 $\to\delta_{\mathrm{const}(3)+\mathrm{const}(3)}$，步 $2$ 常量加 $\to\delta_{\mathrm{const}(6)}$）结清于 $e'=\mathrm{const}(6)$（$p=6$）。当环境更新为 $\rho_1(x)=5$（增量 $\varepsilon=+2$）时，残差请求 $e\ominus\mathrm{const}(6)=(x+x)+\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(6))$ 与形式迹边界 $\delta_{x+x}-\delta_{\mathrm{const}(6)}$ 在**任意**环境 $\rho$ 下均求值为 $2\rho(x)-6$，故两者之差属于 $\mathcal{Z}_{\mathrm{sem}}$，在 $\mathsf{M}_{\mathrm{fut}}$ 中严格同余；残差请求以 $r(e\ominus e')=3+0+2=5$ 步严格扣款算出效应 $n=10-6=4$，定理 8.15 写回更新总值 $V=p+n=6+4=10=\mathrm{ev}_{\rho_1}(e)$。
2. **双取反恢复与同态续行（定理 10.3）**：在第 $0$ 级帧上，$\mathrm{retainedCode}_0$ 从残差右支 $\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(6))$ 构造双取反 $\mathrm{linear}_{-\mathrm{id}}(\mathrm{linear}_{-\mathrm{id}}(\mathrm{const}(6)))$，求值还原标量 $p_0=-(-6)=6\in V_0$；经零增量配对提升为 $(6,0)\in V_1$ 后施以 $f^{(1)}=3\mathrm{id}\times 3\mathrm{id}$，直接算出 $(f(6),\,0)=(18,0)\in V_1$ 并写入出生库存（跨入下一包时再由 $f^{(2)}$ 推进至 $V_2$）。
3. **执行步—请求双向区间反演（定理 10.5）**：上述 $M=3$ 步归约的端点差各有 $2$ 个有号支撑项（如步 $0$ 为 $+1\cdot(x+x)$ 与 $-1\cdot(\mathrm{const}(3)+x)$），故移交展开总表长 $N=2+2+2=6$，正向切片依次为 $\mathrm{stepInterval}(0)=[0,2)$、$\mathrm{stepInterval}(1)=[2,4)$、$\mathrm{stepInterval}(2)=[4,6)$。任取第 $r=5$ 号请求，$\mathrm{readRequestOrigin}(5)$ 唯一反演出源步骤 $i=2$、步内槽位 $s=1$（因 $5=a_2+s=4+1$，按归约前后顺序排列步端点时对应终态项 $-1\cdot\mathrm{const}(6)$）；三段有号和相加伸缩抵消中间项，精确还原总边界 $\delta_{x+x}-\delta_{\mathrm{const}(6)}$，而漏删或重复任一长 $2$ 的切片都会破坏步长与边界守恒。
4. **封存前缀末态续跑（定理 10.6）**：若已存前 $\mathrm{fuel}=2$ 拍运行历史 $H_2$（末态停在 $\rho_2$），将视野延拓至 $\mathrm{total}=5$ 时，$\mathrm{extendTo}(H_2,5)$ 原封不动复用前 $2$ 拍已存激活记录，仅从 $\rho_2$ 续跑 $5-2=3$ 拍，单遍时间表预分配长 $5+1=6$ 格，相邻格差 $T[i+1]-T[i]$ 即给出全部 $5$ 拍增量库存。∎

### 10.4 三组跨领域实装核验（C41, C50 及算术／物理／分子体系）

上述过程代数与可逆续行定理已在三个性质迥异的数学与科学体系中作为承重基础设施直接实装：

**第一组：共同算术中的 Fock 原生历史、整树计费与存储时间表。** 取值于粒子—波 Fock 空间的算术运行时将原生场词送入自由载体，调用命题 3.6、定理 4.4 与 4.6–4.7、命题 4.8 及命题 6.5 完成定目标 $6$ 的分拆动作债务结清（表 2）；在每个深度从实际发生读出单位历史树并编译为定义 3.8 的整树程序，逐步扣款并纯语法逆读回原树；在定理 10.4 与定理 10.6 实装中，Fock 原算子经整词逐原语回放同步驱动整数余链微分与同态方法，而定目标偶合微步行动者由长 $\mathrm{fuel}+1$ 的单遍时间表 $\mathrm{storedTimeline}$ 直接供给全部脉冲阶段库存、特征标、余链与终态双分支处分（且相邻绑定格严格可分 $T[0]\neq T[1]$）。

**第二组：Riesz 预解梳完整 $R$ 计算、有限窗口四迹入库与逆残差纠正（C41, C50, C53）。** 在非平凡零点右半平面观察输入（$\zeta$ 满足 $\operatorname{Re}\zeta>1/2$、精确 $\Xi$ 阶数 $m$、预解参数 $z=\zeta/2$ 满足 $\operatorname{Re}z>1/4$ 及初始梳向量 $q_0$）下，预解程序 $e_0=x,\ e_{k+1}=\mathrm{linear}_R(e_k)$ 在发射器前安装并以 $m+1$ 步严格扣款算出 $v=R^m q_0$（C41，图 7B）；实算结果内生定义下一环境增量 $\delta_v=\mathrm{constEnv}(v)-\rho$，定理 8.15 写回完整更新总值 $v+(R^m v-v)=R^m v$。单步物理程序在配对输入 $(v,0)$ 上**先以完整环境预解算子 $R_z$ 算出中间常量 $(u,0)=(R_z v,0)$，再正交分裂为 $(p,r)=(Pu,(1-P)u)$**（共 $3$ 步原语扣款），在 $1/4<\operatorname{Re}w<1/2$ 域上由交换积分导出完整 Mellin 定价恒等式（补充 S5.5）：

$$H_w(p)+2M_w(r)=-\frac{H_w(v)}{z+w-1/2}.$$

在有限 $P_a$ 窗口算子作用中（C50），已写入的 Möbius 源 $\nu$ 与两项均值在源内经有限截断拉回、倒数权重与 Tate 极点逐项作为字面表达式执行，正向、逆向、二阶均值与余链**四条完整执行迹**一并保入出生库存；随后从该实际写回中读出首阶逆残差，以字面差 $\nu-\mathrm{residual}$ 与截断代换生成纠正作用，在**完整保留原有四份库存**的同时并入新纠正迹，直接读出源窗口价减残差窗口价并保持联合观察纤维（注：截断半径参数绝不冒充离散演化步号）。此外，$\Gamma$ 请求批次直接消费定理 10.5 的 $\mathrm{stepInterval}$ 分组整账写入与非空组防漏重负控制门禁。

**第三组：同源物理忠实实现与 CPS1 全原子 37 原语连续平滑体系。** 在[《从单一发生源到连续—量子统一场》](https://doi.org/10.5281/zenodo.24100339)中，自源自旋对根登记为因果世界后直接调用第 5 节命题 5.2 与定理 5.3，逐事件同步恢复完整构型准入、物质读回、作用方程与宏后继。在分子体系实装中（补充 S5.6），从固定的 $37$ 项原语输入 $I$ 出发，源内依序执行翻译、修复、资源响应与化学交换，生成保留 DNA、完整编码、蛋白质、原子核与电子场、资源账户、开立责任与已写历史的 `Type 0` 身体 $B:\mathsf{InputBodyAt}(I)$，在每一拍满足规范直达后继等于刚写入身体 $\mathrm{next}(\mathrm{phase},I,B)=(\mathrm{phase}+1,I,\mathrm{bodyNext}_I(B))$。由完整原子核—电子两体四次能量与分离核构型导出的全光滑性保证半步 Cayley 更新下能量差价格满足 $\pi(0)=0$ 与 $\lim_{t\to 0}\pi(t)=0$：当储备 $A>0$ 时，折半步长 $t_k=t_0 2^{-k}$ 由 `Nat.find` 内生选出首个满足就绪且 $\pi(t_{k_*})\le A$ 的有限精化步 $k_*$，生成保持电荷／电子数与总能量 $E+A$ 守恒的有限已付历史；当储备 $A=0$ 时，在首个就绪步 $k_*$ 处按 $\pi(t_{k_*})\le 0$ 或 $>0$ 精确输出已付或显式能量短缺处分，绝不靠零储备伪造付款（临床标签仅为源行索引，本构造不作临床疗效推论）。

### 10.5 四轴文献对话：增量与可逆计算、余代数精化、资源类型论与范畴修订

将本文 C1–C54 的整套结果置于既有文献坐标系中，核心判别标尺只有一条：**当一次过程演化、跨层实现、资源结算或语言修订发生时，回答究竟携带并保持了哪些可复核的不变量？** 表 5 按四条学科主轴给出与二十四项原始文献的逐机制对照。

**表 5 源生过程代数（v3）与二十四项原始文献的四轴逐机制对照矩阵。**

| 比较维度与代表文献 | 经典文献已确立的核心机制 | 本文复用的基础／不越界声明 | 本文（v3）锁定的新增不变量与定理 |
| --- | --- | --- | --- |
| **增量、自调整与差异演算** DBSP [[1]](#ref-1)；ILC [[2]](#ref-2)；自调整计算 [[22]](#ref-22)；张量积 [[5]](#ref-5) | Z-集 $\mathbb{Z}[A]$ 流式增量 $D\circ Q\circ I$ 与三项公式 [[1]](#ref-1)；$\lambda$-项静态微分 [[2]](#ref-2)；可变引用动态依赖图与外置 memo 传播 [[22]](#ref-22) | 明确复用 $\mathbb{Z}[S]$ 自由载体与三项更新公式；不含递归 SQL 算子库、高阶闭包导数或可变指针 DDG | 无加法原生状态自由提升（命题 2.5、定义 2.6、命题 2.7）；`Type` 正合核 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$（定理 4.4）；完备化演化（定理 4.7）；零外置缓存双取反 $\mathrm{retainedCode}$ 同态续行与锁前缀末态续跑（定理 8.12、10.3、10.6） |
| **来源半环、双向透镜与可逆计算** Provenance [[3]](#ref-3)；树透镜 [[23]](#ref-23)；Bennett [[4]](#ref-4) | 半环多项式 $\mathbb{N}[X]$ 同态求值 [[3]](#ref-3)；有损视图回写透镜 $\mathrm{get}$ 与 $\mathrm{put}(V,S)$ [[23]](#ref-23)；正向—复制—逆算消去历史带 [[4]](#ref-4) | 共享符号溯源先于数值求值的思想；不建立正关系代数查询函子，不涉及热力学擦除耗散下界 | 抗全零坍缩（$\kappa\equiv 0$）且无需旧树辅助的整树纯语法左逆（定理 3.9）；无需逆向退算的执行步—请求双向切片反演 $r=a_i+s$ 与防漏重门禁（定理 10.5）；总值写回 $V=p+n$（定理 8.15） |
| **过程代数、精化与余代数能观性** CCS [[20]](#ref-20)；ACP [[21]](#ref-21)；TLA [[6]](#ref-6)[[7]](#ref-7)；事件结构 [[8]](#ref-8)；泛余代数 [[9]](#ref-9)；极小实现 [[10]](#ref-10) | 握手同步、选择 $+$ 与右分配公理／互模拟商 [[20]](#ref-20)[[21]](#ref-21)；历史／预言变量精化 [[7]](#ref-7)；因果／冲突偏序 [[8]](#ref-8)；终余代数商 [[9]](#ref-9) 与能观商 [[10]](#ref-10) | 聚焦确定性单根单发射过程（不含通道握手或非确定性冲突分支）；$\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$ 承接能观商思想 | 单构造子保留完整分叉树而仅在基数阴影导出 $+,\times$（定理 2.2）；**禁预言变量**：共同发生零公理导出无条件逐点唯一实现比较（定理 5.3）；证明**源同一性严格强于行为互模拟**（定理 3.9、9.9、9.12、10.1） |
| **资源逻辑、携证准入与类型论** 线性逻辑 [[11]](#ref-11)；分离逻辑 [[12]](#ref-12)[[13]](#ref-13)；PCC [[14]](#ref-14)；ITT [[15]](#ref-15)；HoTT [[16]](#ref-16)；Lean 4 [[17]](#ref-17) | 公式线性消耗 [[11]](#ref-11)；不相交堆局部 frame 与静态摊还势 [[12]](#ref-12)[[13]](#ref-13)；装入前静态安全证明核验 [[14]](#ref-14)；$\Sigma$ 见证 [[15]](#ref-15) 与单值同构相等 [[16]](#ref-16) | 依托 Lean 4 内核 [[17]](#ref-17) 与 $\Sigma$ 类型构造 [[15]](#ref-15)；不宣称蕴含指针别名分离逻辑 | 显式分离 **T0 `[]`** 与 **T1**，**拒绝单值公理将同构载体等同为同一发生**（定理 5.3、命题 8.3 密封回执）；无总法则 $\le\,;\,<\,;\,\le$ 良基核（定理 6.7）、内生逐步扣款与 `Type` 回执 $d_i=B_i$（定理 6.10、6.12） |
| **信念修订、单纯余面与制度论** AGM [[18]](#ref-18)；单纯对象 [[24]](#ref-24)；制度论 [[19]](#ref-19) | 固定语言内部分交收缩 [[18]](#ref-18)；单纯范畴余面单射 $\delta_i^n$ 与余退化左逆 $\sigma_i^n$ [[24]](#ref-24)；外部签名态射 $\phi:\Sigma\to\Sigma'$ 满足条件与保守扩充 [[19]](#ref-19) | 共享余面／余退化左逆几何与保守不入侵准则；不建立 AGM 选择函数公设翻译 | 针对**双空表达破产** $\eta$（而非逻辑矛盾）零公理内生构造初始余面 $C_\eta=L_+\sqcup\{\star_\eta\}$：旧支承零泄漏、旧定理全存续、三坐标唯一单射且不回充预算分解，新方向直入新根首次整账写入并在第 2 拍直答（定理 8.4、8.6–8.7、命题 8.9） |

围绕上述矩阵，四处深层方法论分野尤为醒目：

**第一，从“流式差值、外置 memo 表与有损视图透镜”到“抗全零坍缩单侧左逆、原位语法树双取反与双向切片寻址”。** DBSP[[1]](#ref-1) 与高阶变化演算[[2]](#ref-2)解决的是如何增量算出更新后的输出值，自调整函数式编程[[22]](#ref-22)依赖可变引用与运行时外置 memo 表重放动态依赖图，来源半环[[3]](#ref-3)以交换多项式记录组合重数，双向树透镜[[23]](#ref-23)在回写 $\mathrm{put}(V,S)$ 时同时输入更新后的视图 $V$ 与旧源树 $S$，使回写能保留视图中未呈现的源信息，Bennett[[4]](#ref-4) 的逻辑可逆图灵机则需在复制输出后**逆向退算**以擦除历史带。本文在三个无需外置缓存、无需旧源补救且无需退算的层次上锁住信息守恒：定理 3.9 证明即便构造子 $\kappa\equiv 0$ 把所有语义输出压成零元，整树程序自身仍保持单射并由纯语法解析器直接给出单侧左逆；定理 10.3 用两步纯语法取反 $(-\mathrm{id})((-\mathrm{id})(e'))$ 直接从残差表达式原位取回已付常量语法树，驱动跨共尾同态 $f^{(n+1)}$；定理 10.5–10.6 更在已执行原语步与下一批有号请求之间建立 $r=a_i+s$ 双向切片反演及锁前缀末态续跑，使漏删或重复任一非空组在迹层面立判。

**第二，从“经典并发过程代数行为商与预言变量精化”到“有根分叉树保持、单根零前瞻比较与全词先行恢复”。** Milner 的 CCS[[20]](#ref-20) 与 Bergstra–Klop 的 ACP[[21]](#ref-21) 以互模拟或右分配公理商去分叉位置差异，Rutten[[9]](#ref-9) 的终余代数将一切行为不可区分状态压成同一点，Abadi 与 Lamport[[7]](#ref-7) 则指出状态空间精化映射一般必须借助预知未来的预言变量方能完备。本文在定理 9.3 与定理 9.12 中完整构造了模线性层面的最大未来不可见不变核商 $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$，但同时划出关键分界：**行为互模拟商处于过程代数的下游观察层，绝不能替代上游有根源层**。在 T0 内核中，单构造子展开保留精确分叉树且严禁预存已完成未来（无预言变量），两忠实实现仅凭与同一权威根发生的双向表示即零公理唯一确定跨实现比较（定理 5.3）；而在跨周期运行中，定理 9.9（及例 9.13）严格要求先在未商化全词载体上完成恒等恢复 $\mathrm{rec}(q(w))=w$ 与迹位置严格保序注入 $\iota(j)=j+L_{\mathrm{old}}+L_{\mathrm{phys}}+3$，再投影读取执行帧与库存。

**第三，从“静态资源势与单值同构相等”到“T0 非单值发生刚性与 `Type` 活账回执”。** 线性逻辑[[11]](#ref-11)、分离逻辑[[12]](#ref-12)与摊还资源分离逻辑[[13]](#ref-13)在证明论或霍尔三元组中断言资源上界，携证代码[[14]](#ref-14)在装入前核验静态安全谓词；而在类型论地基上，同伦类型论[[16]](#ref-16)引入单值公理将等价类型直接等同（$(A\simeq B)\simeq(A=B)$）。本文的 T0 零公理内核给出了鲜明的反单值工程与数学理由：在记账与因果过程中，两个同构的载体（例如同构的单点回执或两套同构的状态编码）只要未锚定到同一次根发生，就绝不能自动视为同一对象——旧目标支承上的处置回执进入新余面支承 $\star_\eta$ 时必须经破产指标信封 $\mathrm{Seal}_{\eta,k}$ 显式重封（命题 8.3），而执行债务律的每一拍归约都在 `Type`（遵循 Martin-Löf $\Sigma$ 见证传统[[15]](#ref-15)）中产出精确步距 $d_i=B_i$ 的运行时活账扣款与关系收据（定理 6.10、6.12、10.2）。

**第四，从“固定语言信念收缩与外部签名态射”到“双空破产内生单纯初始余面与首次整账写入”。** AGM 理论变化[[18]](#ref-18)处理同一语言内的信念冲突与部分交收缩；Goguen 与 Burstall 的制度论[[19]](#ref-19)在范畴模型论中用外部给定的签名态射 $\phi:\Sigma\to\Sigma'$、满足条件与保守扩充刻画跨词汇规格组合。本文第 7–8 节处理的是动态过程遭遇表达破产时的内生升维：新词汇顶点 $D_\eta=\{\star_\eta\}$ 由绑定于精确访问与活账行的根植双空破产 $\eta$ 零公理唯一逼出，使左嵌入 $\operatorname{inl}:L_+\hookrightarrow C_\eta$ 与确定目标行收缩精确构成单纯几何[[24]](#ref-24)中的余面—余退化左逆对；命题 8.3 与定理 8.4 在依值支承网络上同时证明旧支承零泄漏、旧定理全存续及三坐标单射不回充预算的严格范畴初始性，定理 8.6–8.7 与命题 8.9 则进一步把这一定制初始方向送入新根首次整账写入所消费的活账行，在两拍之内完成“语言破产 $\to$ 初始余面升维 $\to$ 新根直接回答”的动态闭环。

---

## 11 结论

开篇的三拍读数 $0,0,1$ 在交点处数值相等，却没有任何共同源词能够贯通首尾。这一极简反例揭示了一条贯穿计算、逻辑与动力学的基本定律：**相等读数只是最弱的瞬时投影；要让回答真正属于这一次演化过程，就必须逐级锁住读数背后的源对象、源对象背后的当次发生、以及当次发生留下的活账责任与语言边界**。

本文在严格分离的 **T0 零公理构造性内核**（`#print axioms = []`）与 **T1 自由模完备化层**上完成了这一四层过程代数的双向闭合（表 6）：

1. **在 T0 零公理内核中**，唯一构造子 $\mathrm{occur}(a,\vec T)$ 内生派生叶前沿、结合推进、联合基数阴影与万有唯一折叠。并列基数公式使用 `propext`。根读恒等 $\mathrm{rootRead}(o)=o$ 对一切下游处分排除隐藏空证人；同一权威根的任意两套忠实实现无需预言变量或外部模拟关系即导出无条件逐点唯一的事件比较；无总法则的 $\le\,;\,<\,;\,\le$ 付款宏步本身即构造性良基；而当旧理论遭遇表达与实现双空破产 $\eta$ 时，$\eta$ 零公理内生生成保守存续全部旧定理、旧支承零泄漏的**范畴初始余面** $C_\eta=L_+\sqcup\{\star_\eta\}$，通过唯一单射且不回充预算的忠实态射将新方向精确送入有类型修订新根首次整账写入所消费的新行，在两拍之内由同一新根直接给出回答。
2. **在 T1 模代数与可逆续行层中**，无需加法的原生状态自由提升至 $\mathbb{Z}[S]$ 并满足三项增量更新律；整树程序即使在常零构造子 $\kappa\equiv 0$ 抹平一切输出值时仍具备不经求值的纯语法左逆；推导差与模律在任意交换环上正合生成求值核 $\operatorname{range}(\mathrm{rel}_\rho)=\ker(\mathrm{ev}_\rho)$，逆极限完备化载体 $\widehat C(s)$ 逐元素满足演化律；环境—表达式对无需旧承担者即内生出生计算责任并交出步距等于预算的 `Type` 完成回执 $d_i=B_i$。结清之后，残差差词 $e\ominus e'$ 内生提出下一问，按 $V=p+n$ 写回总值并同步生成六面余链复形与最大未来模型 $\mathsf{M}_{\rm fut}=\mathcal{W}/K_{\rm fut}$；全环境语义零关系使残差请求与已付迹边界在 $\mathsf{M}_{\rm fut}$ 中严格同余并直达规范后继，纯语法双取反 $\mathrm{retainedCode}$ 无环标量恢复已付语法树跨共尾执行任意预定同态 $f^{(n+1)}$，整词逐原语回放使替换链映射 $\tau_1$、实际边界与余链微分 $d^{0,1}$ 严格锁步，而 $\mathrm{stepInterval}$ 与 $\mathrm{readRequestOrigin}$ 的双向区间反演 $r=a_i+s$ 配合 $\mathrm{extendTo}$ 锁前缀末态续跑，使跨周期增量计算在代数、账本与执行迹三个维度上同时达到无损可逆。

**表 6 四层过程同一性与第三版双向封顶结果总表（C1–C54）。** 无需假定的原生结构、显式外供输入、核心正向定理、配对反例门禁及跨领域实装并列对照。

| 层级与公理核 | 原生前提与外供输入边界 | 内生生成的数学对象 | 核心定理与配对反例门禁 | 跨领域实装核验 |
| --- | --- | --- | --- | --- |
| **T0 单构造子与源过程**（`[]`，§2.1–§2.2） | 任意标签集 $A$、无结构状态集 $S$；无需算术公理或已完成未来表 | 单构造子展开树、前沿结合推进、$+/\times$ 阴影、根读恒等、按需有限历史 | 定理 2.2、命题 2.4；低维投影隐藏空证人门禁 | 全系发生树与单根准入地基 |
| **第 2 层：源对象与求值核**（T1，§2.3–§4） | 状态与二元函数无需加法或线性；交换环 $R$ 与构造子 $\kappa$ 任意 | 自由载体 $\mathbb{Z}[S]$、混合项表、整树程序与语法左逆、双证书求值核、完备化载体 $\widehat C(s)$ | 命题 2.5, 2.7, 3.5, 3.7, 4.8；定理 3.9, 4.4, 4.6, 4.7；例 4.1–4.2 反例与 $\kappa\equiv 0$ 对照 | 算术 Fock 原生场词与整树单位历史计费 |
| **第 3 层：同一次发生**（T0 `[]`，§5） | 固定因果世界 $W$ 及两套忠实实现合同；无需模拟关系或预言变量 | 逐事件完整恢复、与发射器及整编译器相容的唯一事件比较 | 命题 5.2、定理 5.3；多点纤维非唯一门禁 | Spin$\times$SU(7) 同源物理多表示面对齐 |
| **第 4 层：同一笔责任**（T0/T1，§6） | 源事件处分；一般终账需外供同债总律，计算责任无需任何旧承担者或总律 | 生命周期三律、扩充整账、无总法则良基核、内生执行账与 `Type` 回执 $d_i=B_i$ | 命题 6.1, 6.4–6.5, 6.11；定理 6.7, 6.10, 6.12；注记 6.8 零预算空终账反例 | 算术定目标 $6$ 分拆债务；共尾出生停点 |
| **支路 I：初始余面修订**（T0 `[]`，§7–§8.4） | 根植双空破产 $\eta$；动态运行需外供有类型修订与语义锚定 | 同支承残差破产、初始余面 $C_\eta=L_+\sqcup\{\star_\eta\}$、唯一忠实分解、双行首写与两拍回答 | 命题 7.1, 7.3–7.6, 8.2–8.3, 8.8–8.10；定理 7.7, 8.4, 8.6–8.7；空纤维反例 | 因果审计转移与固定两拍自然数修订运行 |
| **支路 II：完整执行与未来核**（T1，§8.5–§9） | 初始询问帧与源程序配置（仅给变量族与读取器）；无需未来查询表 | 残差请求 $e\ominus e'$、双边界差词、总值写回 $V=p+n$、全行动者模型、保序入库、六面复形、$\mathsf{M}_{\rm fut}$ | 定理 8.12, 8.14–8.15, 9.2–9.3, 9.5–9.12；例 8.13, 9.13 与常值零效应正控制 | 预解梳完整 $R^m q_0$ 计算与 $Pu+(1-P)u$ 定价；CPS1 37 原语身体 |
| **可逆增量续行封顶**（T1，§10.1–§10.3） | 同上源程序族，同态续行另取一枚预固定加法同态 $f$；无需外部请求索引表 | 全环境语义零同余请求、重排 $\mathrm{jointCode}$、双取反 $\mathrm{retainedCode}$、逐原语余链回放、双向切片 $\mathrm{stepInterval}$ 与 $\mathrm{readRequestOrigin}$、$\mathrm{extendTo}$ 及 $\mathrm{storedTimeline}$ | 定理 10.1–10.6、例 10.7；漏删／重复任一非空步骤切片负控制门禁 | 有限窗口四迹入库与逆残差纠正；$\Gamma$ 分组写入；定目标偶合存储时间表 |

语言充足时，已付答案以自身在新环境中的残差提出下一问，并携整棵已付语法树、完整余链边界与双向可逆切片向前续行；语言破产时，根植双空阻滞零公理长出范畴初始余面，将唯一新方向送入新根首次写入并在下一拍直接作答。无论执行、结清还是破产，源始终携带着通往下一回答的完整凭据。

---

## 附录 A 有限代数语言技术细节

**A.1 原生状态点与实际运行阶段的衔接。** 记运行态 $u$ 推进 $i$ 步后的状态为 $u_i$，其原生状态为 $s_i$、完整活当前为 $c_i$、生成材料阶段为 $g_i$。定义 2.3 的源过程登记与 §2.3 自由提升给出 $\iota(s_i)=c_i$ 与 $A\delta_{s_i}=\delta_{s_{i+1}}$；同一阶段生成器同时锁住三条运行等式：$g_i$ 的发生等于 $c_i$ 所登记根在该访问处的规范发射；$g_i$ 的整账写回异质等于该根同次访问的整账编译；$g_i$ 的下一当前等于 $u_i$ 单拍记录的下一当前。写成源词 $w_{\mathrm{src}}=\mathrm{var}$ 与作用词 $w_A=\mathrm{linear}_A(\mathrm{var})$ 后，第 $i$ 阶段成对读出分别为 $(\delta_{s_i},\delta_{s_{i+1}}-\delta_{s_i})$ 与 $(\delta_{s_{i+1}},\delta_{s_{i+2}}-\delta_{s_{i+1}})$。后者第一坐标直接由运行态 $u_i$ 记录的目标运行态 $u_{i+1}$ 见证；对无需加法的任意原生读出 $h:S\to B$，先在该运行态见证上取 $h(s_{i+1})$，再由自由观察映射核验基点像，全程无任何从线性组合反解状态的步骤。

**A.2 配对语言为何给出完整阶段库存。** 对每个类别令配对值载体为 $\widetilde V(\kappa):=V(\kappa)\times V(\kappa)$。配对环境 $(\rho,\varepsilon)$ 在变量 $x$ 处取 $(\rho(x),\varepsilon(x))$，常量 $a$ 提升为 $(a,0)$，加法逐坐标定义，加性算子 $h$ 提升为 $\widetilde h(a,da):=(h(a),h(da))$，双加性算子 $\mu$ 提升为

$$\widetilde\mu\bigl((a,da),(c,dc)\bigr):=\bigl(\mu(a,c),\ \mu(a,dc)+\mu(da,c)+\mu(da,dc)\bigr).$$

将原表达式 $e$ 沿同一语法树逐节点替换为配对节点得 $\widetilde e$。对语法树作结构归纳，双加性节点第二坐标恰为定义 3.2 式 (3.1) 的三项效应，故 $\operatorname{ev}_{(\rho,\varepsilon)}(\widetilde e)=(\operatorname{ev}_\rho(e),\operatorname{eff}_{\rho,\varepsilon}(e))$。按系数 $R$-线性延拓至形式词即得定理 4.6 所用的配对提升映射 $w\mapsto\widetilde w$，使定理 4.6 的逐拍关系判据归结为对配对模型逐拍应用一次定理 4.4。

**A.3 求值核包含于关系像的双证书显式组装。** 设 $w=\sum_i a_i\delta_{e_i}\in\mathrm{Fm}_R(\kappa)$ 满足 $\mathrm{ev}_\rho(w)=0$。记 $v_i=\mathrm{ev}_\rho(e_i)$、$q_0=\sum_i a_i\delta_{v_i}\in R[V(\kappa)]$，令常量嵌入 $j(\delta_v):=\delta_{\mathrm{const}(v)}$ 及 $q:=j(q_0)$。每个内生归约推导 $\mathrm{norm}_\rho(e_i):e_i\vdash_\rho\mathrm{const}(v_i)$ 给出左支关系指标，按系数 $a_i$ 线性组合得到推导证书 $c_{\mathrm{der}}$，满足 $\mathrm{rel}_\rho(c_{\mathrm{der}})=w-q$。剩余部分 $q_0$ 在自由模求值下满足 $\sum_i a_i v_i=\mathrm{ev}_\rho(w)=0$。标量模律生成元为 $\delta_x+\delta_y-\delta_{x+y}$ 与 $\delta_{av}-a\delta_v$：直观上将每项 $a_i\delta_{v_i}$ 改写为 $\delta_{a_i v_i}$、有限求和归并为 $\delta_{\sum_i a_i v_i}=\delta_0$，再用 $(0,0)$ 处加法关系 $\delta_0+\delta_0-\delta_0=\delta_0$ 消去 $\delta_0$；形式化证明利用模律商模 $R[V(\kappa)]/\operatorname{range}(\mathrm{rel}_{\mathrm{scl}})\cong V(\kappa)$ 的 $R$-线性同构：因 $q_0$ 求值为零，其商类为零，故存在 $c_0$ 使 $\mathrm{rel}_{\mathrm{scl}}(c_0)=q_0$。将 $c_0$ 右注入总关系指标得 $c_{\mathrm{scl}}$，相加即得 $\mathrm{rel}_\rho(c_{\mathrm{der}}+c_{\mathrm{scl}})=(w-q)+q=w$。

## 附录 B 完备化载体细节与反例完整证明

**B.1 阶段商塔与逆极限上的后继算子。** 固定起点 $s$，视野 $b$ 的阶段商为 $Q_b(s)=\mathrm{Fm}_R(\kappa)/\ker(\mathrm{pre}_b^s)$。同起点限制 $r_b^s:Q_{b+1}(s)\to Q_b(s)$ 删去末拍 $U_{b+1}^s$；起点推进 $d_b^s:Q_{b+1}(s)\to Q_b(\sigma(s))$ 删去首拍 $U_0^s$（因 $U_i^{\sigma(s)}=U_{i+1}^s$）。对任意逆极限元素 $z=(z_b)_{b\in\mathbb{N}}\in\widehat C(s)$（满足 $r_b^s(z_{b+1})=z_b$），定义 $(Tz)_b:=d_b^s(z_{b+1})$。因在长 $b+2$ 窗口上“先删首拍再删末拍”与“先删末拍再删首拍”结果同一（$r_b^{\sigma(s)}\circ d_{b+1}^s=d_b^s\circ r_{b+1}^s$），有 $r_b^{\sigma(s)}((Tz)_{b+1})=d_b^s(r_{b+1}^s(z_{b+2}))=d_b^s(z_{b+1})=(Tz)_b$，故 $Tz\in\widehat C(\sigma(s))$ 确为相容族。对任意固定拍 $i$，取商满射在有限级 $b=i+1$ 上的任一代表元 $w\in\mathrm{Fm}_R(\kappa)$ 使 $[w]_{i+1}=z_{i+1}$，则 $\mathrm{old}_i(Tz)=\mathrm{old}_i(d_i^s([w]_{i+1}))=\mathrm{ev}_{\rho_{i+1}}(w)=\mathrm{ev}_{\rho_i}(w)+\mathrm{eff}_{\rho_i,\varepsilon_i}(w)=\mathrm{old}_i(z)+\mathrm{eff}_i(z)$，无需假定存在同时代表全部无穷阶坐标的单一源词。

**B.2 反例完整推导。** 例 4.1(4)：若存在 $w$ 使 $\mathrm{ev}_1(w)=0$ 且 $\mathrm{ev}_1(w)=1$，由等号对称与传递得 $\mathbb{Z}$ 中 $0=1$，矛盾。例 4.2：词 $w=x\cdot x+(-1)\cdot x$ 在 $\rho(x)=1$ 下求值 $1+(-1)=0\in\ker(\mathrm{ev}_1)$，在 $\rho'(x)=2$（增量 $\varepsilon=+1$）下由命题 3.3 效应为 $1\cdot 1+1\cdot 1+1\cdot 1+(-1)=2\neq 0$，故 $\mathrm{ev}_2(w)=2\notin\ker(\mathrm{ev}_2)$。

## 附录 C 从根植破产到首次整账写入的纤维定义与推导

**C.1 初始余面世界的四类依值纤维。** 固定根植双空破产 $\eta$（旧目标支承为 $s_+$），记单点方向类型 $D_\eta=\{\star\}$。扩充网络 $N_\eta$ 的开立责任纤维 $\mathrm{Open}'$ 分四片定义为：

$$\begin{aligned}
\mathrm{Open}'(\operatorname{inl}s,\operatorname{inl}r)&:=\mathrm{Open}(s,r), & \mathrm{Open}'(\operatorname{inl}s,\operatorname{inr}\star)&:=\varnothing,\\
\mathrm{Open}'(\operatorname{inr}\star,\operatorname{inl}r)&:=\mathrm{Open}(s_+,r), & \mathrm{Open}'(\operatorname{inr}\star,\operatorname{inr}\star)&:=\mathrm{Aligned}_\eta(\star,\star),
\end{aligned}$$

其中 $\mathrm{Aligned}_\eta$ 为单构造子对齐类型（唯一元 $\mathrm{same}(\star)$）；事实纤维 $\mathrm{Holds}'$ 将责任 $r$ 换为主张 $c$、将 $\mathrm{Open}$ 换为 $\mathrm{Holds}$ 按完全相同的四片定义。由此新余面支承上的新增开立行为 $e_{\mathrm{obs}}=\langle\operatorname{inr}\star,\mathrm{same}(\star)\rangle$（主张 $\operatorname{inr}\star$，预算 $0$），而旧支承右上角恒为空类型 `PEmpty` 实现零泄漏。新支承上第 $k$ 类处置定义为单字段私密封装 $\mathrm{Seal}_{\eta,k}(d)$（$d:\mathrm{Disposition}(s_+,k)$），封包与拆包互逆；新增语义变化构造子具有精确类型 $\mathrm{reveal}_\eta:\mathrm{SemanticChange}'(\operatorname{inr}\star,\operatorname{inl}\mathrm{claim}(o),\operatorname{inr}\star)$。

**C.2 精确语义锚定的八项条件与分裂精化锚定。** 对有类型修订 $\Xi$，精确语义锚定由一个世界网络等式（$\Xi$ 的新世界等于 $N_\eta$）与七个依值异质等式组成（新法则面、世界翻译、初支承、旧目标活账收缩、新方向行、新主张成立见证、语义变化分别异质等于 $N_\eta$ 的根语义及对应典范对象）——因后七项类型依赖各自世界，绝不能弱化为基数相等。分裂精化锚定不要求世界相等，而要求新法则面为自身世界的根语义，且新根首次编译选出迁移旧破产行 $e$ 的真实二分裂：两条子行 $l\neq r$ 满足 $\mathrm{origin}(l)=\mathrm{origin}(r)=e$ 且预算均严格小于母行，初始活账除旧目标账与新方向行外无潜伏行，目标行起源亦由这两类完全覆盖。

**C.3 从首次写入生成行到双路回答—后继恢复。** 记 $\Xi$ 新根初访 $v_0$ 的完整生成演化为 $g_0$。首次写入非终结证明排除终结分支，给出后继访问 $v_1$ 与完整整账演化。对 $g_0$ 的任一生成补丁行 $e$，生成证明赋予初始因果权威 $\mathrm{au}_0(e)$，沿整账去向推进至 $v_1$ 处目标行 $e_1$ 的目标权威 $\mathrm{au}_1(e_1)$，继而直接调用新根自身在 $v_1$ 处的回答—后继编译器 $\mathrm{ans}_\Xi(v_1,e_1,\mathrm{au}_1(e_1))$。分别对迁移旧破产行与新方向行（定理 8.6 保证 $F_\Xi(\operatorname{inr}\star)=e_{\mathrm{new}}$）施用该映射即得定理 8.7 的双路输出。

**C.4 逐次修订容量的结合律映射。** 设三段相对表达容量依次给出单射 $k_1:O\sqcup D_1\to M$、$k_2:M\sqcup D_2\to F$、$k_3:F\sqcup D_3\to G$。令规范重加括号同构为 $\alpha:O\sqcup(D_1\sqcup(D_2\sqcup D_3))\xrightarrow{\sim}O\sqcup((D_1\sqcup D_2)\sqcup D_3)$，在旧元素 $o$ 及三族方向 $d_1,d_2,d_3$ 四种构造子上逐一展开，两侧复合均映至同一个 $G$ 中元素，故 $k_{(12)3}\circ\alpha=k_{1(23)}$。

**C.5 扩充世界读回与按事件整账编译证明（命题 6.4、6.5）。** 命题 6.4 按不相交并构造子分情况核验：非活跃支承新侧为空，活跃支承开立见证迫使债务标签等于 $\mathrm{id}_0$，单射性由旧行单射与新行无旧原像给出。命题 6.5 设源生成事件为 $a=\mathrm{src.gen}$，依其内生处分 $\delta=\mathrm{dispositionAt}(a)$ 分支依值编译：扣款步合成目标债务态整账演化，阶段终结合成整支承终结账，阻滞支归约为同一债务行的理论审计，并在编译像中封存分支等式防止串支替换。

**C.6 因果审计转移字段构造（命题 7.5）。** 审计根的源载荷定义为双端发生对 $(\mathrm{occ}(a),\mathrm{occ}^+(r))$，故初访与目标发生均直接投影读回两端点而无需从支承标签猜测。每条嵌入旧行作为恒等余项保留，有限补丁查询返回“非当次新生成行”；唯独新残差行持有当次补丁生成见证从而取得初始活时序因果权威，与命题 7.4 双空证明装配成定义 8.1 的根植破产 $\eta$ 并直接输入初始余面构造。

## 附录 D 形式化声明入口与公理边界

本文全部定义、构造、正定理与反例门禁均以 Lean 4[[17]](#ref-17) 形式化验证。各历史批次固定提交如下：首版主体采用 **H = `e60a86058abcb74b7f2225f2383c182be8343785`**（含命题 6.1 回归测试在基线 `8e29b8e` 的两条私有列表引理策略对齐）；正向计算与完整执行链采用 **AB = `fde5c14df36b6064c87064acd20830d3df0500bb`**、**AC = `b67aa48c75b3cd7738766ed40093bb3f7c1d7a1a`**、**AD = `aef0ad2a26199d9fd6da9bc9e7ec1a65636ef63f`**、**AE = `26b91feb6b507fdc3f43be9c429edb63fb9395ef`**（上游三行接口对齐见 `089a1727993bec51c27ee72a0311022fec8111ab`）；第二版完成数据、总值写回与全未来模型采用 **PR = `e05558097256e86b537c019c8ca63cd449d6b2d2`**、**MF = `c62f3d25c42d4bf2b77ac009b49fc71cfd752f46`**、**MV2 = `71e94e8261d67cf4849a05eb14ac95aa2f7dcbb9`**、**MV3 = `9c73a630ce05bea062ec889b188f5105c0afb796`**（公开源环境配置补充见 H0mework **H0-S = `a1adcc9f4a06b872c381b8ad49513d6bf1cd621a`**）；第三版可逆增量续行与跨周期方法封顶采用 **MV4 = `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`**（C46–C50）、**MV5 = `df421ff600085cbc290a7ae946193961bed7c83b`**（C51–C52）与 **`7e4da746f300b3796b8b18afb26cb0765c29afcb`**（C53–C54）。

**T0 与 T1 公理闭包核验边界。** 下表 D.1 中标有 **`[T0]`** 的内核模块（主体汇总于零公理门面 `Tracks/LivingLawAxiomFreeCore.lean`，独立实现比较与回归门禁经各自 `#print axioms` 核验）不依赖任何公理（`#print axioms` 输出为空表 `[]`）；自由模商、逆极限、非构造性六分支分类（`noncomputable`）与算子／连续平滑实装模块的传递公理闭包严格限于 `{propext, Classical.choice, Quot.sound}`（**T1**），零研究公理、零 `sorry`、零逻辑 `unsafe`/`partial` 依赖。

### D.1 T0 零公理内核与首版基础层声明入口（提交 H 基础核；除残差破产核在 `eec031c489` 增补 C17 反控引理外均与 MV4 同字节）

路径相对 `Lean/SaturationMonoid/`：

| 正文定理与结构 | Lean 4 模块与核心声明（`[T0]` 表示声明的公理列表为空 `[]`） |
| --- | --- |
| 定义 2.1、定理 2.2(1)(2) 单构造子展开与万有折叠 `[T0]` | `LivingLawRootedAccountedUnfoldingKernel.lean`: `RootedAccountedUnfolding.occur`, `frontier`, `frontier_ne_nil`, `trace`, `advance`, `advance_assoc`, `parallelAt`, `jointAt`, `cardinalShadow_parallelAt`（`propext`），`cardinalShadow_jointAt`, `fold`, `fold_unique` |
| 定理 2.2(3) 根读恒等、零隐藏空证人与投影分解 `[T0]` | `LivingLawRootCoreRepresentationKernel.lean`: `rootCofaceRead`, `rootCofaceRead_consumerSafe`, `no_hiddenNull_at_rootCofaceRead`, `installedSubsystemAuthority_factorizes`, `installedJointSubsystemAuthority_factorizes` |
| 定义 2.3、命题 2.4 源过程与固定法则后继刚性 `[T0]` | `LivingLawRelationNetworkKernel.lean`: `WorldRelationNetwork`; `LivingLawRootAnswerNextHistoryKernel.lean`: `SourceNativeLivingRootCurrentAt`, `erase`, `SourceNativeLivingRootProcess`, `successor_difference_reflects_current`, `generateHistory` |
| 命题 2.5、定义 2.6、命题 2.7、附录 A、定理 4.4 自由提升与正合核 | `GenericFoundation/Operations/Native/{Core,Field}.lean`: `point_factorizes`, `nextWitness`, `nativeReadWitness`; `Scalar/InventoryLift.lean`: `eval_liftExpr`, `evaluation_liftMap`; `Scalar/Presentation.lean`: `source_reduction`, `relation_range_eq_kernel` |
| 定理 4.6–4.7、命题 4.8 完备化纤维与逐元素演化 | `GenericFoundation/Operations/Runtime/{Relations,Successor,Evolution}.lean`: `completion_fibre_generated`, `successor_fibre_generated`; Fock 见证延拓见 `ParticleWave/Fock/Runtime/SourceHistory/...` |
| 命题 5.2、定理 5.3 忠实实现恢复与唯一比较 `[T0]` | `LivingLawCausalRealizationConstructiveKernel.lean`: `World`, `NoSuspendedCausalMagic`, `commutingPresentation`; `LivingLawRootGroundedRealizationKernel.lean`: `recover_eq_generated`, `event_eq_emitted`, `comparison_unique` |
| 命题 6.1、6.4–6.5、定理 6.7 生命周期与良基结算 `[T0]` 核 | `ResponsibilityLifecycleKernel.lean`: `Edge.freshlyAllocated_implies_admitted`, `newlyLive_implies_admitted_or_reopened`, `disappears_implies_obligationTerminal`, `Run.history_eq`; `GenericFoundation/Responsibility/Debt/Activation/World/LivingLawRootGeneratedDebtActivationWorldReadback.lean` `[T0]`: `inactiveInventoryPresentation`, `activeInventoryPresentation`, `active_debt_row_unique`; `.../Root/Direct/LivingLawRootGeneratedDebtActivationDirectCompilerKernel.lean` `[T0]`: `CompiledResultAt`, `compile`; `LivingLawRootNoetherianDebtClosureKernel.lean` `[T0]`: `generatedHistory`, `terminalSettlement`, `generatedSettlement`, `generatedReceipt`; 表 2 实例见 `...TargetSixActionDebt.lean` |
| 命题 7.3–7.5 同支承残差双空破产与因果审计 `[T0]` 破产核 | `GenericFoundation/Occurrence/Residual/Admission/LivingLawRootGeneratedResidualWorldCofaceKernel.lean` `[T0]`: `liftTheory`, `residualFailure`; `...DependentJointPassiveResidualAuditTransition.lean`: `causal_transition_mouth` |
| 命题 8.2–8.3、定理 8.4, 8.6–8.7、命题 8.8 初始余面 `[T0]` | `LivingLawObstructionGeneratedMinimalCofaceKernel.lean` `[T0]`: `GeneratedMinimalCofaceAt`, `oldTheoremSurvival`, `no_newResponsibility_on_oldFace`, `no_newClaim_on_oldFace`, `FaithfulCofaceMorphism`, `minimal_coface_initial`, `minimal_coface_factorization_unique`, `compose_embed_associates`; `LivingLawTypedSemanticWorldNetworkU8{,Recovery}Kernel.lean` `[T0]`: `factorizesThroughInitialCoface`, `factorizesThroughInitialCofaceAnswerAndNext` |
| 表 4、命题 8.9–8.10 两拍修订运行与一次性空纤维反例 | `LivingLawRootInquiryU8CompletionRegression.lean`: `generatedTypedRevision`, `public_old_new_rows_generate_same_next`; `LivingLawCanonicalInquiryRuntimeRegression.lean`: `firstTick_resolution_is_revised`, `secondTick_is_revised_root_answer`, `oneShot_has_no_autonomous_runtime` `[T0]` |

### D.2 内生计算链与完整执行层声明入口（提交 AB, AC, AD, AE）

路径相对 `Lean/SaturationMonoid/GenericFoundation/`（缩写：`JS/` = `Responsibility/Debt/Activation/Root/Direct/JointSource/`，`DJ/` = `Operations/Native/Tree/Fold/Dependent/`，`ACT/` = `Operations/Inquiry/Context/Faces/Execution/Activation/`，`AW/` = `DJ/Joint/ActionWords/Inventory/`）：

| 正文定理（固定提交） | Lean 4 模块与核心声明 |
| --- | --- |
| 命题 3.7、定理 3.9 计费执行迹与整树语法左逆（AB） | `Operations/Execution/{Step,Run,Trace,Relations}.lean`: `remaining`, `Step.remaining_eq`, `step_wellFounded`, `execution_length`, `Trace.toDerivation`, `Trace.relation_boundary`; `Operations/Native/Tree/Fold/{Source,Inverse}.lean`: `program`, `program_value`, `program_budget`, `readTree`, `read_program`, `program_injective` |
| 定义 6.9、定理 6.10、命题 6.11 内生执行账与整树询问（AB） | `Operations/Execution/Debt/Source.lean`: `State`, `law`, `completed_value`; `JS/OwnerFree/{Source,Compiler,Authority,Runtime,Completion,Payment,Consumer}.lean`: `mathEntry`, `patch_fold`, `budget`, `activePayment`, `no_refill`, `endpoint_no_paid`, `relation_boundary`; `Operations/Native/Tree/Fold/{Installation,Consumer,Recovery}.lean` |
| 命题 7.6（AB）、定理 7.7（AC）依赖步供料与后继激活 | `DJ/{Source,Installation}.lean`: `sourceFeed`, `generatedFeed`, `actual_effect_value`; `DJ/Input/{Source,Consumer,Runtime/Source,Runtime/Consumer}.lean`: `inputState`, `generatedRuntime`; `DJ/Next/{Source,Consumer}.lean`: `nextVisit`, `generatedNext`, `current_whole_next` |
| 定义 8.11、定理 8.12 残差请求与递归帧运行（AB） | `JS/Native/ResidualRequest.lean`: `expression_eval`, `budget`, `updated_value`, `residual_zero_iff`; `JS/Native/Restructuring/Inquiry/Continuation/{Frame,Source,Policy,Inventory,Occurrence,Runtime,Payment,Residual}.lean`: `frames_erase_injective`, `actual_node`, `macro_next_preserves`, `actual_paid_receipt` |
| 定理 9.2、9.3、9.5 联合时序程序、全行动者与通用准入（AD） | `Occurrence/Temporal/{Source,Action/Source,Action/Inverse,History/Common/...}.lean`; `DJ/Joint/{Source,Laws,Consumer,TargetDifference,TargetProgramme,TargetConsumer}.lean`; `AW/{Source,Complete/Source,EffectHistory/...,NodeHilbert/...}.lean`; `ACT/{Programme,Target,Receipt/Source,Receipt/Execution,Receipt/Compiler,Receipt/Consumer,Receipt/Runtime}.lean` |
| 定理 9.6、9.7、9.8 双库存跨越、协变配对与默认运行（AE） | `ACT/Receipt/Inventory/{Source,Laws,Installation,Born/...}.lean`: `binding_value`, `migrated_charge`, `actual_injective`; `Operations/Inquiry/Context/Native/Pairing/{Source,Orbit/...}.lean`: `point_covariance`, `complete_charge`; `DJ/{Joint,Branch}/Primary/Consumer.lean`; `DJ/Branch/JointQuery/Actor/.../Consumer.lean` |

### D.3 `Type` 完成回执、总值反馈、六面复形与最大未来核声明入口（提交 PR, MF, MV2, MV3, H0-S）

缩写承接 D.2，另记 `W/` = `ACT/Receipt/Configured/Writeback/`，`I/` = `Operations/Inquiry/Cofinal/Native/`，`F/` = `DJ/Branch/JointQuery/Actor/Operation/Query/Inventory/Observer/CurrentChild/Dynamic/Live/Native/Action/Coupled/Registry/Calculation/Common/Feedback/Continuation/`，`Cx/` = `F/SourceFamily/Foresight/Contextual/`：

| 正文定理（固定提交） | Lean 4 模块与核心声明 |
| --- | --- |
| 定理 6.12 `Type` 完成回执与共尾出生（MV2/MV3） | `ACT/Completion.lean`: `Receipt`, `receipt`, `receipt_next`, `receipt_compiles`; `ACT/Completion/{Prefix,Births}.lean`: `receipt_distance_exact`, `receipt_paid_prefix`, `birthIndex`, `cover` |
| 定理 8.14 同发生双边界差词与环境方块（PR, MF, H0-S） | `Operations/Execution/Coefficients/{Source,Words}.lean`: `expression_eval`, `expression_remaining`; `Cx/Profile/Finite/Reader/Difference/{Source,Inquiry/...,Actual}.lean`: `difference_in_actual_history`, `own_fee`; `Cx/Mixed/{Effect,Receipt,Consumer}.lean`; H0-S `FiniteIncoming.lean`, `ActualNativeEnvironment.lean` |
| 定理 8.15 总值写回与逐包重生解码器（MV3） | `W/{Source,Consumer}.lean`: `old_paid_value`, `native_value`, `updated_total`, `born_environment`; `W/Successor/{Source,Consumer}.lean`: `successorPacket`, `second_decoder`, `second_writeback` |
| 定理 9.9–9.12 全词保序入库、共尾段、六面与 $\mathsf{M}_{\rm fut}$（MV2/MV3） | `Operations/Inquiry/Context/Native/Frame/{Source,Stock,Stock/Return,Stock/Coordinates,Stock/Birth}.lean`: `fullword_read`, `intoBorn_strictMono`; `F/SourceFamily/Activation/{Source,Stage,Admissions}.lean`: `nextAdmissionAt`, `actual_segment`, `cofinal`; `W/Successor/FourFace/...`: `actualRelation`, `generated_differential`; `I/Installed/Cofinal/Tower/...`: `actual_receiver_square`, `model_fibre`, `model_action_native`; `Operations/Observed/Words/{Kernel,Model}.lean` |

### D.4 第三版可逆增量续行与跨领域窗口实装声明入口（提交 MV4, MV5, `7e4da746f3`）

缩写承接 D.2–D.3，另记 `SF/` = `F/SourceFamily/Calculation/`，`Q/` = `ACT/Receipt/Inventory/ActualQuery/`，`RC/` = `I/Installed/Cofinal/Action/Common/RootConsumer/`，`A_src/` = `I/Installed/Cofinal/Action/Source/`，`NM/` = `NoIslandNoMagic/CanonicalArithmeticState/ParticleWave/Fock/Runtime/SourceHistory/Operation/Calculation/Admission/Inquiry/Continuation/Residual/PaidNativeMethod/`，`J/` = `NoIslandNoMagic/CanonicalRiemann/GeneralizedDual/CoPoissonEnergy/Muntz/Cokernel/CenteredGram/JointAction/Runtime/Feedback/`：

| 正文定理与命题编号（固定提交） | Lean 4 生产模块与直接核验声明 |
| --- | --- |
| 定理 10.1 全环境语义零与后继可写请求（C46，MV4） | `RC/Semantics.lean`: `semanticZero`, `universal_inventory_zero`, `lift_semantic_zero`, `residual_semantic_zero`, `semantic_model_equiv`; `RC/{Source,Consumer}.lean`: `rootedMaterial`, `rootedRequest`, `rooted_request_model`, `actual_generated_current`, `originalOldRow`, `originalBornRow`, `actual_root_future`（CP121） |
| 定理 10.2(1) 保留余项重排联合求值（C47，MV4） | `SF/Factory/{Source,Consumer}.lean`: `withCalculation`, `codeAt`, `cofinal_actual_value`; `SF/ActualInput/{Source,Consumer}.lean`: `withActualInput`, `actual_environment`; `SF/FullResidual/{Source,Consumer,Dynamics/Source,Dynamics/Consumer,Dynamics/Initial}.lean`: `regroup`, `jointCode`, `joint_eval`, `joint_complete`, `cofinal_collapsed_value`（CP122–126） |
| 定理 10.2(2) 共同源输入与线性接收器出处（C48，MV4） | `Q/{Source,Consumer,Next/Source,Next/Consumer}.lean`: `commonMaterial`, `query_action_raw`, `commonAtNext`; `Q/Next/EnvironmentUpdate/{Source,Consumer}.lean`: `source_env_update`, `source_sum_actual`; `Q/Next/Linear/Receiver/{Source,Consumer,Action}.lean`: `actual_updated_value`, `read_material_update`（CP128–131, 135–136） |
| 定理 10.2(3) 同债语法信用严格扣款与完结（C49，MV4） | `SF/ActualInput/EnvironmentUpdate/CurrentMaterial/{Source,Consumer}.lean`: `nativeMaterial`, `consume_actual`; `.../RootedEffect/{Source,Consumer,Completion/Source,Completion/Consumer}.lean`: `native_residual_effect`, `born_actual_payment`, `bornWholeWrite`, `completed_native_effect`, `consume_rooted_completed_answer`（CP132–134） |
| §10.4 有限 $P_a$ 窗口四迹与逆残差纠正（C50，MV4） | `J/ClozelOriginalKFinitePaWindowOperatorSourceAction/{Word,Inverse,Cochain,Emitter,Born,Received,Consumer,Root,Complete}.lean`: `finite_stock_generated_source_delta`, `actual_finite_window_whole_next_future`（CP217）；`J/ClozelOriginalKWindowInverseResidualSourceAction/{Source,Effect,Emitter,Born,Received,Observation,Physical,Consumer}.lean`: `received_source_recovery_action`, `received_actual_source_window_price`（CP219） |
| 定理 10.3 双取反已付语法树恢复与同态续行（C51，MV5） | `SF/ActualInput/PaidMethod/Source.lean`: `pairAction`, `actionAt`, `retainedCode`, `raw`, `raw_value`, `factory`, `templateFourFaces`; `PaidMethod/Recovery.lean`: `negate_paid`, `after_native_retained`, `after_native_value`, `after_native_whole_action`, `actual_complete_query_written`, `actual_native_faces`; `PaidMethod/Admissions.lean`: `cofinal_paid_method_faces`, `finite_paid_method_faces`（CP483） |
| 定理 10.4 整词逐原语回放与余链微分锁步（C52，MV5） | `Operations/Native/Context/WordExecution.lean`: `observerEnvironment`, `embed_eval`, `embeddedStep`, `embeddedTrace`, `pairedForward`, `forward_charge`; `NM/RelationCochain/{Source,Consumer}.lean`: `replayStock`, `replay_written`, `replay_next_query`, `actual_boundary_from_source`, `actual_complex_boundary`, `actual_complex_differential`, `actual_coimage_boundary`, `actual_relation_cochain_method`（CP485） |
| 定理 10.5 执行步—请求双向区间反演与防漏重（C53，`7e4da746f3`） | `A_src/Receipt.lean`: `atBirth`; `A_src/Receipt/Block/Position.lean`: `readExecutedStep`; `A_src/Receipt/Origin.lean`: `RequestOriginAt`, `readRequestOrigin`; `A_src/Receipt/Block/StepInterval.lean`: `StepInterval`, `stepInterval`, `sourceRequestAt_interval_address`; `StepInterval/Whole.lean`: `grouped_requests`, `grouped_executed_trace`, `grouped_request_boundary`; 负控制门禁见 `Verification/no-island/riemann-r-cofinal-complete-grouped-write/Gate.lean`（CP514, 521, 528–532） |
| 定理 10.6 封存历史末态续跑与单遍时间表（C54，`7e4da746f3`） | `Operations/Inquiry/NativeHistoryContinuation.lean`: `HistoryAt.eq_runFrom`, `storedOccurrenceAt`, `stored_occurrence_eq`, `continueFor`, `extendTo`, `extendTo_prefix`; `Operations/Runtime/StoredHistory.lean`: `stored_pair_actual`, `stored_inventory_actual`; `Operations/Runtime/StoredTimeline.lean`: `storedTimeline`, `stored_timeline_adjacent`, `timeline_inventory_actual`（CP596–598） |

## 附录 E 核心术语与符号速查表

| 术语／符号 | 单行结构定义 | 首次正式引入 |
| --- | --- | --- |
| T0 / T1 双层公理核 | T0：零公理构造性内核（`#print axioms = []`）；T1：仅用 `propext`、`Classical.choice`、`Quot.sound` 的模与完备化层 | 题注、§1.1 |
| 有根发生展开 $\mathrm{occur}(a,\vec T)$ | 唯一归纳构造子，零公理派生前沿 $\mathrm{fr}$、结合推进 $\mathrm{adv}$、并／联组合 $\oplus_r,\otimes_r$ 与唯一折叠 $\mathrm{fold}$ | 定义 2.1、定理 2.2 |
| 根读恒等 $\mathrm{rootRead}(o)=o$ | 完整时序根发生上的恒等读出，对任意下游处分消费安全且隐藏空证人类型为空 | 定义 2.1、定理 2.2(3) |
| 源过程 $\mathcal{P}=(S,\iota,s_0,\sigma)$ | 无结构状态集 $+$ 活当前单射登记 $+$ 初态 $+$ 保持法则面的单拍生成后继 | 定义 2.3、命题 2.4 |
| 自由载体 $\mathbb{Z}[S]$ 与联合提升 $\mathrm{lift}(f)$ | 状态基点有限整数形式和（Z-集）及二元函数经 $\mathrm{push}_f\circ\mathrm{joint}$ 的双加性提升 | §2.3、定义 2.6 |
| 结构效应 $\mathrm{eff}_{\rho,\varepsilon}(e)$ 与混合项表 | 更新差值 $\mathrm{ev}_{\rho+\varepsilon}(e)-\mathrm{ev}_\rho(e)$（双线性节点含三项）及保序保重数展开表 | 定义 3.2、定义 3.4 |
| 整树程序 $\mathrm{prog}_\kappa T$ 与语法左逆 $\mathrm{read}$ | 按节点双线性提升构造子的计费表达式（预算 $\beta(T)$）及不经求值还原整棵树的纯语法解析器 | 定义 3.8、定理 3.9 |
| 关系映射 $\mathrm{rel}_\rho$ 与阶段商塔 $\widehat C(s)$ | 推导端点差 $\sqcup$ 标量模律的线性延拓（$\operatorname{range}=\ker\mathrm{ev}_\rho$）及前缀商逆极限完备化载体 | 定义 4.3、定义 4.5 |
| 忠实过程实现与源生唯一比较 $\Phi_{12}$ | 双向发生—事件表示 $+$ 发射相容 $+$ 编译合法；无需模拟关系唯一确定跨实现事件映射 | 定义 5.1、定理 5.3 |
| 完整活账 $L_s$ 与付款宏步 | 开立责任依赖和 $\sum_r\mathrm{OpenAt}(s,r)$；三段夹逼 $\le\,;\,<\,;\,\le$ 构成的良基扣款链 | §6、定义 6.6、定理 6.7 |
| 执行债务律 $\Lambda_{\rho,e}$ 与 `Type` 回执 $\mathsf{Receipt}_i$ | 以已付迹前缀为态、剩余步数 $r(e')$ 为预算的内生激活律及返回步距 $d_i=B_i$ 的依赖和回执 | 定义 6.9、定理 6.12 |
| 根植双空破产 $\eta$ 与初始余面 $C_\eta$ | 表达见证与合法实现纤维俱空且绑定访问与活账行；零公理生成 $L_+\sqcup\{\star_\eta\}$ 并具唯一忠实单射分解 | 定义 8.1、命题 8.2、定理 8.4 |
| 语义锚定（精确／分裂精化） | 将有类型语义修订 $\Xi$ 的新根字段认回初始余面或认回真实二分裂覆盖，导出双路回答—后继 | 定理 8.7、附录 C.2 |
| 残差请求 $e\ominus e'$ 与总值写回 $V=p+n$ | 已付态在新环境下的差词 $e+\mathrm{linear}_{-\mathrm{id}}(e')$（预算 $\ge 2$）及旧已付值加原生效应写回 | 定义 8.11、定理 8.15 |
| 最大未来不可见不变核 $K_{\mathrm{fut}}$ 与 $\mathsf{M}_{\mathrm{fut}}$ | 直和载体 $\bigoplus_j\mathcal{W}_j$ 上经一切允许未来词 $a\in\{\ast\}^{<\omega}$ 与站点 $j$ 读出皆零的最大 $S$-不变子模及商 | 定理 9.12 |
| 全环境语义零子模 $\mathcal{Z}_{\mathrm{sem}}$ | 在一切环境赋值下求值恒为零的形式词子模，保持配对提升并使 $\delta_{e\ominus e'}$ 与 $\delta_e-\delta_{e'}$ 在 $\mathsf{M}_{\rm fut}$ 同余 | §10.1、定理 10.1 |
| 保留代码提取器 `retainedCode` | 从两层残差语法原位构造纯语法双取反 $(-\mathrm{id})((-\mathrm{id})(e'))$，无环标量恢复已付常量执行同态 $f^{(n+1)}$ | 定理 10.3 |
| 双向切片 `stepInterval` / `readRequestOrigin` | 已执行步骤 $i$ 到连续有号请求切片 $[a_i,a_i+c_i)$ 的正向映射与 $r=a_i+s$ 的反向唯一起源反演 | 定理 10.5 |
| 末态增量续行 `extendTo` 与 `storedTimeline` | 锁死已存 `fuel` 拍激活前缀、仅从末态跑 `total-fuel` 拍后缀，及长 `fuel+1` 的单遍相邻库存投影表 | 定理 10.6 |

<!-- code-availability:begin -->
## 代码与数据可得性

首版继承证明与直接核验模块绑定公开仓库 [H0mework](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a) 固定提交 `234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a`，对应[首发证明映射](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/docs/first-release-map.json)与[首发复现指南](https://github.com/Sapientropic/H0mework/tree/234817b3c3f7a1023226e7a4fdb8660ddcbc9d0a/docs/first-release-reproduction.md)。

第二版证明、源生动作环境方块与有限入站接线绑定公开仓库提交 `b9d66048342b1a5aeac3e112d920ed85401bb20a`，对应[第二版逐项源码映射](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/second-edition-map.json)、[准备度记录](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/second-edition-readiness.md)、[已发布绑定索引](https://github.com/Sapientropic/H0mework/blob/e9734c69f38cf03b79859a1108ae23a5663a0495/docs/assets/paper-source-binding-b9d66048.json)及已发表第二版归档（DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175)）。按[版本复现指南](https://github.com/Sapientropic/H0mework/tree/b9d66048342b1a5aeac3e112d920ed85401bb20a/docs/edition-reproduction.md)，运行 `python3 tools/edition_release.py --edition second verify-map` 校验源码映射，运行 `python3 tools/edition_release.py --edition second --paper source-process-core build --output .local/v2-build`（或将 `build` 换为 `trust`）执行严格构建与声明闭包核验。

第三版的 C46–C54 公开证明固定于 [H0mework](https://github.com/Sapientropic/H0mework/tree/5f94af7e988c9831c92e54fe89747699fa29cd85) 提交 `5f94af7e988c9831c92e54fe89747699fa29cd85`。
[逐项映射](https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/source-process-core-v3-map.json)登记源、直接消费者、完整声明类型和原认证。C47–C48 的入口为
`H0mework.Papers.SourceProcessCoreV3.MV4`。C46、C49、C50 沿用整账法 WA38–WA40，C51–C54
沿用 WA41–WA42 与 WA44–WA45。固定研究来源为 MV4 `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`、MV5 `df421ff600085cbc290a7ae946193961bed7c83b` 与
`7e4da746f300b3796b8b18afb26cb0765c29afcb`，原认证各有自己的执行纪元。

在 H0mework 根目录运行 `python3 tools/source_process_core_v3.py entry`。
[复现指南](https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/source-process-core-v3-reproduction.md)给出构建、公理依赖、完整类型和公开恢复命令。
[本地验收](https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/source-process-core-v3-readiness.md)登记实际结果与根读核的公理检查。两种语言的正文与证明补充、
书目、编辑图源和固定文件清单 `public-source-binding.json` 随可编辑包提供。
源码采用 Apache-2.0，正文、证明补充和原创图件采用 CC BY 4.0。
<!-- code-availability:end -->

## 参考文献

1. <a id="ref-1"></a>M. Budiu, T. Chajed, F. McSherry, L. Ryzhyk, V. Tannen. DBSP: Automatic Incremental View Maintenance for Rich Query Languages. *Proceedings of the VLDB Endowment*, 16(7):1601–1614, 2023. doi:10.14778/3587136.3587137.
2. <a id="ref-2"></a>Y. Cai, P. G. Giarrusso, T. Rendel, K. Ostermann. A Theory of Changes for Higher-Order Languages: Incrementalizing $\lambda$-Calculi by Static Differentiation. In *Proceedings of the 35th ACM SIGPLAN Conference on Programming Language Design and Implementation (PLDI ’14)*, 145–155, 2014. doi:10.1145/2594291.2594304.
3. <a id="ref-3"></a>T. J. Green, G. Karvounarakis, V. Tannen. Provenance Semirings. In *Proceedings of the 26th ACM SIGMOD-SIGACT-SIGART Symposium on Principles of Database Systems (PODS ’07)*, 31–40, 2007. doi:10.1145/1265530.1265535.
4. <a id="ref-4"></a>C. H. Bennett. Logical Reversibility of Computation. *IBM Journal of Research and Development*, 17(6):525–532, 1973. doi:10.1147/rd.176.0525.
5. <a id="ref-5"></a>The Stacks Project Authors. Lemma 10.12.2: Tensor Products, Tag 00CX. *The Stacks Project*, https://stacks.math.columbia.edu/tag/00CX.
6. <a id="ref-6"></a>L. Lamport. The Temporal Logic of Actions. *ACM Transactions on Programming Languages and Systems*, 16(3):872–923, 1994. doi:10.1145/177492.177726.
7. <a id="ref-7"></a>M. Abadi, L. Lamport. The Existence of Refinement Mappings. *Theoretical Computer Science*, 82(2):253–284, 1991. doi:10.1016/0304-3975(91)90224-P.
8. <a id="ref-8"></a>G. Winskel. Event Structures: Lecture Notes for the Advanced Course on Petri Nets. Technical Report UCAM-CL-TR-95, University of Cambridge Computer Laboratory, 1986. doi:10.48456/tr-95.
9. <a id="ref-9"></a>J. J. M. M. Rutten. Universal Coalgebra: A Theory of Systems. *Theoretical Computer Science*, 249(1):3–80, 2000. doi:10.1016/S0304-3975(00)00056-6.
10. <a id="ref-10"></a>R. E. Kalman. Mathematical Description of Linear Dynamical Systems. *Journal of the Society for Industrial and Applied Mathematics, Series A: Control*, 1(2):152–192, 1963. doi:10.1137/0301010.
11. <a id="ref-11"></a>J.-Y. Girard. Linear Logic. *Theoretical Computer Science*, 50(1):1–101, 1987. doi:10.1016/0304-3975(87)90045-4.
12. <a id="ref-12"></a>J. C. Reynolds. Separation Logic: A Logic for Shared Mutable Data Structures. In *Proceedings of the 17th Annual IEEE Symposium on Logic in Computer Science (LICS 2002)*, 55–74, 2002. doi:10.1109/LICS.2002.1029817.
13. <a id="ref-13"></a>R. Atkey. Amortised Resource Analysis with Separation Logic. *Logical Methods in Computer Science*, 7(2:17):1–33, 2011. doi:10.2168/LMCS-7(2:17)2011.
14. <a id="ref-14"></a>G. C. Necula, P. Lee. Safe Kernel Extensions Without Run-Time Checking. In *Proceedings of the Second USENIX Symposium on Operating Systems Design and Implementation (OSDI ’96)*, 229–243, 1996. doi:10.1145/238721.238781.
15. <a id="ref-15"></a>P. Martin-Löf. *Intuitionistic Type Theory*. Bibliopolis, Naples, 1984.
16. <a id="ref-16"></a>The Univalent Foundations Program. *Homotopy Type Theory: Univalent Foundations of Mathematics*. Institute for Advanced Study, Princeton, 2013.
17. <a id="ref-17"></a>L. de Moura, S. Ullrich. The Lean 4 Theorem Prover and Programming Language. In *Automated Deduction – CADE 28*, Lecture Notes in Computer Science, vol. 12699, 625–635, 2021. doi:10.1007/978-3-030-79876-5_37.
18. <a id="ref-18"></a>C. E. Alchourrón, P. Gärdenfors, D. Makinson. On the Logic of Theory Change: Partial Meet Contraction and Revision Functions. *Journal of Symbolic Logic*, 50(2):510–530, 1985. doi:10.2307/2274239.
19. <a id="ref-19"></a>J. A. Goguen, R. M. Burstall. Institutions: Abstract Model Theory for Specification and Programming. *Journal of the ACM*, 39(1):95–146, 1992. doi:10.1145/147508.147524.
20. <a id="ref-20"></a>R. Milner. *A Calculus of Communicating Systems*. Lecture Notes in Computer Science, vol. 92, Springer-Verlag, Berlin, 1980. doi:10.1007/3-540-10235-3.
21. <a id="ref-21"></a>J. A. Bergstra, J. W. Klop. Process Algebra for Synchronous Communication. *Information and Control*, 60(1–3):109–137, 1984. doi:10.1016/S0019-9958(84)80025-X.
22. <a id="ref-22"></a>U. A. Acar, G. E. Blelloch, R. Harper. Adaptive Functional Programming. *ACM Transactions on Programming Languages and Systems*, 28(6):990–1034, 2006. doi:10.1145/1186632.1186634.
23. <a id="ref-23"></a>J. N. Foster, M. B. Greenwald, J. T. Moore, B. C. Pierce, A. Schmitt. Combinators for Bidirectional Tree Transformations: A Linguistic Approach to the View-Update Problem. *ACM Transactions on Programming Languages and Systems*, 29(3):Article 17, 2007. doi:10.1145/1232420.1232424.
24. <a id="ref-24"></a>S. Mac Lane. *Categories for the Working Mathematician*. 2nd ed., Graduate Texts in Mathematics, vol. 5, Springer, New York, 1998. doi:10.1007/978-1-4757-4721-8.
