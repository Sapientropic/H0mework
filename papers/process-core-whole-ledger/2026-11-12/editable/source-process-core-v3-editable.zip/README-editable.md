# source-process-core · v3 editable inputs

The Markdown manuscripts and supplements, bilingual vector figures, bibliography,
metadata and the existing builders retain the publish-relative layout. The
source notebooks, private prompts and research repositories are separate.

Run from `papers/source-process-core` with Python 3, Pandoc, XeLaTeX, xeCJK and the Noto
Serif/Sans CJK SC fonts installed. Build the four reading PDFs with:

```sh
python3 scripts/build_pdf.py manuscript.md --output build/v3/source-process-core.pdf --work-dir build/v3/work-zh
python3 scripts/build_pdf.py manuscript-en.md --output build/v3/source-process-core-en.pdf --work-dir build/v3/work-en
python3 scripts/build_pdf.py supplement.md --output build/v3/source-process-core-supplement.pdf --work-dir build/v3/work-supp-zh
python3 scripts/build_pdf.py supplement-en.md --output build/v3/source-process-core-supplement-en.pdf --work-dir build/v3/work-supp-en
```

These are the editable inputs for the four Zenodo reading PDFs. Paper text and
figures use CC BY 4.0; formalization follows the repository's Apache-2.0 license.
The Code and data availability section records each fixed source, the published
claim binding and its actual acceptance scope. Original source certification,
source identity, subsequent public package re-verification and CI retain their
separate execution scopes.

`editable-inputs.json` binds the inputs byte for byte.
