# Proof Supplement: Provenance-Preserving Conservation Calculus and Non-Free Continuity

**Whole-Event Inventories, Paid Syntax, Zero-Evaluation Certificate Inversion, and Step-Grouped Continuation**

**Author: Jian Gao (高健)**\
Independent Researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

This proof supplement expands in full detail the technical constructions and step-by-step proofs invoked in Sections 3, 4, 5, 7, 8, 14, and 15 of *Provenance-Preserving Conservation Calculus and Non-Free Continuity: Whole-Event Ledgers, Observer Safety, and Well-Founded Settlement* (Second Edition, v2): Section A proves the four-way mathematical residual disposition induced by native-write receipts (WA12); Section B proves full-type restructuring certificate lifting, continuing transported remainders, and capacity-maintenance debit bounds (WA4–WA5, WA15–WA17); Section C proves owner-free syntactic birth, integer coefficient and substitution body replays, iterative batch charges, and all-count row authorities (WA13–WA14, WA18–WA21, WA26–WA28); Section D proves cross-language heterogeneous stock readback, same-receipt total writeback, exact completion distance and maximal future kernels, double-negation paid-AST recovery and primitive cochain replay (WA41–WA42), free constant-table integer certificate inversion (WA43), and contiguous step-interval anti-omission/anti-duplication batching with sealed-prefix tail continuation (WA44–WA45); Section E proves upstream resolvent-comb installation for long analytic windows (WA33). Shared process-core results cite Version 2 of the process-algebra companion [[1]](#ref-1) (DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175)).

---

<a id="supplement-a"></a>
## A Four-Way Mathematical Residual Disposition Induced by Native-Write Receipts

<a id="supplement-a-1"></a>
### A.1 Complete Linear Recovery and Three Exact Residual Witnesses (WA12)

Fix a concrete dynamical source $D$, state $s$, and target additive abelian group $A$. At every primitive event, the source input law supplies generator type $G$, the complete exposure tree rooted at that occurrence, initial seed, continuation tree, and evaluator tree; seed and continuation generate complete history $H_s$. None of these inputs contains a preset disposition branch, trivial-kernel premise, surjectivity premise, or external inverse.

Step 1 eliminates the whole-ledger compilation at that occurrence: because relation-write, continued-transport, redirect, and local-terminal payloads are all `PEmpty` in this vocabulary, the unique surviving native-write payload directly recovers $\varepsilon=D.\mathrm{emit}(s)$, and presentation round-trip equality identifies the compiled receipt with the emitted event. Every algebraic object below is determined by that single transfer receipt.

Let $E:\mathbb Z^{(G)}\to A$ be the $\mathbb Z$-linear extension of the evaluator. History $H_s$ retains both generator closure and relation closure: if the relation closure vanishes under $E$ (sound relations), $E$ descends to $\overline E:\widehat H_s\to A$ on the completed carrier; otherwise some actual relation $q$ in the closure satisfies $E(q)\ne 0$. Faithful settlement classifies relation soundness, $\ker\overline E$, and $A/\operatorname{im}\overline E$ into four branches:

1. **Faithful isomorphism branch**: sound relations, $\ker\overline E=\{0\}$, and singleton cokernel $A/\operatorname{im}\overline E$ construct a full $\mathbb Z$-linear isomorphism $\phi:\widehat H_s\simeq A$ whose inverse satisfies $\overline E(\phi^{-1}(a))=a$ for every $a\in A$.
2. **Unsound-relation branch**: extracts an actual relation $q$ in the history's relation closure together with $u=E(q)\ne 0$.
3. **Nonzero-kernel branch**: sound relations with $\ker\overline E\ne\{0\}$ extract $k\in\widehat H_s$ satisfying $k\ne 0$ and $\overline E(k)=0$ (zero numerical evaluation never erases this nonzero completed coordinate).
4. **Coverage-loss branch**: sound relations and $\ker\overline E=\{0\}$ with non-singleton $A/\operatorname{im}\overline E$ take the difference of two distinct cosets to obtain a nonzero coset $c\ne 0$ and preimage representative $a\in A$ ($[a]=c$), so $a\notin\operatorname{im}\overline E$. For **any** candidate recovery function $f:A\to\widehat H_s$ (without assuming linearity), $\overline E(f(a))=a$ would imply $a\in\operatorname{im}\overline E$ and $[a]=0=c$, a contradiction; hence $\overline E(f(a))\ne a$.

Because both material and residual projections install prior to the emitter on the same authoritative source, the ledger root and emitter $D.\mathrm{emit}$ remain unchanged, delivering alongside any branch the budget-preserving transfer:
$$\mathrm{entry}(s)\xrightarrow{\varepsilon}\mathrm{entry}\bigl(D.\mathrm{update}(\varepsilon)\bigr),\qquad \mathrm{next}(s)=D.\mathrm{update}(\varepsilon),\tag{S.1}$$
without mistaking residual classification for a strict same-debt debit.

---

<a id="supplement-b"></a>
## B Full-Type Restructuring Certificate Lifting, Remainders, and Capacity Debits

<a id="supplement-b-1"></a>
### B.1 Fieldwise Left-Inverse Lifting and All-Branch Whole-Join Folding (WA5, WA15–WA17)

In the finite complete-native append setting (WA15), augmenting row index set $I=\operatorname{Fin}(m)$ to $\operatorname{Fin}(m+1)$ preserves every prior row via $\operatorname{castSucc}:\operatorname{Fin}(m)\hookrightarrow\operatorname{Fin}(m+1)$ with its source/target entries, selectors, and receipts intact while placing the new math row at $\operatorname{last}(m)$. Repeated claims or identical payloads remain at distinct indices without deduplication; two-sided injectivity follows solely from the prior `IdentityScope` certificate and disjoint `old`/`math` tags.

In the general split/merge lifting setting (WA16), target injectivity is dropped. Augmenting mother vocabulary $V$ to $V^+$ tags content, residual, bearer, beneficiary, scope, event, and lineage by `old` $\sqcup$ `math` while keeping every prior `Type`-valued admission, authority, assumption, origin, and progress, transfer, and discharge fibre verbatim on `old`. Embedding $j:\mathrm{Obligation}_V\to\mathrm{Obligation}_{V^+}$ and partial readback $p:\mathrm{Obligation}_{V^+}\to\operatorname{Option}(\mathrm{Obligation}_V)$ satisfy fieldwise:
$$p(j(a))=\operatorname{some}(a),\tag{S.2}$$
proving $j$ injective by applying $p$ and cancelling `some`. Mother split child lists map to $\operatorname{map}(j,\mathrm{children})$ (and merge parent lists symmetrically to $\operatorname{map}(j,\mathrm{parents})$): list membership recovers mother membership via Equation (S.2), transporting source ownership, anchor transport, lineage, and local discharge directly; full origin-fibre coverage inverts $j$ to invoke mother coverage (`math` targets cannot share an `old` origin tag); and no-phantom membership plus strict child budget descent $b(\mathrm{child})<b(\mathrm{parent})$ commute with budget readout. The lifted restructuring certificate is thus generated entirely from the mother compiler image with zero target-side re-certification.

Across all continuing branches (WA17), a per-current `Packet` eliminates native-write, relation-write, continued-transport, or redirect from the generated ledger to recover $(d,o)$, finite patch, and next current. Pairing math paid steps (or settled idle carries) with $(d,o)$ commutes on prior entries:
$$d^+(j_s(e))=j_t(d(e)),\qquad o^+(j_t(f))=j_s(o(f)).\tag{S.3}$$
Listing only slot-$0$ math row explicitly and routing all prior rows to the compiled remainder event folds componentwise over the $\Sigma$-sum to Equation (S.3)'s exact whole join, lifting the mother restructuring certificate within the same step.

<a id="supplement-b-2"></a>
### B.2 Capacity-Shortage Obstruction and Certified Maintenance-Debit Runs (WA4)

In `ResponsibilityCapacityKernel`, capacity readout $\mathcal R$ bundles source event, bearer, admitted obligations, demanded capacity $C_{\mathrm{dem}}\in\mathbb N$, available capacity $C_{\mathrm{avail}}\in\mathbb N$, and lists of incompatible demands, affected dependencies, and protected boundaries. Classifier $\mathsf{obstruction?}(\mathcal R)$ returns $\operatorname{some}\langle h\rangle$ if $h:C_{\mathrm{avail}}<C_{\mathrm{dem}}$ and $\operatorname{none}$ otherwise; decidability of $<$ on $\mathbb N$ proves both biconditionals in Equation (5) of the main text, while $\mathsf{CapacityObstruction}(\mathcal R)$ holds only $h$ with zero discharge or branch-selection fields.

For a carry-debit process $B$, each receipt $d:\mathsf{ActualMaintenanceDebit}(P,B,g,\lambda)$ holds slot $s\in\mathbb N$, live obligation $o$, source event $\varepsilon$, maintenance receipt $r$, `event_eq` identifying $g.\mathsf{lifecycleEvent}=\mathrm{carried}(s,o,\varepsilon,\mathrm{maintained}(r))$, pre/post slot liveness, $o.\mathsf{lineage}=\lambda$, and $B(\tau,\lambda)<B(\sigma,\lambda)$. Matching `event_eq` across `admit`, `reopen`, and the nine sub-cases of `cross` refutes eight branches by constructor clash and extracts `boundary_anchor_eq` plus `boundary_incidence_eq` in the sole surviving `maintained` branch to build `sourceOwnership`. Inductively mapping a certified run $\gamma$ to $\mathsf{StrictBudgetRun}(B(\sigma,\lambda),B(\tau,\lambda))$ combines $B(\tau,\lambda)+1\le B(\mu,\lambda)$ with $|\mathrm{prior}|+B(\mu,\lambda)\le B(\sigma,\lambda)$ to yield $(|\mathrm{prior}|+1)+B(\tau,\lambda)\le B(\sigma,\lambda)$, proving all bounds in Equation (6).

---

<a id="supplement-c"></a>
## C Paid Syntactic Execution, Exact Node Charges, and All-Count Row Authorities

<a id="supplement-c-1"></a>
### C.1 Telescoping Primitive Traces and Owner-Free Whole-Ledger Splicing (WA13–WA14, WA18)

Over multi-sorted abelian-group languages, remaining node counts satisfy:
$$r(\operatorname{const}c)=0,\quad r(\operatorname{var}x)=1,\quad r(e+f)=r(e)+r(f)+1,\quad r(Le)=r(e)+1,\quad r(B(e,f))=r(e)+r(f)+1.\tag{S.4}$$
Variable binds and constant binary, unary, and biadditive operations each consume one primitive step, while context steps recurse into left or right subtrees. Induction over step constructors proves $r(e)=r(e')+1$ and $\operatorname{ev}_\rho(e)=\operatorname{ev}_\rho(e')$, so left-to-right evaluation produces $T_e:e\to\operatorname{const}(\operatorname{ev}_\rho e)$ with $|T_e|=r(e)$. Mapping $e\to e'$ to $\delta_e-\delta_{e'}$ telescopes along any prefix trace $T:e\to e_k$:
$$\partial\eta_T=\delta_e-\delta_{e_k},\qquad \operatorname{ev}_\rho(\partial\eta_T)=0.\tag{S.5}$$
Telescoping occurs solely in the formal boundary projection $\partial\eta_T$; every intermediate step, order, and relation index of $T$ remains intact inside paid state $(e_k,T_k)$. Extending support by optional math state gives budget $b_k=B-k>0$ for $k<B:=r(e)$ (emitting strict same-debt debits while prior rows carry via transported remainder) and local settlement at $k=B$ ($b_B=0$, admitting no further paid macro-step). In the ten-node Fock instance at depth $d$, budget is $10-(d+1)$ and live residual $\mathrm{physicalPair}_d-\operatorname{ev}_{\rho_d}(e_d)$ reduces at exhaustion to current minus origin physical pair.

<a id="supplement-c-2"></a>
### C.2 Explicit Constants for Integer Expansions, Substitutions, Action Words, and Call Batches (WA19, WA21, WA26–WA28)

1. **Integer expansions**: $N_0(e)=\operatorname{const}0,N_{a+1}(e)=e+N_a(e)$ evaluates to $a\operatorname{ev}(e)$ at cost $a(r(e)+1)$; negative $z=-(a+1)$ adds one unary negation node, giving $c_z(e)=|z|(r(e)+1)+\mathbf 1_{z<0}$. Folding support list $L=[(e_1,z_1),\dots,(e_m,z_m)]$ into $F(L)$ yields:
   $$r(F(L))=\sum_{(e,z)\in L}\bigl(c_z(e)+1\bigr),\qquad \operatorname{ev}(F(L))=\sum_{(e,z)\in L}z\operatorname{ev}(e).\tag{S.6}$$
2. **Substitution body replay**: substitution $\theta$ at target environment $\Theta$ induces $\rho(x):=\operatorname{ev}_\Theta(\theta(x))$ and lifts every step in $\rho$ to a trace in $\Theta$—expanding each $\operatorname{bind}(x)$ into the **complete evaluation trace** of $\theta(x)$ so that $|T[\theta]|=r(e[\theta])$ at constant endpoints.
3. **Ordered action words**: for $|w|=n$, model-only ASTs use $n$ letter nodes plus variable and projection ($n+2$); prefix retention adds $1$ ($n+3$); paired trees pay $2n+5$. Letterwise effect history pays $5$ on the empty word and $7$ per prepended letter:
   $$h([\,])=5,\qquad h(\ell u)=7+h(u),\qquad h(w)=7n+5.\tag{S.7}$$
4. **Cochain coordinates, batches, and child queries**: list $[\mathrm{updated}(e),\mathrm{old}(e)]\mathbin{++}\mathrm{mixedTerms}(e)$ injects mixed terms via $i\mapsto i+2$ at total vector cost equal to term costs plus twice list length. Prefix pair-lifts $e_i=e[\sigma]^i$ with $\Sigma_n=\sum_{i=0}^{n}r(\widetilde e_i)$ assemble into an $(n+1)$-coordinate vector batch of trace length $|T_{\mathrm{batch}}|=\Sigma_n+2(n+1)$, while $B+2$ actual calls pay their exact individual costs:
   $$\mathrm{callCharge}=\sum_{j=0}^{B+1}|T_j|=\sum_{j=0}^{B+1}r(\mathrm{Raw}_j)=\mathrm{callCost}.\tag{S.8}$$
   Selected children of size $m_i$ with output injection cost $4m_i+1$ ($0$ when absent), giving primary query cost $c_{\mathrm{main}}=c_{\mathrm{query}}+c_{\mathrm{oldChild}}+c_{\mathrm{nextChild}}+3$.

<a id="supplement-c-3"></a>
### C.3 Sealed Initial Row Authority and All-Count Recursive Admission (WA20, WA24)

Selecting slot $0$ in the initial math patch directly certifies sealed initial authority $a_0$, and step $k\mapsto k+1$ advances $(e_k,a_k)$ via canonical target entry and $a_k.\mathrm{next}$ without target-side re-admission. From settled material $M=(\rho,e,e',T,\mathrm{owner},\varepsilon)$, residual request $e+(-e')$ has positive budget $r(e)+r(e')+2\ge 2>0$, forcing a strict payment first step that compiles at that exact temporal occurrence to $\mathsf{debtAdmission}$ while preserving `firstDestination`, all prior projection outcomes, and canonical next (even when $\varepsilon=0$, paying $B+2$ steps in full).

---

<a id="supplement-d"></a>
## D Typed Stock, Maximal Future Kernels, Certificate Inversion, and Batch Continuation

<a id="supplement-d-1"></a>
### D.1 Heterogeneous Readback of Cross-Language Stock and Born-Stock Offsets (WA22, WA25, WA32)

At every supplied occurrence, `stockLaw` outputs the complete dependent record holding upper/lower `Raw` inputs, both paid states and traces, variable bindings, migrated traces, and written stock. Inherited target outcome and source outcome satisfy `HEq`, yielding payload type equality; casting along that equality and eliminating `PEmpty` on the inactive branch composes with `HEq` to reduce to ordinary equality, recovering the exact cross-layer record. Under Equation (17)'s three nested $\operatorname{seed}$ seams, position $j$ of the query trace lands at:
$$\iota(j)=j+|H_o|+|H_P|+3,\qquad H_B[\iota(j)]=H_Q[j],\tag{S.9}$$
which is strictly monotone and injective by natural-number cancellation, while recursive folding $\mathrm{historyWritten}(d+1)=\operatorname{seed}(\mathrm{historyWritten}(d),\mathrm{written}(d+1))$ retains every historical stage $0\le d\le\mathrm{depth}$.

<a id="supplement-d-2"></a>
### D.2 Same-Receipt Total-Value Writeback and Joint Difference Stock (WA23, WA29–WA31, WA34)

Paired evaluation outputs $(p,n)=(\operatorname{ev}_\rho e,\operatorname{eff}_{\rho,\varepsilon}e)$, where residual request $e-\operatorname{const}(p)$ settles at $\rho+\varepsilon$ to $n=\operatorname{ev}_{\rho+\varepsilon}e-p$, summing to the exact total:
$$p+n=\operatorname{ev}_{\rho+\varepsilon}e.\tag{S.10}$$
The decoder writes $(p+n)$ solely in the receipt-selected settled branch (retaining $p$ when $n=0$); the next born packet re-reads its own action result to refresh $p^+$ and its decoder, while `Move` aligns `target_root`, `whole_first`, prior projections, and `physicalNext` within one `generatedAction`. For two-execution boundary differences (WA30–WA31), $(r-c(\Psi,0))-(r-c(\Psi,\sigma))=c(0,\sigma)$ executes its own integral-coefficient AST and embeds every new paid exposure through `pairWritten` and native stock into `jointStock`.

<a id="supplement-d-3"></a>
### D.3 Exact Settlement Distance of `Type`-Valued Completion Receipts (WA32)

For any valid programme, frame, and start $i$ with remaining pending node count $B_i$, strong recursion over `frame.action` returns $d=0$ when settled and recurses on `mathNext` (budget $B_i-1$) to return $d'+1$ when paid, transporting endpoint settlement along $(i+1)+d'=i+(d'+1)$. Inducting over $0\le h\le B_i$ gives $B_{i+h}=B_i-h$: positivity for $h<B_i$ excludes settlement so every intermediate step is paid, while $B_{i+d}=0$ combined with $d\le B_i$ forces $d=B_i$.

<a id="supplement-d-4"></a>
### D.4 Cofinal Stop Segment Coverage, Receiver Squares, and Maximal Future Kernels (WA35–WA37)

`StockTarget` compiles paid actions to `answered`/`mathNext` and settled actions to `debtAdmission`/`nextBorn`. Equation (20) ($t_0=0,t_{j+1}=t_j+1+d(t_j+1)$) satisfies $t_{j+1}>t_j$ and $t_j\ge j$, covering every discrete step inside $[t_j,t_{j+1}]$ while incrementing `grade` solely at actual births. On $\mathcal W_j$, word action $S_j:\mathcal W_j\to\mathcal W_{j+1}$ reads the receiver's own environment $(\rho_j^{\mathrm{rec}},\varepsilon_j^{\mathrm{rec}})$ via inverse transport:
$$\mathrm{receiverRead}_j(S_jw)=\bigl(\operatorname{ev}_{\rho_j^{\mathrm{rec}}}(w),\,\operatorname{eff}_{\rho_j^{\mathrm{rec}},\varepsilon_j^{\mathrm{rec}}}(w)\bigr),\tag{S.11}$$
without assuming cross-grade environment equality. On $\mathcal W=\bigoplus_j\mathcal W_j$, $K_{\mathrm{fut}}=\bigcap_a\bigcap_j\ker(D_jS_a)$ is $S$-invariant, characterizes equivalence in $\mathcal M_{\mathrm{fut}}=\mathcal W/K_{\mathrm{fut}}$ by agreement at all $(a,j)$, and embeds into the completion kernel at the empty word.

<a id="supplement-d-5"></a>
### D.5 Three Environment and Positive-Credit Supplements in the Public Implementation

Three companion lemmas from the public v2 process-core implementation retain their exact byte identities in the whole-ledger package: (i) positive receiver credit follows directly from the two-node residual overhead (negation plus addition) minus the birth step; (ii) generic query/calculation environment alignment is stated explicitly and discharged automatically by `Incoming` in contextual families; and (iii) finite configurations with `calculationReader = none` wire directly to the incoming calculation word of the same pair stock while keeping query readers, decoders, and both stocks intact.

<a id="supplement-d-6"></a>
### D.6 Double-Negation Paid-AST Recovery and Primitive Cochain Differential Replay (WA41–WA42)

**Cross-packet paid-method recovery and callback stock (`PaidMethod/{Source,Recovery,Admissions}.lean`, WA41).** Given `baseFactory` and additive homomorphism $f:W_s\to_+ W_s$, define grade-$n$ pair actions recursively by $\mathsf{actionAt}(f,0)=f$ and $\mathsf{actionAt}(f,n+1)=\mathsf{pairAction}(\mathsf{actionAt}(f,n))$ ($\mathsf{pairAction}(g)(u,v)=(g(u),g(v))$), and define the three-branch syntactic extractor:
$$\mathsf{retainedCode}(n,\mathrm{frame}):=\begin{cases}\operatorname{linear}(-\mathrm{id},u),&\text{if }\mathrm{frame.registered.input.expression}=\operatorname{add}(\operatorname{add}(e_0,u),e_{\mathrm{eff}}),\\\operatorname{linear}(-\mathrm{id},u),&\text{else if }\mathrm{frame.registered.input.expression}=\operatorname{add}(e_0,u),\\\mathrm{frame.registered.input.expression},&\text{otherwise.}\end{cases}\tag{S.12}$$
For any grade-$n$ admission packet $P=\langle n,(s,\xi),\mathsf{cfg},\langle\mathrm{rfl}\rangle\rangle$ settling at $p_\star=\operatorname{const}(v_{\mathrm{paid}})\in V_{n+1}$, `nativeAfterAdmission` forms initial frame `native` with first-layer residual $\operatorname{add}(e_0,\operatorname{linear}(-\mathrm{id},p_\star))$; with receipt distance $d$ and settled frame $\mathrm{selected}=\mathrm{frames}(\mathrm{native},d)$, prefix invariance `paid_prefix_expression` proves $\mathrm{selected}$ keeps that first-layer residual, while `bornAfterNative` ($P^+$, at grade $n+1$) wraps a second outer residual $\operatorname{add}(\operatorname{add}(e_0,\operatorname{linear}(-\mathrm{id},p_\star)),\operatorname{linear}(-\mathrm{id},\mathrm{selected.event.state.1}))$. Applying the first branch of Equation (S.12) strips the outer residual and extracts $u=\operatorname{linear}(-\mathrm{id},p_\star)$ to yield:
$$\mathsf{retainedCode}(P^+)\ \simeq\ \operatorname{linear}\bigl(-\mathrm{id},\,\operatorname{linear}(-\mathrm{id},p_\star)\bigr),\qquad p_\star=\operatorname{const}(v_{\mathrm{paid}}),\tag{S.13}$$
which evaluates at any $\Gamma^+$ via $-(-v_{\mathrm{paid}})=v_{\mathrm{paid}}$ (`negate_paid`) to $v_{\mathrm{paid}}$. At grade $n+1$ ($P^+$), setting method input `raw f (n+1) frame` to $\operatorname{pairEnv}(\Gamma^+,0)$ and $\operatorname{linear}(\mathsf{pairAction}(\mathsf{actionAt}(f,n+1)),\operatorname{liftExpr}(\mathsf{retainedCode}(n+1,\mathrm{frame})))$ uses $\operatorname{effect}(\Gamma,0)=0$ (`effect_zero`) and $f^{(n+1)}(0)=0$ to output $(\mathsf{actionAt}(f,n+1)(v_{\mathrm{paid}}),0)=((f^{(n)},f^{(n)})(v_{\mathrm{paid}}),0)$ (`after_native_whole_action`). Setting `nextPairInventory` to `some (Stock.preserve prior (completeQueryWritten (n+1) frame))` embeds every event of `completeQueryWritten` into `birthStock` (`birth_keeps_callback`), while on contextual recognition families (`RecognitionAt H root`) sevenfold `InstallationAt` coface composition installs `InstalledFaces` prior to emission across every cofinal ordinal $k\in\mathbb N$ and finite segment `finite_paid_method_faces`.

**Primitive-by-primitive word replay and cochain differential lockstep (`WordExecution.lean`, `RelationCochain/{Source,Consumer}.lean`, WA42).** On any living source process with `readEnv`, observer environment $\rho_{\mathrm{obs}}(w)(t,x):=\mathrm{observer}(\lambda s.\,\mathrm{readEnv}(s,t,x),w)$ satisfies $(\operatorname{embed}(e)).\operatorname{eval}(\mathrm{env}(w))=e.\operatorname{eval}(\rho_{\mathrm{obs}}(w))$ and $(\lambda t,x.\,\operatorname{binding}(t,x).\operatorname{eval}(\mathrm{env}(w)))=\mathrm{env}(\mathrm{sourceAction}(w))$. Recursing over all nine step constructors defines `embeddedStep` and `embeddedTrace`, which combine with `Trace.substitutedTrace` to produce `forward` and zero-increment pair lift `pairedForward` with exact length $|\mathrm{forward}(w,e)|=\mathrm{remaining}((\operatorname{embed}(e)).\operatorname{subst}(\operatorname{binding}))$ (`forward_charge`).

At frame `count` of the canonical particle–wave Fock sealed runtime `sourceRuntime`, inductive clock alignment `actual_grounded` (starting from the initial $11$-step calibration offset) identifies the active environment with step $11+\mathrm{count}$ of the underlying physical process, yielding `paired_binding_square`: $\operatorname{sourceEnvironment}(\mathrm{pairBinding},\mathrm{actualPairEnv}(c))=\mathrm{actualPairEnv}(c+1)$. Exposure `replayStock` enters both `birthStock` (`native_replay_written`) and the next complete query (`native_replay_next_query`), placing its boundary inside the next prefix history's relation closure as `actualBoundary`. Feeding $\mu_{\mathrm{src}}=\mathrm{sourceRelations}(c)$ through chain morphism $\tau_1$ and invoking `SourceSubstitution.boundary_square` yields:
$$\operatorname{relationMap}\bigl(\tau_1(\mu_{\mathrm{src}})\bigr)=\operatorname{substitution}\bigl(\operatorname{relationMap}(\mu_{\mathrm{src}})\bigr)=\mathrm{actualBoundary}(c).\mathrm{val}=\bigl(d^{0,1}(\mathrm{actualBoundary}(c))\bigr).\mathrm{val},\tag{S.14}$$
delivering coimage differentials and `physicalReadback` at the same selected stop `stop = start + receipt.1`.

<a id="supplement-d-7"></a>
### D.7 Free Constant-Table Relation Correction and Zero-Evaluation Certificate Inversion (WA43)

In `ConstantTransport.lean` and `ConstantInverse.lean`, let $G:=\mathrm{PairValue}(V,s)=V_s\times V_s$. In `ScalarRelationPresentation`, relation indices lie in $\mathrm{RelationIndex}(\mathbb Z,G):=(G\times G)\sqcup(\mathbb Z\times G)$, with boundary $\operatorname{relationMap}:\mathbb Z^{(\mathrm{RelationIndex}(\mathbb Z,G))}\to\mathbb Z^{(G)}$ defined on generators by:
$$\operatorname{relationMap}\bigl([\mathrm{inl}(u,v)]\bigr)=[u]+[v]-[u+v],\qquad \operatorname{relationMap}\bigl([\mathrm{inr}(z,g)]\bigr)=[z\cdot g]-z[g].\tag{S.15}$$
Because $\operatorname{freeEval}:\mathbb Z^{(G)}\to G$ sends $[g]\mapsto g$, both generators map to $0\in G$, so $\operatorname{im}(\operatorname{relationMap})\subseteq\ker(\operatorname{freeEval})$.

1. **Forward free-table transport**: For $(\Gamma,\delta)$, define $\mathbb Z$-linear maps $F(\mathbb Z,G,X;s)\to\mathbb Z^{(G)}$ by $\mathrm{valueMap}_\Gamma([e])=[\llbracket e\rrbracket_\Gamma]$, $\mathrm{effectValueMap}_{\Gamma,\delta}([e])=[D_e(\Gamma,\delta)]$, and $\mathrm{additionCertificate}_{\Gamma,\delta}([e])=[\mathrm{inl}(\llbracket e\rrbracket_\Gamma,D_e(\Gamma,\delta))]$. On $[e]$, $\llbracket e\rrbracket_{\Gamma+\delta}=\llbracket e\rrbracket_\Gamma+D_e(\Gamma,\delta)$ gives:
   $$[\llbracket e\rrbracket_\Gamma]+[D_e(\Gamma,\delta)]-[\llbracket e\rrbracket_{\Gamma+\delta}]=\operatorname{relationMap}\bigl([\mathrm{inl}(\llbracket e\rrbracket_\Gamma,D_e(\Gamma,\delta))]\bigr);\tag{S.16}$$
   extending $\mathbb Z$-linearly and precomposing with coimage recovery $\mathrm{recover}:\mathcal W_{\mathrm{perf}}\to F(\mathbb Z,G,X;s)$ proves $\mathsf{computedAfter}:=\mathsf{before}+\mathsf{effect}-\mathsf{corr}=\mathsf{after}$, matching `originFace.rootRead.source.newConstants` at $\widehat w$ via `F.whole_recovery` and preserving detector pairings (`actual_detector`).

2. **Explicit integer certificate construction and lossless inversion**: For any finite weighted list $L\in\operatorname{List}(G\times\mathbb Z)$ with word $W(L):=\sum_{(g,z)\in L}z[g]\in\mathbb Z^{(G)}$ and group sum $V(L):=\sum_{(g,z)\in L}z\cdot g\in G$, define `coefficientRelations(L)` recursively:
   $$\begin{aligned}
   \mathsf{cert}([\,])&:=-[\mathrm{inr}(0,0)],\\
   \mathsf{cert}\bigl((g,z)::R\bigr)&:=-[\mathrm{inr}(z,g)]+\mathsf{cert}(R)+\bigl[\mathrm{inl}\bigl(z\cdot g,\,V(R)\bigr)\bigr].
   \end{aligned}\tag{S.17}$$
   Induction on $L$ proves $\operatorname{relationMap}(\mathsf{cert}(L))=W(L)-[V(L)]$:
   - Base $L=[\,]$: $W([\,])=0,V([\,])=0$, while $\operatorname{relationMap}(-[\mathrm{inr}(0,0)])=-([0\cdot 0]-0[0])=-[0]=0-[0]$ (explaining why the empty list must retain $-[\mathrm{inr}(0,0)]$ rather than $0$: in the free module $\mathbb Z^{(G)}$, the basis vector $[0]\ne 0$!);
   - Step $(g,z)::R$: Equation (S.15) and the induction hypothesis expand the image to
     $$-\bigl([z\cdot g]-z[g]\bigr)+\bigl(W(R)-[V(R)]\bigr)+\bigl([z\cdot g]+[V(R)]-[z\cdot g+V(R)]\bigr)=\bigl(z[g]+W(R)\bigr)-[z\cdot g+V(R)],$$
     cancelling $[z\cdot g]$ and $[V(R)]$ in $\mathbb Z^{(G)}$ to match $W((g,z)::R)-[V((g,z)::R)]$.

   Enumerating the finite support of $\Delta T=\mathsf{computedAfter}(\widehat w)-\mathsf{before}(\widehat w)$ in standard T1 as $L_{\Delta T}$ (with $\mathsf{cert}$ itself a pure list recursion requiring zero external kernel-preimage assumption) sets $\mathsf{actualCertificate}:=\mathsf{cert}(L_{\Delta T})$ and $v_{\mathrm{paid}}:=\operatorname{freeEval}(\Delta T)$, yielding Equation (90) ($\Delta T-[v_{\mathrm{paid}}]=\operatorname{relationMap}(\mathsf{actualCertificate})$). Eliminating the resulting `ExistsEvidence` witness `actualInverse` proves:
   $$\mathsf{restoredTable}=\mathsf{before}(\widehat w)+[v_{\mathrm{paid}}]+\operatorname{relationMap}(\mathsf{actualCertificate})=\mathsf{before}(\widehat w)+\Delta T=\mathsf{computedAfter}(\widehat w)=\mathsf{newConstants},\tag{S.18}$$
   with $v_{\mathrm{paid}}$ matching both the request's actual paid evaluation (`actual_paid_value`) and inverse-fibre value (`actual_inverse_value`).

<a id="supplement-d-8"></a>
### D.8 Contiguous Step-Interval Anti-Drop/Anti-Dup Batching and Sealed-Prefix Tail Continuation (WA44–WA45)

**Step-interval batch partition and anti-omission/anti-duplication gate (`Origin.lean`, `StepInterval.lean`, `StepInterval/Whole.lean`, `NextReceiptStepJointWhole.lean`, `Gate.lean`, WA44).** Let $E=[e_0,\dots,e_{m-1}]$ with start offset $s_0\in\mathbb N$, item expansion $\mathrm{items}(e)\in\operatorname{List}(\mathrm{Expr}\times\mathbb Z)$, and concatenated batch $R_{\mathrm{batch}}:=\mathrm{requestsFrom}(s_0,E)$.

1. **Backward request origin (`readRequestOrigin`)**: Setting $P_k:=\mathrm{requestsFrom}(s_0,E.\mathrm{take}\,k)$ and $Q_k:=\mathrm{requestsFrom}(s_0+k,(E[k]?).\mathrm{toList})$ gives $P_{k+1}=P_k\mathbin{++}Q_k$ and $P_m=R_{\mathrm{batch}}$. For any $r\in\operatorname{Fin}(|R_{\mathrm{batch}}|)$, `OrderedTracePartition.locatePart` uniquely extracts block $b\in\operatorname{Fin}(m)$ and local index $\ell\in\operatorname{Fin}(|\mathrm{items}(e_b)|)$ satisfying:
   $$r=|P_b|+\ell,\qquad R_{\mathrm{batch}}.\mathrm{take}\,r=P_b\mathbin{++}\bigl((\mathrm{items}(e_b).\mathrm{take}\,\ell).\operatorname{map}(\mathrm{form}_b)\bigr).\tag{S.19}$$
2. **Forward step intervals and two-way address identity (`stepInterval`, `sourceRequestAt_interval_address`)**: Splitting $E=(E.\mathrm{take}\,i)\mathbin{++}[e_i]\mathbin{++}(E.\mathrm{drop}\,(i+1))$ decomposes $R_{\mathrm{batch}}=\mathrm{prior}_i\mathbin{++}\mathrm{own}_i\mathbin{++}\mathrm{later}_i$. Setting $\mathrm{first}_i:=|\mathrm{prior}_i|$ and $\mathrm{count}_i:=|\mathrm{own}_i|=|\mathrm{sourceItems}(w_i)|$ isolates $G_i=\mathrm{own}_i$ with decoded request-word sum equal to $\mathrm{affine}_{\rho_{\mathrm{dec}}}(w_i)$, and cancelling prefix lengths in Equation (S.19) proves $r=\mathrm{first}_{i(r)}+s(r)$.
3. **Whole-batch folding and nonempty-group negative controls**: For every $(\mathcal F,P,\mathcal E)$, event-list induction proves $\operatorname{flatten}([G_0,\dots,G_{m-1}])=R_{\mathrm{batch}}$ (`grouped_requests`, retaining empty $G_i=[\,]$ in place) and `executedTrace_grouped` gives $\operatorname{flatten}(\operatorname{map}(\mathrm{exec},\mathcal G))=\mathrm{exec}(R_{\mathrm{batch}})$ (`grouped_executed_trace`); on the resolvent–price method instance over Section 14.1's conditional right-half-plane input domain (subject to Section 14.1's vacuous-truth boundary), finite-sum linearity in the $\Gamma$-successor space yields $\sum_{i=0}^{m-1}\mathsf{stepCochain}(i)=\partial_{\mathrm{joint}}$ (`actual_grouped_joint_boundary`). Any actual request $r\in\operatorname{Fin}(|R_{\mathrm{batch}}|)$ satisfies $0\le s(r)<\mathrm{count}_{i(r)}=|G_{i(r)}|$, forcing $|\mathrm{own}|=|\mathrm{exec}(G_{i(r)})|>0$; writing $\mathrm{trace}=\mathrm{before}\mathbin{++}\mathrm{own}\mathbin{++}\mathrm{after}$, strict length inequalities $|\mathrm{before}|+|\mathrm{after}|<|\mathrm{trace}|<|\mathrm{before}|+2|\mathrm{own}|+|\mathrm{after}|$ refute both omission ($\mathrm{before}\mathbin{++}\mathrm{after}$) and duplication ($\mathrm{before}\mathbin{++}\mathrm{own}\mathbin{++}\mathrm{own}\mathbin{++}\mathrm{after}$), closing `Gate.lean::actual_nonempty_group_rejects_omission_and_duplication`.

**Sealed-prefix horizon extension and single-pass timeline (`NativeHistoryContinuation.lean`, `StoredHistory.lean`, `StoredTimeline.lean`, WA45).**

1. Inductive type $\mathsf{HistoryAt}(F,s)$ (`exhausted` at $0$, `step activated tail` at $F+1$) satisfies $h=\mathrm{runFrom}(F,s)$ and `storedOccurrenceAt = occurrenceAt` by induction on $F$. `continueFor(h, E)` preserves all $F$ `step` nodes verbatim and runs $\mathrm{runFrom}(E,s_{\mathrm{tail}})$ solely at `exhausted`; casting `continueFor(h, T-F)` along $(T-F)+F=T$ to define $\mathsf{extendTo}(h,T)$ proves:
   $$\bigl(\mathsf{extendTo}(h,T)\bigr).\mathsf{prefix}(F)=\bigl(\mathrm{runFrom}(T,s)\bigr).\mathsf{prefix}(F)=\mathrm{runFrom}(F,s)=h.\tag{S.20}$$
2. For micro-step history $H:\mathsf{SourceNativeLivingRootHistoryAt}(F,s_0)$, `storedPairAt(H, i)` equals $(\mathrm{advance}(i).\mathrm{state},\mathrm{advance}(i+1).\mathrm{state})$ (`stored_pair_actual`). Single-pass collector `collect` uses `Nat.dfoldRev` to push each state once into a capacity-$(F+1)$ array followed by the final state, forming $\mathcal T=\mathrm{storedTimeline}(\mu,H)\in\operatorname{Vector}(A,F+1)$ with $(\mathcal T[i],\mathcal T[i+1])=(\mu(s_i),\mu(s_{i+1}))$ (`stored_timeline_adjacent`), whence applying $\mathcal E$ and `updateInventory` proves Equation (96) ($\mathsf{timelineInventory}(\mathcal T,i)=\mathsf{stageInventory}(\mathrm{advance}(i))$).

---

<a id="supplement-e"></a>
## E Upstream Resolvent-Comb Source Programme Interface for Long Analytic Windows

<a id="supplement-e-1"></a>
### E.1 Closed-Facade Resolvent-Comb Installation and Trace Supply (WA33)

On the conditional right-half-plane nontrivial zero-observation input of Section 14.1, the nontrivial coordinate and right-half-plane fibre supply initial vector $q_0$, single-step resolvent-comb operator $R$, and exact iteration order $m\in\mathbb N$. In the single-variable environment binding $x\mapsto q_0$, recursive syntax $e_0=\operatorname{var}x,e_{k+1}=R(e_k)$ satisfies $\operatorname{ev}(e_k)=R^k q_0$ and $r(e_k)=k+1$ by induction on $k$, so canonical evaluation at $k=m$ outputs target paid state, value $R^m q_0$, and a complete trace of length $m+1$.

Installing this calculation component prior to the emitter on `runtimeEffectAuthoritySource` lets the closed facade `RuntimeEffectFace` extract that exact result at the same occurrence (`runtimeCombCalculationReadoutAt_factorizes`), feeding target state, relation boundary, inverse fibres, and update cochains from that single $(m+1)$-step trace while preserving the lower physical ledger, emitter, and paired-$\Omega$ successor ($m+1$ measures syntactic node budget, while physical single-step transitions retain their own ledger receipts). Completed value $v=R^m q_0$ in turn generates the constant environment increment and residual request $R^m(v)-v$ feeding the window and inverse-residual chain of Section 14.

## References

<a id="ref-1"></a>
[1] Jian Gao. *The State Is Not the History, the Source Is: Identity, Responsibility, and Minimal Revision in Processes*. Version 2, 2026. DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175). Main text and complete proof supplement.
