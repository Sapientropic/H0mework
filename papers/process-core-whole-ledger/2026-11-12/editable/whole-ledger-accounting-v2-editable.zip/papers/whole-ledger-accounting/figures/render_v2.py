#!/usr/bin/env python3
"""Generate the Whole-Ledger Accounting v2 editable SVG plates and PNG previews.

Preserves all v1 plates (`*.svg`/`*.png`) untouched by writing `*-v2.svg`/`*-v2.png`
and `*-v2-en.svg`/`*-v2-en.png`. Uses `shared/figure-style` with 1440 px canvas
width, minimum 24 px body type size, and strict bounding-box / non-overlap assertions.
"""
import argparse
import subprocess
import sys
import tempfile
from html import escape
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH  # noqa: E402
import svg_text  # noqa: E402
from svg_text import line, text_width  # noqa: E402

svg_text.OPS.update('⋆⊔≡⇏∅∀∃∄→←↔↦≠≤≥×√′−∧∂≺∘⊗⊕∈∉')
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'

W = 1440
MIN_SIZE = W / 60  # 24.0 px body floor
SUB_MIN = 18.5     # mathematical sub/superscript floor
LANG = ['zh']
parts, boxes = [], []


def L(zh, en):
    return zh if LANG[0] == 'zh' else en


def start(height, title, description):
    parts.clear()
    boxes.clear()
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
        f'viewBox="0 0 {W} {height}" role="img">'
    )
    parts.extend([f'<title>{escape(title)}</title>', f'<desc>{escape(description)}</desc>'])
    parts.append(
        '<defs>'
        + ''.join(
            f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" '
            f'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>'
            for n, c in [('ink', SLATE), ('acc', VERMILION), ('deep', DEEP)]
        )
        + '</defs>'
    )
    parts.append(f'<rect width="{W}" height="{height}" fill="#FFFFFF"/>')
    return height


def txt(x, y, text, size=25, color=INK, weight=400, anchor='start'):
    assert size >= MIN_SIZE - 1e-9, (text, size)
    width = text_width(text, size, SUB_MIN)
    x0 = x - {'start': 0, 'middle': width / 2, 'end': width}[anchor]
    boxes.append((x0, y - 0.80 * size, x0 + width, y + 0.22 * size, text))
    parts.append(line(x, y, text, size, color, weight, anchor, min_size=SUB_MIN))


def rect(x, y, w, h, fill='none', stroke=HAIR, width=1.6, radius=6, dashed=False):
    dash = ' stroke-dasharray="10 7"' if dashed else ''
    parts.append(
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" '
        f'stroke="{stroke}" stroke-width="{width}"{dash}/>'
    )


def path(d, color=SLATE, width=2.2, marker='ink', dashed=False):
    dash = ' stroke-dasharray="9 6"' if dashed else ''
    end = f' marker-end="url(#arrow-{marker})"' if marker else ''
    parts.append(
        f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{dash}{end}/>'
    )


def arrow(x1, y1, x2, y2, color=SLATE, marker='ink', width=2.2, dashed=False):
    path(f'M {x1} {y1} L {x2} {y2}', color, width, marker, dashed)


def card(x, y, w, h, title, rows, stroke=HAIR, fill='none', gap=35, title_color=INK, dashed=False, badge=None):
    rect(x, y, w, h, fill, stroke, 2.4 if stroke in (VERMILION, DEEP) else 1.6, dashed=dashed)
    txt(x + 20, y + 40, title, 26, title_color, 600)
    if badge:
        txt(x + w - 18, y + 40, badge, 24, DEEP if stroke != VERMILION else VERMILION, 500, 'end')
    for i, row in enumerate(rows):
        txt(x + 20, y + 80 + i * gap, row, 24, SLATE)
    check_count = len(rows) + (2 if badge else 1)
    for (x0, _, x1, _, t) in boxes[-check_count:]:
        assert x1 <= x + w - 12, ('card overflow', LANG[0], t, x1, x + w)


def save(name, height):
    for i, a in enumerate(boxes):
        assert a[0] >= 8 and a[2] <= W - 8 and a[1] >= 4 and a[3] <= height - 4, ('outside canvas', LANG[0], a)
        for b in boxes[i + 1:]:
            if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                raise AssertionError(('text overlap', LANG[0], a[4], b[4]))
    svg = '\n'.join(parts + ['</svg>'])
    stem = f'{name}-v2' if LANG[0] == 'zh' else f'{name}-v2-en'
    svg_path = OUT / f'{stem}.svg'
    png_path = OUT / f'{stem}.png'
    svg_path.write_text(svg, encoding='utf-8')
    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        html_path = tmp_dir / f'{stem}.html'
        pdf_path = tmp_dir / f'{stem}.pdf'
        html_path.write_text(
            '<!doctype html><html><head><style>'
            f'@page{{size:{W}px {height}px;margin:0}}html,body{{margin:0;padding:0}}'
            f'img{{display:block;width:{W}px;height:{height}px}}</style></head>'
            f'<body><img src="{svg_path.as_uri()}"></body></html>',
            encoding='utf-8',
        )
        subprocess.run(
            [
                CHROME, '--headless=new', '--disable-gpu', '--no-pdf-header-footer',
                '--allow-file-access-from-files', f'--print-to-pdf={pdf_path}', html_path.as_uri(),
            ],
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ['pdftoppm', '-png', '-r', '150', '-singlefile', str(pdf_path), str(tmp_dir / stem)],
            check=True,
            capture_output=True,
        )
        png_path.write_bytes((tmp_dir / f'{stem}.png').read_bytes())
    print(f'wrote {svg_path.name} and {png_path.name}')


def plate_whole_inventory():
    h = start(
        850,
        L('全事件库存准入、余项覆盖与容量短缺正阻滞核',
          'Complete Event-Inventory Admission, Remainder Coverages, and Capacity Obstruction'),
        L('上排为全事件双向准入与终账穷尽；中排为三种有限片段覆盖整账；下排为容量短缺正阻滞门禁与源绑定维护扣款。',
          'Top: bijective event-inventory admission and terminal exhaustion. Middle: three remainder coverages. Bottom: capacity-shortage obstruction gate and source-bound maintenance debit.'),
    )
    # Tier I: Complete Event-Inventory Admission (WA1-WA3)
    card(
        24, 26, 548, 196,
        L('具体源完整事件族 {i:S}{sub:*}', 'Concrete Source Inventory {i:S}{sub:*}'),
        [
            L('每态完整事件族 {i:E}{sub:*}({i:x}) 与访问历史', 'Full per-state events {i:E}{sub:*}({i:x}) and visit history'),
            L('原生写入、关系、续接、重定向、终账', 'Writes, relations, transports, redirects, terminals'),
            L('共尾发射、前驱路径与落点一并保留', 'Cofinal emitters, paths, and landings retained'),
        ],
        stroke=DEEP, fill=WASH, badge='WA1-WA3',
    )
    card(
        868, 26, 548, 196,
        L('权威呈现完整事件族 {i:S}', 'Presented Authoritative Source {i:S}'),
        [
            L('正反映射复合恒等 {i:g} ∘ {i:f} = id, {i:f} ∘ {i:g} = id', 'Round-trip identities {i:g} ∘ {i:f} = id, {i:f} ∘ {i:g} = id'),
            L('交换整账写回、有限片段与后继映射', 'Commutes with whole writeback, patch, and next'),
            L('{v:终账穷尽}：本地终账 ⇒ 普通出边族为空', '{v:Terminal exhaustion}: local term ⇒ no out-edges'),
        ],
        stroke=DEEP, badge='Thm 2.3',
    )
    txt(720, 88, L('双向全族同构', 'Bijective round trip'), 24, DEEP, 600, 'middle')
    arrow(584, 108, 856, 108, DEEP, 'deep', 2.4)
    arrow(856, 136, 584, 136, DEEP, 'deep', 2.4)
    txt(720, 178, L('{v:禁删共尾 / 禁私插}', '{v:No trimming / insertion}'), 24, VERMILION, 500, 'middle')

    # Downward connections to Tier II (flanking the centered banner cleanly)
    arrow(252, 224, 252, 276, DEEP, 'deep', 2.2)
    arrow(1188, 224, 1188, 276, DEEP, 'deep', 2.2)
    txt(720, 258, L('单次登记发生编译整账演化 ({i:d}{sub:ε}, {i:o}{sub:ε})',
                    'One occurrence compiles whole-ledger evolution ({i:d}{sub:ε}, {i:o}{sub:ε})'), 24, INK, 600, 'middle')

    # Tier II: Three Exact Remainder Schemes (WA4)
    xs = [24, 504, 984]
    cw = 432
    schemes = [
        (
            L('I. 原位余项覆盖', 'I. In-Place Remainder'),
            [
                L('命中：返回准确生成行与账项等式', 'Hit: exact generated row + equality'),
                L('未命中：同一支承原项恒等携带', 'Miss: identity carry at same support'),
                L('{v:未显式列出 ≠ 责任消失}', '{v:Unlisted row ≠ vanished debt}'),
            ],
            DEEP,
        ),
        (
            L('II. 完整有限覆盖', 'II. Full Finite Cover'),
            [
                L('源账与目标账全映射至有限行号', 'Total index maps on both fibres'),
                L('每行号满射认回被询问的原账项', 'Every index recovers the queried row'),
                L('{v:有限表绝不冒充无限开放纤维}', '{v:Finite list never fakes infinite fibre}'),
            ],
            HAIR,
        ),
        (
            L('III. 运输余项覆盖', 'III. Transported Remainder'),
            [
                L('有限显式例外 + 同源余项事件', 'Finite exceptions + source remainder'),
                L('未命中项统一交由余项事件编译', 'Misses routed to compiled remainder'),
                L('{v:零显式行亦可驱动整账严格付款}', '{v:Zero explicit rows pay whole ledger}'),
            ],
            DEEP,
        ),
    ]
    for x, (title, rows, st) in zip(xs, schemes):
        card(x, 280, cw, 196, title, rows, stroke=st)

    # Divider to Tier III: Capacity Obstruction 4th Kernel (arrows outside centered banner)
    arrow(110, 478, 110, 530, VERMILION, 'acc', 2.4)
    arrow(1330, 478, 1330, 530, DEEP, 'deep', 2.4)
    txt(720, 512, L('生命周期第四核：容量短缺正阻滞与源绑定维护扣款（WA4 / Thm 3.7）',
                    'Fourth Kernel: Capacity-Shortage Obstruction and Source-Bound Debit (WA4 / Thm 3.7)'),
        25, INK, 600, 'middle')

    # Tier III Left: Capacity Obstruction vs Forbidden Discharge
    card(
        24, 536, 680, 284,
        L('容量读数门禁：短缺 ≠ 免责放电', 'Capacity Gate: Shortage ≠ Discharge'),
        [
            L('读数 {i:R}：可用容量 {i:C}{sub:avail} 与需求容量 {i:C}{sub:dem}', 'Readout {i:R}: available {i:C}{sub:avail} vs demanded {i:C}{sub:dem}'),
            L('{v:充要判据}：obstruction? = some {i:w} ↔ {i:C}{sub:avail} < {i:C}{sub:dem}',
              '{v:Criterion}: obstruction? = some {i:w} ↔ {i:C}{sub:avail} < {i:C}{sub:dem}'),
            L('正阻滞证人保留全部已准入义务、依赖与保护边界',
              'Witness retains admitted rows, dependencies & boundaries'),
            L('{v:阻断越权}：{i:C}{sub:avail} < {i:C}{sub:dem} ⇏ 终结回执 / 私自裁支',
              '{v:Blocked leap}: {i:C}{sub:avail} < {i:C}{sub:dem} ⇏ discharge / branch cut'),
            L('充足分支：obstruction? = none ↔ {i:C}{sub:dem} ≤ {i:C}{sub:avail}',
              'Sufficient branch: obstruction? = none ↔ {i:C}{sub:dem} ≤ {i:C}{sub:avail}'),
        ],
        stroke=VERMILION, fill=WASH, badge='Capacity',
    )

    # Tier III Right: Source-Owned Maintenance Debit & Exhaustion Gate
    card(
        736, 536, 680, 284,
        L('源绑定维护扣款与零预算耗尽门禁', 'Source-Bound Maintenance Debit'),
        [
            L('每笔维护扣款由 event_eq 导出 {i:sourceOwnership}', 'Maintenance debit derives {i:sourceOwnership} from event_eq'),
            L('严格锁定具体维持义务、稳定槽位 {i:slot} 与谱系 {i:λ}', 'Locks concrete obligation, stable {i:slot}, and lineage {i:λ}'),
            L('认证扣款运行界：|{i:events}| + {i:B}{sub:target}({i:λ}) ≤ {i:B}{sub:source}({i:λ})',
              'Certified run bound: |{i:events}| + {i:B}{sub:target}({i:λ}) ≤ {i:B}{sub:source}({i:λ})'),
            L('恰好耗尽 |{i:events}| = {i:B}{sub:source}({i:λ}) ⇒ {i:B}{sub:target}({i:λ}) = 0',
              'Exact exhaustion |{i:events}| = {i:B}{sub:source}({i:λ}) ⇒ {i:B}{sub:target}({i:λ}) = 0'),
            L('{v:零预算禁续扣}：{i:B} = 0 ⇒ IsEmpty(DebitEvent {i:g} {i:λ})',
              '{v:Zero-budget gate}: {i:B} = 0 ⇒ IsEmpty(DebitEvent {i:g} {i:λ})'),
        ],
        stroke=DEEP, badge='Debit',
    )
    save('whole-inventory', h)


def plate_target_six():
    h = start(
        560,
        L('定目标 6 的真实修复、严格扣款与双钥匙结清',
          'Actual Factor-Two Repair, Strict Debit, and Two-Key Settlement at Target Six'),
        L('从 (2,4) 内生发出因子 2 修复抵达 (3,3)，预算 1→0 严格扣款，生成独立终回执并进入无同债后继。',
          'Target six emits factor-two repair (2,4) -> (3,3), strictly debits budget 1 -> 0, produces an independent terminal receipt, and enters a debt-inactive successor.'),
    )
    xs = [24, 384, 744, 1104]
    cw = 312
    steps = [
        (
            L('1. 源行动发射', '1. Source Action'),
            [
                L('初态：2 + 4 = 6', 'Start: 2 + 4 = 6'),
                L('4 非素数，最小因子 2', '4 nonprime; factor 2'),
                L('编译发出因子二修复', 'Emits factor-2 repair'),
                L('无调用方预设目标字段', 'No caller target field'),
            ],
            DEEP, WASH,
        ),
        (
            L('2. 严格同债扣款', '2. Strict Debit'),
            [
                L('准确目标：(3, 3)', 'Exact target: (3, 3)'),
                L('行动债 {i:u} → {i:v}', 'Action debt {i:u} → {i:v}'),
                L('{v:预算严格降 1 → 0}', '{v:Strict debit 1 → 0}'),
                L('旧账余项逐项原样保持', 'Prior rows preserved'),
            ],
            VERMILION, '#FFFFFF',
        ),
        (
            L('3. 终回执（钥匙 1）', '3. Terminal Key 1'),
            [
                L('读取 (3, 3) 两侧皆素', 'Reads (3, 3) both prime'),
                L('生成支承终结见证', 'Support discharge proof'),
                L('整账逐项终回执生成', 'Whole-ledger receipt'),
                L('{v:非由“预算=0”自动推得}', '{v:Not from zero budget}'),
            ],
            DEEP, '#FFFFFF',
        ),
        (
            L('4. 无同债（钥匙 2）', '4. Successor Key 2'),
            [
                L('固定终账接续律推进', 'Fixed handoff law steps'),
                L('原算术账继续演化', 'Arithmetic rows continue'),
                L('该行动债分支未激活', 'Action debt inactive'),
                L('{v:同债纤维}：{i:T}({i:x}) = ∅', '{v:Same-debt}: {i:T}({i:x}) = ∅'),
            ],
            DEEP, WASH,
        ),
    ]
    for x, (t, rows, st, fl) in zip(xs, steps):
        card(x, 34, cw, 236, t, rows, stroke=st, fill=fl, gap=36)

    arrow(340, 152, 380, 152, VERMILION, 'acc', 2.5)
    arrow(700, 152, 740, 152, DEEP, 'deep', 2.5)
    arrow(1060, 152, 1100, 152, DEEP, 'deep', 2.5)

    # Blocked shortcut arc beneath step 2 -> step 4
    rect(24, 316, 1392, 212, fill=WASH, stroke=VERMILION, width=2.0, dashed=True)
    txt(56, 360, L('反捷径门禁（WA8 / WA10）：为何“预算归零”不能跳过第 3、4 步？',
                   'Anti-Shortcut Gate (WA8 / WA10): Why Budget = 0 Cannot Skip Steps 3 and 4'),
        26, VERMILION, 600)
    txt(56, 404, L('1) 预算 1 → 0 仅证明付款宏步已发生严格下降，不生成本地忠实终账回执 LocalTerm({i:x})；无局部终账时总闭合律类型恒空。',
                   '1) Budget 1 → 0 proves one strict debit occurred, but constructs no LocalTerm({i:x}); without it the closure law is empty.'),
        24, INK)
    txt(56, 446, L('2) 终局结清 Settle({i:x}) = LocalTerm({i:x}) × IsEmpty({i:T}({i:x})) 必须同时核验第 3 步原终回执与第 4 步实际后继中同债纤维为空。',
                   '2) Final settlement Settle({i:x}) = LocalTerm({i:x}) × IsEmpty({i:T}({i:x})) requires both Key 1 (receipt) and Key 2 (empty {i:T}({i:x})).'),
        24, INK)
    txt(56, 488, L('3) 结清只终结该笔已履行的行动债 {i:u}，原算术世界与其余已登记责任在规范后继中毫发无损地继续运行。',
                   '3) Settlement ends only the fulfilled action debt {i:u}; the arithmetic world and all other registered rows continue intact.'),
        24, SLATE)
    save('target-six', h)


def plate_source_continuation():
    h = start(
        760,
        L('全未来残差内生请求、同债严格扣款与后缀完成闭环',
          'All-Future Residual Request, Strict Same-Debt Debit, and Suffix Completion'),
        L('全未来模型中的语义残差转化为下一原生请求，正语法信用驱动同债严格扣款，后缀完成同时交付效应值、回执、整账去向与规范后继。',
          'The semantic residual in the all-future model generates the next endogenous request, positive syntax credit drives strict same-debt debit, and suffix completion delivers the effect, receipt, whole-ledger destinations, and canonical successor.'),
    )
    xs = [24, 384, 744, 1104]
    cw = 312
    top_cards = [
        (
            L('1. 残差与全未来等价', '1. Residual & Future'),
            [
                L('{i:m} = ({i:Γ}, {i:δ}, {i:a}, ({i:p},{i:τ}), {i:e})', '{i:m} = ({i:Γ}, {i:δ}, {i:a}, ({i:p},{i:τ}), {i:e})'),
                L('{i:r}{sub:m} = {i:a} + (−id)({i:p})', '{i:r}{sub:m} = {i:a} + (−id)({i:p})'),
                L('[{i:r}{sub:m}] − ([{i:a}] − [{i:p}]) ∈ {i:Z}', '[{i:r}{sub:m}] − ([{i:a}] − [{i:p}]) ∈ {i:Z}'),
                L('全允许词 {i:h} 与站位 {i:j} 同类', 'Same class at all {i:h}, {i:j}'),
            ],
            DEEP, WASH,
        ),
        (
            L('2. 内生请求与正信用', '2. Request & Credit'),
            [
                L('运输至规范后继 {i:c}{sub:n}{sup:+}', 'Transported to {i:c}{sub:n}{sup:+}'),
                L('{i:Q}{sub:m} = ({i:Γ}+{i:δ}, {i:r}{sub:m}, {i:e})', '{i:Q}{sub:m} = ({i:Γ}+{i:δ}, {i:r}{sub:m}, {i:e})'),
                L('语法费 {i:Q} = {i:c}({i:a})+{i:c}({i:p})+2', 'Cost {i:Q} = {i:c}({i:a})+{i:c}({i:p})+2 ≥ 2'),
                L('{v:首步后余信用 Q − 1 > 0}', '{v:Credit left Q − 1 > 0}'),
            ],
            DEEP, '#FFFFFF',
        ),
        (
            L('3. 同债严格扣款', '3. Same-Debt Payment'),
            [
                L('正余费排除结算分支', 'Positive cost bars settle'),
                L('必走已付分支生出 {i:π}{sub:b}', 'Forces paid step {i:π}{sub:b}'),
                L('{v:唯一同债目标 · 严格扣减}', '{v:Unique target · strict debit}'),
                L('不补旧债预算（no-refill）', 'No refill on prior lineage'),
            ],
            VERMILION, '#FFFFFF',
        ),
        (
            L('4. 后缀完成与四读口', '4. Suffix Completion'),
            [
                L('续跑 {i:Q} − 1 步至 {i:R}({i:Q})', 'Runs {i:Q} − 1 steps to {i:R}({i:Q})'),
                L('完成值 {i:ε} = {i:D}{sub:a}({i:Γ}, {i:δ})', 'Value {i:ε} = {i:D}{sub:a}({i:Γ}, {i:δ})'),
                L('编译准入动作 {i:G}{sub:b}{sup:end}', 'Compiles action {i:G}{sub:b}{sup:end}'),
                L('交付回答、回执与后继', 'Answer, receipt & next'),
            ],
            DEEP, WASH,
        ),
    ]
    for x, (t, rows, st, fl) in zip(xs, top_cards):
        card(x, 30, cw, 240, t, rows, stroke=st, fill=fl, gap=36)

    arrow(338, 150, 380, 150, DEEP, 'deep', 2.4)
    arrow(698, 150, 740, 150, VERMILION, 'acc', 2.4)
    arrow(1058, 150, 1100, 150, DEEP, 'deep', 2.4)

    # Downward arrows into shared whole-ledger write & negative control
    arrow(540, 272, 368, 338, DEEP, 'deep', 2.2)
    arrow(1260, 272, 560, 338, DEEP, 'deep', 2.2)
    arrow(900, 272, 1060, 338, VERMILION, 'acc', 2.2)

    card(
        24, 344, 688, 256,
        L('同一次整账第一写入 {i:E}{sub:n} 与规范后继（WA38–WA39）',
          'Shared Whole-Ledger Write {i:E}{sub:n} and Successor (WA38–39)'),
        [
            L('旧责任去向：{i:E}{sub:n}.destination(oldEntry({i:e}{sub:n}))',
              'Prior row: {i:E}{sub:n}.destination(oldEntry({i:e}{sub:n}))'),
            L('出生责任去向：{i:E}{sub:n}.destination(debtEntry({i:m}{sub:n}))',
              'Born row: {i:E}{sub:n}.destination(debtEntry({i:m}{sub:n}))'),
            L('付款演化异质等同：{i:π}{sub:b}.step.evolution ≃ {i:E}{sub:b}.destination({i:e}{sub:b})',
              'Payment matches {i:E}{sub:b}.destination({i:e}{sub:b})'),
            L('全部旧事件与本次执行迹保序注入出生库存 {i:H}{sub:B}',
              'Prior events and paid traces inject in order into {i:H}{sub:B}'),
            L('下一停点 {i:P}{sub:n+1} 直接读取已更新环境与完整库存',
              'Next stop {i:P}{sub:n+1} reads updated environment and full stock'),
        ],
        stroke=DEEP, gap=36,
    )

    card(
        744, 344, 672, 256,
        L('配对负控：零效应仍须付账，新债禁替旧债续杯',
          'Controls: Zero Effect Pays; No Cross-Debt Refill'),
        [
            L('常量 {i:a} = const {i:v}, {i:p} = const {i:v} ⇒ 数值效应 {i:ε} = 0',
              'Take {i:a} = const {i:v}, {i:p} = const {i:v} ⇒ numerical effect {i:ε} = 0'),
            L('{v:语法费仍为 c(r) = 2}：首步负号 2→1，次步加法付 1→0',
              '{v:Syntax cost c(r) = 2}: negation 2→1, addition pays 1→0'),
            L('零数值效应绝不抹除两次语法发生、执行迹位置或谱系',
              'Zero effect erases neither syntax steps nor debt lineage'),
            L('同发生新生请求归入和类型右支 inr，旧债居左支 inl',
              'Fresh request enters sum tag inr; prior debt stays in inl'),
            L('{v:和类型互斥}：新债正预算绝不回填旧债零预算行',
              '{v:Disjoint sum tags}: fresh budget never refills prior row'),
        ],
        stroke=VERMILION, fill=WASH, gap=36,
    )

    rect(24, 632, 1392, 96, fill='#FFFFFF', stroke=HAIR, width=1.6)
    txt(720, 672, L('核心不变量：每个下一请求均由源编译器在准确当前态内生生成，全程零商类代表元挑选、零外部调度干预',
                   'Invariant: Every next request is generated endogenously at the exact current — zero representative choice'),
        24, INK, 600, 'middle')
    txt(720, 708, L('数值完成值 {i:ε} · 带原回执动作回答 · 双行整账去向 · 规范后继 四读口同源相容且类型严格区分',
                   'Value {i:ε}, receipted answer, prior/born row destinations, and canonical next share one event'),
        24, SLATE, 400, 'middle')
    save('source-continuation', h)


def plate_debt_settlement():
    h = start(
        760,
        L('无总闭合律付款宏步良基性与双钥匙终局结清定理',
          'Law-Free Paid Macro-Step Well-Foundedness and Two-Key Final Settlement'),
        L('上排展示夹逼一次严格付款的宏步下降链；左下为无总律良基性与平转反证；右下为总发射律驱动的双钥匙有限结清。',
          'Top: macro-step chain enclosing one strict payment. Bottom left: law-free well-foundedness and equal-budget refutation. Bottom right: total emission law and two-key settlement.'),
    )
    # Top chain: x ~>* u ->pay u' ~>* y
    xs = [24, 384, 744, 1104]
    cw = 312
    nodes = [
        (L('起点当前项 {i:x}', 'Start Current {i:x}'),
         [L('同债项 {i:x} ∈ {i:X}{sub:a}', 'Same-debt {i:x} ∈ {i:X}{sub:a}'),
          L('预算 {i:B}({i:x}) ∈ N', 'Budget {i:B}({i:x}) ∈ N'),
          L('锁谱系 {i:λ} 与主张 {i:c}', 'Locks {i:λ} and claim {i:c}')], DEEP, '#FFFFFF'),
        (L('前史终点 {i:u}', 'Pre-History End {i:u}'),
         [L('有限前史 {i:x} →* {i:u}', 'Pre-history {i:x} →* {i:u}'),
          L('携带/改名/接受转移', 'Carry, rechart, transfer'),
          L('非增：{i:B}({i:u}) ≤ {i:B}({i:x})', 'Bound: {i:B}({i:u}) ≤ {i:B}({i:x})')], HAIR, '#FFFFFF'),
        (L('严格付款后 {i:u}′', 'Post-Payment {i:u}′'),
         [L('单步严格付款 pay', 'One strict payment pay'),
          L('后继同债目标唯一', 'Unique same-debt target'),
          L('{v:严格降 B(u′) < B(u)}', '{v:Strict debit B(u′) < B(u)}')], VERMILION, WASH),
        (L('宏步终点 {i:y}', 'Macro Target {i:y}'),
         [L('有限后史 {i:u}′ →* {i:y}', 'Post-history {i:u}′ →* {i:y}'),
          L('非增：{i:B}({i:y}) ≤ {i:B}({i:u}′)', 'Bound: {i:B}({i:y}) ≤ {i:B}({i:u}′)'),
          L('{v:合成得 B(y) < B(x)}', '{v:Yields B(y) < B(x)}')], DEEP, '#FFFFFF'),
    ]
    for x, (t, rows, st, fl) in zip(xs, nodes):
        card(x, 30, cw, 204, t, rows, stroke=st, fill=fl, gap=35)

    txt(360, 108, '≤', 26, SLATE, 600, 'middle')
    arrow(340, 130, 380, 130, SLATE, 'ink', 2.2)
    txt(720, 108, '<', 26, VERMILION, 700, 'middle')
    arrow(700, 130, 740, 130, VERMILION, 'acc', 2.8)
    txt(1080, 108, '≤', 26, SLATE, 600, 'middle')
    arrow(1060, 130, 1100, 130, SLATE, 'ink', 2.2)

    # Bottom Left: Law-Free Well-Foundedness (Thm 10.3 & Refutation 10.4)
    arrow(360, 238, 360, 294, DEEP, 'deep', 2.3)
    card(
        24, 300, 680, 424,
        L('第一层：无总闭合律良基性（主定理 10.3）',
          '1. Law-Free Well-Foundedness (Main Thm 10.3)'),
        [
            L('拉回子关系：{i:y} ≺{sub:a} {i:x} ⇒ {i:B}({i:y}) < {i:B}({i:x}) ∈ (N, <)',
              'Subrelation: {i:y} ≺{sub:a} {i:x} ⇒ {i:B}({i:y}) < {i:B}({i:x}) ∈ (N, <)'),
            L('无需输入任何全局终止律、预给终态或未来神谕表',
              'Needs zero total closure law, endpoint, or future oracle'),
            L('反自返律：¬({i:x} ≺{sub:a} {i:x})（付过一次绝不回原债态）',
              'Irreflexive: ¬({i:x} ≺{sub:a} {i:x}) (paid debt never loops)'),
            L('{v:平转反证 10.4}：等额微步 {i:B}({i:u}′) = {i:B}({i:u}) 绝非付款',
              '{v:Refutation 10.4}: equal step {i:B}({i:u}′) = {i:B}({i:u}) is not payment'),
            L('前后包裹任意改名或换承担者，0 ≤ 0 永不生出严格下降',
              'Finite carries around 0 ≤ 0 never create strict descent'),
            L('零预算封顶：{i:B}({i:x}) = 0 ⇒ PaidMacro({i:x}) 类型恒空',
              'Zero-budget ceiling: {i:B}({i:x}) = 0 ⇒ PaidMacro({i:x}) = ∅'),
        ],
        stroke=DEEP, gap=54, badge='WA7',
    )

    # Bottom Right: Total Emission Law & Two-Key Settlement (Thm 11.4, Cor 11.5, Counterex 11.6)
    arrow(1080, 238, 1080, 294, VERMILION, 'acc', 2.3)
    card(
        736, 300, 680, 424,
        L('第二层：双钥匙终局结清（主定理 11.4）',
          '2. Two-Key Final Settlement (Main Thm 11.4)'),
        [
            L('总发射律 emit({i:x}) : Settle({i:x}) ⊔ PaidMacro({i:x})',
              'Total law emit({i:x}) : Settle({i:x}) ⊔ PaidMacro({i:x})'),
            L('沿 ≺{sub:a} 良基递归生成有限历史 {i:H}({i:x})，集齐{v:两把钥匙}：',
              'Well-founded recursion builds {i:H}({i:x}) with {v:both keys}:'),
            L('  钥匙 1 LocalTerm({i:x})：编译器忠实终账与逐项终回执',
              '  Key 1 LocalTerm({i:x}): faithful terminal & row receipt'),
            L('  钥匙 2 IsEmpty({i:T}({i:x}))：实际后继 {i:σ}{sub:P}({i:s}) 无同债项',
              '  Key 2 IsEmpty({i:T}({i:x})): no same debt in {i:σ}{sub:P}({i:s})'),
            L('{v:流体介质反例 11.6}：{i:B}({i:x}) = 0 且 LocalTerm({i:x}) = ∅ 时',
              '{v:Counterexample 11.6}: when {i:B}({i:x}) = 0 & LocalTerm = ∅'),
            L('PaidMacro、Settle 与总闭合律同时为空（归零≠结清）',
              'PaidMacro, Settle, and closure law are all provably empty'),
        ],
        stroke=VERMILION, fill=WASH, gap=54, badge='WA8',
    )
    save('debt-settlement', h)


def plate_observation_separation():
    h = start(
        620,
        L('全局整算术边界类的有限复观察全盲反例',
          'Total Blindness of Finite Complexified Observations to a Global Integral Class'),
        L('同一全局相容整数余核中的非零类 z 与零类 0 在全部有限阶复观察下恒同为零，但在第一阶段整数消费者下严格分离。',
          'In the global compatible integer cokernel G, nonzero class z and 0 have identical zero images under all finite-stage complexified observations F, yet separate at stage-one integer readout J.'),
    )
    # Left box: Global Integer Cokernel G
    card(
        24, 130, 404, 290,
        L('全局相容整数余核 {i:G}', 'Global Integer Cokernel {i:G}'),
        [
            L('{i:G} ⊆ ∏{sub:n} {i:C}{sub:n}, {i:ρ}{sub:n}({i:g}{sub:n+1}) = {i:g}{sub:n}',
              '{i:G} ⊆ ∏{sub:n} {i:C}{sub:n}, {i:ρ}{sub:n}({i:g}{sub:n+1}) = {i:g}{sub:n}'),
            L('{i:C}{sub:n} = {i:M}{sub:n} / im({i:I} − {i:E}{sub:n})',
              '{i:C}{sub:n} = {i:M}{sub:n} / im({i:I} − {i:E}{sub:n})'),
            L('{v:单位回执生出 z = (z}{isub:n}{v:) ≠ 0}',
              '{v:Unit receipt yields z = (z}{isub:n}{v:) ≠ 0}'),
            L('对照基准：零类 0 = (0){sub:n} ∈ {i:G}',
              'Baseline: zero class 0 = (0){sub:n} ∈ {i:G}'),
            L('所有后继保持 {i:z}{sub:k+1} ≠ 0',
              'Every stage keeps {i:z}{sub:k+1} ≠ 0'),
        ],
        stroke=DEEP, fill=WASH, gap=42,
    )

    # Top Right box: All finite complexified observations F
    card(
        544, 32, 872, 210,
        L('上路：全部有限阶段复数化观察族 {i:F}（引理 13.2）',
          'Upper Path: All Finite Complexified Observations {i:F} (Lemma 13.2)'),
        [
            L('素数—对偶块余因子给出 {i:D}{sub:n} = ∏{sub:p} (1 − {i:p}){sup:2} ≠ 0 且 {i:D}{sub:n}{i:z}{sub:n} = 0',
              'Block cofactor gives {i:D}{sub:n} = ∏{sub:p} (1 − {i:p}){sup:2} ≠ 0 with {i:D}{sub:n}{i:z}{sub:n} = 0'),
            L('在 C ⊗{sub:Z} {i:C}{sub:n} 中乘 {i:D}{sub:n}{sup:−1} 消去：∀{i:n}, 1 ⊗ {i:z}{sub:n} = {i:D}{sub:n}{sup:−1}({i:D}{sub:n} ⊗ {i:z}{sub:n}) = 0',
              'In C ⊗{sub:Z} {i:C}{sub:n}, scaling by {i:D}{sub:n}{sup:−1} yields ∀{i:n}, 1 ⊗ {i:z}{sub:n} = 0'),
            L('{v:整族坍缩}：{i:F}({i:z}) = (0, 0, …) = {i:F}(0)（观察商 {i:G}/ker {i:F} 中 [{i:z}] = [0]）',
              '{v:Total collapse}: {i:F}({i:z}) = (0, 0, ...) = {i:F}(0) ([{i:z}] = [0] in {i:G}/ker {i:F})'),
        ],
        stroke=HAIR, gap=40,
    )

    # Bottom Right box: Stage-1 Integer Consumer J
    card(
        544, 336, 872, 248,
        L('下路：第一阶段原整数读出 {i:J} = {i:π}{sub:1}（定理 13.1、13.3）',
          'Lower Path: Stage-One Integer Readout {i:J} = {i:π}{sub:1} (Thms 13.1, 13.3)'),
        [
            L('第一阶段单位推进生出 {i:p} = 3 因子行：{i:ℓ}{sub:r}({i:β}{sub:1}) = 1, {i:ℓ}{sub:r}(({i:I}−{i:E}{sub:1}){i:v}) = −2{i:ℓ}{sub:r}({i:v})',
              'Stage-1 unit step creates {i:p} = 3 row: {i:ℓ}{sub:r}({i:β}{sub:1}) = 1, {i:ℓ}{sub:r}(({i:I}−{i:E}{sub:1}){i:v}) = −2{i:ℓ}{sub:r}({i:v})'),
            L('整数奇偶性 1 ≠ −2{i:k} 锁死 {i:J}({i:z}) = {i:z}{sub:1} ≠ 0 = {i:J}(0)，故 ker {i:F} ⊈ ker {i:J}',
              'Integer parity 1 ≠ −2{i:k} forces {i:J}({i:z}) = {i:z}{sub:1} ≠ 0 = {i:J}(0), so ker {i:F} ⊈ ker {i:J}'),
            L('{v:不可能定理}：∄ 任何（线性或非线性）函数 {i:h} 使 ∀{i:g} ∈ {i:G}, {i:J}({i:g}) = {i:h}({i:F}({i:g}))',
              '{v:Impossibility}: ∄ function {i:h} (linear or nonlinear) with {i:J} = {i:h} ∘ {i:F} on {i:G}'),
            L('观察安全边界：仅看标量/复行列式投影的系统在结构上对整挠类责任全盲',
              'Safety boundary: scalar/complex determinant audits are blind to integral torsion'),
        ],
        stroke=VERMILION, fill=WASH, gap=40,
    )

    # Arrows from G to F and J, plus blocked vertical recovery h
    path('M 432 220 L 538 136', SLATE, 2.4, 'ink')
    txt(478, 154, '{i:F}', 26, SLATE, 600, 'middle')
    path('M 432 330 L 538 440', VERMILION, 2.6, 'acc')
    txt(478, 412, '{i:J}', 26, VERMILION, 700, 'middle')

    # Vertical blocked arrow from F down to J
    arrow(830, 246, 830, 330, VERMILION, 'acc', 2.6, dashed=True)
    txt(850, 298, L('∄ 恢复函数 {i:h} 使 {i:J} = {i:h} ∘ {i:F}（含非线性）',
                    '∄ decoder {i:h} with {i:J} = {i:h} ∘ {i:F} (even nonlinear)'), 24, VERMILION, 600, 'start')
    save('observation-separation', h)


def plate_certificate_batch_continuation():
    h = start(
        820,
        L('已付方法续行、零求值关系证书反演与按步成批防漏重续账',
          'Paid-Method Continuation, Zero-Evaluation Certificate Inversion, and Batch Continuation'),
        L('左列展示双负号恢复已付语法树与逐原语回放驱动余链微分；中列展示零求值常量表的显式关系证书反演；右列展示按步区间归账排斥漏重与封存前缀末态续账。',
          'Left: double-negation paid-AST recovery and primitive replay driving cochain differentials. Middle: explicit relation-certificate inversion of free constant tables even at zero evaluation. Right: step-interval batch anti-omission/anti-duplication and prefix-preserving tail continuation.'),
    )
    # Three columns for WA41-42, WA43, WA44-45
    cw = 436
    xs = [32, 502, 972]

    card(
        xs[0], 30, cw, 590,
        L('I. 已付方法与回放', 'I. Paid Method & Replay'),
        [
            L('双负号提取恢复已付 AST（WA41）：', 'Double-negation paid AST (WA41):'),
            L('  retainedCode(({i:e}{sub:0}+(−{i:p}))+_) = −(−{i:p})', '  retainedCode(({i:e}{sub:0}+(−{i:p}))+_) = −(−{i:p})'),
            L('零增量求值精确读回原已付值 {i:v}{sub:paid}', 'Zero-increment eval recovers {i:v}{sub:paid}'),
            L('跨共尾持续作用：({i:f}{sup:(n+1)}({i:v}{sub:paid}), 0)', 'Applies across stops: ({i:f}{sup:(n+1)}({i:v}{sub:paid}), 0)'),
            L('完整查询迹经回调写入出生库存', 'Full query trace enters born stock'),
            L('安装代数/组合/拓扑/逻辑统一四面', 'Installs unified 4-faces + dual'),
            L('整词逐原语步进回放（WA42）：', 'Primitive word replay (WA42):'),
            L('  embeddedStep / pairedForward', '  embeddedStep / pairedForward'),
            L('每步转化为库存整系数关系词 {i:μ}', 'Each step yields integral relation {i:μ}'),
            L('同步驱动链态射 {i:τ}{sub:1} 与微分 {i:d}{sup:0,1}', 'Drives {i:τ}{sub:1}, boundary, and {i:d}{sup:0,1}'),
            L('{v:禁拿端点同值冒充回放迹相等}', '{v:Endpoint eq never fakes trace eq}'),
            L('同停点物理读回与整账后继共消费', 'Same-stop physicalReadback + next'),
        ],
        stroke=DEEP, gap=41, badge='WA41-42',
    )

    card(
        xs[1], 30, cw, 590,
        L('II. 零求值证书反演', 'II. Certificate Inverse'),
        [
            L('自由常量表 Z{sup:(G)} 恒等式（WA43）：', 'Free constant table Z{sup:(G)} (WA43):'),
            L('  after = before + effect − corr', '  after = before + effect − corr'),
            L('corr = relMap(addCert({i:Γ}, {i:δ}))', 'corr = relMap(addCert({i:Γ}, {i:δ}))'),
            L('虽有 freeEval(corr) = 0（数值抵消）', 'Even though freeEval(corr) = 0,'),
            L('{v:自由模分录绝不因相消而抹除}', '{v:free entries never vanish by cancel}'),
            L('显式整数关系证书构造反演：', 'Explicit integer certificate inverse:'),
            L('  Δ{i:T} = computedAfter − before', '  Δ{i:T} = computedAfter − before'),
            L('  Δ{i:T} − [{i:v}{sub:paid}] = relMap(actualCert)', '  Δ{i:T} − [{i:v}{sub:paid}] = relMap(actualCert)'),
            L('空表仍保零原子 −[inr(0, 0)]', 'Empty list keeps zero atom −[inr(0,0)]'),
            L('ExistsEvidence 消元无损恢复：', 'ExistsEvidence reconstructs:'),
            L('  restoredTable = newConstants', '  restoredTable = newConstants'),
            L('{v:平账为零仍有完整可反演凭据}', '{v:Zero sum retains invertible proof}'),
        ],
        stroke=VERMILION, fill=WASH, gap=41, badge='WA43',
    )

    card(
        xs[2], 30, cw, 590,
        L('III. 成批门禁与续账', 'III. Batch & Tail Extend'),
        [
            L('按执行步区间成批归账（WA44）：', 'Step-interval batching (WA44):'),
            L('  stepInterval({i:i}) = [{i:first}, {i:first}+{i:count})', '  stepInterval({i:i}) = [{i:first}, {i:first}+{i:count})'),
            L('双向地址：{i:r} = {i:first} + supportIndex', 'Address: {i:r} = {i:first} + supportIndex'),
            L('拼接还原整批请求、执行迹与 {i:∂}{sub:joint}', 'Flattens to batch, trace, and {i:∂}{sub:joint}'),
            L('{v:防漏重门禁}（|{i:own}| > 0 非空组）：', '{v:Anti-omission/dup gate} (|{i:own}| > 0):'),
            L('  trace ≠ before ++ after（禁漏记）', '  trace ≠ before ++ after (no drop)'),
            L('  trace ≠ before++own++own++after', '  trace ≠ before++own++own++after'),
            L('封存前缀末态增量续账（WA45）：', 'Prefix-preserving extend (WA45):'),
            L('  (extendTo {i:h} {i:T}).prefix {i:F} = {i:h}', '  (extendTo {i:h} {i:T}).prefix {i:F} = {i:h}'),
            L('旧激活零重算，仅从末态跑 {i:T} − {i:F} 步', 'Runs only {i:T} − {i:F} suffix from tail'),
            L('单遍投影表相邻格导出增量库存', 'Adjacent cells yield stage inventory'),
            L('{v:首步绑定格严格不等} {i:T}[0] ≠ {i:T}[1]', '{v:Distinct bind cells} {i:T}[0] ≠ {i:T}[1]'),
        ],
        stroke=DEEP, gap=41, badge='WA44-45',
    )

    arrow(470, 325, 498, 325, VERMILION, 'acc', 2.4)
    arrow(940, 325, 968, 325, DEEP, 'deep', 2.4)

    # Bottom synthesis bar
    rect(32, 650, 1376, 138, fill=WASH, stroke=DEEP, width=2.0)
    txt(56, 692, L('第五支柱闭环（WA41–WA45）：从单步残差付款升级为跨周期可逆审计总账',
                   'Fifth Pillar Synthesis (WA41-WA45): From Single-Step Residual Payment to Reversible Multi-Epoch Ledger'),
        26, DEEP, 600)
    txt(56, 734, L('方法查询有回调出处（WA41）→ 逐步回放驱动余链微分（WA42）→ 零求值分录凭整数证书精确反演（WA43）',
                   'Callback-grounded method query (WA41) → primitive replay cochain d (WA42) → zero-eval certificate inversion (WA43)'),
        24, INK)
    txt(56, 770, L('→ 下一批请求按原执行步严格切片防漏防重（WA44）→ 封存历史锁死前缀、仅在真实末态增量续账（WA45）。',
                   '→ step-sliced batch anti-drop/anti-dup gate (WA44) → sealed prefix locked with tail-only incremental continuation (WA45).'),
        24, INK)
    save('certificate-batch-continuation', h)


def render_all():
    plate_whole_inventory()
    plate_target_six()
    plate_source_continuation()
    plate_debt_settlement()
    plate_observation_separation()
    plate_certificate_batch_continuation()


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--english', action='store_true', help='Render English v2 plates (*-v2-en.svg/.png)')
    args = ap.parse_args()
    LANG[0] = 'en' if args.english else 'zh'
    render_all()
