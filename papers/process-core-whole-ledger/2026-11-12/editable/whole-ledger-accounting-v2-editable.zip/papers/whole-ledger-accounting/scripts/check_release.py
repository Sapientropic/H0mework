#!/usr/bin/env python3
"""Check the Whole-Ledger Accounting paper's v2 written locations, source bindings,
bilingual math/anchor parity, punctuation hygiene, and frozen v1 artifact bytes.

Run from the publish root. Defaults to v2 (`release-selection-v2.json`); pass
`--selection papers/whole-ledger-accounting/release-selection.json` to inspect
frozen v1 claim records. Fixed research sources are read with `git show` from
Homework and H0mework; nothing is built or mutated in either repository.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
PAIRS = [
    ('manuscript', PAPER / 'manuscript.md', PAPER / 'manuscript-en.md'),
    ('supplement', PAPER / 'supplement.md', PAPER / 'supplement-en.md'),
]
MATH = re.compile(r'\$\$.*?\$\$|(?<![\\$])\$(?!\$).*?(?<![\\$])\$', re.S)
META = re.compile(
    r'写作时|本轮|提示词|子代理|工作窗口|新窗口|本次完整回读|重新说成有待|'
    r'\bagent\b|\bprompt\b|this draft|not rebuilt',
    re.I,
)
FULLWIDTH_EN = re.compile(r'[｜：；，。（）　《》【】]')
DECL = r'\b(?:theorem|def|lemma|abbrev|structure|inductive|instance|class)\s+(?:[\w.]*\.)?{}\b'
ENV_ZH = re.compile(r'(?m)^\*\*(主定理|定理|命题|引理|推论|定义|例)\s+(\d+(?:\.\d+|[A-Z]\.\d+)|[A-Z]\.\d+)')
ENV_EN = re.compile(r'(?m)^\*\*(Main Theorem|Theorem|Proposition|Lemma|Corollary|Definition|Example)\s+(\d+(?:\.\d+|[A-Z]\.\d+)|[A-Z]\.\d+)')
PROSE_PROTECT = re.compile(
    r'<!--.*?-->|`[^`]+`|\$\$.*?\$\$|(?<![\\$])\$(?!\$).*?(?<![\\$])\$|\(https?://[^)]+\)',
    re.S,
)
FROZEN_GIT_RECORDS = (
    'papers/whole-ledger-accounting/release-selection.json',
    'papers/whole-ledger-accounting/zenodo-metadata.json',
    'papers/whole-ledger-accounting/zenodo-metadata.md',
    'papers/whole-ledger-accounting/release-artifacts.json',
    'papers/whole-ledger-accounting/source-evidence.json',
    'papers/whole-ledger-accounting/source-evidence-20261013.json',
    'papers/whole-ledger-accounting/release-validation.json',
    'papers/whole-ledger-accounting/release-validation-20261017.json',
    'shared/verification-20261013-topic-sources.json',
    'shared/verification-20261013-framework-topic-sources.json',
    'shared/verification-20261029-framework-topic-sources.json',
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def anchor_list(text: str) -> list[str]:
    return re.findall(r'<a id="([^"]+)"></a>', text)


def prose_body(text: str) -> str:
    """Prose between the first section/appendix heading and code-availability/references."""
    m = re.search(r'(?m)^## (?:1\b|A\b)', text)
    start = m.start() if m else 0
    end = text.index('<!-- code-availability:begin -->') if '<!-- code-availability:begin -->' in text else len(text)
    return text[start:end]


def check_prose_ascii_dashes(text: str) -> list[int]:
    bad_lines = []
    for idx, line in enumerate(text.splitlines(), 1):
        if re.fullmatch(r'---[ \t]*', line) or re.fullmatch(r'\|(?:[ \t]*-+[ \t]*\|)+[ \t]*', line):
            continue
        cleaned = re.sub(r'<[^>]+>', '', PROSE_PROTECT.sub('', line))
        if '--' in cleaned or '"' in cleaned or re.search(r'\\["\'^~]', cleaned):
            bad_lines.append(idx)
    return bad_lines


def check_list_blank_lines(text: str) -> list[int]:
    bad_lines = []
    lines = text.splitlines()
    in_code = False
    in_math = False
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith('```'):
            in_code = not in_code
            continue
        if stripped == '$$':
            in_math = not in_math
            continue
        if not in_code and not in_math and idx > 1 and re.match(r'^(\s*[-*+] |\s*\d+\. )', line):
            prev = lines[idx - 2]
            if prev.strip() != '' and not re.match(r'^(\s*[-*+] |\s*\d+\. |\s{2,})', prev):
                bad_lines.append(idx)
    return bad_lines


def make_blob_reader():
    cache: dict[tuple[str, str, str], bytes] = {}

    def get_blob(repo: Path, commit: str, path: str) -> bytes:
        key = (str(repo), commit, path)
        if key not in cache:
            cache[key] = subprocess.run(
                ['git', '-C', str(repo), 'show', f'{commit}:{path}'],
                check=True,
                capture_output=True,
            ).stdout
        return cache[key]

    return get_blob


def check(homework: Path, h0: Path, selection_path: Path) -> dict:
    errors: list[str] = []
    report: dict = {'paper': 'whole-ledger-accounting', 'selection': selection_path.name}
    get_blob = make_blob_reader()

    # 1. Bilingual parity & hygiene across manuscript and supplement pairs
    bilingual_summary = {}
    anchor_Lookup: dict[str, set[str]] = {}
    for kind, zh_path, en_path in PAIRS:
        texts = {'zh': zh_path.read_text(), 'en': en_path.read_text()}
        anchor_Lookup[zh_path.name] = set(anchor_list(texts['zh']))
        anchor_Lookup[en_path.name] = set(anchor_list(texts['en']))
        pair_info: dict = {}

        zh_anchors = anchor_list(texts['zh'])
        en_anchors = anchor_list(texts['en'])
        pair_info['anchors'] = len(zh_anchors)
        if zh_anchors != en_anchors:
            errors.append(f'{kind}: ordered anchors differ between zh ({len(zh_anchors)}) and en ({len(en_anchors)})')

        zh_tags = re.findall(r'\\tag\{([^}]+)\}', texts['zh'])
        en_tags = re.findall(r'\\tag\{([^}]+)\}', texts['en'])
        pair_info['equation_tags'] = len(zh_tags)
        if zh_tags != en_tags:
            errors.append(f'{kind}: ordered equation tags differ between zh and en')
        expected_tags = (
            [str(i) for i in range(1, len(zh_tags) + 1)]
            if kind == 'manuscript'
            else [f'S.{i}' for i in range(1, len(zh_tags) + 1)]
        )
        if zh_tags != expected_tags:
            errors.append(f'{kind}: equation tags not strictly consecutive ({zh_tags[:5]}.. vs {expected_tags[:5]}..)')

        zh_disp = len(re.findall(r'\$\$', texts['zh']))
        en_disp = len(re.findall(r'\$\$', texts['en']))
        pair_info['display_delimiters'] = {'zh': zh_disp, 'en': en_disp}
        if zh_disp % 2 != 0 or en_disp % 2 != 0 or zh_disp != en_disp:
            errors.append(f'{kind}: display $$ delimiters mismatch: zh={zh_disp}, en={en_disp}')

        zh_envs = [m.group(2) for m in ENV_ZH.finditer(texts['zh'])]
        en_envs = [m.group(2) for m in ENV_EN.finditer(texts['en'])]
        pair_info['numbered_environments'] = len(zh_envs)
        if zh_envs != en_envs:
            errors.append(f'{kind}: environment numbering differs: zh={zh_envs} vs en={en_envs}')

        zh_figs = re.findall(r'\]\((figures/[^)]+?)\.svg\)', texts['zh'])
        en_figs = [s.removesuffix('-en') for s in re.findall(r'\]\((figures/[^)]+?)\.svg\)', texts['en'])]
        pair_info['figures'] = len(zh_figs)
        if zh_figs != en_figs:
            errors.append(f'{kind}: figure sequence differs: zh={zh_figs} vs en={en_figs}')

        for lang, path_obj in [('zh', zh_path), ('en', en_path)]:
            t = texts[lang]
            fname = path_obj.name
            alist = anchor_list(t)
            if len(alist) != len(set(alist)):
                errors.append(f'{fname}: duplicate HTML anchor detected')
            aset = set(alist)
            for target in re.findall(r'\]\(#([^)]+)\)', t):
                if target not in aset:
                    errors.append(f'{fname}: broken internal anchor #{target}')
            for fig in re.findall(r'!\[[^\]]*\]\(([^)]+)\)', t):
                if not (PAPER / fig).exists():
                    errors.append(f'{fname}: missing figure {fig}')
                if (lang == 'en') != fig.endswith('-v2-en.svg'):
                    errors.append(f'{fname}: non-v2 or wrong-language figure {fig}')
                if lang == 'zh' and not fig.endswith('-v2.svg'):
                    errors.append(f'{fname}: expected -v2.svg figure, got {fig}')
            cited = set(re.findall(r'#ref-(\d+)', t))
            listed = set(re.findall(r'<a id="ref-(\d+)"></a>', t))
            if cited != listed:
                errors.append(f'{fname}: cited refs {sorted(cited)} != listed refs {sorted(listed)}')
            if re.search(r'\[@', t):
                errors.append(f'{fname}: unresolved [@...] citation key')
            cjk_in_math = [s for s in MATH.findall(t) if re.search(r'[\u4e00-\u9fff]', s)]
            if cjk_in_math:
                errors.append(f'{fname}: CJK characters inside math ({len(cjk_in_math)} spans)')
            for m in re.finditer(r'`([^`]+)`', t):
                bad = sorted({c for c in m.group(1) if ord(c) > 127})
                if bad:
                    errors.append(f'{fname}: non-ASCII inline code {m.group(0)!r}: {bad}')
            for m in META.finditer(prose_body(t)):
                errors.append(f'{fname}: editorial meta-narrative wording "{m.group(0)}"')
            list_bad = check_list_blank_lines(t)
            if list_bad:
                errors.append(f'{fname}: list missing preceding blank line on lines {list_bad[:10]}')

        en_non_byline = '\n'.join(l for l in texts['en'].splitlines() if not l.startswith('**Author:'))
        fw = FULLWIDTH_EN.findall(en_non_byline)
        if fw:
            errors.append(f'{en_path.name}: fullwidth punctuation found: {sorted(set(fw))}')
        dash_lines = check_prose_ascii_dashes(texts['en'])
        if dash_lines:
            errors.append(f'{en_path.name}: unconverted ASCII --/---/quotes/escapes on lines {dash_lines[:10]}')

        bilingual_summary[kind] = pair_info
    report['bilingual'] = bilingual_summary

    # 2. JSON validity, v2 BibTeX synchronization & local Markdown link resolution
    for jpath in sorted(PAPER.glob('*.json')):
        json.loads(jpath.read_text())
    bib_v2_keys = re.findall(r'@\w+\s*\{\s*([^,\s]+)', (PAPER / 'references-v2.bib').read_text())
    report['references_v2_keys'] = len(bib_v2_keys)
    for mname in ('manuscript.md', 'manuscript-en.md'):
        ref_count = len(re.findall(r'<a id="ref-(\d+)"></a>', (PAPER / mname).read_text()))
        if ref_count != len(bib_v2_keys):
            errors.append(f'{mname}: reference count {ref_count} != references-v2.bib count {len(bib_v2_keys)}')
    local_links = 0
    for mdpath in [*sorted(PAPER.glob('*.md')), PAPER / 'figures' / 'README.md']:
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', mdpath.read_text()):
            if target.startswith(('http:', 'https:', 'mailto:', '#', '/')):
                continue
            rel_file = target.split('#')[0]
            if rel_file and not (mdpath.parent / rel_file).exists():
                errors.append(f'{mdpath.name}: broken local link {target}')
            local_links += 1
    report['local_links_checked'] = local_links

    # 3. Selection claims, claims.md anchors, metadata-v2 & code-availability alignment
    selection = json.loads(selection_path.read_text())
    is_v2 = selection.get('schema', '').endswith('/v2')
    expected_n = 45 if is_v2 else 40
    claim_ids = [c['id'] for c in selection['claims']]
    if claim_ids != [f'WA{i}' for i in range(1, expected_n + 1)]:
        errors.append(f'Expected WA1..WA{expected_n} in exact order, got {len(claim_ids)} claims')
    report['claims'] = len(claim_ids)

    if is_v2:
        claim_table_anchors = re.findall(r'<a id="(wa\d+)">', (PAPER / 'claims.md').read_text())
        if claim_table_anchors != [f'wa{i}' for i in range(1, 46)]:
            errors.append('claims.md must contain <a id="wa1"> through <a id="wa45"> in exact order')
        report['claims_md_anchors'] = len(claim_table_anchors)

        meta_v2 = json.loads((PAPER / 'metadata-v2.json').read_text())
        bound_h0 = selection['h0_binding']['new_paper_acceptance_commit']
        mat_h0 = selection['h0_binding']['material_commit']
        mv5 = selection['new_source_caps']['MV5_WA41_WA43']['commit']
        c53_54 = selection['new_source_caps']['C53_C54_WA44_WA45']['commit']
        prev_doi = selection['previous_v1_doi']
        if (
            meta_v2.get('H0_acceptance_commit') != bound_h0
            or meta_v2.get('H0_material_commit') != mat_h0
            or meta_v2.get('Homework_MV5_commit') != mv5
            or meta_v2.get('Homework_C53_C54_commit') != c53_54
            or meta_v2.get('previous_doi') != prev_doi
        ):
            errors.append('metadata-v2.json commit/DOI fields differ from release-selection-v2.json')

        for fname in ('manuscript.md', 'manuscript-en.md'):
            body_txt = (PAPER / fname).read_text()
            block = body_txt.split('<!-- code-availability:begin -->', 1)[1].split('<!-- code-availability:end -->', 1)[0]
            for token in (bound_h0, mat_h0, mv5, c53_54, prev_doi,
                          'python3 tools/whole_ledger_v2.py entry', 'ResponsibilityCapacityKernel.lean'):
                if token not in block:
                    errors.append(f'{fname}: code-availability block missing {token}')

    # 4. Per-claim written anchor check & fixed Homework / H0mework Git blob verification
    checked_sources = 0
    checked_decls = 0
    checked_h0_modules = 0
    for claim in selection['claims']:
        cid = claim['id']
        if is_v2:
            for lang in ('zh', 'en'):
                locs = claim.get('written', {}).get(lang, [])
                if not locs:
                    errors.append(f'{cid}: missing written.{lang} anchors')
                for loc in locs:
                    fpart, _, apart = loc.partition('#')
                    if apart not in anchor_Lookup.get(fpart, set()):
                        errors.append(f'{cid}: missing anchor {loc}')
        for src in claim.get('sources', []):
            commit = src.get('source_commit') or src.get('commit')
            path = src['path']
            if homework.exists():
                data = get_blob(homework, commit, path)
                digest = hashlib.sha256(data).hexdigest()
                if 'sha256' in src and src['sha256'] != digest:
                    errors.append(f'{cid}: Homework sha256 mismatch for {path} at {commit[:10]}')
                if 'bytes' in src and src['bytes'] != len(data):
                    errors.append(f'{cid}: Homework byte-size mismatch for {path} at {commit[:10]}')
                text = data.decode()
                for decl in src.get('declarations', []):
                    short = decl.split('.')[-1]
                    if not re.search(DECL.format(re.escape(short)), text):
                        errors.append(f'{cid}: declaration {decl} not found in {path}')
                    checked_decls += 1
                checked_sources += 1
            if h0.exists() and 'h0_public_module' in src:
                pub = src['h0_public_module']
                pub_data = get_blob(h0, pub['commit'], pub['path'])
                if hashlib.sha256(pub_data).hexdigest() != pub['sha256'] or len(pub_data) != pub['bytes']:
                    errors.append(f'{cid}: H0mework public module mismatch {pub["path"]}')
                checked_h0_modules += 1

    report['source_files_checked'] = checked_sources
    report['declarations_checked'] = checked_decls
    report['h0_public_modules_checked'] = checked_h0_modules

    binding = selection['h0_binding']
    if h0.exists():
        h0_commit = binding['new_paper_acceptance_commit']
        h0_records_checked = 0
        if is_v2:
            path = binding['new_paper_map']
            raw = get_blob(h0, h0_commit, path)
            proof_map = json.loads(raw)
            claims = {row['id']: row for row in proof_map['claims']}
            if (path != 'docs/whole-ledger-v2-map.json'
                or hashlib.sha256(raw).hexdigest() != binding['new_paper_map_sha256']
                or proof_map.get('acceptance', {}).get('status') != 'passed'
                or set(claims) != {'WA4', 'WA41', 'WA42', 'WA43', 'WA44', 'WA45'}):
                errors.append('H0mework v2 proof map does not match the accepted WA4 and WA41–WA45 scope')
            owners = set()
            for claim in claims.values():
                for entry in (claim['producers'] + claim['direct_consumers'] + claim['resources']):
                    public = entry['public']
                    path = public['path']
                    if path not in owners:
                        raw = get_blob(h0, h0_commit, path)
                        if hashlib.sha256(raw).hexdigest() != public['sha256']:
                            errors.append(f'{claim["id"]}: mapped H0mework bytes differ at {path}')
                        owners.add(path)
            report['v2_mapped_public_files_checked'] = len(owners)
        for rpath, rmeta in binding.get('fixed_records', {}).items():
            rdata = get_blob(h0, h0_commit, rpath)
            if hashlib.sha256(rdata).hexdigest() != rmeta['sha256'] or len(rdata) != rmeta['bytes']:
                errors.append(f'H0mework fixed_record mismatch: {rpath}')
            h0_records_checked += 1
        for rec in binding.get('acceptance_receipts', []):
            rdata = get_blob(h0, h0_commit, rec['path'])
            if hashlib.sha256(rdata).hexdigest() != rec['sha256']:
                errors.append(f'H0mework acceptance receipt mismatch: {rec["path"]}')
            h0_records_checked += 1
        sc = binding.get('scoped_certification')
        if sc:
            sdata = get_blob(h0, h0_commit, sc['path'])
            if hashlib.sha256(sdata).hexdigest() != sc['sha256']:
                errors.append(f'H0mework scoped certification mismatch: {sc["path"]}')
            h0_records_checked += 1
        report['h0_records_checked'] = h0_records_checked

    # 5. Frozen v1 published artifacts & historical evidence byte-identity
    frozen_checked = 0
    artifact_manifest = PAPER / 'release-artifacts.json'
    if artifact_manifest.exists():
        artifacts = json.loads(artifact_manifest.read_text())
        for group in ('artifacts', 'editable_vector_figures', 'metadata'):
            for entry in artifacts[group]:
                fpath = ROOT / entry['path']
                if not fpath.is_file() or sha(fpath) != entry['sha256'] or fpath.stat().st_size != entry['bytes']:
                    errors.append(f'Frozen v1 {group} file altered or missing: {entry["path"]}')
                frozen_checked += 1
    if (ROOT / '.git').exists():
        for rel_rec in FROZEN_GIT_RECORDS:
            head_bytes = subprocess.run(
                ['git', '-C', str(ROOT), 'show', f'HEAD:{rel_rec}'],
                check=True,
                capture_output=True,
            ).stdout
            if (ROOT / rel_rec).read_bytes() != head_bytes:
                errors.append(f'Frozen historical record modified vs HEAD: {rel_rec}')
            frozen_checked += 1
    report['frozen_v1_and_historical_files_verified'] = frozen_checked

    report['errors'] = errors
    report['status'] = 'pass' if not errors else 'fail'
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    default_hw = PAPER.parents[2] / 'Homework' if (PAPER.parents[2] / 'Homework').exists() else PAPER.parents[3] / 'Homework'
    default_h0 = PAPER.parents[2] / 'H0mework' if (PAPER.parents[2] / 'H0mework').exists() else PAPER.parents[3] / 'H0mework'
    ap.add_argument('--homework', type=Path, default=default_hw)
    ap.add_argument('--h0', type=Path, default=default_h0)
    ap.add_argument('--selection', type=Path, default=PAPER / 'release-selection-v2.json')
    ap.add_argument('--report', type=Path)
    args = ap.parse_args()
    result = check(args.homework, args.h0, args.selection)
    if args.report:
        args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(1 if result['errors'] else 0)


if __name__ == '__main__':
    main()
