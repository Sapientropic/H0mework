#!/usr/bin/env python3
"""Package the Whole-Ledger Accounting paper's v2 editable inputs in the shared builder's layout."""
from __future__ import annotations

from pathlib import Path
import argparse
import hashlib
import json
import zipfile

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
OUTPUT = PAPER / 'build' / 'reading-review-v2'
TEXTS = ('manuscript.md', 'manuscript-en.md', 'supplement.md', 'supplement-en.md')
SHARED = (
    'shared/scripts/build_pdf.py',
    'shared/scripts/byline.py',
    'shared/styles/article-header.tex',
    'shared/styles/article-header-en.tex',
    'shared/styles/article-filter.lua',
    'shared/figure-style/house_style.py',
    'shared/figure-style/svg_text.py',
)


def package(output_dir: Path | None = None) -> dict:
    target_dir = output_dir.resolve() if output_dir else OUTPUT
    build_path = target_dir.relative_to(ROOT).as_posix()
    inputs = {ROOT / p for p in SHARED}
    inputs.update(
        PAPER / p
        for p in (
            *TEXTS,
            'references.bib',
            'references-v2.bib',
            'literature-v2.md',
            'reproduction.md',
            'release-artifacts.json',
            'release-validation-20261017.json',
            'release-selection.json',
            'release-selection-v2.json',
            'metadata-v2.json',
        )
    )
    inputs.update((PAPER / 'scripts').glob('*.py'))
    for pattern in ('*-v2*.svg', '*-v2*.png', 'render_v2.py'):
        inputs.update((PAPER / 'figures').glob(pattern))

    payload: dict[str, bytes] = {}
    records: list[dict] = []
    for path in sorted(inputs):
        data = path.read_bytes()
        if path.suffix in ('.md', '.json', '.svg', '.py', '.bib') and (b'/' + b'Users/') in data:
            raise ValueError(f'Personal path in publication input: {path}')
        rel = path.relative_to(ROOT).as_posix()
        payload[rel] = data
        records.append({
            'path': rel,
            'sha256': hashlib.sha256(data).hexdigest(),
            'bytes': len(data),
        })

    selection = json.loads((PAPER / 'release-selection-v2.json').read_text())
    binding = selection['h0_binding']
    metadata = json.loads((PAPER / 'metadata-v2.json').read_text())
    code_commit = binding['new_paper_acceptance_commit']
    guide = f"""# Provenance-Preserving Conservation Calculus and Non-Free Continuity · editable v2

The bilingual v2 main manuscripts (Sections 1-16 and Appendices A-B), bilingual v2
proof supplements (Sections A-E), twelve editable v2 vector figures (six bilingual
plates), PNG previews, the v2 figure generator, bibliography, metadata, and the
complete WA1-WA45 selection preserve the directory layout required by the shared
builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome, and Noto Serif/Sans CJK SC. Build all four v2 PDFs:

    python3 shared/scripts/build_pdf.py papers/whole-ledger-accounting/manuscript.md papers/whole-ledger-accounting/manuscript-en.md papers/whole-ledger-accounting/supplement.md papers/whole-ledger-accounting/supplement-en.md --output-dir {build_path}

With fontTools, Google Chrome, and pdftoppm installed, regenerate all v2 figures:

    python3 papers/whole-ledger-accounting/figures/render_v2.py
    python3 papers/whole-ledger-accounting/figures/render_v2.py --english

Public formal proofs and reproduction scripts for WA1-WA45 are bound to H0mework
commit {code_commit}. Follow the fixed reproduction guide at
https://github.com/Sapientropic/H0mework/blob/{code_commit}/{binding['reproduction_guide']}.
The earlier WA1-WA40 material commit is {binding['material_commit']}. Fixed Homework source
commits for WA41-WA43 ({metadata['Homework_MV5_commit']}) and WA44-WA45
({metadata['Homework_C53_C54_commit']}) together with per-file SHA-256 digests,
declaration signatures, and bilingual anchors are bound in `release-selection-v2.json`.

Prior v1 preprint (*Book-Balancing Magic Has Nowhere to Hide: Source-Native
Accounting and Actual Continuation*): DOI {metadata['previous_doi']}. Paper text,
proof supplements, and original figures use CC BY 4.0; code uses Apache-2.0.
"""
    payload['README-editable.md'] = guide.encode()
    payload['editable-inputs.json'] = (
        json.dumps(
            {
                'schema': 'whole-ledger-editable-inputs/v2',
                'paper': 'whole-ledger-accounting',
                'version': 'v2',
                'files': records,
                'private_prompts_or_research_repositories_included': False,
            },
            ensure_ascii=False,
            indent=2,
        )
        + '\n'
    ).encode()

    target_dir.mkdir(parents=True, exist_ok=True)
    archive = target_dir / 'whole-ledger-accounting-v2-editable.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path, data in sorted(payload.items()):
            info = zipfile.ZipInfo(path, date_time=(*map(int, selection['date'].split('-')), 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(archive) as z:
        if set(z.namelist()) != set(payload) or z.testzip() is not None:
            raise ValueError('Archive contents or integrity mismatch')
        if any(z.read(path) != data for path, data in payload.items()):
            raise ValueError('Archive payload byte mismatch')

    return {
        'archive': archive.relative_to(ROOT).as_posix(),
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'bytes': archive.stat().st_size,
        'file_count': len(payload),
        'payload_bytes_match': True,
        'zip_integrity': 'pass',
        'input_files': records,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, help='Directory for the v2 packaged archive')
    result = package(parser.parse_args().output_dir)
    print(json.dumps({k: v for k, v in result.items() if k != 'input_files'}, ensure_ascii=False))
