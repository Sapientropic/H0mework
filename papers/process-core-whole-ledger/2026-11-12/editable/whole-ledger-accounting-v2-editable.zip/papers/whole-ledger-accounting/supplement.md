# 证明补充：全事件库存、有偿语法、零求值反演与成批续账

*Proof Supplement: Whole-Event Inventories, Paid Syntax, Zero-Evaluation Certificate Inversion, and Step-Grouped Continuation*

**作者：高健（Jian Gao）**\
独立研究者 · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## 摘要

本证明补充逐节给出《溯源守恒演算与非免费连续性：全事件账本、观察安全与良基结清》（第二版，v2）正文第 3、4、5、7、8、14、15 节所调用的完整技术构造与逐步骤证明：A 节展开原生写入回执诱导的四支数学残差处置（WA12）；B 节展开全类型拆并重构证书提升、继续分支运输余项与容量扣款运行归纳（WA4–WA5, WA15–WA17）；C 节展开无旧承担者语法出生、整数系数与替换重放、迭代批次计费及全计数行权限（WA13–WA14, WA18–WA21, WA26–WA28）；D 节展开跨语言类型化库存异质消元、同回执总值写回、完成距离与最大未来不可见核、双负号已付语法树恢复与逐原语余链微分回放（WA41–WA42）、自由常量表显式整数证书反演（WA43）以及按执行步连续切片防漏重与封存历史末态续账（WA44–WA45）；E 节展开长计算窗口的前置预解梳算子安装供料（WA33）。共享过程核心定理引用已发表过程代数篇第二版[[1]](#ref-1)（DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175)）。

---

<a id="supplement-a"></a>
## A　原生写入回执诱导的四支数学残差处置

<a id="supplement-a-1"></a>
### A.1　完整线性恢复与三类精确残差证人（WA12）

固定具体动力学源 $D$、状态 $s$ 与目标加法交换群 $A$。源输入律在每个原始事件上给出生成元类型 $G$、以该发生为根的完整暴露树、初始种子、继续树与评价器树；种子与继续树共同生成完整历史 $H_s$。上述输入中不含任何预设的处置分支、核为零假设、满射覆盖假设或外置逆映射。

第一步是整账回执消元：对同一次整账编译结果做结构分支消元，由于在此具名源词表中关系写入、续接运输、重定向与本地终账四支载荷均为 `PEmpty`，唯一存活的原生写入载荷直接还原出 $\varepsilon=D.\mathrm{emit}(s)$，事件呈现往返恒等给出编译回执与发射事件严格全等。以下全部代数对象均由此同一枚旧账转移回执唯一确定。

记 $E:\mathbb Z^{(G)}\to A$ 为评价器的 $\mathbb Z$-线性延拓。历史 $H_s$ 保存生成元闭包与关系闭包：若关系闭包在 $E$ 下恒为零（关系可靠），则 $E$ 下降为完备化载体上的同态 $\overline E:\widehat H_s\to A$；否则存在源关系闭包中的实际关系 $q$ 使 $E(q)\ne 0$。忠实结算判据依次对关系可靠性、核 $\ker\overline E$ 与余核 $A/\operatorname{im}\overline E$ 做构造性四分：

1. **忠实等价支**：关系可靠、$\ker\overline E=\{0\}$ 且余核 $A/\operatorname{im}\overline E$ 为单点群，正向生成完整 $\mathbb Z$-线性同构 $\phi:\widehat H_s\simeq A$；对任意 $a\in A$，恢复映射 $\phi^{-1}(a)$ 严格满足 $\overline E(\phi^{-1}(a))=a$。
2. **关系不可靠支**：提取属于当次历史关系闭包的实际关系 $q$ 及其非零评价坐标 $u=E(q)\ne 0$。
3. **非零核残差支**：关系可靠而 $\ker\overline E\ne\{0\}$，提取非零完备化元素 $k\in\widehat H_s$ 满足 $k\ne 0$ 且 $\overline E(k)=0$（数值评价为零绝不抹除该非零完备化坐标）。
4. **覆盖残差支**：关系可靠、$\ker\overline E=\{0\}$ 而余核 $A/\operatorname{im}\overline E$ 非单点，取两个不同陪集之差得非零余核类 $c\ne 0$ 并取原像代表 $a\in A$（$[a]=c$），从而 $a\notin\operatorname{im}\overline E$。任取候选恢复函数 $f:A\to\widehat H_s$（无需假设 $f$ 线性），若 $\overline E(f(a))=a$ 则 $a\in\operatorname{im}\overline E$、$[a]=0=c$，矛盾！故恒有 $\overline E(f(a))\ne a$。

由于材料与残差投影均在发射器前安装于同一权威源，底层账根与发射器 $D.\mathrm{emit}$ 保持不变；与上述任一分支同步交出的旧账行演化仍为保预算转移：
$$\mathrm{entry}(s)\xrightarrow{\varepsilon}\mathrm{entry}\bigl(D.\mathrm{update}(\varepsilon)\bigr),\qquad \mathrm{next}(s)=D.\mathrm{update}(\varepsilon).\tag{S.1}$$
同债预算满足非增等式，不把数学残差分类伪造成严格扣款。

---

<a id="supplement-b"></a>
## B　全类型拆并证书提升、运输余项与容量维护扣款核

<a id="supplement-b-1"></a>
### B.1　旧责任类型的逐字段左逆提升与全继续分支直和折叠（WA5, WA15–WA17）

在有限原生追加情形（WA15）中，设旧显式行索引集为 $I=\operatorname{Fin}(m)$，扩充后索引集取 $\operatorname{Fin}(m+1)$：每个旧位置沿保序嵌入 $\operatorname{castSucc}:\operatorname{Fin}(m)\hookrightarrow\operatorname{Fin}(m+1)$ 原样保留源／目标账项、双端选择器与完整回执，新增独立数学行置于末位 $\operatorname{last}(m)$。重复主张或相同有效载荷均按位置独立保存，绝不去重；双端单射性仅由旧同一性范围证书与旧／数学和标签互斥推出。

在一般拆并提升情形（WA16）中，取消目标单射限制。设母源责任词表为 $V$，扩充词表 $V^+$ 在内容、剩余事项、承担者、受益方、管辖范围、源事件及谱系上附加“旧值 $\sqcup$ 数学”二元标签，而在旧值分支上逐字段原样保留准入类型、源权限、承担证明、起源及全部进展／转移／终结回执类型。定义嵌入 $j:\mathrm{Obligation}_V\to\mathrm{Obligation}_{V^+}$ 与部分读回 $p:\mathrm{Obligation}_{V^+}\to\operatorname{Option}(\mathrm{Obligation}_V)$，逐字段验证：
$$p(j(a))=\operatorname{some}(a),\tag{S.2}$$
对等式两边作用 $p$ 并消去 $\operatorname{some}$ 即证 $j$ 严格单射。母拆分回执的子项列表映射为 $\operatorname{map}(j,\mathrm{children})$（合并父项列表对称映射为 $\operatorname{map}(j,\mathrm{parents})$）：列表成员由式 (S.2) 还原为母成员，故源归属、锚点运输、同谱系与局部履责证明均沿标签等式直接运输；全来源纤维覆盖由 $j$ 单射反解母来源等式后调用母覆盖定理再映回新列表（数学标签行不可能与旧来源同标签）；无幽灵成员与逐子项严格扣减 $b(\mathrm{child})<b(\mathrm{parent})$ 沿预算读取交换式同步保持。因此扩充整账的重组证书完全由母编译图像自产，无需目标侧另交任何分类证明。

在全继续分支情形（WA17）中，输入为源律给出的逐当前继续载荷包 `Packet`，从当次生成整账消去原生写入、关系写入、续接运输或重定向四支之一以还原旧整账演化 $(d,o)$、有限补丁与规范后继。数学已付分支采用实际严格扣款步，结算分支采用原位恒等演化，直和连接（whole join）在旧分支上严格交换：
$$d^+(j_s(e))=j_t(d(e)),\qquad o^+(j_t(f))=j_s(o(f)).\tag{S.3}$$
有限生成式片段仅显式列出零号数学行，其余一切旧行交由同源消元所得的余项事件编译处理；逐标签展开两侧依赖和，$\Sigma$ 折叠精确等于式 (S.3) 的完整直和连接，母拆并证书随之同根提升并在同一演化步消元消费。

<a id="supplement-b-2"></a>
### B.2　容量短缺阻滞与认证维护扣款运行界（WA4）

在 `ResponsibilityCapacityKernel` 中，容量读数 $\mathcal R$ 由源事件、承担者、已准入责任列表、需求容量 $C_{\mathrm{dem}}\in\mathbb N$、可用容量 $C_{\mathrm{avail}}\in\mathbb N$ 以及不相容需求、受影响依赖与受保护边界三份列表构成。判定算子 $\mathsf{obstruction?}(\mathcal R)$ 定义为：若 $h:C_{\mathrm{avail}}<C_{\mathrm{dem}}$ 成立则返回 $\operatorname{some}\langle h\rangle$，否则返回 $\operatorname{none}$。由于自然数严格小于关系可判定，分情况讨论立即给出正文式 (5) 的两条充要等价，且结构体 $\mathsf{CapacityObstruction}(\mathcal R)$ 除不等式见证 $h$ 外不含任何解除义务或删减分支字段。

对携带扣款过程 $B$，每步回执 $d:\mathsf{ActualMaintenanceDebit}(P,B,g,\lambda)$ 包含稳定槽位 $s\in\mathbb N$、已准入活义务 $o$、源事件 $\varepsilon$、维护回执 $r$、事件等式 $g.\mathsf{lifecycleEvent}=\mathrm{carried}(s,o,\varepsilon,\mathrm{maintained}(r))$、前后槽位存活证明、谱系等式 $o.\mathsf{lineage}=\lambda$ 与严格扣减 $B(\tau,\lambda)<B(\sigma,\lambda)$。对边 $g$ 的三类构造子（准入、重开、跨界）及跨界内部九种子处置逐一匹配事件等式，除 `carried ... maintained` 外八支均因构造子不相交直接导出矛盾；唯一匹配分支直接提取过程边界的锚点恒等与发生关联恒等，证出 `sourceOwnership`。将认证运行 $\gamma$ 映射至 $\mathsf{StrictBudgetRun}(B(\sigma,\lambda),B(\tau,\lambda))$，对归纳步 `step prior debit`（其中 $B(\tau,\lambda)<B(\mu,\lambda)$，即 $B(\tau,\lambda)+1\le B(\mu,\lambda)$）结合归纳假设 $|\mathrm{prior}|+B(\mu,\lambda)\le B(\sigma,\lambda)$ 立得 $(|\mathrm{prior}|+1)+B(\tau,\lambda)\le B(\sigma,\lambda)$，证出正文式 (6) 全部结论。

---

<a id="supplement-c"></a>
## C　有偿语法执行、精确节点计费与全计数行权限

<a id="supplement-c-1"></a>
### C.1　原语求值迹伸缩与无旧承担者整账连接（WA13–WA14, WA18）

在多型加法交换群值语言中，剩余节点计数递归定义为：
$$r(\operatorname{const}c)=0,\quad r(\operatorname{var}x)=1,\quad r(e+f)=r(e)+r(f)+1,\quad r(Le)=r(e)+1,\quad r(B(e,f))=r(e)+r(f)+1.\tag{S.4}$$
变量绑定、双常量加法、常量线性作用与双常量双加法作用各消耗一步原语归约；上下文归约将子式归约步嵌入父节点左／右槽。对构造子归纳立见每一步 $s:e\to e'$ 满足 $r(e)=r(e')+1$ 且 $\operatorname{ev}_\rho(e)=\operatorname{ev}_\rho(e')$；左优先求值器对语法树归纳生成长度 $|T_e|=r(e)$ 的完整执行迹 $T_e:e\to\operatorname{const}(\operatorname{ev}_\rho e)$。单步关系词像为 $\delta_e-\delta_{e'}$，沿执行迹串接求和后中间项逐对伸缩相消，故任意前缀迹 $T:e\to e_k$ 满足：
$$\partial\eta_T=\delta_e-\delta_{e_k},\qquad \operatorname{ev}_\rho(\partial\eta_T)=0.\tag{S.5}$$
注意：伸缩相消仅发生在自由模边界投影 $\partial\eta_T$ 上，底层执行迹 $T$ 的每一步原语发生、先后顺序与关系索引均原封不动保存在有偿状态 $(e_k,T_k)$ 中。无旧承担者整账将支承扩充为“原支承 $\times$ 可选数学状态”：对 $k<B:=r(e)$，预算 $b_k=B-k>0$ 发出严格扣款步，旧责任行经运输余项完整保留；对 $k=B$，$b_B=0$ 进入局部结算，不再产生该数学行的付款宏步。十节点 Fock 询问实例在深度 $d$ 处满足预算 $10-(d+1)$，当前物理环境 $\rho_d$ 下的更新残差为 $\mathrm{physicalPair}_d-\operatorname{ev}_{\rho_d}(e_d)$，在预算耗尽处化为首尾完整物理配对之差。

<a id="supplement-c-2"></a>
### C.2　整数展开、绑定替换、有序动作词与调用批次常数展开（WA19, WA21, WA26–WA28）

1. **整数系数展开**：令 $N_0(e)=\operatorname{const}0$、$N_{a+1}(e)=e+N_a(e)$（$a\in\mathbb N$），归纳得求值 $a\operatorname{ev}(e)$ 与节点费 $a(r(e)+1)$；负整数 $z=-(a+1)$ 外包一层负号节点，总节点费统一写为 $c_z(e)=|z|(r(e)+1)+\mathbf 1_{z<0}$。对有限支撑列表 $L=[(e_1,z_1),\dots,(e_m,z_m)]$ 折叠生成的词语法树 $F(L)$ 满足：
   $$r(F(L))=\sum_{(e,z)\in L}\bigl(c_z(e)+1\bigr),\qquad \operatorname{ev}(F(L))=\sum_{(e,z)\in L}z\operatorname{ev}(e).\tag{S.6}$$
2. **绑定体替换重放**：给定变量代换 $\theta$ 与目标环境 $\Theta$，诱导原环境 $\rho(x):=\operatorname{ev}_\Theta(\theta(x))$。将 $\rho$ 下的单步归约逐构造子提升为 $\Theta$ 下的执行迹：变量绑定步 $\operatorname{bind}(x)$ 展开为 $\theta(x)$ 的**整条求值迹**，常量原语步保持单步，上下文步嵌入对应子槽；串接迹映射为迹拼接，常量终点处总长度严格满足 $|T[\theta]|=r(e[\theta])$。
3. **有序动作词费用**：设词长 $|w|=n$。模型单程序含 $n$ 个字母线性节点、$1$ 个变量节点与 $1$ 个投影节点，费 $n+2$；完整前缀作用多 $1$ 个节点，费 $n+3$；联合配对树费 $2n+5$。逐字母效应历史递归保存作用前状态点与单步残差，空词占 $5$ 步，每增一字母占 $7$ 步：
   $$h([\,])=5,\qquad h(\ell u)=7+h(u),\qquad h(w)=7n+5.\tag{S.7}$$
4. **余链全坐标、迭代批次与主子查询**：对表达式 $e$，列表 $[\mathrm{updated}(e),\mathrm{old}(e)]\mathbin{++}\mathrm{mixedTerms}(e)$ 由有限下标集索引，混合项偏移 $i\mapsto i+2$ 单射保留重复项独立坐标，向量树总费用为各项原费之和加 $2$ 倍列表长度。对迭代前缀 $e_i=e[\sigma]^i$，配对提升保节点数，记 $\Sigma_n=\sum_{i=0}^{n}r(\widetilde e_i)$，向量批次在 $n+1$ 个坐标各加嵌入与累加两节点，得 $|T_{\mathrm{batch}}|=\Sigma_n+2(n+1)$；独立发出的有限变量界 $B+2$ 次实际调用满足实付总费恒等：
   $$\mathrm{callCharge}=\sum_{j=0}^{B+1}|T_j|=\sum_{j=0}^{B+1}r(\mathrm{Raw}_j)=\mathrm{callCost}.\tag{S.8}$$
   带分支主子查询中，每个被选中的子查询（规模 $m_i$）带输出注入计费 $4m_i+1$（空后继支计 $0$），主语法树连接原查询与两子查询共加 $3$ 个节点，总费用精确为 $c_{\mathrm{main}}=c_{\mathrm{query}}+c_{\mathrm{oldChild}}+c_{\mathrm{nextChild}}+3$。

<a id="supplement-c-3"></a>
### C.3　密封初始行权限与全计数递推准入（WA20, WA24）

数学编译器的初始有限片段在零号槽显式选中新数学行，由该选择等式直接构造密封初始行权限 $a_0$；若第 $k$ 步已持有 $(e_k,a_k)$，下一步目标账项直接取同一次整账写入的规范目标行，后继权限取 $a_{k+1}=a_k.\mathrm{next}$，全程无需目标侧重新准入。对完成材料 $M=(\rho,e,e',T,\mathrm{owner},\varepsilon)$，下一残差请求 $e+(-e')$ 的语法预算满足 $r(e)+r(e')+2\ge 2>0$，保证首步必为严格付款步，经通用债务准入编译在同一精确时序发生上输出 $\mathsf{debtAdmission}$，同步锁定整账首写去向、全部旧投影读出与规范后继（即便环境增量 $\varepsilon=0$，仍完整支付 $B+2$ 步语法预算）。

---

<a id="supplement-d"></a>
## D　类型化库存、最大未来核、零求值证书反演与成批续账

<a id="supplement-d-1"></a>
### D.1　跨语言类型化库存异质消元与出生位置偏移（WA22, WA25, WA32）

库存投影律在每个供应发生处直接输出包含高层／低层原始输入、两份有偿状态与执行迹、逐变量绑定、迁入迹及已写库存的完整依赖记录。通用准入目标继承的读出结果与源读出满足异质相等 $\mathrm{HEq}$，由此导出载荷类型相等；沿该类型等式转型并消去空未激活支（`PEmpty`），激活支异质转型与原 $\mathrm{HEq}$ 复合化为普通相等，严格证出读回对象即原完整跨层记录本身。由正文式 (17) 三次嵌套并列接缝 $\operatorname{seed}$，查询执行迹第 $j$ 位在出生库存中的精确位置满足：
$$\iota(j)=j+|H_o|+|H_P|+3,\qquad H_B[\iota(j)]=H_Q[j],\tag{S.9}$$
自然数消去律保证 $\iota$ 严格单调且单射。跨阶段逆迹写回通过递归折叠 $\mathrm{historyWritten}(0)=\mathrm{written}(0)$、$\mathrm{historyWritten}(d+1)=\operatorname{seed}(\mathrm{historyWritten}(d),\mathrm{written}(d+1))$ 将 $0\le d\le\mathrm{depth}$ 的全部历史阶段事件完整保存在出生库存中。

<a id="supplement-d-2"></a>
### D.2　同回执总值解码写回与两次边界差联合入库（WA23, WA29–WA31, WA34）

配对提升求值输出 $(p,n)=(\operatorname{ev}_\rho e,\operatorname{eff}_{\rho,\varepsilon}e)$，其中原生残差请求 $e-\operatorname{const}(p)$ 在更新环境 $\rho+\varepsilon$ 下的完成值恰为 $n=\operatorname{ev}_{\rho+\varepsilon}e-p$，相加即得同回执总值：
$$p+n=\operatorname{ev}_{\rho+\varepsilon}e.\tag{S.10}$$
解码写入器仅在类型回执选中的结算分支调用写入 $(p+n)$（当 $n=0$ 时仍忠实写回 $p$）；下一出生包重新读取自身完成结果生成新基准 $p^+$ 与新解码器，有类型子种子的 `Move` 递归在同一 `generatedAction` 中同步对齐目标根、整账首写、旧投影与下一物理环境。在两次实际执行的边界差计算中（WA30–WA31），同范围读出相减 $(r-c(\Psi,0))-(r-c(\Psi,\sigma))=c(0,\sigma)$ 独立生成整系数语法树并按自身节点预算跑出完整执行迹，每笔新增已付暴露依次经配对已写库、原生已付库嵌入联合库存 `jointStock`。

<a id="supplement-d-3"></a>
### D.3　类型完成回执的精确结算距离（WA32）

对任意有效配置、初始帧与起点 $i$（待求值式剩余节点数记作 $B_i$），类型级完成回执通过对动作分支强递归构造：若当前动作已是结算分支则返回距离 $d=0$；若为已付分支则跳转至 `mathNext`（剩余节点数降为 $B_i-1$），递归取得子回执并将距离加 $1$，由索引结合律 $(i+1)+d'=i+(d'+1)$ 运输终点结算等式。对 $0\le h\le B_i$ 归纳知第 $i+h$ 帧剩余节点数为 $B_i-h$：当 $h<B_i$ 时剩余计数为正，结算分支不可能发生，故全部中间位均为真实已付扣款步；终点处剩余计数为 $0$ 且回执保证 $d\le B_i$，故必有 $d=B_i$。

<a id="supplement-d-4"></a>
### D.4　共尾停点片段覆盖、接收器环境方块与最大未来核（WA35–WA37）

库存目标编译器对已付动作输出直接回答推进、对结算动作输出责任出生准入 `debtAdmission`。由正文式 (20) $t_0=0,t_{j+1}=t_j+1+d(t_j+1)$ 生成的停点序列满足 $t_{j+1}>t_j$ 及 $t_j\ge j$，第 $j$ 段运行片段精确覆盖区间 $[t_j,t_{j+1}]$ 内的全部离散步（分次阶数 `grade` 仅在实际出生处加 $1$，绝不冒充底层离散步时钟）。在第 $j$ 个停点的自由整系数词模 $\mathcal W_j$ 上，源词作用 $S_j:\mathcal W_j\to\mathcal W_{j+1}$ 经逆运输读取原接收器自身环境 $(\rho_j^{\mathrm{rec}},\varepsilon_j^{\mathrm{rec}})$，满足精确接收器求值方块：
$$\mathrm{receiverRead}_j(S_jw)=\bigl(\operatorname{ev}_{\rho_j^{\mathrm{rec}}}(w),\,\operatorname{eff}_{\rho_j^{\mathrm{rec}},\varepsilon_j^{\mathrm{rec}}}(w)\bigr),\tag{S.11}$$
无需假定不同阶数的环境预先相等。在直和载体 $\mathcal W=\bigoplus_j\mathcal W_j$ 上，正文式 (21) 的联合零核 $K_{\mathrm{fut}}=\bigcap_a\bigcap_j\ker(D_jS_a)$ 对 $S$ 封闭，商空间 $\mathcal M_{\mathrm{fut}}=\mathcal W/K_{\mathrm{fut}}$ 上两元素等价当且仅当在一切允许词 $a$ 与站位 $j$ 下观察全同；空词包含当前读口保证 $K_{\mathrm{fut}}$ 落入完备化核并诱导规范原生限制映射。

<a id="supplement-d-5"></a>
### D.5　公开实现中的三项环境与正信用补充说明

过程代数篇第二版公开实现中的三项配套引理在整账包中各守真实字节身份：(i) 原生接收器正语法费用由残差语法树固有的两节点开销（负号加加法）与首步扣减直接导出；(ii) 通用查询与计算读口的环境对齐写作显式输入合同，并由上下文配置族的 `Incoming` 构造自动兑现（最终下游核验不增额外前提）；(iii) 有限配置下 `calculationReader = none` 分支精确接入同一配对库存的计算词，原查询读口、解码写入器与双库存保持不变。

<a id="supplement-d-6"></a>
### D.6　双负号恢复已付语法树与整词逐原语余链微分回放（WA41–WA42）

**已付方法跨包恢复与回调入库（`PaidMethod/{Source,Recovery,Admissions}.lean`，WA41）。** 设基础源配置族为 `baseFactory`，预定加法同态为 $f:W_s\to_+ W_s$，配对阶数同态递归定义为 $\mathsf{actionAt}(f,0)=f$、$\mathsf{actionAt}(f,n+1)=\mathsf{pairAction}(\mathsf{actionAt}(f,n))$（其中 $\mathsf{pairAction}(g)(u,v)=(g(u),g(v))$）。三分支语法提取算子定义为：
$$\mathsf{retainedCode}(n,\mathrm{frame}):=\begin{cases}\operatorname{linear}(-\mathrm{id},u),&\text{if }\mathrm{frame.registered.input.expression}=\operatorname{add}(\operatorname{add}(e_0,u),e_{\mathrm{eff}}),\\\operatorname{linear}(-\mathrm{id},u),&\text{else if }\mathrm{frame.registered.input.expression}=\operatorname{add}(e_0,u),\\\mathrm{frame.registered.input.expression},&\text{otherwise.}\end{cases}\tag{S.12}$$
对任意阶数 $n$ 的准入包 $P=\langle n,(s,\xi),\mathsf{cfg},\langle\mathrm{rfl}\rangle\rangle$（已完成配对端点 $p_\star=\operatorname{const}(v_{\mathrm{paid}})\in V_{n+1}$），第一步 `nativeAfterAdmission` 生成的初帧 $\mathrm{native}$ 注册第一层残差 $\operatorname{add}(e_0,\operatorname{linear}(-\mathrm{id},p_\star))$；令类型完成回执距离为 $d$，结算选中帧为 $\mathrm{selected}=\mathrm{frames}(\mathrm{native},d)$。由已付前缀不变引理 `paid_prefix_expression`（沿 $0\le k\le d$ 归纳使用已付步 `mathNext` 不改写注册输入）知 $\mathrm{selected}$ 的注册语法树仍等于该第一层残差；而第二步 `bornAfterNative` 生成的下一出生包 $P^+$（位于阶数 $n+1$）在外层包裹第二层残差 $\operatorname{add}(\operatorname{add}(e_0,\operatorname{linear}(-\mathrm{id},p_\star)),\operatorname{linear}(-\mathrm{id},\mathrm{selected.event.state.1}))$。对其作用式 (S.12) 的首分支剥离外层右项、提取内层负项 $u=\operatorname{linear}(-\mathrm{id},p_\star)$，立得：
$$\mathsf{retainedCode}(P^+)\ \simeq\ \operatorname{linear}\bigl(-\mathrm{id},\,\operatorname{linear}(-\mathrm{id},p_\star)\bigr),\qquad p_\star=\operatorname{const}(v_{\mathrm{paid}}).\tag{S.13}$$
在任意环境 $\Gamma^+$ 下求值，由阿贝尔群对合恒等式 $-(-v_{\mathrm{paid}})=v_{\mathrm{paid}}$（`negate_paid`）无损还原原完成值 $v_{\mathrm{paid}}$。接着，在阶数 $n+1$ 的包 $P^+$ 上，方法原始输入 `raw f (n+1) frame` 取零增量配对环境 $\operatorname{pairEnv}(\Gamma^+,0)$ 与语法树 $\operatorname{linear}(\mathsf{pairAction}(\mathsf{actionAt}(f,n+1)),\operatorname{liftExpr}(\mathsf{retainedCode}(n+1,\mathrm{frame})))$：由 $\operatorname{eval}(\Gamma+\delta)=\operatorname{eval}(\Gamma)+\operatorname{effect}(\Gamma,\delta)$ 代入 $\delta=0$ 消去左项得 $\operatorname{effect}(\Gamma,0)=0$（`effect_zero`），故配对提升求值为 $(v_{\mathrm{paid}},0)$，再作用同态保零性得方法完成输出 $(\mathsf{actionAt}(f,n+1)(v_{\mathrm{paid}}),0)=((f^{(n)},f^{(n)})(v_{\mathrm{paid}}),0)$（`after_native_whole_action`）。同时，派生配置族将 `nextPairInventory` 设为 `some (Stock.preserve prior (completeQueryWritten (n+1) frame))`，由 `birth_keeps_callback` 证明 $\forall \varepsilon\in\mathsf{completeQueryWritten}.\mathrm{trace},\ \varepsilon\in\mathsf{birthStock}.\mathrm{trace}$；在带复内积识别 `RecognitionAt H root` 的上下文配置族上，通过七层 `InstallationAt` 投影余面复合在发射器前安装 `InstalledFaces`（统一四面与对偶读回），在每个共尾停点 $k\in\mathbb N$ 及任意有限更新段 `finite_paid_method_faces` 上同步交付完整场作用段与整账后继。

**整词逐原语步进回放与余链微分同步（`WordExecution.lean`、`RelationCochain/{Source,Consumer}.lean`，WA42）。** 对任意活源过程与状态环境读出 `readEnv`，定义词载体观察环境 $\rho_{\mathrm{obs}}(w)(t,x):=\mathrm{observer}(\lambda s.\,\mathrm{readEnv}(s,t,x),w)$；对表达式结构归纳得上下文嵌入求值恒等式 $(\operatorname{embed}(e)).\operatorname{eval}(\mathrm{env}(w))=e.\operatorname{eval}(\rho_{\mathrm{obs}}(w))$，且上下文绑定满足求值推进等式 $(\lambda t,x.\,\operatorname{binding}(t,x).\operatorname{eval}(\mathrm{env}(w)))=\mathrm{env}(\mathrm{sourceAction}(w))$。据此对原单步归约 $s:b\to a$ 的九种构造子递归定义上下文嵌入迹 `embeddedStep(s)`（变量绑定步调用上下文变量自身求值迹并用上述求值等式改写终点，常量原语步映射为单步迹，子式步递归嵌入左／右槽），串接得 `embeddedTrace`；再结合变量代换迹定理 `Trace.substitutedTrace`，构造正向逐原语回放迹 `forward` 及其零增量配对提升 `pairedForward`，其长度严格满足 $|\mathrm{forward}(w,e)|=\mathrm{remaining}((\operatorname{embed}(e)).\operatorname{subst}(\operatorname{binding}))$（`forward_charge`）。

在规范粒子—波 Fock 密封运行态 `sourceRuntime` 的第 `count` 帧上，由归纳时钟对齐引理 `actual_grounded`（初段预置 $11$ 步校准偏移）证出活跃环境等于底层物理过程推进 $11+\mathrm{count}$ 步的真实环境，从而导出配对绑定交换方块 `paired_binding_square`：$\operatorname{sourceEnvironment}(\mathrm{pairBinding},\mathrm{actualPairEnv}(c))=\mathrm{actualPairEnv}(c+1)$。回放暴露 `replayStock` 经同一 `birth_keeps_callback` 机制同时写入当次 `birthStock`（`native_replay_written`）与下一包完整查询库存（`native_replay_next_query`），因而其关系边界落入下一前缀历史的关系闭包成为子类型元素 `actualBoundary`。最后，将源关系词 $\mu_{\mathrm{src}}=\mathrm{sourceRelations}(c)$ 送入代换链复形态射 $\tau_1$，由 `SourceSubstitution.boundary_square` 与两端关系边界伸缩展开得：
$$\operatorname{relationMap}\bigl(\tau_1(\mu_{\mathrm{src}})\bigr)=\operatorname{substitution}\bigl(\operatorname{relationMap}(\mu_{\mathrm{src}})\bigr)=\mathrm{actualBoundary}(c).\mathrm{val}=\bigl(d^{0,1}(\mathrm{actualBoundary}(c))\bigr).\mathrm{val},\tag{S.14}$$
并在同一选定停点 `stop = start + receipt.1` 处同步完成余像边界消元与物理状态—强制迹读回 `physicalReadback`。

<a id="supplement-d-7"></a>
### D.7　自由常量表关系修正与零求值显式整数证书反演（WA43）

在 `ConstantTransport.lean` 与 `ConstantInverse.lean` 中，设配对值阿贝尔群为 $G:=\mathrm{PairValue}(V,s)=V_s\times V_s$。标量关系呈现 `ScalarRelationPresentation` 的关系索引类型为和类型 $\mathrm{RelationIndex}(\mathbb Z,G):=(G\times G)\sqcup(\mathbb Z\times G)$，其边界映射 $\operatorname{relationMap}:\mathbb Z^{(\mathrm{RelationIndex}(\mathbb Z,G))}\to\mathbb Z^{(G)}$ 在两类单点生成元上分别定义为：
$$\operatorname{relationMap}\bigl([\mathrm{inl}(u,v)]\bigr)=[u]+[v]-[u+v],\qquad \operatorname{relationMap}\bigl([\mathrm{inr}(z,g)]\bigr)=[z\cdot g]-z[g].\tag{S.15}$$
由于群自由求值同态 $\operatorname{freeEval}:\mathbb Z^{(G)}\to G$ 将单点 $[g]$ 映为 $g$，式 (S.15) 两类生成元在 $\operatorname{freeEval}$ 下分别映为 $u+v-(u+v)=0$ 与 $z\cdot g-z\cdot g=0$，故恒有 $\operatorname{im}(\operatorname{relationMap})\subseteq\ker(\operatorname{freeEval})$。

1. **正向自由常量表传输**：对旧环境 $\Gamma$ 与增量 $\delta$，定义三个 $\mathbb Z$-线性映射 $F(\mathbb Z,G,X;s)\to\mathbb Z^{(G)}$：$\mathrm{valueMap}_\Gamma([e])=[\llbracket e\rrbracket_\Gamma]$、$\mathrm{effectValueMap}_{\Gamma,\delta}([e])=[D_e(\Gamma,\delta)]$，以及加法证书映射 $\mathrm{additionCertificate}_{\Gamma,\delta}([e])=[\mathrm{inl}(\llbracket e\rrbracket_\Gamma,D_e(\Gamma,\delta))]$。在单生成元 $[e]$ 上利用 $\llbracket e\rrbracket_{\Gamma+\delta}=\llbracket e\rrbracket_\Gamma+D_e(\Gamma,\delta)$ 验证：
   $$[\llbracket e\rrbracket_\Gamma]+[D_e(\Gamma,\delta)]-[\llbracket e\rrbracket_{\Gamma+\delta}]=\operatorname{relationMap}\bigl([\mathrm{inl}(\llbracket e\rrbracket_\Gamma,D_e(\Gamma,\delta))]\bigr),\tag{S.16}$$
   沿自由词模线性延拓并前复合统一四面完美化余像恢复映射 $\mathrm{recover}:\mathcal W_{\mathrm{perf}}\to F(\mathbb Z,G,X;s)$，即证 $\mathsf{computedAfter}:=\mathsf{before}+\mathsf{effect}-\mathsf{corr}=\mathsf{after}$。在源整词规范像 $\widehat w$ 处，利用 `F.whole_recovery`（$\mathrm{recover}(\widehat w)=w$）与环境推进等式，认回 $\mathsf{after}(\widehat w)=\mathrm{originFace.rootRead.source.newConstants}$，并对任意检测器 $d\in\mathbb Z^{(G)}$ 保持双线性配对恒等式 `actual_detector`。

2. **反向显式整数证书构造与无损还原**：对任意有限带权列表 $L\in\operatorname{List}(G\times\mathbb Z)$，定义自由词 $W(L):=\sum_{(g,z)\in L}z[g]\in\mathbb Z^{(G)}$、群求和值 $V(L):=\sum_{(g,z)\in L}z\cdot g\in G$，并递归构造整数关系证书 `coefficientRelations(L)`：
   $$\begin{aligned}
   \mathsf{cert}([\,])&:=-[\mathrm{inr}(0,0)],\\
   \mathsf{cert}\bigl((g,z)::R\bigr)&:=-[\mathrm{inr}(z,g)]+\mathsf{cert}(R)+\bigl[\mathrm{inl}\bigl(z\cdot g,\,V(R)\bigr)\bigr].
   \end{aligned}\tag{S.17}$$
   对列表 $L$ 归纳证明 $\operatorname{relationMap}(\mathsf{cert}(L))=W(L)-[V(L)]$：
   - 基步 $L=[\,]$：$W([\,])=0,V([\,])=0$，而 $\operatorname{relationMap}(-[\mathrm{inr}(0,0)])=-([0\cdot 0]-0[0])=-[0]=0-[0]$（这正是空列表不能返回 $0$ 而必须保留零原子 $-[\mathrm{inr}(0,0)]$ 的精确代数原因：在自由模 $\mathbb Z^{(G)}$ 中，群零元的基向量 $[0]\ne 0$！）；
   - 归纳步 $(g,z)::R$：由式 (S.15) 与归纳假设展开右边映射像：
     $$-\bigl([z\cdot g]-z[g]\bigr)+\bigl(W(R)-[V(R)]\bigr)+\bigl([z\cdot g]+[V(R)]-[z\cdot g+V(R)]\bigr)=\bigl(z[g]+W(R)\bigr)-[z\cdot g+V(R)],$$
     在阿贝尔群 $\mathbb Z^{(G)}$ 中 $[z\cdot g]$ 与 $[V(R)]$ 两对中间项精确对消，恰得 $W((g,z)::R)-[V((g,z)::R)]$。

   对任意有限支撑表 $S\in\mathbb Z^{(G)}$，在标准 T1 层取其支撑枚举列表 $L_S=\operatorname{map}(\lambda g.\,(g,S(g)),S.\mathrm{support.toList})$（证书递归算子 $\mathsf{cert}$ 本身对任意给定带权列表纯递归生成，无需外部核前像假设），则 $W(L_S)=S$ 且 $V(L_S)=\operatorname{freeEval}(S)$。将其应用于自由差表 $\Delta T=\mathsf{computedAfter}(\widehat w)-\mathsf{before}(\widehat w)$，定义 $\mathsf{actualCertificate}:=\mathsf{cert}(L_{\Delta T})$ 与 $v_{\mathrm{paid}}:=\operatorname{freeEval}(\Delta T)$，立得正文式 (90) $\Delta T-[v_{\mathrm{paid}}]=\operatorname{relationMap}(\mathsf{actualCertificate})$。由此构造 `ExistsEvidence` 反演见证 `actualInverse`，消元所得还原表满足：
   $$\mathsf{restoredTable}=\mathsf{before}(\widehat w)+[v_{\mathrm{paid}}]+\operatorname{relationMap}(\mathsf{actualCertificate})=\mathsf{before}(\widehat w)+\Delta T=\mathsf{computedAfter}(\widehat w)=\mathsf{newConstants},\tag{S.18}$$
   且由求值自然性证出 $v_{\mathrm{paid}}$ 精确等于当次残差请求的实际已付求值（`actual_paid_value`）及逆纤维值（`actual_inverse_value`）。

<a id="supplement-d-8"></a>
### D.8　按执行步连续切片防漏重与封存历史锁前缀续账（WA44–WA45）

**按执行步区间成批归账与防漏重门禁（`Origin.lean`、`StepInterval.lean`、`StepInterval/Whole.lean`、`NextReceiptStepJointWhole.lean`、`Gate.lean`，WA44）。** 设事件序列为 $E=[e_0,\dots,e_{m-1}]$，起点偏移为 $s_0\in\mathbb N$，单事件展开项列表为 $\mathrm{items}(e)\in\operatorname{List}(\mathrm{Expr}\times\mathbb Z)$，`requestsFrom(s_0, E)` 按事件顺序拼接生成总请求列表 $R_{\mathrm{batch}}$。

1. **反向请求溯源（`readRequestOrigin`）**：令前 $k$ 个事件的累计请求表为 $P_k:=\mathrm{requestsFrom}(s_0,E.\mathrm{take}\,k)$，单块切片为 $Q_k:=\mathrm{requestsFrom}(s_0+k,(E[k]?).\mathrm{toList})$，满足逐步递推 $P_{k+1}=P_k\mathbin{++}Q_k$ 及 $P_m=R_{\mathrm{batch}}$。对任意请求全局下标 $r\in\operatorname{Fin}(|R_{\mathrm{batch}}|)$，有序分区定位算子 `locatePart` 唯一给出事件块下标 $b\in\operatorname{Fin}(m)$ 与块内局部下标 $\ell\in\operatorname{Fin}(|\mathrm{items}(e_b)|)$，满足全局地址分解与前缀分解：
   $$r=|P_b|+\ell,\qquad R_{\mathrm{batch}}.\mathrm{take}\,r=P_b\mathbin{++}\bigl((\mathrm{items}(e_b).\mathrm{take}\,\ell).\operatorname{map}(\mathrm{form}_b)\bigr).\tag{S.19}$$
2. **正向步骤区间与双向互认（`stepInterval`、`sourceRequestAt_interval_address`）**：对执行记录中第 $i\in\operatorname{Fin}(m)$ 步作用词 $w_i$，将事件列表拆为 $E=(E.\mathrm{take}\,i)\mathbin{++}[e_i]\mathbin{++}(E.\mathrm{drop}\,(i+1))$，映射得 $R_{\mathrm{batch}}=\mathrm{prior}_i\mathbin{++}\mathrm{own}_i\mathbin{++}\mathrm{later}_i$。令 $\mathrm{first}_i:=|\mathrm{prior}_i|$、$\mathrm{count}_i:=|\mathrm{own}_i|=|\mathrm{sourceItems}(w_i)|$，由列表截断恒等式 `(prior ++ own ++ later).drop |prior| |>.take |own| = own` 得连续切片 $G_i=\mathrm{own}_i$，且切片内解码请求词之和等于单元素关系请求和 $\mathrm{affine}_{\rho_{\mathrm{dec}}}(w_i)$。将式 (S.19) 前缀长度与前驱块长度消去即证 $r=\mathrm{first}_{i(r)}+s(r)$。
3. **整批折叠与非空组防漏重负控**：对任意 $(\mathcal F,P,\mathcal E)$，对事件列表归纳证出 $\operatorname{flatten}([G_0,\dots,G_{m-1}])=R_{\mathrm{batch}}$（`grouped_requests`，空切片在原序号处保持为空列表 $G_i=[\,]$ 不移位）；由 `executedTrace` 对拼接的同态性得 $\operatorname{flatten}(\operatorname{map}(\mathrm{exec},\mathcal G))=\mathrm{exec}(R_{\mathrm{batch}})$（`grouped_executed_trace`）；在正文第 14.1 节条件右半平面零点输入域（适用同一空真边界声明）的预解—价格方法实例上，由有限和结合律与线性重标运输得各步余链之和等于 $\Gamma$ 后继空间联合边界 $\sum_{i=0}^{m-1}\mathsf{stepCochain}(i)=\partial_{\mathrm{joint}}$（`actual_grouped_joint_boundary`）。任取一条真实请求 $r\in\operatorname{Fin}(|R_{\mathrm{batch}}|)$，因块内下标满足 $0\le s(r)<\mathrm{count}_{i(r)}=|G_{i(r)}|$，该组非空，从而其执行迹 $\mathrm{own}=\mathrm{exec}(G_{i(r)})$ 满足 $|\mathrm{own}|>0$；将已写总库存迹写为 $\mathrm{trace}=\mathrm{before}\mathbin{++}\mathrm{own}\mathbin{++}\mathrm{after}$，利用正长度列表拼接的严格长度不等式 $|\mathrm{before}|+|\mathrm{after}|<|\mathrm{trace}|<|\mathrm{before}|+2|\mathrm{own}|+|\mathrm{after}|$，立证漏记（$\mathrm{before}\mathbin{++}\mathrm{after}$）与重记（$\mathrm{before}\mathbin{++}\mathrm{own}\mathbin{++}\mathrm{own}\mathbin{++}\mathrm{after}$）均严格不等于 $\mathrm{trace}$（对应 `Gate.lean::actual_nonempty_group_rejects_omission_and_duplication`）。

**封存历史前缀锁死延长与单遍投影时间线（`NativeHistoryContinuation.lean`、`StoredHistory.lean`、`StoredTimeline.lean`，WA45）。**

1. 对确定性询问运行器 `runtime`，归纳历史类型 $\mathsf{HistoryAt}(F,s)$ 仅有 `exhausted`（$F=0$）与 `step activated tail`（$F+1$）两个构造子。对 $F$ 归纳立即证出唯一性引理 $h=\mathrm{runFrom}(F,s)$，以及存储查找 `storedOccurrenceAt` 与计算查找 `occurrenceAt` 逐位相等。续行算子 `continueFor(h, E)` 对 $F$ 递归：在 `step` 处原样保留已存激活 `activated` 并递归处理尾部，仅在基底 $F=0$ 处读取已存末态 $s_{\mathrm{tail}}$ 执行 $\mathrm{runFrom}(E,s_{\mathrm{tail}})$。对任意 $T\ge F$，令 $\mathsf{extendTo}(h,T)$ 为 `continueFor(h, T-F)` 沿 $(T-F)+F=T$ 的类型转型，则：
   $$\bigl(\mathsf{extendTo}(h,T)\bigr).\mathsf{prefix}(F)=\bigl(\mathrm{runFrom}(T,s)\bigr).\mathsf{prefix}(F)=\mathrm{runFrom}(F,s)=h.\tag{S.20}$$
2. 对微步历史 $H:\mathsf{SourceNativeLivingRootHistoryAt}(F,s_0)$，`storedPairAt(H, i)` 读取第 $i\in\operatorname{Fin}(F)$ 步转移的相邻保存状态对，归纳证出 `stored_pair_actual`：$H.\mathrm{storedPairAt}(i)=(\mathrm{advance}(i).\mathrm{state},\mathrm{advance}(i+1).\mathrm{state})$。单遍收集器 `collect` 利用 `Nat.dfoldRev` 顺序将每步起始态压入预分配容量 $F+1$ 的动态数组并在末尾压入终态，生成定长向量 $\mathcal T=\mathrm{storedTimeline}(\mu,H)\in\operatorname{Vector}(A,F+1)$。对 $F$ 与累加数组归纳证出相邻格恒等式 `stored_timeline_adjacent`：$(\mathcal T[i],\mathcal T[i+1])=(\mu(s_i),\mu(s_{i+1}))$。将环境同态 $\mathcal E$ 作用于 $(\mathcal T[i],\mathcal T[i+1]-\mathcal T[i])$ 并送入 `updateInventory`，立得正文式 (96) $\mathsf{timelineInventory}(\mathcal T,i)=\mathsf{stageInventory}(\mathrm{advance}(i))$。

---

<a id="supplement-e"></a>
## E　长计算窗口的前置预解梳算子源程序接口

<a id="supplement-e-1"></a>
### E.1　预解梳算子封闭门面安装与精确执行迹供料（WA33）

对正文第 14.1 节界定的右半平面非平凡零点观察条件输入，非平凡坐标与右半平面证明纤维内生给出初始向量 $q_0$、单步预解梳线性算子 $R$ 以及精确迭代阶数 $m\in\mathbb N$。在仅装入 $q_0$ 的单变量环境中，递归构造线性迭代语法树 $e_0=\operatorname{var}x$、$e_{k+1}=R(e_k)$：对 $k$ 归纳立得求值 $\operatorname{ev}(e_k)=R^k q_0$ 与节点语法费 $r(e_k)=k+1$。因此，规范求值器在 $k=m$ 处内生输出目标有偿状态、准确完成值 $R^m q_0$ 以及长度恰为 $m+1$ 的完整执行迹。

将该计算读口作为语义投影分量在发射器前安装于 `runtimeEffectAuthoritySource`，封闭运行门面 `RuntimeEffectFace` 在同一发生处直接提取该完成结果（`runtimeCombCalculationReadoutAt_factorizes`），使目标状态、关系收据边界、任意真实增量下的逆纤维与更新余链共同消费这同一条长度 $m+1$ 的执行迹；底层物理账根、发射器与配对 $\Omega$ 后继由投影安装交换式原样保留（$m+1$ 为语法节点责任尺度，物理单步演化另持自身账面回执）。该完成值 $v=R^m q_0$ 进一步生成常量环境增量与下一残差请求 $R^m(v)-v$，为正文第 14 节的有限窗口与逆残差纠正链提供源内认证的前置供料。

## 参考文献

<a id="ref-1"></a>
[1] 高健（Jian Gao）. 《状态不是历史，源才是：过程同一性、责任承接与最小修订》／*The State Is Not the History, the Source Is: Identity, Responsibility, and Minimal Revision in Processes*. 第二版，2026. DOI: [10.5281/zenodo.23297175](https://doi.org/10.5281/zenodo.23297175). 正文与完整证明补充。
