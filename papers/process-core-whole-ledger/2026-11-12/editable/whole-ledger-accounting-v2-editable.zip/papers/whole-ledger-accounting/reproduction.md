# 本地阅读版与形式化来源（v2 与冻结 v1）

## 第二版（v2）阅读与可编辑材料

第二版四份阅读审校 PDF 位于 `build/reading-review-v2/`：`whole-ledger-accounting.pdf`、`whole-ledger-accounting-en.pdf`、`whole-ledger-accounting-supplement.pdf`、`whole-ledger-accounting-supplement-en.pdf`，配套可编辑源码包 `whole-ledger-accounting-v2-editable.zip`。第一版已发表成品与历史阶段存档（`build/zenodo-20261017/`、`build/conditional-input-20261014/`、`build/h0-bound-20261014/`、`build/cold-read-20261013/`、`build/first-release-20261013/`、[第一版成品清单](release-artifacts.json)与[验收记录](release-validation-20261017.json)）原字节保留不变。

从 publish 根目录复现第二版图件、四份 PDF 与可编辑源码包：

```sh
python3 papers/whole-ledger-accounting/figures/render_v2.py
python3 papers/whole-ledger-accounting/figures/render_v2.py --english
python3 shared/scripts/build_pdf.py \
  papers/whole-ledger-accounting/manuscript.md \
  papers/whole-ledger-accounting/manuscript-en.md \
  papers/whole-ledger-accounting/supplement.md \
  papers/whole-ledger-accounting/supplement-en.md \
  --output-dir papers/whole-ledger-accounting/build/reading-review-v2
python3 papers/whole-ledger-accounting/scripts/package_release.py \
  --output-dir papers/whole-ledger-accounting/build/reading-review-v2
```

需要 Python 3、Pandoc 3、XeLaTeX、xeCJK／unicode-math、Google Chrome、Noto Serif/Sans CJK SC、`fontTools` 与 `pdftoppm`。

一键核对双语公式与锚点镜像、编号环境、英文标点卫生、行内代码 ASCII 纯净性、WA1–WA45 全部固定源码文件 SHA-256／声明签名、H0 公开绑定及第一版冻结成品原字节：

```sh
python3 papers/whole-ledger-accounting/scripts/check_release.py --homework /path/to/Homework --h0 /path/to/H0mework
```

## 固定研究来源（WA1–WA45）

WA1–WA45 的逐项双语书面位置、原声明与公开目标由 [release-selection-v2.json](release-selection-v2.json) 维护（第一版 WA1–WA40 冻结选集保留于 [release-selection.json](release-selection.json)）。Homework 固定研究源各守真实纪元：

- **Y** = `b81a443863f4d7135ebaca92c5bb7d208ccc18ca`（WA1–WA11，含全事件库存准入、生命周期三律、容量短缺正阻滞第四核 `ResponsibilityCapacityKernel`、观察安全、拆并重构、良基双钥匙结清、修订首写、定目标 6 与全局整算术余核；例 11.7 构建链用直接子提交 Y1）；
- **Z / AA / AB / AC / AD / AE / PR / MF / MV2 / MV3**（WA12–WA37，各有偿语法执行、整数系数与替换重放、跨语言类型化库存、总值写回、共尾停点与最大未来不可见核固定提交逐项列于选集）；
- **MV4** = `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`（WA38–WA40，全未来残差内生请求、正信用同债严格扣款、后缀四读口完成与右半零点条件长窗口纠正）；
- **MV5** = `df421ff600085cbc290a7ae946193961bed7c83b`（WA41–WA43，双负号恢复已付语法树跨共尾同态续行、整词逐原语余链微分回放与自由常量表零求值显式整数证书反演）；
- **C53–C54 固定提交** = `7e4da746f300b3796b8b18afb26cb0765c29afcb`（WA44–WA45，按执行步连续区间成批归账防漏重门禁与封存确定性历史前缀锁死末态续账）。

从本地源仓副本按固定提交读取任一源码对象：

```sh
git -C /path/to/Homework show SOURCE_COMMIT:SOURCE_PATH
```

## H0mework 公开代码包

[固定提交](https://github.com/Sapientropic/H0mework/tree/5f94af7e988c9831c92e54fe89747699fa29cd85) `5f94af7e988c9831c92e54fe89747699fa29cd85` 包含 WA1–WA45 的完整公开证明。[首版指南](https://github.com/Sapientropic/H0mework/blob/4301fa8c5bb19bb1e8c3824d7c69be406264ed12/docs/whole-ledger-reproduction.md)
保留 WA1–WA40 的原验收与构建入口。[第二版映射](https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/whole-ledger-v2-map.json)和[本地回执](https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/whole-ledger-v2-readiness.md)
登记容量核、WA41–WA45、原回执及新增证明包。工具链为 Lean 4.33.0 与 Mathlib v4.33.0。

从 H0mework 根目录复验。

```sh
make bootstrap
python3 tools/whole_ledger_v2.py entry
python3 tools/whole_ledger_v2.py build --output .local/whole-ledger-v2-build
python3 tools/whole_ledger_v2.py trust --output .local/whole-ledger-v2-trust
python3 tools/whole_ledger_v2.py types --output .local/whole-ledger-v2-types
```

[复现指南](https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/whole-ledger-v2-reproduction.md)给出按包检查和源码逆恢复命令。
