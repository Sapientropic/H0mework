# Provenance-Preserving Conservation Calculus and Non-Free Continuity · editable v2

The bilingual v2 main manuscripts (Sections 1-16 and Appendices A-B), bilingual v2
proof supplements (Sections A-E), twelve editable v2 vector figures (six bilingual
plates), PNG previews, the v2 figure generator, bibliography, metadata, and the
complete WA1-WA45 selection preserve the directory layout required by the shared
builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome, and Noto Serif/Sans CJK SC. Build all four v2 PDFs:

    python3 shared/scripts/build_pdf.py papers/whole-ledger-accounting/manuscript.md papers/whole-ledger-accounting/manuscript-en.md papers/whole-ledger-accounting/supplement.md papers/whole-ledger-accounting/supplement-en.md --output-dir papers/whole-ledger-accounting/build/zenodo-20261112-v2

With fontTools, Google Chrome, and pdftoppm installed, regenerate all v2 figures:

    python3 papers/whole-ledger-accounting/figures/render_v2.py
    python3 papers/whole-ledger-accounting/figures/render_v2.py --english

Public formal proofs and reproduction scripts for WA1-WA45 are bound to H0mework
commit 5f94af7e988c9831c92e54fe89747699fa29cd85. Follow the fixed reproduction guide at
https://github.com/Sapientropic/H0mework/blob/5f94af7e988c9831c92e54fe89747699fa29cd85/docs/whole-ledger-v2-reproduction.md.
The earlier WA1-WA40 material commit is f607eb646d4e9cddba3512755365842895af44ca. Fixed Homework source
commits for WA41-WA43 (df421ff600085cbc290a7ae946193961bed7c83b) and WA44-WA45
(7e4da746f300b3796b8b18afb26cb0765c29afcb) together with per-file SHA-256 digests,
declaration signatures, and bilingual anchors are bound in `release-selection-v2.json`.

Prior v1 preprint (*Book-Balancing Magic Has Nowhere to Hide: Source-Native
Accounting and Actual Continuation*): DOI 10.5281/zenodo.23437454. Paper text,
proof supplements, and original figures use CC BY 4.0; code uses Apache-2.0.
