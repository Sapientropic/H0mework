#!/usr/bin/env python3
"""Write Zenodo upload metadata for the eight drafted papers.

Usage: zenodo_metadata.py [--only DIR[,DIR...]]

Each paper gets <paper dir>/zenodo-metadata.md with the web-form fields in the
order Zenodo's upload page asks for them. Titles, abstracts and keywords are
read from the manuscripts, so rerunning after an edit keeps them in step; the
PDFs listed are the current reading editions under each paper's build/.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CODE = "https://github.com/Sapientropic/H0mework"
TAG = "papers-2026-09"
CREATOR = ("Gao, Jian", "0009-0009-5002-1655", "Independent Researcher")

# directory, zh manuscript, en manuscript (None: Chinese text with an English
# abstract), reading PDFs to upload (first one is the primary file)
PAPERS = [
    ("source-process-core", "manuscript.md", "manuscript-en.md",
     ["build/source-process-core-en.pdf", "build/source-process-core.pdf",
      "build/source-process-core-supplement-en.pdf", "build/source-process-core-supplement.pdf"]),
    ("physics-common-source", "manuscript.md", "manuscript-en.md",
     ["build/physics-common-source-en.pdf", "build/physics-common-source.pdf",
      "build/physics-common-source-supplement-en.pdf", "build/physics-common-source-supplement.pdf"]),
    ("low-energy-phenomenology", "manuscript.md", None, ["build/low-energy-phenomenology.pdf"]),
    ("low-energy-loop-response", "manuscript.md", None, ["build/low-energy-loop-response.pdf"]),
    ("constrained-local-quantum", "manuscript.md", None, ["build/constrained-local-quantum.pdf"]),
    ("native-flow/review-20260922-65001", "manuscript.md", None, ["build/native-flow.pdf"]),
    ("whole-ledger-accounting", "manuscript.md", None, ["build/whole-ledger-accounting.pdf"]),
    ("observation-dynamics", "manuscript.md", None, ["build/observation-dynamics.pdf"]),
]


def section(text: str, heading: str) -> str:
    m = re.search(r"(?ms)^#{1,3} " + heading + r"[^\n]*\n(.*?)(?=^#{1,3} |\Z)", text)
    if not m:
        raise SystemExit(f"no {heading} section")
    return m[1]


def split_keywords(block: str) -> tuple[str, list[str]]:
    m = re.search(r"(?m)^\*\*(?:关键词|Keywords)\s*[:：]?\*\*\s*[:：]?\s*(.+)$", block)
    body = block[:m.start()] if m else block
    words = [w.strip(" 。.") for w in re.split(r"[；;]", m[1])] if m else []
    paras = [re.sub(r"\s+", " ", p).strip() for p in re.split(r"\n\s*\n", body)]
    return "\n\n".join(p.replace("**", "") for p in paras if p), [w for w in words if w]


def english_title(text: str) -> str:
    for line in text.splitlines()[1:8]:
        m = re.fullmatch(r"(?:#{1,2} +(.+)|\*\*(.+)\*\*|\*(.+)\*)", line.strip())
        if m:
            t = next(g for g in m.groups() if g)
            if re.match(r"[A-Za-z]", t) and "COURTYCOURT" not in t.upper():
                return t
    raise SystemExit("no English title")


def pages(pdf: Path) -> int:
    info = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
    return int(re.search(r"Pages:\s+(\d+)", info)[1])


def write(paper: str, zh_name: str, en_name: str | None, pdfs: list[str], *,
          version: str = "v1", pdf_dir: str | None = None,
          output_name: str = "zenodo-metadata.md") -> Path:
    base = ROOT / "papers" / paper
    zh = (base / zh_name).read_text()
    title_zh = zh.splitlines()[0][2:].strip()
    title_en = english_title(zh)
    series = "CourtyCourt · The Theory Takes the Stand" if "COURTYCOURT" in zh[:600].upper() else ""
    abstract_zh, kw_zh = split_keywords(section(zh, "摘要"))
    if en_name:
        abstract_en, kw_en = split_keywords(section((base / en_name).read_text(), "Abstract"))
        languages = "English (eng), Chinese (zho) — English and Chinese editions"
    else:
        abstract_en, kw_en = split_keywords(section(zh, "Abstract"))
        languages = "Chinese (zho) — full text in Chinese with an English abstract"
    files = []
    for rel in pdfs:
        if pdf_dir:
            rel = str(Path(pdf_dir) / Path(rel).name)
        pdf = base / rel
        files.append(f"- `{pdf.relative_to(ROOT)}`（{pages(pdf)} 页）")
    out = base / output_name
    binding_pattern = (r"H0mework 第二版材料提交 `([0-9a-f]{40})`" if version == 'v2'
                       else r"H0mework 固定提交 `([0-9a-f]{40})`")
    binding = re.search(binding_pattern, zh)
    if version == 'v2' and binding is None:
        raise SystemExit(f'{paper}: second-edition code binding missing')
    code_relation = f"{CODE}/tree/{binding[1] if binding else TAG}"
    prior_dois = {"source-process-core": "10.5281/zenodo.23210084",
                  "physics-common-source": "10.5281/zenodo.23210292"}
    prior_doi = prior_dois.get(paper) if version == "v2" else None
    doi_instructions = (f"从第一版 https://doi.org/{prior_doi} 的记录创建 New version 草稿；"
                        "新版本 DOI 由 Zenodo 分配，不把第一版的版本 DOI 填作第二版 DOI。"
                        "本文件仅为本地上传准备，尚未创建草稿或公开第二版。"
                        if prior_doi else
                        "已有本文的 DOI 时填写原 DOI；没有时选择 No，并可用 Get a DOI now! 在草稿中预留。"
                        "DOI 在记录发布时注册。操作见 [Zenodo DOI 指南]"
                        "(https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/)。")
    prior_relation = (f"\n- Relation：Is new version of；Identifier：{prior_doi}；"
                      "Scheme：DOI；Resource type：Publication → Preprint" if prior_doi else "")
    generator_command = ("python3 shared/scripts/zenodo_metadata.py" if version == 'v1' else
                         f"python3 shared/scripts/zenodo_metadata.py --only {paper} --version v2"
                         + (f" --pdf-dir {pdf_dir}" if pdf_dir else ""))
    out.write_text(f"""# Zenodo 上传元数据

由 `{generator_command}` 从正文生成；改稿后重新生成。字段按 Zenodo 上传页的顺序排列，逐项复制。发布前保存草稿并预览；发布后的更正与删除规则见 [Zenodo 记录管理](https://help.zenodo.org/docs/deposit/manage-records/)，修订文件使用 [版本管理](https://help.zenodo.org/docs/deposit/manage-versions/)。

## Files（上传）

{chr(10).join(files)}

## Resource type

Publication → Preprint

## Digital Object Identifier (DOI)

{doi_instructions}

## Title

{title_en}

## Additional titles

- Translated title（Chinese）：{title_zh}

## Publication date

填写本版本首次公开的日期。草稿默认值是创建日，发布时核对；见 [Zenodo 上传指南](https://help.zenodo.org/docs/deposit/create-new-upload/)。

## Creators

- Person：{CREATOR[0]}
- ORCID：{CREATOR[1]}
- Affiliation：{CREATOR[2]}
- Role：（留空；独著）

## Description

{abstract_en}

## Additional descriptions

- Type：Abstract；Language：Chinese

{abstract_zh}

## Licenses

Creative Commons Attribution 4.0 International（CC BY 4.0）。代码仓另为 Apache-2.0。

## Keywords and subjects

{"; ".join(kw_en)}

## Languages

{languages}

## Version

{version}

## Related works

- Relation：Is supplemented by；Identifier：{code_relation}；Scheme：URL；Resource type：Software{prior_relation}

## Notes（可选）

{("Part of the series " + series + ". ") if series else ""}Formal proofs, exact programs and frozen receipts are in the code repository above; the paper's "Code and data availability" section gives the entry modules and reproduction commands.
""")
    return out


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", default="", help="Comma-separated paper directories")
    parser.add_argument("--version", choices=("v1", "v2"), default="v1")
    parser.add_argument("--pdf-dir", help="Version directory relative to each paper")
    parser.add_argument("--output-name", help="Metadata filename; v2 defaults to zenodo-metadata-v2.md")
    args = parser.parse_args()
    only = {d for d in args.only.split(",") if d}
    output_name = args.output_name or ("zenodo-metadata-v2.md" if args.version == "v2" else "zenodo-metadata.md")
    for spec in PAPERS:
        if only and spec[0] not in only:
            continue
        print("wrote", write(*spec, version=args.version, pdf_dir=args.pdf_dir,
                             output_name=output_name).relative_to(ROOT))
