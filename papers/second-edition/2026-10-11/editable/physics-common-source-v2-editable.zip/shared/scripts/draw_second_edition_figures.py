#!/usr/bin/env python3
"""Draw the two second-edition mechanism plates without replacing v1 art.

These are structural diagrams of the written proofs, not measured curves.
Usage: python draw_second_edition_figures.py [--lang zh|en]
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "shared/figure-style"))
from house_style import INK, SLATE, HAIR, DEEP, VERMILION, WASH, install


def canvas(height: float):
    fig, ax = plt.subplots(figsize=(10.2, height * .85))
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, 12), ylim=(0, height))
    ax.axis("off")
    return fig, ax


def label(ax, x, y, text, size=12, color=INK, ha="center", **kwargs):
    return ax.text(x, y, text, fontsize=size, color=color, ha=ha,
                   va="center", linespacing=1.4, **kwargs)


def box(ax, x, y, w, h, text, *, accent=False, size=12):
    color = VERMILION if accent else DEEP
    ax.add_patch(Rectangle((x, y), w, h, facecolor=WASH if accent else "white",
                           edgecolor=color, linewidth=1.1))
    label(ax, x+w/2, y+h/2, text, size, color=color)


def arrow(ax, p, q, *, color=SLATE, connection=None):
    kwargs = {"connectionstyle": connection} if connection else {}
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=11,
                                color=color, linewidth=1.1, shrinkA=2,
                                shrinkB=2, **kwargs))


def core(lang):
    zh = lang == "zh"
    fig, ax = canvas(6.2)
    label(ax, .45, 5.93, "A  同一收据，完整总值" if zh else "A  One receipt, the complete value",
          12.5, SLATE, ha="left")
    box(ax, .45, 4.65, 2.4, .92,
        ("本次材料" if zh else "This receipt") + "\n" + r"$(\rho,\varepsilon,e,p)$")
    box(ax, 3.35, 4.65, 2.7, .92,
        ("有费执行直到结清" if zh else "Paid execution to settlement") + "\n" + r"$n=\operatorname{ev}_{\rho+\varepsilon}(e-p)$",
        size=11.5)
    box(ax, 6.55, 4.65, 2.15, .92, r"$V=p+n$" + "\n" +
        ("本收据总值" if zh else "This receipt's total"), accent=True)
    box(ax, 9.2, 4.65, 2.35, .92,
        ("新解码与出生" if zh else "Fresh decoder and birth") + "\n" + r"$\operatorname{write}(V)$", size=11.5)
    for a, b in [(2.85, 3.35), (6.05, 6.55), (8.7, 9.2)]:
        arrow(ax, (a, 5.11), (b, 5.11))
    label(ax, 6, 4.23, r"$p=\operatorname{ev}_{\rho}(e),\qquad V=\operatorname{ev}_{\rho+\varepsilon}(e)$", 13)
    ax.plot([.65, 11.25], [3.73, 3.73], color=HAIR, linewidth=1.2)
    for x in [1.1, 2.3, 3.5, 4.7, 5.9, 7.1, 8.3]:
        ax.plot(x, 3.73, "o", markersize=3.6, color=DEEP)
    ax.plot(9.8, 3.73, "o", markersize=5, color=VERMILION)
    label(ax, 4.8, 3.4, "全部中间 paid 拍保留 State、Trace 与 owner" if zh
          else "Every intermediate paid tick keeps State, Trace and owner", 11.5, SLATE)
    label(ax, 10.05, 3.4, "结清才出生" if zh else "Birth at settlement", 11, VERMILION)
    arrow(ax, (10.3, 4.65), (10.3, 4.0), color=VERMILION)
    label(ax, .45, 2.91, "B  计算实例：实际值写入下一环境" if zh
          else "B  Calculation instance: the actual value enters the next environment",
          12.5, SLATE, ha="left")
    box(ax, .45, 1.72, 2.4, .86, r"$v=R^m q_0$" + "\n" +
        ("完整计算结果" if zh else "Complete calculation"))
    box(ax, 3.35, 1.72, 4.0, .86, r"$\delta_v=\operatorname{constEnv}(v)-\rho$" + "\n" +
        r"$\rho+\delta_v=\operatorname{constEnv}(v)$", accent=True, size=12)
    box(ax, 7.85, 1.72, 3.7, .86, r"$u=Rv=Pu+(1-P)u$" + "\n" +
        ("先执行完整 u，再拆两腿" if zh else "Execute the whole u, then split"), size=11.7)
    arrow(ax, (2.85, 2.15), (3.35, 2.15))
    arrow(ax, (7.35, 2.15), (7.85, 2.15))
    label(ax, 6, 1.15, "下一收据重新生成自己的旧值；解码器跟随这张收据" if zh
          else "The next receipt generates its own old value; the decoder follows that receipt",
          12, DEEP)
    label(ax, 6, .58, "箭头为实际构造与读回；横带为同一运行时的 paid 历史" if zh
          else "Arrows: construction and readback. Ribbon: paid history in the same runtime",
          10.8, SLATE)
    return fig


def physics(lang):
    zh = lang == "zh"
    fig, ax = canvas(7.7)
    box(ax, .5, 6.5, 11, .8,
        ("同一原作用、实际发生与准备态：完整 289 方向" if zh
         else "One original action, actual event and preparation: all 289 directions") + "\n" + r"$d,\ F,\ p$",
        accent=True, size=13)
    arrow(ax, (3.25, 6.5), (3.25, 5.98))
    arrow(ax, (8.75, 6.5), (8.75, 5.98))
    label(ax, 3.25, 5.75, "A  非线性微分与正则反馈" if zh
          else "A  Nonlinear derivative and regular feedback", 12.5, DEEP)
    label(ax, 8.75, 5.75, "B  transfer0 的解析红外域" if zh
          else "B  Analytic infrared domain at transfer0", 12.5, DEEP)
    ax.plot([6, 6], [1.3, 5.9], color=HAIR, linewidth=.9)
    box(ax, .5, 4.55, 5.15, .9,
        ("常场真正非线性 Noether 半轴" if zh else "Constant-field nonlinear Noether half-axis") + "\n" +
        r"$\operatorname{Re}\lambda>0,\quad C^2\ \longrightarrow\ \Pi_{\rm st}$", size=12)
    box(ax, 6.35, 4.55, 5.15, .9,
        ("两频时钟、五因子与源生复邻域" if zh else "Two-frequency clock, five factors, source disk") + "\n" +
        r"$\mathrm{transfer}=0,\quad\operatorname{Re}z>0$", size=12)
    box(ax, .5, 3.16, 5.15, .94,
        r"$\operatorname{Re}\lambda>\gamma_{\rm clk},\quad Q_d=(\lambda-P_0)\Pi_\infty$" + "\n" +
        r"$\det(I-GQ_d)\ne 0$", size=12)
    box(ax, 6.35, 3.16, 5.15, .94,
        r"$z^4\Pi_{\rm st}(0,z)=G_4(z)$" + "\n" +
        (r"$G_4$ 在零点邻域解析" if zh else r"$G_4$ is analytic in a neighborhood of zero"), size=12)
    box(ax, .5, 1.77, 5.15, .94,
        ("全部九约束的相容方程" if zh else "Compatibility equations for all nine constraints") + "\n" +
        r"$[H_{289}-Q_d]x=f$", size=12)
    box(ax, 6.35, 1.77, 5.15, .94,
        r"$z^4\Pi_{\rm st}(0,z)\longrightarrow G_4(0)$" + "\n" +
        r"$z^6\Pi_{\rm st}(0,z)\longrightarrow 0$", size=13)
    for x in (3.08, 8.93):
        arrow(ax, (x, 4.55), (x, 4.1))
        arrow(ax, (x, 3.16), (x, 2.71))
    label(ax, 3.08, 1.34, "同 Green 读回原场与曲率" if zh
          else "The same Green reads back the field and curvature", 11.4, DEEP)
    label(ax, 8.93, 1.34, "全 289×289 原矩阵" if zh
          else "The complete original 289 by 289 matrix", 11.4, DEEP)
    label(ax, 6, .84, "两域分别证明；红外极限不提供正则域的 Schur 逆" if zh
          else "The two domains are proved separately; the IR limit does not supply a regular Schur inverse",
          11.5, SLATE)
    label(ax, 6, .35, "箭头为同对象的构造依赖；横向位置不代表 λ 的数值尺度" if zh
          else "Arrows: construction dependencies on the same object. Position is not a scale of lambda",
          10.7, SLATE)
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lang", choices=("zh", "en"), default="zh")
    args = parser.parse_args()
    install("second-edition-proof-chains", args.lang)
    suffix = "-en" if args.lang == "en" else ""
    for paper, stem, draw, claims in [
        ("source-process-core", "figure7-receipt-feedback-v2", core, ["C35-C45"]),
        ("physics-common-source", "fig7-two-domains-v2", physics, ["P37-P38"]),
    ]:
        out = ROOT / "papers" / paper / "figures/vector"
        out.mkdir(parents=True, exist_ok=True)
        fig = draw(args.lang)
        paths = []
        for extension in ("svg", "pdf", "png"):
            path = out / f"{stem}{suffix}.{extension}"
            fig.savefig(path, dpi=200, metadata={"Creator": "publish second-edition figures"}
                        if extension == "pdf" else None)
            paths.append(path)
        plt.close(fig)
        record = {"kind": "proof-mechanism diagram", "language": args.lang,
                  "source_cap": "9c73a630ce05bea062ec889b188f5105c0afb796",
                  "claim_refs": claims,
                  "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "artifacts": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
                  "visual_review": "pending"}
        (out / f"second-edition-figure-checks{suffix}.json").write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n")
        print(paper, args.lang, "three independent v2 files written")


if __name__ == "__main__":
    main()
