# Supplementary material: complete proofs

**We Found No Magic in This Mighty Universe: Common-Source Generation and Classical–Quantum Correspondence in a Spin×SU(7) Theory**

**Author: Jian Gao (高健)**

This supplement supplies complete written proofs and verification accounts for §6.7–§6.15 (including Theorems 6.8a, 6.9a, 6.10a, 6.12a and 6.13a–b), Propositions 9.1–9.4, the end of §6.9 and related results of §9.2. S1–S9 retain the first-release proofs; S11–S15 derive the second-edition results in this paper; S10 maps both editions. The main text states the results and gives proof ideas; here each result is given its objects and domain, actual inputs and quantifiers, construction, key lemmas, decisive derivation, and the direct use of the same object in later results, and is finally matched to its formal declaration or frozen receipt. Notation is that of the main text, and numbers of definitions, theorems and equations refer to the main text. The proofs of §2–§5, §6.1–§6.6, §7 and §8 are complete in the main text and Appendices A–C and are not repeated.

The “formal correspondence” at the end of each section lists the Lean declarations or frozen receipts that carry the result; the source commits, full paths and receipt identities are in Appendices D.7–D.8 of the main text, and the public reproduction entry is in its “Code and data availability”. The pinned-commit aliases AB, AC, AD, AE, CAP, H, F are defined in Appendix D.1 and D.7–D.8; this supplement only checked the pinned source files and rebuilt, compiled or ran nothing.

The second-edition fixed-source aliases are **71e** = Homework `71e94e8261d67cf4849a05eb14ac95aa2f7dcbb9` and **9c73** = Homework `9c73a630ce05bea062ec889b188f5105c0afb796`. Each section S11–S15 identifies its actual producer and direct consumer; scientific receipts retain their own earlier commits (S15.5). The constructions are proved here without outsourcing a decisive step to an unpublished companion paper.

Evidence identities come in five classes, marked item by item: **formal theorem** (a declaration verified by the Lean kernel), **finite exact computation** (a finite identity decided term by term in the proof kernel, with the deciding means reported faithfully), **fixed exact source program with independent recomputation** (an exact computation program at a pinned commit, each accompanied by an independent-implementation recomputation at the same commit), **dual-implementation numerical check** (frozen receipts produced separately by two independent implementations, with tolerances), and **statistical contract** (an anytime test with a pre-registered error rate). Physical interpretation and hardware identity are not enlarged under any class.

---

## S0 Common notation and tools

The following objects recur throughout; we define them once.

**S0.1 Configuration and test spaces.** Fixed source and original action (3.1). $\mathscr U_{103}=\mathscr U_q\times\mathscr U_x\times\mathbb R^{36}$ is the common noncharacteristic domain (the source-containing connected component of $v_e>0$, $\det h\ne0$, $g_{00}\ne0$, $h^{00}\ne0$, $\det D_9\ne0$ and the fourth-order time–electric block $\det\mathscr M\ne0$), and $\mathscr U_{100}$ is the three-stabilizer section (S1). $\mathcal I=\{+,-\}\times\{0,1,2,3\}\times(\Lambda^6\sqcup\Lambda^2\sqcup\Lambda^4)$ is the index set of 504 CAR modes, $\mathcal F_{504}=\Lambda^*\mathbb C^{504}$. The configuration Hilbert space $\mathscr H$ is given by the weighted $L^2$ direct sum of (S1.5); the quantum test space $\mathcal Q=C_c^\infty(\mathscr U_{100};\mathcal F_{504})$ is dense in it.

**S0.2 Cutoff compression and retained term.** For a cutoff index $F$ (a finite index of the Gauss unitary history), $C_F(p)$ denotes the self-adjoint compression at momentum $p$ of the complete native Hamiltonian $H_0$ to $F$; $A_F$ is the retained term of the uncut Yukawa; $K_F(p)=C_F(p)+A_F$ is the actual generator. $C_F$ preserves the $\Lambda^6$ occupation grading and $A_F$ raises it by one (S1.3). $T_p(t)=e^{-itK_F(p)}$, $R_p(z)=(K_F(p)-z)^{-1}$ ($z$ non-real). Cutoff indices are directed by inclusion; “for cofinal $F$” means on all $F$ beyond some terminal segment of the source filter.

**S0.3 Response point and five-factor kernel.** A **response point** $q$ carries: a cutoff index $F$, left/right matter momenta $p_L,p_R$, two non-real spectral parameters $z,w$ ($\operatorname{Im}z\ne0$, $\operatorname{Im}w\ne0$), a preparation precision $\varepsilon>0$, a finite window $T$ and a source field curve. The current read-port $J$ is the quantization of the mother action's first variation. The five-factor kernel is
$$\mathcal K_q(t)=T_{p_R}(-t)\,R_{p_R}(z)\,J\,R_{p_L}(w)\,T_{p_L}(t).\tag{S0.1}$$
$\mathbb C^{289}$ is the space of real directions of the nine field groups, and $H_{289}(p)$ is the Jacobi matrix at four complex momenta $p$ (S5).

**S0.4 Resolvent and Duhamel tools.** The resolvent of a self-adjoint operator $A$ satisfies $\|(A-z)^{-1}\|\le|\operatorname{Im}z|^{-1}$ ($z$ non-real), and the resolvent-difference formula $R_p-R_k=R_p(C_F(k)-C_F(p))R_k$. The unitary Duhamel formula $e^{-itB}-e^{-itA}=-i\int_0^te^{-i(t-s)B}(B-A)e^{-isA}ds$ is used in the operator-norm topology. The Bochner integral $\int_0^\infty e^{-\lambda t}\Phi_t\,dt$ converges for a uniformly bounded strongly continuous operator semigroup when $\operatorname{Re}\lambda>0$; for the two-leg action $\Phi_t(X)=T_{p+k}(-t)XT_p(t)$ it is defined componentwise.

**S0.5 How the finite exact identities are checked.** Many proofs here reduce to finitely many identities decided term by term in the proof kernel: e.g. the 3071-term dictionary of $H_{289}$ (coefficients in $\mathbb Q(\sqrt2,\sqrt{15})$), the 576-entry polynomial matrix product, and the explicit inverse of a 289-dimensional matrix. The deciding means are stated faithfully at each section's “decisive derivation”; three kinds are actually used: termwise equality of canonicalized term lists and dictionaries by `decide +kernel` (the kernel reduces both sides to the same canonical form); scalar equalities in the coefficient field $\mathbb Q(\sqrt2,\sqrt{15})$ by `ring`, `norm_num`, `field_simp`, `linear_combination`, `nlinarith` term by term; finite-dimensional matrix equalities, after indexwise expansion, by `decide +kernel` and `fin_cases` together with the scalar decisions. Such decisions are theorems, not numerical fits.

**S0.6 How the data-type declarations are checked.** The items of Propositions 9.1–9.3 marked “dual-implementation check” or “statistical contract” have their numerical conclusions produced separately by two programs that share no forward computation (the primary and the independent implementation), each producing a frozen first receipt which is then cross-checked; criterion files are frozen before execution, and statistical contracts pre-register a total error budget (e.g. the joint $\alpha=1/20$). Receipt identities are listed item by item in S9 and Appendix D.8.

---

## S1 Theorem 6.7: the common quantum Hamiltonian

**Objects and domain.** The fixed source and the original action (3.1) satisfying the noncharacteristic conditions of §4: $v_e>0$, $\det h\ne0$, $g_{00}\ne0$, $h^{00}\ne0$, $\det D_9\ne0$, $\det\mathscr M\ne0$ (see S0.1 and (3.2)–(3.6), (4.1)–(4.6) of the main text). The matter configuration is the complete 252-dimensional Dirac×colour symbol $\psi$ together with the independent dual $\chi$.

**Inputs and quantifiers.** All conclusions hold for every source neighbourhood satisfying the noncharacteristic conditions; “61”, “504”, “103”, “100”, “392” are fixed source-generated dimensions, not tunable parameters. The identity of item (3) holds for every four complex momenta $p$.

**Construction.** Four steps: the canonical one-form and CCR/CAR; the four energies on a common domain; the three-stabilizer section and measure; the action recognition.

**(1) The canonical carrier.**

*Legendre map.* The spatial Gram $h=e_{\rm sp}^{\mathsf T}\eta e_{\rm sp}$ gives the coframe six-velocity map
$$\Pi_e=M_e\dot e+b_e,\qquad Z^{\mathsf T}(\Pi_e-b_e)=0,\qquad \dot e=Q_e(\Pi_e-b_e)+Z\lambda,\tag{S1.1}$$
where $M_e=D_h^{\mathsf T}B_hD_h$ ($B_h=(4v_e)^{-1}\operatorname{Hess}_h\det h$), of rank six when $\det h\ne0$, and $Q_e=R_hB_h^{-1}R_h^{\mathsf T}$ is generated by an explicit right inverse rather than an arbitrary pseudoinverse; the ten primary constraints are given by the ten columns of $Z$ (four time columns and six Lorentz columns). The scalar map requires $h^{00}\ne0$: $\Pi_\phi=h^{00}(\dot\phi+\rho^{70}_{A_0}\phi)+b_\phi$. The gauge map requires $g_{00}\ne0$: $K_E^{-1}=-\tfrac{\sigma v_e}{g_{00}}(g^{-1})_{\rm sp}$, with twelve time components of momentum zero. The matter dual is $p=-i\chi E$ with $E=v_e(e^{-1})^0{}_a i\gamma^a\otimes I_{63}$; $\chi$ is not pre-identified with $\psi^\dagger$. The common canonical one-form is
$$\Theta=\Pi_e\cdot\delta e+\Pi_\phi\cdot\delta\phi+\sum_i\Pi_A^i\cdot\delta A_i+\operatorname{Re}(ip\,\delta\psi),\tag{S1.2}$$
with energy $H_{\rm cl}=H_e+H_\phi+H_{\rm g}+H_{\psi,{\rm rem}}$ and common twelve-dimensional Gauss $\mathcal G=\mathcal G_A+\Pi_\phi^{\mathsf T}\rho^{70}\phi+\operatorname{Re}(ip\,\rho^{252}\psi)$.

*61 CCR pairs.* Take a fixed real basis $R\in\mathbb R^{70\times61}$ of $\ker O^{\mathsf T}$ ($O=(O_1,\dots,O_{12})$ the original gauge–scalar orbit matrix, $\operatorname{rank}O=9$, $D_9=O_b^{\mathsf T}O_b$ equal to $256$ at the source). On the scalar constraint map write $\phi=v+Rx$, $\Pi_\phi=R^\vee\pi+O_b\zeta$ ($R^\vee=R(R^{\mathsf T}R)^{-1}$, $\zeta$ generated by the remainders of the nine unstable Gauss conditions through $D_9^{-\mathsf T}$). Since $O_b^{\mathsf T}R=0$, $\Theta$ pulls back exactly to $\pi\cdot\delta x$ on this map, giving 61 CCR pairs $[x_j,-i\partial_{x_k}]=i\delta_{jk}$.

*504-mode two-branch CAR.* The real canonical coordinates of the matter one-form $\operatorname{Re}(ip\,\delta\psi)$ are $(\operatorname{Re}\psi,\operatorname{Im}\psi)$ with momenta $(-\operatorname{Im}p,-\operatorname{Re}p)$. After complexifying the two independent real branches, the mode indices are $\mathcal I$ (S0.1), $|\mathcal I|=504$, and the creation/annihilation operators satisfy the standard CAR (equation (5.2) of the main text). The two-branch gauge-current matrix is $Q_a=\operatorname{diag}(i\rho_a^{252},i\overline{\rho_a^{252}})$; the two-branch realization of the matter Hamiltonian matrix $M$ is $\operatorname{diag}(M,-\overline M)$. This is one CAR quantization of the 504-dimensional whole, not a separate quantization of $\psi$ and $\chi$ paired afterwards.

*Common domain of the four energies.* Writing the coframe six velocities as combinations of orthogonal momenta $\kappa_r=-i\partial_{q_r}$ and Lorentz currents (lower-triangular spatial parametrization $L(q)$, $v=\det L$), the four energies actually add on
$$\mathscr D_{103}=C_c^\infty(\mathscr U_{103};\mathbb C)\otimes\mathcal F_{504}\tag{S1.3}$$
and every finite ordered composite preserves this domain. Each coefficient is generated by inverses of the given nondegenerate matrices and finitely many differentiations, hence smooth on $\mathscr U_{103}$; the cross principal part has 944 nonzero entries on the original coefficients, and the 61 original Yukawa force directions are retained. Note $103=6+61+36$ (coframe, scalar tangential, gauge connection): a configuration dimension, not a propagating-quotient dimension.

**(2) Section, measure and the common Hamiltonian.**

*Three stabilizers.* Let $S\in\mathbb R^{12\times3}$ span $\ker O$. With the original Gram $G$ define $B=E_b-S(S^{\mathsf T}GS)^{-1}S^{\mathsf T}GE_b$; then $[B,S]$ is a complete basis of the gauge algebra and the three stabilizers satisfy $[S_a,S_b]=-2\epsilon_{abc}S_c$; the original action further gives $[S_a,B]=BC_a$, $\rho_{S_a}O_b=O_bC_a$, $\rho_{S_a}R=RT_a$ and $C_a^{\mathsf T}D_9+D_9C_a=0$.

> **Lemma S1.1 (The three stabilizers commute with the common action).** The $\widehat G_a$ generated by the three stabilizers on $\mathscr D_{103}$ satisfy $[\widehat G_a,\widehat H]=0$, and their common kernel is nonzero and invariant under every finite ordered composite of the four energies.

*Proof.* By the covariance laws above, $V_aD_9=-C_a^{\mathsf T}D_9-D_9C_a$, hence $V_aF=C_aF+FC_a^{\mathsf T}$ ($F=D_9^{-\mathsf T}$); substituting into the ordered expansion of the momentum square, the variations of the normal coefficients and the current matrices cancel slot by slot, without commuting inner momenta. The gauge part uses the original Gram invariance and the Lie-derivative laws; the coframe part commutes spin matrices and the exterior-power gauge action. Nonzeroness is given by occupation vectors preserving the three stabilizers (e.g. $|(7,259)\rangle$) times compactly supported functions; a charged single mode gives a nonzero action, so the common kernel is a proper subspace of the Fock fibre. ∎

*Quantum section.* The quantum configuration is the 103-dimensional boson part (the matter is already realized by the CAR fibre). The same three gauge pivots as the classical reduction are used: at the designated source the orbit matrix $M=I_p^{\mathsf T}V$ satisfies $\det M_*=-54\sqrt2/125\ne0$. The local orbit map $\Phi(\alpha,z)=\exp(\sum_a\alpha_aL_a)(z_{\rm base}+I_fz)$ has an invertible derivative at the source point, and the inverse function theorem gives a nonempty local chart. The extension $\mathcal E$ and restriction $\mathcal R$ satisfy $\mathcal R\mathcal E=I$, $\widehat G_a\mathcal Ef=0$; the reduced operator $H_{100}=\mathcal R\widehat H\mathcal E$ preserves every finite composite (by $\widehat H\mathcal E=\mathcal EH_{100}$ of Lemma S1.1).

*Measure cancellation and half-density.* The orbit Jacobian gives the section weight $\rho_3(z)=8a_1^2a_{12}>0$ (value $54\sqrt2/125$ at the source). The nine unstable scalar conditions are second-class constraints: the product of the three factors — fixed-basis volume, normal-momentum integral and second-class determinant — is
$$\frac1{256}\cdot\frac{256}{|\det D_9|}\cdot|\det D_9|=1,\tag{S1.4}$$
so the actual measure of the quantum section is $\rho_3$, not multiplied by $|\det D_9|$ again; the density of the twelve-dimensional geometric extension is separately $\rho_{12}=|\det D_9|\rho_3/256$, a different responsibility. The sector of occupation number $m$ carries weight $v^{m+2}$:
$$\langle f,g\rangle=\sum_{w\subset\mathcal I}\int_{\mathscr U_{100}}\overline{f_w}g_w\,\rho_3v^{m+2}dz,\qquad \mathscr H=\bigoplus_{w}L^2(\rho_3v^{m+2}dz).\tag{S1.5}$$
The compactly supported smooth domain is dense in it (the cutoff–approximate–mollify argument per occupation number). The half-density map $(Uf)_w=\rho_3^{1/2}v^{1+m/2}f_w$ is a surjective isometry to the flat measure; the $v^{m+2}$ factor is required for the coframe adjoint closure.

*The formal adjoint pair and minimal closure.* On the same dense domain $\mathscr D_{100}$ of (S1.3)–(S1.5), let $H_0$ be the sum of the coframe, the formally ordered scalar ($\sum_j\Pi_j^\dagger\Pi_j/(2h^{00})$ ordering), the gauge and the non-Yukawa matter energies, and $Y$ the CAR realization of the original one-directional Yukawa.

> **Lemma S1.2 (Adjoint pair and closed graphs).** $H_0$ is formally symmetric; the complete $H=H_0+Y$ and the independent $H^\sharp=H_0+Y^\dagger$ satisfy $\langle f,Hg\rangle=\langle H^\sharp f,g\rangle$ ($f,g\in\mathscr D_{100}$). Both are closable, each with a single-valued minimal graph closure. The common one-body nullspace of the original full Yukawa and its adjoint has 392 modes across the two independent branches; its Fock carrier reduces $H_0$, on which $Y=Y^\dagger=0$ and the restriction is formally symmetric.

*Proof.* Termwise integration by parts: the scalar uses the designated $\Pi^\dagger\Pi$ ordering; the gauge Gram and magnetic derivatives are symmetric; the coframe's momentum, mixed-current, normal-product and coefficient-derivative terms pair under the weight $v^{m+2}$; the non-Yukawa matter matrix is Hermitian under the two-branch pairing. Only the original one-directional $Y$ becomes $Y^\dagger$ under adjunction—the unique source of asymmetry, and a substantive counterexample: on the two-particle vector $|144,396\rangle$, the source point gives $\|Y|144,396\rangle\|^2=4N^2=216/125$ and $Y^2\ne0$, so $Y$ on the whole Fock action is neither zero nor implicitly symmetric. The nonzero spectrum of the 70 Yukawa Grams is $10N^2$ (multiplicity 42) and $30N^2$ (multiplicity 14), with common two-sided nullspace of 196 dimensions per branch; projecting to the common kernel gives the $196\times2=392$ mode restriction.

Closeness: if $f_n\to0$ and $Hf_n\to g$, then for every $h\in\mathscr D_{100}$, $\langle h,g\rangle=\lim_n\langle H^\sharp h,f_n\rangle=0$, and density gives $g=0$; swapping $H,H^\sharp$ is symmetric. This gives the minimal graph closure of each, without choosing a self-adjoint extension first. ∎

*Four-time Weyl representation and all canonical motions.* On $U\mathscr D_{100}$ there is a quadratic momentum symbol $\sigma_0+Y$, uniquely read from the original coefficients, with $\operatorname{Op}_W(\sigma_0+Y)=UHU^{-1}$: first read the second-order $K$, then use the first divergence correction to read the first-order $B$, and restore the zeroth-order term; the coframe's $\operatorname{divdiv}(K)/4$ merges with the half-density potential into $n(3\mathrm{Number}^2+18\mathrm{Number}+20)/(16v)$; the Hermiticity of $\sigma_0$ is given by termwise integration by parts and Lemma S1.2; $Y$ contains no momentum and $U$ is scalar per occupation number, so it is preserved as is. Hence $H$ generates all canonical motions of the 100 CCR pairs and the 504 CAR pairs.

**(3) Action recognition.** The original action–force coefficient is the configuration-dependent $4W$, with $W\ge1$ generated by the original scalar Gram. The actual core $K(p)$ contains the original full Yukawa, the configuration matter, the retained time and spin terms and the physical momentum, and satisfies for every $p$ exactly
$$S_{\rm phys}(p)+Y=S_{\rm nat}+S_{\rm cf}+K(p)-K_{\rm ret}.\tag{S1.6}$$
The recognition is slotwise: every second-order density term of $S_{\rm phys}$ is recovered by the native sector $S_{\rm nat}$, the coframe part $S_{\rm cf}$ and $K(p)$, and the remaining slots are exactly $K_{\rm ret}$; $K_{\rm ret}$ is not an externally supplied remainder—it is given by the original action itself as part of the same core's definition. The identity holds term by term on the $\mathbb C^{289}$ symbol dictionary, with the configuration dependence of $W$ kept in every direction.

**Direct use.** The carrier and minimal closure of (1)(2) are the carriers of $H_0$, $Y$, $R$ and the prepared state of Theorem 6.8; the $K(p)$ and $4W$ of (3) enter the genuinely varying response of Theorem 6.9 and the Ward channels of Theorem 6.10; $\mathscr H$ and its graded structure are the underlying carrier of the spectral argument of Theorem 6.12 and the readout model of Proposition 9.2.

**Formal correspondence.** The sub-conclusions of Theorem 6.7(1)(2) are pinned item by item to earlier commits of the constrained-local-quantization source programs; the production mouths and evidence classes are as follows (`ecd/` abbreviates `Verification/physics/low-energy-phenomenology/external-composite-decay/`; aliases and commits are in Appendix D.7 of the main text):

| Sub-conclusion | Pinned commit | Production mouth | Evidence class |
| --- | --- | --- | --- |
| 61 CCR pairs ($O_b^{\mathsf T}R=0$, $\Theta$ pulls back exactly) | `85cb5386…` | `ecd/source_scalar_gauss_reduction.py` and `independent_*.py` | fixed exact source program and its independent recomputation |
| 103-dimensional common domain, 944 nonzero cross entries, 61 Yukawa directions | `85cb5386…` | `ecd/source_joint_local_quantum.py` and `independent_*.py` | fixed exact source program and its independent recomputation |
| 504-mode two-branch CAR and gauge-current matrix $Q_a$ | `85cb5386…` | the same two programs | fixed exact source program and its independent recomputation |
| three-stabilizer covariance laws and nonzero common kernel (Lemma S1.1) | `f9b73392…` | `ecd/source_quantum_stabilizer.py` and `independent_source_quantum_stabilizer.py` | fixed exact source program and its independent recomputation |
| classical reduced phase-space map and gauge pivots | `f9b73392…` | `ecd/source_stabilizer_phase_reduction.py` and `independent_source_stabilizer_phase_reduction.py` | fixed exact source program and its independent recomputation |
| quantum section, second-class measure cancellation (S1.4), half-density (S1.5) | `6726f385…` | `ecd/source_quantum_gauss_section.py`, `source_gauss_section_measure.py`, `source_full_gauss_section.py` and same-named `independent_*.py`; `ecd/SecondClassReduction.lean` | fixed exact source program and its independent recomputation + Lean formal theorem (cancellation identity) |
| Hilbert carrier $\mathscr H$, formal symmetry of $H_0$, adjoint pair $(H,H^\sharp)$, minimal closure, 392-mode common-kernel reduction (Lemma S1.2) | `6726f385…` | `ecd/SourceQuantumConfigurationHilbert.lean`, `SourceQuantumHalfDensityHilbert.lean`, `GaussRadialDomain.lean`, `FockFilteredWords.lean`, `GaussSymmetricGraphClosure.lean`, `AntiunitaryDefectPair.lean`, `GaussYukawaCoefficient.lean`, `GaussYukawaNullspace.lean`, `RadialHilbertTransfer.lean`, `GaussHalfDensity.lean`; `ecd/source_hilbert_space.py`, `source_yukawa_cocycle.py`, `source_adjacent_cocycle.py`, `source_symmetric_graph.py`, `source_temporal_cofinal.py` and `independent_*.py` | Lean formal theorems + fixed exact source programs and their independent recomputations (the programs carry the finite-dimensional carrier computations) |
| four-time Weyl representation $\operatorname{Op}_W(\sigma_0+Y)=UHU^{-1}$ | `6726f385…` | `ecd/source_{coframe,scalar,common}_weyl_symbol.py`, `source_common_temporal_form.py` and same-named `independent_*.py` | fixed exact source program and its independent recomputation |
| all canonical motions of the 100 CCR pairs and 504 CAR pairs (configuration port and normal-product port) | `eec031c4…` | `ecd/source_joint_ccr_car_ports.py` and `independent_source_joint_ccr_car_ports.py`; `ecd/JointCCRCarPorts.lean` | fixed exact source program and its independent recomputation + Lean formal theorem (normal-product port) |

The other results of the same source programs at these commits (time-constraint reduction, the quantum time map, the complete 122 inputs and the time/Lorentz constraint orbits, among others) carry no load in this paper; it directly consumes only the sub-conclusions listed in the table above, and the commit aliases are in Appendix D.7 and in the phys.P26 row of S10. The program parts are **not** Lean theorems: they are fixed exact source programs (symbolic/exact arithmetic, not floating-point fits), each accompanied by an independent recomputation program at the same commit as a dual-implementation check; the Lean parts are formal theorems item by item.

Theorem 6.7(3) action recognition: `physical_action_decomposition` of `alpha-source/CanonicalPreparationActionCoreDecomposition.lean`, and `FieldQuantization{Symbols,Core,Contacts}.lean` with the same prefix (Lean formal theorems). Commit AB (the carrier part of 6.7(1)(2) is at the four earlier pinned commits listed in the table).

---

## S2 Theorem 6.8: the all-order clock, the complete fixed $R$ and one source preparation

**Objects and domain.** The carrier $\mathscr H$ of Theorem 6.7, the dense domain $\mathscr D_{100}$, $H=H_0+Y$ and the minimal closed graph. The four time directions of the constraint system are described by the principal-force Jacobi $J_4$ generated by the source coefficient matrices $T,S,C$; $J_4$ is invertible on the source support's positive cone (a condition of the kind of (4.3) of the main text).

**Inputs and quantifiers.** (1) for every order $k\ge0$ and the four time directions $a$; (2) for all scalar test functions; (3) for every $\varepsilon>0$; (4) for the sequence $\varepsilon_n=1/(n+1)$. The clock, $R$, the source operator and the source energy are all generated inside the source, not supplied by the caller.

**Construction and key lemmas.**

**(1) The all-order clock.** The clock recursion is organized by order: the order-$k$ clock is a family of symbols on the four time directions with $k+1$ slots. The initial order puts the source clock value in the zeroth slot and zero elsewhere; the recursion step is
$$C_{k+1}(a,\mathrm{last})=-\sum_b (J_4^{-1})_{ab}\,R_{k+1,b}\tag{S2.1}$$
where $R_{k+1,b}$ is that order's residual symbol on the $b$-th time equation, composed of the 42 order/slot functions already paid at lower orders, the ordered product words and the original 13 time leaves.

> **Lemma S2.1 (Generation and preservation).** (i) the new order is generated exactly by (S2.1); (ii) $C_{k+1}$ agrees with $C_k$ on the first $k+1$ slots (paid lower orders are not rewritten); (iii) for every $k$, $a$, the order-$(k+1)$ four successor forces are identically zero on the closed source-support set (position cone, unit momentum directions, $p\ne0$).

*Proof.* (i)(ii) are direct properties of the recursive definition. (iii) Write that order's residuals as $r_b$ and the new clock as $n_b=-(J_4^{-1}r)_b$; the response of the $b$-th force at order $k+1$ to the new order is linear, equal to $r_b+(J_4n)_b$ (the force-response Jacobi in each direction is exactly $J_4$, the condition being the source clock's nonzeroness on the positive cone). Substituting $n=-J_4^{-1}r$ gives $r+J_4(-J_4^{-1}r)=0$; this uses the actual invertibility of $J_4$ on the source support. ∎

The finite-order derivative budgets of all 100 directions (with multiplicities of repeated directions retained) and the original coefficient table are generated by the same engine.

**(2) The complete fixed $R$.** The energy tail $E_{\rm tail}$ first generates a Fourier kernel (keeping the full translation structure $\pi(\xi+\eta)$) and two-sided Schur bounds; the complete energy form splits on Schwartz inputs as
$$\mathcal E_B(g,f)=\mathcal E_{\rm prin}(g,f)+\mathcal E_{\rm tail}(B;g,f),\tag{S2.2}$$
the two parts integrable separately. Through the Riesz representation, $E_{\rm tail}$ gives a self-adjoint tail operator. Define
$$R=E_{\rm tail}-C_{\rm src},\tag{S2.3}$$
with $C_{\rm src}$ the source-native composition term.

> **Lemma S2.2 (Fixity of $R$).** $R$ is a bounded self-adjoint operator, with source-generated norm bound $\|R\|\le\|E_{\rm tail}\|_{\rm est}+\|C_{\rm src}\|_{\rm est}$; for all original scalar test functions $g,f$, the form composed of the original closed factor $A$ (the closed factor of $B_1^2$) and $R$ satisfies
> $$\langle Ag,Af\rangle+\langle g,Rf\rangle=\mathcal E_B(\check g,\check f),\tag{S2.4}$$
> i.e. exactly the original Weyl energy form of the complete $B_1^2+E_{\rm tail}$. $R$, the source operator $\mathcal T$ composed of $A$ and $R$, and the source energy $E$ are all independent of any preparation precision.

*Proof.* The decomposition (S2.4) expands the left side by the definition of $R$ into a principal part plus a tail part, i.e. (S2.2); self-adjointness is inherited from the energy tail's and the composition term's own self-adjointness. The norm bound: the energy tail's Fourier kernel $k(x,y)$ satisfies a two-sided Schur estimate—the row and column integrals have source-generated finite bounds $S_1=\sup_x\int|k(x,y)|\,dy$, $S_2=\sup_y\int|k(x,y)|\,dx$, and the Schur test gives $\|E_{\rm tail}\|\le\sqrt{S_1S_2}$; the composition term $C_{\rm src}$ has an independent source-generated bound, hence $\|R\|\le\|E_{\rm tail}\|+\|C_{\rm src}\|$. ∎

**(3) One source preparation.** The preparation point is not constructed clause by clause but produced at once by one source factory:

> **Lemma S2.3 (The same preparation point).** For every $\varepsilon>0$, the domain of the source operator contains a point $x_\varepsilon$ satisfying simultaneously: unit norm $\|v_\varepsilon\|=1$; near spectrum $\|\mathcal Tx_\varepsilon-Ex_\varepsilon\|<\varepsilon$; the source-production equality (the prepared image equals the source-created object); the original weak-form identity $\langle\mathcal Tx_\varepsilon,y\rangle=\langle A\hat x_\varepsilon,Ay\rangle+\langle x_\varepsilon,Ry\rangle$; native Yukawa charge readout $=-1$; the norms of the eight external legs controlled by a uniform source-generated bound; an independent time–frequency field (for every $p,k$, Lie index, cutoff, $z,w$ with $\operatorname{Im}z,\operatorname{Im}w>0$ and all discrete indices, the two-time reading converges to the frequency reading); the full Yukawa's domain membership, value equality and cutoff bound
> $$\|Y_{\rm closed}v_\varepsilon-\mathrm{cut}_n(v_\varepsilon)\|\le(915/916)^{n+1}\cdot 916\cdot b,\tag{S2.5}$$
> $b$ the source-generated Yukawa coefficient bound; and limit of the cutoff sequence $=$ the Yukawa value.

*Proof sketch.* The actual mechanism of existence is as follows. The augmented closed form generated by $A,R$ (adding a factor $(1+\|R\|)$ on the graph domain) determines a unique operator $\mathcal T$ and gives a positive, injective bounded resolvent $B=(\mathcal T+1+\|R\|)^{-1}$. Take the source energy
$$E=\|B\|^{-1}-(1+\|R\|):\tag{S2.5a}$$
Since $B$ is a positive bounded operator, $\|B\|$ is a spectral point; for a positive bounded injection, the spectral point $\|B\|$ produces unit approximate eigenvectors (the approximate-spectrum criterion), which through $B^{-1}$ reduce to a unit approximate eigenvector $x_\varepsilon$ of $\mathcal T$ at $E$ (the general lemma being the inverse-operator version for a bounded positive injection). The weak-form identity is the pointwise domain-membership identity of the augmented form and needs no separately chosen point. The eight external legs and the time–frequency convergence are carried by additional fields of the same construction; the four full-Yukawa fields are given by the closed Yukawa graph's original-domain estimates, and the geometric ratio $915/916$ is an explicit upper bound of a ratio of source Yukawa coefficients. ∎

**(4) Two residuals tend to zero together.** Take $\varepsilon_n=1/(n+1)$ and $x_n=x_{\varepsilon_n}$. With the same fixed $R$, $\mathcal T$, $E$:

- near-spectral residual: $\|\mathcal Tx_n-Ex_n\|<1/(n+1)\to0$;
- full-Yukawa cutoff residual: by (S2.5), $\|Y_{\rm closed}v_n-\mathrm{cut}_n(v_n)\|\le(915/916)^{n+1}\cdot916\,b\to0$ (geometric).

The two convergences share the same sequence $\{x_n\}$, not separately chosen states. **This is residual convergence**: it does not assert that $x_n$ converges in norm, nor does it call $x_\varepsilon$ an exact eigenstate.

**Direct use.** The causal, contact, positive-damping time-tail and nonlinear readings (Theorems 6.9–6.10, 6.12) consume all fields of the same preparation point; the fixity of $R$ keeps $\mathcal T$, $E$ in (4) unchanged with $n$.

**Formal correspondence.** `alpha-source/CanonicalPreparationEngineProgram.lean` (`sourceEngine`, `sourceEngine_generated`, `sourceEngine_preserves`), `CanonicalPreparationEngineCancellationForces.lean` (`sourceEngineForces_successor_zero`) and `Filtration`, `PaidForces`, `ActualRadial` with the same prefix; `CanonicalPreparationFullEnergyForm.lean` (`completeEnergyForm_split`, `actual_closed_form_complete_energy`), `CanonicalPreparationSourceRemainder.lean` (`sourceRemainder_decomposition`, `sourceRemainder_selfAdjoint`, `sourceRemainder_norm`, `sourceRemainder_readback`); `CanonicalPreparationSource{PreparedState,BoundarySequence,CausalState,NonlinearState}.lean` (`sourcePreparation_exists`, `preparationSequence_residual`, `preparationSequence_yukawa_residual`, `sourceCausalState_same_preparation`, `sourceNonlinearState_same_preparation`). Commit AB.

---

## S3 Theorem 6.9: the genuinely varying response and cutoff exchange; and the spectral measure and all-time convergence at the end of §6.9

**Objects and domain.** The carrier of Theorems 6.7–6.8, $H=H_0+Y$, the fixed $R$ and the same preparation sequence $x_\varepsilon$. A field curve means a smooth curve in the original field space parametrized by a source coordinate slice, $z\mapsto$ a point on the physical chart; the response point $q$ is as in S0.3. The cutoff index $F$ is directed by inclusion; a cutoff-order slot at a finite value $n$ is the $n$-th-order Yukawa cutoff, and at the uncut value the uncut term.

**Inputs and quantifiers.** (1)(4) for every field curve and test state; (2) for every damping $\gamma>0$ and every nonlinear parameter $r$ with $|r|\le r_*(f,\psi,p,n,\gamma)$ ($r_*$ the source-generated nonlinear radius); (3) for every $F$, every non-real $z$ and original local field neighbourhood. The two items at the end of §6.9 hold for every original core input $g$ and every bounded insertion.

**Key lemmas.**

> **Lemma S3.1 (Cutoff jet limit).** For every fixed field curve, $p$, $F$, non-real $z$ and real parameter $r$: the cutoff Yukawa jet $Y_n(p,F,r)$ converges as $n\to\infty$ to the uncut $Y_\infty$; the resolvent, current, contact, insertion and inverse contact, five items in turn, converge to the corresponding uncut operators.

*Proof.* The core fact is the **finite retainer set**: for every fixed $F$ and momentum $p$, the retained terms act only on some finite retainer index set, hence for every fixed parameter tuple $(f,p,F,z,r)$ the sequence **stabilizes pointwise**—there is an $N$ such that for $n\ge N$ the $n$-th-order jet and the uncut jet are equal as objects. An eventually constant sequence converges in its (finite-dimensional) operator space in the $\mathcal N$ neighbourhood topology, equivalently in norm—hence $Y_n\to Y_\infty$, $R_n\to R_\infty$, the current, the contact and the insertion each hold (each is a corresponding `Tendsto` declaration), except that the stabilizing order $N$ depends on the parameter tuple, not uniformly over all inputs. The resolvent limit also follows from continuity of the inverse map: for non-real $z$ the uncut moving diagonal entry is invertible and matrix inversion is continuous there. ∎

> **Lemma S3.2 (Read-back of the cutoff preparation).** For every cutoff order $n$, the $n$-th-order cutoff response equals, term by term on the original readout channel, the cutoff value of the prepared response; the response, its first derivative and its second derivative each have a pointwise identity.

*Proof.* The cutoff response's definition expands into a pairing of the completed external legs with the cutoff resolvent; Lemma S3.1 gives the convergence of each factor, and the joint continuity of the inner product transports the convergence to the reading; the derivative cases first use the same identity as a pointwise rewrite, then the convergence of the first and second jets. ∎

**Decisive derivation.**

**(1) Genuinely varying field.** The original 106-dimensional inverse and all native, coframe and retained terms generate a genuine 289-dimensional field vector and 36 curvature readings: each reading is a density integral transported along the original field curve—the actual Gauss density $Jv^{N+2}$ and the first two derivatives of the half-density ratio are transported with the curve, and the diagonal fibre keeps the graded-compression layout $\sum_gP_gP_FH_{\rm phys}P_FP_g$. The complete form and its cutoff compressions have genuine second-order jets: the native integral and the coframe integral each carry a continuous second derivative and an explicit remainder on the source domain $|r|<r_*(f,a)$, as does the composite; the inverse at a finite cutoff directly gives the same preparation's first-order $-RJR$ and complete second-order contact term.

**(2) Nonlinear response.** For damping $\gamma>0$, the nonlinear Laplace response has a genuine parameter derivative inside the source-generated radius $r_*$ (differentiable at $r=0$, with explicit derivative), and the remainder satisfies
$$\bigl\|\Phi(r)-\Phi(0)-r\Phi'(0)\bigr\|\le L^2\,\bigl(s(f,g,\psi,p,n,\gamma)\cdot m(\gamma)\bigr)\,|r|^2\,\|u\|^2,\tag{S3.1}$$
where $L$ is the external-leg bound, $s$ the source-generated remainder scale, $m(\gamma)$ the Laplace mass and $u$ the prepared image. The two independent transfer chains keep the momentum labels $p,\ p+\ell,\ p+k,\ p+k+\ell$ and the minus sign of the force, the plus sign of the contact.

**(3) From cutoff to uncut.** The original moving closed Yukawa has a dense closed graph, and the retained space and the preparation's eight external legs lie in its true domain. The literal cutoffs' 0-, 1- and 2-jets all converge to the uncut ones: this is the conjunction of Lemmas S3.1 and S3.2—first the operator convergence from the finite retainer set, then the pointwise read-back identities and the jet convergence transport the exchange to the prepared response and all 36 curvature readings.

**(4) Mother state and fixed measure.** The coordinate edges and the diagonal of the original state square recover the same mother-action state and generate all four ordered Hessian blocks; inside the source neighbourhood the moving fibre integral equals the original fixed-measure fibre exactly—the density derivatives cancel by the same transport identity (note: only the already-paid density derivative is cancelled; the response itself is read as usual)—and the mother current, the native and coframe jets and the retained balance still enter the cutoff and uncut first and second derivatives of the same preparation.

**End of §6.9: the spectral measure and all-time response of the original $H_0$.** For the original $H_0$, every original core input $g$ generates, through the same source filter, a positive finite measure $\mu_g$ on $\mathbb R$ of mass $\|g\|^2$: every finite level of the source filter gives a channel decomposition whose channel squared norms sum exactly to $\|g\|^2$, positivity and consistency are guaranteed by the projection family, and the limit measure is unique on cofinal indices. It reads simultaneously the resolvent quadratic amplitudes (Stieltjes type) of all non-real $z$ and the even-order energy moments; for nonzero $g$ the normalized probability measure has the corresponding limit statement. For every bounded insertion $A$ and damping $\mu>0$, the complete complex retarded amplitude converges in $L^1$ on the whole real frequency axis—the termwise error is controlled by the resolvent price and the mass decomposition—and through the inverse Fourier transform converges, uniformly in all times, to the time response. **These are quantities of the original $H_0$'s source response**: the positive measure is carried on the spectrum of the free generator and is not renamed as the particle spectrum of the complete interaction.

**Direct use.** The cutoff–uncut exchange of (3) is a prerequisite of Theorem 6.10's two-leg Ward and Theorem 6.12's half-axis argument; the curvature readings of (1)(4) enter the field returns of Theorems 6.11–6.13.

**Formal correspondence.** `alpha-source/CanonicalPreparationSourceNonlinearState.lean` (`preparedLaplace_derivative`, `preparedLaplace_remainder`, `sourceNonlinearState_same_preparation`), `CanonicalPreparationYukawaObservedLimit.lean` (`sourceY_limit`, `sourceResolvent_limit`, `observed_uncut_limit`, `observed_uncut_limit_near`, `observed_first_exchange`, `observed_second_exchange`, `curvature_uncut_limit`, `curvature_first_exchange`, `curvature_second_exchange`, declarations related to `finiteRetainer`), `CanonicalPreparationHalfDensityCompressionFeed.lean` (`diagonalFiber_source`, `transportedForm_fixed`, `transported_first_fixed`, `transported_second_fixed`, `compression_fixed_source`); AC adds `CanonicalPreparationSpatialFullFormFeed.lean` (`completeForm_source`, `complete_first_source`, `complete_second_source`, `nativeIntegral_fixed`, `coframeIntegral_fixed`), `CanonicalPreparationJointMixedResponse.lean` (`mixedCurvatureMatrix_generated`), `CanonicalPreparationRawJointFiveTerms.lean` (`eulerCovector_generated`, `fiveKernel_generated`), `CanonicalPreparationOriginalPreparedGreen.lean` (`original_green_equation`, `original_forced_field`), `CanonicalPreparationPhysicalFeedbackField.lean` (`physicalField_generated`). End of §6.9: `external-composite-decay/SourceHamiltonianSpectralMeasure.lean` (`actual_channel_mass`, `actual_stieltjes`, `actual_even_moment`, `actual_source_spectral_measure`, `actual_probability_limit`), `SourceBoundedInsertionTime.lean` (`actual_time_error`, `actual_uniform_time_response`). Commits AB (end of §6.9) and AC (common-field consumption).

---

## S4 Theorem 6.10: the charge–current Ward identity and one preparation

**Objects and domain.** The carrier of Theorems 6.7–6.9: the 504-mode CAR fibre, the quantum test space $\mathcal Q$, the momentum action $P(k)$, the charge action $Q_a$ ($a$ a native Lie-algebra element), the one-body spatial current $J_{\rm sp}(k,a)$ and the pair current $J_{\rm pair}(k,a)$. The two-leg responses are parametrized by the cutoff index $F$, the cutoff order $n$ and non-real $z,w$.

**Inputs and quantifiers.** (1) for every test state, every momentum $k$ and every $a$; (2) for every cutoff $(n,F)$; (3) the global-charge boundedness for every time direction, and the joint momentum representation for weighted functions on the 106-dimensional orbit.

**Key lemmas.**

> **Lemma S4.1 (The pair fibre of quantized normal order).** For arbitrary complex matrices $A,B$ (mode dimension arbitrary), the quantization map satisfies
> $$Q(A)Q(B)=Q(AB)+\Pi(A,B),\tag{S4.1}$$
> where $\Pi(A,B)=\sum_{ijkl}A_{ij}B_{kl}\,c_i^\dagger c_k^\dagger c_l c_j$ is the pair-fibre operator; $\Pi(A,B)$ commutes with every particle-number weight operator.

*Proof.* Expand index by index and use the CAR: $c_jc_k^\dagger=\delta_{jk}-c_k^\dagger c_j$, $c_jc_l=-c_lc_j$, hence
$$Q(A)Q(B)=\sum_{ijkl}A_{ij}B_{kl}\,c_i^\dagger c_jc_k^\dagger c_l
=\sum_{ijl}A_{ij}B_{jl}\,c_i^\dagger c_l+\sum_{ijkl}A_{ij}B_{kl}\,c_i^\dagger c_k^\dagger c_l c_j
=Q(AB)+\Pi(A,B).$$
The weight commutation holds because both $Q(A)$ and $\Pi(A,B)$ preserve occupation number. ∎

> **Lemma S4.2 (One-particle annihilation of the pair current).** On the fibre at every configuration point $z$, $J_{\rm pair}(k,a)\,f=\Pi(P_k(z),Q_a)\,f(z)$; hence $J_{\rm pair}=0$ on the one-particle projection.

*Proof.* Pointwise by Lemma S4.1: the coordinates of $P(k)Q_a f$ equal $J_{\rm sp}(k,a)f+\Pi(P_k,Q_a)f$; on the one-particle sector two annihilation operators cannot act together, so the $\Pi$ term vanishes identically. ∎

**(1) Charge–current decomposition.** Lemmas S4.1 and S4.2 directly give (6.4) of the main text: $P(k)Q_a=J_{\rm sp}(k,a)+J_{\rm pair}(k,a)$, the pair current's four-operator sum having the one-body momentum and charge matrices as coefficients, commuting with all particle-number density weights and vanishing on the one-particle projection.

**(2) Complete Ward.** The charge difference of the unprojected original physical action plus Yukawa keeps exactly four channels: configuration torque, spatial current, quartic pair current, Yukawa torque—written
$$[Q_a,H_{\rm full}]=J_{\rm cfg}(a)+J_{\rm sp}(a)+J_{\rm pair}(a)+J_{Y}(a).\tag{S4.2}$$
At every cutoff $(n,F)$, the compression defect and the Yukawa cutoff difference $Y_n-Y$ enter the remainder as they are: the finite insertion on cofinal $F$ equals
$$\mathrm{finIns}_{n,F}=W_{\rm core}+\Delta^{Y}_n(Q_a f)-Q_a\,\Delta^{Y}_n(f)+\text{compression defect},\tag{S4.3}$$
i.e. the defect is not silently deleted. The two-leg response $\langle x,R_{\rm full}(p+k,z)Q_aR_{\rm full}(p,w)y\rangle$ equals exactly the sum of the resolved channels (the core channel plus the transport remainder): resolve the two legs separately as $\widetilde x=R(p+k,z)^*x$, $\widetilde y=R(p,w)y$, first by a source-internal approximation, then read out by (S4.3); the response has the uniform price
$$\|\mathrm{resp}\|\le\|x\|\Bigl(c_a\,b_n(w)+b_n(z)\,c_a+|z-w|\,v_a(n,z,w)\Bigr)\|y\|,\tag{S4.4}$$
with $c_a$ the charge price, $b_n$ the cutoff-resolvent bound and $v_a$ the vertex price.

**(3) Global charge and one preparation.** The original 12 time directions generate from the actual action a global bounded charge $Q$: each direction's readout operator has an explicit price $c_a=\|\mathrm{quantized}(C_a)\|$. Along the same curve, the $-rQ$ variations of the bare Hamiltonian and of the retained term cancel—the complete $H$ minus the retained term produces no spurious $-rQ$ term; the joint graph of the native 106-dimensional orbit generates the weighted joint momentum representation $\sum_iP_i^\dagger(c_i f)=-Q$ (the joint readout operator is bounded, the graph closed and dense). The genuine two-leg Ward is completed by the same source filter—on cofinal $F$ the compression defect is zero and (S4.3) tends to the Ward core—and is read directly by the eight external legs and the twelve time columns of the 36 curvature readers of the same preparation point (S2).

**Boundary note.** This section retains the original native Ward operator identity. The physical EM contraction of the same density is proved in S11.4 and the actual charged N3 external state in S14.1. That the pair current vanishes on the one-particle sector is a cancellation fact, not that all currents vanish.

**Direct use.** The decomposition (6.4) and the two-leg Ward are inputs to Theorem 6.12's five-factor kernel and Theorem 6.13's static residue and cosource compatibility condition; the global charge $Q$'s price bound is consumed by Theorem 6.14's whole-word budget.

**Formal correspondence.** `alpha-source/CanonicalPreparationElectricPairCurrent.lean` (`quantized_normal_order`, `pairFiber_weight`, `full_current`, `pairCurrent_original_words`, `pairCurrent_oneParticle`), `CanonicalPreparationElectricCoreWard.lean` (`physical_full_ward`, `original_full_ward`, `finite_full_core`, `finite_full_core_eventually`, `compressionDefect_eventually`), `CanonicalPreparationElectricWeightedGraph.lean` (`weighted_adjoint_constraint`, `original_weighted_ordering`, `jointReader_price`, `original_joint_graph_closed`), `CanonicalPreparationElectricPreparedWard.lean` (`insertion_actual_channels`, `resolvedChannels_original_response`, `original_response_price`, `resolvedChannels_price`, `resolvedChannels_samefilter`, `preparedChannels_same_state`, `curvatureChannels_same_state`), `CanonicalPreparationTemporalGlobalCharge.lean` (`temporal_hamiltonian`, `temporal_contact_balance`, `globalReader_norm`). Commit AB.

---

## S5 Theorem 6.11: the mother action's second variation is this $H_{289}$

**Objects and domain.** The fixed source, the original action (3.1) and the designated solution of Construction 4.1. The 289 real directions are the real coordinates of the nine field groups (coframe, Lorentz connection, gauge, scalar, primal, independent dual etc.) on the holonomic configuration; $p\in\mathbb C^4$ are four complex momenta; $H_{289}(p)$ is the original Jacobi dictionary (3071 terms, coefficients in $\mathbb Q(\sqrt2,\sqrt{15})$).

**Inputs and quantifiers.** (1) for all variations along the 289 directions at that solution; (2) for every $p$; (3) for all 289 field unit directions; (4) for every nondegenerate coframe.

**Key lemmas.**

> **Lemma S5.1 (Smoothness and the second-order density decomposition).** The mother density is smoothly generated at the designated solution by twelve source-supported nodes (inverse coframe, third-order $H$ coefficients, the non-Abelian contact, the scalar orbit and the independent dual's third-order coefficients and adjugate matrix); its Fréchet second variation is a symmetric bilinear form and decomposes by sector—gravity (topological BF and linear $\Lambda$ residue), gauge, scalar and Dirac (including the independent dual)—into second-order densities of 234, 406, 220 and 790 terms; all 95 constants return to the original source coefficients.

> **Lemma S5.2 (Fourier merging).** Every second-order density term is a product of two field legs and one momentum monomial; the Fourier transform writes each term as two signed contributions. All 1650 terms produce 3300 signed two-leg contributions which, merged in the original dictionary's order, equal term by term the 3071 terms of the original $H_{289}(p)$; the left Euler's minus sign is inserted only once.

*Proof sketch.* The termwise comparison is an equality on finite sets, decided in two steps: the termwise equality of the two separately canonicalized term lists is decided by `decide +kernel` (the proof kernel reduces them to the same canonical term list); that the Fourier merging correctly writes each literal second-order term as signed two-leg contributions is an independent restatement theorem, composed with the term-list equality above. The coefficient field is $\mathbb Q(\sqrt2,\sqrt{15})$; scalar-coefficient equalities are decided term by term by `ring`, `norm_num` etc., not by floating-point comparison. ∎

> **Lemma S5.3 (Holonomic Euler readings).** For a holonomic configuration the Euler reading equals "partial derivative of the value minus divergence of the momentum". The pullbacks of the nine groups of mother residues along all 289 field unit directions equal that reading direction by direction: the 184 derivative-free slots give zero momentum and zero divergence, and the scalar, primal and connection direction classes (9, 24, 72) satisfy "value minus divergence equals the original Euler".

> **Lemma S5.4 (Legendre read-back).** In the Lorentz connection's complete quadratic form $\tfrac12\omega^{\mathsf T}\mathcal H\omega$, $\mathcal H$ is generated by 216 structure coefficients and a rational matrix $K_0$ of the nondegenerate coframe ($e^{\mathsf T}K_0e/\det e$); the product of the 576 polynomial entries verifies that $K$ is a two-sided inverse. After adding the spin and geometry load $J$ it eliminates uniquely to $\Omega=-KJ$ with value $-\tfrac12J^{\mathsf T}KJ-3\det e$. The Legendre transform of the coframe's 16 canonical momenta and 10 primary constraints returns the coframe kinetic energy of S1; CAR contraction over the eight Clifford directions gives the spin constant term $\tfrac{3\,\mathrm{lapse}}{4V}\mathrm{Number}-\tfrac{\mathrm{lapse}}{2V}\mathrm{normal}$; the $\mathrm{Number}^2$ term produced by pairing the linear current with the particle-number radial momentum cancels exactly against the mixed Gram's extra terms, leaving $-\tfrac{9\,\mathrm{lapse}}{8V}\mathrm{Number}$.

**Decisive derivation.** (2) obtains the source-generated decomposition of the Hessian from Lemma S5.1 and merges it by Lemma S5.2 into the same $H_{289}(p)$—the same matrix object, not an isomorphism or an approximation; (3) holds slot by slot by Lemma S5.3; (4) is a finite-dimensional quadratic elimination ($K$'s invertibility is verified by the product of Lemma S5.4) plus a finite contraction of the CAR normal order.

**Direct use.** The $H_{289}$ consumed by Theorem 6.12's Green equation, the nine compatibility residuals and the 36 curvature readers is this matrix; Theorem 6.13's static pole expands inside its source radius domain.

**Formal correspondence.** `alpha-source/CanonicalSourcePropagationOriginalHessianReturn.lean` (`nativeCompleteLiteralTerms`, `nativeHessian_complete_source`, `nativeActionFourierHessian_original`, `nativeJacobi_original`, `nativeAction_sourceField`, `nativeAction_original_regular_point`, `nativeAction_sourceField36`, `nativeAction_noetherField`, `nativeAction_noetherField36`), `CanonicalSourcePropagationPreparedMotherEulerReturn.lean` (`actualPreparedMotherEuler_generated`, `actualPreparedMotherEuler_linear`, `actualPreparedMotherEuler_multiplier`, `actualPreparedMotherEuler_{gravityAuxiliary,gaugeAuxiliary,coframe,independentDual}`, `nativeHolonomicEuler_raw`, `nativeHolonomicEuler_raw_near`, `preparedMotherForcing_cosources`). Commit AD.

---

## S6 Theorem 6.12: the same preserved current returns to $H_{289}$ through the complete half-axis

**Objects and domain.** The $H_{289}$ of Theorem 6.11 (the original Jacobi), the kernel $K_F(p)$ and the read-port $J$ of Theorems 6.9–6.10, and the response point $q$ (S0.3). The native configuration embedding of $\mathbb C^{289}$ into the configuration Hilbert space is written $\iota_{289}$ (the full-field carrier of S1; not to be confused with 6.13's five-direction embedding $E_0$). The four components of the original Green data are defined once: $D$ the contact-block inverse, $P_a$ the orthogonal projection onto the active 103-dimensional block, $K_{\rm ext}$ the extended kernel (active kernel plus empty-slot supplement), $P_{\rm null}$ the nine-dimensional null-direction projection; the row lift is written $L$ and the read-back $R_b$ ($R_bL=I$, detailed in S7). The operator pencil is of Sylvester type
$$\mathcal P_q(\lambda)A=\lambda A+\mathcal A_L A-A\mathcal A_R,\tag{S6.1}$$
with $\mathcal A_L=-iK_F(p+k)$, $\mathcal A_R=-iK_F(p)$. The Green factor matrix is written $\Xi$ (not to be confused with the cutoff index $F$): the original Green is
$$G=\Xi\,\bigl(D^{-1}+P_aK_{\rm ext}^{-1}\bigr)\,\Xi(-p)^{\mathsf T},\qquad H_{289}\,G=I-\Xi(-p)^{-\mathsf T}P_{\rm null}\Xi(-p)^{\mathsf T},\tag{S6.2}$$
the second identity holding on the regular domain where the active-103 determinant is nonzero.

**Inputs and quantifiers.** (1) for every response point, forcing and cutoff $F$; (2) for every non-real spectral parameter and $\operatorname{Re}\lambda>0$; (3)(4) for every non-real $w$, momentum $k$ and response point; (5) for every frequency with $\operatorname{Re}\lambda>0$ and one source-generated concrete instance (clock $\lambda_0=3-g$, read frequency $3$, $g$ as in (5)).

**(1) Common field and the finite-window identity.**

*Construction and quantifiers.* The same spatial half-density and the complete configuration integral generate the common field vector (289 components) and the 36 curvature readings; the field is $C^2$ in the source field curve with symmetric Hessian—each of the 36 cells consisting of 1296 mixed-response entries ($36\times36$). The mother Euler's original term is $-4W\cdot DH$, and the complete density contact term cancels by the same transport identity.

*Key derivation.* The nine-term expansion: the time derivative of the five-factor product is expanded factor by factor by the product rule and agrees term by term with the five-term time derivative kernel—the native five-term kernel and the same window's Euler covector are generated together. The finite-window identity is weighted integration by parts: for the original field curve $c(s)$ and the forcing,
$$\Xi(-\lambda,-ik)^{\mathsf T}\cdot\mathrm{forcing}
=\int\bigl(\text{time jets}\bigr)\,dt-\bigl(\text{terminal}-\text{initial}\bigr),\tag{S6.3}$$
and the derivative of the field curve equals the Green function applied to that forcing. The original Green equation (S6.2) and the forced-field equation are verified in the coefficient field by a finite matrix identity interlacing the original Jacobi, $\Xi$ and the active-103 block; the regular domain is nonempty: at a source-generated rational point, the extended kernel times the source-generated inverse matrix equals the identity (term by term by `decide +kernel`), and the right inverse gives a nonzero determinant, making that point a regular point.

*Use.* This item's Green equation also serves the compatibility criterion of 6.13(4).

**(2) The 57-term polynomial time bound and the complete positive half-axis.**

*Key lemma (graded bound).* The compressed part $C_F$ preserves the occupation grading and the retained term $A_F$ raises it by one, so the 57-th pure upgrade of $K_F=C_F+A_F$ vanishes; the Duhamel expansion terminates at order 56, and the time evolution on the full carrier is exactly the finite sum
$$\text{time bound}(\text{cutoff}\,c,t)=\sum_{n<57}\bigl(|t|\cdot\|c\|\bigr)^n\tag{S6.4}$$
—the bound of the physical time evolution is a degree-56 polynomial in $|t|$ with coefficients powers of the cutoff norm. This is the real source of the evolution polynomial bound: not a global assumption on the semigroup norm but a combinatorial truncation by the graded structure.

*Half-axis.* For every $\operatorname{Re}\lambda>0$, the polynomial bound times the Laplace weight $e^{-\lambda t}$ is termwise Bochner integrable; taking the source price $\eta=\operatorname{Re}\lambda/8$, the norm envelope $e^{(\operatorname{Re}\lambda/2)t}\cdot e^{-\operatorname{Re}\lambda t}=e^{-(\operatorname{Re}\lambda/2)t}$ gives the complete positive-half-axis forcing $\Phi^+$ and field response. The $T\to\infty$ limit of (S6.3) is the **half-axis identity**
$$\Xi(-\lambda)^{\mathsf T}\,\Phi^+=\Sigma^++B_0,\tag{S6.5a}$$
where $\Sigma^+$ is the time-jet integral term and $B_0$ the $t=0$ initial-boundary term (no longer sharing a letter with 6.13's static tensor $S$); the difference between finite window and half-axis has the explicit exponential tail
$$\bigl\|\Phi^+-\Phi_T^+\bigr\|\le\frac{2}{\operatorname{Re}\lambda}\,c\,e^{-(\operatorname{Re}\lambda)T/2},\tag{S6.5}$$
with $c$ the same source's norm price at $\eta$ ($c=\text{source price coefficient}(\eta)$), and the terminal cosource tends to zero.

**(3) Bochner inverses on the two half-planes and the spectral axis.**

*Two-sided inverses.* For $\operatorname{Re}\lambda>0$, the positive-time integral $R^+(\lambda)=\int_0^\infty e^{-\lambda t}\Phi_t\,dt$ satisfies, by the time equation $X_t'=A X_t-X_t B$ ($\Phi_t(X)=T_{p+k}(-t)XT_p(t)$), the two-sided inverse identities
$$\mathcal P_q(\lambda)\,R^+(\lambda)=R^+(\lambda)\,\mathcal P_q(\lambda)=\mathrm{id}\tag{S6.6a}$$
(the left action $\mathcal P_q(\lambda)X=\lambda X+AX-XB$ and the right action $X\mathcal P_q(\lambda)=\lambda X+XA-BX$ each follow from one integration by parts exchanging the $\lambda$ weight for a time derivative), giving the pencil's two-sided inverse on the right half-plane; for $\operatorname{Re}\lambda<0$ the negative-time (past) integral gives the left half-plane inverse symmetrically. Each open half-plane has one bounded inverse, so the pencil spectrum can lie only on the imaginary axis $\operatorname{Re}\lambda=0$.

*The spectral point at zero transfer.* At zero transfer (equal two-leg momenta), the pencil generator coincides with the single-leg generator, the identity operator lies in the kernel, and the carrier contains a nonzero unit (the same preparation's unit vector), so $0$ is an actual spectral point of the pencil; its response is exactly a $\lambda^{-1}\langle\cdot,\cdot\rangle$-type reading—unbounded at $\lambda=0$, consistent with "spectrum on the imaginary axis".

**(4) Picard iteration and the genuinely varying background.**

*Derivation.* Given a $C^1$ field history and an amplitude parameter $a$, the two legs are each driven by a nonautonomous generator $\mathcal G_a(t)$: the primal leg $U_a'= \mathcal G_aU_a$, the dual leg $V_a'=-V_a\mathcal G_a$, with initial values $U_a(0)=V_a(0)=1$; the solution exists and is unique as the evolution of a bounded generator on the finite window $[0,T_*)$ (the source window objects give the generator's uniform norm prices inside the window and a Lipschitz bound in $a$). The physical background map between the two legs (the operator-on-operators left-multiplying by $T_{p+k}(-t)$ and right-multiplying by $T_p(t)$) is **autonomous**: its generator $\mathcal E$ is a fixed transfer operator, $\mathcal E$ commutes with the map's values and the initial value is $1$, hence the map is exactly $\exp(t\mathcal E)$ (autonomous uniqueness); between the two exponentials there is the Volterra/Duhamel identity
$$e^{tL_1}=e^{tL_0}+\int_0^t e^{(t-s)L_0}(L_1-L_0)\,e^{sL_1}\,ds\tag{S6.8}$$
The amplitude derivative at $a=0$ is given by the same identity—the primal leg's variation is the variation-of-constants integral
$$\partial_aU\big|_0=T_p(t)\int_0^t T_p(-s)\,\partial_a\mathcal G_a\big|_0(s)\,T_p(s)\,ds,\tag{S6.9}$$
and the dual leg is the minus-sign conjugate form; differentiating under the integral in $a$ is paid by the parameterized-derivative lemma (on the finite window the three principal estimates—generator secant bound, evolution bound and solution amplitude bound—hold simultaneously, and dominated convergence exchanges derivative and integral). The ordered history source (the Noether history source) preserves the order of the ordered product words rather than sorting by frequency, and the first and second time derivatives of the native history kernel return term by term to that source; the mother Euler's current variants, the forcing cosources and the mother return under the varying background are generated in the same actual construction—the history return is not an approximation but a termwise equality.

**(5) The real-current operator, signal jets and the feedback fixed point.**

*The real-current continuous linear operator.* The same preparation's real current generates a continuous linear operator on the complete 289-dimensional real field: the Bochner integral $\int_0^\infty e^{-\lambda t}J_t\,dt$ of the weighted current kernel converges for $\operatorname{Re}\lambda>0$, and the difference between finite window and half-axis satisfies the same tail bound (S6.5) in operator norm; the field version has the same conclusion.

*Real Fourier signals.* The two real orthogonal components of the original four-dimensional real Fourier signal $\operatorname{Re}(e^{ip\cdot x}a)$ are each a complex-linear operator; their 0-, 1- and 2-order time jets enter the actual ordered history input and agree term by term with the mother Euler—the signal causal response reads the same preparation to the field.

*Determinant–adjugate and the unique fixed point.* The feedback matrix is $I-\mathcal U$ ($\mathcal U$ the source-generated update operator, a composite of the original Green and the five-direction residuals, not an externally supplied projection). For any $289\times289$ matrix the determinant–adjugate identity holds unconditionally; at frequencies with $\det(I-\mathcal U)\neq0$ it gives an explicit two-sided inverse, and the response equation $\varphi=f+\mathcal U\varphi$ has the unique fixed point $\varphi=(I-\mathcal U)^{-1}f$.

*The source-generated instance and the $3/16$ bound.* The source anchor takes the initial budget $B$ (source-generated bounds on the original Green norm, the time-jet matrix norm etc., $B\ge0$), the read gap $g=\frac1{8(1+B)}$, the clock $\lambda_0=3-g$ and the read frequency $3$. The genuine derivation of $3/16$: at the anchor frequency the feedback update operator splits into a Laplace-current term and an initial-value term, whose source prices give $\le\frac1{16}$ and $\le\frac18$ respectively, hence
$$\|\mathcal U\|\le\tfrac1{16}+\tfrac18=\tfrac3{16}.\tag{S6.6}$$
From $\|\mathcal U\|<1$ follows $\det(I-\mathcal U)\neq0$ (spectral radius below 1, zero kernel gives nonzero determinant), and the regular domain is nonempty; writing the response equation as $\varphi=f+\mathcal U\varphi$ gives
$$\|\varphi\|\le\|f\|+\tfrac3{16}\|\varphi\|\ \Longrightarrow\ \|\varphi\|\le\tfrac{16}{13}\|f\|.\tag{S6.7}$$
The initial cosource and the nine compatibility residuals are retained throughout.

**Direct use.** The Green equation of (1) and the zero spectral point of (3) serve directly Theorem 6.13's static pole domain, compatibility criterion and residue; the half-axis identity of (2) is consumed by 6.13(5)'s origin-weight formula; the feedback fixed point of (5) is the closed-form solution of 6.12's field feedback.

**Formal correspondence.** (1): AC `CanonicalPreparationSpatialFullFormFeed.lean` (`completeForm_source`, `transportedForm_fixed`), `CanonicalPreparationJointMixedResponse.lean` (`jointHessian_symmetric`, `mixedCurvatureMatrix_generated`), `CanonicalPreparationRawJointFiveTerms.lean` (`fiveKernel_generated`, `eulerCovector_generated`), `CanonicalPreparationOriginalPreparedGreen.lean` (`original_green_equation`, `original_forced_field`, `generatedRegularPoint`: the right-inverse identity term by term by `decide +kernel`), `CanonicalPreparationPhysicalFeedbackField.lean` (`physicalField_derivative`). (2): AD `CanonicalPhysicalLaplace.lean` (`timeBound cut t = Σ_{n<57}(|t|‖cut‖)^n`), `CanonicalPreparationPhysicalTimePolynomial.lean`, `CanonicalPreparationPhysicalSourceGrowth.lean`, `CanonicalPreparationPhysicalActualEnvelopes.lean`, `CanonicalGradedMixed.lean` (`graded_mixed_zero`, `source_homogeneous_zero`), `CanonicalPreparationPhysicalFullHalfAxis.lean` (`weighted_integrable`, `halfForcing`, `halfForcing_readback`, `halfField_equation`, `halfField_cosources`), `CanonicalPreparationPhysicalControlledFieldTail.lean` (`actual_controlled_field_tail`, `explicitSourceTail`, `source_scalarCoefficient`). (3): AD `CanonicalSourcePropagationAxisReadback.lean` (`actualResolvent_{left,right,isUnit,spectral}`, `actual_spectrum_axis`, `zero_transfer_{source_kernel,pencil_unit,resolvent_unit,prepared_pole_read,actual_spectral_point}`), `CanonicalSourcePropagationSourceSpectralInverse.lean` (`sourcePencilUnit`, finiteness of `sourcePoleSet`, `sourceSpectrum_sub_poles`), `CanonicalSourcePropagationSpectralAxis.lean`. (4): AD `CanonicalSourcePropagationActualBackgroundEvolution.lean`, `CanonicalSourcePropagationActualPreparedHistoryVariation.lean` (`historyPrimal/Dual Variation_generated`, `orderedHistoryDirection_*`), `CanonicalSourcePropagationActualNativeHistoryReturn.lean` (`actualPreparedHistoryKernel`, `actualPreparedHistorySource`). (5): AE `CanonicalPreparationSourceHalfAxisCurrentOperator.lean` (the `sourceHalfCurrent` integral, `sourceHalfCurrent_generated`, `sourceWindowJacobian` norm convergence and the $(2/\operatorname{Re}\lambda)\cdot\text{sourceCurrentPrice}\cdot e^{-(\operatorname{Re}\lambda/2)T}$ tail), `CanonicalPreparationSourceHalfAxisFieldOperator.lean`, `CanonicalPreparationSourceNativeFourierHistory.lean` (`sourceSignalOperator_{left,right}`, `sourceHistoryInput`), `CanonicalPreparationSourceOrderedSignalOperator.lean`, `CanonicalPreparationSourceSignalCausalResponse.lean`, `CanonicalPreparationSourcePreparedSignalEuler.lean`, `CanonicalPreparationSourceCurrentFeedbackAdjugate.lean` (`sourceFeedbackMatrix_actual`, `sourceFeedbackAdjugate_{left,right}`, `sourceFeedbackResolvent_{left,right}`, `sourceFeedbackResponse_{generated,unique}`), `CanonicalPreparationSourceAnalyticRegularPoint.lean` (`sourceInitialBudget`, `sourceAnchorGap` $g=1/(8(1+B))$, `sourceAnchorClock` $3-g$, `sourceAnchorUpdate_price` $\le3/16$, `sourceAnalyticResolvent_price` $\le16/13$, `sourceAnchorDenominator_ne_zero`, `sourceRegularDomain_nonempty`). Commits AC, AD, AE.

---

## S7 Theorem 6.13: poles, constraints and the static residue

**Objects and domain.** The $H_{289}$ (original Jacobi) of Theorems 6.11–6.12, the original Green $G(p)$, the Green data $L$ (row lift), $R_b$ (read-back, $R_bL=I$), $P_{\rm null}$ (the nine-dimensional null-direction projection), and the five-factor current read-port and response point $q$ of 6.12. The rest octet is indexed by eight indices $l,r$; the moving octet basis at momentum $p$ is given by the source's $4\times4$ Hermitian matrix, four states on each chirality. This section's static tensor is written $S$; the time-jet integral term of 6.12(2) is $\Sigma^+$, and the two no longer share a letter. The main text's "uncleared-field limit of a varying forcing" is carried by `actualAxisWindow_tendsto` and `axisCosource_tendsto`, `axisNullCosource_tendsto` (see the formal correspondence below).

**Inputs and quantifiers.** (1) for every three-momentum and Gauss operator $A$; (2) for every $F$, non-real $z$ and momentum pair; (3) for every $\kappa$ in the static domain (a nonempty punctured interval), forcing $f$ and the actual transfer (left momentum $-\kappa e_1$, right momentum $0$, $\lambda=0$, finite window $T$), the residue limit taken along $\kappa\to0$ inside that domain; (4)(5) for every response point, two-leg momenta, rest-state indices, $\lambda$ and finite window $T$.

**(1) The moving carrier and the overlap unitary.**

> **Lemma S7.1.** The overlap matrix $U(p)$ of the moving basis against the rest octet is unitary: the same-$\varepsilon$ preparation's orthonormality gives $U(p)^\dagger U(p)=I$, and in finite dimension the right inverse follows (there is also an explicit two-sided unitarity); $U(0)=I$. The preparation, production operators, primal legs, fibre vectors and same-$\varepsilon$ preparation at momentum $p$ are all $U(p)$ combinations of the rest ones; the readout tensor satisfies
> $$M(p_L,p_R)[A]=U(p_L)^{\dagger}\,M(0,0)[A]\,U(p_R),\tag{S7.1}$$
> i.e. the whole operator $A$ is retained and the octet only carries the outer coordinates.

*Proof.* Orthonormal columns give the left inverse; in dimension $8\times8$ a left inverse is unitary, and there is additionally a layered two-sided unitarity construction. The tensor formula comes from the bilinear expansion of the inner product at both ends: each outer coordinate picks up one $U$. ∎

**(2) Momentum-affinity and joint continuity.**

> **Lemma S7.2.** The compression $C_F(p)=C_F(0)+v_F(p)$, where $v_F$ is a continuous real-linear momentum action, so $\|C_F(p)-C_F(k)\|\le\|v_F\|\,\|p-k\|$; by the resolvent-difference formula (S0.4), $\|R_p(z)-R_k(z)\|\le|\operatorname{Im}z|^{-2}\|v_F\|\,\|p-k\|$. The finite retainer set and the retained term $A_F$ are the same across momenta, hence the joint generator, joint resolvent, joint time evolution, the 289 read-ports, the five-factor tensor and the finite Laplace window are all continuous in the momentum (each continuity declaration generated separately). No continuity of any single spectral label is assumed.

*Proof.* The momentum action is real-linear through quantization and the fixed compression, so boundedness of the velocity operator gives the Lipschitz constant $\|v_F\|$; the resolvent difference follows by taking norms on both sides of the difference formula. The retainer set depends only on the fixed retainer index set and $F$, not on $p$, hence the retained term is the same across momenta; the joint generator's momentum difference is controlled by the same velocity bound, and the time evolution, as a norm-exponential composite of the generator, stays continuous. ∎

**(3) The static pole and the residue.**

> **Lemma S7.3 (The static principal block).** At the physical momentum $p_\kappa=(0,i\kappa,0,0)$, all $\kappa$-containing dictionary terms of $H_{289}$ collect by $-\kappa^2$ into a leading term $-\kappa^2S$, with $S$ the static tensor. $S$ is explicitly invertible under the extension by the 98-dimensional complement plus the five-direction block (verified by the termwise product of the source-generated inverse list), with a source-generated norm budget; the normalized kernel is invertible inside a source-generated positive radius (a Neumann-type argument), and that radius gives the nonempty punctured static domain.

> **Lemma S7.4 (The pole decomposition).** Inside the punctured static domain, the uncleared complete 289-dimensional Green decomposes as
> $$\begin{aligned}G(\kappa)f=\ &\text{contact term}\ +\ (-\kappa^2)^{-1}\cdot V_0S^{-1}V_0^{\mathsf T}\!f\\ &+\ \text{regular part on the 98-dimensional complement},\end{aligned}\tag{S7.2}$$
> with the nine null-direction forcings retained. Each factor is continuous as $\kappa\to0$: the normalized inverse converges to the padded inverse $S^{-1}_{\rm pad}$, the effective frame converges to the native five-direction frame $V_0$, and the readout converges to $V_0^{\mathsf T}$. Hence for fixed forcing $f$,
> $$-\kappa^2\,G(\kappa)f\ \longrightarrow\ V_0S^{-1}V_0^{\mathsf T}f=:\rho_{\rm st}(f).\tag{S7.3}$$
> For a varying forcing, the same decomposition's axis window and axis cosource each have uncleared-field limits (`actualAxisWindow_tendsto` etc. in the formal correspondence).

*Proof.* The contact term and the complement term tend to zero after multiplication by $-\kappa^2$; the middle term's factors converge termwise and compose; the static domain's nonemptiness is given by Lemma S7.3's positive radius. ∎

> **Lemma S7.5 (The origin weight and the mode readout).** The five-direction origin embedding $E_0:\mathbb C^5\to\mathbb C^{289}$ (the native frame through the original change of variables) acts on the two-component vector; for the actual transfer's current, the residue is
> $$\rho_{\rm st}=E_0\Bigl(-\tfrac9{125}\sqrt{30}\,\mathfrak{w},\ -\tfrac{67}{72}\sqrt{30}\,\mathfrak{w},\,0,0,0\Bigr),\qquad \mathfrak{w}=\tfrac{3\sqrt2}{10}\bigl(J_{21}-J_{34}\bigr)=-c_{114},\tag{S7.4}$$
> where $-\tfrac9{125}\sqrt{30}$, $-\tfrac{67}{72}\sqrt{30}$ are the two exact components of $S^{-1}$ acting on the five-direction weight ($\sqrt{30}=\sqrt2\sqrt{15}$); $\mathfrak{w}$ is exactly the negative of actual cosource number 114 (see (4)), and the two gauge slots are indices $21$ and $34$.

**(4) The constraint compatibility criterion and row 114.**

> **Lemma S7.6 (Axis-field compatibility).** Applying both sides of the original Green equation (S6.2) to the actual window field:
> $$H_{289}\,\varphi=w_{\rm win}-L\,(\text{nine-dimensional axis null cosource});\tag{S7.5}$$
> hence $H_{289}\varphi=w_{\rm win}$ if and only if the nine-dimensional axis null cosource vanishes—the forward direction direct, the converse using $R_bL=I$ (read back through the original change of variables of $\Xi$). The criterion is a condition given by the theorem, not generated by it.

> **Lemma S7.7 (Constraint row 114).** Row 114 of the original read-back is a sum of three linear readings: a charge term, a covariant-constraint term and an unsupported term; the unsupported term is identically zero on the actual current window and on the half-axis. Hence actual cosource number 114 retains only the charge and covariant terms, whose Ward boundary form is in (5).

*Proof.* The equivalence of $H_{289}\varphi=w_{\rm win}$ with the vanishing of the nine-dimensional cosource is two lines of linear algebra from (S6.2) and $R_bL=I$; the threefold decomposition of row 114 is a rowwise expansion of the read-back matrix, and the unsupported term's vanishing follows from that row's termwise structure on the actual current; $\mathfrak{w}=-c_{114}$ is the rowwise equality of the actual cosource and the original large weight. ∎

**(5) The contact–deviation decomposition of the origin weight, the weighted Ward form and the price.**

*The contact–deviation decomposition.* $\mathfrak{w}$ decomposes as the native contact window minus the configuration-deviation window:
$$\begin{aligned}\mathfrak{w}&=\kappa_{\rm ct}-\delta_{\rm cf},\qquad \kappa_{\rm ct}=\int_0^T\!(\text{pole readout}\circ\text{contact kernel})\,dt,\\ \delta_{\rm cf}&=\int_0^T\!(\text{pole readout}\circ\text{deviation kernel})\,dt,\end{aligned}\tag{S7.6}$$
holding pointwise by the actual relation of the mode readout's contact and deviation kernels.

*The Laplace-weighted Ward form.* The actual cosource number 114, for every spectral parameter $\lambda$ and finite window $T$, is
$$\begin{aligned}c_{114}(\lambda,T)=\ &\int_0^Te^{-\lambda t}\,(\text{N1 colour Ward readout})\,dt\\ &+\int_0^Te^{-\lambda t}\,(\text{covariant constraint current})\,dt-\Bigl(e^{-\lambda T}Q(T)-Q(0)\Bigr),\end{aligned}\tag{S7.7}$$
the three terms corresponding respectively to (4)'s charge term (the N1 normalization agrees with the primal normalization), the covariant term and the integration-by-parts boundary; (3)'s actual transfer takes $\lambda=0$ (weight identically 1), where
$$\mathfrak{w}=\kappa_{\rm ct}-\delta_{\rm cf}=-c_{114}(0,T),\tag{S7.8}$$
i.e. the formula of the main text (5).

*Price.* The deviation window is controlled by the $|\operatorname{Im}\cdot|^{-1}$ bounds of the two matter resolvents and the operator norm of the deviation read-port $D_0F$:
$$|\mathfrak{w}-\kappa_{\rm ct}|=|\delta_{\rm cf}|\ \le\ \frac1{|\operatorname{Im}z|}\,\|D_0F\|\,\frac1{|\operatorname{Im}w|}\cdot|T|,\tag{S7.9}$$
and the residue error is further multiplied by the norm of the complete five-direction pole vector (that vector being the two nonzero component columns of $E_0$). The native residue convergence and the price hold together.

**Boundary note.** The $\kappa$ static limit and the matter Abel limit are taken separately and their order does not commute; the original constraint residue here retains its native Ward identity; S11.4 proves the physical EM contraction and its readings from the same Green function.

**Direct use.** The residue formula (S7.4) and the compatibility criterion are the endpoint of §6.13; the mode kernels and the time evolution of $Q(T)$ are reused in 6.14's diffusion decomposition.

**Formal correspondence.** `alpha-source/CanonicalPreparationSource{MovingPoleCurrent,MovingPoleGaussPreparation,MovingPoleGaussVertex}.lean`, `CanonicalPreparationSourceStaticPoleDomain.lean` (`staticTensor_generated`, `paddedStaticInverse_{left,right}`, `normalizedKernel_isUnit`, `normalizedKernel_inverse_price`, `staticRadius_pos`, `staticDomain`), `CanonicalPreparationSourceStaticOriginalGreen.lean` (`staticNativeField_{uncleared,whole}`, `staticDomain_nonempty_regular`), `CanonicalPreparationSourceStaticActualPole.lean` (`staticNativeField_{pole_factor,pole_price,residue}`, `staticResidue`, `normalizedInverse_tendsto`, `nativeEffectiveFrame_tendsto`, `actualStaticField_{whole,schur,pole_price}`, `actualOriginWeight`), `CanonicalPreparationSourceModeCurrent.lean` (`sourceMode{Kernel,Current}_generated`, `actualOriginWeight_sourceReader`, `actualCurrent_staticResidue_modeReader`, `actualRestState_mode_charge_clock`, `sourceModeStatic{Coefficient,Residue}_generated`, `sourceModeHalfWeight_Abel`), `CanonicalPreparationSourceFullOriginCurrent.lean` (`fullNativeOrigin`, `actual_current_ward`, `actual_effective_dynamics`, `actual_complement_return`, `actual_native_reconstruction`, `actual_forcing_twoSectors`), `CanonicalPreparationSourceConstraint{Read,Boundary}.lean` and `CanonicalPreparationSourceColorBoundaryWard.lean` (`constraint114_source_linear`, `constraintUnsupported_actual{Window,Half}_zero`, `sourceActualCosource114_generated`, `sourceActualCosource114_actualWardBoundary`), `CanonicalPreparationSourceN1{Prepared,NormalWard,Dynamics}.lean` (`sourceActualN1Primal_*`, `sourceActualCosource114_N1WardBoundary`—the Laplace-weighted (S7.7), `actual{C,A,Generator,Time}_sourceN1_range`). The files above are byte-identical between AE and CAP, first pinned at AE.

(1)(2)'s carrier and continuity and (4)(5)'s decomposition, compatibility and price are pinned at CAP: `CanonicalPreparationSourceMovingCarrier.lean` (`movingOverlap_right_unitary` and the layered `movingOverlap_*` composites), `CanonicalPreparationSourcePreparedTensor.lean` (`sourceTensor_generated`, `actualModeTensor_{generated,same_carrier}`), `CanonicalPreparationSourceMomentumContinuation.lean` (`actualC_affine`, `actualC_difference_price`, `actualC_continuous`, `sourceResolvent_difference_price`, `sourceTime_continuous`, `sourceModeKernel_continuous`, `actualModeTensor_continuous`, `movingOverlap_zero`, `actualModeWindow_continuous`), `CanonicalPreparationSourceRetainerMomentum.lean` (`sourceRetainer_momentum`, `actualA_momentum`, `actualJoint{Generator,Resolvent,Time}_continuous`), `CanonicalPreparationSourceReaderMomentum.lean` (`rawReader_momentum_continuous`), `CanonicalPreparationSourceFullPoleTensor.lean` (`actualAxisField_{whole,residue,coupled_residue}`, `actualAxisWindow_tendsto`—the uncleared-field limit of a varying forcing), `CanonicalPreparationSourceReferenceContact.lean`, `CanonicalPreparationSourceModeNativeSymbol.lean`, `CanonicalPreparationSourceModeContactRead.lean` (`sourceContactKernel`, `sourceDeviationKernel`, `sourceActualMode_contact_deviation`—the contact–deviation pointwise relation of (S7.6), `sourceDeviationReader`), `CanonicalPreparationSource{GaussConnection,GaussKineticTorque,GaussColorWard}.lean` (the Ward identities of colour charge, covariant torque and configuration torque), `CanonicalPreparationSourceNativePoleBalance.lean` (`nativeContactWindow`, `configurationDeviationWindow`, `actualOriginWeight_native`: $\mathfrak{w}=\kappa_{\rm ct}-\delta_{\rm cf}$, `origin_native_Ward_balance`, `actualOriginWeight_residue_tendsto`), `CanonicalPreparationSourceNativePolePrice.lean` (`configurationDeviationPrice`, `actualOriginWeight_native_price`—(S7.9), `sourcePoleVector`, `actualResidue_price`), `CanonicalPreparationSourceAxisCompatibility.lean` (`actualOriginWeight_cosource114`: $\mathfrak{w}=-c_{114}$, `actualAxisField_constraint_residue`, `actualAxisField_compatibility`: $H_{289}\varphi=w_{\rm win}\iff$ the nine-dimensional axis null cosource vanishes). The original Green equation of (4) is shared with 6.12(1) at AC `CanonicalPreparationOriginalPreparedGreen.lean`'s `original_green_equation`.

Direct consumers: `alpha-source/AuditCanonicalPreparation{SharedPoleCarrier,FullPoleContinuation,PhysicalModeContact,PhysicalGaussColorTorque,PoleConstraintReturn}.lean`. Commits AE (the static and Ward main line) and CAP (moving carrier, momentum continuity, pole decomposition, compatibility and price).

---

## S8 Theorem 6.14: the matched whole-word budget and the renormalized endpoint's common tail

**Objects and domain.** The complete native-history Hamiltonian $H_0$, its finite compression $C_F=H_0-d_F$ ($d_F$ the retained term), operators on the quantum test space $\mathcal Q$ (written End), the damping parameter $\sigma=\mu>0$, and the composite-source clock $\varphi$. Two seeds $(g,\rho g)$ generate the normalized state $w$; $A=aD$ is the product of the root action and the Gauss direction, $U=a^2$; $D_c$ is the central direction; $n=\sqrt{54/125}$ is the lapse. The delayed frequency $z=\mathrm{line}(\mu,t)$ satisfies $\operatorname{Im}z\ne0$.

**Notation.** $R_3$ is the literal delayed word (the matched source word $R_{\rm forcing}$ in the source); $J_3$ is the matched price $\Pi_{m,\ell,F,z}(g)=P_3(w)+12\,\mathrm{cp}(z,w,v)/n-3\,\mathrm{contact}_{\rm cf}$, where $P_3$ is the native pressure term (a real pairing of a pair of native pressure operators on $w$, defined in Lemma S8.1) and $\mathrm{cp}$ the local clock price; $\mathrm{sh}_{40}(w)=\sum_i\|\mathrm{sh}_{40,i}w\|^2$ is the second moment of the 40-shifted columns ($\mathrm{sh}_{40,i}$ the shifted-column operators); $\mathsf{sc},\mathsf{cf}$ are respectively the scalar form and the coframe Gram; $M_\mu(k)$ is the source $\mu$-factor, $P_\rho$ the radius price, $C_{\rm J}$ the closed joint cost, $\mathcal E$ the renormalized endpoint and $R_{\rm df}$ the diffusion remainder.

**Inputs and quantifiers.** (1) for all $m,\ell,F$, non-real $z$ and domain elements $g$; (2) for every $\varepsilon>0$, $\mu>0$ and domain elements $g,k$, there is an $N$ such that all $m\ge N$, $\ell\ge m$, cofinal $F$ and **both** sharp cutoffs (one boolean choice, two values) hold uniformly; (3) the same quantifiers as (2) but with the object replaced by the absolute endpoint integral, over the two causal ports (one boolean choice); (4) on cofinal $F$ for all $m,\ell,z,g$.

**Key lemmas.**

> **Lemma S8.1 (The matched positive source).** Write the matched column $C_3:=UD+3iD_cU$ ($D_c$ the central direction) and the native pressure term
> $$P_3(f)=\operatorname{Re}\bigl\langle f,\bigl([A,[A,H_0]]+3U[D,H_0]+2U\,M_{\rm matter}+\tfrac85U\,V_{\rm vac}\bigr)f\bigr\rangle.\tag{S8.0}$$
> The tester identity, the exact phase correction and the slotwise lower bound hold together:
> $$\mathcal T:=C_3+2U=UD+3iD_cU+2U=UD+i\,U\bigl(3D_c+4i\bigr),\qquad J_3=R_3+6\,\sigma\,\operatorname{Im}\langle C_3w,w\rangle,\tag{S8.1}$$
> $$J_3\ \ge\ \tfrac{3n}{8}\|C_3w\|^2+\tfrac{5n}{2}\mathsf{sc}(Uw)+10n\,\mathrm{sh}_{40}(w)+\tfrac{3n}{4}\mathsf{cf}(Uw)+18n\|w\|^2,\tag{S8.2}$$
> every right-hand slot nonnegative, and $P_3(w)\le4J_3$.

*Proof sketch.* The tester's two forms are interchangeable through the commutation relation $D_cU-UD_c=2iU$ (the inverse-expansion relation), a finite operator identity; the phase correction is the termwise expansion of $J_3-R_3$ (the merging of the pressure term with the $U$ cross terms, substituting $D$'s generator commutation relation); the lower bound is the matched slot expansion: the local clock price's lower bound, the nonnegativity of the scalar form and the coframe Gram, the shift moment and the state energy term by term nonnegative. $P_3\le4J_3$ is a corollary of the same slot expansion: the pressure term is controlled by four times the clock-price and Gram slots. ∎

> **Lemma S8.2 (Common phase payment).** For $\mu>0$, $g$ and every $\varepsilon>0$, there is an $N$ such that all $m\ge N$, $\ell\ge m$, cofinal $F$ and the two causal ports satisfy
> $$\int_{\mathbb R}\bigl(J_3-2R_3\bigr)_+\,dt\ \le\varepsilon\tag{S8.3}$$
> This is a **positive-part** integral, not an absolute-value bound: only the side $J_3>2R_3$ is paid—the intervals where $J_3-2R_3$ is negative incur no liability (the exact form is $\int^{-}\mathrm{ofReal}(J_3-2R_3)\le\varepsilon$). The absorption chain: by (S8.1) exactly $J_3-2R_3=12\sigma\operatorname{Im}\langle C_3w,w\rangle-J_3$ ($\sigma=\operatorname{Im}z$, and on the actual frequency $\sigma=\mu$); the phase price inequality (Cauchy–Schwarz then Young, taking $t=\eta\cdot3n/8$ and using the slot $\tfrac{3n}{8}\|C_3w\|^2\le J_3$ of (S8.2)) gives
> $$\bigl|6\sigma\operatorname{Im}\langle C_3w,w\rangle\bigr|\ \le\ \eta J_3+\frac{24\sigma^2}{n\eta}\|w\|^2;$$
> taking $\eta=\tfrac12$ gives $J_3-2R_3\le2\bigl|6\sigma\operatorname{Im}\langle C_3w,w\rangle\bigr|-J_3\le\tfrac{96\sigma^2}{n}\|w\|^2$, so the positive-part integrand is controlled by $K\cdot$(normalized state energy), $K=96\mu^2/n$; the normalized response's ordinary common tail, at target $\varepsilon/(K+1)$, gives the same $N$ and pays both phases at once.

> **Lemma S8.3 (Radius budget).** The radius-square decomposition
> $$\rho^2=1+\tfrac{2\|\mathrm{vac}\|^2}{25}+\tfrac12\|\varphi-\tfrac{2\mathrm{vac}}5\|^2-\tfrac14\|\varphi-\tfrac{4\mathrm{vac}}5\|^2\tag{S8.4}$$
> gives
> $$\|v_\varphi\|^2\le\Bigl(1+\tfrac{2\|\mathrm{vac}\|^2}{25}\Bigr)\|w\|^2+\frac{J_3}{20n}.\tag{S8.5}$$

*Proof.* The $\|\varphi-\tfrac{4\mathrm{vac}}5\|^2$ term is paid by the $10n\,\mathrm{sh}_{40}(w)$ slot: $10n\,\mathrm{sh}_{40}\le J_3$ (all slots of (S8.2) nonnegative), so $\tfrac12\mathrm{sh}_{40}\le J_3/(20n)$, substituted into the radius identity. ∎

> **Lemma S8.4 (The endpoint common tail).** The renormalized second Green endpoint
> $$\mathcal E=\operatorname{Re}\langle k,(H_0-\operatorname{Re}z)Aw\rangle-\|k\|^2\operatorname{Re}(1/z)\tag{S8.6}$$
> reads on cofinal $F$ only two original $H_0^2g_i$ inputs (a fixed endpoint word); its absolute whole-frequency $L^1$ tail has a common $N$: $\int|\mathcal E|\,d\omega\le\varepsilon$, holding for both causal ports at once. The derivation has two halves: the fixed-frequency price satisfies the source-generated bound
> $$\mathrm{fixPrice}(m,\ell,\mu,\eta)\ \le\ 4\eta\cdot\frac{\pi}{\mu}+C(\mu,\eta,g)\cdot\Sigma,\tag{S8.7a}$$
> where $\frac{\pi}{\mu}=\int_{\mathbb R}\frac{dt}{t^2+\mu^2}$ is the mass of the Lorentz-type kernel (the coefficients $\frac{\pi}{4\eta\mu^3}+\frac{\pi}{4\eta\mu}$ times second-order source masses enter $C$) and $\Sigma$ is a sum of fixed-source squared norms. Taking $\eta=\varepsilon\mu/(8\pi)$ gives $4\eta\cdot\frac{\pi}{\mu}=\frac{\varepsilon}{2}$; then the source's fourth-order jets and the Ritt third- and fourth-order gradient bounds (constants 32, 256) press $\Sigma$ below $\varepsilon/(2(C+1))$, hence $C\Sigma\le\varepsilon/2$ and the total $\varepsilon$.

> **Lemma S8.5 (Diffusion covariance).** The diffusion flow $\Gamma_L(X)=\mathcal D^{\mathsf T}X+X\mathcal D-2AXA$ ($\mathcal D=A^2-3D_{\rm clk}$, $D_{\rm clk}$ the drift-clock operator) satisfies
> $$\Gamma_L(1)=0,\qquad \Gamma_L(V)=18\cdot1\tag{S8.7}$$
> ($V$ the volume action, $VU=I$); the noise kernel $K_t(x,y)=2\int_0^t\rho_s(x)\rho_s(y)\,ds$, $\rho_s=(V(x)+18\max(s,0))^{-1/2}$, is positive definite for every finite point family; the carré retains the complete cross:
> $$\Gamma_L(X^2)-\Gamma_L(X)X-X\Gamma_L(X)\big|_{X=H_0}\ =\ 2\,\|[A,C_F]f+[A,d_F]f\|^2.\tag{S8.8}$$
> The regularized deviation $\|A-\mathcal D_t\|^2$ has a common payment $(192t/n)J_3$ and, under the same quantifiers, a whole-frequency tail.

**Decisive derivation.** (1) is Lemma S8.1. (2) combines three budgets: the radius-response price budget under a sharp cutoff ($C_{\rm J}\le\varepsilon/2+C\cdot(\text{homogeneous term}+4\,\text{phase budget})$), the homogeneous radius budget ($\delta$) and the common phase payment ($\delta$, whose $\varphi$-response budget has the form $\delta+2(\mu/(20n))\int R_3^{\,+}$); the phase error is converted, through Lemma S8.3's $J_3/(20n)$ factor, into the matched word's positive-part integral $\int R_3^{\,+}:=\int(R_3)_+\,dt$ (the source form $\int^{-}\mathrm{ofReal}\,R_3$), with coefficient
$$C\cdot5\delta+4C\cdot\bigl(2\,\mu/(20n)\bigr)\cdot\int R_3^{\,+}\ \longrightarrow\ \varepsilon+48\,M_\mu(k)\,P_\rho\,\frac{\mu}{20n}\int R_3^{\,+}\tag{S8.9}$$
(taking $\delta=\varepsilon/(10(C+1))$ and $C=6M_\mu(k)P_\rho$, the coefficient identity $4C\cdot2\mu/(20n)=48M_\mu(k)P_\rho\cdot\mu/(20n)$ is checked term by term: $4\times6\times2=48$, agreeing with the right-hand side of `actual_original_native_matched_Gamma_budget`). (3) is Lemma S8.4. (4) is Lemma S8.5 and the literal expansion: on cofinal $F$,
$$R_3=\frac{\mathcal E}{\sigma^2}-\frac{D_{\rm ren}}{2\sigma^2}+R_{\rm df},\qquad D_{\rm ren}=W_{C_F}^{(2)}-2\|v_{\rm fix}\|^2\operatorname{Re}(1/z),\tag{S8.10}$$
where $W_{C_F}^{(2)}$ is the second-order $C_F$ word and $v_{\rm fix}$ the fixed column. The same family's diffusion-source price is, through the phase identity, exactly the matched price: $\Pi_{\rm df}=R_3+6\sigma\operatorname{Im}\langle C_3w,w\rangle=J_3$ (i.e. the electric-word form $W_{\rm elec}+6\sigma\operatorname{Im}\langle C_3w,w\rangle$), not $R_3$ itself.

**Boundary note.** (2) is a budget for the two prescribed sharp cutoffs and the original source responsibility, not a statement about the complete $C_F$ semigroup; $D_{\rm ren}$ and $R_{\rm df}$ are the parts of $R_3$ settled by their own consumers.

**Direct use.** The matched price of (1) is the common balance of (2)(4); the endpoint tail (3) gives the positive measure of the end of §6.9 a corresponding whole-frequency convergence on the composite-source clock.

**Formal correspondence.** `external-composite-decay/SourceClockPhiNativeMatchedSource.lean` (`matchedColumn`, `matchedTester`, `matchedPrice`, `matchedForcingWord`, `actual_native_matched_source`, `actual_native_matched_common_payment`), `SourceClockPhiNativeMatchedGammaBudget.lean` (`radius_shifted_norm`, `actual_original_native_matched_radius_budget`, `matchedBudget`, `actual_original_native_matched_Gamma_budget`), `SourceClockPhiRenormalizedSecondGreen{,Tail}.lean` (`renormalizedEndpoint`, `actual_renormalized_fixed_source`, `actual_renormalized_endpoint_absolute_common_tail`), `SourceClockPhiMatchedDiffusionSource.lean` (`diffusionDrift`, `diffusionCurrent`, `noiseKernel`, `diffusionRemainder`, `original_matched_diffusion_covariance`, `fixedEndpointWord`, `actual_matched_diffusion_source`), `SourceClockPhiFixedSourceJets.lean`, `SourceClockPhiRittHigherGradient.lean`. Commit AE; the original geometric bulk time budget `SourceGeometricBulkTimeBudget.lean` (`actual_original_geometric_budget`), used in the dependency closure through `SourceScalarEssentialBudget.lean`, is not in the AE commit, and its bytes are kept at Homework `fa15016c…` (see Appendix D.7 of the main text).

---

## S9 Propositions 9.1–9.3 and the public-experiment evidence of §9.2

Each item states its evidence class separately, following the three classes of Table 4 of the main text: **mathematics** (a source-internal formal theorem, with proof); **dual-implementation check** (two programs sharing no forward computation, each producing a frozen first receipt, then cross-checked); **statistical contract** (an anytime test with a pre-registered error budget, with statistic, budget and criterion given). Historical numbers not marked inside an item keep their original frozen identities of §9.2; this section re-runs no event stream or fit.

### S9.1 Proposition 9.1: the complete optical source domain and the joint 95% strictly positive CH

**Objects and domain.** The conditional source family of the NIST 2015 public counts: coordinates $(m,z,x,r,e)$ describe the same two-polarization TMSV, a common real Jones frame and scalar losses; $k=(1-2\lambda)T$ keeps the per-pulse phase mixture; the training data are six confidence intervals (four single, two joint).

**(1) Complete source (mathematics).**

> **Proposition S9.1a (Phase fibre).** The common sign constant $k$, the physical square bounds and all training slabs of a lawful original source hold if and only if there is a lawful phase $\lambda$ and a snapshot—generated inside the original source and a lawful $k$, not supplied by the caller.
>
> *Proof sketch.* The two directions of the "if and only if" are elimination and reconstruction: the forward translates the training intervals into linear constraints and square bounds on $k$; the reverse solves $\lambda=(1-k/T)/2$ back from $k$ and checks term by term that this $\lambda$ lands in the original lawful domain, every cell count of the snapshot generated by the same source. ∎

> **Proposition S9.1b (Mean map).** Four actual means recover the common covariance coordinates $(m,z,x,r)$; all single intervals hold if and only if the intersection of eight half-spaces does. Strict ascending ordering generates $z>0$, $R^2>0$.
>
> *Proof sketch.* The four means are linear readouts of the coordinates, invertibility given by the explicit nonzero determinant of the coefficient matrix; each single interval is a pair of half-spaces on the coordinates, four giving eight. ∎

> **Proposition S9.1c (Covariance source).** Every regular quintuple ($z>0$) and lawful $k$ generate by themselves an $\arctan$ common axis, the original RawSource and a lawful phase, and read back exactly the five coordinates and all cell/five-pulse windows; the pure-mode boundary $n_V=0$, $T=0$ and all $\lambda$ readouts are equivalently retained.
>
> *Proof sketch.* The axis is generated from $(x,r)$ by $\arctan$; $T$ and the two intensities are recovered from $m,z$ and the transmission relation; the read-back is a coordinatewise algebraic identity. ∎

**(2) Ports and infinite Born (mathematics).**

> **Proposition S9.1d (Environment ports).** The actual polarization action preserves $\mathrm{Pol}\otimes\mathrm{Env}$; the six ports generate, for every $T_H,T_V\in[0,1]$ and $|\xi|\le1$, the effect $\Gamma_n=O^\dagger X^{\otimes n}O$ of every $n$; $\xi=1$ recovers the original $\Gamma$ of all $n$; the two environment components cannot be replaced by the old occupation $\Gamma(R)$.
>
> *Proof sketch.* The port action is a native symbol realization of the two-mode unitary; $\Gamma_n$ is a blockwise identity per occupation number, positivity given by the effect as a compression; substituting $\xi=1$ gives the original $\Gamma$. ∎

> **Proposition S9.1e (Matched infinite Born).** The complete infinite Born joint probability in the matched case is
> $$Q_{AB}=\frac{1}{1+n_V\,(T_A+T_B-T_AT_B)}.\tag{S9.1}$$
>
> *Proof sketch.* The per-sector Born terms are generated by the actual source root and $D$ (keeping the complex phase and the sector mass budgets), summing over all $n$ is a geometric series whose denominator is $1+n_V(T_A+T_B-T_AT_B)$. ∎

**(3) Statistical fibre and members of both signs (dual-implementation check).** Each of the six training intervals may vary inside its complete interval; two independent covering trees (primary and independent implementations) each recompute term by term **81,922 nodes**, paying the initial whole domain, the outerness of every interval contraction, the complete partition, the exclusion grounds and all capped and boundary segments—the primary retains 15,061 blocks, the independent 11. The 512 members are each reborn from the native recipe: the primary's 256 Gaussian envelopes all contained, the independent's 256 actual Born envelopes all contained; **141 actual Born out-of-bounds counterexamples** (47 primary, 94 independent) uniformly include the held-out cells—for example the independent member no. 6's $j_{01}\approx0.00016726781197301952$ lies strictly above the original upper bound $0.00016712361973910759$; these sources satisfy all six training CIs, so the training constraints do not imply all held-out cells fall inside the bands, while the whole source family is not rejected.

On the all-data intersection $F_{\rm all}=F_{\rm train}\cap$ all public held-out CIs of the twelve CIs, the acceptance of another 81,922 nodes and 128 members gives: on every path **64 actual $\Gamma$/Fock sources** satisfy all twelve exact CIs with the complete outcomes, among them **41 strictly positive CH and 23 strictly negative CH**; concrete sign witnesses refute uniform strict positivity and uniform strict negativity over the whole $F_{\rm all}$ (the domain's sign certificate is registered as mixed of the two numbers). **This is a retrospective check of a conditionally consistent source family, not an identification of the actual apparatus configuration, and not a blind-state verification.**

**(4) Joint 95% domain (statistical contract plus mathematical kernel).** Inside the original $1/20$ joint budget, the actual setting exposures, all four outcomes and the source-generated exact normalized support function are additionally consumed:
$$h=\ell\cdot\mathrm{CH}-\varepsilon(1-\varepsilon)\min(c^{A}_{01},c^{B}_{10},c_{11}),\qquad d_k=1+2^{-k}h,$$
$$\log E_k=W_{\rm obs}\log a_k+L_{\rm obs}\log b_k-T\log d_k.\tag{S9.2}$$
where $c^{A}_{01}$, $c^{B}_{10}$, $c_{11}$ are respectively the A-side 01, B-side 10 and joint 11 outcome counts. The safe old failure bound is $3/(80\times32767)$; the total budget $1/20$ minus that failure bound is divided equally among the 24 complete-exposure contrast families and the $24\times4\times6\times40$ conditional-direction bets. The source kernel generates by itself the exact support vertices, the positivity of $d_k$ and the one-step expectation bound (`NormalizedSourceBet.lean`); the statistical cross certificates check term by term the 576 new intervals, 23,040 direction bets, 480 original fixed-bet base values and 24 rational inversion brackets. The new joint 95% acceptance domain is nonempty: **8 original $\Gamma$/Fock physical members** satisfy simultaneously the old 72 CIs, the new 96 conditional constraints and the four joint source cuts, the complete continuous outer cover holds, and **every** accepted source satisfies
$$\mathrm{CH}_{N5}>1.3790180504\times10^{-6}\tag{S9.3}$$
(the exact rational lower bound is kept by the certificate; the two statistical heads were frozen at `5a35416ec6` and `85d5b45efa`).

**(5) Public review (statistical contract).** The family upper bound of the 24 public spacelike source-signature families at $\alpha=0.05$ is approximately $0.00241643$; the whole continuous nominal domain of the named environment-calibration nominal model and the original confidence interval are strictly disjoint; the five published controls of the nineteen r6/r6.1 sources all deviate (that verdict keeps its original contract identity and is not reinterpreted as a new Bell count test).

**Direct use.** The source domain and ports of (1)(2) are the source kernel of the observation-generated slice of §9.2; the members and acceptance domain of (3)(4) are cited directly by Proposition 9.1 of the main text; (5) is the public-review entry of §9.2.

**Formal correspondence.** AD: `nist-real/nominal-replay/observable-closure/full-statistical-fiber/` (`PhaseFiber.lean`, `TrainingChart.lean`, `CovarianceSource.lean`, `CovarianceSourceCertification.lean`, `PhaseCertification.lean`; check receipts `cross-verification.json`, `all-data-verification.json`, `all-data-sign-certification.json`, `criterion.md`, `criterion-all-data.md`), `environment-source/` (`MatchedSource.lean`, `EnvironmentSource.lean`, `SectorSource.lean`; `criterion.md`), `public-review/source-compression/` (`NormalizedSourceBet.lean`; receipts `statistics-cross-verification.json`, `kernel-certification-first.json`, `domain-verification.json`, `source-compression-verification.json`) and `public-review/` (`complete-review*.json`). Commit AD. This writing re-ran no covering, member generation or statistical acceptance.

### S9.2 The remaining NIST/Storz public-experiment results of §9.2

**(a) The Storz nominal lock (existing frozen statistical contract).** The first 100000 trial rows of the ETH data [8,9] are read under the frozen rule; at $\alpha=0.025$ the zero-radius model is rejected: maximal $\log E=46803.6234$, the independent high-precision receipt $p_{\rm any}\approx2.783760711\times10^{-20327}$ (the `0.0` of the original JSON is a floating-point underflow). Radii $0.01,0.02,0.05$ are still rejected, $0.1,0.2$ not rejected. The phase-bridge gap (substituting the control map into the original CHSH sign definition gives $S=0$) keeps the standalone verdict on the underlying source theory **inconclusive**.

**(b) The NIST nominal replay r0003 (dual-implementation check).** The nominal model follows the frozen choices of §9.2 (the normalized $|HH\rangle+r|VV\rangle$ family, mirrored angles, efficiency-product joint counts, per-trial background, CH-type combination); the efficiency half-width was frozen beforehand at probability $0.003$. The numerical optima of the centre and 16 corners form the pre-declared band, widened by $\pm0.05^\circ$, $\pm0.0005$ to
$$r\in[0.3051567847356201,0.3257119970321657],\quad \theta_0\in[4.727559269219637^\circ,5.179646420478821^\circ],$$
$$\theta_1\in[-27.552833724021912^\circ,-26.90090064406395^\circ].\tag{S9.4}$$
The centre is $(0.315463895,\,4.954737358^\circ,\,-27.232869633^\circ)$. The five documented values $r=0.2872$, $\theta_0=4.2^\circ$, $\theta_1=-25.9^\circ$ and the two Bob mirror angles all lie outside the band (the primary implementation's verdict `REPLAY_DEVIATION_EXCEEDS_PREDECLARED_BAND`, the independent implementation the same). This is an optimality-band verdict on the nominal model under frozen inputs, not a new Bell event test, and it does not undo the original experiment's conclusion.

**(c) The Table S-II conditional source member (dual-implementation check).** On the four-cell full counts (five-pulse window, $N=177{,}358{,}351$, no-click outcomes kept), a full-Fock source is trained on cells 00, 01, 11 with the fourth cell held out: all 12 probability envelopes lie inside the simultaneous average-probability domain—a conditionally consistent member on public counts, not an identification of the actual apparatus configuration.

**(d) The AC observation-generated source slice and the two-Bob-angle update (dual-implementation check plus Lean consumers).** The revised slice takes only the four single and joint00 centres from cells 00 and 11, restores the original confidence interval for joint11, and holds out the two complete cells 01 and 10. The two independent covering constructions each produce **69 segments**: 32 entirely lawful, 35 exclusions and 2 boundaries, 68 partition cuts, no missing or repeated segments, no capped segment. The lawful outer interval $\eta_A\in[0.7411896212237604,\,0.7414274323892578]$; the canonical rational member $\eta_B\approx0.76465288593$, $\lambda\approx0.00409579367$, and the 12 mathematical probabilities of the two canonical members all lie inside the original CIs; the whole slice's prediction envelopes for the two held-out cells also fall inside the held-out CIs:
$$\text{01}:\,[0.00015821397237,\,0.00015855716089],\qquad \text{10}:\,[0.00015026944774,\,0.00015053199993].\tag{S9.5}$$
Keeping the same source and training phase, the two independent derivative systems give a strict finite update that **lowers both Bob angles by $0.01^\circ$** over the entire rounding box of $\pm0.05^\circ$ at the four angles (update angles $(4.2,-25.9,-4.21,25.89)$, common direction, step $1/100$ degree): the primary implementation's common gain lower bound $\approx1.99\times10^{-9}$, the independent implementation's $\approx1.69\times10^{-9}$, the independent Fock endpoint gain $\approx3.8493\times10^{-9}$. The Lean consumers (`ObservableClosure.lean`, `ClosureConsumer.lean`, `ScalarFiber.lean`, `ScalarFiberConsumer.lean`) read the slice back as source-family objects. **This is a conditional-consistency result on one named one-dimensional slice**: it claims no complete six-dimensional statistical fibre, identifies no actual hardware driver, and recovers no apparatus optimum.

**Formal correspondence.** AB: `nist-real/nominal-replay/{criterion-r0003.md,replay-r0003.json,independent_replay-r0003.json}`; AC: `observable-closure/{criterion-ef0002.md,verification.json,slice-primary.json,independent-slice.json,cross-receipt.json,receiver-criterion.md,receiver-verification.json}` and the four Lean consumers (above). Commits AB, AC.

### S9.3 Proposition 9.2: zero-empirical-input prediction, the complete atomic readout domain and same-law parameters

**Objects and domain.** The readout model of the atomic Bell experiment of Rosenfeld et al. [11]: Bloch probes are parametrized by $(\mu,u,z)$—$\mu$ the gain, $u$ the Bloch-vector part, $z$ the bias; effects $E_\pm$, probabilities $\Pr_\pm$; XZ axis settings.

**(1) Prediction lock (mathematics).**

> **Proposition S9.3a.** The original source generates, for all lawful XZ axes, probability families with the uniform bound $|S_{\rm CHSH}|\le2\sqrt2$; fixed orthogonal axes and a normalized bisector generate a 32-cell exact prediction reaching $2\sqrt2$. The constructor contains no data, device or calibration parameters.
>
> *Proof sketch.* The actual proof of the upper bound is explicit Cauchy–Schwarz: writing $S_{\rm CHSH}$ as the inner product of two four-vectors $u=(\pm a_0^x,a_0^z,a_1^x,\pm a_1^z)$ and $v=(b_0^x+b_1^x,b_0^z+b_1^z,b_0^x-b_1^x,b_0^z-b_1^z)$, the unitarity of the two axes gives $\|u\|^2=2$, $\|v\|^2=4$, hence $S_{\rm CHSH}^2\le8$, and taking the root $|S_{\rm CHSH}|\le2\sqrt2$ (uniform over the two herald signs). The 32-cell prediction is a per-cell algebraic value for four outcomes × two stations × four settings, satisfying normalization, nonnegativity, $\tfrac12$ marginals and the alignment; reaching $2\sqrt2$ is a cell-by-cell substitution of the fixed axes (diagonal directions $\pm1/\sqrt2$) into the CHSH formula. ∎

**(2) Complete readout domain (mathematics).**

> **Proposition S9.3b (Round trip).** Every lawful binary readout channel (including negative or zero gain) and XZ axis generates a compact effect $(\mu,u,z)$; conversely, the radius and the source cone generate a lawful channel and axis, and the round trip is exact; four effects give the complete domain of 12 real coordinates.
>
> *Proof sketch.* The forward is the Bloch decomposition of the effect matrix (compactness given by coefficient bounds); the reverse—the radius condition guarantees the constructed matrix is a lawful quantum effect and the source-cone condition guarantees the axis is lawful; the two-way composite is a componentwise identity. ∎

**(3) All trials (statistical contract).** The 10,201 and 10,202 valid pairs of the two Munich runs keep the original order; the test is the prefix-maximal likelihood ratio (anytime $e$-value) against the ideal zero-error surface: April is rejected at prefix **3974**, where it first crosses threshold 40 (maximal $E\approx494.849935$); the complete readout domain has one exact original witness in each run, and all 20,403 prefixes stay strictly below 40 (April maximum 1, June approximately 1.338729277); the two runs share a $1/20$ anytime budget.

**(4) Same law and fibre (mathematics).**

> **Proposition S9.3c.** Two lawful setting families give the same probability law if and only if the four biases and the two groups of X/Z product matrices agree—the maximal observational quotient of the whole domain; inside the regular range, a same-law effect is exactly a lawful reciprocal scale of one unique nonzero $(s,t)$.
>
> *Proof sketch.* "Only if": the probability equality holding on all inputs forces the two families' coordinatewise readouts to be equal—the biases are read from the constant terms, the product matrices from the quadratic terms; "if": the same parameters generate the same law. The actual structure of the scale: regularity gives $a_0^u b_0^u\neq0$ and $a_0^z b_0^z\neq0$, and the product-matrix equality, through a rank-one decomposition (rowwise/columnwise factorization with nonzero anchors), writes all $u$ coordinates of the other side as $s$-multiples and all $z$ coordinates as $t$-multiples, the opposite direction by $1/s,1/t$; the target effect is lawful if and only if $(s,t)$ satisfies the source cone's lawful-scale condition, in which case the other family is generated exactly by the scale transformation; the scale is unique—$s$, $t$ are recovered explicitly as ratios of the regular anchor coordinates, and any $(s',t')$ generating the same family must equal them. Hence inside the regular range, **every same-law effect is a lawful reciprocal scale of some unique nonzero $(s,t)$**. ∎

**(5) Response bounds (mathematics plus dual-implementation check).** Over the entire original confidence domain all effective gains are at least $0.36579$, and both kinds of gauge error rates are below $0.37916$: the bounds are given by the source-internal response formulas (the mathematical part), and the pointwise check over the whole confidence domain is done by the two independent implementations (the dual-implementation check).

**Direct use.** The readout domain of (2) and the same-law quotient of (4) are the whole input of Proposition 9.3; the witness domain of (3) is consumed by 9.3(1)'s joint gain upper bounds.

**Formal correspondence.** `Bell/TheoryBlind.lean` (prediction lock, CHSH bound, 32 cells), `Bell/ReadoutEffects.lean` (effect round trip), `Bell/ReadoutIdentification.lean` (same law, fibre, unique scale), `Bell/ReadoutResponseBounds.lean` (response bounds); `munich/` (`README.md`, `criterion-mu0001.1.md` and `readout-domain/`'s `parameter-recovery.md`, `history-source.md`, `verification.json`, `identification-verification.json`, `response-projection-verification.json` etc.). Commits AD (Lean entries), AE (Munich consumers).

### S9.4 Proposition 9.3: the hardware inverse, the pulse-realizable image and the original post-measurement history

**Objects and domain.** The same readout domain as S9.3; the detector effect $E_{\rm click}=dI+kJ$, $k=(1-d)\eta$; Garthoff's original 12-state matrices, 18 natural transitions and 7 ionization channels generate the GKSL dynamics; finite rectangular pulses.

**(1) Joint gain upper bounds (dual-implementation check).** The same whole-prefix joint domain gives 8 cross-setting gain product upper bounds and 6 maximal-ray bounds: April's maximal gain $>0.67020$, each side $>0.44918$; June's $>0.66386$, $>0.44071$ respectively. The two implementations each produced a frozen first receipt and the cross-checks agree.

**(2) Two-probe unique inverse (mathematics).**

> **Proposition S9.4a.** On the identified regular complete law, the signed responses to two source-known independent Bloch probes and a nonzero identification determinant give two-sided inverses, recover all family coordinates, and the effect family is unique; the probes may come from different settings, and zero determinant has a separate counterexample.
>
> *Proof sketch.* Probe responses are linear readouts of the family coordinates; when the two-probe response matrix has nonzero determinant, Cramer's rule gives two-sided inverses and recovers the coordinates term by term; uniqueness follows since any same-law effect gives the same response, and the inverse image is unique. At zero determinant the linear system is underdetermined, and an explicit counterexample gives two families sharing all responses. ∎

**Boundary note.** The two-probe unique inverse needs independently prepared probe inputs; the nominal settings and AOM channel identities of the original 2021 thesis [13] do not pay that input.

**(3) Detector fibre (mathematics).**

> **Proposition S9.4b.** $E_{\rm click}=dI+kJ$, $k=(1-d)\eta$; for positive gain, all lawful $(d,k)$ satisfy exactly
> $$0\le d\le m,\qquad M-d\le k\le1-d,\tag{S9.6}$$
> where $m=(1-\mu-g)/2$ and $M=(1-\mu+g)/2$ are the effect's minimum and maximum click probabilities; the inverse atom is unique, and $\eta\,\lambda_{\max}(J)\ge\dfrac{2g}{1+\mu+g}$.
>
> *Proof sketch.* The bound on $d$ is the physical range of the dark-count rate; the two-sided bound on $k$ is the eigenvalue-by-eigenvalue translation of the effect condition $0\le E_{\rm click}\le I$ on the spectrum of $J$—the spectral minimum gives the lower bound $M-d$, the maximum $1-d$; the inverse atom is unique because the Bloch expansion coefficients of $E$ recover $(d,k,J)$ uniquely; the efficiency lower bound follows by substituting $\eta=k/(1-d)$ into the spectral-end condition and rearranging. ∎

**(4) Atomic forward and pulse image (mathematics plus dual-implementation numerical forward).** This item has two evidence classes, stated separately and not merged.

*Mathematics (source-internal Lean theorems).*
> **Proposition S9.4c (Realizability characterization).** For a positive-gain effect and a named spectrum, write $b,d$ for the spectrum's bright and dark rates and $\gamma=b-d>0$ for the spectral gap: a pulse is realizable if and only if two source-internal squared inequalities hold,
> $$(u^2+z^2)(b+d)^2\le(1-\mu)^2\gamma^2,\qquad (u^2+z^2)\bigl(2-b-d\bigr)^2\le(1+\mu)^2\gamma^2,\tag{S9.7}$$
> equivalently if and only if the generated background rate and rate factor form lawful rates; when realizable, the atomic effect built from that spectrum and the generated axis, after the detector, equals the original effect coordinatewise (background rate $<1$, efficiency $\in(0,1]$); two different feasible spectra can realize the same effect with different atoms. This is an "if and only if" characterization of realizability and does not concern semigroup existence.
>
> *Proof sketch.* Realizability is by definition the two remainder inequalities of background and detector; substituting the rate factor $g/\gamma$ and multiplying by $\gamma$, the two remainders match exactly the two squared inequalities of (S9.7) (both sides nonnegative, so squaring is an equivalence); the realized effect expands coordinatewise back to the original $(\mu,u,z)$; the spectrum can be recovered from the effect's maximal/minimal atomic readouts, so different spectra are distinguished at the atomic level. ∎

> **Proposition S9.4d (Area cap).** Under lawful detector rates ($\mathrm{Rates}\,d\,k$), a realization relation $\mathrm{Realizes}$, background $d<1$, bias bound $|\mu|\le B$, efficiency upper bound $0\le\eta_{\rm up}\le1$ with $\eta\le\eta_{\rm up}$, squared-area bound $0\le A_{\rm up}$ with $\mathcal A^2\le A_{\rm up}$, and the **forward inequality** $p^{\rm at}_{\max}\le7\mathcal A^2/4$ all holding,
> $$g\ \le\ \min\Bigl(1,\ \frac{(1+B)\,\eta_{\rm up}\,\bar a}{2-\eta_{\rm up}\,\bar a}\Bigr),\qquad \bar a=\min\Bigl(1,\frac{7A_{\rm up}}4\Bigr),\tag{S9.8}$$
> where $\mathcal A=\int\Omega_{12}\,dt$ is the dimensionless readout Rabi area and $p^{\rm at}_{\max}=(1+\mu_{\rm at}+g_{\rm at})/2$ the atomic effect's maximal click probability. The forward inequality itself is a conclusion of the numerical forward (next paragraph), not an internal conclusion of this theorem's premises; the theorem gives the gain bound given that forward inequality.
>
> *Proof sketch.* Atomic-readout upper bound: $p^{\rm at}_{\max}\le\min(1,7A_{\rm up}/4)=\bar a$ (composing the atomic gain $\le1$ with the forward inequality and the area bound); hence the efficiency×atomic product $\eta\cdot p^{\rm at}_{\max}\le\eta_{\rm up}\bar a\le1$; substituting into the product-cap theorem (raw_product_cap_gain: when $\eta\cdot p^{\rm at}_{\max}\le c\le1$, $g\le\min(1,(1+B)c/(2-c))$) gives (S9.8). ∎

*Dual-implementation numerical forward.* The GKSL forward of Garthoff's original 12-state matrix, 18 natural transitions and 7 ionization channels [12] is simulated separately by two programs sharing no forward computation, giving: (i) the forward inequality $\mathrm{gain}\le\min(1,7\mathcal A^2/4)$ consumed by Proposition S9.4d (the fixed-chart model's `source_inequality`, primary and independent receipts agreeing); (ii) strict lower bounds on each run and side's maximal readout Rabi area and its square (e.g. the 2016-04-15 uniform ray $\mathcal A^2>46056427315/120259084288$, $\mathrm{gain}>46056427315/68719476736$); (iii) the four named pulses realizable on all 32 domains of two runs × four roles, with six strictly different atomic responses still giving the same joint probabilities and every prefix factor (per-domain receipts). Note that the receipts also register `atomic_response_forward_model_kernel_proved=false`: the 12-state forward model itself is a dual-implementation numerical check, not a kernel theorem—this is exactly why the two evidence classes of this item are stated separately.

**(5) Complete history and post-measurement clock (mathematics plus dual-implementation check).**

> **Proposition S9.4d.** The complete history of the original source, visit 10 and run steps 16→17 keeps the current, the successor and every installed output; every step of the complete history fibre is uniquely determined by the complete observation; the original writer, whole ledger and installed projections are recovered item by item, the current field and the next field are both the original configuration, and the tick restrictions are retained.
>
> *Proof sketch.* Induction step by step: each step's complete observation uniquely determines that step's state and successor; the original record's fields are generated one by one by the writer's definition; the original-configuration identities of the current/next fields and the tick restrictions are per-projection identities. ∎

Two independent parsers recover the nine original fields of 41,673 local records and the 867 unpaired records (dual-implementation check, byte-level parse receipts); the original record clock additionally registers 41,603 positive intervals, 66 zero intervals and 4 right-censored ends, and the ordered two-clock commitment keeps the same history.

**Direct use.** The inverse image and fibre of (2)(3) are the carrier of §9.3's exact scale equivalence; (4)(5) connect the readout to the atomic hardware and the original history, cited by the boundary sentences of §9.2–9.3.

**Formal correspondence.** `Bell/ReadoutAnchors.lean` (`BlochProbe.{response,probability}`, probability nonnegativity and normalization, `recoveredU`, `recoveredZ`, `same_law_two_probes_unique`, `anchored_same_occurrence`, `same_law_split_probes_unique`), `Bell/ReadoutDetectorFiber.lean` (`click_bounds`, `click_gap`, `max_atomic_bounds`, `feasible_iff_rates`), `Bell/ReadoutPulseRealization.lean` (`realizationRates`, `realization_background_lt_one`, `realization_efficiency`, `pulse_realizes`, `feasible_gap_lower`, `realized_effect_eq`, `atomic_effect_injective`, `two_spectra_same_effect`), `Bell/SourceHistory.lean` (`next_generator`, `whole_history_read`, `history_frontier`, `whole_common_read`, `full_observation_event`, `constructor_code_faithful`, `complete_history_fibre`, `full_observation_determines_step`, `complete_model_determines_step`, `original_{writer,whole_ledger,installed_projection,entry,successor_entry}`, `current_field_is_original_configuration`, `next_field_is_original_configuration`, `original_{tick,next_tick}_restriction`); `munich/readout-domain/` receipts (`shared-response-verification.json`, `fiber-verification.json`, `pulse-realization-verification.json`, `atomic-forward-verification.json`, `detector-fiber-verification.json`, `history-verification.json`, `clock-verification-cl0001.json`). Commits AE (Lean and Munich consumers), AD (`Bell/TheoryBlind.lean`, `Readout{Effects,Identification,ResponseBounds}.lean`).

---

## S10 Claim and proof locations in both editions

The selection indices agree with the `phys.Pn` of the first-release map of the public code selection (H0mework `docs/first-release-map.json`), for item-by-item review. The written proofs of P1–P22 are in the corresponding sections and appendices of the main text (locations per the selection's `text_location`); the written proofs of P24–P36 are in this supplement and the main text's proof ideas, with receipt identities in Appendix D.8.

| Selection index | Main-text result | Written proof | Pinned commit |
| --- | --- | --- | --- |
| phys.P1 | The master chain actually generated (Construction 4.1; Theorem 8.3) | §4, §8; Appendix C.8 | H |
| phys.P2 | The complete classical world and uniqueness (Theorems 4.2–4.4) | §4; Appendices A, B | H |
| phys.P3 | Early matter returned to the actual field (Proposition 2.5) | §2.5; Appendix A.3 | H |
| phys.P4 | The classical–quantum pairing identity (Theorem 6.2) | §6.1–6.2, eqs. (6.1)–(6.2) | H |
| phys.P5 | Current, kinetic loads, transport and exterior-power remainder (Theorem 6.3, Proposition 6.4) | §6.3–6.4; Appendix B.4 | H |
| phys.P6 | Complete representation, all events and macro successors (Theorem 8.3) | §8; Appendix C.8 | H |
| phys.P7 | All-real-time gauge–Dirac orbit (Theorem 7.1) | §7.1–7.2 | H |
| phys.P8 | Analytic predictions and the Bell probability family (Theorem 7.3, Proposition 7.4) | §7.3–7.4, §9.2; Appendix D.4 | H |
| phys.P9 | Formation of every physical source family (Theorem 8.1) | §8; Appendix C.2 | H |
| phys.P10 | Complete classical–quantum realization of every source (Theorem 8.1) | §8; Appendix C.8 | H |
| phys.P11 | Complete source path and autonomous programs (Theorem 8.2) | §8; Appendix C.3 | H |
| phys.P12 | Quantum time derivatives recover the orbit energy (Theorem 7.2) | §7.2 | H |
| phys.P13 | Generated geometry enters the actual action (Propositions 2.3–2.4, 3.3) | §2.3–2.4, §3.3; Appendices B.3, B.6 | H |
| phys.P14 | Exact signed elimination of the auxiliary fields (Theorem 3.2) | §3.2; Appendix B.2 | H |
| phys.P15 | Clock–B coupling and nonzero feedback (Construction 5.1, Theorems 5.2–5.4) | §5.1–5.4 | H |
| phys.P16 | Standard Fock preservation (Theorem 6.5, Example 6.6) | §6.5–6.6; Appendix D.3 | H |
| phys.P17 | Complete matter action formed from the mother material (Theorem C.1) | Appendix C.5 | H |
| phys.P18 | Complete joint carrier and nonzero feedback (Proposition C.2) | Appendix C.6 | H |
| phys.P19 | All-history all-order compact-domain bounds (Theorem 4.5) | §4 | H |
| phys.P20 | Mother-law completion and continuous-process representation (Proposition C.3) | Appendix C.7 | H |
| phys.P22 | Fixed mother source completely realized (Theorem 8.4, Corollary 8.5) | §8; Appendix C.9 | F |
| phys.P24 | The NIST 2015 nominal replay r0003 (§9.2; Appendix D.4.6) | S9.2(b); Appendix D.4.6 receipts | AB |
| phys.P25 | Conditional source member on public counts (Table S-II, §9.2) | S9.2(c) | AB |
| phys.P26 | Theorems 6.7–6.10 and the end of §6.9 (the complete quantum construction) | S1–S4, end of S3; §6.7–§6.10 | AB (the carrier of 6.7(1)(2) additionally at the four earlier commits `85cb5386…`, `f9b73392…`, `6726f385…`, `eec031c4…`, see S1) |
| phys.P27 | Theorem 6.12(1): the original complete 289 Green enters genuine finite-window field feedback | S6(1); §6.12 | AC (the feedback field operator and half-axis version at AE) |
| phys.P28 | The §9.2 observation-generated source slice and the same-source receiver update | S9.2(d) | AC |
| phys.P29 | Theorem 6.11: the mother action recovers the same $H_{289}$ | S5; §6.11 | AD |
| phys.P30 | Theorem 6.12(2)–(4): the complete-time paid half-axis, spectral axis and genuinely varying background | S6(2)–(4); §6.12 | AD ((2)'s half-axis consuming files and the exponential tail partly at AE) |
| phys.P31 | Proposition 9.1: the complete optical source domain and the joint 95% strictly positive CH | S9.1; §9.2 | AD |
| phys.P32 | Proposition 9.2(1)(2)(4)(5): prediction lock, readout domain, same-law scale, response bounds | S9.3; §7.4, §9.2 | AD |
| phys.P33 | Theorem 6.12(5): real-current operator and source-generated two-sided inverses + Theorem 6.13(3)–(5): static residue, constraint compatibility, origin weight | S6(5), S7(3)–(5); §6.12–6.13 | AE (static principal block, pole decomposition, Ward main line); the compatibility criterion, contact–deviation decomposition and price of 6.13(4)(5) at CAP |
| phys.P34 | Theorem 6.14: the matched original $\Gamma$ word's whole-frequency budget and the endpoint common tail | S8; §6.14 | AE |
| phys.P35 | Proposition 9.2(3) and Proposition 9.3: hardware inverse, pulse-realizable image, original post-measurement history | S9.3(3), S9.4; §9.2 | AE (Lean entries and Munich consumers) |
| phys.P36 | Theorem 6.13(1)–(3): the same-source moving carrier, momentum continuity and the varying-forcing field pole | S7(1)–(3); §6.13 | CAP (the base files of the static decomposition and (S7.3) are byte-identical in AE and CAP) |

The path prefixes in the "formal correspondence" rows: `alpha-source/` means `Verification/physics/low-energy-phenomenology/alpha-source/`, `external-composite-decay/` means `Verification/physics/low-energy-phenomenology/external-composite-decay/`, `Bell/` means `Lean/SaturationMonoid/PhysicsCore/Stage10/Bell/`, `nist-real/` means `Verification/physics/stage10/independent-bell/nist-real/`, `munich/` means `Verification/physics/stage10/independent-bell/munich/`. The commit aliases and blob records are in `checks/first-release-source-audit.json`.



The four second-edition intake groups retain their stable identifiers. The fixed Git objects preserve the published first-edition artifacts and selection identities; the present files are the second edition.

| Intake ID | Second-edition main-text result | Complete written proof in this paper | Fixed source |
| --- | --- | --- | --- |
| phys.P37 | Theorems 6.8a, 6.10a, 6.13b; actual N3 state in 6.15 | S11.1–S11.6, S14.1 | 71e, 9c73 |
| phys.P38 | Theorems 6.9a, 6.12a, 6.13a; inherited 6.11–6.13 | S12.1–S12.5, S13.1–S13.5; same-Green readings in S11.3–S11.4 | 71e, 9c73 |
| phys.P39 | Theorem 6.15; inherited matched common tail in 6.14 | S14.1–S14.5; N3 Born dressing in S11.6, original matched proof in S8 | 71e, 9c73; matched at AE |
| phys.P40 | Proposition 9.4; whole history and original clock in 9.2–9.3 | S15.1–S15.5; original readout evidence in S9.3–S9.4 | 71e, 9c73; scientific freezes in S15.5 |

---

## S11 Actual external states, twelve temporal columns and original field readers

This section proves the preparation, action and spatial returns used in Theorems 6.8a, 6.10a and 6.13b, and the Born dressing of the same original N3 response. The configuration measure, dense test core, 504-mode CAR and source profile are those of S1–S2. In $d=(\epsilon,p,F,m,\zeta)$, $\epsilon>0$ and $\operatorname{Im}\zeta\ne0$; events may be independent. The static limit precedes the independent material Abel limit; their order is not exchanged.

### S11.1 The original preparation bound generates nonzero creation

Let $c_{12}(z)$ be the actual scalar coordinate $(1,2)$. It is 1 at the source vacuum, and the perturbation-coordinate norm is below $1/2$. Coordinate evaluation has norm at most 1, so the triangle inequality gives $|c_{12}(z)|\ge1/2$ on the source box. Actual creation uses its three colour coefficients. On the original seed the unoccupied mode obeys

$$a_{02}\mathcal A_{10}^\dagger f=\overline{c_{12}}f.\tag{S11.1}$$

CAR proves this at each configuration: $a_{02}$ anticommutes through the other two colour creations and annihilates the seed; the equal-colour anticommutator gives 1. The complete half-density uses the same Number-weighted pairing. Since $\|a_{02}\|\le1$,

$$\int\|f(z)\|^2\rho(z)dz
\le4\int\|\mathcal A_{10}^\dagger f(z)\|^2\rho(z)dz.\tag{S11.2}$$

The test $f$ is supported in that same source box. Both sides are continuous squared norms, and the original core is dense in the closed preparation space, so (S11.2) extends to every actual preparation point. For the unit background $v_\epsilon$ of S2, creation has norm at least $1/2$. The original phase character is the nonzero $i/2$, hence $g_\epsilon=(i/2)\mathcal A_{10}^\dagger v_\epsilon\ne0$. Its actual positive norm gives the unique positive real normalization $\|g_\epsilon\|^{-1}$. Thus $u_\epsilon$ and its unchanged background $v_\epsilon$ are unit states. Twice applying Cauchy–Schwarz to (6.9a) gives $\|\ell_d\|\le2$.

### S11.2 Joint characters, action normalization and weighted seed current

Write the original block data of $a$ as $(A_3,A_2,y_a)$, with $A_3^*=-A_3$ and $\overline{y_a}=-y_a$. The scalar creation coefficients satisfy the complete exterior-power row formula

$$c_r(a\Phi)=-\sum_s(A_3)_{sr}c_s(\Phi).\tag{S11.3}$$

It is the sum of the four positions in the four-exterior basis. The three colour indices in the fixed creation channel give this row; weak and imaginary-hypercharge actions cancel on its wedge basis. The CAR creation commutator of the full mother matrix $L_a$ is its corresponding mode column:

$$[Q(L_a),a_{s,r}^\dagger]=\sum_v(A_3)_{vr}a_{s,v}^\dagger+y_a a_{s,r}^\dagger.\tag{S11.4}$$

The original joint variation is defined by $\delta_a^{\rm joint}\mathcal A^\dagger:=\mathcal A^\dagger(a\Phi)-[Q(L_a),\mathcal A^\dagger(\Phi)]$, with the same difference for annihilation. Insert (S11.3) and (S11.4) into $\mathcal A^\dagger(\Phi)=\sum_r\overline{c_r(\Phi)}a_{s,r}^\dagger$, and use $\overline{(A_3)_{rs}}=-(A_3)_{sr}$. The two colour columns agree and cancel in this difference. It leaves $-y_a\mathcal A^\dagger$ for creation and $y_a\mathcal A$ for annihilation. Creation and annihilation in the test core carry the original $V^{-1}$ and $V$ factors; both preserve (S11.3). The core norm bound and unique continuous completion preserve the character. The coordinates $y_Y=i$ and $y_{\rm ph}=-i/2$ give the characters in the body.

The temporal columns $f_a$ inject all twelve original Lie bases into Field289. The directional first variation of the mother density carries the complete time matrix $\mathsf w_t(s)$; its Fourier columns are $\mathsf w_t(s)C_a$ in every component. The canonical phase inverse of the original momentum matrix satisfies

$$M_{\rm ph}(s)\,[\mathsf a\mathsf w_t(s)]=I_{504}.\tag{S11.5}$$

The noncharacteristic conditions of a valid original action state pay this actual inverse. Here $\mathsf a$ is the original actionScale. Multiplication by $C_a$ proves (6.10a). For arbitrary complete mode matrices, S4 gives $Q(A)Q(B)=Q(AB)+\operatorname{Pair}(A,B)$, so quantizing (S11.5) gives (6.10b) with its complete N2 pair.

The weighted version keeps the source action weight as a matrix. For any full 504 matrix $W$, define

$$A_W^\dagger=[Q(W),\mathcal A^\dagger(\Phi)],\qquad
A_{a,\rm sc,W}^\dagger=[Q(W),\mathcal A^\dagger(a\Phi)].\tag{S11.6}$$

Expand the complete CAR matrix columns of $Q(WC_a)$, and use (S11.3) for the scalar-varied column. This gives

$$[Q(WC_a),\mathcal A^\dagger(\Phi)]
=iA_{a,\rm sc,W}^\dagger+i y_a A_W^\dagger.\tag{S11.7}$$

Explicitly, use $[Q(M),a_j^\dagger]=\sum_iM_{ij}a_i^\dagger$ and $(WC_a)_{ij}=\sum_rW_{ir}(C_a)_{rj}$. Substitute (S11.3) for the colour column of $C_a=iL_a$. Its imaginary-hypercharge column becomes $iy_a\sum_iW_{ij}a_i^\dagger$. These are exactly the two complete-matrix commutators in (S11.6). In the original local core take $W=\mathsf w_{\rm source}(z)$, then multiply by $V(z)^{-1}$. Outside the domain the test state is zero; inside, the equality holds pointwise. Evaluation on the original seed and rearrangement prove (6.10c). The values are $iy_{\rm ph}=1/2$ and $iy_Y=-1$. When $y_a=0$, (S11.7) leaves the original scalar compensation, rather than deleting the raw colour current.

### S11.3 Complete reader matching retains both material inverses

The complete temporal field reader $J_a$ and the Noether reader $N_a$ at fixed canonical momentum obey

$$J_a=-N_a+C_a^{\rm comp}.\tag{S11.8}$$

The compensation is the sum of original native and coframe first jets, configuration-density derivative and missing fibre directions, minus the retained-fibre first jet, plus the nonscalar time weight minus identity applied to the temporal current, minus the normal-charge pair. The configuration-density term is the parameter-fibre derivative plus the original temporal current. Integration subtracts that current once and gives (S11.8). Every term is integrable in the original measure; the original finite Riesz construction turns this complete form into a matrix on the same $F$.

Let $L_c,R_c,L_u,R_u$ be the cut and uncut material inverses, and let $D_L,D_R$ be the respective cut errors plus retainer leaks. The actual resolvent identities give

$$L_c=L_u+L_cD_LL_u,\qquad R_c=R_u+R_cD_RR_u.\tag{S11.9}$$

Distributivity and (S11.8) alone give the complete sandwich

$$L_cJ_aR_c=-L_uN_aR_u+
L_cC_a^{\rm comp}R_c-L_cD_LL_uN_aR_c-L_uN_aR_cD_RR_u.\tag{S11.10}$$

Both cutoff tails and both cross positions remain. Apply the same $\ell_d$ and expand $J_d$ in all 289 bases to obtain the same-event Noether/Coulomb reader matching. The actual unit and background lie in the same retained space, preserved by the original uncut right inverse. The right retainer leak therefore vanishes on both; the left tail and the full compensation remain. At fixed $F$, the finite retainer makes cutoff-to-uncut values and first and second jets eventually constant pointwise. Both material inverses and every reader thus converge together. Bilinear continuity gives the same-cutoff-to-uncut matrix-reader limit for two independent events.

### S11.4 Same-density Hessian, physical frequency and 72 curvatures

S5 identifies the actual first-jet Hessian with the second differential of the same mother density and its Fourier matrix with $H_{289}$. For the actual EM insertion $E$, retain all original output rows before taking $E^{\mathsf T}GE$. The insertion is the literal original Lie insertion, without an supplied unbroken-direction premise. The two original simple sheets and their complete Green residues come from that Jacobi matrix.

Along physical frequency write $K(\omega),G(\omega)$, with source-generated simple pole $\omega_*$ and $(\omega-\omega_*)G(\omega)\to R_\omega$. The two original equations are $KG=I-Q_s$ and $GK=I-Q_f$, retaining the frequency variation of both null projections. Multiplication by $\omega-\omega_*$ and passage to the limit give $K_*R_\omega=R_\omega K_*=0$. The actual original reader also gives $R_\omega Q_s(\omega_*)=0$, hence

$$R_\omega\frac{K(\omega)-K_*}{\omega-\omega_*}
[(\omega-\omega_*)G(\omega)]=R_\omega[I-Q_s(\omega)]
\longrightarrow R_\omega.\tag{S11.11}$$

The left side tends to $R_\omega K'_\omega R_\omega$, proving (6.13d) without dropping the moving constraint source. With $t'=ct$ and $\omega'=\omega/c$, the same Green difference quotient gives $R'_\omega=c^{-1}R_\omega$; the chain rule gives $K'_{\omega'}=cK'_\omega$. The flux identity is preserved.

The actual classical window forcing is the same $K$ applied to its complete window field, so $R_\omega K_*=0$ annihilates its pole contraction. The actual Noether forcing is continuous in frequency on the source window. Multiplying its limit by the residue leaves $R_\omega J_d$, without assuming that vector is nonzero.

The linear curvature reader for a gauge jet $a$ is

$$\mathcal F_{\mu\nu}(P;a)=P_\mu a_\nu-P_\nu a_\mu
+[\bar A_\mu,a_\nu]+[a_\mu,\bar A_\nu].\tag{S11.12}$$

Each of the six pairs has twelve Lie components. All 72 readers are continuous in $(P,a)$ and consume the same pole limit. The original second action also contains $a\wedge a$, $\delta B_A\wedge D_{\bar A}a$, $B_A\wedge(a\wedge a)$ and coframe contacts $\delta\star_e,\delta^2\star_e$. They retain their places in the same-H identification of S5 and the actual field return in (S11.12). The reader is not replaced by a vacuum expression containing only $P_\mu a_\nu-P_\nu a_\mu$.

### S11.5 Uncut Newton integration at one opposite transfer

Use the complete five-direction static inverse $S^{-1}$ of S7, its original field embedding $F_0$, and $S_0=-F_0S^{-1}F_0^{\mathsf T}$. The complete original Schur identity is

$$r^2G(0,irn)=r^2A(0,irn)-F(0,irn)B(r,n)^{-1}F(0,-irn)^{\mathsf T}.\tag{S11.13}$$

For every unit $n$, the original coefficient price gives $\|B^{-1}-B(0,n)^{-1}\|\le2M_G^2M_Er$. The recovery matrices are continuous at zero and $\|(0,irn)\|\le r$, so $r^2G\to S_0$ uniformly over all directions. Output error 1 lets the source generate a positive radius and $\|r^2G\|\le1+\|S_0\|$.

S11.3 first removes both material cutoffs, giving continuous currents $J_D^{\rm uncut}(-k),J_S^{\rm uncut}(k)$. Their combination $L(k,M)=J_D^{\rm uncut}(-k)^{\mathsf T}M J_S^{\rm uncut}(k)$ is jointly continuous. Therefore $L(rn,r^2G)\to L(0,S_0)$ uniformly in direction. With output error 1 the actual events generate $\rho_{DS}>0$ and $B_{DS}=1+|L(0,S_0)|$. Within $0<a|k|<\rho_{DS}$,

$$|L(ak,a^2G(0,iak))|\le B_{DS}|k|^{-2},\qquad
L(ak,a^2G(0,iak))\to |k|^{-2}L(0,S_0).\tag{S11.14}$$

The source defines the packet to be zero outside its window. In three dimensions $|k|^{-2}$ is locally integrable; Schwartz decay pays infinity. Thus $B_{DS}|\phi(\xi)|/|2\pi\xi|^2$ is a common integrable majorant, and Bochner dominated convergence gives (6.13e). The Newton constant follows from one common positive Gaussian regulator:

$$\frac1{|k|^2+d^2}=\int_0^\infty e^{-t(|k|^2+d^2)}dt,
\quad\mathcal F^{-1}e^{-t|2\pi\xi|^2}(y)=(4\pi t)^{-3/2}e^{-|y|^2/(4t)},\tag{S11.15}$$

whose time integral is $e^{-d|y|}/(4\pi|y|)$. As $d\downarrow0$, Schwartz/$|k|^2$ pays the frequency side and Schwartz/$|y|$ pays the spatial side, giving (6.13f). The same original five-direction contraction gives $L(0,S_0)=-(J_D^{(5)})^{\mathsf T}S^{-1}J_S^{(5)}$. Exactly one $4\pi$ appears; the raw created-connected reading acquires no $hc$ divisor.

### S11.6 Born dressing of the complete N3 response

S14.1 gives the actual norm and classification of the original N3 input $q$. For each independent leg put $b=R_{0,F}(\zeta)q$ and $T=-R_{0,F}(\zeta)Y$. Number is 3 and $Y$ raises grade by one, hence $T^4b=0$. The full response is $r=\sum_{j=0}^3T^jb$, while the independent sharp response is $r=b$. The original complete equation is $(H_0+Y^{(\sharp)}-\zeta)r=q+d_Fr$, retaining the finite-frame defect. The bottom projection obeys $P_{3,0}r=b\ne0$ and all raised grades are orthogonal. Therefore

$$u=r/\|r\|,\quad z=\|b\|/\|r\|\in(0,1],
\quad z^2=\|P_{3,0}u\|^2.\tag{S11.16}$$

An independent sharp leg has $z=1$. The pure gauge action preserves grade and $P_{3,0}$ is self-adjoint in the original configuration pairing. If **each left/right pair has at least one sharp leg**, its full numerator equals the bottom numerator; the normalizations still use both complete response norms. Hence $w_{LR}^{\rm actual}=z_Lz_R\widehat w_{LR}^{\rm base}$. Apply this independently to detector and source. The four-overlap product $Z=\prod z_j\in(0,1]$ gives

$$C_{\rm full}=ZC_{\rm base},\qquad
|C_{\rm full}-C_{\rm base}|=(1-Z)|C_{\rm base}|,\quad
C_{\rm base}=\frac{9023\sqrt{30}}{9000hc}\widehat w_D\widehat w_S.\tag{S11.17}$$

The constant is the actual same-$S^{-1}$ contraction: $9/125+67/72=9023/9000$. This bare two-unit reader uses the original detector $hc$ once; the raw connected reader of (S11.14) is already normalized in the original action. Continuous matrix reading commutes with the same Fourier integral, so $Z$ directly enters its Newton return. With two fullY legs, raised–raised numerators may survive and this pair formula need not apply. Strict integrated $Y$ excess does not require every overlap to be strictly below 1.

**Fixed sources and direct use.** At 71e: `ActualDressedSourcePreparation`, `ActualDressedTemporalNormalization/TemporalCurrent`, `ActualDressedReaderComponents/CutReturn/ReaderMatching`, `ActualEMCarrier/Action/Clock`, `ActualEMGaugeCurvature`, `ActualEMDressedGaugePole`, `ActualWholeCoulombPacket`, `ActualDressedMovingCoulomb`, `ActualCompositeCoulombDressing`, `ActualEMExternalRepresentation`. At 9c73: `PhysicalDressedP286Character/PhysicalDressedWeightedCreation` and `ActualDressedUncutCurrent/UncutCoulomb/UncutMomentum/UncutMovingCoulomb`. All are under `Verification/physics/low-energy-phenomenology/alpha-source/em-identification/`. The bearing declarations are `actual_dressed_creation_nonzero`, `canonical_temporal_quantized`, `jointDressedCompleted_return`, `raw_charge_seed_current`, `temporal_cut_noether_match`, `dressed_gauge_frequency_pole`, `moving_coulomb_origin_spatial_limit` and `composite_coulomb_coefficient_dressing`. The second-edition selection preserves the original certifications. This section is their written mathematical expansion, with no new scientific run.


---

## S12 Nonlinear half-axis, all five terms and matrix infrared return

This section proves Theorems 6.9a and 6.13a. Fix the same actual event $d$, independent transfer $k$, original $F$ and two nonreal material inverses. Let $\mathscr B=\mathcal L(\mathscr H)$ be the bounded-operator algebra of the complete configuration Hilbert space. Field289 is real for differentiation; the output is the full 289-component complex covector. Analyticity of the original full matrix uses the finite source minimal polynomial, without assuming the target IR limit.

### S12.1 The original constant-field nonlinear integral returns to the same-field inverse

For a constant real field $h$ define

$$I_i(h)=R_+(h)N_i(h)R_-(h),\qquad
\mathcal P_\lambda(h)X=\lambda X+A_+(h)X-XA_-(h).\tag{S12.1}$$

The two-leg generators are $A_\pm=-iK_\pm(h)$ from the same original action. Propagation $\mathcal T_h(t)X=V_h(t)XU_h(t)$ obeys $U_h\prime=A_-(h)U_h$, $V_h\prime=-V_hA_+(h)$. Its derivation is $X\mapsto-A_+(h)X+XA_-(h)$, so (S12.1) is exactly $\lambda I$ minus that derivation, with the original $i$ appearing once. Factor by factor, the complete original Noether kernel is $\mathcal T_h(t)I_i(h)$: both material inverses, the reader at fixed canonical momentum and both original time actions use the same $h$.

At $h=0$, the source polynomial time bound of S6 gives a Bochner two-sided inverse $\mathcal I_\lambda$ for $\operatorname{Re}\lambda>0$. Original field coefficients are $C^2$ and both nonreal material inverses exist at zero. Continuity generates a positive real field radius on which both material inverses remain invertible and

$$\|\mathcal I_\lambda[\mathcal P_\lambda(h)-\mathcal P_\lambda(0)]\|<1/2.\tag{S12.2}$$

The original time budget on this source neighbourhood also gives

$$\|e^{-\lambda t}\mathcal T_h(t)\|
\le\mathcal B_d(\operatorname{Re}\lambda/4)e^{-\operatorname{Re}\lambda t/2},\quad t\ge0.\tag{S12.3}$$

Explicitly, take $\eta=\operatorname{Re}\lambda/4$. The base-field finite grade word gives $\|\mathcal T_0(t)\|\le B e^{\eta t}$ with $B=\mathcal B_d(\eta)$. Let $\Delta(h)$ be the difference of the same two-leg evolution derivations. Duhamel and Gronwall give $\|\mathcal T_h(t)\|\le B e^{(\eta+B\|\Delta(h)\|)t}$. Since $\Delta(0)=0$ and it is continuous, restrict the source neighbourhood to $B\|\Delta(h)\|\le\eta$. Multiplication by $e^{-\operatorname{Re}\lambda t}$ gives (S12.3). Intersect it with the inverse-open set (S12.2); it still contains zero with positive radius.

Equation (S12.3) pays the actual integral. Integration by parts in the weighted time equation, with $\mathcal T_h(0)=I$ and vanishing terminal term, gives

$$\int_0^\infty e^{-\lambda t}\mathcal T_h(t)dt
=\mathcal P_\lambda(h)^{-1}.\tag{S12.4}$$

Applying the time generator on each side returns the identity. This two-sided inverse equals the Neumann inverse of (S12.2) by uniqueness. Therefore the actual nonlinear half-axis is

$$\mathcal J_d(h;\lambda)_i=\ell_d\{\mathcal P_\lambda(h)^{-1}I_i(h)\}.\tag{S12.5}$$

The right side is $C^2$ at zero: the original coefficients are $C^2$, inversion is $C^2$ on the open set of units, and multiplication and $\ell_d$ are continuous. There are finitely many readers, so a common source neighbourhood pays all 289 simultaneously. The proof differentiates an equality between the actual nonlinear integral and its same-field inverse on a neighbourhood, rather than substituting an integrated linear kernel for the nonlinear integral.

### S12.2 Five derivatives of actual histories and the unaveraged pencil

For an original $C^1$ time history $h(t)$, the original generator is $C^2$ near $h(0)$. On a common closed amplitude/time rectangle its coefficients and derivatives have finite norms. Picard's Volterra series converges with bound $M^nt^n/n!$. Uniqueness on overlapping intervals gives both actual nonautonomous histories on a positive source window. Duhamel difference quotients, the same rectangular majorant and Gronwall give

$$\dot U(t)=\int_0^tU_0(t-s)\dot A_R(s)U_0(s)ds,\qquad
\dot V(t)=-\int_0^tV_0(s)\dot A_L(s)V_0(t-s)ds.\tag{S12.6}$$

The two material inverses obey $\dot R_\pm=-R_\pm J_\pm(h(0))R_\pm$; the central contact is the actual $\dot N_i$ at fixed canonical momentum. Differentiating the complete original word

$$V_r(t)R_+(rh(0))N_i(rh(t))R_-(rh(0))U_r(t)\tag{S12.7}$$

places a derivative at each of its five positions:

$$\dot V R_+N_iR_-U_0+V_0\dot R_+N_iR_-U_0
+V_0R_+\dot N_iR_-U_0+V_0R_+N_i\dot R_-U_0
+V_0R_+N_iR_-\dot U.\tag{S12.8}$$

Complete the ordered product before applying the same $\ell_d$. Its middle contact retains $N_i'-J_{{\rm raw},i}'$; the independent dual and primal time legs retain their orders.

For the Fourier signal $\operatorname{Re}(e^{P\cdot x}a)$ and its $-ia$ quadrature, take the minimum of the two actual source durations, $\tau(d,k,P,a)>0$. If $L$ is the real-linear response, $\mathscr D(a)=L(a)+iL(-ia)$ obeys $\mathscr D(ia)=i\mathscr D(a)$. Set $\Pi_d(P,t)_{ij}=\mathscr D(e_j)_i$. Finite basis expansion gives $\mathscr D(a)=\Pi_d(P,t)a$. S5 identifies the original holonomic mother Euler at this same amplitude with $H_{289}(P)e^{P_0t}a$. Subtracting the actual nonlinear preparation gives the pointwise derivative in (6.9e). Finite-window continuity pays termwise integration, keeping $W_T$ as the original input time factor. When $\lambda=P_0$ its integrand is exactly 1, giving $W_T=T$.

The linearized original five terms have complete-time prices from finite grade words. For $\operatorname{Re}\lambda>\max(0,\operatorname{Re}P_0)$, both the constant term and the input exponential retain a positive gap. A fixed fraction of its minimum absorbs every finite time power, giving $\|e^{-\lambda t}\mathscr D(t)\|\le C e^{-\eta t}$. The Bochner integral of $\Pi^\infty$ and its operator-norm tail follow from that same source. The general nonautonomous nonlinear contract remains its $\tau$; S12.1 pays the constant-field nonlinear contract.

### S12.3 The actual full-field differential is the same static matrix

Put $\mathcal D_f=-D_h\mathcal P_\lambda(0)[f]$. The original symbol gives $\mathcal D_fX=-J_L[f]X+XJ_R[f]$, with $J_L,J_R$ carrying their original time signs. Inverse differentiation gives

$$D_h\mathcal P_\lambda^{-1}(0)[f]=\mathcal I_\lambda\mathcal D_f\mathcal I_\lambda.\tag{S12.9}$$

The three initial factors in (S12.1) differentiate to

$$DI_i(0)[f]=-R_+J_+[f]R_+N_iR_-+R_+N_i'[f]R_-
-R_+N_iR_-J_-[f]R_-.\tag{S12.10}$$

Call this sum $I_{i,f}^{N}$; its complete Noether contact already contains the raw-contact correction. The product rule in (S12.5) gives

$$D\mathcal J_d(0;\lambda)[f]_i
=\ell_d\,\mathcal I_\lambda\{I_{i,f}^{N}
-J_L[f]\mathcal I_\lambda I_i(0)+[\mathcal I_\lambda I_i(0)]J_R[f]\}.\tag{S12.11}$$

The original constant history in (S12.8) satisfies this same propagation pencil and initial value. Its half-axis is exactly (S12.11), by the two-sided inverse (S12.4). Each column of the original $\Pi_d^{\rm st}$ is (S12.11) at $f=e_j$. Since $\mathcal J_d$ already has a full Fréchet differential, expand $f=\sum_jf_je_j$ and use linearity to obtain (6.9c) on all of Field289. The constant input has integral $\lambda^{-1}$; its original inverse normalization is $\lambda$, giving normalized derivative $\lambda\Pi_d^{\rm st}f$.

Multiply (S12.3) by $\|I_i(h)\|$ and $\|\ell_d\|\le2$. The tail integral $\int_T^\infty e^{-\lambda_Rt/2}dt=2e^{-\lambda_RT/2}/\lambda_R$ yields (6.9d). Finite nonlinear windows and the same half-axis reading thus have an actual paid tail.

### S12.4 Full-field finite words pay a cubic complete observation

The original full-field compression $C_F(h)$ preserves grade; $Y_F(h)$ raises it by one. Grades run from 0 to 56, so 57 raises vanish. The terminal finite Duhamel recurrence satisfies the ODE and initial value. Uniqueness therefore identifies the actual 57-term time expansion at every original $h$. The actual N2 unit and N1 background lie in their finite occupation sectors: N2 stops after two raises and N1 after one. The original full-field current also preserves Number and its actions on the upper-one and upper-two flags.

Let $a=\|Y_F\|$, $j=\|J_F[f]\|$ and $P_2v=v$. The graded Duhamel formula separates each integral into N2, upper-one and upper-two contributions, with time prices $1+a|t|+a^2|t|^2$, $1+a|t|$ and 1. It yields

$$\|\partial_fT_F(t)v\|\le |t|j[1+2a|t|+3a^2|t|^2]\|v\|
\le3j(1+a)^2(1+|t|)^3\|v\|.\tag{S12.12}$$

The original N1 bound $|t|j(1+a|t|)^2$ is controlled by the same right side. The upper support of the original full-field current is decisive: after a second-order time word there is no independent second-order growth. The complete time variation is cubic, rather than the quintic obtained by multiplying coarse bounds for both legs.

First prove the actual two-state left-free return. Let $P$ be the original grade-zero projection, with $Pu_\epsilon=u_\epsilon$ and $Pv_\epsilon=v_\epsilon$. The original full field satisfies $[P,C_F(h)]=0$ and $PY_F(h)=0$. Project the original time ODE, whose initial value is $P$; uniqueness gives $PT_{\rm full}(h,t)=PT_C(h,t)$. In the common neighbourhood where both original inverses exist, use $P(C+Y-z)=P(C-z)$ and $PR_C=R_CP$, multiplying on the left by the free inverse and on the right by the full inverse, to obtain $PR_{\rm full}(h,z)=PR_C(h,z)$. Move the self-adjoint $P$ through the inner products with $u_\epsilon,v_\epsilon$. The left time and inverse in the complete five-factor observation return to their free versions. Thus the same-source two-state observation equals its left-free-kernel observation on that field neighbourhood. This germ equality retains all readers; it does not equate the whole-H left time operator with the free operator on the full carrier. Write that kernel as $A B C D T$, with $\|A\|\le1$, and use original prices

$$c_p=\|J_{L,\rm free}[f]\|,\ b=\|R_{L,\rm free}\|,
\ c=\|N_i\|,\ d=\|R_R\|,
\ e=\|N_i'[f]\|,\ j_g=\|J_R(\zeta)[f]\|,
\ j_t=\|J_R(0)[f]\|.\tag{S12.13}$$

Free Duhamel and the two inverse derivatives give $\|A'\|\le|t|c_p$, $\|B'\|\le b^2c_p$ and $\|D'\|\le d^2j_g$. The first four-factor slope is at most $(1+|t|)C_4$, where

$$C_4=c_pbcd+b^2c_pcd+bed+bcd^2j_g,
\quad K_3=[C_4(1+a)^2+3bcdj_t(1+a)^2](1+\|v_\epsilon\|^2).\tag{S12.14}$$

For the fifth term use (S12.12); multiply the other four by the actual quadratic time price of $T$. The complete observation is bounded by $K_3(1+|t|)^3$. The unit norm is 1 and the original background norm remains in (S12.14). Uniqueness of derivatives transfers this price through the germ equality to all original Noether terms. These are the body prices $K_{ij}=K_3(e_i,e_j)$.

Laplace integration pays each matrix entry:

$$|\Pi_{ij}^{\rm st}(k,\lambda)|\le K_{ij}
\int_0^\infty e^{-\lambda_Rt}(1+t)^3dt.\tag{S12.15}$$

The integral is $\lambda_R^{-1}+3\lambda_R^{-2}+6\lambda_R^{-3}+6\lambda_R^{-4}$. For $0<\sigma\le1$ the original outward source price 56 pays $\sigma^4$ times this integral, yielding $\sigma^4|\Pi_{ij}^{\rm st}|\le56K_{ij}$. The source price is retained without a separate constant-optimization claim.

### S12.5 Analytic factorization of the same matrix, for every pole-order branch

Fix transfer zero. The source minimal polynomial $p_d$ of the original two-leg generator gives $\mathcal I_z=p_d(z)^{-1}\mathcal N_d(z)$. The numerator is the finite coefficient sum obtained by polynomial division by $X-z$, hence analytic. Write $p_d(z)=z^{m_d}d_d(z)$ with $d_d(0)\ne0$. Then $T_d(z)=d_d(z)^{-1}\mathcal N_d(z)$ is analytic at zero. Substituting $\mathcal I_z=z^{-m_d}T_d(z)$ into (S12.11), keeping both inverses in their original order, generates an analytic full matrix $R_d$ satisfying, for $\operatorname{Re}z>0$,

$$R_d(z)=z^{2m_d}\Pi_d^{\rm st}(0,z).\tag{S12.16}$$

Each entry is $\ell_d\{z^{m_d}T_d(z)I_{i,e_j}^{N}+T_d(z)\mathcal D_{e_j}[T_d(z)I_i(0)]\}$, so all 289² entries are analytic together.

**Vanishing-order lemma.** If a Banach-valued analytic $R$ near zero satisfies $\|R(s)\|\le Cs^q$ on the positive real axis, its analytic vanishing order is at least $q$. Otherwise write $R(z)=z^ng(z)$ with $n<q$, $g(0)\ne0$. The bound implies $\|g(s)\|\le Cs^{q-n}\to0$, contradicting continuity. If the germ is identically zero, the conclusion already holds.

Use the elementwise norm or a finite equivalent matrix norm, and take the finite sum of all $56K_{ij}$ as the source price $C_d$. If $2m_d\ge4$, (S12.15)–(S12.16) give $\|R_d(s)\|\le C_ds^{2m_d-4}$. The lemma gives $R_d(z)=z^{2m_d-4}G_{4,d}(z)$ with analytic $G_{4,d}$. Cancel the common power at nonzero $z$ in the right half-plane to get $z^4\Pi=G_{4,d}$. If $2m_d<4$, define $G_{4,d}=z^{4-2m_d}R_d$; the same identity follows directly. Every $m_d$ branch is covered.

Continuity of the analytic $G_{4,d}$ gives the common full-matrix limit $G_{4,d}(0)$ through the complex right half-plane or positive real damping. Multiplication by $z^2$ gives $z^6\Pi=z^2G_{4,d}\to0$. No feedback determinant or nine-Schur invertibility premise enters this proof.

**Fixed sources and direct use.** At 71e, `ActualDressedNoetherCauchy/NoetherHistory` and `ActualDressedSignalOperator/Tensor/Causal/Pencil` pay S12.2. At 9c73, `ActualDressedNoetherBackground/NoetherHalfIntegral/NonlinearHalfResponse/NonlinearPolarization/NoetherSylvester` pay S12.1–S12.3, while `ActualDressedFieldTimeFull/FieldTimeConsumer/GradedSlopePrice/CubicNoetherPrice/CubicLaplacePrice/CubicStaticPrice/IRAnalytic/CubicIRFactor/CubicIRReturn` pay S12.4–S12.5. The file prefix is that of S11. Direct declarations are `dressed_native_window_pencil_generated`, `dressed_noether_half_fderiv`, `actual_complete_noether_cubic_jet_price`, `actual_static_polarization_sigma_four_price`, `actual_fourth_ir_regularization`, `actual_fourth_ir_return` and `actual_sixth_ir_zero_return`. Their original audits and certifications retain their fixed identities.


---

## S13 Actual feedback, nine-coordinate Schur and the complete two-clock return

This section proves Theorem 6.12a. The matrices $H(P)=H_{289}(P)$, $G(P)$, original change of variables $F(P)$ and its two-sided inverse retain the objects of S5–S7. The half-axis quantum matrix consumes S12's complete linearization at the same event; for constant input $P_0=0$ it consumes the differential of the same actual nonlinear half-axis. Actual determinant regularity, the source finite-window anchor and transfer-zero IR are three separate contracts.

### S13.1 Nine initial coordinates and nine constraints have their original readers

Let $J_9:\mathbb C^9\to\mathbb C^{289}$ inject coordinates into original slots 112–120, with $r_9J_9=I_9$ and $J_9r_9=P_n$. Define

$$N(P)=F(P)J_9,\quad D(P)=r_9F(P)^{-1},
\quad C(P)=r_9F(-P)^{\mathsf T},\quad
L(P)=F(-P)^{-\mathsf T}J_9.\tag{S13.1}$$

All zero rows and columns of the original factor matrix give $HN=0$ and $CH=0$. The two-sided inverse gives $DN=CL=I_9$. The original two-sided Green equations give

$$GH=I-ND,\qquad HG=I-LC,\qquad D G=0.\tag{S13.2}$$

The null-field initial-data projection is $ND$; the null-source covector projection is $LC$. They are different readers. Since $C(P)=N(-P)^{\mathsf T}$, each complete constraint row consumes the same original column at opposite momentum.

### S13.2 Full half-axis quantum solutions are exactly the nine-Schur solutions

On the original regularSource set put $Q=(\lambda-P_0)\Pi_d^\infty(P,\lambda)$. The actual half-axis requires $\lambda_R>\max(0,\operatorname{Re}P_0)$. When the actual determinant of $B=I-GQ$ is nonzero, the two-sided adjugate formula generates $A=B^{-1}$. One directly checkable sufficient price is $\sum_{ij}|(GQ)_{ij}|<1$: if $(I-GQ)v=0$, the maximum-coordinate norm gives $\|v\|\le(\sum|GQ|)\|v\|$, hence $v=0$. A finite square matrix is then invertible. The IR limit does not supply this price.

For $x(c)=A(Gf+Nc)$, the equation $BA=I$ gives

$$x(c)=Nc+G(f+Qx(c)),\qquad Dx(c)=c.\tag{S13.3}$$

Applying $H$ gives

$$[H-Q]x(c)=f-LC(f+Qx(c)).\tag{S13.4}$$

Since $CL=I_9$, the residual is zero exactly when $C(f+Qx(c))=0$. Substitute the original inverse expression and separate $c$ and $f$:

$$S=CQAN,\quad b=-C(f+QAGf),\qquad C(f+Qx(c))=Sc-b.\tag{S13.5}$$

Every Schur solution therefore gives a full-field solution. Conversely, if $[H-Q]x=f$, then $f+Qx=Hx$. Equation (S13.2) yields $G(f+Qx)=x-NDx$, hence $Bx=Gf+NDx$ and $x=x(Dx)$. Also $C(f+Qx)=CHx=0$, so $S(Dx)=b$. This proves (6.12b) for every input, without a Schur-inverse assumption. For $P_0=0$, the original constant-input normalization in S12.3 gives $Q=\lambda\Pi_d^{\rm st}$. On the physical restriction $\lambda=\sigma-i\omega(P)$ the source frequency sheet gives $H-\sigma\Pi^\infty$, with the original Green and all nine rows restricted together.

On the same half-axis domain, $\Pi_T\to\Pi^\infty$ in operator norm. Multiplication by the fixed input normalization and original $G$ gives $B_T\to B$. Continuity of determinant keeps sufficiently late windows in the same $\det B\ne0$ domain; continuity of matrix inversion gives $B_T^{-1}\to A$. The original actual initial data $c$ remain fixed, rather than being reselected for each window.

### S13.3 The source generates a finite-window anchor and the $16/15$ inverse price

For a given $d$, the original operator-level time prices generate finite nonnegative $L_d,C_d$: sums over all 289 original readers of the linear and constant budgets at source exponent parameter 1, each multiplied by observer price 2. Put

$$B_d^{\rm win}=2(L_d+C_d)e^4,\quad
G_*^{\rm price}=\sum_{ij}|G(P_*)_{ij}|,\quad
E_d=4(1+G_*^{\rm price}B_d^{\rm win}).\tag{S13.6}$$

The original two-material-frequency radius function generates $r_d\ge E_d>0$ and changes the nonreal material energy of $d$ to $ir_d$. It preserves the actual prepared unit, background, $p,F,m$ and physical clock, so $\ell_d$ is unchanged. This generates anchor event $d_*$; the claim does not impose the same small price on every pre-existing material energy.

At common clock 3 and the original regular point $P_*$, $W_T=T$. The source material-radius price gives $\|e^{-3t}\mathscr D_{d_*}(P_*,t)\|\le B_d^{\rm win}/r_d^2$ for $0\le t\le1$. Therefore

$$\|\Pi_Ta\|\le (B_d^{\rm win}/r_d^2)T\|a\|,
\qquad\|T^{-1}G_*\Pi_Ta\|\le\frac{G_*^{\rm price}B_d^{\rm win}}{r_d^2}\|a\|
\le\frac1{16}\|a\|.\tag{S13.7}$$

The last bound follows from $r_d\ge4(1+G_*^{\rm price}B_d^{\rm win})$ and $q/(16(1+q)^2)\le1/16$ for $q\ge0$. It holds for every $0<T\le1$. The choice $T_d(a)=\min(1,\tau(d_*,0,P_*,a)/2)>0$ also stays inside the actual nonlinear duration.

The kernel of $B_T=I-T^{-1}G_*\Pi_T$ is zero, so both inverses exist. Its response obeys $x=f+T^{-1}G_*\Pi_Tx$, hence $\|x\|\le\|f\|+\|x\|/16$ and $\|B_T^{-1}\|\le16/15$. The complete unaveraged equation at this source anchor is $(TH-\Pi_T)x=f$. The same nine-row algebra of S13.2 gives its original $c$ and Schur contract. Its forcing enters $T^{-1}Gf$, retaining the actual normalization.

### S13.4 Constraint histories, original preparation remainder and the two-frequency rational expression

Insert the reflected columns of (S13.1) into all five terms of (S12.8). Finite basis expansion recovers every row of $C(P)\Pi_Ta$. The original $CH=0$ gives $C(P)[W_TH-\Pi_T]=-C(P)\Pi_T$; S12.2's actual coupled-residual derivative reads the same nine-row nonlinear history. Along a native reference column, the Noether reader is exactly the native reader minus the configuration-deviation reader, and the middle contact has the same decomposition. Each of the five terms is linear in reader and contact, so the complete history splits termwise. Locking the reference background does not erase the second history.

The original temporal half-axis also retains both preparation endpoints. Let $X$ be its half-jet, $I'$ its initial jet and $D_{\rm phys}$ both physical driven legs. The propagation equation gives

$$\lambda\ell_d(X)-\ell_d(I')-i\ell_d(D_{\rm phys})
=i\{M_{\rm phys}(X)+E_{{\rm prep},d}(X)\}.\tag{S13.8}$$

Here $M_{\rm phys}$ is the original physical-Hamiltonian endpoint mismatch and $E_{{\rm prep},d}$ the same-preparation Ward remainder. The preparation theorem gives $\|E_{{\rm prep},d}\|\le2(2\|\mathcal A_{10}^\dagger\|+1)\epsilon$. Thus on a same-source preparation sequence $\epsilon_n\downarrow0$ with fixed dynamical fields, this remainder tends to zero. Actual phase charge still obeys $Q_{\rm ph}u=\frac12u+\mathrm{input}_d$, and the leading-pole reader consumes its actual preparation mismatch as well. Unit norm has not been used to declare $u$ an exact common charge/H eigenstate.

For general input clock $c=P_0$ and observer clock $\lambda$, the source minimal polynomial $p_d$ pays both propagation inverses. If $\lambda_R>0$ and $\operatorname{Re}(\lambda-c)>0$, the complete five-term half-axis in its original order is

$$\mathcal I_\lambda M+
\mathcal I_{\lambda-c}\{C+\mathcal D_f(\mathcal I_\lambda I_0)\}.\tag{S13.9}$$

Here $M$ is the original material-inverse/preparation initial term, $C$ the original Noether contact and $\mathcal D_f$ the two-leg drive. Substitute $\mathcal I_z=p_d(z)^{-1}\mathcal N_d(z)$. The common denominator is $p_d(\lambda)p_d(\lambda-c)$, with numerator

$$p_d(\lambda-c)\mathcal N_d(\lambda)M+
 p_d(\lambda)\mathcal N_d(\lambda-c)C+
 \mathcal N_d(\lambda-c)\mathcal D_f[\mathcal N_d(\lambda)I_0].\tag{S13.10}$$

Applying $\ell_d$ rowwise gives the complete $\Pi^\infty$, then $\lambda-P_0$ normalizes it to $Q$. Static input gives the square $p_d(\lambda)^2$. Zero transfer really has a source pole at zero; numerator cancellation is paid by the actual price of S12.5, rather than inferred from the denominator's shape.

### S13.5 All four factors in the finite-window synchronized-clock derivative

This clause separately denotes $S_T(z)=C(z)\Pi_T(z)A_T(z)N(z)$, distinct from the half-axis $CQAN$ of S13.2. The original source clock varies input and observation together, giving $W_T=T$. The genuine $\Pi_T'(z)$ contains both clock variations: the Laplace-weight $-t$ term and the source-input history clock jet. They are continuous on the same bounded time window, permitting differentiation.

Let $\mathcal P_T(z)=TH(z)-\Pi_T(z)$ and $P_n(z)=N(z)D(z)$. Since the original $GH=I-P_n$,

$$B_T(z)=T^{-1}G(z)\mathcal P_T(z)+P_n(z),\quad
B_T'(z)=T^{-1}\{G'(z)\mathcal P_T(z)+G(z)\mathcal P_T'(z)\}+P_n'(z).\tag{S13.11}$$

Here $\mathcal P_T'=TH'-\Pi_T'$; the original quadratic time polynomial gives $H'=H_1+2zH_2$. At the source anchor (S13.7) pays the inverse, whose determinant remains nonzero near $z=3$. The inverse difference identity gives $A_T'=-A_TB_T'A_T$. The original 200-term temporal columns of $F(z)$ and their reflected columns generate $N',C'$; reflection carries its own chain-rule minus sign. The four-factor product rule yields

$$S_T'=C'\Pi_TA_TN+C\Pi_T'A_TN+C\Pi_TA_T'N+C\Pi_TA_TN'.\tag{S13.12}$$

Every moving null column, original Green, quantum-memory jet and inverse is present. If the half-axis $S=CQAN$ is differentiated along a clock, its formula must use $Q,Q'$ and include the original input-normalization factor. These two derivatives retain their different objects.

**Fixed sources and direct use.** At 9c73: `ActualEMDressedSourceAnchor/AnchorInverse/Constraint/Schur`, `ActualDressedConstraintHistory/NativePreparedWard/RationalFourier/TemporalQuantumResidual/CommonPreparationConsumer`, `ActualDressedNativeClockFlux/FullSchurFlux`, and `ActualDressedHalfFeedback/HalfSchur/HalfPhysicalConsumer`, under the S11 prefix. The bearing declarations are `anchor_full_solution_schur`, `source_constraint_schur_history`, `native_reference_actual_history`, `temporal_quantum_preparation_return`, `same_event_charge_quantum_pole`, `dressed_frequency_response_rational`, `clock_source_schur_flux_generated` and `half_full_solution_schur`. The original `actual_em_dressed_anchor_schur`, `actual_dressed_nonlinear_half`, `actual_dressed_full_schur_flux` and `actual_dressed_half_ir` certifications remain separate from the present written checks.


---

## S14 Charged three-particle source, all four blocks and same-source payments

This section proves Theorem 6.15. Every CAR action uses the full 504 modes; the profile uses the Number-weighted configuration Hilbert space of S1. Contact/79/24/61 are four departments of the same action. The fixed source input precedes every finite response frame, sharp and causal choice and damping. The budget clause separately retains the original $C_F$, source damping and every source invoice.

### S14.1 One actual three-particle vector is charged, spin-half and a colour singlet

Let $a^\dagger_{d,(s,c,h)}$ denote the original named modes: $d\in\{0,1\}$ is the independent dual branch, $s\in\{0,1,2,3\}$ the Dirac index, $c\in\{0,1,2\}$ colour, and $h=0,1$ the original colour-hyperPlus and colour-weak0 wedge modes. Define

$$\epsilon_d(s_0,s_1,s_2)=\sum_{\pi\in S_3}\operatorname{sgn}\pi\,
 a^\dagger_{d,(s_0,\pi_0,0)}a^\dagger_{d,(s_1,\pi_1,0)}
 a^\dagger_{d,(s_2,\pi_2,1)}\Omega_d,
\quad q_d=\tfrac13[\epsilon_d(0,1,2)-\epsilon_d(0,0,3)].\tag{S14.1}$$

The inner product of CAR triples is the three-dimensional Kronecker Gram determinant. The first epsilon has six orthogonal unit words, squared norm 6. Repeated spins in the second combine colour-exchanged terms into three words with coefficient 2, squared norm 12. The two spin occupations differ, so their cross inner product is zero. Thus $\|q_d\|^2=(6+12)/9=2$. For every $A\in\mathfrak{su}(3)$, the complete three-position action on the alternating colour tensor gives $\operatorname{tr}A=0$, annihilating $q_d$.

The literal EM matrix is $\operatorname{diag}(q_i,-q_i)$, retaining every fractional weight on the 252 modes and the independent dual sign. Charge of a triple is the sum of its mode weights. The original phase readings of two hyperPlus and one weak0 mode give $(-1)^d$. The original rotation matrices $s_a$ come from the four-dimensional Dirac Clifford action, with the original conjugate sign on the full 504 branches. CAR makes their action on an ordered triple the three-position sum $\sum_{\ell=1}^3s_a^{(\ell)}$. For fixed colours $a,b,c$, the original Pauli blocks give

$$\sum_{j=1}^3(s_j^{(1)}+s_j^{(2)}+s_j^{(3)})^2
\{[0a0,1b0,2c1]-[0a0,0b0,3c1]\}
=\tfrac34\{[0a0,1b0,2c1]-[0a0,0b0,3c1]\}.\tag{S14.2}$$

Brackets denote the same original creation triples. Expansion over the four Dirac indices flips the original Pauli spin bit, uses $\sigma_j^2=I$ and cancels cross-position spin flips between the two words. Weight the six colour permutations and divide by 3 to obtain the original $\mathsf S^2q_d=3q_d/4$. Hence $q_d/\sqrt2$ has unit norm, EM charge ±1, Casimir $3/4$ and the complete colour kernel simultaneously.

The literal $Y$ at the original common vacuum is also nonzero on $q_d$. An actual CAR witness in the output wedge mode has coefficient equal to nonzero lapse times the nonzero original Yukawa phase; the other triple terms do not cancel it. The mother-profile factory generates smooth compactly supported $f$ with $f(z_*)=1$, whose value at the source point is that same nonzero coefficient. The complete test-core embedding is injective, so both $q_df$ and its $Y$ output are nonzero. Normalization of $Y$ by its original positive radius gives a bounded reader $B_Y$ still nonzero on this same input, consumed next.

### S14.2 All four blocks combine coherently before producing a positive spectrum

Original kinematics carries common $x,k$, independent $p_L,p_R$, and actual nonzero values for ten canonical, six dual and one scalar denominator. Let $\mathcal B_0$ be the contact tree, $\mathcal B_1$ the 79-inverse tree, $\mathcal B_2$ the 24-inverse tree and $\mathcal B_3$ the 61-scalar-inverse tree, with their original coefficients on the same full CAR. Number preservation makes these finite Fock actions commute with the configuration weights. Their constant fibre action first extends to bounded $\mathcal B$ on the whole weighted Hilbert space, with $\|\mathcal B\|\le\|\sum_b\mathcal B_b^{\rm fiber}\|$.

For the original fullY/independent-sharp response $r_F(\omega)$, $\mathcal B r_F=\sum_b\mathcal B_b r_F$. Inner-product expansion gives (6.15a), retaining all sixteen complex Gram entries. Nonnegative density makes $\nu(S)=\int_S\|\mathcal B r_F\|^2d\omega$ a positive measure. The source input's 57-term time word bounds $\|w_F(t)\|\le P_{56}(|t|)\|q\|$. After multiplying by $e^{-\mu t}1_{t>0}$, both $L^1$ and squared $L^2$ are paid by finite sums of $\int_0^\infty t^n e^{-2\mu t}dt=n!/(2\mu)^{n+1}$. Both causal and sharp choices remain independent. Every original bounded whole-H reader can use this price, including $\mathcal B$.

The original Fourier convention is $\omega=-\operatorname{dir}(c)2\pi\xi$, giving $\mathcal B r_F(\omega)=\operatorname{dir}(c)i\,\mathcal F(\mathcal B w_F)(\xi)$. Hilbert-valued Parseval and this Jacobian give (6.15b), without fullY norm conservation. Bounded $\mathcal B$ also gives the whole-frequency two-frame output-difference bound $\|\mathcal B\|^2\int\|r_F-r_G\|^2$, so cofinal relative moments return through the same complete reader.

### S14.3 A nonzero complex witness generates one shared real-transfer window

For the original fixed bra of (S14.1), at $x=i$ and $k=p_L=p_R=0$ the four departments give exactly

$$\sqrt{30}\left(-\frac1{25},\quad
\frac{50304430064141165448074104830433}{97699116566232156027102301987500},\quad
-\frac{27}{316},\quad0\right).\tag{S14.3}$$

Their coherent sum is

$$\sqrt{30}\,
\frac{1502925864947895702084635234454041}{3859115104366170163070540928506250}\ne0\tag{S14.4}$$

on both duals. The zero scalar value is a CAR pairing at this fixed bra, without deletion of its complete scalar70 matrix.

All 33 analytic numerator groups of the original rational matrices/source DAG are generated by finite polynomials and real/complex constants. The public canonical-numerator theorem discharges each group's analyticity. Both complete bra amplitudes are therefore meromorphic on the complex plane and analytic and nonzero at $i$ by (S14.4). All seventeen actual denominators are analytic and nonzero at $i$ as well. Take the product of both bras and require nonvanishing of every denominator. The meromorphic identity theorem makes each germ at zero nontrivial. Its local Laurent form is a finite integer power times an analytic function nonzero at zero, yielding a punctured neighbourhood without zeros or poles. The minimum of finitely many radii gives one $\delta>0$ for every real $0<|x|<\delta$, both duals and all seventeen denominators together.

The original profile $f(z_*)=1$ is chosen before these kinematics, with the total source consumer choosing one profile for both duals. The analytic step gives the actual nonzero tree at every real kinematics in this window. Evaluation at the source point and injectivity of embedding give $\mathcal B(q_df)\ne0$. The original high-frequency resolvent return $z r_F(z)\to-q_df$ and bounded $\mathcal B$ give $z\mathcal B r_F(z)\to-\mathcal B(q_df)\ne0$. Thus the actual output is nonzero at sufficiently high frequencies. Continuity gives positive spectrum on each measurable neighbourhood of such a frequency. The total spectrum is finite by S14.2 and strictly positive. In time, $U(0)=I$ and continuity give $\mathcal B w_F(t)\to\mathcal B(q_df)$ as $t\downarrow0$, producing nonzero onset and positive time mass. The frequency threshold may depend on the actual parameters; $\delta,f$ precede every $F,\mu,\sharp,c$.

### S14.4 Nonzero $Y$ excess and neutral zero channels use the same source

The N3 response splits orthogonally by grade into its bottom part and $Y$ correction. Its original frequency identity is

$$\int\|r_F(\omega)\|^2d\omega
=\frac\pi\mu\|q_df\|^2+\int\|\mathrm{corr}_{Y,F}(\omega)\|^2d\omega.\tag{S14.5}$$

S14.1 generates $B_Y(q_df)\ne0$. If the $Y$ correction vanished everywhere, the original source-graph splice would give $B_Y(C_F-z)^{-1}q_df=0$ on the whole frequency line. High-frequency resolvent return would force $B_Yq_df=0$, a contradiction. The correction is continuous and square integrable, so a neighbourhood of one nonzero point has positive mass, making the second integral strictly positive. This proves actual integrated excess for every $F,c,\mu>0$, without requiring nonzero output at every frequency.

For signed occupation $Q_s$, each of the four original blocks commutes coefficientwise, including the complete scalar tree. The input $q_d$ has signed value ±3. Original fullY and sharp times and resolvents preserve it on the original saturation$(\pm3,F)$, cofinal along the source filter. For a neutral occupation word $e_w$ with value zero,

$$\langle e_w,\mathcal B r\rangle
=\frac1{\pm3}\langle Q_se_w,\mathcal B r\rangle=0.\tag{S14.6}$$

This is the original signed-sector selection law. Pointwise embedding gives zero at every frequency and every real time, and the squared density gives zero on every Borel band. The strict $Y$ correction of (S14.5) and the neutral zero channels of (S14.6) retain the same profile and cofinal carrier.

### S14.5 Sylvester, raw balance and source invoices on the same $C_F$

This clause fixes the original source damping $\mu_*>0$. The complete spectral decomposition of the finite compression, including escape, is $C_F=\sum_ae_aP_a$ and $\sum_aP_a=I$. It generates

$$\mathcal L_{F,c,\mu}(D)=\sum_{a,b}
\frac{P_aDP_b}{2\mu-i\operatorname{dir}(c)(e_a-e_b)},\quad
2\mu\mathcal L-i\operatorname{dir}(c)[C_F,\mathcal L]=D.\tag{S14.7}$$

Positive $\mu$ pays every denominator. Expanding the products in each channel, using left/right orthogonality and the two-pole integrals, gives the exact same-source price

$$\int\|R_F(\omega)DR_F(\omega)g\|^2d\omega
=\frac\pi\mu\|\mathcal L(D)g\|^2+
\int\|\mathcal L(D)R_F(\omega)g\|^2d\omega.\tag{S14.8}$$

The decisive integral is explicit in each spectral channel. Let $r_a(\omega)$ be the coefficient of the original causal resolvent $R_F(\omega)$ on $P_a$, put $l_{ab}=[2\mu-i\operatorname{dir}(c)(e_a-e_b)]^{-1}$ and $K_2(b,d)=\int\overline{r_b}r_d$. The exact four-pole integral with equal left pole is

$$K_4(a,b;a,d):=\int\overline{r_ar_b}\,r_ar_d
=\overline{l_{ab}}\,l_{ad}\left[\frac\pi\mu+K_2(b,d)\right].\tag{S14.8a}$$

Write $w_{ab}=P_aDP_bg$. Distinct output channels $a$ are orthogonal; within each $a$, every ordered $b,d$ cross term is retained. The squared integral on the left is therefore $\operatorname{Re}\sum_{a,b,d}K_4(a,b;a,d)\langle w_{ab},w_{ad}\rangle$. Its constant term is exactly $(\pi/\mu)\sum_a\|\sum_b l_{ab}w_{ab}\|^2=(\pi/\mu)\|\mathcal L(D)g\|^2$, while its $K_2$ term is precisely the remaining $\int\|\mathcal L(D)R_Fg\|^2$. This proves (S14.8) term by term and explains the initial income in the original two-term Hardy decomposition. Actual $D$ is the original cutoff increment and escape channels remain throughout.

For any complete test-core form $Q$, the same channel expansion and two-pole integrals give

$$\int\langle R_Fg,[2\mu Q-i\operatorname{dir}(c)(C_FQ-QC_F)]R_Fg\rangle d\omega
=2\pi\langle g,Qg\rangle.\tag{S14.9}$$

This finite channel equality is used on the source core; an unbounded $Q$ need not first have a bounded whole-H realization. Substitution of the original raw stored-energy form combines the Lyapunov term and the actual two-resolvent mixed term into

$$\int R_{\rm raw}\,d\omega
=4\pi Q_{m\ell}(g)-2\mu_*\int\|R_F D_{m\ell}R_Fg\|^2d\omega.\tag{S14.10}$$

The original cutoff and Hardy tails each choose a common $N$ at target $\varepsilon/4$. Their maximum, (S14.8) and (S14.10) give $\mathrm{JointCost}\le\varepsilon-\mu_*^{-1}\int R_{\rm raw}$ for all $m\ge N$, $\ell\ge m$, cofinal $F$ and both causal choices. The raw integral remains signed, retaining negative income.

The pressure invoices also arise on this same core. Let $I_{\rm corrected}$ be the original native invoice plus the original pressure-moment/contact corrections, and $I_{\rm move}=I_{\rm contact}+\operatorname{Re}(\mathrm{productCross})/12$. The original phase, pressure and covariance product rules give these same-source identities. The source moment tail pays $|\int\mathrm{OwnFlux}-\int I_{\rm corrected}|\le\varepsilon$. Paying the contact-cleared lower bound at $\varepsilon/2$ and the whole-frequency productCross norm at $6\varepsilon$ makes its $1/12$ contribution at most $\varepsilon/2$, giving $\int\mathrm{OwnFlux}\ge\int I_{\rm move}-\varepsilon$. The original radial Ward endpoints retain inverse-form debt with coefficient $432\,\mathsf p/3481$. Fixed-pressure and causal-correction tails use $\delta=\varepsilon/[4(B+1)]$, where $B$ is the sum of the two nonnegative raw sharp coefficients; four cofinal obligations share the maximum $N$. Substitution into original stored energy returns native work, reserve, Sylvester initial price and both radial debts together. Every cross integrand retains its order before integration.

Finally the original scalar-balanced generator is $A_{\rm bal}=A_{\rm rev}-9G$, and $G$ commutes with the complete scalar bulk. Its scalar current is exactly

$$J_{\rm sc}=120nE_{\rm nat}^{-1}+24nM_{\rm shift}+24C_{\rm root}
-6n\|\Phi_{\rm vac}\|^2\|w\|^2.\tag{S14.11}$$

Here $n$ is the original lapse, $E_{\rm nat}^{-1}$ the inverse-volume native energy, $M_{\rm shift}$ the vacuum-affine position square and $C_{\rm root}$ the original centred-root pairing, all evaluated on the same $w=\theta_{m\ell}R_Fg$. The coefficient 120 is $3\cdot4+108$ and every vacuum-affine term remains. The explicit two-square definition of original field debit, with nonnegative coefficient $c_\sharp$, gives

$$\mathrm{Debit}_{\rm field}
=\frac{c_\sharp}{128n\mu_*}J_{\rm sc}
-\frac{15c_\sharp}{16\mu_*}E_{\rm nat}^{-1}
+\frac{3c_\sharp\|\Phi_{\rm vac}\|^2}{64\mu_*}\|w\|^2.\tag{S14.12}$$

Original forcing is $\theta g+[H_0,\theta]R_Fg+\theta d_FR_Fg$, generated directly by the original two-sided inverse as $H_0w=zw+\mathrm{forcing}$. Its two original Noether endpoints make signed work exactly $J_{\rm sc}$, so (S14.12) is actual payment by that forcing. The native pressure gain's $3c_\sharp/(16\mu_*)$ plus this $15c_\sharp/(16\mu_*)$ credit is exactly $9c_\sharp/(8\mu_*)$. Its other original gauge, phase-force and vacuum-norm terms remain. These payments belong to the new literal budget and preserve S8's matched $\Gamma$ and absolute endpoint common tail.

**Fixed sources and direct use.** At 71e: `external-composite-decay/MixedSpectatorYukawaNonzero`, `SourceYukawaPositiveCorrection`, `MixedSpectatorFourBlockSource`, `SourceActualFourBlock{Retarded,HilbertOperator,SharpCausalMass,ElasticNonzero,RealTransferCanonicalNumerator,RealTransferWindow,ProfileFamily,RealTransferPositive,SignedSector}` and the original 17-denominator/33-group closure. At 9c73: `Lean/scratch/LowEnergyRetardedCouncil/ActualFourBlockResponse/SourceActual{TwoResolventSylvester,ExactSylvesterRawFrequencyBalance,BalancedPressureMomentPayment,PressureProductCrossPayment,BalancedPressureRadialPayment,ScalarFieldDebitPayment}`. Direct declarations are `actual_generated_source_real_transfer_positive`, `actual_generated_source_dynamic_selection`, `actual_two_resolvent_price`, `actual_vector_joint_raw_paid_price`, `actual_source_native_pressure_integral_payment`, `actual_source_moving_current_native_lower`, `actual_raw_pressure_reserve_return` and `actual_scalar_field_native_credit`. Their original kernel certifications are retained; no scientific programme was rerun.


---

## S15 The complete first event of the original 120 ns source, with two actual recoveries

This section gives the mathematics and original scientific evidence for Proposition 9.4. Model input is the original source-issued detector gate, initial joint matrix, all natural jumps and registered Mark. Scientific curves retain their respective freezes and independent consumers. The intervals below come from accepted original receipts, without new curves, fitting or event samples.

### S15.1 Original full generator, free bank and first forcing

Write the original stopped source's natural generator as $\mathcal L_{\rm nat}(\rho)=K\rho+\rho K^\dagger+\sum_jJ_j\rho J_j^\dagger$, retaining same-arm and opposite-arm recycling, natural loss and paired complex cross terms. Registered updates act on the complete Mark through their original target-minus-identity form. The natural local TP part gives free propagation $\mathcal U_0$ and the Mark update difference is $\mathcal R(t)$. The actual ordered Volterra equation is

$$\rho(t)=\mathcal U_0(t,0)\rho(0)+\int_0^t\mathcal U_0(t,s)\mathcal R(s)\rho(s)ds.\tag{S15.1}$$

The complete tensor action satisfies $(L_A\otimes L_B)(\rho_A\otimes\rho_B)(R_A\otimes R_B)=(L_A\rho_AR_A)\otimes(L_B\rho_BR_B)$, including opposite-arm cross terms. Each complex cross $cZ$ retains its reverse $\bar cZ^\dagger$, making the sum Hermitian. First registered forcing substitutes the same actual free initial term for $\rho(s)$ in (S15.1). It is the complete original jump rows acting on the actual free bank, rather than a forcing inferred from mean counts.

If the original complete-gate registered activity has source price $a\ge0$, simplex volume pays the ordered term $n$ by $a^n/n!$. For $a<N+2$, every finite suffix obeys

$$\sum_{k=0}^{m-1}\frac{a^{N+1+k}}{(N+1+k)!}
\le\frac{a^{N+1}}{(N+1)!}\frac1{1-a/(N+2)}.\tag{S15.2}$$

Indeed, consecutive ratios are $a/(N+2+k)\le a/(N+2)$. Induction gives geometric domination and the finite geometric-sum bound proves the result. This mathematical suffix price, the actual TP consumer and the scientific bank below retain their evidence classes.

The complete original ten-factor free bank passes the original $10^{-8}$ relative gate over 120 ns. Its new joint uniform error is approximately $2.409899\times10^{-14}$; the old inlet error of approximately $6.921854\times10^{-10}$ is paid once. The actual forcing DAG contains ten curve nodes, 40 operators and 328 signed rows, consuming all 45 Marks, four backgrounds and two phase words. The independent raw compiler and complete tensor identities yield `complete_source_first_registered_forcing_DAG_and_prices_checked`. This pays complete forcing, without claiming numerical integration of every later Volterra term.

### S15.2 Complete late-adjoint integration retains natural recycling

For each of the four original registered ports $r$, the late effect is the actual original free-TP adjoint integral

$$E_r^{\rm late}=\int_{I_{\rm late}}
\mathcal U_0(t,0)^*(\mathcal J_r^*I)dt.\tag{S15.3}$$

The interval $I_{\rm late}$ retains the original gate's actual late restriction. The natural TP spectator remains. The precise algebra reducing some jumps is: if $P=P^\dagger$, $PJ=J$ and $POP=0$, then $J^\dagger OJ=0$. If $P$ commutes with the original propagator, conjugation preserves $POP=0$. Direct matrix multiplication proves these reductions under their conditions; every other natural recycling term remains.

The original four-port integral evaluates all 60 degree-64 pieces at the actual source positive-quadrature nodes. Conjugation, multiplication, Hermitian projection and source rates have rational outward prices. Phase tails and complete polynomial quadrature are paid together. If the two local relative errors are $a,b$, their joint error is $a+b+ab$, retaining cross error. The finite moment price $e\sum|c_j|$ follows from $|m_j-q_j|\le e$ and the triangle inequality.

Independent arbitrary-precision complex integer multiplication checks 4,915,200 original coefficients. The full four-port late integral passes the original $10^{-10}$ gate with maximum operator error approximately $8.42743690252\times10^{-12}$. This includes natural recycling, Gamma price, source phase and all 60 pieces. This consumer pays an actual late time integral, distinct from the original free bank and first forcing.

### S15.3 Three no-count coimages are exactly the complete first event

For each original Mark history let $n_\perp,n_\parallel$ be Boolean indicators of no registration yet in the two required groups. Pointwise Boolean algebra gives

$$1_{\rm first}=1-n_\perp-n_\parallel+n_\perp n_\parallel.\tag{S15.4}$$

Sum under the same complete history mass. If the total input mass is $M$, the actual event mass is $M-M_\perp-M_\parallel+M_{\perp\parallel}$; individual signed tensor factors need not be probability states.

Each no-count query is the original full-Mark restriction

$$\mathcal L_Q^{\rm nc}=\mathcal L_{\rm nat}-\sum_{j\in Q}\mathcal J_j.\tag{S15.5}$$

For each Mark, $1_{\rm inside\wedge\neg forbidden}-1_{\rm inside}=-1_{\rm inside\wedge forbidden}$. Thus only forbidden registered jumps are subtracted; the remaining natural bath, loss and cross terms continue to act. Three queries on two arms give the original six complete 120 ns adjoint flows with the actual identity effect as terminal value.

The original trace duality is termwise

$$\operatorname{tr}[E(K\rho+\rho K^\dagger)]
=\operatorname{tr}[(K^\dagger E+EK)\rho],\quad
\operatorname{tr}[E(L\rho R)]=\operatorname{tr}[(REL)\rho].\tag{S15.6}$$

Cyclic trace gives the right-drift identity and the recycle identity, retaining paired complex cross terms. For the original TNI evolution $\rho_Q'=\mathcal L_Q^{\rm nc}\rho_Q$ and the backward identity-terminal effect, $d\operatorname{tr}(E_Q\rho_Q)/dt=0$. Both original primal and adjoint therefore read the same complete event (S15.4).

### S15.4 The whole event pays the same-source inlet error once

Let the trace-norm error between $\rho_0$ and its prior source approximation $\widehat\rho_0$ be $E_0$. The original complete first-receipt activity generates the effect bound

$$\|E_{\rm first}\|\le\kappa,\qquad
\kappa\le0.003740914454934,\quad
|P_{\rm first}-\widehat P_{\rm first}|
\le\kappa E_0+E_{\rm new}.\tag{S15.7}$$

The value $\kappa$ is the same-source Poisson/activity envelope generated by the original Gamma, gate duration and the empty Mark's requirement for at least two future registered arrivals. Source contraction and probability coimages retain the same gate, initial clock, Mark and activity record. The old error is applied once to the combined first-event effect; the three no-count queries do not each reapply it. New effect and arithmetic errors are combined by the three-coimage triangle inequality.

The original adjoint certificate gives whole-event error $4.82891852304\times10^{-12}$ through (S15.7). An outward decimal enclosure of its exact rational interval is

$$P_{\rm first}\in[3.17845500810,3.17846466595]\times10^{-6}.\tag{S15.8}$$

All six original complete coflows pass the $10^{-8}$ gate. The strictly positive lower endpoint is the actual normalizer of the original any-first-herald event.

The independent primal consumer directly solves (S15.5) for the original signed Hermitian inlet factors: thirty complete 120 ns curves, 3600 pieces. Full 33-coordinate piecewise ODE residuals, continuous joins, source coefficients and Gamma prices are checked independently. Hermitian TNI trace-norm contraction pays propagated residuals; numerical-centre positivity does not substitute for positivity of the source model. At complete endpoints, recovery combines all thirty factors into the same three queries and (S15.4). It gives whole-event error $2.65930922070\times10^{-12}$ and

$$P_{\rm first}\in[3.17845717771,3.17846249634]\times10^{-6}.\tag{S15.9}$$

The centres differ by approximately $1.301828\times10^{-21}$, an original independent-recovery result. The old inlet error was not used to explain this difference between numerical centres. The source issues all seven priority queries and 140 activation/scalar programmes including four coupled queries. Original readiness consumes the same successor-herald and two-arm UID domains. The complete coupled CEM time mother and its numerical curves retain their own consumers, without changing the identities of these accepted free/no-count banks.

```{=latex}
\clearpage
```

### S15.5 Original scientific freezes and the present written checks are separate

| Actual consumer | Original scientific freeze | Reading/evidence in this paper |
| --- | --- | --- |
| Complete late integral rha0038.1 | `a165b04a26febd0bc4e7ed1f33d4668b564a6e4f` | Four ports, 60 pieces and complex integer coefficients; original $10^{-10}$ gate |
| Original three no-count coimages rha0039 | `425ed6ed406b2a96f044dafd1c39b3587a9f14f0` | Six complete 120 ns adjoint flows; original $10^{-8}$ gate |
| Same-activity probability price rha0039.1 | `87f9b1234441783f945727408b06ede72af9683d` | (S15.7)–(S15.8), prior error paid once |
| Thirty primal curves and actual recovery rha0041.1 | Science `065399a21dcf684b38fd34c791e9861fca95d5ea`; consumer `f7a5ee523ac80f6bee40671a03ce7d678d020760` | 3600 source pieces, 90 independent rational pieces; (S15.9) and centre difference |
| Original priority quantum programmes rha0042 | `7c9423057a2ee8f594b7502172e1a37105490829` | All seven queries, 140 activation/scalar components, four coupled programmes |

Complete streams, source records and generated artifacts keep their original receipt bindings; read-only recovery is not a new scientific run. Original mathematical mouths are `RegisteredDuhamelTail.every_finite_suffix_upper`, `RegisteredTensorAction.source_tensor_left_right`, `LateRegisteredAdjoint`, `FirstReceiptZeroCount.complete_mass_identity`, `FirstReceiptQuantumFlux.original_drift_duality` and `NoCountQuantumGenerator.whole_source_quantum_restriction`. Direct checkers are `registered_forcing_independent_rha0034.py`, `late_registered_integral_rha0038_1.py`, `zero_count_check_rha0039.py`, `zero_count_probability_price_rha0039_1.py`, `zero_count_primal_check_rha0040.py` and `zero_count_primal_run_rha0041_1.py`, under `Verification/physics/stage10/independent-bell/munich/readout-domain/`. This pass reads fixed sources, model algebra and original receipts, without executing solvers or statistical trials again.
