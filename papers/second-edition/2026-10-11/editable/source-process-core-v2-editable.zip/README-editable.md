# source-process-core · second edition editable inputs

The Markdown manuscripts and supplements, bilingual vector figures, bibliography,
metadata and the existing builders retain the publish-relative layout. The
source notebooks, private prompts and research repositories are separate.

Run from `papers/source-process-core` with Python 3, Pandoc, XeLaTeX, xeCJK and the Noto
Serif/Sans CJK SC fonts installed. Build the four reading PDFs with:

```sh
python3 scripts/build_pdf.py manuscript.md --output build/v2/source-process-core.pdf --work-dir build/v2/work-zh
python3 scripts/build_pdf.py manuscript-en.md --output build/v2/source-process-core-en.pdf --work-dir build/v2/work-en
python3 scripts/build_pdf.py supplement.md --output build/v2/source-process-core-supplement.pdf --work-dir build/v2/work-supp-zh
python3 scripts/build_pdf.py supplement-en.md --output build/v2/source-process-core-supplement-en.pdf --work-dir build/v2/work-supp-en
```

Run the portable English arXiv build from the package root:

```sh
python3 shared/scripts/arxiv_package.py papers/source-process-core --output-dir papers/source-process-core/build/v2/arxiv
```

The arXiv tarball is a separate TeX/figure package. Its target is TeX Live 2025;
the local edition was actually compiled with TeX Live 2026. Paper text and
figures use CC BY 4.0; formalization follows the repository's Apache-2.0 license.
The Code and data availability section records each fixed source and its actual
acceptance scope. Public package acceptance remains a separate delivery gate.

`editable-inputs.json` binds the copied inputs byte for byte. This local ZIP
does not create an upload or a new DOI.
