# 1 Bit Is All You Need · editable v1

The bilingual manuscripts (each with Appendices A-E), eight editable vector
figures, PNG previews, the figure generator, bibliography, local metadata and
the OB1-OB11 selection keep the directory layout required by the shared builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome and Noto Serif/Sans CJK SC. Build both PDFs:

    python3 shared/scripts/build_pdf.py papers/one-bit/manuscript.md papers/one-bit/manuscript-en.md --output-dir papers/one-bit/build/zenodo-20261017

With CairoSVG and fontTools installed, regenerate the figures:

    python3 papers/one-bit/figures/render.py
    python3 papers/one-bit/figures/render.py --english

All formal material is located through H0mework commit 6bff9d4046b3f89004678244482b1c403837150c
(material commit c40ef754ccbbea96f8c1417f12348e840da5eb82) and its docs/one-bit-map.json.
In that repository run make check-one-bit-entry to check the five reused accepted
packages and the selected sources; after make bootstrap, make check-one-bit-full
builds, trusts and type-checks the new OB2 ghost control. The reused packages can
be rebuilt completely with make check-whole-ledger-full (OB3, OB5, OB8-OB10) and
make check-first-release-full (OB6-OB7). reproduction.md gives the full paper and
proof reproduction route.

The input manifest binds every copied file byte for byte. This editable package
accompanies the v1 preprint, DOI 10.5281/zenodo.23437456. Paper text and original figures
use CC BY 4.0; code uses Apache-2.0.
