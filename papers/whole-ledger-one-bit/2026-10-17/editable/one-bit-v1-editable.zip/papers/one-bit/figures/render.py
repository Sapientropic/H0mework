#!/usr/bin/env python3
"""Generate the One Bit paper's editable SVG plates and PNG previews.

Series visual language (shared/figure-style): no in-figure headline, serif
type, ink/grey structure, deep blue for generated objects, one vermilion
accent per plate. The canvas is 1440 px wide and prints at about 6 in, so no
text is set below 24 px. Each label exists once with its Chinese and English
wording; `--english` writes the `-en` plates from the same layout.
"""
import argparse
import sys
from html import escape
from pathlib import Path

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH  # noqa: E402
import svg_text  # noqa: E402
from svg_text import line, text_width, register_cjk_for_cairo  # noqa: E402

# Operators these plates use beyond the shared set; STIX Two Math owns their glyphs.
svg_text.OPS.update('⋆⊔≡⇏∅')

W = 1440
MIN_SIZE = W / 60
LANG = ['zh']
parts, boxes = [], []


def L(zh, en):
    return zh if LANG[0] == 'zh' else en


def start(height, title, description):
    parts.clear(); boxes.clear()
    parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
                 f'viewBox="0 0 {W} {height}" role="img">')
    parts.extend([f'<title>{escape(title)}</title>', f'<desc>{escape(description)}</desc>'])
    parts.append('<defs>' + ''.join(
        f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" '
        f'orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>'
        for n, c in [('ink', SLATE), ('acc', VERMILION), ('deep', DEEP)]) + '</defs>')
    parts.append(f'<rect width="{W}" height="{height}" fill="#FFFFFF"/>')
    return height


def txt(x, y, text, size=26, color=INK, weight=400, anchor='start'):
    assert size >= MIN_SIZE - 1e-9, (text, size)
    width = text_width(text, size, MIN_SIZE)
    x0 = x - {'start': 0, 'middle': width / 2, 'end': width}[anchor]
    boxes.append((x0, y - .82 * size, x0 + width, y + .22 * size, text))
    parts.append(line(x, y, text, size, color, weight, anchor, min_size=MIN_SIZE))


def rect(x, y, w, h, fill='none', stroke=HAIR, width=1.6, radius=6, dashed=False):
    dash = ' stroke-dasharray="10 7"' if dashed else ''
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" '
                 f'stroke="{stroke}" stroke-width="{width}"{dash}/>')


def path(d, color=SLATE, width=2.2, marker='ink', dashed=False):
    dash = ' stroke-dasharray="9 6"' if dashed else ''
    end = f' marker-end="url(#arrow-{marker})"' if marker else ''
    parts.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{dash}{end}/>')


def arrow(x1, y1, x2, y2, color=SLATE, marker='ink', width=2.2, dashed=False):
    path(f'M {x1} {y1} L {x2} {y2}', color, width, marker, dashed)


def card(x, y, w, h, title, rows, stroke=HAIR, fill='none', gap=38, title_color=INK, dashed=False):
    rect(x, y, w, h, fill, stroke, 2.4 if stroke in (VERMILION, DEEP) else 1.6, dashed=dashed)
    txt(x + 22, y + 42, title, 27, title_color, 600)
    for i, row in enumerate(rows):
        txt(x + 22, y + 84 + i * gap, row, 24, SLATE)
    for (x0, _, x1, _, t) in boxes[-len(rows) - 1:]:
        assert x1 <= x + w - 10, ('card overflow', t, x1, x + w)


def save(name, height):
    for i, a in enumerate(boxes):
        assert a[0] >= 8 and a[2] <= W - 8 and a[1] >= 4 and a[3] <= height - 4, ('outside canvas', a)
        for b in boxes[i + 1:]:
            if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                raise AssertionError(('text overlap', a[4], b[4]))
    svg = '\n'.join(parts + ['</svg>'])
    stem = name if LANG[0] == 'zh' else name + '-en'
    (OUT / f'{stem}.svg').write_text(svg, encoding='utf-8')
    import cairosvg
    cairosvg.svg2png(bytestring=svg.encode(), write_to=str(OUT / f'{stem}.png'))


def forest():
    """Accent: the 0 is only the entry stamp; the source root carries every branch."""
    H = start(1000, L('一枚0，整片森林', 'One 0, a whole forest'),
              L('入口0是二值问句；根是源与登记发生；四条分支各由一项构造支付，下层实例只消费上层构造。',
                'The 0 is the binary question; the root is the source and its registered occurrence; '
                'each branch is paid by one construction, and instances only consume them.'))
    # entry stamp
    parts.append(f'<ellipse cx="118" cy="420" rx="54" ry="68" fill="none" stroke="{VERMILION}" stroke-width="13"/>')
    txt(118, 534, L('入口', 'Entry'), 26, VERMILION, 600, 'middle')
    txt(118, 574, L('二值问句', 'binary'), 24, SLATE, anchor='middle')
    txt(118, 608, L('账外差异', 'question'), 24, SLATE, anchor='middle')
    txt(118, 642, L('能否进门？', 'only'), 24, SLATE, anchor='middle')
    arrow(184, 420, 228, 420, VERMILION, 'acc')
    # root
    card(236, 302, 300, 236, L('根：源与发生', 'Root: the source'),
         [L('源生权威根', 'authoritative root'), L('时序访问', 'temporal visit'),
          L('登记发生 occ', 'registered occ'), L('整账写入·后继', 'ledger write · next')],
         DEEP, WASH, title_color=DEEP)
    # four branches
    bx, bw = 640, 520
    branches = [
        (40, L('身份', 'Identity'), [L('occ(w) ≠ occ(w′) ⇒ 结构身份', 'occ(w) ≠ occ(w′) ⇒ structural id'),
                                     L('全实在性 ⇒ 无补写 ⇒ 无魔法', 'total ⇒ no supplement ⇒ no magic')],
         L('登记发生不等', 'occurrences differ')),
        (260, L('形成', 'Formation'), [L('S{sub:⋆} 有限程序像之完成', 'completion of S{sub:⋆} programmes'),
                                        L('世界 · 询问 · 宏过程，限制恢复', 'world · inquiry · process recovered')],
         L('稠密完成＋工厂恢复', 'dense completion + factory')),
        (480, L('行动', 'Action'), [L('未来残差 → 请求 → 同债付款', 'residual → request → same-debt pay'),
                                     L('回答 · 回执 · 整账写入 · 后继', 'answer · receipt · write · next')],
         L('语法费用＋同债付款', 'syntax cost + payment')),
        (700, L('修订', 'Revision'), [L('扎根失败 → 最小方向 → 修订', 'rooted failure → minimal direction'),
                                       L('旧行与新行同一次首写', 'old and new rows: one first write')],
         L('初始性＋同一首写', 'initiality + first write')),
    ]
    for y, title, rows, label in branches:
        card(bx, y, bw, 160, title, rows)
        cy = y + 80
        path(f'M 536 420 C 580 420, 590 {cy}, {bx - 8} {cy}', DEEP, 2.4, 'deep')
        txt(bx + bw - 16, y + 42, label, 24, DEEP, anchor='end')
    # instance layer
    ix, iw = 1200, 200
    txt(ix + iw / 2, 226, L('下游消费', 'Consumers'), 24, MUTE, 600, 'middle')
    card(ix, 242, iw, 196, L('原物理过程', 'Physics run'),
         [L('封印·整条法则', 'seal · whole law'), '16 → 17', L('任意深度历史', 'every depth')])
    card(ix, 462, iw, 196, L('长计算', 'Long run'),
         [L('四份旧迹', 'four old traces'), L('纠正·付款', 'correction · pay'), L('全部未来读口', 'all futures')])
    arrow(1168, 340, 1192, 340, MUTE, 'ink', 2.0)
    arrow(1168, 560, 1192, 560, MUTE, 'ink', 2.0)
    rect(40, 890, 1360, 84, WASH, VERMILION, 2.4)
    txt(720, 942, L('这个比特只问来历；每条分支的结论由它自己的构造支付', 'The bit only asks for provenance; each branch is paid by its own construction'),
        28, VERMILION, 600, 'middle')
    save('one-bit-forest', H)


def ghost():
    """Accent: the overreach from raw inequality to world inequality."""
    H = start(590, L('两枚bit，一张身份证', 'Two bits, one identity'),
              L('原始二元组不同；准入投影（第一分量）给出同一合法状态、登记发生与权威演化；真实差异来自不同的根访问。',
                'Raw pairs differ; the admission projection (first component) gives one lawful state, occurrence and evolution; '
                'a real difference comes from distinct root visits.'))
    card(40, 40, 360, 250, L('原始数据', 'Raw data'),
         ['g{sub:0} = (w{sub:1}, false)', 'g{sub:1} = (w{sub:1}, true)', L('g{sub:0} ≠ g{sub:1}：真的', 'g{sub:0} ≠ g{sub:1}: true')])
    card(520, 40, 400, 250, L('准入之后', 'After admission'),
         ['g{sub:0}.1 = g{sub:1}.1 = w{sub:1}', L('登记发生相等', 'same occurrence'), L('权威演化相等', 'same evolution'),
          L('构造子无 Bool 参数', 'no Bool argument')], DEEP, title_color=DEEP, gap=40)
    card(1000, 40, 400, 250, L('真实差异', 'Real difference'),
         ['w{sub:1} = finite(v{sub:1})', 'w{sub:2} = finite(v{sub:1}.next)', 'occ(w{sub:1}) ≠ occ(w{sub:2})'], gap=40)
    arrow(408, 165, 512, 165, DEEP, 'deep', 2.6)
    txt(460, 140, L('准入投影', 'admission'), 24, DEEP, anchor='middle')
    # the forbidden step
    path('M 220 300 C 220 390, 600 390, 680 390', VERMILION, 2.6, None, dashed=True)
    txt(700, 400, '⇏', 40, VERMILION, 600, 'middle')
    txt(740, 400, L('“现实多一个”', '“one more world”'), 27, VERMILION, 600)
    rect(40, 470, 1360, 84, WASH, VERMILION, 2.4)
    txt(720, 522, L('原始数据多一位 ⇏ 现实多一个；改变登记发生，才是新差异',
                    'One more raw bit ⇏ one more world; only a changed occurrence is a new difference'),
        28, VERMILION, 600, 'middle')
    save('ghost-identity', H)


def continuation():
    """Accent: the actual same-debt payment generated by the request's own syntax."""
    H = start(800, L('原残差自己入账、付款、回答并翻页', 'The residual enters, pays, answers and turns the page'),
              L('原材料生成下一请求，实际语法付款与后缀完成交付原回答和回执；同一整账写入保全部旧行和出生行并生成规范后继。',
                'Original material generates the next request; syntax payment and completion deliver the answer and receipt; '
                'one whole-ledger write keeps old and born rows and yields the canonical next.'))
    xs, width = [40, 390, 740, 1090], 310
    data = [
        (L('材料与未来模型', 'Material · future'), ['Raw · State · Trace', L('承担行·全部词／站位', 'owner · words/sites'),
                                                  L('残差 ≡ 已付边界', 'residual ≡ boundary')]),
        (L('下一原请求', 'Next request'), [L('材料生成语法树', 'material → AST'), L('首步已执行', 'first step paid'),
                                         L('剩余 Q − 1 > 0', 'remaining Q − 1 > 0')]),
        (L('同债实际付款', 'Same-debt payment'), [L('已付·严格扣减', 'paid · strict debit'), L('同债唯一·不补充', 'same debt · no refill'),
                                                 L('零效应仍付语法费', 'zero effect still pays')]),
        (L('完成事件', 'Completion'), [L('后缀·完成值 = ε', 'suffix · value = ε'), L('回答与其原回执', 'answer + receipt'),
                                      L('因果回答与后继', 'causal answer + next')]),
    ]
    for i, (x, (title, rows)) in enumerate(zip(xs, data)):
        card(x, 38, width, 224, title, rows, VERMILION if i == 2 else HAIR)
        if i < 3:
            arrow(x + width + 6, 150, xs[i + 1] - 7, 150, VERMILION if i == 1 else SLATE, 'acc' if i == 1 else 'ink')
    path('M 1245 270 L 1245 340 L 465 340 L 465 384')
    card(40, 391, 850, 214, L('同一次整本账写入', 'One whole-ledger write'),
         [L('全部旧行 → 各自的原去向', 'every old row → its exact destination'),
          L('出生行 → 同一写入中的去向', 'born row → destination in that write'),
          L('新责任有自己的来源与首步', 'new responsibility: own source, own first step')])
    card(975, 391, 425, 214, L('规范后继', 'Canonical next'),
         [L('完整根与当前', 'full root and current'), L('已付材料与库存', 'paid material, stock'),
          L('下一请求继续消费', 'next request uses them')], DEEP, title_color=DEEP)
    arrow(903, 500, 961, 500, DEEP, 'deep')
    rect(40, 676, 1360, 84, WASH, VERMILION, 2.4)
    txt(720, 728, L('账本别光记仇，自己付一次：零值不能删除已付步骤', 'A ledger that pays: zero values erase no paid step'),
        30, VERMILION, 600, 'middle')
    save('paid-continuation', H)


def revision():
    """Accent: old and new rows entering one first write, then disposed separately."""
    H = start(1020, L('修宪可以，销账不行', 'Amend the constitution, not the debt'),
              L('扎根失败生成最小方向；容许修订唯一接收它；实际发射的修订把旧行与新行送入同一次首写，新根分别处置。',
                'A rooted failure generates the minimal direction; admissible revisions receive it uniquely; an emitted revision '
                'sends old and new rows into one first write, and the new root disposes of each.'))
    card(40, 40, 400, 250, L('扎根失败', 'Rooted failure'),
         [L('表达 = ∅ · 实现 = ∅', 'expression = ∅ · realization = ∅'), L('事件 = 规范发射', 'event = canonical emit'),
          L('需求行 e · 处置交换', 'demand row e · commuting'), L('e 的因果后继', 'successor of e')])
    card(540, 40, 380, 250, L('最小方向', 'Minimal direction'),
         ['C = L{sub:+} ⊔ {⋆}', L('旧行预算照读', 'old budgets kept'), L('⋆ 预算 0，无旧原像', '⋆: budget 0, no preimage')],
         DEEP, title_color=DEEP)
    card(1020, 40, 380, 250, L('任一容许修订', 'Any admissible revision'),
         [L('旧面回缩', 'old faces retract'), L('新元无旧原像', 'new element, no preimage'), L('继承预算不增', 'no refill')])
    arrow(448, 165, 532, 165, DEEP, 'deep', 2.6)
    txt(490, 140, L('生成', 'generate'), 24, DEEP, anchor='middle')
    arrow(928, 165, 1012, 165, SLATE, 'ink', 2.4)
    txt(970, 140, L('唯一', 'unique'), 24, SLATE, anchor='middle')
    card(330, 340, 780, 176, L('有类型修订 Ξ：须由询问程序实际发射', 'Typed revision Ξ: must be emitted by the inquiry'),
         [L('新根 · 翻译 · 旧账回缩 · 新行 · 首写', 'new root · translation · old ledger · new row · first write'),
          L('精确接地，或更丰富的忠实接地', 'exact grounding, or richer faithful grounding')], SLATE, dashed=True)
    path('M 730 296 L 730 332', SLATE)
    txt(745, 322, L('因子化', 'factorize'), 24, SLATE)
    # two rows into one first write
    card(40, 570, 400, 176, L('迁入旧行 i(e)', 'Migrated old row i(e)'), [L('自己的初始行', 'its own initial row'), L('→ 初始权威', '→ initial authority')])
    card(40, 790, 400, 176, L('新增行 ⋆{sub:η}', 'New row ⋆{sub:η}'), [L('自己的初始行', 'its own initial row'), L('→ 初始权威', '→ initial authority')])
    # both rows are generated rows of Ξ's initial patch
    path('M 330 430 L 20 430 L 20 878 L 32 878', SLATE)
    path('M 20 658 L 32 658', SLATE)
    rect(560, 680, 260, 140, WASH, VERMILION, 2.6)
    txt(690, 740, L('同一次首写', 'One first write'), 28, VERMILION, 600, 'middle')
    txt(690, 782, L('同一后继等式', 'same next equation'), 24, SLATE, anchor='middle')
    path('M 448 658 C 500 658, 510 720, 552 726', VERMILION, 2.6, 'acc')
    path('M 448 878 C 500 878, 510 790, 552 776', VERMILION, 2.6, 'acc')
    card(920, 590, 480, 330, L('新根自己的处置器', 'The new root’s own classifier'),
         [L('旧行：回答与后继', 'old row: answer and next'), L('新行：回答与后继', 'new row: answer and next'),
          L('下一当前相同', 'one next current'), L('旧障碍是否结清：', 'old obstruction settled?'),
          L('由此处置给出', 'decided here'), L('不由改名给出', 'not by renaming')], DEEP, title_color=DEEP)
    arrow(828, 750, 912, 750, DEEP, 'deep', 2.6)
    save('revision-ledger', H)


def render_all():
    forest(); ghost(); continuation(); revision()


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--english', action='store_true')
    args = ap.parse_args()
    register_cjk_for_cairo()
    LANG[0] = 'en' if args.english else 'zh'
    render_all()
    print('Rendered four ' + ('English' if args.english else 'Chinese') + ' plates.')
