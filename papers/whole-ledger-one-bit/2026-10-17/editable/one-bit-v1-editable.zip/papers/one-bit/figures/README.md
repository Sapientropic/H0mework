# 一比特稿图件

四图与[中文正文](../manuscript.md)及[英文正文](../manuscript-en.md)的图1–4对应。SVG 是可编辑矢量源，PNG 是同源预览；中英文标签在同一生成器中逐项成对维护。

| 图 | 中文／英文源 | 读者应看出的关系 | 正文与证明 |
| --- | --- | --- | --- |
| 1 一枚0，整片森林 | [中文SVG](one-bit-forest.svg)／[英文SVG](one-bit-forest-en.svg) | 0只是二值问句的入口印记；根是源与登记发生；身份、形成、行动、修订四支各由自己的构造支付，右列物理过程与长计算构造只消费所连分支。 | 主定理1.1；[OB1–OB10](../claims.md) |
| 2 两枚bit，一张身份证 | [中文SVG](ghost-identity.svg)／[英文SVG](ghost-identity-en.svg) | 原始二元组确实不等；唯一准入投影给出同一状态、登记发生与权威演化；真实差异来自两次不同根访问。朱红标出越权的一步。 | 命题2.3；[OB2](../claims.md#ob2) |
| 3 不准免费翻页 | [中文SVG](paid-continuation.svg)／[英文SVG](paid-continuation-en.svg) | 原材料生成请求，语法付款严格扣减同一笔债，完成事件交付回答、回执与规范后继；同一整账写入安置旧行与出生行。 | 定理5.1–5.3；[OB8](../claims.md#ob8) |
| 4 修宪可以，销账不行 | [中文SVG](revision-ledger.svg)／[英文SVG](revision-ledger-en.svg) | 扎根失败生成最小方向并被容许修订唯一接收；修订须实际发射并接地；旧行与新行同一次首写，由新根分别处置。 | 定理6.2–6.5；[OB9](../claims.md#ob9) |

图3的布局与语义沿用[整账法图3](../../whole-ledger-accounting/figures/source-continuation.svg)，标签按本文记号重写。

## 编辑与再生成

在 publish 根目录运行：

```sh
python3 papers/one-bit/figures/render.py
python3 papers/one-bit/figures/render.py --english
```

依赖 Python 3、CairoSVG 与 fontTools；字体与测量 helper 来自 `shared/figure-style`。生成器在写出前检查文字不重叠、不越界、卡片不溢出。画布宽 1440px，按 6 英寸版心排印，最小字号 24px。图内无标题；墨灰表示结构，深蓝表示生成对象，朱红只标每图要读者看见的那一处。箭头表示构造、直接调用或沿准确等式的运输，框距没有数值含义。PDF 中的图由共用构建器经 Chrome 矢量打印，逐页显示检查记录见[验收记录](../release-validation.json)。
