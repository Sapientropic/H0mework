# 本地阅读版与形式化来源

## 阅读与可编辑材料

中英文阅读版位于 `build/cold-read-20261015/`：`one-bit.pdf`、`one-bit-en.pdf`，各含正文与附录 A–E。实际文件与校验身份由[成品清单](release-artifacts.json)登记；同目录的可编辑 ZIP 保存双语正文、八份矢量图及预览、图件生成器、书目、元数据、OB 选集、本稿检查脚本与共用构建入口。

从 publish 根目录复现本稿：

```sh
python3 shared/scripts/build_pdf.py \
  papers/one-bit/manuscript.md \
  papers/one-bit/manuscript-en.md \
  --output-dir papers/one-bit/build/cold-read-20261015
```

图件与可编辑包：

```sh
python3 papers/one-bit/figures/render.py
python3 papers/one-bit/figures/render.py --english
python3 papers/one-bit/scripts/package_release.py --output-dir papers/one-bit/build/cold-read-20261015
```

需要 Python 3、Pandoc 3、XeLaTeX、xeCJK／unicode-math、Google Chrome、Noto Serif/Sans CJK SC，图件另需 CairoSVG 与 fontTools。两份正文是共用构建器的显式目标，`--all` 的原六稿范围不变。

书面位置、原声明与公开包的对应可以在本机直接核对：

```sh
python3 papers/one-bit/scripts/check_release.py --homework /path/to/Homework
```

它比较双语锚点、公式标签、图件与引文，读取每条 OB 所列固定源文件，核对 SHA-256 与声明确在该文件中定义；不构建 Lean。

## 固定研究来源

OB1–OB11 的逐项来源、书面位置、原声明及公开目标见 [release-selection.json](release-selection.json)。Homework 来源保持各自 epoch：Y＝`b81a443863f4d7135ebaca92c5bb7d208ccc18ca`，H＝`e60a86058abcb74b7f2225f2383c182be8343785`，F＝`cde4b910929d9bc57554aa56f6ade116bc3b8675`，MV4＝`ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`。从拥有原源仓的本地副本读取：

```sh
git -C /path/to/Homework show SOURCE_COMMIT:SOURCE_PATH
```

## H0 证明包

本稿的形式材料由 H0mework `6bff9d4046b3f89004678244482b1c403837150c` 统一定位，实际材料提交 `c40ef754ccbbea96f8c1417f12348e840da5eb82`。固定提交的[一比特映射](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-map.json)、[准备状态](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-readiness.md)与[复现入口](https://github.com/Sapientropic/H0mework/blob/6bff9d4046b3f89004678244482b1c403837150c/docs/one-bit-reproduction.md)维护 OB1–OB11 的原声明、历史环境与验收。在该提交根目录：

```sh
make check-one-bit-entry
make bootstrap
make check-one-bit-full
```

入口核对五个已签原包（整账法 Y／MV4，首发核心 H，物理 H／F）的完整源码与 import 摘要、原具名审查根及选中资源，并从公开模块精确恢复选定源码。完整命令只对新增的 OB2 原 ghost control（`H0mework.Checks.OneBit.ZeroLawRootAdmissionRegression`，原 Y 源 SHA-256 `59132da0687ab67b235ac4fdffb9fe585ed02c104787571ee5f1d0928f2aaf06`）及其直接消费的准入声明执行最小闭包构建、完整 metadata trust 与完整类型核验；原包按同一源码范围复用原验收。原 ghost 源码及全部依赖的原路径恢复：

```sh
python3 tools/one_bit.py source --output .local/one-bit-original-view
```

复用的原包可在同一提交独立完整重建：OB3、OB5、OB8–OB10 用 `make check-whole-ledger-full`（WA1、WA6、WA9、WA11、WA38–WA40），OB6–OB7 用 `make check-first-release-full`（phys.P6、phys.P22）。两份原映射与 `4301fa8c5bb19bb1e8c3824d7c69be406264ed12` 时的字节相同。工具链固定为 Lean 4.33.0／Mathlib v4.33.0。
