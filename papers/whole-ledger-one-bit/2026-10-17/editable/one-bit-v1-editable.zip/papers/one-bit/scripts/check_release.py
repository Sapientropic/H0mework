#!/usr/bin/env python3
"""Check the One Bit paper's written locations, source bindings and bilingual parity.

Run from the publish root. Fixed research sources are read with `git show` from
the Homework clone given by --homework (default: ../../Homework next to this
workspace). Nothing is built; the report states exactly what was compared.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys

PAPER = Path(__file__).resolve().parents[1]
TEXTS = {'zh': PAPER / 'manuscript.md', 'en': PAPER / 'manuscript-en.md'}
META = re.compile(r'写作时|本轮|提示词|子代理|工作窗口|新窗口|agent|prompt|this draft|not rebuilt', re.I)
DECL = r'\b(?:theorem|def|lemma|abbrev|structure|inductive|instance|class)\s+(?:[\w.]*\.)?{}\b'


def anchors(text):
    return set(re.findall(r'<a id="([^"]+)"></a>', text))


def body(text):
    """Prose between the abstract and the code-availability block."""
    start = text.index('## 1')
    return text[start:text.index('<!-- code-availability:begin -->')]


def blob(homework, commit, path):
    return subprocess.run(['git', '-C', str(homework), 'show', f'{commit}:{path}'],
                          check=True, capture_output=True).stdout


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--homework', type=Path, default=PAPER.parents[3] / 'Homework')
    ap.add_argument('--h0', type=Path, default=PAPER.parents[3] / 'H0mework',
                    help='H0mework clone; its bound one-bit records are compared when present')
    args = ap.parse_args()
    texts = {k: p.read_text() for k, p in TEXTS.items()}
    errors, report = [], {}

    # bilingual parity of anchors, tags, figures and citations
    for name, rx in [('anchors', r'<a id="([^"]+)"></a>'), ('tags', r'\\tag\{([^}]+)\}'),
                     ('figures', r'\]\((figures/[^)]+?)(?:-en)?\.svg\)'), ('citations', r'\[\[(\d+)\]\]\(#ref-\d+\)')]:
        sets = {k: sorted(set(re.findall(rx, t))) for k, t in texts.items()}
        report[name] = len(sets['zh'])
        if sets['zh'] != sets['en']:
            errors.append(f'{name} differ: zh-only {set(sets["zh"]) - set(sets["en"])}, en-only {set(sets["en"]) - set(sets["zh"])}')
    for lang, t in texts.items():
        for fig in re.findall(r'\]\((figures/[^)]+\.svg)\)', t):
            if not (PAPER / fig).exists():
                errors.append(f'{lang}: missing figure {fig}')
            if (lang == 'en') != fig.endswith('-en.svg'):
                errors.append(f'{lang}: figure language mismatch {fig}')
        cited = set(re.findall(r'#ref-(\d+)', t))
        listed = set(re.findall(r'<a id="ref-(\d+)"></a>', t))
        if cited != listed:
            errors.append(f'{lang}: cited {sorted(cited)} vs listed {sorted(listed)}')
        for m in META.finditer(body(t)):
            errors.append(f'{lang}: meta wording "{m.group(0)}"')

    # written locations and source declarations of every claim
    selection = json.loads((PAPER / 'release-selection.json').read_text())
    checked_sources = 0
    for claim in selection['claims']:
        for lang, locs in claim['written'].items():
            for loc in locs:
                file, _, anchor = loc.partition('#')
                if anchor not in anchors((PAPER / file).read_text()):
                    errors.append(f'{claim["id"]}: missing anchor {loc}')
        for src in claim['sources']:
            data = blob(args.homework, src['commit'], src['path'])
            digest = hashlib.sha256(data).hexdigest()
            if 'sha256' in src and src['sha256'] != digest:
                errors.append(f'{claim["id"]}: sha mismatch {src["path"]}')
            text = data.decode()
            for decl in src['declarations']:
                if not re.search(DECL.format(re.escape(decl.split('.')[-1])), text):
                    errors.append(f'{claim["id"]}: declaration {decl} not declared in {src["path"]}')
            checked_sources += 1
    binding = selection['h0_binding']
    if args.h0.exists():
        for rec in binding['one_bit_records']:
            data = blob(args.h0, binding['one_bit_commit'], rec['path'])
            if hashlib.sha256(data).hexdigest() != rec['sha256']:
                errors.append(f'H0 record mismatch {rec["path"]}')
        report['h0_records_checked'] = len(binding['one_bit_records'])
    report['claims'] = len(selection['claims'])
    report['source_files_checked'] = checked_sources
    report['h0_bindings'] = sum(len(c['h0']) for c in selection['claims'])
    report['errors'] = errors
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(1 if errors else 0)


if __name__ == '__main__':
    main()
