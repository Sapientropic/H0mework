#!/usr/bin/env python3
"""Package the One Bit paper's editable inputs in the shared builder's layout."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[1]
OUTPUT = PAPER / 'build' / 'zenodo-20261017'
TEXTS = ('manuscript.md', 'manuscript-en.md')
SHARED = (
    'shared/scripts/build_pdf.py', 'shared/scripts/byline.py',
    'shared/styles/article-header.tex', 'shared/styles/article-header-en.tex',
    'shared/styles/article-filter.lua', 'shared/figure-style/house_style.py',
    'shared/figure-style/svg_text.py',
)


def package(output_dir: Path | None = None):
    target_dir = output_dir.resolve() if output_dir else OUTPUT
    build_path = target_dir.relative_to(ROOT).as_posix()
    inputs = {ROOT / p for p in SHARED}
    inputs.update(PAPER / p for p in (*TEXTS, 'references.bib', 'reproduction.md',
                                    'release-selection.json', 'metadata.json'))
    inputs.update((PAPER / 'scripts').glob('*.py'))
    for pattern in ('*.svg', '*.png', '*.py', 'README.md'):
        inputs.update((PAPER / 'figures').glob(pattern))
    payload, records = {}, []
    for path in sorted(inputs):
        data = path.read_bytes()
        if path.suffix in ('.md', '.json', '.svg') and b'/Users/' in data:
            raise ValueError(f'Personal path in publication input: {path.name}')
        rel = path.relative_to(ROOT).as_posix()
        payload[rel] = data
        records.append({'path': rel, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    selection = json.loads((PAPER / 'release-selection.json').read_text())
    binding = selection['h0_binding']
    metadata = json.loads((PAPER / 'metadata.json').read_text())
    guide = f"""# 1 Bit Is All You Need · editable v1

The bilingual manuscripts (each with Appendices A-E), eight editable vector
figures, PNG previews, the figure generator, bibliography, local metadata and
the OB1-OB11 selection keep the directory layout required by the shared builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome and Noto Serif/Sans CJK SC. Build both PDFs:

    python3 shared/scripts/build_pdf.py papers/one-bit/manuscript.md papers/one-bit/manuscript-en.md --output-dir {build_path}

With CairoSVG and fontTools installed, regenerate the figures:

    python3 papers/one-bit/figures/render.py
    python3 papers/one-bit/figures/render.py --english

All formal material is located through H0mework commit {binding['one_bit_commit']}
(material commit {binding['one_bit_material_commit']}) and its docs/one-bit-map.json.
In that repository run make check-one-bit-entry to check the five reused accepted
packages and the selected sources; after make bootstrap, make check-one-bit-full
builds, trusts and type-checks the new OB2 ghost control. The reused packages can
be rebuilt completely with make check-whole-ledger-full (OB3, OB5, OB8-OB10) and
make check-first-release-full (OB6-OB7). reproduction.md gives the full paper and
proof reproduction route.

The input manifest binds every copied file byte for byte. This editable package
accompanies the v1 preprint, DOI {metadata["doi"]}. Paper text and original figures
use CC BY 4.0; code uses Apache-2.0.
"""
    payload['README-editable.md'] = guide.encode()
    payload['editable-inputs.json'] = (json.dumps({
        'schema': 'one-bit-editable-inputs/v1', 'paper': 'one-bit', 'version': 'v1-local',
        'files': records, 'private_prompts_or_research_repositories_included': False,
    }, ensure_ascii=False, indent=2) + '\n').encode()
    target_dir.mkdir(parents=True, exist_ok=True)
    archive = target_dir / 'one-bit-v1-editable.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path, data in sorted(payload.items()):
            info = zipfile.ZipInfo(path, date_time=(*map(int, selection['date'].split('-')), 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(archive) as z:
        if set(z.namelist()) != set(payload) or z.testzip() is not None:
            raise ValueError('Archive contents or integrity mismatch')
        if any(z.read(path) != data for path, data in payload.items()):
            raise ValueError('Archive payload byte mismatch')
    return {'archive': archive.relative_to(ROOT).as_posix(),
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'bytes': archive.stat().st_size, 'file_count': len(payload),
            'payload_bytes_match': True, 'zip_integrity': 'pass', 'input_files': records}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, help='Directory for the packaged artifact')
    result = package(parser.parse_args().output_dir)
    print(json.dumps({k: v for k, v in result.items() if k != 'input_files'}, ensure_ascii=False))
