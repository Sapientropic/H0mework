# 本地阅读版与形式化来源

## 阅读与可编辑材料

当前四份 PDF 位于 `build/conditional-input-20261014/`：中英文正文、中英文证明补充。实际文件与校验身份由[成品清单](release-artifacts.json)登记；可编辑 ZIP 同目录保存正文、证明、原矢量图、书目、样式、图件生成器及本稿构建入口。首稿与冷读修订成品分别保存在 `build/first-release-20261013/`、`build/cold-read-20261013/`，按 Git `625e563`、`b54db87` 的清单解释；首次H0绑定版保在 `build/h0-bound-20261014/`，按 Git `6ff2358` 的清单解释。

从 publish 根目录复现本稿：

```sh
python3 shared/scripts/build_pdf.py \
  papers/whole-ledger-accounting/manuscript.md \
  papers/whole-ledger-accounting/manuscript-en.md \
  papers/whole-ledger-accounting/supplement.md \
  papers/whole-ledger-accounting/supplement-en.md \
  --output-dir papers/whole-ledger-accounting/build/conditional-input-20261014
```

构建后打包当前可编辑材料：

```sh
python3 papers/whole-ledger-accounting/scripts/package_release.py --output-dir papers/whole-ledger-accounting/build/conditional-input-20261014
```

需要 Python 3、Pandoc 3、XeLaTeX、xeCJK／unicode-math、Google Chrome 及 Noto Serif/Sans CJK SC。沿用项目管线；英文与补充为明确目标，`--all`保原六稿范围。图件复现：

```sh
python3 papers/whole-ledger-accounting/figures/render.py
python3 papers/whole-ledger-accounting/figures/render_continuation.py
python3 papers/whole-ledger-accounting/figures/render_continuation.py --english
```

图源使用CairoSVG／fontTools和随附字体测量 helper；PDF采用Chrome矢量打印，再以实际页面渲染复查。原四中文图保其现有字节，新续行图及五份英文图由新生成器维护。

## 固定研究来源与实际代码对应

WA1–WA40逐项来源及正文／证明位置在[release-selection.json](release-selection.json)。原Y、Y1、Z、AA、AB、AC、AD、AE、PR、MF、MV2、MV3分别保自己的commit；新上限为Homework `ba7e274beb1de38900a6fc2c8c8dfe6cfad9d9aa`。从拥有原源仓的本地副本按选择记录读取：

```sh
git -C /path/to/Homework show SOURCE_COMMIT:SOURCE_PATH
```

CP121及窗口CP217／219的原执行head未必已经包含新源路径；真实可恢复的tracked epoch、原verdict source SHA及固定引用三者分别登记。旧认证不改写为本次执行。

## H0代码包

WA1–WA40 的完整证明与复现包绑定 H0mework `4301fa8c5bb19bb1e8c3824d7c69be406264ed12`，实际材料提交为 `f607eb646d4e9cddba3512755365842895af44ca`。固定版本的[逐项映射](https://github.com/Sapientropic/H0mework/blob/4301fa8c5bb19bb1e8c3824d7c69be406264ed12/docs/whole-ledger-map.json)维护生产证明、原直接消费者、资源、完整类型及回执；[准备状态](https://github.com/Sapientropic/H0mework/blob/4301fa8c5bb19bb1e8c3824d7c69be406264ed12/docs/whole-ledger-readiness.md)签收完整验收。13 个历史包在独立 Lean 环境构建，准确 `H0mework.Papers.WholeLedgerAccountingR…` 入口逐包登记；WA38–WA40 使用 `H0mework.Papers.WholeLedgerAccountingRba7e274b`。第11.7节第三阶段付款实例使用 Y1，其他 Y 材料保原身份。

恢复该固定提交，在仓库根目录核查来源与资源：

```sh
make check-whole-ledger-entry
```

工具链由该提交的 `Lean/lean-toolchain`、`Lean/lake-manifest.json` 固定为 Lean 4.33.0／Mathlib v4.33.0。准备依赖并完成 kernel、metadata trust 与完整声明类型核查：

```sh
make bootstrap
make check-whole-ledger-full
```

完整命令生成独立 `.local/whole-ledger-runs/` 运行目录，构建采用 `--trust=0` 与 `warningAsError=true`。完整类型使用 `lean-expr-dag@1`，保全部 binder、宇宙层级及证明项，并在 Lean 中重建核对；原始控制文件的匿名例子由其完整 import 构建验收。分包与源码恢复命令见[固定复现指南](https://github.com/Sapientropic/H0mework/blob/4301fa8c5bb19bb1e8c3824d7c69be406264ed12/docs/whole-ledger-reproduction.md)。

实际已签回执、工作区缓存身份及写作端的固定字节／入口复核由[验收记录](release-validation.json)分别登记；原历史认证保自己的 epoch 与 SHA。当前所用170项写作源均对应准确原 epoch，并落在已签包的完整 import 闭包中。
