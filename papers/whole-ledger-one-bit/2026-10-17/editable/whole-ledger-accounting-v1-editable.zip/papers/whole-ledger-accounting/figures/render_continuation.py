#!/usr/bin/env python3
"""Render the continuation plate and translated plates from editable sources."""
import argparse
import re
from pathlib import Path

import render as r

EN = {
    '具体源的完整事件族': 'Complete source events',
    '原写入、转移、终账与边界事件': 'Writes, transfers, ends, boundaries',
    '事件属于哪次访问，也一并保留': 'The original visit is retained',
    '权威呈现的完整事件族': 'Complete presented events',
    '正反映射复合为恒等': 'Both round trips are identities',
    '不是从原事件族挑一个子集': 'The whole family is presented',
    '双向呈现': 'Round trips',
    '必须交换：结构分支 · 实际后继 · 整账写回 · 边界发生': 'Preserve branch, actual next, whole write, and boundary',
    '同一次原发生生成有限行，并固定完整余项的处理方式': 'One occurrence generates finite rows and the exact remainder',
    '原位余项': 'In-place remainder',
    '命中：使用准确生成行': 'Hit: exact generated row',
    '未命中：同一项原样携带': 'Miss: carry the same row',
    '未列出 ≠ 已删除': 'Unlisted ≠ deleted',
    '完整有限覆盖': 'Full finite cover',
    '每项都有准确行索引': 'Each entry: exact row index',
    '旧账与目标账均须全覆盖': 'Cover both whole ledgers',
    '有限清单不能冒充无限纤维': 'A finite list is not infinity',
    '运输余项': 'Transported remainder',
    '有限例外 + 原源余项事件': 'Finite exceptions + source event',
    '未命中：交给该生成事件': 'Miss: use that source event',
    '零条显式行也能处理整账': 'Zero explicit rows can suffice',
    '对每个旧项给出去向；对每个目标项给出来源': 'Every old row has a destination; every new row has an origin',
    '原行动源': 'Source action',
    '4 的最小因子为 2': 'Least factor of 4: 2',
    '编译器发出修复': 'Actual repair emitted',
    '不接收期望目标': 'Source fixes the target',
    '准确目标': 'Exact target',
    '目标分类：素数对': 'Read: a prime pair',
    '原行动债：{v:1 → 0}': 'Debt: {v:1 → 0}',
    '这一步真的严格降': 'An actual strict debit',
    '独立终账': 'Terminal receipt',
    '读取准确已付目标': 'Read this paid target',
    '原整账逐项终回执': 'Whole-ledger receipt',
    '不是零预算推出来': 'Its own source receipt',
    '原算术后继': 'Arithmetic next',
    '固定终账接续律': 'Fixed handoff law',
    '旧责任仍在原账': 'Old rows preserved',
    '行动债不再激活': 'This debt is inactive',
    '因子二修复': 'Factor-two repair',
    '原目标读取': 'Read the target',
    '固定接续': 'Fixed handoff',
    '最终结清仍要同时检查': 'Final settlement checks both',
    '原结清回执': 'Original terminal receipt',
    '绑定原事件、原整账和原责任': 'Bound to the event, ledger, and responsibility',
    '实际后继中无同债': 'No same debt in the actual next',
    '不能换一个没有债的世界来检查': 'The successor is fixed by the source',
    '原当前项 {i:x}': 'Original current {i:x}',
    '付款起点 {i:u}': 'Before payment {i:u}',
    '付款目标 {i:u}′': 'After payment {i:u}′',
    '宏步终点 {i:y}': 'Macro target {i:y}',
    '预算 {i:B}({i:x})': 'Budget {i:B}({i:x})',
    '预算 {i:B}({i:u})': 'Budget {i:B}({i:u})',
    '预算 {i:B}({i:u}′)': 'Budget {i:B}({i:u}′)',
    '预算 {i:B}({i:y})': 'Budget {i:B}({i:y})',
    '可改变载体与名称': 'Carrier may change',
    '前史已经实际发生': 'Actual finite history',
    '有严格付款事实': 'Actual strict payment',
    '后史已经实际发生': 'Actual finite history',
    '有限前史（非增）': 'Non-refilling history',
    '真实付款': 'Actual payment',
    '有限后史（非增）': 'Non-refilling history',
    '无须总闭合律，已经得到': 'Without a total closure law',
    '实际付款宏步关系良基': 'The actual paid macro relation is well founded',
    '同债不能付一圈又回原处': 'A paid debt cannot return to the same current',
    '零预算不能再发生严格付款': 'Zero budget excludes further strict payment',
    '不等于所有普通运动都会停止': 'Ordinary source evolution can continue',
    '另给逐当前的总发射律': 'Add a total emission law at each current',
    '每个当前：准确结清，或已完成付款宏步': 'Emit exact settlement or an actual paid macro',
    '只沿该律实际发射的宏目标递归': 'Recurse only at its actual emitted macro target',
    '生成有限历史；结清终点同时持有：': 'Finite history ends with both:',
    '原终回执 + 实际后继中无同债': 'Original receipt + no same debt in the actual next',
    '同一整体整数余核': 'One global integer cokernel',
    '全部有限阶段的复数化观察': 'All finite complexified observations',
    '同一输入': 'One input',
    '无法还原两个不同输出': 'cannot give two outputs',
    '原第一阶段整数消费者': 'Original stage-one integer reading',
    '原材料与未来模型': 'Material / future',
    'Raw · State · Trace': 'Raw · State · Trace',
    'owner · 全部词／站位': 'owner · all words/sites',
    '残差与已付边界同义': 'Equal evaluations',
    '下一原请求': 'Next original request',
    '原材料生成注册 AST': 'Source generates AST',
    '原首步已经执行': 'Actual first step',
    'credit = AST 费 − 1 > 0': 'credit = cost − 1 > 0',
    '同债实际付款': 'Same-debt payment',
    'paid · strict debit': 'paid · strict debit',
    'same debt · no refill': 'same debt · no refill',
    '零 effect 仍付语法费': 'Zero effect pays syntax',
    '完成事件': 'Completion event',
    'suffix · v = effect': 'suffix · v = effect',
    '回答与其原回执': 'Answer + own receipt',
    '因果 answer-and-next': 'Causal answer + next',
    '同一次完整账写入': 'One complete ledger write',
    '全部旧行 → 原 destination': 'Every old row → its exact destination',
    '出生行 → 同一个 whole destination': 'Born row → that same whole destination',
    '新责任有自己的来源与首步': 'New responsibility has its own source and first step',
    '实际规范后继': 'Actual canonical next',
    '完整 root 与 current': 'Full root and current',
    '已付材料与全部库存': 'Paid material and whole stock',
    '下一请求继续消费': 'The next request uses them',
    '原账保留每个发生位置；零值不能删除已付步骤': 'Every occurrence position survives; zero values erase no paid steps',
    '原残差自己入账、付款、回答并继续': 'The residual enters the ledger, pays, answers, and continues',
}


def continuation():
    h = r.start(790, '原残差自己入账、付款、回答并继续',
                '原材料生成下一请求，实际语法付款与后缀完成交付原回答和回执；同一整账写入保全部旧行和出生行并生成规范后继。')
    xs, width = [40, 390, 740, 1090], 310
    data = [
        ('原材料与未来模型', ['Raw · State · Trace', 'owner · 全部词／站位', '残差与已付边界同义']),
        ('下一原请求', ['原材料生成注册 AST', '原首步已经执行', 'credit = AST 费 − 1 > 0']),
        ('同债实际付款', ['paid · strict debit', 'same debt · no refill', '零 effect 仍付语法费']),
        ('完成事件', ['suffix · v = effect', '回答与其原回执', '因果 answer-and-next']),
    ]
    for i, (x, (title, rows)) in enumerate(zip(xs, data)):
        r.card(x, 38, width, 224, title, rows, r.VERMILION if i == 2 else r.HAIR)
        if i < 3:
            r.arrow(x + width + 6, 150, xs[i + 1] - 7, 150, accent=i == 1)
    r.arrow(1245, 277, 1245, 370)
    r.card(40, 391, 850, 214, '同一次完整账写入',
           ['全部旧行 → 原 destination', '出生行 → 同一个 whole destination', '新责任有自己的来源与首步'])
    r.card(975, 391, 425, 214, '实际规范后继',
           ['完整 root 与 current', '已付材料与全部库存', '下一请求继续消费'])
    r.arrow(903, 500, 961, 500)
    r.parts.append(f'<path d="M 1245 370 L 465 370 L 465 380" fill="none" stroke="{r.SLATE}" stroke-width="2.2" marker-end="url(#arrow-ink)"/>')
    r.rect(40, 676, 1360, 82, r.WASH, r.VERMILION, 2.4)
    r.txt(720, 728, '原账保留每个发生位置；零值不能删除已付步骤', 30, r.VERMILION, 600, 'middle')
    r.save('source-continuation', h)


def english():
    original_txt, original_start, original_save = r.txt, r.start, r.save

    def txt(x, y, text, *args, **kwargs):
        translated = EN.get(text, text)
        if re.search('[\u3400-\u9fff]', translated):
            raise ValueError(f'Untranslated label: {text}')
        return original_txt(x, y, translated, *args, **kwargs)

    def start(height, title, description):
        return original_start(height, EN.get(title, 'Whole-ledger accounting'),
                              'Source-indexed construction; arrows show generation or exact transport.')

    def save(name, height):
        return original_save(name + '-en', height)

    r.txt, r.start, r.save = txt, start, save
    r.inventory(); r.target_six(); r.settlement(); r.observation_separation(); continuation()


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--english', action='store_true')
    args = ap.parse_args()
    r.register_cjk_for_cairo()
    english() if args.english else continuation()
    print('Rendered editable continuation plate' + (' and four English plates.' if args.english else '.'))
