#!/usr/bin/env python3
"""Generate the paper's editable SVG diagrams and their PNG previews.

Series visual language (shared/figure-style): no in-figure headline, serif
type, ink/grey structure with deep blue for generated objects, and one
vermilion accent per figure on the object the reader is asked to see. The
canvas is 1440 px wide and prints at about 6 in, so no text is set below 24 px.
"""
from pathlib import Path
from html import escape
import sys

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parents[2] / 'shared' / 'figure-style'))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH  # noqa: E402
from svg_text import line, text_width, register_cjk_for_cairo  # noqa: E402

W = 1440
MIN_SIZE = W / 60
parts, boxes = [], []
shift = [0]  # vertical offset of an open <g> group, for the layout checks


def start(height, title, description):
    parts.clear(); boxes.clear()
    parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" viewBox="0 0 {W} {height}" role="img">')
    parts.extend([f'<title>{escape(title)}</title>', f'<desc>{escape(description)}</desc>'])
    parts.append('<defs>' + ''.join(
        f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
        f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>' for n, c in [('ink', SLATE), ('acc', VERMILION)]) + '</defs>')
    parts.append(f'<rect width="{W}" height="{height}" fill="#FFFFFF"/>')
    return height


def txt(x, y, text, size=26, color=INK, weight=400, anchor='start'):
    assert size >= MIN_SIZE - 1e-9, (text, size)
    width = text_width(text, size, MIN_SIZE)
    x0 = x - {'start': 0, 'middle': width / 2, 'end': width}[anchor]
    y_page = y + shift[0]
    boxes.append((x0, y_page - .82 * size, x0 + width, y_page + .22 * size, text))
    parts.append(line(x, y, text, size, color, weight, anchor, min_size=MIN_SIZE))


def rect(x, y, w, h, fill='none', stroke=HAIR, width=1.6, radius=6):
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')


def arrow(x1, y1, x2, y2, accent=False, width=2.2):
    c, m = (VERMILION, 'acc') if accent else (SLATE, 'ink')
    parts.append(f'<path d="M {x1} {y1} L {x2} {y2}" fill="none" stroke="{c}" stroke-width="{width}" marker-end="url(#arrow-{m})"/>')


def card(x, y, w, h, title, lines, stroke=HAIR, fill='none', gap=40):
    rect(x, y, w, h, fill, stroke, 2.4 if stroke == VERMILION else 1.6)
    txt(x + 26, y + 46, title, 28, INK, 600)
    for i, row in enumerate(lines):
        txt(x + 26, y + 92 + i * gap, row, 26, INK if isinstance(row, str) and '{v:' in row else SLATE)
    for (x0, _, x1, _, t) in boxes[-len(lines) - 1:]:
        assert x1 <= x + w - 10, ('card overflow', t, x1, x + w)


def save(name, height):
    for i, a in enumerate(boxes):
        assert a[0] >= 8 and a[2] <= W - 8 and a[1] >= 4 and a[3] <= height - 4, ('outside canvas', a)
        for b in boxes[i + 1:]:
            if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                raise AssertionError(('text overlap', a[4], b[4]))
    svg = '\n'.join(parts + ['</svg>'])
    (OUT / f'{name}.svg').write_text(svg, encoding='utf-8')
    import cairosvg
    cairosvg.svg2png(bytestring=svg.encode(), write_to=str(OUT / f'{name}.png'))


def inventory():
    """Accent: the closing requirement that the finite patch still answers the whole ledger."""
    H = start(740, '完整事件库存与本拍处理片段',
              '上层：具体源与权威呈现的完整事件族双向呈现。下层：同一次原发生生成有限行，三种余项处理方式都对整账逐项给出去向与来源。')
    card(40, 30, 540, 170, '具体源的完整事件族', ['原写入、转移、终账与边界事件', '事件属于哪次访问，也一并保留'])
    card(860, 30, 540, 170, '权威呈现的完整事件族', ['正反映射复合为恒等', '不是从原事件族挑一个子集'])
    arrow(600, 118, 840, 118); arrow(840, 150, 600, 150)
    txt(720, 92, '双向呈现', 26, SLATE, anchor='middle')
    txt(720, 250, '必须交换：结构分支 · 实际后继 · 整账写回 · 边界发生', 26, INK, anchor='middle')
    parts.append(f'<path d="M 40 290 L 1400 290" stroke="{HAIR}" stroke-width="1.2"/>')
    txt(40, 342, '同一次原发生生成有限行，并固定完整余项的处理方式', 28, INK, 600)
    for x, title, rows in [
        (40, '原位余项', ['命中：使用准确生成行', '未命中：同一项原样携带', '未列出 ≠ 已删除']),
        (500, '完整有限覆盖', ['每项都有准确行索引', '旧账与目标账均须全覆盖', '有限清单不能冒充无限纤维']),
        (960, '运输余项', ['有限例外 + 原源余项事件', '未命中：交给该生成事件', '零条显式行也能处理整账'])]:
        card(x, 372, 440, 212, title, rows)
        arrow(x + 220, 594, x + 220, 628)
    rect(40, 640, 1360, 84, WASH, VERMILION, 2.4)
    txt(720, 694, '对每个旧项给出去向；对每个目标项给出来源', 30, VERMILION, 600, 'middle')
    save('whole-inventory', H)


def target_six():
    """Accent: the exact target where the action debt is actually paid, 1 -> 0."""
    H = start(530, '原目标六：行动、付款、终账与实际后继',
              '原因子二修复使2+4变为3+3，付款1到0；独立终账与原算术后继无同债共同结清。')
    xs, w = [40, 397, 754, 1111], 289
    cards = [('原行动源', ['2 + 4 = 6', '4 的最小因子为 2', '编译器发出修复', '不接收期望目标']),
             ('准确目标', ['3 + 3 = 6', '目标分类：素数对', '原行动债：{v:1 → 0}', '这一步真的严格降']),
             ('独立终账', ['读取准确已付目标', '原整账逐项终回执', '不是零预算推出来']),
             ('原算术后继', ['固定终账接续律', '旧责任仍在原账', '行动债不再激活'])]
    for i, (x, (title, rows)) in enumerate(zip(xs, cards)):
        card(x, 70, w, 250, title, rows, VERMILION if i == 1 else HAIR)
    for i, label in enumerate(['因子二修复', '原目标读取', '固定接续']):
        gx = xs[i] + w
        arrow(gx + 8, 195, gx + 60, 195, accent=(i == 0))
        txt(gx + 34, 44, label, 24, VERMILION if i == 0 else SLATE, anchor='middle')
    txt(40, 382, '最终结清仍要同时检查', 28, INK, 600)
    rect(40, 410, 600, 100, WASH, HAIR)
    txt(340, 453, '原结清回执', 28, INK, 600, 'middle')
    txt(340, 490, '绑定原事件、原整账和原责任', 25, SLATE, anchor='middle')
    txt(720, 472, '+', 40, INK, 400, 'middle')
    rect(800, 410, 600, 100, WASH, HAIR)
    txt(1100, 453, '实际后继中无同债', 28, INK, 600, 'middle')
    txt(1100, 490, '不能换一个没有债的世界来检查', 25, SLATE, anchor='middle')
    save('target-six', H)


def settlement():
    """Accent: the one real payment and the strict inequality it produces."""
    H = start(640, '同债迁移、真实付款与双条件结清',
              '固定谱系和主张；有限迁移前后夹一次实际严格付款，关系良基无需总律；生成有限结清历史另用总发射律。')
    xs, w = [40, 397, 754, 1111], 289
    for i, (x, label, rows) in enumerate(zip(xs, ['原当前项 {i:x}', '付款起点 {i:u}', '付款目标 {i:u}′', '宏步终点 {i:y}'],
                                         [['预算 {i:B}({i:x})', '可改变载体与名称'], ['预算 {i:B}({i:u})', '前史已经实际发生'],
                                          ['预算 {i:B}({i:u}′)', '有严格付款事实'], ['预算 {i:B}({i:y})', '后史已经实际发生']])):
        card(x, 70, w, 170, label, rows, VERMILION if i == 2 else HAIR)
    for i, label in enumerate(['有限前史（非增）', '真实付款', '有限后史（非增）']):
        gx = xs[i] + w
        arrow(gx + 8, 155, gx + 60, 155, accent=(i == 1))
        txt(gx + 34, 44, label, 24, VERMILION if i == 1 else SLATE, anchor='middle')
    txt(720, 306, '{i:B}({i:y}) ≤ {i:B}({i:u}′) {v:<} {i:B}({i:u}) ≤ {i:B}({i:x})', 40, INK, anchor='middle')
    card(40, 350, 640, 250, '无须总闭合律，已经得到',
         ['实际付款宏步关系良基', '同债不能付一圈又回原处', '零预算不能再发生严格付款', '不等于所有普通运动都会停止'])
    card(720, 350, 680, 250, '另给逐当前的总发射律',
         ['每个当前：准确结清，或已完成付款宏步', '只沿该律实际发射的宏目标递归', '生成有限历史；结清终点同时持有：', '原终回执 + 实际后继中无同债'])
    save('debt-settlement', H)


def observation_separation():
    """Accent: the nonzero class z, tracked from G through the integer reading J."""
    H = start(705, '同一整数类的两路读出',
              '同一个源生成的非零整数类z与零类：F把它们送到完全相同的有限阶段复观察零族，J分别读出非零z1与零。因此不存在J经F的任意函数分解。')

    def path(d, color=SLATE, dash=False, head=True, width=2.4):
        attrs = ' stroke-dasharray="9 7"' if dash else ''
        marker = ' marker-end="url(#arrow-ink)"' if head else ''
        parts.append(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{attrs}{marker}/>')

    def point(x, y, filled, color):
        parts.append(f'<circle cx="{x}" cy="{y}" r="13" fill="{color if filled else "white"}" stroke="{color}" stroke-width="3"/>')

    shift[0] = -95
    parts.append(f'<g transform="translate(0,{shift[0]})">')
    parts.append(f'<ellipse cx="220" cy="380" rx="160" ry="180" fill="{WASH}" stroke="{HAIR}" stroke-width="1.6"/>')
    txt(220, 172, '{i:G}', 40, INK, anchor='middle')
    point(220, 300, True, VERMILION); txt(220, 356, '{i:z} ≠ 0', 34, VERMILION, anchor='middle')
    point(220, 450, False, SLATE); txt(220, 506, '0', 34, SLATE, anchor='middle')
    txt(220, 600, '同一整体整数余核', 26, INK, anchor='middle')
    path('M 385 380 L 460 380', head=False)
    parts.append(f'<circle cx="460" cy="380" r="4" fill="{SLATE}"/>')
    path('M 460 380 C 525 250 610 240 712 240', DEEP)
    path('M 460 380 C 520 560 610 590 712 590', SLATE)
    txt(440, 206, '{i:F}({i:g}) = (1 ⊗ π{isub:n}({i:g})){isub:n}', 32, DEEP)
    txt(500, 660, '{i:J}({i:g}) = π{sub:1}({i:g})', 32, SLATE)
    txt(1050, 150, '全部有限阶段的复数化观察', 26, DEEP, 600, 'middle')
    for x, n in [(790, '0'), (890, '1'), (990, '2'), (1190, '{i:n}')]:
        txt(x, 198, n, 25, MUTE, anchor='middle')
        txt(x, 258, '0', 42, DEEP, anchor='middle')
    txt(1090, 258, '…', 38, DEEP, anchor='middle'); txt(1290, 258, '…', 38, DEEP, anchor='middle')
    path('M 752 213 L 740 213 L 740 273 L 752 273', DEEP, head=False)
    path('M 1333 213 L 1345 213 L 1345 273 L 1333 273', DEEP, head=False)
    txt(1045, 335, '{i:F}({i:z}) = {i:F}(0) = (0, 0, 0, …)', 32, DEEP, anchor='middle')
    path('M 1045 360 L 1045 470', SLATE, dash=True)
    path('M 1028 398 L 1062 432 M 1062 398 L 1028 432', INK, head=False, width=3.2)
    txt(1090, 408, '同一输入', 24, SLATE)
    txt(1090, 442, '无法还原两个不同输出', 24, INK)
    txt(1045, 530, '原第一阶段整数消费者', 26, INK, 600, 'middle')
    point(880, 590, True, VERMILION)
    txt(880, 650, '{i:J}({i:z}) = {i:z}{sub:1} ≠ 0', 32, VERMILION, anchor='middle')
    txt(1045, 600, '≠', 36, INK, anchor='middle')
    point(1210, 590, False, SLATE)
    txt(1210, 650, '{i:J}(0) = 0', 32, SLATE, anchor='middle')
    parts.append(f'<path d="M 40 700 L 1400 700" stroke="{HAIR}" stroke-width="1.2"/>')
    txt(720, 760, '{i:F}({i:z}) = {i:F}(0),   {i:J}({i:z}) ≠ {i:J}(0)   ⇒   ∄ {i:h} : {i:J} = {i:h} ∘ {i:F}', 34, INK, anchor='middle')
    parts.append('</g>'); shift[0] = 0
    save('observation-separation', H)


if __name__ == '__main__':
    register_cjk_for_cairo()
    inventory(); target_six(); settlement(); observation_separation()
    print('Rendered 4 editable SVG diagrams and 4 PNG previews.')
