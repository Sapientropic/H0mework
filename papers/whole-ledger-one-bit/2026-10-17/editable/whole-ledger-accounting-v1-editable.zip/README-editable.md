# Source-Native Whole-Ledger Accounting · editable v1

The bilingual manuscripts and proof supplements, ten editable vector figures,
PNG previews, figure generators, bibliography, local metadata and WA1–WA40
selection retain the directory layout required by the shared builder.

Run from this extracted root with Python 3, Pandoc 3, XeLaTeX, xeCJK,
unicode-math, Google Chrome and Noto Serif/Sans CJK SC. The current local build
uses macOS Chrome and fonts in Library/Fonts. Build all four reading PDFs:

    python3 shared/scripts/build_pdf.py papers/whole-ledger-accounting/manuscript.md papers/whole-ledger-accounting/manuscript-en.md papers/whole-ledger-accounting/supplement.md papers/whole-ledger-accounting/supplement-en.md --output-dir papers/whole-ledger-accounting/build/zenodo-20261017

With CairoSVG and fontTools installed, regenerate the figures:

    python3 papers/whole-ledger-accounting/figures/render.py
    python3 papers/whole-ledger-accounting/figures/render_continuation.py
    python3 papers/whole-ledger-accounting/figures/render_continuation.py --english

The complete WA1–WA40 proof and reproduction selection is bound to H0mework
commit 4301fa8c5bb19bb1e8c3824d7c69be406264ed12, with the accepted material commit f607eb646d4e9cddba3512755365842895af44ca.
Its per-claim map, thirteen separate historical Lean environments and acceptance
receipts are available from https://github.com/Sapientropic/H0mework/tree/4301fa8c5bb19bb1e8c3824d7c69be406264ed12.
The included reproduction.md specifies both paper and proof reproduction.
In that fixed proof repository, run make check-whole-ledger-entry; prepare fixed
dependencies with make bootstrap, then run make check-whole-ledger-full.
The selection retains original epochs, source and target identities, exact
written-proof locations, and each claim's accepted package entries.

The input manifest binds every copied file byte for byte. This editable package
accompanies the v1 preprint, DOI 10.5281/zenodo.23437454. Paper text and original figures
use CC BY 4.0; code uses Apache-2.0.
