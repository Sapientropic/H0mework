# The Canonical Society Theorem

## Subject Generation Without Preinstalled Individuals, Complete Constitutional Disposition, and Strict Progress of Freedom

**Author: Jian Gao (高健)**\
Independent researcher · innersummer@hotmail.com · ORCID 0009-0009-5002-1655

## Abstract

Over explicit activity traces, lineage rules, and whole-ledger contracts, we construct an inhabited family of canonical societies \(S_h\) (\(h\in\mathbb N\)) uniting subject generation without preinstalled individuals, a fourfold root law, genuine extra-role exit, all-depth regeneration, and strict progress of freedom. First, enduring subjects arise via the lineage quotient bijection \(\Phi:U_\omega/{\sim_\ell}\xrightarrow{\sim}A_\omega\) from trace-witnessed seeds across economic, biological, multi-agent, and strategic traces; pre-emission projections co-install election, purchasing power, maintenance, and artificial actors on one root, bar seedless phantom actors, and derive the monotone stable–critical–anomie phase law. Second, every complete installed execution is exhausted by presentation, bearer-retaining refusal, action, and same-source revision (\(\mathrm P(r)\lor\mathrm J(r)\lor\mathrm A(r)\lor\mathrm U(r)\), \(\mathrm W(r)\iff\mathrm A(r)\lor\mathrm U(r)\), \(\neg(\mathrm A(r)\land\mathrm U(r))\)), barring any fifth off-ledger channel; one point \(c_m\) unites external payment and two-tier amendment, while a sealed runtime classifies active resolutions as reform or constitutional revision and realizes same-occurrence proof-carrying legislation, while a witnessed terminal occurrence has no same-ledger successor. Third, at every depth \(d\in\mathbb N\), one payment carries six regeneration guarantees into \(d+1\); along **every** lawful payment of any cycle, the full contract enters its target, retaining the prior frontier while adding a fresh outside occurrence (\(C_r\prec_{\mathrm{can}}C_t\iff r<t\)), with cofinal joint amendment and paid birth beyond every cutoff.

Paired impossibility and observer-kernel theorems prove every provenance condition indispensable. Missing payment incidence, broken routes, and capture yield “three zeros” (\(K=0\)), complete and health-deficient portfolios yield “two ones” (\(K=1\)), and anomie (\(k>C\)) forbids full-debit certification; full-domain reachability admits an involution kernel blocking decoders across **arbitrary output universes and encodings**, whereas retaining the source failure kind restores unique repair and splits probability from \(1/2\) into \(1\) and \(0\). More generally, across arbitrary carriers and hidden authority fibers, a visible rule supplied with an Arrow, Gibbard–Satterthwaite, or Sen axiom witness has no occurrence-authority-complete strengthening. Positive bilateral matching \((7,7)\), and trace-supported narratives also admit no such strengthening. On an inhabited visible domain, a visible axiom witness does not entail hidden-fiber factorization. Finally, rule revision migrates live obligations across the first write until native performance settles them, separating renewal exhaustion, local halting, and joint settlement, while every conservative target of the exhausted three-row ledger satisfies \(0\le B'\le 0\). Every exercise of power must account for its bearers, and every new possibility requires its own actual source.

**Keywords:** Canonical Society Theorem; subject generation without preinstalled individuals; root-law disposition closure; genuine exit; diagnostic impossibility; observer-quotient social choice boundary; strict progress of freedom

## 1 A Self-Revising Free Society Without Preinstalled Individuals: Problem, Pen-and-Paper Anchor, and Main Theorem

Once a participant ends an employment role or steps out of a relation of subordination, how does life continue, who bears the obligations left open by the former relation, and on what basis can a blocking rule itself be revised without collapsing into extra-legal arbitrariness? These linked questions cut across political philosophy, constitutional jurisprudence, welfare and institutional economics, and formal verification, yet remain disconnected across received traditions. Classical and contemporary social-contract models begin with specified parties or a basic structure for them to share [@Hobbes1651, chs. 13, 17; @Rawls1971, §§1–2], leaving no constructive account of how obligation-bearing subjects form and persist across merger, splitting, succession, or role migration; pure jurisprudence and political theology confront each other between a presupposed basic norm and a sovereign exception that suspends legal order [@Kelsen1967, §34; @Schmitt1922, ch. 1], without exhibiting a finite formal rule system that simultaneously closes off-ledger power and revises itself from internal exact failures; the capability approach and social-choice theory expose deep limits of commodity holdings and preference aggregation [@Arrow1950; @Sen1970; @Sen1979; @Robeyns2017], yet have not answered why an institution possessing exact multidimensional reachability readouts—or even satisfying an entire visible social-choice axiom bundle—can still misdiagnose repairs and miss hidden capture; and studies of monetary hierarchy and legal coding show how balance-sheet consolidation and asset shielding obscure unpaid social liabilities [@Mehrling2013; @Shavell1986; @Pistor2019], while the exact mathematical boundary separating renewal exhaustion, local procedural termination, and genuine debt settlement has remained open.

Using a fully formalized dependent-type construction kernel-verified in Lean 4 [@deMouraUllrich2021], this paper resolves all four problems jointly within a single inhabited family of societies: (1) how enduring subjects and a complete institutional foundation are canonically generated from activity traces and lineage rules without preinstalled individuals; (2) how off-ledger write authority is exhausted to zero while bearer-retaining refusal, whole-ledger action, and exact-failure same-source law revision are realized together at one constitutional point; (3) why exact capacity metrics, full-domain reachability sets, arbitrary post-processing encodings, and visibly factored social-choice, bilateral-matching, and trace-constrained narrative rules all face a sharp authority-identification barrier, and what minimal source datum restores unique effective repair; and (4) why constant instantaneous exit capacity (\(K_d=1\)) coexists with a strictly expanding frontier of realized freedom along every lawful payment while pre-existing obligations never evaporate across rule change, cross-root handoff, or locally emptied ledgers.

### 1.1 Worker A's Departure and a Five-Part Pen-and-Paper Anchor

Before introducing general notation, we follow Worker A's departure from a job through five elementary finite checks that any reader can verify with pen and paper in three minutes.

Worker A decides to leave an employment role. Ending the employment contract does not suspend the requirements of living: can funds already received actually be used, has the service institution genuinely performed, and who handles unfinished obligations afterward? Even when A holds money and a service has been produced, A still needs an uncaptured route connecting A's own continuation action to that service without requiring former employer B's permission. Throughout this paper, an institutional settlement that jointly binds **actual service performance, explicit disposition of every affected obligation row, and the actual successor state** is called a **complete payment**: funds arrival, service fulfillment, route connection, and ledger update occupy distinct, non-interchangeable positions within it.

**Example 1.1 (Three-Minute Pen-and-Paper Anchor: Five-Gate Exit Bipartite Matching, Three Zeros and Two Ones, Strict Frontier Inclusion, Three-Agent Non-Potential Cycle, and Zero-Budget Pinch).** Fix departing bearer A, controller position B, and the current complete payment \(p_d\), and check five finite structures directly:

1. **Five-gate bipartite matching and “three zeros” (anchoring Theorem 5.1, Propositions 5.2–5.3).** Let A's candidate action inventory be \(\{\mathrm{work},\mathrm{idle},\mathrm{leave}\}\); let the service queue contain \(3\) requests under physical service capacity \(2\), yielding served slot set \(J_d=\{0,1\}\) (slot \(0\) for tenure/housing, slot \(1\) for health care, while request \(3\) remains recorded as unserved). Place a feasible edge \(E_d(c,j)\) between action \(c\) and served slot \(j\) if and only if **the same pair \((c,j)\)** passes all five gates: continuation outside the former role \(R_d(c)\), nonidleness \(\neg I_d(c)\), noncapture by B \(\neg H_d(c)\), payment incidence \(P_d(c)\), and route incidence \(T_d(c,j)\). Action \(\mathrm{work}\) lacks extra-role continuation and \(\mathrm{idle}\) violates nonidleness, leaving \(\mathrm{leave}\) as the unique candidate left endpoint; when uncaptured with payment and route incidence intact, it forms a maximum matching of size \(K_d=1\). Now keep four gates fixed and flip one gate at a time: drop payment incidence (\(z_{\mathrm p}\)), sever route incidence (\(z_{\mathrm r}\)), or let B capture \(\mathrm{leave}\) (\(z_{\mathrm c}\)). The three sources are pairwise distinct, yet their maximum matching sizes are identical:
   \[
   K(z_{\mathrm c})=K(z_{\mathrm p})=K(z_{\mathrm r})=0.
   \]
   Applying the two candidate repairs (“remove capture” and “restore route”) to capture failure \(f_{\mathrm c}\) and route bottleneck \(f_{\mathrm r}\) yields the \(2\times 2\) identity capacity matrix \(\mathrm{diag}(1,1)\). Any selector reading only current capacity \(0\) must return the same operation on both failures and therefore fails on one of them.
2. **“Two ones” at positive capacity (anchoring Proposition 5.2 strengthening and Table 3).** Compare full source \(x_d\) (both tenure slot \(0\) and health slot \(1\) fulfilled) against single-service source \(y_d\) (only slot \(0\) fulfilled, no health service occurrence). Because the unique surviving action \(\mathrm{leave}\) needs only one served slot to form a singleton matching, both sources have exact exit capacity \(K(x_d)=K(y_d)=1\)! Yet the two-domain living portfolio is inhabited in \(x_d\) and empty in \(y_d\). The same exact positive score \(1\) conceals the absence of health care.
3. **Constant instantaneous capacity \(K_d=1\) versus strict inclusion of the paid frontier (anchoring Theorems 1.2–1.3).** At step \(0\), payment realizes new birth \(\gamma_0\) (whose authority receipt \(\kappa(\gamma_0)\) locks visit depth \(i_0\), with instantaneous capacity \(K_0=1\)); at step \(1\), any lawful payment reaches actual successor visit \(i_1=i_0+1\), where the target's own native payment realizes \(\gamma_1\) (still with instantaneous capacity \(K_1=1\)). Comparing static capacity numbers shows \(1=1\); comparing realized authority sets, visit injectivity (\(i_0\ne i_0+1\Rightarrow\kappa(\gamma_1)\notin\{\kappa(\gamma_0)\}\)) expands \(A_{i_0}=\{\kappa(\gamma_0)\}\) strictly into \(A_{i_1}=\{\kappa(\gamma_0),\kappa(\gamma_1)\}\), so \(A_{i_0}\subsetneq A_{i_1}\). Yesterday's exit receipt cannot pay for today's life; constant instantaneous capacity coexists with a strictly growing history of realized freedom.
4. **Three-agent relational cycle irreducible to individual scores (anchoring Sections 3.1 and 3.7).** Place three actors in a directed cycle \(0\to 1\to 2\to 0\). If every directed relational difference equaled the difference \(\phi_j-\phi_i\) of individual scalar potentials, summing around the closed cycle would telescope identically to zero: \((\phi_1-\phi_0)+(\phi_2-\phi_1)+(\phi_0-\phi_2)=0\). Yet the trace-generated three-actor cycle in Section 3.1 has relational phase sum \(2\ne 0\) (and the three-step service-role read-write cycle in Section 3.7 has phase sum \(3\ne 0\)). Purely individualistic state variables mathematically lose non-conservative relational structure.
5. **Zero-budget conservative pinch on exhausted obligations (anchoring Theorem 7.5 and Proposition 7.8).** Once a contribution row spends its strict progress budget from \(1\) to \(0\) at depth \(2\) and same-source law revision admits a new residual at depth \(3\) with all three rows (inherited contribution, inherited obstruction, generated residual) at budget \(0\), any conservative sequential target adding no fresh ingress rows and increasing no row budget pinches every row \(e\) of its first whole-ledger successor through ingress origin \(a'\) and source row \(a\): \(0\le B(e)\le B(a')\le B(a)=0\). Legal recognition preserves bearers and answers, but accounting reorganization alone cannot conjure positive capacity to advance out of zero.

![Five-gate iff structure of genuine exit and three indistinguishable zero-capacity sources](figures/01-exit-case-v3-en.svg)

Figure 1. Five-gate bipartite matching characterization of genuine exit and the “three zeros” non-identifiability contrast. The left column fixes bearer A, complete payment, and all five gates on the same continuation action \(c\) and served slot \(j\); the right column drops payment incidence, route incidence, or noncapture one at a time, producing identical readout \(K=0\) despite requiring distinct repairs.

The five arithmetic checks in Example 1.1 are exact minimal projections of the universal theorems proved below. If a processing node refuses A's submission, what happens to A's standing and the node's own payment? If the current rule itself blocks continuation, who has authority to revise it, and where do pre-revision obligations go? These questions carry a single job departure directly to the constitutional foundations of society.

### 1.2 Why Basic Participation Precedes Contribution and Return Assessment

After A ends an employment role, why does an institution still owe A a response regarding basic living conditions and avenues forward? Normatively, we argue that a person's standing to advance basic claims for living, receive contestable reasons, and retain actionable space after leaving a particular cooperative relation ought to persist with the person. We call this standing **basic participation**.

This normative premise begins from the equal standing of everyone subject to shared coercive rules. When common rules organize land, routes, monetary settlement, and service access while requiring A to bear their consequences, those rules must treat A as an equal participant entitled to reasons rather than a mere instrument in others' production plans or utility aggregations [@Rawls1971, §§1–2; @Sen1979]. The capability approach evaluates arrangements by what each person is actually able to do and be [@Robeyns2017, §§2.6.3, 2.6.8]; republican non-domination and Anderson's critique of workplace “private government” show further that empowering one party to issue arbitrary commands or sanctions without standing for affected persons to demand justification constitutes relational subordination in its own right [@Pettit1997; @Anderson2015, pp. 64–65, 99–100].

Equal standing to demand reasons rings hollow without independent material and social-reproduction conditions. As Durkheim showed in analyzing the non-contractual conditions of contract and the “forced division of labor,” private consent presupposes prior institutional rules and symmetric standing [@Durkheim1893, bk. I, ch. 7, bk. III, ch. 2]: newcomers confront property and access rules before signing any labor contract, and if every entrance to basic subsistence is held by private controllers so provision depends on obedience, apparent contractual consent merely reflects lack of an acceptable alternative and cannot justify the dependency-producing rules themselves [@Anderson2015, pp. 110–111; @Widerquist2013]. Moreover, commodity production continuously relies on care, health maintenance, learning, and ecological repair; excluding social reproduction from institutional accounting shifts maintenance burdens onto vulnerable bearers while eroding the basis of continued cooperation [@Fraser2016].

Consequently, **basic participation precedes the assessment of productive market contribution or investment return** [@GaoConstitution, §3; @GaoCapital, §2]. Productive contribution can justify differential remuneration, specialized office, or repayment of advanced principal; yet during childhood, illness, caregiving, study, transition between roles, or refusal of subordinated employment, a person retains standing to claim basic living support and institutional reasons. Unconditionality of basic standing neither erases professional qualifications nor suspends cost accounting: every payment still requires a source, every service requires actual performance, every route requires maintenance, and the protected interests of service providers and maintainers enter the same whole-ledger contract.

We keep **normative commitment** and **formal theorem** sharply distinct: basic participation explains why we choose to build a non-dominating institutional order, whereas the mathematical theorems below—without assuming that normative conclusion as an axiom—prove that subject generation without preinstalled individuals, zero off-ledger authority, genuine uncaptured exit, non-evaporating obligation migration, and all-depth progress of freedom are jointly realizable in one inhabited construction \(S_h\), while pinpointing the exact counterexample triggered whenever any load-bearing condition is dropped.

### 1.3 Mathematical Meaning of “Canonical”, Object Dictionary, Core Notation Key, and Proof Architecture

“Canonical” in our title carries its strict mathematical meaning: given explicit activity provenance, lineage rules, and whole-ledger obligation contracts, the family of societies \(S_h\) (\(h\in\mathbb N\) denoting foundation observation horizon) is generated by explicit rules without ad hoc choices, with components joined by proved natural bijections or heterogeneous equalities—for instance, the canonical bijection between the lineage quotient of trace seeds and generated actors (Theorem 2.2). We claim neither that human history admits a single institutional form nor that all models satisfying social contracts are unique up to isomorphism; normative justification stands on Section 1.2, while formal theorems establish inhabited joint realization, universal exhaustion, and sharp impossibility boundaries.

To make the main text self-contained across disciplines without requiring readers to inspect underlying code, we define six core institutional objects up front (exact identifier mappings to the formal repository appear in Supplement Appendix D):

- **Occurrence (\(\omega\)) and visit (\(v\))**: An occurrence \(\omega\) retains the actual activity trace, execution path, whole-ledger write-back, and pending obligations produced by the generating program; a visit \(v\) indexes its exact position in registered execution. Two visits displaying identical surface states at distinct historical positions remain distinct occurrences [@GaoProcess].
- **Responsibility row (\(\delta\)) and whole-ledger update**: Each responsibility row records its originating occurrence, bearer, content owed or accountable, strict progress budget, and live versus archived status. A “whole-ledger” update covers **every** institutional, material, and financial obligation row touched by an operation, ruling out accounting sleights of hand that balance cash while dropping unfulfilled duties [@GaoLedger; @Ellerman2014].
- **Source root and native payment**: A generating structure fixing permissions, obligation rows, and successor rules across a family of occurrences is a source root; a complete payment generated directly from an occurrence's own trace and obligations without external retroactive fiat is its native payment.
- **Independent processing operation**: An institutional operator authorized by provenance to inspect policy effects, read performance receipts, or drive subsequent obligation dispositions. In the main text it denotes a checkable institutional verification or execution mechanism, never a market consumer.
- **Root law and constitutional point**: The overarching formal rule constraining how every complete program acquires write authority and accounts for obligations under refusal or rule change is the root law; an institutional node installing recognition rules, receiving submissions, and delivering complete dispositions is a constitutional point.
- **Observer-factored readout and occurrence authority**: An authority observer \(O=(\operatorname{forget},K)\) projects full occurrences \(\omega\) onto visible records \(\operatorname{forget}(\omega)\) while retaining true source authority \(K(\omega)\). Any metric, vote, matching, or narrative computed solely from visible records is a visibly factored readout.

For rapid cross-section lookup, core mathematical symbols and their defining sections are summarized below:

- **Traces and actors (§2)**: \(\tau(\omega)\) denotes the activity trace; \(U_\omega\) the trace-witnessed seed set; \(\ell:U_\omega\to L_\omega\) the lineage map; \(A_\omega=\ell[U_\omega]\) the generated actor domain, with canonical quotient bijection \(\Phi:U_\omega/{\sim_\ell}\xrightarrow{\sim}A_\omega\).
- **Foundation and capacity phases (§1.4, §§3.2–3.6)**: \(S_h\) is the canonical society at horizon \(h\in\mathbb N\); \(\mathcal F_h\) the complete foundation dependent product; \(\mathcal O(e),\mathcal P(e)\) open-settlement and price-observation types; \(C,k\) installed renewal capacity and exact queue-prefix cut.
- **Root law and proof-carrying legislation (§§4.1–4.5)**: \(\mathrm P(r),\mathrm J(r),\mathrm A(r),\mathrm U(r)\) denote presentation, refusal, action, and same-source revision, and \(\mathrm W(r)\) actual write authority; \(c_m\) is the same-point constitutional locus; \(\rho,\tau_d\) denote a sealed inquiry runtime and its depth-\(d\) active occurrence.
- **Payment cycles and strict progress (§§1.5–1.6)**: \(\mathcal C(v,s,b)\) is the payment-cycle type; \(\mathsf P_{i_d}\) the complete lawful-payment type at \(i_d=i_0+d\); \(H_i,A_i\) the paid frontier list and authority image; \(\prec_{\mathrm{can}}\) the strict canonical progress order.
- **Exit and observer-kernel boundaries (§§5.1–5.13)**: \(E_d(c,j)\) is a five-gate feasible exit edge and \(K_d\) maximum-matching exit capacity; \(\Omega_d,\rho_d,\phi(x)\) denote the failure-source family, full-domain reachability readout, and source failure kind; \(O_{\mathrm{soc}},O_{\mathrm{hid}},\partial_O\) denote the society observer, hidden-fiber product observer, and attaching boundary.
- **Regeneration and whole-ledger clearing (§§6–7)**: \(\Gamma_d\) is the depth-\(d\) sixfold regeneration carrier; \(s_{\mathrm{clr}},s_{\mathrm{post}},s_{\mathrm{next}}\) denote the joint-settlement endpoint, first post-settlement visit, and next visit; \(\Lambda_n\) denotes persistent external liability across locally empty ledgers; \(B\) denotes a row's natural-number strict progress budget.

Every definition, lemma, proposition, and theorem in this paper is machine-checked in the Lean 4 dependent-type kernel using only the three standard mathematical axioms (`propext`, `Classical.choice`, and `Quot.sound`, with zero unproven axioms) [@deMouraUllrich2021]; the main text gives complete, self-contained mathematical proofs, while long dependent transports and cross-module assemblies appear in Supplement Appendices A–G.

### 1.4 The Canonical Society Theorem and Paired Positive-Negative Controls

Handling A's departure requires distinguishing two senses of “what comes next”: a **responsibility post-state** recording which obligations are archived and which remain live, and the **next constitutional visit** specifying where the next institutional execution starts. Committing an authorized whole-ledger update to its target is an **actual write**; the state actually reached and handed to the next step is the **actual successor state**. Theorem 1.1 unifies subject generation, constitutional closure, all-depth regeneration, strict progress, cofinal self-amendment, and diagnostic/observer-kernel impossibility across six pillars on \(S_h\).

**Theorem 1.1 (The Canonical Society Theorem).** There exists an inhabited family of canonical societies \(S_h\) (foundation horizon \(h\in\mathbb N\)) over explicit activity sources, lineage rules, and whole-ledger obligation contracts jointly satisfying six conclusions:

1. **Subject generation without preinstalled individuals, co-installed phase laws, and same-point foundation (`G0, G2, G2a, G6, M8, M10`; Sections 2–3 and 4.3).** Each \(S_h\) postulates no prior set of individuals: its actor domain is canonically bijective with the lineage quotient of trace-witnessed activity seeds while retaining provenance recovery across economic, biological, multi-agent, and strategic traces, six lifecycle transitions, and the complete foundation \(\mathcal F_h\); seedless renewal faces (including empty artificial-actor seeds) are strictly empty, pre-emission projections co-install election, purchasing power, maintenance, and trace-witnessed artificial actors on one root, and one position-indexed queue endogenously derives the monotone stable–critical–anomie phase law while forbidding full-debit certification in anomie. Across all prescribed parameters, registered recursion generates stage \(m\) and **one constitutional point \(c_m\)** uniting an inhabited external complete payment, complete raw-submission dispositions, and universal root-law classification.
2. **Fourfold root-law closure, endogenous reform/revision classification, and proof-carrying legislation (`G1–G2a, G8, M9`; Sections 4.1–4.5).** Every complete installed program's generated execution \(r\) is exhausted by presentation, refusal, action, and revision (\(\mathrm P(r)\lor\mathrm J(r)\lor\mathrm A(r)\lor\mathrm U(r)\)); actual writing holds iff action or revision occurs and never both (\(\mathrm W(r)\iff\mathrm A(r)\lor\mathrm U(r)\), \(\neg(\mathrm A(r)\land\mathrm U(r))\)), excluding any fifth off-ledger write channel. Root-authorized raw submissions obtain external revision packages via the transport bridge, and inhabited installed revisions retain exact failure, the targeted row, first write, and old/new successor packages within \(r\); a sealed inquiry runtime classifies active decisions as reform or same-source constitutional revolution, distinguishes both from successor-free authoritative rupture, and realizes same-occurrence proof-carrying legislation across a fourfold heterogeneous splice.
3. **All-depth same-occurrence sixfold regeneration and exact visit continuation (`G8–G9`; Sections 6.1–6.3).** At every depth \(d\in\mathbb N\) (unbounded by horizon \(h\)), current payment \(p_d\) indexes an inhabited carrier \(\Gamma_d\) whose **every** element jointly retains law and lineage continuation, noncontracting ordinary exit (\(K_d=K_{d+1}=1\)), capture repair, residual-bearer retention and processing, successor amendment routes, and distinct-actor counterparty attribution on that same payment. The actual next visit equals depth \(d+1\)'s entry (\(v^+(g)=v_{d+1}\)), adjacent payments remain distinct (\(\widehat p_d\ne\widehat p_{d+1}\)), and depth-zero policy rupture yields strictly unequal ordinary-repair and law-revision successors.
4. **Universal lawful-payment preservation and strict progress of the paid frontier (`G13–G14`; Sections 1.5–1.6).** For every cycle \(C:\mathcal C(v,s,b)\), observation depth \(o\), position \(d\in\mathbb N\), and **every** lawful payment \(p\in\mathsf P_{i_d}\), the target generated by \(p\) itself preserves all essential-access channels, external-liability processing, target new birth, and the next complete exit constitution; the entire earlier paid frontier persists while the target's native payment fulfills a fresh occurrence outside the old authority image (\(\kappa(\gamma_{i_d+1})\notin A_{i_d}\)), establishing \(C_r\prec_{\mathrm{can}}C_t\iff r<t\) for all \(r,t\in\mathbb N\).
5. **Cofinal single-step joint amendment, rich birth, and obligation conservation (`G6–G7, G18–G22, G27`; Sections 6.4–6.5 and 7).** Beyond every finite cutoff \(n\) and parameter \(h\), a later step \(m>n\) jointly realizes actual same-source law revision, root-law continuation, and paid compatible future in one step, emptying every “revision-free terminal state.” Rule revision migrates live obligations across the first write until native performance archives them; strict-renewal exhaustion (depth \(3\)), faithful local termination (depth \(9\)), and joint settlement (\(s_{\mathrm{clr}}\)) occupy strictly distinct loci, locally empty ledgers retain external liabilities \(\Lambda_n\), and every conservative sequential target of the exhausted three-row ledger has zero positive-budget rows at its first whole-ledger successor.
6. **All-universe diagnostic impossibility and observer-quotient authority boundary (`G3–G5, G15–G17, G23–G26, M7`; Section 5).** Genuine exit holds iff one pair \((c,j)\) satisfies all five gates (Theorem 5.1). Full-domain reachability \(\rho_d\) admits an involution kernel on \(\Omega_d\) blocking any decoder across **arbitrary output universes and encodings** factored through \(\rho_d\), whereas retaining source failure kind \(\phi(x)\) restores unique repair and refines unit-counting probability from \(1/2\) to \(1\) and \(0\) (Theorems 5.10–5.11). On \(O_{\mathrm{soc}}\) and across arbitrary agent/alternative carriers and hidden authority fibers, the Arrow, Gibbard–Satterthwaite, and Sen visible axiom bundles stay intact, yet occurrence-authority completeness for all three collective rules, positive bilateral matching \((7,7)\), and trace-constrained common narratives is strictly empty; over any inhabited visible carrier, visible axioms never entail hidden-fiber factorization (Theorem 5.13).

| Pillar of Theorem 1.1 | Core constitutional & social problem solved | Main-text results & location | Paired dark-twin / negative-control gate (triggered if dropped) |
| --- | --- | --- | --- |
| Subject generation & co-installed base | Can enduring actors and overload bounds arise from traces without prior individuals? | §§2–3, §4.3; Theorem 2.2, Props. 3.1–3.2, Theorem 4.3 | Empty AI seed \(\Rightarrow\) renewal \(=\varnothing\); 3-cycle sum \(2\ne 0\) refutes scalar potential; anomie \(k>C\) full debit \(=\varnothing\) |
| Fourfold root law & proof-carrying law | How can off-ledger power be closed while endogenously separating reform, revolution, and rupture? | §§4.1–4.5, §5.4; Def. 4.1, Theorems 4.2–4.4, Prop. 5.4 | Total-capture search & misrouted write \(=\varnothing\); faceless revolution producer \(=\varnothing\); rupture has no same-ledger successor |
| Genuine exit & anti-capture lifecycle | Why can a worker with money, services, or a new job remain trapped in subordination? | §§5.1–5.9; Theorems 5.1, 5.5–5.6, 5.9, Props. 5.7–5.8, 5.12 | Missing route (with 7 renewals intact) or capture \(\Rightarrow\) exit \(=\varnothing\); 4 retaliatory retypings \(=\varnothing\); 3rd slot in 2 slots \(=\varnothing\) |
| All-universe diagnosis & observer kernel | Can exact capability panels, arbitrary encodings, or visible votes/matchings decode authority? | §§5.2, 5.10–5.13; Props. 5.2–5.3, Theorems 5.10–5.11, 5.13 | Three zeros \((K=0)\), two ones \((K=1)\), and \(\rho_d=(0,\varnothing)\) kernel block all post-decoders; Arrow/GS/Sen, match & narrative auth \(=\varnothing\) |
| All-depth regeneration & strict progress | Does constant capacity \(K_d=1\) imply stagnation, or can amendment freeze after finite rounds? | §§1.5–1.6, §6; Theorems 1.2–1.3, Prop. 6.1, Theorems 6.2–6.5 | Dropping old frontier or replaying receipts violates \(A_{i_r}\subsetneq A_{i_t}\); any “revision-free terminal state” collides with step \(m=n+1\) |
| Live migration & ledger conservation | Can rule change, countdown publication, or emptying a local ledger wipe out debt and ecological harm? | §§7–9; Props. 7.1–7.2, 7.8, Lemma 7.3, Theorems 7.4–7.7 | Depth-\(3\) exhaustion \(\ne\) depth-\(9\) halt \(\ne s_{\mathrm{clr}}\) clearing; publication fixed point \((1=0)=\varnothing\); conservative pinch \(0\le B'\le 0\) |

Table 1: Six pillars of the Canonical Society Theorem, main-text theorem mapping, and paired dark-twin controls. Every universal positive guarantee is paired with a same-source formal negative control isolating its indispensable premise.

Table 1 and Figure 2 exhibit our two-sided proof architecture: the positive loop quantifies universally over arbitrary lawful payments, complete programs, sealed inquiry runtimes, output universes, and agent/alternative carriers in Theorems 1.2, 4.2, 4.4, 5.10, 5.13, 7.8, and Proposition 3.2, while the paired negative-control gates prove exactly where phantom shell actors, coarse indicators, visible voting or matching tables, and nominal reorganizations hit empty-type contradictions when severed from provenance.

![Six interlocking constitutional pillars and three paired negative-control gates of the Canonical Society Theorem](figures/09-master-architecture-v3-en.svg)

Figure 2. Global architecture of the Canonical Society Theorem. Panel A displays the positive interlocking loop inside \(S_h\) linking subject quotient and co-installed foundation (§§2–3), fourfold root law and proof-carrying legislation (§4), five-gate exit and source refinement (§5), all-depth regeneration and cofinal amendment (§6), strict progress across every lawful payment (§§1.5–1.6), and whole-ledger conservation with four open interfaces (§§7–9); Panel B aligns the three paired impossibility gates for subject/anomie bounds, rupture/observer kernels, and debt/zero-budget conservation.

### 1.5 Every Lawful Payment Preserves the Complete Institutional Contract

Once A receives housing and health care through one payment today, life tomorrow still requires performance and pending external liabilities still require handling. If institutional continuity worked only along a single cherry-picked demonstration payment while breaking whenever a participant used another lawful payment of the same type, constitutional protection would remain fragile. Pillar 4 therefore quantifies universally over **every lawful payment** at every step of any registered cycle.

A canonical payment cycle records the current constitutional entry, the payment and same-source law revision generated there, and the recursive rule producing the next entry from the actual successor. Write \(\mathcal C(v,s,b)\) for this cycle type, where \(v\) is an old visit on the fixed source root, \(s\) selects the source, and \(b\) fixes the starting boundary. For any cycle \(C:\mathcal C(v,s,b)\) with lifecycle origin \(i_0\), round \(d\) sits at index
\[
i_d=i_0+d,
\]
with explicit origin \(i_0=b+2\) fixed by the boundary (Supplement Appendix E.1). Write \(\mathsf P_{i_d}\) for the complete payment type at this occurrence: each element carries native write-back, complete obligation successor, exercise and response on the same continuation action, and external liability attribution. Given **any** \(p\in\mathsf P_{i_d}\), Theorem 1.2 constructs the target and all institutional guarantees directly from \(p\) itself without substituting a preselected canonical witness.

**Theorem 1.2 (Complete Canonical Payment Preservation).** For all \(v,s,b\), every payment cycle \(C:\mathcal C(v,s,b)\), observation depth \(o\), natural number \(d\), and every lawful payment \(p\in\mathsf P_{i_d}\), the target generated by \(p\) itself preserves the cycle's complete institutional contract and jointly satisfies:

1. The input payment remains \(p\) itself, and the target occurrence produced by its whole-ledger obligation successor connects with exact dependent equality to the canonical post-state at index \(i_d+1=i_{d+1}\).
2. That post-state possesses its own native payment, complete target new birth, extra-role exit for the bearer, and every installed essential-access channel. For each channel, its relation witness returns that channel's existing actor and relation, payment and settlement projections return the target's own actual exit, and its independent processing operation is compatible with the next occurrence generated by the target.
3. The target retains provenance attribution and root-level independent processing for external obligation (even when the target's local open-obligation set is empty) and regenerates the next round's complete exit constitution: source-backed standing and payment, extra-role continuation, noncapture, actual routes and services, external-obligation handling, same-source law revision at that node, and the actual next cycle.
4. The target's complete state, native payment, and root event align by lawful transport with the next lifecycle's source state, source payment, and source event; replacing \(p\) by any other lawful payment \(p'\in\mathsf P_{i_d}\) reaches the same compatible target occurrence.

For every finite request bound \(n\), these conclusions hold for every lawful payment across \(d=0,\ldots,n\) and generate the same preservation object for every lawful payment at \(d=n+1\). Every canonical society \(S_h\) stores a registered payment cycle together with its complete finite-prefix proof.

**Proof.** Fix arbitrary \(C,d,p\). Type \(\mathsf P_{i_d}\) indexes \(p\)'s write-back, complete obligation successor, and external liability to the same exact root event and actual-exit fiber. Within that exact fiber, the obligation-successor carrier is a subsingleton, so any two lawful payments in \(\mathsf P_{i_d}\) share the same target-occurrence projection (using subsingletonity of the successor fiber alone, without equating distinct full payments). Specializing one side to the program's native payment \(\bar p_{i_d}\), whose successor is literally index \(i_d+1\), identifies \(p\)'s target projection with occurrence \(i_d+1\) while keeping \(p\) itself as the source payment.

Running the canonical state generator on this target occurrence produces the target's own native payment \(\bar p_{i_d+1}\), target new birth \(\gamma_{i_d+1}\), and independent processing operations for both installed essential channels (tenure and health). Each channel returns its actor, relation, and served-slot receipt aligned with the target's actual exit and next occurrence. Even though the target's local open-obligation set is empty, external-obligation provenance and root processing persist from the external-liability construction. Finally, \(i_d+1=i_{d+1}\) transports target state, native payment, and root event onto the next lifecycle's source end, regenerating \(\mathsf E_C(d+1)\). Applying this across \(d=0,\ldots,n\) and \(n+1\) on \(S_h\)'s registered initial cycle completes the proof (nine exact deletion and misreporting refutations appear in Appendix E.1.4). ∎

### 1.6 Constant Instantaneous Exit Capacity with Strictly Growing Realized History

If A faces instantaneous exit capacity \(1\) at every round, is the institution merely running in place? Looking only at the static capacity score, yesterday read \(1\) and today still reads \(1\). Yet yesterday's meal, medical visit, or safe passage cannot satisfy today's need. What distinguishes genuine ongoing freedom from circular replay is whether all previously fulfilled occurrences remain intact while today's **own native payment** realizes a fresh service and exit occurrence outside the entire earlier authority image.

Along a chosen cycle \(C\), write \(\gamma_k\) for the new birth generated at index \(k\) and \(\kappa(\gamma_k)\) for its complete service-exit authority object (recording actual visit, payment occurrence, settlement, and uncaptured feasible edge). Define the paid frontier list and authority image up to index \(i\):
\[
H_i=[\gamma_0,\ldots,\gamma_i],
\qquad
A_i=\{\kappa(\gamma_k)\mid 0\le k\le i\}.
\]
Writing \(\mathsf E_C(d)\) for the complete exit constitution preserved at step \(d\) by Theorem 1.2, define **strict canonical progress** between two cycle stages by
\[
C_r\prec_{\mathrm{can}}C_t
\quad\Longleftrightarrow\quad
\mathsf E_C(r)\land\mathsf E_C(t)
\land A_{i_r}\subsetneq A_{i_t}.
\]
This strict order jointly requires intact constitutional structure at both endpoints and strict proper inclusion of realized authority images.

**Theorem 1.3 (Strict Canonical Progress).** For every payment cycle \(C:\mathcal C(v,s,b)\) and all depths \(r,t\in\mathbb N\),
\[
C_r\prec_{\mathrm{can}}C_t
\quad\Longleftrightarrow\quad r<t.
\]
Moreover, for every observation depth \(o\), natural number \(d\), and arbitrary lawful payment \(p\in\mathsf P_{i_d}\), one and the same payment step jointly generates the complete preservation object of Theorem 1.2 together with
\[
H_{i_d+1}=H_{i_d}\mathbin{+\!\!+}[\gamma_{i_d+1}],
\qquad
\kappa(\gamma_{i_d+1})\notin A_{i_d}.
\]
The fresh occurrence \(\gamma_{i_d+1}\) resides at the actual target reached by \(p\) and is fulfilled by that target's own native payment, while pre-payment obligation records, channel actors and relations, external-liability provenance and root processing, and the root law's complete disposition at this step are all retained. Every \(S_h\) exports this joint conclusion across every requested finite prefix and its next edge.

**Proof.** List extension \(H_{i+1}=H_i\mathbin{+\!\!+}[\gamma_{i+1}]\) holds by construction; the crux is proving \(\kappa(\gamma_{i+1})\notin A_i\). Suppose \(\kappa(\gamma_j)=\kappa(\gamma_k)\). Projecting their payment-occurrence identities and applying injectivity of visit-packaged payments (Supplement Lemma B.3) forces equal actual visits; since index \(k\) sits at visit coordinate \(r_0(s)+k\), cancelling \(r_0(s)\) yields \(j=k\). Thus \(\kappa(\gamma_{i+1})\ne\kappa(\gamma_k)\) for all \(k\le i\), establishing \(\kappa(\gamma_{i+1})\notin A_i\).

Theorem 1.2 supplies \(\mathsf E_C(r)\) and \(\mathsf E_C(t)\) at all depths. If \(r<t\), \(i_r<i_t\) retains all earlier elements while adjoining outside witnesses, giving \(A_{i_r}\subsetneq A_{i_t}\). Conversely, if \(A_{i_r}\subsetneq A_{i_t}\), assuming \(t\le r\) implies \(i_t\le i_r\) and hence \(A_{i_t}\subseteq A_{i_r}\), contradicting proper inclusion; thus \(r<t\). Unfolding adjacent steps \(i_d\) and \(i_d+1\) confirms that input \(p\) reaches actual target \(T_{i_d+1}\), whose own native payment \(\bar p_{i_d+1}\) fulfills \(\gamma_{i_d+1}\), placing contract preservation and strict frontier growth on the same payment edge (Appendix E.2). ∎

![Strict growth of the actual paid frontier alongside constant instantaneous capacity](figures/07-paid-frontier-v3-en.svg)

Figure 3. Strict canonical progress along a payment cycle. Every lawful payment carries the complete contract into its actual target, retaining the entire old authority image \(A_{i(r)}\) while fulfilling a new occurrence outside it via the target's native payment so that \(A_{i(r)}\subsetneq A_{i(t)}\) (\(r<t\)); below, instantaneous exit capacity \(K_d\) can remain constantly \(1\) while the realized history of freedom grows strictly.

Theorem 1.3 separates static capacity snapshots from cumulative realized freedom: even when instantaneous exit capacity equals \(1\) at every round, refusing to recycle old receipts or erase prior commitments forces the paid frontier to expand strictly. Yesterday's exit receipt cannot pay for today's life; openness means every successor supplies a genuinely paid new beginning.

### 1.7 Fifteen-Minute Fast-Track Channels Across Four Disciplines and Series Positioning

Because this paper bridges normative philosophy, jurisprudence, economics, and formal verification, we provide four self-contained 15-minute reading paths tailored to each readership:

- **Political Philosophy, Capability Theory, and Normative Social Theory** (pre-contractual individuals, non-contractual conditions of contract, non-domination, private government, basic income, and social reproduction): Read Sections 1.1–1.2 (Example 1.1 and basic participation) \(\to\) Section 2.2 Theorem 2.2 and Section 3.6 Proposition 3.2 (subject quotient without prior individuals, phantom-AI prohibition, and anomie phase law) \(\to\) Sections 5.1–5.2, 5.6, 5.8, and 5.12 (five-gate exit iff, three zeros and two ones, structural anti-retaliation, income-service-job separation, and dark twins) \(\to\) Section 8 and Sections 10.1–10.2.
- **Constitutional Jurisprudence, Institutional Grammar, and Norm Change** (*Grundnorm*, sovereign exception, dualist constitutional moments, rules of recognition and change, Hohfeldian power, and obligation migration across amendment): Read Section 3.1 \(\to\) Sections 4.1–4.5 Definition 4.1, Theorems 4.2–4.4, and Table 2 (fourfold root-law closure, same-point realization, 16-point social grammar, classification of active reform/revision and the separately witnessed terminal rupture, and same-occurrence proof-carrying legislation) \(\to\) Section 5.4 Proposition 5.4 (misdirected refusal and node-payment recourse) \(\to\) Sections 6.1–6.5 \(\to\) Section 7.4 Theorem 7.4 and Section 10.4.
- **Social Choice, Mechanism Design, Accounting, and Monetary Political Economy** (Arrow/GS/Sen theorems, Gale–Shapley bilateral matching, property-rights residual control, double-entry whole ledgers, monetary hierarchy, judgment-proofness, and Bancor clearing): Read Section 1.1 Example 1.1 \(\to\) Sections 3.2 and 3.6 (\(\mathcal P(e)\simeq\mathcal O(e)\) and full-settlement elimination) \(\to\) Sections 5.7, 5.10–5.11, and 5.13 Proposition 5.7, Theorems 5.10–5.11, Example 5.1, and Theorem 5.13 (observer-kernel bridge across social choice, matching, and narrative) \(\to\) Sections 7.1–7.3 and 7.5–7.8 (leg-by-leg clearing, three termination loci, and zero-budget conservative pinch) \(\to\) Sections 8.2–8.4, 9, and Sections 10.2–10.3, 10.5.
- **Formal Verification, Dependent Type Theory, and Algebraic Specification** (quotient types, pre-emission projection lifting, heterogeneous transport, cofinal liveness, and proof-carrying execution): Inspect Sections 1.4–1.6 Theorems 1.1–1.3 \(\to\) Theorem 2.2, Propositions 3.1–3.2, Section 3.7 universe-polymorphic memory equivalence, Theorems 4.2–4.4, 5.9–5.13, 6.2–6.5, and 7.4–7.7 alongside Supplement Appendices A–G (especially Appendices C.6–C.7, D, and G) and the theorem–source correspondence table.

Within the companion research series, *Source-Native Process Algebra and Initial-Coface Revision* establishes four-tier event identity, exact evaluation kernels, and minimal initial-coface revision [@GaoProcess]; *Provenance-Preserving Conservation Calculus and Non-Free Continuity* establishes whole-event inventories, observer safety, and well-founded two-key settlement [@GaoLedger]; *An Economic Constitution of Possibility* formulates the normative four-power separation among basic participation, contribution claims, scarce budgeting, and revocable governance [@GaoConstitution]; and *The Structural Theorem of Capitalism* proves minimal port-asymmetry support, same-length non-dominating public functional replay, and prior-free unique minimal risk pricing across concrete production and financial regimes [@GaoCapital]. The present paper forms the constitutional keystone of the social-institutional series: starting without preinstalled individuals, it generates actors, power relations, and the fourfold root law itself, establishes all-depth regeneration, observer-quotient diagnostic boundaries, and cofinal self-amendment, and exports four formal interfaces in Section 9 anchoring the downstream specialized treatises.

## 2 Generating Subjects from Activity Without Preinstalled Individuals

### 2.1 Retaining Complete Provenance of Activity and Obligation

From Hobbes's resolution of commonwealths into pre-covenantal atomic individuals to Rawls's rational contracting parties at the outset of *A Theory of Justice*, standard social and economic theory takes a pre-given individual set \(I=\{1,\ldots,n\}\) as an unquestioned starting point [@Hobbes1651, ch. 13; @Rawls1971, §§1–2]. In actual institutional life, however, legal and social boundaries of agency are continuously formed through activity, lineage, and obligation transfer: organizations merge or split, offices undergo succession, artificial agents are instantiated or retired, and persons move across roles; as Parfit's classic analysis of personal identity showed, what carries practical weight across branching, fusion, or transformation is not an underlying Cartesian ego, but traceable continuity and relational connection [@Parfit1971].

To track who inherits claims and duties after A leaves a role without presupposing prior individuals, our construction first retains what has actually occurred and then generates enduring bearer positions from within those occurrences. An **occurrence** \(\omega\) retains the generating program's trace, execution path, whole-ledger write-back, and pending obligations; a visit \(v\) marks its exact locus in registered execution [@GaoProcess; @GaoLedger]. Each visit \(v\) carries a family of obligation rows \(\mathcal R_v\). A complete payment \(p\) assigns an explicit disposition (archival or migration) to every old row and an old origin or lawful birth to every new row, advancing in the same execution to next visit \(v^+(p)\) and target occurrence:
\[
\omega^+(p)=\varepsilon\!\left(v^+(p)\right).
\]
Subsequent service fulfillment or law revision proceeds directly from this actual target without rewriting prior history.

**Definition 2.1 (Responsibility Row and Independent Processing Operation).** A responsibility row records its originating occurrence, bearer, content owed or accountable, strict progress budget, and current live status. An independent processing operation acts within the scope authorized by that provenance to verify policy effects, read performance receipts, or generate subsequent dispositions. Migration preserves content, lineage, and source anchor; final settlement requires both an actual performance receipt and emptiness of same-debt continuations in the successor.

Denote the responsibility row tied to A's post-departure continuation by \(\delta\): after refusal, \(\delta\) witnesses that A's bearer standing persists; after payment, \(\delta\) records fulfilled service; after law revision, \(\delta\) carries the live obligation into the revised first write until native performance archives it.

### 2.2 Generating Subjects from Activity Seeds: The Canonical Lineage Quotient Theorem

Without a preinstalled roster of individuals, how does an institution recognize “the same bearer A” across an expanding activity log? Construction proceeds in two steps: first collect activity seeds carrying actual witnesses inside trace \(\tau(\omega)\), then quotient by a lineage rule identifying seeds along the same enduring thread. Writing \(B(\omega,x,s)\) for the provenance relation witnessing seed \(s\) at trace entry \(x\), define the witnessed seed set
\[
U_\omega=
\{s\mid \exists x\in\tau(\omega),\ B(\omega,x,s)\}.
\]
Every \(s\in U_\omega\) carries an explicit trace witness, excluding phantom actors. Given lineage map \(\ell:U_\omega\to L_\omega\), the **generated actor domain** is its actual image:
\[
A_\omega=\ell[U_\omega].
\]
A health request and a housing settlement leave distinct seeds in \(\tau(\omega)\), yet \(\ell\) recognizes both as A's activities; a constant lineage map merges all seeds into one collective actor, whereas an injective lineage map keeps every seed distinct. Theorem 2.2 proves that generated actors stand in canonical bijection with lineage equivalence classes.

**Theorem 2.2 (Subject Generation and Canonical Quotient Bijection).** Every generated actor possesses a trace-witnessed source seed. Defining lineage equivalence on \(U_\omega\) by
\[
s\sim_\ell t\quad\Longleftrightarrow\quad\ell(s)=\ell(t),
\]
the canonical map from the seed lineage quotient to generated actors,
\[
\Phi:U_\omega/{\sim_\ell}\longrightarrow A_\omega,
\qquad \Phi([s])=\ell(s),
\]
is a well-defined bijection. Moreover, the seed-to-actor generation map is injective if and only if \(\ell\) is injective on \(U_\omega\).

**Proof.** If \(s\sim_\ell s'\), then \(\ell(s)=\ell(s')\), so \(\Phi\) is independent of class representatives. If \(\Phi([s])=\Phi([t])\), then \(\ell(s)=\ell(t)\) and hence \([s]=[t]\), proving injectivity. For any \(a\in A_\omega=\ell[U_\omega]\), some \(s\in U_\omega\) satisfies \(\ell(s)=a\), giving \(\Phi([s])=a\) and proving surjectivity. Finally, \(s\mapsto\Phi([s])=\ell(s)\) agrees pointwise with \(\ell\) on \(U_\omega\), so injectivity of both maps is equivalent (full quotient details in Appendix A.1). ∎

Theorem 2.2 places social theory without preinstalled Cartesian individuals on a clean algebraic footing: every institutional subject has checkable activity provenance, and each lineage class yields exactly one subject without omission or duplication. Lineage rules track continuing identity across events, while basic participation (Section 1.2) governs whom the institution must admit and answer—enabling affected newcomers to enter institutional protection by registering actual relations rather than invoking pre-institutional privilege.

### 2.3 Cross-Role Migration, Six Lifecycle Operations, and Four-Domain Generality

Persistence of a subject and change of social role live on distinct levels. Roles depend on the triple *(actor, relation, phase)*: when A leaves a job, the employment role ends while A's lineage identity, complete payment, and pending obligations enter subsequent public-service or cooperative relations intact.

Subjects themselves also evolve structurally over time. Our universal lifecycle operator tracks source actors, target actors, and occurrence incidence across six transitions—**birth, persistence, merge, split, exit, and succession**: persistence preserves lineage; merge retains all contributing sources; split explicitly allocates child sources and obligation shares (Section 7.7); succession archives the outgoing officeholder's completed mandate while transferring continuing office responsibilities to a newly generated holder (Section 5.7); and domain exit executes native terminal disposition when a subject leaves an activity domain.

Crucially, this zero-preinstalled-individual mechanism is not custom-wired to wage employment alone. Within the same formal kernel, **economic exchange traces, biological lineage traces, multi-agent coordination traces, and finite-horizon strategic Go traces** all recover their respective actors, lineages, and provenance attributions through the identical seed-quotient interface (Supplement Appendices A.1 and C.1; cross-domain regression `SocietyBookCrossDomainG8`). With enduring subjects established, we now examine how payments, powers, and spaces assemble into usable institutional capabilities.

## 3 How Payments and Relations Assemble into a Checkable Institutional Foundation

### 3.1 Relational Power, Capture, and the Irreducible Three-Agent Non-Potential Cycle

Once subject A is identified, what A can actually do depends on the institutional relations A inhabits. Relations themselves are generated from activity seeds and lineages, assigning distinct target roles as the same subject enters distinct relations.

Over a century ago, Hohfeld drew a foundational jural distinction between a **claim-right** to another party's performance (correlative to *duty*) and a **power** to alter legal relations by one's own act (correlative to *liability*) [@Hohfeld1913, “Powers and Liabilities”]. This distinction cuts straight to A's departure: A may hold the legal power to terminate an employment contract while former employer B holds power to alter downstream access conditions; even after valid termination, whether A can live outside the former role depends on whether nonidle, uncaptured continuation actions remain available. Every relational locus in our foundation retains a finite inventory of future action codes together with their continuation conditions: power exercise records both controller B's source event and the resulting contraction of affected bearer A's continuable future. When B eliminates every independently exercisable nonidle continuation for A, formal **capture** occurs; even if the action-code set remains nonempty because an idle code survives, substantive agency is reduced to zero.

Relational differences also exhibit topological structure strictly irreducible to individual scalar attributes. As checked in Example 1.1(4), if every directed difference around a three-actor cycle \(0\to 1\to 2\to 0\) equaled a difference \(\phi_j-\phi_i\) of individual scalar potentials, summing around the loop would telescope to \(0\). Yet the trace-generated three-actor cycle in our foundation has relational phase sum equal to \(2\ne 0\) (Appendix C.1). **No global assignment of individual scores, credit ratings, or utility weights can reconstruct these relational differences**—mathematically witnessing a nontrivial first cohomology class on the relation graph and refuting scalar individualism.

### 3.2 Four-Leg Exchange, Open Settlement, and Price-Domain Equivalence

How does A's payment connect to genuine obligation discharge? Money is not a neutral veil over barter, but a constitutional practice organizing common resources, defining whose promises count in payment, and allocating settlement burdens [@Desan2013, pp. 1–3, 28–29; @Desan2014, pp. 6–8]; mathematically, double-entry bookkeeping tracks paired vector claims and obligations rather than scalar net worth alone [@Ellerman2014]. Finite four-leg exchange in our foundation generates both counterparties, their relation, source event, obligation bearer, and protected interest on every leg, storing either a live obligation or a fulfilled terminal archive in each stable slot.

On what object does a price observation live? Writing \(\mathcal O(e)\) for the open-settlement type of an exact settlement \(e\) and \(\mathcal P(e)\) for its admissible price-observation type, the foundation proves an exact equivalence:
\[
\mathcal P(e)\simeq\mathcal O(e).
\]
This equivalence enforces a structural law routinely blurred by purely quantitative models: **the existence of a price observation strictly presupposes an open, unsettled obligation**. As long as unsettled content remains, a price observation exists—so a zero price quote (such as unpriced public provision or zero-interest rollover) can belong to an obligation that is still very much alive; conversely, once all legs are genuinely fulfilled and archived, \(\mathcal O(e)\) becomes empty and the price domain \(\mathcal P(e)\) vanishes with it. Zero price never implies settled debt; verifying whether row \(\delta\) has ended requires reading its live slot and native performance receipt while advancing history to that performance's actual target.

### 3.3 Authorization, Hard Queue Capacity, Spatial Maintenance Debt, and Strategic Representation

Turning nominal purchasing power into lived support requires authorization lineages, payment acceptance, service capacity, and physical routes to interlock on the same source root:

1. **Four-aspect co-installation on one root**: Actual election updates public authorization lineages, payment acceptance updates purchasing-power standing, relational maintenance separates usage permission from debt flow, and trace-generated artificial actors enter obligation renewal—all four sharing one whole-ledger update and actual successor at the same visit.
2. **Hard service-queue capacity and non-fungible slot ordinals**: Physical service capacity in the canonical queue equals \(2\). Queue prefixes of lengths \(1,2,3\) enter stable, critical, and overloaded regimes respectively: the critical length-\(2\) prefix obtains complete budget debit and completion receipts, whereas the overloaded length-\(3\) prefix admits no certificate that all queued requests were served. Even if request \(3\) has the exact same visible description as request \(1\), it occupies a distinct queue ordinal; slot \(1\)'s receipt cannot certify completion of slot \(3\).
3. **Separation of settled spatial crossing from pending maintenance debt**: Sustainable governance of shared infrastructure and commons hinges on pairing resource extraction or passage with explicit maintenance duties [@Ostrom2009]. Our spatial construction binds location crossing, route usage, resource debit, and maintenance liability into one occurrence: its boundary instance exhibits **\(2\) settled crossing services alongside \(3\) pending maintenance debts**. The route is genuinely usable right now, yet maintenance obligations remain live with identified bearers.
4. **Isomorphic embedding of finite strategic games with residual-authority fibers**: Lawful source codes generate finite strategic games, and conversely **every finite strategic game admits an isomorphic source-generated representation**. Classical game theory embeds losslessly into our framework, yet two game objects with identical strategy profiles and payoff matrices can still carry distinct residual-handling authorities. Payoff tables alone cannot tell who holds authority to settle unfinished obligations.

### 3.4 Fiber-Conditional Probability from Provenance: Measured Zero Versus Undefined Zero Mass

Institutions routinely evaluate uncertain causes from partial observations. Yet when a conditioning observation has zero prior weight, textbook Bayesian conditioning either invents exogenous priors or conflates “ample evidence refuting event \(A\)” with “zero evidence observed at all.” Given visible readout \(z\), let \(X_z\) be the fiber of source objects reading out \(z\), each carrying nonnegative provenance weight \(w(x)\ge 0\). For any event \(A\), provenance-grounded conditional probability takes values in \([0,1]\cup\{\bot\}\):
\[
P(A\mid z)=
\begin{cases}
\dfrac{\sum_{x\in X_z,\ x\in A}w(x)}
{\sum_{x\in X_z}w(x)},&\sum_{x\in X_z}w(x)>0,\\
\bot,&\sum_{x\in X_z}w(x)=0.
\end{cases}
\]
When total fiber mass is strictly positive and no member falls in \(A\), probability equals the defined number \(0\); when the entire fiber has zero mass (as at horizon \(h=0\) before any occurrence is observed), no normalizing denominator exists and the operator honestly returns undefined \(\bot\) (\(\mathrm{none}\)) rather than fabricating priors. An installed foundation instance yields \(1/3\) (“below one half”) while sharing whole-ledger write-back and successor with boundary maintenance; Section 5.11 will show how the exact same unit-counting measure reads \(1/2\) under coarse observation yet splits cleanly into \(1\) and \(0\) once source failure kinds are retained.

### 3.5 Inhabited Co-Assembly of the Complete Institutional Foundation

Can the actor quotient, six-mode lifecycle, non-potential cycle, four-leg exchange, hard queue capacity, spatial maintenance, strategic game isomorphism, fiber probability, theory adoption (Section 7.4), and observer-quotient bridges (Section 5.13) coexist without type collision inside one mathematical object? Write \(\mathcal F_h\) for the dependent product assembling all these components together with their cross-component installation equalities at foundation horizon \(h\in\mathbb N\)—“dependent” ensuring that every maintenance receipt points back to the exact debit that produced it, every processing operator binds its own obligation row, and co-installed aspects literally share visit and successor.

**Proposition 3.1 (Inhabited Construction of the Complete Foundation).** For every foundation horizon \(h\in\mathbb N\), the complete institutional foundation \(\mathcal F_h\) is inhabited and is stored and exported by the canonical society \(S_h\).

**Construction and proof.** First construct the actor domain via the seed-lineage quotient (Theorem 2.2), retaining provenance recovery across economic, biological, multi-agent, and Go traces, six lifecycle obligation transitions, relational power, capture witnesses, and the three-actor cycle of phase sum \(2\). Next assemble four-leg exchange, \(\mathcal P(e)\simeq\mathcal O(e)\), bidirectional finite-game representation, and the observer-quotient boundary package (ordinary left proxy section alongside empty faithful/natural authority reconstruction and base-universe social-choice, visible-matching, and trace-narrative bridges, with full multi-universe polymorphism exported independently in Section 5.13 Theorem 5.13). Co-install election, purchasing power, relational maintenance, and artificial-actor renewal on one source root, adjoin length-\(1,2,3\) capacity-\(2\) queues, \(2\)-service/\(3\)-debt spatial crossing, \(1/3\) fiber probability co-installed with boundary maintenance, and theory-adoption effect verification, mother-law failure migration, and clearing. Packing these witnessed components with their proved installation equalities inhabits \(\mathcal F_h\) inside \(S_h\) (full factor inventory in Appendices C.1 and C.6–C.7). ∎

![Subject generation without preinstalled individuals, four-domain reuse, and institutional foundation assembly](figures/02-generation-v3-en.svg)

Figure 4. Construction chain from activity provenance to the complete institutional foundation \(\mathcal F_h\). Activity seeds pass through the canonical quotient bijection \(\Phi\) to generate enduring subjects (reused across economic, biological, multi-agent, and strategic domains), entering non-potential relational structures, four-leg settlement, and co-installed public capabilities while keeping bearer, controller, and service provider distinct.

### 3.6 No-Free-Seed Renewal Prohibition, Four-Face Pre-Emission Co-Installation, and the Stable–Critical–Anomie Phase Law

In seeking post-departure support, Worker A confronts two quintessentially modern institutional hazards: first, a controller or platform may fabricate a seedless “algorithmic shell entity” with no real activity record to siphon renewal standing or absorb liability; second, an institution may expand nominal commitments past physical service capacity while still purporting to certify full performance. Durkheim traced anomie to inadequate regulation of relations in the division of labour [@Durkheim1893, bk. III, ch. 1]. The construction below gives a concrete mechanism in terms of registered occurrences and service capacity. Foundation \(\mathcal F_h\) closes both hazards via general universe-polymorphic laws (full definitions and proofs in Supplement Appendix C.7 Propositions C17–C18).

**Proposition 3.2 (No-Free-Seed Renewal Prohibition, Four-Face Pre-Emission Factorization, and the Stable–Critical–Anomie Phase Law).** Across universe-polymorphic process carriers and installed temporal roots, two structural laws hold jointly:

1. **Seedless renewal prohibition, full-settlement elimination, and four-face pre-emission factorization**: Every local renewal face is sealed as a dependent triple of a trace-witnessed source seed, seed-indexed consumer, and local disposition; whenever the source-seed type is empty (\(\operatorname{SourceSeed}(s)=\varnothing\), including the empty artificial-actor seed on the three-agent process), the renewal-face type is strictly empty. Across polymorphic settlements, open-obligation activation plus counterparty acceptance generates purchasing-power standing, whereas full performance of all exchange legs (\(\mathcal O(e)=\varnothing\)) simultaneously empties purchasing-power standing and price observations over every price carrier:
   \[
   \begin{aligned}
   &\bigl(\operatorname{SourceSeed}(s)=\varnothing\Longrightarrow \operatorname{RenewalFace}(s)=\varnothing\bigr)\\
   &\quad\land\ \bigl(\mathcal O(e)=\varnothing\Longrightarrow \operatorname{Standing}(e)=\varnothing\land\mathcal P(e)=\varnothing\bigr),
   \end{aligned}
   \tag{3.6a}
   \]
   relational maintenance independently selects unidirectional control-permission and debt-flow fibers on one occurrence; and trace-witnessed three-agent seeds generate artificial-actor renewal and terminal exit without consciousness or value oracles. Given four compatible projection laws on one root, applying four successive sum-projection lifts \(P\mapsto\mathsf{renewal}\sqcup P\) **prior to root emission** keeps the underlying ledger source and emitter definitionally unchanged, so election mandate, purchasing power, relational maintenance, and trace-witnessed artificial-actor coordinates read their payloads at the same visit \(v\) from one root causal evolution packet, sharing one whole-ledger write-back, non-refilled progress budget (\(B_{\mathrm{op}}\le B_{\mathrm{src}}\)), and one generated next current (whereas post-hoc attachment to an already emitted root is rejected by the type checker).
2. **Position-indexed occurrence-rate queue, monotone three-phase transition, and anomie full-debit prohibition**: Let an installed renewal row fix operational capacity \(C\in\mathbb N\) via its progress budget, and let a focal occurrence-rate compiler index trace positions \(p\in\operatorname{Fin}|\tau|\) into a duplicate-free queue \(Q\) (keeping distinct trace positions distinct even when state and seed recur, while preserving focal lineage). On the exact prefix \(Q_{\le k}=\operatorname{take}_k(Q)\) with \(0\le k\le |Q|\) (rate \(r=k\)), phase classification and the fundamental budget inequality of any native debited maintenance run (\(\mathrm{events}\)) satisfy:
   \[
   \operatorname{phase}(Q_{\le k})=
   \begin{cases}
   \mathrm{stable},&k<C,\\
   \mathrm{critical},&k=C,\\
   \mathrm{anomie},&k>C,
   \end{cases}
   \qquad
   |\mathrm{events}|+b_{\mathrm{end}}\le b_{\mathrm{start}},
   \tag{3.6b}
   \]
   with cuts \(0,C,C+1\) inhabiting all three phases from one source whenever \(0<C<|Q|\). Along prefix order, stability is downward-hereditary, anomie is upward-persistent with strictly growing backlog length \(k-C\) (every backlog unit retaining focal lineage), the critical cut \(k=C\) is unique, and single-step extension \(k'=k+1\) **never jumps from stable directly to anomie without crossing critical**. Aligning initial budget \(b_{\mathrm{start}}=C\) and run length \(|\mathrm{events}|=k\) forces target budget \(b_{\mathrm{end}}=0\) at criticality, while rendering **the type of full native debited runs in anomie (\(k>C\)) strictly empty**.

**Proof.** Part 1: Projecting the seed coordinate of any putative renewal face inhabits \(\operatorname{SourceSeed}(s)\), establishing the left implication of (3.6a); full performance empties \(\mathcal O(e)\), emptying both purchasing-power standing and price observations since each requires an open-settlement witness. Each pre-emission lift expands only the projection index to \(\mathsf{renewal}\sqcup P\) while preserving inherited coordinates via right injection and embedding the new coordinate via left injection; across four lifts, all four coordinates read the identical `canonicalCausalAnswerAndNext` packet with \(B_{\mathrm{op}}\le B_{\mathrm{src}}\).

Part 2: Sigma-list nodup and position projection establish duplicate-free \(Q\) and separation of recurrent visits; natural-number trichotomy \(k<C,k=C,k>C\) yields (3.6b)'s exhaustive phase partition and monotonicity, with \(k<C\Rightarrow k+1\le C\) ruling out one-step jumps over criticality. Every edge in a native debited run enforces strict natural-number decrease \(b'<b\) (\(1+b'\le b\)) on a stable live slot; induction on run length gives \(|\mathrm{events}|+b_{\mathrm{end}}\le b_{\mathrm{start}}\). Substituting \(b_{\mathrm{start}}=C\) and \(|\mathrm{events}|=k\) gives \(C+b_{\mathrm{end}}\le C\Rightarrow b_{\mathrm{end}}=0\) when \(k=C\), and yields the contradiction \(C<k\le k+b_{\mathrm{end}}\le C\) when \(k>C\), emptying full debited runs in anomie (Appendix C.7 Propositions C17–C18). ∎

### 3.7 How Institutions Remember Choices Across Representations

After leaving a job, A chooses and adjusts housing, health, and platform services repeatedly over time. If an institution migrates its database schema or internal encoding, could role changes established by prior actions silently vanish? Goguen and Burstall's theory of abstract *institutions* showed that truth invariance across specification languages rests on compatibility between signature morphisms and satisfaction [@GoguenBurstall1992, §2]. Here we establish a direct universe-polymorphic memory-equivalence theorem over dynamic read-write runs.

Fixing old visit, source index, boundary, and initial payment cycle for the reselection interface, consider the generated reselection run. For each \(n\in\mathbb N\), the program executes the \(n\)-th cross-representation relational action at step \(t_n\), reads the resulting role selection at \(t_n+1\), and enters the next action at \(t_n+2\), so steps advance by
\[
t_{n+1}=t_n+2.
\]
Each target initial state embeds the entire prior history, generates a fresh relation root via its first whole-ledger write as the next step's source root, and retains basic-income obligation processing along every action receipt. Across any three consecutive relational actions, the generated target roles cycle injectively through **tenure, health care, and platform provider**: each action edge flips its downstream role-recognition readout from \(0\) before writing to \(1\) after writing, giving total change \(3\) across the three selected cycle edges; role injectivity fixes all \(3\times 3=9\) read-write phases to \(1\) on the three cycle edges and \(0\) on the remaining six, whose nonzero loop sum (\(3\ne 0\)) again precludes scalar individual potentials.

Denoting this read-write pair by query \(q=(r,w)\) (\(w\) writing the target role, \(r\) reading downstream recognition, \(x\) the pre-write source state, and \(\star\) the proposition “observation changed”), define canonical institutional memory by
\[
M_q(x,\star)\quad\Longleftrightarrow\quad r(w(x))\ne r(x).
\]
Call an encoding-decoding pair \((C,D)\) **sound** if decoding implies actual read-write change, and **complete** if actual read-write change is decoded (inhabited canonically by \(C(x)=M_q(x,-)\)). Then for **any two type universes**, any representation carriers within them, and any two sound and complete representations \((C_1,D_1)\) and \((C_2,D_2)\) for query \(q\),
\[
D_1(C_1(x),\star)
\ \Longleftrightarrow\
M_q(x,\star)
\ \Longleftrightarrow\
D_2(C_2(x),\star).
\]
Regardless of storage universe or naming convention, every sound and complete institutional record decodes the exact same history of which action altered which role observation (full all-depth reselection, nine-phase calculation, and cross-universe proof in Appendix F.9).

## 4 Fourfold Disposition Closure of Constitutional Power and Same-Point Nonempty Realization

### 4.1 How the Root Law Ends the Standoff Between Presupposed *Grundnorm* and Sovereign Exception

Modern constitutional theory has revolved around a multi-sided tension over ultimate legal authority: Kelsen traced the validity of positive norms to a non-positive presupposed basic norm (*Grundnorm*) [@Kelsen1967, §34]; Schmitt contended that no norm applies itself to an exception and defined the sovereign as he who decides on the exception by suspending the legal order in its entirety [@Schmitt1922, ch. 1]; Hart replaced sovereign command with officials' shared *rule of recognition* joined to *rules of change* and *adjudication* [@Hart1961, chs. V–VI]; Ackerman's dualist democracy separated everyday *normal politics* inside established rules from rare moments of higher *constitutional lawmaking* [@Ackerman1991, ch. 1]; and Crawford and Ostrom formalized rule syntax through ADICO institutional grammar [@CrawfordOstrom1995, pp. 583–586]. Yet unless rule amendment is closed together with the whole obligation ledger, the Schmittian and Ackermanian questions linger: when an existing rule genuinely fails on a concrete claim, must amendment rely on extra-legal suspension or informal mobilization? The question here is how a finite formal constitution can separate routine reform from self-amendment via exact failure on the very same obligation row while barring any fifth off-ledger write channel.

Our **root law** delivers a constructive resolution. Submit a request to a complete installed institutional program and denote its generated execution result by \(r\). Once source root, recognition installation, current visit, and scenario are fixed, the program binds submission, response, and claimed effect together (visible content, response, and effect carriers may vary across arbitrary universes, provided execution uses the exact response already generated by the program).

**Definition 4.1 (Four Complete Dispositions).** For a generated execution result \(r\), the four canonical dispositions are:

- **Presentation \(\mathrm P(r)\)**: A lawful observation or provenance-backed explanatory answer under current law and obstruction review, performing no ledger write.
- **Refusal \(\mathrm J(r)\)**: An exact refusal determination paired with the **residual bearer object** preserved in the original generated submission itself (retaining provenance, full obligation record, and downstream decomposition).
- **Action \(\mathrm A(r)\)**: Current-root action authority paired with a complete whole-ledger write-back and its actual successor state—encompassing both sequential transport of existing obligations and full first-write admission of new obligations (Section 6.1).
- **Revision \(\mathrm U(r)\)**: Exact failure of current law on **the same responsibility row**, installed revision authority on that row, the revision first write, and the complete successor relation constraining both inherited old rows and newly generated rows.

Write \(\mathrm W(r)\) for possession of **actual write authority** committing an authorized whole-ledger update to its target.

**Theorem 4.2 (Root-Law Disposition Closure and Exact Write Criterion).** For every source root, recognition installation, visit, scenario, three independently chosen representation types, complete installed program, and generated execution \(r\), the four dispositions are exhaustive:
\[
\mathrm P(r)\lor\mathrm J(r)\lor\mathrm A(r)\lor\mathrm U(r).
\]
Moreover, actual write authority satisfies the exact criterion and mutual exclusion:
\[
\mathrm W(r)\quad\Longleftrightarrow\quad
\mathrm A(r)\lor\mathrm U(r),\qquad
\neg\bigl(\mathrm A(r)\land\mathrm U(r)\bigr).
\]
Presentation and refusal carry empty write authority. Whenever the actual result's same-source law-revision branch is inhabited, that same result \(r\) retains the exact failure, targeted responsibility row, revision first write, and old/new row successor package. **No fifth channel of off-ledger write authority exists.**

**Proof.** Execution first inspects raw submission recognition: presentation yields \(\mathrm P(r)\), while refusal yields exact refusal plus the submission's preserved residual bearer object \(\mathrm J(r)\), both having empty write types by construction. Submissions carrying root authority must read the program's bound response (the installation equality forbids swapping in an unbound response without contradiction): direct answers, obstruction-review answers, and old-language answers fall in \(\mathrm P(r)\); sequential actions and new-obligation admissions (Section 6.1) supply whole-ledger write-back and actual successor in \(\mathrm A(r)\); exact-failure revisions carry same-row failure, revision authority, first write, and two-row successor packages in \(\mathrm U(r)\). This exhausts all constructors. Actual write-back is defined solely on the disjoint sum branches \(\mathrm A(r)\) and \(\mathrm U(r)\), giving \(\mathrm W(r)\iff\mathrm A(r)\lor\mathrm U(r)\) and \(\neg(\mathrm A(r)\land\mathrm U(r))\). Projecting an inhabited same-source revision witness extracts the complete revision package inside \(r\) (Appendix A.2). ∎

![Fourfold complete constitutional dispositions, exclusion of a fifth write channel, and obligation routing](figures/03-root-law-v3-en.svg)

Figure 5. Root-law disposition closure (Theorem 4.2). Every complete installed execution falls into presentation \(\mathrm P\), bearer-retaining refusal \(\mathrm J\), action \(\mathrm A\) (old-obligation transport or new-obligation birth), or same-source law revision \(\mathrm U\); write authority is locked to mutually exclusive \(\mathrm A\) and \(\mathrm U\), eliminating sovereign suspension and off-ledger writes.

Theorem 4.2 dissolves the sovereign-exception dilemma structurally: rule failure neither appeals to an ungrounded meta-norm nor suspends accountability; exact failure on a specific responsibility row is itself the typed trigger activating \(\mathrm U(r)\), replacing authorization while forcing live obligations into the revised first write.

### 4.2 How Source-Backed Submissions Cross an Empty Local Inventory into External Execution

Universal exhaustion in Theorem 4.2 is necessary, yet in logic an empty system processing nothing also satisfies universal implications vacuously. Making the constitution usable for A requires constructing an inhabited constitutional point. Here a sharp structural distinction arises between **where a submission is recognized** and **where whole-ledger execution occurs**.

In our canonical construction, the recognition root receiving raw submissions generates root-authorized submissions \(g\), yet its **local open-obligation inventory is empty**. Because a local complete installed program must hold a local open obligation row at the current root, local action channels at the recognition root are empty. How then is \(g\) handled? Through the source's already registered **external complete-payment transport span \(T\)**. Given old visit, source index, and boundary, the source program extracts from an already generated paid replay an external complete payment, row authority, revision grounds, and actual successor whose source submission matches \(g\)'s originating event:
\[
\operatorname{event}(g)
=\operatorname{event}(T.\operatorname{sourceSubmission}).
\]
The source-end equation certifies that the external bridge handles A's exact submission \(g\), while the target end binds legislation, same-row revision, and independent processing to that one external payment across lawful type transport (Appendix A.3).

### 4.3 Same-Point Nonempty Realization and Two-Tier Conditional Law Revision

We now assemble Section 4.2's external payment bridge and Theorem 4.2's universal root law inside **one and the same constitutional point \(c_m\)**, ensuring that universal constraint on power and inhabited practical recourse hold at a single locus.

For each foundation horizon \(h\in\mathbb N\), take canonical society \(S_h\). Given arbitrary prescribed old-visit parameters, source index, boundary, health depth, finite request parameter \(f\), and observation parameter \(o\), registered recursion generates stage \(m\) and constitutional point \(c_m\). Call \(c_m\) **root-law complete** (\(\operatorname{Complete}(c_m)\)) when three properties hold jointly at \(c_m\): (i) an inhabited witness of root-authorized external complete disposition; (ii) complete raw disposition for every source-generated raw submission across all visit indices, scenarios, and three arbitrary representation types; and (iii) Theorem 4.2's fourfold exhaustion for every complete installed program across the same universal domain. Call \(c_m\) **conditionally revisable** (\(\operatorname{RevAvailable}(c_m)\)) when root-authorized raw submissions obtain complete external revision packages via transport \(T\), and installed executions with inhabited same-source revision branches retain exact failure, same responsibility row, first write, and successor packages.

**Theorem 4.3 (Inhabited Canonical Society and Same-Point Root-Law Completeness).** For all prescribed parameters above, registered recursion in \(S_h\) generates a stage \(m\) and one constitutional point \(c_m\) satisfying
\[
\operatorname{Complete}(c_m)\ \land\
\operatorname{RevAvailable}(c_m).
\]
Inhabited external-payment witness, universal raw-submission classification, universal installed-program classification, and two-tier conditional law revision all belong to the same point \(c_m\).

**Proof.** Extract the initial constitutional object and registered recursion from \(\mathcal F_h\) inside \(S_h\) (Proposition 3.1) and unfold to \(m=f+1>f\) to obtain \(c_m\). Source scenario selection and recognition generate a root-authorized submission bridged by Section 4.2's span \(T\) into an external complete payment, giving the inhabited witness. Quantifying universally over visit indices, scenarios, representation types, and raw submissions yields presentation, refusal, or root-authorized external revision (local action being empty by local inventory emptiness); quantifying universally over complete installed programs applies Theorem 4.2 directly. Packing these witnesses and universal proofs at \(c_m\) yields the conjunction (Appendix A.4). ∎

### 4.4 Sixteen-Point Concrete Social Grammar: Zero-Write Diagnostic Search Alongside Actual Amendment

The root law also instantiates a concrete **16-point social grammar** checking eight institutional requirements across two parallel compilations on the same source occurrence: the **actual scenario** governs live execution, whereas the **total-capture search scenario** retains identical payment, service, and bearer materials to test which exact requirement breaks under total capture. Two scenarios across eight items form sixteen duplicate-free provenance-stamped points.

| Content checked | Actual scenario | Total-capture search scenario |
| --- | --- | --- |
| Complete obligation update | Current whole-ledger evolution passes | Retains identical whole-ledger material |
| Actual service exit | Occurrence's actual exit passes | Retains actual exit material |
| New-birth bearer exit | Obtained from the same actual exit | Retains bearer material |
| Bearer exercise response | Exercise response of same exit passes | Retains response material |
| Bearer leave execution | Leave execution of same exit passes | Retains execution material |
| Extra-role bearer continuation | Actionable continuation passes | Actionable continuation fails under total capture |
| Tenure access | Relation and actual exit pass jointly | Retains identical access material |
| Health-service access | Relation and actual exit pass jointly | Retains identical access material |

Table 2: Sixteen-point social grammar on one source occurrence. All eight items pass in the actual scenario, while the total-capture search scenario isolates failure at item 6 (extra-role continuation) while preserving all other paid materials.

Table 2 enforces a vital constitutional safeguard: actual and search compilations share the same recognition item, visit, full ledger, and actual next state—so diagnostic audit inspects the genuine institutional books—yet actual write authority requires matching the installed **actual scenario**. Because the total-capture search scenario differs from the actual scenario, its write-authority type is strictly empty and its ledger disposition is the identity map. **Diagnostic audit can inspect every real entry without possessing authority to alter the ledger; actual writing and law revision belong exclusively to authorized execution.**

Embedding this 16-point grammar into any cycle \(C\) of Section 1.5 (and any full constitutional proof \(Q_C\) for \(C\)) yields, at every observation parameter \(o\) and depth \(d\), one realization point jointly carrying root-law transition to the next step, exact total-capture search failure, actual same-source law revision at step \(d\), and successor alignment with
\[
C_{d+1}=\operatorname{nextCycle}(\operatorname{step}(C,d)).
\]
(With lifecycle origin \(i_d\), grammar sits at \(i_d+2\) and its successor at \(i_d+3\).) Consequently, for all finite request parameters \(f,o\), evaluating at the same stage \(m\) supplied by the request proof inhabits the joint product:
\[
\forall f,o\ \exists m:\quad
\operatorname{Nonempty}\bigl(
\mathsf{Req}_{C,f,o,m}\times
\mathsf{Joint}_{Q_C,o,m}\bigr).
\]
Zero-write diagnostic safety and live self-amendment thus hold together at every requested finite depth (full 16-point fold, universe-polymorphic observation classification, and transports in Appendix F.6).

### 4.5 Reform, Same-Source Constitutional Revision, Terminal Rupture, and Same-Occurrence Proof-Carrying Legislation

Ackerman's dualist constitutionalism leaves open a sharp formal question: must separating ordinary within-rule reform from higher constitutional lawmaking rely on retrospective political interpretation or external discretion [@Ackerman1991, ch. 1]? And what exact mathematical line separates genuine constitutional self-revision from Schmittian order-breaking rupture [@Schmitt1922, ch. 1]? Without supplying any external branch tag, policy target, or desired law surface, one sealed inquiry runtime **automatically and exhaustively** classifies active decisions as reform or same-source constitutional revolution. A separate terminal occurrence with a discharge witness has no same-ledger successor. The construction realizes **proof-carrying legislation** on one literal occurrence (full formalization in Supplement Appendix C.7 Theorem C19).

**Theorem 4.4 (Reform and Revision at Active Occurrences, Terminal Rupture, and Same-Occurrence Proof-Carrying Legislation).** Let \(\rho\) be any sealed inquiry runtime over any source-native inquiry process, \(d\in\mathbb N\) any recursion depth, and \(\tau_d=\rho.\operatorname{tickAt}(d)\) the unique active occurrence following finite macro prefix \(\rho.\operatorname{run}(d)\). Three conclusions hold jointly:

1. **Zero-choice endogenous reform/revolution dichotomy and two-step continuation**: Without any supplied branch tag or revision core, exhaustive dependent elimination on \(\tau_d\)'s compiler resolution splits execution into two mutually exclusive updates:
   \[
   \begin{aligned}
   &\operatorname{kind}(\tau_d)=\mathrm{reform}\\
   &\quad\lor\ \bigl(\operatorname{kind}(\tau_d)=\mathrm{revolution}\land \operatorname{next}(q_{\mathrm{old}})=\operatorname{next}(q_{\mathrm{new}})\bigr),
   \end{aligned}
   \tag{4.5a}
   \]
   where direct answers, obstruction-review answers, old-language answers, and sequential actions receive the reform tag and carry the successors specified by their own resolutions. When a root-installed renewal supplies a bounded same-law reform, the selected row retains its debt lineage and law surface and its progress budget does not refill. solely the exact revision constructor resolves to **rooted same-source constitutional revolution**—consuming dual emptiness of old expression and old realization on the same open responsibility row (absent an installed failure face, direct same-row revolution producers are strictly empty), generating the unique initial minimal coface (whose fresh obstruction row has no old-ledger preimage), performing the revised living root's first write, and uniting the migrated old row \(q_{\mathrm{old}}\) and fresh obstruction row \(q_{\mathrm{new}}\) onto one identical heterogeneous revised next state. The canonical runtime automatically triggers constitutional revolution at \(d=0\) and enters ordinary same-law reform inside that revised living root at \(d=1\) without reverting to the pre-revision law.
2. **Source-owned authoritative terminal rupture control**: On a faithful terminal occurrence admitting no actual successor, source-owned institutional rupture faithfully discharges the existing residual obligation row while rendering the **same-ledger generated-successor type strictly empty**, constructively excluding every root-installed renewal and bounded same-law reform; on a fully expressive root-semantic surface, the failure fiber required to trigger same-source constitutional revision is empty.
3. **Fourfold heterogeneous splice and literal same-occurrence proof-carrying legislation**: Whenever a pre-emission installed renewal coordinate \(I_{\mathrm{inst}}\) (locking local domain consumer, full lifecycle compilation, existing unsettled residual bearer, and observer vertical-automorphism kernel pair) splices onto \(\tau_d\) via four heterogeneous equalities across root, temporal visit, open responsibility row, and exact temporal-causal occurrence,
   \[
   \operatorname{root}(\tau_d)\simeq R_{\mathrm{inst}},\quad
   \operatorname{visit}(\tau_d)\simeq v_{\mathrm{inst}},\quad
   \operatorname{row}(\tau_d)\simeq \delta_{\mathrm{inst}},\quad
   \operatorname{occ}(\tau_d)\simeq \omega_{\mathrm{inst}},
   \tag{4.5b}
   \]
   zero-choice proof-carrying legislation exports existing residual-bearer retention, observer-kernel retention, whole-ledger write-back factorization, and automatic reform/revolution successor handoff on **one and the same literal occurrence** without external policy discretion (automatically extracting full revolutionary consumption and shared two-row successor at \(d=0\) on the joint runtime).

**Proof.** Part 1: Answered nodes have empty query fibers, so activation uniquely fixes \(\tau_d\). The four non-revision constructors have the reform tag, proving the left disjunct of (4.5a). Bounded reform with a root-installed renewal preserves lineage, the budget bound, and the law surface on its selected row. on `.revised`, same-row boundary equality feeds dual expression/realization emptiness into the unique initial minimal coface (an old preimage for the fresh row would fold the new direction back into the old language, while missing an installed failure face blocks constructing a same-row rooted gate), and both post-first-write row consumers read the identical generated successor by construction, proving the right disjunct. Unfolding the canonical runtime yields `.revised` at \(d=0\) and `.directlyAnswered` inside the revised root at \(d=1\).

Part 2: The terminal occurrence supplies the residual discharge receipt while its inventory admission rests on absence of actual successors, refuting any same-ledger successor or installed renewal; the root-semantic surface expresses every obstruction natively, emptying expressibility failure.

Part 3: Transporting along the four `HEq` identifications in (4.5b) aligns the pre-emission renewal payload with \(\tau_d\)'s whole-ledger evolution at one temporal-causal occurrence; Proposition 3.2(1) yields whole-ledger factorization while Part 1's dependent elimination extracts the endogenous reform/revolution classification and successor on that literal occurrence (Appendix C.7 Theorem C19). ∎

## 5 Genuine Exit, Diagnostic Impossibility, and the Observer-Kernel Authority Boundary

### 5.1 Does Worker A Possess an Actionable Exit? The Five-Gate Bipartite Matching Theorem

Hirschman analyzed exit and voice as interacting responses to organizational decline: when departure routes are blocked or prohibitively costly, exit loses credibility and internal voice withers [@Hirschman1970, pp. 3–4, 35–36, 81–82]; Widerquist placed independent access to basic living resources sufficient to refuse unwanted cooperation at the center of substantive freedom [@Widerquist2013]. A's post-departure situation sits squarely at their intersection: can A genuinely step out of subordination, and what sustains life afterward?

At depth \(d\) of canonical society \(S_h\), A's former employment role has ended, yet A remains both the claimant of living support and the bearer of pending responsibility row \(\delta\). Turning A's request into an actionable exit requires connecting one continuation action, current complete payment \(p_d\), and actual service performance on the same occurrence structure. From the finite candidate action inventory \(C_d\) supplied by the source program, take action \(c\): write \(R_d(c)\) for continuation in an exit relation distinct from the ended employment, \(I_d(c)\) for idleness, \(H_d(c)\) for capture by controller B, and \(P_d(c)\) for valid payment-incidence evidence from \(p_d\) for \(c\). Let \(J_d\) be the index set of services actually fulfilled in the current settlement, with \(j\in J_d\) pointing to service \(s_j\), and write \(T_d(c,j)\) for route incidence connecting action \(c\) along a usable route \(\pi\) to \(s_j\). Define a **feasible exit edge** by
\[
E_d(c,j)\quad\Longleftrightarrow\quad
R_d(c)\land\neg I_d(c)\land\neg H_d(c)
\land P_d(c)\land T_d(c,j).
\]
This forms an explicit finite bipartite graph between candidate actions on the left and actually served slots on the right: an edge exists if and only if all five gates open on **one and the same pair \((c,j)\)**. Attaching payment to one action, a route to a second, and service to another run fails to construct a usable path out.

**Theorem 5.1 (Five-Gate Necessary and Sufficient Condition for Genuine Exit).** For every foundation horizon \(h\) and depth \(d\), the source program generates a genuine extra-role exit continuation for A if and only if
\[
\exists c\in C_d,\ \exists j\in J_d,\quad E_d(c,j).
\]
Extra-role continuation, nonidleness, noncapture, payment incidence, and route incidence must hold on the same \((c,j)\), with served slot \(j\) drawn from the actual run indexed by \(p_d\).

**Proof.** Forward: project action \(c\), served slot \(j\), and feasible-edge evidence directly from any genuine exit continuation; the edge retains \(R_d(c),\neg I_d(c),\neg H_d(c),P_d(c),T_d(c,j)\) with \(j\in J_d\), yielding the right-hand side. Converse: given \((c,j)\) satisfying \(E_d(c,j)\), settlement connects served slot \(j\) to the same-ordinal event in the actual run and supplies its service receipt; combining that receipt with payment incidence from \(p_d\), route \(\pi\), extra-role continuation, and noncapture constructs the complete feasible edge from which the exit generator produces actual continuation. Both directions preserve the identical action, slot, and occurrence index. ∎

Define **exit capacity \(K_d\)** as the maximum matching size of the finite bipartite graph \(E_d\). Because a matching uses each action and each served slot at most once, it counts simultaneously supportable independent exits, giving
\[
K_d>0\quad\Longleftrightarrow\quad
\text{genuine exit continuation is inhabited}.
\]
As checked in Example 1.1(1), the canonical instance has \(3\) queued requests, physical service capacity \(2\), and \(2\) actually served slots; pairing the unique surviving leave action with a served slot yields maximum matching size \(K_d=1\) while preserving the unserved record of request \(3\).

Both the five gates and bearer-service alignment are **independently necessary** (Appendix F.10): first, at every depth \(d\), the route-outage construction retains actual payment, service, obligation row, whole-ledger successor, and seven other installed renewal operations while the source route-receipt type is empty—all remaining materials still cannot construct a route until repair at the next visit restores \(K=1\); second, at one post-settlement occurrence, the tenure channel's receipt aligns literally with bearer A, whereas the health channel retains genuine service, payment, and successor under a distinct registered actor, leaving exact alignment to A strictly empty. Institutions must not merely produce services, but connect them to the affected bearer.

### 5.2 Three Zeros and Two Ones: Why Exact Capability Measurement Cannot Diagnose Institutional Failure

When \(K_d=0\), A cannot leave; yet the exact score “zero” reveals nothing about which institutional barrier blocks departure. Fixing complete payment, bearer A, and exit interest, construct three provenance-distinct comparison branches: total capture \(z_{\mathrm c}\) (payment, route, and service intact, but continuation captured by B), missing payment incidence \(z_{\mathrm p}\) (underlying complete payment intact, lacking incidence to the candidate action), and missing route incidence \(z_{\mathrm r}\) (payment and service intact, lacking route connection).

**Proposition 5.2 (Non-Identifiability of Source and Portfolio Completeness from Capacity).** For every depth \(d\), the three provenance-bearing objects \(z_{\mathrm c},z_{\mathrm p},z_{\mathrm r}\in Z_d\) are pairwise distinct and satisfy
\[
K(z_{\mathrm c})=K(z_{\mathrm p})=K(z_{\mathrm r})=0.
\]
No recovery function \(g:\mathbb N\to Z_d\) satisfies \(g(K(z))=z\) for all \(z\in Z_d\).

**Proof.** Total capture eliminates noncaptured actions, missing payment incidence removes payment evidence from every candidate edge, and missing route incidence removes route evidence; all three have empty feasible-edge sets and hence matching capacity \(0\). Distinct provenance constructors make them pairwise unequal. Any \(g\) recovering sources from capacity would force
\[
z_{\mathrm c}=g(0)=z_{\mathrm p},
\]
contradicting \(z_{\mathrm c}\ne z_{\mathrm p}\). ∎

**“Two ones” and missing portfolio completeness at positive capacity.** Even when exit is genuinely feasible (\(K=1\)), scalar capacity conceals structural deprivation in essential living domains. Define a **complete capability portfolio** across the installed tenure and health domains as the dependent product of each domain's actor, relation, actual service, route, and feasible continuation. At every depth \(d\), the generator supplies full source \(x_d\) and single-service source \(y_d\) sharing the identical root occurrence, payment occurrence, and payment/route rules:

| Actual source | Tenure service | Health service | Exit capacity | Complete portfolio |
| --- | --- | --- | --- | --- |
| \(x_d\) | Fulfilled | Fulfilled | \(1\) | Inhabited |
| \(y_d\) | Fulfilled | No corresponding service occurrence | \(1\) | Empty |

Table 3: The “two ones” contrast at positive exit capacity. Both sources possess a genuine feasible exit (\(K=1\)), yet the single-service source lacks health service fulfillment; no capacity-only predicate \(q:\mathbb N\to\mathrm{Prop}\) correctly classifies portfolio completeness on both sources.

**Proof.** Full source \(x_d\) obtains two distinct paid slots in the queue prefix, inhabiting the complete portfolio; single-service source \(y_d\) executes only slot \(0\), while the installed rule assigns health to another slot, leaving health-service witnesses empty. Both have a single nonidle leave action forming a maximum matching of size \(1\), so \(K(x_d)=K(y_d)=1\). Any classifier \(q:\mathbb N\to\mathrm{Prop}\) true on \(x_d\) gives \(q(1)\), forcing an inhabited portfolio on \(y_d\), a contradiction (Appendix F.1). ∎

Diagnostic blindness immediately causes repair failure. Evaluating the two candidate operations (“remove capture” and “restore route”) on capture failure \(f_{\mathrm c}\) and uncaptured route bottleneck \(f_{\mathrm r}\) yields the diagonal post-repair capacity matrix:
\[
\begin{array}{c|cc}
 & \text{remove capture} & \text{restore route}\\ \hline
f_{\mathrm c} & 1 & 0\\
f_{\mathrm r} & 0 & 1
\end{array}.
\]

**Proposition 5.3 (Impossibility of Exact Repair Selection from Capacity).** At every depth \(d\), across the two failures and two candidate repairs above, no repair selector reading only the pre-repair capacities of both failures is effective for both sources, nor can any function recover each source's canonical repair from capacity.

**Proof.** Removing capture restores \(f_{\mathrm c}\) to capacity \(1\) while leaving route-deficient \(f_{\mathrm r}\) at \(0\); restoring the route brings \(f_{\mathrm r}\) to capacity \(1\) while leaving captured \(f_{\mathrm c}\) at \(0\). Each row admits a unique, distinct effective repair. Because both failures read capacity \(0\) prior to repair, any capacity-only selector returns one identical operation for both, leaving the other at \(0\); nor can a single value \(g(0)\) equal two distinct canonical repairs. ∎

### 5.3 The Institutional Division of Labor Between Ordinary Repair and Same-Source Law Revision

Removing capture or repairing a broken route restores A's continuation under existing law; when the existing rule itself causes the obstruction, case-by-case repair cannot substitute for amending the law. Our construction separates the two tasks sharply: **ordinary repair** preserves pre-repair law, obligation lineage, and inherited rows, writes back the full ledger, and runs the installed target repair program at the next visit; **same-source law revision** extracts exact failure grounds on the same obligation row from within the failure, invokes installed revision authority to introduce a fresh expressive direction, executes the revision first write, and migrates live obligations into the revised law. The policy rupture at depth zero supplies both coordinates from one shared rupture source, generating successors proved structurally unequal in Theorem 6.3.

### 5.4 First Refusal and Recourse Through the Node's Own Payment: Closing a Wrong Door Without Locking Out the Bearer

What should happen when a genuinely valid payment credential is submitted to the wrong processing node? Accepting a mismatched credential would destroy provenance verification; yet refusing the submission while freezing the bearer's legitimate standing and native payment at that node would turn procedural checking into confiscation.

Suppose a finite sequence of nodes each generates and recognizes its own native payment \(q_i\) while receiving external candidate payment \(a_i\) (acceptance requiring \(a_i=q_i\)). Submit node \(1\)'s genuine payment to node \(0\): distinct boundary identities give \(q_0\ne q_1\), forcing refusal of the external submission, while node \(0\)'s own payment \(q_0\), bearer standing, and service relations remain intact.

**Proposition 5.4 (First Refusal and Recourse Through the Node's Native Payment).** For every initial source cycle and finite external proposal sequence, if the set of mismatching nodes is nonempty, its least element \(r\) is the unique first refusal, preserved under every prefix-preserving extension. At node \(r\), external acceptance and every operation depending on external acceptance are strictly empty; yet node \(r\)'s canonical execution, actual successor, and earlier paid prefix effects all persist. The native payment \(q_r\) already present at node \(r\) generates ordinary repair, preserving that node's existing bearer standing without re-selecting a bearer, and produces a genuine capacity-\(1\) exit successor and next visit \(v_{d_r+1}\) strictly distinct from node \(r\)'s canonical revising-legislation successor. At every finite recursion depth, adjacent-node payment misdirection inhabits this refusal and recourse.

**Proof.** Every nonempty finite subset of \(\mathbb N\) has a unique least element \(r\) determined solely by matches below \(r\) and mismatch at \(r\). Empty external acceptance empties every dependent operation type. Meanwhile, node \(r\)'s canonical execution consumes its own native \(q_r\) independently of \(a_r\), preserving legislation, successor, and prefix effects. Extracting service authority from node \(r\)'s existing replay fixes repair depth \(d_r\) and transports \(q_r\) lawfully onto the depth-\(d_r\) cycle payment, driving ordinary repair from the existing bearer standing to deliver full write-back, capacity-\(1\) exit continuation, and \(v_{d_r+1}\). Finally, ordinary repair's current-state carrier is a singleton (cardinality \(1\)), whereas canonical revising legislation at node \(r\) has carrier \(\mathbb N\) (infinite), preventing successor equality (Appendix A.5). ∎

![First refusal of a misdirected genuine payment and recourse through the receiving node's native payment](figures/04-refusal-v3-en.svg)

Figure 6. First refusal and recourse through the node's own payment (Proposition 5.4). A genuine external payment misdirected to node \(r\) is refused for boundary mismatch (empty external acceptance), yet the receiving node continues running: its native payment \(q_r\) preserves the bearer's standing and generates capacity-\(1\) ordinary-repair exit continuation.

### 5.5 How Personal Exit Unfolds Across Time into a Four-Stage Course of Life

Exit is not an instantaneous button press, but a temporal relay: who authorizes departure at the outset, when does action actually sever employment, which subsequent payment sustains extra-role life, and how do external obligations continue afterward?

Fixing old-visit parameter \(o\), source index \(a\), and lifecycle origin \(i\), the lifecycle program generates four occurrences \(e_0,e_1,e_2,e_3\) at \(i,i+1,i+2,i+3\), with complete payments \(p_0,p_1,p_2\) belonging to the first three occurrences:

| Stage | Actual content obtained at this occurrence |
| --- | --- |
| \(e_0\) | A's exit action carries \(p_0\)'s own root read and provenance authority; \(p_0\) generates the next occurrence. |
| \(e_1\) | The new occurrence reauthorizes the same leave action; A executes it personally, shifting the employment relation from employed to released and ending the former job option. |
| \(e_2\) | Executed payment \(p_1\)'s actual successor supplies an independent extra-role continuation relation; the leave action remains nonidle and uncaptured with all essential-service channels, external-liability provenance, and independent processing intact. |
| \(e_3\) | Continuation payment \(p_2\) generates a further occurrence retaining source-backed services, obligations, and whole-ledger successor. |

Table 4: Four-stage lifecycle structure of actual exit. Contract termination (\(e_1\)) and extra-role life support (\(e_2,e_3\)) interlock through actual payment edges.

**Theorem 5.5 (Complete Four-Stage Lifecycle of Actual Exit).** For every old-visit parameter \(o\), source index \(a\), and origin \(i\), the four-stage object and three payment edges are inhabited and satisfy exact dependent successor equalities:
\[
 \operatorname{next}(p_0)\simeq e_1,\qquad
 \operatorname{next}(p_1)\simeq e_2,\qquad
 \operatorname{next}(p_2)\simeq e_3,
 \tag{5.5a}
\]
where \(\simeq\) denotes exact heterogeneous equality across the dependent occurrence types. Writing \(R_i(c)\) for the temporal contract locking all three actual payment edges, personal exercise, extra-role continuation, external liability, and service successors to action code \(c\), and \(S_i(c,j)\) for \(c\) belonging to the action inventory with extra-role continuation, nonidleness, noncapture, same-source payment, and route to the \(j\)-th actual service, the lifecycle satisfies the exact characterization:
\[
 \text{complete exit lifecycle}(o,a,i)
 \quad\Longleftrightarrow\quad
 \exists c,j\; S_i(c,j)\land R_i(c).
 \tag{5.5b}
\]
All four stages read out the identical visible “leave” action code, yet both the stage-to-outer-authority map and the stage-to-actual-service map are injective, so the static action code admits no left inverse recovering stages. Replacing noncapture by total capture preserves all payments, employment loss, exit interest, bare extra-role future, external liability, and service successors while rendering actionable exit renewal strictly empty.

**Proof.** Payment \(p_0\) generates \(e_1\) at \(i+1\), which re-reads personal leave authority and executes role transition from employed to released. Executed payment \(p_1\)'s successor reaches \(e_2\) at \(i+2\), where source and target roles are independent of employment and the leave code retains nonidle uncaptured continuation; \(e_2\)'s native payment \(p_2\) supplies external-liability provenance, all essential-service witnesses, and \(e_3\), establishing (5.5a). Extracting the feasible edge from a complete lifecycle gives \(S_i(c,j)\) alongside \(R_i(c)\); conversely, assembling \(S_i(c,j)\) into the feasible edge and joining \(R_i(c)\) reconstructs the full lifecycle directly without circularly assuming success, proving (5.5b). Root visit coordinates strictly increase as \(i+s\) (\(s\in\{0,1,2,3\}\)), forcing injectivity of authority and service occurrences; total capture eliminates the sole nonidle extra-role leave code (Appendix E.3). ∎

### 5.6 Structural Anti-Retaliation: Administrative Relabeling Cannot Strip Post-Refusal Independence

Once A exercises the power to leave, could a former controller or downstream bureaucracy retaliate after the fact—by reclassifying policy categories, swapping service directories, stamping a “captured” administrative label, or rewriting employment records—to strip A's independent continuation? To foreclose retroactive retaliation at the root, the lifecycle program embeds the institutional response directly inside the target payment: indexed by A's chosen leave action, it extracts its bearer from that payment's own root read and carries an explicit proof of noncapture.

**Theorem 5.6 (Structural Anti-Retaliation Theorem).** For all \(o,a,i\), the renewed target payment generates a provenance-fixed response whose action is literally A's chosen leave action, jointly retaining: (1) the distinct provenances of bearer A's power to leave and a separate controller's power to terminate, actual employment loss, and actor inequality between controller and worker; (2) actual fulfillment, independent processing, and payment successor on every installed essential-service channel; and (3) provenance ownership, root processing, and next-occurrence generation for external obligation.

For this leave action, capacity equals \(1\) under uncaptured geometry and \(0\) under total capture. **Four exact retaliatory retypings** retaining that target payment and response while reporting its action as captured—**policy, service, administrative, and employment retypings**—are all **strictly empty types**. Moreover, for every Boolean administrative labeling of this lifecycle's occurrence domain, label readouts can recover neither the occurrence nor its actual-service authority.

**Proof.** Response, bearer, and leave-action projections all belong to one target payment, identifying the response action literally with the exercised action and applying its built-in noncapture proof directly; channel processors and external obligations read the same target payment. Each of the four retaliatory retypings adjoins capture of that same action to the positive response, contradicting its noncapture proof and emptying the type. Under any Boolean administrative label, source and target occurrences share identical old administrative restriction readouts while carrying strictly distinct authority coordinates and service occurrences, barring any left inverse or authority factorization (Appendix E.4). ∎

### 5.7 Tenure and Mandate Exits with Maximum-Seed Office Succession

Wage employment is only one relation from which people exit. Incomplete-contract theory bundles uncontracted “residual rights of control” into private asset ownership, treating exclusion from physical assets as the central lever of organizational authority [@HartMoore1990]. Yet ending a housing or land **tenure** relation, or stepping down from a public **mandate** or office, shows why freedom and accountability require **unbundling usage authority, completed-duty archiving, and personal continuation by provenance**: the provenance-generated **common bearer** carries life support across relations while obligations inside each relation close or pass cleanly to a new holder without private appropriation.

**Proposition 5.7 (Two Non-Employment Relation Exits and Office Succession).** For every payment-cycle entry, observation parameter, and depth \(d\), the relation generator constructs two complete instances:

1. **Tenure exit**: The relation seed generates action power, nonzero phase, and entitlement loss with payment purpose identifying tenure; its subject and departing worker A share the identical parent bearer; the root law's actual scenario admits this coordinate exactly once, and the depth-\(d\) exit constitution supplies extra-role continuation, source-backed payment, route, external liability, and services (\(K=1\)), while total capture preserves nominal transfer yet empties exit renewal.
2. **Mandate exit and \(m+1\) office succession**: Previously restored power, renewal phase, and held role drive a sequential exit action placing its target into **lost power, exit phase, and exited role** while sealing completed mandate obligations inside a **terminal archive** (any retyping as restored, renewed, or held is empty by constructor clash); the action's source occurrence aligns heterogeneously with the depth-\(d+1\) constitution payment's root occurrence, completing first whole-ledger write and macro successor while preserving law revision and compatible future. Immediately at the post-exit visit actually reached, a second actual action records the completed exit history, folds the maximum controller seed \(m\) across that history, and generates **fresh controller seed \(m+1\)** (strictly distinct from every prior holder): the office persists, the terminal archive never reopens, the successor assumes a live newly admitted obligation from their own provenance, and depth-\(d+2\) services, routes, extra-role continuation, and joint regeneration all hold (Appendix F.7).

**Proof.** Tenure merges payment-counterparty and departing-worker provenance onto the shared parent bearer and extracts a feasible edge from exact-once 16-point grammar admission and finite-constitution elimination. Mandate chains heterogeneous visit alignment with presentation transport to establish the exit bridge, then applies uniqueness of the maximum-seed fold on post-exit history to obtain \(m+1>m\). Equal old and new obligations would force equal bearers, contradicting \(m+1>m\); the exit action's actual successor is literally the succession action's source, bridged by two presentation transports into depth-\(d+2\) regeneration. ∎

### 5.8 Non-Substitutable Separation of Basic Income, Basic Public Services, and Paid Jobs

Contemporary social-policy debates frequently pit universal basic income (UBI), universal basic services (UBS), and job guarantees (JG) against one another as rival cure-alls. Our formal construction proves that **basic income, basic public services, and paid jobs perform structurally distinct, non-substitutable tasks**.

Basic income renews extra-role purchasing power so A need not trade obedience for subsistence while waiting, caregiving, or relocating; basic public services must commit physical capacity, debit maintenance budgets, allocate specific slots, and open usable routes to turn purchasing power into actual housing or health care; a new paid job establishes labor and remuneration in a new role. Concretely, the served sequence indexed by the current payment has **exactly two slots**, already occupied by tenure and health—so the **fiber of third material service admission into those two existing slots is strictly empty**! Neither positive exit (\(K=1\)) nor new job standing can conjure a third service out of two occupied slots; a third platform material service requires a **fresh occurrence** in the platform lineage (cycling back to the same bearer in three relational steps with a new occurrence identity, admitting maintenance liability, debiting its own service budget \(1\to 0\), and archiving native fulfillment).

**Proposition 5.8 (Actual Separation of Basic Income, Public Services, and Job Standing).** For every payment-cycle entry and finite observation and recursion parameters, there exists a later constitutional point where positive extra-role exit, fulfilled platform material service, and job standing in a new role coexist (former-job standing being empty, while new-role job standing can coexist both with positive exit and with captured zero exit). Meanwhile, the fiber of third material admission into the existing two slots remains strictly empty, so neither positive exit nor new job standing can construct an inhabitant of that old fiber, nor can fulfilled new material service plus new job standing construct exit under total capture.

**Proof.** Co-assemble Theorem 4.3's constitutional point (positive exit, empty captured exit, ended former employment, new job standing) with full platform admission on the same cycle (fresh-occurrence material service, \(1\to 0\) budget debit, fulfillment archive, retention of both old slots). Every non-substitution claim rules out a function from an inhabited constructed source into an exact empty target: applying any putative substitution function to the constructed witness would inhabit the empty type, a contradiction (Appendix E.11). ∎

Proposition 5.8 clarifies what “unconditional” means institutionally: **renewal of basic standing requires neither keeping a former job, proving destitution, nor passing a behavioral obedience test**, keeping the power to say no in A's hands—while physical service capacity, maintenance budgets, and performance receipts must each be paid from their own actual sources.

### 5.9 Shortest Actual Recovery Paths and Literal-Prefix Viable Continuation

Once repair is authorized, what is the minimum number of actual operations needed to recover a viable life, and do shorter plans remain literally consistent inside longer horizons without backtracking? Using Section 5.2's two-domain portfolio, call a configuration **viable (\(\operatorname{Viable}\))** when it jointly carries a complete portfolio, an uncaptured leave action, and a compatible economic disposition. At every depth \(d\), the source program supplies two nonviable failure configurations: health-deficient \(M_d\) (\(K=1\) with incomplete portfolio) and totally captured \(C_d\) (services intact with \(K=0\), including tenure-based structural rent capture); their respective repairs reach viable uncaptured configuration \(V_d\) at visit depth \(d+1\).

**Theorem 5.9 (Shortest Actual Recovery, Literal Prefixes, and Arbitrary-Horizon Viable Continuation).** For every foundation parameter \(h\), starting depth \(d\), and requested continuation horizon \(n\in\mathbb N\), the recovery program generates service-restoration edge \(a_d:M_d\to V_d\), capture-removal edge \(b_d:C_d\to V_d\), and renewal edge \(r_d:V_d\to V_{d+1}\) with pairwise distinct operational authorities. Both repair edges have length \(1\), attaining the **global minimum length over all legal candidate paths** carrying a viable target from their respective sources; their minimal recovery times both equal \(1\), yet the time readout admits no left inverse recovering the two distinct repair operations.

From \(V_d\), the renewal program recursively generates viable continuation path \(\rho_{d,n}:V_d\to V_{d+n}\) satisfying
\[
 |\rho_{d,n}|=n,\qquad
 |a_d\cdot\rho_{d,n}|=|b_d\cdot\rho_{d,n}|=n+1,
 \tag{5.9a}
\]
and for every intermediate horizon \(k\le n\), an exact suffix \(\sigma_{d,k,n}\) satisfies **literal path equality**:
\[
 \rho_{d,k}\cdot\sigma_{d,k,n}=\rho_{d,n},
 \qquad \operatorname{Viable}(V_{d+k})\ne\varnothing.
 \tag{5.9b}
\]
Tenure-generated structural rent capture (retaining payment, routes, services, and processing while emptying feasible exit edges in every essential domain) likewise reaches \(V_d\) in one step via \(b_d\) and composes with \(\rho_{d,n}\) for every \(n\).

**Proof.** \(M_d\) lacks a health witness and \(C_d\) captures the leave action, so both are nonviable; any length-\(0\) path equates target with nonviable source, forcing every legal recovery candidate to have length \(\ge 1\), which length-\(1\) edges \(a_d,b_d\) attain. Distinct sum-type constructors separate \(a_d\) and \(b_d\), ruling out a left inverse on constant time \(1\). Recursive concatenation of \(r_{d+k}\) joins each portfolio's payment occurrence to the next service occurrence while keeping \(\operatorname{Viable}(V_{d+k})\) inhabited; induction on \(n\ge k\) appending the identical final edge establishes literal equality in (5.9b) (Appendix F.2). ∎

### 5.10 All-Universe Post-Processing Impossibility for Full-Domain Readouts and Provenance Refinement

Could an institution overcome Section 5.2's scalar blindness simply by recording reachability across **every installed domain** simultaneously, or feeding that multidimensional panel into an arbitrarily sophisticated classifier or high-dimensional encoding? Theorem 5.10 proves a categorical no.

Let \(\mathcal D\) be the full set of source-generated essential-access relation authorities (including tenure and health). At depth \(d\), failure-source type \(\Omega_d\) contains tenure-control capture and uncaptured route interruption. Define the **full-domain multidimensional reachability readout**:
\[
\rho_d(x)=
\bigl(K_d(x),\{D\in\mathcal D\mid
\text{source }x\text{ has an actually feasible exit edge in }D\}\bigr).
\]
Write \(r_d(x)\) for the canonical repair generated from \(x\) by the installed rule. Both failure sources evaluate to the identical multidimensional readout \((0,\varnothing)\), while requiring distinct canonical repairs (“remove capture” versus “restore route”). Imposing symmetric label fairness (**naturality** under admissible source symmetries exchanging the two constructors) rules out arbitrary tie-breaking sections as well.

**Theorem 5.10 (All-Universe Diagnostic Impossibility for Full-Domain Readouts and Provenance Recovery).** For every depth \(d\in\mathbb N\), full-domain readout \(\rho_d\) possesses an exact source kernel on \(\Omega_d\) with distinct sources, identical visible readout \((0,\varnothing)\), and distinct canonical repairs, together with a fixed-point-free involution of \(\Omega_d\) preserving \(\rho_d\) while swapping the two canonical repairs. Consequently, canonical repair does not factor through \(\rho_d\), no left inverse recovers every source, and no faithful authority reconstruction, natural proxy section, or natural authority reconstruction exists.

This impossibility blocks **every post-processing pipeline** factored through \(\rho_d\): for **every output type universe**, every output carrier \(Y\), and every readout \(q:\Omega_d\to Y\), whenever \(f\) satisfies
\[
q=f\circ\rho_d,
\]
no decoder \(g:Y\to\operatorname{Repair}\) satisfies \(g(q(x))=r_d(x)\) for all \(x\in\Omega_d\).

Conversely, retaining the **failure kind \(\phi(x)\)** already present in the source prior to repair yields refined readout
\[
\widehat\rho_d(x)=(\rho_d(x),\phi(x)),
\]
which preserves \(\rho_d\), is injective on \(\Omega_d\), and enables the installed rule \(R_d\) to factor canonical repair directly:
\[
r_d(x)=R_d(\phi(x)).
\]
Every \(x\in\Omega_d\) thereby generates a proof-carrying geometric plan restoring capacity to \(1\), with a candidate repair effective if and only if it equals \(r_d(x)\).

**Proof.** Capture blocks independent exit edges in every \(D\in\mathcal D\), while route interruption empties route receipts in every \(D\in\mathcal D\), giving \(\rho_d=(0,\varnothing)\) on both while \(r_d\) differs. If \(q=f\circ\rho_d\) and \(g\circ q=r_d\), equal \(\rho_d\)-values force equal \(g(f(\rho_d(x)))\) values across any universe \(Y\) without cardinality assumptions, contradicting distinct \(r_d\). Swapping the two source constructors and proof payloads preserves \(\rho_d\) while exchanging repairs without fixed points, refuting natural sections over \((0,\varnothing)\). Under \(\widehat\rho_d\), equal readouts force equal \(\phi(x)\) and identical source constructors, allowing \(R_d(\phi(x))\) to select the unique capacity-\(1\) repair (Appendix F.3). ∎

### 5.11 How Actual Execution Traces Split Coarse Probability \(1/2\) into Refined \(1\) and \(0\)

Both failure sources in \(\Omega_d\) are inhabited by actual institutional executions at every depth \(d\): basic-payment disposition generates capture-removal occurrence \(a_d^{\mathrm c}\), while independent route disposition generates route-restoration occurrence \(a_d^{\mathrm r}\). They share **the exact same root event, source entry, whole-ledger write-back, and actual next state**, while carrying distinct branch processors and repairs.

**Theorem 5.11 (Full Actual Support, Duplicate-Free Finite Traces, and Refined Provenance Probability).** At every depth \(d\), every element of \(\Omega_d\) possesses an installed actual witness (actual support equals all of \(\Omega_d\)), with cross-retyping of repairs impossible in either direction. For every finite horizon \(h\in\mathbb N\), the generator constructs duplicate-free dependent trace \(T_h\) containing \(a_d^{\mathrm c},a_d^{\mathrm r}\) iff \(d<h\), of exact length \(2h\) and unit-counting mass \(2h\): failure-kind-stamped root readouts are collision-free on \(T_h\), whereas bare root-event readouts collide at every \(h>0\).

Let \(E\) be the event “installed repair is capture removal.” Fixing \(d\) and folding at horizon \(h=d+1\) on the shared coarse query
\[
y_d=\bigl(e_d,(0,\varnothing)\bigr),
\]
the coarse observation fiber is \([a_d^{\mathrm c},a_d^{\mathrm r}]\) and event subfiber is \([a_d^{\mathrm c}]\), yielding defined conditional probability \(1/2\) without recovering repair authority. Adjoining the source failure kind splits the two query fibers into singletons, restores repair factorization, and sharpens conditional probability to deterministic values:
\[
\widehat P_d(E\mid \widehat y_d^{\mathrm c})=1,
\qquad
\widehat P_d(E\mid \widehat y_d^{\mathrm r})=0;
\]
at horizon \(h=0\), empty observation fibers return undefined \(\mathrm{none}\).

**Proof.** Both installed branches execute from the same root occurrence with identical ledger write-back and next state yet distinct repairs, covering \(\Omega_d\). Listing capture occurrences for \(0,\ldots,h-1\) followed by route occurrences yields duplicate-free \(T_h\) of length \(2h\). At \(h=d+1\), root coordinate \(e_d\) isolates \(a_d^{\mathrm c},a_d^{\mathrm r}\), both reading \((0,\varnothing)\) with only \(a_d^{\mathrm c}\in E\), giving unit-counting ratio \(1/2\); stamping \(\phi\) isolates singleton fibers of masses \(1\) and \(0\); \(h=0\) has zero mass and returns \(\mathrm{none}\) by Section 3.4 (Appendix F.4). ∎

The \(1/2\) ambiguity here reflects no randomness in reality—only provenance erased by coarse observation. Keeping the underlying measure, trace, and repair rule fixed while retaining failure provenance immediately turns a coin-flip guess into deterministic institutional diagnosis.

### 5.12 Dark Twins Synthesized: Why a Smoothly Running Ledger Can Still Trap Its Participants

Collecting these negative controls reveals the **dark twins** of institutional design: funds arrive, services execute, whole-ledger write-backs balance, and successor states advance without a hitch—yet participant A remains trapped in subordination, or an agency armed with exact multidimensional tables repeatedly prescribes the wrong repair.

**Proposition 5.12 (Three Structural Obstructions from Missing Relations and Coarse Observation).** Across all depths, the canonical construction exhibits three exact dark-twin contrasts:

1. **All other institutional operations intact without entailing a route**: At every depth \(d\), route-outage carrier \(B_d\) is inhabited (sharing root occurrence, actual payment, standing, tenure relation, noncapture, actual service, obligation row, whole-ledger write-back, independent processor, actual successor, and seven other installed renewal operations), while source route type \(T_d\) is empty:
   \[
   B_d\ne\varnothing,
   \qquad T_d=\varnothing,
   \qquad (B_d\to T_d)=\varnothing,
   \]
   with feasible exit restored only at repaired visit \(d+1\ne d\).
2. **Full payment chain and extra-role relation intact without entailing uncaptured exit**: Across all visits, source indices, and lifecycle origins, total capture preserves Theorem 5.5's three payment edges, purchasing power, employment termination, exit interest, bare extra-role future, external liability, services, and successors while emptying actionable exit renewal.
3. **Identical root, ledger, and successor without entailing identical repair**: At every depth \(d\), Theorem 5.11's two actual branches share exact root occurrence, compatible whole-ledger write-back, actual next state, and full-domain readout \((0,\varnothing)\), blocking any decoder \(g(f(\rho_d(x)))=r_d(x)\) across arbitrary output universes and carriers \(Y\).

**Proof.** Part 1 applies any putative \(u:B_d\to T_d\) to constructed \(b_d\in B_d\) to inhabit empty \(T_d\), while depth projection separates \(d\) from \(d+1\). Part 2 notes that any feasible exit renewal under total capture forces the unique nonidle extra-role leave action to be both captured and uncaptured. Part 3 combines Theorem 5.10's all-universe factorization barrier with Theorem 5.11's shared-root actual support (Appendices E.3, F.3-F.4, F.10). ∎

Proposition 5.12 unites Pettit's non-domination [@Pettit1997], Anderson's critique of private government [@Anderson2015], and Sen's capability analysis [@Sen1979] into one constructive test: **procedural execution does not entail personal freedom, and exact capability measurement does not entail diagnostic identifiability**.

### 5.13 Observer-Kernel Authority Boundary for Social Choice, Visible Matching, and Trace-Constrained Narratives

A deeper cross-disciplinary question now arises: what if an institution moves beyond individual exit metrics and deploys full-fledged **collective preference aggregation** (Arrow social welfare functions, Gibbard–Satterthwaite strategy-proof voting schemes, or Sen liberal Paretian rules), **bilateral visible matching** [@GaleShapley1962], or **strictly trace-constrained historical narratives**? Can any of those high-level visible mechanisms decode underlying occurrence authority?

Arrow's 1950 argument limits social welfare functions satisfying universality, positive association, and independence of irrelevant alternatives to imposed or dictatorial rules [@Arrow1950, pp. 340–342]. Our observer bridge uses the axiom bundle stated below, including weak Pareto; Gibbard and Satterthwaite proved that over a finite population and an unrestricted strict-preference domain, deterministic strategy-proofness onto at least three outcomes forces dictatorship [@Gibbard1973; @Satterthwaite1975]; Sen proved that assigning even two individuals bidirectional decisiveness over one pair each (Condition L) conflicts with weak Pareto on an unrestricted domain [@Sen1970, Theorem I]. Those celebrated theorems establish **horizontal, intra-quotient** aggregation conflicts inside the visible preference world. Here we establish an **orthogonal vertical observer-kernel bridge**: **we neither reprove nor invoke** the classical intra-quotient impossibility theorems; instead, working polymorphically over **arbitrary agent carriers \(\mathcal I\) and alternative carriers \(\mathcal X\) in any type universes**, we keep the Arrow visible axiom bundle \(\mathsf{Ax}_{\mathrm{Arr}}\), Gibbard–Satterthwaite visible axiom bundle \(\mathsf{Ax}_{\mathrm{GS}}\), and Sen visible liberal axiom bundle \(\mathsf{Ax}_{\mathrm{Sen}}\) completely intact as premises on the visible image \(V\), and prove what happens across a nontrivial authority observer \(O=(\operatorname{forget}:\Omega\to V,\ K:\Omega\to R)\).

A two-minute finite check makes the entire bridge transparent. In the bilateral matching readout below, terminal payoffs take values in optional rationals \(\mathbb Q\cup\{\bot\}\) (\(\operatorname{Option}\mathbb Q\) in the formalization, writing \(\mathrm{some}\,q\) for a defined rational \(q\) and \(\mathrm{none}\) for \(\bot\)).

**Example 5.1 (Two-Path Society Observer Kernel, Two-Point Hidden Boolean Flip, and Visible Balance / Trace-Constrained Narrative Check).** Inspect the source-generated society observer \(O_{\mathrm{soc}}=(\operatorname{forget},K_{\mathrm{soc}})\) installed in \(\mathcal F_h\) alongside a two-point Boolean hidden fiber:

1. **Two actual source paths in \(O_{\mathrm{soc}}\)**: Left occurrence \(\omega_{\mathrm L}\) and right occurrence \(\omega_{\mathrm R}\) carry distinct terminal authority verifiers (\(\omega_{\mathrm L}\ne\omega_{\mathrm R}\)) yet project under normalized forgetting to **the same visible image** \(v_{\mathrm{soc}}=\operatorname{forget}(\omega_{\mathrm L})=\operatorname{forget}(\omega_{\mathrm R})\), while a vertical involution swaps \(\omega_{\mathrm L}\leftrightarrow\omega_{\mathrm R}\) and flips fulfilled rational authority values without fixed points: \(K_{\mathrm{soc}}(\omega_{\mathrm L})=1\neq 0=K_{\mathrm{soc}}(\omega_{\mathrm R})\). Although an ordinary left proxy section \(s_{\mathrm L}(v_{\mathrm{soc}})=\omega_{\mathrm L}\) exists, **every** Arrow welfare rule \(F_{\mathrm A}\), GS voting rule \(f_{\mathrm G}\), or Sen rule \(F_{\mathrm S}\) defined on \(V\) receives identical visible input at both ends: \(F_{\mathrm A}(\operatorname{forget}(\omega_{\mathrm L}))=F_{\mathrm A}(v_{\mathrm{soc}})=F_{\mathrm A}(\operatorname{forget}(\omega_{\mathrm R}))\). Any putative authority decoder \(d\) from collective output immediately forces \(1=K_{\mathrm{soc}}(\omega_{\mathrm L})=d(F_{\mathrm A}(v_{\mathrm{soc}}))=K_{\mathrm{soc}}(\omega_{\mathrm R})=0\), a contradiction!
2. **Two-point Boolean hidden-fiber swap**: Over any inhabited visible carrier \(V\) (picking \(v\in V\)), set hidden fiber \(H=R_{\mathrm h}=\{\mathrm{false},\mathrm{true}\}\) with fixed-point-free swap \(\sigma=\operatorname{swap}(\mathrm{false},\mathrm{true})\) on product observer \(O_{\mathrm{Bool}}:V\times\mathrm{Bool}\to V\). Pulling back any visible profile and collective rule satisfying \(\mathsf{Ax}_\star\) gives \((v,\mathrm{false})\) and \((v,\mathrm{true})\) identical individual preferences and collective outcomes—all visible axioms hold—while authority factorization on \(O_{\mathrm{Bool}}\) is strictly empty because \(\mathrm{false}\ne\mathrm{true}\).
3. **Positive visible bilateral matching and anti-fictional trace-constrained narrative**: On the same \(O_{\mathrm{soc}}\), installed bilateral matching achieves defined positive balance \(\mu(\omega_{\mathrm L})=\mu(\omega_{\mathrm R})=(\mathrm{some}\,7,\mathrm{some}\,7)\) on both paths; meanwhile, trace-constrained narrative readout (forbidding any atomic claim absent from the occurrence's actual trace \(\mathrm{tr}(\omega)\)) **strictly rejects** the left-exclusive authority narrative at \(\omega_{\mathrm R}\) (enforcing anti-fictionality), yet emits the identical well-supported common narrative \(\nu(\omega_{\mathrm L})=\nu(\omega_{\mathrm R})\) on the shared witnessed `origin` atom. Visible accounts balance at \((7,7)\) and every word of the common narrative is trace-verified, yet both remain completely blind to whether \(\omega_{\mathrm L}\) or \(\omega_{\mathrm R}\) holds source authority!

We now state the general universe-polymorphic theorem (full formal definitions in Supplement Appendix C.6 Proposition C14, Theorem C15, and Proposition C16). For an authority observer \(O=(\operatorname{forget}:\Omega\to V,\ K:\Omega\to R)\), readout \(q:\Omega\to Y\) is **visibly factored** if \(q=v_q\circ\operatorname{forget}\) for some \(v_q:V\to Y\), and satisfies **occurrence-authority completeness** (\(\operatorname{AuthComp}(O,q)\)) if \(d(q(\omega))=K(\omega)\) for all \(\omega\in\Omega\) under some decoder \(d:Y\to R\).

**Theorem 5.13 (Observer Factorization Forcing and Authority Boundary for Social Choice, Visible Matching, and Trace-Constrained Narratives).** Let \(\mathcal I\) and \(\mathcal X\) be arbitrary agent and alternative carriers in any type universes (requiring neither finiteness nor decidable equality), and let \(E_{\mathrm{hid}}=(H,R_{\mathrm h},\kappa,\sigma_H,\sigma_R,h_0)\) be any hidden authority fiber extension with compatible automorphisms \(\kappa\sigma_H=\sigma_R\kappa\) and \(\sigma_R(\kappa(h))\ne\kappa(h)\) for every \(h\in H\). Four conclusions hold jointly:

1. **General observer factorization forcing and identity positive control**: On any authority observer \(O\), every readout \(q\) satisfying both visible factorization and occurrence-authority completeness forces visible authority factorization \(r_O:=d\circ v_q:V\to R\) (\(r_O\circ\operatorname{forget}=K\)); if an occurrence-valued visibly factored readout \(q:\Omega\to\Omega\) satisfies exact occurrence identification \(q(\omega)=\omega\) in the presence of an ordinary proxy right section \(s:V\to\Omega\), then \(v_q\) is forced to be a two-sided inverse of \(\operatorname{forget}\) inducing faithful authority reconstruction (and full natural authority reconstruction when equivariant under admissible automorphisms). Identity observer \(O_{\mathrm{id}}=(\mathrm{id}_\Omega,K)\) inhabits all positive properties, whereas any observer carrying a source-generated attaching boundary \(\partial_O\) induced by an authority-altering vertical automorphism renders occurrence-authority completeness strictly empty for every visibly factored readout.
2. **Observer-kernel exclusion across all three social-choice axiom bundles**: On the society observer \(O_{\mathrm{soc}}\), given any visible rules satisfying the Arrow visible axiom bundle \(\mathsf{Ax}_{\mathrm{Arr}}(p_{\mathrm A},F_{\mathrm A})\) (unrestricted domain, weak Pareto, IIA, non-dictatorship), Gibbard–Satterthwaite visible axiom bundle \(\mathsf{Ax}_{\mathrm{GS}}(p_{\mathrm G},f_{\mathrm G})\) (\(\ge 3\) distinct alternatives, unrestricted domain, surjectivity, non-dictatorship, unilateral strategy-proofness), or Sen visible liberal axiom bundle \(\mathsf{Ax}_{\mathrm{Sen}}(p_{\mathrm S},F_{\mathrm S})\) (unrestricted domain, weak Pareto, bidirectional minimal liberalism), all three visible axiom bundles remain intact while their occurrence-authority completeness strengthenings are strictly empty:
   \[
   \operatorname{AuthComp}_{\mathrm{Arr}}(O_{\mathrm{soc}})=\varnothing,\quad
   \operatorname{AuthComp}_{\mathrm{GS}}(O_{\mathrm{soc}})=\varnothing,\quad
   \operatorname{AuthComp}_{\mathrm{Sen}}(O_{\mathrm{soc}})=\varnothing.
   \tag{5.13a}
   \]
3. **Hidden-fiber invariance and non-implication negative control**: On product observer \(O_{\mathrm{hid}}:V\times H\to V\), pulled-back individual profiles and collective outputs remain invariant across all hidden coordinates \(h_1,h_2\in H\) over any visible point (\(\pi^*g(v,h_1)=\pi^*g(v,h_2)\)). For every inhabited visible carrier \(V\) (with \(v_0\in V\), including \(V_{\mathrm{soc}}\)), \(\operatorname{AuthorityFactorization}(O_{\mathrm{hid}})=\varnothing\); hence for any visible rule on \(V\) carrying a bundle witness \(a:\mathsf{Ax}_\star\), satisfying that visible axiom bundle never entails authority factorization on \(O_{\mathrm{hid}}\):
   \[
   \neg\bigl(\mathsf{Ax}_\star\Longrightarrow \operatorname{Nonempty}(\operatorname{AuthorityFactorization}(O_{\mathrm{hid}}))\bigr),\qquad \star\in\{\mathrm{Arr},\mathrm{GS},\mathrm{Sen}\},
   \tag{5.13b}
   \]
   with two-point swap \(H=R_{\mathrm h}=\mathrm{Bool}\) supplying the minimal executable negative control.
4. **Positive visible matching balance and trace-constrained narrative versus empty authority completeness**: On \(O_{\mathrm{soc}}\), installed bilateral matching achieves inhabited defined positive balance \(\mu(\omega_{\mathrm L})=\mu(\omega_{\mathrm R})=(\mathrm{some}\,7,\mathrm{some}\,7)\), yet \(\mu\)'s occurrence-authority completeness is empty and proxy-induced readout \(s_{\mathrm L}\circ\operatorname{forget}\) cannot identify all occurrences; simultaneously, trace-constrained narrative readout (\(\forall a\in\mathrm{cl}(\nu(\omega)),\ a\in\mathrm{tr}(\omega)\), reusing the existing trace without a second archive) strictly rejects every candidate narrative claiming an unwitnessed atom (\(\neg\operatorname{SupportsAt}(\omega,S)\)), while the visibly factored common narrative satisfies \(\nu(\omega_{\mathrm L})=\nu(\omega_{\mathrm R})\), has a strictly non-singleton narrative fiber, and has empty occurrence-authority completeness.

**Proof.** Part 1: If \(q=v_q\circ\operatorname{forget}\) and \(d\circ q=K\), setting \(r_O:=d\circ v_q\) yields \(r_O(\operatorname{forget}(\omega))=d(v_q(\operatorname{forget}(\omega)))=d(q(\omega))=K(\omega)\). If \(q(\omega)=\omega\) and \(\operatorname{forget}(s(v))=v\), then \(v_q(\operatorname{forget}(\omega))=\omega\) gives the left inverse while evaluating at \(\omega=s(v)\) gives \(\operatorname{forget}(v_q(v))=v\), inducing \(K\circ v_q\) (preserving automorphisms under equivariance). On kernel pair \((\omega_0,\omega_1)\) of \(\partial_O\), \(\operatorname{forget}(\omega_0)=\operatorname{forget}(\omega_1)\) with \(K(\omega_0)\ne K(\omega_1)\) refutes \(r_O\circ\operatorname{forget}=K\); \(O_{\mathrm{id}}\) takes identity maps.

Part 2: Collective readouts \(F_{\mathrm A}\circ\operatorname{forget}\), \(f_{\mathrm G}\circ\operatorname{forget}\), and \(F_{\mathrm S}\circ\operatorname{forget}\) factor explicitly through \(\operatorname{forget}\); applying Part 1 to the society observer's attaching boundary (\(\omega_{\mathrm L}\ne\omega_{\mathrm R}\) over \(v_{\mathrm{soc}}\) with \(K_{\mathrm{soc}}(\omega_{\mathrm L})\ne K_{\mathrm{soc}}(\omega_{\mathrm R})\)) empties all three types in (5.13a) without altering any visible axiom clause.

Part 3: First-projection pullback invariance is definitional; given \(v_0\in V\), on \(O_{\mathrm{hid}}\) bijection \(\mathrm{id}_V\times\sigma_H\) anchored at \((v_0,h_0)\) fixes \(\mathrm{id}_V\) while flipping authority via \(\sigma_R\) across the fiber, emptying \(\operatorname{AuthorityFactorization}(O_{\mathrm{hid}})\) by Part 1 so no implication map from inhabited \(a:\mathsf{Ax}_\star\) into that empty type can exist, proving (5.13b).

Part 4: Evaluating at \(v_{\mathrm{soc}}\) confirms both legs equal \(\mathrm{some}\,7\); if \(a\in\mathrm{cl}(S)\) with \(a\notin\mathrm{tr}(\omega)\), the support law yields an immediate contradiction, proving anti-fictionality; distinct \(\omega_{\mathrm L}\ne\omega_{\mathrm R}\) both inhabit the fiber over \(S_0=\nu(\omega_{\mathrm L})=\nu(\omega_{\mathrm R})\), refuting subsingletonity; applying Part 1 to visibly factored \(\mu\) and \(\nu\) empties their occurrence-authority completeness (Appendix C.6 Proposition C14, Theorem C15, Proposition C16). ∎

![Society observer, cross-tier authority boundary, and hidden-fiber and provenance controls](figures/08-observer-bridge-v3-en.svg)

Figure 7. Observer factorization forcing and cross-institutional authority boundary (Theorem 5.13 alongside Theorems 5.10–5.11). Panel A shows distinct actual paths \(\omega_{\mathrm L}\ne\omega_{\mathrm R}\) in \(O_{\mathrm{soc}}\) carrying unequal rational authorities (\(1\ne 0\)) into one normalized visible image \(v_{\mathrm{soc}}\), inducing attachment boundary \(\partial_O\); Panel B shows Arrow, Gibbard–Satterthwaite, and Sen visible rules, bilateral matching \((7,7)\), and anti-fictional trace narratives retaining positive visible properties with empty occurrence-authority completeness; Panel C contrasts hidden-fiber negative control \(O_{\mathrm{hid}}\) (for \(v_0\in V\), visible axioms never force factorization) against identity positive control \(O_{\mathrm{id}}\) and failure-kind refinement on the separate repair family \(\Omega_d\).

Theorem 5.13 elevates Section 5's diagnostic findings into a general epistemology of institutions: **visible social-choice axioms, balanced bilateral clearing tables, and strictly trace-verified narratives operate entirely within the visible quotient \(V\); once cross-tier occurrence provenance is forgotten, none of the three can substitute for source-backed obligation tracking**.

## 6 New Birth of Responsibility and All-Depth Same-Occurrence Regeneration

### 6.1 How Continuing Activity Generates Genuinely New Obligations Within the Action Class

Social life never merely consumes obligations fixed at an initial moment: entering new cooperation or establishing new public commitments creates obligations absent from prior ledgers. Does admitting a genuinely new responsibility break Theorem 4.2's fourfold root-law closure or demand a fifth extra-legal write channel? No: complete institutional programs distinguish inside the action class \(\mathrm A(r)\) between **sequential action** (injectively transporting old obligations) and **new-obligation admission** (expanding the obligation domain to disjoint union \(R\sqcup D\) and activating the right summand).

In \(R\sqcup D\), right summand \(D\) begins inactive without open rows; once activated, state \(s\) natively fixes the new row, and a same-source actual step
\[
s\longrightarrow t,\qquad B(t)<B(s)
\]
supplies its first payment—strict natural-number budget decrease \(B(t)<B(s)\) witnessing positive initial budget \(B(s)>0\) and spending one unit of progress margin.

**Proposition 6.1 (Complete First Write of Actual Responsibility Birth).** For every complete installed program containing the actual admission step above, its generated execution produces a fresh responsibility row lacking any preimage in the full prior ledger, its first payment, the **first-write successor** retaining all old-row evolutions alongside the new row's first write, and the actual next visit generated from that successor; old observation projections are preserved, every member of the target initial open-obligation set either comes from an old row or is this newly born row, and the entire execution belongs to the action class \(\mathrm A(r)\) of Theorem 4.2.

**Proof.** Inactive \(D\) has no open witnesses and active \(D\) is disjoint from \(R\), barring any old-ledger preimage (pure sequential transport cannot alone create new rows). Step \(s\to t\) (\(B(t)<B(s)\)) supplies open witness and first payment, joining all old-row transfer receipts into one whole-ledger write-back, first-write successor, and next visit; case analysis across \(R\sqcup D\) proves target exhaustion while binding the output to \(\mathrm A(r)\) without adding a fifth permission class (Appendices B.1-B.2). ∎

### 6.2 How Six Regeneration Guarantees Land Together on One Actual Payment

Sustaining A's security across time requires continuing legal lineage, noncontracting ordinary exit, repair of capture, residual-bearer handling, future amendability, and protection of counterparties' claims. If these six guarantees held only across separate runs, securing one could still forfeit another. At every depth \(d\in\mathbb N\), we therefore define joint regeneration carrier \(\Gamma_d\): its three components belong to the ordinary-repair carrier, full capture-obligation carrier, and actual repair-successor carrier, locked onto **one and the same payment \(p_d\)** by two exact shared-repair seam equalities (while bridging payment **responsibility post-state** to source-root **next constitutional visit** via installation decomposition).

| Joint conclusion | Exact institutional content retained by the same complete payment \(p_d\) |
| --- | --- |
| Law and obligation-lineage continuation | Pre-repair law, obligation lineage, and inherited rows persist; actual repair successor aligns with target program |
| Noncontracting ordinary exit | Both current uncaptured continuation and next actual occurrence possess genuine exit; here \(K_d=K_{d+1}=1\) |
| Capture-relation repair | Current captured configuration has empty feasible exit; target repair program installs at next visit and restores exit |
| Residual bearer and processing retained | Current payment's residual and bearer persist; active processor's post-state equals \(p_d\)'s post-state, with root processor at successor |
| Successor law-revision capacity | Successor retains a faithful law-revision route plus receipt of depth-zero execution consuming that same revision core |
| Cross-actor obligation attribution | Protected interest of an actual counterparty distinct from A enters disposition; settlement identity and \(p_d\) provenance persist |

Table 5: Six constitutional guarantees realized jointly on one actual payment \(p_d\) by every element of \(\Gamma_d\).

**Theorem 6.2 (All-Depth Same-Occurrence Sixfold Regeneration).** For every natural-number depth \(d\in\mathbb N\), there exists \(g_d\in\Gamma_d\); and for **every** element \(g\in\Gamma_d\), all six conclusions in Table 5 hold jointly on that same payment. For every foundation horizon \(h\in\mathbb N\) and every depth \(d\in\mathbb N\), canonical society \(S_h\) stores and exports this joint certificate—**finite foundation horizon \(h\) never truncates regeneration depth within \(h\)**.

**Proof.** Given \(d\), the regeneration generator constructs from depth-\(d\) payment the triple satisfying both shared-repair equalities, inhabiting \(g_d\in\Gamma_d\). Taking arbitrary \(g\in\Gamma_d\): ordinary repair evolves selected row \(\delta\) while preserving pre-repair law, lineage, and inherited rows (item 1); uncaptured geometry and repaired next occurrence each pair one nonidle leave action with served slots to give \(K_d=K_{d+1}=1\) (item 2), whereas captured geometry is empty now and restored at the next visit (item 3); capture settlement equals \(p_d\)'s open settlement, preserving residual, bearer, matching post-state processor, and next constitutional visit (item 4); repair successor carries the faithful revision map and depth-zero shared-core receipt (item 5); counterparty acceptance fixes a distinct actor's protected interest and provenance incidence (item 6). \(S_h\) exports this certificate for all \(h,d\) (Appendix B.8). ∎

### 6.3 Exact Visit Continuation Across Adjacent Depths and Depth-Zero Policy-Rupture Separation

Is the visit actually reached by repair at step \(d\) literally the entry from which step \(d+1\) generates its occurrence? Write \(v_d\) for the regeneration root's visit at depth \(d\), \(v^+(g)\) for \(g\in\Gamma_d\)'s next constitutional visit, \(e_R(v)\) for the occurrence generated at \(v\), \(e(g')\) for the root occurrence of \(g'\in\Gamma_{d+1}\), and \(\widehat p_d=(v_d,p_d)\) for the visit-packaged payment carrier.

**Theorem 6.3 (Exact Cross-Depth Continuation and First Policy-Rupture Successor Separation).** For every depth \(d\), every \(g\in\Gamma_d\), and every \(g'\in\Gamma_{d+1}\), exact continuation holds:
\[
v^+(g)=v_{d+1},\qquad
e(g')=e_R\bigl(v^+(g)\bigr),
\]
with adjacent payments strictly distinct in the common carrier: \(\widehat p_d\ne\widehat p_{d+1}\). Moreover, the depth-zero policy rupture generates actual same-source law revision; its ordinary-repair successor and same-source law-revision successor from that shared rupture are both inhabited and strictly unequal.

**Proof.** Ordinary repair's target visit equals \(v_{d+1}\) by the root's temporal recursion, and every \(g'\in\Gamma_{d+1}\) generates its root occurrence from \(v_{d+1}\), giving both equations. Equal \(\widehat p_d=\widehat p_{d+1}\) projects to \(d=d+1\), a contradiction. At depth \(0\), policy rupture connects the shared payment and capture contrast to the installed exact-failure face, driving same-source revision first write and migration; ordinary repair continues on the \(2\)-point old support, whereas revision successor support contains \(2\) distinct old points plus \(1\) fresh direction (\(3\) distinct points), barring equality by pigeonhole injectivity (Appendices B.7, B.9). ∎

![Six joint regeneration guarantees on one payment and exact entry into the next depth](figures/05-regeneration-v3-en.svg)

Figure 8. All-depth same-occurrence sixfold regeneration and cross-depth continuation (Theorems 6.2–6.3). Six guarantees bind to current payment \(p_d\); the actual next visit \(v^+(g)\) reached by repair literally forms the entry generating depth \(d+1\)'s occurrence, while depth-zero ordinary-repair and law-revision successors separate by support cardinality \(2\ne 3\).

### 6.4 Cofinal Single-Step Joint Law Revision and New Birth: Why “Revision-Free Terminal States” Are Empty

If a constitution permitted amendment for ten rounds and then permanently froze revision under the pretext of final perfection, later arrivals would once again be trapped under dead rules. To rule out amendment freeze after any finite stage, we track a cycle driven by **paid replay spans**: from initial entry \(c_0\), step-\(d\) entry \(c_d\) has right replay at \(i_d=i_0+d\) whose payment reaches target \(i_d+1\); step \(d+1\) takes step \(d\)'s right replay as its new left end and step \(d\)'s payment target as its new right end:
\[
i_d=i_0+d,\qquad
c_{d+1}
=\operatorname{nextCycle}(\operatorname{step}(c_d)).
\tag{6.4a}
\]
Within each step, actual same-source law revision, compatible new future fulfilled by the target's native payment, and root-law continuation \(i_d+2\to i_d+3\) complete together. In liveness theory, realizing a property at some \(m>n\) beyond every finite cutoff \(n\) is **cofinality**.

**Theorem 6.4 (Cofinal Single-Step Joint Law Revision, New Birth, and Open Operation).** Fix arbitrary old-visit parameter, source index, boundary, and payment-cycle entry:

1. For every observation parameter \(h\) and depth \(d\), step \(d\) generates the joint step above; hence **beyond every finite cutoff \(n\) and observation parameter \(h\)**, one and the same later step \(m>n\) (explicitly \(m=n+1\)) jointly realizes actual same-source law revision, payment-supported compatible new future, and complete root-law continuation:
   \[
   \forall n,h\ \exists m>n:\quad
   \text{law revision}(m)\land
   \text{compatible future}(h,m)\land
   \text{root-law continuation}(h,m).
   \tag{6.4b}
   \]
   Its next entry is \(c_{m+1}\); the next revision payment and target-future payment are dependently equal occurrences, while source and target payments are distinct. At every depth, any **“revision-free terminal state”** retaining current constitution while claiming empty target root law, target constitution, or lifecycle evidence is **strictly empty**.
2. Full platform admission (Section 5.8) joins this cofinal run at the first next pair's left replay, yielding arbitrarily late points retaining platform provenance, root law, actual amendment, and compatible future. Furthermore, beyond every finite representation cutoff, two later occurrences share visible readout \(z\) while carrying distinct obligation coordinates \(u_0<u_1\): every old-language single-value function \(f\) outputs diagonal \((f(z),f(z))\ne(u_0,u_1)\) (dropping either slot makes a constant function succeed, localizing exact failure to joint two-slot expression), triggering same-source revision, first write, and an ongoing question-response chain placing positive execution depth \(k\) at distinct revision visit \(k+1\).

**Proof.** Span transport aligns step \(d\)'s second lifecycle stage with step \(d+1\)'s first stage across root, payment, authority, and service occurrences, establishing (6.4a) and dependent equality of next-revision and target-future payments while payment injectivity separates source from target. Setting \(m=n+1>n\) proves (6.4b) and refutes any empty-target claim. Platform replay matches the first next pair's left end literally. Finally, \((f(z),f(z))=(u_0,u_1)\) contradicts \(u_0<u_1\); sequential action installs this minimal exact failure to drive fresh-direction first write, and induction on \(k\ge 1\) places authority visits at distinct \(k+1\) (Appendix E.6). ∎

### 6.5 Rich Birth and Open New Futures Across Three Settlements

Once same-source law revision creates a fresh residual obligation \(\rho\), can \(\rho\) survive subsequent settlements without deadlocking the ledger or swallowing the bearer's exit? Call an obligation birth **rich** when it jointly supplies no-old-preimage proof, first-generated row, native admission, explicit bearer, and independent processing.

**Theorem 6.5 (Rich Birth and Post-Settlement Open New Futures).** For every visit \(v\) on the fixed source root, the capacity-failure revision target possesses a complete three-row obligation set: two inherited rows embedded from the prior ledger (contribution and obstruction) plus fresh residual \(\rho\) having no preimage in the embedded prior ledger and acquiring rich birth under existing parent bearer \(b_\star\).

For every source index \(s\) and \(n\in\mathbb N\), local state \(n+1\) of the reopening root generates a compatible new future: \(\rho\) continues at \(0\to 0\) preserving content, lineage, and processing while current payment fulfills service and connects purchasing power to \(b_\star\)'s extra-role continuation (capacity \(1\) uncaptured, \(0\) under total capture). This macro path then traverses **residual settlement, joint settlement of both inherited rows, and post-settlement native payments**: at every post-settlement index \(n\) (coordinate \(c_n=c_0(s)+n\)), compatible new future \(\beta_n\) advances to exact successor \(c_n+1\), with \(n=m+1\) giving \(c_n>m\) beyond every finite bound \(m\). Any \(h\) consecutive futures form a duplicate-free list of count \(h\), yet pure cardinality recovers neither occurrence identity, service authority, nor distinct cross-settlement root successors.

**Proof.** Reverse indexing exhausts the three revised rows (ordinary joint clearing has old preimages on every row, whereas an old preimage for \(\rho\) would fold its fresh direction back into the old language). Reopening payments continue all three rows while pairing \(b_\star\)'s sole nonidle edge (\(K=1\)). At reopening state \(3\), payment matches residual-clearing source payment, emptying \(\rho\)'s successor same-debt fiber while handing both inherited rows to joint clearing; post-settlement native payments rebuild service, extra-role continuation, and external-liability processing at each \(c_n\to c_n+1\). Index injectivity gives duplicate-free count \(h\), while singleton counts \(1\) at distinct indices or across settlements carry unequal service indices and root successors (Appendix E.7). ∎

### 6.6 Standing of Newcomers and Freely Disposable Time

Theorem 6.5 proves rich birth and cross-settlement continuation of new obligations under bearer \(b_\star\); normatively, we pair this formal template with a clear constitutional principle for **human birth, migration, and re-entry**: every newcomer affected by shared institutional rules acquires basic participation standing directly from those affected relations without first having to earn admission through market output. Formal whole-ledger birth guarantees that admitting new claims never corrupts accountability.

Once income, services, and uncaptured routes connect into a reopenable future, how A spends life after leaving a job—caring for loved ones, learning, resting, creating art, pursuing open-ended inquiry, or entering a new revocable cooperative role—belongs to A's own judgment. Strict progress (Theorem 1.3) and cofinal amendment-with-birth (Theorems 6.4–6.5) secure the institutional floor: every completed disposition leaves behind the paid conditions for another free beginning.

## 7 How Economic and Institutional Obligations Persist Conservatively After Payment

After A pays or receives credit support, whose obligations are genuinely finished and who still owes performance? In corporate and financial practice, consolidated balance sheets cancel inter-tier promises [@Mehrling2013, §§I–IV], while limited assets constrain recoverable damages and asset partitioning affects the property accessible to creditors [@Shavell1986; @Pistor2019]. Tracking clearing, credit, representation extension, theory amendment, and risk splitting from their actual sources proves why local halting, renewal exhaustion, and genuine debt settlement cannot be conflated.

### 7.1 Four-Leg Common Clearing Versus Unilateral Counterparty Residual

Let finite transaction-leg set \(I\) carry involutive counterparty map \(\sigma:I\to I\) (\(\sigma^2=\mathrm{id}\)). Leg \(i\) generates bearer \(a_i\), obligation \(q_i\), and stable slot \(j_i\) with distinct counterparties and slots:
\[
a_i\ne a_{\sigma(i)},\qquad j_i\ne j_{\sigma(i)},
\]
injective slot assignment \(i\mapsto j_i\), and duplicate-free exhaustive enumeration; each leg's native performance updates only its own slot.

**Proposition 7.1 (Leg-by-Leg Common Clearing and Unilateral Counterparty Debt).** Executing all native performance events along the finite enumeration places every transaction leg into a fulfilled terminal archive, leaving zero open settlements; conversely, executing leg \(i\) alone leaves counterparty slot \(j_{\sigma(i)}\) with a live open obligation. Four-leg clearing installs at every periodic depth \(d\) to advance whole-ledger execution to \(d+1\) across distinct occurrences (Appendix C.2.1).

**Proof.** Induct on executed prefixes: injectivity of \(i\mapsto j_i\) archives \(j_i\) without disturbing prior terminal slots, exhausting \(I\) at the end so no open settlement survives. Unilateral performance updates \(j_i\) alone, preserving live \(q_{\sigma(i)}\) at \(j_{\sigma(i)}\ne j_i\). ∎

### 7.2 Credit Support: Purchasing Power Advances Without Shifting the Risk Bearer

Credit grants an unsettled relation immediate purchasing power, yet as monetary-hierarchy theory stresses, liquidity accommodation is not final settlement [@Mehrling2013]. Starting where leg \(a\) is fulfilled while leg \(b\) remains open, same-source repayment tender and counterparty acceptance confer purchasing-power standing between distinct borrower \(t_1\) (from \(b\)'s seed) and creditor \(t_0\) (from its counterparty leg, \(t_0\ne t_1\)), while reading the risk bearer from open obligation \(q_b\).

**Proposition 7.2 (Credit Risk Attribution and Actual Clearing Successor).** At every periodic depth, same-source credit support and purchasing-power standing generate a credit object whose risk bearer is literally \(q_b\)'s existing bearer; its actual successor appends \(b\)'s native performance event to archive slot \(b\) (closing the slot left open in Proposition 7.1), while preserving root obligation content, lineage, and root progress budget \(2\to 2\) (Appendix C.2.2).

**Proof.** Counterparty involution separates \(t_0\ne t_1\); tender plus acceptance establishes purchasing power while open \(q_b\) fixes the risk bearer. Appending \(b\)'s native performance archives slot \(b\), while root transport preserves content, lineage, and budget \(2\to 2\). ∎

### 7.3 Exact Quotient Extensions of Institutional Records: Admission Provenance, Control, and Spatial Reachability

Bearer A and controller B can appear on the same payment receipt under sharply unequal rights and burdens. Over source-generated domain \(X\) and registered independent processors \(\{c_i\}\), call representation \(F:X\to\mathcal A\) **complete** when
\[
F(x)=F(y)\iff\forall i,\ c_i(x)=c_i(y).
\]
Adjoining a new observation \(r:X\to\mathcal B\) defines \(F^+(x)=(F(x),r(x))\).

**Lemma 7.3 (Exact Content-Preserving Quotient Extension and Non-Recovery Criterion).** Extended equality satisfies \(F^+(x)=F^+(y)\iff(\forall i,\ c_i(x)=c_i(y))\land r(x)=r(y)\); the induced quotient is naturally bijective with the image of \(F^+\), factoring every \(c_i\) uniquely. Whenever \(F(x)=F(y)\) and \(r(x)\ne r(y)\) for some \(x,y\in X\), \(r\) cannot be recovered from \(F\).

**Proof.** Any \(r=g\circ F\) forces \(r(x)=r(y)\) from \(F(x)=F(y)\), contradicting \(r(x)\ne r(y)\); kernel and quotient factorization follow by universal product properties (Appendix C.3.1). ∎

Three concrete extensions apply Lemma 7.3 directly into execution (Appendices C.3.2-C.3.3): (1) **admission-channel provenance**, separating tenure from newly admitted platform provision collapsed by legacy cultural records; (2) **control versus bearing**, separating controller B (`false`) from paying counterparty A (`true`) on the shared post-refusal payment while retaining open price, capture, and residual; and (3) **spatial reachability**, separating blocked routes (capacity \(0\)) from repaired next-depth routes (capacity \(1\)) collapsed by artistic-layer records.

### 7.4 Theory Adoption and Mother-Law Failure: Amending the Rule Migrates Live Obligations Across the First Write

When an institution adopts a classification or policy theory \(T\) governing admission and completion, adopting \(T\) generates accountable institutional effects. Fixing legacy theory \(T\), trajectory seed \(s\), and feedback generation produces classification \(\chi(s)\), policy choice \(\varpi(s)\), actual effect \(e_s:E(s)\), and independent effect verifier
\[
K(s,e_s)
\]
(any candidate \(e\) with empty \(K(s,e)\) satisfies \(e\ne e_s\) against inhabited \(K(s,e_s)\)). When an exact obstruction within \(T\)'s mother law hits responsibility row \(r\), same-source law revision fires.

**Theorem 7.4 (Theory Revision, Live Obligation Migration, and Subsequent Native Clearing).** Actual mother-law failure generates same-source law revision, minimal revision coface, and revision first write: legacy authorization is superseded, yet the failing pre-revision obligation \(q\) persists **live** as inherited obligation \(q'\) at first-write target visit \(1\), preserving content, bearer, lineage, and source anchor; only a subsequent native performance event starting from that exact target visit \(1\) archives the inherited slot and produces the clearing successor. Ordinary and revised successors are strictly unequal.

**Proof.** Obstruction and failure-face equalities pin failure to row \(r\), whose causal authority drives rooted failure and revision first write. As shown in Figure 9, first write migrates pre-revision row \(\delta\) into live \(q'\) at \(i(\delta)\): target visit \(1\) cannot be closed without making the same slot simultaneously live and terminal, proving that **replacing legal or theoretical authorization never automatically erases incurred obligations**. Subsequent execution starts literally from target visit \(1\) and reads native performance to archive \(i(\delta)\). Finally, ordinary successor support has \(2\) points while revised support has at least \(3\), separating the successors (Appendix C.4). ∎

![Effect verification in theory adoption, live obligation migration across mother-law revision, and native clearing](figures/06-theory-v3-en.svg)

Figure 9. Theory adoption and obligation clearing chain (Theorem 7.4). Effect verifier \(K(s,e_s)\) checks adopted theory outputs; exact mother-law failure triggers same-source revision migrating pre-revision row \(\delta\) as live \(i(\delta)\) at target visit \(1\), until subsequent native performance genuinely settles it.

### 7.5 Strict Separation of Three Termination Loci: Renewal Exhaustion, Local Halting, and Final Debt Settlement

In economic life, “this obligation can no longer roll over under strict-renewal terms,” “the local agency or procedure has halted,” and “the underlying debt has actually been paid off” are three distinct events. Shavell distinguishes harm from the damages a liable party has the assets to pay, and Pistor studies legal mechanisms that insulate assets [@Shavell1986; @Pistor2019].

Following the canonical contribution obligation across risk split, merge, depth-\(2\) progress debit \(1\to 0\), depth-\(3\) same-source law revision, residual handling, cross-root handoff, and finally the **joint-settlement endpoint \(s_{\mathrm{clr}}\)** (followed by first post-settlement visit \(s_{\mathrm{post}}\) and next visit \(s_{\mathrm{next}}\); original formal stage identifiers are mapped in Supplement Appendix D), call a payment a **strict renewal payment** for this lineage if it carries complete payment, exact old origin, whole-ledger same-debt evolution, and strict progress-budget decrease (\(B'<B\)).

**Theorem 7.5 (Strict Separation of Three Obligation Termination Loci).** Along the actual history of the canonical contribution obligation, three distinct termination events occur at strictly separate depths:

| Locus | Exact institutional content occurring at this locus |
| --- | --- |
| Observation-sequence depth \(3\) | Immediately after depth-\(2\) strict debit \(1\to 0\), same-source revision first write inherits the live contribution row while its **strict-renewal payment fiber becomes empty for the first time** (local index \(0\), service depth \(2\)) |
| Observation-sequence depth \(9\) | The three-row root obtains complete faithful local terminal receipts and **empty local successor type**; yet the same contribution debt passes live via native handoff into the depth-\(10\) inherited root |
| Joint-settlement endpoint \(s_{\mathrm{clr}}\) | Both inherited obligations obtain exact terminal receipts with empty post-handoff open-obligation set (no successor same-debt), **finally settling** this contribution obligation |

Table 6: Three strictly separated termination loci along one obligation lineage. Neither strict-renewal exhaustion (depth \(3\)) nor local procedural halting (depth \(9\)) extinguishes cross-root debt prior to \(s_{\mathrm{clr}}\).

From depth-\(3\) first write onward, no strict renewal payment exists for this old debt across any capacity-revision, reopening, or inherited-root index, while native current-service payments continue unimpeded.

**Proof.** Depth-\(2\) action debits contribution budget \(1\to 0\) (obstruction \(0\to 0\)), and depth-\(3\) revision inherits budget-\(0\) contribution without replenishing budget. Every subsequent transport keeps budget \(0\), so any strict renewal payment would force \(0<0\), emptying renewal fibers while leaving native service payments intact. At depth \(9\), local terminal receipts empty local successors, yet native handoff constructs a live depth-\(10\) same-debt target, refuting empty-successor-debt required for final settlement. Only at \(s_{\mathrm{clr}}\) do both inherited rows archive with empty post-handoff open obligations (Appendix E.8). ∎

### 7.6 Publication Enters Execution: Why Pre- and Post-Publication Loci Cannot Form a Static Fixed Point

Return to the concrete clearing scene between A and a counterparty: once a public clearing office audits the books, officially announces “one final installment remains before joint settlement,” and executes that final clearing payment, recomputing remaining installments at the reached state must yield \(0\) so both parties can move on! Freezing the pre-execution countdown \(1\) as a post-execution fixed point would ignore the performance just completed and trap A in perpetual “one step left” limbo.

**Theorem 7.6 (Actual Publication, Target Recomputation Shift, and Post-Settlement Paid Continuation).** For every visit \(v\) and source index \(s\), the finite publication demand installed at the two-row inherited root prior to joint settlement has two-section Boolean readout \((\mathrm{false},\mathrm{true})\) and **unique** constructor-compatible minimal distance readout \(1\). That same source occurrence generates a complete publication payment bundling native service payment, both obligations' evolutions, and the joint-settlement receipt reaching \(s_{\mathrm{clr}}\), where target recomputation finds both rows terminal and returns \(0\). Hence the **fixed-point fiber equating pre- and post-publication loci is strictly empty**, while the actual non-fixed-point payment and response are inhabited; terminal handoff from \(s_{\mathrm{clr}}\) enters first post-settlement visit \(s_{\mathrm{post}}\), whose native payment generates \(s_{\mathrm{next}}\).

**Proof.** Local unfolding consists of one nonterminal parent (both rows continuing) over one terminal child (both rows terminal), so any constructor-compatible fold evaluates uniquely to \(0+1=1\). Publication payment advances to terminal root \(s_{\mathrm{clr}}\) where recomputation reads terminal receipts to return \(0\); fixed-point equality demands \(1=0\), emptying the fiber. Terminal handoff reaches \(s_{\mathrm{post}}\), whose native payment successor equals \(s_{\mathrm{next}}\) heterogeneously (Appendix E.9). ∎

### 7.7 Source-Grounded Risk Splitting, Three-Step Contribution Merge, and External Liability After an Empty Ledger

What obligations a settlement discharges depends strictly on the ledger scope it touches: when A and an exchange counterparty share a credit advance, how does risk split across two bearers and merge back at repayment without forged split receipts? And when a firm or project closes all internal accounts at zero, can ecological soil-and-water damage or cross-root liabilities left behind simply vanish? Theorem 7.7 closes both cross-actor chains: risk splitting and three-step merging across distinct bearers, and injective persistence of **source-grounded external liability \(\Lambda_n\)** after the local open ledger is completely empty.

**Theorem 7.7 (Source-Grounded Risk Splitting, Merge Origin Injectivity, and Post-Settlement External Liability).** At every periodic depth \(d\), same-visit credit materials and clearing failure generate a risk split: parent and two child rows preserve obligation identifier, content, and parent lineage across distinct exchange-leg bearers, each child taking strict budget decrease \(2\to 1\) (obstruction transporting \(0\to 0\)) from the \(2\)-row source ledger onto the \(3\)-row target ledger with independent child processors. At depth \(0\), risk split connects across three consecutive execution steps to **contribution merge**, mapping child rows \(a,b\) and obstruction \(o\) onto \(m,o'\):
\[
a:1\longrightarrow m:1,\qquad
b:1\longrightarrow m:1,\qquad
o:0\longrightarrow o':0,
\]
with exact parent list \([a,b]\) and injective selected target origins (\(m\mapsto a,\,o'\mapsto o\), refuting any simultaneous split receipt claiming distinct targets from one source row), before spending remaining capacity into the two settlements.

After settlement, for every visit \(v\), source index \(s\), and post-settlement index \(n\in\mathbb N\), occurrence \(e_n\) has an **empty local open-obligation set** yet generates inhabited **source-grounded external liability \(\Lambda_n\)** (retaining bearer ownership, source payment trace, root processor, service settlement, and cross-root provenance) advancing to \(c_n+1\). Root, payment, service occurrences, and visit-packaged payment witnesses are all strictly injective in \(n\).

**Proof.** Split first write attaches \(1<2\) proofs across distinct leg bearers to exhaust the three target rows; three-step merge uses distinct \(a\ne o\) for origin injectivity. At post-settlement coordinate \(c_n=c_0(s)+n\), support equality empties local open obligations while the native service witness extracts source-root payment trace and root processor to inhabit \(\Lambda_n\), proving coexistence of **local ledger emptiness and cross-root external liability**. Cancelling \(c_0(s)\) in \(c_0(s)+n=c_0(s)+m\) proves injectivity in \(n\) (Appendices E.10, F.8). ∎

### 7.8 All-Universe Zero-Budget Conservative Closure After Legal Recognition

Once same-source law revision legally recognizes A's claim—giving the fresh residual explicit expression, bearer, and answer—all three rows of the revised source ledger (inherited contribution, inherited obstruction, generated residual) stand at progress budget \(0\). Without introducing a genuine new budget source, can reorganizing accounts or switching representation universes restore positive strict-progress budget?

**Proposition 7.8 (All-Universe Conservative Closure of Exhausted Progress Budgets).** For every visit of the fixed source root, every revised-root visit index, and any source obligation row, native authority, and exact source event there, **every** source-native sequential action target in any representation universe satisfying **no fresh ingress rows** and **non-increasing row budgets** has zero positive-progress-budget rows at its first whole-ledger successor.

**Proof.** Exhaustive case analysis on the three-row source ledger \(L\) gives \(B(a)=0\) for all \(a\in L\). For any row \(e\in L_1'\) of the first whole-ledger successor, complete write-back supplies ingress origin \(a'\in L_0'\) with \(B(e)\le B(a')\), and no-fresh ingress supplies \(a\in L\) with \(B(a')\le B(a)\), pinching
\[
0\le B(e)\le B(a')\le B(a)=0.
\]
Hence \(B(e)=0\) for every \(e\in L_1'\), emptying the positive-budget fiber across all universes (Appendix F.5). ∎

Proposition 7.8 seals obligation conservation: **legal recognition prevents residuals and bearers from disappearing, while restoring positive capacity to advance requires an actual new source**—no conservative relabeling escapes \(0\le B'\le 0\).

## 8 An Economic Constitution: Returning Collectively Created Capacities to Continuing Lives

Sections 1–7 prove mathematically which institutional guarantees hold together and which weaker substitutes fail. Standing on those checkable premises, this section formulates five economic-constitutional principles, explicitly distinguishing what the formal theorems lock down from the normative constitutional choices proposed for public deliberation [@GaoConstitution].

### 8.1 Substantive Economic Wealth as a Reopenable Bundle of Uncaptured Continuation Relations

An account balance records instantaneous purchasing power, yet cannot by itself record how long A can wait without surrendering to subordination, whether A can refuse an unwanted job, care for dependents, or obtain repair when a route breaks. The “three zeros” and “two ones” in Section 5 (Propositions 5.2–5.3) prove that identical scalar balances or capacities collapse distinct institutional obstructions; Theorem 1.3 proves further that even when instantaneous capacity stays \(1\), today's life requires today's fresh native payment rather than yesterday's spent receipt. Economic wealth relevant to substantive freedom should therefore be defined and audited as **an enduring bundle of continuation relations backed by physical service capacity, open routes, noncapture, and identified maintenance bearers**. Before aggregating everything into GDP or net worth, institutions must preserve the routes by which people actually use the conditions of life.

### 8.2 Symmetric Common Clearing and Revocable Renewal of Clearing Authority

The 1943 International Clearing Union proposal advanced a far-sighted constitutional design: recording surpluses and deficits in Bancor within one institution, levying **two-sided charges on excessive creditor and debtor balances alike**, requiring persistent creditors to share in adjustment, and establishing explicit rules for member withdrawal and annual rule amendment [@Keynes1943, §§I.4, II.6(7),(9),(16),(18)].

Proposition 7.1 (leg-by-leg performance required for joint clearing) and Theorem 7.7 (risk splitting and persistence of external liability across locally empty ledgers) ground two constitutional principles: first, persistent surpluses and persistent deficits belong inside one symmetric adjustment process accounting for how liquidity hoarding and financing burdens affect other participants' continuation; second, **the authority supplying final clearing and payment acceptance must itself operate under explicit authorization, periodic renewal, uncaptured exit, and same-source law revision**. Any platform, bank, or currency issuer monopolizing others' sole clearing gateway can capture their continuation simply by withholding settlement (Proposition 5.12(2)). Theorem 5.1's extra-role exit and noncapture criteria apply to clearing authorities themselves.

### 8.3 Shared Production Dividends and Freely Disposable Time

Every productive innovation draws upon accumulated public knowledge, shared infrastructure, everyday care work, and current cooperative inputs [@Fraser2016]. Lemma C12 in Section 9's public-production interface supplies an exact accounting template for net innovation dividends: reusing an already paid audited method preserves executability of every previously lawful finite action word while leaving **exactly \(1\) additional unit of available labor** in the actual successor state, with subsistence, maintenance, and financial claim matrices paid in full.

Constitutionalizing this template means **net productive gains are reckoned only after current living services, equipment and spatial maintenance debts (Section 3.3), care, and ecological obligations are paid in full**; the genuinely saved labor should then expand **uncaptured disposable time** and public provision. The test of whether technical progress advances freedom is razor-sharp: as output rises, does participants' power to say no to former roles (\(K_d\) and full-domain portfolios) expand, or do algorithmic gates tighten control?

### 8.4 Unbundling Exclusive Property, Public Mandates, and Intergenerational Commons

Treating property as indivisible private dominion—assigning all uncontracted residual control rights to private asset ownership [@HartMoore1990]—is a primary legal-coding device for manufacturing subordination and shielding liability [@Hohfeld1913; @Pistor2019]. Proposition 5.7 (tenure and mandate exits with \(m+1\) succession) and Theorem 7.7 demonstrate that entry, use, maintenance, return claims, exit continuation, and office succession can be unbundled by provenance and audited separately. Usage and management powers over housing, land, compute, and infrastructure ought to be granted jointly with maintenance duties and uncaptured exit for affected parties; any gatekeeper capable of cutting off others' basic living entrances must answer to public authorization and revocability [@GaoCapital, §§3, 6]. Across unenclosed shared domains—deep oceans, polar regions, digital commons, and future cooperative activity in outer space—prior arrival and maintenance justify bounded contribution claims, never permanent private sovereignty excluding later arrivals from entry and constitutional amendment.

### 8.5 Ecological External Liabilities, Later Arrivals, and Distributed Proof-Carrying Verification

Balancing monetary accounts never substitutes for restoring damaged soil and water or fulfilling long-term care. Theorem 7.5 (local halting does not extinguish debt) and Theorem 7.7 (source-grounded external liability \(\Lambda_n\) persists injectively after local open obligations are empty) establish a hard ecological and intergenerational floor: **organizational restructuring, project closure, or zeroing out a local ledger cannot erase material and social external liabilities**; ecological costs must remain live, enforceable obligation rows at affected sites until native material performance archives them.

Crucially, verifying this whole-ledger contract requires no omniscient central panopticon: independent processing operations inspect only their authorized channels, receipts, and successors, while **proof-carrying authority** places the primary burden of proof on the exercise of power itself—whoever alters others' living conditions must supply provenance, authorization, whole-ledger write-back, and uncaptured continuation.

## 9 Open Formal Interfaces: Seamless Extension to Production, Public Functions, and Distributed Protocols

A's post-departure life connects directly to productive access, public administration, material replication, and multi-site communication. Four self-contained formal interfaces carry their own source laws, states, and runs while plugging completion directly into whole-ledger obligations and actual successors (full definitions and proofs in Supplement Appendix C.5 Propositions C9–C13):

1. **Capital relations and port-permission symmetry (Proposition C9; directly anchoring [@GaoCapital])**: Permission laws specify who may enter each production state and port. Across all such laws, **five-layer absence of capital holds if and only if at every state and port, permission for the controller implies permission for every subject (absence of permission asymmetry)**. Paired negative control: uniformly closing admission to everyone (the all-zero law) also satisfies symmetry yet fails openness whenever technology, ports, and subjects are inhabited—so removing controller privilege must still be paired with verifying actual payment of A's living needs!
2. **Public functions and post-revocation continuation of live obligations (Proposition C10)**: Given inventory, authorization, obligation packet, and finite action word, the public-function generator produces response and whole-ledger successor: all input rows and slots are terminal **if and only if** a complete termination receipt exists, while any live obligation forces continuation even after prior authorization is withdrawn and the current task finishes. Arbitrary finite continuations preserve prior history prefixes and financial matrices; menu success delivers same-word payment, whereas failure pinpoints the exact item and shortage.
3. **Public-production replication and preservation of a one-unit labor dividend (Proposition C11 and Lemma C12)**: Under public improved technology, sufficient six-resource stocks, and nonnegative child inventories, replication pays child subsistence and maintenance within the same action word, preserves the full financial claim matrix, and costs parent net labor \(2\). Reusing a paid audited method saves \(1\) unit of parent labor and proves that **every** finite word \(w\) itemwise lawful at \(u\) remains itemwise lawful at slack state \(W_1(u)\) with \(\operatorname{execute}(W_1(u),w)=W_1(\operatorname{execute}(u,w))\)—turning saved labor into usable net slack in the actual successor.
4. **Two-site \(24\)-step distributed protocol fulfillment across all branches (Proposition C13)**: Two sites respond asynchronously from local queues and current signals across four delivery-timing branches \(\Theta=\{(0,0),(0,1),(1,0),(1,1)\}\). For **every adaptive callback** whose actual inputs satisfy communication admission, the active executor completes all input services, send readbacks, and final queue emptying in exactly \(24\) discrete steps, with the identical executed history consumed into whole-ledger write-back and literal next state.

## 10 Literature in Five-Axis Dialogue: From Preinstalled Individuals and Exception Sovereignty to Source-Native Constitutional Mathematics

Rather than inventing isolated terminology, this paper resolves long-standing structural gaps across political philosophy, capability and social-choice theory, monetary and legal economics, constitutional jurisprudence, and program verification within one provenance-preserving mathematical architecture. Below we engage each tradition in its strongest primary form and state our exact theorem-level advance.

### 10.1 Subject Ontology, Non-Contractual Preconditions, and Non-Dominating Participation

Hobbes begins with the parties to the covenant, while Rawls takes society's basic structure as the primary subject of justice [@Hobbes1651, chs. 13, 17; @Rawls1971, §§1–2]; Durkheim showed that private contracts rest on prior non-contractual norms and that the anomic division of labor arises where relations among functions lack regulation [@Durkheim1893, bk. I, ch. 7, bk. III, chs. 1–2]; and Parfit grounded personal survival in relational continuity [@Parfit1971], yet none supplied a constructive quotient turning activity traces into obligation bearers. Theorem 2.2, Section 2.3, and Proposition 3.2 close both ontological and capacity gaps: without preinstalled individuals, \(\Phi:U_\omega/{\sim_\ell}\xrightarrow{\sim}A_\omega\) generates enduring subjects across economic, biological, multi-agent, and strategic traces while barring seedless artificial actors, and position-indexed queues derive the monotone stable–critical–anomie phase law with empty full-debit runs in anomie.

On freedom, property, and power, Hirschman showed how credible exit sustains internal voice [@Hirschman1970, pp. 3–4, 35–36, 81–82]; Hart and Moore assigned residual control rights to private asset ownership [@HartMoore1990]; Pettit defined republican liberty as non-domination [@Pettit1997]; Anderson exposed unaccountable workplaces as “private governments” [@Anderson2015, pp. 64–65, 99–100, 110–111]; Widerquist grounded substantive freedom in independent subsistence sufficient to say no [@Widerquist2013]; and Fraser analyzed capitalism's erosion of social reproduction [@Fraser2016]. We turn those insights into exact theorems: Theorem 5.1 proves the five-gate exit characterization; Theorems 5.5–5.6 unfold four-stage paid exit while emptying four retaliatory retypings; and Propositions 5.7–5.8 unbundle residual control rights across tenure exit, \(m+1\) office succession, and non-substitutable basic income, public services, and paid jobs.

### 10.2 Capability Evaluation, Social Choice, Bilateral Matching, and Observer-Quotient Non-Identifiability

Sen shifted normative evaluation from commodities to capabilities [@Sen1979], and Robeyns placed conversion factors at the center of policy targeting [@Robeyns2017, §§2.6.3, 2.6.7]. We advance from **capability evaluation** to **exact repair identifiability**: Propositions 5.2–5.3 and Theorems 5.10–5.11 prove that even exact measurement of exit capacity plus reachability across every installed domain \(\rho_d\) admits a fixed-point-free involution kernel on \(\Omega_d\), blocking **every output universe and encoding** factored through \(\rho_d\) from separating capture removal from route restoration and locking coarse probability at \(1/2\), whereas retaining source failure kind \(\phi(x)\) restores uniquely effective repair and splits probability into \(1\) and \(0\).

The same observer-quotient geometry opens an orthogonal vertical dimension alongside social choice and market design. Arrow's theorem [@Arrow1950], the Gibbard–Satterthwaite theorem [@Gibbard1973; @Satterthwaite1975], Sen's Paretian liberal theorem [@Sen1970, Theorem I], and Gale and Shapley's deferred-acceptance stability model [@GaleShapley1962] establish properties **within** the visible preference and matching quotient. Gale–Shapley stability excludes blocking pairs. The value \((7,7)\) in Theorem 5.13 records the same installed balance on two occurrence paths. Across arbitrary agent and alternative carriers the theorem takes a visible axiom witness as given and proves that on \(O_{\mathrm{soc}}\) and across arbitrary hidden authority fibers, **given the corresponding axiom witness, or when bilateral matching balances at \((7,7)\) and trace-constrained narratives exclude fabrication, every strengthening claiming to decode true occurrence authority from visible outputs is strictly empty**. Aggregation and matching govern visible ballots and tables, but cannot pierce provenance erased by the observer quotient.

### 10.3 Monetary Hierarchy, Whole-Ledger Bookkeeping, and the Threefold Separation of Obligation Termination

Desan established money as a constitutional practice allocating common burdens and payment force [@Desan2013, pp. 1–3, 28–29, 36–37; @Desan2014, pp. 6–8]; Mehrling showed that payment at one monetary tier is a promise owed by the tier above, with consolidated balance sheets hiding inter-tier exposure [@Mehrling2013, §§I–IV]; Ellerman formalized double-entry bookkeeping via paired vector groups [@Ellerman2014]; Shavell studied how wealth limits recoverable damages and deterrence, and Pistor examined how legal coding insulates assets [@Shavell1986; @Pistor2019]; and Keynes's Clearing Union proposed symmetric creditor-debtor adjustment and withdrawal settlement [@Keynes1943, §§I.4, II.6(7),(9),(16),(18)].

Our whole-ledger theorems unify these strands rigorously: Sections 3.2 and 3.6 prove \(\mathcal P(e)\simeq\mathcal O(e)\) and full-settlement elimination, separating zero price quotes from settled debt while emptying standing and price domains upon complete fulfillment; Propositions 7.1–7.2 prove leg-by-leg clearing and non-shifting credit risk attribution; Theorem 7.5 strictly separates **strict-renewal exhaustion (depth \(3\)), faithful local root termination (depth \(9\)), and cross-root joint settlement (\(s_{\mathrm{clr}}\))**; Theorem 7.7 proves persistence and injectivity of source-grounded external liability \(\Lambda_n\) across locally empty ledgers; and Proposition 7.8 pinches every conservative sequential target of the exhausted source ledger to \(0\le B'\le 0\) across all universes.

### 10.4 Sovereign Decision, Dualist Constitutional Moments, Institutional Grammar, and Proof-Carrying Execution

In jurisprudence and formal rule systems, Hohfeld separated claim-rights from powers [@Hohfeld1913]; Kelsen posited a presupposed *Grundnorm* [@Kelsen1967, §34], Schmitt invoked extra-legal sovereign exception [@Schmitt1922, ch. 1], Hart joined rules of recognition and change [@Hart1961, chs. V–VI], and Ackerman separated everyday normal politics from higher constitutional moments [@Ackerman1991, ch. 1]; Crawford and Ostrom built ADICO institutional grammar and polycentric commons governance [@CrawfordOstrom1995, pp. 583–586; @Ostrom2009]; and Alchourrón, Gärdenfors, and Makinson (AGM) characterized norm contraction and revision [@AGM1985, §§1–2]. In computer science, Goguen and Burstall formalized cross-signature *institutions* [@GoguenBurstall1992], Necula introduced proof-carrying code (PCC) [@Necula1997, pp. 106–109], Catala verified default-logic statutory compilation [@MerigouxChataingProtzenko2021, §4.5], and Lean 4 provided a small-kernel dependent-type prover [@deMouraUllrich2021].

Three structural advances emerge at their intersection: first, Theorems 4.2–4.4 establish fourfold root-law closure (\(\mathrm P\lor\mathrm J\lor\mathrm A\lor\mathrm U\), \(\mathrm W\iff\mathrm A\lor\mathrm U\)), same-point realization, and zero-choice endogenous runtime classification, proving that **constitutional self-amendment has a construction within the installed process**. That construction supplies a formal model for the higher lawmaking discussed by Ackerman. Active reform and same-source constitutional revision separate automatically from causal resolution on the same obligation row while standing apart from successor-free rupture; second, unlike proposition-only AGM revision without bearer ledgers, Theorem 7.4 migrates live pre-revision obligations into the revised first write until native performance archives them; third, extending receiver-safety PCC and static statutory compilation into literal same-occurrence proof-carrying legislation and an all-depth constitutional obligation, Theorems 4.4 and 6.2–6.5 derive bearer routing, uncaptured exit, and cofinal amendability from the same payment under the all-depth regeneration contract.

### 10.5 Five-Axis Synthesis Table and the Joint Force of Universal Theorems

| Theoretical axis | Representative primary works | Open structural gap in prior literature | Theorem-level advance and location here |
| --- | --- | --- | --- |
| Subject ontology, anomie phases, and non-dominating exit | [@Hobbes1651; @Durkheim1893; @Rawls1971; @Parfit1971; @Hirschman1970; @HartMoore1990; @Pettit1997; @Anderson2015; @Widerquist2013; @Fraser2016] | Preinstalled individual sets; anomie and private residual control lack whole-ledger replacements; exit & 3-tool division lack iff criteria | Seed-lineage quotient, phantom-AI ban & anomie phase law (Theorem 2.2, Prop. 3.2); 5-gate exit, anti-retaliation, succession & 3-tool separation (Theorems 5.1, 5.5–5.6, Props. 5.7–5.8) |
| Capability evaluation, social choice, matching, and observer kernel | [@Sen1979; @Robeyns2017; @Arrow1950; @GaleShapley1962; @Sen1970; @Gibbard1973; @Satterthwaite1975] | Multidimensional capabilities focus on outcome evaluation; social choice and matching stay intra-quotient without cross-tier authority identification | All-universe post-processing impossibility & failure-kind recovery (Theorems 5.10–5.11); carrier-polymorphic Arrow/GS/Sen, visible matching & trace-narrative bridge (Theorem 5.13) |
| Monetary hierarchy, whole ledgers, and obligation termination | [@Desan2013; @Desan2014; @Mehrling2013; @Keynes1943; @Ellerman2014; @Shavell1986; @Pistor2019] | Consolidated balance sheets and asset shielding blur renewal exhaustion, local halting, and final debt settlement | \(\mathcal P(e)\simeq\mathcal O(e)\) & settlement elimination (§3.2, Prop. 3.2); 3-locus termination separation, empty-ledger liability \(\Lambda_n\) & zero-budget pinch (Props. 7.1, 7.8, Theorems 7.5, 7.7) |
| Constitutional root law, reform/revision classification, and proof-carrying law | [@Hohfeld1913; @Kelsen1967; @Schmitt1922; @Hart1961; @Ackerman1991; @CrawfordOstrom1995; @Ostrom2009; @AGM1985; @GoguenBurstall1992; @Necula1997; @MerigouxChataingProtzenko2021; @deMouraUllrich2021] | *Grundnorm*, sovereign suspension & informal constitutional moments; AGM lacks bearer migration ledgers; PCC stops short of legislation | 4-way root law barring 5th channel, active reform/revision and terminal rupture & same-occurrence PCL (Theorems 4.2–4.4); live migration (Theorem 7.4); cross-universe memory (§3.7) |
| Companion process algebra, whole ledgers, and political economy | [@GaoProcess; @GaoLedger; @GaoConstitution; @GaoCapital] | Foundational process and conservation calculi require a complete constitutional synthesis anchoring downstream production treatises | All-depth 6-fold regeneration, universal lawful-payment preservation, strict progress, cofinal amendment-with-birth & 4 open interfaces (Theorems 1.1–1.3, 6.2–6.5, §9) |

Table 7: Five-axis synthesis of primary literature and theorem-level advances established in this paper.

Table 7 exhibits the combined force of pairing universal constructive theorems with sharp impossibility theorems: constructive existence alone might look like one institutional option among many, whereas all-universe post-processing impossibility, observer-kernel social-choice and matching exclusions, and zero-budget conservative closure prove that **every shortcut attempting to bypass activity provenance, whole-ledger obligation migration, and uncaptured routes mathematically hits an exact non-identifiability or empty-type wall**.

## 11 Conclusion: Complete Disposition, Another Beginning

Worker A's departure from a job brings institutional judgment back from a single number to an auditable network of relations. The “three zeros” break at payment incidence, route incidence, and noncapture respectively; the “two ones” separate single-channel escape from complete multi-domain living support; and even placing full-domain reachability sets, Arrow or strategy-proof collective choice rules, \((7,7)\)-balanced bilateral matchings, and strictly trace-verified narratives on the table cannot recover underlying source authority or exact repairs once cross-tier provenance is forgotten. Counting and aggregation can be completely accurate while diagnosis and accountability still have to trace the source.

The positive construction delivers the other half of the answer. Without preinstalled individuals, activity traces generate enduring subjects via the canonical lineage quotient; the fourfold root law closes off-ledger writing while realizing bearer-retaining refusal, whole-ledger action, and exact-failure self-amendment at one constitutional point; misdirected credentials are refused without forfeiting recourse through the node's own native payment; and when rules or theories change, pre-existing obligations migrate live across the first write—past renewal exhaustion and local procedural halting—until native performance genuinely settles them.

All-depth regeneration and strict progress carry these guarantees across unbounded time. At every natural-number depth, one payment jointly realizes six regeneration guarantees and opens the exact entry to the next depth; at every position of any registered cycle, every lawful payment carries the complete constitutional contract into its actual target, preserving the entire earlier paid frontier while realizing a fresh occurrence beyond the old authority image; and beyond every finite stage, one and the same later step jointly accomplishes actual law revision and payment-supported new birth. Yesterday's receipt cannot pay for today's life, and today's disposition cannot freeze tomorrow's amendment: an institution accountable to living persons must close every exercise of power with full provenance while supplying the paid conditions for another free beginning.

## References

[GaoProcess] Gao, Jian. *Source-Native Process Algebra and Initial-Coface Revision: Four-Tier Identity, Exact Evaluation Kernels, and Reversible Incremental Continuation*. Zenodo, Version 3, 2026 (Version 2 DOI: 10.5281/zenodo.23297175). [doi:10.5281/zenodo.24147130](https://doi.org/10.5281/zenodo.24147130).

[GaoLedger] Gao, Jian. *Provenance-Preserving Conservation Calculus and Non-Free Continuity: Whole-Event Ledgers, Observer Safety, and Well-Founded Settlement*. Zenodo, Version 2, 2026 (Version 1 DOI: 10.5281/zenodo.23437454). [doi:10.5281/zenodo.24147183](https://doi.org/10.5281/zenodo.24147183).

[GaoConstitution] Gao, Jian. *An Economic Constitution of Possibility*. Zenodo, Version 2, 2026. [doi:10.5281/zenodo.23917902](https://doi.org/10.5281/zenodo.23917902).

[GaoCapital] Gao, Jian. *The Structural Theorem of Capitalism: Minimal Permission Support, Public Functional Replay, and Unique Minimal Risk Pricing*. Zenodo, Version 2, 2026. [doi:10.5281/zenodo.24155195](https://doi.org/10.5281/zenodo.24155195).

[Hobbes1651] Hobbes, Thomas. *[Leviathan, or The Matter, Forme, & Power of a Common-Wealth Ecclesiasticall and Civill](https://www.gutenberg.org/ebooks/3207)*. London: Andrew Crooke, 1651.

[Durkheim1893] Durkheim, Émile. *The Division of Labour in Society*. Translated by W. D. Halls, introduction by Lewis Coser. Macmillan, 1984 (originally published as *De la division du travail social*, 1893). [doi:10.1007/978-1-349-17729-5](https://doi.org/10.1007/978-1-349-17729-5).

[Hohfeld1913] Hohfeld, Wesley Newcomb. “Some Fundamental Legal Conceptions as Applied in Judicial Reasoning.” *The Yale Law Journal* 23(1), 1913, pp. 16–59. [doi:10.2307/785533](https://doi.org/10.2307/785533).

[Schmitt1922] Schmitt, Carl. *Political Theology: Four Chapters on the Concept of Sovereignty*. Translated by George Schwab. University of Chicago Press, 2005 (originally published as *Politische Theologie*, 1922). [doi:10.7208/chicago/9780226738901.001.0001](https://doi.org/10.7208/chicago/9780226738901.001.0001).

[Keynes1943] Great Britain, Treasury. *[Proposals for an International Clearing Union](https://fraser.stlouisfed.org/title/federal-reserve-bulletin-62/june-1943-21058/fulltext)*. Cmd. 6437, April 1943. Reprinted in *Federal Reserve Bulletin*, June 1943.

[Arrow1950] Arrow, Kenneth J. “A Difficulty in the Concept of Social Welfare.” *Journal of Political Economy* 58(4), 1950, pp. 328–346. [doi:10.1086/256963](https://doi.org/10.1086/256963).

[Hart1961] Hart, H. L. A. *The Concept of Law*. 3rd ed., Oxford University Press, 2012 (1st ed. Clarendon Press, 1961). [doi:10.1093/he/9780199644704.001.0001](https://doi.org/10.1093/he/9780199644704.001.0001).

[GaleShapley1962] Gale, D., and L. S. Shapley. “College Admissions and the Stability of Marriage.” *The American Mathematical Monthly* 69(1), 1962, pp. 9–15. [doi:10.1080/00029890.1962.11989827](https://doi.org/10.1080/00029890.1962.11989827).

[Kelsen1967] Kelsen, Hans. *Pure Theory of Law*. Translated by Max Knight from the 2nd German ed. (*Reine Rechtslehre*, 1960). University of California Press, 1967. [doi:10.1525/9780520312296](https://doi.org/10.1525/9780520312296).

[Sen1970] Sen, Amartya. “The Impossibility of a Paretian Liberal.” *Journal of Political Economy* 78(1), 1970, pp. 152–157. [doi:10.1086/259614](https://doi.org/10.1086/259614).

[Hirschman1970] Hirschman, Albert O. *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Harvard University Press, 1970.

[Parfit1971] Parfit, Derek. “Personal Identity.” *The Philosophical Review* 80(1), 1971, pp. 3–27. [doi:10.2307/2184309](https://doi.org/10.2307/2184309).

[Rawls1971] Rawls, John. *A Theory of Justice*. Harvard University Press, 1971. [doi:10.4159/9780674042605](https://doi.org/10.4159/9780674042605).

[Gibbard1973] Gibbard, Allan. “Manipulation of Voting Schemes: A General Result.” *Econometrica* 41(4), 1973, pp. 587–601. [doi:10.2307/1914083](https://doi.org/10.2307/1914083).

[Satterthwaite1975] Satterthwaite, Mark Allen. “Strategy-Proofness and Arrow's Conditions: Existence and Correspondence Theorems for Voting Procedures and Social Welfare Functions.” *Journal of Economic Theory* 10(2), 1975, pp. 187–217. [doi:10.1016/0022-0531(75)90050-2](https://doi.org/10.1016/0022-0531(75)90050-2).

[Sen1979] Sen, Amartya. “[Equality of What?](https://ophi.org.uk/sites/default/files/Sen-1979_Equality-of-What.pdf)” *The Tanner Lectures on Human Values*, Vol. 1, delivered at Stanford University, 22 May 1979, Cambridge University Press, 1980, pp. 197–220.

[AGM1985] Alchourrón, Carlos E., Peter Gärdenfors, and David Makinson. “On the Logic of Theory Change: Partial Meet Contraction and Revision Functions.” *The Journal of Symbolic Logic* 50(2), 1985, pp. 510–530. [doi:10.2307/2274239](https://doi.org/10.2307/2274239).

[Shavell1986] Shavell, Steven. “The Judgment Proof Problem.” *International Review of Law and Economics* 6(1), 1986, pp. 45–58. [doi:10.1016/0144-8188(86)90038-4](https://doi.org/10.1016/0144-8188(86)90038-4).

[HartMoore1990] Hart, Oliver, and John Moore. “Property Rights and the Nature of the Firm.” *Journal of Political Economy* 98(6), 1990, pp. 1119–1158. [doi:10.1086/261729](https://doi.org/10.1086/261729).

[Ackerman1991] Ackerman, Bruce. *We the People, Volume 1: Foundations*. Belknap Press of Harvard University Press, 1991.

[GoguenBurstall1992] Goguen, Joseph A., and Rod M. Burstall. “Institutions: Abstract Model Theory for Specification and Programming.” *Journal of the ACM* 39(1), 1992, pp. 95–146. [doi:10.1145/147508.147524](https://doi.org/10.1145/147508.147524).

[CrawfordOstrom1995] Crawford, Sue E. S., and Elinor Ostrom. “A Grammar of Institutions.” *American Political Science Review* 89(3), 1995, pp. 582–600. [doi:10.2307/2082975](https://doi.org/10.2307/2082975).

[Necula1997] Necula, George C. “Proof-Carrying Code.” *Proceedings of the 24th ACM SIGPLAN-SIGACT Symposium on Principles of Programming Languages*, 1997, pp. 106–119. [doi:10.1145/263699.263712](https://doi.org/10.1145/263699.263712).

[Pettit1997] Pettit, Philip. “[Republicanism: A Propositional Summary](https://liberalarts.tamu.edu/pols/wp-content/uploads/sites/20/2021/04/Pettit-Republicanism.pdf).” In *Republicanism: A Theory of Freedom and Government*. Clarendon Press, 1997.

[Ostrom2009] Ostrom, Elinor. “[Beyond Markets and States: Polycentric Governance of Complex Economic Systems](https://www.nobelprize.org/uploads/2018/06/ostrom_lecture.pdf).” Nobel Prize Lecture, 8 December 2009 (*American Economic Review* 100(3), 2010, pp. 641–672). [doi:10.1257/aer.100.3.641](https://doi.org/10.1257/aer.100.3.641).

[Desan2013] Desan, Christine. *[Creation Stories: Myths About the Origins of Money](https://dash.harvard.edu/bitstreams/7312037c-f89a-6bd4-e053-0100007fdf3b/download)*. Harvard Public Law Working Paper No. 13-20, revised 30 July 2013.

[Mehrling2013] Mehrling, Perry. “The Inherent Hierarchy of Money.” In Lance Taylor, Armon Rezai, and Thomas Michl (eds.), *Social Fairness and Economics: Economic Essays in the Spirit of Duncan Foley*. Routledge, 2013, pp. 394–404.

[Widerquist2013] Widerquist, Karl. *Independence, Propertylessness, and Basic Income: A Theory of Freedom as the Power to Say No*. Palgrave Macmillan, 2013. [doi:10.1057/9781137313096](https://doi.org/10.1057/9781137313096).

[Desan2014] Desan, Christine. *Making Money: Coin, Currency, and the Coming of Capitalism*. Oxford University Press, 2014. [doi:10.1093/acprof:oso/9780198709572.001.0001](https://doi.org/10.1093/acprof:oso/9780198709572.001.0001).

[Ellerman2014] Ellerman, David. “On Double-Entry Bookkeeping: The Mathematical Treatment.” *Accounting Education* 23(5), 2014, pp. 483–501. [doi:10.1080/09639284.2014.949803](https://doi.org/10.1080/09639284.2014.949803).

[Anderson2015] Anderson, Elizabeth. “[Liberty, Equality, and Private Government](https://tannerlectures.utah.edu/_resources/documents/a-to-z/a/Anderson%20manuscript.pdf).” *The Tanner Lectures on Human Values*, delivered at Princeton University, 4–5 March 2015.

[Fraser2016] Fraser, Nancy. “[Contradictions of Capital and Care](https://newleftreview.org/issues/ii100/articles/nancy-fraser-contradictions-of-capital-and-care).” *New Left Review* 100, 2016, pp. 99–117.

[Robeyns2017] Robeyns, Ingrid. *Wellbeing, Freedom and Social Justice: The Capability Approach Re-Examined*. Open Book Publishers, 2017. [doi:10.11647/OBP.0130](https://doi.org/10.11647/OBP.0130).

[Pistor2019] Pistor, Katharina. “[Coding Capital for the Globe](https://ssir.org/books/excerpts/entry/coding_capital_for_the_globe).” *Stanford Social Innovation Review*, 2019 (excerpt from *The Code of Capital*). [doi:10.48558/GYV7-NE54](https://doi.org/10.48558/GYV7-NE54).

[deMouraUllrich2021] de Moura, Leonardo, and Sebastian Ullrich. “The Lean 4 Theorem Prover and Programming Language.” In *Automated Deduction – CADE 28*, Lecture Notes in Computer Science, Vol. 12699, Springer, 2021, pp. 625–635. [doi:10.1007/978-3-030-79876-5_37](https://doi.org/10.1007/978-3-030-79876-5_37).

[MerigouxChataingProtzenko2021] Merigoux, Denis, Nicolas Chataing, and Jonathan Protzenko. “Catala: A Programming Language for the Law.” *Proceedings of the ACM on Programming Languages* 5(ICFP), Article 77, 2021, pp. 1–29. [doi:10.1145/3473582](https://doi.org/10.1145/3473582).
