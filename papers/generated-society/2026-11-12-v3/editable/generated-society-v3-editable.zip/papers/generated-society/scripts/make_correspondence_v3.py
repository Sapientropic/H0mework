#!/usr/bin/env python3
"""Generate v3 theorem-to-source correspondence and M7/G8 public H0mework bindings.

Preserves frozen v2 theorem-correspondence.md and records/theorem-correspondence.json
byte-for-byte. Reads fixed Git blobs from Homework (df421ff600085cbc290a7ae946193961bed7c83b)
and H0mework (2d6fbc96e33b7c4c3cfd91104fda74e3caeda045 and fd6147f8c337d88ebf72d91ddadef0aa601e6c2e).
Read the compilation epoch of each owner from the pinned public export map,
and retain the intake reading as a separate source identity,
without running Lean or mutating any source repository.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess

PAPER = Path(__file__).resolve().parents[1]
RECORDS = PAPER / "records"

HW_COMMIT = "df421ff600085cbc290a7ae946193961bed7c83b"
H0_MAIN_COMMIT = "2d6fbc96e33b7c4c3cfd91104fda74e3caeda045"
H0_G8_COMMIT = "fd6147f8c337d88ebf72d91ddadef0aa601e6c2e"
H0_REPO_URL = "https://github.com/Sapientropic/H0mework"

M7_SPECS = [
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Observer/ReadoutFactorization.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Rdf421ff6/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Observer/ReadoutFactorization.lean",
        "declarations": [
            "ReadoutFactorization",
            "AuthorityCompleteReadoutAt",
            "toAuthorityFactorization",
            "forceActualReconstruction",
            "forceNaturalActualReconstruction",
            "boundary_rejectsAuthorityCompleteReadout",
            "identityObserver_hasNaturalAuthorityReconstruction",
        ],
        "direct_consumer": "M7ReadoutFactorizationWholeRegression.lean :: m7ReadoutFactorizationWholeDirectConsumer",
        "supplement": "C.6.1（命题 C14）",
        "scope": "任意类型宇宙中的权威观察器可见因子化、发生权威完备性迫使、双侧与自然重构迫使、源生附着边界排斥及恒等观察器正控。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/PreferenceReadout.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/PreferenceReadout.lean",
        "declarations": [
            "WeakPreference",
            "LinearPreference",
            "HiddenFibreExtension",
            "attachment_noAuthorityFactorization",
        ],
        "direct_consumer": "SocialChoiceAuthorityBridgeRegression.lean :: societySocialChoiceAuthorityBridgeDirectConsumer",
        "supplement": "C.6.2（定理 C15）",
        "scope": "任意主体与备选方案载体上的弱偏好／线性偏好剖面及任意隐藏权威纤维扩张的无权威因子化附着边界。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/ArrowObserverBridge.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/ArrowObserverBridge.lean",
        "declarations": [
            "ArrowVisibleAxiomBundle",
            "ArrowOccurrenceAuthorityCompleteness",
            "arrowAuthorityStrengtheningNoGo",
            "preferenceReadouts_hidden_invariant",
            "standardArrowAxiomsDoesNotForceAuthority",
        ],
        "direct_consumer": "SocialChoiceAuthorityBridgeRegression.lean :: society_arrowAuthorityStrengtheningNoGo; society_standardArrowAxiomsDoesNotForceAuthority",
        "supplement": "C.6.2（定理 C15）",
        "scope": "不重证经典横向 Arrow 定理；保留可见公理束前提，证明跨观察核的发生权威完备性加强为空且可见公理不蕴涵隐藏纤维权威因子化。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/GibbardSatterthwaiteObserverBridge.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/GibbardSatterthwaiteObserverBridge.lean",
        "declarations": [
            "GibbardSatterthwaiteVisibleAxiomBundle",
            "GibbardSatterthwaiteOccurrenceAuthorityCompleteness",
            "gibbardSatterthwaiteAuthorityStrengtheningNoGo",
            "preferenceAndChoice_hidden_invariant",
            "standardGibbardSatterthwaiteAxiomsDoesNotForceAuthority",
        ],
        "direct_consumer": "SocialChoiceAuthorityBridgeRegression.lean :: society_gibbardSatterthwaiteAuthorityStrengtheningNoGo; society_standardGibbardSatterthwaiteAxiomsDoesNotForceAuthority",
        "supplement": "C.6.2（定理 C15）",
        "scope": "不重证经典横向 Gibbard-Satterthwaite 定理；在不少于三备选项等可见公理束原样保留下证明跨观察核权威加强为空及隐藏纤维非强制性。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/SenObserverBridge.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/SenObserverBridge.lean",
        "declarations": [
            "SenVisibleAxiomBundle",
            "SenOccurrenceAuthorityCompleteness",
            "senAuthorityStrengtheningNoGo",
            "preferenceReadouts_hidden_invariant",
            "standardSenAxiomsDoesNotForceAuthority",
        ],
        "direct_consumer": "SocialChoiceAuthorityBridgeRegression.lean :: society_senAuthorityStrengtheningNoGo; society_standardSenAxiomsDoesNotForceAuthority",
        "supplement": "C.6.2（定理 C15）",
        "scope": "不重证经典横向 Sen 自由帕累托定理；在双向最小自由等可见公理束原样保留下证明跨观察核权威加强为空及隐藏纤维非强制性。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M7/SocialChoice/HiddenFibreControlRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M7/SocialChoice/HiddenFibreControlRegression.lean",
        "declarations": [
            "swapEquiv",
            "extension",
            "attachment",
        ],
        "direct_consumer": "SocialChoiceAuthorityBridgeRegression.lean :: booleanHiddenFibre_minimalBoundaryNoAuthorityFactorization",
        "supplement": "C.6.2（定理 C15，例 5.1）",
        "scope": "二点布尔翻转隐藏权威纤维最小可执行负控。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M7/SocialChoice/SocialChoiceAuthorityBridgeRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M7/SocialChoice/SocialChoiceAuthorityBridgeRegression.lean",
        "declarations": [
            "SocietySocialChoiceAuthorityBridgeCertificate",
            "societySocialChoiceAuthorityBridgeDirectConsumer",
            "booleanHiddenFibre_minimalBoundaryNoAuthorityFactorization",
        ],
        "direct_consumer": "M7WholeProgramRegression.lean :: m7WholeProgram",
        "supplement": "C.6.2（定理 C15）",
        "scope": "社会观察实例 O_soc 上的三类社会选择权威加强排斥与任意宇宙隐藏纤维负控总装。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Matching/VisibleBalance.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Matching/VisibleBalance.lean",
        "declarations": [
            "VisibleBalanceReadout",
            "BalancedImage",
            "balancedImage_has_positive_witness",
        ],
        "direct_consumer": "MatchingAuthorityIdentificationRegression.lean :: matchingAuthorityIdentificationDirectConsumer",
        "supplement": "C.6.3（命题 C16）",
        "scope": "可见双边匹配平衡子类型及其正向非空见证。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M7/Matching/MatchingAuthorityIdentificationRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M7/Matching/MatchingAuthorityIdentificationRegression.lean",
        "declarations": [
            "matching_output_exact",
            "matching_no_complete_authority_identification",
            "matching_no_complete_actual_path_identification",
            "matchingAuthorityIdentificationDirectConsumer",
        ],
        "direct_consumer": "MatchingHistoryWholeRegression.lean :: matchingHistoryWholeDirectConsumer; M7WholeProgramRegression.lean :: m7WholeProgram",
        "supplement": "C.6.3（命题 C16，式 C.7）",
        "scope": "O_soc 上正值双边匹配 (some 7, some 7) 与发生权威／全发生路径不可识别。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/History/TraceConstrainedNarrative.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Cognition/Selfhood/Narrative.lean",
        "declarations": [
            "TraceConstrainedNarrativeReadout",
            "SupportsAt",
            "NarrativeFibreAt",
            "narrativeFibre_not_subsingleton",
            "not_supports_of_claim_absent",
        ],
        "direct_consumer": "NarrativeAuthorityIdentificationRegression.lean :: narrativeAuthorityIdentificationDirectConsumer",
        "supplement": "C.6.3（命题 C16）",
        "scope": "受既有发生迹严格约束的叙事读出、未见证原子拒绝（防虚构）与非单点叙事发生纤维。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M7/History/NarrativeAuthorityIdentificationRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M7/History/NarrativeAuthorityIdentificationRegression.lean",
        "declarations": [
            "visible_narrative_factorization_positive",
            "every_emitted_narrative_is_trace_constrained",
            "narrative_no_complete_authority_identification",
            "narrativeAuthorityIdentificationDirectConsumer",
        ],
        "direct_consumer": "MatchingHistoryWholeRegression.lean :: matchingHistoryWholeDirectConsumer; M7WholeProgramRegression.lean :: m7WholeProgram",
        "supplement": "C.6.3（命题 C16）",
        "scope": "O_soc 上复用既有发生迹的共同叙事正向支持与发生权威完备性为空。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M7/M7WholeProgramRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M7/M7WholeProgramRegression.lean",
        "declarations": [
            "M7WholeProgramCertificate",
            "m7WholeProgram",
        ],
        "direct_consumer": "MInfinityWholeProgramRegression.lean :: m4ThroughM10",
        "supplement": "C.1、C.6.3",
        "scope": "将围棋视野读出、匹配、受迹叙事与全宇宙三类社会选择观察核桥接装入完整基础 F_h 的 m4ThroughM10 字段。",
    },
]

M8_M10_SPECS = [
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Renewal/SourceGeneratedRenewalFace.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Society/Renewal/RenewalFaceSource.lean",
        "declarations": [
            "SourceGeneratedRenewalFace",
            "noSourceSeed_noRenewalFace",
            "RenewalControlAsymmetryAt",
            "RenewalDebtAsymmetryAt",
        ],
        "direct_consumer": "M8RenewalFoundationRegression.lean :: m8RenewalFoundation",
        "supplement": "C.7.1（命题 C17）",
        "scope": "全称无免费续生面禁令（含空人工主体种子）与单向控制权限／债务流向不对称纤维。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Renewal/SourceInstalledRenewalProjection.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Society/Renewal/InstalledRenewalProjection.lean",
        "declarations": [
            "SourceNativeRenewalProjectionLaw",
            "distinctRootOccurrences_generate_distinctSourceSeeds",
            "withRenewalProjection",
            "SourceInstalledRenewalAt",
            "rootAnswerAndNext_factorizes",
        ],
        "direct_consumer": "M8JointRootInstallationRegression.lean :: jointM8RootInstallationDirectConsumer",
        "supplement": "C.7.1（命题 C17）",
        "scope": "预发射和类型投影提升、活跃根发生源种子反坍缩与同根因果演化包因子化。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Money/PurchasingPowerStanding.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Money/PurchasingPowerStanding.lean",
        "declarations": [
            "PurchasingPowerStandingAt",
            "purchasingPowerRenewalStep",
            "fullyFulfilled_eliminatesStandingAndPrice",
            "fullyFulfilledOccurrence_eliminatesStanding",
        ],
        "direct_consumer": "PurchasingPowerStandingRegression.lean :: purchasingPowerStandingDirectConsumer",
        "supplement": "C.7.1（命题 C17，式 C.8）",
        "scope": "九宇宙多态购买力续生与完全清偿同步消去购买力地位及价格观察定义域。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M8/M8WholeProgramRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M8/M8WholeProgramRegression.lean",
        "declarations": [
            "M8WholeProgramCertificate",
            "m8WholeProgram",
        ],
        "direct_consumer": "M9WholeProgramRegression.lean :: m9WholeProgram",
        "supplement": "C.7.1（命题 C17）",
        "scope": "选举、购买力、关系维护与有迹人工主体四面预发射同根共同安装及 noFreeAISeed 负控。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Capacity/OccurrenceCapacityPhase.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Capacity/OccurrenceCapacityPhase.lean",
        "declarations": [
            "SourceGeneratedExactQueuePrefixAt",
            "SourceGeneratedOccurrenceCapacityPhaseAt",
            "phaseTag_eq_stable_iff",
            "phaseTag_eq_critical_iff",
            "phaseTag_eq_anomie_iff",
            "sameSource_generates_threePhases",
        ],
        "direct_consumer": "OccurrenceCapacityPhaseRegression.lean :: occurrenceCapacityPhaseDirectConsumer",
        "supplement": "C.7.2（命题 C18）",
        "scope": "零选择发生率—容量稳定、临界与失范（anomie）三相充要判据及同源三截点生成。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Capacity/OccurrenceCapacityTransition.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Capacity/OccurrenceCapacityTransition.lean",
        "declarations": [
            "anomie_persistent",
            "stable_hereditary",
            "critical_cut_unique",
            "no_stable_to_anomie_at_successor",
            "anomie_backlog_strictly_grows",
        ],
        "direct_consumer": "OccurrenceCapacityTransitionRegression.lean :: occurrenceCapacityTransitionDirectConsumer",
        "supplement": "C.7.2（命题 C18）",
        "scope": "沿精确队列前缀序的单调相变律、唯一临界边界与失范未决积压严格递增。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Capacity/OccurrenceCapacityConsumer.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Capacity/OccurrenceCapacityConsumer.lean",
        "declarations": [
            "backlog_lineage_eq_focal",
            "critical_targetBudget_eq_zero",
            "anomie_forbids_full_debited_consumption",
            "anomie_forbids_full_debited_run",
        ],
        "direct_consumer": "OccurrenceCapacityDebitConsumerRegression.lean :: occurrenceCapacityDebitDirectConsumer",
        "supplement": "C.7.2（命题 C18，式 C.9）",
        "scope": "积压谱系保持、临界实付运行耗尽预算至零与失范相全额实付扣减运行空性。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M10/M10WholeProgramRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M10/M10WholeProgramRegression.lean",
        "declarations": [
            "M10WholeProgramCertificate",
            "m10WholeProgram",
        ],
        "direct_consumer": "MInfinityWholeProgramRegression.lean :: m4ThroughM10",
        "supplement": "C.1、C.7.2",
        "scope": "发生率—容量三相生成、单调相变与实付扣款总装并汇入 F_h 的 m4ThroughM10 字段。",
    },
]

M9_SPECS = [
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Revision/SourceGeneratedInstitutionalDichotomy.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Revision/SourceGeneratedInstitutionalDichotomy.lean",
        "declarations": [
            "SourceGeneratedInstitutionalDichotomyAt",
            "SourceGeneratedRevolutionaryTickAt",
            "twoRows_share_generatedNext",
        ],
        "direct_consumer": "InstitutionalRevisionRegression.lean :: institutionalRevisionDirectConsumer",
        "supplement": "C.7.3（定理 C19，式 C.10）",
        "scope": "封存询问运行时在任意深度零选择内生分流同法改良与同源修宪革命，且双行共享同一生成后继。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Revision/SourceGeneratedInstitutionalRevision.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Revision/SourceGeneratedInstitutionalRevision.lean",
        "declarations": [
            "SourceNativeBoundedInstitutionalReformAt",
            "lawSurface_preserved",
            "RootedRevolutionaryInstitutionalRevisionAt",
            "generatedRow_hasNoOldPreimage",
            "SourceOwnedInstitutionalRuptureAt",
            "noSameLedgerSuccessor",
            "noRootInstalledRenewal",
            "noInstalledFailureFace_noRevolutionaryProducer",
        ],
        "direct_consumer": "InstitutionalRevisionRegression.lean :: institutionalRevisionDirectConsumer",
        "supplement": "C.7.3（定理 C19，式 C.10）",
        "scope": "有界同法改良保持法面、同源修宪革命新障碍行无旧原像、无失败面革命禁令及权威终结断裂无同账后继负控。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Society/Legislation/ProofCarryingLegislation.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Legislation/ProofCarryingLegislation.lean",
        "declarations": [
            "SourceInstalledRenewalRuntimeSpliceAt",
            "ProofCarryingLegislationAt",
            "sourceGeneratedProofCarryingLegislation",
            "ProofCarryingRevolutionaryConsumptionAt",
        ],
        "direct_consumer": "ProofCarryingLegislationRegression.lean :: proofCarryingLegislationDirectConsumer",
        "supplement": "C.7.3（定理 C19，式 C.11）",
        "scope": "根、访问、开放责任行与时间因果发生四重异质拼接下的字面同发生零选择携证立法。",
    },
    {
        "hw_path": "Lean/SaturationMonoid/ProcessGame/Regression/Society/M9/M9WholeProgramRegression.lean",
        "h0_commit": H0_MAIN_COMMIT,
        "h0_path": "Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Regression/Society/M9/M9WholeProgramRegression.lean",
        "declarations": [
            "M9WholeProgramCertificate",
            "m9WholeProgram",
        ],
        "direct_consumer": "M10WholeProgramRegression.lean :: m10WholeProgram",
        "supplement": "C.7.3（定理 C19）",
        "scope": "规范运行 d=0 革命接 d=1 同法改良、终结断裂负控与联合同发生携证立法全程序回归。",
    },
]


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def git_file(repo: Path, commit: str, path: str) -> tuple[str, bytes]:
    blob = subprocess.check_output(
        ["git", "-C", str(repo), "rev-parse", f"{commit}:{path}"], text=True
    ).strip()
    raw = subprocess.check_output(["git", "-C", str(repo), "show", f"{commit}:{path}"])
    return blob, raw


def declaration_line(text: str, name: str, path: str) -> int:
    ident = re.escape(name)
    header = (
        r"(?m)^(?:noncomputable\s+|private\s+|protected\s+|@\[[^\]]+\]\s+)*"
        r"(?:theorem|lemma|def|structure|inductive|class|abbrev)\s+(?:[A-Za-z0-9_]+\.)*"
        + ident + r"\b"
    )
    match = re.search(header, text) or re.search(r"(?m)^[^\n/-]*\b" + ident + r"\b", text)
    if match is None:
        raise ValueError(f"Missing {name} in {path}")
    return text.count("\n", 0, match.start()) + 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--homework", type=Path, required=True)
    parser.add_argument("--h0mework", type=Path, required=True)
    args = parser.parse_args()

    v2 = json.loads((RECORDS / "theorem-correspondence.json").read_text(encoding="utf-8"))
    zh = (PAPER / "manuscript.md").read_text(encoding="utf-8")
    titles = dict(re.findall(r"^\*\*(?:定理|命题|引理)\s+(\d+\.\d+)（([^）]+)）", zh, re.M))
    assert len(titles) == 35, f"Expected 35 named results in manuscript.md, found {len(titles)}"

    _, raw_export = git_file(args.h0mework, H0_MAIN_COMMIT, "tools/export-map.json")
    owners = {row["path"]: row for row in json.loads(raw_export)["modules"]}

    def verify_specs(specs):
        row_sources = []
        pub_bindings = []
        for spec in specs:
            hw_blob, hw_raw = git_file(args.homework, HW_COMMIT, spec["hw_path"])
            h0_blob, h0_raw = git_file(args.h0mework, spec["h0_commit"], spec["h0_path"])
            owner = owners[spec["h0_path"]]
            epoch, source = owner["source_revision"], owner["source_path"]
            source_blob, source_raw = git_file(args.homework, epoch, source)
            if sha(source_raw) != owner["source_sha256"] or sha(h0_raw) != owner["target_sha256"]:
                raise ValueError(f"Compilation source identity differs for {spec['h0_path']}")
            hw_text, source_text = hw_raw.decode("utf-8"), source_raw.decode("utf-8")
            h0_text = h0_raw.decode("utf-8")
            compiled = {"commit": epoch, "path": source, "git_blob": source_blob,
                        "sha256": sha(source_raw), "origin": owner.get("source_origin"),
                        "variant": owner.get("variant")}
            reading = {"commit": HW_COMMIT, "path": spec["hw_path"], "git_blob": hw_blob,
                       "sha256": sha(hw_raw)}

            decl_records = []
            for decl in spec["declarations"]:
                hw_line = declaration_line(hw_text, decl, spec["hw_path"])
                source_line = declaration_line(source_text, decl, source)
                h0_line = declaration_line(h0_text, decl, spec["h0_path"])
                decl_records.append(
                    {"declaration": decl, "homework_line": hw_line, "compiled_source_line": source_line,
                     "h0mework_line": h0_line}
                )
                row_sources.append(
                    {
                        **compiled,
                        "declaration": decl,
                        "declaration_line": source_line,
                        "intake_reading": {**reading, "line": hw_line},
                        "direct_consumers": spec["direct_consumer"],
                        "h0_public": {
                            "repository": H0_REPO_URL,
                            "commit": spec["h0_commit"],
                            "path": spec["h0_path"],
                            "git_blob": h0_blob,
                            "sha256": sha(h0_raw),
                            "line": h0_line,
                        },
                    }
                )

            pub_bindings.append(
                {
                    "homework_commit": HW_COMMIT,
                    "homework_path": spec["hw_path"],
                    "homework_blob": hw_blob,
                    "homework_sha256": sha(hw_raw),
                    "compiled_source": compiled,
                    "reading_bytes_equal_compiled": hw_raw == source_raw,
                    "h0mework_repository": H0_REPO_URL,
                    "h0mework_commit": spec["h0_commit"],
                    "h0mework_path": spec["h0_path"],
                    "h0mework_blob": h0_blob,
                    "h0mework_sha256": sha(h0_raw),
                    "supplement": spec["supplement"],
                    "direct_consumer": spec["direct_consumer"],
                    "scope": spec["scope"],
                    "declarations": decl_records,
                }
            )
        return row_sources, pub_bindings

    m7_sources_for_row, m7_public_bindings = verify_specs(M7_SPECS)
    m8_m10_sources_for_row, m8_m10_public_bindings = verify_specs(M8_M10_SPECS)
    m9_sources_for_row, m9_public_bindings = verify_specs(M9_SPECS)
    all_v3_bindings = m7_public_bindings + m8_m10_public_bindings + m9_public_bindings
    all_v3_decls = m7_sources_for_row + m8_m10_sources_for_row + m9_sources_for_row

    # Also verify cross-domain G8 public entry in H0mework fd6147f8
    g8_path = "Lean/H0mework/Papers/SocietyBookCrossDomainG8.lean"
    g8_blob, g8_raw = git_file(args.h0mework, H0_G8_COMMIT, g8_path)
    g8_text = g8_raw.decode("utf-8")
    assert "G8WholeProgramRegression" in g8_text or "CrossDomain" in g8_text or "G8" in g8_text

    m7_binding_doc = {
        "schema": "publish/generated-society-m7-m10-source-binding@3",
        "paper_id": "generated-society",
        "edition": "v3",
        "homework_intake_commit": HW_COMMIT,
        "h0mework_repository": H0_REPO_URL,
        "h0mework_society_commit": H0_MAIN_COMMIT,
        "h0mework_cross_domain_g8_commit": H0_G8_COMMIT,
        "axioms": ["propext", "Classical.choice", "Quot.sound"],
        "mathematical_scope": "Theorem 5.13 takes the visible axiom witness as a premise and rules out occurrence-authority completeness on O_soc. The hidden-fiber implication fails over any inhabited visible carrier when supplied with the axiom witness. Positive matching (some 7, some 7) and trace-supported narrative have the same authority obstruction. Proposition 3.2 proves the seedless-renewal ban, factorization of four compatible pre-emission projections, and phase transitions over exact queue prefixes. Theorem 4.4 classifies active reform and revision and constructs same-occurrence proof-carrying legislation; terminal rupture has a separate occurrence witness.",
        "m7_modules": m7_public_bindings,
        "m8_m10_modules": m8_m10_public_bindings,
        "m9_modules": m9_public_bindings,
        "total_v3_modules_verified": len(all_v3_bindings),
        "total_v3_declarations_verified": len(all_v3_decls),
        "cross_domain_g8_public_export": {
            "repository": H0_REPO_URL,
            "commit": H0_G8_COMMIT,
            "path": g8_path,
            "git_blob": g8_blob,
            "sha256": sha(g8_raw),
            "reproduction_doc": "docs/society-book-supplement-reproduction.md",
        },
    }

    def dedup_sep(s: str, sep: str) -> str:
        parts = [p.strip() for p in s.split(sep) if p.strip()]
        return f" {sep.strip()} ".join(dict.fromkeys(parts)) if sep.strip() == "/" else f"{sep.strip()} ".join(dict.fromkeys(parts))

    rows = []
    for r in deepcopy(v2["rows"]):
        n = r.get("main")
        if n in titles:
            r["title"] = titles[n]
        if n == "1.1":
            r["claims"] = "G0–G9 / G13–G14 / G18–G27 / M7–M10"
            r["supplement"] = "A–G（六大支柱见 A–B、C.1、C.6–C.7、E.1–E.2、E.6、F.3–F.5）"
        else:
            r["claims"] = dedup_sep(r.get("claims", ""), "/")
            r["supplement"] = dedup_sep(r.get("supplement", ""), ";")
        if n == "4.2":
            r["location"] = "正文 4.2（§4.1、§4.4 实际语法与全深度共同实现）"
        if r.get("location") and "3.6" in r["location"]:
            r["location"] = r["location"].replace("3.6", "3.7")
        rows.append(r)

    row_32 = {
        "main": "3.2",
        "location": "正文 3.6（命题 3.2）",
        "placement": "main",
        "title": titles["3.2"],
        "claims": "G6 / M8 renewal & M10 capacity-anomie",
        "supplement": "C.7.1–C.7.2（命题 C17–C18；式 C.8–C.9）",
        "sources": m8_m10_sources_for_row,
        "assembly_note": "多态无免费续生面禁令（含三主体源空人工主体种子 noFreeAISeed）、完全清偿同步消去购买力与价格观察、四次预发射 withRenewalProjection 同根因果演化因子化，以及位置索引队列的稳定—临界—失范单调相变律与失范全额实付扣减空性；全宇宙总口为 M8WholeProgramRegression.m8WholeProgram 与 M10WholeProgramRegression.m10WholeProgram。",
        "scope_notes": [s["scope"] for s in M8_M10_SPECS],
    }
    row_44 = {
        "main": "4.4",
        "location": "正文 4.5（定理 4.4）",
        "placement": "main",
        "title": titles["4.4"],
        "claims": "G1 / G6 / M9 institutional dichotomy & PCL",
        "supplement": "C.7.3（定理 C19；式 C.10–C.11）",
        "sources": m9_sources_for_row,
        "assembly_note": "封存询问运行时内生分流活跃改良与同源修宪。忠实终结发生另见证无同账后继的断裂。根、访问、责任行与时间因果发生的四重 HEq 给出同发生携证立法。总口为 M9WholeProgramRegression.m9WholeProgram。",
        "scope_notes": [s["scope"] for s in M9_SPECS],
    }
    row_513 = {
        "main": "5.13",
        "location": "正文 5.13",
        "placement": "main",
        "title": titles["5.13"],
        "claims": "G4 / M6–M7 observer bridge",
        "supplement": "C.6（命题 C14、定理 C15、命题 C16；式 C.2–C.7）",
        "sources": m7_sources_for_row,
        "assembly_note": "在任意类型宇宙载体上保留可见公理束前提，由 ReadoutFactorization 迫使引理统一导出三类社会选择权威加强排斥、隐藏纤维非强制负控（给定非空可见域与公理束见证）、正值可见匹配平衡 (some 7, some 7) 及受迹约束叙事防虚构与非单点纤维；独立全宇宙总口为 M7WholeProgramRegression.m7WholeProgram，Type 0 实例装入 MInfinityWholeProgramRegression.m4ThroughM10。",
        "scope_notes": [s["scope"] for s in M7_SPECS],
    }
    rows.extend([row_32, row_44, row_513])

    main_rows = sorted(
        [r for r in rows if r.get("placement") == "main"],
        key=lambda r: tuple(map(int, r["main"].split("."))),
    )
    extra_rows = [r for r in rows if r.get("placement") != "main"]

    v3_corr = {
        **{k: v for k, v in v2.items() if k != "rows"},
        "schema_version": 3,
        "edition": "v3",
        "scope": f"All {len(titles)} named v3 main-text results (adding Proposition 3.2 M8/M10, Theorem 4.4 M9, and Theorem 5.13 M7), §3.7 memory equivalence, §4.4 sixteen-point grammar, and four §9 / Appendix C.5 interfaces.",
        "revision_scope": "v3 flagship upgrade: five-part pen-and-paper anchor (Example 1.1), Master Architecture Figure 2, paired positive/dark-twin Table 1, Proposition 3.2 (M8/M10), Theorem 4.4 (M9), Theorem 5.13 & Example 5.1 (M7), and 40-reference five-axis primary literature synthesis; frozen v2 correspondence and public-source-binding records remain untouched.",
        "named_main_results": sorted(titles, key=lambda s: tuple(map(int, s.split(".")))),
        "m7_public_binding_record": "records/m7-source-binding-v3.json",
        "rows": main_rows + extra_rows,
    }

    for out_path, payload in (
        (RECORDS / "m7-source-binding-v3.json", m7_binding_doc),
        (RECORDS / "theorem-correspondence-v3.json", v3_corr),
    ):
        encoded = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        assert b"/Users/" not in encoded and b"/Volumes/" not in encoded and b"file://" not in encoded
        out_path.write_bytes(encoded)

    Q = "`"
    md_lines = [
        "# 正文命题与原声明对应（v3）",
        "",
        f"本表连接双语正文全部 **{len(titles)}** 项具名结果（含 v3 新增命题 3.2、定理 4.4 与定理 5.13）、技术附录 A–G 及第 9 节四组独立形式接口；同时保留第 3.7 节跨宇宙记忆等价与第 4.4 节十六点社会语法。v2 冻结版对应表见 [theorem-correspondence.md](theorem-correspondence.md) 与 [theorem-correspondence.json](records/theorem-correspondence.json)；v3 完整机器可读记录见 [theorem-correspondence-v3.json](records/theorem-correspondence-v3.json) 与 [m7-source-binding-v3.json](records/m7-source-binding-v3.json)。",
        "",
        f"源仓收稿上限为 `{HW_COMMIT}`；公开验证仓 `H0mework` 社会主包提交为 `{H0_MAIN_COMMIT}`，跨领域四域主体来源复现补充入口为 `{H0_G8_COMMIT}`。",
        "",
        "| 正文位置 | 命题锚点 | 补充材料证明 | 核心原声明与直接消费者 | 固定来源提交 |",
        "| --- | --- | --- | --- | --- |",
    ]
    for r in main_rows + extra_rows:
        zs = r["sources"]
        seen, vers, consumers = [], [], []
        for z in zs:
            t = Path(z["path"]).name + " :: " + z["declaration"]
            if t not in seen:
                seen.append(t)
            if z["commit"] not in vers:
                vers.append(z["commit"])
            if z.get("h0_public") and "H0:" + z["h0_public"]["commit"][:12] not in vers:
                vers.append("H0:" + z["h0_public"]["commit"][:12])
            raw_c = z.get("direct_consumers", [])
            items = [raw_c] if isinstance(raw_c, (str, dict)) else raw_c
            for it in items:
                val = (
                    Path(it["path"]).name + " :: " + it.get("declaration", "")
                    if isinstance(it, dict)
                    else str(it)
                )
                for part in val.split("; "):
                    if part and part not in consumers:
                        consumers.append(part)
        cshort = list(dict.fromkeys(x.split("/")[-1] for x in consumers))[:3]
        label = (r.get("location") or f"正文 {r.get('main', '')}") + " " + r["title"]
        md_lines.append(
            "| "
            + label
            + " | "
            + r["claims"]
            + " | "
            + r["supplement"]
            + " | "
            + "<br>".join(f"{Q}{x}{Q}" for x in seen[:3])
            + "<br>→ "
            + "<br>".join(f"{Q}{x}{Q}" for x in cshort)
            + " | "
            + "<br>".join(f"{Q}{x[:12]}{Q}" for x in vers)
            + " |"
        )

    md_lines += [
        "",
        "## 关键量词与精确范围说明",
        "",
        "- **编号稳定性**：原有的 32 项具名结果编号（`1.1–1.3`、`2.2`、`3.1`、`4.2–4.3`、`5.1–5.12`、`6.1–6.5`、`7.1–7.8`）保持百分之百不变；v3 在第 3.6 节新增 **命题 3.2**、在第 4.5 节新增 **定理 4.4**、在第 5.13 节新增 **定理 5.13**（对应补充材料第 C.6–C.7 节命题 C14、定理 C15、命题 C16–C18、定理 C19），并在第 1.1 节与第 5.13 节新增纸笔验算锚点 **例 1.1** 与 **例 5.1**。",
        "- **命题 3.2、定理 4.4 与定理 5.13 的严格忠实边界**：（1）`noSourceSeed_noRenewalFace` 与 `noFreeAISeed` 严格排除无轨迹见证的人工主体空种子，`OccurrenceCapacityPhase` 与 `OccurrenceCapacityConsumer` 导出稳定—临界—失范单调相变及失范全额扣减空性；（2）`SourceGeneratedInstitutionalDichotomyAt` 与 `ProofCarryingLegislationAt` 在不输入外部标签下内生分离同法改良与同源修宪革命、区分终结断裂并实现字面同发生携证立法；（3）阿罗、吉巴德—萨特斯韦特与森三套可见公理束作为可见商上的合法输入原封保留，不重证亦不调用经典横向社会选择不可能定理，严格证明跨观察核的发生权威完备性加强为空、隐藏纤维非强制负控以及正值可见匹配 `(some 7, some 7)` 与防虚构受迹叙事的源权威不可识别性。",
        "- **内核验证基线**：全部声明在 Lean 4 内核中仅依赖三条标准公理 `propext`、`Classical.choice`、`Quot.sound`（`unsafe = 0`、`partial = 0`）。",
        "",
    ]
    md_bytes = "\n".join(md_lines).encode("utf-8")
    assert b"/Users/" not in md_bytes and b"/Volumes/" not in md_bytes
    (PAPER / "theorem-correspondence-v3.md").write_bytes(md_bytes)
    print(
        json.dumps(
            {
                "named_results": len(titles),
                "correspondence_rows": len(main_rows) + len(extra_rows),
                "v3_modules_verified": len(all_v3_bindings),
                "v3_declarations_verified": len(all_v3_decls),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
