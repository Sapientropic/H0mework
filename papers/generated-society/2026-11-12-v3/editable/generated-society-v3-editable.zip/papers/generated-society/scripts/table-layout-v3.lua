-- Paper-local v3 layout filter: allocate exact column widths for comparison tables and preserve long hashes.
function Header(el)
  if not FORMAT:match('latex') then return nil end
  if el.level == 2 then
    return {pandoc.RawBlock('latex', '\\Needspace{6\\baselineskip}'), el}
  end
  if el.level == 3 then
    return {pandoc.RawBlock('latex', '\\Needspace{5\\baselineskip}'), el}
  end
  if el.level ~= 1 then return nil end
  local title = pandoc.utils.stringify(el.content)
  local short_titles = {
    ['1 A Self-Revising Free Society Without Preinstalled Individuals: Problem, Pen-and-Paper Anchor, and Main Theorem'] = '1 Problem, Pen-and-Paper Anchor, and Main Theorem',
    ['4 Fourfold Disposition Closure of Constitutional Power and Same-Point Nonempty Realization'] = '4 Root-Law Disposition Closure and Same-Point Realization',
    ['5 Genuine Exit, Diagnostic Impossibility, and the Observer-Kernel Authority Boundary'] = '5 Genuine Exit, Diagnostic Impossibility, and Observer Boundary',
    ['7 How Economic and Institutional Obligations Persist Conservatively After Payment'] = '7 Obligation Conservation Across Clearing and Amendment',
    ['8 An Economic Constitution: Returning Collectively Created Capacities to Continuing Lives'] = '8 Economic Constitution Principles',
    ['9 Open Formal Interfaces: Seamless Extension to Production, Public Functions, and Distributed Protocols'] = '9 Open Formal Interfaces',
    ['10 Literature in Five-Axis Dialogue: From Preinstalled Individuals and Exception Sovereignty to Source-Native Constitutional Mathematics'] = '10 Literature in Five-Axis Dialogue'
  }
  if short_titles[title] then
    local latex = pandoc.write(pandoc.Pandoc({el}), 'latex')
    latex = latex:gsub('\\section{', '\\section[' .. short_titles[title] .. ']{', 1)
    return pandoc.RawBlock('latex', latex)
  end
end

function Str(el)
  if not FORMAT:match('latex') then return nil end
  local result = pandoc.List()
  local cursor = 1
  for first, token, after in el.text:gmatch('()([0-9a-f]+)()') do
    if #token >= 40 then
      if first > cursor then result:insert(pandoc.Str(el.text:sub(cursor, first - 1))) end
      result:insert(pandoc.RawInline('latex', '\\paperinlinecode{\\seqsplit{' .. token .. '}}'))
      cursor = after
    end
  end
  if cursor > 1 then
    if cursor <= #el.text then result:insert(pandoc.Str(el.text:sub(cursor))) end
    return result
  end
end

function Table(el)
  if not FORMAT:match('latex') then return nil end
  if not el.head or not el.head.rows or #el.head.rows == 0 then return nil end
  local row = el.head.rows[1]
  if #row.cells == 0 then return nil end
  local label = pandoc.utils.stringify(row.cells[1].contents)

  if #el.colspecs == 4 and (label == '总定理支柱' or label == 'Pillar of Theorem 1.1') then
    el.colspecs[1][2] = 0.16
    el.colspecs[2][2] = 0.25
    el.colspecs[3][2] = 0.21
    el.colspecs[4][2] = 0.38
    return {pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.05}\\renewcommand{\\arraystretch}{1.14}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 4 and (label == '学科对话主轴' or label == 'Theoretical axis') then
    el.colspecs[1][2] = 0.17
    el.colspecs[2][2] = 0.22
    el.colspecs[3][2] = 0.29
    el.colspecs[4][2] = 0.32
    return {pandoc.RawBlock('latex', '\\begingroup\\small\n\\AtBeginEnvironment{longtable}{\\setstretch{1.04}\\renewcommand{\\arraystretch}{1.10}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.4em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 3 and (label == '检查内容' or label == 'Content checked') then
    el.colspecs[1][2] = 0.25
    el.colspecs[2][2] = 0.36
    el.colspecs[3][2] = 0.39
    return {pandoc.RawBlock('latex', '\\Needspace{18\\baselineskip}\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 5 and (label == '实际源' or label == 'Actual source') then
    el.colspecs[1][2] = 0.13
    el.colspecs[2][2] = 0.19
    el.colspecs[3][2] = 0.28
    el.colspecs[4][2] = 0.16
    el.colspecs[5][2] = 0.24
    return {pandoc.RawBlock('latex', '\\Needspace{11\\baselineskip}\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 2 and (label == '阶段' or label == 'Stage') then
    el.colspecs[1][2] = 0.13
    el.colspecs[2][2] = 0.87
    return {pandoc.RawBlock('latex', '\\Needspace{14\\baselineskip}\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 2 and (label == '共同结论' or label == 'Joint conclusion') then
    el.colspecs[1][2] = 0.27
    el.colspecs[2][2] = 0.73
    return {pandoc.RawBlock('latex', '\\Needspace{20\\baselineskip}\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.55em}\\setlength{\\LTpost}{0.55em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 2 and (label == '位置' or label == 'Locus') then
    el.colspecs[1][2] = 0.24
    el.colspecs[2][2] = 0.76
    return {pandoc.RawBlock('latex', '\\Needspace{15\\baselineskip}\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end

  if #el.colspecs == 3 and (label == '正文术语' or label == 'Main-text term') then
    el.colspecs[1][2] = 0.28
    el.colspecs[2][2] = 0.44
    el.colspecs[3][2] = 0.28
    return {pandoc.RawBlock('latex', '\\begingroup\n\\AtBeginEnvironment{longtable}{\\setstretch{1.06}\\renewcommand{\\arraystretch}{1.12}}\n\\setlength{\\LTpre}{0.5em}\\setlength{\\LTpost}{0.5em}'),
      el, pandoc.RawBlock('latex', '\\endgroup')}
  end
end
