#!/usr/bin/env python3
"""Build only generated-society v3 Chinese/English main texts and supplements.

Outputs strictly to build/reading-v3/ and records/reading-build-v3.json so that
published Zenodo v2 PDFs in build/reading/ and records/reading-build.json remain
byte-identical. Never runs Lean or mutates Homework/H0mework.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import re
import subprocess
import sys

PAPER = Path(__file__).resolve().parents[1]
PUBLISH = PAPER.parents[1]
SHARED = PUBLISH / "shared" / "scripts"
sys.dont_write_bytecode = True
sys.path.insert(0, str(SHARED))

spec = importlib.util.spec_from_file_location("society_shared_pdf_v3", SHARED / "build_pdf.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)

REL = PAPER.relative_to(PUBLISH).as_posix()
TARGETS = {
    "zh": (
        f"{REL}/manuscript.md",
        ("generated-society", "典范社会总定理", "无预装个体生成、完备宪制处置与自由进展"),
    ),
    "en": (
        f"{REL}/manuscript-en.md",
        ("generated-society", "The Canonical Society Theorem", "Subject generation, root law, and strict progress"),
    ),
    "supplement-zh": (
        f"{REL}/supplement.md",
        ("generated-society-supplement", "典范社会总定理：技术附录", "高健"),
    ),
    "supplement-en": (
        f"{REL}/supplement-en.md",
        ("generated-society-supplement", "Canonical Society: Technical Supplement", "Jian Gao"),
    ),
}

for rel, heads in TARGETS.values():
    builder.EXPLICIT_RUNHEADS[rel] = heads
builder.CONTINUOUS_APPENDICES.add(f"{REL}/supplement-en.md")

shared_latin_title = builder.latin_title
shared_prepare = builder.prepare
shared_run = builder.run


def latin_title(line: str):
    if re.match(r"^#{1,2}\s+(?:Abstract\b|References\b|[A-H](?:\.\d+)*\s|\d+(?:\.\d+)*\s)", line.strip()):
        return None
    return shared_latin_title(line)


builder.latin_title = latin_title


def run(command, **kwargs):
    command = list(command)
    if command and str(command[0]) == "pandoc":
        command.extend(["--lua-filter", str(PAPER / "scripts" / "table-layout-v3.lua")])
    return shared_run(command, **kwargs)


builder.run = run


def prepare(source: str, toc: bool, profile):
    override = ""
    if source.startswith("# 典范社会总定理\n"):
        for candidate in (
            "无预装个体的主体生成、完备宪制处置与严格自由进展",
        ):
            marker = "\n## " + candidate + "\n"
            if marker in source:
                if source.count(marker) != 1:
                    raise RuntimeError("Ambiguous Chinese subtitle.")
                source = source.replace(marker, "\n", 1)
                override = candidate
                break
    title, subtitle, body = shared_prepare(source, toc, profile)
    if override:
        if subtitle:
            raise RuntimeError("Unexpected extra subtitle.")
        subtitle = override

    # Allow long abstracts (especially English) and the 36-entry reference list
    # to flow naturally across pages instead of forcing an entire page break when
    # a single minipage exceeds the remaining space on page 1.
    body = re.sub(
        r"```\{=latex\}\n\\noindent\\begin\{minipage\}\{\\linewidth\}\n```\n\n(# (?:摘要|Abstract(?: \(English\))?))\n\n```\{=latex\}\n(\\begingroup\\small\\setstretch\{1\.16\})\n```\n(.*?)\n```\{=latex\}\n\\endgroup\\end\{minipage\}\\par\n```",
        lambda m: f"{m[1]}\n\n```{{=latex}}\n{m[2]}\n```\n{m[3]}\n```{{=latex}}\n\\endgroup\\par\n```",
        body,
        flags=re.S,
    )

    ref = re.search("(?m)" + builder.REFERENCES, body)
    if ref:
        opening = "```{=latex}\n\\noindent\\begin{minipage}{\\linewidth}\n```\n\n"
        prefix = body[:ref.start()]
        if not prefix.endswith(opening):
            raise RuntimeError("Shared bibliography wrapper changed.")
        body = prefix[:-len(opening)] + body[ref.start():]
        closing = "\\endgroup\\end{minipage}\\par"
        end = body.rfind(closing)
        if end < 0:
            raise RuntimeError("Shared bibliography end changed.")
        body = body[:end] + "\\endgroup\\par" + body[end + len(closing):]
        if source.startswith("# The Canonical Society Theorem\n"):
            body = body.replace("\\footnotesize\\setstretch{1.13}", "\\footnotesize\\setstretch{1.10}", 1)

    lines = body.splitlines(keepends=True)
    result = []
    fenced = False
    for index, ln in enumerate(lines):
        if ln.lstrip().startswith("```"):
            fenced = not fenced
        if not fenced and re.match(r"^# \d+\s", ln):
            following = next((x for x in lines[index + 1:] if x.strip()), "")
            need = 12 if following.startswith("## ") else 9
            result.append(f"```{{=latex}}\n\\Needspace{{{need}\\baselineskip}}\n```\n\n")
        result.append(ln)
    return title, subtitle, "".join(result)


builder.prepare = prepare


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", nargs="+", choices=list(TARGETS))
    parser.add_argument("--figures", action="store_true")
    parser.add_argument("--output-dir", type=Path, default=PAPER / "build" / "reading-v3")
    args = parser.parse_args()

    resolved_out = args.output_dir.resolve()
    if resolved_out in ((PAPER / "build").resolve(), (PAPER / "build" / "reading").resolve()):
        raise SystemExit(
            "Refusing to overwrite frozen Zenodo v2 PDFs in build/reading/; use build/reading-v3/."
        )
    if args.figures:
        subprocess.run([sys.executable, str(PAPER / "figures" / "make_figures_v3.py")], check=True)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    record_path = PAPER / "records" / "reading-build-v3.json"
    data = json.loads(record_path.read_text()) if record_path.exists() else {"edition": "v3", "artifacts": {}}

    selected = args.only or list(TARGETS)
    for key in selected:
        rel, _ = TARGETS[key]
        src = PUBLISH / rel
        if not src.is_file():
            raise FileNotFoundError(src)
        src_bytes = src.read_bytes()
        report = builder.build(rel, toc=Path(rel).name.startswith("supplement"), output_dir=args.output_dir)
        if src.read_bytes() != src_bytes:
            raise RuntimeError("Manuscript changed during build; rebuild stable source.")
        pdf = PUBLISH / report["pdf"]
        report.update(
            {
                "source_sha256": hashlib.sha256(src_bytes).hexdigest(),
                "pdf_sha256": sha(pdf),
                "build_script_sha256": sha(Path(__file__).resolve()),
                "built_at_utc": datetime.now(timezone.utc).isoformat(),
            }
        )
        data["artifacts"][key] = report
        print(json.dumps(report, ensure_ascii=False), flush=True)

    dependencies = [
        PUBLISH / "shared" / "scripts" / "build_pdf.py",
        PUBLISH / "shared" / "scripts" / "byline.py",
        PUBLISH / "shared" / "styles" / "article-header.tex",
        PUBLISH / "shared" / "styles" / "article-header-en.tex",
        PUBLISH / "shared" / "styles" / "article-filter.lua",
        PAPER / "scripts" / "table-layout-v3.lua",
        PAPER / "figures" / "make_figures_v3.py",
        Path(__file__).resolve(),
    ]
    data["build_dependencies"] = [
        {"path": str(p.relative_to(PUBLISH)), "sha256": sha(p)} for p in dependencies
    ]
    data["python"] = platform.python_version()
    data["scope"] = "v3 document rendering only; frozen v2 build/reading PDFs untouched; no Lean compilation."
    record_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if any(data["artifacts"][k]["missing_characters"] or data["artifacts"][k]["overfull_boxes"] for k in selected):
        raise SystemExit("Layout findings (missing_characters or overfull_boxes) remain; inspect reading-build-v3.json.")


if __name__ == "__main__":
    main()
