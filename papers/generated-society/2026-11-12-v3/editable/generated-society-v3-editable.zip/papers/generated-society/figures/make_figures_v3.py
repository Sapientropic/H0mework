#!/usr/bin/env python3
"""Bilingual v3 editable plates for The Canonical Society Theorem (v3).

Preserves all v1/v2 frozen files (01..07*.{svg,pdf}, manifest.json, source/*)
untouched. Writes *-v3{,-en}.{svg,pdf} and manifest-v3.json, adding Plate 08
for the M6/M7 observer-kernel, social-choice (Arrow / Gibbard-Satterthwaite /
Sen), visible-matching, and trace-constrained-narrative authority bridge
together with source-native failureKind refinement.
"""
from __future__ import annotations
import argparse
from functools import lru_cache
import hashlib
from html import escape
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
PUBLISH = OUT.parents[2]
sys.path.insert(0, str(PUBLISH / "shared" / "figure-style"))
from house_style import INK, SLATE, MUTE, HAIR, DEEP, VERMILION, WASH
import svg_text
from svg_text import line, register_cjk_for_cairo

svg_text.OPS.update("∼≅∧∨⇔≡∅∞′⊊≺≠≤≥↔↦→¬∃∀×∑⊔∈∉∘ℕ∂⋆")
W = 1440
PRINT_WIDTH = 464
MIN_SIZE = 24
LANG = "zh"
PARTS, BOXES, SHAPES = [], [], []
MANIFEST = []
CHECK_ONLY = False


def L(zh: str, en: str) -> str:
    return zh if LANG == "zh" else en


def start(height: int, title: str, description: str) -> int:
    PARTS.clear()
    BOXES.clear()
    SHAPES.clear()
    PARTS.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{height}" '
        f'viewBox="0 0 {W} {height}" role="img">'
    )
    PARTS.extend([f"<title>{escape(title)}</title>", f"<desc>{escape(description)}</desc>"])
    PARTS.append(
        "<defs>"
        + "".join(
            f'<marker id="arrow-{n}" viewBox="0 0 10 10" refX="9" refY="5" '
            f'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>'
            for n, c in [("ink", SLATE), ("deep", DEEP), ("acc", VERMILION)]
        )
        + "</defs>"
    )
    PARTS.append(f'<rect width="{W}" height="{height}" fill="white"/>')
    return height


@lru_cache(maxsize=None)
def weighted_metrics(cls: str, weight: int):
    from fontTools.ttLib import TTFont
    from fontTools.varLib.instancer import instantiateVariableFont

    font_path = svg_text._FONT_FILES[cls]
    if cls == "zh" and weight >= 600:
        suffix = "Bold" if weight >= 700 else "SemiBold"
        font_path = Path.home() / "Library/Fonts" / f"NotoSerifCJKsc-{suffix}.otf"
    font = TTFont(str(font_path))
    if "fvar" in font:
        font = instantiateVariableFont(font, {"wght": weight}, inplace=True)
    return font.getBestCmap(), font["hmtx"].metrics, font["head"].unitsPerEm


def weighted_width(text: str, size: float, weight: int = 400) -> float:
    total = 0.0
    for piece, tag in svg_text._pieces(str(text)):
        actual_size = svg_text._script(size, MIN_SIZE) if tag in ("sub", "isub", "sup") else size
        actual_weight = 700 if tag == "b" else weight
        for ch in piece:
            cls = "en" if ch.isspace() else svg_text._cls(ch)
            if tag in ("i", "isub") and cls == "en":
                cls = "it"
            cmap, metrics, upm = weighted_metrics(cls, actual_weight)
            glyph = cmap.get(ord(ch))
            assert glyph in metrics, ("missing font glyph", ch, cls)
            total += metrics[glyph][0] * actual_size / upm
    return total


def txt(x, y, text, size=28, color=INK, weight=400, anchor="start", max_width=None):
    assert size >= MIN_SIZE, ("font below floor", text, size)
    tw = weighted_width(text, size, weight)
    if max_width is not None:
        assert tw <= max_width, ("label too wide", text, tw, max_width)
    x0 = x - {"start": 0, "middle": tw / 2, "end": tw}[anchor]
    BOXES.append(
        {"box": [x0, y - 0.82 * size, x0 + tw, y + 0.26 * size], "text": text, "font_px": size}
    )
    PARTS.append(line(x0, y, text, size, color, weight, "start", min_size=MIN_SIZE))


def text_lines(x, y, lines, size=28, color=INK, weight=400, anchor="start", gap=39, max_width=None):
    for i, label in enumerate(lines):
        txt(x, y + i * gap, label, size, color, weight, anchor, max_width)


def rect(x, y, w, h, stroke=HAIR, fill="none", width=1.6, radius=4, dashed=False):
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    PARTS.append(
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" '
        f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"{dash}/>'
    )
    SHAPES.append([x, y, x + w, y + h])


def circle(x, y, r, stroke=DEEP, fill="white", width=2.2):
    PARTS.append(
        f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>'
    )
    SHAPES.append([x - r, y - r, x + r, y + r])


def path(d, color=SLATE, width=2.2, marker=None, dashed=False):
    dash = ' stroke-dasharray="9 7"' if dashed else ""
    end = f' marker-end="url(#arrow-{marker})"' if marker else ""
    PARTS.append(
        f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" '
        f'stroke-linejoin="round" stroke-linecap="round"{dash}{end}/>'
    )


def arrow(x1, y1, x2, y2, color=SLATE, marker="ink", dashed=False, width=2.2):
    path(f"M {x1} {y1} L {x2} {y2}", color, width, marker, dashed)


def biarrow(x1, y1, x2, y2, color=VERMILION, marker="acc", width=2.4):
    PARTS.append(
        f'<path d="M {x1} {y1} L {x2} {y2}" fill="none" stroke="{color}" stroke-width="{width}" '
        f'marker-start="url(#arrow-{marker})" marker-end="url(#arrow-{marker})"/>'
    )


def rule(y, x1=40, x2=1400):
    path(f"M {x1} {y} L {x2} {y}", HAIR, 1.5)


def cross(x, y, size=13):
    path(
        f"M {x-size} {y-size} L {x+size} {y+size} M {x-size} {y+size} L {x+size} {y-size}",
        VERMILION,
        4,
    )


def dot(x, y, r=5, color=DEEP):
    circle(x, y, r, color, color, 1)


def panel(x, y, letter, zh, en):
    txt(x, y, letter, 27, SLATE, 600)
    txt(x + 42, y, L(zh, en), 28, INK, 600)


def save(stem: str, height: int, semantics: dict):
    for i, item in enumerate(BOXES):
        a = item["box"]
        assert a[0] >= 16 and a[2] <= W - 16 and a[1] >= 5 and a[3] <= height - 6, (
            "outside canvas",
            stem,
            LANG,
            item,
        )
        for other in BOXES[i + 1 :]:
            b = other["box"]
            if a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]:
                raise AssertionError(("text overlap", stem, LANG, item["text"], other["text"]))
    for s in SHAPES:
        assert min(s[:2]) >= 0 and s[2] <= W and s[3] <= height, ("shape outside", stem, s)
    out_stem = f"{stem}-v3" + ("-en" if LANG == "en" else "")
    if CHECK_ONLY:
        MANIFEST.append({"stem": out_stem, "language": LANG, "layout": "pass"})
        return
    svg = "\n".join(PARTS + ["</svg>"]) + "\n"
    svg_path = OUT / f"{out_stem}.svg"
    pdf_path = OUT / f"{out_stem}.pdf"
    svg_path.write_text(svg, encoding="utf-8")

    import pymupdf

    preview = OUT / ".review-v3"
    preview.mkdir(exist_ok=True)
    page = preview / f"{out_stem}.html"
    hp = height / W * PRINT_WIDTH
    page.write_text(
        '<!doctype html><html><head><meta charset="utf-8"><style>'
        + f"@page{{size:{PRINT_WIDTH}pt {hp}pt;margin:0}}html,body{{margin:0;padding:0}}"
        + f"img{{display:block;width:{PRINT_WIDTH}pt;height:{hp}pt}}</style></head>"
        + f'<body><img src="{svg_path.as_uri()}"></body></html>'
    )
    result = subprocess.run(
        [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "--headless=new",
            "--disable-gpu",
            "--no-pdf-header-footer",
            "--allow-file-access-from-files",
            f"--user-data-dir={preview / 'chrome-profile'}",
            f"--print-to-pdf={pdf_path}",
            page.as_uri(),
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode:
        raise RuntimeError(result.stdout[-2000:] + result.stderr[-2000:])
    pdf = pymupdf.open(pdf_path)
    assert len(pdf) == 1
    assert abs(pdf[0].rect.width - PRINT_WIDTH) < 1
    assert "\ufffd" not in pdf[0].get_text()
    pix = pdf[0].get_pixmap(
        matrix=pymupdf.Matrix(W / pdf[0].rect.width, W / pdf[0].rect.width), alpha=False
    )
    pix.save(preview / f"{out_stem}.png")
    entry = {
        "stem": out_stem,
        "language": LANG,
        "canvas_px": [W, height],
        "printed_pt": [PRINT_WIDTH, height / W * PRINT_WIDTH],
        "minimum_text_px": MIN_SIZE,
        "minimum_printed_pt": MIN_SIZE / W * PRINT_WIDTH,
        "text_layout_check": "pass",
        "semantics": semantics,
        "files": {},
    }
    for ext in ["svg", "pdf"]:
        f = OUT / f"{out_stem}.{ext}"
        entry["files"][ext] = {
            "path": f.name,
            "sha256": hashlib.sha256(f.read_bytes()).hexdigest(),
            "bytes": f.stat().st_size,
        }
    MANIFEST.append(entry)


def exit_case():
    h = start(
        840,
        L("五门联立的可实行退出与三种零容量根源", "Five-gate actionable exit and three zero-capacity origins"),
        L(
            "上部给出同一劳动者甲、完整支付、角色外非闲置继续、通路与实际服务联立形成可行退出边；下部固定甲、支付与利益，分别改变一项关系产生相同的零容量读数。",
            "Upper panel: worker A, complete payment, non-idle outside-role continuation, route, and actual service jointly form a feasible exit edge. Lower panel: fixing A, payment, and interest while varying one relation yields three distinct origins of K = 0.",
        ),
    )
    panel(40, 44, "A", "五项条件在同一 (c, j) 联立：可实行退出容量 K = 1", "Five conditions meet on one pair (c, j): actionable exit K = 1")
    circle(100, 165, 33)
    txt(100, 176, L("甲", "A"), 34, DEEP, 600, "middle")
    txt(100, 237, L("承担者", "worker A"), 26, SLATE, anchor="middle")
    arrow(142, 165, 337, 165, DEEP, "deep")
    txt(240, 138, L("亲自行使", "exercises"), 27, SLATE, anchor="middle")
    rect(345, 94, 310, 143, DEEP, width=2.2)
    txt(500, 136, L("继续行动 {i:c}", "continuing action {i:c}"), 29, DEEP, 600, "middle", 282)
    txt(500, 178, L("原岗位之外 · 非闲置", "outside role · non-idle"), 26, SLATE, anchor="middle", max_width=282)
    txt(500, 215, "{i:R}{isub:d}({i:c}) ∧ ¬{i:I}{isub:d}({i:c})", 25, DEEP, anchor="middle", max_width=282)
    arrow(663, 165, 1022, 165, DEEP, "deep")
    txt(840, 137, L("通路收据 {i:T}{isub:d}({i:c},{i:j})", "route {i:T}{isub:d}({i:c},{i:j})"), 27, DEEP, anchor="middle")
    rect(1030, 94, 365, 143, DEEP, width=2.2)
    txt(1212, 143, L("实际服务 {i:s}{isub:j}", "actual service {i:s}{isub:j}"), 30, DEEP, 600, "middle", 337)
    txt(1212, 187, L("已服务槽 {i:j} ∈ {i:J}{isub:d}", "served slot {i:j} ∈ {i:J}{isub:d}"), 27, SLATE, anchor="middle", max_width=337)
    rect(345, 307, 310, 88, SLATE)
    txt(500, 342, L("完整支付 {i:p}{isub:d}", "complete payment {i:p}{isub:d}"), 28, INK, 600, "middle", 286)
    txt(500, 379, L("支付关联 {i:P}{isub:d}({i:c})", "incidence {i:P}{isub:d}({i:c})"), 26, SLATE, anchor="middle", max_width=286)
    arrow(500, 298, 500, 246, DEEP, "deep")
    path("M 840 307 L 840 292 L 785 292 L 785 215 L 655 215", MUTE, 2, None, True)
    dot(655, 215, 4, DEEP)
    circle(840, 340, 28, SLATE)
    txt(840, 350, L("乙", "B"), 30, INK, 600, "middle")
    txt(885, 347, L("控制者位置乙", "controller B"), 27, SLATE)
    txt(845, 262, L("非捕获 ¬{i:H}{isub:d}({i:c})", "non-capture ¬{i:H}{isub:d}({i:c})"), 26, DEEP)
    rule(427)
    panel(40, 471, "B", "三个对照构造：原因互异，标量读数同为零", "Three comparison origins: distinct causes, identical scalar zero")
    ys = [550, 654, 758]
    causes = [
        ("payment", "支付关联缺失 z_p", "payment link absent"),
        ("route", "路径关联缺失 z_r", "route link absent"),
        ("captured", "继续被乙捕获 z_c", "continuation captured"),
    ]
    for y, (kind, zh, en) in zip(ys, causes):
        label_txt = zh.replace("z_p", "{i:z}{sub:p}").replace("z_r", "{i:z}{sub:r}").replace("z_c", "{i:z}{sub:c}")
        en_txt = en + (" ({i:z}{sub:p})" if kind == "payment" else (" ({i:z}{sub:r})" if kind == "route" else " ({i:z}{sub:c})"))
        txt(55, y + 8, L(label_txt, en_txt), 27, INK, 600, max_width=345)
        arrow(477, y, 701, y, MUTE if kind == "payment" else DEEP, "ink" if kind == "payment" else "deep", kind == "payment")
        arrow(779, y, 1040, y, MUTE if kind == "route" else DEEP, "ink" if kind == "route" else "deep", kind == "route")
        circle(445, y, 29)
        txt(445, y + 10, "{i:p}", 30, DEEP, anchor="middle")
        circle(740, y, 31, VERMILION if kind == "captured" else DEEP, width=3.4 if kind == "captured" else 2.2)
        txt(740, y + 10, "{i:c}", 30, DEEP, anchor="middle")
        circle(1080, y, 34)
        txt(1080, y + 10, "{i:s}{isub:j}", 29, DEEP, anchor="middle")
        if kind == "captured":
            rect(697, y - 43, 86, 86, VERMILION, width=2.2, radius=0)
            txt(865, y - 31, L("乙捕获继续", "B captures c"), 25, VERMILION, anchor="middle")
        if kind == "payment":
            cross(587, y)
        if kind == "route":
            cross(910, y)
        txt(1300, y + 10, "{i:K} = 0", 31, INK, 600, "middle")
    save(
        "01-exit-case",
        h,
        {
            "focus": "five-gate exit iff and three non-identifiable zero-capacity origins",
            "proofLocation": "Theorem 5.1, Proposition 5.2; Supplement B.4-B.5",
        },
    )


def generation():
    h = start(
        920,
        L("零预装个体的谱系商生成、四域复用与制度位置", "Zero-preinstalled-individual lineage quotient, four-domain reuse, and positions"),
        L(
            "上部展示同一发生轨迹准入的源种子经谱系等价商唯一生成行动者（经济、生物、多主体、围棋四域同源复用）；下部展示同源装配中的角色、服务与责任行位置分离。",
            "Upper panel: trace-admitted seeds generate actors canonically via the lineage quotient, reused across economic, biological, multi-agent, and Go domains. Lower panel: distinct bearer, controller, and beneficiary positions in the same-source assembly.",
        ),
    )
    panel(40, 44, "A", "舞蹈生成舞者：轨迹种子经谱系商双射生成主体", "Dancing generates dancers: trace seeds modulo lineage generate actors")
    arrow(75, 132, 565, 132, DEEP, "deep")
    for x, label in [(130, "{i:x}{sub:0}"), (280, "{i:x}{sub:1}"), (440, "{i:x}{sub:2}")]:
        dot(x, 132, 8)
        txt(x, 102, label, 29, DEEP, anchor="middle")
    txt(75, 184, L("发生轨迹 τ(ω)", "trace τ(ω)"), 27, SLATE, max_width=210)
    rect(225, 253, 270, 94, HAIR, radius=47, dashed=True)
    arrow(280, 145, 280, 263, DEEP, "deep")
    arrow(440, 145, 440, 263, DEEP, "deep")
    txt(360, 224, L("源种子准入", "admitted"), 26, SLATE, anchor="middle", max_width=136)
    for x, label in [(280, "{i:s}"), (440, "{i:t}")]:
        circle(x, 299, 29)
        txt(x, 309, label, 30, DEEP, anchor="middle")
    path("M 495 299 C 650 299, 790 255, 938 255", DEEP, 2.2, "deep")
    txt(725, 205, L("谱系商映射 Φ", "quotient map Φ"), 28, SLATE, anchor="middle")
    txt(360, 379, L("同谱系等价类", "lineage class"), 26, SLATE, anchor="middle")
    txt(725, 379, "ℓ({i:s}) = ℓ({i:t})", 31, DEEP, anchor="middle")
    circle(1004, 255, 58, DEEP, width=2.6)
    txt(1004, 267, "ℓ({i:s})", 31, DEEP, 600, "middle")
    rect(1105, 152, 275, 206, HAIR)
    txt(1242, 194, L("四域同源复用", "4-domain reuse"), 27, DEEP, 600, "middle", 250)
    text_lines(
        1242,
        236,
        [
            L("经济联盟 · 生物祖裔", "economy · biology"),
            L("三主体交互 · 围棋博弈", "3-agent · Go game"),
            L("逆向源种子全保留", "inverse seeds kept"),
        ],
        24,
        SLATE,
        anchor="middle",
        gap=36,
        max_width=255,
    )
    txt(720, 436, "Φ : {i:U}{sub:ω} / ∼{sub:ℓ} ≅ {i:A}{sub:ω}", 33, DEEP, 600, "middle")
    txt(
        720,
        480,
        L(
            "无需预装个人 ID；每个生成主体都有轨迹源种子，合法合并与单射分离精确受控",
            "No pre-installed PersonId; every actor has a trace seed while merges remain exact",
        ),
        26,
        INK,
        anchor="middle",
        max_width=1340,
    )
    rule(511)
    panel(40, 561, "B", "同源制度装配：主体身份与关系位置严格区分", "Same-source assembly: actor identity separated from relational positions")
    rect(50, 604, 310, 170, DEEP, width=2.2)
    txt(205, 647, L("同源已安装基础", "installed foundation"), 28, DEEP, 600, "middle", 280)
    txt(205, 693, L("角色环 ∑δ = 2 ≠ 0", "role cycle ∑δ = 2 ≠ 0"), 26, VERMILION, 600, "middle", 280)
    txt(205, 738, L("不可化归个人分值", "non-potential H¹"), 25, SLATE, anchor="middle", max_width=280)
    arrow(369, 691, 466, 691, DEEP, "deep")
    rect(475, 604, 915, 170, HAIR, radius=0)
    path("M 475 666 L 1390 666", HAIR, 1.6)
    for x in [615, 870, 1125]:
        path(f"M {x} 604 L {x} 774", HAIR, 1.6)
    txt(545, 647, L("责任行", "row"), 27, SLATE, 600, "middle")
    txt(742, 647, L("承担者", "bearer"), 27, SLATE, 600, "middle")
    txt(997, 647, L("控制者", "controller"), 27, SLATE, 600, "middle")
    txt(1257, 647, L("受益者", "beneficiary"), 27, SLATE, 600, "middle")
    txt(545, 723, "{i:δ}", 34, DEEP, 600, "middle")
    txt(742, 723, L("该行承担者", "row bearer"), 29, DEEP, 600, "middle", 230)
    txt(997, 723, L("乙", "controller B"), 29, DEEP, 600, "middle")
    txt(1257, 723, L("对手受益方", "counterparty"), 28, INK, anchor="middle", max_width=230)
    txt(
        720,
        836,
        L(
            "同一主体可进入不同关系角色；每次权力作用、实际服务与未结责任各保发生来源",
            "One actor may enter distinct roles; power, service, and live rows each retain provenance",
        ),
        27,
        INK,
        anchor="middle",
        max_width=1340,
    )
    save(
        "02-generation",
        h,
        {
            "focus": "zero-preinstalled-individual quotient, 4-domain reuse, H1 cycle, distinct positions",
            "proofLocation": "Theorem 2.2, Proposition 3.1; Supplement A.1, C.1",
        },
    )


def root_law():
    h = start(
        900,
        L("四分完备根法、写入边界与无第五类账外权威", "Four-way complete root law, writing boundary, and zero off-ledger authority"),
        L(
            "任意完整已安装程序的生成执行严格穷尽于呈现、拒绝、行动与修订四类互斥出口；世界写入当且仅当行动或修订，排除第五类账外法外写入权限。",
            "Every generated execution of a complete installed program lands in presentation, refusal, action, or revision; world writing holds iff action or revision, excluding any fifth off-ledger authority.",
        ),
    )
    rect(160, 32, 1120, 82, DEEP, width=2.2)
    txt(
        720,
        84,
        L(
            "给定完整已安装程序、确定访问及生成执行 {i:r} ：P({i:r}) ∨ J({i:r}) ∨ A({i:r}) ∨ U({i:r})",
            "Installed program, exact visit, execution {i:r}: P({i:r}) ∨ J({i:r}) ∨ A({i:r}) ∨ U({i:r})",
        ),
        28,
        DEEP,
        600,
        "middle",
        1080,
    )
    path("M 720 114 L 720 146 M 350 146 L 1090 146", SLATE, 2.2)
    arrow(350, 146, 350, 170, SLATE, "ink")
    arrow(1090, 146, 1090, 170, SLATE, "ink")
    rect(40, 178, 620, 532, HAIR, radius=0)
    rect(780, 178, 620, 532, VERMILION, width=2.5, radius=0)
    txt(350, 220, L("只读侧：呈现 P 与拒绝 J", "Read-only side: Presentation P and Refusal J"), 28, SLATE, 600, "middle", 580)
    txt(350, 256, L("¬W(r)：无世界写入，不静默抹除承担者", "¬W(r): no world write; bearer never erased"), 25, SLATE, anchor="middle", max_width=580)
    txt(1090, 220, L("写入侧：行动 A 与同源修宪 U", "Writing side: Action A and Revision U"), 28, VERMILION, 600, "middle", 580)
    txt(1090, 256, L("W(r) ⇔ A(r) ∨ U(r) 且 ¬(A(r) ∧ U(r))", "W(r) ⇔ A(r) ∨ U(r) and ¬(A(r) ∧ U(r))"), 25, INK, anchor="middle", max_width=580)

    def leaf(x, y, title, tag, lines, accent=False):
        rect(x, y, 560, 180, HAIR)
        txt(x + 30, y + 44, title, 29, DEEP, 600, max_width=320)
        txt(x + 530, y + 43, tag, 25, VERMILION if accent else SLATE, 600, "end", max_width=220)
        text_lines(x + 30, y + 88, lines, 25, INK, gap=38, max_width=500)

    leaf(
        70,
        286,
        L("呈现 P(r)", "Presentation P(r)"),
        L("无写入", "no write"),
        [
            L("合法观察或旧法／障碍审查回答", "lawful observation or audited answer"),
            L("保留对应呈现见证与原状态", "retains presentation witness intact"),
        ],
    )
    leaf(
        70,
        494,
        L("拒绝 J(r)", "Refusal J(r)"),
        L("无写入", "no write"),
        [
            L("类型化精确拒绝及处置等式", "typed refusal and disposition equation"),
            L("被拒提交自身保留残差承担对象", "refused submission retains residual bearer"),
        ],
    )
    leaf(
        810,
        286,
        L("行动 A(r)", "Action A(r)"),
        L("整账写入", "whole write"),
        [
            L("顺序行动运输旧债 ／ 新债准入 R ⊔ D", "sequential transport / debt admission R ⊔ D"),
            L("新责任以严格预算下降完成首写", "fresh row makes paid first write B(t) < B(s)"),
            L("生成完整责任写回与实际后继", "delivers whole writeback and actual next"),
        ],
        True,
    )
    leaf(
        810,
        494,
        L("同源修订 U(r)", "Revision U(r)"),
        L("首写迁移", "first write"),
        [
            L("旧法精确失败与同一责任行修订核", "exact failure; revision core on same row"),
            L("最小余面首写，旧债谱系继续存活", "initial-coface first write; old debt stays live"),
            L("旧行与新行共同进入修订后继", "old and new rows jointly enter successor"),
        ],
        True,
    )
    rule(742)
    txt(
        720,
        804,
        L(
            "不存在第五类账外法外权威；终结基本规范预设与法外主权决断的无穷倒退",
            "No fifth off-ledger authority: ends infinite regress of Grundnorm or sovereign exception",
        ),
        27,
        VERMILION,
        600,
        "middle",
        1340,
    )
    txt(
        720,
        850,
        L(
            "一般执行穷尽（定理 4.2）与同一宪制点的非空实现（定理 4.3）分别独立证明",
            "General exhaustiveness (Theorem 4.2) and inhabited realization at {i:c}{isub:m} (Theorem 4.3) proved separately",
        ),
        26,
        INK,
        anchor="middle",
        max_width=1340,
    )
    save(
        "03-root-law",
        h,
        {
            "focus": "four-way exhaustive root law and exclusion of fifth off-ledger authority",
            "proofLocation": "Theorems 4.2-4.3, Proposition 6.1; Supplement A.2-A.4, B.1-B.2",
        },
    )


def refusal():
    h = start(
        880,
        L("首次拒绝与节点自身支付上的救济", "First refusal and recourse on the node's own payment"),
        L(
            "错投节点的真实外部支付被精确拒绝且无世界写入；同一拒绝节点读取自身既有的支付 q_r 与典范立法，分别生成普通修复后继和严格不同的修订后继。",
            "A genuine payment misdirected to another node is refused with no write; at that very refusal node, its own payment q_r and canonical legislation yield ordinary repair and a strictly distinct revised successor.",
        ),
    )
    panel(40, 44, "A", "错投外部提案：精确拒绝且不倒改已付前缀", "Misdirected external proposal: exact refusal without altering prior prefix")
    rect(50, 80, 470, 132, HAIR)
    txt(285, 129, L("相邻节点的真实支付 {i:q}{sub:1} ≠ {i:q}{sub:0}", "genuine payment {i:q}{sub:1} ≠ {i:q}{sub:0}"), 27, INK, 600, "middle", 440)
    txt(285, 174, L("有真实来源，但不匹配当前节点", "genuine source; mismatched node"), 26, SLATE, anchor="middle", max_width=440)
    arrow(529, 146, 641, 146, SLATE, "ink")
    path("M 653 116 L 653 176", VERMILION, 5)
    txt(711, 131, L("唯一首次拒绝 {i:r}：外部接受为空", "Unique first refusal {i:r}: external acceptance empty"), 27, VERMILION, 600, max_width=670)
    txt(711, 177, L("被拒提交保留承担者；无世界写入", "Refused submission retains bearer; no world write"), 27, INK, max_width=670)
    rule(247)
    panel(40, 299, "B", "同一拒绝节点 {i:r}：自身支付救济与典范修法分轨", "At refusal node {i:r}: node-payment recourse versus canonical revision")
    rect(50, 356, 350, 142, DEEP, width=2.2)
    txt(225, 402, L("节点自身支付 {i:q}{isub:r}", "node payment {i:q}{isub:r}"), 28, DEEP, 600, "middle", 322)
    txt(225, 446, L("本节点既有原生发生", "native to node {i:r}"), 26, SLATE, anchor="middle", max_width=322)
    arrow(408, 427, 492, 427, DEEP, "deep")
    rect(500, 356, 462, 142, HAIR)
    txt(731, 402, L("同支付普通修复（深度 {i:d}{isub:r}）", "ordinary repair at depth {i:d}{isub:r}"), 27, DEEP, 600, "middle", 432)
    txt(731, 446, L("保留甲地位、行 {i:δ} 与 {i:K} = 1 退出", "keeps A's standing, row {i:δ}, {i:K} = 1"), 26, INK, anchor="middle", max_width=432)
    arrow(970, 427, 1042, 427, DEEP, "deep")
    rect(1050, 356, 340, 142, DEEP, width=2.2)
    txt(1220, 402, L("普通实际后继", "ordinary successor"), 28, DEEP, 600, "middle", 312)
    txt(1220, 446, L("单点状态载体 · 保旧法", "unit carrier · old law"), 26, SLATE, anchor="middle", max_width=312)
    txt(1220, 565, "≠", 43, VERMILION, 600, "middle")
    rect(50, 616, 350, 142, DEEP, width=2.2)
    txt(225, 661, L("该节点的典范立法", "canonical legislation"), 28, DEEP, 600, "middle", 322)
    txt(225, 705, L("节点自身提案仍获接受", "node proposal accepted"), 26, SLATE, anchor="middle", max_width=322)
    arrow(408, 687, 492, 687, DEEP, "deep")
    rect(500, 616, 462, 142, HAIR)
    txt(731, 661, L("同源条件修宪路线", "same-source law revision"), 28, DEEP, 600, "middle", 432)
    txt(731, 705, L("精确失败、首写与责任承接", "exact failure and first write"), 26, INK, anchor="middle", max_width=432)
    arrow(970, 687, 1042, 687, DEEP, "deep")
    rect(1050, 616, 340, 142, DEEP, width=2.2)
    txt(1220, 661, L("修订实际后继", "revised successor"), 28, DEEP, 600, "middle", 312)
    txt(1220, 705, L("自然数状态载体 ℕ", "natural-number carrier ℕ"), 26, SLATE, anchor="middle", max_width=312)
    txt(
        720,
        825,
        L(
            "同源事件经合法依赖类型运输连接；单点载体与自然数载体严格分离两类后继",
            "Lawful transport links the source event; unit and natural-number carriers separate the successors",
        ),
        26,
        INK,
        anchor="middle",
        max_width=1340,
    )
    save(
        "04-refusal",
        h,
        {
            "focus": "unique first refusal, node-payment recourse, and Unit vs Nat successor separation",
            "proofLocation": "Proposition 5.4; Supplement A.5",
        },
    )


def observer_bridge():
    h = start(
        980,
        L(
            "源生社会观察器 O_soc、跨层权威边界与隐藏纤维／来源精化对照",
            "Society observer O_soc, cross-tier authority boundary, and hidden-fiber / provenance controls",
        ),
        L(
            "A：社会观察器 O_soc 中两条真实源路径 ω_L ≠ ω_R 共享正规化可见像 v_soc 而有理数权威值 1 ≠ 0，生成附着边界 ∂_O。B：Arrow、GS、Sen 可见规则与双边匹配 (7,7) 及防虚构受迹叙事均无法解码 K_soc。C：隐藏权威纤维 O_hid 负控对比恒等观察器 O_id 与独立修复源族 Ω_d 的失败种类精化。",
            "A: In O_soc, distinct paths ω_L ≠ ω_R share normalized visible image v_soc with rational authorities 1 ≠ 0, inducing boundary ∂_O. B: Arrow, GS, and Sen rules, bilateral matching (7,7), and trace-checked narratives keep visible properties yet fail authority completeness. C: Hidden-fiber O_hid negative control contrasted with identity O_id and separate repair family Ω_d.",
        ),
    )
    panel(
        40,
        42,
        "A",
        "源生社会观察器 {i:O}{sub:soc} 上的垂直权威核与附着边界（例 5.1、定理 5.13(1)）",
        "Vertical authority kernel and boundary on {i:O}{sub:soc} (Example 5.1, Theorem 5.13(1))",
    )
    rect(55, 76, 390, 96, DEEP, width=2.2)
    txt(250, 115, L("左真实源路径 ω{sub:L}", "left actual path ω{sub:L}"), 26, DEEP, 600, "middle", 365)
    txt(250, 152, L("已履行有理数权威 {i:K}{sub:soc}(ω{sub:L}) = 1", "fulfilled authority {i:K}{sub:soc}(ω{sub:L}) = 1"), 25, INK, anchor="middle", max_width=365)

    rect(55, 224, 390, 96, DEEP, width=2.2)
    txt(250, 263, L("右真实源路径 ω{sub:R}", "right actual path ω{sub:R}"), 26, DEEP, 600, "middle", 365)
    txt(250, 300, L("已履行有理数权威 {i:K}{sub:soc}(ω{sub:R}) = 0", "fulfilled authority {i:K}{sub:soc}(ω{sub:R}) = 0"), 25, INK, anchor="middle", max_width=365)

    biarrow(250, 178, 250, 218, VERMILION, "acc", 2.6)
    txt(355, 206, L("垂直对合 τ", "involution τ"), 25, VERMILION, 600, "middle")

    arrow(455, 124, 625, 182, SLATE, "ink")
    arrow(455, 272, 625, 214, SLATE, "ink")
    txt(540, 140, "forget", 25, SLATE, anchor="middle")

    rect(635, 132, 360, 134, HAIR)
    txt(815, 174, L("同一正规化可见像 {i:v}{sub:soc}", "shared visible image {i:v}{sub:soc}"), 27, INK, 600, "middle", 335)
    txt(815, 212, L("forget(ω{sub:L}) = forget(ω{sub:R})", "forget(ω{sub:L}) = forget(ω{sub:R})"), 25, SLATE, anchor="middle", max_width=335)
    txt(815, 247, L("存在选左路径的截面 {i:s}{sub:L}", "section {i:s}{sub:L} selects left path"), 24, DEEP, 600, "middle", max_width=335)

    rect(1040, 114, 355, 170, VERMILION, fill=WASH, width=2.2)
    txt(1217, 156, L("源生附着边界 ∂{sub:O}", "Attachment boundary ∂{sub:O}"), 27, VERMILION, 600, "middle", 330)
    txt(1217, 198, L("ω{sub:L} ≠ ω{sub:R} 且 1 ≠ 0", "ω{sub:L} ≠ ω{sub:R} and 1 ≠ 0"), 25, INK, anchor="middle", max_width=330)
    txt(1217, 236, L("无忠实重构 · 无权威因子化", "no authority factorization"), 25, VERMILION, 600, "middle", max_width=330)
    arrow(1002, 199, 1032, 199, VERMILION, "acc")

    rule(352)
    panel(
        40,
        394,
        "B",
        "在 {i:O}{sub:soc} 上经可见商因子化的四类机制：给定可见公理见证，权威完备性为空（定理 5.13(2),(4)）",
        "Visibly factored mechanisms on {i:O}{sub:soc}: given visible axioms, AuthComp = ∅ (Theorem 5.13(2),(4))",
    )
    cards = [
        (
            45,
            L("Arrow 福利规则", "Arrow welfare"),
            [
                L("无限制域 · 弱帕累托", "unrestricted · Pareto"),
                L("IIA · 非独裁原样保留", "IIA · non-dictator"),
                L("集体序在纤维恒同", "order fixed on fiber"),
            ],
        ),
        (
            385,
            L("GS 防操纵选择", "GS choice rule"),
            [
                L("≥3 结果 · 满射", "≥3 outcomes · onto"),
                L("抗单边偏离原样保留", "strategy-proof kept"),
                L("选中项在纤维恒同", "choice fixed on fiber"),
            ],
        ),
        (
            725,
            L("Sen 最小自由", "Sen liberty rule"),
            [
                L("无限制域 · 弱帕累托", "unrestricted · Pareto"),
                L("双向个人决定权保留", "minimal liberty kept"),
                L("集体序在纤维恒同", "order fixed on fiber"),
            ],
        ),
        (
            1065,
            L("匹配与受迹叙事", "Matching & story"),
            [
                L("正值可见平衡 (7, 7) 成立", "positive balance (7, 7)"),
                L("防虚构：仅支持有迹原子", "rejects unwitnessed claims"),
                L("共同叙事纤维 ω{sub:L} ≠ ω{sub:R}", "fiber ω{sub:L} ≠ ω{sub:R} non-unit"),
            ],
        ),
    ]
    for x, title, lines in cards:
        rect(x, 422, 330, 178, HAIR)
        txt(x + 165, 462, title, 27, DEEP, 600, "middle", 308)
        text_lines(x + 165, 504, lines, 24, INK, anchor="middle", gap=34, max_width=308)

    rect(90, 620, 1260, 62, VERMILION, width=2.2)
    txt(
        720,
        660,
        L(
            "共同判决：给定可见公理见证及受迹支持， ¬∃ {i:d}, ∀ ω, {i:d}({i:q}(forget(ω))) = {i:K}{sub:soc}(ω)",
            "Joint verdict: given visible axioms and trace support, ¬∃ {i:d}, ∀ ω, {i:d}({i:q}(forget(ω))) = {i:K}{sub:soc}(ω)",
        ),
        25,
        VERMILION,
        600,
        "middle",
        1220,
    )

    rule(706)
    panel(
        40,
        748,
        "C",
        "隐藏权威纤维负控 {i:O}{sub:hid} 与两类正向恢复对照（定理 5.13(1),(3) 及定理 5.10–5.11）",
        "Hidden-fiber negative control {i:O}{sub:hid} vs. two positive controls (Theorems 5.13 & 5.10-5.11)",
    )
    rect(45, 778, 435, 152, VERMILION, width=2.3)
    txt(262, 820, L("隐藏纤维负控 {i:O}{sub:hid} : {i:V} × {i:H} → {i:V}", "Hidden fiber {i:O}{sub:hid} : {i:V} × {i:H} → {i:V}"), 26, VERMILION, 600, "middle", 410)
    txt(262, 862, L("如 {i:H} = Bool 翻转，拉回剖面恒同", "{i:H} = Bool swap; pullbacks fixed"), 24, INK, anchor="middle", max_width=410)
    txt(262, 902, L("{i:v}{sub:0} ∈ {i:V} 时权威因子化为空", "for {i:v}{sub:0} ∈ {i:V}, no authority factorization"), 24, VERMILION, 600, "middle", max_width=410)

    rect(515, 778, 410, 152, DEEP, width=2.2)
    txt(720, 820, L("恒等观察器正控 {i:O}{sub:id}", "Identity control {i:O}{sub:id}"), 26, DEEP, 600, "middle", 385)
    txt(720, 862, L("forget = id{sub:Ω}（零遗忘投影）", "forget = id{sub:Ω} (zero loss)"), 24, INK, anchor="middle", max_width=385)
    txt(720, 902, L("完整实现双侧与自然权威重构", "full natural reconstruction"), 24, DEEP, 600, "middle", max_width=385)

    rect(960, 778, 435, 152, DEEP, width=2.2)
    txt(1177, 820, L("独立修复源族 Ω{isub:d}（§5.10–5.11）", "Separate repair family Ω{isub:d}"), 26, DEEP, 600, "middle", 410)
    txt(1177, 862, L("粗读出 ρ{isub:d} = (0, ∅) · 概率 1/2", "coarse ρ{isub:d} = (0, ∅) · prob 1/2"), 24, INK, anchor="middle", max_width=410)
    txt(1177, 902, L("保留源失败种类 φ({i:x}) 分化为 1 与 0", "failure kind φ({i:x}) splits 1 and 0"), 24, DEEP, 600, "middle", max_width=410)

    save(
        "08-observer-bridge",
        h,
        {
            "focus": "O_soc observer-kernel bridge across Arrow, GS, Sen, matching, narrative, plus O_hid and provenance controls",
            "proofLocation": "Theorem 5.13, Theorems 5.10-5.11; Supplement C.6, F.3-F.4",
        },
    )


def regeneration():
    h = start(
        930,
        L("任意深度的同发生六项续生与精确访问接续", "All-depth same-occurrence sixfold regeneration and exact visit splice"),
        L(
            "每个自然数深度 d 的同一完整支付 p_d 共同投影出六项续生保证，且本次实际下一宪制访问精确等于下一深度入口 v^+(g) = v_{d+1}。",
            "At every depth d, one complete payment p_d jointly projects six regeneration guarantees, and its actual next constitutional visit equals the next depth's entry v^+(g) = v_{d+1}.",
        ),
    )
    rect(40, 40, 270, 130, VERMILION, fill=WASH, width=2.7, radius=0)
    txt(175, 77, L("完整支付", "complete payment"), 29, VERMILION, 600, "middle", 244)
    txt(175, 117, "{i:p}{isub:d}", 38, VERMILION, 600, "middle")
    txt(175, 153, L("任意深度 {i:d} ∈ ℕ", "every depth {i:d} ∈ ℕ"), 26, SLATE, anchor="middle", max_width=244)
    txt(635, 82, L("同一次支付，六项共同投影", "one payment, six joint projections"), 25, SLATE, anchor="middle")
    path("M 310 105 L 910 105", VERMILION, 2.5)
    arrow(360, 105, 360, 160, VERMILION, "acc")
    arrow(910, 105, 910, 160, VERMILION, "acc")
    path("M 360 160 L 360 690 M 910 160 L 910 690", VERMILION, 2.5)
    rows = [
        (
            190,
            400,
            "1 既有法与谱系续接",
            "1 Law and lineage continue",
            ["既有法面、责任谱系与继承行", "在整账演化中一并保留"],
            ["Existing law surface, lineage, and", "inherited rows remain intact."],
        ),
        (
            190,
            950,
            "2 普通退出不收缩",
            "2 Ordinary exit noncontracting",
            ["当前与下一发生均有真实退出", "{i:K}{isub:d} ≤ {i:K}{isub:d+1}（本构造 1 ≤ 1）"],
            ["Both current and next have exit;", "{i:K}{isub:d} ≤ {i:K}{isub:d+1} (here 1 ≤ 1)."],
        ),
        (
            370,
            400,
            "3 捕获纤维精确修复",
            "3 Captured fiber repaired",
            ["全捕获退出为空；目标程序", "在下一访问安装并恢复退出"],
            ["Captured exit is empty; target", "program restores exit at {i:d} + 1."],
        ),
        (
            370,
            950,
            "4 残差承担者与核验保留",
            "4 Residual bearer retained",
            ["开放结算残差与承担者不变", "责任后态与本次支付对齐"],
            ["Open residual and bearer stay;", "post-state matches payment {i:p}{isub:d}."],
        ),
        (
            550,
            400,
            "5 后继修法路线保留",
            "5 Revision route continues",
            ["保留忠实余面映射及深度 0", "实际消费同源修法核收据"],
            ["Keeps faithful coface map and", "depth-0 revision receipt."],
        ),
        (
            550,
            950,
            "6 跨主体责任继续归属",
            "6 Cross-actor attribution",
            ["不同于甲的对手方利益入账", "结算身份与来源关联保持"],
            ["Distinct counterparty interest", "and source incidence remain."],
        ),
    ]
    for y, x, zh, en, zlines, elines in rows:
        rect(x, y, 450, 140, HAIR)
        bus = 360 if x == 400 else 910
        dot(bus, y + 70, 4, VERMILION)
        arrow(bus + 10, y + 70, x - 10, y + 70, DEEP, "deep")
        txt(x + 25, y + 40, L(zh, en), 27, DEEP, 600, max_width=405)
        text_lines(x + 25, y + 80, [L(a, b) for a, b in zip(zlines, elines)], 24, INK, gap=34, max_width=405)
    path("M 360 690 L 360 730 L 530 730 M 910 690 L 910 730 L 530 730", DEEP, 2.4)
    arrow(530, 730, 530, 760, DEEP, "deep")
    rect(310, 770, 440, 110, DEEP, width=2.2)
    txt(530, 813, L("实际下一宪制访问", "actual next constitutional visit"), 26, DEEP, 600, "middle", 410)
    txt(530, 861, "{i:v}{sup:+}({i:g}) = {i:v}{isub:d+1}", 32, DEEP, 600, "middle", 410)
    arrow(760, 825, 930, 825, DEEP, "deep")
    txt(845, 797, L("生成下一发生", "emits next"), 25, SLATE, anchor="middle")
    rect(940, 770, 420, 110, HAIR)
    txt(1150, 813, L("下一深度支付（新发生）", "next payment (distinct)"), 26, INK, 600, "middle", 395)
    txt(1150, 861, "{i:p}{isub:d+1}  (({i:v}{isub:d}, {i:p}{isub:d}) ≠ ({i:v}{isub:d+1}, {i:p}{isub:d+1}))", 24, DEEP, 600, "middle", 395)
    save(
        "05-regeneration",
        h,
        {
            "focus": "all-depth same-occurrence sixfold regeneration and exact next-visit splice",
            "proofLocation": "Theorems 6.2-6.3; Supplement B.6-B.8",
        },
    )


def theory():
    h = start(
        800,
        L("理论采用、母法失败修宪与旧责任的跨修订清算", "Theory adoption, exact failure revision, and cross-revision debt settlement"),
        L(
            "上部区分实际理论采用的普通后继与同源母法精确失败触发的修宪路线；下部追踪同一旧责任行 δ 在修订首写中迁移为活行 i(δ)，直至后续原生履行才归档结清。",
            "Upper panel: ordinary successor of theory adoption versus same-source revision from exact failure. Lower panel: old responsibility row δ migrates as live row i(δ) at the first revised write and settles only upon later native fulfillment.",
        ),
    )
    rect(40, 44, 398, 204, DEEP, width=2.2)
    txt(239, 89, L("理论 {i:T} 的实际采用", "actual adoption of theory {i:T}"), 28, DEEP, 600, "middle", 370)
    text_lines(
        239,
        136,
        [
            L("分类与政策选定入账", "classification and policy"),
            L("效果 {i:e}{isub:s} 经独立核验 {i:K}({i:s}, {i:e}{isub:s})", "effect {i:e}{isub:s} checked by {i:K}({i:s}, {i:e}{isub:s})"),
        ],
        25,
        INK,
        anchor="middle",
        gap=42,
        max_width=370,
    )
    arrow(447, 146, 524, 146, DEEP, "deep")
    rect(534, 44, 382, 204, HAIR)
    txt(725, 89, L("普通实际后继（2 点支持）", "ordinary successor (2-pt)"), 27, DEEP, 600, "middle", 354)
    txt(725, 141, L("保留旧理论 {i:T} 法面", "retains old theory {i:T}"), 27, INK, anchor="middle", max_width=354)
    txt(725, 183, L("与修订后继（≥3 点）严格不等", "distinct from revised next"), 25, SLATE, anchor="middle", max_width=354)
    rect(1036, 44, 362, 204, HAIR)
    txt(1217, 89, L("母法精确失败（同源审计）", "exact mother-law failure"), 27, DEEP, 600, "middle", 334)
    text_lines(
        1217,
        136,
        [
            L("针对同一责任行生成最小余面", "minimal coface on same row"),
            L("触发同源修法 U({i:r})", "triggers same-source U({i:r})"),
        ],
        25,
        INK,
        anchor="middle",
        gap=42,
        max_width=334,
    )
    path("M 1217 258 L 1217 312 L 725 312 L 725 412", SLATE, 2.2, "ink")
    txt(40, 372, L("同一责任行的跨修宪迁移与后来原生履行", "Migration across revision and later native fulfillment"), 28, INK, 600)
    rect(40, 427, 398, 316, HAIR, radius=0)
    rect(534, 427, 382, 316, VERMILION, width=2.7, radius=0)
    rect(1036, 427, 362, 316, DEEP, width=2.2, radius=0)
    for x, w in [(40, 398), (534, 382), (1036, 362)]:
        path(f"M {x} 504 L {x+w} 504", HAIR, 1.6)
    txt(239, 475, L("修订前旧责任 {i:q}", "pre-revision row {i:q}"), 28, INK, 600, "middle", 370)
    txt(725, 475, L("修订首写目标（访问 1）", "first write (visit 1)"), 28, VERMILION, 600, "middle", 354)
    txt(1217, 475, L("后来原生履行清算", "later native fulfillment"), 28, DEEP, 600, "middle", 334)
    txt(239, 562, "{i:δ}", 40, DEEP, 600, "middle")
    txt(725, 562, "{i:i}({i:δ})", 40, DEEP, 600, "middle")
    txt(1217, 562, "{i:i}({i:δ})", 40, DEEP, 600, "middle")
    arrow(446, 559, 526, 559, DEEP, "deep")
    arrow(924, 559, 1028, 559, DEEP, "deep")
    txt(486, 611, L("迁移", "migrate"), 25, SLATE, anchor="middle")
    txt(978, 611, L("履行", "fulfill"), 25, SLATE, anchor="middle")
    text_lines(
        239,
        629,
        [L("旧授权下已发生义务", "incurred under old law"), L("保留来源锚点与承担者", "anchor and bearer kept")],
        26,
        INK,
        anchor="middle",
        gap=44,
        max_width=370,
    )
    text_lines(
        725,
        629,
        [L("旧授权已替代，谱系保持", "authority superseded"), L("继承槽仍为活债 {i:q}′", "row {i:q}′ remains live")],
        26,
        VERMILION,
        600,
        "middle",
        gap=44,
        max_width=354,
    )
    text_lines(
        1217,
        629,
        [L("在访问 1 消费履行事件", "native retirement event"), L("写入终结档案并产生后继", "terminal archive & next")],
        26,
        INK,
        anchor="middle",
        gap=44,
        max_width=334,
    )
    save(
        "06-theory",
        h,
        {
            "focus": "theory adoption effect check, self-U8 migration of live debt, and later settlement",
            "proofLocation": "Theorem 7.4; Supplement C.4",
        },
    )


def paid_frontier():
    h = start(
        750,
        L("已付自由前沿的严格扩张与恒定瞬时容量", "Strict expansion of the paid freedom frontier with constant instantaneous capacity"),
        L(
            "上部显示任意合规付款保留整个旧权威像并在真实目标由目标原生付款兑现像外新发生；下部对比相邻时刻可恒为 1 的瞬时退出容量。",
            "Upper panel: every lawful payment retains the entire old authority image and realizes a new outside occurrence via the target's native payment. Lower panel: instantaneous exit capacity may stay K = 1 throughout.",
        ),
    )
    panel(40, 46, "A", "历史发生前沿：旧权威像完整保留，真实目标严格新增像外项", "Historical frontier: old authority image kept, outside occurrence added at target")
    rect(60, 108, 480, 280, DEEP, width=2.3, radius=0)
    txt(300, 153, L("当前已付前沿权威像", "current paid authority image"), 28, DEEP, 600, "middle", 452)
    txt(300, 192, "{i:A}{isub:i}", 35, DEEP, 600, "middle")
    for x in [164, 300, 436]:
        dot(x, 264, 10, DEEP)
    txt(300, 333, L("每枚 κ(γ{isub:k}) 保有唯一付款发生身份", "each κ(γ{isub:k}) keeps payment identity"), 24, SLATE, anchor="middle", max_width=452)
    path("M 556 229 C 700 229, 760 216, 900 216 L 1280 216 L 1280 236", DEEP, 2.4, "deep")
    txt(669, 184, L("合规付款 {i:p} ∈ P{isub:i}", "payment {i:p} ∈ P{isub:i}"), 26, DEEP, 600, "middle", 230)
    txt(669, 282, L("完整承接至目标", "full contract kept"), 25, SLATE, anchor="middle", max_width=230)
    rect(800, 108, 580, 280, VERMILION, width=2.3, radius=0)
    txt(1090, 153, L("下一已付前沿权威像", "next paid authority image"), 28, VERMILION, 600, "middle", 552)
    txt(1090, 192, "{i:A}{isub:i+1}", 35, VERMILION, 600, "middle")
    rect(828, 230, 364, 73, DEEP, width=1.8, radius=0)
    for x in [886, 1010, 1134]:
        dot(x, 264, 10, DEEP)
    circle(1280, 264, 24, VERMILION, fill="white", width=2.8)
    dot(1280, 264, 7, VERMILION)
    txt(1010, 333, L("旧像 {i:A}{isub:i} 完整保留", "old image {i:A}{isub:i} retained"), 24, INK, 600, "middle", 320)
    txt(1010, 367, L("不删减既有实现", "no prior item lost"), 24, SLATE, anchor="middle", max_width=320)
    txt(1280, 333, L("κ(γ{isub:i+1}) ∉ {i:A}{isub:i}", "κ(γ{isub:i+1}) ∉ {i:A}{isub:i}"), 24, VERMILION, 600, "middle", 200)
    txt(1280, 367, L("目标原生付款兑现", "target payment"), 24, SLATE, anchor="middle", max_width=200)
    txt(720, 443, "{i:C}{isub:r} ≺{sub:can} {i:C}{isub:t}  ⇔  {i:A}{isub:i(r)} ⊊ {i:A}{isub:i(t)}  ⇔  {i:r} < {i:t}   ({i:i}({i:d}) = {i:i}{sub:0} + {i:d})", 27, DEEP, 600, "middle", 1340)
    rule(480)
    panel(40, 526, "B", "瞬时容量与历史前沿正交：昨日收据付不了今日生活", "Instantaneous capacity versus realized history: yesterday's receipt cannot pay today")
    txt(720, 618, "{i:K}{isub:i} = {i:K}{isub:i+1} = 1    ∧    {i:A}{isub:i} ⊊ {i:A}{isub:i+1}", 35, DEEP, 600, "middle")
    txt(
        720,
        690,
        L(
            "{i:K}{isub:i} 计数当刻可并行支持的退出匹配数；严格典范进展比较已实际付款兑现的自由发生历史",
            "{i:K}{isub:i} counts concurrent exits now; strict canonical progress orders the realized history of paid occurrences",
        ),
        26,
        INK,
        anchor="middle",
        max_width=1350,
    )
    save(
        "07-paid-frontier",
        h,
        {
            "focus": "strict proper inclusion of paid occurrence images alongside unchanged scalar capacity",
            "proofLocation": "Theorems 1.2-1.3; Supplement E.1-E.2",
        },
    )


def master_architecture():
    h = start(
        904,
        L(
            "典范社会总定理：六大宪制支柱咬合与三道同源负控门禁",
            "The Canonical Society Theorem: six interlocking pillars and three paired negative-control gates",
        ),
        L(
            "上部展示非空社会族 S_h 从轨迹主体生成、四分根法与携证立法、五门真实退出、全深度续生、每笔合规付款严格进展到整账守恒与四接口的正向闭合；下部并列对应的三组形式化不可能性门禁。",
            "Upper panel: positive closure of S_h from subject quotient and joint foundation through fourfold root law, five-gate exit, all-depth regeneration, strict paid progress, and whole-ledger conservation. Lower panel: three paired impossibility gates.",
        ),
    )
    panel(
        40,
        46,
        "A",
        "正向联合实现：同一非空社会族 {i:S}{isub:h} 上的六大咬合支柱（定理 1.1–7.7）",
        "Positive joint realization: six interlocking pillars in society family {i:S}{isub:h} (Theorems 1.1–7.7)",
    )
    cols = [36, 514, 992]
    bw = 412
    top_y, bh = 82, 168
    bot_y = 298
    top_cards = [
        (
            L("1. 主体商与同根基础 (§2–§3)", "1. Subject quotient & base (§2–§3)"),
            [
                L("谱系商双射 Φ : {i:U}{isub:ω}/∼ ≅ {i:A}{isub:ω}", "Quotient Φ : {i:U}{isub:ω}/∼ ≅ {i:A}{isub:ω}"),
                L("四域恢复；四面预发射同根续约", "4-domain reuse; 4-face root renewal"),
                L("跨宇宙可靠完备记忆等价 (§3.7)", "Cross-universe memory eq. (§3.7)"),
            ],
        ),
        (
            L("2. 四分根法与携证立法 (§4)", "2. Fourfold root law (§4)"),
            [
                L("{i:P} ∨ {i:J} ∨ {i:A} ∨ {i:U}；{i:W} ⇔ {i:A} ∨ {i:U}", "{i:P} ∨ {i:J} ∨ {i:A} ∨ {i:U}; {i:W} ⇔ {i:A} ∨ {i:U}"),
                L("同一宪制点 {i:c}{isub:m} 非空与两层修宪", "Nonempty {i:c}{isub:m} & two-tier {i:U}"),
                L("内生改良 / 修宪二分与同发生立法", "Reform / revolution & same-tick law"),
            ],
        ),
        (
            L("3. 五门退出与来源精化 (§5)", "3. Five-gate exit & source (§5)"),
            [
                L("同一 ({i:c},{i:j}) 五门匹配充要条件", "Five-gate iff on one ({i:c},{i:j})"),
                L("四阶段生命周期与四类反报复", "4-stage exit & 4 anti-retaliation"),
                L("失败种类 ϕ({i:x}) 恢复唯一修复与 (1,0)", "Failure kind ϕ({i:x}) restores repair"),
            ],
        ),
    ]
    bot_cards = [
        (
            L("6. 整账守恒与四接口 (§7–§9)", "6. Ledger & interfaces (§7–§9)"),
            [
                L("改法首写活态迁移旧责 {i:δ} ↦ {i:i}({i:δ})", "Revision migrates {i:δ} ↦ {i:i}({i:δ})"),
                L("空账存外部责任 Λ{isub:n}；风险拆合单射", "Empty ledger keeps Λ{isub:n}; split-merge"),
                L("经济宪法五原则与四下游开放接口", "5 principles & 4 open interfaces"),
            ],
        ),
        (
            L("5. 每笔付款与严格进展 (§1.5–1.6)", "5. Payments & progress (§1.5–1.6)"),
            [
                L("∀ {i:p} ∈ {i:P}{isub:i(d)} 完整承接制度合同", "∀ {i:p} ∈ {i:P}{isub:i(d)} keeps contract"),
                L("旧前沿全保，目标原生支付添新项", "Old image kept; native pay adds"),
                L("{i:K}{isub:d} = 1 恒定而 {i:A}{isub:i(r)} ⊊ {i:A}{isub:i(t)}", "{i:K}{isub:d} = 1 while {i:A}{isub:i(r)} ⊊ {i:A}{isub:i(t)}"),
            ],
        ),
        (
            L("4. 全深度续生与共终修宪 (§6)", "4. All-depth & cofinal {i:U} (§6)"),
            [
                L("∀ {i:d} ∈ ℕ 单次支付同步兑现六保证", "∀ {i:d} ∈ ℕ one pay: 6 guarantees"),
                L("精确接续 {i:v}⁺({i:g}) = {i:v}{isub:d+1}；破裂分离", "{i:v}⁺({i:g}) = {i:v}{isub:d+1}; split 2 ≠ 3"),
                L("∀ {i:n},{i:h} ∃ {i:m} > {i:n} 同拍修法与丰富出生", "∀ {i:n},{i:h} ∃ {i:m} > {i:n} joint {i:U} & birth"),
            ],
        ),
    ]
    for idx, (title, lines) in enumerate(top_cards):
        x = cols[idx]
        rect(x, top_y, bw, bh, DEEP, WASH, width=2.1, radius=4)
        path(f"M {x} {top_y + 46} L {x + bw} {top_y + 46}", HAIR, 1.5)
        txt(x + bw // 2, top_y + 34, title, 25, DEEP, 600, "middle", bw - 18)
        text_lines(x + bw // 2, top_y + 82, lines, 24, INK, anchor="middle", gap=35, max_width=bw - 18)

    for idx, (title, lines) in enumerate(bot_cards):
        x = cols[idx]
        rect(x, bot_y, bw, bh, DEEP, "white", width=2.1, radius=4)
        path(f"M {x} {bot_y + 46} L {x + bw} {bot_y + 46}", HAIR, 1.5)
        txt(x + bw // 2, bot_y + 34, title, 25, DEEP, 600, "middle", bw - 18)
        text_lines(x + bw // 2, bot_y + 82, lines, 24, INK, anchor="middle", gap=35, max_width=bw - 18)

    arrow(454, 166, 508, 166, DEEP, "deep", width=2.4)
    arrow(932, 166, 986, 166, DEEP, "deep", width=2.4)
    arrow(1198, 256, 1198, 290, DEEP, "deep", width=2.4)
    arrow(986, 382, 932, 382, DEEP, "deep", width=2.4)
    arrow(508, 382, 454, 382, DEEP, "deep", width=2.4)
    arrow(242, 290, 242, 256, SLATE, "ink", dashed=True, width=2.1)
    txt(720, 282, L("正向携证闭环：无外加神谕、无账外第五权、无旧责蒸发", "Proof-carrying loop: no oracle, no fifth write channel, no erased debt"), 24, SLATE, 600, "middle", 880)

    rule(490)
    panel(
        40,
        534,
        "B",
        "同源黑暗孪生与观察核负控：抽去任一承重条件即触发精确不可能性",
        "Paired dark twins & kernel no-gos: dropping any pillar triggers impossibility",
    )
    gate_y, gh = 570, 294
    gates = [
        (
            L("门禁 I｜主体、容量与失范 (§2–§3)", "Gate I: Subject & anomie (§2–§3)"),
            [
                L("空 AI 种子 ⇒ 续生面 = ∅", "Empty AI seed ⇒ renewal = ∅"),
                L("三环和 2 ≠ 0 排除个人标量势", "3-cycle sum 2 rules out a potential"),
                L("失范相 {i:k} > {i:C} 全额扣减运行 = ∅", "Anomie {i:k} > {i:C} full debit = ∅"),
                L("完全清偿 ⇒ 购买力与价格域 = ∅", "Settled ⇒ price & standing = ∅"),
            ],
        ),
        (
            L("门禁 II｜断裂与观察核 (§4–§5)", "Gate II: Rupture & kernel (§4–§5)"),
            [
                L("无搜索写入或错投接受", "No search write or misrouting"),
                L("断裂无同账后继；免修订终态 = ∅", "Rupture has no next; final = ∅"),
                L("粗读出 ρ{isub:d} 阻断任意宇宙解码", "Coarse ρ{isub:d} blocks decoding"),
                L("阿罗 / GS / 森、匹配与叙事权威 = ∅", "Arrow/GS/Sen, match & trace = ∅"),
            ],
        ),
        (
            L("门禁 III｜逃债幻觉与零预算 (§7)", "Gate III: Debt & budget (§7)"),
            [
                L("缺通路或受捕获 ⇒ 可行退出 = ∅", "No route or capture ⇒ exit = ∅"),
                L("深度 3 耗尽 ≠ 深度 9 ≠ {i:s}{isub:clr} 结清", "Depth 3 ≠ depth 9 ≠ {i:s}{isub:clr} settled"),
                L("公布前后位置不动点 (1 = 0) = ∅", "Fixed-point announce (1 = 0) = ∅"),
                L("耗尽源账保守后继 0 ≤ {i:B}′ ≤ 0", "Conservative step 0 ≤ {i:B}′ ≤ 0"),
            ],
        ),
    ]
    for idx, (title, lines) in enumerate(gates):
        x = cols[idx]
        rect(x, gate_y, bw, gh, VERMILION, "white", width=2.2, radius=4)
        path(f"M {x} {gate_y + 48} L {x + bw} {gate_y + 48}", HAIR, 1.5)
        txt(x + bw // 2, gate_y + 35, title, 25, VERMILION, 600, "middle", bw - 18)
        text_lines(x + bw // 2, gate_y + 88, lines, 24, INK, anchor="middle", gap=52, max_width=bw - 18)

    save(
        "09-master-architecture",
        h,
        {
            "focus": "master six-pillar positive architecture and three paired impossibility gates",
            "proofLocation": "Theorem 1.1, Table 1; Sections 1-9",
        },
    )


FIGURES = [
    ("01-exit-case", exit_case),
    ("09-master-architecture", master_architecture),
    ("02-generation", generation),
    ("03-root-law", root_law),
    ("04-refusal", refusal),
    ("08-observer-bridge", observer_bridge),
    ("05-regeneration", regeneration),
    ("06-theory", theory),
    ("07-paid-frontier", paid_frontier),
]


def main():
    global LANG, CHECK_ONLY
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only", choices=[x[0] for x in FIGURES])
    ap.add_argument("--language", choices=["zh", "en", "both"], default="both")
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()
    CHECK_ONLY = args.check_only
    register_cjk_for_cairo()
    for LANG in ["zh", "en"] if args.language == "both" else [args.language]:
        for name, fun in FIGURES:
            if not args.only or args.only == name:
                fun()
    report = {
        "paperId": "generated-society",
        "edition": "v3",
        "generator": "make_figures_v3.py",
        "preservedV2": "01..07*.{svg,pdf} and manifest.json retain exact Zenodo v2 bytes",
        "printedWidthPt": PRINT_WIDTH,
        "figures": MANIFEST,
    }
    (OUT / ".review-v3").mkdir(exist_ok=True)
    target = (
        ".review-v3/layout-report.json"
        if CHECK_ONLY
        else ("manifest-v3.json" if not args.only and args.language == "both" else ".review-v3/partial-manifest.json")
    )
    (OUT / target).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {"rendered": len(MANIFEST), "manifest": target, "outputs": [x["stem"] for x in MANIFEST]},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
