# 固定源码、完整类型与验收证据

《典范社会总定理》的形式证明选集固定于 [H0mework](https://github.com/Sapientropic/H0mework/tree/2d6fbc96e33b7c4c3cfd91104fda74e3caeda045) 提交 `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045`。仓库 URL、提交号和以下仓内相对路径共同标识来源；当前可得性说明见附录 G。原 Homework 收稿上限仍为 `df421ff600085cbc290a7ae946193961bed7c83b`，各历史证明与认证保留自己的实际 epoch。

## 当前完整对应

| 对象 | 固定范围与实际结果 |
| --- | --- |
| 论文主张 | G0–G27、G2a，共29项；G10–G12及C.13／PT15保持引用接口 |
| 逐主张映射 | 539项：320个生产／直接消费角色条目，219次资源引用 |
| 论文对应 | 37行、299次原声明引用，逐项绑定原来源、实际公开owner、完整声明和类型 |
| 完整证明闭包 | 4091个公开owner，全部所需imports和156项公开资源身份可恢复 |
| 形式验收 | 七包完整构建、1012项声明的trust和完整Lean Expr DAG类型均通过 |
| 公理与定义安全性 | `propext`、`Classical.choice`、`Quot.sound`；`unsafe=0`、`partial=0` |

十份原来源清单的全部345项与原选集共同保留。最终选集包含351个Lean文件根、165个按epoch区分的资源来源键；它们与公开owner或去重资源身份采用不同计数口径。1012项完整类型包括1010个按包／owner／声明去重的主张根，以及实际 `Distributed.Code` 和 `Code.afterDelivery` 两个provider控制根。

[本稿固定公开绑定](records/public-source-binding.json)把正文对应表接到H0的实际选集，而不重复复制证明。每项保存：

- 正文／附录位置及原完整声明的固定来源；
- H0 `docs/generated-society-map.json`中的精确JSON位置、公开模块、文件及SHA；
- 完整声明名、原签名位置、实际类型索引及类型SHA；
- 同一主张的生产、直接消费角色和资源／原认证；
- 依赖补源的实际Git来源、可逆适配及原失败身份。

原声明与直接消费者的阅读记录仍在十份 `*-sources.json` 及 [逐项对应](theorem-correspondence.md) 中。记录里的辅助引理随原完整文件和实际imports编译；它们不被重复计作1012个单独类型根。

## 七个形式入口

下列入口均带前缀 `H0mework.Papers.`；仓内文件为 `Lean/H0mework/Papers/<入口>.lean`。

| 入口 | 实际来源／范围 |
| --- | --- |
| `GeneratedSocietyMInfinity` | e60；G0–G7、首次拒绝长链及原完整基础 |
| `GeneratedSocietyRegeneration` | AB；G8–G9的实际责任出生与同发生六项续生 |
| `GeneratedSocietyInterfaces` | df收稿上下文；G10–G12已引用接口，实际provider另列 |
| `GeneratedSocietyProgress` | 1d7；G13原严格已付进展 |
| `GeneratedSocietyEconomy` | df；G14–G27、G13当前来源实例及实际语法／关系／记忆消费者 |
| `GeneratedSocietyProductivitySupplement` | df；G12实际复制、原根消费及完整所需imports |
| `GeneratedSocietyProtocolInterface` | e0b；独立C.13／PT15接口和同一emitter的whole-ledger／literal-next消费 |

G13的历史1d7证明与df当前实例分别保存。C.13的df核读根与原认证源e0b根字节相同，但H0按明确选择的 `e0b980ffb69e638c9f1e000932f6bb14f778dcdc` 上下文恢复完整imports；该对应不是以单文件SHA把两个递归环境认作相同。协议独立论文的其余材料没有因此并入社会主张。

## 精确版本与实际辅助来源

旧观察中的 `LivingLawRootInquiryCompletionKernel.lean` 精确版本及三个 `Distributed.Recall` 导入边界已经按固定Git对象与实际provider接齐。当前完整选集不再保留这四处材料缺口，也没有以已有同名旧版本替换所选版本。依赖补源的45项上下文及其实际来源逐项保于H0映射的 `source_providers`，并进入本稿公开绑定。

`Distributed.Execution` 使用原资本认证实际绑定的 `7e2cc053821fedbb638122b3b2f8c82134c61ac0` provider，保完整记忆语义。原df单树源码另存，不能用它代替实际依赖环境。其余三个辅助来源分别为：

| 辅助文件 | 实际采用来源与处置 |
| --- | --- |
| `Reaction/Feedback/Quota/Plan.lean` | `59df7e39d81e8698f3cf8507e64b93829bb1cac3`；等式明确保留 `memoryReady` 门控。原df无条件等式在实际paid-memory环境中有内核反例，原失败源码与回执保留 |
| `Reaction/Feedback/Authority/Trace/Challenge.lean` | `6c24593364cd7763e3cdccf8f3654996a6dc8b5f`；补齐真实 `scopeBoundary` carrier和第六事件分支，原不完整体及失败／超时保留 |
| `Reaction/Feedback/Regression.lean` | 固定7e来源，与59df同字节；signals=3时重绑四个原默认记忆字段，原定理类型、证明、其他定义及预算不变 |

Quota和Trace是实际源修订，不能概称为保持原命题不变的证明体适配。另一文件 `Distributed.Regression` 的四字段重绑则是已登记的可逆编译适配，原类型及证明保留。上述辅助闭包的处置与所选主声明、原科学认证分别记账。

## 实际执行与原认证

H0仓内 `evidence/generated-society/acceptance/final-manuscript/` 保存本选集实际回执：

| 入口 | 内容 |
| --- | --- |
| `summary.json`、`entry.json` | 当前通过范围、完整owner／资源恢复和1012项类型绑定 |
| `build/result.json.gz`、`trust/result.json.gz`、`types/result.json.gz` | 七包实际完整构建、type/value信任闭包及完整类型检查 |
| `execution-map.json.gz`、`publication.json` | 执行输入map原字节与公开回执的来源／公开化身份 |
| `attempt-original-provider/`、`attempt-feedback-defaults/` | 两次实际失败原件，原错误和状态不改 |

完整构建为189.546秒；三层验收输入前后身份保持。独立验收位于 `evidence/economic-constitution/acceptance/initial-intake/independent-acceptance.json`，逐项复核实际程序、日志、owner／名称和类型索引。新提交的远端CI尚未执行，本地通过不转写成远端全绿。

原Society strict／ACCEPT／T1与协议原认证各保自己的执行身份。协议原window的9份检查源码、9份setup和8份olean已恢复核对；61项parent回执加window及支持材料共68项逐资源保存。后置custody只固定恢复原件的SHA。原review状态和exit=1负例继续保留，不被本次H0成功改写。

本轮两稿共用的缓存、默认覆盖、旧六篇材料及科学输入身份，见H0 `evidence/economic-constitution/acceptance/initial-intake/cache/current-report.json`。原63个分片记录与52523个旧模块及入口身份保持；新材料追加两个分片。Bell和量子载体沿用原成功artifact，`full_replay=false`。

## 核对与复现

在publish根目录，用任意含固定提交的H0检出核对本稿引用：

```sh
python3 papers/generated-society/scripts/bind_public_sources.py \
  --h0-repo <H0-checkout> --check
```

脚本只读固定Git对象、真实回执和完整类型索引，核对所有539项映射、1012项类型及299次正文来源引用；不编译或改写源仓。省略 `--check` 可刷新本稿的公开绑定和对应表引用。

在H0固定检出中，按 `docs/generated-society-reproduction.md` 执行公开恢复、完整构建、trust、types和 `entry --require-ready`。历史原件的精确逆恢复遵循 `docs/evidence-publication.md` 的原件规则。

`records/h0-source-map.json{,.gz}` 和 `records/economic-expansion-h0-source-map.json{,.gz}` 保持原字节，分别保留早期146根及48dc版本的345项迁移观察。原报告的未解析边界、退出码2和当时缺口是历史事实；当前来源可得性以本页及固定公开绑定为准。

## v3 增补：M7–M10 观察桥接、预发射同根续约、失范相变、携证立法与跨领域 G8 公开入口

v3 新增的正文第 3.6 节（命题 3.2）、第 4.5 节（定理 4.4）、第 5.13 节（例 5.1、定理 5.13）与补充材料第 C.6–C.7 节（命题 C14、定理 C15、命题 C16–C18、定理 C19），完全取自已在同一公开快照 `2d6fbc96e33b7c4c3cfd91104fda74e3caeda045` 中通过内核编译的 `GeneratedSocietyMInfinity` 包（经 `M10WholeProgramRegression.m10WholeProgram`、`M9WholeProgramRegression.m9WholeProgram`、`M8WholeProgramRegression.m8WholeProgram` 与 `M7WholeProgramRegression.m7WholeProgram` 装入 `MInfinityWholeProgramRegression.m4ThroughM10`）：

- **观察因子化迫使定理**：`Lean/H0mework/Versions/Rdf421ff6/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Observer/ReadoutFactorization.lean`
- **任意载体偏好剖面、隐藏权威纤维与三类社会选择观察桥接**：`Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/SocialChoice/M7/{PreferenceReadout,ArrowObserverBridge,GibbardSatterthwaiteObserverBridge,SenObserverBridge}.lean` 及 `.../Regression/Society/M7/SocialChoice/{HiddenFibreControlRegression,SocialChoiceAuthorityBridgeRegression}.lean`
- **双边可见匹配平衡与受迹约束叙事**：`Lean/H0mework/Versions/Re60a8605/ReleaseMaterials/SaturationMonoid/ProcessGame/Society/Matching/VisibleBalance.lean`、`Lean/H0mework/Cognition/Selfhood/Narrative.lean` 及 `.../Regression/Society/M7/{Matching/MatchingAuthorityIdentificationRegression,History/NarrativeAuthorityIdentificationRegression,M7WholeProgramRegression}.lean`
- **无免费续生面、购买力清偿消去与四面预发射同根因子化（M8）**：`Lean/H0mework/Society/Renewal/{RenewalFaceSource,InstalledRenewalProjection}.lean`、`.../Society/Money/PurchasingPowerStanding.lean` 及 `.../Regression/Society/M8/M8WholeProgramRegression.lean`
- **发生率—容量稳定—临界—失范单调相变与超载全额扣减空性（M10）**：`.../Society/Capacity/{OccurrenceCapacityPhase,OccurrenceCapacityTransition,OccurrenceCapacityConsumer}.lean` 及 `.../Regression/Society/M10/M10WholeProgramRegression.lean`
- **活跃改良／修宪二分、忠实终结断裂与同发生携证立法（M9）**：`.../Society/Revision/{SourceGeneratedInstitutionalDichotomy,SourceGeneratedInstitutionalRevision}.lean`、`.../Society/Legislation/ProofCarryingLegislation.lean` 及 `.../Regression/Society/M9/M9WholeProgramRegression.lean`
- **四域主体来源恢复独立复现入口**：H0mework 提交 `fd6147f8c337d88ebf72d91ddadef0aa601e6c2e` 中的 `Lean/H0mework/Papers/SocietyBookCrossDomainG8.lean` 与 `docs/society-book-supplement-reproduction.md`

这 24 个模块在实际编译纪元逐一恢复原字节。观察因子化源于 `df421ff6`，其余取各公开 owner 记录的 `e60a8605` 来源。收稿上限 `df421ff6` 的阅读记录单独保留。续生投影与决议分类两份源码在该上限有后续改动，正文采用实际公开编译的版本。精确 Git blob、SHA-256、行号与直接消费者见 [来源绑定](records/m7-source-binding-v3.json)和[逐项对应](theorem-correspondence-v3.md)。完整类型及实际核验见[第三版复现说明](https://github.com/Sapientropic/H0mework/blob/main/docs/generated-society-v3-reproduction.md)。
