# The Canonical Society Theorem · 典范社会总定理

The Chinese and English papers each consist of a main text and technical
supplement. Start with the four PDFs under
papers/generated-society/build/reading-v3/. The matching Markdown, bibliography,
and editable figure sources are under papers/generated-society/.

Run the following from the extracted directory with Python 3, Pandoc, XeLaTeX,
and the CJK and Latin fonts named in the article styles. The builder uses
latexmk when available.

    python3 verify-inputs.py
    python3 papers/generated-society/scripts/build_reading_v3.py

The supplied vector PDFs are sufficient for this build. To regenerate the
figures, use the figure script with CairoSVG, fontTools and the fonts named in
shared/figure-style/svg_text.py.

The [proof correspondence](papers/generated-society/theorem-correspondence-v3.md)
identifies original declarations, public Lean owners, and their consumers.
The [H0mework reproduction guide](https://github.com/Sapientropic/H0mework/blob/main/docs/generated-society-v3-reproduction.md)
documents kernel and type checks for this edition.

Paper text and original figures are CC BY 4.0. Original code and formalization
are Apache-2.0.
